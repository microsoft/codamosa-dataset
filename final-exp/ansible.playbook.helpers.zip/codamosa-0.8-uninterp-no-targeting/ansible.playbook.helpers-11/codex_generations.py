

# Generated at 2022-06-21 00:33:31.459253
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = [{'name': 'testrole'}]
    loader = DataLoader()
    variable_manager = VariableManager()
    result = load_list_of_roles(ds, 'testrole', None, variable_manager, loader)
    assert result[0].name == 'testrole'



# Generated at 2022-06-21 00:33:38.576253
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    generate_test({
        'role_name': 'test',
        'role_path': '{{ role_executing_path }}/roles/common'
    })

    assert load_list_of_roles() == [
        {
            'role_name': 'test',
            'role_path': '{{ role_executing_path }}/roles/common'
        }
    ]



# Generated at 2022-06-21 00:33:40.226710
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO

    return


# Generated at 2022-06-21 00:33:51.899189
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    tmp = {"include": "role1.yml"}
    assert load_list_of_tasks(
            [tmp],
            lambda : None,
            block=lambda : None,
            role=lambda : None,
            task_include=lambda : None,
            use_handlers=True,
            variable_manager=lambda : None,
            loader=lambda : None,
        ) == [lambda : None]
    assert load_list_of_tasks(
            [tmp],
            lambda : None,
            block=lambda : None,
            role=lambda : None,
            task_include=lambda : None,
            use_handlers=True,
            variable_manager=lambda : None,
            loader=lambda : None,
        ) == [lambda : None]


# Generated at 2022-06-21 00:33:59.511864
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import context
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.template import Templar
    loader = DataLoader()
    variable_manager = VariableManager()
    collection_search_list = []
    ds = []
    play = {}
    hosts = []
    current_role_path = None
    assert load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list) == []
    current_role_path = None
    ds = [OrderedDict([('name', 'test')])]
    play = {}

# Generated at 2022-06-21 00:34:01.973632
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert isinstance(load_list_of_roles([], None), list)



# Generated at 2022-06-21 00:34:12.750203
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play

    ds = [
        {'action': {'module': 'ping'}},
        {'action': {'module': 'ping'}},
        {'block': [
            {'action': {'module': 'shell', 'args': {'_raw_params': 'hostname'}}},
            {'action': {'module': 'ping'}},
        ]}
    ]

    play = Play().load(ds, variable_manager=dict(), loader=dict())
    o = load_list_of_blocks(ds, play)
    for b in o:
        assert isinstance(b, Block)

    # Test that this import is not leaking from the testing env (such as from tox)

# Generated at 2022-06-21 00:34:13.633952
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:34:24.305068
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    data = '''
tasks:
- debug: msg="test1"
- debug: msg="test2"
- include: foo.yml
- include_role: name=test
  tasks:
    - debug: msg="test3"
'''

# Generated at 2022-06-21 00:34:35.298860
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    _tasks = [
        {'include': 'mytasks'},
        {'include': 'mytasks'},
        {'name': 'my task'},
        {'name': 'my task'},
        {'name': 'my task'},
        {'block': [
            {'name': 'my block task 1'},
            {'name': 'my block task 2'},
        ]}
    ]

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    class DummyRole(object):
        def __init__(self, name):
            self.name = name
            self.tasks = []

        def get_task(self, play, ds):
            return Task.load(ds, play=play)


# Generated at 2022-06-21 00:35:01.012034
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    ds = [
        {"name":"mars"},
        {"name":"venus"},
    ]

    roles = load_list_of_roles(ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)

    assert len(roles) == 2
    assert isinstance(roles[0], RoleInclude)
    assert isinstance(roles[1], RoleInclude)
    assert roles[0]._role_name == "mars"
    assert roles[1]._role_name == "venus"



# Generated at 2022-06-21 00:35:12.867376
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import sys
    import tempfile
    import shutil
    from ansible.playbook.play import Play
    sys.path.append(".")
    sys.path.append("lib")
    from ansible.variable_manager import VariableManager
    from ansible.inventory import Inventory
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.utils.template as template
    current_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(current_dir, "test_data/load_list_of_tasks.yml")

# Generated at 2022-06-21 00:35:25.131587
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Tests if the function  load_list_of_roles is working properly.

    This is a very basic test for a function that is nothing but a wrapper.
    """
    list_of_roles = [
        {
            "role": "filebeat"
        }, {
            "role": "logstash"
        }
    ]
    play = type('MockPlay', (), {})
    current_role_path = None
    variable_manager = type('MockVariableManager', (), {})
    loader = type('MockLoader', (), {})
    collection_search_list = None

    load_list_of_roles(list_of_roles, play, current_role_path, variable_manager, loader, collection_search_list)

# Generated at 2022-06-21 00:35:34.437562
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager,  sources='')


# Generated at 2022-06-21 00:35:44.524417
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager._extra_vars = {'foo': 'bar'}
    play = dict(
        name='Mixed Role/Include tests',
        hosts='localhost',
        gather_facts='no',
        roles=['test_role_2'],
        vars=[
            dict(
                role_var='a')
        ]
    )
    basedir = 'test_roles'

# Generated at 2022-06-21 00:35:45.376542
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:35:55.589222
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def assert_raises(obj, exception):
        if hasattr(obj, 'assertRaises'):
            return obj.assertRaises(exception)
        return obj(exception)
    assert_raises(lambda: load_list_of_tasks('abc'), AnsibleAssertionError)
    assert_raises(lambda: load_list_of_tasks({'abc': 123}), AnsibleAssertionError)
    assert_raises(lambda: load_list_of_tasks({'block': 'abc'}), AnsibleAssertionError)
    assert_raises(lambda: load_list_of_tasks({'action': 'abc'}), AnsibleAssertionError)

# Generated at 2022-06-21 00:36:02.128221
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {
            'block': [
                {'action': {'module': 'setup'}},
                {'action': {'module': 'debug', 'msg': b'Hello world'}},
            ],
            'any_errors_fatal': True,
            'name': 'Some task'
        },
        {'action': {'module': 'command', 'args': b'echo "Hello world"'}},
        {'action': {'module': 'debug', 'msg': b'Goodbye world'}}
    ]
    # We need to initialize the data structure
    play = Play()
    block = Block()
    role = Role()
    task_include = TaskInclude()
    use_handlers = False
    variable_manager = dict()
    loader = dict()
    tasks = load_list_of

# Generated at 2022-06-21 00:36:04.438851
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# vim:set noet sts=4 sw=4 ts=4:

# Generated at 2022-06-21 00:36:15.056057
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.config.manager import ConfigManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.collection import CollectionLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

    config_manager = ConfigManager()
    config_manager.load()

    loader = DataLoader()

    play_context = PlayContext()
    variable_manager = VariableManager()


# Generated at 2022-06-21 00:36:45.399492
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # load_list_of_roles(ds, play, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None):
    pass

# Test using the module directly
if __name__ == '__main__':
    import sys
    import yaml
    from ansible.parsing.dataloader import DataLoader

    # Create the loader object
    loader = DataLoader()
    args = dict(
        action=dict(required=True),
        _raw_params=dict(required=True, type='str'),
        _uses_shell=dict(required=False, type='bool'),
        _raw_filename=dict(required=False, type='str'),
        _attributes=dict(required=False, type='dict'),
    )

    p = ModuleArgsParser(args)

# Generated at 2022-06-21 00:36:55.585678
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    if not isinstance(ds, list):
        raise AnsibleAssertionError('The ds (%s) should be a list but was a %s' % (ds, type(ds)))

    task_list = []

# Generated at 2022-06-21 00:37:05.923571
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import IncludeRole

    from ansible.plugins.loader import action_loader, module_loader


# Generated at 2022-06-21 00:37:14.010933
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # Load test cases
    output = []
    with open("./test/unit/utils/test_load_list_of_roles.out") as fd:
        for line in fd:
            output.append(line.replace('\n', ''))

    # Generate actual output
    # Get Ansible Base Directory
    module_loader = ModuleLoader()
    collections_paths = module_loader.get_collections_paths()
    ansible_base_path = os.path.join(collections_paths[0], "ansible_collections", "ansible")

    # Create loader object
    loader = Dataloader()
    loader.set_basedir(ansible_base_path)

    # Create variable manager
    variable_manager = VariableManager()
    # Parse play file to get data structure
   

# Generated at 2022-06-21 00:37:25.191235
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.parsing.dataloader
    import ansible.vars.manager

    parent_block_data = [
        {'block': [{"hosts": "localhost", "tasks": [{"debug": {"msg": "ok"}}]}]},
        {'block': [{"hosts": "localhost", "tasks": [{"debug": {"msg": "ok"}}]}]},
        {'block': [{"hosts": "localhost", "tasks": [{"debug": {"msg": "ok"}}]}]},
    ]
    ds = [{"hosts": "localhost", "tasks": [{"debug": {"msg": "ok"}}]}]
    ds.extend(parent_block_data)
    parent_

# Generated at 2022-06-21 00:37:34.198671
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.block import Block

    assert isinstance(load_list_of_blocks(ds=None,
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None), list)

    # Test that implicit blocks are converted to a single list
    load_list_of_blocks(ds=[{'name': 'first'}, {'name': 'second'}],
        play=None,
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None)

    # Test that implicit blocks are converted to Block Objects

# Generated at 2022-06-21 00:37:43.718507
# Unit test for function load_list_of_roles

# Generated at 2022-06-21 00:37:53.549759
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    import ansible.constants as C
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()

    loader, inventory, variable_manager = C.get_loader(), InventoryManager(loader=loader), VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play_context.inventory = inventory

# Generated at 2022-06-21 00:37:54.406049
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:37:55.455679
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-21 00:38:22.216609
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:38:32.988694
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DictDataLoader({
        "roles1/meta/main.yml": "{}",
        "roles2/meta/main.yml": "{}",
        "roles3/meta/main.yml": "{}",
    })
    play = Play().load({}, loader=loader, variable_manager=variable_manager)
    roles = load_list_of_roles([{'role': 'roles1'}, {'role': 'roles2'}, {'role': 'roles3'}], play=play, current_role_path=None, variable_manager=variable_manager, loader=loader, collection_search_list=None)
    assert roles[0].has_parent() is False
    assert roles[1].has_parent() is False
    assert roles[2].has_parent() is False


# Generated at 2022-06-21 00:38:40.443612
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
        'test1',
        'test2',
        {
            'block': 'test3',
            'block1': 'test4'
        },
        'test5',
        'test6',
    ]
    print('ds:', ds)
    # print('load_list_of_blocks:', load_list_of_blocks(ds))
    assert load_list_of_blocks(ds)



# Generated at 2022-06-21 00:38:47.500841
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = [{"action": {"__ansible_module__": "x", "a": 1, "b": "c"}, "register": "a"}, {"action": {"__ansible_module__": "x", "a": 3, "b": "d"}, "register": "b"}]
    assert load_list_of_tasks(task_list) == task_list

# Generated at 2022-06-21 00:38:54.743995
# Unit test for function load_list_of_blocks

# Generated at 2022-06-21 00:39:03.771384
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    context = PlayContext()
    context._variables = VariableManager()
    all_vars = context.get_vars()
    templar = Templar(loader=loader, variables=all_vars)

    TEST_DATA = """
    - name: Test List of tasks
      include_role:
        name: include_role
        static: True
        tasks_from: something_that_doesnt_exist.yml
    """

    display.verbosity = 3
    ds = yaml.safe_load(TEST_DATA)

# Generated at 2022-06-21 00:39:14.203786
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.role.definition
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.playbook.task_include import TaskInclude

    options = [("connection", "smart"), ("forks", "5"), ("become", "true"), ("become_method", "sudo"), ("become_user", "root"), ("check", "false"), ("diff", "false")]
    loader = DataLoader()


# Generated at 2022-06-21 00:39:18.009402
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    # TODO
    pass



# Generated at 2022-06-21 00:39:25.425106
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop


# Generated at 2022-06-21 00:39:27.235307
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
# /Unit test for function load_list_of_tasks


# Generated at 2022-06-21 00:40:32.259959
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Tests the load_list_of_roles
    """
    role_def_succeed = [
        {'name': "SomeRole", 'some_variable': 'some_value'},
        {'name': "SomeOtherRole", 'some_variable': 'some_value'},
    ]
    role_def_fail = [
        {'name': "SomeRole", 'noverride': "some_value"},
        {'name': "SomeRole", 'noverride': "some_value"},
    ]
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=[]))
    loader = DataLoader()

# Generated at 2022-06-21 00:40:40.872812
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test function without required args
    try:
        load_list_of_tasks()
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test function without all required args
    try:
        load_list_of_tasks(ds=[{'roles': [], 'action': 'include_role'}])
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test function with TypeError
    try:
        load_list_of_tasks(ds=dict(), play=dict(), block=dict(), role=dict(), task_include=dict(), use_handlers=dict(), variable_manager=dict(), loader=dict())
    except Exception as e:
        assert isinstance(e, TypeError)

    # Test function with ValueError (not instance of string, integer or list)

# Generated at 2022-06-21 00:40:43.133887
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # for later use - see comment about using setattr for testing inside a function
    pass



# Generated at 2022-06-21 00:40:50.918926
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # format_validate_fail
    assert_raises(AnsibleAssertionError, load_list_of_roles, 2, None)
    assert_raises(AnsibleAssertionError, load_list_of_roles, 2, None, None, None, None)
    assert_raises(AnsibleAssertionError, load_list_of_roles, 2, None, None, None, None, None)

    # Load_list_of_roles_no_current_role_path_pass
    assert load_list_of_roles([], None) == []
    assert load_list_of_roles([], None) == []
    assert load_list_of_roles([], None, None) == []
    assert load_list_of_roles([], None, None) == []

# Generated at 2022-06-21 00:40:59.498384
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test simple host
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = PlayContext()
    play_context._connection = connection_loader.get('paramiko', None, PLAYBOOK_NAME)

    variable_manager = VariableManager()

    # Load the list of tasks
    ds = dict(action='shell', args='echo hello world')
    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=Options())

# Generated at 2022-06-21 00:41:08.922854
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.module_utils.facts.system.distribution import DistributionFactModule
    from ansible.module_utils.facts.system.pkg_mgr import PkgMgrFactModule
    from ansible.module_utils.facts.system.platform import PlatformFactModule
    from ansible.module_utils.facts.system.selinux import SELinuxFactModule
    from ansible.module_utils.facts.system.user import UserFactModule

    # Platform
    def generate_platform_facts_tests():
        # platform_facts_test_module.run_module(tmpdir, system_facts, ansible_facts)
        platform_test_module = {}

# Generated at 2022-06-21 00:41:18.363323
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import yaml
    yml_string = '''
        - name: test task 1
          action: module name
        - include_tasks: test.yml
        - import_tasks: test2.yml
        - include_role: testrole
        - import_role: testrole
        - block:
            - name: test task 2
              action: module name
        - block:
            - name: test task 3
              action: module name
            tasks:
              - name: test task 4
                action: module name

        - block:
            - name: test task 6
              action: module name
            rescue:
              - name: test task 7
                action: module name
            always:
              - name: test task 8
                action: module name
    '''

# Generated at 2022-06-21 00:41:29.313386
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Testing function load_list_of_tasks")

    block = {
        'hosts': 'localhost',
        'tasks': [
            {
                'block': {
                    'block': ['blocked'],
                },
            },
            ['implicit'],
            {
                'block': {
                    'block': {
                        'name': 'name',
                        'block': ['more'],
                    },
                },
            },
        ],
    }

    task_list = load_list_of_tasks(
        block['tasks'],
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )


# Generated at 2022-06-21 00:41:38.118980
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  # Mock data 
  task_ds = [
    {
      "block":{
        "block": {
          "name": "Hosts in group localhost",
          "hosts": "127.0.0.1",
          "tasks": [
            {
              "name": "NoOp"
            }
          ]
        }
      }
    },
    {
      "block":{
        "block":{
          "name": "Hosts in group localhost",
          "hosts": "127.0.0.1",
          "tasks": [
            {
              "name": "NoOp"
            }
          ]
        }
      }
    }
  ]
  play = {
    "name": "NoOp"
  }

# Generated at 2022-06-21 00:41:46.736489
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.play
    import ansible.playbook.role.include
    test_play = ansible.playbook.play.Play()
    test_role_def = [{'name': 'foo', 'foo': 1}, {'name': 'bar', 'bar': 2}]
    test_vars = {}
    test_loader = 'ansible.parsing.dataloader.DataLoader'
    test_roles = load_list_of_roles(test_role_def, test_play, variable_manager = test_vars, loader = test_loader)
    assert isinstance(test_roles, list)
    assert isinstance(test_roles[0], ansible.playbook.role.include.RoleInclude)