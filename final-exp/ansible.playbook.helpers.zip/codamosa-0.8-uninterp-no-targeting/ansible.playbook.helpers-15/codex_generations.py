

# Generated at 2022-06-21 00:32:39.577086
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # FIXME: remove this import once the loader/config refactor is complete
    from ansible.parsing.dataloader import DataLoader

    # FIXME: remove this import once the loader/config refactor is complete
    from ansible.vars.manager import VariableManager
    from ansible.config.manager import ConfigManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    config_manager = ConfigManager()
    host_a = Host('a')
    host_b = Host('b')
    host_c = Host('c')
    host_d = Host('d')

    inventory = InventoryManager(loader=loader, sources=[])
    inventory.add_host(host_a)
    inventory.add_host(host_b)
    inventory.add

# Generated at 2022-06-21 00:32:41.683394
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, 'This test needs to be written'


# Generated at 2022-06-21 00:32:54.042480
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    def _get_templar():
        mock_loader = mock.Mock()
        mock_loader._basedir = "./test_playbooks/"
        templar = Templar(loader=mock_loader, variables={})
        return templar

    task_list = load_list_of_tasks([{'include_tasks': "./include.yml"}, {"include_tasks": "./sub_include.yml"}], None, None, None, False, None, _get_templar())
    assert len(task_list) == 2, "Expected two tasks to be loaded"
    for task in task_list:
        assert task.action in ["include_tasks", "include_role"], "Expected action to be include_tasks or include_role"

# Generated at 2022-06-21 00:33:01.780143
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [1,2,3,4]
    #print(load_list_of_blocks(ds))
    assert load_list_of_blocks(ds)==[1,2,3,4]
    #ds = "str"
    #print(load_list_of_blocks(ds))
    #assert load_list_of_blocks(ds)=='str'
    #ds = True
    #print(load_list_of_blocks(ds))
    #assert load_list_of_blocks(ds)==True
    #ds = 1
    #print(load_list_of_blocks(ds))
    #assert load_list_of_blocks(ds)==1
    #ds = None
    #print(load_list_of_blocks(ds))
    #assert load_list_of_blocks(

# Generated at 2022-06-21 00:33:02.191016
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:33:13.126422
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    _ansible_test_custom_roles = [
        {"name": "test-role-1","collection": "ansible_test_col"},
        {"name": "test-role-2","collection": "ansible_test_col"}
    ]

    _ansible_test_custom_env = dict(os.environ)
    _ansible_test_custom_env["ANSIBLE_COLLECTIONS_PATHS"] = os.path.join(os.path.dirname(__file__), "data/collections")
    _ansible_test_custom_env["ANSIBLE_ROLES_PATH"] = os.path.join(os.path.dirname(__file__), "data/roles")

    _ansible_test_custom_loader = DataLoader()
    _ansible_test_custom_loader.set

# Generated at 2022-06-21 00:33:14.275210
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display = Display()
    display.display("foo")


# Generated at 2022-06-21 00:33:14.780274
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:33:28.514606
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-21 00:33:33.474330
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(
        ds=[
            {'action': 'shell', 'args': 'echo hello'},
            {'action': 'shell', 'args': 'echo world'}
        ],
        play=None,
        block=None,
        use_handlers=True,
        loader=None,
        variable_manager=None,
    )

# Generated at 2022-06-21 00:33:54.351521
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {'block': 'block1', 'name': 'test'}
    display = None
    loader = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = True
    variable_manager = None
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(task_list[0], Handler)

# Generated at 2022-06-21 00:34:01.473422
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}


# Generated at 2022-06-21 00:34:02.460336
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

# Generated at 2022-06-21 00:34:10.025007
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.include
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_roles('47', None, None, None, None)
    assert "ds (47) should be a list but was a <class 'str'>" in str(excinfo.value)
    assert 'ds (47) should be a list but was a str' in str(excinfo.value)



# Generated at 2022-06-21 00:34:22.695215
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import unittest

    def setup_loader_modules():
        mock_loader1 = MagicMock()
        mock_loader1.path_exists.return_value = True
        mock_loader2 = MagicMock()
        mock_loader2.path_exists.return_value = True
        mock_loader3 = MagicMock()
        mock_loader3.path_exists.return_value = True
        mock_loader4 = MagicMock()
        mock_loader4.path_exists.return_value = True
        mock_loader5 = MagicMock()
        mock_loader5.path_exists.return_value = True


# Generated at 2022-06-21 00:34:31.111189
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    class Play():
        _roles = {}

    play = Play()
    ds = [
        {
            'name': 'b'
        },
        {
            'name': 'a',
            'collections': ['collection']
        }
    ]

    roles = load_list_of_roles(ds, play)

    assert roles[0]._role_name == 'a'
    assert roles[1]._role_name == 'b'
    # Unit test for function load_list_of_blocks

# Generated at 2022-06-21 00:34:34.635906
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    sys.modules['ansible'] = Mock()
    import ansible.playbook.play
    role_ds = [{"name": "foo"}]
    role = load_list_of_roles(role_ds, ansible.playbook.play.Play())
    assert role[0]._role_name == 'foo'


# Generated at 2022-06-21 00:34:41.548730
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test function load_list_of_roles
    """
    # pylint: disable=import-error
    from ansible.plugins.loader import action_loader
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.parsing.dataloader import DataLoader

    action_loader.add_directory(get_test_data_path() + '/test_action_plugins')
    collection_loader = AnsibleCollectionLoader()
    collection_loader.set_collection_paths([get_test_data_path() + '/collection_data'])
    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test_host': '127.0.0.1'}
    variable_manager.set_collection_loader(collection_loader)

# Generated at 2022-06-21 00:34:54.539833
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def get_loader(basedir=None):
        return DataLoader()

    def get_inventory(loader, variables):
        return InventoryManager(loader=loader, sources=["localhost"])

    def get_variable_manager(loader, inventory):
        return VariableManager(loader=loader, inventory=inventory)

    def get_play_ds(loader, variable_manager, name="test"):
        play_ds = dict(
            name=name,
            hosts='localhost',
            gather_facts='no',
            roles=[],
        )

        variable_manager.set_nonpersistent_facts(play_ds)

# Generated at 2022-06-21 00:35:06.171056
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.filevars import FileVars
    from ansible.vars.groupvars import GroupVars
    from ansible.vars.dictionary import Dictionary
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-21 00:35:42.953777
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude

    # 1. Normal operation

# Generated at 2022-06-21 00:35:54.907044
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    # Given a list of task datastructures (parsed from YAML),
    # return a list of Task() or TaskInclude() objects.

# Generated at 2022-06-21 00:36:01.712207
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    class FakePlay:
        def __init__(self):
            self.handlers = []
        def get_vars(self):
            return dict()
        def get_variable_manager(self):
            return None
    class FakeBlock:
        def __init__(self):
            self.block = []
            self.handlers = []
        def get_vars(self):
            return dict()
        def get_variable_manager(self):
            return None

# Generated at 2022-06-21 00:36:02.996854
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, 'No tests defined'



# Generated at 2022-06-21 00:36:14.473000
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.basic import AnsibleModule
    from ansible.template import Templar

    class MockModule(object):
        def __init__(self, name):
            self.name = name

# Generated at 2022-06-21 00:36:22.306575
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    def _my_load(file_name):
        my_file = file_name
        if file_name.endswith(".yaml"):
            my_file = file_name[:-5]
        return my_file


# Generated at 2022-06-21 00:36:34.111890
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    #from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.ini import InventoryParser
    from ansible.module_utils._text import to_bytes
    from ansible.vars.clean import module_response_deepcopy
   

# Generated at 2022-06-21 00:36:43.760985
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 99

    m = InventoryManager(loader=DataLoader(), sources='tests/integration/inventory_multi')
    ds = [{"role": "common"},
          {"role": "nginx"},
          {"role": "non_existing", "foo": "bar"}]

    v = VariableManager()
    v.extra_vars = {'hosts': 'webservers'}
    p

# Generated at 2022-06-21 00:36:47.701233
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, loader=None):
    pass



# Generated at 2022-06-21 00:36:54.283352
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    
    # Test valid inputs
    assert load_list_of_tasks(ds=None, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None) == []
    
    # Test invalid inputs
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks(ds=0, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert "should be a list but was a" in excinfo.exconly()
    

# Generated at 2022-06-21 00:37:51.060319
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    t1 = {'block': 'some_block', 'action': 'some_action'}
    t2 = {'action': 'some_action2'}
    t3 = {'task': 'some_task'}
    ts = [t1, t2, t3]
    loader=DataLoader()
    variable_manager=VariableManager()
    inventory=InventoryManager(loader=loader, variable_manager=variable_manager)

# Generated at 2022-06-21 00:38:00.931421
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.host import Host, Inventory
    from ansible.parsing.mod_args import ModuleArgsParser, ModuleArgsSpec
    import pprint
    mytask_args = {
        'action': 'ec2_group create',
        'name': 'test'
    }
    play_context = PlayContext()
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None
    play_context.remote_addr = None
    play_context.remote_user = 'ansible'
    play_context.password = None
   

# Generated at 2022-06-21 00:38:11.572294
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    dataloader = DataLoader()
    inventory_manager = InventoryManager(loader=dataloader)
    variable_manager = VariableManager(loader=dataloader, inventory=inventory_manager)
    play1 = Play().load(dict(name="test play", hosts=["all"]), variable_manager=variable_manager, loader=dataloader)
    task1 = Task.load(dict(action=dict(name="fail", args=dict(msg="error message"))))
    task2 = Task.load

# Generated at 2022-06-21 00:38:22.209834
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude

    ds_list = [
        {'name': 'foo', 'foo': 'bar'},
        {'name': 'baz', 'baz': 'qux'},
    ]

    ctx = PlayContext()
    ctx.verify_hosts = False
    ctx.remote_addr = "127.0.0.1"
    ctx.network_os = "default_os"

    loader, inventory, variable_manager = CLI.setup_loader()
    inventory.load_hosts()


# Generated at 2022-06-21 00:38:32.673660
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager.set_inventory(inventory_manager)

# Generated at 2022-06-21 00:38:33.795932
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:38:34.741844
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:38:44.724994
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    import os
    import pytest
    # import ansible.constants as C
    # C.DEFAULT_ROLES_PATH = os.path.join(os.path.dirname(__file__), 'utils/roles')
    # C.DEFAULT_ROLES_PATH = None
    # C.DEFAULT_ROLES_PATH = os.path.join(os.path.dirname(__file__), '../../roles')
    # C.DEFAULT_ROLES_PATH = os.path.join(os.

# Generated at 2022-06-21 00:38:57.314597
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    module_name = 'ping'
    is_new_style = False
    play = Play()
    block = Block()
    role = Role()
    task_include = TaskInclude()
    use_handlers = False
    variable_manager = VariableManager() # is this legit?
    loader = DataLoader()
    ds = []
    # case 1
    task_ds = dict()
    task_ds['action'] = dict(module=module_name)
    task_ds['block'] = dict()
    ds.append(task_ds)
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    # test if the message is correct

# Generated at 2022-06-21 00:38:58.655239
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    raise AnsibleParserError()

# Generated at 2022-06-21 00:41:44.310949
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Given a list of mixed task/block data (parsed from YAML),
    return a list of Block() objects, where implicit blocks
    are created for each bare Task.
    '''


# Generated at 2022-06-21 00:41:54.959014
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task_include import IncludeTask
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()


# Generated at 2022-06-21 00:42:05.308860
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role_include import IncludeRole
    ansible_vars = dict(a=1, b=2, c=3)
    variable_manager = VariableManager(loader=DictDataLoader({}), inventory=Inventory(host_list=[], groups=[]))
    variable_manager.set_inventory(Inventory(host_list=[], groups=[]))
    variable_manager.extra_vars = ansible_vars
    play = Play().load({'hosts': 'localhost', 'gather_facts': 'no',
                        'tasks': [
                            {'include': 'role1.yml', 'name': 'role test'}
                        ]
                        },
                       variable_manager=variable_manager, loader=DataLoader())


# Generated at 2022-06-21 00:42:15.450557
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.display import Display
    from ansible.module_utils.six import string_types

    loader  = DataLoader()
    play_context = PlayContext()