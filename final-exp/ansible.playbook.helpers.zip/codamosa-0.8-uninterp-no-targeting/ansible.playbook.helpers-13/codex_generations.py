

# Generated at 2022-06-21 00:32:38.392094
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
  # This is needed for the import of the function
  return


# Generated at 2022-06-21 00:32:45.235916
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    collection_list = ['/path/to/collection1', '/path/to/collection2']
    return load_list_of_roles(ds, play, current_role_path=current_role_path, variable_manager=variable_manager,
                             loader=loader, collection_search_list=collection_list)

# Generated at 2022-06-21 00:32:49.407965
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles([{'role': 'test'}], None)
    assert load_list_of_roles([{'name': 'test'}], None)


# Generated at 2022-06-21 00:33:00.131585
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook
    playbook_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "..", "examples", "test_static_include.yml")
    pb = ansible.playbook.Playbook.load(playbook_path, loader=ansible.parsing.dataloader.DataLoader())
    play = pb.get_plays_by_name("main")[0]

    # Test load_list_of_tasks()
    block = play.compile()
    tasks = [task for task in block.block if isinstance(task, ansible.playbook.block.Block)]
    assert len(tasks) == 3

# Generated at 2022-06-21 00:33:11.749488
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This is a unit test for load_list_of_tasks
    # It will run in the same directory as the playbook,
    # so we need to move to the root for the import
    orig_cwd = os.getcwd()
    os.chdir(os.path.dirname(__file__) + "/../")
    sys.path.append("lib")


# Generated at 2022-06-21 00:33:24.561049
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # inventory for testing
    inventory = InventoryManager(loader=DataLoader(), sources='''
        127.0.0.1 ansible_connection=local
        localhost ansible_connection=local
    ''')
    # group all
    group_all = Group('all')
    inventory.add_group(group_all)
    # group test
    group_test = Group('test')
    group_test.vars = {'test_group_var': 'test group var'}
    inventory.add_group(group_test)
    # hosts
    host

# Generated at 2022-06-21 00:33:35.792925
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    os.environ['PATH'] = '/bin:/usr/bin'

# Generated at 2022-06-21 00:33:44.266362
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import module_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible import context
    import copy
    import os

    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 00:33:53.412836
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    play = Play()
    play_ds = dict(
        name="test_load_list_of_blocks",
        hosts="test_hosts",
        gather_facts="no",
        tasks=[
            dict(
                name="foo",
                action=dict(module="shell", args="bar")
            )
        ],
    )
    play.load(play_ds, variable_manager=None, loader=None)

    block_ds = load_list_of_blocks(play._task_blocks, play, variable_manager=None, loader=None)

    assert len(block_ds) == 1, "Only one block should have been found"

# Generated at 2022-06-21 00:33:53.896588
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:34:14.384383
# Unit test for function load_list_of_blocks

# Generated at 2022-06-21 00:34:17.277335
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks() == "This function is used in the Ansible codebase and cannot be unit tested"

# Generated at 2022-06-21 00:34:22.567625
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.reserved import Reserved
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser
    import ansible.constants as C
    import ansible.module_utils.urls as urls
    import json

    # Setup

    # Test load_list_of_blocks with blocks with single tasks
    # Test load_list_

# Generated at 2022-06-21 00:34:25.197111
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks == load_list_of_tasks


# Generated at 2022-06-21 00:34:35.063183
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.utils import context_objects as co

    collection_search_list = ["col1"]
    variable_manager = co.VariableManager()

    ds = [
        {'role': 'example1'},
        {'role': 'example2'}
    ]

    loader = DictDataLoader(dict(col1=dict(roles=dict(example1=dict(tasks=dict())))))

    def mock_load(role_definition, play, current_role_path, variable_manager=None, loader=None, collection_list=None):
        role_definition["collection"] = "col1"
        role_definition["root"] = "example1"

# Generated at 2022-06-21 00:34:41.891092
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    # given there is a list of task datastructures (parsed from YAML)
    # return a list of Task() or TaskInclude() objects.
    task_ds = [{'block': {'block': {'block': {'block': 'unblock'}}, 'otherblock': 'unblock'}}, {'include_tasks': {'a': 'b'}},
               {'import_tasks': {'a': 'b'}}, {'include': {'a': 'b'}}, {'handler': 'unblock'}]

    # when calling load_list_of_tasks
    # then task_list should contain a list of Task() or

# Generated at 2022-06-21 00:34:54.779562
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    ds = [{u'include': u'roles/some_role/tasks/main.yml'}]
    assert load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)[0].__class__ == IncludeRole

# Generated at 2022-06-21 00:35:06.388441
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    role_def = dict(
        name='somedir.somerole',
        tasks_from='somedir.somerole.tasks',
        handlers_from='somedir.somerole.handlers',
        vars_from='somedir.somerole.vars',
        defaults_from='somedir.somerole.defaults',
        meta_from='somedir.somerole.meta'
    )
    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 00:35:14.810502
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play.load(dict(
        name="Test Play",
        hosts=['localhost'],
        roles=[
            dict(name='role1', tasks=[dict(action=dict(module='fail', args=dict(msg="This should not be executed")))]),
            dict(name='role2', tasks=[dict(action=dict(module='ping', args=dict()))]),
        ],
    ),
    variable_manager=variable_manager, loader=loader)
    assert isinstance(play.get_roles()[0], RoleInclude)
    assert play.get_roles()[0].name == 'role1'

# Generated at 2022-06-21 00:35:25.880897
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = FakeDataLoader()
    play = Playbook.load(dict(), loader=loader, variable_manager=variable_manager)
    loader.set_basedir("/tmp")
    ds = [{"role": "foobar"}, {"role": "baz"}, {"name": "include foobar", "role": "baz"}]
    roles = load_list_of_roles(ds, play, loader=loader)
    assert len(roles) == 3
    assert roles[0]._role_name == 'foobar'
    assert roles[1]._role_name == 'baz'
    assert roles[2].role._role_name == 'baz'
    assert roles[2]._role_name == "foobar"
    assert roles[2].name == "include foobar"

# Generated at 2022-06-21 00:36:02.701496
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import Include
    from ansible.playbook.role.task_include import TaskInclude
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsiblePathMeta
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleParserError

    # load_list_of_blocks: error cases
    with pytest.raises(AnsibleParserError):
        load_list_of_blocks(42)
    with pytest.raises(AnsibleParserError):
        load_list_

# Generated at 2022-06-21 00:36:14.360741
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.constants import DEFAULT_VAULT_SECRET_FILE

    class SingletonLoader():
        class Loader():
            path_basedir = None
            data = None
            def __init__(self, data, path_base=None):
                self.path_basedir = path_base
                self.data = data
            def path_dwim(self, path):
                return self.data[path]
            def get_contained_elements(self, path):
                return self.data
        class FileVaultSecret():
            vault = None
            path = None

# Generated at 2022-06-21 00:36:24.785887
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.utils.path import unfrackpath

    def _create_play(ds):
        play = Play().load(ds, variable_manager=variable_manager, loader=loader)
        return play

    variable_manager = VariableManager()
    loader = DataLoader()
    roles_path = unfrackpath('../../lib/ansible/plugins/inventory/dir')

    yaml_data1 = """
    ---
    - hosts: localhost
      roles:
      - simple_role_1
      - simple_role_2
      - simple_role_3
    """


# Generated at 2022-06-21 00:36:35.419346
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("test start")
    # Test case: All tasks
    task_list = []
    ds = [
        {"block": [{"block": [{"block": [{"name": "test_task"}]}]}]},
        {"debug": {"msg": "test_task2"}},
        {"block": [{"block": [{"block": [{"block": [{"name": "test_task3"}]}]}]}]}
    ]
    play = {}
    block = {}
    role = {}
    task_include = {}
    use_handlers = False
    variable_manager = {}
    loader = {}
    task_list = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-21 00:36:47.993514
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition

    role_def = [{'role': 'role_name'}]


# Generated at 2022-06-21 00:36:50.104206
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
    # ds_list = []
    # play = {}
    # load_list_of_tasks(ds_list,play)



# Generated at 2022-06-21 00:37:03.543314
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  from ansible.constants import DEFAULT_VAULT_ID_MATCH
  DataLoader = namedtuple('DataLoader', ('data_parser', '_basedir'))
  loader = DataLoader(data_parser=False, _basedir='/home/ansible/ansible-devel/test/test_loader/test_vars/')

  play = namedtuple('play', ['vars'])
  play.vars = {'name': 'test_play'}
  play.vars['ansible_vault_password_file'] = '/home/ansible/ansible-devel/test/test_loader/test_vars/ansible_vault_password_file'

  block = namedtuple('block', ['vars'])
  block.vars = {'name': 'test_block'}

 

# Generated at 2022-06-21 00:37:10.152510
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    config_data = {}
    config_data['DEFAULT_ROLES_PATH'] = "../roles/test"
    config_data['ANSIBLE_LIBRARY'] = "../library"
    config_data['ANSIBLE_MODULE_UTILS'] = "../module_utils"
    config_data['ANSIBLE_FILTER_PLUGINS'] = "../filter_plugins"
    config_data['ANSIBLE_LOOKUP_PLUGINS'] = "../lookup_plugins"
    config_data['ANSIBLE_TEST_DATA'] = "../test/data"
    config_data['ANSIBLE_CONFIG'] = "../ansible.cfg"
    config_data['ANSIBLE_ANSIBLE_TREE_LIBRARY']= "../library"
    config_data['ANSIBLE_OUTPUT_CALLBACK']

# Generated at 2022-06-21 00:37:23.514836
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.playbook_include import PlaybookInclude
    task_list = [
        dict(action='name=a'),
        dict(action='include_role', name='a'),
        dict(action='import_role', name='a'),
        dict(block=None),
        dict(include='b'),
        dict(import_playbook='b'),
        dict(hosts='a'),
    ]
    task_list2 = load_list_of_tasks(task_list, None)
    assert isinstance(task_list2[0], Task)

# Generated at 2022-06-21 00:37:33.344739
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    task_c = dict(name='c', action='ping')
    task_d = dict(name='d', action='ping')
    task_e = dict(name='e', action='ping')
    role_a = dict(name='role_a', tasks=[task_c, task_d])
    role_b = dict(name='role_b', tasks=[task_e])
    play = dict(tasks=[task_a, task_b], roles=[role_a, role_b])
    play_ds = Play().load(play, variable_manager=variable_manager, loader=loader)
    print(play_ds.roles[0].get_block_list(loader=loader, variable_manager=variable_manager))

# Generated at 2022-06-21 00:38:03.159912
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:38:05.847804
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block_list = load_list_of_tasks({'action': 'shell'}, None, None, None)

# Generated at 2022-06-21 00:38:13.623998
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:38:23.435678
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
  from ansible.playbook.block import Block, Task
  from ansible.parsing.yaml import objects
  ds = [ 'task1', 'task2',
          objects.Task(action="debug", args=dict(msg="debug task"), tags=['debug'], tags_add=['debug_add']),
          [ 'task3',
            objects.Task(action="debug", args=dict(msg="debug task 2"), tags=['debug2'], tags_add=['debug2_add']),
            'task4',
            'task5',
          ],
          'task6'
        ]

  blocks = load_list_of_blocks(ds)
  assert len(blocks) == 4
  assert isinstance(blocks[0], Block)
  assert isinstance(blocks[1], Block)

# Generated at 2022-06-21 00:38:33.612682
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:38:44.218744
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    var_manager = DummyVarsModule()
    play = Play.load({}, loader=DummyLoader(), variable_manager=var_manager)

    task_1 = Task.load({
        'action': {
            'module': 'test1'
        }
    }, play=play, variable_manager=var_manager)

    task_2 = Task.load({
        'action': {
            'module': 'test2'
        }
    }, play=play, variable_manager=var_manager)

    task_3 = Task.load({
        'action': {
            'module': 'test3'
        }
    }, play=play, variable_manager=var_manager)

# Generated at 2022-06-21 00:38:53.136247
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from unittest import TestCase
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    class MockVariableManager:
        def get_vars(self, loader, play=None, host=None, task=None):
            return {}

    class MockLoader:
        def get_basedir(self, play=None):
            pass

    class TestLoadListOfBlocks(TestCase):
        def test_load_list_of_blocks(self):
            b = Block()
            b.block  = [{'block': 'tasks', 'tasks': [{'yum': 'name=vim state=latest'}]}]


# Generated at 2022-06-21 00:38:55.152756
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    raise NotImplementedError


# Generated at 2022-06-21 00:39:00.882241
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role_include import RoleInclude
    # Base case test
    assert isinstance(load_list_of_roles(ds=[], play='', current_role_path='', variable_manager='', loader='', collection_search_list='')[0], RoleInclude)

    # Test the case where obj is not of type RoleInclude
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(ds='', play='', current_role_path='', variable_manager='', loader='', collection_search_list='')

    # Test __repr__() and __str__() for objects of type RoleInclude
    obj = RoleInclude([], '', '', '', '', '')

# Generated at 2022-06-21 00:39:02.063554
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-21 00:39:49.491974
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert(load_list_of_roles(ds=None,play=None,current_role_path=None,variable_manager=None,loader=None,collection_search_list=None) == None)
    assert(load_list_of_roles(ds=['a','b','c'],play=None,current_role_path=None,variable_manager=None,loader=None,collection_search_list=None) == None)
    assert(load_list_of_roles(ds=[{},{},{}],play=None,current_role_path=None,variable_manager=None,loader=None,collection_search_list=None) == None)

# Generated at 2022-06-21 00:39:50.913519
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: implement_me
    pass


# Generated at 2022-06-21 00:40:00.346645
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import ansible.constants as C
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.template import Templar
    from ansible.inventory.host import Host

    loader = DataLoader()
    hosts = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=hosts)

    # load the default variable manager
    variable_manager.extra_vars = load_extra_vars(loader=loader, options=None)

# Generated at 2022-06-21 00:40:01.267267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:40:02.134833
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:40:03.295177
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-21 00:40:11.157941
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    import ansible.module_utils.common.collections
    ansible.module_utils.common.collections.exact_lookup_error = True
    import ansible.module_utils.common.validation
    ansible.module_utils.common.validation.REQUIRED_IF_DEFINED_KWARGS = tuple(['undefined_kwarg'])
    import ansible.module_utils.common.warnings
    ansible.module_utils.common.warnings.deprecate.warning

# Generated at 2022-06-21 00:40:20.931016
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import yaml
    data = """
    - name: task 1
      debug:
        msg: task 1

    - include_tasks: tasks_file.yml
      static: yes

    - include_role:
        role: role1
        tasks_from: main
    """

    data = yaml.safe_load(data)

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    #print(data)
    inventory = InventoryManager(loader=DataLoader(), sources='/home/liucong/liucong/workspace/ansible-playbook/hosts')

# Generated at 2022-06-21 00:40:29.340342
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    class MockTask():
        pass
    mock_task = MockTask()

    ds = [mock_task]

    play = Play()
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    display.verbosity = 3

    # Test function with no args
    b = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, display)
    assert(len(b) == 1)


# Generated at 2022-06-21 00:40:39.685521
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import sys
    import os
    import json

    sys.path.append(os.getcwd())

    from test.unit.loader.test_data import TestData
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # test that parsing of explicit blocks works

# Generated at 2022-06-21 00:42:13.877424
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # Test for missing parameters
    try:
        load_list_of_blocks()
        raise AssertionError('Should have failed due to missing arguments')
    except TypeError:
        pass

    # Test for non list or None ds
    try:
        load_list_of_blocks(ds = {})
        raise AssertionError('Should have failed due to non list or None input')
    except AnsibleAssertionError:
        pass

    # Test if the implicit task count is correct in the outputs