

# Generated at 2022-06-21 00:32:44.874967
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar


# Generated at 2022-06-21 00:32:55.756191
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play

    from ansible.playbook.play_context import PlayContext

    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.inventory.manager import InventoryManager

    loader, inventory, variable_manager = (
        Mock(), Mock(), Mock(spec=VariableManager)
    )
    play_context = PlayContext()
    play_context._become = None
    play_context._become_method = None
    play_context._become_user = None
    play_context._remote_user = None

# Generated at 2022-06-21 00:33:09.430344
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.playbook.task import Task
    import mock

    opts = mock.MagicMock(spec=C.configuration.Config)
    opts.no_log = None
    opts.parser = None

    ds = AnsibleSequence()
    ds.append(__tmp_ds_task())
    ds.append(__tmp_ds_block())
    ds.append(__tmp_ds_task())
    ds.append(__tmp_ds_task())

    ret = load_list_of_blocks(ds, opts)
    assert isinstance(ret[0], Block)

# Generated at 2022-06-21 00:33:19.385460
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.parsing.dataloader
    import ansible.vars.manager
    import ansible.inventory.manager

    loader = ansible.parsing.dataloader.DataLoader()

    # simple test to create a PlaybookExecutor object and make sure that doesn't fail
   

# Generated at 2022-06-21 00:33:31.517970
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    ds = [
        {'block': 'test', 'rescue': 'rescue'},
        {'block': 'test2', 'rescue': 'rescue2'},
        {'meta': 'test3'}
    ]
    play = {'name': 'test'}
    parent_block = "test"
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    result = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)

    assert len(ds) == len(result)
    for item in result:
        assert isinstance(item, Block)

# Generated at 2022-06-21 00:33:41.759020
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # FIXME: Move this to a test case
    # tests for variadic task/blocks
    from ansible.playbook.task import Task
    ds = [{'include': {'name': 'foo'}}, {'block': [{'task': 'bar'}, {'task': 'baz'}]}]
    task_list = load_list_of_tasks(ds, [])
    assert len(task_list) == 3
    assert isinstance(task_list[0], Task)
    assert isinstance(task_list[1], Task)
    assert isinstance(task_list[2], Task)
    #assert task_list[0].action == 'include'
    #assert task_list[1].action == 'block'
    #assert task_list[2].action == 'block'

# Generated at 2022-06-21 00:33:42.659883
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    raise NotImplementedError()


# Generated at 2022-06-21 00:33:52.824542
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    yaml_data = [
        {'debug': {'msg': 'test1', 'test': 1}},
        {'debug': {'msg': 'test2',}},
        {'debug': {'msg': 'test3'}},
    ]

    pc = PlayContext()
    p = Play().load({}, variable_manager=None, loader=None)
    result = load_list_of_blocks(yaml_data, p)
    assert len(result) == 3
    assert result[0].block.resolve_valid_when(pc).was_skipped == False
    assert result[1].block.resolve_valid_when(pc).was_skipped == False
    assert result[2].block

# Generated at 2022-06-21 00:33:53.774123
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:34:01.188563
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude

    ds = [
        {'name': 'myrole'},
        {'name': 'mycollection.myrole'},
    ]
    assert isinstance(load_list_of_roles(ds, None), list)
    assert len(load_list_of_roles(ds, None)) == 2
    for i in load_list_of_roles(ds, None):
        assert isinstance(i, RoleInclude)
        assert i.name == i.role_name == i.role._role_name
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(1, None)

    # test the role path

# Generated at 2022-06-21 00:34:26.520320
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Ensure load_list_of_tasks() returns the correct types
    '''

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler

    class MockPlay(object):
        pass

    class MockParentBlock(Block):
        pass

    class MockRole(object):
        pass

    class MockTaskInclude(Task):
        name = 'mock_task_include'

    class MockVariableManager(object):
        def __init__(self, vars_dict=None, extra_vars_dict=None):
            if vars_dict is None:
                vars_dict = {}
            if extra_vars_dict is None:
                extra_vars_

# Generated at 2022-06-21 00:34:35.700937
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = dict(
        name='Ansible Play',
        hosts='all',
        gather_facts=False,
        become=False,
        become_method='sudo',
        become_user='root',
        connection='paramikos',
    )

    block = dict(
        name='Test block',
        hosts='all',
        gather_facts=False,
        become=False,
        become_method='sudo',
        become_user='root',
        connection='local',
        tasks=[dict(action=dict(module='ping', args=''))]
    )

    # Test when task is a valid task structure
    # (success)
    task_list = load_list_of_tasks(block['tasks'], play)
    assert len(task_list) == 1

# Generated at 2022-06-21 00:34:42.380227
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''Test load_list_of_tasks'''
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    # 1. task list
    ds = [dict(action=dict(module='test'))]
    task_list = load_list_of_tasks(ds, play=None, role=None, task_include=None, loader=None, variable_manager=None)
    assert isinstance(task_list[0], Task)

    # 2. task list with include
    ds = [dict(action=dict(module='test')), dict(include='test')]

# Generated at 2022-06-21 00:34:54.896760
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'action': 'shell', 'args': {'_raw_params': 'pwd'}, 'delegate_to': '', 'register': ''},
        {'block': [ {'action': 'shell', 'args': {'_raw_params': 'pwd'}, 'delegate_to': '', 'register': ''} ]},
        {'action': 'include_tasks', 'args': {'_raw_params': 'include/test.yml'}, 'delegate_to': '', 'register': ''},
        {'include_role': {'name': 'test'}, 'vars': {'a': '1'}},
        {'include': 'include/test.yml'},
    ]
    play = Play()

# Generated at 2022-06-21 00:34:58.311723
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:35:08.977822
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    my_variable_manager = VariableManager()
    my_loader = None
    my_play = Play().load({'name': 'test play'}, variable_manager=my_variable_manager, loader=my_loader)
    my_role = Role().load({'name': 'test role'}, variable_manager=my_variable_manager, loader=my_loader)
    # Load an array of tasks into a list of Blocks
    list_of_tasks = [{'action': 'stat', 'name': '/root'}, {'action': 'stat', 'name': '/root/nope'}]
    list_of_blocks = load_

# Generated at 2022-06-21 00:35:17.779021
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test when current_role_path is None
    play = Mock()
    play.ROLE_PATH = None
    assert load_list_of_roles(['role1', 'role2', 'role3'], play) == [
        RoleInclude(play, role_name='role1'),
        RoleInclude(play, role_name='role2'),
        RoleInclude(play, role_name='role3')
    ]

    # Test when current_role_path is not None
    play.ROLE_PATH = '/path/to/role/'

# Generated at 2022-06-21 00:35:30.008114
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    This function checks that load_list_of_blocks correctly handles a sequence of blocks and
    tasks with and without implicit blocks.
    '''
    # We do not import ansible.playbook.play.Play here because of circular dependencies.
    # We just create an instance of the class directly instead.
    play = Play()
    # We do not import ansible.playbook.block.Block here because of circular dependencies.
    # We just create an instance of the class directly instead.
    block = Block()
    # We do not import ansible.playbook.task.Task here because of circular dependencies.
    # We just create an instance of the class directly instead.
    task = Task()

    # We now create a list of data structures with and without implicit blocks, simulating
    # what we might find in a playbook.

# Generated at 2022-06-21 00:35:42.731802
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory import Inventory
    from pprint import pprint

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    #inventory = InventoryManager(loader=loader, sources=b'/Users/rkumar6/Documents/github/ansible/test/inventory.ini')

# Generated at 2022-06-21 00:35:54.229939
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import module_loader
    from ansible.plugins.task import TaskBase
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    m = module_loader._find_plugin("ping")
    t = TaskBase(ModuleArgsParser("ping", "", "", "", "", "", "", "", "", m), None)

    v = VariableManager()
    i = InventoryManager(v, {})
    p = Play("test play", v, i, "/path")
    role = Role("test role", "/path", v, i)

# Generated at 2022-06-21 00:36:24.261422
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.plugins.loader import action_loader
    from ansible import context
    from ansible.utils.display import Display
    from ansible.errors import AnsibleParserError
    from ansible.template import Templar
    from ansible.parsing.mod_args import ModuleArgsParser

    display = Display()
    display.verbosity = 4

# Generated at 2022-06-21 00:36:35.168905
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 4

    assert load_list_of_roles(None, None, None, None, None) == []

    loader, inventory, variable_manager = (
        AnsibleLoader(None, None),
        HostInventory(loader=None, vault_password=None),
        VariableManager(loader=None, inventory=None),
    )

    add_all_plugin_dirs()


# Generated at 2022-06-21 00:36:47.484683
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    ds is None
    ds is not list
    ds is a list and each element is not dict
    '''
    mock_ds = None
    res = load_list_of_tasks(ds=mock_ds,play='test_play',block='test_block',role='test_role',task_include='test_task_include',use_handlers=False,variable_manager='variable_manager',loader='loader')
    assert res == []
    mock_ds = 'mock_ds'

# Generated at 2022-06-21 00:36:56.354792
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_extra_vars(dict(foo='bar'))
    variable_manager.set_extra_vars(dict(spam='eggs'))
    variable_manager.set_extra_vars(dict(baz='zee'))

    templar = Templar(loader=None, variables=variable_manager)
    templar.set_available_variables(variable_manager.get_vars(loader=None, play=None, include_hostvars=True))

    loader = DataLoader()
    pb = AnsibleParser(loader=loader)

# Generated at 2022-06-21 00:37:06.266590
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager._extra_vars = {
        'item': "{{ lookup('file', '/tmp/file') }}"
    }
    play_context = PlayContext(play=Play().load({}), variable_manager=variable_manager)

# Generated at 2022-06-21 00:37:10.551235
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'role': 'name1'}, {'role': 'name2'}]
    roles = load_list_of_roles(ds, None)
    assert(len(roles) == 2)


#
# DEPRECATED: use load_list_of_roles instead

# Generated at 2022-06-21 00:37:23.295730
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:37:25.100006
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:37:28.846560
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
        {
            'block': 'test1'
        },
        {
            'block': 'test2'
        }
    ]
    return load_list_of_blocks(ds)

# Generated at 2022-06-21 00:37:41.388671
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    data = [
        {
            "block": [
                "task1",
                "task2"
            ]
        },
        {
            "include": "include1"
        },
        "task3"
    ]

    play = {}
    role = {}
    task_include = {}
    use_handlers = False
    variable_manager = {}
    loader = {}

    ret = load_list_of_tasks(data, play, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=variable_manager, loader=loader)
    assert len(ret) == 3
    assert ret[0].__class__.__name__ == 'Block'
    assert ret[1].__class__.__name__ == 'TaskInclude'
    assert ret[2].__class

# Generated at 2022-06-21 00:38:12.271428
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # Arrange
    ds = [
        {
            "block": [
                {
                    "name": "test block1",
                    "block": [
                        {"name": "test block2", "block": [{"name": "test block3"}]}
                    ],
                }
            ]
        },
        {
            "block": [
                {
                    "name": "test block4",
                    "block": [
                        {"name": "test block5", "block": [{"name": "test block6"}]}
                    ],
                }
            ]
        },
    ]

    # Act
    block_list = load_list_of_blocks(ds)

    # Assert
    assert len(block_list) == 2
    assert len(block_list[0].block) == 1

# Generated at 2022-06-21 00:38:22.455159
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role import include
    import ansible.playbook.role.include
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    class FakeRolePath(object):
        def __init__(self, path):
            self._role_path = os.path.realpath(path)

    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-21 00:38:33.088886
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task

    yaml_data = """
    - name: all
      hosts: localhost
      connection: local
      gather_facts: yes
      tasks:
      - name: hello
        command: echo hello
        register: hello_out
      - name: goodbye
        command: echo goodbye
        register: goodbye_out
      - name: check
        command: echo check
        register: check_out
      - name: whoa
        command: echo whoa
    """
    fake_loader = DictDataLoader({})
    fake_loader.set_basedir(os.getcwd())
    p = Play.load(yaml_data, variable_manager=None, loader=fake_loader)

# Generated at 2022-06-21 00:38:34.160479
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-21 00:38:44.507516
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    module_utils_path = os.path.join(os.getcwd(), 'lib', 'ansible', 'module_utils')
    module_utils_paths = [module_utils_path]
    module_utils_paths.extend(C.DEFAULT_MODULE_UTILS_PATHS)
    module_utils_paths.append(os.getcwd())

    loader = DataLoader()

    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:38:56.578406
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    from ansible.playbook.play import Play

    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    from ansible.playbook.role.definition import RoleDefinition

    #
    #
    #

    loader = DictDataLoader({
        "foo.yml": "",
        "role1/meta/main.yml": "name: role1",
        "role2/meta/main.yml": "name: role2",
    })

    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        "system_role_paths": []
    }

    loader.set_basedir('/some/path')

    #
    # Test 1: Error when not a list
    #


# Generated at 2022-06-21 00:39:04.289879
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def test_simple():
        ds = [
            {"debug": "hello world"},
            {"debug": "foo"},
        ]
        blocks = load_list_of_blocks(ds)
        assert len(blocks) == 2

    def test_implicit_blocks():
        ds = [
            {"debug": "hello world"},
            {"debug": "foo"},
            {"debug": "bar"},
            {"block": "first"},
            {"block": "second"},
        ]
        blocks = load_list_of_blocks(ds)
        assert len(blocks) == 4
        assert len(blocks[0].block) == 2
        assert len(blocks[1].block) == 1
        assert len(blocks[2].block) == 1
        assert len(blocks[3].block) == 1

# Generated at 2022-06-21 00:39:08.227157
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    play = Play.load(dict(
        hosts='all',
        pre_tasks=[
            dict(action=dict(module='shell', args='echo hello')),
            dict(action=dict(module='shell', args='echo world')),
        ],
        tasks=[
            dict(action=dict(module='shell', args='echo hello')),
            dict(action=dict(module='shell', args='echo world')),
            dict(block=dict(
                tasks=[
                    dict(action=dict(module='shell', args='echo hello')),
                    dict(action=dict(module='shell', args='echo world')),
                ],
            )),
        ]
    ))


# Generated at 2022-06-21 00:39:10.466110
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{'action': 'test', 'args': 'test args'}], play=None) != []


# Generated at 2022-06-21 00:39:14.475811
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{"include": "test.yml", "vars": {"x": "y"}}]
    assert isinstance(load_list_of_blocks(ds)[0], Block)



# Generated at 2022-06-21 00:40:08.554575
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import sys

    test_tools_dir = os.path.dirname(os.path.abspath(__file__)) + "/test_tools"
    test_ansible_module_path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

    test_playbook_file = os.path.join(test_tools_dir, "playbooks", "test_playbook.yml")
    test_vars = {"var1": "val1"}

    sys.path.insert(0, test_ansible_module_path)
    from ansible.module_utils.common._collections_compat import Mapping, Sequence


# Generated at 2022-06-21 00:40:20.100163
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
#Example code to test function load_list_of_roles
    class AnsibleModule:
        def __init__(self, args):
            self.args = args
    class ModuleArgsParser:
        def parse(self, args, **kwargs):
            return AnsibleModule(args)
        def __init__(self, args):
            self.args = args
    class AnsibleVariableManager:
        def __init__(self):
            self.vars = {}
        def get_vars(self, play=None, task=None):
            return self.vars
#Example code for function test_load_list_of_roles

# Generated at 2022-06-21 00:40:21.006825
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:40:24.561174
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: implement this
    test_data = []
    assert load_list_of_blocks(test_data)


# Generated at 2022-06-21 00:40:32.561820
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play()
    role_ds = [
        {'role': 'foo'},
        {'role': 'bar'},
        {'role': 'baz'}
    ]

    assert load_list_of_roles(role_ds, play, variable_manager=variable_manager, loader=loader) == [
        RoleInclude('foo', play=Play(), parent_role_path='', variable_manager=variable_manager, loader=loader),
        RoleInclude('bar', play=Play(), parent_role_path='', variable_manager=variable_manager, loader=loader),
        RoleInclude('baz', play=Play(), parent_role_path='', variable_manager=variable_manager, loader=loader),
    ]


# Generated at 2022-06-21 00:40:40.970956
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    block_list = load_list_of_blocks(None, None, )
    assert(block_list == [])
    block_list = load_list_of_blocks([], None, )
    assert(block_list == [])
    ds = [{"hosts": "localhost", "tasks": [{"action": {"module": "command", "args": "ls"}}]}]
    block_list = load_list_of_blocks(ds, Play().load(ds, variable_manager=VariableManager(), loader=None), )
    for block in block_list:
        assert(isinstance(block, Block))


# Generated at 2022-06-21 00:40:43.436401
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles('test','test','test','test','test')==None

# Generated at 2022-06-21 00:40:44.116080
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

# Generated at 2022-06-21 00:40:44.826953
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:40:45.546054
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:42:14.036803
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Unit test for function load_list_of_blocks
    '''
    from ansible.module_utils.six import string_types
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.role import Role

# Generated at 2022-06-21 00:42:25.748464
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_result import TaskResult
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    play_context._ansible_no_log = True
    play_context._ansible_keep_remote_files = False
    play_context._ansible_verbosity = 5
    play_context._ansible_diff = False
    play_context._ansible_show_custom_stats = True
    play_context._ansible_show_file_deprecation_warnings = True
    play_context._ans