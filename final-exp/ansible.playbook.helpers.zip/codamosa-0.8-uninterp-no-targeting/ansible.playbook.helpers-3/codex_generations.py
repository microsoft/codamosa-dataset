

# Generated at 2022-06-21 00:32:53.204378
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import unittest
    loader = 'setup'
    ds = ['setup']
    play ='df'
    role = 'role'
    task_include = 'task_include'
    use_handlers = False
    variable_manager = 'variable_manager'
    from ansible.playbook.block import Block
    assert (Block.load(
                    ds[0],
                    play=play,
                    role=role,
                    task_include=task_include,
                    use_handlers=use_handlers,
                    variable_manager=variable_manager,
                    loader=loader,
                    ))

    #display.debug("implicit_blocks is not None")
    #return implicit_blocks



# Generated at 2022-06-21 00:33:00.587822
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    try:
        import io
        import yaml
    except ImportError:
        # We can't test without yaml or io
        return

    test_input = {'name': 'test'}
    test_ds = yaml.safe_dump(test_input)
    test_ds_io = io.StringIO(test_ds)
    assert load_list_of_roles(yaml.safe_load(test_ds_io), None, None) == [RoleInclude(name='test')]



# Generated at 2022-06-21 00:33:11.057539
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    ds = [
        {
            'hosts': 'webservers',
            'tasks': [
                {'debug': 'msg=foo'},
                {'debug': 'msg=bar'},
                {
                    'block': [
                        {'debug': 'msg=baz'},
                        {'debug': 'msg=bat'},
                    ],
                },
                {'debug': 'msg=qux'},
            ],
        },
    ]



    # test load_list_of_blocks
    # except ImportError:
    #    raise SkipTest("Cannot import ansible.playbook.block")
    # TODO: skip test because of missing ansible.playbook.block



# Generated at 2022-06-21 00:33:24.048723
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Play


# Generated at 2022-06-21 00:33:34.304086
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:33:40.480172
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    ds = [{'name': 'role-name', 'tasks': 'a', 'vars': 'a'}]
    play = Play()
    roles = load_list_of_roles(ds, play)
    assert len(roles) == 1
    assert roles[0].name == 'role-name'
    assert isinstance(roles[0], RoleInclude)



# Generated at 2022-06-21 00:33:52.205507
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:34:02.895592
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    If not isinstance(ds, (list, type(None))):
        raise AnsibleAssertionError('%s should be a list or None but is %s' % (ds, type(ds)))
    '''
    from ansible.playbook.block import Block

    ds = dict()
    try:
        load_list_of_blocks(ds)
        assert False, 'Should be not reach here'
    except AnsibleAssertionError:
        pass

    ds = dict()
    try:
        load_list_of_blocks(ds)
        assert False, 'Should be not reach here'
    except AnsibleAssertionError:
        pass

    ds = dict()

# Generated at 2022-06-21 00:34:13.012284
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    ds = [{'test': 'var'}]
    assert Block.is_block(ds[0]) is True
    display.verbosity = 4
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager())
    play = Play.load({}, loader=loader, variable_manager=variable_manager, use_handlers=True)

# Generated at 2022-06-21 00:34:23.190066
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    print("Test for function load_list_of_tasks") 
    
    
    
    
    
    
    
    
    
    
    
    
    
    pass

# Generated at 2022-06-21 00:34:41.722362
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    play_ds = dict(
        name="Ansible Play",
        hosts="all",
        gather_facts="no",
    )


# Generated at 2022-06-21 00:34:54.659694
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        import ansible.playbook.block
        import ansible.playbook.task
    except ImportError:
        print("SKIP: related to missing imports")
        raise

    ds = [{"name": "foo"}, {"name": "bar"}]
    assert load_list_of_blocks(ds)
    assert len(load_list_of_blocks(ds)) == 2
    assert isinstance(load_list_of_blocks(ds)[0], ansible.playbook.block.Block)
    assert isinstance(load_list_of_blocks(ds)[1], ansible.playbook.block.Block)
    assert load_list_of_blocks(ds)[0].block is None
    assert load_list_of_blocks(ds)[1].block is None

# Generated at 2022-06-21 00:34:58.351367
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # I can't see a way to test this from within the normal ansible test setup so I've added this unit test.  TODO: work
    # out how to test this as part of the normal ansible test suite
    assert True



# Generated at 2022-06-21 00:35:05.814606
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' test load_list_of_roles function '''

    yaml_str = '''
    - name: postgresql
      become: true
    - role: webserver
      become: false
    '''
    data = yaml.safe_load(yaml_str)
    print(data)
    assert isinstance(data, list)
    print(load_list_of_roles(data, None, None, None, None, None))



# Generated at 2022-06-21 00:35:14.385295
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    ctx = PlayContext()
    ctx._init_globals()
    play = Play.load({
        'name': 'test',
        'connection': 'local',
        'hosts': ['localhost'],
    }, variable_manager=VariableManager(), loader=None)

    ds = [{'debug': 'msg="this is a task"'}, {'debug': 'msg="this is a task"'}]

# Generated at 2022-06-21 00:35:26.109335
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import module_utils_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    loader = DataLoader()

    play_context = PlayContext()
    templar = Templar(loader=loader)

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'test': 'from_extra_vars'}

# Generated at 2022-06-21 00:35:32.504276
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # The following test is added to ensure that a whole load_list_of_blocks is called
    # If a bare task is loaded, then load_list_of_blocks returns a list of one block.
    # I am not sure if this test is valid as we don't have a bare task but it at least calls the function
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.include import Include
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role.include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-21 00:35:33.716395
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    return True


# Generated at 2022-06-21 00:35:41.308576
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'action': 'foo'}, {'action': 'bar'}]
    task_list = load_list_of_tasks(ds, {}, block=None, role=None, task_include='', use_handlers=False, variable_manager='', loader='')
    assert len(task_list) == 2

if __name__ == "__main__":
    test_load_list_of_tasks()

# Generated at 2022-06-21 00:35:42.590974
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:36:03.245267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    variable_manager.set_inventory(inventory)
    variable_manager._extra_vars = {'test_var': 'value_for_test_var'}


# Generated at 2022-06-21 00:36:14.544599
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block


# Generated at 2022-06-21 00:36:18.369359
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Getting a list of tasks and checking the role of the first task
    ds = [{'block': [{'block': [{'block': 'task test 1\n'}], 'block': 'task test 2\n'}, {'block': 'task test 3\n'}]}]
    task_list = load_list_of_tasks(ds)
    assert role.value == 'task test 1'

# Generated at 2022-06-21 00:36:25.306158
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, module_loader
    from ansible.plugins.strategy import StrategyBase
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    display = Display()

    def get_plugins(cls):
        return cls.get_plugins()

    def load_plugins(cls):
        return cls.load_plugins()

    # Required for get_plugins to work
    Display.verbosity = 4
    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../action_plugins'))

# Generated at 2022-06-21 00:36:34.137221
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ''' Run unit test for function load_list_of_blocks '''

    # pylint: disable=redefined-outer-name
    import pytest
    from ansible.inventory import Inventory

    def get_all_blocks(ds, play, parent_block=None, role=None, task_include=None,
                       use_handlers=False, variable_manager=None, loader=None):
        '''
        Returns a list of all Blocks in a given list
        '''

# Generated at 2022-06-21 00:36:45.434607
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader, callback_loader

    playbooks = ["test_load_list_of_roles.yml"]
    loader = DataLoader()

    # create inventory
    host = Host(name="localhost")
    group = Group(name="local")
    group.add_host(host)
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    inventory.add_group(group)
    inventory.add_host(host)



# Generated at 2022-06-21 00:36:55.618104
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = [
        {'debug': {'var': 'var1'}},
        {'debug': {'var': 'var2'}},
        {'include': {'tasks': 'task1.yml'}},
        {'include': {'tasks': 'task2.yml'}},
        {'block': [
            {'debug': {'var': 'var3'}},
            {'debug': {'var': 'var4'}}
        ]},
        {'debug': {'var': 'var5'}},
        {'debug': {'var': 'var6'}}
    ]
    # fake play and variable_manager
    play = [{'hosts': 'all'}]
    variable_manager = [{'name': '', 'vars': ''}]


# Generated at 2022-06-21 00:37:05.954019
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.playbook.play
    import ansible.playbook.role

    class MockVariableManager():
        def get_vars(self, task, loader, play=None, host=None):
            return {}

    m = MockVariableManager()

    # test None block
    load_list_of_blocks(None, task_include=None, variable_manager=m)

    # test single Block()
    dlist = ansible.playbook.task.Task.load({'name': 'taskname', 'action': 'testaction'})
    block = ansible.playbook.block.Block.load(dlist)

# Generated at 2022-06-21 00:37:07.919076
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test case for load_list_of_roles
    '''

    pass

# Generated at 2022-06-21 00:37:11.187714
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest

    # TODO: Add checks for play, role, task_include, use_handlers, variable_manager and loader
    with pytest.raises(AnsibleAssertionError):
        load_list_of_blocks(1, parent_block=None)



# Generated at 2022-06-21 00:37:50.589652
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # get a unittest.TestCase class in function
    TestCase = type('TestCase', (unittest.TestCase,), {'assertRaisesRegex': unittest.TestCase.assertRaisesRegex})

    # Prepare test variables
    ds = [ "LoginDemo.SimpleLogin", ]
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None

    # Test the function
    try:
        roles = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
        assert isinstance(roles, list)
    except Exception as e:
        print(e)


# Generated at 2022-06-21 00:37:52.417323
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False # TODO: Implement test

# Generated at 2022-06-21 00:38:01.466896
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    # None value returns empty list
    assert load_list_of_blocks(ds=None, play=None) == []

    # List of bare tasks becomes list of single-task blocks
    ds = [{'name': 'task1'}, {'name': 'task2'}]
    ds_truncated = [{'name': 'task1'}, [{'name': 'task2'}]]
    assert load_list_of_blocks(ds=ds, play=None) == [Block.load(ds[0]), Block.load(ds[1])]
    assert load_list_of_blocks(ds=ds_truncated, play=None) == [Block.load(ds[0]), Block.load(ds[1])]

    # List of bare tasks followed by a

# Generated at 2022-06-21 00:38:02.384012
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-21 00:38:12.133195
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[dict(action=dict(module='setup', args=''))]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:38:18.381361
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: fix this test
    # We need to find a way to mock all the objects that we pass to
    # load_list_of_tasks
    pass
    # from ansible.playbook.play import Play
    # from ansible.playbook.play_context import PlayContext
    # from ansible.playbook.task import Task
    # from ansible.inventory.group import Group
    # from ansible.inventory.host import Host
    # from ansible.vars.manager import VariableManager
    # from ansible.parsing.dataloader import DataLoader
    #
    # host = Host(name='myhost')
    # group = Group(name='mygroup')
    # group.add_host(host)
    #
    # loader = DataLoader()
    # variable_manager = VariableManager()
   

# Generated at 2022-06-21 00:38:20.026397
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert 1 == 0

# Generated at 2022-06-21 00:38:31.775162
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class MyTask(object):
        def __init__(self, ds):
            self._ds = ds
            self.action = 'ping'
        def __setattr__(self, attr, val):
            if attr in self.__dict__:
                self.__dict__[attr] = val
            else:
                self._ds[attr] = val
        def __getattr__(self, attr):
            return self._ds.get(attr)

    def my_load(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        return MyTask(ds)

    class MyBlock(object):
        def __init__(self, ds, *args):
            self.block = ds

# Generated at 2022-06-21 00:38:32.443758
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:38:43.528858
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:40:01.379394
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    loader = DataLoader()
    options = None
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 00:40:10.560323
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.executor.task_queue_manager import TaskQueueManager

    # Temporary task_queue_manager to capture the result
    class TaskQueueManagerTmp(TaskQueueManager):
        def load_list_of_roles(self, ds, play, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None):
            return load_list_of_roles(
                ds, play, current_role_path=current_role_path, variable_manager=variable_manager,
                loader=loader, collection_search_list=collection_search_list
            )

    # We can't use the existing playbook.py because it assumes a role is already created
    # and fails with a traceback

# Generated at 2022-06-21 00:40:20.732461
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    # Create a single play
    p = Play().load({'name': 'test_play', 'hosts': 'all', 'local_action': {'module': 'local_action', 'args': ""}, }, variable_manager=None, loader=None)
    # Create a single block
    b = Block().load({'name': 'test_block', }, use_handlers=True, variable_manager=None, loader=None)

    # ****************************
    # Create a single normal task
    # ****************************

# Generated at 2022-06-21 00:40:30.676439
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Simulates the load of a list of roles
    """

    def load_list_of_blocks(ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        """
        Return a list of Block() objects
        """
        pass

    loader = DictDataLoader({})

    # Case 1: load_list_of_roles returns a list of RoleInclude objects

# Generated at 2022-06-21 00:40:40.244482
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import unittest
    import json

    class load_list_of_blocksTester(unittest.TestCase):
        def setUp(self):
            self.test_dir = os.path.dirname(os.path.realpath(__file__))
            self.test_data = open(self.test_dir + "/unit/parsing/parser/parser_fixture1.json", "r").read()
            self.test_data = json.loads(self.test_data)
            self.maxDiff = None

        def test_load_list_of_blocks(self):
            from ansible.playbook.play import Play
            from ansible.playbook.block import Block
            from ansible.parsing.yaml.objects import AnsibleUnicode
            from ansible.vars.manager import VariableManager

# Generated at 2022-06-21 00:40:49.722164
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.requirement import RoleRequirement
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars import VariableManager

    def test_result(result, expected):
        print(result)
        if isinstance(expected, string_types):
            assert isinstance(result, string_types)
            assert result == expected
        else:
            assert isinstance(result, type(expected))


# Generated at 2022-06-21 00:40:58.338932
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    ds = [
        {
            u"block": 1,
            u"always": [
                {
                    u"block": 1,
                    u"always": [
                        {
                            u"debug": {
                                u"var1": u"value1"
                            }
                        }
                    ],
                    u"rescue": [],
                    u"block": 1
                }
            ],
            u"rescue": [],
            u"changed_when": False
        }
    ]
    assert len(load_list_of_blocks(ds, ansible.playbook.play.Play()))==1


# Generated at 2022-06-21 00:41:08.446767
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    with pytest.raises(AnsibleAssertionError):
        ds = 10
        load_list_of_roles(ds)
    ds = []
    roles = load_list_of_roles(ds)
    assert isinstance(roles, list) and not roles
    ds = ["httpd"]
    roles = load_list_of_roles(ds)
    assert len(roles) == 1
    assert isinstance(roles[0], RoleInclude)
    assert roles[0].name == "httpd"
    ds = [{"role": "httpd"}]
    roles = load_list_of_roles(ds)
    assert len(roles) == 1

# Generated at 2022-06-21 00:41:18.142956
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.clean import module_response_deepcopy
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 00:41:19.339578
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: This test needs to be implemented
    pass
