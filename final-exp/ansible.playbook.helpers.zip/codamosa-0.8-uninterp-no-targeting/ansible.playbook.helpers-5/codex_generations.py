

# Generated at 2022-06-21 00:32:39.108334
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test that load_list_of_roles can accept all the various forms of roles syntax
    :return:
    '''
    from ansible.playbook.role.definition import RoleDefinition
    roledef_ds = dict(name='foo',
                      foo=dict(bar=dict(key='value')))
    r = RoleDefinition.load(roledef_ds)
    assert r == RoleDefinition(name='foo', foo=dict(bar=dict(key='value')))

    # Role include syntax dict
    ri = dict(role='foo', foo=dict(bar=dict(key='value')))
    assert RoleInclude.load(ri) == RoleInclude(role='foo', foo=dict(bar=dict(key='value')))

    # Role include syntax list

# Generated at 2022-06-21 00:32:53.478010
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.template import Templar

    fake_loader = DataLoader()
    fake_variable_manager = dict()
    fake_loader.set_basedir('/some_dir')

    implicit_blocks = [
        {'hosts': 'first_host','vars':{'some_var': 'some_val'}},
        {'hosts': 'second_host', 'vars':{'some_var': 'some_other_val'}}
    ]


# Generated at 2022-06-21 00:32:54.347319
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert(False), "TODO"


# Generated at 2022-06-21 00:32:54.926694
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-21 00:32:55.516188
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-21 00:33:09.532707
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    import os
    import tempfile
    current_dir = os.path.dirname(os.path.realpath(__file__))

    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.collections import is_sequence

    from ansible.module_utils.parsing.convert_bool import boolean

    from ansible import context
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    from ansible.vars.manager import VariableManager

    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars

    from ansible.utils.vars import combine_vars



# Generated at 2022-06-21 00:33:13.703971
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import context
    from ansible.cli import CLI
    from ansible.utils.display import Display

    context._init_global_context(CLI.base_parser(None, usage="%prog ...", runas_opts=True, meta_opts=True))
    display = Display()
    display.verbosity = 3
    context.CLIARGS._parse_cli_opts()

    loader = DataLoader()

    role_list = load_list_of_roles(ds=["myrole"], play=None, current_role_path=None, variable_manager=None, loader=loader)


# Generated at 2022-06-21 00:33:27.369607
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
        Test load_list_of_roles
    '''
    from ansible.plugins.loader import collection_loader
    from ansible.plugins import module_loader
    from ansible.module_utils.common._collections_compat import MutableMapping
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.inventory.manager import InventoryManager
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from io import StringIO


# Generated at 2022-06-21 00:33:36.900795
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.unsafe_proxy import wrap_var

    current_role_path = os.path.join(os.path.dirname(__file__),"../support/test_role")
    loader = DataLoader()
    vars_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources="localhost,")
    vars_manager.set_inventory(inventory)
    vars_manager._vars['role_path'] = os.path.join(os.path.dirname(__file__),"../support/test_role")

# Generated at 2022-06-21 00:33:45.228330
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play import Play

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    ds = [
            dict(action="pause", args=dict(minutes=10)),
            dict(action="include", args=dict(tasks="include_task_file.yml"))
          ]

    loader = DataLoader()

# Generated at 2022-06-21 00:33:55.770034
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:34:04.749665
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task

    # NOTE: load_list_of_blocks assumes the input is already validated
    #       by the playbook YAML loading
    yml_playbook = """
    - hosts: localhost
      tasks:
        - action: debug msg="Hello"
        - name: test task 2
          action: debug msg="world"
    """
    loader, inventory, variable_manager = TestingTaskExecutor.setup_loader()
    play = Play().load(yml_playbook, variable_manager=variable_manager, loader=loader)
    result = load_list_of_blocks(play.get_blocks(), play=play, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:34:13.358441
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    # setup
    ds = [
        {'role': 'some_role'},
        {'role': 'some_other_role'},
    ]
    inventory = InventoryManager(loader=DataLoader(), sources='localhost')
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    play_context = PlayContext()
    play_source = dict(name="Ansible Play", hosts=['localhost'], gather_facts='no',
                       tasks=[dict(action=dict(module='shell', args='ls'))])


# Generated at 2022-06-21 00:34:24.213265
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  # Expected values
  action = 'first_task'
  args = {'name': 'first_task', 'static': True}
  delegate_to = 'localhost'
  task_list = [{'first_task': {'name': 'first_task', 'static': True}}]

  # Mock - Play
  m_play = mock.MagicMock()
  m_block = None

  # Call the tested function
  task_list_returned = load_list_of_tasks(task_list, m_play, m_block)

  # Check the test result
  assert len(task_list_returned) == 1
  assert task_list_returned[0].action == action
  assert task_list_returned[0].args == args

# Generated at 2022-06-21 00:34:34.599890
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test opts
    test_opts = {'ANSIBLE_CONFIG': './ansible.cfg'}
    # test args
    test_vars = {'var1': 'value1'}
    test_args = {'verbosity': 0, 'ask_sudo_pass': False, 'ask_pass': False, 'module_path': None, 'forks': 10, 'become': False, 'become_method': 'sudo', 'become_user': None, 'check': False, 'listhosts': None, 'listtasks': None, 'listtags': None, 'syntax': None, 'connection': 'smart', 'module_path': None}
    test_options = Options(test_args)
    test_options._load_vars_from_file(options.VARS_FILES)
    test_options

# Generated at 2022-06-21 00:34:41.488347
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    ds = list()
    ds.append({'name': 'test_task', 'action': {'module': 'test_module'}})
    ds.append({'name': 'test_block', 'block': [{'name': 'test_task2', 'action': {'module': 'test_module2'}}]})

    play = None
    role = None
    task_include = None

    # Should have 2 blocks, one with one task and one with one task
    block_list = load_list_of_blocks(ds, play, role=role, task_include=task_include)
    print(block_list)
    print(block_list[0])
    print(block_list[1])
    print

# Generated at 2022-06-21 00:34:54.797159
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.block import Block
    import ansible.constants as C
    from ansible.vars.unsafe_proxy import UnsafeProxy
    import copy
    import ansible
    ds = [{'block': {'block': [{'block': ['hello']}, 'world']}}]
    role = None
    task_include = TaskInclude.load(ds)
    use_handlers = False
    variable_manager = None
    loader = None
    play = None

# Generated at 2022-06-21 00:35:08.077172
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    # example role definition
    ds = [{'role': 'myrole', 'become_method': 'sudo'}]
    pc = PlayContext()
    v = VariableManager()
    assert load_list_of_roles(ds, None, current_role_path=None, variable_manager=v, loader=None, collection_search_list=None) == [{"become_method": "sudo", "role": "myrole", "role_path": None}]

# Generated at 2022-06-21 00:35:16.861624
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader

    play_ds = [{
        "name": "test",
        "hosts": "localhost",
        "tasks": [
            {"action": {"module": "shell", "args": "ls", "name": "Test"}},
            {"action": {"module": "shell", "args": "ls", "name": "Test"}},
        ]
    }]

    loader = DataLoader()

    play, ds = Play.load(play_ds, variable_manager=None, loader=loader)
    blocks = load_list_of_blocks(ds, play)

    assert len(blocks) == 1
    assert blocks[0].name is None


# Generated at 2022-06-21 00:35:27.442273
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Implicit blocks are created by bare tasks listed in a play without
    # an explicit block statement. If we have two implicit blocks in a row,
    # squash them down to a single block to save processing time later.
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    def task1_load(_self, ds, block=None, role=None, task_include=None, variable_manager=None, loader=None):
        task = Task()
        task.block = block
        task.name = "first"
        task.args = {}
        return task

    Task.load = task1_load


# Generated at 2022-06-21 00:35:49.614711
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:35:57.902359
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds=list()
    block_list=list()
    play=list()
    parent_block=list()
    role=list()
    task_include=list()
    use_handlers=bool(True)
    variable_manager=list()
    loader=list()
    load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-21 00:36:05.461519
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    mock_block = MagicMock(Block)
    mock_role = MagicMock()
    mock_task_include = MagicMock(TaskInclude)
    mock_use_handlers = MagicMock()
    mock_variable_manager = MagicMock()
    mock_loader = MagicMock()

    ds_empty_list = []
    ds_dict_only = [1]
    ds_not_dict = [{}]
    ds_no_block = [{'test': 'success'}]
    ds_block = [{'block': 'success'}]

    # Empty

# Generated at 2022-06-21 00:36:15.448787
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # noinspection PyUnresolvedReferences
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.loader import get_collection_loader
    from ansible.utils.vars import combine_vars

    # Using dummy Play from the tests since we only care about the variable_manager
    variable_manager = Play()._variable_manager
    # We must do an update instead of setting the attribute directly because this variable_manager is created with a call to
    # ansible/utils/vars.py:get_vars and that call calls ansible/utils/vars.py:get_validation_rules which is a method
    # that returns a memoized object and we want to update that object and not replace it

# Generated at 2022-06-21 00:36:25.196644
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:36:35.619007
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

        ds = [{'action': 'test_action', 'args': 'test_args'}]
        class mock_variable_manager:
            def get_vars(self, play=None, task=None):
                return {}
            def set_host_variable(self, host, varname, value):
                pass
            def set_nonpersistent_facts(self, facts):
                pass
            def set_task_facts(self, host, facts, task):
                pass

        class mock_play:
            def get_variable_manager(self):
                return mock_variable_manager()

        class mock_task:
            def copy(self, exclude_parent=False):
                pass

        class mock_block:
            def get_dep_chain(self):
                return ['test_dependencies_chain']


# Generated at 2022-06-21 00:36:48.138078
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition

    ds = [
        {'tasks': [{'debug': 'msg=foo'}]},
        {'tasks': [{'debug': 'msg=foo'}, {'debug': 'msg=bar'}]},
        {'tasks': [{'debug': 'msg=foo'}]},
        None
    ]

    play = Play().load({
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': ds
    }, variable_manager=dict(), loader=dict())

    result = load_list_of_

# Generated at 2022-06-21 00:36:56.626596
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader, inventory=InventoryManager(loader=loader, sources=[]))
    play = Play.load(
        dict(
            name="foobar",
            hosts='localhost',
            gather_facts='no',
            roles=dict(
                role1=dict(
                    name="someargs",
                    tasks=[dict(name="task1")]
                )
            )
        ),
        variable_manager=variable_manager,
        loader=loader)


# Generated at 2022-06-21 00:37:06.364186
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block

    loader, inventory, variable_manager = _get_base_objects()

    variable_manager.extra_vars = {
        "test_var": "test_var_val"
    }

    ds = [
        {"task": {"test": "test"}, "name": "test task"},
        {"block": {"test": "test"}, "name": "test block"},
    ]

    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:37:12.739403
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = []
    play = yaml.load("name: firstplay")
    block = yaml.load("name: firstblock")
    role = yaml.load("name: firstrole")
    task_include = yaml.load("name: firsttask_include")
    use_handlers = False
    variable_manager = True
    loader = True
    expected_ans = []
    ans = load_list_of_tasks(ds,play,block,role,task_include,use_handlers,variable_manager,loader)
    assert ans == expected_ans


# Generated at 2022-06-21 00:37:44.199016
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import merge_hash


# Generated at 2022-06-21 00:37:44.994164
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False

# Generated at 2022-06-21 00:37:45.936945
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-21 00:37:55.002181
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-21 00:37:59.809585
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar

    # create a dummy play to pass in
    play = Play()
    play._role_name = 'test_role'
    play._file_name = 'test_playbook.yml'
    play._hosts = ''
    play._basedir = os.path.abspath('/test_playbook_basedir')

    # create a dummy task to pass in
    task = Task()
    task._role = None
    task._role_name = None

    # create a dummy block to pass in
    block = Task()
    block._role = None
    block._role_name = None
    block._parent = None

   

# Generated at 2022-06-21 00:38:11.218771
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    playbook_file = './test/unit/test_command_module.yml'
    play = Play().load(playbook_file, variable_manager=VariableManager(), loader=None)
    inventory = InventoryManager(loader=None, sources=play.hosts)
    variable_manager = VariableManager(loader=None, inventory=inventory)
    run_context = play.set_variable_manager(variable_manager)
    print (run_context)
    print

# Generated at 2022-06-21 00:38:12.954775
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "Unimplemented"

# Generated at 2022-06-21 00:38:20.522935
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{
        'block': [
            {'block': []},
            {'block': [{'block': []}, {'block': []}]},
        ]
    }]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    blocks = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-21 00:38:32.058810
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

    # Fake play data
    play_ds = dict(
        name = "Ansible Play",
        hosts = "fake_hosts",
        gather_facts = False,
        vars=dict()
    )
    p = Play().load(play_ds, variable_manager=None, loader=None)

    # Fake task data

# Generated at 2022-06-21 00:38:43.359123
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    import ansible.utils.template as template
    import ansible.utils.vars as vars
    import ansible.utils.jinja_filters as jinja_filters

    display = Display()
    display.verbosity = 4
    display.deprecated('test')
    display.display('test')

    yaml_loader = AnsibleLoader(yaml_str, 'json')
    res = yaml_loader.get_single_data()
    #print json.dumps(res)

    inventory = ansible.inventory.Inventory('/Users/lz/git/ansible/test/inventory')

# Generated at 2022-06-21 00:39:20.700104
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    test_ds = [
        {"role": "role1"},
        {"role": "role2"},
        {"role": "role3"}
    ]
    play = MagicMock()
    current_role_path = None
    variable_manager = MagicMock()
    loader = MagicMock()
    collection_search_list = None
    results = load_list_of_roles(test_ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert len(results) == 3


# Generated at 2022-06-21 00:39:31.768265
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins import module_loader
    from ansible.utils.vars import combine_vars

    # setup
    variable_manager = VariableManager()
    loader = DataLoader()
    id = "test_id"
    name = "test_name"
    ds = [
        {"name": "name", "id": "id" }
    ]
    play = Play().load(ds, variable_manager=variable_manager, loader=loader)
    vm = combine_vars(loader=loader,
                      variables=variable_manager.get_vars(play=play))
    # test

# Generated at 2022-06-21 00:39:42.185292
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    from ansible.playbook.play import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 00:39:49.491621
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    #from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.sentinel import Sentinel
    #from ansible.utils.vars import load_extra_vars

    # this is a test harness to invoke a playbook and test the results
    # of the results of the run, based on the configuration in a test
    # yaml file

# Generated at 2022-06-21 00:39:59.840733
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.objects import AnsibleSequence
    ds = AnsibleSequence()
    ds[0] = 'debug'
    ds[1] = 'ansible'
    ds[2] = 'foo'
    
    try:
        output = load_list_of_tasks(ds)
        assert False, 'This should have thrown an error.'
    except AnsibleParserError as e:
        assert 'The ds (%s) should be a dict' % ds in str(e)
    
    
    ds[0] = {'debug': 1}
    ds[1] = {'ansible' : 2}
    ds[2] = {'foo': 3}
    

# Generated at 2022-06-21 00:40:04.576952
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile

    inventory = InventoryManager()
    variable_manager = VariableManager(loader=None, inventory=inventory)

    loader = DataLoader()

# Generated at 2022-06-21 00:40:06.188707
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # TODO: load_list_of_roles should be moved to a separate module, so that it can be tested independently.
    # Currently, it involves test_roles_collections which is not a unit test.
    pass

# Generated at 2022-06-21 00:40:18.810367
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-21 00:40:29.277553
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    ansible.playbook.helpers.load_list_of_tasks unit test stub
    """

    #from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    if not hasattr(builtins, 'unittest'):
        import unittest2 as unittest
    else:
        import unittest

    test_case = unittest.TestCase()
    test_case.assertEqual(AnsibleRunner(
    ).run_unit_test(load_list_of_tasks_ansible_collections_not_supported), 0)


if __name__ == '__main__':
    main()

# Generated at 2022-06-21 00:40:39.685104
# Unit test for function load_list_of_roles

# Generated at 2022-06-21 00:41:32.874303
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def test(input, expected, expected_length=None):
        from ansible.playbook.play import Play
        from ansible.vars.manager import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader
        from ansible.parsing.mod_args import ModuleArgsParser

        p = Play.load(input, variable_manager=VariableManager(), loader=DataLoader())
        assert p.block == expected
        if expected_length:
            assert len(p.block) == expected_length

    test_case = {
        "tasks": [
            {"shell": "echo hello"}
        ]
    }

# Generated at 2022-06-21 00:41:39.405699
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host
            print(host.name)

    dummy_loader = DataLoader()
    dummy_inventory = Inventory(loader=dummy_loader, variable_manager=VariableManager(), host_list=[])

# Generated at 2022-06-21 00:41:40.863847
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # ToDo: Write unit test
    pass

# Generated at 2022-06-21 00:41:41.725653
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    assert False

# Generated at 2022-06-21 00:41:47.853864
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.context import CLIContext

    ds = [
        dict(
            name='test_role',
            foo='bar',
        ),
        dict(
            name='test_collection.test_role',
            foo='baz',
        )
    ]
    context = CLIContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 00:41:55.349107
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(None, None, None, None, None, None, None) == []
    assert load_list_of_tasks([], None, None, None, None, None, None) == []
    assert load_list_of_tasks([{}], None, None, None, None, None, None) == []
    assert load_list_of_tasks([{'name': 'xyz'}], None, None, None, None, None, None) == []
    assert load_list_of_tasks([{'name': 'xyz'}, {}], None, None, None, None, None, None) == []



# Generated at 2022-06-21 00:42:02.783606
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'include_tasks': 'test.yml'},
        {'include_role': 'test'},
        {'include': 'test.yml', 'static': True},
        {'include': 'test.yml', 'static': False},
    ]
    result = load_list_of_tasks(ds, play=True, block=True, variable_manager=True, loader=True)

    assert result == None

# Generated at 2022-06-21 00:42:14.582567
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    mock_loader = DictDataLoader({
        "some.yml": "",
        "other.yml": ""
    })
    mock_variable_manager = VariableManager()
    mock_variable_manager.set_host_variable(Host("mock_host"), "mock_var", "mock_value")
    mock_play = Play()
    mock_block = Block()

    # test no ds param
    result = load_list_of_tasks(None, mock_play, mock_block, None, None, False, mock_variable_manager, mock_loader)
    assert result == []

    # test non-list ds param

# Generated at 2022-06-21 00:42:24.479869
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class Dummy:
        def __init__(self):
            self.display = display
    dummy_loader = Dummy()