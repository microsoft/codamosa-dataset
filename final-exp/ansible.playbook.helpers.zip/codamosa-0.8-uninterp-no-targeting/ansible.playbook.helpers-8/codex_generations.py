

# Generated at 2022-06-21 00:33:08.184800
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins import collection_loader
    import ansible.constants as C
    import os

    class Options(object):
        connection = 'local'
        module_path = None
        forks = 100
        become = False
        become_method = None
        become_user = None
        check = False
        diff = False
        syntax = None
        start_at_task = None
        remote_user = 'root'
        verbosity = 3

# Generated at 2022-06-21 00:33:17.001188
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    data = [{"task_field": "task_value"}]
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict(play_field="play_value")

    play = Play.load(
        {
            "name": "test",
            "hosts": "test_hosts",
            "gather_facts": "no",
        },
        variable_manager=variable_manager,
        loader=None
    )

    blocks = load_list_of_blocks(data, play, variable_manager=variable_manager)
    block = blocks[0]

    # The block.block contains the original data, and the tasks contains the parsed version

# Generated at 2022-06-21 00:33:30.012981
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds=[{'action': 'setup', 'register': 's1'},
        {'action': 'shell', 'args': 'ls -l', 'register': 'r1'},
        {'action': 'debug', 'msg': '{{r1.stdout_lines}}'},
        {'action': 'include_tasks', 'file': 'hosts.yml', 'name': 'abcd'},
        {'action': 'include_role', 'name': 'myrole', 'tasks_from': 'main'},
        {'action': 'meta', 'flush_cache': 'yes'},
        {'action': 'pause', 'seconds': 5}]
    task_list=load_list_of_tasks(ds)
    print(task_list)
test_load_list_of_tasks()



# Generated at 2022-06-21 00:33:41.103321
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    print("Testing load_list_of_blocks")
    import unittest
    import os
    import yaml
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.module_utils.six import string_types


    class TestTask:
        def __init__(self, name="test"):
            self.name = name

        def __repr__(self):
            return '{"%s"}' % self.name


    class TestPlay(Play):
        def __init__(self):
            super(TestPlay, self).__init__()
            self.extra_vars = dict(test="testvar")
            self.connection = "test"
            self.hosts = "test"
            self.any_errors_fatal = False


# Generated at 2022-06-21 00:33:49.998501
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test load_list_of_roles()
    """
    fake_role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test')
    fake_role_path = os.path.realpath(fake_role_path)

    # Find the 'test' role
    fake_role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test')
    fake_role_path = os.path.realpath(fake_role_path)

    # Setup the fake play
    play = {}


# Generated at 2022-06-21 00:34:02.105772
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    '''
        Given a list of task datastructures (parsed from YAML),
        return a list of Task() or TaskInclude() objects.
    '''

    from ansible.parsing.yaml.objects import AnsibleSequence


# Generated at 2022-06-21 00:34:06.328808
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    current_role_path = os.path.abspath(['test_data', 'roles', 'test_role'])

    def assert_load_list_of_roles(ds, expected):
        assert expected is not None
        roles

# Generated at 2022-06-21 00:34:09.006087
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{'include': 'test.yml'}]) == []

# Generated at 2022-06-21 00:34:14.892088
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play = Play().load({'name': 'test play', 'hosts': 'all'}, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:34:19.902586
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Init
    ds = [{'name': 'test_role', 'foo': 'bar'}]
    play = Play()
    current_role_path= None,
    variable_manager= None,
    loader= None,
    collection_search_list= None

    # load_list_of_roles
    roles = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)

    # Assert
    assert roles

# Generated at 2022-06-21 00:34:42.684734
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test case where ds is None.
    ds = None
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    res = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert res == []

    # Test case where ds is not a list
    ds = 'test123'
    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

    # Test case where ds is a list and has an empty list entry.

# Generated at 2022-06-21 00:34:54.980963
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # This will blow up with a circular import until we move this function out of this file
    from ansible.playbook.block import Block

    ds = [1, 2, 3, 4]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    assert len(load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)) == 4
    for block in load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader):
        assert isinstance(block, Block)
        assert block.block is None

    ds = 4
    play = None
    parent

# Generated at 2022-06-21 00:35:06.523510
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Create role includes
    loader = DictDataLoader({})
    inventory = HostInventory('localhost')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play()
    ds = [{'role': 'foo'}, {'role': 'geerlingguy.jenkins'}, {'role': 'bar', 'some_var': 10, 'tags': ['foo', 'bar']}]
    role_includes = load_list_of_roles(ds, play, variable_manager=variable_manager, loader=loader)

    # Test role includes
    assert role_includes[0]._role_name == 'foo'
    assert role_includes[1]._role_name == 'geerlingguy.jenkins'
    assert role_includes[2]._role_name == 'bar'
    assert role

# Generated at 2022-06-21 00:35:14.918322
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """Unit test for function load_list_of_roles."""
    ansible_start_dir = os.path.dirname(os.path.abspath(__file__))
    fixtures_path = os.path.join(ansible_start_dir, 'test/test_playbook/playbook/test_playbook_data/')
    test_playbook_path = os.path.join(fixtures_path, 'playbook_roles.yml')

    with open(test_playbook_path, 'r') as stream:
        ds = yaml.safe_load(stream)

# Generated at 2022-06-21 00:35:26.015666
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    
    variable_manager = VariableManager()
    loader = DataLoader()

    host_list = [
        "test01-ansible-test.example.com",
        "test02-ansible-test.example.com",
        "test03-ansible-test.example.com"
    ]

    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=host_list)
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:35:34.761507
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    import ansible.playbook
    ansible.playbook.loader.get_loader_instance = lambda : FakeAnsibleFileLoader()

    block_vars = dict(
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=FakeVariableManager(dict()),
        loader=None,
    )

    block_vars['variable_manager']._fact_cache['hostvars'] = dict(
        testhost=dict(
            ansible_host='testhost_val',
        ),
        testhost_group="testhost_group_val",
        testhost_ip="testhost_ip_val",
    )


# Generated at 2022-06-21 00:35:42.460630
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'name': 'role1'}, {'name': 'role2'}]

    # test empty list
    assert len(load_list_of_roles(None, None)) == 0

    # test malformed roles list
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(object, object)

    # test roles list
    assert len(load_list_of_roles(ds, object)) == 2



# Generated at 2022-06-21 00:35:54.119497
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    dummy_task1={
        "name": "hello",
        "block": []
    }
    task_list1=[]
    task_list1=load_list_of_tasks([dummy_task1], None, None, None, None, None, None, None)
    assert (len(task_list1) == 1)
    dummy_task2={
        "name": "hello2"
    }
    task_list2=load_list_of_tasks([dummy_task2], None, None, None, None, None, None, None)
    assert (len(task_list2) == 1)
    task_list3=load_list_of_tasks([dummy_task1, dummy_task2], None, None, None, None, None, None, None)

# Generated at 2022-06-21 00:36:03.724861
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group

    display.verbosity = 3

    inventory = InventoryManager(loader=None, sources='')
    variable_manager = VariableManager(loader=None, inventory=inventory)

    play_source =  dict(
            name = "Ansible Play",
            hosts = 'localhost',
            gather_facts = 'no',
            tasks = [
                dict(action=dict(module='setup', args='')),
            ]
        )

    play = Play().load(play_source, variable_manager=variable_manager, loader=None)

    task_list = load_list_of_

# Generated at 2022-06-21 00:36:04.662818
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-21 00:36:23.371474
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    task_list      = [{'action': {'module': 'setup'}}, {'action': {'module': 'shell', 'args': 'ls -la'}}]

    fake_loader    = FakeLoader()
    fake_tasks     = FakeTasks(task_list)
    fake_play      = FakePlay(load_tasks=fake_tasks)
    fake_variablem = FakeVariableManager()

    block_list = load_list_of_blocks(task_list, fake_play, fake_variablem, fake_loader)
    assert len(block_list) == 2

    assert isinstance(block_list[0], Block)
    assert block_list[0].block  == task_list[0]
    assert block_list[0]._play  == fake_

# Generated at 2022-06-21 00:36:24.400881
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-21 00:36:35.203394
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks([None]) == []

    # Test load_list_of_blocks with bare tasks
    implicit_block_tasks = [{'local_action': 'shell foo'}, {'block': 'task 2'}]
    implicit_block_obj = load_list_of_blocks(implicit_block_tasks)[0]
    assert implicit_block_obj.block  == ['task 2']
    assert implicit_block_obj.filter_tagged_tasks() == [{'local_action': 'shell foo'}, {'block': 'task 2'}]

    # Test load_list_of_blocks with multiple bare tasks
    implicit_block_tasks = [{'local_action': 'shell foo'}, {'local_action': 'shell bar'}]
    implicit_block_obj = load_

# Generated at 2022-06-21 00:36:47.410834
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = host_list=[['host1', 'host2']]

# Generated at 2022-06-21 00:36:54.258286
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # setup
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole


# Generated at 2022-06-21 00:37:05.431141
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader, inventory, variable_manager = (
        _get_loader(),
        _get_inventory(),
        _get_variable_manager()
    )
    task_ds = [
        {
            'name': 'task1',
            'action': 'action1',
        },
        {
            'name': 'task2',
            'action': 'action2',
        }
    ]
    result = load_list_of_tasks(
        task_ds,
        _get_play(),
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=variable_manager,
        loader=loader,
    )
    assert len(result) == 2
    assert len(result[0].args) > 0 and len(result[1].args)

# Generated at 2022-06-21 00:37:13.526661
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var

    fake_loader = DictDataLoader({'/test-test-test': dict(test_data='test')})

    ds1 = dict(
        block=dict(
            tasks=[
                dict(action=dict(module='setup', args='a=1')),
                dict(action=dict(module='debug', args=dict(msg='testing'))),
                dict(action=dict(module='debug', args=dict(msg='- debug: {1: 1, 2: 2')))
            ]
        )
    )

# Generated at 2022-06-21 00:37:24.969961
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import Reserved
    from ansible.inventory.manager import InventoryManager

    ds = [
       {'name': 'Test Task 1', 'action': {'__ansible_module__': 'debug', 'msg': 'Hello' }},
       {'name': 'Test Task 2', 'action': {'__ansible_module__': 'debug', 'msg': 'Hello' }},
    ]

    count

# Generated at 2022-06-21 00:37:25.940064
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert True

# Generated at 2022-06-21 00:37:34.453132
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def _create_data(raw):
        # We only want to test the parsing of blocks, we don't care about the
        # execution of them, so create the minimum required data structures
        # to parse
        from ansible.playbook.play import Play
        from ansible.playbook.task import Task
        from ansible.playbook.role_include import RoleInclude
        from ansible.vars.manager import VariableManager

        play = Play().load(dict(
            name='Test Play',
            hosts=['all'],
            gather_facts='no',
            tasks=raw,
        ), variable_manager=VariableManager())

        role = RoleInclude().load(dict(
            name='Test Role',
            static='yes'
        ))

        return play, role, Task()

    def _test_ds(ds):
        display

# Generated at 2022-06-21 00:38:02.404413
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    role_def = {
        "name": "test_role",
        "tasks_from": "./tasks/main.yml",
        "default_vars": {
            "tomcat_user" : "tomcat",
            "tomcat_group" : "tomcat",
            "tomcat_home" : "/var/tomcat",
        }
    }

    ds = [role_def]
    play = {}

    roles = load_list_of_roles(ds, play, current_role_path=None, variable_manager=None, loader=None,
                               collection_search_list=None)

    assert len(roles) == 1
    assert isinstance(roles[0], RoleInclude)

# Generated at 2022-06-21 00:38:12.149925
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    ds = [
        {'block':[
            {'task': {'action': 'dummy', 'loop':['1','2']}},
            {'task': {'action': 'dummy2', 'loop':'1'}},
        ]},
        {'task': {'action': 'dummy3', 'loop':'1'}},
        {'task': {'action': 'dummy4', 'loop':'1', 'include_tasks': 'dynamic.yml'}},
        {'task': {'action': 'dummy5', 'loop':'1', 'import_tasks': 'dynamic.yml'}},
    ]

# Generated at 2022-06-21 00:38:22.425569
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar

    from ansible.config.manager import ConfigManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()

    variable_manager = VariableManager()

# Generated at 2022-06-21 00:38:33.090740
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Simple test of load_list_of_roles
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {
        'name': 'bob',
        'longness': 10,
        'greeting': 'hello',
    }


# Generated at 2022-06-21 00:38:39.329289
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.block import Block
    from ansible.plugins import module_loader


# Generated at 2022-06-21 00:38:40.704936
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: needs a unit test
    pass

# Generated at 2022-06-21 00:38:41.839884
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-21 00:38:44.270879
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play

# Generated at 2022-06-21 00:38:55.889876
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.template import Templar


# Generated at 2022-06-21 00:39:04.095545
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test 1
    # have include tasks, static_load: off, loop: off
    # static_load: off
    ds1 = """
- command: echo "123"
- include_tasks: abc.yml
- include_tasks: /tmp/def.yml
  static_load: no
"""
    # loop: off
    ds2 = """
- command: echo "123"
- include_tasks: abc.yml
- include_tasks: /tmp/def.yml
  loop: "{{ items }}"
  loop_control:
      loop_var: item
"""
    # static_load: off and loop: off

# Generated at 2022-06-21 00:39:59.125667
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play

    class DummyVariable:
        def __init__(self,hostvars):
            self.hostvars = hostvars
        def get_vars(self, host=None, task=None, include_hostvars=True):
            return self.hostvars
        def update_vars(self,hostvars):
            self.hostvars.update(hostvars)
        def get_hostvars(self,host):
            return self.hostvars


# Generated at 2022-06-21 00:40:04.013639
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.collection import VariableCollection
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    vc = VariableCollection()
    vc.add_empty_group()
    vc.set_variable('my_var', 'my_value')
    vc.add_child('child', vc)
    vm = VariableManager(loader=None, inventory=None, variable_manager=vc)

    p = Play.load({'name': 'test_load_list_of_blocks', 'hosts': 'all'})

# Generated at 2022-06-21 00:40:04.908303
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    return 1


# Generated at 2022-06-21 00:40:10.056758
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import include
    assert load_list_of_roles([{
        'role': 'apache',
        'when': 'ansible_os_family == "RedHat"',
        'tags': ["web"]
        }], None) == [include.RoleInclude({'role': 'apache',
                                           'when': 'ansible_os_family == "RedHat"',
                                           'tags': ["web"]},
                                          play = None,
                                          current_role_path = None)]

# Generated at 2022-06-21 00:40:20.558773
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-21 00:40:26.410926
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # assert that specific exception is raised
    with pytest.raises(AnsibleAssertionError) as excinfo:
        load_list_of_roles(set(), None)
    assert "ds" in str(excinfo.value)
    assert "should be a list" in str(excinfo.value)

# Generated at 2022-06-21 00:40:38.218625
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  # Create a variable manager, loader, etc.:
  variable_manager = ansible.vars.VariableManager()
  loader = ansible.parsing.dataloader.DataLoader()
  inventory = ansible.inventory.Inventory(loader=loader, variable_manager=variable_manager, host_list='')
  variable_manager.set_inventory(inventory)
  # Create a task_ds list, a task_list:
  task_ds = [{'action': 'include_tasks', 'args':{'_raw_params': 'var/tasks/test.yml'}},
  {'action': 'include_tasks', 'args':{'_raw_params': 'var/tasks/test.yml'}}]

# Generated at 2022-06-21 00:40:48.797258
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.unsafe_proxy import UnsafeProxy
    ds = [{"role": "role1", "foo": "bar"}, {"role": "role2", "bar": "foo"}]

    roles = load_list_of_roles(ds, None)

    assert isinstance(roles[1], RoleInclude)
    assert roles[1]._role_name == 'role2'
    assert roles[1]._role_params['bar'] == 'foo'

    loader = DictDataLoader({'path1': (None, b'{"hosts": "all"}')})

# Generated at 2022-06-21 00:40:49.705229
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:40:59.184836
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    test_args = [
        {
            "name": "TESTING",
            "when": True,
            "become": True,
            "become_user": "root",
            "block": [
                {
                    "name": "TESTING_PLUGIN",
                    "when": True,
                    "become": True,
                    "become_user": "root",
                },
                {
                    "name": "TESTING_PLUGIN2",
                    "when": True,
                    "become": True,
                    "become_user": "root",
                }
            ]
        }
    ]
    # Import dependencies
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play