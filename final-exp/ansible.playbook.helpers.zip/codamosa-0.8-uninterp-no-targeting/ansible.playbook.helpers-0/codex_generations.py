

# Generated at 2022-06-21 00:32:41.038868
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    sample_block = {u'block': [{u'task': {u'action': {u'module': u'yum', u'name': u'name=httpd state=latest'}}}]}
    assert load_list_of_blocks(sample_block) == [{u'block': [{u'task': {u'action': {u'module': u'yum', u'name': u'name=httpd state=latest'}}}]}]


# Generated at 2022-06-21 00:32:53.684780
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext

    # Create test data

# Generated at 2022-06-21 00:33:01.662887
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from collections import namedtuple
    from ansible.module_utils.common._collections_compat import Sequence
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.block import Block

    Task = namedtuple('Task', ['module_args', 'when'])

    def dummy_get_role_path(role_name, role_search_path=None):
        return ['', '']

    def dummy_load_role_definition(self, role, role_params, role_path=None):
        return ['','']

    AnsibleBaseYAMLObject.load = lambda x,y,z: ([], []) + ([], []) + ([], []) + ([], [])

    Module

# Generated at 2022-06-21 00:33:09.608955
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    isinstance(TASK_LIST, list): bool
    :param list obj: test object.
    :return: bool
    '''
    assert isinstance(load_list_of_tasks([{"include_vars": {"name": "{{SECRET}}", "default": {"secret": "password"}}}]), list)
    print("Test SUCCESS")

if __name__ == '__main__':
    test_load_list_of_tasks()

# Generated at 2022-06-21 00:33:19.842497
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.handler import Handler

    test_ds = [{'block': [{'test': 'foo'}], 'test': 'bar'}]
    test_ds1 = [{'meta': [{'test': 'foo'}], 'test': 'bar'}]

    assert load_list_of_tasks(test_ds, None) == load_list_of_tasks(test_ds1, None)
    assert load_list_of_tasks(test_ds, None) == load_list_of_tasks(test_ds1, None, use_handlers=True)

# Generated at 2022-06-21 00:33:31.781764
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    class Options(object):
        connection = 'local'
        forks=10
        remote_user = 'vagrant'
        private_key_file = 'test/test_utils/test.pem'
        ssh_common_args = ''
        ssh_extra_args = ''
        sftp_extra_args = ''
        scp_extra_args = ''
        become=True
        become_method='sudo'
        become_user='root'
        verbosity=3
        check=False

    options = Options()
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 00:33:41.842177
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'block': 'a block'},
        {'tasks': 'tasks to load'},
        {'include_tasks': 'tasks to load'}
    ]

    play = object()
    block = object()
    role = object()
    task_include = object()
    use_handlers = object()
    variable_manager = object()
    loader = object()

    with pytest.raises(AnsibleAssertionError):
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-21 00:33:49.836347
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    class MockInclude:
        def __init__(self):
            self.role_name = 'test_role'
            self.is_loaded = True

    mock_role = MockInclude()
    mock_loader = mock.Mock()
    mock_loader.path_dwim_relative.return_value = 'test_role'
    data = [{'role': 'test'}]
    result = load_list_of_roles(data, play=None,
                               current_role_path=None,
                               variable_manager=None,
                               loader=mock_loader, collection_search_list=None)
    assert len(result) == 1
    assert result[0].role_name == 'test'


# Generated at 2022-06-21 00:34:02.070627
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Ensures that load_list_of_tasks returns the most basic task.
    """
    from ansible.playbook.play import Play
    play_ds = {
        'name': 'test_play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'debug': {'msg': ' hi '}}
        ],
    }

    play = Play().load(
        play_ds,
        variable_manager=VariableManager(),
        loader=DictDataLoader(),
    )

    simple_task_ds = [{'debug': {'msg': ' hi '}}]
    block_list = load_list_of_tasks(simple_task_ds, play, None, None, None, False, VariableManager(), DictDataLoader())


# Generated at 2022-06-21 00:34:12.799174
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DataLoader()

    def create_value(value):
        if isinstance(value, list):
            return [create_value(elem) for elem in value]
        elif isinstance(value, tuple):
            return tuple(create_value(elem) for elem in value)
        elif isinstance(value, dict):
            return {k: create_value(v) for k, v in value.items()}
        else:
            return value

    def _check(input, expected):
        play = Play().load({
            'name': 'role_play',
            'hosts': 'all',
            'roles': input
        }, variable_manager=None, loader=loader)
        roles = play.compile_roles_list()
        actual = [role.get_name() for role in roles]

# Generated at 2022-06-21 00:34:51.003989
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    role_def1 = dict(role='test_role1')
    role_def2 = dict(role='test_role2')
    ds = [role_def1, role_def2]

    test_roles = load_list_of_roles(ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
    assert len(test_roles) == 2
    for i in test_roles:
        assert isinstance(i, RoleInclude)


# Generated at 2022-06-21 00:35:01.549266
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'role': 'role1'}, {'role': 'role2'}]
    play = Play()
    roles = load_list_of_roles(ds, play)
    assert len(roles) == 2
    assert roles[0].get_name() == 'role1'
    assert roles[1].get_name() == 'role2'

    ds = [{'name': 'role1'}, {'name': 'role2'}]
    play = Play()
    roles = load_list_of_roles(ds, play)
    assert len(roles) == 2
    assert roles[0].get_name() == 'role1'
    assert roles[1].get_name() == 'role2'


# Generated at 2022-06-21 00:35:12.898191
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
        { "block": []},
        {
            "block": [
                { "task": [{ "include": "some.yml" }] }
            ]
        },
        { "include": "some.yml" },
        { "import_playbook": "some.yml" },
        { "block": []},
        { "include": "some.yml" },
        { "import_playbook": "some.yml" },
    ]


# Generated at 2022-06-21 00:35:13.746413
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:35:25.794511
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C
    import ansible.variables as V
    import ansible.template as T
    import ansible.modules as M
    import ansible.errors as E

    ds = '''
    - include_tasks: abc
    - name: 'hi'
    '''

    d = yaml.safe_load(ds)

    # ARRANGE
    play = Play.load(d, variable_manager=V.VariableManager(), loader=T.AnsibleLoader(None))
    block = play.block
    role = play.role

# Generated at 2022-06-21 00:35:34.649933
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import load_extra_vars

    from ansible.vars.manager import VariableManager


    loader = DataLoader()

    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:35:44.571326
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar

    loader = DsLoader()
    play_context = PlayContext()
    variable_manager = VariableManager()

    ds = [
        'role_name1',
        {
            'role': 'role_name2',
            'name': 'role_name2',
            'tasks_from': 'main.yml',
            'allow_duplicates': False,
            'tags': ['tag1', 'tag2'],
            'when': '1 > 2',
            'async': 2
        }
    ]



# Generated at 2022-06-21 00:35:54.953378
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = Base.variable_manager_class()

    play = Base()
    play._loader = loader
    play._variable_manager = variable_manager

    ds = [
        dict(name='task1', action=dict(module='copy', src='{{ test2 }}')),
        dict(name='task2', action=dict(module='copy', src='{{ test2 }}')),
        dict(name='task3', action=dict(module='copy', src='{{ test3 }}')),
        dict(name='task4', action=dict(module='copy', src='{{ test4 }}'))
    ]

    block_list

# Generated at 2022-06-21 00:35:55.626880
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:36:02.153509
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback.default import CallbackModule
    #from ansible.playbook.playbook_inventory import PlaybookInventory
    #from ansible.inventory.inventory import Inventory
    #from ansible.vars.hostvars import HostVars
    import io
    import sys
    import json
    import os
    #import pdb
    #pdb.set_trace()
    current_dir = os.getcwd()


# Generated at 2022-06-21 00:36:35.382851
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test 1: role_def is  a non-list
    ds = {}
    play = Play()
    current_role_path = None
    variable_manager = ""
    loader = ""
    collection_search_list = ""

    with pytest.raises(AnsibleAssertionError) as execinfo:
        load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert "ds (dict) should be a list but was a dict" in str(execinfo.value)
    # Test 2: role_def is a list
    ds = [{'role' : 'test_role'}]
    play = Play()
    current_role_path = None
    variable_manager = ""
    loader = ""
    collection_search_list

# Generated at 2022-06-21 00:36:47.992931
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
        Given a list of task datastructures (parsed from YAML),
        return a list of Task() or TaskInclude() objects.
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VarsManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost, testserver'])
    variable_manager = VarsManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:36:54.322150
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Test suite for module ansible.executor.task_utils
    :return: no return
    '''
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.utils.vars import TrustedHostsArgumentParser
    from ansible.utils.vars import combine_vars

    class LOOB():
        variables = []
        def __init__(self):
            self.play = Play()
            self.play.post_validate()
            self.play.handlers = []

# Generated at 2022-06-21 00:36:58.875166
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins import callback_loader
    from ansible.playbook.play_context import PlayContext

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager)
    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'test'
    play_context.remote_addr = '127.0.0.1'

# Generated at 2022-06-21 00:37:04.522194
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    Unit test for method load_list_of_tasks
    """

    load_list_of_blocks(ds="", play='', parent_block='', role='', task_include='', use_handlers=False, variable_manager='', loader='')
    load_list_of_tasks(ds="", play='', block='', role='', task_include='', use_handlers=False, variable_manager='', loader='')
    return

# Generated at 2022-06-21 00:37:12.622463
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleMapping
    import ansible.constants as C
    loader_args = dict(
        mock_loader=True,
        collection_playbooks=False,
        fake_collection_dir=True
    )
    loader = AnsibleCollectionLoader(**loader_args)
    variable_manager = VariableManager()

    # Testing with a list of tasks

# Generated at 2022-06-21 00:37:24.515514
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    display.display("load list of blocks")
    ds = [{}, {}, {}, {}]
    display.display(load_list_of_blocks(ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None))
    ds = [{'include': 'dw'}, {}, {}, {}]
    display.display(load_list_of_blocks(ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None))
    ds = [{'include': 'dw'}, {'include_tasks': 'sw'}, {}, {}]

# Generated at 2022-06-21 00:37:25.562366
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: provide a unit test
    pass


# Generated at 2022-06-21 00:37:34.353392
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    add_all_plugin_dirs()

    loader, inventory, variable_manager = CLI.setup_loader()

    # create play with tasks
    play_source =  dict(
        name="Ansible Play",
        hosts='webservers',
        gather_facts='no',
        tasks=[
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # create role with pre_tasks


# Generated at 2022-06-21 00:37:43.794396
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = '''
- include:
    file: foo.yml
    static: yes
    loop: "{{ range(1, 10) }}"
- import_tasks:
    file: foo.yml
    static: yes
- import_role:
    name: role1
    static: yes
- include_role:
    name: role2
    loop: "{{ range(1, 10) }}"
- include_tasks:
    file: bar.yml
    loop: "{{ range(1, 10) }}"
'''
    ds = yaml.safe_load(ds)
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())

    loader = DataLoader()

# Generated at 2022-06-21 00:38:20.549560
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    fake_play = Play()
    fake_role_list = [
        {
            "name": "galaxy.foo",
        },
        {
            "name": "ansible-foo",
        },
    ]

    class FakeRoleCollection():
        def get_single_role_definition(self, role_name):
            return {
                "name": "{}.{}".format(self.name, role_name),
                "path": "foo/bar",
                "version": "1.2.3",
            }

    class FakeRoleCM():
        def get(self, role_name):
            return FakeRoleCollection()

    class FakeCollectionLoader():
        role_collections = FakeRoleCM()

    class FakeVarsMgr():
        def __init__(self, **kwargs):
            self.extra_vars

# Generated at 2022-06-21 00:38:24.869812
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    play_list = []
    load_list_of_blocks(ds=play_list, play=None)
    load_list_of_blocks(ds=None, play=None)



# Generated at 2022-06-21 00:38:34.311914
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test with a list of mixed task/block data
    ds = [
        {'block': {'block': {'block': [{'always': 'always'}], 'always': 'always'}, 'always': 'always'}},
        {'name': 'name'},
        {'include': 'include', 'static': 'static'},
        {'import_tasks': 'import_tasks'},
        {'include_role': 'include_role', 'static': 'static'},
        {'import_role': 'import_role'}
    ]

# Generated at 2022-06-21 00:38:44.572541
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:38:47.193359
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(None) == []
    assert load_list_of_blocks([]) == []
    assert len(load_list_of_blocks([{'tasks': []}])) == 1



# Generated at 2022-06-21 00:38:51.990370
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{"role": "test_role"}]
    role_list = load_list_of_roles(ds=ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
    first_role = role_list[0]
    assert first_role._role_name == "test_role"


# FIXME: this needs to be reworked to use the new plugin architecture

# Generated at 2022-06-21 00:38:55.147790
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    res = load_list_of_blocks(None, None, None, None, None, None, None, None)
    assert res == []



# Generated at 2022-06-21 00:39:03.880297
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

    ds = [
        {'action': {'module': 'setup', 'args': ''}},
        {'block': [
            {'action': {'module': 'setup', 'args': ''}},
            {'block': [
                {'action': {'module': 'setup', 'args': ''}}
            ]},
            {'action': {'module': 'setup', 'args': ''}}
        ]}
    ]
    play = Play().load({}, variable_manager=None, loader=None)
    test_blocks = load_list_of_blocks(ds, play)
    assert len(test_blocks) == 3
    assert isinstance(test_blocks[0], Block)

# Generated at 2022-06-21 00:39:14.300570
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.process.factory import Factory
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils._text import to_text

    class MockOptions:
        connections = None
        remote_user = None
        module_path = None

# Generated at 2022-06-21 00:39:24.459875
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude

    ds = [
        {'name': 'role_foo',
         'tasks': {
             'task_one': {},
             'task_two': {}
         }},
        {'name': 'role_bar',
         'tasks': {
             'task_one': {},
             'task_two': {}
         }},
        {'name': 'role_baz',
         'tasks': {
             'task_one': {},
             'task_two': {}
         }},
    ]

    play = Play()
    results = load_list_of_roles(ds, play=play)
    assert len(results) == 3

# Generated at 2022-06-21 00:40:27.399524
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False

# Generated at 2022-06-21 00:40:38.850665
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_play
    from ansible.playbook.task import Task
    play = Play()
    play._ds = dict()
    ds = dict()
    ds['name'] = "test task"
    ds['action'] = dict()
    ds['action']['module'] = 'command'
    ds['action']['args'] = 'ls -al'
    ds_list = list()
    ds_list.append(ds)
    play_ds = dict()
    play_ds['hosts'] = 'all'
    play_ds['tasks'] = ds_list
    play._ds = play_ds
    ds_list = load_list_of_blocks(ds_list, play=play)

# Generated at 2022-06-21 00:40:49.121508
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Playbook
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.module_utils.common._collections_compat import OrderedDict

    args = OrderedDict()
    args['block'] = None
    args['role'] = 'test_role'
    args['task_include'] = ''
    args['use_handlers'] = False
    args['loader'] = None
    args['variable_manager'] = None

    task1 = dict(action='ping', hosts='192.168.1.1')

    block1 = dict(block=['ping the world'], tasks=[task1])


# Generated at 2022-06-21 00:40:58.970801
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.listify import listify_lookup_plugin_terms

    display.verbosity = 3
    current_path = os.path.dirname(os.path.realpath(__file__))
    inventory_file = os.path.join(current_path, '../inventory')
    inventory = InventoryManager(loader=loader, sources=inventory_file)

    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 00:41:08.713691
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.inventory import Inventory

    ds = [dict(role=dict(name='foo', bar=1)),]

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost')

    play = Play.load(dict(
        name='foo',
        hosts='localhost',
        roles=[dict(name='foo', bar=1),],
    ), variable_manager=variable_manager, loader=loader)

    foo_role = load_list_of_roles(ds, play, collection_search_list=[])
    assert len(foo_role) == 1
    assert foo_role[0]._role_name == 'foo'

# Generated at 2022-06-21 00:41:18.256648
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    task1 = Task()
    task1.name = 'task1'
    task2 = Task()
    task2.name = 'task2'
    task3 = Task()
    task3.name = 'task3'
    task4 = Task()
    task4.name = 'task4'
    task5 = Task()
    task5.name = 'task5'
    task6 = Task()
    task6.name = 'task6'
    task7 = Task()
    task7.name = 'task7'
    task8 = Task()
    task8.name = 'task8'


# Generated at 2022-06-21 00:41:28.916632
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import json

    # test None
    ds = None
    var_manager = VariableManager()
    try:
        load_list_of_blocks(ds, var_manager)
        assert False
    except AnsibleAssertionError as e:
        assert e.message == 'None should be a list or None but is None'

    # test list

# Generated at 2022-06-21 00:41:30.877113
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: Write unit test
    return True



# Generated at 2022-06-21 00:41:38.704794
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager
    from ansible.playbook.included_file import IncludedFile
    from ansible.template import Templar
    from ansible.parsing.vault import VaultLib

    # Setup
    display.verbosity = 3

    fake_loader = DictDataLoader({})
    fake_vault_secrets = dict(vault_pass='fake_vault_pass')
    vault_secrets_file = '/fake_vault_secrets'
    fake_vault = VaultLib([('default', fake_vault_secrets)])

# Generated at 2022-06-21 00:41:39.482589
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

