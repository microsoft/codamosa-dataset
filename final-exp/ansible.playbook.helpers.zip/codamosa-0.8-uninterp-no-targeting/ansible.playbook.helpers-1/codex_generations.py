

# Generated at 2022-06-21 00:33:13.550886
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    #
    # Test for skipping block_ds
    #
    task = {'foo':'bar'}
    block = {'block':task}
    ds = [task, task]
    actual = load_list_of_blocks(ds, None, None, None, None, use_handlers=False, variable_manager=None, loader=None)
    expected = [{'block':{'foo':'bar'}}, {'block':{'foo':'bar'}}]
    assert actual == expected
    #
    # Test for empty block_ds
    #
    ds = [task, block]
    actual = load_list_of_blocks(ds, None, None, None, None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-21 00:33:14.972283
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: Implement me.
    pass
# Load list of blocks

# Load list of tasks

# Generated at 2022-06-21 00:33:28.741010
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Test load_list_of_blocks
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()

# Generated at 2022-06-21 00:33:30.074591
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:33:39.822142
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import VariableResolver
    from ansible.template import Templar

# Generated at 2022-06-21 00:33:43.646056
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Unit test for function load_list_of_blocks
    '''
    raise NotImplementedError


# Generated at 2022-06-21 00:33:52.295489
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # prepare for testing
    # variable_manager and loader are needed for calling load_list_of_roles
    variable_manager = VariableManager()
    variable_manager._extra_vars = dict()
    loader = DataLoader()
    # collect data for calling load_list_of_roles
    # it needs a list of role definitions, which are dictionaries
    role_1 = {'role': 'role1'}
    role_2 = {'role': 'role2'}
    ds = [role_1, role_2]
    play = Play()
    current_role_path = '/tmp/current_role_path'
    collection_search_list = ['collection1', 'collection2']
    # call load_list_of_roles

# Generated at 2022-06-21 00:33:53.106729
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert False, "No tests for this yet"

# Generated at 2022-06-21 00:33:53.909227
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False


# Generated at 2022-06-21 00:34:04.024828
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # use a real playbook tree and a file which is found in the roles
    # "common" directory (in the test data) and belongs to the "roles"
    # directory of the playbook
    main_yaml_path = os.path.join(os.path.dirname(__file__), 'unit/test_collections/tasks/main.yml')
    playbook_dir = os.path.dirname(main_yaml_path)
    playbook_dir = playbook_dir[0:-len('tasks')]
    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play.load(dict(
        name='test',
        hosts='all',
        gather_facts='no',
        roles=['common'],
    ), loader=loader, variable_manager=variable_manager, loader_cache=dict())

# Generated at 2022-06-21 00:34:31.184982
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    load_list_of_tasks function - returns a list of Task() objects.
    :return:
    '''
    module = AnsibleModule(
        argument_spec = dict(
            item = dict(required=True, type='str'),
        ),
    )
    module.exit_json(changed=False, msg='this is a test')


# Generated at 2022-06-21 00:34:35.474111
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role_context import RoleContext

    # create task
    t = Task()
    t.action = 'setup'

    play_context = PlayContext()
    play_context.connection = 'local'
    role_context = RoleContext()
    role_context.name = 'myrole'
    blocks = [
        {'name': 'first', 'block': [{'action': 'setup'}]},
        {'name': 'second', 'block': [{'action': 'setup'}]},
        {'action': 'setup'},
        {'action': 'setup'},
        {'name': 'third', 'block': [{'action': 'setup'}]}
    ]


# Generated at 2022-06-21 00:34:42.218059
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'include': {'tasks': 'hello.yaml', 'static': True, 'name': 'hello'}},
        {'import_tasks': {'static': True, 'name': 'include_me'}},
        {'include_tasks': {'static': False, 'name': 'include_me_too'}},
        {'import_tasks': {'static': False, 'name': 'and_me_too'}},
        {'include': {'tasks': 'bye.yaml', 'static': True, 'name': 'bye'}},
        {'include_tasks': {'static': True, 'name': 'include_me_again'}},
    ]

# Generated at 2022-06-21 00:34:54.897689
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play as P
    from ansible.template import Templar
    from ansible.vars import VariableManager

    class FakeVarMgr(object):
        def __init__(self, *args, **kwargs):
            self.vars = {}
            self.extra_vars = {}
            self.options = {}
            self.extra_vars_loaded = False

        def set_options(self, *args, **kwargs):
            pass

        def get_options(self, *args, **kwargs):
            pass

        def get_vars(self, *args, **kwargs):
            return self.vars

        def get_host_vars(self, *args, **kwargs):
            return {}


# Generated at 2022-06-21 00:35:06.479449
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.manager import VariableManager

    play = Play.load(dict(vars=dict(foo="bar")))
    block = Block.load(dict(when="true"), play=play)


# Generated at 2022-06-21 00:35:14.881680
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # We import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    test_play = MagicMock()


    # For a block ds with no tasks, an empty list should be returned
    # Should pass the test
    test_block = MagicMock()
    test_block.block = []
    test_block.loop = None
    test_block_ds = MagicMock()
    test_block_ds.get.return_value = test_

# Generated at 2022-06-21 00:35:25.815840
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    # setup env
    import ansible
    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task
    fake_play = ansible.playbook.play.Play()
    fake_play._included_filenames = ['dummy_file']
    my_block_list = "[1, 2, 3]"
    # test happy path
    my_function_return = load_list_of_blocks(my_block_list, fake_play)
    assert isinstance(my_function_return, list)
    assert len(my_function_return) == 3
    # test exception

# Generated at 2022-06-21 00:35:34.679363
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()
    display = Display()

    hosts = {
        'all': [{
            'hostname': 'localhost'
        }]
    }
    inventory = InventoryManager(
        loader=loader,
        sources=hosts
    )


# Generated at 2022-06-21 00:35:44.600403
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Unit test for function load_list_of_tasks
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.task_executor import TaskExecutor
    import mock
    # target_host = Host(name="testhost")
    results_callback_mock = mock.Mock()


    mock_loader = mock.MagicMock()
    variable_manager = mock.MagicMock(VariableManager)
    inventory_manager = mock.Mock(InventoryManager)
    loader = mock.Mock

# Generated at 2022-06-21 00:35:55.018385
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    posts = [{'block': [{'block': [{'block': 'test','test': 'end'}]}]}, {'block': 'test','test': 'end'}]

    play = Play().load({
        'hosts': 'test',
        'gather_facts': 'no',
        'tasks': posts
    }, variable_manager=None, loader=None)
    p = Play()
    p.post_validate(play)

    assert len(p.tasks) == 2
    assert isinstance(p.tasks[0], Block)
    assert isinstance(p.tasks[0].block[0], Block)

# Generated at 2022-06-21 00:36:25.814212
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    This function tests the load_list_of_roles function
    """
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.template import Templar
    from ansible.vars.resolved_variable import ResolvedVariable

    # setup test objects
    def_loader = DataLoader()
    def_vars_mgr = VariableManager()
   

# Generated at 2022-06-21 00:36:36.191530
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Configure test environment
    import sys
    import os
    import shutil
    ansible_path = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../..'))
    sys.path.append(ansible_path)
    sys.modules['_ansible'] = mock.Mock()
    import ansible.constants as C
    C.HOST_KEY_CHECKING = False
    C.DEFAULT_ROLES_PATH = [os.path.join(ansible_path, 'test/testdata/roles')]
    C.ANSIBLE_RETRY_FILES_ENABLED = False
    C.ANSIBLE_INVENTORY = os.path.join(ansible_path, 'test/testdata/inventory')
    C.ANSIBLE

# Generated at 2022-06-21 00:36:44.738359
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
        This is a unit test for the function load_list_of_roles()
        @params ds: list of roles to load
        @params play: calling Play object
        @params current_role_path: path of the owning role, if any
        @params variable_manager: varmgr to use for templating
        @params loader: loader to use for DS parsing/services
        @params collection_search_list: list of collections to search for unqualified role names
        We will be testing it with different values for ds and expect different results
        The function return list of RoleInclude objects
    '''
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play

    role_def1 = "test/test1/test1.yml"

# Generated at 2022-06-21 00:36:55.357966
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Mock the loader functions
    loader_mock = mock.MagicMock()
    def mock_init(**kwargs):
        self = loader_mock
        self._config = None
        self._basedir = "."
        self._data = {}
        self._collection_paths = []
    loader_mock.__init__.side_effect = mock_init
    loader_mock.get_basedir.return_value = "."
    loader_mock.collection_list.return_value = {}

    # Test with a list of roles

# Generated at 2022-06-21 00:37:05.860653
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader

    play_context = PlayContext()
    play_context.CLIARGS = {'module_path': None, 'module_paths': None}
    play_context.basedir = "/Users/sjaroszynska/Documents/ansible-gitlab/test/integration/targets/module_utils/module_utils_path/missing"
    playbook = Play()
    playbook._attributes['_playbook_basedir'] = "/Users/sjaroszynska/Documents/ansible-gitlab/test/integration/targets"

# Generated at 2022-06-21 00:37:09.840953
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:37:25.100080
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    display = Display()
    display.display("Hello")
    display.display("World")
    #import pdb; pdb.set_trace()
    #display.display("World", color='red', stderr=True)
    display.display("World", color='red', log_only=True)
    #display.display("World", color='red', stderr=True)
    #display.display("World", color='red', log_only=True)
    #display.display("World", color='red', stderr=True)
    #display.display("World", color='red', log_only=True)
    #display.display("World", color='red', stderr=True)
    #display.display("World", color='red', log_only=True)
    #display.display("World", color='red',

# Generated at 2022-06-21 00:37:34.167834
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #
    # tests we are going to cover:
    #
    # 1. basic loading of a role
    # 2. loading a role with private vars
    # 3. loading a role with variables
    # 4. loading a role with a deprecation warning
    # 5. loading of an unqualified role name
    #

    # We need the following for the tests:
    # play object
    # variable manager object
    # loaders object
    #

    #
    # basic loading of a role
    #
    loader = DictDataLoader({})
    variable_manager = VariableManager()


# Generated at 2022-06-21 00:37:43.717726
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    module_utils_path = os.path.join(os.path.dirname(__file__), '..', '..', 'module_utils')
    sys.path.insert(0, module_utils_path)

    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.module_utils.facts.system.distribution import DistributionFactCollector

    facts_collector = DistributionFactCollector()
    facts_dict = facts_collector.collect(module_name='setup', module_args=dict(filter='*'))
    facts = ImmutableDict(facts_dict)
    hostvars = dict(myhost=dict(ansible_distribution=facts['ansible_distribution'], ansible_distribution_version=facts['ansible_distribution_version']))
    ds = dict

# Generated at 2022-06-21 00:37:53.549588
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.playbook.handler.task import Handler
    from ansible.plugins.loader import add_all_plugin_dirs, plugins
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    add_all_plugin_dirs()



# Generated at 2022-06-21 00:38:49.427316
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #we import here to prevent a circular dependency with imports
    from ansible.plugins.loader import action_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    # Calling load_list_of_roles through load_list_of_tasks like it was done, in practice
    all_vars = dict(
        foo='bar',
        baz='rab',
        bat='tab',
        ansible_forks=1,
    )


# Generated at 2022-06-21 00:39:01.585635
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
  from ansible.parsing.mod_args import ModuleArgsParser
  from ansible.vars import VariableManager
  from ansible.playbook.block import Block
  from ansible.playbook.play import Play
  from ansible.template import Templar
  from ansible.parsing import ds_loader, data_structures
  from ansible.errors import AnsibleParserError
  from ansible.utils.display import Display
  display = Display()
  variable_manager = VariableManager()
  # 1. load_list_of_blocks
  #    test load basic task
  data = data_structures.load_data('''
  - ping: {}
  ''')
  play = Play().load(data[0], variable_manager=variable_manager, loader=ds_loader)
  block_list = load_list_

# Generated at 2022-06-21 00:39:02.647954
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-21 00:39:13.700391
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        from ansible.plugins.loader import action_loader
    except (ImportError, AttributeError):
        # Until Ansible 2.8 action_loader is not a mandatory requirement
        return

    display = Display()
    variable_manager = VariableManager()
    loader = DataLoader()

    tasks = [
        dict(action=dict(module='shell', args='ls'), register='shell_out'),
        dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
    ]

    task_list = load_list_of_tasks(tasks, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)

    assert len(task_list) == 2
    assert task_list

# Generated at 2022-06-21 00:39:24.192716
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    fake_play = []
    fake_var_manager = []
    fake_loader = []

    # Test implicit block
    ds = [{'task': 'task'}]
    result = load_list_of_blocks(ds, fake_play, variable_manager=fake_var_manager, loader=fake_loader)
    assert len(result) == 1
    assert result[0].block is None

    # test implicit followed by block
    ds = [{'task': 'task'}, {'name': 'block_name'}]
    result = load_list_of_blocks(ds, fake_play, variable_manager=fake_var_manager, loader=fake_loader)
    assert len(result) == 2
    assert result[0].block is None
    assert result[1].block is not None

    # test two implicit

# Generated at 2022-06-21 00:39:33.228915
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    pb = Playbook.load([], DataLoader(), variable_manager=VariableManager())
    my_play = pb.get_plays()[0]
    my_block = Block(parent_block=my_play)

    test_load = load_list_of_tasks([{'include_tasks': 'a.yml'}, {'include_tasks': 'b.yml'}], my_play, my_block)
    assert len(test_load) == 2
    assert isinstance(test_load[0], TaskInclude)


# Generated at 2022-06-21 00:39:42.795629
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory

    pb_dir = './test/integration/playbooks/'
    loader, inventory, variable_manager = (Loader(), Inventory(loader=loader), VariableManager())

    roles_path = os.path.join(pb_dir, '../../../lib/ansible/playbook/roles')
    role_def = {'hosts': 'all', 'role': 'test', 'vars': dict(foo='bar')}
    role_def2 = {'hosts': 'all', 'role': 'test', 'vars': dict(foo='bar')}

# Generated at 2022-06-21 00:39:49.683897
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook
    import ansible.playbook.task
    import ansible.playbook.block
    import ansible.vars
    def load_list_of_blocks_mock_Block_load(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader):
        block_list = []
        for b in ds:
            block_list.append(b)
        return block_list

    class Ds(object):
        def __init__(self):
            self.ds = None
        def __getitem__(self, item):
            return self.ds
        def __len__(self):
            return 1

    old_Block_load = ansible.playbook.block.Block.load
    ansible.playbook.block.Block.load = load_

# Generated at 2022-06-21 00:39:55.290683
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play_name = 'Test Play'
    play_path = 'included_playbook.yml'
    play_ds = dict(
        name=play_name,
        connection='local',
        hosts='all',
        gather_facts='no',
    )
    play = Play.load(play_ds, variable_manager=variable_manager, loader=loader)
    role = Role()

# Generated at 2022-06-21 00:40:01.817646
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import tempfile
    from ansible.plugins.loader import action_loader

    from ansible.parsing.vault import get_vault_secrets
    from ansible.vars.manager import VariableManager

    # Change this to something that exists locally and is a valid role
    role_name = 'test_role'

    role_path = '%s/%s' % (os.path.dirname(__file__), role_name)

    task_path = '%s/tasks/main.yml' % role_path

    # Generate a random file name for the test vault secret
    test_vault_id = tempfile.mktemp()

    # Create the vault secret

# Generated at 2022-06-21 00:41:37.344228
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    We are testing the load_list_of_roles function in the playbook/__init__.py file
    '''
    fake_play = MagicMock()
    fake_play.roles = []

    # test when list
    fake_loader = MagicMock()
    fake_variable_manager = MagicMock()
    fake_ds = [
        {
            'role1': 'name',
            'role2': 'name'
        }
    ]
    fake_current_role_path = '/'
    ret = load_list_of_roles(fake_ds, fake_play, fake_current_role_path, fake_variable_manager, fake_loader)
    assert len(ret) == 2

    # test when empty list
    fake_ds = {}
    ret = load_list_of_ro

# Generated at 2022-06-21 00:41:46.610019
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    loader_mock = Mock()
    loader_mock.path_dwim_relative.return_value = 'relative_mock_path'
    loader_mock.path_dwim.return_value = 'dwim_mock_path'

    var_mgr_mock = Mock()

    play_mock = Mock()
    play_mock.roles = []

    valid_role_def = {'name': 'role_name', 'collection': 'collection_name.role_name'}

# Generated at 2022-06-21 00:41:54.745604
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{"name": "block1", "block": "^this is a regex with several lines", "rescue": [],"always": [],"ignore_errors": True, "when": "ansible_distribution==\"Debian\""}]
    play = []
    parent_block = None
    role = []
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    result = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert result[0].name == "block1"

# Generated at 2022-06-21 00:42:05.285950
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    #Note: For testing this method the loader.path_dwim method needs to be mocked.
    #Initialize the class objects required for loading
    collection_search_list=None
    variable_manager=None
    play= None
    current_role_path = None
    #Mock the loader class
    loader = MagicMock(spec=AnsibleCollectionConfig)
    #Mock the path_dwim method
    loader.path_dwim = MagicMock(return_value=None)
    #Initialize the datastructure to be passed in
    role_def = [ { 'name': 'test'} ]
    #Load the role

# Generated at 2022-06-21 00:42:15.449229
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.playbook.play import Play
