

# Generated at 2022-06-21 00:32:33.692874
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    result = load_list_of_tasks(["ds"], "play", "block", "role", "task_include", False, "variable_manager", "loader")
    assert(isinstance(result, list))


# Generated at 2022-06-21 00:32:41.083840
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play, Playbook
    from ansible.playbook.block import Block, BlockInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-21 00:32:54.849051
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.utils.vars import combine_vars

    loader = DictDataLoader({})

    # Create a new play for the test
    play = Play.load({
        'name': 'Ansible Play',
        'hosts': 'hosts',
        'tasks': [
            {'action': {'module': 'setup', 'args': ''}},
            {'action': {'module': 'debug', 'args': {'msg': "This is a test"}}},
        ]
    }, variable_manager=VariableManager(), loader=loader)

   

# Generated at 2022-06-21 00:33:08.696915
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    hosts = [
        'local',
    ]
    play = Play().load({
        'name': 'test',
        'hosts': hosts,
        'roles': [
            dict(role='myrole'),
            dict(role='myrole2'),
        ],
    }, variable_manager=VariableManager(), loader=None)
    assert len(play.roles) == 2
    assert play.roles[0].get_name() == 'myrole'
    assert play.roles[1].get_name() == 'myrole2'


# Generated at 2022-06-21 00:33:14.279507
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    class Play():
        def __init__(self):
            self.deps = []

    class VariableManager():
        def get_vars(self, play=None, task=None, host=None, task_vars=dict()):
            return dict()

    class Loader():
        def path_dwim(self, name):
            return '%s.yml' % name
    from ansible.collection import ansible_collections_paths

    collection_search_list = ansible_collections_paths(['/etc/ansible/collections', '/usr/share/ansible/collections'])


# Generated at 2022-06-21 00:33:27.306038
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.meta

    play = Play()
    play.hosts = ''
    play.become = None
    play.no_log = None
    play.vars = dict()
    play.name = None

    role_defs = [dict(name='test_role')]

    loader = DictDataLoader()
    variable_manager = VariableManager()
    roles = load_list_of_roles(role_defs, play, loader=loader, variable_manager=variable_manager)

    assert 1 == len(roles)
    assert isinstance(roles[0], ansible.playbook.role.meta.RoleInclude)
    assert 'test_role' == roles[0]._name


# Generated at 2022-06-21 00:33:35.299878
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks([]) == []
    assert load_list_of_blocks(None) == []
    assert load_list_of_blocks([{'task': 'do something'}]) == []
    assert load_list_of_blocks([{'task': 'do something'}, {'task': 'do something'}, {'task': 'do something'}]) == []



# Generated at 2022-06-21 00:33:43.072201
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({'name': 'test play', 'hosts': 'all'}, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-21 00:33:52.993587
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar

    # setup
    variable_manager = dict()
    loader = dict()

    # some valid tasks

# Generated at 2022-06-21 00:33:59.401152
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Success test
    ds = [
        {
            'name': "MyRole",
            'foo': 'bar'
        }
    ]
    play = Play()
    roles = load_list_of_roles(ds, play, collection_search_list=[])
    assert roles
    assert isinstance(roles, list)

    # Fail test
    ds = 'not a list of roles'
    try:
        load_list_of_roles(ds, play, collection_search_list=[])
    except AnsibleAssertionError:
        pass
    else:
        assert False, "Failed to raise an exception when passing in a string"



# Generated at 2022-06-21 00:34:49.285145
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: Add unit test
    pass

# Generated at 2022-06-21 00:34:51.003513
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: This unit test need to be implemented
    assert True == True


# Generated at 2022-06-21 00:35:01.992217
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # Test the function load_list_of_blocks
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.parsing.dataloader import DataLoader
    arguments = dict(
      a = dict(required=True, type='str'),
      b = dict(required=False, type='int'),
      c = dict(required=False, type='bool', default=False),
    )

# Generated at 2022-06-21 00:35:05.217720
# Unit test for function load_list_of_tasks

# Generated at 2022-06-21 00:35:14.205794
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Run unit tests for load_list_of_roles
    '''

    collection_dirs = [os.path.join(os.getcwd(), 'tests/collections/test_collection')]

    class Options(object):
        pass

    opt = Options()
    opt.roles_path = [os.path.join(os.getcwd(), 'test/test_roles')]
    opt.collections_path = collection_dirs
    opt.become = False

    display.verbosity = 3

    loader = DataLoader()
    variable_manager = VariableManager()

    from ansible.playbook import Playbook
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-21 00:35:25.993788
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    data = [{'action': {'module': 'debug', 'msg': 'hello world'}, 'name': 'task 1'}, {'action': {'module': 'debug', 'msg': 'hello world'}, 'name': 'task 2'}, {'name': 'task 3'}, {'action': {'module': 'debug', 'msg': 'hello world'}, 'name': 'task 4'}, {'name': 'task 5'}]
    result = load_list_of_blocks(data, Play().load({}))
    assert isinstance(result, list)
    assert len(result) == 3
    assert result[0]._name == 'task 1'

# Generated at 2022-06-21 00:35:34.735310
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    vars = {'foo': 'bar'}
    variable_manager = VariableManager()
    variable_manager.extra_vars = vars
    variable_manager.options_vars = vars
    variable_manager.set_inventory(Inventory('localhost'))

    role_def = {'name': '../test/data/roles/role1',
                'options': {'role1_option': 'role1_option_value'},
                'tags': 'role1_tag'}
    loader = DataLoader()
    play = Play().load({
        'name': 'test',
        'hosts': 'all',
        'roles': [role_def]
    }, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-21 00:35:36.831757
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: Write this test
    assert False


# Generated at 2022-06-21 00:35:45.167906
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition

    # create the play context and then the play
    context = PlayContext()
    context._prompt = None

# Generated at 2022-06-21 00:35:54.154889
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager

    # TODO: create a fake vars object

    ds_list = [
        {
            'name': 'do something',
            'debug': "msg={{myvar}}",
            'when': 'myvar is defined',
        },
        {
            'block': [
                {'name': 'do something else', 'debug': 'msg={{myvar2}}'}
            ]
        }
    ]

    ret = load_list_of_blocks(ds_list, Play(), variable_manager=VariableManager())
    assert len(ret) == 2


# Generated at 2022-06-21 00:36:12.093148
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.template import Templar

    # We do not have a test for this because this is a helper function
    # for loading a list of blocks
    assert False



# Generated at 2022-06-21 00:36:24.124727
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import become_loader, connection_loader, module_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)

    variable_manager.set_inventory(inventory)
    play_context = PlayContext(become_method='sudo', become_user='root')
    loader.set_basedir(C.DEFAULT_MODULE_PATH)

# Generated at 2022-06-21 00:36:35.094658
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["localhost", "127.0.0.1"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()
    play_context.variable_manager = variable_manager
    play1 = Play()
    role1 = RoleDefinition()
    role2 = RoleDefinition()
    role3 = RoleDefinition()
    role1.name = 'role1'
   

# Generated at 2022-06-21 00:36:44.206182
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible import constants as C
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.dataloader import DataLoader

    C.DEFAULT_ROLES_PATH = os.path.expanduser('~/.ansible/roles')
    loader = DataLoader()

    # NOTE: This should work with and without Block.is_block, but the test has to be fixed
    assert Block.is_block is not None, 'Block.is_block should be defined'

    assert load_list_of_blocks(None, None) == [], 'load_list_of_blocks() with None should return []'

# Generated at 2022-06-21 00:36:55.068686
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    #from ansible.plugins.loader import action_loader
    #from ansible.plugins.loader import module_loader
    #action_loader.add_directory(os.path.dirname(os.path.dirname(__file__)) + "/lib/ansible/plugins/action/")
    #module_loader.add_directory(os.path.dirname(os.path.dirname(__file__)) + "/lib/

# Generated at 2022-06-21 00:37:05.759979
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    def _get_loader(inventory, data=None):
        if data is None:
            data = dict()
        loader = DataLoader()
        inventory_manager = InventoryManager(loader=loader, sources=inventory)
        variable_manager = VariableManager(loader=loader, inventory=inventory_manager)
        play_context = PlayContext()
        play = Play().load(
            data,
            variable_manager=variable_manager,
            loader=loader
        )

        return inventory_manager, variable_manager, play, loader

    def _get_play(data):
        inventory = [os.path.join(os.path.dirname(__file__), '../../test/files/hosts')]
        inv, var

# Generated at 2022-06-21 00:37:13.873217
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # building the ds
    ds = [
        {'action': 'include', 'param': 'some_param'},
        {'action': 'some_action', 'param': 'some_param'},
        {'action': 'some_other_action', 'param': 'some_param'},
    ]
    task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(task_list, list)
    assert len(task_list) == 2 # One of them was discarded because wasn't in C._ACTION_ALL_INCLUDE_IMPORT_TASKS

    # building the ds

# Generated at 2022-06-21 00:37:25.120698
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    class fake_block:
        def __init__(self):
            self.block = Block()

        @staticmethod
        def is_block(b):
            return True
    b = fake_block()
    fake_play = ''
    fake_parent_block = ''
    fake_role = ''
    fake_task_include = ''
    fake_use_handlers = ''
    fake_variable_manager = ''
    fake_loader = ''

    ds = ''
    ret = load_list_of_blocks(ds, fake_play, fake_parent_block, fake_role, fake_task_include, fake_use_handlers, fake_variable_manager, fake_loader)
    assert ret is None, 'should be None'

    ds = 0

# Generated at 2022-06-21 00:37:34.166149
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # pylint: disable=unused-variable
    # import here to prevent circular import
    import ansible.playbook.play
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    from ansible.playbook.role import Role
    from ansible.playbook.preprocessors import get_default_options

    play_context = PlayContext()
    play_context.update_vars(
        loader=DictDataLoader({'vars': {'foo': 'bar'}}),
        basedir='/path/to/basedir',
        extra_vars={},
    )

    # This is what we are testing

# Generated at 2022-06-21 00:37:38.463935
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test function load_list_of_roles
    """

    # We can't test this function because it is used in a circular dependency.
    # It will be tested through the tasks module.
    pass

# Generated at 2022-06-21 00:38:11.748592
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.task_include import TaskInclude

    ds1 = dict(
        name='foo',
        action='debug',
        args=dict(msg='foo')
    )

    ds2 = dict(
        name='foo2',
        action='debug',
        args=dict(msg='foo2')
    )

    ds3 = dict(
        name='foo3',
        action='debug',
        args=dict(msg='foo3')
    )
    ds4 = dict(
        include='somefile'
    )
    block1 = Block()

    # Load

# Generated at 2022-06-21 00:38:17.950701
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        {'action': 'include',
         'args': {'_raw_params': '/tmp/test.yml'},
         'static': True},
    ]
    assert len(load_list_of_tasks(ds, None, None, None)) == 1

# Generated at 2022-06-21 00:38:29.743615
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    ds = [
        {'name': 'task1', 'action': 'shell', 'args': 'ls'},
        {'include': 'role1'}
    ]
    task_list = load_list_of_tasks(ds=ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(task_list) == 2
    assert isinstance(task_list[0], Task)
    assert isinstance(task_list[1], TaskInclude)



# Generated at 2022-06-21 00:38:42.356498
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # isinstance
    assert not isinstance(load_list_of_roles(), list)
    # empty list
    assert load_list_of_roles([], None, None, None, None, None) == []
    # role object
    role_def = []
    role_obj = RoleInclude()
    role_def.append(role_obj)
    assert load_list_of_roles(role_def, None, None, None, None, None) != []
    # should raise exception
    role_def = {}
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(role_def, None, None, None, None, None)
    # should return list
    role_def = []

# Generated at 2022-06-21 00:38:53.712977
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.executor.playbook_executor import PlaybookExecutor

    display = Display()
    loader = DataLoader()
    inventory = InventoryManager()
    variable_manager = VariableManager()
    play_context = PlayContext()


# Generated at 2022-06-21 00:38:59.811531
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import json
    ds = '''
- name: task1
  debug: msg="{{ template1 }}"

- name: task2
  debug: msg="{{ template2 }}"

- name: task3
  debug: msg="{{ template3 }}"

- name: task4
  debug: msg="{{ template4 }}"
'''.strip()
    ds = json.loads(json.dumps(ds))
    variablemanager = '''
{{ template1 }}
{{ template2 }}
{{ template3 }}
{{ template4 }}
'''.strip()
    variablemanager = json.loads(json.dumps(variablemanager))

# Generated at 2022-06-21 00:39:12.612770
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds_list=[
            {"name": "Get facts", "action": {"module": "setup"}},
            {"block": [{"name": "Do something", "action": {"module": "shell", "args": "echo hello"}}]},
            {"name": "Get other facts", "action": {"module": "setup"}},
            {"block": [{"name": "Do something else", "action": {"module": "shell", "args": "echo world"}}]}
        ]


    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play

# Generated at 2022-06-21 00:39:23.701908
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task


# Generated at 2022-06-21 00:39:32.981751
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest
    loader = DataLoader()

    # Test passing None
    # If a task/delegate_to/block is None, fail
    with pytest.raises(AssertionError) as ex:
        load_list_of_blocks(None, Play(), variable_manager=VariableManager(), loader=loader)
    assert 'should be a list or None but is' in str(ex)

    # Test passing list
    # If a task/delegate_to/block is not a list

# Generated at 2022-06-21 00:39:37.638880
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: This.
    import doctest
    # TODO: I see no way to make it work. Suggestions?
    # doctest.testmod(load_list_of_tasks)
    pass

# Generated at 2022-06-21 00:40:08.554269
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Check to make sure a task_include with a loop and static is not allowed
    with pytest.raises(AnsibleParserError):
        load_list_of_tasks(
            [{
                'block': [{'include_tasks': 'mytest.yml'}],
                'loop': '{{ my_list }}',
                'static': True
            }],
            None,
            block=None,
            role=None,
            use_handlers=False,
        )
    # Check to make sure the loop isn't an issue when static is not specified

# Generated at 2022-06-21 00:40:20.054859
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    test_playbook = """
    roles:
        - role1
        - role2
        - role3
        - role: role4
          tags: [foo, bar]
          become_user: testUser
          become_method: su
          connection: ssh
          vars:
            key1: value1
            key2: value2
        - role5
    """

    mocker = Mocker()
    fake_loader = mocker.mock()
    fake_variable_manager = mocker.mock()
    fake_play_context = mocker.mock()
    fake_play_context.become = False


# Generated at 2022-06-21 00:40:22.969508
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    There is no unit test for function load_list_of_roles().
    '''
    pass

# Generated at 2022-06-21 00:40:31.731727
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import become_loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1'])
    variable_manager.set_inventory(inventory)

    play_context = PlayContext()
    play_context.connection = 'local'
    play_context.become = become_loader.get('root')
    play_context.become_method = 'sudo'


# Generated at 2022-06-21 00:40:40.660498
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    play_context = PlayContext()
    play = Play().load({'name': 'foobar', 'hosts': 'somehost'}, variable_manager=VariableManager(), loader=DataLoader())
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play._set_loader(loader=loader)
    host = inventory.get_host('localhost')


# Generated at 2022-06-21 00:40:49.473734
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Ansible playbook unit test for function load_list_of_roles
    """
    fake_play = dict(name="test")
    role1 = dict(name="role1")
    role2 = dict(name="role2")
    fake_ds = [role1, role2]

    # Test for exception
    # In this test `ds` should be a list but set to integer for testing
    test_ds = 1
    try:
        load_list_of_roles(test_ds, fake_play)
        assert False
    except AnsibleAssertionError:
        pass

    # Test for success
    assert len(load_list_of_roles(fake_ds, fake_play)) == 2



# Generated at 2022-06-21 00:40:59.095012
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.template
    import ansible.vars.manager

    ds = [{'a': 'b', 'c': 'd'}, {'a': 'b', 'c': 'd'}]
    var_manager = ansible.vars.manager.VariableManager()
    loader = DataLoader()
    play_ds = ds
    play = ansible.playbook.Play()
    play._variable_manager = var_manager
    play._loader = loader
    tt = load_list_of_blocks(ds, play)
    assert len(tt) == 2
    assert isinstance(tt[0], ansible.playbook.block.Block)
    assert tt[0]._parent is None

# Generated at 2022-06-21 00:41:01.700311
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    print('TESTING load_list_of_blocks')
    print('TODO')



# Generated at 2022-06-21 00:41:09.775744
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.errors import AnsibleError
    from ansible.utils.path import unfrackpath

    DEFAULT_ROLES_PATH = [unfrackpath("/a/roles")]
    DEFAULT_ROLES_PATH_2 = [unfrackpath("/b/roles")]
    DEFAULT_TASKS_PATH = [unfrackpath("/a/playbook")]
    DEFAULT_TASKS_PATH_2 = [unfrackpath("/b/playbook")]
    DEFAULT_ROLES_PATHS = DEFAULT_ROLES_PATH + DEFAULT_ROLES_PATH

# Generated at 2022-06-21 00:41:18.722757
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task, TaskInclude

# Generated at 2022-06-21 00:41:47.291137
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])
    variable_manager.set_inventory(inventory)
    templates = 'templates'

    data = [
        {
            'role': 'role1',
            'static': 'yes'
        }
    ]


# Generated at 2022-06-21 00:41:55.966683
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    import ansible.parsing.dataloader
    ds = [{u'include': u'role1'}, {u'task': {u'name': u'mytask'}}, {u'task': {u'name': u'mytask2'}}, None, {u'task': {u'name': u'mytask3'}}]
    dataloader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.d

# Generated at 2022-06-21 00:42:05.516820
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    variable_manager = VariableManager()

    # Setup a test play

# Generated at 2022-06-21 00:42:15.549859
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  play = {
      "_raw_params": "{{ build_phase }}",
      "_ansible_no_log": False,
      "action": {
        "__ansible_module__": "setup",
        "__ansible_arguments__": {},
        "__ansible_positional_args__": [],
        "_uses_shell": False,
        "_raw_params": "",
        "_ansible_no_log": False,
        "module_args": {}
      }
    }

# Generated at 2022-06-21 00:42:24.804151
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    # Test case 1: Call with incorrect ds
    test_ds = "test"
    test_play = Play()
    test_block = None
    test_role = None
    test_task_include = None
    test_use_handler = False
    test_variable_manager = None
    test_loader = None
    try:
        expected_result = load_list_of_tasks(test_ds, test_play, test_block, test_role, test_task_include, test_use_handler, test_variable_manager, test_loader)
    except AnsibleAssertionError:
        assert 1 == 1
    # Test case 2: call with incorrect