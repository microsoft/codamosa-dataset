

# Generated at 2022-06-23 06:13:44.650287
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    This will test load list of roles
    '''
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role import Role


# Generated at 2022-06-23 06:13:56.554887
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def setup_call(collection_search_list=None, vars_manager=None, loader=None):
        if collection_search_list is None:
            collection_search_list = []
        if vars_manager is None:
            vars_manager = DummyVarsManager()
        if loader is None:
            loader = DummyLoader()
        ds = [{"role": "role1"}, {"role": "role2"}, {"path": "/path/to/role3"}, {"role": "role4"}]
        return load_list_of_roles(ds, play=None, current_role_path="/path/to/play",
                                  variable_manager=vars_manager, loader=loader,
                                  collection_search_list=collection_search_list)

    # If a role is not found in a collection, then it's

# Generated at 2022-06-23 06:14:07.244576
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars import VariableManager

    # create mock play
    mock_play = Play()

    # create loader
    mock_loader = AnsibleCollectionLoader(variable_manager=VariableManager())

    # create vars
    mock_vars = dict()

    # create collection_search_list
    mock_collection_search_list = list()

    # create list of roles with multiple roles
    mock_ds = [
        {'role': 'name-of-role'},
        {'role': 'name-of-role2', 'collection': 'collection_name'}
    ]

    mock_role_list = load_list_of_ro

# Generated at 2022-06-23 06:14:18.039426
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test valid list of tasks
    ds = [{'block': [{}]}, {'block': [{}]}, {'block': [{}]}]
    task_list = load_list_of_tasks(ds, None, None, None, None, None, None)
    assert len(task_list) == 3

    # Test when ds is not a list
    ds = {}
    try:
        load_list_of_tasks(ds, None, None, None, None, None, None)
        assert False
    except AnsibleAssertionError:
        assert True

    # Test when task_ds is not a dictionary
    ds = [1]

# Generated at 2022-06-23 06:14:29.508893
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_context = PlayContext()
    play_context.network_os = 'ios'

    # Test
    variable_manager.extra_vars = {
        'namespace': {
            'key': 'value'
        },
        'plain_key': 'value'
    }
    variable_manager._fact_cache = {
        'ansible_device_os': 'ios'
    }
    import copy

# Generated at 2022-06-23 06:14:30.639969
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass



# Generated at 2022-06-23 06:14:41.981346
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Unit test for function load_list_of_roles
    '''
    from ansible.playbook.role.include import RoleInclude
    from ansible.template import Templar

    variable_manager = VariableManager()

    loader = DataLoader()
    play = Play()
    role = RoleInclude.load({'role': 'webservers', 'name': 'web'}, play, ['common'], variable_manager=variable_manager,
                            loader=loader, current_role_path='/home/foo')
    templar = Templar(loader=loader, variables=variable_manager.get_vars(play=play, task=role))
    assert templar.template('{{web.role}}') == 'webservers'
    assert templar.template('{{web.name}}') == 'web'

# Generated at 2022-06-23 06:14:43.895806
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # FIXME: Add unit test
    pass



# Generated at 2022-06-23 06:14:49.740288
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' 
        https://github.com/ansible/ansible/issues/27684
        Reproduce the issue in Ansible 2.7.
    '''

    class MockPlay:
        def __init__(self):
            self.vars_files = None
            self.host_vars = None
            self.group_vars = None

    class MockLoader:
        def __init__(self):
            self.basedir = None
            self.path_exists = None
            self.determine_collection_role_path = None

        def get_basedir(self):
            return self.basedir

        def path_exists(self, path):
            return self.path_exists

        def determine_collection_role_path(self, role, collection_search_list):
            return self.determine

# Generated at 2022-06-23 06:15:01.355403
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task_include import TaskInclude
    
    loader = AnsibleCollectionLoader
    variable_manager = VariableManager()
    play = Play()

    ds = ['Tasks.test']
    current_role_path = None
    collection_search_list = []
    t = load_list_of_roles(ds, play, current_role_path=current_role_path, variable_manager=variable_manager, loader=loader, collection_search_list=collection_search_list)
    assert(t[0].role_name == 'Tasks')
    assert(t[0].task_include.module_name == 'test')


# Generated at 2022-06-23 06:15:12.473615
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    def get_blocks(ds):
        # No implicit block creation
        blocks = load_list_of_blocks(ds, {}, None, None, None, False, None, None)
        # all bare tasks should be created as implicit blocks
        i_blocks = load_list_of_blocks(ds, {}, None, None, None, True, None, None)
        return blocks, i_blocks

    # Block
    ds = [
        dict(
            name='a task in block',
            debug=dict(msg='This is a task inside a block')
        )
    ]
    expected = [Block(ds, None, None, None, None, False, None, None)]
    actual, i_actual = get_blocks(ds)
    assert expected == actual and expected == i_actual

# Generated at 2022-06-23 06:15:23.794010
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    fake_role_name = "test_role_name"
    play_context = PlayContext()
    fake_loader = DictDataLoader({})
    fake_var_manager = VariableManager()
    fake_var_manager.extra_vars = {"git_latest_version": "1.0.0"}

    ds = [{"role": fake_role_name}]
    roles = load_list_of_roles(ds, play=play_context, current_role_path="",
                               variable_manager=fake_var_manager, loader=fake_loader)
    assert len(roles) == 1
    for role in roles:
        assert role.name == fake_role_name

    # Test that a task marked as static is loaded correctly
    # This is the only case where the RoleInclude will automatically load the tasks
    fake

# Generated at 2022-06-23 06:15:26.921444
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles('','')
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles([1], '')

# Generated at 2022-06-23 06:15:41.277806
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook import Play
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.executor.playbook_executor import PlaybookExecutor

    VariableManager._fact_cache={}
    loader = DictDataLoader({})
    inventory = InventoryManager(loader=loader, sources=['/dev/null'])
    host = Host(name='testhost')
    group = Group(name='testgroup')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    parameterized_

# Generated at 2022-06-23 06:15:41.945517
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:15:52.808191
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Tests load_list_of_roles()
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError
    from ansible.plugins.loader import plugin_loader

    play_context = PlayContext()


# Generated at 2022-06-23 06:16:02.324778
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test the load_list_of_roles function by using a mock object
    :return:
    '''
    p = mock.MagicMock()
    v = mock.MagicMock()
    l = mock.MagicMock()
    ds = 'test'
    crp = 'test'
    collection_list = 'test'
    load_list_of_roles(ds, p, current_role_path=crp, variable_manager=v, loader=l, collection_search_list=collection_list)



# Generated at 2022-06-23 06:16:15.760375
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.module_utils._text import to_text
    import io
    import sys
    import pytest

    name = "test.test_load_list_of_blocks"
    fh = io.StringIO()
    display = Display(verbosity=0, stdout=fh, stderr=fh)
    play = Play()
    ds = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager

# Generated at 2022-06-23 06:16:27.729662
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    role_path = os.path.dirname(os.path.dirname(os.path.dirname(__file__)))
    loader = AnsibleLoader(
        play_source=dict(),
        variable_manager=VariableManager(),
        loader=DictDataLoader(),
    )

# Generated at 2022-06-23 06:16:37.962649
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DictDataLoader({
        'ansible_collections': {},
        'collections': {},
        'main.yml': """
        - include_role:
            name: foo
        - include_role:
            name: bar
            loop: True
        """
    })
    variable_manager = VariableManager()
    play = Play.load(
        dict(name='test'),
        loader=loader,
        variable_manager=variable_manager,
        use_handlers=True,
        use_task_includes=True
    )

    lor = load_list_of_roles(
        play.get_ds(),
        play,
        variable_manager=variable_manager,
        loader=loader)
    assert len(lor) == 2
    assert lor[0].name == 'foo'
   

# Generated at 2022-06-23 06:16:42.855154
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.parsing import DataLoader, Loader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    variable_manager = VariableManager()
    loader = DataLoader()
    play = Play.load(dict(), variable_manager=variable_manager, loader=loader)
    res = load_list_of_blocks(ds=dict(), play=play, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:16:53.543440
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    # Setup
    ds = [
        {
            'block': [
                {'task': {'foo': 'bar'}},
                {'task': {'foo': 'baz'}}
            ],
            'rescue': [
                {'task': {'foo': 'biz'}},
            ],
            'always': [
                {'task': {'foo': 'buz'}},
            ],
            'name': 'the block'
        }
    ]

# Generated at 2022-06-23 06:17:00.777499
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def assert_equal(a, b):
        if a != b:
            raise AssertionError('%s != %s' % (a, b))
    ds = [
        {'role': 'common'},
        {'role': {'name': 'webservers'}},
        {'role': {'name': 'dbservers'}},
    ]
    # mock out Play
    class MockPlay:
        pass
    play = MockPlay()
    play.roles = None
    play.roles_path = None
    play.role_path = None
    roles = load_list_of_roles(ds, play)
    assert_equal(len(roles), 3)
    for role in roles:
        assert_equal(role._role_name, role.get_name())



# Generated at 2022-06-23 06:17:10.135961
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude

    # Test case: multiple sequential task lists
    ds1 = [
        {'include': 'some_include'},
        {'action': 'some_action', 'args': 'some_args'}
    ]
    ds2 = [
        {'action': 'some_action2', 'args': 'some_args2'},
        {'action': 'some_action3', 'args': 'some_args3'},
    ]
    # Test case: multiple sequential list/task items

# Generated at 2022-06-23 06:17:10.873761
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
  pass



# Generated at 2022-06-23 06:17:18.093265
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader


# Generated at 2022-06-23 06:17:21.533279
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    module_scenario_utils.run_role_include_scenarios(load_list_of_roles)

# Generated at 2022-06-23 06:17:30.434504
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test load_list_of_tasks()
    '''
    task_ds_1 = dict(
        name="test_task_1",
        a=1, b=2, c=3,
    )
    task_ds_2 = dict(
        name="test_task_2",
        d=4, e=5, f=6
    )

    task_ds_list = [task_ds_1, task_ds_2]

    result = load_list_of_tasks(
        task_ds_list,
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )
    assert len(result) == 2
    assert result

# Generated at 2022-06-23 06:17:31.106784
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    raise NotImplementedError



# Generated at 2022-06-23 06:17:40.613215
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    unit test for load_list_of_tasks
    '''
    class MockVariableManager(object):
        def get_vars(self, play=None, task=None):
            return {}
    # Simplest test, empty list
    ds = []
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = MockVariableManager()
    loader = None
    ts = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert ts == []

    # Simple list of two tasks
    ds = [{'debug': {'msg': 'hello'}}, {'debug': {'msg': 'world'}}]
    ts = load_

# Generated at 2022-06-23 06:17:50.687076
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """ Test load_list_of_roles when only a string is passed in """
    play_ds = [{"hosts": "all"}, {"name": "test", "roles": "role1"}]
    ds_list = [{'role1': {}}]

    try:
        loader, inventory, variable_manager = CLICommonLoader(None, play_ds).load()
        play = Play().load(play_ds[1], loader=loader, variable_manager=variable_manager,
                           inventory=inventory)
        roles = load_list_of_roles(ds_list, play, variable_manager=variable_manager, loader=loader)
        assert len(roles) == 1
    except AnsibleError as err:
        pytest.fail(to_native(err))



# Generated at 2022-06-23 06:18:00.530770
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    task1 = {"name": "task1"}
    task2 = {"name": "task2"}
    task3 = {"name": "task3"}
    tasks = [task1, task2, task3]
    tasks_with_block = [task1, {"block": task2}, task3]
    display.verbosity = 0
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-23 06:18:10.568540
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    pm = PlayContext()
    loader = DataLoader()

# Generated at 2022-06-23 06:18:21.607046
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import Role
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import become_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    #################################################
    #
    #  1. Test with a list containing a single role
    #
    #################################################
    ds = [{
        'role': 'geerlingguy.java',
    }]

    play = Play()
    variable_manager = VariableManager()
    loader = DataLoader()

    roles = load_list_of_roles(ds=ds, play=play, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:18:29.364235
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from collections import namedtuple
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 06:18:32.118256
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:18:43.660193
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import json

    # Example json
    #
    # tasks:
    #   - include_role:
    #       name: httpd
    #       tasks_from: foo
    #   - include_role:
    #       name: httpd
    #   - include_role:
    #       name: http

# Generated at 2022-06-23 06:18:50.719134
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars

    from .mock.loader import DictDataLoader


# Generated at 2022-06-23 06:18:58.368318
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test that loading a list with role imports, role includes, and tasks
    # will load tasks and roles, but will ignore a role import that is not valid
    host_list = [
        dict(hostname='host1'),
        dict(hostname='host2'),
        dict(hostname='host3'),
    ]
    ds = [
        'include_role',
        'import_role',
        'task',
        'role',
    ]
    role_defs = [
        dict(name='include_role', role='role1'),
        dict(name='import_role', role='role2'),
        dict(name='role', role='role3'),
    ]

# Generated at 2022-06-23 06:19:09.849954
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # pylint: disable=redefined-outer-name
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    fake_loader = DictDataLoader({})

    test_template_str = '{{ test_var }}'
    test_template_result = 'test_var_result'

    test_var_manager = VariableManager()
    test_var_manager.set_nonpersistent_facts(dict(test_var=test_template_result))

    playbook_dir = 'test_playbook_dir'



# Generated at 2022-06-23 06:19:16.606624
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.plugins.loader as plugin_loader

    from ansible.playbook.play import Play
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    variable_manager.set_inventory(loader.load_inventory('localhost'))
    pb = Play()
    pb.load({
        'name': 'foo',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [{'shell': 'echo hi'}, {'debug': 'msg="yo"'}]
    }, variable_manager=variable_manager, loader=loader)

    assert len(pb.block_list) == 1
    assert len(pb.block_list[0].block)

# Generated at 2022-06-23 06:19:19.650311
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{
        'name': 'geerlingguy.drupal',
        'include_role': {
            'name': 'geerlingguy.firewall',
            'tasks_from': 'main'
        }
    },
        {
        'name': 'geerlingguy.mysql',
        'include_role': {
            'name': 'geerlingguy.php'
        }
    }]


# Generated at 2022-06-23 06:19:28.227761
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test for load_list_of_roles
    :return:
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.template import Templar

    # Create a dummy object of PlayContext
    p

# Generated at 2022-06-23 06:19:39.021696
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.errors import AnsibleParserError
    from ansible.playbook.role.include import RoleInclude
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock

    ds_list = [{"role": "myrole"}, {"role": "myrole2"}, {"include": "myinclude"}]
    try:
        load_list_of_roles(ds_list, None, collection_search_list=['test_collection'])
    except AnsibleParserError:
        pass
    else:
        assert False, "Incorrect role definitions should raise exception"
    role1 = Mock(spec_set=RoleInclude)
    role2 = Mock(spec_set=RoleInclude)
    role1.name = 'myrole'
    role2.name = 'myrole2'


# Generated at 2022-06-23 06:19:48.372915
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = ['first', 'second', {'block': 'value'}]
    block = load_list_of_blocks(ds, None)
    for b in block:
        if isinstance(b, dict):
            assert b['block'] == 'value'
        elif isinstance(b, string_types):
            assert b in ('first', 'second')
        else:
            raise Exception("Unknown type %s" % (type(b)))


# Generated at 2022-06-23 06:19:56.188336
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_data = [
        {
            'name': 'first task'
        },
        {
            'name': 'second task'
        },
        {
            'include_tasks': {
                'name': 'include the thing'
            }
        }
    ]
    task_list = load_list_of_tasks(task_data, play=None)
    assert len(task_list) == 3
    assert isinstance(task_list[0], Task)
    assert isinstance(task_list[1], Task)

# Generated at 2022-06-23 06:20:06.642559
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = []
    ds.append(dict(action='1'))
    ds.append(dict(action='2'))
    ds.append(dict(action='3'))
    ds.append(dict(action='4'))
    ds.append(dict(action='5'))
    
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    
    result = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-23 06:20:16.103200
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    ds = [
        {'role': 'some_role'},
        {'role': 'some_role2'},
        {'role': 'some_role3'},
    ]
    play = {
        'name': 'test_play'
    }
    current_role_path = 'test_path'
    variable_manager = {
        'test': 'test_var'
    }
    loader = {
        'test': 'test_loader'
    }
    collection_search_list = [
        'test_collection_1',
        'test_collection_2'
    ]

# Generated at 2022-06-23 06:20:24.538861
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    from ansible.playbook.block import Block
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task

    play = ansible.playbook.play.Play()
    loader = None
    variable_manager = None
    task_ds = {
        'include_role': dict(name='foo'),
        'block': dict(name='bar'),
        'tasks': [{'foo': 'bar'}],
    }
    ds = load_list_of_blocks(task_ds, play, None, None, None, None, variable_manager, loader)
    assert ds[0].name == 'bar'

# Generated at 2022-06-23 06:20:35.606431
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    block = Block.load(
        {'block': 'test_block', 'rescue': 'test_rescue', 'always': 'test_always', 'vars': {'test_var1': 'test_value1', 'test_var2': 'test_value2'}})

    task_ds = {'include_vars': 'test_include_vars'}
    task_include = TaskInclude.load(task_ds, block=block, loader=None, variable_manager=None)
    task_ds = {'name': 'test_task_name'}
    task_list = load_list_of_tasks([task_ds], block=block, task_include=task_include, variable_manager=None, loader=None)
    assert len(task_list) == 1
    assert task_list[0].block

# Generated at 2022-06-23 06:20:42.323301
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    list_of_tasks = [{'name':'apt',
                    'action':'include_role',
                    'args':{'name':'geerlingguy.apt', 'tasks_from':'main.yml'},
                    'register':'apt_result'}]
    data = load_list_of_roles(list_of_tasks,None,None,None,None,None)
    assert data[0].role_name == "geerlingguy.apt"

# Generated at 2022-06-23 06:20:53.792092
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from .mock.loader import DictDataLoader
    from .mock.collections import MockCollectionPath
    from .mock.vars import MockVariableManager
    from .mock.path import MockAnsiblePath

    test_data = dict(
        roles=[
            dict(name='myrole'),
            dict(name='myrole2'),
            dict(name='myrole3'),
        ],
    )

    mock_loader = DictDataLoader({})
    mock_collection_path = MockCollectionPath()
    mock_variable_manager = MockVariableManager()
    mock_ansible_path = MockAnsiblePath()

    roles = load_list_of_roles(test_data['roles'], mock_loader, None, mock_variable_manager, mock_collection_path, mock_ansible_path)


# Generated at 2022-06-23 06:21:03.363750
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Playbook
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.task import Task
    from tests.unit.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager


# Generated at 2022-06-23 06:21:14.553484
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    play_context.network_os = 'ios'
    play_context.become = True
    play_context.become_method = 'enable'
    play_context.become_user = 'someuser'

    variables = VariableManager()
    loader = DataLoader()

    hostvars = {
        'host1': {
            "network_os": "eos",
        }
    }

    variables.add_host_vars(hostvars=hostvars)


# Generated at 2022-06-23 06:21:25.487032
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole

    # create play context
    p_con = PlayContext()
    # create variable context with inventory
    v_con = VariableManager(loader=MockDataLoader())
    # create play

# Generated at 2022-06-23 06:21:35.553143
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    # The function load_list_of_blocks will load a list of blocks, with implicit blocks
    # in between.
    # Example:
    # A list of blocks with only one implicit block.
    # ds = [
    #        {
    #            "name": "Create a file"
    #            "apt": "name={{item}} state=present"
    #            "with_items": [ "foo", "bar", "baz" ]
    #        },
    #        {
    #            "name": "Create a file"
    #            "apt": "name={{item}} state=present"
    #            "with_items": [ "foo", "bar", "baz" ]
    #        },
    #     ]
    # Will be parsed as
    #

# Generated at 2022-06-23 06:21:45.738656
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def validate_block(block, task, block_name='block name', parent_block=None,
        use_handlers=False, unused=None):
        assert block.block  == task
        assert block.name   == block_name
        assert block.parent == parent_block
        assert block.use_handlers() == use_handlers
        assert block.unused  == unused

    task_name = {'name': 'task name'}
    block_one = None

    block_two = [task_name, 'block name']
    block_two_result = Block.load(block_two, play=None, parent_block=block_one,
        role=None, task_include=None, use_handlers=False, variable_manager=None,
        loader=None)

# Generated at 2022-06-23 06:21:57.477238
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        from ansible.playbook.play import Play
    except ImportError:
        print('skipping test while importing play')
        return

    try:
        from ansible.executor.task_queue_manager import TaskQueueManager
    except ImportError:
        print('skipping test while importing TaskQueueManager')
        return

    try:
        from ansible.vars.manager import VariableManager
    except ImportError:
        print('skipping test while importing VariableManager')
        return

    try:
        from ansible.inventory.manager import InventoryManager
    except ImportError:
        print('skipping test while importing inventory')
        return

    from ansible.parsing.dataloader import DataLoader

    from collections import namedtuple
    from ansible.playbook.block import Block


# Generated at 2022-06-23 06:21:59.538189
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # FIXME: we need a more comprehensive test here
    pass



# Generated at 2022-06-23 06:22:00.479872
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass


# Generated at 2022-06-23 06:22:11.157439
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play

# Generated at 2022-06-23 06:22:21.456831
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' test_load_list_of_roles.py '''
    import pytest
    from ansible.playbook.play import Play

    pytest.skip("Unskip when role_path_matching is implemented")
    ds = [
        {u'name': u'apa', u'role_path_matching': None},
    ]
    play = Play().load({
        u'name': u'just_roles',
        u'roles': ds
    }, variable_manager=None, loader=None)
    roles = load_list_of_roles(ds, play, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
    assert roles[0]._role_name == u'apa'
    assert roles[0].is_file is False


# Generated at 2022-06-23 06:22:24.492921
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: unit test for the function 'load_list_of_blocks'
    # mock all dependencies that the function has
    # create actual return values and test against them
    pass



# Generated at 2022-06-23 06:22:25.343741
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:22:36.751388
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # Setup for test
    # This requires a role file to load
    role_file = 'test_role_include.yml'
    role_path = './'
    role_vars = ['role_vars']

    my_args_str = 'name=test_role'
    my_args_dict = {'name':'test_role', 'role_vars':{'test_var':'test_val'}}

    # Slightly different than the function call signature
    # But needed to run the target function
    curr_role_path = './'
    play = None
    variable_manager = None
    loader = None
    collection_search_list = None

    # The role_def is a list (or maybe a list of lists)
    # of RoleInclude objects to be loaded and returned
    # We need to mock

# Generated at 2022-06-23 06:22:38.408559
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Test load_list_of_blocks function
    '''
    pass



# Generated at 2022-06-23 06:22:50.403196
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Test single block
    data = [
        {
            'block1': [
                {
                    'local_action': {
                        'module': 'shell',
                        'args': 'echo 123'
                    }
                }
            ]
        }
    ]
    play = None
    block_list = load_list_of_blocks(data, play)
    assert len(block_list) == 1
    assert isinstance(block_list[0], Block)

    # Test two blocks

# Generated at 2022-06-23 06:22:59.318829
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    block_list = load_list_of_blocks(None, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(block_list, list)
    assert len(block_list) == 0
    block_ds = {
        'name': 'test block',
        'block': 'lol',
    }
    block_list = load_list_of_blocks([block_ds], play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(block_list, list)
   

# Generated at 2022-06-23 06:23:08.462521
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible import context
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.template import Templar

    context._init_global_context(ImmutableDict())

# Generated at 2022-06-23 06:23:20.135734
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    import ansible.playbook
    import ansible.playbook.play
    import ansible.playbook.task
    import ansible.playbook.block


# Generated at 2022-06-23 06:23:32.124952
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook import Play
    from ansible.playbook.role import definition

    ds = [
        {'name': 'role1'},
        {'name': 'role2'},
        {'name': 'role3'},
    ]

    collection_search_list = ['collection1']

    roles = load_list_of_roles(ds, Play(), current_role_path=None, variable_manager=None, loader=None, collection_search_list=collection_search_list)
    assert len(roles) == 3
    assert isinstance(roles[0], definition.RoleInclude)
    assert roles[0]._role_name == 'role1'
    assert roles[0]._collection_name == 'collection1'

# Generated at 2022-06-23 06:23:35.822911
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    playbook_path = os.path.join(C.DEFAULT_MODULE_PATH, 'core', 'doc_files', 'playbook_blocks.yml')
    pb_data = open_playbook(playbook_path)
    print(pb_data)
