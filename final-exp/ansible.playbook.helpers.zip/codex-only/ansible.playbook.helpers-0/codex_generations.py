

# Generated at 2022-06-23 06:13:44.441656
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  import ansible.playbook.task
  import ansible.playbook.block
  import ansible.playbook.play
  import ansible.playbook.helpers
  import ansible.playbook.role
  import ansible.playbook.role_include
  import ansible.playbook.task_include
  import ansible.playbook.handler_task_include
  play = ansible.playbook.play.Play()
  role = ansible.playbook.role.Role()
  task = ansible.playbook.task.Task()
  block = ansible.playbook.block.Block()
  loader = ansible.playbook.helpers.ModuleLoader()
  fake_var = {}
  AnsibleVars = {}

# Generated at 2022-06-23 06:13:56.346901
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.include
    class test_RoleInclude(ansible.playbook.role.include.RoleInclude):
        def __init__(self):
            super(test_RoleInclude, self).__init__(
                role_name="test",
                role_path=None,
                task_include=None,
                role_params=None,
            )
    class test_loader(object):
        def __init__(self, name):
            self.name = name
        def path_dwim(self, path):
            return path
        def path_dwim_relative(self, basedir, path, target):
            return path

    class test_variable_manager(object):
        pass

    class test_Play(object):
        def __init__(self):
            self.role

# Generated at 2022-06-23 06:14:07.104218
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.parsing.yaml.dumper import AnsibleDumper


# Generated at 2022-06-23 06:14:17.806796
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import plugin_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    # We use the connection plugin here because it is a base class
    # and doesn't depend on any other plugins and therefore we can
    # safely skip loading those into the plugin loader.
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../plugins'))
    display.verbosity = 3
    play_context = PlayContext()
    my_inventory = InventoryManager()
    variable_manager = VariableManager(loader=None, inventory=my_inventory)
    play_context.accelerate = False

# Generated at 2022-06-23 06:14:29.474280
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.module_utils.six import PY3
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.clean import module_response_deepcopy

    class Empty(object):
        pass

    class MyDict(dict):
        def __init__(self, **kwargs):
            self.__dict__ = self
            super(MyDict, self).__init__(**kwargs)

        def copy(self):
            return MyDict(**self)

    class MyList(list):
        def __init__(self, data=None, **kwargs):
            self.__dict__ = self

# Generated at 2022-06-23 06:14:34.603988
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Load a list of tasks using the load_list_of_tasks function
    This is a basic unit test for the functions involved in loading list of tasks
    '''

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole

    ds1 = {'name': 'task1', 'action': 'ping'}
    ds2 = {'name': 'task2', 'action': 'debug'}
    ds3 = {'name': 'task3', 'action': 'debug', 'block': 'testblock'}

# Generated at 2022-06-23 06:14:40.034868
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test to verify that a list of roles can be loaded correctly.
    """
    ds_list = [
        {
            "role1": {},
            "role2": {}
        },
        {
            "role3": {},
            "role4": {}
        }
    ]
    roles = load_list_of_roles(ds, None)
    assert len(roles) == 4



# Generated at 2022-06-23 06:14:41.677983
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
  # Test that nothing breaks for empty lists
  load_list_of_blocks(None,None,None,None)


# Generated at 2022-06-23 06:14:53.293572
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins import module_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    # 构造inventory，可以是个字典也可以是 InventoryManager
    # 注意这里必须带上host变量，否则Task中变量替换不会生效

# Generated at 2022-06-23 06:14:56.136336
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks([]) == []
    assert load_list_of_blocks(None) == []
    with pytest.raises(AnsibleAssertionError):
        load_list_of_blocks('')



# Generated at 2022-06-23 06:15:06.204214
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Fixture
    action = 'action'
    args = { 'arg1' : 'value1', 'arg2' : { 'subarg1' : 'subvalue1', 'subarg2' : 'subvalue2' }}
    delegate_to = 'delegate to value'
    blocks = [ { 'block1' : 'value1'}, { 'task1' : { 'action' : action, 'args' : args, 'delegate_to' : delegate_to  } } ]
    # Exercise
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    play_context = PlayContext()
    loader = DataLoader()
    variable_manager = Variable

# Generated at 2022-06-23 06:15:14.989674
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible import context
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    class FakeCallbacks:
        def __init__(self):
            self.cb = {}
            for cb in context.CLIARGS['callback'].split(','):
                # a shortcut for setting up callbacks
                self.cb[cb] = getattr(self, cb)
            self.stats = {}

        def v2_runner_on_ok(self, result, **kwargs):
            host = result._host.get_name()
            self.stats[host] = kwargs


# Generated at 2022-06-23 06:15:25.611740
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.dataloader import DataLoader as AnsibleDataloader

    context = PlayContext()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=AnsibleDataloader()))
    loader = AnsibleDataloader()
    my_play = dict(
        name="Testing",
        hosts=['localhost'],
        gather_facts='no',
        roles=list(),
    )

# Generated at 2022-06-23 06:15:33.620155
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:15:45.558900
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])
    play_context = PlayContext()

    play = Play().load({
        'name': 'Ansible Play 1',
        'hosts': 'localhost',
        'gather_facts': 'no',
    },
        variable_manager=variable_manager,
        loader=loader,
    )

    task_ds = []

# Generated at 2022-06-23 06:15:56.337018
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # We use a fake loader and variable manager here
    loader = FakeLoader()
    # The variable manager contains a dictionary with all variables
    # used to get their values when they are used in a template.
    variable_manager = VariableManager()

    roles = load_list_of_roles([{"role": "awesome_role"},
                                 {"role": "another", "tags": ["thisone", "orthisone"]}],
                                play=None, current_role_path=None,
                                variable_manager=variable_manager,
                                loader=loader)
    assert isinstance(roles, list)
    assert len(roles) == 2
    assert roles[0].name == "awesome_role"
    assert roles[1].name == "another"
    assert roles[1].tags == ["thisone", "orthisone"]

# Generated at 2022-06-23 06:16:06.691854
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.plugins.loader as plugin_loader
    from ansible.playbook.play import Play

    sample_play_name = 'test_play'
    sample_play_passwords = {'some_pass': 'some_pass_val', 'some_other_pass': 'some_other_pass_val'}
    sample_play_role_paths = {}

    plugin_loader.add_directory('./lib/ansible/modules')

# Generated at 2022-06-23 06:16:15.945115
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks([]) == []
    assert load_list_of_blocks(None) == []

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    ds = [
        dict(
            action=dict(
                module='debug',
                args=dict(msg='this is a task')
            )
        ),
        dict(
            tasks= [
                dict(
                   action=dict(
                       module='debug',
                       args=dict(msg='this is a sub task')
                   )
                )
            ]
        ),
        dict(
            action=dict(
                module='debug',
                args=dict(msg='this is another task')
            )
        ),
    ]

# Generated at 2022-06-23 06:16:27.874904
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole


# Generated at 2022-06-23 06:16:38.029326
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.block
    import ansible.playbook.role_include
    import ansible.playbook.task_include
    import ansible.playbook.task
    import ansible.vars.manager
    import ansible.template
    import ansible.utils
    import ansible.inventory
    import ansible.constants
    import ansible.plugins.loader
    import ansible.parsing.yaml.objects
    import ansible.playbook.play
    import ansible.playbook.role

    try:
        import yaml
    except ImportError:
        from ansible.module_utils.six.moves import _import_module
        yaml = _import_module("yaml")


    # We need to use the same objects as the main code
    # so that the main code's test would not

# Generated at 2022-06-23 06:16:43.964433
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import collection_loader
    from ansible.parsing.dataloader import DataLoader

    ds = [
         {'role': 'b'},
         {'role': 'c'},
         {'role': 'd'}
        ]
    loader = DataLoader()
    play = Play().load({}, loader=loader, variable_manager=VariableManager())

    # Test without "current_role_path"
    roles = load_list_of_roles(ds, play, None, None, loader, collection_loader.all_collections)
    assert isinstance(roles[0], RoleInclude) == True
    assert roles[0]._role_name == 'b'

# Generated at 2022-06-23 06:16:54.084355
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    get_res('ansible-playbook', 'compare_strings_task.yml', 'playbook', 'compare_strings.yml')
    get_res('ansible-playbook', 'logic_conditions_task.yml', 'playbook', 'logic_conditions.yml')
    get_res('ansible-playbook', 'error_handling_task.yml', 'playbook', 'error_handling.yml')
    get_res('ansible-playbook', 'block_task.yml', 'playbook', 'block.yml')
    get_res('ansible-playbook', 'loop_task.yml', 'playbook', 'loop.yml')



# Generated at 2022-06-23 06:17:01.003347
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test that calling load_list_of_roles with a non-list ds raises an assertion error
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles('some string', None)

    # Test that calling load_list_of_roles with an empty list returns an empty list
    assert load_list_of_roles([], None) == []

    # Test that calling load_list_of_roles with a list of role definitions
    # returns a list of RoleInclude objects
    ds = [{'role': 'some_role_name'}]
    assert type(load_list_of_roles(ds, None)[0]).__name__ == 'RoleInclude'



# Generated at 2022-06-23 06:17:07.610779
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    block = [{"name": "foo", "bar": "baz"}]
    ansible_module_path = os.path.join(os.getcwd(), 'lib/ansible/modules/extras/')
    collections_paths = [os.path.join(os.getcwd(), 'lib/ansible/collections/*'), '~/.ansible/collections/*']

    MockModule = collections.namedtuple('MockModule', ['ANSIBLE_MODULE_ARGS', 'ansible_module_args',
                                                       'ANSIBLE_MODULE_UTILS', 'ANSIBLE_COLLECTIONS_PATHS'])
    mock_module = MockModule({"_ansible_verbosity": 4}, {"foo": "bar"}, "lib/ansible/module_utils",
                             collections_paths)

    play = Play

# Generated at 2022-06-23 06:17:19.338287
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.parsing.dataloader import DataLoader

    class Options(object):
        def __init__(self, verbosity):
            self.module_path = './lib'
            self.verbosity = verbosity
            self.connection = 'local'
            self.forks = 10
            self.check = False
            self.inventory = Inventory(loader)
            self.diff = False
            self.timeout = 10


# Generated at 2022-06-23 06:17:29.080501
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    # test_list_of_roles_valid
    def _valid(ds):
        ds = load_list_of_roles(ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
        assert ds

    # test_list_of_roles_invalid
    def _invalid(ds, assert_exception=None):
        try:
            ds = load_list_of_roles(ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
        except AnsibleParserError as e:
            assert e.message == assert_exception
        else:
            raise AssertionError('AnsibleParserError was not raised')


    # test_

# Generated at 2022-06-23 06:17:35.053445
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.unsafe_proxy import wrap_var, UnsafeProxy

    def _get_host_vars(host):
        hostvars = HostVars(loader=None, variable_manager=None, hostname=host)
        hostvars.vars['a'] = wrap_var(UnsafeProxy(dict(b=dict(c=1))))
        hostvars.vars['d'] = 2
       

# Generated at 2022-06-23 06:17:40.540267
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    pass

# Generated at 2022-06-23 06:17:50.661769
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    list_of_tasks = [
        {'include': '{{ var }}'},
        {'include_role': 'role1'},
        {'include_tasks': 'some.yaml'},
        {'import_playbook': 'some.yaml'},
        {'include_vars': 'some.yaml'},
        {'block': [{'include': 'other.yaml'}]}
    ]

    # Load it
    task_list = load_list_of_tasks(
        list_of_tasks,
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None,
    )

    # Here we have 6 tasks and 1 block.
   

# Generated at 2022-06-23 06:17:52.026756
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    print('Test function load_list_of_roles')
    assert True


# Generated at 2022-06-23 06:17:53.098012
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, 'Not implemented'


# Generated at 2022-06-23 06:18:03.197015
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    roles_list = [
        {'name': 'test'},
        {'name': 'test2', 'collections': ['test.col']},
        {'name': 'test3', 'collections': {'foo': 'test.col'}}
    ]
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles('test.col', None)
    assert len(load_list_of_roles([], None)) == 0
    assert len(load_list_of_roles(roles_list, None)) == 3

# Generated at 2022-06-23 06:18:15.494013
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test case for load_list_of_roles.
    '''
    # We need to stub out the objects we don't want to instantiate to test this function
    class StubbedRoleInclude:
        pass

    class StubbedPlay:
        pass

    class StubbedVariableManager:
        pass

    class StubbedLoader:
        pass

    # The actual test case
    ds = [{'name': 'test_role'}]
    play = StubbedPlay()
    current_role_path = None
    variable_manager = StubbedVariableManager()
    loader = StubbedLoader()
    collection_search_list = None

    # Mock the load method so we don't have to instantiate a RoleInclude class

# Generated at 2022-06-23 06:18:24.871144
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    my_block = Block(
        parent_block=None,
        block=dict(
            tasks=load_list_of_blocks([
                dict(
                    action=dict(
                        module='test',
                        args=dict(arg1='one', arg2='two')
                    ),
                    name='Test task 1',
                ),
                dict(
                    action=dict(
                        module='test2',
                        args=dict(arg1='one', arg2='two')
                    ),
                    name='Test task 2',
                ),
            ])
        )
    )

    assert isinstance(my_block.block, dict)

# Generated at 2022-06-23 06:18:37.486296
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from units.mock.loader import DictDataLoader
    from ansible.utils.vars import combine_vars
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleSequence

    fake_loader = DictDataLoader({})
    variable_manager = VariableManager()

    variable_manager.set_variable_limit(False)
    variable_manager.extra_vars = combine_vars(loader=fake_loader, variables=dict(
        var1="value1"
    ))

    play_ds

# Generated at 2022-06-23 06:18:42.819601
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    assert load_list_of_blocks([{'block':[{'task':{}}]},{'task':{}},{'task':{}}]) == [
        Block.load(
            {'block':[{'task':{}}]},
        ),
        Block.load(
            {'task':{}},
        ),
        Block.load(
            {'task':{}},
        )
    ]

# Generated at 2022-06-23 06:18:50.149521
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    sample_ansible_env_var = os.environ['ANSIBLE_CONFIG']
    sample_roles_path = constants.DEFAULT_ROLES_PATH
    C = ConfigLoader(None)
    C.load()
    assert load_list_of_roles([], 'play')
    assert load_list_of_roles([], 'play', current_role_path=sample_roles_path)
    assert load_list_of_roles([], 'play', current_role_path=sample_roles_path, collection_search_list=[])
    assert load_list_of_roles([], 'play', current_role_path=sample_roles_path, collection_search_list=sample.collection_search_list())

# Generated at 2022-06-23 06:18:52.685304
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ###########################################################################
    # TODO: Need to implement test_load_list_of_tasks
    ###########################################################################
    pass



# Generated at 2022-06-23 06:19:04.458702
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [
        {
            'name': 'test-role-1',
            'tasks': [
                'test.yml'
            ]
        },
        {
            'name': 'test-role-2',
            'tasks': [
                'test.yml'
            ]
        }
    ]

    roles = load_list_of_roles(ds, current_role_path='/some/path')
    assert len(roles) == 2

    assert roles[0].name == 'test-role-1'
    assert roles[0].current_role_path == '/some/path'
    assert len(roles[0].tasks) == 1

    assert roles[1].name == 'test-role-2'
    assert roles[1].current_role_path == '/some/path'

# Generated at 2022-06-23 06:19:16.996151
# Unit test for function load_list_of_roles
def test_load_list_of_roles():  # pylint: disable=unused-variable
    """
    Unit test for function load_list_of_roles
    """

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition

    from units.mock.loader import DictDataLoader

    ################################################################################
    # Setup the test (load test data to a dict)
    test_data = {}
    test_data['test_task_include_1'] = {u'include_tasks': [u'roles/test_role1.yml']}
    test_data['test_task_include_2'] = {u'include_tasks': [u'roles/test_role2.yml']}

# Generated at 2022-06-23 06:19:24.950357
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = {}
    block = {}
    role = {}
    task_include = {}
    use_handlers = False
    variable_manager = {}
    loader = {}

    data = [
        {
            'block': {
                'block': [
                    {
                        'shell': 'echo',
                        'name': 'echo'
                    }
                ]
            },
            'hosts': 'localhost'
        },
        {
            'include': 'echo'
        }
    ]

    task_list = load_list_of_tasks(data, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert len(task_list) == 2, task_list

# Generated at 2022-06-23 06:19:25.523827
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:19:27.164245
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, "TODO: Write tests for load_list_of_blocks"


# Generated at 2022-06-23 06:19:38.963085
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # Setup
    try:
        from ansible.playbook import Play
        from ansible.playbook.domain import Domain
        from ansible.playbook.block import Block
        from ansible.playbook.handler import Handler
        from ansible.playbook.task import Task
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.play_context import PlayContext
        from ansible.playbook.play import Play
    except ImportError:
        from ansible.playbook import Play
        from ansible.playbook.block import Block
        from ansible.playbook.handler import Handler
        from ansible.playbook.task import Task
        from ansible.playbook.task_include import TaskInclude
        from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 06:19:52.175432
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    load_list_of_roles([], None)
    load_list_of_roles(None, None)

    class FakeRoleInclude(object):
        @classmethod
        def load(cls, ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_list=None):
            return 'FakeRoleInclude'

    with patch.object(RoleInclude, 'load', FakeRoleInclude.load):
        class FakePlay(object):
            def __init__(self):
                self.host_vars = {}
                self.groups = {}
                self.FILES_CACHE = {}
                self.variable_manager = None
                self.basedir = ''

        class FakeVarMgr(object):
            def __init__(self):
                self.extra

# Generated at 2022-06-23 06:20:02.069413
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ## Load fixture data
    ds = yaml.load(open(
        './test/unit/parsing/fixtures/load_list_of_blocks.yml', 'r'
    ).read())

    ## Load test object
    from ansible.parsing.mod_args import ModuleArgsParser
    mod = ModuleArgsParser()

    ## Create test object
    test_obj = dict(
        ds=ds,
        play=mod,
        role=mod,
        task_include=mod,
        use_handlers=False,
        variable_manager=mod,
        loader=mod
    )

    ## Test
    assert isinstance(load_list_of_blocks(**test_obj), list)



# Generated at 2022-06-23 06:20:02.785990
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:20:12.057948
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    pl = Play()
    ds = [{'role': 'apb.mongodb', 'name': 'abc.abc'}]
    roles = load_list_of_roles(ds, pl,  current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
    assert roles[0].name == 'apb.mongodb'
    assert roles[0]._role_name == 'apb.mongodb'
    assert roles[0]._role_path == 'apb.mongodb/tasks'
    assert roles[0]._role_

# Generated at 2022-06-23 06:20:14.240699
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    None

# Generated at 2022-06-23 06:20:23.426854
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [{'include_tasks': 'tasks/main.yml'}, 'debug: msg={{ val }}']
    class p:
        def __init__(self):
            self.basedir = "/home/user/.ansible"
    class r:
        def __init__(self):
            self.name = "test_role"
    class l:
        def __init__(self):
            self.path_dwim_relative = lambda path, dir, file: "/home/user/.ansible/tasks/main.yml"
            self.path_dwim = lambda path: path
            self.load_from_file = lambda file: file
    class v:
        def __init__(self):
            self.extra_vars = {}

# Generated at 2022-06-23 06:20:34.758236
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import sys
    import os
    import ansible
    print('Testing Ansible module parsing')
    sys.path.insert(0, os.path.join(os.path.dirname(ansible.__file__), 'utils'))
    from test.test_module_parser import load_fixture_and_parse


# Generated at 2022-06-23 06:20:45.200670
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    bad_arguments_type = ['', 'abc', '123', 123, 123.0, True, None]
    bad_arguments_type_not_list = ['abc', '123', 123, 123.0, True, None]
    bad_arguments_type_not_task = ['', 'abc', '123', 123, 123.0, True, None]

    for value in bad_arguments_type:
        try:
            load_list_of_blocks(value)
        except AnsibleAssertionError:
            pass
        else:
            assert False, 'list or None should be provided, but {} is provided'.format(value)

    for value in bad_arguments_type_not_list:
        try:
            load_list_of_blocks(value)
        except AnsibleAssertionError:
            pass


# Generated at 2022-06-23 06:20:57.015372
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader
    import os

    try:
        os.getcwd()
    except OSError:
        os.mkdir('/tmp')
        os.chdir('/tmp')

    loader = DataLoader()
    loader = DictDataLoader({
        "/etc/ansible/hosts": """
        localhost
        """,
    })
    inventory = InventoryManager(loader, sources=["/etc/ansible/hosts"])

# Generated at 2022-06-23 06:21:05.978268
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role_include import IncludeRole
    from ansible.plugins.loader import PluginLoader

    # create a plugin loader with a dummy service
    plugin_loader = PluginLoader(
        'ansible.plugins.loader',
        'DummyModuleLoader',
        'DummyModuleLoader',
        'DummyModuleLoader',
        'DummyModuleLoader',
        'DummyModuleLoader',
    )
    plugin_loaders = get_all_plugin_loaders()
    plugin_loaders.append(plugin_loader)

    # create a mock play object

# Generated at 2022-06-23 06:21:06.584473
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:21:18.859848
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
        Test if load_list_of_roles loads roles correctly
    """
    from ansible.playbook.role.include import RoleInclude
    ds = [{
        "role": "test",
        "when": "test_condition"
    },
    {
        "role": "test2",
        "when": "test_condition2"
    }]
    current_role_path = "role_base_path"
    roles = load_list_of_roles(ds, current_role_path)
    assert len(roles) == 2
    for i, role in enumerate(roles):
        assert isinstance(role, RoleInclude)
        assert role.role == ds[i]['role']
        assert role.when == ds[i]['when']
        assert role._role_

# Generated at 2022-06-23 06:21:19.482219
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:21:28.456688
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #FIXME true unit test
    from ansible.playbook.role.include import RoleInclude

    result = load_list_of_roles(
        [dict(name='foo'),
         dict(name='bar', tasks_from='baz'),
         dict(name='bam', tasks_from='boo'),
         dict(name='bar', tasks_from='foo')],
        play=None,
        variable_manager=None,
        loader=None,
    )

# Generated at 2022-06-23 06:21:40.276677
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # test_load_list_of_blocks_one_task
    tasks = [{"debug": "text"}]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    assert(len(load_list_of_blocks(tasks, play, parent_block, role, task_include, use_handlers, variable_manager, loader)) == 1)
    # test_load_list_of_blocks_two_tasks
    tasks = [{"debug": "text"}, {"debug": "text2"}]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

# Generated at 2022-06-23 06:21:51.946632
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    p = Play().load({
        'name': 'test play',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'debug': {'msg': 'task1'}},
            {'block': [
                {'debug': {'msg': 'task2'}},
                {'debug': {'msg': 'task3'}},
            ]},
        ]
    })
    b = load_list_of_blocks(p._entries, play=p, loader=DataLoader(), variable_manager=VariableManager())

# Generated at 2022-06-23 06:22:01.411551
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    import ansible.playbook.task_include
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    play_context = PlayContext()
    variable_manager = VariableManager()

    ds = []
    play = Play()
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = variable_manager
    loader = None
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)


# Generated at 2022-06-23 06:22:03.064221
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    load_list_of_tasks()

# Generated at 2022-06-23 06:22:08.196423
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Play
    import ansible.constants as C
    pass



# Generated at 2022-06-23 06:22:17.770513
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    display.verbosity = 3
    # FIXME: This unit test needs to be completed.
    # (any volunteers?)
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader

    yaml_data = """
    - hosts: all
      gather_facts: no
      tasks:
         - name: test1
           action: ping
           register: a

         - block:
             - name: test2
               action: ping

           rescue:
             - name: test3
               action: ping

           always:
             - name: test4
               action: ping
    """

    # create an empty play
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager,  host_list=[])
    variable_manager

# Generated at 2022-06-23 06:22:27.093892
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager
    import ansible.constants as C

    # needed for the module to work
    module_loader.add_directory(C.DEFAULT_MODULE_PATH)

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(host_list=['dummy']))

    context = PlayContext()


# Generated at 2022-06-23 06:22:38.362039
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.parsing.utils.addresses import parse_address
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import run_filters
    from ansible.vars.loader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.data import InventoryData
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-23 06:22:44.148745
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import IncludeRole

# Generated at 2022-06-23 06:22:46.112587
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role import Role

    # TODO: Write a test for this function
    pass



# Generated at 2022-06-23 06:22:55.871957
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins import module_loader
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    # Mocking some objects here because it seems very difficult to avoid
    # them in this case.
    class Host(object):
        def __init__(self, name):
            self.name = name
            self.vars = dict()

    class Inventory(object):
        def __init__(self, hosts):
            self.hosts = hosts


# Generated at 2022-06-23 06:23:06.939564
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # create a mock play
    play = Play()
    play._attributes['name'] = "fake_play"

    # create a mock role
    role = Role()
    role._attributes['name'] = "fake_role"

    loader = DataLoader()
    # create a mock collection
    collection = Collection()
    collection._cache = dict()
    collection.load(loader=loader, path="my/fake/collection")

    inventory = Inventory(loader=loader, host_list=[])

    vm = VariableManager(loader=loader, inventory=inventory)  # , version_info=version_info)

    # create a list of roles to load

# Generated at 2022-06-23 06:23:19.096604
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude

    # arrange
    ds_json = '[{"role": "foo"}]'
    ds = json.loads(ds_json)
    play = Play()
    variables = HostVarsVars()
    variable_manager = VariableManager(loader=None, variables=variables)
    loader = DataLoader()
    collection_search_list = []

    # act
    actual = load_list_of_roles(ds, play, None, variable_manager, loader, collection_search_list)

    # assert
    m_ds = mock.MagicMock()
    m_play = mock.MagicMock()
    m_current_role_path = mock.MagicMock()
    m_variable_manager =  mock

# Generated at 2022-06-23 06:23:26.761987
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    module_include_yaml = """
- include_tasks: test_static.yml
- name: include test_variable.yml
  include_tasks: test_variable.yml
- name: include test_block.yml
  include_tasks: test_block.yml
- name: include test_block_variable.yml
  include_tasks: test_block_variable.yml
- name: include test_include.yml
  include_tasks: test_include.yml
- name: include test_block_include.yml
  include_tasks: test_block_include.yml
  """

# Generated at 2022-06-23 06:23:38.246334
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.utils.display import Display
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import discover_entry_points

    display = Display()
    loader = DataLoader()
    inventory = InventoryManager('localhost', display)
    var_mgr = VariableManager(loader=loader, inventory=inventory)