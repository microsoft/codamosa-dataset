

# Generated at 2022-06-23 06:13:44.612952
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory())

    my_list = [['role_name', {'foo': 'bar'}],
               ['role1', {'baz': 'qux'}],
               ['role2', {'xyz': 'abc'}],
               ]

    roles = load_list_of_roles(my_list, Play(), variable_manager=variable_manager, loader=loader)

    assert len(roles) == len(my_list), "number of roles mismatch"
    for i in range(len(roles)):
        # Check the role arguments
        assert roles[i].role_name == my_list

# Generated at 2022-06-23 06:13:56.514734
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    return_value = load_list_of_tasks(
        ds=[
            {
                "name": "block",
                "block": [
                    {
                        "name": "block2",
                        "block": [
                            {
                                "name": "task"
                            }
                        ]
                    }
                ]
            },
            {
                "name": "task2"
            }
        ],
        play=None,
        block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
        loader=None
    )

    assert len(return_value) == 2, "list of length 2 expected, length is {len(return_value)}"

# Generated at 2022-06-23 06:14:07.174519
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext
    import ansible.playbook.role
    import ansible.playbook.task
    import ansible.playbook.role.include

    p = ansible.playbook.play.Play.load(dict(
        name="test play",
        hosts="all",
        gather_facts=False,
        roles=["test-role"]
    ))
    p._tqm = None
    p.post_validate({}, [])
    p.finalize()

    pm = p.get_variable_manager()
    pm._fact_cache = {}
    pm._task_cache = {}

    pc = PlayContext()
    pm._options_vars = {}
    pm._internal_cache = {}

    r = ansible.play

# Generated at 2022-06-23 06:14:17.966215
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test for bare tasks
    # {'action':{'module':'ping'}}
    # {'action':'shell', 'args':'ifconfig'}
    assert load_list_of_tasks([{'action':{'module':'ping'}}], None) == [{'action':{'module':'ping'}},]
    assert load_list_of_tasks([{'action':{'module':'ping'}}], None) == load_list_of_tasks([{'action':{'module':'ping'}}], None)
    # test for tasks in block
    # [{'block':{'name':'hello', 'tasks':{'action':'shell', 'args':'ifconfig'}}},]

# Generated at 2022-06-23 06:14:29.508963
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.utils.display import Display
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import include_role
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    dl = DataLoader()
    mock_display = Display()
    ivm = InventoryManager(dl)

    #test role include
    #test static role include
    test_static_task_ds = {'include_role': {'name': 'myrole'}}

# Generated at 2022-06-23 06:14:41.127332
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Testing without implicit and without explicit blocks
    init_ds = None
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    result = load_list_of_blocks(init_ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    print(result)

    # Testing with implicit and without explicit blocks
    init_ds = [{"tasks": {"name": "do something", "local_action": {"module" : "shell", "args" : "echo hi"}}}, {"another_task": {"name": "do something else", "local_action": {"module" : "shell", "args" : "echo hi2"}}}]
    play = None
    parent

# Generated at 2022-06-23 06:14:52.601896
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DataLoader()
    all_vars = dict(foo='bar')
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, play_context=play_context, all_vars=all_vars)
    role_path = os.path.join(os.path.dirname(__file__), '../../../lib/ansible/galaxy/data')
    role_1 = "name1"
    role_2 = "name2"
    play_name_ = "play"

# Generated at 2022-06-23 06:15:00.533108
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test for AnsibleAssertionError (ds should be a list)
    vars_of_interest = {"test_lists_of_tasks_list": 'test_string'}
    ds = "test_string"
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = VariableManager()
    loader = DictDataLoader()
    variable_manager.set_vars(vars_of_interest)
    variable_manager.set_host_variable(host="localhost", varname="test_lists_of_tasks_list", value=["test_string", "second_string_in_list"])
    loader.set_basedir(os.path.join(os.path.dirname(__file__), 'vars'))


# Generated at 2022-06-23 06:15:11.783342
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    ds = [
        dict(
            name='foo1',
            tasks=[
                dict(action=dict(module='debug', args=dict(msg='bar1'))),
                dict(action=dict(module='debug', args=dict(msg='bar2'))),
            ]
        ),
        dict(
            name='foo2',
            tasks=[
                dict(action=dict(module='debug', args=dict(msg='bar3'))),
            ]
        )
    ]


# Generated at 2022-06-23 06:15:12.287698
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:15:19.596777
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    This function tests the load_list_of_roles function.
    :return: 
    """
    import ansible.playbook
    import ansible.plugins
    import ansible.utils
    import ansible.inventory
    import ansible.module_utils
    import ansible.constants as C
    import ansible.errors
    import ansible.vars
    import ansible.playbook.role.include
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import sys
    

# Generated at 2022-06-23 06:15:31.467077
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.template import Templar


# Generated at 2022-06-23 06:15:43.047100
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook
    import ansible.playbook.play
    from ansible.playbook.block import Block

    ds = [
        {'action': {'__ansible_module__': 'ping'}},
        {'block': {'name': 'test_block', 'block': {'action': {'__ansible_module__': 'ping'}}}}
    ]

    play = ansible.playbook.play.Play()

    block_list = load_list_of_blocks(ds, play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

    assert isinstance(block_list[0], Block)
    assert isinstance(block_list[1], Block)
    assert len(block_list) == 2


# Generated at 2022-06-23 06:15:54.171087
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources=["/etc/ansible/hosts"]))

# Generated at 2022-06-23 06:16:05.925757
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, 'localhost')
    play_source =  dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='debug', args=dict(msg='Hello World'))),
            ]
        )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    block_list = load_list_of_blocks

# Generated at 2022-06-23 06:16:20.425366
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.play
    import ansible.playbook.play_context
    import ansible.playbook.included_file
    import ansible.vars.manager

    def load_call_block(block, play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        return block

    def load_call_task(block_ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        return block_ds

    # Let's patch the function now
    ansible.playbook.task.Task.load = load_call_task


# Generated at 2022-06-23 06:16:31.897590
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test the load_list_of_roles function.
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars

    my_play = Play()
    my_play_context = PlayContext()
    my_loader = DataLoader()

    variable_manager = VariableManager(loader=my_loader, inventory=InventoryManager(loader=my_loader, sources=[]))

    my_inventory = InventoryManager(loader=my_loader, sources=['localhost,'])
    variable_manager.set_inventory(my_inventory)

# Generated at 2022-06-23 06:16:39.940240
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import os
    import shutil
    import tempfile
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from units.mock.loader import DictDataLoader

    from ansible.errors import AnsibleParserError

    class TestInclude:
        def __init__(self, path, options):
            self.path = path
            self.args = options

    # Using a Directory on disk to store the data for the test
    temp_dir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:16:47.658975
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test if we can load list of roles
    """
    RoleInclude = collections.namedtuple('RoleInclude', 'role_name vars_files')

    def load_list_of_roles(ds, play=None, current_role_path=None, variable_manager=None, loader=None, collection_search_list=None):
        if not isinstance(ds, list):
            raise AnsibleAssertionError('ds (%s) should be a list but was a %s' % (ds, type(ds)))

        roles = []
        for role_def in ds:
            i = RoleInclude(role_name = role_def.get('role'),
                            vars_files = role_def.get('vars_files'))
            roles.append(i)
        return roles

    # check if

# Generated at 2022-06-23 06:16:50.510845
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    print("TESTING: load_list_of_blocks")
    print("Not available right now")
    #TODO (dc)
    return False


# Generated at 2022-06-23 06:16:54.901567
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def do_test(ds, expect_ok=True, current_role_path=None):
        # we import here to prevent a circular dependency with imports
        from ansible.playbook.play import Play
        from ansible.vars.manager import VariableManager

        variable_manager = VariableManager()
        play = Play.load({'name': 'test',
                          'hosts': 'localhost',
                          'connection': 'local',
                          'roles': ds}, variable_manager=variable_manager, loader=None)


# Generated at 2022-06-23 06:17:02.269002
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    variable_manager = VariableManager()
    # inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list='localhost,')


# Generated at 2022-06-23 06:17:08.846475
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    data="""
    - name: '{{ role_name }}'
      static: '{{ static_import }}'
      tags:
        - one
        - two
        - three
    """
    data_ds = yaml.safe_load(data)
    loader = DictDataLoader(dict(
        plays=dict(
            play="""
            - name: test play
              hosts:
                - localhost
              tasks:
                - name: test task
                  include_role:
                    name: role_name
            """
        )
    ))
    mock_play = Play().load("", loader=loader, variable_manager=VariableManager())

# Generated at 2022-06-23 06:17:21.031532
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        import ansible.playbook.play
    except ImportError:
        sys.exit("Failed to import ansible.playbook.play")

    fake_loader = DictDataLoader({
        "test.yml": """
        - name: 'my first task'
        - name: "my second task"
          block:
            - name: 'my first block task'
            - name: 'my second block task'
        """,
    })

    play_ds = [{'hosts': 'all', 'roles': [], 'name': 'test', 'tasks': []}]
    play = ansible.playbook.play.Play.load(play_ds[0], variable_manager=VariableManager(), loader=fake_loader)

# Generated at 2022-06-23 06:17:27.757537
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # First we need to make a fake datastructure to load
    ds = [
        dict(action=dict(module='action_module', args={})),
        dict(block=dict(block={})),
    ]
    # Next, a fake play object
    class FakePlay(object):
        pass

    play = FakePlay()

    # Finally, we can call the function
    ret = load_list_of_tasks(ds, play=play)

    # We need to write tests to check that ret matches ds
    #assert ret == expected
    pass

# Generated at 2022-06-23 06:17:38.267754
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import callback_loader
    from ansible.errors import AnsibleParserError
    from collections import namedtuple
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.common._collections_compat import MutableMapping
    import ansible.constants as C
    import ansible.module_utils.collections

    loader = DataLoader()

    # Create mock objects

# Generated at 2022-06-23 06:17:45.294389
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [
        {'role': 'my_role'},
        {'name': 'my_second_role'},
        {'role': 'my_third_role', 'tasks': []}
    ]
    loader = DataLoader()
    variable_manager = VariableManager()
    assert load_list_of_roles(ds, None, loader, variable_manager) is not None


# Generated at 2022-06-23 06:17:53.393950
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import pytest
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import module_loader
    from ansible.module_utils._text import to_bytes
    from ansible.template import Templar
    from ansible.utils.collection_loader import AnsibleCollectionConfig
    from ansible.vars.manager import VariableManager

    from ansible.errors import AnsibleAssertionError, AnsibleParserError

    AnsibleCollectionConfig.set_collection_playbook_paths(['../../', '../../../ansible_collections'])
    stdout_callback = callback_loader.get('stdout')
    variable_manager = VariableManager()

    loader = DataLoader()


# Generated at 2022-06-23 06:18:02.531489
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    ds = [{'include_role': {'name': AnsibleUnsafeText('role_name')}}, {'include_role': {'name': AnsibleUnsafeText('role_name')}}]
    play = Play()
    block = None
    task_include = None
    role = None
    use_handlers = False
    variable_manager = VariableManager()
    loader = None

# Generated at 2022-06-23 06:18:03.497440
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Unit test for load_list_of_tasks
    assert True



# Generated at 2022-06-23 06:18:09.333171
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    ds = """
    - hosts: localhost
      task:
        debug:
          msg: "test"
    - name: example
      block:
        - debug:
            msg: "test"
    """

    assert (load_list_of_blocks(ds, None)
                                [0].block
                                [0].block
                                [0].module_name == 'debug')


# Generated at 2022-06-23 06:18:13.348620
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    return load_list_of_blocks(None, None, None, None, None, None, None, None)

# Make this a method on the Task class so it can be overridden by any plugin that needs to provide its own
# set of fail_when entries

# Generated at 2022-06-23 06:18:23.882242
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources=[])
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)
    fake_variable_manager.extra_vars = dict(foo='bar')

# Generated at 2022-06-23 06:18:30.786138
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    #
    # Test role with no name specified
    #
    role_list = load_list_of_roles([{}], None)
    assert len(role_list) == 1
    assert isinstance(role_list[0], RoleInclude)
    assert role_list[0].role_name == ''

    #
    # Test role with name, no path, and no src
    #
    role_list = load_list_of_roles([{'name': 'test-role'}], None)
    assert len(role_list) == 1
    assert isinstance(role_list[0], RoleInclude)
    assert role_list[0].role_name == 'test-role'
    assert role_list[0].role_path is None
    assert role_list[0].role_src is None

    #

# Generated at 2022-06-23 06:18:42.448763
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # 1. check if ds is a list
    ds = "a"
    play = ""
    block = ""
    role = ""
    task_include = ""
    use_handlers = ""
    variable_manager = ""
    loader = ""

# Generated at 2022-06-23 06:18:51.051910
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    # Create a block
    b = Block(None, None)
    assert Block.is_block(b) is True

    # Create a task
    task = Task()
    task.action = 'test'

    # Create a block with a task
    b = Block(None, None, task)
    assert Block.is_block(b) is True

    # Create a block with a task and a task
    b = Block(None, None, task, task)
    assert Block.is_block(b) is True

    # Create a block with a task and no task


# Generated at 2022-06-23 06:19:00.288336
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars

    variable_manager = DictData({})
    loader = DictData({})
    loader.set_basedir(os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures'))
    ini_vars = {}
    ini_vars.update(combine_vars(loader=loader, var_list=[loader.load_from_file('fixtures/group_vars/all.yml')]))
    variable_manager._extra_vars = ini_vars
    variable_manager._options_vars = {}

# Generated at 2022-06-23 06:19:09.575887
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Funtion to unit test load_list_of_roles
    :return:
    '''
    from ansible import context
    from ansible.cli import CLI
    from ansible.errors import AnsibleError, AnsibleParserError
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext

    ds = [{'role': 'webservers'}, {'role': 'dbservers'}]
    play = Play.load({}, variable_manager=None, loader=None)
    result = load_list_of_roles(ds, play)
    assert(len(result) == 2)



# Generated at 2022-06-23 06:19:14.573691
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    ds = [{'test1': 'test2'}, {'test3': 'test4'}, 'test5']

    result = load_list_of_blocks(ds, None, None)
    assert result[0]._attributes == {'test1': 'test2'}
    assert result[1]._attributes == {'test3': 'test4'}
    assert result[2]._attributes == {'block': 'test5'}


# Generated at 2022-06-23 06:19:16.613467
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks()
    '''
    pass

# Generated at 2022-06-23 06:19:17.980886
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert 'Not Yet Implemented'

# Generated at 2022-06-23 06:19:27.277655
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor import playbook_executor
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    import os
    ld = DataLoader()
    task_vars = {}
    play_vars = {}
    role_vars = {}


    # Construct a fake play and fake task.

# Generated at 2022-06-23 06:19:36.721536
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude

    ds = [{'name': 'foo'}]
    play = Play()
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None

    roles = load_list_of_roles(ds, play, current_role_path=current_role_path, variable_manager=variable_manager, loader=loader, collection_search_list=collection_search_list)

    assert type(roles[0]) == RoleInclude

# Generated at 2022-06-23 06:19:50.536248
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    # create a loader
    loader = DataLoader()
    # create an inventory
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    # create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    # create a play

# Generated at 2022-06-23 06:19:51.136872
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:19:53.369987
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:20:02.925429
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [{u'block': u'test_block'},{u'task': u'test_task'},{u'task': u'test_task2'}]
    display = Display()
    test_play = Play()
    test_play.playbook = {u'statement': u'Command line'}
    test_play._included_filenames = []
    test_play.name = u'test_playbook'
    test_play.basedir = u''
    test_play.play_hosts = {u'all': {u'hosts': [u'localhost']}}
    test_play.role_names = []
    test_play.vars_files = []
    vm = VariableManager()
    l = DataLoader()

# Generated at 2022-06-23 06:20:12.911549
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=["tests/lib/ansible/inventory/test_invalid_groups.yml"])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = Play

# Generated at 2022-06-23 06:20:19.747601
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Setup
    ds = []
    play = (0, 'test')
    current_role_path = ""
    variable_manager = None
    loader = None
    collection_search_list = []

    # Execute
    result = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)

    # Assert
    assert(result)



# Generated at 2022-06-23 06:20:21.021737
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # FIXME: How do we test this?
    pass


# Generated at 2022-06-23 06:20:33.447484
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Unit test for function load_list_of_blocks
    '''


# Generated at 2022-06-23 06:20:44.965176
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext

    play = PlayContext()

    ret0 = load_list_of_blocks(None, play)
    assert ret0 == []

    ret1 = load_list_of_blocks([], play)
    assert ret1 == []

    with pytest.raises(AnsibleAssertionError) as e1:
        load_list_of_blocks(1, play)
        assert e1.message == '1 should be a list or None but is <type \'int\'>'

    with pytest.raises(AnsibleAssertionError) as e2:
        load_list_of_blocks('string', play)

# Generated at 2022-06-23 06:20:56.791281
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.module_utils._text import to_bytes
    loader, inventories, variable_manager = setup_loader()
    play = Play().load(dict(
        name = "foobar",
        hosts = "all",
        gather_facts = 'no',
        tasks = [
            {'action': {'module': 'debug', 'args': {'msg': "ok"}}},
            {'action': {'module': 'debug', 'args': {'msg': "ok"}}}
        ]
    ), loader=loader, variable_manager=variable_manager)
    assert len(play.tasks()) == 2
    assert play.tasks()[0].name == 'debug'
    assert play.tasks()[1].name == 'debug'
    assert play.tasks()

# Generated at 2022-06-23 06:21:05.400779
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_1_dict = {'include_vars': {'_raw_params': '/Users/sreid/automation/git/roles/tf_app/vars/main.yml', 'tags': ['tasksimport'], '_uses_eval': False}}
    task_2_dict = {'meta': {'_raw_params': {'nested': {'var': 2}}, 'tags': ['tasksimport'], '_uses_eval': False}}
    ds = [task_1_dict, task_2_dict]

    task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:21:17.697987
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import unittest2 as unittest

    from ansible import constants as C
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

    class TestLoadListOfBlocks(unittest.TestCase):

        def setUp(self):
            self.loader = DataLoader()
            self.variable_manager = VariableManager(loader=self.loader)

            # setup the test play, which has tasks and blocks in it

# Generated at 2022-06-23 06:21:27.184908
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = []
    display = Display()

    """ Using hosts to set up ansible inventory """
    hosts = ['hello-world.org', 'localhost']
    inventory = Hosts(hosts)
    inventory.get_host("hello-world.org").set_variable("ansible_python_interpreter", "/usr/bin/python")
    inventory.get_host("hello-world.org").set_variable("ansible_ssh_host", "172.0.0.1")
    inventory.get_host("hello-world.org").set_variable("ansible_ssh_port", "22")


# Generated at 2022-06-23 06:21:36.866950
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser

    ds_list_1 = [
        {
            'block': 'block1',
            'tasks': [
                {
                    'meta': 'meta1'
                }
            ]
        },
        {
            'block': 'block2',
            'tasks': [
                {
                    'meta': 'meta2'
                }
            ]
        }
    ]

    ds_list_2 = [
        {
            'meta': 'meta1'
        },
        {
            'meta': 'meta2'
        }
    ]

    templar = Templar(loader=None)
    vm

# Generated at 2022-06-23 06:21:38.772707
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles(None,None,None,None,None,None) is None

# Generated at 2022-06-23 06:21:39.606118
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:21:51.220011
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    Loader_module_mock = MagicMock()
    Loader_module_mock.path_dwim = MagicMock(return_value='/tmp/test_load_list_of_blocks.yml')
    loaderMock = Loader_module_mock()
    mock_data = [{"block": "block1"}, {"task": "task1"}, {"task": "task2"}, {"block": "block2"}]
    task_vars = dict(foo='foo', bar='bar')
    variable_manager = variable_manager.VariableManager(loader=loaderMock, inventory=None)
    variable_manager.set_nonpersistent_facts(task_vars)

# Generated at 2022-06-23 06:22:01.011697
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Note: this test cannot be run in its current state because it depends on
    # a global Ansible that is not in scope here.
    # TODO: this function is really tested pretty well in the more general
    # tests that load playbooks, so leave it alone for now but reevaluate to
    # see whether this is worth updating
    # TODO: decide whether to replace with separate Integration test
    from ansible import context
    from ansible.module_utils.common.collections import is_sequence
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 06:22:11.456300
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play
    from ansible.playbook.datastructure import to_yaml
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display

    class DummyOptions:
        def __init__(self):
            self.connection = 'local'
            self.module_path = ''
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.remote_user = 'root'
            self.listhosts = False

# Generated at 2022-06-23 06:22:23.478958
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode


    display = Display()
    display.verbosity = 3
    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext()
    play = Play()

    play.vars = HostVars(loader=loader, variables=variable_manager)
    play.variable_manager = variable_manager

    play.vars['test_var'] = 'test_value'


# Generated at 2022-06-23 06:22:29.614865
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    b1 = Block.load({'block': 'Test'})
    b2 = Block.load({'block': 'Test2'})

    assert load_list_of_blocks([{'block': 'Test'}]) == [b1]
    assert load_list_of_blocks([{'block': 'Test'}, {'block': 'Test2'}]) == [b1, b2]



# Generated at 2022-06-23 06:22:40.371206
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    role_list = load_list_of_roles(
        [
            {
                'name': 'apache',
            },
            {
                'name': 'database',
            },
        ],
        play=None,
        current_role_path=None,
        variable_manager=None,
        loader=None,
        collection_search_list=None,
    )

    assert len(role_list) == 2
    assert isinstance(role_list[0], RoleInclude)
    assert isinstance(role_list[1], RoleInclude)
    assert role_list[0]._role_name == 'apache'
    assert role_list[1]._role_name == 'database'

# Generated at 2022-06-23 06:22:42.665638
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # no test because this is mostly a helper function for use in the tests for the Block
    pass



# Generated at 2022-06-23 06:22:45.222909
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test for function load_list_of_tasks
    pass



# Generated at 2022-06-23 06:22:53.811579
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # mocks
    class FakePlay:
        pass
    fake_play = FakePlay()
    fake_role_name = 'some_role'
    fake_role_def = dict(name=fake_role_name)

    # test the happy path
    r = load_list_of_roles([fake_role_def], fake_play)
    assert(len(r) == 1)
    assert(r[0].name == fake_role_name)

    # test bad parameters
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(fake_role_def, fake_play)

# Generated at 2022-06-23 06:23:05.276441
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:23:13.893967
# Unit test for function load_list_of_blocks

# Generated at 2022-06-23 06:23:17.425821
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'role': 'base'}, {'role': 'web', 'foo': 'bar'}]
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    assert load_list_of_roles(ds, None) == [RoleInclude.load(ds[0], None), RoleInclude.load(ds[1], None)]



# Generated at 2022-06-23 06:23:24.220561
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.base import Base
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.plugins.loader import action_loader

    AnsibleBaseYAMLObject.FAIL_ON_MISSING_ATTRIBUTES = False
    Block.FAIL_ON_MISSING_ATTRIBUTES = False
    Task.FAIL_ON_MISSING_ATTRIBUTES = False


# Generated at 2022-06-23 06:23:34.830096
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    import yaml
    current_dir = os.path.dirname(os.path.realpath(__file__))