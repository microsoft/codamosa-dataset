

# Generated at 2022-06-23 06:13:44.652295
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # to confirm the expected result,
    # run ansible-playbook --version
    # then diff the output with the expected result
    from ansible.config.manager import ConfigManager

    config_manager = ConfigManager.get_instance()
    config_manager.load_configuration_file()

    from ansible.utils.plugin_docs import get_action_documentation
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_v

# Generated at 2022-06-23 06:13:55.854585
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [
        {
            'block': [
                {
                    'block': [
                        {
                            'name': 'test1'
                        }
                    ],
                    'name': 'TEST'
                }
            ],
            'name': 'test2'
        },
        {
            'block': [
                {
                    'block': [
                        {
                            'name': 'test4'
                        }
                    ],
                    'name': 'TEST'
                }
            ],
            'name': 'test5'
        },
    ]
    try:
        ansible_util.load_list_of_tasks(ds=task_ds)
    except AnsibleAssertionError as e:
        print(e)

# Generated at 2022-06-23 06:14:07.029349
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO
    import unittest
    import mock
    class TestLoadListOfBlocks(unittest.TestCase):
        @mock.patch('ansible.playbook.block.Block')
        def setUp(self, mock_block):
            self.mock_block_instance = mock.MagicMock()
            mock_block.return_value = self.mock_block_instance
            self.play = mock.MagicMock()
            self.parent_block = mock.MagicMock()
            self.role = mock.MagicMock()
            self.task_include = mock.MagicMock()
            self.use_handlers = mock.MagicMock()
            self.variable_manager = mock.MagicMock()
            self.loader = mock.MagicMock()


# Generated at 2022-06-23 06:14:17.725952
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.module_utils.six import PY3
    from ansible.module_utils.six.moves import builtins

    open_name = '__builtin__.open'
    if PY3:
        open_name = 'builtins.open'

    # Need a valid Play object to test loading
    fake_loader = DummyLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=fake_loader))
    variable_manager.extra_vars = {'somevar': 'somevalue'}

# Generated at 2022-06-23 06:14:24.513472
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds=['block', {'block': 'action'}]
    load_list_of_tasks(ds=task_ds, play="play", block="block", role="role", task_include="task_include", use_handlers=False, variable_manager="variable_manager", loader="loader")
test_load_list_of_tasks()

# Generated at 2022-06-23 06:14:25.022541
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-23 06:14:32.164795
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import ansible.callbacks
    import os
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), "../tests")
    os.environ["ANSIBLE_CONFIG"] = os.path.join(path, "ansible.cfg")
    C.HOST_KEY_CHECKING = False

    class Options(object):
        connection = 'local'
        module_path = None

# Generated at 2022-06-23 06:14:44.549201
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    import ansible.constants as C
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    myplaybook = "playbook.yaml"
    inventory = "inventory.yaml"

    task_ds = dict(
        name = "test_name",
        block = "block",
        debug = "msg=test_variable:{{ test_variable }}"
    )


# Generated at 2022-06-23 06:14:54.866160
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        dict(action='action_one'),
        dict(action='action_two'),
    ]
    import ansible.playbook.play
    from ansible.playbook.play import Play
    play = Play()
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_list = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(task_list) == 2
    assert isinstance(task_list[0], Task)

# Generated at 2022-06-23 06:15:04.883223
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    import ansible.playbook.play
    import ansible.playbook.task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from ansible.vars.unsafe_proxy import AnsibleUnsafeText

    ds = [
        {
            'tasks': [
                {'name': 'task 1'}
            ]
        },
        {
            'block': 'inner',
            'rescue': [
                {'name': 'rescue task'}
            ]
        }
    ]

    variable_manager = VariableManager()

# Generated at 2022-06-23 06:15:15.094766
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    play_ds = dict(
        name="Ansible Play",
        hosts="test",
        gather_facts="yes"
        )

    play = Play().load(
        play_ds,
        variable_manager=VariableManager(),
        loader=DictDataLoader()
        )

    test_block = Block(
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=VariableManager(),
        loader=DictDataLoader()
        )

    # test for task with block

# Generated at 2022-06-23 06:15:25.648530
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test load_list_of_roles
    """

    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import load_plugins

    loader = DataLoader()
    options = Options()
    variable_manager = VariableManager(loader=loader, options=options)
    inventory = InventoryManager(loader=loader, sources=["/etc/ansible/hosts"])


# Generated at 2022-06-23 06:15:27.210268
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #TODO write test for load_list_of_roles
    pass



# Generated at 2022-06-23 06:15:29.980861
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:15:30.753872
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-23 06:15:42.653410
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds=[
        {
            "block": [
                "foo"
            ]
        },
        {
            "block": [
                {
                    "block": [
                        "foo2"
                    ]
                },
                {
                    "include": [
                        "somefile"
                    ]
                }
            ],
            "doit": [
                "ok"
            ]
        },
        {
            "block": [
                "bar"
            ]
        },
        {
            "include": [
                "somefile2"
            ]
        },
        {
            "block": [
                "baz"
            ]
        }
    ]

# Generated at 2022-06-23 06:15:54.220009
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader

    # Create mocks
    InventoryManager.define_host = MagicMock(return_value=None)
    DataLoader.load = MagicMock(return_value=None)
    Task.load = MagicMock()

    mock_loader = MagicMock(**{'get_basedir.return_value': '/basedir/'})
    mock_loader._is_collection_item.return_value=False

   

# Generated at 2022-06-23 06:16:05.925460
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [
        'include: test1.yaml',
        {'block': [
            'include: test2.yaml',
            'include: test3.yaml',
            {'block': [
                'include: test4.yaml',
            ]},
            'include: test5.yaml',
        ]},
        'import_tasks: test6.yaml',
        {'block': [
            'import_tasks: test7.yaml',
            'import_tasks: test8.yaml',
            {'block': [
                'import_tasks: test9.yaml',
            ]},
            'import_tasks: test10.yaml',
        ]},
    ]


# Generated at 2022-06-23 06:16:20.530325
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{"role": "test_role"}]
    ds2 = [{"role": "test_role2"}]
    play = Play()
    current_role_path = "test_role"
    variable_manager = VariableManager()
    loader = DataLoader()

    assert(load_list_of_roles(ds, play, current_role_path=current_role_path, variable_manager=variable_manager, loader=loader) == [RoleInclude(role="test_role", play=play, current_role_path=current_role_path, variable_manager=variable_manager,
                             loader=loader)])

# Generated at 2022-06-23 06:16:29.983596
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    basic test of load_role_definition

    '''

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude

    test_ds = [
        dict(name='role.0.0'),
        dict(name='role.0.1'),
    ]
    ds = load_list_of_roles(test_ds, None)
    assert len(ds) == len(test_ds)
    assert ds[0] == RoleInclude.load(test_ds[0])
    assert ds[1] == RoleInclude.load(test_ds[1])



# Generated at 2022-06-23 06:16:39.018011
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook import Play
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable

# Generated at 2022-06-23 06:16:51.435814
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    write_fake_yaml()
    display.verbosity = 3
    parser = ModuleArgsParser()
    play_ds = dict(
        name="test",
        hosts='test',
        gather_facts='no',
        tasks=[{"include": "test-include"}],
    )
    play = Play().load(play_ds, variable_manager=None, loader=None)
    load_list_of_blocks(None, play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:16:52.064166
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:17:03.060362
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    test_data = [{'hosts': 'host1', 'tasks': [{'name': 'task1'}, {'block': [{'name': 'task2'}]}]}, {'hosts': 'host2', 'tasks': [{'name': 'task3'}, {'block': [{'name': 'task4'}]}]}]
    test_play = Play().load(test_data, variable_manager=None, loader=None)
    result = load_list_of_blocks(test_data, test_play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert type(result) is list

# Generated at 2022-06-23 06:17:11.894102
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.playbook.block import Block
    ds = [{'task1': 'task1'}, {'block1': {'task1': 'task1'}}, {'block2': {'task1': 'task1'}}]
    result = load_list_of_blocks(ds)
    assert len(result) == 3
    assert isinstance(result[0], Block)
    assert isinstance(result[1], Block)
    assert isinstance(result[2], Block)

    

# Generated at 2022-06-23 06:17:24.022954
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import IncludeRole
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.config.manager import ConfigManager


# Generated at 2022-06-23 06:17:36.567259
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.plugins import module_loader
    from ansible.module_utils.common._collections_compat import Mapping
    import json

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 06:17:46.644775
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds=[{'name':'hello','tags':['a','b','c']},{'name':'hello','tags':['a','b','c']}]
    play=Play().load({'name':'test','hosts':'all','gather_facts':'no'})
    role=dict()
    task_include=dict()
    use_handlers=True
    variable_manager=VariableManager()
    loader=DictDataLoader({})
    task=load_list_of_tasks(ds,play,role,task_include,use_handlers,variable_manager,loader)
    print(task)

#test_load_list_of_tasks()


# Generated at 2022-06-23 06:17:53.847137
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    d = []
    d.append({'block': {'block': {'task': 'test'}}})
    d.append('test')
    d.append('test2')
    d.append({'block': 'test3'})
    d.append({'block': 'test4'})
    d.append('test5')
    # Test that we have the correct amount
    assert len(d) == 6
    assert len(load_list_of_blocks(d, None, None)) == 4



# Generated at 2022-06-23 06:18:06.946910
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    load_list_of_roles: load list of roles
    '''
    ds = "foo"
    play = {}
    current_role_path = {}
    variable_manager={}
    loader={}
    collection_search_list={}
    try:
        load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list )
    except AnsibleAssertionError as e:
        print(e.args[0])
    ds = [
        {
            "role": "foo/bar"
        },
        {
            "name": "foo/bar/baz",
            "tasks_from": "bar"
        }
    ]

# Generated at 2022-06-23 06:18:18.423345
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.utils.vars import combine_vars
    
    def create_var_manager(vars_dict, vars_files=None):
        from ansible.vars import VariableManager
        from ansible.inventory.manager import InventoryManager
        from ansible.parsing.dataloader import DataLoader
        
        inventory = InventoryManager(loader=DataLoader(), sources='')
        variables = VariableManager(loader=DataLoader(), inventory=inventory)
        variables.extra_vars = combine_vars(variables.extra_vars, vars_dict)

# Generated at 2022-06-23 06:18:26.271759
# Unit test for function load_list_of_blocks

# Generated at 2022-06-23 06:18:37.935232
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test Functional
    my_role_path = os.path.join(os.path.dirname(__file__), '..', '..', 'test', 'units', 'lib_playbook', 'test_roles', 'test_role_as_role')
    roles = load_list_of_roles(ds=['test_role_as_role'], play=Play().load(dict(name="TEST_PLAY")), current_role_path=my_role_path,
                               variable_manager=None, loader=None, collection_search_list=[])
    assert len(roles) == 1
    assert roles[0]._role_name == 'test_role_as_role'

    # Test AssertionError

# Generated at 2022-06-23 06:18:47.587601
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    collections_search_list = []
    loader = DictDataLoader({})
    variable_manager = VariableManager()
    variable_manager._extra_vars = {"collection_search_list": collections_search_list}
    play_ds = dict(
        name="a play",
        hosts=['localhost'],
        gather_facts='no',
        roles=[
            dict(
                name="role_name",
                tasks=[
                    dict(action=dict(module='debug', args=dict(msg='Hi there')))
                ]
            )
        ]
    )
    play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:18:54.953241
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    # Tests
    # 1. Test loading list of task ds with a dict ds with action "include_role"
    # 2. Test loading list of task ds with a dict ds without action "include_role"
    # 3. Test loading list of task ds with an empty list
    # 4. Test loading list of task ds with a list of dict ds with multiple actions
    # 5. Test loading list of task ds with a list of dict ds with one action
    # 6. Test loading list of task ds with a dict ds with 'block' key
    # 7. Test loading list of task ds with a dict ds with a shell module
    # 8. Test loading list of task ds with a dict ds with

# Generated at 2022-06-23 06:19:04.553281
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Assignments, variables
    ds = [
            None,
            dict(task='name_task1'),
            dict(task='name_task2'),
            dict(task='name_task1'),
            dict(task='name_task1'),
            ]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # Call function
    result = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)

    # Test
    assert result[0]._parent == parent_block
    assert result[0]._tasks[0]._attributes['name'] == 'name_task1'

# Generated at 2022-06-23 06:19:14.053308
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    test_dir = os.path.dirname(__file__)
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

    yaml_file = os.path.join(test_dir, 'load_list_of_tasks.yml')
    with open(yaml_file, 'r') as f:
        ds = yaml.safe_load(f)


# Generated at 2022-06-23 06:19:23.887709
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.collection_loader import AnsibleCollectionConfig
    import pytest

    collection_name = 'test_collection'
    collection_path = os.path.join(os.path.dirname(__file__), 'test_collections', collection_name)
    collection_config = AnsibleCollectionConfig(collection_name=collection_name, collection_path=collection_path)

    ds = [dict(role='test_role_name')]
    p = Play()
    pc = PlayContext()

# Generated at 2022-06-23 06:19:29.581540
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # empty list test
    assert load_list_of_tasks(None,None,None,None,None,False,None,None) == []
    assert load_list_of_tasks([],None,None,None,None,False,None,None) == []
    # 2 tasks test
    ds = [{'include_tasks': 'a.yml'}, {'include_tasks': 'b.yml'}]
    task_list = load_list_of_tasks(ds,None,None,None,None,False,None,None)
    assert len(task_list) == 2



# Generated at 2022-06-23 06:19:39.667560
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.vars.hostvars import HostVars



# Generated at 2022-06-23 06:19:44.500994
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.errors import AnsibleAssertionError
    pass



# Generated at 2022-06-23 06:19:54.036634
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def assert_block(block, attr, val):
        assert block.__dict__[attr] == val

    block_ds = [
        {'block': 'lines', 'name': 'lines'},
        {'block': 'lines', 'name': 'lines1'},
        {'block': 'lines', 'name': 'lines2'},
    ]
    blocks = load_list_of_blocks(ds=block_ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    for block in blocks:
        assert_block(block, '_parent', None)
        assert_block(block, 'name', block._uuid)
        assert_block(block, 'role', None)



# Generated at 2022-06-23 06:20:03.060553
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude

    @patch.object(RoleInclude, 'load')
    def test_mock_load_list_of_roles_with_mock_collection_list(mock_load):
        ds = [
            {'name': 'ansible.builtin', 'tasks_from': 'main'}
        ]
        play = Mock()
        current_role_path = None
        variable_manager = None
        loader = Mock()
        collection_search_list = ['ansible.builtin']

# Generated at 2022-06-23 06:20:13.643031
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext

    from ansible.playbook.play import Play

    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.include import RoleInclude
    from ansible.vars.manager import VariableManager


# Generated at 2022-06-23 06:20:21.929262
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.collection import __collection_name__
    from ansible.plugins.loader import collection_loader

    ds = [
        {'name': __collection_name__ + '.new'},
    ]
    play = None
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None
    roles = load_list_of_roles(ds, play, current_role_path=current_role_path, variable_manager=variable_manager,
                               loader=loader, collection_search_list=collection_search_list)
    assert roles[0].name == __collection_name__ + '.new'



# Generated at 2022-06-23 06:20:24.265978
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: this will be a unit test
    pass



# Generated at 2022-06-23 06:20:35.413146
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    This is a wrapper around load_list_of_blocks to make it easier to test
    '''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    host_list = [u'localhost']

    inventory = InventoryManager(loader=loader, sources=u'localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play  = dict(
        name = "test play",
        hosts = "all",
        gather_facts = "no",
        vars = dict(),
    )
    task_include= dict(
        name = "test task_include",
        static = "yes",
        vars = dict(),
    )

# Generated at 2022-06-23 06:20:45.454799
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''test load_list_of_blocks'''
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 06:20:57.396265
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    from ansible.utils.vars import combine_vars
    import ansible.constants as C

    # Setup
    # Create the test objects
    ds = [{'role': 'test1'}, {'role': 'test2'}]
    test_inventory = InventoryManager(["localhost"])
    test_variable_manager = VariableManager()
    test_loader = None

# Generated at 2022-06-23 06:21:06.297595
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    play = Play().load({'name': 'test play',
                        'hosts': 'localhost',
                        'gather_facts': 'no',
                        'tasks': []})

    play._variable_manager = VariableManager()

    play_context = PlayContext()
    play_context.become = False
    play_context._task_vars = dict()
    play_context._stack = dict(REMAINING_ARGS=[])
    play_context.set_config_options({})
    play_context.set_options({'become_user': 'root', 'become': False, 'become_method': 'sudo', 'verbosity': 2})
    play_context._update_vars_files = []


# Generated at 2022-06-23 06:21:18.450323
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    data = [
        {
            'block': [
                'block1',
                {'task': {'foo': 'bar'}}
            ]
        },
        {
            'task': 'task0'
        },
        {
            'block': [
                'block2',
                {'task': 'task2.0'}
            ]
        },
        {
            'task': 'task3'
        },
        {
            'block': [
                'block4',
                {'task': 'task4.1'}
            ]
        },
        'block6',
        'block7',
        {
            'task': 'task8'
        }
    ]

    class Play(object):
        pass

    class VariableManager(object):
        pass


# Generated at 2022-06-23 06:21:27.758939
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' mock out load_list_of_roles so we can unit test'''

    mock_data = dict(
        role1=dict(
            name="role1",
            tasks=["task1", "task2"],
        ),
        role2=dict(
            name="role2",
            tasks=["task3", "task4"],
        )
    )

    # The function load_list_of_roles is expecting a list as the first param so we will convert the mock_data to a list
    # containing the dictionary from mock_data
    mock_list_of_roles = [mock_data[x] for x in mock_data]


# Generated at 2022-06-23 06:21:33.936445
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import context
    from ansible.module_utils.six import StringIO
    from ansible.vars.manager import VariableManager
    from ansible.errors import AnsibleParserError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars

    display = Display()
    display.verbosity = 2


# Generated at 2022-06-23 06:21:44.973106
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.role.task import Task
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    ds = [
        {'block': 'test'},
        'test_task',
        {'another_block': 'test_2'},
        'task_2',
        None,
        'task_3',
        {'block': 'test_3'},
    ]

# Generated at 2022-06-23 06:21:50.820084
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    #
    # Test task_include
    #
    ds = [
        {'include': 'test_include.yml'},
        {'include_task': 'test_include_task.yml'}
    ]
    loader = DictDataLoader({})
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:21:52.549174
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Load array of roles
    # Return array of RoleInclude objects
    pass

# Generated at 2022-06-23 06:21:54.105863
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
# vim: set noexpandtab:

# Generated at 2022-06-23 06:22:07.248997
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:22:14.679230
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.mod_args import ModuleArgsParser

    # Load tasks from yaml file
    yaml_file = os.path.join(os.path.dirname(__file__), "load_list_of_blocks_tasks.yml")
    ds = DataLoader().load_from_file(yaml_file)

    # Load inventory file
    inv_file = os.path.join

# Generated at 2022-06-23 06:22:26.224105
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars import VariableManager
    from ansible.template import Templar
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins import loader as plugin_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars


# Generated at 2022-06-23 06:22:37.460129
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    import yaml

    yaml_data = open(os.path.join(os.path.dirname(__file__), 'parsing/strategy-tests/test-load-list-of-blocks.yaml')).read()
    ds = yaml.safe_load(yaml_data)

    # Quick fix to avoid loading the entire playbook and pass a dummy play instead
    class Dummy(object):
        def __init__(self, name):
            self.name = name
            self.basedir = os.path.join(os.path.dirname(__file__), 'parsing')

    class DummyPlay:
        def __init__(self, name='play'):
            self._ds = Dummy(name)

        def get_basedir(self):
            return self._ds.basedir

    #

# Generated at 2022-06-23 06:22:38.822127
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # import pdb; pdb.set_trace()
    pass

# Generated at 2022-06-23 06:22:51.139008
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task

# Generated at 2022-06-23 06:22:59.632858
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # test that unqualified role names with matching collections properly resolve
    class FakeVars:
        def __init__(self, includes):
            self._fact_cache = includes

        def set_fact(self, key, val):
            self._fact_cache[key] = val

        def get_fact(self, key):
            try:
                return self._fact_cache[key]
            except KeyError:
                raise AnsibleUndefinedVariable()


# Generated at 2022-06-23 06:23:08.540105
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    play = "test_play"
    role = "test_role"
    task_include = "test_task_include"
    variable_manager = "test_variable_manager"
    loader = "test_loader"

    ds = [
        {
            'name': 'test name',
            'action': 'test action'
        },
        {
            'block': {
                'block': {
                    'block': "test block",
                    'rescue': "test rescue"
                },
                'rescue': "test rescue"
            }
        }
    ]
    block_list = load_list_of_blocks(ds, play, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert len(block_list) == 2


# Generated at 2022-06-23 06:23:20.182275
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test function load_list_of_roles()
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import role_loader

    role_loader.add_directory(DATA_PATH)

    play_context = PlayContext()
    variable_manager = VariableManager()
    loader = DataLoader()

    roles = load_list_of_roles(["role3"], None, play_context, variable_manager, loader,
                               collection_search_list=[], all_vars=[],
                               current_role_path=os.path.join(DATA_PATH, 'roles', 'role3'))
    assert len(roles) == 1
    assert roles[0].name == "role3"

# Generated at 2022-06-23 06:23:32.118483
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    import os
    import tempfile
    import shutil

    # create a temp directory to work in
    tmp_dir = tempfile.mkdtemp()
    
    # create a fake Role to pass to load
    host=InventoryManager(loader=DataLoader())
    loader=Data

# Generated at 2022-06-23 06:23:40.235449
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task
    from ansible.parsing.yaml.objects import AnsibleUnicode

    # make sure implicit blocks get created
    ds = load_list_of_blocks([{'hosts': 'host1', 'tasks': [{'name': 'task1.1'}, {'name': 'task1.2'}]}, {'hosts': 'host2', 'tasks': [{'name': 'task2.1'}, {'name': 'task2.2'}]}], Play())
    assert len(ds) == 2
    assert ds[0].implicit == True
    assert ds[1].implicit == True

    # make sure implicit blocks do not get created