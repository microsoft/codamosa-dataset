

# Generated at 2022-06-23 06:13:45.146670
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.template import Templar

    variable_manager = VariableManager()
    loader = DictDataLoader({})
    variable_manager.set_loader(loader)
    variable_manager.set_inventory(Inventory(loader=loader, variable_manager=variable_manager))

    play_context = PlayContext()
    play_context.network_os = 'junos'
    play_context.become = False
    play_context.become_method = None
    play_context.become_user = None


# Generated at 2022-06-23 06:13:46.952775
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: implement this test
    pass

# Generated at 2022-06-23 06:13:54.602258
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    import os

    # Create a Block
    task = Task.load(dict(action='/usr/bin/test', name='test'),
        task_include=None, variable_manager=None, loader=None)
    assert task is not None
    task.post_validate(templar=None)
    block = task.block

    # Create a Play
    from ansible.playbook.play import Play
    play = Play.load(
        dict(
            name='test',
            hosts='test',
            gather_facts='no'
        ),
        variable_manager=None,
        loader=None
    )
    assert play is not None

    # Create a list of mixed task/block data

# Generated at 2022-06-23 06:14:05.184510
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.utils.contextmanager as test_contextmanager
    from ansible.vars.manager import VariableManager

    # Load the play
    # dataset is the YAML file content
    with test_contextmanager.create_tempfile() as temp_dir_file:
        temp_dir = temp_dir_file.name

        # creating resolver directories and files
        task_dir = os.path.join(temp_dir, 'tasks')
        meta_dir = os.path.join(temp_dir, 'meta')
        handler_dir = os.path.join(temp_dir, 'handlers')
        var_dir = os.path.join(temp_dir, 'vars')

# Generated at 2022-06-23 06:14:11.211673
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test for load_list_of_roles
    :return:
    """
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars

    ds = [{"build": "test_build"}, {"create": "test_create"}]
    loader = DataLoader()
    context = PlayContext()
    inventory = InventoryManager(loader=loader, sources=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:14:20.576554
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'role_path': 'foo/bar'}
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-23 06:14:29.293586
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
        {
            'block': [
                {'block': [{'task': [{'debug': 'msg={{ a }}'}]}]}
            ]
        }
    ]
    ret = load_list_of_blocks(ds=ds, play={'hosts': 'all', 'vars': {'a': 'b'}}, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert len(ret) == 1
    assert ret[0].get_name() == 'Implicit Block'
    assert ret[0]._load_name == '<string>'


# Generated at 2022-06-23 06:14:40.868602
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    role_params = dict(
        name='role_name',
        tasks_path='foo/bar/main.yml',
        task_include=None,
        role_path='/tmp/ansible_test/roles/foo',
        vars_files=['/tmp/ansible_test/roles/foo/main.yml'],
        def_vars=dict(role_def_val='role_def_value'),
        vars=dict(role_def_val='role_override_value'),
        default_vars=dict(role_def_val='role_override_value'),
        handlers_path='foo/bar/handlers',
        default_handlers=['default_handler_1', 'default_handler_2'],
        meta_dir='foo/bar',
    )

# Generated at 2022-06-23 06:14:52.450330
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.include
    import ansible.playbook.role
    import ansible.constants
    ansible.constants.HOST_KEY_CHECKING = False
    if not hasattr(ansible.playbook.role, '_ROLE_PATH'):
        ansible.playbook.role._ROLE_PATH = None
    mock = {'role': 'test_role'}
    play = ansible.playbook.play.Play()
    current_role_path = None
    variable_manager = None
    loader = None
    collection_search_list = None
    ansible.playbook.role.include.load = lambda role_def, play, current_role_path, variable_manager, loader, collection_list: role_def

# Generated at 2022-06-23 06:15:03.069451
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import dynamic_loader
    from ansible.plugins.loader import plugin_loader
    from ansible.executor.task_queue_manager import TaskQueueManager

    req_plugins = [
        "connection",
        "module_utils",
        "lookup",
        "filter",
        "test",
        "callback",
        "vars",
    ]
    plugin_loader.add_directory(os.path.join(os.getcwd(), 'lib'))
    dynamic_loader.add_directory(os.path.join(os.getcwd(), 'lib'))

# Generated at 2022-06-23 06:15:03.453702
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert True

# Generated at 2022-06-23 06:15:14.277703
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars import VariableManager


# Generated at 2022-06-23 06:15:25.536615
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task

    ds = [
        {'block': [], 'block_type': 'rescue', 'key': 'rescue'},
        {'block': [], 'block_type': 'always', 'key': 'always'}
    ]

    ret = load_list_of_tasks(ds)

    assert isinstance(ret[0], Block)
    assert ret[0].block_type == 'rescue'

    assert isinstance(ret[1], Block)
    assert ret[1].block_type == 'always'


# Generated at 2022-06-23 06:15:38.601787
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.dataloader import DataLoader

    ds = [{"block": "test", "rescue": [{"debug": {"msg": "VARIABLE IS NOT DEFINED!"}}], "always": [{"debug": {"msg": "VARIABLE IS NOT DEFINED!"}}]},
          {"block": "test", "rescue": [{"debug": {"msg": "VARIABLE IS NOT DEFINED!"}}], "always": [{"debug": {"msg": "VARIABLE IS NOT DEFINED!"}}]}]
    play = Play.load(ds, variable_manager=None, loader=DataLoader())

# Generated at 2022-06-23 06:15:50.781339
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.cli import CLI
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.vars_plugins.yaml import YamlInventoryVariable
    from ansible.module_utils.common._collections_compat import MutableMapping

    #import os
    import json
    import pprint
    pp = pprint.PrettyPrinter(indent=2)

# Generated at 2022-06-23 06:15:59.277541
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play

    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager

    play_context = PlayContext()
    play = Play()
    play._variable_manager = VariableManager()


# Generated at 2022-06-23 06:16:05.925446
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    test_ds = [{"block": "test_block"}]
    test_block = {'name': 'test_block'}
    test_play = None
    test_task_include = None
    test_use_handlers = False
    test_variable_manager = None
    test_loader = None
    assert load_list_of_tasks(test_ds, test_play, test_block, None, test_task_include, test_use_handlers, test_variable_manager, test_loader)

# Generated at 2022-06-23 06:16:11.227261
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    script_loader = DictDataLoader(
        {
            "test_load_list_of_tasks.yml": """
# From playbook: test_load_list_of_tasks.yml
- hosts: localhost
  gather_facts: no

  tasks:

  - name: task1
    debug:
      msg: off

  - name: task2
    debug:
      msg: task2

  - name: task3
    debug:
      msg: task3

  vars:
    task1_name: task1

  handlers:
  - name: task1
    debug:
      msg: "{{ task1_name }} handler"
    when: "'{{ task1_name }}' != 'task0'"
"""}
        )

    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 06:16:26.290947
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task import Task
    from ansible.utils.vars import combine_vars
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader, lookup_loader
    from ansible.errors import AnsibleUndefinedVariable, AnsibleAssertionError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    def task_loader():
        return [Task()]

    def role_loader():
        return [RoleDefinition()]

    inventory = InventoryManager(loader=DataLoader())
    variable_manager = VariableManager(loader=DataLoader(), inventory=inventory)
    loader = DataLoader()

    # first

# Generated at 2022-06-23 06:16:33.886714
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test_load_list_of_tasks
    # load_list_of_tasks should raise an AnsibleAssertionError if the ds is not a list
    ds = 'some string'
    with pytest.raises(AnsibleAssertionError) as e:
        load_list_of_tasks(ds)
    assert "should be a list" in to_native(e.value)

    # load_list_of_tasks should raise an AnsibleAssertionError if the task_ds is not a dict
    ds = ['some string']
    with pytest.raises(AnsibleAssertionError) as e:
        load_list_of_tasks(ds)
    assert "The ds should be a dict" in to_native(e.value)


# Generated at 2022-06-23 06:16:44.554121
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = None
    variable_manager = None
    loader = None

    ds = []
    blocks = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert len(blocks) == 0

    ds = None
    blocks = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert len(blocks) == 0


# Generated at 2022-06-23 06:16:55.947721
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    test_list = [{
        'action': 'module_name',
        'block': True,
        'other_var': True
    }, {
        'action': 'module_name2',
        'block': True,
        'other_var': True
    }, {
        'action': 'module_name3',
        'block': False,
        'other_var': True
    }, {
        'action': 'module_name4',
        'block': False,
        'other_var': True
    }]
    import contextlib
    with contextlib.redirect_stdout(None):
        assert(load_list_of_tasks(test_list, None, None, None, None, False, None, None)[0])

# Generated at 2022-06-23 06:17:02.916730
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [{'test': 'abc'}, {'test': 'abc'}]

    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.vars.manager import VariableManager
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role import Role
    from ansible.template import Templar

    play_ds = {'hosts': 'all', 'tasks': task_ds}
    play = Play.load(play_ds, variable_manager=VariableManager(), loader=None)

# Generated at 2022-06-23 06:17:09.312329
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from os.path import join, abspath, dirname

    _inventory_file = abspath(join(dirname(__file__), '../../inventory/test_inventory.yml'))
    _inventory = InventoryManager(_inventory_file)
    _loader = DataLoader()
    _variable_manager = VariableManager(_loader, _inventory)

    ds = [{'name': 'role1'}, {'name': 'role2'}]

# Generated at 2022-06-23 06:17:21.482660
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from collections import namedtuple

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'inventory_dir': '/data/ansible/ops/inventory'}
    variable_manager.options_vars = {}
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=['localhost'])
    variable

# Generated at 2022-06-23 06:17:24.108840
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks([{'a': 1}, {'blk': {'tasks': [{'a': 2}]}}], play=None) == 1



# Generated at 2022-06-23 06:17:29.011135
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(None, None, None, None, None) is not None
    assert load_list_of_tasks([], None, None, None, None) is not None


# Generated at 2022-06-23 06:17:29.560686
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-23 06:17:35.291007
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # test that invalid data raises an error
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import vault_loader
    from ansible.vars import VariableManager

    play = Play()
    play._injector = DictData("play")
    play._variable_manager = VariableManager()
    play.context = PlayContext()

    ds = "Test"
    role = None
    task_include = None
    use_handlers = False
    variable_manager = VariableManager()
    loader = None


# Generated at 2022-06-23 06:17:46.186257
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handlers import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..', '..', 'lib', 'ansible', 'modules', 'extras'))

# Generated at 2022-06-23 06:17:46.908114
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass


# Generated at 2022-06-23 06:17:57.132897
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:18:08.932577
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test vars
    current_role_path = '/home/user/roles/role1'
    variable_manager = {"_variable_manager": "var man"}
    loader = {"_loader": "loader"}
    collection_search_list = ["collections"]
    role_def = {
        "role": "role2",
        "some_var": "some_value",
        "some_var2": 2,
        "a_dict": {"a": "b"},
        "a_list": ["a", "b", "c", "d"]
    }

    # Create mock ansible.playbook.role.include.RoleInclude
    mock_role_include = {"_loaded_from": "dir/dir/dir/role2"}
    module_mock = MagicMock(spec=RoleInclude)
    attrs

# Generated at 2022-06-23 06:18:20.133071
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print('\n\n############')
    print('# Test load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None')
    print('#')
    print('# ds: list of task dict')
    print('# play: Play')
    print('# block: Block')
    print('# role: Role')
    print('# task_include: TaskInclude')
    print('# use_handlers: to use handler or task')
    print('# variable_manager')
    print('# loader: DataLoader')
    print('#')
    print('# return: list of block or task')

    from ansible.playbook import Play
    from ansible.playbook.block import Block

# Generated at 2022-06-23 06:18:28.598410
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = {'include': ["all"]}
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    #we import here to prevent a circular dependency with imports
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from collections import namedtuple
    from ansible.utils import context_objects as co

    Options = namedtuple('Options',
                                 ['connection', 'module_path', 'forks', 'become', 'become_method', 'become_user', 'check', 'diff', 'listhosts', 'listtasks', 'listtags', 'syntax'])



# Generated at 2022-06-23 06:18:40.117265
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import os
    import copy
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.config.manager import ConfigManager
    config_manager = ConfigManager()
    ansible_cfg = os.path.join(os.path.dirname(__file__), 'ansible.cfg')
    config_manager.load_config_file(config=ansible_cfg)
    loader = DataLoader(config_manager)
    variable_manager = VariableManager()
    inventory_dir = os.path.dirname(__file__)

# Generated at 2022-06-23 06:18:48.623138
# Unit test for function load_list_of_blocks

# Generated at 2022-06-23 06:18:50.120885
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert(load_list_of_tasks(None,None,None,None,None,None,None,None) == [])

# Generated at 2022-06-23 06:18:59.125095
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import discover_plugins
    from ansible.vars import VariableManager
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser

    discover_plugins()


# Generated at 2022-06-23 06:19:01.009376
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False # Error: NameError: name 'ds' is not defined



# Generated at 2022-06-23 06:19:11.536310
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    role_def1 = {
        'role': 'role_name',
        'tasks': ['task_file1', 'task_file2'],
    }
    role_def2 = {
        'role': 'role_name_2',
        'tasks': ['task_file1', 'task_file2'],
        'tags': ['tag_name'],
        'defaults': {
            'default1': 'var1'
        },
        'vars': {
            'var1': 'var2',
            'var2': 'var3'
        }
    }
    ds = [role_def1, role_def2]
    roles = load_list_of_roles(ds)
    assert(len(roles) == 2)

# Generated at 2022-06-23 06:19:21.469067
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    global loader, variable_manager

# Generated at 2022-06-23 06:19:29.409603
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import constants as C
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    import os

    ds = [
        {
            "name": "Zerotier"
        }
    ]

    mydir = os.path.dirname(__file__)
    mydir = os.path.abspath(mydir)
    datapath = os.path.join(mydir, '../../../lib/ansible/plugins/connection')

# Generated at 2022-06-23 06:19:39.391546
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class test_Task():
        def __init__(self):
            pass
        def load(self, task_ds, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
            return self
    class test_Block():
        def __init__(self):
            pass
        def load(self, task_ds, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
            return self
        @staticmethod
        def is_block(block_ds):
            if block_ds is not None:
                return True
            else:
                return False
    class test_play():
        def __init__(self):
            pass

# Generated at 2022-06-23 06:19:49.242241
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def test_play():
        return {
            'name': 'test',
            'connection': 'local',
            'hosts': 'all',
            'gather_facts': 'no',
        }
    p = test_play()
    b = load_list_of_blocks(None, p)
    assert len(b) == 0
    blocks = [{}, {}]
    b = load_list_of_blocks(blocks, p)
    assert len(b) == 2

# Generated at 2022-06-23 06:20:01.022489
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleError
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.module_utils._text import to_native
    from ansible.module_utils.six import string_types
    from ansible.plugins import module_loader
    import ansible.constants as C
    import json
    import sys
    import os

    class Options(object):
        """
        Options class fake ansible opts
        """

# Generated at 2022-06-23 06:20:04.611672
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # assertEquals(expected, load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list))
    raise NotImplementedError()


# Generated at 2022-06-23 06:20:11.508569
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    ds = [{"role": "foo"}, {"role":"bar"}]
    play = Play.load(ds, loader=DataLoader(), variable_manager=VariableManager())
    results = load_list_of_roles(ds=ds, play=play, loader=DataLoader(), variable_manager=VariableManager())
    for i in results:
        assert i._role_name == ds[0]["role"]
    assert(len(results) == 2)

# Generated at 2022-06-23 06:20:18.931156
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    # Adhoc task:
    task_ds = {
        'foo': 'bar'
    }

    # Block
    task_ds = {
        'block': [
            {
                'foo': 'bar'
            }
        ]
    }

    # Include
    task_ds = {
        'include': 'blah.yml'
    }
    # Include with when clause

# Generated at 2022-06-23 06:20:20.799094
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles({}, {})



# Generated at 2022-06-23 06:20:29.248277
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor

    tqm = TaskQueueManager(
                inventory=inventory,
                variable_manager=variable_manager,
                loader=loader,
                passwords=passwords,
                stdout_callback=results_callback,
            )


# Generated at 2022-06-23 06:20:38.285348
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def _get_loader():
        from ansible.parsing.dataloader import DataLoader
        return DataLoader()

    def _get_fixture(filename):
        return load_fixture_role(filename)

    def _get_roles_from_fixture(filename, current_role_path=None, loader=None, variable_manager=None):
        role_def = _get_fixture(filename)
        if not loader:
            loader = _get_loader()
        if not variable_manager:
            from ansible.vars.manager import VariableManager
            variable_manager = VariableManager()
        return load_list_of_roles(role_def, play=None, current_role_path=current_role_path, loader=loader,
                                  variable_manager=variable_manager)


# Generated at 2022-06-23 06:20:38.897735
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:20:40.318930
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # The function is not tested, it is just imported
    pass

# Generated at 2022-06-23 06:20:48.065617
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # We import here to prevent a circular dependency with imports
    import json
    import yaml
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role.definition import RoleDefinition
    # Set the directory of test files
    yaml_dir = C.DEFAULT_TEST_YAML_DIR
    json_dir = C.DEFAULT_TEST_JSON_DIR
    # Get the current working directory
    cwd = os.getcwd()

    for subdir, dirs, files in os.walk(yaml_dir):
        # Get the relative path from the top directory
        rel_path = os.path.relpath(subdir, yaml_dir)

# Generated at 2022-06-23 06:20:59.953954
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    This test is meant to be run manually, e.g.
    $ ansible-playbook run_tests.yml --tags load_list_of_tasks

    Run the following to display task output:
    $ pytest --capture=no
    '''
    import json
    import sys
    import os

    from unittest import TestCase
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import ansible.module_utils.common.removed
    import ansible.module_utils.facts
    import ansible.module_utils.basic
    import ansible.module_utils.urls
    import ansible.plugins.loader
   

# Generated at 2022-06-23 06:21:08.447315
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block


# Generated at 2022-06-23 06:21:14.977645
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    ds = [{'name':'roleA'}]
    roles = load_list_of_roles(ds)
    assert len(roles) == 1
    assert isinstance(roles[0], RoleInclude)
    assert roles[0].name == 'roleA'



# Generated at 2022-06-23 06:21:25.527599
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Basic unit test
    :return:
    '''
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import collection_loader, get_plugins

    import ansible.constants as C

    class FakeLoader():
        ''' fake loader class to test with '''
        basedir = 'foobase'

    fake_plugin = get_plugins('action')

    fake_plugin[C.DEFAULT_ACTION_PLUGIN_NAME] = C.DEFAULT_ACTION_PLUGIN_NAME
    fake_plugin[C.DEFAULT_ACTION_PLUGIN_NAME] = FakeModule()

    collection_loader.set_all(fake_plugin)

    test_data = """
    - role: 'common'
    """


# Generated at 2022-06-23 06:21:33.472698
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'tasks': [ {'include_tasks': "/path/foo.yml", 'static':True}]}]
    # We do not need to test all the functionality of the function.
    # Here we just test if we can run the function without error.
    try:
        load_list_of_tasks(ds, None, None, None, None, None, None, None)
    except:
        import traceback
        traceback.print_exc()
        assert False # We should not get here, if we do the test has failed.

test_load_list_of_tasks()


# Generated at 2022-06-23 06:21:35.277765
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: Implement
    pass

# Generated at 2022-06-23 06:21:37.700442
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play

    pass

# -----------------------------------------------------------------------------
# PLAYBOOK
# -----------------------------------------------------------------------------



# Generated at 2022-06-23 06:21:48.214873
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader

    fake_loader = DataLoader()
    fake_variable_manager = object()
    test_data = [
        {'hosts': 'localhost', 'gather_facts': False,
         'tasks': [{'name': 'foo', 'debug': 'var=hostvars'},
                   {'name': 'bar', 'debug': 'msg={{ 1 | fail }}'}]},
        {'hosts': 'localhost', 'gather_facts': False,
         'tasks': [{'name': 'foo', 'debug': 'var=hostvars'},
                   {'name': 'bar', 'debug': 'msg={{ 1 | fail }}'}]}
    ]
    play_ds = test_data

# Generated at 2022-06-23 06:21:54.806853
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    variable_manager = {'_raw_params':'test_action'}
    task_ds = [{'test_action':{}}]
    task_list = load_list_of_tasks(task_ds, variable_manager)
    assert isinstance(task_list[0], Task)

# Generated at 2022-06-23 06:22:01.737970
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task import Task
    assert(isinstance(load_list_of_tasks([{'name': 'copy', 'action': 'copy'}], None)[0], Task))
    assert(isinstance(load_list_of_tasks([{'include': 'role'}], None)[0], IncludeRole))



# Generated at 2022-06-23 06:22:12.022544
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DictDataLoader({
        '/etc/ansible/test_module.py': dict(
            path='/etc/ansible/test_module.py',
            data=dedent("""
            #!/usr/bin/python
            import os

            import ansible.module_utils.basic
            from ansible.module_utils.basic import *

            if __name__ == '__main__':
                main()
            """),
            mode=0o644)})
    inventories = [InventoryManager(loader=loader, sources='')]
    variable_manager = VariableManager(loader=loader, inventory=inventories[0])

# Generated at 2022-06-23 06:22:15.455515
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    #TODO: Implement unit test for function load_list_of_blocks
    pass



# Generated at 2022-06-23 06:22:25.178782
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.plugins.loader import add_all_plugin_dirs
    add_all_plugin_dirs()
    block_list = load_list_of_blocks([{
        'tasks': {
            'name': 'test'
        }
    }], Play(), None, None, task_include=TaskInclude(None, None, None), loader=None)

# Generated at 2022-06-23 06:22:26.222970
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert False, "No tests for this function yet"

# Generated at 2022-06-23 06:22:30.790565
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # ENABLE_COMPLEX_MOCK will bring in a bunch of extra mocking methods
    # but it won't pull in all possible imports
    from ansible.module_utils.six.moves import builtins
    from ansible.utils import context_objects
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.errors import AnsibleParserError
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.utils.addresses import parse_address

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.task import Task

# Generated at 2022-06-23 06:22:39.303392
# Unit test for function load_list_of_blocks

# Generated at 2022-06-23 06:22:48.302318
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    new_loader = DataLoader()
    new_play = Play()

    ds = [{
        "role": "test_role"
    },
    {
        "role": "test_role2",
        "scenario": "test_scenario",
        "tags": [
            "test_tag"
        ]
    }]

    res = load_list_of_roles(ds, new_play, variable_manager=VariableManager(), loader=new_loader)

    assert isinstance(res, list)
    assert isinstance(res[0], RoleInclude)
    assert isinstance(res[1], RoleInclude)



# Generated at 2022-06-23 06:22:57.333780
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    module_utils = '''
    def add(a, b):
        return a + b
    '''
    config_data = {'MODULE_UTILS': {'example.py': module_utils}}
    play_source =  dict(
            name = "Ansible Play",
            hosts = 'test_hosts_pattern',
            gather_facts = 'no',
            roles = [
                dict(name="test_role1",
                ),
                dict(name="test_role2",
                ),
                dict(name="test_role3",
                ),
            ],
        )
    variable_manager = VariableManager()
    loader = DataLoader()

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # This will set the role_path to ../roles/

# Generated at 2022-06-23 06:23:07.474346
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ###########################################################################
    # Load test data
    ###########################################################################
    file_name = os.path.join(os.path.dirname(__file__), "data/task_list.yml")
    with open(file_name, "rb") as f:
        data = yaml.safe_load(f)
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    ###########################################################################
    # Test Load list of tasks
    ###########################################################################

# Generated at 2022-06-23 06:23:10.420604
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
	print(load_list_of_tasks([{},{'action': 'an_action'}]))

# Generated at 2022-06-23 06:23:21.527308
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:23:32.783436
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.blocks import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude


# Generated at 2022-06-23 06:23:40.338357
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task.include import TaskInclude
