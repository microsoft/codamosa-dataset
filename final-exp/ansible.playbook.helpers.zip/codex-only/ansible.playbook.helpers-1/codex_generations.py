

# Generated at 2022-06-23 06:13:35.454257
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
# vim: set et ts=8 sts=4 sw=4 :

# Generated at 2022-06-23 06:13:45.693434
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.module_utils._text import to_text
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.template import Templar

    args = dict(
        block=None,
        loader=None,
        play=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=None,
    )
    args_parser = ModuleArgsParser(dict())

# Generated at 2022-06-23 06:13:57.582561
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    myplay = Play()
    myplay.play_hosts = None
    myplay.play_context = PlayContext()
    myplay.play_context._variable_manager = VariableManager()
    varmgr_dict = dict()
    myplay.play_context._variable_manager._varmgr_cache = varmgr_dict
    templar = Templar(loader=None,
                      shared_loader_obj=None,
                      variables=myplay.play_context._variable_manager.get_vars(play=myplay))
    myplay.play_context._variable_manager.set_templar(templar)
    myplay.play_context._tem

# Generated at 2022-06-23 06:14:08.094418
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    variable_manager = VariableManager(loader=loader)

    ds = [{'role': 'one', 'tasks': [{'debug': {'msg': '1'}}, {'debug': {'msg': '2'}}]},
          {'role': 'two', 'tasks': [{'debug': {'msg': '3'}}, {'debug': {'msg': '4'}}]},
          {'role': 'three', 'tasks': [{'debug': {'msg': '5'}}, {'debug': {'msg': '6'}}]}]

    play = MockPlayContext()
    play.vars = dict()
    play._variable_

# Generated at 2022-06-23 06:14:18.810630
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    from ansible.playbook.play import Play
    from ansible.playbook.playbook import PlayBook

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory

    from ansible.vars.manager import VariableManager
    from ansible.template import Templar

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager

# Generated at 2022-06-23 06:14:24.439263
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # test without a current_role_path
    host_vars = {}
    loader = DictDataLoader(host_vars)
    variable_manager = VariableManager(loader=loader)
    ds = [{'role': 'foo1'}, {'role': 'foo2'}]
    role_includes = load_list_of_roles(ds, None, variable_manager=variable_manager, loader=loader)
    assert len(role_includes) == 2
    assert role_includes[0]._role_name == 'foo1'
    assert role_includes[1]._role_name == 'foo2'

    # test with a current_role_path and relative role names
    ds = [{'role': 'foo1'}, {'role': '../foo2'}]
    role_includes = load_list_

# Generated at 2022-06-23 06:14:32.072534
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    loader = None
    variable_manager = None
    play = None
    parent_block=None
    role=None
    task_include=None
    use_handlers=False


# Generated at 2022-06-23 06:14:44.508628
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=['host'])
    def gethost(host):
        return inventory.get_host('host')
    options = Options()
    #Returns an empty list when the input is not a list
    assert load_list_of_tasks('x', None, None, None, None, None, None, None) == []
    #Returns an empty list when the input is None
    assert load_list_of_tasks(None, None, None, None, None, None, None, None) == []
    # Returns a list of task objects when the input is valid
    input = [{'name': 'test', 'implements': 'test'}]

# Generated at 2022-06-23 06:14:54.742324
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    loader = DataLoader()
    inv_data = """
    [all]
    localhost
    """
    inventory = InventoryManager(loader=loader, sources=[inv_data])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = Play()
    ds = [{'include': '1.yml'}, {'include': '2.yml'}]

# Generated at 2022-06-23 06:14:55.424322
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:15:05.426471
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable, AnsibleFileNotFound
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.config.manager import ConfigManager
    from ansible.template import Templar
    import os
    import shutil
    import tempfile
    import yaml
    import pytest
    #taken from the unit test file test_load_list_of_roles

# Generated at 2022-06-23 06:15:15.131277
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [{"action": "setup", "setup_task": True, "was_included": True},
               {"action": "include", "include_tasks": "tasks/sample.yml", "include_role": "sample",
                "include_variables": "vars/sample.yml", "include_vars": "vars/sample.yml"},
               {"action": "import_tasks", "import_tasks": "tasks/sample.yml", "import_role": "sample"},
               {"action": "include_role", "include_tasks": "tasks/sample.yml", "include_role": "sample"},
               {"action": "include", "include_tasks": "tasks/sample.yml"}]
    from ansible.playbook.play_context import PlayContext

# Generated at 2022-06-23 06:15:25.647198
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

# Generated at 2022-06-23 06:15:28.623874
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test the load_list_of_roles function
    """
    assert True


# Generated at 2022-06-23 06:15:41.868364
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play = Play().load({'name': 'test'})
    role = RoleDefinition()
    task_include = TaskInclude()
    vars_manager = None
    loader = None
    a = [
        {'block': 'block1'},
        {'task': 'task1'},
        {'block': 'block2'},
    ]
    b = [
        {'task': 'task1'},
        {'task': 'task2'},
    ]

# Generated at 2022-06-23 06:15:43.257891
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    raise NotImplementedError



# Generated at 2022-06-23 06:15:48.471105
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Run a series of test cases against the function load_list_of_blocks.
    '''
    # We import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    from units.mock.loader import DictDataLoader

    mock_loader = DictDataLoader({})

    # The tests for load_list_of_blocks() are in the test load_list_of_blocks_test().
    # go there for details.

    # GIVEN: a play with a simple block
    block_name = 'test_block'
    ds = [{block_name:[]}]
    play = Play().load({'name': 'test_play', 'hosts': 'all'}, loader=mock_loader)
    role = None

# Generated at 2022-06-23 06:15:58.096300
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    play_data = dict(
        name = 'test_load_list_of_roles',
        hosts = 'all',
    )
    p = Play().load(play_data, variable_manager=None, loader=None)
    ds_dup = [
        dict(
            name='test_role_1',
        ),
        dict(
            name='test_role_2',
        ),
    ]
    rls = load_list_of_roles(ds_dup, play=p)

# Generated at 2022-06-23 06:16:07.651729
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.vars.manager import VarsDict
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsVarsAggregate
    from ansible.playbook.play import Play
    from ansible.playbook.play import Playbook


# Generated at 2022-06-23 06:16:08.854046
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False # TODO: Implement your test here if you wish to




# Generated at 2022-06-23 06:16:23.612038
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager

    task_ds = []
    block_ds = []

    result = load_list_of_tasks(task_ds, Play(), block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert result == []
    result = load_list_of_tasks(block_ds, Play(), block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert result == []

    task_ds = [
        {'include': 'test_include.yml'},
        {'include': 'test_include.yml'},
    ]
    result = load_list_of_

# Generated at 2022-06-23 06:16:26.393331
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles([{'name':'test'}], None, None, None, None) == [ {'name': 'test'} ]


# Generated at 2022-06-23 06:16:29.207265
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([],None,None,None,None,None,None,None) == []
    assert True

# Generated at 2022-06-23 06:16:38.696965
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.playbook.task import Task
    class FakeLoader:
        pass
    class FakePlay:
        def __init__(self, variable_manager):
            self.variable_manager = variable_manager
    class FakeVariableManager:
        def get_vars(self, **kwargs):
            return {}
    class FakeTaskInclude:
        def __init__(self, role_name=None):
            self.role_name = role_name or 'include_role_name'
            self.loop = None

    class FakeBlock:
        pass
    class FakeIncludeRole:
        pass

    loader = FakeLoader()
    variable_manager = FakeVariableManager()
    play = FakePlay(variable_manager)
    block

# Generated at 2022-06-23 06:16:47.017259
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block

    loader = DataLoader()
    context = PlayContext()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-23 06:16:57.798272
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test different role format as in meta/main.yml
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_context import PlaybookContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import plugin_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    import json

    # Define original list of roles
    # Normal role format
    role1 = {'role1': 'test1'}

# Generated at 2022-06-23 06:17:00.892270
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Returns True if successful, False otherwise
    '''
    try:
        role_defs = [dict(role="geerlingguy.pip", pip_version="latest")]
        load_list_of_roles(role_defs, None)
    except:
        return False

    return True


# Generated at 2022-06-23 06:17:07.488886
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext

    def mock_load_from_file(self, path):
        return []


# Generated at 2022-06-23 06:17:18.791771
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.playbook import Playbook
    # load_list_of_blocks()
    playbook = Playbook.load('playbooks/test.yaml', loader=fake_loader)
    assert len(playbook.get_plays()) == 4
    playbook = Playbook.load('playbooks/test.yaml', loader=fake_loader, variable_manager=fake_variable_manager)
    assert len(playbook.get_plays()) == 4
    playbook = Playbook.load('playbooks/test.yaml', loader=fake_loader, variable_manager=fake_variable_manager)
    assert len(playbook.get_plays()) == 4
    playbook = Playbook.load('playbooks/test.yaml', loader=fake_loader, variable_manager=fake_variable_manager)

# Generated at 2022-06-23 06:17:28.977959
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DataLoader()
    coll_list = collections.Collections('test_collection', loader)
    coll_list.add_collection(collections.Collection('test_collection.test_role'))
    coll_list.add_collection(collections.Collection('test_collection.broken_role'))
    variable_manager = VariableManager(loader=loader)

    # #1: test RoleInclude.load with different parameters
    ds = [{'role': 'test_role'}]
    roles = load_list_of_roles(ds, play=None, current_role_path=None, variable_manager=variable_manager, loader=loader, collection_search_list=coll_list)
    assert isinstance(roles, list)
    assert len(roles) == 1
    assert roles[0].role.get_name()

# Generated at 2022-06-23 06:17:39.234736
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 06:17:50.074791
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    tasks_start = [{'include': 'foo.yml'}, "bar.yml", "baz.yml", {'name': 'foobar'}, {'name': 'foobaz'}]
    tasks_expected = [{'include': 'foo.yml'}, {'include': 'bar.yml'}, {'include': 'baz.yml'}, {'name': 'foobar'}, {'name': 'foobaz'}]

    # get the list of tasks in the block
    play = dict(
        hosts='all',
        roles=[],
        tasks=tasks_start,
        vars=dict(),
        post_tasks=dict(
            tasks=[],
            vars=dict(),
        ),
        handlers=[],
    )

    new_tasks, _ = load_list

# Generated at 2022-06-23 06:17:58.905786
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:18:07.311279
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    d = dict(
        name = "test_role1",
        when = "test_when",
        become = True,
        become_user = "test_user"
    )
    result = load_list_of_roles([d], None, None, None, None)
    assert len(result) == 1
    assert result[0].name == "test_role1"
    assert result[0].when == "test_when"
    assert result[0].become is True
    assert result[0].become_user == "test_user"



# Generated at 2022-06-23 06:18:18.541290
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    # do not test with None. invalid input
    data = None
    assert load_list_of_roles(data,None,None,None,None) is None

    data = {}
    assert load_list_of_roles(data,None,None,None,None) is None
    '''

    # valid inputs
    data = ['test1','test2','test3','test4']
    assert load_list_of_roles(data,None,None,None,None) == []

    data = ['test1','test2','test3','test4']
    assert load_list_of_roles(data,None,None,None,None) == []

    data = []
    assert load_list_of_roles(data,None,None,None,None) == []

    data = {}
   

# Generated at 2022-06-23 06:18:24.839902
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [
        {'role': 'role1'},
        {'role': 'role2'}
    ]
    play = object()

    roles = load_list_of_roles(ds, play, variable_manager=None, loader=None)
    assert isinstance(roles, list)
    assert roles[0]._role_name == 'role1'
    assert roles[1]._role_name == 'role2'



# Generated at 2022-06-23 06:18:35.425307
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  play = dict(
    name='ansible.builtin.ping',
    vars_prompt=dict()
  )
  block = None
  role = None
  use_handlers = False
  task_include = None
  loader=None
  variable_manager=None
  ds=dict(
    name='test',
    module='test',
    args=dict()
  )
  #task = Task.load(ds,block,role,task_include,variable_manager,loader)
#  task_list = load_list_of_tasks(ds, block, role, task_include, use_handlers, variable_manager, loader)
  print(task_list)



# Generated at 2022-06-23 06:18:36.952539
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:18:46.052634
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    A testcase for load_list_of_tasks
    '''

    def test_action(action, result_count, assert_msg='Test action '):
        '''
        :type action: str
        :type result_count: int
        :type assert_msg: str
        :rtype: None
        '''

        # run the test
        ds = dict(action=dict(module=action))
        task_list = load_list_of_tasks([ds], None, None, None, None)

        # check result
        assert len(task_list) == result_count, assert_msg + action


# Generated at 2022-06-23 06:18:58.154935
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition

    play = Play().load({
        'name': 'test',
        'hosts': 'all',
        'roles': [
            {'role': 'foo'},
            {'role': 'bar', 'include_role': dict(name='foo')},
            {'role': 'baz'}
        ]
    }, variable_manager=None, loader=None)

    assert len(play.roles) == 3

    role = play.roles[0]
    assert isinstance(role, RoleDefinition)
    assert role.role_name == 'foo'
    assert role.include_role is None

    role = play.roles[1]
    assert isinstance(role, RoleDefinition)

# Generated at 2022-06-23 06:19:06.076204
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Test load_list_of_tasks function with a list of tasks
    '''
    test_tasks = [
        'debug: var=vars["test_var"]',
        'include: other_test.yaml',
    ]
    test_results = load_list_of_tasks(test_tasks, play=None)
    results_count = len(test_results)
    assert results_count == 2

    for i in range(results_count):
        if i == 0:
            assert hasattr(test_results[i], 'args')
            assert test_results[i].action == 'debug'
            assert test_results[i].args.get('var') == 'vars["test_var"]'

# Generated at 2022-06-23 06:19:07.940333
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:19:15.869286
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # establish a play context
    p = Play()
    # establish a current_role_path context
    r = Role()
    # establish a loader to find the roles

# Generated at 2022-06-23 06:19:25.771470
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test the load_list_of_tasks function
    result = load_list_of_tasks(ds=[{'action': {'module': "copy", 'args': 'foo'}},
                                     {'include_tasks': 'foo'},
                                     {'include': 'bar'}])
    assert(isinstance(result[0], Task.Task))
    assert(isinstance(result[1], TaskInclude.TaskInclude))
    assert(isinstance(result[2], TaskInclude.TaskInclude))

    # Test for misordered block and action

# Generated at 2022-06-23 06:19:32.177146
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()

    rolemeta = RoleMetadata()
    rolemeta.name = "myrolename"
    rolemeta.path = "/mypath"
    roles = load_list_of_roles([{"role": "myrolename", "mapping": {}, "with_item": "myitem"}], play=Play(), current_role_path=None,
                                variable_manager=variable_manager, loader=loader, collection_search_list="")

# Generated at 2022-06-23 06:19:43.068512
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    in_file = './test_playbook_files/simple_playbook.yml'
    name = in_file
    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 06:19:52.886447
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    empty_vars = {}
    empty_vars_pre = {}
    empty__fact_cache = {}
    mock_play_context = PlayContext()
    mock_inventory = InventoryManager(empty_vars,
                                      empty__fact_cache,
                                      mock_play_context.search_path,
                                      mock_play_context.passwords)
    mock_variable_manager = VariableManager(loader=None, inventory=mock_inventory)
    test_loader = DictDataLoader(dict())
    test_data = [{'name': 'test'}]


# Generated at 2022-06-23 06:20:02.399506
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Load list of blocks test
    '''
    ds = [{'block': 'a', 'tasks': 't1'}, {'block': 'b', 'tasks': 't2'}, {'block': 'c', 'tasks': 't3'}, {'block': 'd', 'tasks': 't4'}]
    bl = load_list_of_blocks(ds)
    assert bl[0].block is not None and bl[0].name == 'a'
    assert bl[1].block is not None and bl[1].name == 'b'
    assert bl[2].block is not None and bl[2].name == 'c'
    assert bl[3].block is not None and bl[3].name == 'd'


# Generated at 2022-06-23 06:20:04.259249
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # TODO: mock out needed functions to test this
    pass

# Generated at 2022-06-23 06:20:14.754564
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test module_args_parser.py
    from ansible.playbook.task import Task
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({})

    class VM(object):
        def __init__(self, keywords=None):
            self.keywords = keywords

        def get_vars(self, *args, **kwargs):
            return self.keywords

    ds = [{'block': 'tagged block'}, {'tags': ['tag1', 'tag2'], 'action': 'include_tasks'}]

    block = Task()
    block.vars = VM(keywords={'test': 'var'})
    block.tags = ['tag1', 'tag2']

# Generated at 2022-06-23 06:20:23.810714
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager, ensure_type

    ds = ensure_type([{
        'role': 'geerlingguy.git',
        'version': '1.0.0'
    }, {
        'role': 'geerlingguy.apache',
        'version': 'latest',
        'default_version': '2.0.2'
    }])

    play = Play().load({}, loader=MockLoader())
    roles = load_list_of_roles(ds, play=play, variable_manager=VariableManager())
    assert len(roles) == 2
    assert roles[0].name == 'geerlingguy.git'
    assert roles[0].src == 'geerlingguy.git'

# Generated at 2022-06-23 06:20:35.116190
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import unittest
    import tempfile
    import shutil
    import os
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.include import RoleInclude
    from ansible.plugins.loader import plugin_loader
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.constants import DEFAULT_VAULT_ID_MATCH
    from ansible.template import Templar
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.utils.path import unfrackpath


# Generated at 2022-06-23 06:20:41.199387
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'role': 'example1'}, {'role': 'example2'}]
    roles = load_list_of_roles(ds)
    assert len(roles) == 2
    assert roles[0].name == 'example1'
    assert roles[1].name == 'example2'
# test case for load_list_of_roles: role names from collections

# Generated at 2022-06-23 06:20:42.000135
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass


# Generated at 2022-06-23 06:20:46.922545
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    mock_ds = [{'name': 'role1'}, {'name': 'role2'}]
    mock_play = FakePlay()

    roles = load_list_of_roles(mock_ds, mock_play)

    assert roles[0]._role_name == 'role1'
    assert roles[1]._role_name == 'role2'


# Generated at 2022-06-23 06:20:58.876817
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    loader = AnsibleLoader()
    variable_manager = VariableManager()
    # Ok, the first thing we should do is read the YAML into the tasks list
    # and look for the 'include' statement
    # Using a resource file to handle YAML parsing

    # First we need to know if the play is static or dynamic
    # and if it has any loops.  This is determined by the block
    # parent of the task

# Generated at 2022-06-23 06:21:07.604470
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Example:
    - name: Some Role
      include_role:
        name: my_role
        apply:
          some_var: foo
        tasks_from: somefile
      loop: "{{ my_list }}"
    '''
    data = dict(
        name="Some Role",
        include_role=dict(
            name="my_role",
            apply=dict(
                some_var="foo"
            ),
            tasks_from="somefile"
        ),
        loop="{{ my_list }}"
    )

    class TestPlay(object):
        pass

    play = TestPlay()
    loader = DictDataLoader(dict())
    roles = load_list_of_roles([data], play=play, loader=loader)
    assert len(roles) == 1

# Generated at 2022-06-23 06:21:19.514661
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
        Unit test for function load_list_of_tasks
    '''
    import __main__
    __main__.display = Display()

    test_host = Mock()
    test_host.get_vars.return_value = dict(test_host_var='test_host_value')
    test_host.name = 'test_host'

    test_group = Mock()
    test_group.get_vars.return_value = dict(test_group_var='test_group_value')
    test_group.name = 'test_group'

    test_play = Mock()
    test_play.get_vars.return_value = dict(test_play_var='test_play_value')
    test_play.get_hosts.return_value = ['test_host']
    test_play

# Generated at 2022-06-23 06:21:20.019372
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:21:21.585876
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # assertion: to have a list of task or a list of task_include object
    pass

# Generated at 2022-06-23 06:21:29.778830
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.playbook.task import Task
    test_module_args = ModuleArgsParser.args_to_dict(args=[])
    test_play = Play()

# Generated at 2022-06-23 06:21:40.124820
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    from ansible.playbook.play_context import PlayContext
    from ansible.config.manager import ensuredir
    from ansible.collection_loader import AnsibleCollectionNotFound
    import os

    class MockPlay(object):
        def __init__(self, tqm):
            self._variable_manager = tqm.variable_manager


# Generated at 2022-06-23 06:21:51.780223
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.unsafe_proxy import wrap_var
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVarsGroup
    from ansible.errors import AnsibleError
    from ansible.parsing.vault import VaultLib
    from ansible.utils.vars import combine_vars
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.display import Display
    from ansible.utils.unicode import to_bytes

# Generated at 2022-06-23 06:22:01.355765
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play

    assert load_list_of_blocks(ds=[{"block": "yes", "name": "name"}, {"block": "yes"}, {"task": "yes"}], play=Play()) == [
        Block(ds={"block": "yes", "name": "name"}, play=Play()),
        Block(ds={"block": "yes"}, play=Play()),
        Block(ds={"task": "yes"}, play=Play()),
    ]


# Generated at 2022-06-23 06:22:11.743081
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    if not isinstance(ds, list):
        raise AnsibleAssertionError('The ds (%s) should be a list but was a %s' % (ds, type(ds)))

    task_list = []

# Generated at 2022-06-23 06:22:23.732186
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    class FakeOptions(object):
        def __init__(self):
            self.connection = 'local'
            self.module_path = None
            self.forks = 10
            self.become = None
            self.become_method = None
            self.become_user = None
            self.check = False
            self.diff = False

    p = Play()
    i = InventoryManager(loader=DataLoader())
    v = VariableManager(loader=DataLoader(), inventory=i)
    c = PlayContext(remote_user='root', become_user='root')
    o = Fake

# Generated at 2022-06-23 06:22:29.312213
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'role': 'test'}]
    play = Mock()
    current_role_path = None
    variable_manager = Mock()
    loader = Mock()
    collection_search_list = Mock()
    result = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert isinstance(result, list)



# Generated at 2022-06-23 06:22:40.566899
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.role_include import IncludeRole

    yaml_data = [
        dict(
            action="include_tasks",
            args=dict(
                _raw_params="foo.yaml",
            ),
            delegate_to="{{foo_delegate_to}}",
        ),
        dict(
            action="include_role",
            args=dict(
                name="foo",
                tasks_from="bar",
            ),
        ),
        dict(
            action="debug",
            args=dict(
                msg="hello world",
            ),
        ),
    ]


# Generated at 2022-06-23 06:22:52.949162
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager)
    play = Play.load({}, variable_manager=variable_manager, loader=loader, inventory=inventory)

    # Load a role with all the different possible parameters
    role_def = dict(name="myrole", collections=["myns.mycoll", "myns.mycoll2"], included_in=['main'])
    role = load_list_of_roles([role_def], play)[0]
    assert role

# Generated at 2022-06-23 06:22:58.069136
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    res = load_list_of_blocks()
    assert isinstance(res, list)
    assert len(res) == 0
    assert res == []

    # todo: mock all the things



# Generated at 2022-06-23 06:23:07.838737
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    # test load_list_of_tasks wrapped around my own list of tasks
    #play = Play().load(play_ds, variable_manager=variable_manager, loader=loader)
    ds = [{'debug': 'msg={{ item }}'},{'debug': 'var=omg'}]
    task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(task_list, list)
    assert len(task_list) == 2

# Generated at 2022-06-23 06:23:20.090287
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.plugins.loader import role_loader
    from ansible.vars.manager import VariableManager

    fake_loader = DictDataLoader({})
    variable_manager = VariableManager()

    mock_collection = MagicMock()
    mock_collection.get_role_path.return_value = 'lib/ansible/roles/mock_collection/mock/role'

    role_loader.add('mock_collection', 'mock.role', mock_collection)


# Generated at 2022-06-23 06:23:32.118423
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    import ansible.constants as C
    import os
    import yaml
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import filter_loader
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.facts import is_group
    from ansible.Playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from __main__ import display
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-23 06:23:38.206350
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, callback_loader
    import pytest
    import os

    fake_loader = DataLoader()
    context = PlayContext()
    context.connection = 'local'
    inventory = InventoryManager(loader=fake_loader, sources=[os.path.join(os.path.dirname(__file__), 'inventory')])
    inventory._set_hosts_cache()
    inventory.clear_pattern_cache()

    play_source