

# Generated at 2022-06-23 06:13:45.302236
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Test that load_list_of_blocks throw exception when a list of mixed task/block is empty
    # On contrary, it should throw an assertion error
    # Reference issue: https://github.com/ansible/ansible/issues/32444
    from ansible.playbook.block import Block

    input_data = []
    ds = input_data[2]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # Condition to test if assertion error is thrown with empty list

# Generated at 2022-06-23 06:13:57.210554
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.constants as C
    from ansible.playbook.play_context import PlayContext

    # requires a play to load the role, as well
    from ansible.playbook.play import Play

    # invalid - must supply a list of roles
    res = load_list_of_roles(0, Play())
    assert res is None

    # invalid - must supply a Play object, not a string
    res = load_list_of_roles([], "")
    assert res is None

    # invalid - not a role definition
    res = load_list_of_roles([{'invali': 0}], Play())
    assert res is None

    # invalid - role name must be specified
    res = load_list_of_roles([{'name': 0}], Play())
    assert res is None

    #

# Generated at 2022-06-23 06:14:07.776555
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    print("Unit test for function load_list_of_tasks")
    failure_count = 0
    try:
        load_list_of_tasks("string_not_list", None)
    except AnsibleAssertionError as e:
        pass
    except Exception as e:
        print("Unit test load_list_of_tasks with string as input 1 failed")
        print("Reason: " + str(e))
        failure_count += 1
    try:
        load_list_of_tasks({'dict_not_list': 1}, None)
    except AnsibleAssertionError as e:
        pass
    except Exception as e:
        print("Unit test load_list_of_tasks with dict as input 1 failed")
        print("Reason: " + str(e))
        failure_count += 1

# Generated at 2022-06-23 06:14:16.137458
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{"include_tasks": "file.yml"}, {"block": "block.yml"}]
    # TODO: well, import ansible.playbook.task_include is a bad idea, we should fix it.
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    assert load_list_of_tasks(ds, None, None, None, None, None, None, None) == [TaskInclude({"include_tasks": "file.yml"}), Block({"block": "block.yml"})]

# Generated at 2022-06-23 06:14:23.628334
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook

# Generated at 2022-06-23 06:14:31.704461
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.callback_plugins import v2_0_

# Generated at 2022-06-23 06:14:37.527998
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles(None, None) == None
    assert load_list_of_roles("   ", None) == None
    assert load_list_of_roles("", None) == None
    assert load_list_of_roles({}, None) == None
    assert load_list_of_roles("a", None) == None



# Generated at 2022-06-23 06:14:46.334418
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
   result_list = load_list_of_blocks(['a', {'b': 'c'}, 'd', {'e': 'f'}, 'g'])
   assert len(result_list) == 5
   assert result_list[0].block == ['a']
   assert result_list[1].block == {'b': 'c'}
   assert result_list[2].block == ['d']
   assert result_list[3].block == {'e': 'f'}
   assert result_list[4].block == ['g']


# Generated at 2022-06-23 06:14:55.962782
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    # ini file path
    ini_file = 'tests/unit/test_include_role/test_inventory'
    # ini file for dynamic inventory
    inventory = InventoryManager(loader=DataLoader(), sources=[ini_file])
    # hosts in dynamic inventory
    hosts = inventory.get_hosts()
    # The host which contains vars
    host = hosts[0]
    # vars for the host
    vars = host.get_vars()
    # constructor
    vm = VariableManager(loader=DataLoader(), inventory=inventory)
    # assign vars to vm
    vm.set_host_variable(host, vars)
    # path

# Generated at 2022-06-23 06:15:05.630283
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C
    ds_diff = [
        {'name': 'first block'},
        {'name': 'one task'},
        {'name': 'second task'},
        {'name': 'second block'},
        {'name': 'one task'},
    ]
    hostvars = dict(foo='bar')

    play_ds = dict(
        name='foobar',
        hosts='all',
        gather_facts='no',
        roles=['role1'],
    )

    play = Play.load(play_ds, variable_manager=VariableManager(), loader=DataLoader())


# Generated at 2022-06-23 06:15:15.167217
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Make sure load_list_of_blocks parses lists and returns a list of Block objects
    '''
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    # Test 1 very simple list
    ds = [{"some":"data"}]
    block_list = load_list_of_blocks(ds=ds, play=Play().load({}, loader=None, variable_manager=None), parent_block=None)
    assert isinstance(block_list, list)
    assert isinstance(block_list[0], Block)

    # Test 2 very simple list with a task
    ds = [{"some":"data"}, {"task":"data"}]

# Generated at 2022-06-23 06:15:21.238641
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #
    # setup args
    #
    collection_search_list = None

    #
    # start mocks
    #
    # mock vars of Play
    class Play_Vars(object):
        def __init__(self):
            self.vars = {
                'foo': 'bar',
                'bat': 'baz'
            }
            self.secret_vars = {
                'foo_secret': 'bar_secret',
                'bat_secret': 'baz_secret',
                '_secret': '_secret'
            }

    # mock loader of Play
    class Play_Loader(object):
        def __init__(self):
            pass

        def path_dwim(self, foo):
            return 'Fake_path' + foo

    # mock Play

# Generated at 2022-06-23 06:15:24.311555
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    for role in load_list_of_roles([{'name':'foo'}, {'name':'bar'}], None):
        assert role._role_name == 'foo' or role._role_name == 'bar'


# Generated at 2022-06-23 06:15:31.259610
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # ds: The dictionary of tasks.
    # play: The play object.
    # block: The parent block object.
    # role: The parent role object if applicable.
    # task_include: The parent task_include object if applicable.
    # use_handlers: If true, use Handler objects.
    # variable_manager: The variable manager object.
    # loader: The data loader object.

    # TODO: Write unit tests for this module
    pass

# Execute the tasks from the task_list

# Generated at 2022-06-23 06:15:42.957408
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.role_include import IncludeRole

# Generated at 2022-06-23 06:15:48.430253
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.template import Templar
    from ansible.vars import VariableManager

    assert load_list_of_tasks(ds=None, play=None) == []
    assert load_list_of_tasks(ds=dict(), play=None) == []
    assert load_list_of_tasks(ds=[], play=None) == []
    assert load_list_of_tasks(ds="", play=None) == []

    assert isinstance(load_list_of_tasks(ds=[dict()], play=None)[0], TaskInclude)
    # TODO.
    #

# Generated at 2022-06-23 06:15:49.095964
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:15:58.439111
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    AppVeyor doesn't have the bash executable, which is required by the
    `qurz_package.yml` fixture. Use a different file instead.
    """
    if 'APPVEYOR' in os.environ:
        fixture_file = os.path.join(os.path.dirname(__file__), 'fixtures', 'package_github.yml')
    else:
        fixture_file = os.path.join(os.path.dirname(__file__), 'fixtures', 'package_local.yml')
    with open(fixture_file) as f:
        package_data = yaml.load(f, Loader=yaml.FullLoader)

    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 06:16:07.818689
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    load_list_of_roles() test case.

    This is a regression test for:
    https://github.com/ansible/ansible/issues/26672
    '''
    # To reproduce the issue, the loader object must be patched
    import ansible.plugins.loader
    real_loader = ansible.plugins.loader.get

    ansible.plugins.loader.get = lambda *args, **kwargs: None


# Generated at 2022-06-23 06:16:22.476945
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' `ds` below contains:
            - A list of roles to be loaded
                - Each role contains:
                    - name of the role
                    - list of tasks to be run
                    - any associated vars with the role
    '''

    # FIXME: extremely poor test implementation

# Generated at 2022-06-23 06:16:33.971199
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    block = {
        'block': [
            {
                'block': [
                    {'task': {'meta': 'empty'}},
                    {'task': {'name': 'inner'}}
                ]
            },
            {'task': {'name': 'outer'}}
        ]
    }

    blocks = load_list_of_blocks(block['block'], None)
    assert len(blocks) == 2, "There should be 2 blocks"
    assert all(isinstance(b, Block) for b in blocks), "All items should be a block"
    assert len(blocks[0].block) == 2, "The first block should have 2 elements"
    assert len(blocks[1].block) == 1, "The second block should have 1 element"



# Generated at 2022-06-23 06:16:44.730016
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    import ansible.constants as C

    loader = DataLoader()
    options = {'connection': 'local', 'module_path': '', 'forks': 10, 'become': None, 'become_method': None, 'become_user': None, 'check': False, 'diff': False}
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')

# Generated at 2022-06-23 06:16:54.010945
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='')
    play_context = PlayContext(variable_manager=variable_manager)

    # Empty list
    ds = []
    role = Role().load({}, loader=loader, variable_manager=variable_manager)
    block_list = load_list_of_blocks(ds=ds, play=None, parent_block=None, role=role, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)
    assert len(block_list) == 0

    # None
    ds = None

# Generated at 2022-06-23 06:17:01.341455
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Loads and returns a list of RoleInclude objects from the ds list of role definitions
    '''
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.role.include import RoleInclude
    config = [
        {
            "name": "test_role",
            "path": "/path/to/test_role",
            "scm": "git",
            "scm_url": "https://github.com/ansible/ansible-test-role.git",
            "scm_branch": "mybranch",
            "scm_path": "path/to/dir",
            "version": "v1.2"
        }
    ]

# Generated at 2022-06-23 06:17:07.967307
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.inventory import Inventory
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.utils.vars import combine_vars
    import os
    import tempfile
    import shutil
    import json
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.path import unfrackpath

    INVENTORY_PATH = os.path.join(unfrackpath(__file__), '../data')


# Generated at 2022-06-23 06:17:20.075288
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play_context = PlayContext()
    fh, temp_path = tempfile.mkstemp()
    task_ds = dict(action=dict(module='shell', args="echo the test command"))
    task_ds2 = dict(action=dict(module='shell', args="echo the test command2"))
    task_ds_list = [task_ds, task_ds2]
    args_parser = ModuleArgsParser(task_ds)
    (action, args, delegate_to) = args_parser.parse(skip_action_validation=True)
    task = Task()
    task._ds = task_ds
    task._role = None
    task._parent = None
    play = Play()
    play._included_file = None
    play._loader = DataLoader()
    play._variable_manager = VariableManager()
    task

# Generated at 2022-06-23 06:17:21.982019
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # load_list_of_tasks(self, ds, block=None, role=None, task_include=None, variable_manager=None, loader=None)
    pass

# Generated at 2022-06-23 06:17:32.794693
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test the normal scenario
    ds_list = [{'block': 'block1', 'local_action': 'local_action1'}, {'block': 'block2', 'local_action': 'local_action2'}]
    assert load_list_of_tasks(ds_list, None, None, None, None) != None
    # Test empty dataset
    ds_list = []
    assert load_list_of_tasks(ds_list, None, None, None, None) != None
    # Test the dataset is not a list
    ds_list = {}
    assert load_list_of_tasks(ds_list, None, None, None, None) != None

# Generated at 2022-06-23 06:17:41.353548
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from pprint import pprint
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    p = Play.load(
        dict(
            name="test",
            hosts="all",
            gather_facts="no",
            tasks=[
                dict(action=dict(module="test", args=dict(test_key="test_value"))),
                dict(action=dict(module="test", args=dict(test_key="test_value2"))),
            ],
        ),
        variable_manager=VariableManager(loader=DataLoader()),
        loader=DataLoader(),
    )
    print(p)
    print(p.tasks)


# Generated at 2022-06-23 06:17:42.071549
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:17:47.075046
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    play = Mock()
    play.roles = dict()
    varmgr = Mock()
    loader = Mock()
    ds = [{'role': 'foo'}]
    assert load_list_of_roles(ds, play, current_role_path=None, variable_manager=varmgr, loader=loader, collection_search_list=None)

# Generated at 2022-06-23 06:17:57.202498
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode
    # Create a play, loader and variable
    play = Play.load(dict(name='testing',
                          hosts=['localhost'],
                          gather_facts='no',
                          connection='local',
                          roles=[],
                          tasks=[{'name': 'foobar', 'action': 'test', 'args': {'a': 'b'}}]
                          ), variable_manager=None, loader=None)


# Generated at 2022-06-23 06:18:09.008681
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import ROLE_CACHE
    from ansible.collections.search import AnnotatedRoleDefinition

    test_collection_spec = dict(
        name='good_collection',
        namespace=None,
        version=1,
    )
    test_role_name = 'test_role'
    test_role_spec = dict(
        name=test_role_name,
        namespace=None,
        version=1,
    )
    test_role_def_data = dict(
        defaults=dict(test_role_default='default_value'),
        meta=dict(test_role_meta='meta_value'),
        tasks=dict(test_role_task='task_value'),
    )

# Generated at 2022-06-23 06:18:09.550861
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: test this
    pass



# Generated at 2022-06-23 06:18:20.705223
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def _test_load_list_of_roles(role_list, play, current_role_path, variable_manager,
                                 collection_search_list, expected):
        actual = load_list_of_roles(role_list, play, current_role_path, variable_manager,
                                    None, collection_search_list)
        assert len(actual) == len(expected)
        for ri, i in zip(actual, expected):
            assert ri.get_name() == i

    # Test case 1: ensure each items in the list of roles are correctly parsed into
    # RoleInclude objects.
    test_case = load_fixture('test_load_list_of_roles_1.yml')
    the_play = type('play', (object,), {})()

# Generated at 2022-06-23 06:18:22.881463
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert issubclass(type(load_list_of_blocks({},'play')), list)

# Generated at 2022-06-23 06:18:36.040882
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def mock_block_load(task, *args, **kwargs):
        return {'task': task}
    Block.load = mock_block_load

    ds = [
            {'block': 'A'},
            {'command': 'task A'},
            {'block': 'B'},
            {'command': 'task B'},
            {'command': 'task B'},
    ]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False

    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()

# Generated at 2022-06-23 06:18:45.643241
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.utils.vars import combine_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}
    loader = DictDataLoader({})
    play_context = PlayContext()

# Generated at 2022-06-23 06:18:47.272512
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:18:58.437669
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

    yaml_1 = '''
        - hosts: localhost
          tasks:
            - name: test 1
              ping:
            - include_tasks: "testing.yml"
              static: yes
            - import_role:
                name: testrole
                static: yes
            - name: test 2
              ping:
            - handlers:
              - name: test 3
                ping:
    '''
    play_ds = AnsibleParser(yaml_1)
    task_list = load_list_of_tasks(play_ds.data['tasks'], play=None)
    assert len(task_list) == 5
    assert type(task_list[0]) == Task
    assert task_

# Generated at 2022-06-23 06:19:09.854630
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible import context
    import os
    import pytest

    pm = Play()
    assert (isinstance(pm, Play))

    inv_manager = InventoryManager(loader=DataLoader(), sources="localhost")
    assert (isinstance(inv_manager, InventoryManager))

    v_manager = VariableManager(loader=DataLoader(), inventory=inv_manager)
    assert (isinstance(v_manager, VariableManager))


# Generated at 2022-06-23 06:19:20.305246
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:19:29.079905
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play

    assert isinstance(load_list_of_blocks([{'block': []}], Play()), list)

    # A bare task in a list of blocks is an implicit block
    assert isinstance(load_list_of_blocks([{'task': {}}], Play())[0], Block)

    # An empty list is returned as None
    assert load_list_of_blocks(None, Play()) is None
    assert load_list_of_blocks([], Play()) == []

    # Nested blocks should stay nested
    nested_block = load_list_of_blocks([{'block': [{'task': {}}, {'block': []}]}], Play())[0]
    assert isinstance

# Generated at 2022-06-23 06:19:32.577377
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    def get_test_block(test_name):
        block_ds = [{'block': [
            [{'include': 'test2', 'name': 'test2'}]]},
            {'include': test_name, 'name': test_name}]
        return (block_ds, {'include': test_name, 'name': test_name})
    block_ds, expected_block_ds = get_test_block('test')
    assert block_ds == expected_block_ds



# Generated at 2022-06-23 06:19:33.524788
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:19:48.833843
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.plugins.loader import role_loader, get_collection_loader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.cli.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    basedir = 'test/list_roles_loader_fixtures'
    host_list = ['localhost']
    data = {
        'playbook_path': 'playbook.yml',
        'hosts': host_list,
        'vars': {},
        'gather_facts': 'no'
    }
    loader = DataLoader()
    vars_manager = VariableManager()

# Generated at 2022-06-23 06:19:56.024903
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Set up
    from ansible.utils.vars import combine_vars
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.playbook.task import dict_to_task
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    ds = [
        dict(
            name="geerlingguy.php",
            vars=dict(
                foo="bar",
                baz="{{ bam }}"
            )
        ),
        AnsibleUnsafeText('geerlingguy.php'),
    ]

    vars_manager = VariableManager()
    vars_manager._extra_vars = dict(bam="bat")
    loader = DataLoader

# Generated at 2022-06-23 06:20:08.503223
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = {'include': 'filename'}
    _, task_list = load_list_of_tasks(task_ds, play=None, block=None, role=None, task_include=None,
                                      use_handlers=False, variable_manager=None, loader=None,)
    assert isinstance(task_list, list)
    assert isinstance(task_list[0], TaskInclude)
    assert task_list[0]._task_name == 'INCLUDE'

    task_ds = {'import_tasks': 'filename'}
    _, task_list = load_list_of_tasks(task_ds, play=None, block=None, role=None, task_include=None,
                                      use_handlers=False, variable_manager=None, loader=None,)

# Generated at 2022-06-23 06:20:16.902202
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    This function tests load_list_of_roles function in ansible/playbook/__init__.py
    '''
    # Create a collection object
    mc = AnsibleCollectionRef()
    # Create a list of collections
    collection_list = [mc]

    # Create a loader object
    loader = DataLoader()
    # Create a variable manager object
    variable_manager = VariableManager()
    # Create a play object
    play = Play()
    # Create a dict to test the function
    ds = [{"role": "role_test"}, {"role": "role_test2"}]
    # Create a list of roles
    roles = load_list_of_roles(ds, play, current_role_path=None, variable_manager=variable_manager, loader=loader, collection_search_list=collection_list)

# Generated at 2022-06-23 06:20:24.882155
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    ds = ['ds1', 'ds2']
    try:
        load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    except AnsibleAssertionError as e:
        assert e.message == 'The ds (%s) should be a dict but was a %s' % (ds, type(ds))

    ds = {'block': 'block'}

# Generated at 2022-06-23 06:20:35.760602
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    display = Display()
    ansible = Ansible()
    ansible.verbosity = 0
    ansible.callbacks = PlaybookCallbacks(verbose=ansible.verbosity)
    ansible.groups = Groups()
    ansible.hosts = Hosts()

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='setup', args=dict()), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    )

    # Create play object, based on play_source

# Generated at 2022-06-23 06:20:41.351030
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler

    task_list = [
        {'include_tasks': 'task/main.yml'},
        {'import_tasks': 'task/main.yml'},
        {'include': 'task/main.yml'}
    ]

    task_list_with_block = {'block': task_list}

    task_list_without_block = [{'include': 'task/main.yml'}, {'include': 'task/main.yml'}]

    # Load list of tasks with block
    task_result = load

# Generated at 2022-06-23 06:20:52.768775
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load({}, variable_manager=variable_manager, loader=loader)
    parent_block = Block(play=play)
    task_ds = {
        'action': 'fake',
        'name': 'fake2',
    }
    task = Task()
    task.action = 'fake'
    task.name = 'fake2'
    task.task_include = None
    task.role = None
    task.use_handlers

# Generated at 2022-06-23 06:21:02.738386
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    ds = dict()
    play = dict()
    block = dict()
    role = dict()
    task_include = dict()
    use_handlers = False
    variable_manager = dict()
    loader = dict()

    # If ds is not a list,then an AnsibleAssertionError will be throwed

# Generated at 2022-06-23 06:21:09.017282
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    play = Play().load({
        'name': 'test',
        'hosts': 'all',
        'gather_facts': 'no',
        'tasks': [
            {'debug': 'msg="{{test}}"'},
            {'block': [{'debug': 'msg={{item}}'},
                       {'loop': '{{test_list}}'}]},
            {'debug': 'msg="{{foo}}"'},
        ]
    }, variable_manager=VariableManager())

    loader = DataLoader()

# Generated at 2022-06-23 06:21:19.702673
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    This is a unit test for function load_list_of_tasks
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.template import AnsibleUndefinedVariable
    from ansible.template import AnsibleAssertionError

    # TODO: setup the class and run the test
    # play =
    # block =
    # loader =
    # variable_manager =
    # role =
    # task_include =
    # use_hand

# Generated at 2022-06-23 06:21:23.529763
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    x = load_list_of_roles(["/a/b/c","/d/e/f"], '/tmp/play')
    assert x[0]._role_name == "/a/b/c"
    assert x[1]._role_name == "/d/e/f"

# Generated at 2022-06-23 06:21:34.081971
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import unittest
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader, callback_loader
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_result import TaskResult
    from ansible.plugins.callback import CallbackBase

    class MyCallback(CallbackBase):
        """
        A sample callback plugin used for performing an action as results come in
        """

# Generated at 2022-06-23 06:21:41.559442
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handlers.task import Task as HandlerTask
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    load_list_of_blocks(["name: foo"],play)

# Generated at 2022-06-23 06:21:42.223967
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:21:54.414165
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    # Test to see if all objects are created

# Generated at 2022-06-23 06:22:07.388741
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
        {
            'name': 'test A',
            'action': 'setup'
        },
        {
            'block': [
                {
                    'name': 'test B',
                    'action': 'setup'
                },
                {
                    'name': 'test C',
                    'action': 'setup'
                }
            ]
        },
        {
            'block': {
                'name': 'test D',
                'block': [
                    {
                        'name': 'test D1',
                        'action': 'setup'
                    },
                    {
                        'name': 'test D2',
                        'action': 'setup'
                    }
                ]
            }
        },
        {
            'name': 'test E',
            'action': 'setup'
        }
    ]
    #

# Generated at 2022-06-23 06:22:14.789907
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.requirement import RoleRequirement


# Generated at 2022-06-23 06:22:22.752976
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block

    play = Play()
    task = Task()
    block_load_list = load_list_of_blocks([task,block],play)

    # Checks to see if list returned is Block type
    if not block_load_list or (not isinstance(block_load_list[0], Block) or not isinstance(block_load_list[1], Block)):
        return False

    return True



# Generated at 2022-06-23 06:22:34.058720
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.script import AnsibleModule
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.template import Templar

    context = PlayContext()

# Generated at 2022-06-23 06:22:34.690589
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
   assert True

# Generated at 2022-06-23 06:22:41.431736
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import pytest

    loader = DataLoader()

    def _assert(data, expected, expected_result):
        actual = load_list_of_blocks(data, Play(), loader=loader)
        assert isinstance(actual, list)
        assert len(actual) == len(expected)
        # result comparison is only performed avout non-empty values
        if expected_result:
            assert isinstance(expected_result, dict)
            assert isinstance(actual[0]._result, dict)
            for k in expected_result.keys():
                assert expected_result[k] == actual[0]._result[k]
        # comparing type and attributes

# Generated at 2022-06-23 06:22:53.525874
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # to run under pytest
    #   pytest -s --pdb test/unit/test_loader.py::test_load_list_of_roles
    #
    # Test load_list_of_roles()
    #   pytest -s --pdb test/unit/test_loader.py::test_load_list_of_roles
    #
    import pytest
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager

# Generated at 2022-06-23 06:23:06.174607
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role_include import IncludeRole
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_executor import TaskExecutor
    from ansible.plugins.callback import CallbackBase
    import ansible.constants as C


# Generated at 2022-06-23 06:23:18.745021
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.modules.system import command
    from ansible.compat.tests.mock import patch
    from ansible.playbook.task import Task
    modules_d = {'command': command}

    # creating a play and adding a task
    play = Play().load({
        'name': 'Ansible Play',
        'hosts': 'localhost',
        'gather_facts': 'no',
        'tasks': [
            {'command': 'whoami'},
        ]
    }, variable_manager=VariableManager(), loader=DummyLoader())

    # creating a block and adding a task
    block = Block().load(data={}, play=play)
    task = Task().load(data=play.tasks()[0], block=block, role=None)
    block.block = [task]

    # creating

# Generated at 2022-06-23 06:23:31.639013
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor


# Generated at 2022-06-23 06:23:40.022419
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.utils.display import Display
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins import module_loader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.task import Task
    import ansible.constants as C
    import os


    # First we create a few objects
    display_obj = Display()
    loader_obj = AnsibleLoader(None, True)
    dataloader_obj