

# Generated at 2022-06-23 06:13:35.009234
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-23 06:13:45.210259
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    load_list_of_roles:
    1. no role_path
    2. role_path
    3. role_path and play
    '''
    fake_loader, inventory, variable_manager = \
        _init_global_context(None)

    role = dict(name = 'role1')
    role_def = dict(role = ['role1'])
    role_def_dirs = dict(roles = [role])
    assert load_list_of_roles(role_def, None, None, variable_manager, fake_loader).pop().role == RoleInclude(role)
    assert load_list_of_roles(role_def_dirs, None, None, variable_manager, fake_loader).pop().role == RoleInclude(role)


# Generated at 2022-06-23 06:13:57.210524
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    This is an integration test.
    It uses the ansible.cfg file to determine the following:
        1. the directories to search for roles and collections
        2. the location of the inventory
    To run the test correctly, the following need to be set in the ansible.cfg file:
        - roles_path
        - collections_path
        - inventory
    :return:
    """
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_mgr = InventoryManager(loader=loader, sources='ansible.cfg')
    variable_manager = VariableManager(loader=loader, inventory=inv_mgr)
    play_source

# Generated at 2022-06-23 06:14:07.245124
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # Tests with empty input list
    list_of_blocks = load_list_of_blocks(None, None, None, None, None, None)
    assert list_of_blocks == []

    # Tests with a list of one block
    ds = [{"block": "this is a test"}]
    list_of_blocks = load_list_of_blocks(ds, None, None, None, None, None)
    assert list_of_blocks[0].module_name == "block"
    assert list_of_blocks[0].args == "this is a test"

    # Tests with a list of two blocks
    ds = [{"block": "this is a test"}, {"block": "this is a test2"}]

# Generated at 2022-06-23 06:14:12.285676
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DictDataLoader({})

    variable_manager = VariableManager()
    variable_manager.set_inventory(Inventory(loader=loader,
                                             host_list=[],
                                             group_list=[]))

    play = Play()
    play.variable_manager = variable_manager
    play.variable_manager.set_play_context(PlayContext())

    # simple role definition
    role_def = {
        'name': 'myrole',
        'include_role': {
            'name': 'test'
        }
    }
    i = load_list_of_roles(ds=[role_def], play=play,
                           variable_manager=variable_manager,
                           loader=loader)[0]

    assert isinstance(i, RoleInclude)
    assert i.role_name == 'test'

# Generated at 2022-06-23 06:14:21.040305
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from . import play_context
    from .block import Block
    from .play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.module_utils.six import string_types
    from ansible.vars import VariableManager
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context.CLIARGS = {}
    variable_manager = VariableManager()
    variable_manager.extra_vars = {'foo': 'bar'}  # Fake setup of variable manager

# Generated at 2022-06-23 06:14:22.026390
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO
    pass



# Generated at 2022-06-23 06:14:27.495140
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    fake_var = {}
    fake_loader = {}
    fake_vm = {}

    def mock_vm_get_vars(play, task):
        return fake_vm
    fake_vm.get_vars = mock_vm_get_vars

    fake_vm = {}
    fake_tmplar = {}
    fake_loader = {}

    def mock_vm_get_vars(play, task):
        return fake_vm
    fake_vm.get_vars = mock_vm_get_vars

    def mock_tmplar_template(data):
        return data
    fake_tmplar.template = mock_tmplar_template

    def mock_loader_path_dwim_relative(basedir, rel_path, target):
        return "/fake/path"
    fake_loader.path_

# Generated at 2022-06-23 06:14:39.912725
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager

    play_source = dict(
        name="Test Play",
        hosts="all",
        gather_facts='no',
        roles=[],
        vars_files=[],
        vars={},
        tasks=[]
    )
    block_source = dict(
        name="Test Block",
        tasks=[],
    )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=None)
    task_source = dict(name="Test Task")
    task = Task().load(task_source, block=None, role=None, task_include=None, variable_manager=None, loader=None)

# Generated at 2022-06-23 06:14:47.861486
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()

    ds = [{
        "block": [{
            "task": {
            }
        }]
    }]

    Block.is_block = staticmethod(lambda ds: False)

    block = load_list_of_blocks(
        ds,
        play=Object(),
        parent_block=None,
        role=None,
        task_include=None,
        use_handlers=False,
        variable_manager=variable_manager,
        loader=loader,
    )

    assert len(block) == 1

# Generated at 2022-06-23 06:14:52.598123
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = {}
    play = Play()
    role = Role()
    loader = DataLoader()
    variable_manager = VariableManager()
    task_list = load_list_of_tasks(task_ds, play, block=None, role=role, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)

# Generated at 2022-06-23 06:15:03.143169
# Unit test for function load_list_of_roles

# Generated at 2022-06-23 06:15:07.320103
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    import ansible.constants as C
    import os
    import yaml

    # yaml data
    ds = yaml.load("""
    - hosts: all
      blocks:
        - name: test block
          tasks:
            - debug:
                msg: "Hello World"
    """)

    # the data is wrapped in a list, need to unwrap to get a dictionary
    ds = ds[0]

    inventory = InventoryManager(loader=DataLoader(), sources="localhost")

# Generated at 2022-06-23 06:15:16.700504
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    block_list = load_list_of_blocks(None, None)
    assert block_list == []
    block_list = load_list_of_blocks([], None)
    assert block_list == []
    ds = [dict(action=dict(module='shell', args='whoami'))]
    block_list = load_list_of_blocks(ds, None)
    assert len(block_list) == 1
    block = block_list[0]
    assert isinstance(block, Block)
    assert block._parent is None
    assert block._role is None
    assert block._task_include is None
    assert block._use_handlers is False
    assert block._dep_chain == []
    assert block._loop

# Generated at 2022-06-23 06:15:27.080729
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import VarsModule
    from ansible.vars.resolver import TaskVars
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader

    class TestPlaybookObject:

        def __init__(self):
            self.hostvars = dict()

    class TestTask(AnsibleBaseYAMLObject):

        def __init__(self):
            self._

# Generated at 2022-06-23 06:15:41.491041
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: use ansible.module_utils.six.moves for imports
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager


    ds = [
        {"block": "This is a block with a task"},
        {"task": "This is a task"},
        {"task": "This is a task with a block"},
        {"block": "This is a block with a task"},
        {"task": "This is a task"},
        {"task": "This is a task"},
    ]

    play_context = PlayContext()
    loader = DictDataLoader({})
    variable

# Generated at 2022-06-23 06:15:52.377530
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test imports
    from ansible.playbook.role.include import RoleInclude
    import collections
    import tempfile
    import os

    # Create some roles with a collection
    tmpdir = tempfile.mkdtemp()

# Generated at 2022-06-23 06:16:00.011057
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    Test for function load_list_of_roles
    """
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.include import RoleInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    role_path = 'tests/test_playbooks/role_load'
    role_name = 'test_role'
    role_full_path =  '%s/%s' % (role_path, role_name)

    collection_search_list = ['ansible_collections.testnamespace.testcoll']


# Generated at 2022-06-23 06:16:11.725413
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import Role
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Playbook
    from ansible import constants as C

    loader = DictDataLoader({
    })

    variable_manager = VariableManager()

    play_source = dict(
        name = "Ansible Playbook",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(
                include_role=dict(
                    name='test_role',
                    tasks_from='main.yml'
                )
            )
        ]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)
    tqm = None

# Generated at 2022-06-23 06:16:26.845805
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """
    :return: A return code, 0 for success, 1 for failure.
    """
    from ansible.plugins.loader import load_plugins

    current_role_path = 'test/role1'
    ds = [
        dict(role='role1'),
        dict(name='role2'),
        dict(include='role3'),
        dict(role='role4'),
        dict(include='role5'),
        dict(name='role6'),
        dict(include='role7'),
    ]

    names = [d['role'] if 'role' in d
             else d['name'] if 'name' in d
             else d['include'] if 'include' in d
             else None
             for d
             in ds]


# Generated at 2022-06-23 06:16:37.435113
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.template import Templar
    ds = [{'block': True, 'name': 'Test_Block'},
          {'name': 'Test_Task'},
          {'import_tasks': 'test.yml'}]

    role = C.DEFAULT_HASH_BEHAVIOUR
    variable_manager = Mock()
    variable_manager.get_vars.return_value = {}
    variable_manager.extra_vars = {}
    variable_manager.host_vars = {}
    variable_manager.host_vars.get.return_value = {}
    variable_manager.group_vars = {}
    variable_manager.group_vars.get.return_value = {}
    variable_manager.task_vars = {}

# Generated at 2022-06-23 06:16:43.505624
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    dummy_loader = DummyLoader()
    dummy_vm = DummyVarsManager()
    dummy_play = DummyPlay()
    items = ['a', 'b', 'c']
    ds = [{'block': items}, 'd']
    ds_implicit_block_squash = [items, 'd']
    blocks = load_list_of_blocks(ds, dummy_play, variable_manager=dummy_vm, loader=dummy_loader)
    assert len(blocks) == 2
    # The first one should be a proper block
    assert isinstance(blocks[0], DummyBlock)
    assert blocks[0].squashed_from == items
    # And the second one should be an implicit block, whose items were squashed
    assert isinstance(blocks[1], DummyBlock)
    assert blocks[1].squ

# Generated at 2022-06-23 06:16:54.343232
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.variable_manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 06:17:01.449972
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    import ansible.playbook
    import ansible.playbook.play
    from ansible.playbook.play_context import PlayContext

    pb = ansible.playbook.Playbook()
    pc = PlayContext()
    loader = pb._loader

    # Create a list of tasks
    yaml_data = [dict(hosts='localhost'), dict(action='shell', module='echo', args=dict(msg='hi'))]

    # Call the function
    result = load_list_of_tasks(yaml_data, ansible.playbook.play.Play().load(dict(name='tester'), loader=loader, variable_manager=pb._variable_manager), pc, loader=loader)

    # Check the result
    assert len(result) == 2
    assert result

# Generated at 2022-06-23 06:17:10.559912
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role_include import IncludeRole
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.task_include import TaskInclude

    ds = [
        {'block': [
            {
                'block': [
                    {'block': [{'include_role': 'all'}]},
                ]
            }
        ]},
        {
            'include_role': 'all'
        }
    ]
    class DataStructure(AnsibleBaseYAMLObject):
        def __init__(self, ds):
            # set up the data that is parsed from YAML so that it is accessible via the logic
            # that is shared with the ini and json plugins.
            self.ds = ds


# Generated at 2022-06-23 06:17:13.519525
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.playbook.task_include 
    assert ansible.playbook.task_include.load_list_of_tasks is load_list_of_tasks

# Generated at 2022-06-23 06:17:25.170381
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader, inv_loader, var_manager = setup_loader()
    ds = [
        {
            'role': 'web',
            'foo': 'bar'
        },
        {
            'role': 'database',
            'other': 'var'
        }
    ]
    role_includes = load_list_of_roles(ds, None, None, var_manager, loader)
    assert len(role_includes) == 2
    assert role_includes[0].get_name() == 'web'
    assert role_includes[0]._role_params == {'foo': 'bar'}
    assert role_includes[1].get_name() == 'database'
    assert role_includes[1]._role_params == {'other': 'var'}



# Generated at 2022-06-23 06:17:36.717319
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ''' Unit test for function load_list_of_roles
    '''
    # We are using the CLI options in order to set the paths,
    # so we need to initialize those and the config singleton
    # *before* loading the plugin manager
    cli_parser = CLI.base_parser(constants.DEFAULT_MODULE_PATH, constants.DEFAULT_MODULE_NAME,
                                 ignore_unknown_options=True)
    cli_parser.parse_args()
    cli_parser.terminate()

    config = ConfigManager(cli_options=cli_parser.cli_options)
    config.set_inventory_sources("/tmp/hosts")
    config.add_callback(C.DEFAULT_CALLBACK_WHITELIST)

# Generated at 2022-06-23 06:17:37.396797
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-23 06:17:48.915942
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class Mock(object):
        def __init__(self, **kwargs):
            for k, v in kwargs.items():
                setattr(self, k, v)

    loader = Mock()

    class MockPlay(object):
        def __init__(self):
            self.host_map = dict()

    play = MockPlay()

    class Mock_Varmgr(object):
        def get_vars(self, **kwargs):
            return dict()

        def hostvars(self, **kwargs):
            return dict()

    variable_manager = Mock_Varmgr()

    class MockBlock(object):
        def __init__(self, name, parent_block=None, task_include=None):
            self.block = self
            self.name = name

# Generated at 2022-06-23 06:17:50.154691
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # FIXME
    pass


# Generated at 2022-06-23 06:17:52.307011
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    output = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert output == 'some_output'


# Generated at 2022-06-23 06:17:52.888198
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:18:02.118352
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # required by import
    # Used to create a proper object
    class MockPlaybook(object):
        pass

    # Used to create a proper object
    class MockVar:
        def __init__(self):
            self.vars = dict()

    # Used to create a proper object
    class MockLoader:
        pass

    playbook = MockPlaybook()
    playlist_vars = MockVar()
    loader = MockLoader()
    role = None
    task_include = None
    use_handlers = False
    VariableManager = collections.namedtuple("VariableManager", "get_vars")
    variable_manager = VariableManager(lambda **kwargs: dict())

# Generated at 2022-06-23 06:18:07.351240
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Note: AnsibleTestCase is deprecated in Ansible 2.8. The replacement is to use AnsibleRunnerTestCase.
    # Ref: https://github.com/ansible/ansible/issues/8778
    # TODO: replace AnsibleTestCase with AnsibleRunnerTestCase
    # from ansible.plugins.loader import test_utils
    from ansible.utils.display import Display
    from ansible.plugins.loader import test_utils
    from ansible.utils.context_objects import AnsibleContext
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
   

# Generated at 2022-06-23 06:18:15.125605
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(None) == []
    assert load_list_of_blocks([None]) == []
    assert load_list_of_blocks([{},{}]) == []
    assert load_list_of_blocks([{},{'block': []}]) == []
    assert load_list_of_blocks([{'block': []},{'block': []}]) == []
    assert load_list_of_blocks([{'block': None},{'block': None}]) == []



# Generated at 2022-06-23 06:18:24.257948
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Task list contains: Task, Action, TaskInclude, and HandlerTaskInclude
    # Task is at the end of the list - should return Task object
    ds = [{'debug': 'msg={{ test }}'}, {'debug': 'msg={{ test }}'}, {'include_tasks': 'first.yml'}, {'import_tasks': 'first.yml'}, {'name': 'test', 'debug': 'msg={{ test }}'}]
    task_list = load_list_of_tasks(ds, None, None, None, None, False, None)
    assert task_list[-1].__class__.__name__ == 'Task'

# Generated at 2022-06-23 06:18:31.073473
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    load_list_of_roles function tests.
    '''
    from ansible.playbook.play import Play

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'local',
        gather_facts = 'no',
        roles = [
            dict(name='test'),
            # This is a bad role name, which should be skipped
            'invalid-role-name'
        ]
    )
    pb = Playbook.load(play_source, loader=DictDataLoader())
    play = pb.get_play(play_source.get('name'))
    loader = DataLoader()
    current_role_path = None
    variable_manager = VariableManager()
    collection_search_list = ['ansible_collections.foobar.test']
    #

# Generated at 2022-06-23 06:18:31.689609
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:18:36.853566
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test Case 1:
    yaml_data = """
- include_role:
    name: test
    tasks_from: test-task
"""
    loader = DataLoader()
    variable_manager = VariableManager()
    ds = yaml.load(yaml_data)
    play = Play.load(ds, variable_manager=variable_manager, loader=loader)
    role_path = "/path/to/role"
    # Assertion Check
    assert len(load_list_of_roles(ds, play, current_role_path=role_path, variable_manager=variable_manager, loader=loader)) == 1

    # Test Case 2:
    yaml_data = """
- import_role:
    name: test
"""
    loader = DataLoader()
    variable_manager = VariableManager()
    ds

# Generated at 2022-06-23 06:18:46.953745
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Test load_list_of_blocks with implicit blocks
    '''
    from ansible.playbook import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    variable_manager = VariableManager()
    variable_manager.set_inventory(MockInventory())
    variable_manager.extra_vars = {'var1': 'val1'}

    host = variable_manager.get_host('localhost')


# Generated at 2022-06-23 06:18:58.274433
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # implicit block case
    ds = [dict(loop='foo'), dict(debug='msg="Hi"'), dict(debug='msg="Hi"')]
    blocks = load_list_of_blocks(ds, play=None)
    if len(blocks) != 2:
        raise AssertionError("Two blocks should have been found")
    if len(blocks[0].block) != 2:
        raise AssertionError("First block should contain two tasks")
    if len(blocks[1].block) != 1:
        raise AssertionError("Second block should contain one task")

    # explicit block case
    ds = [dict(block=dict(rescue=dict(debug='msg="Hi"'), always=dict(debug='msg="Hi"'))), dict(debug='msg="Hi"')]
    blocks = load_list_of_

# Generated at 2022-06-23 06:19:06.101357
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    print("Testing function load_list_of_blocks")

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.plugins.loader import callback_loader
    from ansible.template import Templar

    # Fake inventory
    class FakeInventory(object):
        def __init__(self):
            self.hosts = dict(
                localhost = dict(
                    ansible_port = 22,
                    ansible_host = 'localhost',
                    ansible_user = 'root',
                    ansible_connection = 'local',
                )
            )

# Generated at 2022-06-23 06:19:14.755056
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    # mock return value of any test using load_list_of_blocks
    mock_return_value = "foo"

    # mock variabls for tests
    mock_ds = [1, 2, 3]
    mock_play = "play"
    mock_parent_block = "parent block"
    mock_role = "role"
    mock_task_include = "task include"
    mock_use_handlers = True
    mock_variable_manager = "variable manager"
    mock_loader = "loader"

    # specify an unittest for each test of load_list_of_blocks
    # assert that load_list_of_blocks calls Block.load with the correct args
    def check_load_list_of_blocks():
        Block.load = MagicMock(return_value=mock_return_value)
        ansible

# Generated at 2022-06-23 06:19:17.980467
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = load_list_of_tasks()
    assert type(ds) == list
    assert ds == []

# Generated at 2022-06-23 06:19:19.398921
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
    #  TODO: Add appropriate asserts



# Generated at 2022-06-23 06:19:20.420974
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    if 0:
        pass


# Generated at 2022-06-23 06:19:28.946806
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['tests/inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source =  dict(
        name = "Ansible Play",
        hosts = 'webservers',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )

    # Create

# Generated at 2022-06-23 06:19:39.119855
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks is not None
    print('Test load_list_of_tasks function')
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    play = Play()
    role = Role()
    task_include = TaskInclude()
    block = Block()
    handler = Handler()
    task = Task()
    ds = [{'block': 'test_block', 'block': 'test_block1'}]

# Generated at 2022-06-23 06:19:52.247063
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.play import Play as Play_ds
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.parsing.mod_args import ModuleArgsParser
    display = Display()
    loader = DictDataLoader({})
    roles_path = C.DEFAULT_ROLES_PATH
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, host_list=['localhost'])
    play_ds = Play_ds.load(dict(
        name ="Ansible Play",
        hosts='localhost',
        gather_facts = 'no',
    ), loader=loader, variable_manager=variable_manager)
    play = Play().load(play_ds, loader, inventory)
   

# Generated at 2022-06-23 06:19:56.563526
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(ds=[1,2,3], play=None) == [1,2,3]

#Unit test for function load_list_of_blocks

# Generated at 2022-06-23 06:20:08.583538
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    d = [{"action": {"__ansible_module__": "ping"}}]
    task_list = load_list_of_tasks(d, None, None, None, None, None)
    assert len(task_list) == 1
    assert isinstance(task_list[0], Task)
    d = [{"include": "test"}]
    task_list = load_list_of_tasks(d, None, None, None, None, None)
    assert len(task_list) == 1
    assert isinstance(task_list[0], TaskInclude)
    d = [{"loop": "test"}]

# Generated at 2022-06-23 06:20:16.933654
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # just testing our structure here, so we can fake some of the objects
    ds = [{'action': 'foo'}, {'action': 'bar'}, {'block': 'foo'}, {'block': 'bar'}]
    role = FakeRole()
    task_include = FakeTaskInclude()
    variable_manager = FakeVariableManager()
    loader = FakeLoader()
    play = FakePlay()

    task_list = load_list_of_tasks(ds, play, block=None, role=role, task_include=task_include, variable_manager=variable_manager, loader=loader)
    assert len(task_list) == 5
    assert task_list[0]._role is role
    assert task_list[0]._parent is role
    assert task_list[0]._task_include is task_include


# Generated at 2022-06-23 06:20:24.861424
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-23 06:20:35.759818
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.base import Base
    from ansible.playbook.task import Task
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader, connection_loader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.plugins.strategy.linear import LinearStrategy
    from ansible import context
    

# Generated at 2022-06-23 06:20:44.210272
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    host=AnsibleHost('localhost')
    connection=AnsibleConnection('local')
    variable_manager=VariableManager()
    loader=DataLoader()
    variable_manager.set_inventory(Inventory(loader=loader, host_list=[host]))
    
    ds = yaml.load('''
    - name: common
      src: /path/to/common
    - name: webservers
      when: webservers
      src: /path/to/webservers
    ''')
    load_list_of_roles(ds, 'play', variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:20:55.867535
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # FIXME: this is not a lot of test coverage, but we don't have a way to load roles
    #        currently so we cannot test other scenarios
    import os
    import sys
    import shutil
    import tempfile

    THIS_DIR = os.path.normpath(os.path.dirname(os.path.abspath(__file__)))
    TEST_ROLE = os.path.normpath(os.path.join(THIS_DIR, '..', '..', 'test_roles', 'test_role'))

    # Create a temporary directory for the test, change to that directory and create a 'roles' directory
    # so we can test using the full path in a role declaration
    if sys.version_info >= (3,):
        tempdir = tempfile.TemporaryDirectory(dir=os.getcwd())


# Generated at 2022-06-23 06:21:00.169266
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # test_load_list_of_tasks
    # load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
    # TODO: add test
    pass



# Generated at 2022-06-23 06:21:08.544868
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.hostvars import HostVars

    fake_loader = DataLoader()
    fake_inventory = InventoryManager(loader=fake_loader, sources='')
    fake_variable_manager = VariableManager(loader=fake_loader, inventory=fake_inventory)

# Generated at 2022-06-23 06:21:16.426817
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import filter_loader
    from ansible.parsing.splitter import parse_kv

    def get_loader():
        mock_loader = DataLoader()
        mock_loader.set_basedir('/tmp')
        return mock_loader

   

# Generated at 2022-06-23 06:21:26.319108
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.plugins.loader import action_loader
    action_loader.add_directory(C.DEFAULT_ACTION_PLUGIN_PATH)
    assert load_list_of_tasks([{'include_role': {'name': 'foo'}}], None, role='bar')
    assert load_list_of_tasks([{'include_tasks': 'foo'}], None, role='bar')
    assert load_list_of_tasks([{'include_tasks': 'foo', 'loop': 'bar'}], None, role='bar')
    load_list_of_tasks([{'include': 'foo'}], None, role='bar')
    load_list_of_tasks([{'command': '/bin/foo'}], None, role='bar')

# Generated at 2022-06-23 06:21:27.123493
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:21:33.473853
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import constants as C
    from ansible.cli import CLI
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.plugins import get_all_plugin_loaders, get_loader
    from ansible.template import Templar
    from ansible.plugins.loader import action_loader, lookup_loader, filter_loader

    class FakePlugin(object):
        def __init__(self):
            pass

        def get_name(self):
            return 'fake'

    class FakeLookupPlugin(FakePlugin):
        def __init__(self):
            FakePlugin.__init__(self)


# Generated at 2022-06-23 06:21:44.717974
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [
        {
            'block': [
                [
                    {
                        'include_role': {
                            'name': 'my-role',
                            'tasks_from': 'main'
                        }
                    }
                ]
            ]
        },
        {
            'block': [
                [
                    {
                        'debug': {
                            'msg': 'test-msg'
                        }
                    },
                    {
                        'register': 'var'
                    }
                ]
            ]
        }
    ]

    TaskInclude = get_action_class('include_role')
    Task = get_action_class('debug')
    Task = get_action_class('register')


# Generated at 2022-06-23 06:21:56.664096
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def check_role(i):
        assert isinstance(i, RoleInclude)
        assert i.role_name == role_name
        assert i.play == play
        assert i._role_name == role_name
        assert i.tags == tags
        assert i.conditional == conditional

    def check_empty():
        assert len(roles) == 0

    loader = DictDataLoader({})
    variable_manager = VariableManager()
    play = Play.load(play_role_tasks_yaml, loader=loader, variable_manager=variable_manager)

    # 1. no roles are defined
    roles = load_list_of_roles([], play, variable_manager=variable_manager, loader=loader)
    check_empty()

    # 2. single role is defined
    role_name = 'dependency'
   

# Generated at 2022-06-23 06:22:08.679276
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook import Play
    from ansible.parsing.plugin_docs import read_docstring
    from ansible.plugins import module_loader

    loader = module_loader
    play = Play.load({})
    doc = read_docstring(loader.find_plugin('./plugins/modules/copy.py'))
    ds = dict(name='copy', args=dict(src='file.txt', dest='/tmp'))
    task = load_list_of_tasks([ds], play)[0]
    assert task.action == 'copy'
    assert task.args['src'] == 'file.txt'

    ds = dict(name='template', args=dict(src='file.j2', dest='/tmp'))
    task = load_list_of_tasks([ds], play)[0]


# Generated at 2022-06-23 06:22:17.960114
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.play_iterator import PlayIterator
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.callback import CallbackBase
    class ResultsCollector(CallbackBase):
        def __init__(self, *args, **kwargs):
            super(ResultsCollector, self).__init__(*args, **kwargs)
           

# Generated at 2022-06-23 06:22:27.248761
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role.role import Role
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    # variable manager
    variable_manager = VariableManager()

    # inventory
    inventory = InventoryManager(loader=DataLoader(), sources='')

    # host
    host = Host(name="testbox")
    host.vars = dict()

    # group
    group = Group(name="testgroup")
    group.vars = dict()

    # inventory
    inventory.add

# Generated at 2022-06-23 06:22:38.571474
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import os
    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    # We put this here, to avoid issues with blocking imports
    from ansible.plugins.loader_fragment import FragmentLoader

    from ansible.executor import playbook_executor

    # This is a minimal playbook
    test_playbook = u'''
- hosts: localhost
  tasks:
  - action: ping
'''
    playbook_path = 'playbook.yml'
    with open(playbook_path, 'w') as fd:
        fd.write(test_playbook)

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
   

# Generated at 2022-06-23 06:22:48.988695
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Load dummy play object
    play = {}
    # Load dummy loader object
    loader = {}
    # Load dummy variable_manager object
    variable_manager = {}
    # Load dummy role include object
    role_def = {}
    # Load a dummy role include object
    roledef = RoleInclude(role_def, play, None, loader, variable_manager)
    # Load a list of dummy role include objects
    ds = [roledef,roledef]
    # Load a dummy current_role_path object
    current_role_path = ''
    # Call function load_list_of_roles and save result to dummy object
    ret = load_list_of_roles(ds,play,current_role_path,variable_manager,loader)
    assert ret == []


# REPLACED BY role/meta.py

# Generated at 2022-06-23 06:22:54.418510
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    import ansible.plugins.loader as plugin_loader
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader, variable_manager, None)
    variable_manager.set_inventory(inventory)
    test_play = Play()
    test_play.loaders = loader
    plugin_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../../test/units/module_utils/test_list_of_roles/'))

    # Test case 1: Init test_play.ro

# Generated at 2022-06-23 06:23:06.327529
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    #Creating a test playbook and task
    this_dir = os.path.dirname(os.path.realpath(__file__))
    playbooks = [
        Playbook.load(
            os.path.join(this_dir, '../ansible_test/test_playbook_1.yml'),
            variable_manager=variable_manager,
            loader=loader,
        )
    ]
    playbook = playbooks[0]
    block=playbook.get_blocks()[0]
    # Test task = ping
    task_ds=block._tasks[0]
    expected_result = task_ds

# Generated at 2022-06-23 06:23:07.205032
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 1==1

# Generated at 2022-06-23 06:23:19.353034
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    # ds = [{'include_tasks': 'test.yml'}, '', {'shell':'echo hello'}, {'block': [{'block1':''}, {'block2':''}]}]
    ds = [{'include_tasks': 'test.yml'}, {'shell':'echo hello'}, {'block': ['block1', 'block2']}]
    variable_manager = VariableManager()
    loader = DataLoader()


# Generated at 2022-06-23 06:23:26.832365
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    ds = [
        {'block': 'test1'},
        'test2',
        {'block': 'test3'},
        'test4',
        'test5',
        {'block': 'test6'}
    ]

    blocks = load_list_of_blocks(ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)

    assert len(blocks) == 5

    assert isinstance(blocks[0], Block)
    assert blocks[0].block  == 'test1'

    assert isinstance(blocks[1], Block)
    assert blocks[1].block  == 'test2'

    assert isinstance(blocks[2], Block)
    assert blocks

# Generated at 2022-06-23 06:23:38.279040
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Create a Fake Play
    play = {
        'name': 'Play 1',
        'hosts': [
            'all'
        ],
        'gather_facts': 'no',
        'tasks': [{
            'name': 'Test task',
            'action': 'dummy',
            'tags': ['always']
        }],
        'roles': [{
            'name': 'Test role 1',
        }]
    }
    assert load_list_of_roles(ds=play, play=None, current_role_path=None, variable_manager=None, loader=None,
                              collection_search_list=None) is not None

    # Test for all types of roles