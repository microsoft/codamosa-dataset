

# Generated at 2022-06-23 06:13:42.316557
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import yaml

    yaml_string = """
- name: playbook.yml
  hosts: localhost
  connection: local
  tasks:
    - name: task1
      ping:
    - name: task2
      setup:
    - name: task3
      setup:
    - name: task4
      debug:
        msg: test
      block:
        - name: nested task1
          ping:
        - name: nested task2
          setup:
    - name: task5
      debug:
        msg: test
"""

    class DisplayObj:
        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False, runner=None):
            pass



# Generated at 2022-06-23 06:13:42.918551
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:13:47.280927
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [1, 2, 3]
    assert load_list_of_blocks(ds=ds) == ds


# Generated at 2022-06-23 06:13:59.265462
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.template import Templar
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.utils.vars import combine_vars
    from ansible.errors import AnsibleParserError
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor import playbook_executor
    from ansible.inventory.host import Host
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-23 06:13:59.866061
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True

# Generated at 2022-06-23 06:14:00.449729
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:14:08.748377
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play

    p = Play().load({
        'name': 'test',
        'hosts': 'all',
        'roles': [
            'common',
            {'role': 'apache', 'name': 'web'},
            {'role': 'database', 'with_items': '"{{ databases }}"'},
            {'role': 'database', 'tags': ['other'], 'with_items': '"{{ databases }}"'},
        ],
    })

    assert len(p.roles) == 4

    assert p.get_role_by_name('common')
    assert p.get_role_by_name('web')
    assert p.get_role_by_name('database_1')
    assert p.get_role_by_name('other_database_1')
   

# Generated at 2022-06-23 06:14:17.599271
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # This works because we aren't actually trying to load roles, and only care about the function to return a list of objects
    ds = [{'name': 'role-to-load'}]
    assert len(load_list_of_roles(ds, None)) == len(ds)
    # now we can make sure it throws an exception on an invalid data structure
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(None, None)
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles('bogus', None)



# Generated at 2022-06-23 06:14:19.039217
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test for function load_list_of_roles
    '''
    pass


# Generated at 2022-06-23 06:14:29.699403
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from collections import namedtuple
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.extra_vars = {"foo": "bar"}
    # noinspection PyTypeChecker
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost'))

    play_ds = namedtuple('play_ds', ['name', 'hosts', 'become'])
    play_ds = play_ds(name='test play', hosts='localhost', become=False)

    # Implicit blocks are created by bare tasks listed in

# Generated at 2022-06-23 06:14:37.066297
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.include
    import ansible.playbook.play_context
    import ansible.vars.manager

    i=ansible.playbook.role.include.RoleInclude()
    i.role_name='test1'

    pc=ansible.playbook.play_context.PlayContext()
    v=ansible.vars.manager.VarsManager()

    rl = load_list_of_roles([{'role':'test1'}],pc,variable_manager=v)
    assert rl[0].role_name == 'test1'



# Generated at 2022-06-23 06:14:49.348342
# Unit test for function load_list_of_roles

# Generated at 2022-06-23 06:14:58.570092
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # We import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block

    assert isinstance(load_list_of_blocks([], None), list)
    assert not load_list_of_blocks(None, None)
    assert isinstance(load_list_of_blocks([{}, {}], None), list)
    assert len(load_list_of_blocks([{}, {}], None)) == 2
    assert isinstance(load_list_of_blocks([{}], None)[0], Block)
    assert isinstance(load_list_of_blocks([{}, {}, {}, {}], None)[3], Block)



# Generated at 2022-06-23 06:15:09.302175
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # define data structure for testing
    ds = [{'action': 'setup',
           'delegate_to': 'localhost',
           'include_tasks': 'main.yml'},
          {'action': 'notify',
           'delegate_to': 'localhost',
           'handler': 'restart httpd'},
          {'action': 'debug',
           'delegate_to': 'localhost',
           'msg': 'This is a message'}
          ]

    # define variables for testing/mocking
    play = None
    block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    # load list of tasks

# Generated at 2022-06-23 06:15:17.769324
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host

    # Create a mock task and Block()
    ds = dict(
        block=dict(
            tasks=[
                dict(
                    action=dict(
                        module='setup'
                    )
                ),
                dict(
                    action=dict(
                        module='setup'
                    )
                )
            ]
        )
    )

    # Create a mock play and Task()

# Generated at 2022-06-23 06:15:24.475506
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import yaml
    yaml_data = '''
- include_role:
    name: test
- import_role:
    name: test
- name: test
- name: test
- name: test
- block:
    - name: test
'''
    data = yaml.safe_load(yaml_data)
    load_list_of_tasks(data)

# this import is below the unit test to avoid circular imports
from ansible.playbook.attribute import Attribute, FieldAttribute

# Generated at 2022-06-23 06:15:33.546068
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    try:
        from ansible.playbook.block import Block
        from ansible.playbook.role import Role
        from ansible.playbook.task import Task
    except ImportError:
        raise SkipTest()
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.task_include import TaskInclude


# Generated at 2022-06-23 06:15:45.559283
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
  from ansible.playbook.play import Play
  from ansible.plugins.loader import action_loader

  loader = DataLoader()
  play = Play().load({
    'name': 'ansible_test',
    'hosts': '127.0.0.1',
    'gather_facts': 'no',
    'connection': 'local',
    'tasks': [
      {
        'name': 'test_task',
        'action': 'ping',
      }
    ]
  }, loader=loader, variable_manager=VariableManager())
  assert len(play.tasks()) == 1

  tasks = load_list_of_tasks(play.get_vars()['tasks'], play, task_include=None, use_handlers=True, variable_manager=play._variable_manager, loader=loader)


# Generated at 2022-06-23 06:15:45.984067
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:15:56.174926
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    import pytest


# Generated at 2022-06-23 06:16:06.614884
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    ds = [
        {
            'block': 'stages',
            'name': 'stages',
            'contains': [
                {
                    'block': 'tasks',
                    'name': 'stage1',
                    'contains': [
                        {
                            'block': 'rescue',
                            'name': 'rescue me',
                            'contains': [
                                {
                                    'block': 'tasks',
                                    'name': 'rescue me',
                                },
                            ],
                        },
                    ],
                },
            ],
        },
    ]

# Generated at 2022-06-23 06:16:21.191292
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # BEGIN TEST
    play = Play()
    play.name = "test"
    play.id = "test"
    play.role_path = 'test'

    path = os.path.dirname(__file__)
    test_role_path = path + "/test_roles/role_b"
    variable_manager = VariableManager()
    variable_manager.extra_vars = load_extra_vars(loader=None, options=None, vars_files=[])
    variable_manager.options_vars = load_options_vars(options=None)
    variable_manager.set_inventory(Inventory(loader=None, variable_manager=variable_manager))
    loader = DataLoader()
    collector = RoleIncludeLoader(play, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:16:32.766327
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Example datasets
    ds1 = {'include': 'some value'}
    ds2 = {'include_role': 'some value'}
    ds3 = {'include_tasks': 'some value'}
    ds4 = {'include_vars': 'some value'}
    ds5 = {'import_playbook': 'some value'}
    ds6 = {'import_role': 'some value'}
    ds7 = {'block': [{'include': 'some value'}]}
    ds8 = {'block': [{'include_role': 'some value'}]}
    ds9 = {'block': [{'include_tasks': 'some value'}]}
    ds10 = {'block': [{'import_playbook': 'some value'}]}

# Generated at 2022-06-23 06:16:44.224463
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import os
    #import yaml
    from ansible.playbook import Playbook
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    cur_path = os.path.dirname(__file__)
    file_name = cur_path + '/../../../../test/playbooks/playbook_no_handlers.yml'
    with open(file_name) as f:
        data = f.read()
    #data = yaml.load(stream)
    pb = Playbook.load(data, variable_manager=VariableManager(), loader=DataLoader())
    first_play = pb.get_plays()[0]
    assert first_play._included_playbooks == []

# Generated at 2022-06-23 06:16:55.497305
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import module_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
   

# Generated at 2022-06-23 06:17:02.526614
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import IncludeRole
    from ansible.template import Templar

    # it turned out that loads_list_of_roles function didn't work when variable manager isn't passed,
    # so here is a minimum variable manager that just return empty, otherwize it'll hit assertion
    variable_manager = Mock(spec_set=VariableManager, get_vars=lambda p, t: dict())
    loader = Mock(spec_set=DataLoader, get_basedir=lambda: "/home/fandy/ansible-project/pz-ansible/tests/unit/data")
    # we also need a loader to satisfy the template, so add load_from_file function, but here it's just a stub since we don't need it
    loader.load_from_file = lambda x: {}


# Generated at 2022-06-23 06:17:05.975493
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass
#####################################################################
# This function is used to load the playbook set of tasks and create Task objects
# for each one.
# 1. First it reads each task in the playbook
# 2. Then it loads the Task object from that task
# 3. It appends each Task object to a list called task_list
# 4. The task_list is returned
#####################################################################


# Generated at 2022-06-23 06:17:16.969412
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ROLE_1 = dict(
        name='first',
        tasks=dict(main=dict(action=dict(module='shell', args='ls /')))
    )
    ROLE_2 = dict(
        name='second',
        tasks=dict(main=dict(action=dict(module='shell', args='ls /')))
    )
    ROLE_DEF_1 = dict(
        role='first'
    )
    ROLE_DEF_2 = dict(
        role='second'
    )
    ROLES_DEF = [ROLE_DEF_1, ROLE_DEF_2]

    # Create a variable manager from an empty dict
    variable_manager = VariableManager()
    variable_manager.extra_vars = dict()

    # Create the AnsibleLoader
    loader = DictDataLoader(dict())



# Generated at 2022-06-23 06:17:28.314753
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play

    class MockVarsModule(object):
        def get_vars(self):
            return dict()

    global_vars_dict = dict(
        fred = dict(
            name = "fred",
            lname = "briggs"
        ),
        sally = dict(
            name = "sally",
            lname = "briggs",
            age = 42
        ),
    )

    mock_vm = MockVarsModule()
    pc = C(
        variable_manager=VariableManager(loader=DictDataLoader(), host_vars=global_vars_dict),
        loader=DictDataLoader(),
    )

# Generated at 2022-06-23 06:17:32.038843
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks(None, None, None, None, None, False, None) == []
    assert load_list_of_tasks({}, None, None, None, None, False, None) == []


# Generated at 2022-06-23 06:17:42.498411
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    ds = [
        {'block b1': [
            {'block b11': [
                {'debug': 'msg=test_msg'}
            ]}
        ]},
        {'block b2': [
            {'block b21': [
                {'debug': 'msg=test_msg2'}
            ]}
        ]}
    ]
    play = None
    parent_block = None
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None

    block_list = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert block_list[0].block is ds[0]

# Generated at 2022-06-23 06:17:47.033053
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    ds = [{"block": "one"}, {"block": "two"}]
    ds_out = [Block({"block": "one"}, play=None), Block({"block": "two"}, play=None)]
    assert load_list_of_blocks(ds, None) == ds_out



# Generated at 2022-06-23 06:17:57.168369
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.included_file import IncludedFile
    from ansible.plugins import module_loader
    from ansible.vars.manager import VariableManager

    #from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    #def fake_unicode(string=""):
    #    return AnsibleUnicode(string=string)
    #def fake_sequence(sequence):
    #    return AnsibleSequence(sequence=sequence)
    def fake_unicode(string=""):
        return string
    def fake_sequence(sequence):
        return sequence

# Generated at 2022-06-23 06:18:08.972345
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    from ansible.playbook.block import Block

    display.verbosity = 3
    ds = [
        {
            'block': 1
        },
        {
            'block': 2
        },
        3
    ]
    bl = load_list_of_blocks(ds)
    assert len(bl) == 2
    assert isinstance(bl[0], Block)
    assert isinstance(bl[1], Block)

    ds = [
        {
            'block': 1
        },
        3,
        4,
        {
            'block': 5
        }
    ]
    bl = load_list_of_blocks(ds)
    assert len(bl) == 2
    assert isinstance(bl[0], Block)
    assert isinstance(bl[1], Block)

# Generated at 2022-06-23 06:18:09.628702
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:18:18.687092
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    ds = wrap_var([
        {
            'tasks': [
                UnsafeProxy(
                    {
                        'action': {
                            'module': 'foo'
                        }
                    },
                    is_task_include=False
                ),
                UnsafeProxy(
                    {
                        'block': [
                            {
                                'action': {
                                    'module': 'foo'
                                }
                            }
                        ]
                    },
                    is_task_include=False
                )
            ]
        }
    ])
    assert load_list_of_blocks(ds)

# Generated at 2022-06-23 06:18:24.488991
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    load_list_of_blocks([{'name': 'test', 'local_action': 'test', 'connection': 'local'}], Play())

    with pytest.raises(AnsibleAssertionError):
        load_list_of_blocks('1', Play())



# Generated at 2022-06-23 06:18:26.105485
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:18:27.515472
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    #TODO
    return



# Generated at 2022-06-23 06:18:39.133474
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.vars.resolver import TaskVars
    import sys

    mock_loader = DictDataLoader(dict())
    mock_inventory = InventoryManager(loader=mock_loader, sources=["test_inventory"])
    variable_manager = VariableManager(loader=mock_loader, inventory=mock_inventory)
    play_context = PlayContext()
    play_context._set_task_and_variable_override("test")

# Generated at 2022-06-23 06:18:47.982341
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Testing for tags when tags is set to None as a kwarg
    task_ds = [{'meta': {'tags': ['foo']}}]
    task_include = TaskInclude(play=None, task_include=None, role=None, action='include', args={}, loop={}, inject={}, only_if={}, tags=None)

    new_task_list = load_list_of_tasks(ds=task_ds, play=None, block=None, role=None, task_include=task_include, use_handlers=False, variable_manager=None, loader=None)

    assert new_task_list[0].tags == []

    # Testing for tags when tags is not None as a kwarg
    task_ds = [{'meta': {'tags': ['foo']}}]
    task_include = Task

# Generated at 2022-06-23 06:18:58.538393
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.play
    import ansible.playbook.block
    import ansible.playbook.task
    import ansible.playbook.role

    ds = [{'name': 'first', 'action': 'shell'}]


    task_ds = {'name': 'first', 'action': 'shell', 'block': None}
    block_ds = {'block': [task_ds]}

    play = ansible.playbook.play.Play()
    role = ansible.playbook.role.Role()
    parent_block = ansible.playbook.block.Block()
    task_include = ansible.playbook.task.Task()
    use_handlers = True
    variable_manager = {}
    loader = {}

    blocks_list = []

# Generated at 2022-06-23 06:18:59.221415
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:19:00.663509
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    assert False, "need to write this test"



# Generated at 2022-06-23 06:19:11.174777
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play

    class MyVarsManager:
        def set_variable_manager(self, variable_manager):
            self.variable_manager = variable_manager
            variable_manager.set_nonpersistent_facts(dict(a=1))

        def get_vars(self, loader, play, host, task):
            return self.variable_manager.get_vars(loader=loader, play=play, host=host, task=task)

    class MyTask:
        def __init__(self, args, loader, variable_manager, block=None):
            self.args = args
            self.loader = loader
            self.variable_manager = variable_manager
            self.block = block
            self.vars = MyVarsManager()

# Generated at 2022-06-23 06:19:21.303863
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.meta import RoleMetadata
    from ansible.playbook.play import Play

    class mock_role_meta:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    class mock_role_ds:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs

        def __eq__(self, other):
            return self.__dict__ == other.__dict__

    class mock_role_include:
        def __init__(self, **kwargs):
            self.__dict__ = kwargs


# Generated at 2022-06-23 06:19:29.320401
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.verbosity = 2
    data = """
    action: block
    block:
      - action: debug
        msg: this is a debug
  - action: block
    block:
      - action: debug
        msg: another debug
      - action: block
        block:
          - action: debug
            msg: yet an other debug
        rescue:
          - action: debug
            msg: this is a rescue
    rescue:
      - action: debug
        msg: this is a rescue
    always:
      - action: debug
        msg: this is an always
"""
    #data = None
    ds = yaml.safe_load(data)
    if ds is None:
        raise ValueError("YAML data is empty")

# Generated at 2022-06-23 06:19:39.333690
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    from ansible.vars.unsafe_proxy import UnsafeProxy, wrap_var
    from ansible.vars.clean import module_response_deepcopy

    class ResultCallback(CallbackBase):
        def v2_runner_on_ok(self, result):
            host = result._host
            self.data = module_response_deepcopy(result._result)


# Generated at 2022-06-23 06:19:52.437733
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    # lib/ansible/playbook/block.py

    from ansible.playbook.handler import Handler
    # lib/ansible/playbook/handler.py

    from ansible.playbook.task import Task
    # lib/ansible/playbook/task.py

    from ansible.playbook.task_include import TaskInclude
    # lib/ansible/playbook/task_include.py

    from ansible.playbook.role_include import IncludeRole
    # lib/ansible/playbook/role_include.py

    from ansible.playbook.handler_task_include import HandlerTaskInclude
    # lib/ansible/playbook/handler_task_include.py

    from ansible.template import Templar
    # lib/ansible/template/__init__

# Generated at 2022-06-23 06:20:02.616917
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    """
    Integration test for the function modules._load_list_of_blocks
    """
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    results_callback = lambda *args, **kwargs: None
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()


# Generated at 2022-06-23 06:20:13.942156
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.plugins.loader import find_plugin
    from ansible.vars.manager import VariableManager

    # Setup the basic data types
    fake_ds = [dict(name='role1', tasks=[])]
    fake_play = Play(name="unittest_play", hosts=['fake_host'])
    fake_play._play_context = PlayContext()
    fake_variable_manager = VariableManager()
    fake_loader = find_plugin(fake_play.loader, "file_loader")()

    # Test
    roles = load_list_of_roles(fake_ds, fake_play, variable_manager=fake_variable_manager, loader=fake_loader)
    assert roles

# Generated at 2022-06-23 06:20:22.635510
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DataLoader()

    play = Play().load({
        'name': 'test play',
        'hosts': ['localhost'],
        'roles': [
            {'name': 'role_name_1'},
            {'name': 'role_name_2'}
        ]
    },variable_manager=VariableManager(), loader=loader)

    loaded_list = load_list_of_roles(play.get_roles(), play)

    assert isinstance(loaded_list[0], RoleInclude)
    assert loaded_list[0].name == 'role_name_1'
    assert isinstance(loaded_list[1], RoleInclude)
    assert loaded_list[1].name == 'role_name_2'



# Generated at 2022-06-23 06:20:34.608679
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible
    import ansible.parsing.yaml.objects

    # With a bare task
    ds = [{'action': {'__ansible_module__': 'command', '__ansible_arguments__': {'_raw_params': 'echo ok'}}}]
    block_list = load_list_of_blocks(ds, play=None)
    assert len(block_list) == 1
    assert block_list[0].is_always()
    assert len(block_list[0].block) == 1
    assert block_list[0].block[0].action == {'__ansible_module__': 'command', '__ansible_arguments__': {'_raw_params': 'echo ok'}}

    # With a block

# Generated at 2022-06-23 06:20:45.203625
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    display.verbosity = 4
    display.debug("test_load_list_of_tasks start")
    datastructs = list()
    new_task = dict()
    new_task['action'] = "shell"
    new_task['args'] = dict()
    new_task['args']['_raw_params'] = "id"
    datastructs.append(new_task)
    loader = None
    variable_manager = None
    task_list = load_list_of_tasks(ds=datastructs, play='', block=None, role='', task_include=None, use_handlers=False, variable_manager=variable_manager)
    display.debug("test_load_list_of_tasks len(task_list): %d" % (len(task_list)))

# Unit

# Generated at 2022-06-23 06:20:52.719422
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    """ Unit test for function load_list_of_roles """
    # Params
    ds, play, current_role_path, variable_manager, loader, collection_search_list = \
        [], None, None, None, None, None
    # Expected result
    result = []
    # Target test
    assert load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list) == result



# Generated at 2022-06-23 06:21:02.630934
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    play = Play.load({'hosts': 'all'})
    assert 9 == len(load_list_of_blocks([AnsibleUnicode('a'), AnsibleUnicode('b'), AnsibleUnicode('c')], play))
    assert 3 == len(load_list_of_blocks(AnsibleSequence([AnsibleUnicode('a'), AnsibleUnicode('b'), AnsibleUnicode('c')]), play))

# Generated at 2022-06-23 06:21:08.925345
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import TaskInclude
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 06:21:16.765778
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Just run the function and make sure the types are good
    rd = [{ "role": "test_role"}]
    play = Play()
    roles = load_list_of_roles(ds=rd, play=play, current_role_path="test_role_path", variable_manager=None, loader=None, collection_search_list=None)
    # Check number of items
    assert 1 == len(roles)
    # Check type
    assert isinstance(roles[0], RoleInclude)


# Generated at 2022-06-23 06:21:26.469596
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test loading list of roles with known inputs
    '''
    from ansible.plugins.loader import action_loader

    # Setup test parameter
    ds = [
        {'role': 'role1'},
        {'role': 'role2'},
        {'role': 'role3'},
    ]
    play = {}
    current_role_path = None
    collection_search_list = ['col1', 'col2']

    # Set up a mock for AnsibleLoader
    class mock_loader(object):

        def __init__(self):
            pass

        def path_dwim_relative(self, path, path2, name):
            return name

        def path_dwim(self, name):
            return name

        def load_from_file(self, path):
            return path



# Generated at 2022-06-23 06:21:32.997040
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class fakeobj(object): pass
    b = fakeobj()
    b.get_vars = lambda: {'foo': 'bar'}
    data = [
        {'include': 'file1'},
        {'include': 'file2'},
        {'include': '{{test_var}}', 'loop': '{{test_var_loop}}'},
        {'include': 'file4'}
    ]
    # TODO: This doesn't work because the file in the include task gets loaded as a TaskInclude
    # with a TaskInclude._parent
    # You can get past this if you fake out the _parent attribute when building the TaskInclude
    # but it's not something I want to add just for this test case
    #load_list_of_tasks(data, b, b, b, use_handlers=

# Generated at 2022-06-23 06:21:42.130561
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    # test_load_list_of_tasks: load a list of tasks, one at a time
    yield assert_true, isinstance(load_list_of_tasks([{'include': 'all'}], {}, {})[0], TaskInclude)
    yield assert_true, isinstance(load_list_of_tasks([{'raw': 'command'}], {}, {})[0], Task)

    # test_load_list_of_tasks: raise assertion error
    yield assert_raises, AnsibleAssertionError, load_list_of_tasks, 'test', {}, {}



# Generated at 2022-06-23 06:21:54.316353
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from collections import namedtuple
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.playbook import Playbook
    from ansible.playbook.play import Play
    from ansible.playbook.playbook_include import PlaybookInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    mock_loader = MagicMock()
    mock_variable_manager = MagicMock()
    mock_play = MagicMock()
    mock_collection_search_list = MagicMock()
    role1 = namedtuple('role', ['task_blocks'])
    role2 = namedtuple('role', ['task_blocks'])

    # role_defs = [(role, include_tasks),

# Generated at 2022-06-23 06:22:06.602280
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{'name': 'foo'}], None, None) == [{'name': 'foo'}]
    assert load_list_of_tasks([{'when': 'foo'}], None, None) == [{'when': 'foo'}]
    assert load_list_of_tasks([{'name': 'foo'}, {'name': 'bar'}], None, None) == [{'name': 'foo'}, {'name': 'bar'}]
    assert load_list_of_tasks([{'name': 'foo'}, {'when': 'bar'}], None, None) == [{'name': 'foo'}, {'when': 'bar'}]

# Generated at 2022-06-23 06:22:09.726587
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{'action': 'shell', 'args': ''}, {'block': []}]
    print(load_list_of_tasks(ds, None, None, None, None, False, None, None))


# Generated at 2022-06-23 06:22:18.878593
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.task_include import TaskInclude
    from ansible.plugins.loader import add_all_plugin_dirs


# Generated at 2022-06-23 06:22:30.796859
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.template import Templar
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    loader = DataLoader()

    host = Host(name='localhost')
    inventory = InventoryManager(loader=loader, sources=None)
    inventory.add_host(host, 'all')

    # Set variables
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create play with tasks

# Generated at 2022-06-23 06:22:39.305002
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    This function is used to test the load_list_of_blocks function.
    '''
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play

    ds = [
        {'block': '1'},
        {'block': '2'},
        {'task': {'name': '3'}},
        {'block': '4'},
    ]

    assert len(load_list_of_blocks(ds, Play(), role=RoleDefinition()))

# Generated at 2022-06-23 06:22:49.002812
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.parsing.vault import VaultLib
    from ansible.playbook.block import Block
    ds = [{'tasks': [{'when': "{{ True }}", 'debug': 'msg="{{ foo }}"'}]}, {'tasks': [{'when': "{{ True }}", 'debug': 'msg="{{ foo }}"'}]}]
    parent_block = Block()
    role = None
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    load_list_of_blocks(ds, parent_block, role=role, task_include=task_include, use_handlers=use_handlers, variable_manager=variable_manager, loader=loader)



# Generated at 2022-06-23 06:22:54.440133
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.reserved import DEFAULT_HASH_BEHAVIOUR

    ldr = DictDataLoader({})
    variable_manager = VariableManager(loader=ldr, host_vars=HostVars(hash_behaviour=DEFAULT_HASH_BEHAVIOUR, group_names=[]))

# Generated at 2022-06-23 06:23:06.356781
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.playbook.play import Play
    from ansible.playbook.included_file import IncludedFile
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.context_objects import AnsibleVaultEncryptedUnicode


# Generated at 2022-06-23 06:23:18.745065
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import sys
    import os
    import yaml
    import jinja2

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))

    from lib.ansible_module_common import ModuleArgsParser
    from ansible.errors import AnsibleUndefinedVariable, AnsibleParserError
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook import Playbook
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude

# Generated at 2022-06-23 06:23:25.122917
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    data = [
        {'role': 'foo'},
        {'role': 'foo', 'name': 'foo_1'},
        {'role': 'foo', 'name': 'foo_2', 'when': 'foo_condition'}
    ]
    mock_vm = MagicMock()
    mock_loader = MagicMock()
    roles = load_list_of_roles(data, MagicMock(), current_role_path='/root/mock_role', variable_manager=mock_vm, loader=mock_loader)
    assert len(roles) == 3
    assert roles[0].role_name == 'foo'
    assert roles[0]._name == 'foo'
    assert roles[0].when == 'all'
    assert roles[1].role_name == 'foo'

# Generated at 2022-06-23 06:23:36.280074
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext

    # create a fake play to use for loading roles.
    # the real 'play' just has some additional methods that wrap
    # a subset of the play context, but they don't do enough to test separately
    fake_play = PlayContext()
    fake_play._attributes = PlayContext._attributes
    fake_play.vars = dict()
    fake_play.vars_prompt = dict()
    fake_play.vars_files = list()
    fake_play.default_vars = dict()

    # create a fake loader