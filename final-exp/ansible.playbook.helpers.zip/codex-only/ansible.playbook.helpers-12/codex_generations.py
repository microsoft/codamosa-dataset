

# Generated at 2022-06-23 06:13:44.330356
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.block import Block
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    from ansible.parsing.dataloader import DataLoader

    from io import StringIO

    loader = DataLoader()

    as_hosts = "localhost,"
    as_hosts_vars = "{'ansible_ssh_hosts': 'localhost'}"

    # create inventory, so we can use it to get the variable manager
    inv = InventoryManager(loader=loader, sources=as_hosts)

# Generated at 2022-06-23 06:13:44.851444
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:13:51.764592
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.block
    task1 = dict(action='setup')
    task2 = dict(action='copy', src='/tmp/foo', dest='/tmp')
    block1 = dict(block='b1', tasks=[task1, task2])
    result = list(load_list_of_blocks([task1, block1]))
    assert result == [
        ansible.playbook.block.Block(None, [task1], ''),
        ansible.playbook.block.Block(None, [task2], 'b1'),
    ]


# Generated at 2022-06-23 06:14:01.462935
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude
    from ansible.inventory.manager import InventoryManager
    loader = DictDataLoader({})
    hosts = InventoryManager(loader=loader, sources='localhost,')

# Generated at 2022-06-23 06:14:02.012722
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert True


# Generated at 2022-06-23 06:14:13.296253
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:14:21.206715
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role import IncludeRole
    roles = load_list_of_roles(
        [
            {
                "name": "geerlingguy.java",
                "static": True
            },
            {
                "name": "geerlingguy.jenkins",
                "static": False
            }
        ],
        None,
        None,
        None,
        None,
        collection_search_list=[]
    )
    assert roles[0]._role_name == "geerlingguy.java"
    assert roles[0]._static is True
    assert roles[1]._role_name == "geerlingguy.jenkins"
    assert roles[1]._static is False



# Generated at 2022-06-23 06:14:27.393537
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Test load_list_of_roles
    '''
    ds = [
        {'role': 'test_role1'},
        {'role': 'test_role2'},
        {'role': 'test_role3'},
    ]

    r1 = load_list_of_roles(ds)
    assert len(r1) == 3
    assert r1[0].role_name == 'test_role1'
    assert r1[0].name == 'test_role1'
    assert r1[1].role_name == 'test_role2'
    assert r1[1].name == 'test_role2'
    assert r1[2].role_name == 'test_role3'
    assert r1[2].name == 'test_role3'



# Generated at 2022-06-23 06:14:28.912929
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # pass
    pass


# Generated at 2022-06-23 06:14:30.730057
# Unit test for function load_list_of_roles
def test_load_list_of_roles(): # TODO: unit test
    pass

# Generated at 2022-06-23 06:14:42.034803
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    mock_role = MagicMock(name='mock_role')
    mock_role_name = Mock(name='mock_role_name', return_value='test_role_name')
    mock_role.get_name.return_value = mock_role_name

    mock_role_path = MagicMock(name='mock_role_path')
    mock_role_path.return_value = None

    mock_roles_result = MagicMock(name='mock_roles_result')
    mock_roles_result.return_value = [mock_role]


# Generated at 2022-06-23 06:14:53.512127
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(["tests/inventory"], loader=None)
    variable_manager = VariableManager(loader=None, inventory=inventory)


# Generated at 2022-06-23 06:14:56.812512
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    """
    This is a unit test for the corresponding helper function:
        - ansible.parsing.dataloader.load_list_of_tasks
    """
    # TODO: add unit test here



# Generated at 2022-06-23 06:15:07.050306
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    #setup classes
    class TestPlay:
        pass
    TestPlay.name = 'testplay'
    testplay = TestPlay()
    testplay.name = 'testplay'

    class TestBlock:
        pass
    TestBlock.name = 'testblock'
    testblock = TestBlock()
    testblock.name = 'testblock'

    class TestTask:
        pass
    TestTask.name = 'testtask'
    testtask = TestTask()
    testtask.name = 'testtask'

    class TestRole:
        pass
    TestRole.name = 'testrole'
    testrole = TestRole()
    testrole.name = 'testrole'

    class TestTaskInclude:
        pass
    TestTaskInclude.name = 'testtaskincludetask'
    testtaskinclude = TestTaskInclude()

# Generated at 2022-06-23 06:15:16.533727
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [
        {'block': {'name': 'install haproxy'}},
        {'yum': 'name=haproxy state=latest'},
        {'template': 'src=haproxy.cfg.j2 dest=/etc/haproxy/haproxy.cfg'},
        {'command': 'service haproxy reload'},
        {'block': {'name': 'install haproxy'}},
        {'yum': 'name=haproxy state=latest'},
        {'template': 'src=haproxy.cfg.j2 dest=/etc/haproxy/haproxy.cfg'},
        {'command': 'service haproxy reload'},
    ]
    from ansible.playbook.play import Play
    from ansible.playbook import Playbook
    from ansible.playbook.block import Block

# Generated at 2022-06-23 06:15:18.159818
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: Add test
    return True

# Generated at 2022-06-23 06:15:30.038822
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''Testing the load_list_of_tasks function'''
    import ansible.vars.manager
    import ansible.template.safe_eval
    import ansible.template.templar
    import ansible.template.vars

    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_context import RoleContext
    from ansible.playbook.task import Task

    # test variables

# Generated at 2022-06-23 06:15:42.202278
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # init
    from ansible.playbook.block import Block
    res_load_list_of_blocks = load_list_of_blocks(None, None, None, None, None, None, None, None)
    assert len(res_load_list_of_blocks) == 0

    res_load_list_of_blocks = load_list_of_blocks([], None, None, None, None, None, None, None)
    assert len(res_load_list_of_blocks) == 0

    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    # role without task
    role = RoleDefinition.load(dict(name="role1", tasks=[]), None, None, None)

# Generated at 2022-06-23 06:15:53.374512
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: rewrite once we have a real yaml parser
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins import loader as plugin_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    plugin_loader.add_all_plugin_dirs()
    pc = PlayContext()
    role_name = 'test_role'
    role_path = './lib/ansible/modules/network/nxos'
    role_path_to_file = './lib/ansible/modules/network/nxos/test_role.yml'
    ds = [
        {'name': 'test_role'}
    ]
    play = {"name": "test play"}

    # Test searching for an unqualified role in the collection search list
   

# Generated at 2022-06-23 06:15:57.310485
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    '''
    Tests the load_list_of_blocks function.
    '''
    pass

# Generated at 2022-06-23 06:16:07.173901
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # Create a list to pass to the function
    ds = [['a'], ['b']]
    
    # Create dummy object to pass to function
    play = 'none'
    parent_block = 'none'
    role = 'none'
    task_include = 'none'
    use_handlers = 'none'
    variable_manager = 'none'
    loader = 'none'
        
    # Get the list that should be returned
    result = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    
    # Get the list that we expect to be returned
    answer = Block.load(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    
    # Compare the two lists

# Generated at 2022-06-23 06:16:09.062482
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([], None, None, None, None, False, None, None) == []
    assert load_list_of_tasks(None, None, None, None, None, False, None, None) is None

# Generated at 2022-06-23 06:16:17.129906
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

# Generated at 2022-06-23 06:16:24.399449
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    #arrange
    ds = [{u'role': "role name"}]
    play = None
    current_role_path=None
    variable_manager=None
    loader=None
    collection_search_list=None

    #act
    actual = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)

    #assert
    assert isinstance(actual, list)
    assert len(actual) == 1



# Generated at 2022-06-23 06:16:35.749085
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager

    group = 'all'
    base_path = '.'
    inventory_manager = InventoryManager(loader=AnsibleLoader(None), sources=[base_path + '/hosts'])
    variable_manager = VariableManager(loader=AnsibleLoader(None), inventory=inventory_manager)

    data = {
        'name': 'check_all_the_things',
        'hosts': group,
        'tasks': [
            {'yum': 'name=httpd state=latest'},
            {'service': 'name=httpd state=restarted'}
        ]
    }
    play

# Generated at 2022-06-23 06:16:42.349986
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import action_loader, cache_loader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    def init_vault_secrets(loader, passwords=None):
        vault_secrets_filename = loader.path_dwim_relative(loader.get_basedir(), 'ansible-vault', '.vault_pass')
        if passwords is None:
            passwords = {}
        loader.set_vault_secrets(passwords)
        return vault_secrets_filename

    # Random

# Generated at 2022-06-23 06:16:53.480569
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    loader, inventory, variable_manager = Mock(), Mock(), Mock()
    load_list_of_blocks(
        ds=[
            {
                'block': 'no-name',
                'rescue': [
                    {
                        'block': 'no-name',
                        'rescue': [
                            {
                                'meta': 'no-action'
                            }
                        ]
                    }
                ]
            },
            {
                'block': 'no-name',
                'rescue': [
                    {
                        'meta': 'no-action'
                    }
                ]
            },
            {
                'meta': 'no-action'
            }
        ],
        play=Mock(),
        loader=loader,
        inventory=inventory,
        variable_manager=variable_manager
    )


# Generated at 2022-06-23 06:16:54.817840
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # This will throw an error for coverage.
    load_list_of_tasks(12, None, None, None, None, True, None, None)


# Generated at 2022-06-23 06:17:02.175844
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ansible.utils.platform.Platform.set_platform("SE_Linux")
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.plugins import module_loader
    from ansible.vars.hostvars import HostVars
    from ansible.vars.pipe_vars import PipeVars


    variable_manager = VariableManager()
    loader = DataLoader()

# Generated at 2022-06-23 06:17:08.768531
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play import Play
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.parsing.convert_bool import boolean
    from ansible.vars.manager import VariableManager
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import combine_hash
    from ansible.template import Templar
    from ansible.utils.display import Display

    display = Display()
    vars_manager = VariableManager()
    loader = DataLoader()
    options = Options()
    options.connection = 'local'
    options.module_path = './lib'
    options.forks = 10
    options.become = None
    options.become_method = None
    options.become_user = None
    options.remote_

# Generated at 2022-06-23 06:17:16.481902
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # TODO: fix this test
    return
    from ansible.playbook.block import Block
    ds = [5]                                                                                                                                                                                                                
    play = 5                                                                                                                                                                                                              
    parent_block = 5                                                                                                                                                                                                     
    role = 5                                                                                                                                                                                                             
    task_include = 5                                                                                                                                                                                                      
    use_handlers = 5                                                                                                                                                                                                      
    variable_manager = 5                                                                                                                                                                                                  
    loader = 5                                                                                                                                                                                                            
    variable_manager = 5                                                                                                                                                                                                  
    loader = 5

# Generated at 2022-06-23 06:17:26.052101
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # Test loading a role definition which is a dictionary of role attributes
    role_dict = dict(name='test_role')
    role = load_list_of_roles([role_dict], None)[0]
    assert role.name == 'test_role'
    assert role.vars == {}

    # Test loading a role definition which is a list of role attributes
    role_list = [dict(name='test_role', vars=dict(a='b'))]
    role = load_list_of_roles(role_list, None)[0]
    assert role.name == 'test_role'
    assert role.vars == dict(a='b')

    # Test loading a role name using the newer list format with attributes
    role_list = [dict(role='test_role', vars=dict(a='b'))]

# Generated at 2022-06-23 06:17:37.207163
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # init connection plugin manager
    from ansible.plugins import connection_loader
    connection_loader.add_directory(C.DEFAULT_CONNECTION_PLUGIN_PATH)
    import ansible.constants as C
    C._ANSIBLE_INVENTORY_PLUGINS_PATH_SENTINEL = "./"
    # init inventory plugin manager
    from ansible.plugins import inventory_loader
    inventory_loader.add_directory(C.DEFAULT_INVENTORY_PLUGIN_PATH)
    # init loader plugin manager
    from ansible.plugins import module_loader
    module_loader.add_directory(C.DEFAULT_MODULE_PATH)
    # init filter plugin manager
    from ansible.plugins import filter_loader

# Generated at 2022-06-23 06:17:38.040798
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:17:49.644246
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    roles = [
        {'name': 'test_role'},
        {'name': 'test_role2', 'tags': ['foo', 'bar', 'baz']},
        {'include': 'test_role3', 'tags': ['baz']},
        {'include': 'test_role3'},
        {'name': 'test_role4', 'tasks': [{'debug': {'msg': 'Hello, World!'}}]}
    ]

    loader = DictDataLoader({})
    g = GlobalDict()
    pm = PlaybookManager(loader=loader, variable_manager=VariableManager(), options=Options(g))

# Generated at 2022-06-23 06:17:54.341627
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = {'action': 'foo', 'args': 'bar'}
    role = None
    task_include = None
    use_handlers = False
    block = None
    play = None
    variable_manager = None
    loader = None
    ds = [task_ds]
    test_load_list_of_tasks = load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)
    assert test_load_list_of_tasks[0].name == 'foo'

# Generated at 2022-06-23 06:18:07.028651
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    import ansible.constants as C
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    # import mock
    from unittest.mock import patch, Mock
    mock_loader = Mock()
    mock_loader.path_dwim_relative.return_value = 'hello world!'
    mock_loader.list_directory.return_value = ['file1.yml', 'file2.yml']
    mock_loader.get_basedir.return_value = 'some_path'
    mock_loader.path_dwim.return_value = 'some_path/file.yml'

# Generated at 2022-06-23 06:18:18.461194
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.vars.facts import FactCache
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.collections.ansible.stdlib.tests.unit.test_role_defaults_vars.mock_role import MockRole

# Generated at 2022-06-23 06:18:25.964825
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.playbook.task import Task

    y_obj = AnsibleBaseYAMLObject()
    load_list_of_blocks([])  # should not fail
    load_list_of_blocks(None)  # should not fail
    load_list_of_blocks([True])  # should fail
    load_list_of_blocks([y_obj])  # should fail
    load_list_of_blocks([Task(), Task()])  # should not fail


# Generated at 2022-06-23 06:18:37.720719
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test
    assert load_list_of_tasks([], block=None, role=None, task_include=None, use_handlers=False,
        variable_manager=None, loader=None) == []
    assert load_list_of_tasks(None, block=None, role=None, task_include=None, use_handlers=False,
        variable_manager=None, loader=None) == []

    assert load_list_of_tasks([0, 1], block=None, role=None, task_include=None, use_handlers=False,
        variable_manager=None, loader=None) == [0, 1]

# Generated at 2022-06-23 06:18:46.720824
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    global display

    ds = [
        {
            'action': {'module': 'debug', 'args': {'msg': 'hello world'}}
        },
        {'block': [{'action': {'module': 'debug', 'args': {'msg': 'goodbye'}}}]},
        {'action': {'module': 'debug', 'args': {'msg': 'hello again'}}},
    ]

    # we import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task

    play = Play()
    block = Block()

# Generated at 2022-06-23 06:18:54.298674
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_source =  dict(
        name = "Ansible Play 1",
        hosts = 'localhost',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
         ]
    )
   

# Generated at 2022-06-23 06:19:05.506299
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():

    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import module_loader, fragment_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import connection_loader
    from ansible.plugins.loader import callback_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import strategy_loader
    from ansible.plugins.loader import test_loader
    from ansible.plugins.loader import vars_loader
    from ansible.plugins.loader import fragment_loader
    from ansible.vars.reserved import reserved_variables

    # test_load_list_of_tasks
    # We want this to raise an error since a non dict is passed in

# Generated at 2022-06-23 06:19:17.341423
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [{'include': 'roles/test'}]
    play = Play()
    role = Role()
    task_include = TaskInclude()
    use_handlers = False
    variable_manager = VariableManager()
    loader = DataLoader()
    # FIXME: converting to list here because we have a circular dependency
    #        with imports.py, which is imported by most modules

# Generated at 2022-06-23 06:19:17.811386
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:19:19.347684
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''Testing function load_list_of_tasks'''
    pass

# Generated at 2022-06-23 06:19:23.575349
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.errors import AnsibleError, AnsibleUndefinedVariable
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import action_loader, cache_loader, callback_loader, connection_loader, lookup_loader, module_loader, shell_loader, strategy_loader, test_loader, vars_loader

    # set up plugins
    action_loader.add_directory(os.path.join(os.path.dirname(__file__), '../../lib/ansible/plugins/action'))

# Generated at 2022-06-23 06:19:25.930444
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    play = Play().load({}, variable_manager=None, loader=None)
    assert len(load_list_of_roles(["ping"], play)) == 1



# Generated at 2022-06-23 06:19:37.542698
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # We need to create a test PlayContext as a workaround to not having
    # the ability to instantiate a Play object directly
    p = Play()
    p.hosts = Hosts()
    pc = PlayContext()
    p.set_loader(DataLoader())
    p.set_variable_manager(VariableManager())
    p.set_options(Options())

    # Create a role and add it to the defined roles for the play
    this_path = os.path.dirname(__file__)
    r = Role()
    r._role_name = 'role1'
    r._role_path = os.path.join(this_path, 'roles', 'role1')
    p.roles_definition.append(r)

    # Create the roles list to load

# Generated at 2022-06-23 06:19:51.205408
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # given
    test_dir = os.path.dirname(os.path.realpath(__file__))
    test_file = os.path.join(test_dir, "data", "test_playbook_tasks.yaml")

    # when
    with open(test_file, 'rb') as f:
        ds = yaml.safe_load(f.read())

    # then
    assert(len(ds) == 5)
    ds = ds[0]
    args_parser = ModuleArgsParser(ds)
    assert('name' in ds)
    assert('tasks' in ds)
    assert(ds['name'] == 'rhel-server')
    assert(len(ds['tasks']) == 2)

# Generated at 2022-06-23 06:20:02.558140
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    yaml_str = '''
    - name: this task is a test
    - name: so is this one
    - name: and another one
      block:
        - name: this is in a block 1
        - name: this is in a block 2
          block:
            - name: this is in a block 2
              block:
                - name: this is in a block 2
                  block:
                    - name: this is in a block 2
    '''


# Generated at 2022-06-23 06:20:13.942288
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from .test_data import TEST_DATA_DIR

    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    variable_manager = VariableManager()
    play_context = PlayContext(loader=loader, variable_manager=variable_manager)

    ds_path = os.path.join(TEST_DATA_DIR, 'playbook_1.yml')
    ds = loader.load_from_file(ds_path)
    blocks = load_list_of_blocks(ds, play_context)

    # Unit test that we got the right number of blocks
    assert len(blocks) == 2

    # Unit

# Generated at 2022-06-23 06:20:20.284800
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar

    from ansible.vars.manager import VariableManager

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play_context import PlayContext

    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import become_loader
    from ansible.plugins.loader import cache_loader

# Generated at 2022-06-23 06:20:32.380765
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader


    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_context = PlayContext()

# Generated at 2022-06-23 06:20:43.948795
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{'block': {'name': 'myblock', 'tasks': [] }}], []) == [{'block': {'block': [], 'name': 'myblock', 'tasks': []}}]
    assert load_list_of_tasks([{'debug': {'msg': 'hello'}}], []) == [{'debug': {'msg': 'hello'}}]
    assert load_list_of_tasks([{'debug': {'msg': 'hello'}}, {'block': {'name': 'myblock', 'tasks': [] }}], []) == [{'debug': {'msg': 'hello'}}, {'block': {'block': [], 'name': 'myblock', 'tasks': []}}]

# Generated at 2022-06-23 06:20:55.458210
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    test_loader = DictDataLoader({})
    test_inventory = InventoryManager(loader=test_loader, sources=[])
    test_variable_manager = VariableManager(loader=test_loader, inventory=test_inventory)

    # test load fails on a string instead of a dict
    with pytest.raises(AnsibleAssertionError):
        load_list_of_roles(['-src: src.role', 'role2'], play=Play(), current_role_path=None, variable_manager=test_variable_manager, loader=test_loader)

    # test role parses correctly
    test_load = ['role1']

# Generated at 2022-06-23 06:21:04.443086
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook.block
    import ansible.playbook.block as block

# Generated at 2022-06-23 06:21:12.450184
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [{'role_name': 'foo'}]
    play = object()
    current_role_path = None
    variable_manager = object()
    loader = object()
    collection_search_list = None

    result = load_list_of_roles(ds, play, current_role_path, variable_manager, loader, collection_search_list)
    assert isinstance(result, list)
    assert isinstance(result[0], RoleInclude)


# Generated at 2022-06-23 06:21:21.069982
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    play_obj = Play()

    def mock_block_load(self, ds, play=None, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None):
        return ds

    Block.load = mock_block_load


# Generated at 2022-06-23 06:21:32.372398
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    # load_list_of_blocks(ds, play, parent_block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    ds = [{"task": {"name": "test task"}},
{"task": {"name": "test task2"}},]

    #this may cause problem in future.
    result_list = load_list_of_blocks(ds)
    assert isinstance(result_list[0].block, Block)
    assert result_list[1].block == None
    assert result_list[0].task_list[0].name == "test task"
    assert result_list[0].task_list[1].name == "test task2"

# Generated at 2022-06-23 06:21:39.425311
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    ds = [{
        'include_tasks': '{{ foo }}',
        'static': True
    }]
    play = None
    block = None
    role = "test"
    task_include = None
    use_handlers = False
    variable_manager = None
    loader = None
    load_list_of_tasks(ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-23 06:21:51.103433
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import context
    from ansible.config.manager import ConfigManager
    from ansible.plugins.loader import action_loader
    from ansible.template import Templar
    from units.mock.loader import DictDataLoader
    from units.mock.path import mock_unfrackpath_noop

    # set up expected inputs to load_list_of_roles
    loader = DictDataLoader({})
    context.CLIARGS = ImmutableDict(connection='local', module_path=None, forks=10, become=None,
                                    become_method=None, become_user=None, check=False, diff=False)
    config_manager = ConfigManager(loader.load_from_file(fixture_path('config/ansible.cfg')))

# Generated at 2022-06-23 06:22:00.940635
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from io import StringIO
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import RoleInclude
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=variable_manager, host_list=[])

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        roles=[dict(role="foo"), dict(role="bar")]
    )

    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)


# Generated at 2022-06-23 06:22:01.651108
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:22:11.955530
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_list = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(play, Play)
    task_list = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=True, variable_manager=None, loader=None)
    assert isinstance(play, Play)
    task_list = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    assert isinstance(play, Play)

# Generated at 2022-06-23 06:22:22.887871
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    class PlayDS():
        def __init__(self):
            self.name='PlayDS'
            self.hosts=['127.0.0.1']
            self.connection='local'
            self.gather_facts=True
        def serialize(self):
            return dict()
    class MockLoader():
        def initialize(self, host):
            return None
        def get_basedir(self, host):
            return None
        def load_from_file(self, filename):
            return dict()

# Generated at 2022-06-23 06:22:32.078049
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    class FakePlay(object):
        pass

    fake_play = FakePlay()
    fake_play.vars = {}
    fake_play.options = {}
    fake_play.options['roles_path'] = 'fake_roles_path'
    fake_play._ds_loader = FakeLoader(fake_play.vars)

    roles = load_list_of_roles([['fake_role_name']], fake_play)

    assert len(roles) == 1
    assert roles[0].name == 'fake_role_name'
    assert roles[0]._role_path == '/fake_roles_path/fake_role_name'



# Generated at 2022-06-23 06:22:37.399965
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    data = [{
        'role': 'my-role',
    }, {
        'role': 'my-second-role',
    }]

    ds = load_list_of_roles(ds=data, play=None, current_role_path=None, variable_manager=VariableManager(), loader=DataLoader())
    assert len(ds) == 2

# Generated at 2022-06-23 06:22:49.429558
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role import Role
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.play import Play
    from ansible.plugins.loader import vars_loader

    ds_example = [
        {'role': 'role1', 'tasks': ['hello world']},
        {'role': 'role2'},
        {'role': 'role3'},
        {'role': 'role4', 'tasks': ['hello world']},
    ]

    play = Play()
    names = load_list_of_roles(ds_example, play, vars_loader)

    assert len(names) == 4
    assert isinstance(names[0], RoleInclude)

# Generated at 2022-06-23 06:23:05.481383
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import yaml
    from ansible.playbook.play_context import PlayContext

    c = PlayContext()
    my_loader = DictDataLoader({})
    my_variable_manager = VariableManager()
    my_variable_manager.extra_vars = {'a': 3}

    t1 = {'include': 'foo.yaml'}
    t2 = {'include': 'foo2.yaml'}
    block = {'block': [t1, t2]}

    # Load the block and get the list of blocks
    pb = load_list_of_blocks(yaml.safe_load(block), play=None, variable_manager=my_variable_manager, loader=my_loader)[0]

    # Ensure the include files are on the block
    b = pb.block[0]
    assert isinstance

# Generated at 2022-06-23 06:23:13.703096
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert load_list_of_tasks([{}]) == []
    assert load_list_of_tasks(['foo']) == []
    assert load_list_of_tasks([{'block': 'block'}])
    assert load_list_of_tasks([{'include': 'include'}])
    assert load_list_of_tasks([{'include_tasks': 'include_tasks'}])
    assert load_list_of_tasks([{'import_tasks': 'import_tasks'}])
    assert load_list_of_tasks([{'import_role': 'import_role'}])
    assert load_list_of_tasks([{'include_role': 'include_role'}])



# Generated at 2022-06-23 06:23:23.441360
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from units.mock.loader import DictDataLoader

    # Test proper roles
    mock_loader = DictDataLoader({
        "role1": """
        - hosts: webservers
          roles:
            - role1
            - role2
        """,
        "role2": """
        - hosts: webservers
          roles:
            - role1
            - role2
        """}
    )
    from ansible.vars.manager import VariableManager
    mock_vm = VariableManager()
    from ansible.playbook.play import Play
    empty_play = Play().load(dict(), variable_manager=mock_vm, loader=mock_loader)

# Generated at 2022-06-23 06:23:24.308922
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:23:34.903148
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():  # noqa
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.play_context import PlayContext
