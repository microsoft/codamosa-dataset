

# Generated at 2022-06-23 06:13:36.120598
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert False, "No test for function load_list_of_roles"

# Generated at 2022-06-23 06:13:45.965789
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])

# Generated at 2022-06-23 06:13:57.974813
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # we import here to prevent a circular dependency with imports
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.vars.manager import VariableManager
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import Variable
    from ansible.vars.hostvars import HostVarsVars

    loader = DictDataLoader({})
    inv = Inventory(loader=loader, variable_manager=VariableManager(loader=loader, inventory=None))
    host = Host(name='example.org')
    group = Group(name='group')
    group.add_host(host)
    inv.add_group(group)
    inv.add_host(host)


# Generated at 2022-06-23 06:13:58.531435
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:13:59.568031
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():

    ## TODO: unit test.
    pass



# Generated at 2022-06-23 06:14:08.095003
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.role import Role
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.template import Templar
    from ansible.vars import VariableManager

    Task_ds = {
        'name': 'task1',
        'action': 'ls',
    }
    task_block_ds = [
        Task_ds,
        {
            'name': 'task2',
            'action_inherited': 'ls',
        },
        {
            'block1': 'block1',
            'block': [
                {
                    'name': 'task3',
                    'action': 'ls'
                }
            ]
        }
    ]

# Generated at 2022-06-23 06:14:08.889067
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass

# Generated at 2022-06-23 06:14:18.312073
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import ansible.playbook
    ds = [{'block': []}, {'block': []}]
    play = ansible.playbook.Play()
    parent_block = ansible.playbook.Block()
    role = ansible.playbook.Role()
    task_include = ansible.playbook.TaskInclude()
    use_handlers = False
    loader = None
    variable_manager = ansible.vars.VariableManager()
    block_list = load_list_of_blocks(ds, play, parent_block, role, task_include, use_handlers, variable_manager, loader)
    assert isinstance(block_list, list)
    assert len(block_list) == 2


# Generated at 2022-06-23 06:14:24.036934
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler import Handler
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.role_include import IncludeRole
    from ansible.plugins import module_loader
    from ansible.vars import VariableManager
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-23 06:14:35.025485
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.role.include import IncludeRole
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.block import Block
    from yaml.nodes import MappingNode

    mock_loader = DictDataLoader({})

    play_ds = dict(
        name="test play",
        hosts=['localhost']
    )
    play = Play.load(play_ds, loader=mock_loader)


# Generated at 2022-06-23 06:14:44.022462
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.errors import AnsibleParserError
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.playbook_executor import PlaybookExecutor
    import tempfile
    import shutil
    import sys
    import pytest
    import os
    import os.path

    with tempfile.NamedTemporaryFile(mode='wt') as tf:
        # Create ansible.cfg
        cwd = os.getcwd()
       

# Generated at 2022-06-23 06:14:47.550874
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert isinstance(load_list_of_roles("ds,play,variable_manager,loader", "play", "current_role_path", "variable_manager", "loader, collection_search_list"), list)


# Generated at 2022-06-23 06:14:57.129120
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from units.mock.loader import DictDataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager


# Generated at 2022-06-23 06:15:07.319139
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.play import Play
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.template import Templar


# Generated at 2022-06-23 06:15:14.432884
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    class VariableManager():
        def __init__(self):
            self.options = 'options'

    variable_manager = VariableManager()
    task_ds = [{'include_tasks': 'tasks/main.yml'}]
    play = 'play'
    block = 'block'
    role = 'role'
    task_include = 'task_include'
    use_handlers = False
    loader = 'loader'
    load_list_of_tasks(task_ds, play, block, role, task_include, use_handlers, variable_manager, loader)

# Generated at 2022-06-23 06:15:21.146320
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.role.include import RoleInclude

    assert isinstance(load_list_of_roles(
        [{'role': 'some_role'}],
        play=None,
        current_role_path=None,
        variable_manager=None,
        loader=None,
        collection_search_list=None
    )[0], RoleInclude)

# Generated at 2022-06-23 06:15:31.900517
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.template import Templar

    loader = DataLoader()
    variable_manager = VariableManager()
    play = Play().load(dict(
        name = "Ansible Play",
        hosts = 'all',
        gather_facts = 'no',
        tasks = [
            dict(action=dict(module='shell', args='ls'), register='shell_out'),
            dict(action=dict(module='debug', args=dict(msg='{{shell_out.stdout}}')))
        ]
    ), variable_manager=variable_manager, loader=loader)
    templar

# Generated at 2022-06-23 06:15:34.747428
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    assert load_list_of_roles.__name__ == 'load_list_of_roles'


# Generated at 2022-06-23 06:15:46.199467
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    
    play_context = PlayContext()
    play = Play.load({}, variable_manager=None, loader=None)
    tasks = load_list_of_tasks([{'block': [{'block': [{'include_role': {'name': 'test_role'}}], 'name': 'test_block'}], 'name': 'test_block'}, {'include_role': {'name': 'test_role'}}], play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)
    print(tasks)

# Generated at 2022-06-23 06:15:56.286832
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:16:06.612090
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.task import Task
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    def _get_play(play_name, loader, variable_manager, inventory, blocks):
        play_ds = dict(
            name=play_name,
            hosts='all',
            gather_facts='no',
            roles=[]
        )
        play = Play.load(play_ds, loader=loader, variable_manager=variable_manager, inventory=inventory)
        play

# Generated at 2022-06-23 06:16:09.046470
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert False, "need to write a unit test"



# Generated at 2022-06-23 06:16:09.689692
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:16:24.269357
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role

    ds = [{
        'block': 'foo',
        'block': [
            {'task': 'foo', 'block': 'foo'},
            {'task': 'bar', 'block': 'bar'},
        ]
    },
    {'task': 'foo', 'block': 'foo'}]

# Generated at 2022-06-23 06:16:35.636150
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # test load_list_of_roles
    from units.mock.loader import DictDataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.task_queue_manager import MockTaskQueueManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.module_utils.six import StringIO


# Generated at 2022-06-23 06:16:36.426085
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass

# Generated at 2022-06-23 06:16:45.803292
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    import pytest

    ds = pytest.helpers.mock_data('test.pb.1')
    variable_manager = VariableManager()
    variable_manager._extra_vars = {"var1": 1}
    variable_manager._fact_cache = {}
    variable_manager._nonpersistent_fact_cache = {}

# Generated at 2022-06-23 06:16:57.404724
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import os
    import sys
    import shutil
    from collections import namedtuple

    from ansible.release import __version__
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
    from ansible.module_utils.six import string_types
    from ansible.utils.display import Display
    from ansible.utils.color import stringc
    from ansible.playbook import Playbook
    from ansible.template import Templar
    from ansible.errors import AnsibleError, AnsibleOptionsError, AnsibleUndefinedVariable, AnsibleParserError, AnsibleAssertionError, AnsibleUndefinedVariable
    import ansible.playbook.role.include
    import ansible.playbook.role.definition
    import ansible.playbook.tqdm
    display = Display()



# Generated at 2022-06-23 06:17:01.993571
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block


    assert load_list_of_blocks(None, None) == []

    assert load_list_of_blocks([], None) == []



# Generated at 2022-06-23 06:17:08.609758
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Given a list of task datastructures (parsed from YAML),
    return a list of Task() or TaskInclude() objects.
    '''
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.template import Templar
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.context import strip_internal_keys, CLIARGS

# Generated at 2022-06-23 06:17:09.321673
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True



# Generated at 2022-06-23 06:17:16.858501
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.modules.system import ping
    from ansible.playbook.block import Block
    from ansible.playbook.role import Role
    from ansible.playbook.task import Task


# Generated at 2022-06-23 06:17:17.735384
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass



# Generated at 2022-06-23 06:17:28.683938
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    current_role_path = None

    # ds(play and loader are not used, but are required when running the real function)
    # ds(loader is not used, but is required when running the real function)
    loader = DataLoader()
    # ds(play is not used, but is required when running the real function)
    play = Play()

    variable_manager = VariableManager()

    # ds(use_handlers is not used, but is required when running the real function)
    use_handlers = False

    # ds(role is not used, but is required when running the real function)
    role = Role()

    # ds(task_include is not used, but is required when running the real function)
    task_include = TaskInclude()
    # ds(block is not used, but is required when running the real

# Generated at 2022-06-23 06:17:39.023487
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:17:49.643791
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    '''
    Ensure loading of roles defaults and data is as expected

    '''
    with open('test/ansible_test/playbook/playbook_data/playbook_role_default_data.yml') as test_data_file:
        test_data = yaml.safe_load(test_data_file)
    ds = test_data['data']

    r = load_list_of_roles(ds, None)
    assert len(r) == 1
    assert r[0].name == 'foobar'
    assert r[0].role_path == '/tmp/ansible/roles/foobar'
    assert r[0].role_uuid == 'ABC123'
    assert r[0]._role_name == 'foobar'



# Generated at 2022-06-23 06:17:50.247318
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert 1 == 1

# Generated at 2022-06-23 06:17:59.218962
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    # We import here to prevent a circular dependency with imports
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    example_block_list = [
        {
            'block': [
                {'tasks': [{'debug': 'var=inventory_hostname'}],
                 'name': 'test',
                 'rescue': []
                 },
                {'include_role': {'name': 'name_of_role'}}],
            'name': 'test'
        },
        {
            'block': [{'debug': 'var=inventory_hostname'}],
            'name': 'test'
        },
        {'debug': 'var=inventory_hostname'}
    ]

# Generated at 2022-06-23 06:18:06.276456
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    def mock_load(ds, play, current_role_path, variable_manager, loader, collection_search_list):
        return ds
    try:
        from ansible.playbook.role.include import RoleInclude
        RoleInclude.load = mock_load
    except ImportError:
        pass
    result = load_list_of_roles([{'name': 'foo'}, {'name': 'bar'}], play=object(), current_role_path=None, variable_manager=None, loader=None, collection_search_list=None)
    assert result == [{'name': 'foo'}, {'name': 'bar'}]

# Generated at 2022-06-23 06:18:16.689365
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import ansible.parsing.dataloader
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = ansible.vars.manager.VariableManager()

    ds = [dict(block=dict(name='test'))]
    task_list = load_list_of_tasks(ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)
    assert task_list[0]._parent == None
    assert task_list[0]._play == None
    assert task_list[0].get_name() == 'test'



# Generated at 2022-06-23 06:18:17.688250
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    assert True


# Generated at 2022-06-23 06:18:25.861443
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.block import Block

    play = "test_play"
    parent_block = "test_parent_block"
    role = "test_role"
    task_include = "test_task_include"
    use_handlers = "test_use_handlers"

    ds1 = [{'block': 'b1'}, {'block': 'b2'}]
    ds2 = {'block': 'b1'}
    ds3 = [{'hosts': 'svr1', 'tasks': [{'debug': {'msg': "Hello World"}}]}]

    assert(len(load_list_of_blocks(ds1, play, parent_block, role, task_include, use_handlers)) == 2)

# Generated at 2022-06-23 06:18:26.749530
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    pass



# Generated at 2022-06-23 06:18:27.651944
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:18:32.558072
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    import json
    import yaml
    from ansible.playbook.play import Play
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars
    try:
        from __main__ import display
    except ImportError:
        from ansible.utils.display import Display
        display = Display()
    fake_loader=DataLoader()

# Generated at 2022-06-23 06:18:44.046781
# Unit test for function load_list_of_tasks

# Generated at 2022-06-23 06:18:52.454841
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play

    testcase = [
        {'hosts': 'localhost', 'tasks': [{'debug': {'var': 5}}]},
        {'local_action': {'module': 'debug', 'args': {'var': 1}}},
        {'yum': 'name=httpd state=latest'}
    ]

    play = Play.load(testcase, variable_manager=None, loader=None)
    blocks = load_list_of_blocks(testcase, play, parent_block=None, role=None, task_include=None, use_handlers=False,
                                 variable_manager=None, loader=None)

    assert len(blocks) == 3

    assert len(blocks[0].block) == 1
    assert len(blocks[1].block) == 1


# Generated at 2022-06-23 06:19:04.464978
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import ansible.playbook.role.include
    import ansible.playbook.role
    from ansible.plugins.loader import collection_loader, plugin_loader

    ds = [{"role": "common"}]
    play = ansible.playbook.Play.load({'name': 'test_play'})
    current_role_path = "test/test_roles"
    variable_manager = ansible.vars.manager.VariableManager()
    loader = ansible.parsing.dataloader.DataLoader()
    collection_search_list = []
    collection_list = collection_loader.list_collections()
    for c in collection_list:
        if c.startswith("ansible_collections.ansible.builtin"):
            collection_search_list.append(c)

# Generated at 2022-06-23 06:19:13.991059
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # setup
    from ansible.playbook import Play, PlayContext
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.task_queue_manager import TaskQueueManager
    from units.mock.loader import DictDataLoader
    loader = DictDataLoader({})
    play_source = dict(
            name = "Ansible Play",
            hosts = 'localhost',
            tasks = [{}]
        )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)
    inventory = InventoryManager(loader=loader, sources='localhost,')
    play_context = PlayContext()

# Generated at 2022-06-23 06:19:19.351435
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader

    pb = Playbook()
    tqm = TaskQueueManager(
        inventory=pb.inventory,
        variable_manager=pb.variable_manager,
        loader=pb.loader,
        passwords={"conn_pass": "password"},
    )
    play_context = PlayContext(pb.loader, pb.variable_manager, pb.options, pb.passwords)

# Generated at 2022-06-23 06:19:28.083091
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    import shutil
    import tempfile
    from ansible.errors import AnsibleError
    from ansible.parsing.yaml import objects
    from ansible.playbook.play import Play
    from ansible.playbook.role.definition import RoleDefinition
    from ansible.playbook.role.include import RoleInclude
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    from ansible.utils.path import unfrackpath


# Generated at 2022-06-23 06:19:35.793678
# Unit test for function load_list_of_roles
def test_load_list_of_roles():

    ds = [
        {
            "name": "test_role_include"
        },
    ]

    play = Mock()
    play.ROLE_CACHE = collections.OrderedDict()

    r = load_list_of_roles(ds, play)

    assert len(r) == 1, "One role should have been loaded"
    assert r[0].get_name() == "test_role_include", "The role should have been called test_role_include"



# Generated at 2022-06-23 06:19:38.015385
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    # TODO: This is a stub, replace as part of role test refactor
    pass

# Generated at 2022-06-23 06:19:51.504212
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    clear_cache()
    assert load_list_of_blocks([]) == []
    assert load_list_of_blocks(None) == []
    assert load_list_of_blocks([{'block': []}]) == [Block(tags=[], ignore_errors=False, always_run=False, register=None, rescue=None, when=None, delegate_to=None, name='', environment={}, run_once=False, task_vars={}, no_log=False, only_if=None, block=None, any_errors_fatal=False)]

# Generated at 2022-06-23 06:19:57.813765
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible.playbook.play import Play
    from ansible.playbook.task.include import TaskInclude
    from ansible.playbook.handler.include import HandlerInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback.default import CallbackModule
    from ansible.template import Templar
    # from ansible.playbook.role.include import RoleInclude

    loader = Loader()
    variable_manager = VariableManager()

    playbook = Play()
    hosts = [
        'localhost',
    ]

    from_yaml = """
    - hosts: localhost
      tasks:
        - include_tasks: tasks/test_task.yml
    """
    playbook_ds

# Generated at 2022-06-23 06:19:59.215487
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    pass


# Generated at 2022-06-23 06:19:59.912659
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    pass

# Generated at 2022-06-23 06:20:09.936510
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    import ansible.constants as C

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])

    variable_manager = VariableManager(loader=loader, inventory=inventory)


# Generated at 2022-06-23 06:20:15.393372
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role.definition import TaskInclude
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from io import StringIO
    import yaml


# Generated at 2022-06-23 06:20:24.157742
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(["a","b","c"]) == [Block(["a", "b", "c"])]
    assert load_list_of_blocks([[1,2,3],[4,5,6],[7,8,9]]) == [Block([[1,2,3]]), Block([[4,5,6]]), Block([[7,8,9]])]
    assert load_list_of_blocks([["a"],["b"],["c"]]) == [Block([[["a"]]]), Block([[["b"]]]), Block([[["c"]]])]
    assert load_list_of_blocks([[["a"]],[["b"]],[["c"]]]) == [Block([[["a"]]]), Block([[["b"]]]), Block([[["c"]]])]
    # The following tests

# Generated at 2022-06-23 06:20:35.381217
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.handler_task_include import HandlerTaskInclude
    from ansible.playbook import Play
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import module_loader
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleMapping
    VarsModule = namedtuple('VarsModule', ['setup_config'])


# Generated at 2022-06-23 06:20:39.222748
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(None,None,None,None,None,None,None,None) == []
    assert load_list_of_blocks(dict,None,None,None,None,None,None,None) == []


# Generated at 2022-06-23 06:20:47.645396
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    ds = [
        {'name': 'foo'},
        {'name': 'bar', 'foo': 'bar'}
    ]
    # Does not fail
    assert load_list_of_roles(ds, None)
    # raise an exception because current_role_path is not defined
    try:
        load_list_of_roles(ds, None, current_role_path=None)
        assert False, 'Exception not raised'
    except AnsibleParserError:
        pass  # Exception raised

    # raise an exception because current_role_path is not a path
    try:
        load_list_of_roles(ds, None, current_role_path='foo')
        assert False, 'Exception not raised'
    except AnsibleParserError:
        pass  # Exception raised


# Generated at 2022-06-23 06:20:59.474340
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    ds_list = [
        {
            'block': 'Test1',
            'rescue': [{'block': 'Rescue1'}],
            'always': [{'block': 'Always1'}]
        },
        {
            'task': 'testtask',
            'name': 'tasktest'
        }
    ]

    ds = ds_list[0]

    play_context = PlayContext()

# Generated at 2022-06-23 06:21:02.375670
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert load_list_of_blocks(None, None) is None
    with pytest.raises(TypeError):
        load_list_of_blocks([{'asdf': 'asdf'}], None)


# Generated at 2022-06-23 06:21:10.326960
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    texample = {
        'name': 'testtask'
    }
    texample2 = {
        'name': 'testtask2'
    }
    block_example = [ texample, Block.load(texample2) ]

    l1 = load_list_of_tasks([texample], use_handlers=False)
    l2 = load_list_of_tasks([Task.load(texample)], use_handlers=False)


# Generated at 2022-06-23 06:21:21.483405
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    # Test with empty list of tasks
    ds = []
    tasks = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert tasks == [], 'There should be no tasks for an empty list'

    # Test with one task
    ds = [{'include_tasks': 'tasks/main.yml'}]

    tasks = load_list_of_tasks(ds, None, None, None, None, False, None, None)
    assert len(tasks) == 1, 'There should be one task'
    assert tasks[0].__class__.__name__ == 'TaskInclude', 'The task should be a TaskInclude'

    # Test with two tasks

# Generated at 2022-06-23 06:21:29.748654
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    name_of_role = 'name_of_role'
    name_of_role_2 = 'name_of_role_2'
    role_def = {'role': name_of_role}
    role_def_2 = {'role': name_of_role_2}
    ds = [role_def, role_def_2]
    # Set up a Fake Play object
    play = Play()
    # Set up a Fake Role object
    current_role = Role()
    # Set up a Fake VariableManager object
    variable_manager = VariableManager()
    # Set up a Fake Loader object
    loader = Loader()
    collection_search_list = ['name_of_collection']

# Generated at 2022-06-23 06:21:40.078185
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    task_ds = [{
        'action': 'copy',
        'args': {
            'backup': 'no',
            'content': 'Hello Ansible',
            'dest': '/tmp/myfile.txt',
            'group': 'root',
            'mode': '0440'
        }
    }, {
        'action': 'copy',
        'args': {
            'backup': 'no',
            'content': 'Hello Ansible',
            'dest': '/tmp/myfile.txt',
            'group': 'root',
            'mode': '0440'
        }
    }]
    assert load_list_of_tasks(task_ds, play=None, block=None, role=None, task_include=None, use_handlers=False, variable_manager=None, loader=None)


# Generated at 2022-06-23 06:21:43.861515
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    try:
        load_list_of_blocks(1, None)
    except AnsibleAssertionError as e:
        assert "should be a list or None but is" in to_native(e)
    else:
        raise



# Generated at 2022-06-23 06:21:55.912541
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.task import Task
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    fake_loader = DictDataLoader({
        "test.yml": """
        - name: test task
        """,
    })
    ds = yaml.safe_load(StringIO("""
    - name: test task
    """))
    m = AnsibleBaseYAMLObject(4)
    m.source = 'test.yml'
    p = Play()
    p.name = 'test_play'
    p.post_validate()
    # FIXME: this should return a list of Task objects

# Generated at 2022-06-23 06:22:08.017963
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    from ansible import constants as C
    from ansible.release import __version__
    from ansible.playbook.play import Play
    from ansible.playbook.role_include import RoleInclude

# Generated at 2022-06-23 06:22:18.005421
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.plugins.loader import get_all_plugin_loaders


    def load_list_of_tasks_with_params(load_list_of_tasks_params):
        # print('load_list_of_tasks_params', str(load_list_of_tasks_params))
        # parameter initialization
        ds = load_list_of_tasks_params['ds']
        play = load_list_of_tasks_params['play']
        block = load_list_of_tasks_params['block']
        role = load_list_of_tasks_params['role']
        task_include = load_list_of_tasks_params['task_include']
        use_handlers = load_list_of_tasks

# Generated at 2022-06-23 06:22:27.358765
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.playbook.play_context import PlayContext
    from ansible.vars.manager import VariableManager
    import ansible.constants as C
    import ansible.inventory
    loader = DataLoader()
    inventory = ansible.inventory.Inventory(loader, C.DEFAULT_HOST_LIST)
    play_context = PlayContext()
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play = namedtuple('Play', ['name'])

# Generated at 2022-06-23 06:22:37.895195
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.playbook.play import Play
    from ansible.playbook.playbook import Playbook
    from ansible.vars.manager import VariableManager

    pb = Playbook.load('test_playbook.yaml', variable_manager=VariableManager(), loader=AnsibleLoader)

    assert pb.get_all_plays()[0].get_tasks()[0].action == 'test_action'
    assert pb.get_all_plays()[0].get_tasks()[0].args['test_arg'] == 'test_value'


# Generated at 2022-06-23 06:22:50.013368
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    class TestPlaybook(object):
        def __init__(self, *args, **kwargs):
            self.ROLE_PATH = '/usr/local/share/ansible/roles'

        def get_variable_manager(self):
            return None

        def get_loader(self):
            return None

    class TestRoleInclude(object):
        import_role_failed = False
        def __init__(self, *args, **kwargs):
            if TestRoleInclude.import_role_failed:
                raise AnsibleAssertionError()

    class TestLoader(object):
        def path_dwim(self, *args, **kwargs):
            if kwargs['best_matched'] is True:
                return "akindir/ansible.git/test/roles/rolename"

# Generated at 2022-06-23 06:23:04.853327
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    from ansible.vars.manager import VariableManager

    m = ansible.module_utils.basic.AnsibleModule(argument_spec={'include': {'type': 'dict'}})
    m.params = {"include": {"static": true, "tasks": ['task1.yml', 'task2.yml']}}
    ds = m.params
    loader = ansible.parsing.dataloader.DataLoader()
    variable_manager = VariableManager()
    task_list = load_list_of_tasks(ds, play, block=None, role=None, task_include=None, use_handlers=False, variable_manager=variable_manager, loader=loader)
    assert task_list == task_list

# Generated at 2022-06-23 06:23:10.278038
# Unit test for function load_list_of_roles
def test_load_list_of_roles():
    loader = DataLoader()
    roles = [{'role': 'test'}]
    role = load_list_of_roles(roles,
                              play=None,
                              current_role_path=None,
                              variable_manager=None,
                              loader=loader,
                              collection_search_list=None)[0]
    assert isinstance(role, RoleInclude)

# Generated at 2022-06-23 06:23:11.385393
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    assert True

# Generated at 2022-06-23 06:23:21.941659
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    import ansible.playbook.task
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.vars import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.inventory.host import Host, Group
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.vars.manager import VariableManager

# Generated at 2022-06-23 06:23:33.309144
# Unit test for function load_list_of_blocks
def test_load_list_of_blocks():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.task import Task
    from ansible.playbook.play import Play
    from ansible.playbook.block import Block
    from ansible.playbook.helpers import load_list_of_tasks

    test_play = Play.load({'name': 'test play'})
    test_task_include = TaskInclude.load({'name': 'test task include'})

    result = load_list_of_blocks({'tasks': [{'include_tasks': 'test.yml'}]}, test_play, role=test_task_include)

    assert len(result) == 1
    block = result[0]
    assert len(block._statements) == 1
    task = block._statements[0]
   

# Generated at 2022-06-23 06:23:43.398796
# Unit test for function load_list_of_tasks
def test_load_list_of_tasks():
    '''
    Unit test for function load_list_of_tasks
    '''
    import copy
    # we import here to prevent a circular dependency with imports
    from ansible.playbook.block import Block
    from ansible.playbook.task import Task
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.role_include import IncludeRole
    from ansible.playbook.handler_task_include import HandlerTaskInclude

    task_ds1 = {'action': 'a', 'b': 'c'}
    task_ds2 = {'block': 'a'}
    task_ds3 = {'include': 'b'}
    task_ds4 = {'include_role': 'b'}