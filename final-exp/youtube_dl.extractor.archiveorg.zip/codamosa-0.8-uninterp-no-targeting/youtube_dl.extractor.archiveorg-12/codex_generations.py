

# Generated at 2022-06-22 07:13:41.640687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    # pylint: disable=W0212

    from .common import InfoExtractor
    from .common import FileDownloader

    # Test for constructor of class FileDownloader
    test = FileDownloader(params={})
    assert test.params == {}

    # Test for constructor of class InfoExtractor
    test2 = InfoExtractor()
    assert InfoExtractor.suitable(None) == False

    # Test for constructor of class ArchiveOrgIE
    test3 = ArchiveOrgIE()
    assert ArchiveOrgIE.suitable(None) == False

# Generated at 2022-06-22 07:13:43.881810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveIE=ArchiveOrgIE()
    return("ArchiveOrgIE is configured")

# Generated at 2022-06-22 07:13:49.992847
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL ==\
           r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:50.961287
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE.__new__(ArchiveOrgIE)

# Generated at 2022-06-22 07:13:52.754564
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:13:57.692289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:59.915832
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'

# Unit tests for get_video_info()

# Generated at 2022-06-22 07:14:01.880907
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract(test_ArchiveOrgIE.url)

# Generated at 2022-06-22 07:14:08.660876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:20.003037
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import os
    this_dir = os.path.dirname(os.path.realpath(__file__))
    file_contents = open(os.path.join(this_dir, 'fixtures', 'archive.org_download.html')).read()
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda url, video_id: file_contents
    info_dict = ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert 'entries' not in info_dict
    assert info_dict['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info_dict['ext'] == 'ogg'

# Generated at 2022-06-22 07:14:31.061173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:14:35.907100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:37.200997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:40.568612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    expected_result = 'archive.org'
    assert test_obj.IE_NAME == expected_result, 'Expected result not in class attribute IE_NAME'


# Generated at 2022-06-22 07:14:45.908008
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ArchiveOrgIE._TESTS) == 4

# Generated at 2022-06-22 07:14:46.593580
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:47.645610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:14:59.975788
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test the constructor of the class ArchiveOrgIE"""
    ie = ArchiveOrgIE("", "")
    assert ie.IE_NAME == 'archive.org'    # Test the name of the class
    assert ie.IE_DESC == 'archive.org videos'  # Test the description of the class
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'  # Test the regex valid url

# Generated at 2022-06-22 07:15:07.522023
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ao.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ao._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ao._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:15:08.113666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-22 07:15:19.889408
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-22 07:15:22.728268
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:15:26.252605
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:35.552006
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:47.117624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://example.com/test/'
    result = ArchiveOrgIE._build_url_result(url,
        video_id='XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        formats=[{'format_id': 'mp4_1280x720_1000k', 'url': 'http://cdn.example.com/mp4_1280x720_1000k.mp4'}],
        subtitles={},
        is_live=False)
    assert result['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert result['url'] == 'mp4_1280x720_1000k'
    assert result['display_id'] == 'mp4_1280x720_1000k'
    assert result['title'] is None

# Generated at 2022-06-22 07:15:52.728671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:16:02.786819
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:13.769084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	assert ie._VALID_URL == ie._match_id(url)
	info = ie._real_extract(url)
	assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	assert info['ext'] == 'ogg'
	assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
	assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
	assert info['creator'] == 'SRI International'
	assert info['release_date'] == '19681210'

# Generated at 2022-06-22 07:16:23.626465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This is from the unit test at the bottom of
    # youtube_dl/extractor/archiveorg.py,
    # modified for the new constructor.
    ie = ArchiveOrgIE(None);
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:16:27.262722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie.extract(url)
test_ArchiveOrgIE.unit_test = True

# Generated at 2022-06-22 07:16:48.688109
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:52.314169
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except TypeError as e:
        assert 'type of the first argument must be str, found unicode' in str(e)


# Generated at 2022-06-22 07:16:57.285576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:17:04.714302
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._type = ie._match_id = ie._download_webpage = ie._search_regex = ie._parse_html5_media_entries = ie._parse_jwplayer_data = lambda *args, **kargs: 'faked'
    ie._download_json = lambda *args, **kargs: {'metadata': {'title': 'video title'}}
    assert ie._real_extract('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator') == {
        'id': 'faked',
        'title': 'video title',
        'description': None,
        'thumbnail': None,
        'uploader': None,
        'upload_date': None,
        'timestamp': None,
    }

# Generated at 2022-06-22 07:17:06.655593
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_instance = ArchiveOrgIE()
    assert isinstance(archive_org_instance, InfoExtractor)

# Generated at 2022-06-22 07:17:08.469025
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:17:11.029808
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE's constructor
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:17:12.129198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()

# Generated at 2022-06-22 07:17:21.438792
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    expected = ['Buster Keaton\'s "Cops" (1922)',
              '1968 Demo - FJCC Conference Presentation Reel #1']
    instance = ArchiveOrgIE()
    res = [
        instance._download_webpage('http://archive.org/details/Cops1922', 'Cops1922').get('title'),
        instance._download_webpage('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect').get('title')
    ]
    assert res == expected, "The title does not match"

# Generated at 2022-06-22 07:17:28.415172
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE class"""
    ie = ArchiveOrgIE(None)
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_url = ie.suitable(url)
    assert test_url
    assert ie.IE_NAME == 'archive.org'
    test_class = ie.IE_DESC
    expected_class = 'archive.org videos'
    assert test_class == expected_class

# Generated at 2022-06-22 07:18:15.993963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:18:17.254643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(True)

# Generated at 2022-06-22 07:18:18.827627
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:18:20.059901
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'ArchiveOrg'

# Generated at 2022-06-22 07:18:21.631965
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('www.archive.org')

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-22 07:18:22.709961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-22 07:18:34.196795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        ('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
         {'_type': 'url', 'url': 'https://www.youtube.com/watch?v=zAFkh7YNVQQ'}),
        ('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator',
         {'_type': 'url', 'url': 'http://www.dr.dk/tvmoskva/play/tv/dr-k-live/p2-k-live-og-mandag-mandag?autostart=true'})
    ]
    for test_case in test_cases:
        ie = ArchiveOrgIE(test_case[0])
        test_extract

# Generated at 2022-06-22 07:18:46.317553
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:18:46.980127
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:18:51.935740
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC

# Generated at 2022-06-22 07:20:54.853723
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:20:57.670312
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:21:02.099030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test subclass of InfoExtractor - ArchiveOrgIE.
    ie = ArchiveOrgIE(None)

    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:21:02.735218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE()

# Generated at 2022-06-22 07:21:04.699435
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor
    e = ArchiveOrgIE()
    assert e.IE_NAME == 'archive.org'
    assert e.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:05.167459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Generated at 2022-06-22 07:21:06.223164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:21:06.878309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:21:09.398994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # given
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_title = '1968 Demo - FJCC Conference Presentation Reel #1'

    # when
    ie = ArchiveOrgIE({})
    info = ie.extract(url)

    # then
    assert info['title'] == expected_title


# Generated at 2022-06-22 07:21:12.446099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    temp = ArchiveOrgIE()
    assert temp._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'