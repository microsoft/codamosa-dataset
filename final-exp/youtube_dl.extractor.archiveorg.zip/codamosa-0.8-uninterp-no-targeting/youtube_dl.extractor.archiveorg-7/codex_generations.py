

# Generated at 2022-06-22 07:13:39.501950
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()


# Generated at 2022-06-22 07:13:41.603957
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-22 07:13:47.785338
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testobj = ArchiveOrgIE()
    assert testobj.IE_NAME == 'archive.org'
    assert testobj.IE_DESC == 'archive.org videos'
    assert testobj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:53.194307
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.http = 'https'
    # test for the ArchiveOrgIE.ie_name attribute
    test_ie_name = ie.ie_name
    # test for the ArchiveOrgIE.ie_desc attribute
    test_ie_desc = ie.IE_DESC
    assert test_ie_name == 'archive.org'
    assert test_ie_desc == 'archive.org videos'

# Generated at 2022-06-22 07:13:56.238945
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-22 07:14:02.409366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == 'archive.org'
    assert instance.IE_DESC == 'archive.org videos'
    assert instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:14:03.721134
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:14:13.809964
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().name == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE().description == ArchiveOrgIE.IE_DESC
    assert ArchiveOrgIE().ie_key() == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE()._real_extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ArchiveOrgIE()._real_extract("https://archive.org/details/Cops1922")
    assert ArchiveOrgIE()._real_extract("http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")

# Generated at 2022-06-22 07:14:16.028581
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:16.615537
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-22 07:14:28.977872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:14:31.716234
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:14:36.732471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test case for https://github.com/rg3/youtube-dl/issues/1917
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:38.445747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()
    # Test if we can create an instance of ArchiveOrgIE

# Generated at 2022-06-22 07:14:43.392299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:44.929497
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL

# Generated at 2022-06-22 07:14:48.056137
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    info_extractor.IE_NAME
    info_extractor.IE_DESC
    info_extractor._VALID_URL
    info_extractor._TESTS

# Generated at 2022-06-22 07:14:56.386386
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

    # Test with a URL that contains parameters
    url ='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?start=10&end=20'
    assert ie.extract(url) == ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')



# Generated at 2022-06-22 07:15:07.849512
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:11.348122
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS
    ie._real_extract

# Generated at 2022-06-22 07:15:42.468787
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testModule = ArchiveOrgIE()
    assert testModule.IE_NAME == "archive.org"
    assert testModule.IE_DESC == "archive.org videos"
    assert testModule.VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert testModule.TESTS[0]['url'] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert testModule.TESTS[0]['md5'] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-22 07:15:43.930556
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = None
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:15:45.522878
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("Test constructor of class ArchiveOrgIE")
    instance = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:54.966809
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for url in ('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                'https://archive.org/details/Cops1922',
                'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'):
        assert ArchiveOrgIE._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:15:55.342576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:01.675701
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:16:06.831204
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:16:09.041108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:10.278579
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie != None

# Generated at 2022-06-22 07:16:14.762520
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    unit = ArchiveOrgIE()
    assert unit.IE_NAME == 'archive.org'
    assert unit.IE_DESC == 'archive.org videos'
    assert unit._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:06.870022
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:10.980504
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert(archive._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(archive.IE_NAME == 'archive.org')
    assert(archive.IE_DESC == 'archive.org videos')

# Generated at 2022-06-22 07:17:13.244847
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == '__main__':
        test_ArchiveOrgIE()

# Generated at 2022-06-22 07:17:17.580591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:28.401833
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_DESC == 'archive.org videos'
    assert obj.IE_NAME == 'archive.org'
    assert obj.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert obj.valid_url('https://archive.org/details/Cops1922') == True
    assert obj.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert obj.valid_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == True

# Generated at 2022-06-22 07:17:31.601327
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test whether ArchiveOrgIE is constructed properly
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:39.532244
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_desc() == 'ArchiveOrg videos'
    assert ie.search_ie() == 'common'
    assert ie.extract_ie() == ie.ie_key()
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')

# Generated at 2022-06-22 07:17:40.319544
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    

# Generated at 2022-06-22 07:17:47.714987
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:49.483477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE('archive.org', 'archive.org videos') == ArchiveOrgIE('archive.org', 'archive.org videos'))

# Generated at 2022-06-22 07:18:42.306864
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_initialize()
    # Assert that the instance of ArchiveOrgIE was created successfully.
    assert(ie.IE_NAME == 'archive.org' and ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-22 07:18:43.422425
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-22 07:18:54.723354
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    IE = InfoExtractor
    InfoExtractor._html_search_regex = _html_search_regex
    InfoExtractor._search_regex = _search_regex
    InfoExtractor._parse_json = _parse_json
    InfoExtractor._parse_jwplayer_data = _parse_jwplayer_data
    InfoExtractor._parse_html5_media_entries = _parse_html5_media_entries
    InfoExtractor._download_json = _download_json
    InfoExtractor._download_webpage = _download_webpage
    InfoExtractor._match_id = _match_id

    i = Archive

# Generated at 2022-06-22 07:19:00.625164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [{
        'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'expected_md5': '8af1d4cf447933ed3c7f4871162602db',
        'expected_filename': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect.ogg'
    }, {
        'url': 'https://archive.org/details/Cops1922',
        'expected_md5': '0869000b4ce265e8ca62738b336b268a',
        'expected_filename': 'Cops1922.mp4'
    }]

# Generated at 2022-06-22 07:19:05.134129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE constructor
    """
    ie = ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:19:06.166100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:19:08.385797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:19:19.641107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    creator = 'SRI International'
    release_date = '19681210'
    uploader = 'SRI International'
    timestamp = 1268695290
    upload_date = '20100315'
    description = 'md5:da45c349df039f1cc8075268eb1b5c25'
    title = '1968 Demo - FJCC Conference Presentation Reel #1'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    metadata = {
        "title": [title],
        "creator": [creator],
        "uploader": [uploader],
        "date": [release_date],
        "publicdate": [str(timestamp)],
        "description": [description],
    }

# Generated at 2022-06-22 07:19:19.991127
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:19:20.628550
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME.lower() == 'archive.org'

# Generated at 2022-06-22 07:21:21.464196
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie._download('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie._download('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')

# Generated at 2022-06-22 07:21:23.437571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-22 07:21:24.278487
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-22 07:21:25.380280
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME is not None

# Generated at 2022-06-22 07:21:26.288276
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-22 07:21:27.739969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:21:28.605720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.download('http://example.com')

# Generated at 2022-06-22 07:21:31.727825
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tst = ArchiveOrgIE()
    assert tst.IE_NAME == 'archive.org'
    assert tst.IE_DESC == 'archive.org videos'
    assert tst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:34.691067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .test_youtube_dl.test_youtube_dl import YoutubeDL as BaseYoutubeDL
    class YoutubeDL(BaseYoutubeDL):
        def __init__(self):
            self.ie = InfoExtractor()
    ie = YoutubeDL().ie._ies['archive.org']
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-22 07:21:41.589364
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)
    assert ie != None
    assert ie._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
