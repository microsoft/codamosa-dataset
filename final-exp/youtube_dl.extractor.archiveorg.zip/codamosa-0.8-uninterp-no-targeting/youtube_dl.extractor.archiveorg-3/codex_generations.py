

# Generated at 2022-06-22 07:13:47.171807
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simple test case to check if defined class is constructed correctly.
    """

    ie = ArchiveOrgIE('')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:48.288357
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().result()

# Generated at 2022-06-22 07:13:51.254622
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Unit test for class ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'



# Generated at 2022-06-22 07:13:53.889401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE("http://archive.org/details/ArchiveTestVideo1/")
    
    assert isinstance(IE, InfoExtractor)


# Generated at 2022-06-22 07:13:56.203724
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:14:06.020334
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test JWPlayer
    info = ie._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290
    assert info['language'] == 'en'
    # Test HTML5 media

# Generated at 2022-06-22 07:14:07.852952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    assert t.file_size == -1


# Generated at 2022-06-22 07:14:09.209392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:14.620137
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:22.031543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(InfoExtractor('archive.org'))
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'archiveOrg'
    assert ie.server_encoding == 'UTF-8'
    assert ie._extract_video_description.__func__ == clean_html.__func__


# Generated at 2022-06-22 07:14:42.083576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    assert info.IE_NAME == 'archive.org'
    assert info.IE_DESC == 'archive.org videos'
    assert info._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert info._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-22 07:14:48.805265
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.__name__ == 'archive.org'
    assert ie.__class__.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-22 07:14:53.614369
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:06.501862
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aReq = ArchiveOrgIE()
    # Verify that the constructor works - it only needs to set the class variables
    # pylint: disable=protected-access
    assert(aReq._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:15:08.676209
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('http://foo.com/bar')



# Generated at 2022-06-22 07:15:09.547620
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:21.745965
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    #assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:31.498986
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re
    from .common import InfoExtractor
    from .aenetworks import AENetworksBaseIE
    from .generic import GenericIE

    ie = InfoExtractor()
    ie._ies.clear()
    ie.add_ie(GenericIE)
    ie.add_ie(AENetworksBaseIE)
    ie.add_ie(ArchiveOrgIE)
    regex = re.compile('EmbedPlayer\.embed\s*\(\s*([\'\"])[^\'\"]+\1')
    ie._ies.append(('archive.org', regex, ArchiveOrgIE))
    assert ie._match_ie(regex) is ArchiveOrgIE

    ie = ArchiveOrgIE()
    assert ie.suitable('archive.org') is True
    assert ie.suitable('quotes.toscrape.com') is False

# Generated at 2022-06-22 07:15:32.633854
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        assert True
    except:
        assert False

# Generated at 2022-06-22 07:15:35.596306
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except BaseException:
        raise Exception("Unit test for class ArchiveOrgIE failed!")

# Generated at 2022-06-22 07:15:57.090503
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE().IE_NAME

# Generated at 2022-06-22 07:15:57.780193
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_constructor = ArchiveOrgIE



# Generated at 2022-06-22 07:15:59.709330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'test')
    assert ie.get_title() == 'ArchiveOrgIE'

# Generated at 2022-06-22 07:16:04.700369
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:07.140098
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:08.057406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:11.545764
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert(instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')


# Generated at 2022-06-22 07:16:12.654986
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-22 07:16:19.102949
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Extract a video file
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)
    playlist = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    attrs = extract_attributes(playlist)
    playlist = attrs.get('value')
    jwplayer_playlist = ie._parse_json(playlist, video_id, fatal=False)

# Generated at 2022-06-22 07:16:22.212600
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    with pytest.deprecated_call():
        ArchiveOrgIE(InfoExtractor())


# Generated at 2022-06-22 07:17:10.975806
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:13.753852
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
# Test an extraction
    a.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:17:15.568045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchOrg = ArchiveOrgIE()
    assert ArchOrg.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:17:25.358459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    app = ArchiveOrgIE(None)

    assert app.IE_NAME == 'archive.org'
    assert app.IE_DESC == 'archive.org videos'

    assert app._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:26.679404
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:17:29.265875
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'



# Test unit for the method _real_extract of ArchiveOrgIE

# Generated at 2022-06-22 07:17:31.330750
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_suite import cached_test_suite
    cached_test_suite(ArchiveOrgIE, 'archive.org')

# Generated at 2022-06-22 07:17:32.924320
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'


# Generated at 2022-06-22 07:17:40.473144
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_TEST = ArchiveOrgIE()
    assert IE_TEST._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:45.511269
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)

# Generated at 2022-06-22 07:19:28.701400
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = InfoExtractor(ArchiveOrgIE.IE_NAME)
    assert isinstance(i, ArchiveOrgIE)

# Generated at 2022-06-22 07:19:29.644760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:19:33.358909
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..utils import TestDict
    inst = ArchiveOrgIE()
    class_name = inst.__class__.__name__
    assert class_name == 'ArchiveOrgIE'
    print("Passed test_ArchiveOrgIE()")

# Generated at 2022-06-22 07:19:39.298913
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:19:41.025409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:19:42.663214
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x is not None
    return x


# Generated at 2022-06-22 07:19:50.946668
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:19:53.008694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:19:54.808081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie == ArchiveOrgIE()

# Generated at 2022-06-22 07:20:00.378536
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except Exception as e:
        raise Exception('ArchiveOrgIE unit test failed: %s' % e)
