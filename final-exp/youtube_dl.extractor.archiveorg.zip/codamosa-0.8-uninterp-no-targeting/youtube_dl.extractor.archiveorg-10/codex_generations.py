

# Generated at 2022-06-22 07:13:45.390111
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS

# Generated at 2022-06-22 07:13:46.709124
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()



# Generated at 2022-06-22 07:13:49.448087
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:13:54.759610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:13:55.679879
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:13:57.751101
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Called as a function, not as a test, to satisfy pylint
    assert ArchiveOrgIE

# Generated at 2022-06-22 07:14:01.271687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re
    assert re.match(
        ArchiveOrgIE.IE_NAME,
        ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').IE_NAME
    )

# Generated at 2022-06-22 07:14:02.161766
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:04.137762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:14.349962
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'
    assert a.IE_DESC == 'archive.org videos'
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert a._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert a._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert a._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert a

# Generated at 2022-06-22 07:14:21.036620
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()



# Generated at 2022-06-22 07:14:22.133888
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE._TESTS)

# Generated at 2022-06-22 07:14:22.751735
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:34.737137
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE(None)
    assert aorg.IE_NAME == 'archive.org'
    assert aorg.IE_DESC == 'archive.org videos'
    assert aorg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:37.851052
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    instance = ArchiveOrgIE('archive.org', 'archive.org')
    assert instance is not None
    assert ie.get_host_name() == 'archive.org'

# Generated at 2022-06-22 07:14:47.910899
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    try:
        ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    except Exception:
        assert False
    try:
        ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    except Exception:
        assert False
    try:
        ie.suitable('https://archive.org/embed/Error')
    except Exception:
        assert False
    try:
        ie.suitable('https://archive.org/details/Error')
    except Exception:
        assert False
    assert not ie.suitable('https://archive.org/')

# Generated at 2022-06-22 07:14:56.108909
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:02.054304
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE("http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:15:08.761641
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:15:10.423411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie



# Generated at 2022-06-22 07:15:27.118844
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE.__init__() with correct arguments
    from youtube_dl.utils import DateRange
    # Test with a string
    ie = ArchiveOrgIE('faked_args')
    assert isinstance(ie._daterange, DateRange)
    # Test with a DateRange instance
    daterange = DateRange()
    ie = ArchiveOrgIE(daterange)
    assert ie._daterange is daterange

# Generated at 2022-06-22 07:15:28.301624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:31.921596
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video_id = inst._match_id(url)
    assert video_id is not None


# Generated at 2022-06-22 07:15:41.911195
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:15:46.888734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().IE_DESC == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:15:58.464018
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case 1
    ie = ArchiveOrgIE()
    ie._match_id("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie._match_id("https://archive.org/details/Cops1922")
    ie._match_id("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie._match_id("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")

    # Test case 2
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:01.125289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie.ie_name == 'archive.org'
    assert ie.ie_desc == 'archive.org videos'

# Generated at 2022-06-22 07:16:01.790084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:16:02.281348
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:03.624150
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == ie.name == ie.IE_NAME

# Generated at 2022-06-22 07:16:29.561257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao_ie = ArchiveOrgIE()
    assert hasattr(ao_ie, '_VALID_URL')
    assert hasattr(ao_ie, 'IE_NAME')
    assert hasattr(ao_ie, 'IE_DESC')
    assert hasattr(ao_ie, '_TESTS')

# Generated at 2022-06-22 07:16:34.837733
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE.name)
    assert(ArchiveOrgIE.description)
    assert(ArchiveOrgIE.ie_key())
    assert(ArchiveOrgIE.thumbnail)
    assert(ArchiveOrgIE.uploader)
    assert(ArchiveOrgIE.upload_date)
    assert(ArchiveOrgIE.release_date)
    assert(ArchiveOrgIE.timestamp)
    assert(ArchiveOrgIE.license)
    assert(ArchiveOrgIE.language)
    assert(ArchiveOrgIE.genre)

# Generated at 2022-06-22 07:16:40.552087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE.__init__()"""
    ie = ArchiveOrgIE('archive.org', {'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'})
    assert ie.title == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert ie.data['meta']['creator'] == 'SRI International'

# Generated at 2022-06-22 07:16:41.150858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()

# Generated at 2022-06-22 07:16:41.770953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-22 07:16:53.161867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert ie._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-22 07:16:53.578046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:54.669311
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_class = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:55.300643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-22 07:16:59.941760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:48.700678
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case:
    # Address:
    # https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    # Keyword: archive.org
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url = 'http://archive.org/details/' + video_id
    extractor = ArchiveOrgIE()
    class_name = extractor.__class__.__name__
    assert class_name == 'ArchiveOrgIE'
    assert type(extractor).__name__ == 'type'

# Generated at 2022-06-22 07:17:59.560732
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_info = ArchiveOrgIE()._real_extract(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert video_info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert video_info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert video_info['creator'] == 'SRI International'
    assert video_info['release_date'] == '19681210'
    assert video_info['uploader'] == 'SRI International'
    assert video_info['timestamp'] == 1268695290
    assert video_info['upload_date'] == '20100315'

# Generated at 2022-06-22 07:18:11.306425
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:12.700515
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie)

# Generated at 2022-06-22 07:18:20.031756
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if ie._VALID_URL:
        from re import compile
        compiled_regex = compile(ie._VALID_URL)
        assert compiled_regex.match("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    if ie._TESTS:
        for entry in ie._TESTS:
            if entry['url']:
                assert ie._match_id(entry['url'])

# Generated at 2022-06-22 07:18:20.803660
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    instance.IE_NAME

# Generated at 2022-06-22 07:18:23.748196
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	#Test if constructor properly constructs an ArchiveOrgIE object
	ArchiveOrgIEInstance = ArchiveOrgIE()
	assert(isinstance(ArchiveOrgIEInstance, ArchiveOrgIE))

# Generated at 2022-06-22 07:18:26.976455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'


# Generated at 2022-06-22 07:18:32.423609
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:44.264119
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

	archiveOrgIE = ArchiveOrgIE()

	assert (archiveOrgIE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)")

# Generated at 2022-06-22 07:20:52.339870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'
    assert ie.logo() is None
    assert ie.valid_url(ArchiveOrgIE._VALID_URL) is True

# Unit tests for method extract

# Generated at 2022-06-22 07:21:00.128728
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import os
    import tempfile
    import unittest

    class TestArchiveOrgIE(unittest.TestCase):
        def setUp(self):
            self.test_dir = tempfile.mkdtemp()
            self.addCleanup(self.rm_tmp)

        def rm_tmp(self):
            os.rmdir(self.test_dir)


# Generated at 2022-06-22 07:21:11.289430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # the archive.org video ID
    video_id = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    # the instantiated class
    ia = ArchiveOrgIE()

    # tests on the ID (these are more relevant to the general Extractor interface)
    assert ia._match_id(ia._VALID_URL) == video_id
    assert ia._match_id(ia.IE_NAME, ia._VALID_URL) == video_id
    assert ia._match_id(ia._VALID_URL + '?start=10') == video_id
    assert ia._match_id(ia._VALID_URL.replace('org', 'com')) == video_id

    # getting a webpage from the site

# Generated at 2022-06-22 07:21:12.745889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert "from future import print_function" in ArchiveOrgIE.__doc__

# Generated at 2022-06-22 07:21:19.736616
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(info['description'] == '1968 Demo - FJCC Conference Presentation Reel #1')
    assert(info['creator'] == 'SRI International')
    assert(info['release_date'] == '19681210')
    #assert(info['uploader'] == 'SRI International')
    assert(info['upload_date'] == '20100315')

# Generated at 2022-06-22 07:21:26.210790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.valid_url("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    assert ie.valid_url("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:21:33.782644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=redefined-outer-name
    # pylint: disable=line-too-long
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    videotitle = '1968 Demo - FJCC Conference Presentation Reel #1'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # Constructor of class ArchiveOrgIE
    archorg_ie = ArchiveOrgIE(PBSIE(PBSIE.WORKING_URL))

    # Test the right order of functions with proper args
    # Function test for _real_extract
    assert archorg_ie.url_result(url).get('id') == video_id


# Generated at 2022-06-22 07:21:41.338508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extractor_key = 'archive.org'
    ie.extractor_name = 'archive.org videos'
    ie.valid_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie.match_func = '(?:archive\.org\/details\/|archive\.org\/embed\/)([^/?#&]+)'
    ie.get_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie.get_title = '1968 Demo - FJCC Conference Presentation Reel #1'
    ie.get_description = 'md5:da45c349df039f1cc8075268eb1b5c25'
    ie.get_ext = 'ogg'

# Generated at 2022-06-22 07:21:44.153738
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:46.953623
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert ie.IE_NAME == 'archive.org'