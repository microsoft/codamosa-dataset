

# Generated at 2022-06-22 07:13:47.417071
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE"""

# Generated at 2022-06-22 07:13:58.928869
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:14:03.183180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id = 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    webpage = 'http://archive.org/embed/' + video_id
    ie = ArchiveOrgIE(webpage)
    infoDict = ie.extract(webpage)
    print(infoDict)

# Generated at 2022-06-22 07:14:05.309352
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    site = ArchiveOrgIE()
    assert isinstance(site, ArchiveOrgIE)
#test_ArchiveOrgIE()

# Generated at 2022-06-22 07:14:08.012352
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    # initialize an object of ArchiveOrgIE
    ArchiveOrgIE_obj = ArchiveOrgIE()


# Generated at 2022-06-22 07:14:19.671667
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    entry = ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Title
    assert entry['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    # Description
    assert entry[u'description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    # Creator
    assert entry[u'creator'] == 'SRI International'
    # Uploader
    assert entry[u'uploader'] == 'SRI International'
    # Release date
    assert entry[u'release_date'] == '19681210'
    # Upload date
    assert entry[u'upload_date'] == '20100315'
    # Timestamp
   

# Generated at 2022-06-22 07:14:21.300063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    return info_extractor

# Generated at 2022-06-22 07:14:33.305627
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:14:37.313418
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:14:38.823591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE("archive.org","archive.org")

# Generated at 2022-06-22 07:14:55.444351
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-22 07:15:07.413290
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:15:17.616420
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import inspect

    obj = ArchiveOrgIE(None, None)

    assert obj._VALID_URL is not None, \
        "Test cannot be performed without attribute."

    # Test if all attributes of ArchivOrgIE are listed
    # in this test file
    attributes = [
        '_VALID_URL',
        'IE_DESC',
        'IE_NAME',
        '_TESTS',
    ]

    for attr in attributes:
        assert attr in inspect.getmembers(obj, inspect.ismember), \
            "Attribute '{0}' not listed in test.".format(attr)

# Run the unit test
test_ArchiveOrgIE()

# Generated at 2022-06-22 07:15:21.031087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        print("Successfully initialized ArchiveOrgIE class")
    except Exception as e:
        print(e)
        raise Exception("ArchiveOrgIE constructor failed")



# Generated at 2022-06-22 07:15:22.536159
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE('http://www.archive.org')
    assert o != None

# Generated at 2022-06-22 07:15:24.490671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:34.493525
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:35.281050
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:15:38.770490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re, sys
    if sys.version_info[0] < 3:
        from types import InstanceType
        assert isinstance(ArchiveOrgIE(), InstanceType)
    else:
        assert isinstance(ArchiveOrgIE(), object)

# Generated at 2022-06-22 07:15:42.285820
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    assert ie.suitable(url)

# Generated at 2022-06-22 07:15:48.358138
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global ArchiveOrgIE
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:53.697875
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:55.025529
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org' )
    assert (ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-22 07:15:57.362139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'

    obj.IE_NAME = 'archive.org'
    obj.IE_DESC = 'archive.org videos'


# Generated at 2022-06-22 07:16:00.548179
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# check with an arbitrary url
	assert ArchiveOrgIE()._match_id(url='https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Test for method _real_extract of class ArchiveOrgIE

# Generated at 2022-06-22 07:16:06.212953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-22 07:16:07.188507
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:16:08.665667
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE.test_class = ArchiveOrgIE

# Generated at 2022-06-22 07:16:12.827759
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # assert that the expected exception was raised
    with pytest.raises(NotImplementedError):
        ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Unit tests for extract internal method

# Generated at 2022-06-22 07:16:15.027403
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    assert(test.ie_key() == 'archive.org')
    assert(test.ie_desc() == 'archive.org videos')

# Generated at 2022-06-22 07:16:28.614883
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    expected = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._VALID_URL == expected

# Generated at 2022-06-22 07:16:29.144495
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:36.514196
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Because the class ArchiveOrgIE is not a real module, we call the constructor in test_ArchiveOrgIE
    # to make sure the class constructor, especially _real_extract works well
    # - Replace test_ArchiveOrgIE with ArchiveOrgIE to make it a real module
    tester = ArchiveOrgIE()
    # - Add the following lines to make it an actual unit test
#    assert tester.IE_NAME == 'archive.org'
#    assert tester.IE_DESC == 'archive.org videos'
#    assert tester._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
#    assert tester._TESTS[0].get('url') == 'http://archive.org/details/XD300-23

# Generated at 2022-06-22 07:16:41.955382
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Tests the creation of class ArchiveOrgIE"""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:16:53.226411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:57.044640
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()

    assert info.IE_NAME == 'archive.org'
    assert info.IE_DESC == 'archive.org videos'


# Generated at 2022-06-22 07:16:58.947246
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:17:02.262855
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert ie.ie_key() == 'archive.org'
	assert ie.ie_desc() == 'archive.org videos'
	assert ie.ies_key() == 'ArchiveOrg'
	assert ie.ies_desc() == 'archive.org videos'



# Generated at 2022-06-22 07:17:03.317686
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-22 07:17:14.421681
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    info = info_extractor._real_extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert info['id'] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert info['ext'] == "ogg"
    assert info['title'] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert info['description'] == "Demonstration reel of work on the Augmentation Research Center's oN-Line System (NLS)."
    assert info['creator'] == "SRI International"
    assert info['release_date'] == "19681210"
    assert info['uploader'] == "SRI International"
    assert info['timestamp'] == 1268695290


# Generated at 2022-06-22 07:17:36.110291
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'ArchiveOrg')

# Generated at 2022-06-22 07:17:42.421364
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:17:52.562460
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:53.722970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-22 07:17:59.075076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # test if constructor of class ArchiveOrgIE is appropriate
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._NETRC_MACHINE == 'archive.org'

# Generated at 2022-06-22 07:18:10.482570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['ext'] == 'ogg'
    assert ie

# Generated at 2022-06-22 07:18:10.933076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:18:21.246644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:21.930929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:23.001942
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:19:24.296824
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id='MSNBCW_20131125_040000_To_Catch_a_Predator'
    url = 'https://archive.org/details/%s' % (video_id)
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:19:28.200479
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert(instance.IE_NAME == "archive.org")
    assert(instance.IE_DESC == "archive.org videos")

# Generated at 2022-06-22 07:19:31.793788
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url="https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/start/0/end/20"
    data=ArchiveOrgIE()._real_extract(url)

# Generated at 2022-06-22 07:19:33.181045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE().IE_NAME == 'archive.org'


# Generated at 2022-06-22 07:19:34.580090
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE(InfoExtractor())
    # TODO: Add more unit tests

# Generated at 2022-06-22 07:19:43.966106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This url uses embed, so it should be using the embed constructor
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_embed = ArchiveOrgIE()
    assert archive_org_embed.IE_NAME == 'archive.org:embed'
    # This url uses details, so it should be using the details constructor
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_details = ArchiveOrgIE()
    assert archive_org_details.IE_NAME == 'archive.org:details'

# Generated at 2022-06-22 07:19:51.116475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS
    ie._download_webpage
    ie._html_search_regex
    ie._search_regex
    ie._search_regex
    ie._parse_json
    ie._parse_jwplayer_data
    ie._parse_html5_media_entries
    ie._real_extract
    ie._match_id
    ie._download_json
    ie._
    ie._

# Generated at 2022-06-22 07:19:54.022857
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	test = ArchiveOrgIE()
	test.test_download()


# Generated at 2022-06-22 07:19:55.768920
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except Exception as e:
        raise Exception(e)

# Generated at 2022-06-22 07:20:06.590793
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:22:13.167877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:22:14.051344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:22:14.977857
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	d = ArchiveOrgIE()


# Generated at 2022-06-22 07:22:15.814117
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:22:17.902622
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        raise

# Generated at 2022-06-22 07:22:20.091455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_initialize()

# Generated at 2022-06-22 07:22:21.012833
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:22:22.110627
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE != None


# Generated at 2022-06-22 07:22:23.532188
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("http://archive.org/details/WFMU-Archive")

# Generated at 2022-06-22 07:22:29.484498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    e = ArchiveOrgIE()
    e.init()
    assert e.IE_NAME == 'archive.org'
    assert e.IE_DESC == 'archive.org videos'
    assert e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Test one of the test cases from the class's _TESTS list