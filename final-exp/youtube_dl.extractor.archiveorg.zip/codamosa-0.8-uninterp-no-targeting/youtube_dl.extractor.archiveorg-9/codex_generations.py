

# Generated at 2022-06-22 07:13:39.703037
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE();
    assert info.IE_NAME
    assert info.IE_DESC
    assert info._VALID_URL
    assert info._TESTS

# Generated at 2022-06-22 07:13:40.284596
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:13:52.054245
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:00.839663
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # FIXME: This extracts 'download' URL
    #        (not totally the same as the one
    #         that is used in the web player)
    #        and it not considered a "test"
    # https://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect_512kb.mp4
    ArchiveOrgIE().extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:14:06.502910
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test archive.org ID in the constructor of class ArchiveOrgIE
    archive_org_ie = ArchiveOrgIE('archive.org', 'archive.org')
    assert archive_org_ie.IE_NAME == 'archive.org'
    assert archive_org_ie.IE_DESC == 'archive.org videos'
    assert archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:07.892799
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  test_ArchiveOrgIE = ArchiveOrgIE()
  return

# Generated at 2022-06-22 07:14:09.605299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)

# Generated at 2022-06-22 07:14:10.921475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:14:15.498917
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.__class__.__name__ == 'ArchiveOrgIE'
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:14:21.382473
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:14:37.510336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:41.654376
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor(extractors=[ArchiveOrgIE()])
    assert 'archive.org' in ie.extractors_by_ie
    assert ie.extractors_by_ie['archive.org'] == ArchiveOrgIE

# Generated at 2022-06-22 07:14:50.788575
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    info = ie.extract(url)
    assert info['id'] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert info['title'] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert info['creator'] == "SRI International"
    assert info['release_date'] == "19681210"
    assert info['uploader'] == "SRI International"
    assert info['timestamp'] == 1268695290



# Generated at 2022-06-22 07:14:53.345655
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.ie_key() == 'archive.org'
    assert i.ie_name() == 'archive.org videos'

# Generated at 2022-06-22 07:14:54.558465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert not ie is None

# Generated at 2022-06-22 07:15:00.593824
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Unit test for ArchiveOrgIE constructor
    '''
    test_object = ArchiveOrgIE()
    assert test_object.ie_key() == 'ArchiveOrg'
    assert test_object.ie_name() == 'archive.org'
    assert test_object.ie_desc() == 'archive.org videos'

# Generated at 2022-06-22 07:15:02.442900
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'archive.org'

# Generated at 2022-06-22 07:15:08.646344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:09.971129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	arch = ArchiveOrgIE()


# Generated at 2022-06-22 07:15:13.339074
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie.IE_NAME == ie._TESTS[0]['info_dict']['id']

# Generated at 2022-06-22 07:15:26.052389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-22 07:15:30.686180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class ArchiveOrgIE_test(ArchiveOrgIE):
        def get_test_urls(self, url):
            return [url]
        def _real_extract(self, url):
            return []
    ArchiveOrgIE_test().get_test_urls("https://archive.org/details/Test")

# Generated at 2022-06-22 07:15:31.275076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:33.225245
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:42.703003
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from . import _util_common
    from . import _util_net
    from . import _util_socks
    from . import _util_socksproxy
    from . import _util_test
    from . import _util_url
    from . import _util_webpage
    _util_common.monkeypatch()
    _util_net.monkeypatch()
    _util_socks.monkeypatch()
    _util_socksproxy.monkeypatch()
    _util_test.monkeypatch()
    _util_url.monkeypatch()
    _util_webpage.monkeypatch()

    test = ArchiveOrgIE(archive_org_ie._downloader)
    test._opener = _util_url.build_opener(archive_org_ie._opener_factory)
    test.report_download_page = _util_

# Generated at 2022-06-22 07:15:43.523397
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	print(ArchiveOrgIE())

# Generated at 2022-06-22 07:15:49.205438
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:54.090604
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video = ArchiveOrgIE()._real_extract(url)
    assert video['id'] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-22 07:15:56.898340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert 'archive.org' == info_extractor.IE_NAME
    assert 'archive.org videos' == info_extractor.IE_DESC
    assert r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' == info_extractor._VALID_URL

# Generated at 2022-06-22 07:15:59.553632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'
    assert ie.decription == 'archive.org videos'
    assert ie.valid_urls == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:23.719259
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:30.629751
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    test_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info = ie.extract(test_url)

    expected_title = '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['title'] == expected_title
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:16:31.440665
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video = ArchiveOrgIE()
    assert video

# Generated at 2022-06-22 07:16:37.899227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:38.506956
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:16:46.968953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  # test all possible constructor arguments
  ie = ArchiveOrgIE(combine_xpaths=False, downloader=None, ie_key=None,
                    params=None, progress_hooks=None,
                    proxy=None, std_headers=None)
  assert isinstance(ie, InfoExtractor)
  assert isinstance(ie, ArchiveOrgIE)
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
  assert ie.IE_NAME == 'archive.org'
  assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:58.724675
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re
    import json
    import pycurl
    import urllib
    import httplib
    import requests
    import io
    import os.path
    import base64
    import six

    IE = ArchiveOrgIE()
    # Test values

# Generated at 2022-06-22 07:17:03.381823
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''Unit test for constructor of class ArchiveOrgIE'''
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.supported_extractors() == ['ArchiveOrgIE']
    assert ie.supported_extractors_re() == [r'^https?://(?:www\.)?archive\.org/(?:details|embed)/[^/?#&]+']

# Generated at 2022-06-22 07:17:05.366565
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:16.239657
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class MockDownloader(object):
        def __init__(self, result):
            self.result = result

        def to_screen(self, message):
            pass

        def download(self, url, *args, **kwargs):
            return self.result

    class MockExtractor(ArchiveOrgIE):
        def __init__(self, downloader):
            self.downloader = downloader

    # Test basic case
    result1 = MockDownloader({
        'status': 'success',
        'url': 'https://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect_512kb.mp4',
        'http_headers': {'Content-Type': 'video/mp4'},
    })

# Generated at 2022-06-22 07:18:09.294646
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()

# Generated at 2022-06-22 07:18:21.351039
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:18:22.403338
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:18:23.642785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    auth = ArchiveOrgIE()
    assert auth is not None

# Generated at 2022-06-22 07:18:34.969459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie.jwplayer_data == ArchiveOrgIE.jwplayer_data
    assert ie.jwplayer_entry_decorator == ArchiveOrgIE.jwplayer_entry_decorator
    assert ie.extract == ArchiveOrgIE.extract
    assert ie.suitable == ArchiveOrgIE.suitable
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie._real_extract == ArchiveOrgIE._real_extract
    assert ie._VALID_URL == ArchiveOrg

# Generated at 2022-06-22 07:18:35.609255
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:18:40.291085
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor, list
    ArchiveOrgIE()

    # Constructor, dict
    ArchiveOrgIE({'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'})

# Generated at 2022-06-22 07:18:40.982346
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:18:46.105632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()
    assert archiveorg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archiveorg.IE_NAME == 'archive.org'
    assert archiveorg.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:18:52.336510
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert(ie.IE_NAME == "archive.org")
	assert(ie.IE_DESC == "archive.org videos")
	assert(ie._VALID_URL.find('archive') != -1)
	assert(ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:21:03.625298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'


# Generated at 2022-06-22 07:21:08.137402
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instantiate ArchiveOrgIE object
    class_name = "ArchiveOrgIE"
    yt_ie = globals()[class_name]()
    # Check if object is initialized
    assert yt_ie
    # Check type of object
    assert class_name == type(yt_ie).__name__

# Generated at 2022-06-22 07:21:18.690198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:27.432925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Test unit test code
    assert ie.suitable(None) == False
    assert ie.suitable('') == False
    assert ie.suitable(object()) == False
    assert ie.suitable('https://archive.org/details/Cops1922') == True
    assert ie.suitable('https://www.archive.org/details/msnbcw_20131125_040000_to_catch_a_predator') == True

# Generated at 2022-06-22 07:21:27.895785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:21:28.331786
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:21:29.062789
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    return ie

# Generated at 2022-06-22 07:21:29.730902
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:21:37.473590
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'test_archive_org'
    ie.IE_DESC = 'test_archive_org_desc'
    ie._VALID_URL = r'test_archive_org_url'

# Generated at 2022-06-22 07:21:44.729797
# Unit test for constructor of class ArchiveOrgIE