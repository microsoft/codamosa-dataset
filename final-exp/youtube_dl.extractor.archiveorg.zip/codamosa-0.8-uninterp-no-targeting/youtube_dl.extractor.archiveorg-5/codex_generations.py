

# Generated at 2022-06-22 07:13:43.680206
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archie = ArchiveOrgIE()
    assert(archie is not None)


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:13:45.399934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:13:57.262249
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.set_downloader(None)
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]["url"] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]["url"] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[2]["url"] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:13:58.264650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:00.982265
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:14:08.283301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info.get('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info.get('ext') == 'ogg'
    assert info.get('title') == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info.get('description') == 'Contributor SRI International Creator SRI International Subject Conference Proceedings Identifier XD300-23_68HighlightsAResearchCntAugHumanIntellect Run time 00:02:40 Source http://sloan.stanford.edu/mousesite/1968Demo.html (Sloan Foundation) Year 1968'
    assert info.get('creator')

# Generated at 2022-06-22 07:14:14.469268
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE("archive.org")
    assert o.IE_NAME == "archive.org"
    assert o.IE_DESC == "archive.org videos"
    assert o._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:14:16.898940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:14:18.321158
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check for type error when no arguments are provided
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:21.195005
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    print(ie)

# Generated at 2022-06-22 07:14:37.883975
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE(ie)
    assert isinstance(ie, ArchiveOrgIE)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:40.286395
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:43.130140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL, 'Valid URL not set'
    assert ie.IE_NAME != '', 'IE_NAME not set'
    assert ie.IE_DESC != '', 'IE_DESC set'
    assert ie.__doc__

# Generated at 2022-06-22 07:14:47.387062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Test ArchiveOrgIE initialization
    '''
    ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-22 07:14:53.291071
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = globals()[ArchiveOrgIE.__name__]
    ie = class_()
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie. _VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:14:55.611067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Instantiate the object and call its test method. """
    ie = ArchiveOrgIE()
    ie.test()

# Generated at 2022-06-22 07:15:07.507703
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    fetch_result = {
        'status': 'failed',
        'filename': 'test.mp4',
        'source_url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'error': 'fetch command failed',
    }

# Generated at 2022-06-22 07:15:08.274353
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:09.258449
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:13.493862
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Create instance of class ArchiveOrgIE.
    """
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    assert ydl.get_info_extractor(ArchiveOrgIE.ie_key()) is not None

# Generated at 2022-06-22 07:15:37.529134
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    m = ArchiveOrgIE()
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    m._match_id(test_url)

# Generated at 2022-06-22 07:15:49.774870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:56.360340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    input = {'id': 'A', 'title': 'A', 'url': 'A', 'thumbnail': 'A', 'description': 'A', 'player_url': 'A'}
    output = {'id': 'A', 'title': 'A', 'url': 'A', 'thumbnail': 'A', 'description': 'A', 'player_url': 'A'}
    ArchiveOrgIE.__call__(None, input) == output

# Generated at 2022-06-22 07:16:02.874571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()
    print(test_ArchiveOrgIE.IE_NAME)
    print(test_ArchiveOrgIE.IE_DESC)
    #test_ArchiveOrgIE.IE_NAME = 'archive.org'
    print(test_ArchiveOrgIE.IE_NAME)
    print(test_ArchiveOrgIE.IE_DESC)
    print(test_ArchiveOrgIE._VALID_URL)
    print(test_ArchiveOrgIE._TESTS)
    


# Generated at 2022-06-22 07:16:05.676876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = InfoExtractor()
    ie = info_extractor.get_info_extractor(ArchiveOrgIE.ie_key())
    assert ie is not None

# Generated at 2022-06-22 07:16:07.100585
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-22 07:16:10.945232
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    test.get_info('https://archive.org/details/Cops1922')
    test.get_info('https://archive.org/details/Cops1922')

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:16:12.389785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME is not None


# Generated at 2022-06-22 07:16:16.278345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()
    assert archiveorg.IE_NAME == 'archive.org'
    assert archiveorg.IE_DESC == 'archive.org videos'
    assert archiveorg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:16:22.830366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert isinstance(ie._TESTS, list) == True

# Generated at 2022-06-22 07:16:48.410469
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # The length of the _TESTS lis depends on the number of tests to run
    e = ArchiveOrgIE()
    assert len(e._TESTS) > 0

# Generated at 2022-06-22 07:16:50.234471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:55.245650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:05.237654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..compat import compat_str
    from ..utils import (
        determine_ext,
        parse_duration,
    )

    # Test constructor
    assert ArchiveOrgIE._VALID_URL.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test extractor
    IE = ArchiveOrgIE()
    info_dict = IE.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Test extractor
    assert info_dict['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info_dict['ext'] == 'ogg'

# Generated at 2022-06-22 07:17:06.334308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()



# Generated at 2022-06-22 07:17:09.095047
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(InfoExtractor())
    ie.extract('https://archive.org/details/VideoTributeToSeanAndAlinaCusack')


# Generated at 2022-06-22 07:17:13.393125
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-22 07:17:23.362239
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ao._TESTS[0].get("url") == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert (ao._TESTS[0].get("md5") == '8af1d4cf447933ed3c7f4871162602db' and
            ao._TESTS[0].get("info_dict").get("uploader") == 'SRI International')
    assert ao._TESTS[1].get("url") == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-22 07:17:28.534443
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE('archive.org')
    assert(info_extractor.IE_NAME == 'archive.org')
    assert(info_extractor.IE_DESC == 'archive.org videos')
    assert(info_extractor.VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:17:32.673957
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:21.410591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:18:27.385017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._match_id(url) == video_id
    video = ArchiveOrgIE()._real_extract(url)
    assert video['id'] == video_id

# Generated at 2022-06-22 07:18:30.689774
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"


# Generated at 2022-06-22 07:18:31.396375
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:18:32.813469
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')

# Generated at 2022-06-22 07:18:35.971785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(InfoExtractor())._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:18:44.159628
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable(ArchiveOrgIE._VALID_URL) is True
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    ia = ArchiveOrgIE()
    assert ia._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Unit tests for method ArchiveOrgIE._real_extract()

# Generated at 2022-06-22 07:18:47.135187
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Ensure that the constructor successfully completed by testing an
    # attribute of the instance.
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:18:49.617036
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE({"url": "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"})

# Generated at 2022-06-22 07:18:51.075930
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-22 07:20:54.536781
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Constructor should not raise an exception
    assert ie

# Generated at 2022-06-22 07:20:55.536087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-22 07:20:56.762674
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:57.764791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-22 07:20:59.459610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME

# Generated at 2022-06-22 07:21:04.690007
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == "archive.org"
    assert IE.IE_DESC == "archive.org videos"
    assert IE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:21:06.668967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ 
    Just to test if the ArchiveOrgIE constructor doesn't raise errors
    """
    ArchiveOrgIE()

# Generated at 2022-06-22 07:21:10.979779
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE(None, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:21:20.544800
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:24.648919
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'