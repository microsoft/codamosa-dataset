

# Generated at 2022-06-22 07:13:41.323084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    output = 'Success'
    try:
        ArchiveOrgIE()
    except Exception:
        output = 'Fail'
    finally:
        print(output)

# Generated at 2022-06-22 07:13:43.982680
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simple test of ArchiveOrgIE constructor.
    """
    ie = ArchiveOrgIE() # Should not throw an exception

# Generated at 2022-06-22 07:13:45.644815
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE('archive.org').IE_NAME


# Generated at 2022-06-22 07:13:53.450653
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test for the class ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    assert ie._WORKING is True
    url = ie._TESTS[0]['url']
    assert ie._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._real_extract(url) is not None

# Generated at 2022-06-22 07:14:04.664992
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:14:05.272576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:09.878958
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constr = ArchiveOrgIE()
    assert constr.IE_DESC == 'archive.org videos'
    assert constr.IE_NAME =='archive.org'
    assert constr._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:21.037439
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import inspect
    import unittest
    class TestArchiveOrgIE(unittest.TestCase):
        def setUp(self):
            self.ie = ArchiveOrgIE()

        def test_constructor(self):
            self.assertEqual(self.ie.IE_NAME, 'archive.org')
            self.assertEqual(self.ie.IE_DESC, 'archive.org videos')
            self.assertEqual(self.ie._VALID_URL,
                r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
            self.assertTrue(inspect.isclass(ArchiveOrgIE))

    suite = unittest.TestLoader().loadTestsFromTestCase(TestArchiveOrgIE)
    unittest.TextTest

# Generated at 2022-06-22 07:14:22.620403
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    assert aorg.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:14:27.838075
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE.IE_NAME
    assert 'archive.org videos' == ArchiveOrgIE.IE_DESC
    assert 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:14:37.359937
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    

# Generated at 2022-06-22 07:14:38.023901
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:39.579822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    TestInfoExtractor().test_ie(ArchiveOrgIE)

# Generated at 2022-06-22 07:14:41.114918
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:14:46.009538
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:47.854783
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:14:50.747377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == 'archive.org'
    assert instance.IE_DESC == 'archive.org videos'
    assert isinstance(instance._VALID_URL, basestring)

# Generated at 2022-06-22 07:14:58.095389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = (
        (
            'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
        ),
    )
    for url, video_id in test_cases:
        ie = ArchiveOrgIE(url)
        assert ie.video_id == video_id

# Generated at 2022-06-22 07:15:03.507259
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:06.979267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except Exception as e:
        print(e)
        assert False, "Exception occured while constructing ArchiveOrgIE instance"

# Generated at 2022-06-22 07:15:20.199275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    (InfoExtractor._make_valid_url, InfoExtractor._match_id) = (lambda x: x, lambda x: x)
    return ArchiveOrgIE()

# Generated at 2022-06-22 07:15:24.374272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	objArchiveOrgIE = ArchiveOrgIE()
	objArchiveOrgIE.extract('https://archive.org/details/Cops1922')

# Generated at 2022-06-22 07:15:34.409030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:15:35.651146
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test constructor
    ArchiveOrgIE(None)

# Generated at 2022-06-22 07:15:36.682549
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    m = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:42.285629
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:15:51.194025
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url = 'http://archive.org/details/' + id
    ytdl = 'youtube-dl -v --check-date --no-check-certificate ' + url
    print("Testing " + ytdl)
    ydl = YouTubeDL(params={'verbose': True})
    ydl.add_default_info_extractors()
    ydl.download([url])

# Test downloading videos
if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:15:53.443545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # only run this test when file exists
    import os
    if os.path.exists('test/test.html'):
        # if file exists, load it
        import openanything
        x = openanything.fetch('file://' + os.path.abspath('test/test.html'))
        ao = ArchiveOrgIE()
        ao._real_extract(x)

# Generated at 2022-06-22 07:15:56.307746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")



# Generated at 2022-06-22 07:16:01.311702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-22 07:16:25.319257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract(url=None)

##################################################################################################################################################################################
#https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/bitchute.py

from __future__ import unicode_literals

from .common import InfoExtractor
from ..compat import (
    compat_str,
)
from ..utils import (
    ExtractorError,
    remove_start,
)
import re



# Generated at 2022-06-22 07:16:27.339574
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:16:28.650823
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoie = ArchiveOrgIE()
    assert aoie is not None

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:16:32.308237
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r"https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:16:35.350398
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:16:36.113970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:16:46.286011
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-22 07:16:48.348091
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test __init__ method
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:50.181067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:17:00.760945
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:17:48.569785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test for class ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    # Test for video id
    sample_video_id = 'Cops1922'
    sample_video_url = 'https://archive.org/details/' + sample_video_id
    expected_video_id = 'Cops1922'
    actual_video_id = ie._real_extract(sample_video_url)['id']
    assert(expected_video_id == actual_video_id)

# Generated at 2022-06-22 07:17:53.102220
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.search_ie()
    ie.suitable('https://archive.org/details/Megas01')
    ie.working

# Generated at 2022-06-22 07:17:59.593946
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    return "Unit tests pass"

print(test_ArchiveOrgIE())

# Generated at 2022-06-22 07:18:00.184422
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:04.240064
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg_ie = ArchiveOrgIE("anyvideoUrl")
    assert archiveorg_ie.IE_NAME == 'archive.org'
    assert archiveorg_ie.IE_DESC == 'archive.org videos'
# END unit test for ArchiveOrgIE

# Generated at 2022-06-22 07:18:04.911088
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:09.400657
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:18:12.711489
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None)
    except TypeError:
        pass

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:18:14.793030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Check the creation of an instance of ArchiveOrgIE
    """
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:26.472492
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect", "XD300-23_68HighlightsAResearchCntAugHumanIntellect"), ("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect", "XD300-23_68HighlightsAResearchCntAugHumanIntellect"), ("https://archive.org/details/Cops1922", "Cops1922"), ("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/", "MSNBCW_20131125_040000_To_Catch_a_Predator")]
    for url, expected_id in test_cases:
        assert ArchiveOrgIE(object)._

# Generated at 2022-06-22 07:20:19.007677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-22 07:20:22.673972
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    A unit test for the ArchiveOrgIE constructor.
    """

    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-22 07:20:23.182839
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:24.408423
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:20:25.621209
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert type(ArchiveOrgIE(None)) == ArchiveOrgIE


# Generated at 2022-06-22 07:20:28.211149
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == "archive.org"

# Generated at 2022-06-22 07:20:30.230300
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .extractor import common
    from .extractor import ArchiveOrgIE
    try:
        common.archiveorg = ArchiveOrgIE()
    except Exception:
        print("ERROR: ArchiveOrgIE() doesn't work")


# Generated at 2022-06-22 07:20:30.626585
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:40.630302
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    info_extractor._download_webpage('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-22 07:20:44.315203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'