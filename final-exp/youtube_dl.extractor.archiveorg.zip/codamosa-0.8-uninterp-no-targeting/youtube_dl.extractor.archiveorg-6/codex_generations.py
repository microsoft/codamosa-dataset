

# Generated at 2022-06-22 07:13:42.960714
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:53.194308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    yt = ArchiveOrgIE()
    assert yt.permalink == 'http://archive.org'
    assert yt.ie_key() == 'archive.org'
    assert yt.ie_desc() == 'archive.org videos'
    # assert yt._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert yt._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert yt._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'

# Generated at 2022-06-22 07:14:03.614450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = object.__new__(ArchiveOrgIE)
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert a._real_extract(url) != None
    url = 'https://archive.org/details/Cops1922/'
    assert a._real_extract(url) != None

# Generated at 2022-06-22 07:14:12.150294
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/Cops1922')
    ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-22 07:14:23.977106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .modules.archiveorg import (
        ArchiveOrgIE,
        _get_media_entry,
        _extract_urls,
        _parse_playlist,
        _extract_file_urls,
    )
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

    # test cases with real data
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:27.627280
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:29.878594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL



# Generated at 2022-06-22 07:14:34.842871
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:40.068728
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:14:43.290002
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	instance = ArchiveOrgIE()
	instance.IE_NAME
	instance.IE_DESC
	instance._VALID_URL
	assert isinstance(instance._TESTS,list)


# Generated at 2022-06-22 07:14:50.912670
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();

# Test for method _real_extract of class ArchiveOrgIE
# Should return none

# Generated at 2022-06-22 07:14:51.925215
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(1)

# Generated at 2022-06-22 07:14:53.293528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-22 07:15:06.316966
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['ext'] == 'ogg'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290

# Generated at 2022-06-22 07:15:08.372766
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-22 07:15:20.809166
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[2]['only_matching'] == True
    ia = ArchiveOrgIE()
    ia._match_id(url)

# Generated at 2022-06-22 07:15:32.817571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .generic import GenericIE
    from .youtube import YoutubeIE

    class Dummy(InfoExtractor):
        def __init__(self, *args, **kwargs):
            super(Dummy, self).__init__(*args, **kwargs)
            self.called = True

    dummy = Dummy(Dummy.ie_key())
    assert dummy.called

    dummy = GenericIE(Dummy.ie_key())
    assert dummy.ie_key() == Dummy.ie_key()

    assert not YoutubeIE.working
    assert YoutubeIE.ie_key() not in InfoExtractor._ies
    dummy = YoutubeIE()
    assert dummy is not None
    assert dummy.working
    assert dummy.ie_key() in InfoExtractor._ies
    assert YoutubeIE.working

# Generated at 2022-06-22 07:15:35.368106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    entry = ArchiveOrgIE()
    assert isinstance(entry, ArchiveOrgIE)

# Generated at 2022-06-22 07:15:35.986095
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:37.886407
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)


# Generated at 2022-06-22 07:15:51.194486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# Make sure no error raised in the creation of the instance.
	assert True

# Generated at 2022-06-22 07:15:55.986608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL.match('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None
    assert ie._VALID_URL.match('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None
    assert ie._VALID_URL.match('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/') is not None
    assert ie._VALID_URL.match('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/#') is not None

# Generated at 2022-06-22 07:15:57.419918
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:15:58.335887
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert isinstance(inst, ArchiveOrgIE)

# Generated at 2022-06-22 07:15:59.766233
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg_ie = ArchiveOrgIE()
    assert archiveorg_ie.IE_NAME == 'archive.org'
    assert archiveorg_ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:04.757763
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Unfortunately the test is locked to the current version of the site

# Generated at 2022-06-22 07:16:08.749344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE()
    arch.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:16:11.329261
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
	print(ArchiveOrgIE(url))

# Generated at 2022-06-22 07:16:15.373649
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE("archive.org", "")
    assert test.IE_DESC == "archive.org videos"
    assert test.IE_NAME == "archive.org"
    assert test._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:20.295508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # File for testing
    testfile = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # Test extraction
    ie.extract('https://archive.org/details/' + testfile)


test_ArchiveOrgIE()

# Generated at 2022-06-22 07:16:57.864921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:58.433825
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:17:04.167368
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test
    """
    ie = ArchiveOrgIE()
    print(ie.__class__)
    print(ie.__class__.__name__)
    print(ie.__class__.__bases__)
    print(ie.__class__.__dict__)
    print(ie.__dict__)
    assert(ie.__class__.__name__ == 'ArchiveOrgIE')
    assert(ie.__class__.__bases__ == (InfoExtractor,))
    assert(ie.__class__.__dict__ == {})
    assert(ie.__dict__ == {})

# Generated at 2022-06-22 07:17:08.938811
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:10.247469
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:17:21.741318
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import ArchiveOrgIE

    # test case with all values
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    extractor = ArchiveOrgIE(url)
    assert extractor.get_id() == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert extractor.get_url() == url
    assert extractor.get_title() == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert extractor.get_description() == "md5:da45c349df039f1cc8075268eb1b5c25"
    assert extractor.get_creator() == "SRI International"
    assert extractor.get_release_date() == "1968-12-10"

# Generated at 2022-06-22 07:17:24.603685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL is not None

# Generated at 2022-06-22 07:17:29.051960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL ==  r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:30.416272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:17:38.628649
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.|m\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:36.729414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME is not None
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-22 07:18:37.405654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:18:38.624297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-22 07:18:51.076892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """

    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:18:53.065614
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for constructing ArchiveOrgIE"""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:18:54.070677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('youtube')

# Generated at 2022-06-22 07:18:57.068979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..jsinterp import JSInterpreter   # needed for jwplayer js
    x = InfoExtractor.make_IE('archive.org')
    y = ArchiveOrgIE()
    assert x is y

# Generated at 2022-06-22 07:18:59.357812
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-22 07:19:10.482745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie

# Generated at 2022-06-22 07:19:11.110676
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:21:24.160114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:21:24.832251
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()

# Generated at 2022-06-22 07:21:30.806886
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:31.566108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:21:32.054266
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()

# Generated at 2022-06-22 07:21:33.869768
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # this test ensures that class ArchiveOrgIE is constructed properly
    # ie = ArchiveOrgIE()
    return None


# Generated at 2022-06-22 07:21:35.464494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:21:38.855917
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:21:45.378808
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE._real_extract()
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    vid = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['id'] == vid
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290
    assert info['upload_date'] == '20100315'

# Generated at 2022-06-22 07:21:48.576829
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS
    ie._download_webpage