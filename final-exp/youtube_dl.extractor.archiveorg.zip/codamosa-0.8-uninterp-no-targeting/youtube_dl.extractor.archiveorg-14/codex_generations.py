

# Generated at 2022-06-22 07:13:36.903255
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:13:37.700344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():    
    a = ArchiveOrgIE()

# Generated at 2022-06-22 07:13:38.217872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:13:38.973347
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:13:42.957320
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Execute constructor of class IE_DESC
    ie = ArchiveOrgIE()
    # Confirm values of attributes
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

    # Execute _real_extract() with a value of an attribute
    assert ie._real_extract(ie._VALID_URL) is not None

# Generated at 2022-06-22 07:13:44.183229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 1 == ArchiveOrgIE().ie_key()

# Generated at 2022-06-22 07:13:47.836212
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.get_url_info('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert 1 == 1

# Generated at 2022-06-22 07:13:50.045446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """
    ie = ArchiveOrgIE()
    return


# Generated at 2022-06-22 07:13:52.421933
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-22 07:13:57.291495
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:19.324577
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:26.259406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert ie.IE_NAME == 'archive.org'
  assert ie.IE_DESC == 'archive.org videos'
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
  assert len(ie._TESTS) == 4

# Unit tests for method ArchiveOrgIE.IE_NAME

# Generated at 2022-06-22 07:14:31.716819
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:36.733149
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE('archive.org')
    assert arch.name == 'archive.org'

# Generated at 2022-06-22 07:14:37.580198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:14:39.527250
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME is not None
    assert i.IE_DESC is not None

# Generated at 2022-06-22 07:14:40.626697
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-22 07:14:51.180506
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:04.254066
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:15:08.018632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:15:20.808974
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:30.922422
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test automatic detection
    info = ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # Test constructor (fail)
    try:
        ie = ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect')
        assert False, 'Invalid URL, excpetion expected'
    except Exception:
        pass
    # Test constructor (success)

# Generated at 2022-06-22 07:15:32.899481
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Call the constructor of ArchiveOrgIE class.
    """
    ie = ArchiveOrgIE()

test_ArchiveOrgIE()

# Generated at 2022-06-22 07:15:35.358421
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'ArchiveOrg'

# Generated at 2022-06-22 07:15:44.413013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')
    assert info['id'] == 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    assert info['title'] == 'To Catch a Predator'
    assert info['description'] == 'md5:eabfa0eb9a811cd7b9635be617d2b7ce'
    assert info['timestamp'] == 1385397600
    assert info['upload_date'] == '20131115042812'

# Generated at 2022-06-22 07:15:56.522133
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("Testing ArchiveOrgIE constructor...")

    # Test constructor's input argument (url): should not be empty
    try:
        ArchiveOrgIE("")
        # Should raise an exception for empty string as an input to the constructor function
        print("FAIL: ArchiveOrgIE constructor does not check for empty string input")
    except Exception:
        pass

    # Test constructor's input argument (url): not a string
    try:
        ArchiveOrgIE(None)
        # Should raise an exception for None input to the constructor function
        print("FAIL: ArchiveOrgIE constructor does not check for None input")
    except Exception:
        pass

    # Test constructor's input argument (url): not in a valid url format

# Generated at 2022-06-22 07:16:04.751896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    inst.IE_NAME = 'archive.org'
    inst.IE_DESC = 'archive.org videos'
    inst._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:07.497927
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert "archive.org" in ArchiveOrgIE.IE_NAME

# Generated at 2022-06-22 07:16:09.645890
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	pass

# Code for invoking the test from the command-line
if __name__ == "__main__":
	test_ArchiveOrgIE()

# Generated at 2022-06-22 07:16:11.201968
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:16:34.269354
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    info = ArchiveOrgIE()
    assert info.IE_NAME == "archive.org"

# Generated at 2022-06-22 07:16:45.505363
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # 1. Test invalid url
    url = "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    info_dict = {
        "id": url,
        "ext": "ogg",
        "title": "1968 Demo - FJCC Conference Presentation Reel #1",
        "description": "md5:da45c349df039f1cc8075268eb1b5c25",
        "creator": "SRI International",
        "release_date": "19681210",
        "uploader": "SRI International",
        "timestamp": 1268695290,
        "upload_date": "20100315"
        }

    ie = ArchiveOrgIE()
    info = ie.extract(url)


# Generated at 2022-06-22 07:16:47.143987
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:16:48.231247
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:53.598222
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE().IE_DESC == ArchiveOrgIE.IE_DESC
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:17:04.018372
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:17:05.414906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:17:07.798704
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:17:09.922103
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor should not raise any exception because this is a valid url
    ArchiveOrgIE()._real_initialize()

# Generated at 2022-06-22 07:17:15.152508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_NAME == 'archive.org'
    assert inst.IE_DESC == 'archive.org videos'
    assert inst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

test_ArchiveOrgIE()

# Generated at 2022-06-22 07:18:05.488142
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Function ArchiveOrgIE uses a keyword argument so we cannot simply use
    # default constructor
    # ie = InfoExtractor()
    ie = ArchiveOrgIE()


# Generated at 2022-06-22 07:18:06.928727
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:18:19.461110
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:21.823494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:18:23.483797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'archive.org'


# Generated at 2022-06-22 07:18:25.022199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        return False
    return True

# Generated at 2022-06-22 07:18:26.095778
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:34.370201
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract("https://archive.org/details/Cops1922")
    assert info["id"] == "Cops1922"
    assert info["ext"] == "mp4"
    assert info["title"] == "Buster Keaton's \"Cops\" (1922)"
    assert info["description"] == "md5:43a603fd6c5b4b90d12a96b921212b9c"
    assert info["timestamp"] == 1387699629
    assert info["upload_date"] == "20131222"

# Generated at 2022-06-22 07:18:41.511708
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS is not None

# Generated at 2022-06-22 07:18:52.799964
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert a._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert a._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert a._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert a._TESTS[0]['info_dict']['ext'] == 'ogg'
    assert a

# Generated at 2022-06-22 07:20:52.901119
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:20:56.682267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..utils import expect_warning
    info_extractor = ArchiveOrgIE("archive.org")
    assert info_extractor is not None
    with expect_warning():
        info_extractor = ArchiveOrgIE("archive.org.1")
    assert info_extractor is None

# Generated at 2022-06-22 07:21:00.873366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'http://archive.org/details/test_video')
    assert ie.name == 'archive.org'
    assert ie.url == 'http://archive.org/details/test_video'

# Generated at 2022-06-22 07:21:02.477657
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-22 07:21:04.320549
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("ArchiveOrgIE")


# Generated at 2022-06-22 07:21:06.720939
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check if any errors arise during instantiation and then run a unit test
    ie = ArchiveOrgIE()
    ie.suite()


# Generated at 2022-06-22 07:21:09.017848
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i=ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    return

# Generated at 2022-06-22 07:21:19.254092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    """
    Test cases:
    - For simple URL cases, the idea is to pass URL with different parameters
      and verify the extracted ID matches with the input URL.
    - For complex URL cases, the idea is to check add_ie(ie) method returns
      True. The extracted ID should match with the input URL.
    """

    # Simple URL tests


# Generated at 2022-06-22 07:21:21.212493
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Create an instance of ArchiveOrgIE
    inst = ArchiveOrgIE()

    # Make sure the instance is an instance of ArchiveOrgIE
    assert isinstance(inst, ArchiveOrgIE)

# Generated at 2022-06-22 07:21:24.119013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    I = ArchiveOrgIE()
    assert I._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'