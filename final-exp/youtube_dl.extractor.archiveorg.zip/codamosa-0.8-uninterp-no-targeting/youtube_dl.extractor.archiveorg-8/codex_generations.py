

# Generated at 2022-06-22 07:13:39.569767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    url = 'https://archive.org/'
    ao_instance = ArchiveOrgIE()

    ao_instance.url_result(url)

# Generated at 2022-06-22 07:13:40.446736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE == ArchiveOrgIE

# Generated at 2022-06-22 07:13:44.347477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ie.IE_DESC
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == ie.IE_DESC


# Generated at 2022-06-22 07:13:56.105793
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE()._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ArchiveOrgIE()._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
   

# Generated at 2022-06-22 07:13:58.562372
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:13:59.965151
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:14:03.914372
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:14:06.475993
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Tests ArchiveOrgIE's constructor.
    '''
    ArchiveOrgIE(params={})

# Generated at 2022-06-22 07:14:15.285602
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # create temporary empty folders
    import tempfile
    temp_dir = tempfile.mkdtemp(prefix="ytdl_")
    # create a temporary file
    import os
    file_name = "video_file.m4a"
    file_path = os.path.join(temp_dir,file_name)
    f = open(file_path, "w")
    f.write("ArchiveOrgIE")
    f.close()
    # create a test object
    a = ArchiveOrgIE(InfoExtractor(downloader=None))
    # test the constructor
    assert a != None
    # clean up
    import shutil
    shutil.rmtree(temp_dir)



# Generated at 2022-06-22 07:14:16.689655
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:28.722517
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if ie is None:
        raise Exception('ArchiveOrgIE constructor returned None')
    elif isinstance(ie, ArchiveOrgIE) == False:
        import inspect
        log.trace('Test for ArchiveOrgIE failed, type returned: %s, type expected: %s' % (
            type(ie), inspect.stack()[0][3]))
        raise Exception('Test for ArchiveOrgIE failed, type returned: %s, type expected: %s' % (
                    type(ie), inspect.stack()[0][3]))

# Generated at 2022-06-22 07:14:38.310876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Unit test for ArchiveOrgIE.
    '''
    from ytdl.extractor.archiveorg import ArchiveOrgIE
    from ytdl.utils import HEADRequest
    from ytdl.compat import compat_urllib_request
    import json

    # Get the expected result of parse_jwplayer_data by reading the file
    # testdata/archiveorg.json
    filename = 'archiveorg.json'

    with open(os.path.join(os.path.dirname(__file__), 'testdata', filename)) as f:
        expected_result = json.load(f)

    opener = compat_urllib_request.build_opener()
    opener.addheaders = [('User-Agent', HEADRequest.HEADRequest().user_agent)]
    compat_urllib_request.install_op

# Generated at 2022-06-22 07:14:43.289633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-22 07:14:52.202553
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_input = ('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                  'https://archive.org/details/Cops1922',
                  'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                  'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
                  )
    for url_str in test_input:
        archiveorg = ArchiveOrgIE()
        assert archiveorg._match_id(url_str)
        assert archiveorg._real_extract(url_str)

# Generated at 2022-06-22 07:14:54.103546
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:14:59.465697
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                        'XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:15:05.259974
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of class ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:15:13.120862
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test case for ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    yt_url = "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video_id = ie._match_id(yt_url)
    metadata = ie._download_json(
        'http://archive.org/details/' + video_id, video_id, query={
            'output': 'json',
        })['metadata']
    info = ie._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)

# Generated at 2022-06-22 07:15:13.750819
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:15:18.855996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-22 07:15:36.588219
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:37.578592
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor('ArchiveOrgIE')



# Generated at 2022-06-22 07:15:38.718534
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:41.856175
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:15:54.036337
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE(None)

    assert test.name == 'archive.org'
    assert test.description == 'archive.org videos'

    assert 'details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' in ArchiveOrgIE._TESTS[0]['url']
    assert 'details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' in ArchiveOrgIE._TESTS[0]['md5']
    assert 'details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' in ArchiveOrgIE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-22 07:15:54.810202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:16:03.832975
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:09.336617
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Test building of the class and use of a blank URL.
    i = ArchiveOrgIE()
    assert(i.ie_key() == 'ArchiveOrg')
    assert(i.ie_name() == 'archive.org')
    assert(i.ie_desc() == 'archive.org videos')


# Generated at 2022-06-22 07:16:09.893476
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:16:12.698005
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")

# Generated at 2022-06-22 07:16:40.304309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    IE = ArchiveOrgIE()
    assert isinstance(IE, InfoExtractor)
    assert IE.ie_key() == 'archive.org'
    assert IE.ie_desc() == 'archive.org videos'
    assert IE.valid_url(url)
    assert not IE.extract(url)

# Generated at 2022-06-22 07:16:42.979239
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructing an instance of ArchiveOrgIE should not result in an exception.
    """
    ArchiveOrgIE()

# A test function to provide the content of the webpage to download.

# Generated at 2022-06-22 07:16:44.707952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    r = ArchiveOrgIE()
    assert isinstance(r,InfoExtractor)


# Generated at 2022-06-22 07:16:56.333940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:59.109270
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:02.643511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org')
    assert ie.name == 'archive.org'
    assert ie.url_re == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.__class__.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-22 07:17:04.321882
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:17:10.235051
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # IndexError
    assert ie._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # AttributeError
    assert ie._real_extract(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-22 07:17:14.672423
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._VALID_URL == url
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:15.877675
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test

    """
    ArchiveOrgIE()



# Generated at 2022-06-22 07:18:03.894773
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor({"extractor": "archive_org"})

# Generated at 2022-06-22 07:18:05.370148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert hasattr(ArchiveOrgIE(), '_download_webpage')


# Generated at 2022-06-22 07:18:06.400587
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_initialize()

# Generated at 2022-06-22 07:18:11.759551
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert bool(ArchiveOrgIE()._VALID_URL.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'))

    assert not bool(ArchiveOrgIE()._VALID_URL.match('http://www.youtube.com/'))


# Generated at 2022-06-22 07:18:12.424490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:13.578378
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE
    assert instance

# Generated at 2022-06-22 07:18:18.764167
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:26.407449
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    class TestArchiveOrgIE(unittest.TestCase):
        def test_archiveorg_large(self):
            self.assertEqual(
                ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')._VALID_URL,
                'https://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
            )
    unittest.main()

# Generated at 2022-06-22 07:18:33.542807
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ArchiveOrgIE = ArchiveOrgIE()
    assert isinstance(_ArchiveOrgIE, InfoExtractor)
    assert _ArchiveOrgIE.IE_NAME == 'archive.org'
    assert _ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert _ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:18:37.823729
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from .test_main import _TEST_MAIN_TEST_CLASSES
        _TEST_MAIN_TEST_CLASSES.append(ArchiveOrgIE)
    except NameError:
        pass
    archive_org_ie = ArchiveOrgIE()
    print(archive_org_ie)

# Generated at 2022-06-22 07:20:25.587807
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:20:28.079552
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == "archive.org")
    assert(ie.IE_DESC == "archive.org videos")
    assert(ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)")

# Generated at 2022-06-22 07:20:29.494235
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-22 07:20:39.777442
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # First test
    ArchiveOrgIE._VALID_URL = r'http://archive\.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:20:40.533290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:46.903579
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:20:49.492992
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ The constructor of the class ArchiveOrgIE can be called without arguments. """
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:51.900877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:20:54.537865
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:21:06.193921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor, _TEST_URL
    from .youtube import YoutubeIE, YoutubeSearchIE
    from .youtube_playlists import YoutubePlaylistIE, YoutubeUserIE
    from .youtube_channel import YoutubeChannelIE

    class DummyIE(InfoExtractor):
        def __init__(self, ids):
            self.ids = ids

    InfoExtractor._ies = [
        YoutubeIE(),
        YoutubePlaylistIE(),
        YoutubeUserIE(),
        YoutubeChannelIE(),
        YoutubeSearchIE(),
    ]