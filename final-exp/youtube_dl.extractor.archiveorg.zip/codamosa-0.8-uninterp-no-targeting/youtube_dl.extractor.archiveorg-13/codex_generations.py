

# Generated at 2022-06-22 07:13:38.326542
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE().IE_NAME == 'archive.org');

# Generated at 2022-06-22 07:13:44.482912
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE('archiveorg', 'archive.org')
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:56.253321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import os
    import tempfile

    from .common import makedirs

    from ..utils import (
        urljoin,
        url_basename,
    )

    tempdir = tempfile.mkdtemp()

    for test in ArchiveOrgIE._TESTS:
        url = test['url']
        extractor = ArchiveOrgIE(lambda **x: x)
        try:
            os.makedirs(os.path.join(tempdir, url_basename(url)))
        except:
            pass
        filename = os.path.join(tempdir, url_basename(url), 'test.mp4')
        if not os.path.exists(filename):
            extractor._download_webpage(url, url_basename(url), tempdir)

# Generated at 2022-06-22 07:13:58.356952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # make sure it's an instance of ArchiveOrgIE
    obj = ArchiveOrgIE()
    assert isinstance(obj, ArchiveOrgIE)


# Generated at 2022-06-22 07:13:58.983421
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:07.215064
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of class ArchiveOrgIE."""

    # Create an instance of ArchiveOrgIE
    ie = ArchiveOrgIE()

    # Check that the ie is well-formed
    assert ie.name == 'archive.org'
    assert ie.title == ie.IE_DESC
    assert ie.description == ie.IE_DESC
    assert ie.thumbnail == 're:^https?://.*\.jpg$'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._download == ie.download
    assert ie._is_valid_url(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:14:11.231279
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE(None)
    assert inst._VALID_URL is ArchiveOrgIE._VALID_URL
    assert inst._TESTS is ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:14:21.923848
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_NAME == 'archive.org'
    assert inst.IE_DESC == 'archive.org videos'
    assert inst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:30.862986
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:31.554580
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:43.073501
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:14:51.480666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None
    assert ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None
    assert ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') is not None

# Generated at 2022-06-22 07:14:54.988524
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Nothing interesting to unit test in constructor
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:00.889577
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = ArchiveOrgIE._VALID_URL
    ie.IE_NAME = ArchiveOrgIE.IE_NAME
    ie.IE_DESC = ArchiveOrgIE.IE_DESC
    ie._TESTS = ArchiveOrgIE._TESTS
    ie.test()

# Generated at 2022-06-22 07:15:02.055515
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:03.740935
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:05.779480
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()


# Generated at 2022-06-22 07:15:06.305874
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:15:12.319380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:15:13.338330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Assign parameter to the object
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:24.608606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:25.676441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:35.202221
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    from .common import InfoExtractor
    from ..compat import compat_str
    from ..utils import ExtractorError

    class FakeInfoExtractor(InfoExtractor):
        IE_NAME = 'archive.org'
        _VALID_URL = None
        _TEST = {
            'url': 'http://archive.org/',
            'file': 'fake.mp4',
            'info_dict': {
                'id': 'fake'
            },
            # 'params': {
            #     # rtmp download
            #     'skip_download': True,
            # },
        }

    ie = FakeInfoExtractor()
    ie.initialize()

    # No id
    with ExtractorError(expected_message='You must provide an id'):
        ie._real_initialize(ie._VALID_URL)

   

# Generated at 2022-06-22 07:15:37.342145
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from .common import InfoExtractor
	
	assert InfoExtractor.ie_key('archive.org') == 'ArchiveOrgIE'

# Generated at 2022-06-22 07:15:40.945555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  info = ie.extract(ie._VALID_URL)
  assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:15:47.975981
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# Create an instance of class ArchiveOrgIE and test sensible attributes
	ie = ArchiveOrgIE()
	assert ie.IE_NAME == 'archive.org'
	assert ie.IE_DESC == 'archive.org videos'
	# Test _VALID_URL
	assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:49.094428
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:51.603744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_common import TestCommon
    ie = ArchiveOrgIE(TestCommon.default_get_ready_instance())
    assert ie != None


# Generated at 2022-06-22 07:15:53.304988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("Testing ArchiveOrgIE")
    youtube_ie = ArchiveOrgi()

# Generated at 2022-06-22 07:15:54.416407
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-22 07:16:16.737367
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
     ie = ArchiveOrgIE()
     ie.IE_NAME
     ie.IE_DESC
     ie._VALID_URL
     ie._TESTS

# Generated at 2022-06-22 07:16:25.914394
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_parse_html5_media_entries')
    assert hasattr(ie, '_parse_jwplayer_data')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, 'IE_DESC')
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-22 07:16:27.339892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie != None)



# Generated at 2022-06-22 07:16:28.615519
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)


# Generated at 2022-06-22 07:16:31.037237
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org' 
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:16:32.190881
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:33.245236
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:16:36.350634
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL


# Generated at 2022-06-22 07:16:38.977115
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global ie
    if ie:
        ie.download("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:16:40.899502
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ArchiveOrgIE = ArchiveOrgIE()
    assert isinstance(_ArchiveOrgIE, ArchiveOrgIE)

# Generated at 2022-06-22 07:17:22.701059
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-22 07:17:24.224423
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    Test = ArchiveOrgIE()
    Test

# Generated at 2022-06-22 07:17:24.775453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("")

# Generated at 2022-06-22 07:17:34.128466
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:17:35.162194
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    assert t.name == 'archive.org'
    assert t.description == 'archive.org videos'

# Generated at 2022-06-22 07:17:36.396798
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-22 07:17:42.568642
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:52.678179
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = globals()['ArchiveOrgIE']
    obj = class_()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert obj._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-22 07:18:00.875626
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC = 'archive.org videos'
    ie.IE_NAME = 'archive.org'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:18:06.196487
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    ie.IE_DESC
    ie.IE_NAME
    ie.__name__
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:19:55.649611
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:19:58.775878
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:20:03.470946
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:20:04.863859
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)


# Generated at 2022-06-22 07:20:06.543057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test that we can construct an ArchiveOrgIE object."""
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:14.006572
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # archiveorg: tests for IE being able
    # to extract embeds from embed urls
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # archiveorg: tests for IE being able
    # to extract embeds from details urls
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')

# Generated at 2022-06-22 07:20:14.723564
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:20:15.984775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:20:20.209810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-22 07:20:21.444784
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	test_ArchiveOrgIE.aOrg = ArchiveOrgIE()

test_ArchiveOrgIE()