

# Generated at 2022-06-22 07:13:45.287431
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	infoExtractor = ArchiveOrgIE()
	print('Implemented tests for ArchiveOrgIE')
	assert infoExtractor.IE_NAME == 'archive.org'
	assert infoExtractor.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:13:50.337932
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-22 07:13:52.101245
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = ArchiveOrgIE()._VALID_URL
    assert url is not None


# Generated at 2022-06-22 07:14:02.729769
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class args:
        vid = 'json_test'

    ao = ArchiveOrgIE(args)
    data = ao._download_json(
        'http://archive.org/details/' + args.vid, args.vid, query={
            'output': 'json',
        })
    r = ao._real_extract(data['metadata'])

    # Test if all the given fields are parsed successfully
    assert r.get('id') == data['metadata']['identifier']
    assert r.get('title') == data['metadata']['title'][0]
    assert r.get('description') == data['metadata']['description'][0]
    assert r.get('uploader') == data['metadata']['publisher'][0]

# Generated at 2022-06-22 07:14:06.901560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import urllib2
    try:
        urllib2.urlopen('http://example.com', timeout=1)
    except urllib2.URLError:
        # Test is expected to fail if there is no network connection
        pass

# Generated at 2022-06-22 07:14:18.576013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    m = ArchiveOrgIE()
    assert m.ie_key() == 'archive.org'
    assert m.ie_desc() == 'archive.org videos'
    inf = m.ie_info()
    assert inf['id'] == 'archive.org'
    assert inf['name'] == 'archive.org'
    assert inf['description'] == 'archive.org videos'

# Generated at 2022-06-22 07:14:29.301571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:30.705656
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:34.788826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for url in ['https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect']:
        # at the moment constructor of a class doesn't return.
        ArchiveOrgIE(archiveorgIE = ArchiveOrgIE)

# Generated at 2022-06-22 07:14:42.555685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Note that ArchiveOrgIE constructor accepts 4 arguments. The variables
    # 'clipsUrls' and 'clipsProtocols' are unused
    #
    # In order to check the constructor, we run a test case against it.
    # The md5 result should be 8af1d4cf447933ed3c7f4871162602db.
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:14:54.050297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:06.705741
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # Test valid URLs
    assert ie._valid_url(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._valid_url(
        'http://www.archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._valid_url(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')

# Generated at 2022-06-22 07:15:08.318653
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE({}, {}, {})

# Generated at 2022-06-22 07:15:09.183934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:11.841508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """
    global archiveOrgIE
    archiveOrgIE = ArchiveOrgIE()

# Generated at 2022-06-22 07:15:16.481834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testobject = ArchiveOrgIE()
    assert testobject.IE_NAME == 'archive.org'
    assert testobject.IE_DESC == 'archive.org videos'
    assert testobject._VALID_URL.endswith('archive\.org/(details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:15:25.312555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    class TestArchiveOrgIE(unittest.TestCase):
        def test_constructor(self):
            archiveOrgIE = ArchiveOrgIE("Gopher")
            self.assertEqual(archiveOrgIE.ie_key(), "Gopher")
            self.assertEqual(archiveOrgIE.ie_key(), archiveOrgIE.ie_key())

    unittest.main()

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:15:26.850829
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'

# Generated at 2022-06-22 07:15:35.202107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  # Check that ArchiveOrgIE accepts URL and parse into id
  assert ArchiveOrgIE(None)._match_id(
      'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')\
      == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
  # Check that ArchiveOrgIE accepts URL with "embed" and parse into id
  assert ArchiveOrgIE(None)._match_id(
      'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')\
      == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-22 07:15:46.718161
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

    # Initialization
    assert info_extractor.ie_key() == 'ArchiveOrg'
    assert info_extractor.ie_desc() == 'archive.org videos'
    assert info_extractor.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info_extractor.valid_url('https://archive.org/details/Cops1922')
    assert info_extractor.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not info_extractor.valid_url('http://archive.org/')

# Generated at 2022-06-22 07:16:10.989541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Pass
    print(ArchiveOrgIE._TESTS)

    # Fail
    #print(ArchiveOrgIE._TESTS[1])

# Generated at 2022-06-22 07:16:18.368671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    from .youtube import YoutubeIE
    import re
    import copy

    # First, test for URL of Valid Form
    test_url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    test_video = ArchiveOrgIE(InfoExtractor())._match_id(test_url)
    assert test_video == 'MSNBCW_20131125_040000_To_Catch_a_Predator'

    # Next, test for invalid URL
    with pytest.raises(RegexNotFoundError) as excinfo:
        ArchiveOrgIE(InfoExtractor())._match_id('https://archive.org/details/')

    # Finally, test to see if Regex

# Generated at 2022-06-22 07:16:22.734774
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.ie_name == 'archive.org'
    assert info_extractor.ie_key == 'archive.org'



# Generated at 2022-06-22 07:16:24.555788
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Class ArchiveOrgIE expects to be given a url as its parameter and
    # returns an object of that class
    archive_org_ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert archive_org_ie


# Generated at 2022-06-22 07:16:27.794352
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Test for methods in class ArchiveOrgIE
import os
import unittest

PWD = os.path.dirname(os.path.abspath(__file__))


# Generated at 2022-06-22 07:16:29.667624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:35.951459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=line-too-long
    assert (ArchiveOrgIE._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    # pylint: enable=line-too-long
    # pylint: disable=protected-access
    # constructor check of ArchiveOrgIE
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    _ = ArchiveOrgIE._match_id(url)
    # pylint: enable=protected-access


# Generated at 2022-06-22 07:16:37.108612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:16:37.718029
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:39.508762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie != None

# Generated at 2022-06-22 07:17:28.718458
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    AssertEquals('archive.org', ie.IE_NAME)
    AssertEquals('archive.org videos', ie.IE_DESC)
    AssertEquals(
        'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)',
        ie._VALID_URL)

# Generated at 2022-06-22 07:17:32.839340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    data = ArchiveOrgIE()
    assert data._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert data.IE_NAME == 'archive.org'
    assert data.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:35.311223
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import pprint
    pprint.pprint(ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'))

# Generated at 2022-06-22 07:17:36.455571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:17:41.109199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from . import (
        ArchiveOrgIE,
        common,
        extractor,
        utils,
    )
    import re
    import unittest
    import utils

    class ArchiveOrgIETestCase(unittest.TestCase):
        '''Unit test for archive.org extractor'''
        def setUp(self):
            self.archive_org_extractor = ArchiveOrgIE()

        def test_archive_org_extractor(self):
            self.assertIsInstance(
                self.archive_org_extractor, ArchiveOrgIE)

        def test_archive_org_extractor_title(self):
            expected_title = '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-22 07:17:42.089702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:17:46.195551
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    assert ArchiveOrgIE.ie_key() == 'archive.org'
    assert ArchiveOrgIE.ie_key('archive.org') == 'archive.org'

# Generated at 2022-06-22 07:17:47.832366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # no assert here, just not blow up is enough
    pass

# Generated at 2022-06-22 07:17:55.375471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import pytest
    from archiveorg import ArchiveOrgIE
    
    url1 = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url2 = 'https://archive.org/details/Cops1922'
    url3 = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url4 = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    urls = [url1, url2, url3, url4]
    for url in urls:
        archive_org = ArchiveOrgIE(url)

# Generated at 2022-06-22 07:17:55.901816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:46.672086
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:18:47.776292
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    return True

# Generated at 2022-06-22 07:18:53.461218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i.LANG == 'en'

# Generated at 2022-06-22 07:18:55.154322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-22 07:18:59.644198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import yaml
    yaml.load('''
- !ArchiveOrgIE
    id: XD300-23_68HighlightsAResearchCntAugHumanIntellect
    timestamp: 1268695290
''')

# Generated at 2022-06-22 07:19:05.627814
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE().IE_DESC == ArchiveOrgIE.IE_DESC
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS
    assert ArchiveOrgIE()._extract_playlist

# Generated at 2022-06-22 07:19:10.574633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')


# Generated at 2022-06-22 07:19:22.649026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    expected = 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert instance._VALID_URL == expected

# Generated at 2022-06-22 07:19:26.020941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ test for ArchiveOrgIE constructor """
    sample_url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator'
    ie = ArchiveOrgIE()
    assert ie.suitable(sample_url)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:19:29.002429
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .example_tests import run_example_tests
    run_example_tests(ArchiveOrgIE,module_name='archiveorg')


# Generated at 2022-06-22 07:20:36.735774
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:20:45.738668
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert(instance.IE_NAME == 'archive.org')
    assert(instance.IE_DESC == 'archive.org videos')
    assert(instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(instance._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(instance._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')

# Generated at 2022-06-22 07:20:57.301202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == (r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:21:01.530068
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE

    # Create a mock object for the info extractor class
    ie_mock = InfoExtractor.create_mock()

    test_instance = ArchiveOrgIE(ie_mock.test_instance)

    assert isinstance(test_instance, ArchiveOrgIE)



# Generated at 2022-06-22 07:21:12.545862
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This test only checks the constructor for archive.org, for complete unit tests
    # please see test_archive_org.py
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:13.284324
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:21:21.231364
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:23.140264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:26.974718
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:28.298774
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # (1) Construcion:
    arch = ArchiveOrgIE()
    assert arch.ie_name == "Archive.org"

