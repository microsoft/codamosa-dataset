

# Generated at 2022-06-22 07:13:40.432057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ArchiveOrgIE = ArchiveOrgIE("archive.org")
    assert _ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:13:43.881537
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:13:44.428522
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # For coverage
    ArchiveOrgIE(None)

# Generated at 2022-06-22 07:13:45.240143
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ArchiveOrgIE()

# Generated at 2022-06-22 07:13:47.018289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Test ArchiveOrgIE.suitable()

# Generated at 2022-06-22 07:13:49.743446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE('http://archive.org/')
    assert info_extractor.IE_NAME == 'archive.org'
    

# Generated at 2022-06-22 07:14:01.226505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test url validation of ArchiveOrgIE
    assert ArchiveOrgIE()._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._match_id('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    assert ArchiveOrgIE()._match_id('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'


# Generated at 2022-06-22 07:14:03.363896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:04.039754
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:14:06.248099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a_org_ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:20.460346
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert ie._VALID_URL == ie._WORKING_URL


# Generated at 2022-06-22 07:14:21.509214
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE().test()

# Generated at 2022-06-22 07:14:33.580948
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    # Test _VALID_URL.
    expected_result = InfoExtractor._VALID_URL + '.*'
    actual_result = info_extractor._VALID_URL
    assert actual_result == expected_result, 'Expected: ' + expected_result + ' Actual: ' + actual_result
    # Test _TESTS.

# Generated at 2022-06-22 07:14:34.969309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of class ArchiveOrgIE"""
    # Access without creating object
    assert ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:14:41.601560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:42.713898
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ar = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:47.593803
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:48.805881
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')

# Generated at 2022-06-22 07:14:53.082459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_key()

# Generated at 2022-06-22 07:15:05.846981
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({})
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:28.894997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:15:33.384953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.extractor == ArchiveOrgIE
    assert ie.ie_key() == ArchiveOrgIE.IE_NAME
    assert ie.ie_desc() == ArchiveOrgIE.IE_DESC
    assert ie.valid_url() == ArchiveOrgIE._VALID_URL
    assert ie.get_url() in ArchiveOrgIE._VALID_URL


# Generated at 2022-06-22 07:15:35.888833
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'



# Generated at 2022-06-22 07:15:38.190246
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-22 07:15:50.338282
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tst = ArchiveOrgIE()
    assert tst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert tst._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert tst._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-22 07:15:57.258093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check with Video-URL as input
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.extract() is not None
    # check with HTML-Page as input
    ie = ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.extract() is not None

# Generated at 2022-06-22 07:15:58.265987
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-22 07:15:58.967084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()


# Generated at 2022-06-22 07:16:00.680077
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()
    assert archiveorg.IE_NAME == 'archive.org'
    assert archiveorg.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:01.687711
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:16:46.590521
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL

# Generated at 2022-06-22 07:16:54.033934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    from .youtube import YoutubeIE
    from .common import ListExtractor
    from .common import SearchInfoExtractor
    from .common import merge_dicts
    from .compat import compat_str

    ie = ArchiveOrgIE(InfoExtractor())

    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ArchiveOrgIE)
    assert not isinstance(ie, YoutubeIE)
    assert not isinstance(ie, ListExtractor)
    assert not isinstance(ie, SearchInfoExtractor)

    # __init__() invokes _prepare_extractor()
    assert ie._downloader is not None

    # _prepare_extractor() invokes _get_info_extractor().
    # Here we test ArchiveOrgIE._get_info

# Generated at 2022-06-22 07:16:58.125469
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_name == 'archive.org'

# Generated at 2022-06-22 07:17:05.933580
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:06.618588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-22 07:17:08.101597
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        assert False

# Generated at 2022-06-22 07:17:19.635414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Tests for attribute _VALID_URL
    assert ie._VALID_URL == ie.IE_NAME.lower() + ':' + ie._VALID_URL
    # Tests for method _real_extract
    webpage = ie._download_webpage(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    playlist = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    attrs = extract_attributes(playlist)
    playlist = attrs.get('value')
   

# Generated at 2022-06-22 07:17:23.745478
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie=ArchiveOrgIE()
    assert archive_org_ie.ie_key() == 'archive.org'
    assert archive_org_ie.ie_desc() == 'archive.org videos'
    assert archive_org_ie.ie_name() == 'archive.org'

# Generated at 2022-06-22 07:17:26.162270
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-22 07:17:27.414854
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert(isinstance(obj, InfoExtractor))

# Generated at 2022-06-22 07:19:13.574274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("Test ArchiveOrgIE constructor")
    testArchiveOrgIE = ArchiveOrgIE()
    print("Object ArchiveOrgIE created")


# Generated at 2022-06-22 07:19:17.641992
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(ArchiveOrgIE.ie_key())
    assert ie.SUCCESS == ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:19:26.882558
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE
    """
    from ..utils import make_HTTPServer
    from ..__main__ import main
    from ..compat import urlopen, urljoin
    import re

    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    server = make_HTTPServer()
    next_server = make_HTTPServer()
    ydl = main([], '--socket-timeout=2 --no-warnings --skip-download --quiet "%s"' % url,
               server=server, next_server=next_server)
    assert(re.search(r'https?://.*ogg', ydl.prepare_filename(ydl.get_info(url))) is not None)

# Generated at 2022-06-22 07:19:27.982226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:19:34.628411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                    {'title': 'Test title'}),
                  ('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                    {'title': 'Test title'})]
    for url, _ in test_cases:
        ie = ArchiveOrgIE(url)
        assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:19:41.894779
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    with open('test/testdata/archive.org/WNYC_20080711_200000_TheLeonardLopateShow.json') as f:
        testdata = f.read()
        ie = ArchiveOrgIE()
        ie._parse_jwplayer_data(
            ie._parse_json(testdata, 'WNYC_20080711_200000_TheLeonardLopateShow'),
            'WNYC_20080711_200000_TheLeonardLopateShow')

# Generated at 2022-06-22 07:19:52.090002
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert test_obj.test_URL('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert test_obj.test_URL('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert test_obj.test_URL('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert test_obj.test_URL('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert test_obj.test_URL('http://archive.org/details/Cops1922')

# Generated at 2022-06-22 07:19:57.634311
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:20:08.702988
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:20:12.690962
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("test_ArchiveOrgIE", "test_ArchiveOrgIE")
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-22 07:22:30.185792
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.name is not None
    assert obj.description is not None
    assert obj.ie_key() is not None
    assert obj.thumbnail() is not None
    assert obj.upload_date() is None
    assert obj.uploader_id() is None
    assert obj.height() is None
    assert obj.width() is None
    assert obj.extractor() is not None
    assert obj.duration() is None
    assert obj.num_downloads() is None
    assert obj.average_rating() is None
    assert obj.formats() is not None
    assert obj.age_limit() is None
    assert obj.is_live() is False
    assert obj.debug() is None
    assert obj.subtitles() is None

    assert obj.is_suitable(obj.url)

# Generated at 2022-06-22 07:22:30.826381
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:22:31.400324
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return True

# Generated at 2022-06-22 07:22:34.535379
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE constructor."""
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.ie_description() == 'archive.org videos'

# Generated at 2022-06-22 07:22:42.385243
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_downloader import TestDownloader
    '''
    Test whether constructor generates expected instance
    '''
    ie = TestDownloader([ArchiveOrgIE()], {'':
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    })
    video = ie.extract_info('')
    assert video.get('title') == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert video.get('uploader') == 'SRI International'

# Generated at 2022-06-22 07:22:45.152532
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:22:46.827359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    p = ArchiveOrgIE()
    assert p.IE_NAME == 'archive.org'
    assert p.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:22:50.250238
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-22 07:22:51.765976
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-22 07:23:02.276598
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    loader = ArchiveOrgIE()
    assert loader._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'