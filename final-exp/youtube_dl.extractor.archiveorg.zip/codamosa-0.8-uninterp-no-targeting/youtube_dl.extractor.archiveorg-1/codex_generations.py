

# Generated at 2022-06-22 07:13:42.467506
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return

# Generated at 2022-06-22 07:13:53.984330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE('archive.org videos') == 'archive.org'
	#assert ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == '8af1d4cf447933ed3c7f4871162602db'
	#assert ArchiveOrgIE('http://archive.org/details/Cops1922') == '0869000b4ce265e8ca62738b336b268a'
	#assert ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
	#assert ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == True

# Generated at 2022-06-22 07:14:04.938964
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test with url http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/
    assert ArchiveOrgIE()._match_id('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    assert ArchiveOrgIE()._match_id('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'

# Generated at 2022-06-22 07:14:06.338539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:10.665214
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-22 07:14:11.697929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    print(result)

# Generated at 2022-06-22 07:14:20.678590
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tested on https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    # and https://archive.org/details/japanesecinema
    # and https://archive.org/details/th1_49
    # There are some other complications when the details page is configured
    # with an iframe embed.
    ie = ArchiveOrgIE()
    ie.download('archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.download('archive.org/details/japanesecinema')
    ie.download('archive.org/details/th1_49')

# Generated at 2022-06-22 07:14:21.713720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:22.798223
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:14:30.047541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_NAME == ie.__class__.IE_NAME
    assert ie.IE_DESC == ie.__class__.IE_DESC
    assert ie._VALID_URL == ie.__class__._VALID_URL
    assert ie._TESTS == ie.__class__._TESTS

# Generated at 2022-06-22 07:14:38.446430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # ArchiveOrgIE is abstract class and can not create object
    try:
        item = ArchiveOrgIE()
    except TypeError:
        pass

# Generated at 2022-06-22 07:14:40.195706
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This is a unit test for the constructor of ArchiveOrgIE class
    """
    # No exception should be thrown
    ArchiveOrgIE()

# Generated at 2022-06-22 07:14:42.831691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    obj = ArchiveOrgIE()
    assert isinstance(obj, ArchiveOrgIE)
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-22 07:14:48.567298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instance of ArchiveOrgIE
    ie = ArchiveOrgIE()

    # Check return value of _VALID_URL
    assert ie._VALID_URL == ie._VALID_URL
    # Check return value of IE_NAME
    assert ie.IE_NAME == ie.IE_NAME
    # Check return value of IE_DESC
    assert ie.IE_DESC == ie.IE_DESC

# Generated at 2022-06-22 07:15:01.282591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:05.840791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # if we can construct an ArchiveOrgIE object, a TypeError really is not
    # something that should be raised by this test.
    ArchiveOrgIE(None)

# Generated at 2022-06-22 07:15:09.320902
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ie = ArchiveOrgIE()
    test_ie._VALID_URL = ArchiveOrgIE._VALID_URL
    test_ie._TESTS = ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:15:21.549858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .netrc_env import get_credentials
    username, password = get_credentials('archive.org')

    # test for private video
    _, ext = ArchiveOrgIE._BUILTIN_EXTENSIONS[0]
    expected_url = 'http://archive.org/download/publicdomainmovie_Volcano/Volcano_512kb.mp4'
    expected_id = 'publicdomainmovie_Volcano'

# Generated at 2022-06-22 07:15:22.217496
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:15:23.636337
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None) != None


# Generated at 2022-06-22 07:15:45.847607
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    extractor = ArchiveOrgIE()
    assert extractor.IE_NAME == 'archive.org'
    assert extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:50.680140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test constructor of class ArchiveOrgIE.
    """
    
    # Test instance with empty parameters.
    ie = ArchiveOrgIE()
    
    # Test instance with non-empty parameters.
    ie = ArchiveOrgIE("archive.org videos", "archive.org")

# Generated at 2022-06-22 07:15:53.293924
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:15:56.090520
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # Test
    assert ie._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert ie._TESTS
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie.__doc__

# Generated at 2022-06-22 07:16:00.944901
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert inst.IE_NAME == 'archive.org'
    assert inst.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:02.009006
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-22 07:16:12.874640
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert(test_obj.IE_NAME == 'archive.org')
    assert(test_obj.IE_DESC == 'archive.org videos')
    assert(test_obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-22 07:16:17.744978
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert ie._TESTS[0]['url'] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie._TESTS[0]['md5'] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-22 07:16:18.652107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    (ArchiveOrgIE().IE_NAME)

# Generated at 2022-06-22 07:16:22.310482
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'Archive.org'

# Generated at 2022-06-22 07:16:45.590335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:16:53.255734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test the constructor of ArchiveOrgIE.
    # For the format of self.urls,
    # see http://en.wikipedia.org/wiki/Uniform_resource_locator

    a = ArchiveOrgIE()

    for url in ("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
                "https://archive.org/details/Cops1922",
                "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
                "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"):

        b = ArchiveOrgIE(url)
        assert a.IE_NAME == b.IE_NAME
        assert b.urls == [url]



# Generated at 2022-06-22 07:17:03.143133
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:04.371744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-22 07:17:05.366842
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)

# Generated at 2022-06-22 07:17:14.672860
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    ie = ArchiveOrgIE(ie)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:18.273483
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IEInstance = ArchiveOrgIE()
    assert IEInstance.ie_key() == 'archive.org'
    assert IEInstance.ie_desc() == 'archive.org videos'
    assert IEInstance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:28.801465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        ("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
         "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
        ]

    for (input_url, expect_url) in test_cases:
        ie = ArchiveOrgIE({"url": input_url})
        assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
        assert ie.IE_NAME == "archive.org"
        assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-22 07:17:31.892793
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()
    assert test_ArchiveOrgIE.IE_NAME == 'archive.org'
    assert test_ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:33.798688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test.
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:18:27.026666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test that the constructor of the class ArchiveOrgIE
       raises an exception with invalid url"""

    for url in ['http://archive.org/details', 'http://archive.org/embed']:
        try:
            ArchiveOrgIE()._real_extract(url)
        except Exception:
            pass


# Generated at 2022-06-22 07:18:27.645709
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:18:32.792845
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test Archive.org constructor."""
    # archive.org needs a user-agent to be set otherwise
    # 403: Forbidden is returned.
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.valid_url(ArchiveOrgIE._VALID_URL)

# Generated at 2022-06-22 07:18:35.454301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test to prove that ArchiveOrgIE can be instantiated.
    """
    try:
        ArchiveOrgIE()
    except Exception as e:
        assert False, e

# Generated at 2022-06-22 07:18:36.433725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-22 07:18:37.674234
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst

# Generated at 2022-06-22 07:18:49.879960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    x = ArchiveOrgIE()
    assert x.ie_key() == 'archive.org'
    assert x.ie_desc() == 'archive.org videos'
    assert x.ie_name() == 'archive.org'
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'
    assert x.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert x.valid_url('https://archive.org/details/Cops1922') == True

# Generated at 2022-06-22 07:18:50.977963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-22 07:18:51.593564
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:18:53.416665
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:20:54.737692
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """
    ie = ArchiveOrgIE()

    # ensure that object is instance of right class
    assert ie.__class__.__name__ == 'ArchiveOrgIE'


# Generated at 2022-06-22 07:20:58.061274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
	archiveorg = ArchiveOrgIE()
	assert archiveorg._real_extract(url) == None


# Generated at 2022-06-22 07:21:09.840155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert archive
    assert archive.IE_NAME == 'archive.org'
    assert archive.IE_DESC == 'archive.org videos'
    # follow example from https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/extractor/test_common.py
    assert archive._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:11.060041
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    return ie

# Generated at 2022-06-22 07:21:16.246366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:21:19.150442
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:21:19.969475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()

# Generated at 2022-06-22 07:21:22.233669
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:25.663585
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructing an instance of this class by providing URL should not throw
    any exception.
    """
    ie_obj = ArchiveOrgIE(min_working_bitrate=8000000)
    ie_obj.working_bitrate(1000000)

# Generated at 2022-06-22 07:21:27.918039
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print('Testing constructor of class ArchiveOrgIE...')
    ie = ArchiveOrgIE()
    print('Done.')
