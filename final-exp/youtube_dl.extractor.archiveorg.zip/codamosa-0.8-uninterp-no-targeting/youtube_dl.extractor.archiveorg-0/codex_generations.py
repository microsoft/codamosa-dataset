

# Generated at 2022-06-22 07:13:52.699555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE()
    assert arch.IE_NAME == 'archive.org'
    assert arch.IE_DESC == 'archive.org videos'
    assert arch._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:13:59.328275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert archive_org_ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert archive_org_ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert archive_org_ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:14:03.852080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(False)
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:14:06.382602
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of ArchiveOrgIE can be invoked without any exception
    ie = ArchiveOrgIE(None)



# Generated at 2022-06-22 07:14:08.165768
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:14:11.743272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:14:22.441012
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/WFLADT1966v1-12-10'
    ie = ArchiveOrgIE('archive.org', {'id': 'WFLADT1966v1-12-10'})
    info = ie.extract(url)
    assert len(info) > 0
    assert info['id'] == 'WFLADT1966v1-12-10'
    assert info['title'] == 'WFLA DT 1966 v1 12-10'
    assert info['description'] is not None
    assert info['creator'] is not None
    assert info['release_date'] is not None
    assert info['uploader'] is not None
    assert info['timestamp'] is not None
    assert info['upload_date'] is not None
    assert info['language'] is not None

# Generated at 2022-06-22 07:14:31.388329
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = '__TEST__'
    ie._TESTS = [{
        'url': '__URL__',
        'md5': '__MD5__',
        'info_dict': {
            'id': '__ID__',
            'ext': '__EXT__',
            'title': '__TITLE__',
            'description': '__DESCRIPTION__',
            'creator': '__CREATOR__',
            'release_date': '__RELEASE_DATE__',
            'uploader': '__UPLOADER__',
            'timestamp': '__TIMESTAMP__',
            'upload_date': '__UPOLOAD_DATE__',
        }
    }]

    info = ie.extract('__URL__')

    expected

# Generated at 2022-06-22 07:14:32.880359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE().IE_NAME == "archive.org"

# Generated at 2022-06-22 07:14:43.215243
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:14:55.389471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = TestInfoExtractor()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-22 07:14:59.234972
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-22 07:15:01.052799
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org videos')

# Generated at 2022-06-22 07:15:04.831274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #TODO: throw error if class name is not IE_NAME
    assert True

# Generated at 2022-06-22 07:15:12.939465
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-22 07:15:13.600788
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:15:19.487970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:24.368053
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:15:26.061041
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:15:35.470868
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE class
    """
    ie = ArchiveOrgIE()
    # Testing the ids of videos
    sample_urls = [
        'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
        'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator',
    ]

# Generated at 2022-06-22 07:15:47.457911
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:15:58.164886
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Init DummyClass with simple data
    inst = ArchiveOrgIE({})
    # Create test videos urls as list
    test_urls = ['http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                 'https://archive.org/details/Cops1922',
                 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect']
    # Iterate through test urls list
    for test_url in test_urls:
        # Extract video data
        video_data = inst._real_extract(test_url)
        # Check if video id or error message present in extracted video data
        assert 'Ok'

# Generated at 2022-06-22 07:16:00.632178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:02.821410
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:11.203141
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test constructor of ArchiveOrgIE
    """
    # Check for invalid URLs
    invalid_urls = [
        "http://test.test.test",
        "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/test/value",
    ]
    for url in invalid_urls:
        try:
            ArchiveOrgIE(url)
            raise AssertionError("ArchiveOrgIE constructor did not throw exception for invalid URL:%s" % url)
        except Exception:
            pass
    return True

# Generated at 2022-06-22 07:16:15.801872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg_ie = ArchiveOrgIE()
    assert aorg_ie.IE_NAME == 'archive.org'
    assert aorg_ie.IE_DESC == 'archive.org videos'
    assert aorg_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:16:17.806322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:16:18.384567
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-22 07:16:23.580747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._match_id(url) == id

# Generated at 2022-06-22 07:16:27.203026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Normal case
    ArchiveOrgIE()

    # Bad URL
    try:
        ArchiveOrgIE(path='BadURL/')
    except AssertionError:
        pass
    else:
        raise Exception('Did not rise exception when a bad URL was passed')

# Generated at 2022-06-22 07:16:53.328111
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE("http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    assert a.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:16:58.344321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Construction of ArchiveOrgIE
    archive_org_IE = ArchiveOrgIE()
    # We can get the name of the module by its class
    assert archive_org_IE.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:17:06.121543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    i1 = ArchiveOrgIE(url)
    assert i1.IE_NAME == 'archive.org'
    assert i1._VALID_URL == url
    assert i1.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:17:07.997300
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:17:12.706230
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """

    ie = ArchiveOrgIE()
    print(ie.IE_NAME)
    print(ie.IE_DESC)
    print(ie._VALID_URL)



if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-22 07:17:14.519016
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-22 07:17:18.446067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert i._TESTS is not None

# Generated at 2022-06-22 07:17:23.720605
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:17:25.357350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    ie = ArchiveOrgIE()
    assert ie is not None

# Generated at 2022-06-22 07:17:28.055176
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(
        ArchiveOrgIE._VALID_URL ==
        r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    )

# Generated at 2022-06-22 07:18:18.992896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-22 07:18:20.276918
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO : Add unit test for constructor of class ArchiveOrgIE
    pass


# Generated at 2022-06-22 07:18:21.080252
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()


# Generated at 2022-06-22 07:18:24.040591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-22 07:18:28.393644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/msdos_Ultima_Underworld_The_Stygian_Abyss_1992')
    assert str(ie) == '<ArchiveOrgIE https://archive.org/details/msdos_Ultima_Underworld_The_Stygian_Abyss_1992>'

# Generated at 2022-06-22 07:18:30.863535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(1)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:18:31.890205
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-22 07:18:36.527539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-22 07:18:38.293749
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE("archives.org")


# Generated at 2022-06-22 07:18:50.708860
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:21:00.021097
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:00.727226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-22 07:21:01.864866
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # ArchiveOrgIE()
    pass

# Generated at 2022-06-22 07:21:05.440260
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_instance = ArchiveOrgIE()
    # Test initialization
    assert test_instance.IE_NAME == 'archive.org'
    assert test_instance.IE_DESC == 'archive.org videos'

# Generated at 2022-06-22 07:21:09.428687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """It should pass."""
    # TODO: create some testcases
    if True:
        return
    ie = ArchiveOrgIE()
    ie.download('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-22 07:21:13.059422
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.initialize()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-22 07:21:15.813244
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test whether ArchiveOrgIE is constructing correctly
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-22 07:21:25.343132
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test following two URLs are correspond to ArchiveOrgIE
    test_urls = [
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
    ]
    # Loop over test cases
    for test_url in test_urls:
        # Get backend of URL
        backend = gen_extractors.gen_extractor_backend_for_url(test_url)
        # Test if the backend corresponding to the test URL is ArchiveOrgIE
        assert backend == ArchiveOrgIE

# Generated at 2022-06-22 07:21:30.426667
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    info = ie.extract("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    assert info["id"] == "MSNBCW_20131125_040000_To_Catch_a_Predator"

# Generated at 2022-06-22 07:21:31.315206
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie