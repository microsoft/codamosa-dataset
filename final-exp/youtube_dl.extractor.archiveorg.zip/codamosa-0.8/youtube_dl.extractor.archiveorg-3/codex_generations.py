

# Generated at 2022-06-12 17:14:32.351879
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test an invalid URL
    assert ArchiveOrgIE(None)
    # Test a valid URL
    archiveOrgIE = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:33.008719
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-12 17:14:36.277745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:37.707297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:14:45.169025
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case 1 (normal case)
    # List of keys in info_dict to be compared with expected value in test case
    my_list = ['id', 'ext', 'title', 'description',
               'creator', 'release_date', 'uploader', 'timestamp',
               'upload_date']

    archiveorg_ie = ArchiveOrgIE()
    info_dict = archiveorg_ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    for key in my_list:
        assert info_dict[key] == ArchiveOrgIE._TESTS[0]['info_dict'][key]

    # Test case 2 (abnormal case)
    archiveorg_ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:46.712813
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'


# Generated at 2022-06-12 17:14:54.905170
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import base64
    import sys
    import io
    import traceback
    
    try:
        result = io.StringIO()
        oldstdout, oldstderr = sys.stdout, sys.stderr
        sys.stdout, sys.stderr = result, result
        ArchiveOrgIE()
        result.seek(0)
        resstr = result.read()
        errstr = "No erros generated"
    except Exception:
        result.seek(0)
        resstr = result.read()
        buffer = io.StringIO()
        traceback.print_exc(file=buffer)
        errstr = buffer.getvalue()
    finally:
        sys.stdout, sys.stderr = oldstdout, oldstderr
        result.close()
        
    if resstr:
        test

# Generated at 2022-06-12 17:15:04.648157
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  """Test ArchiveOrgIE."""
  # input url and expected output for ArchiveOrgIE
  # class constructor

# Generated at 2022-06-12 17:15:13.484001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )


    ie = ArchiveOrgIE()
    ie._match_id('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    'id' in ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:15:14.435199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-12 17:15:20.358670
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:22.723373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:24.631151
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TEST['expected_url']

# Generated at 2022-06-12 17:15:34.276194
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:35.910192
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archive.org")
    assert ie.name == "archive.org videos"

# Generated at 2022-06-12 17:15:38.428684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for archive.org video
    ArchiveOrgIE(None)
    # Test for not archive.org video
    with pytest.raises(TypeError):
        ArchiveOrgIE(None, 'youtube')

# Generated at 2022-06-12 17:15:39.849190
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg_ie = ArchiveOrgIE()
    assert archiveorg_ie.IE_NAME == "archive.org"

# Generated at 2022-06-12 17:15:45.382880
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie._real_extract("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    ie._real_extract("http://archive.org/details/Cops1922")

# Generated at 2022-06-12 17:15:50.568390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # The dtype is important for the id match
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:51.817010
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-12 17:16:03.249853
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE()

# Generated at 2022-06-12 17:16:04.264633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:05.704760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org',None)
    assert True

# Generated at 2022-06-12 17:16:11.051684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of class ArchiveOrgIE
    # Test if the ArchiveOrgIE was instantiated correctly
    ie = ArchiveOrgIE(None)

    # Test if the instance has attribute _VALID_URL
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL

    # Test if the instance has attribute IE_NAME
    assert hasattr(ie, 'IE_NAME')
    assert ie.IE_NAME

    # Test if the instance has attribute _TESTS
    assert hasattr(ie, '_TESTS')
    assert ie._TESTS

    # Test if the instance has attribute IE_DESC
    assert hasattr(ie, 'IE_DESC')
    assert ie.IE_DESC

# Generated at 2022-06-12 17:16:20.150301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie is not None
    assert ie.name == u'archive.org'
    assert ie.description == u'archive.org videos'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # TODO: parse youtube video ID and return a youtubeie object
    assert ie.valid_url('https://archive.org/details/youtube-sSAHPlcQsMc') is False
    assert ie.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:16:21.060885
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:24.094957
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:28.077817
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:28.914954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)

# Generated at 2022-06-12 17:16:32.620560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test that the constructor of class ArchiveOrgIE works correctly."""
    ie = ArchiveOrgIE()
    expected_attrs = ['_VALID_URL', 'IE_NAME', 'IE_DESC', '_TESTS']
    for attr in expected_attrs:
        assert ie.__getattribute__(attr)



# Generated at 2022-06-12 17:16:58.541377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test_suite():
        pass
    import unittest
    class Test_ArchiveOrgIE(unittest.TestCase):
        def test_nothing(self):
            pass
    Test_ArchiveOrgIE.test_Nothing = test_suite
    test_suite.__doc__ = Test_ArchiveOrgIE.__doc__
    unittest.main(defaultTest='test_suite')

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:16:59.099360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-12 17:17:00.755257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE()
    assert arch

# Generated at 2022-06-12 17:17:01.891564
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == "archive.org videos"


# Generated at 2022-06-12 17:17:03.989217
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:17:06.543985
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	test = ArchiveOrgIE('test', 'test', {})
	assert isinstance(test, ArchiveOrgIE)

# Unit tests for class ArchiveOrgIE - method extract

# Generated at 2022-06-12 17:17:13.759845
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:16.670883
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).ie_key() == "archive.org"
if __name__ == '__main__':
	test_ArchiveOrgIE()

# Generated at 2022-06-12 17:17:19.143942
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for constructor of class ArchiveOrgIE
    # This test function does nothing useful, but does
    # not crash.
    test = ArchiveOrgIE()
    print(test)

# Generated at 2022-06-12 17:17:25.994666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/tvtunes_4212'

    # File-like object (bad string)
    try:
        info = ie.extract(url, "")
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised."

    # Bad string
    try:
        info = ie.extract(url, "")
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised."

    # Bad URL
    try:
        info = ie.extract(url, "")
    except TypeError:
        pass
    else:
        assert False, "TypeError not raised."


# Generated at 2022-06-12 17:18:19.264917
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:18:20.702752
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(ArchiveOrgIE)

# Generated at 2022-06-12 17:18:23.425626
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch_ie = ArchiveOrgIE()
    assert arch_ie.ie_key() == 'archive.org'
    assert arch_ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:18:29.696723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == 'archive.org'
    assert archive_org_ie.IE_DESC == 'archive.org videos'
    assert archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:34.870609
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # A simple example
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # without an "id"
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-12 17:18:45.712019
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL is not None
    assert ArchiveOrgIE._TESTS is not None
    assert ArchiveOrgIE._TESTS[0].get('url') is not None
    assert ArchiveOrgIE._TESTS[0].get('md5') is not None
    assert ArchiveOrgIE._TESTS[0].get('info_dict') is not None
    assert ArchiveOrgIE._TESTS[0].get('info_dict').get('id') is not None
    assert ArchiveOrgIE._TESTS[0].get('info_dict').get('title') is not None
    assert ArchiveOrgIE._TESTS[0].get('info_dict').get('description') is not None
    assert ArchiveOrgIE._TESTS[0].get('info_dict').get('uploader') is not None
    assert ArchiveOrg

# Generated at 2022-06-12 17:18:48.389476
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    http_server = '--http-server'
    in_archive_org_dir_path = 'in_archive_org_dir'
    assert True == isinstance(
        ArchiveOrgIE(
            http_server, in_archive_org_dir_path),
        InfoExtractor)

# Generated at 2022-06-12 17:18:49.259900
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass # currently there is no constructor for ArchiveOrgIE

# Generated at 2022-06-12 17:18:54.052821
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._VALID_URL is not None
    assert re.match(ArchiveOrgIE._VALID_URL, url)

# Generated at 2022-06-12 17:19:00.072713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    ie = ArchiveOrgIE(url)
    assert ie._match_id(url) == 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-12 17:21:10.444155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i != None


# Generated at 2022-06-12 17:21:11.089980
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:21:11.744619
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()



# Generated at 2022-06-12 17:21:13.022171
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
# Unit test to check _real_extract

# Generated at 2022-06-12 17:21:16.192977
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor test
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4


# Generated at 2022-06-12 17:21:17.829608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(str(type(ArchiveOrgIE(InfoExtractor()))) == "<class '__main__.ArchiveOrgIE'>")

# Generated at 2022-06-12 17:21:24.232347
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:25.646522
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_initialize()

# Generated at 2022-06-12 17:21:27.557326
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' in ArchiveOrgIE._TESTS

# Generated at 2022-06-12 17:21:34.142355
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE.

    This test is used to test whether the class constructor can be called
    successfully or not.
    """
    assert ArchiveOrgIE('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None
    assert ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') is not None
    assert ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None