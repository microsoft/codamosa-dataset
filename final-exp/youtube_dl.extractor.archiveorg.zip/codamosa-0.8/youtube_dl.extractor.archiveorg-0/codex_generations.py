

# Generated at 2022-06-12 17:14:25.558131
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE.__name__ = 'test_ArchiveOrgIE'
    ArchiveOrgIE.test()
    ArchiveOrgIE.__name__ = 'ArchiveOrgIE'


# Generated at 2022-06-12 17:14:28.283475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrg = ArchiveOrgIE()
    archiveOrg._real_initialize()
    archiveOrg._downloader.http.close()


# Generated at 2022-06-12 17:14:28.903460
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:30.323331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();

# Generated at 2022-06-12 17:14:33.540694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE."""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:14:37.677607
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert re.match(ie._VALID_URL, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_VERSION == '20140606'

# Generated at 2022-06-12 17:14:40.425453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_name()

# Generated at 2022-06-12 17:14:44.858100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'download')
    assert ie.valid_url('https://archive.org/details/Cops1922', 'download')



# Generated at 2022-06-12 17:14:47.181058
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-12 17:14:55.167989
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Testing ArchiveOrgIE constructor, fetching a torrent file."""
    import io
    import os
    import shutil
    import tempfile
    import unittest
    import urllib

    from youtube_dl.utils import encode_data_uri, unescapeHTML
    from youtube_dl.YoutubeDL import YoutubeDL

    base_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 17:15:06.979541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:14.999360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor

    ie = InfoExtractor(
        {'outtmpl': '%(id)s.%(ext)s'},
        downloader=None
    )

    ArchiveOrgIE.suitable.when.called_with(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')\
        .should.return_true()

    ArchiveOrgIE.suitable.when.called_with(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')\
        .should.return_true()


# Generated at 2022-06-12 17:15:15.457703
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:15:16.284685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(ArchiveOrgIE)

# Generated at 2022-06-12 17:15:20.424858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:27.047110
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert str(ie) == 'Archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:28.245385
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() != None

# Generated at 2022-06-12 17:15:32.789654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie

# Generated at 2022-06-12 17:15:41.343200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  """Test ArchiveOrgIE"""

  summary = "This is a summary"
  subject = "This is a subject"
  language = "en"

  metadata = {
    'title': ["Title of video"],
    'description': [summary],
    'subject': [subject],
    'language': [language]
  }

  expected = {
    'title': "Title of video",
    'description': summary,
    'subject': subject,
    'language': language
  }

  info = ArchiveOrgIE._parse_metadata(metadata)
  assert len(info) == len(expected)
  assert info['title'] == expected['title']
  assert info['description'] == expected['description']
  assert info['subject'] == expected['subject']
  assert info['language'] == expected['language']

  # Verify that optional fields are not added


# Generated at 2022-06-12 17:15:42.314889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-12 17:16:04.150331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:10.801510
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:12.160735
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:16:14.721057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:15.494401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    pass

# Generated at 2022-06-12 17:16:19.657388
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for url in [
        "http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"]:
        assert ArchiveOrgIE().suitable(url)
        assert ArchiveOrgIE().extract(url)

# Generated at 2022-06-12 17:16:21.160878
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)

# Generated at 2022-06-12 17:16:30.025646
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test init of ArchiveOrgIE
    ie = ArchiveOrgIE()

    # Test _match_id
    assert ie._match_id('http://test.test/test.test/test.test/test') == None
    assert ie._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?test') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:16:31.079506
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:35.342927
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    module = 'archive.org'
    from .. import YouTubeIE
    from .. import YoutubePlaylistIE
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'
    ie = ArchiveOrgIE()
    assert ie.ie_key() == module
    assert ie.IE_NAME == module
    assert ie.IE_DESC == 'archive.org videos'

# Extracting information using constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:16:57.838535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE('archive.org')
    assert info_extractor.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:17:03.839490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    webpage = ie._download_webpage(
        'http://archive.org/embed/' + "XD300-23_68HighlightsAResearchCntAugHumanIntellect", "")

    playlist = None
    play8 = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    print("play8")
    print(play8)
    if play8:
        attrs = extract_attributes(play8)
        playlist = attrs.get('value')

# Generated at 2022-06-12 17:17:06.071395
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Just use the ArchiveOrgIE constructor to test its code
    """

    IE = ArchiveOrgIE(False)
    assert IE != None

# Generated at 2022-06-12 17:17:08.707310
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #TODO:
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'


# Generated at 2022-06-12 17:17:12.435062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    
    archiveOrgIE = ArchiveOrgIE()
    archiveOrgIE.extract(url)

    # TODO:
    # Test extract on more URLs
    # Test parse_jwplayer_data
    # Test _parse_html5_media_entries
    # Test _real_extract

# Generated at 2022-06-12 17:17:13.748712
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:17:18.161347
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# The following is a realistic example of the URL
	url = 'https://archive.org/details/Cops1922'
	# Constructors require the URL of the file, which is a string
	ArchiveOrgIE(url)

# test_ArchiveOrgIE()

# Generated at 2022-06-12 17:17:19.190786
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-12 17:17:20.873708
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    with pytest.raises(AssertionError):
        ArchiveOrgIE('1')

# Generated at 2022-06-12 17:17:25.019795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE';
    assert ArchiveOrgIE.__doc__ == InfoExtractor.__doc__;
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)';
    assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-12 17:18:13.755048
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    ie = ArchiveOrgIE('http://www.youtube.com/results?search_query=test')
    assert ie.ie_key() == 'Youtube'

# Generated at 2022-06-12 17:18:17.020654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simple unit tests to check constructor of ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:18:28.047126
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._download_webpage('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', '123')
    assert ie._search_regex(r'class=["\']js-play8-playlist[^>]+>', '<div class="js-play8-playlist">', 'play8')
    assert ie._search_regex(r'Play\(\'[^\']+\'\s*,\s*(\[.+\])\s*,\s*{.*?}\)', 'Play(\'123\'  ,  [\'abc\'] , {})', 'jwplayer playlist')
    assert ie._parse_json(r'{"test": 123}', 'test')
    assert ie._parse_jwplayer_data

# Generated at 2022-06-12 17:18:32.677045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check with correct arguments
    ie = ArchiveOrgIE('archive.org', None)
    # Check with wrong arguments
    try:
        ie = ArchiveOrgIE(None, None)
    except TypeError as e:
        assert(isinstance(e, TypeError))

# Generated at 2022-06-12 17:18:34.491389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:18:41.873753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    To test it, we have to create a youtube-dl instance and call the _real_extract method
    """
    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({})
    result = ydl.extract_info(
        'http://www.archive.org/details/test',
        download=False # We just want to extract the info
    )

    assert result['id'] == 'test'

# Generated at 2022-06-12 17:18:44.921682
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE(None)._TESTS[0]['url'] == ArchiveOrgIE._TESTS[0]['url']

# Generated at 2022-06-12 17:18:50.960446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_ie(ArchiveOrgIE)

# Generated at 2022-06-12 17:18:53.971685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:18:55.479455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', {})
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.ie_name() == 'archive.org'

# Generated at 2022-06-12 17:21:11.288757
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE, _VALID_URL
    from .kaltura import KalturaIE
    from .ooyala import OoyalaIE
    from .dailymotion import DailymotionIE
    from .youtube import YoutubeIE

    ie = InfoExtractor(
        _VALID_URL, ArchiveOrgIE.ie_key(), 'archive.org')
    if isinstance(ie, ArchiveOrgIE):
        pass
    elif isinstance(ie, (KalturaIE, OoyalaIE, DailymotionIE, YoutubeIE)):
        pass
    else:
        raise AssertionError(ie)

# Generated at 2022-06-12 17:21:12.372236
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE

    :returns: None
    """
    ArchiveOrgIE().test_extract()

# Generated at 2022-06-12 17:21:12.995001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-12 17:21:18.343073
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.ie_key() == 'archive.org'
    assert archiveOrgIE.ie_desc() == 'archive.org videos'
    assert archiveOrgIE.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert archiveOrgIE.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')
    assert not archiveOrgIE.suitable('https://archive.org/')
    assert not archiveOrgIE.suitable('https://archive.org/download/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-12 17:21:24.544615
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint:disable=redefined-outer-name
    url = "https://archive.org/details/Cops1922"
    # test constructor
    ie = ArchiveOrgIE(url)
    assert ie.url == url
    assert ie.title == "Buster Keaton's \"Cops\" (1922)"
    assert ie.id == "Cops1922"
    assert ie.thumbnail == None

# Generated at 2022-06-12 17:21:28.924474
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:29.446841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ArchiveOrgIE()

# Generated at 2022-06-12 17:21:32.241892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert(ie.IE_NAME != "")
    assert(ie.IE_DESC != "")
    assert(ie._VALID_URL != "")
    assert(ie._TESTS != "")

# Generated at 2022-06-12 17:21:33.311901
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Simple test case to check the constructor of class ArchiveOrgIE"""
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:35.901278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    archiveOrgIE.url_result('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert archiveOrgIE.IE_NAME == 'archive.org'