

# Generated at 2022-06-12 17:14:28.032922
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:14:32.868531
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    id = a._match_id(url)
    assert id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:14:34.815576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == "archive.org"
    assert instance.IE_DESC == "archive.org videos"

# Generated at 2022-06-12 17:14:36.055187
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC

# Generated at 2022-06-12 17:14:40.841755
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = ["https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
                  "http://archive.org/details/Cops1922",
                  "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/",
                  "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"]
    for test_case in test_cases:
        test_extractor = ArchiveOrgIE()
        test_extractor._match_id(test_case)

# Generated at 2022-06-12 17:14:41.311275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:42.119988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:43.288793
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testobj = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:43.937324
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-12 17:14:51.545994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from unittest import TestCase, main
    from youtube_dl.postprocessor import FFmpegExtractAudioPP

    class TestArchiveOrgIE(TestCase):
        def test_constructor(self):
            ie = ArchiveOrgIE()
            self.assertIsInstance(ie, ArchiveOrgIE)
            self.assertFalse(hasattr(ie, 'pp'))

            ie = ArchiveOrgIE(
                downloader=None,
                params={'outtmpl': '%(id)s', 'postprocessors': [FFmpegExtractAudioPP()]})
            self.assertIsInstance(ie.pp, FFmpegExtractAudioPP)

    main()

# Generated at 2022-06-12 17:14:57.797227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE()


# Generated at 2022-06-12 17:15:04.261573
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', {
        'playlist': [{
            'id': 1,
            'sources': [{
                'file': '',
                'type': 'video/mp4',
            }],
        }],
    }, 'archive.org')
    assert ie._type == 'playlist'

    ie = ArchiveOrgIE('archive.org', {
        'sources': [{
            'file': '',
            'type': 'video/mp4',
        }],
    }, 'archive.org')
    assert ie._type == 'video'

# Generated at 2022-06-12 17:15:13.352333
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:15:22.165720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:25.360283
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:28.293361
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:35.851555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:44.012423
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj=ArchiveOrgIE()
    assert obj.ie_name() == 'archive.org'
    assert obj.ie_desc() == 'archive.org videos'
    assert obj.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert obj.valid_url('http://archive.org/details/Cops1922')
    assert obj.valid_url('https://archive.org/embed/ToCatchAPredator17')


# Generated at 2022-06-12 17:15:45.098501
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:46.577261
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchivesOrgIE()
    assert i is not None

# Generated at 2022-06-12 17:15:58.310256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(InfoExtractor())._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:16:04.265037
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert isinstance(ie._TESTS[0], dict)

# Generated at 2022-06-12 17:16:05.670797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "http://archive.org/details/BusterKeatonsCops1922"
    _ = ArchiveOrgIE()._real_extract(url)

# Generated at 2022-06-12 17:16:07.718893
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE.suitable(url)

# Generated at 2022-06-12 17:16:17.413203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # Test to see if its a valid info extractor
    assert(isinstance(testie, InfoExtractor))
    # Test to see if it is associated with the given url
    assert(testie.suitable("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"))
    # Test to see if it is not associated with the given url
    assert(not testie.suitable("https://www.youtube.com/watch?v=OEHsCZ4YvY8"))

# Generated at 2022-06-12 17:16:19.655887
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    assert extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:21.161176
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:30.025688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class UnitTestArchiveOrgIE(ArchiveOrgIE):
        ie_key = 'ArchiveOrg'

# Generated at 2022-06-12 17:16:38.231860
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:40.824468
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #pass
    a = ArchiveOrgIE(InfoExtractor())
    a._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:17:03.987436
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    print("Test ArchiveOrgIE constructor: ", 'pass' if instance else 'fail')


# Generated at 2022-06-12 17:17:06.543621
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE()._real_extract(url)

# Generated at 2022-06-12 17:17:09.799724
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import urlparse
    url = "https://archive.org/details/XD300-23_68"
    aorg = ArchiveOrgIE()
    assert aorg._match_id(url) == 'XD300-23_68'

# Generated at 2022-06-12 17:17:11.532821
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    # TODO: Add more test cases

# Generated at 2022-06-12 17:17:13.548559
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _constructor(ArchiveOrgIE, 'archive.org')

# Generated at 2022-06-12 17:17:17.607552
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        archive_org_ie = ArchiveOrgIE()
    except:
        print("Error: ArchiveOrgIE() failed to call.")
        assert False

    print("ArchiveOrgIE() test complete.")
    assert True


# Generated at 2022-06-12 17:17:22.985283
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Since this test may need a long time, we don't test in test_suite
    ie = ArchiveOrgIE()
    # Test invalid url, should return None
    data = ie.extract('http://www.example.com')
    assert data is None
    # Test valid url, should return an object
    data = ie.extract('http://archive.org/details/Popeye_forPresident')
    assert data['id'] == 'Popeye_forPresident'

# Generated at 2022-06-12 17:17:25.819954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for i in ArchiveOrgIE._TESTS:
        ArchiveOrgIE(i['url'])

# Generated at 2022-06-12 17:17:27.384516
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj


# Generated at 2022-06-12 17:17:28.602298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:18:17.269720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:18:28.628695
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE
    assert isinstance(ArchiveOrgIE, InfoExtractor)
    assert hasattr(ArchiveOrgIE, '_VALID_URL')
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert not ArchiveOrgIE._downloader
    assert hasattr(ArchiveOrgIE, '_TESTS')
    assert isinstance(ArchiveOrgIE._TESTS, list)
    assert (ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert isinstance(ArchiveOrgIE._TESTS, list)

# Generated at 2022-06-12 17:18:33.595312
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:35.414867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:18:36.903100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This test is a unit test for class ArchiveOrgIE()
    ie = ArchiveOrgIE()
    assert 'archive.org' in ie.IE_NAME
    assert 'archive.org' in ie.IE_DESC

# Generated at 2022-06-12 17:18:44.922338
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.valid_url('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert not ie.valid_url('http://youtube.com/watch?v=cX8J_O6S-Lw')


# Generated at 2022-06-12 17:18:45.794350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-12 17:18:47.608999
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('ArchiveOrgIE')
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:18:48.273738
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    m = ArchiveOrgIE()
    assert m != None

# Generated at 2022-06-12 17:18:53.114185
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:21:01.735037
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test of the extraction of the url of the webpage for a media in the webpage."""
    # format: url, expected_url
    urls = [
        (
            "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
            "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
        ),
        (
            "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/",
            "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator"
        )
    ]
    for url_input, url_output in urls:
        input_ie = ArchiveOrgIE

# Generated at 2022-06-12 17:21:09.831237
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  assert ArchiveOrgIE.IE_NAME == 'archive.org'
  assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
  assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:10.263542
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:11.373211
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    iae = ArchiveOrgIE()
    assert (iae.get_testcases() is not None), "Test cases are missing"

# Generated at 2022-06-12 17:21:11.806028
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:12.246541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE(): ArchiveOrgIE()

# Generated at 2022-06-12 17:21:20.273284
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:21:22.875350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj != None

# Generated at 2022-06-12 17:21:25.722633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:21:34.279989
# Unit test for constructor of class ArchiveOrgIE