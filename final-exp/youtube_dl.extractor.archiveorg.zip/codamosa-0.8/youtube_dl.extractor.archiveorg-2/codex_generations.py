

# Generated at 2022-06-12 17:14:23.960107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:14:24.511991
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:26.599286
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
      i = ArchiveOrgIE()
      return 0
    except Exception:
      return 1

# Generated at 2022-06-12 17:14:29.301591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a is not None

# Test for _real_extract method of class ArchiveOrgIE

# Generated at 2022-06-12 17:14:30.271717
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ArchiveOrgIE()

# Generated at 2022-06-12 17:14:35.839441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_info_extractor = ArchiveOrgIE()
    assert test_info_extractor.IE_NAME == 'archive.org'
    assert test_info_extractor.IE_DESC == 'archive.org videos'
    assert test_info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:42.745836
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['ext'] == 'ogg'
   

# Generated at 2022-06-12 17:14:45.218074
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ar = ArchiveOrgIE();
    ar.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect');

# Generated at 2022-06-12 17:14:46.756692
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:14:47.910227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-12 17:15:01.084160
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._match_id("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-12 17:15:08.005851
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert ie._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-12 17:15:08.557608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:16.171331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:20.298933
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao.IE_NAME == 'archive.org'
    assert ao.IE_DESC == 'archive.org videos'
    assert ao._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:21.745394
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.suitable("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-12 17:15:27.777709
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Mocking the jwplayer_data result
    jwplayer_data = {
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }
    # Mocking the metadata dict result

# Generated at 2022-06-12 17:15:30.782596
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test __init__
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'


# Generated at 2022-06-12 17:15:31.320854
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tmp = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:34.716406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.getTotalNumberOfVideo()
    print('Number of videos: %d' % ie.total_number_of_video)

# Generated at 2022-06-12 17:16:06.829464
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import FakeYDL
    # I'm sure this is a valid archive.org URL...
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ret = ArchiveOrgIE()
    # check that ArchiveOrgIE can be constructed
    try:
        ArchiveOrgIE()
    except Exception:
        assert 0, "Could not construct ArchiveOrgIE"
    ret = ArchiveOrgIE().extract(url)
    assert 'url' in ret, "archive.org result lacks expected 'url' key"
    # Check that the direct URL we get is playable by youtube-dl
    assert 0 == FakeYDL().process_ie_result(ret, download=False)
    # Check that the direct URL we get is playable by FFmpeg
    # TODO: Write code to test this

# Generated at 2022-06-12 17:16:12.303751
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:14.230467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:17.673968
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # the following URL is the page to the homepage of archive.org
    url = 'http://archive.org/'
    assert ArchiveOrgIE.suitable(url) == False
    aoie = ArchiveOrgIE()
    aoie.url = url
    assert aoie.suitable() == False
    return aoie


# Generated at 2022-06-12 17:16:28.359493
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test for method archive.common.InfoExtractor.ArchiveOrgIE
    """
    mock_args = {
        'archive_org_id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    }

    # test invalid url
    class InvalidUrlIE(ArchiveOrgIE):
        """ class used for testing invalid url """
        _VALID_URL = r'https?://(?:www\.)?archive\.org/details/invalid'
    ie = InvalidUrlIE(**mock_args)
    try:
        ie.test()
        assert False, 'did not throw exception'
    except:
        pass

    ## test valid url
    class ValidUrlIE(ArchiveOrgIE):
        """ class used for testing valid url """

# Generated at 2022-06-12 17:16:30.339214
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)
    ArchiveOrgIE.suite()
if __name__ == '__main__':
    ArchiveOrgIE.suite()

# Generated at 2022-06-12 17:16:34.046366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:34.863400
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:43.975864
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:16:52.466643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:17:39.231749
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:17:44.425606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    inst.extract_info("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    inst._match_id("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    inst.IE_DESC

# Generated at 2022-06-12 17:17:48.718424
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Unit test for constructor of class ArchiveOrgIE
    '''
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    
    

# Generated at 2022-06-12 17:17:52.443173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for class ArchiveOrgIE"""
    archiveOrg = ArchiveOrgIE()
    archiveOrg.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:17:54.012583
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)


# Generated at 2022-06-12 17:17:55.466503
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie == ArchiveOrgIE()

# Generated at 2022-06-12 17:17:56.659579
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:17:57.181457
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-12 17:18:00.063994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for the constructor defined in this file
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'
    # Test for the constructor defined in common.py
    ie = InfoExtractor(None)
    assert ie.IE_NAME == 'Generic'

# Generated at 2022-06-12 17:18:01.958730
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    return

# Generated at 2022-06-12 17:19:05.091436
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    e = ArchiveOrgIE()
    assert e.IE_NAME == 'archive.org'
    assert e.IE_DESC == 'archive.org videos'
    assert e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:19:05.898277
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    new_ArchiveOrgIE()

# Generated at 2022-06-12 17:19:08.549109
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    ArchiveOrgIE.__init__ method unit test
    """
    # Create instance of ArchiveOrgIE class
    ArchiveOrgIE()

# Generated at 2022-06-12 17:19:10.536648
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-12 17:19:20.344378
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert ie._

# Generated at 2022-06-12 17:19:21.212063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    E = ArchiveOrgIE()

# Generated at 2022-06-12 17:19:22.330954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-12 17:19:27.509322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:19:28.013230
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	pass

# Generated at 2022-06-12 17:19:30.282146
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-12 17:21:50.351985
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable(ArchiveOrgIE._VALID_URL)
    assert not ArchiveOrgIE.suitable('http://youtube.com/watch?v=asdf')



# Generated at 2022-06-12 17:21:52.419295
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_json(
        ie._build_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 1), 1)

# Generated at 2022-06-12 17:21:56.674490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Sample input:
        url = https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/
    '''
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    a = ArchiveOrgIE(url)

# Generated at 2022-06-12 17:21:58.384086
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:22:03.190350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test fail without class attr value
    ie.class_attr = None
    assert 'AttributeError' in str(ie)

    # Test fail if class attr value is not from enum
    ie.class_attr = 'not-from-enum'
    assert 'AttributeError' in str(ie)

# Generated at 2022-06-12 17:22:06.462721
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == (r'https?://(?:www\.)?archive\.org/(?:details|embed)/'
                             r'(?P<id>[^/?#&]+)')

# Generated at 2022-06-12 17:22:07.507920
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:22:18.378547
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    dt = datetime.date.today()
    day = '{:02}'.format(dt.day)
    month = '{:02}'.format(dt.month)
    year = '{:04}'.format(dt.year)
    timestamp = '{}-{}-{}'.format(year, month, day)


# Generated at 2022-06-12 17:22:21.493140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:22:24.044471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'