

# Generated at 2022-06-12 17:14:28.055940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test(test_string):
        ie = ArchiveOrgIE(test_string)

# Generated at 2022-06-12 17:14:29.160412
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE(1, 2)

# Generated at 2022-06-12 17:14:31.479896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie  # Just to make sure the constructor doesn't fail


# Generated at 2022-06-12 17:14:35.433788
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Note: Class ArchiveOrgIE is abstract and needs to be derived from
    class IETest(ArchiveOrgIE):
        _VALID_URL = ArchiveOrgIE._VALID_URL
    ie = IETest()

    assert(ie._real_initialize() is None)


# Generated at 2022-06-12 17:14:39.799071
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Test for _real_extract

# Generated at 2022-06-12 17:14:45.547540
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    # Test that URL is accepted, then extract and return an object with all the
    # information we can get
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert i._VALID_URL.match(url)
    assert i._real_extract(url)

# Generated at 2022-06-12 17:14:52.530514
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import youtube_dl
    except:
        _ = YoutubeDl(params)
    # The test for constructor of YoutubeDl() is already done
    # by the test of class YoutubeDL.
    # In the test for __init__() of ArchiveOrgIE, we just
    # call the constructor of ArchiveOrgIE and check if
    # the IE is successfully created.
    ie = ArchiveOrgIE()
    if ie._downloader is None or ie._downloader.params is None:
        pass
    # The success of the constructor can't be asserted.
    # If the test fails, an exception will be raised.

# Generated at 2022-06-12 17:14:58.787676
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # test parameters here
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # test download_webpage here
    # test _real_extract here
    return ie

# Generated at 2022-06-12 17:14:59.698997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:02.231796
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    print(info.IE_NAME)
    print(info.IE_DESC)
    print(info._VALID_URL)

# Generated at 2022-06-12 17:15:08.907538
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-12 17:15:10.696966
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.name == 'archive.org'
    assert a.description == 'archive.org videos'



# Generated at 2022-06-12 17:15:13.583917
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE().url_result(url)

# Generated at 2022-06-12 17:15:15.581416
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:17.412257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-12 17:15:25.389006
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:31.354383
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Class archives constructor test.
    """
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    from .youtube import YoutubeIE
    from .common import InfoExtractor

    ie = ArchiveOrgIE(InfoExtractor())

    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, ArchiveOrgIE)
    assert not isinstance(ie, YoutubeIE)

# Generated at 2022-06-12 17:15:38.745764
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/Cops1922')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'archive.org'
    assert ie.IE_NAME == 'archive.org'
    # test constructor of new superclass InfoExtractor
    assert ie.extractor_key == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:39.249000
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:40.036778
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:51.619537
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:56.698269
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect", 1)
    assert ArchiveOrgIE("https://archive.org/details/Cops1922", 1)
    assert ArchiveOrgIE("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect", 1)
    assert ArchiveOrgIE("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/", 1)

# Generated at 2022-06-12 17:15:59.305509
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect');

# Generated at 2022-06-12 17:16:03.635754
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i._VALID_URL == '^https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)$'

test_ArchiveOrgIE()

# Generated at 2022-06-12 17:16:07.998875
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 3

# Generated at 2022-06-12 17:16:09.424628
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:16:19.460875
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:16:21.755165
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()._get_information_extractor()
    assert(test == 'ArchiveOrgIE')

# Generated at 2022-06-12 17:16:23.282456
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:16:25.963208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor_test(ArchiveOrgIE, ['https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'])

# Generated at 2022-06-12 17:16:51.300393
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == 'archive.org'
    assert archive_org_ie.IE_DESC == 'archive.org videos'
    assert archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:16:59.429385
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    see http://stackoverflow.com/a/27807214/35070
    """

    archive_ie = ArchiveOrgIE()

    # test _VALID_URL regex
    match = re.match(archive_ie._VALID_URL, 'this is a valid URL')
    assert(match is None)

    match = re.match(archive_ie._VALID_URL, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(match is not None)

    match = re.match(archive_ie._VALID_URL, 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(match is not None)

    # test _real_extract

# Generated at 2022-06-12 17:17:03.988061
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    #"url": "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ie.match_info(r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)') # noqa

# Generated at 2022-06-12 17:17:12.462129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        global ArchiveOrgIE
        ArchiveOrgIE
    except NameError:
        ArchiveOrgIE = None
    if not ArchiveOrgIE:
        import inscriptis
        from .extractor.common import InfoExtractor
        from .downloader.common import FileDownloader
        from .utils import (
            clean_html,
            extract_attributes,
            unified_strdate,
            unified_timestamp,
        )
        from .jsinterp import JSInterpreter
        class ArchiveOrgIE(InfoExtractor):
            IE_NAME = 'archive.org'
            IE_DESC = 'archive.org videos'
            _VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:13.753959
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-12 17:17:14.600266
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:17:17.264599
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:17:21.391106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'



# Generated at 2022-06-12 17:17:23.169799
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-12 17:17:33.429842
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.VIDEO_ADDONS == ['archiveorg']
    assert len(ie._TESTS) == 3

# Generated at 2022-06-12 17:18:31.632242
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:33.311633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org = ArchiveOrgIE()
    assert 'archive.org' == archive_org.IE_NAME

# Generated at 2022-06-12 17:18:36.816409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # all of unit test for ArchiveOrgIE
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:18:38.185818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import test_constructor
    test_constructor(ArchiveOrgIE)

# Generated at 2022-06-12 17:18:40.156328
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check if ArchiveOrgIE(InfoExtractor) constructor is still working
    ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-12 17:18:44.633866
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:45.494496
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:18:47.448702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_youtube_dl import test_ArchiveOrgIE
    test_ArchiveOrgIE(ArchiveOrgIE)

# Generated at 2022-06-12 17:18:49.369222
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org', ie.IE_NAME

# Generated at 2022-06-12 17:19:00.513934
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:21:12.925317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org','archive.org videos','archive.org','archive.org','archive.org')

# Generated at 2022-06-12 17:21:18.274477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_NAME = 'archive.org'
    IE_DESC = 'archive.org videos'
    _VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:19.037603
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:30.390597
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:32.243126
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:21:32.725716
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:21:34.437543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test the constructor
    assert ArchiveOrgIE is not None
    # Test the test harness
    assert test_ArchiveOrgIE is not None

# Generated at 2022-06-12 17:21:35.313792
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:21:39.089576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.__name__ == 'archive.org.ArchiveOrgIE'

# Generated at 2022-06-12 17:21:44.763366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = infoExtractor.construct_ie(InfoExtractor, 'archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'