

# Generated at 2022-06-12 17:14:26.461339
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:29.160996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:14:32.823035
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:36.748867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:14:39.512906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:41.009077
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        archiveorg_ie = ArchiveOrgIE()
        assert archiveorg_ie != ''
    except:
        print('error')
        raise

# Generated at 2022-06-12 17:14:41.816080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_initialize()

# Generated at 2022-06-12 17:14:43.686002
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == "__main__":
        from . import main
        main(ArchiveOrgIE)

# Generated at 2022-06-12 17:14:47.942822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:55.574693
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:15:13.385658
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    exp_url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator'
    archive_org_ie = ArchiveOrgIE()
    assert(archive_org_ie._VALID_URL)
    assert(archive_org_ie._match_id(url))
    assert(archive_org_ie._real_extract(url))
    assert (archive_org_ie._match_id(exp_url))
    assert (archive_org_ie._real_extract(exp_url))

# Generated at 2022-06-12 17:15:16.738528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    transform = lambda x: (x[0].split('/')[-1], x[1])
    klass = type('Obj', (ArchiveOrgIE,), {
        '_VALID_URL': ArchiveOrgIE._VALID_URL,
        '_TESTS': map(transform, ArchiveOrgIE._TESTS)})
    globals()[klass.__name__] = klass

# Generated at 2022-06-12 17:15:24.959295
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    config = {'verbose': False}
    # These URLs are not used in the test
    url_video = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url_playlist = 'https://archive.org/details/Cops1922'
    u = ArchiveOrgIE(config)
    # Test Video
    m = u._match_id(url_video)
    info = u._extract_info(m, url_video)
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # Test Playlist
    m = u._match_id(url_playlist)
    info = u._extract_info(m, url_playlist)

# Generated at 2022-06-12 17:15:34.445970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test 1
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    if ie.ie_key() != 'archive.org':
        print("Constructor of class ArchiveOrgIE failed!")

    # Test 2
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    if ie.ie_key() != 'archive.org':
        print("Constructor of class ArchiveOrgIE failed!")

    # Test 3
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    if ie.ie_key() != 'archive.org':
        print("Constructor of class ArchiveOrgIE failed!")

    # Test 4
    ie = ArchiveOrgIE('archive.org', 'archive.org')

# Generated at 2022-06-12 17:15:38.389192
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE('archive.org')._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
        ArchiveOrgIE('archive.org')._real_extract('https://archive.org/details/Cops1922')
    except:
        raise

# Generated at 2022-06-12 17:15:38.904607
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE(): assert ArchiveOrgIE()

# Generated at 2022-06-12 17:15:41.191125
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.genre_list == []
    assert ie.language_list == []
    assert ie.media_type_list == []
    assert ie.uploader_list == []

# Generated at 2022-06-12 17:15:47.581140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global ArchiveOrgIE
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

    # Test id extraction
    assert ie._match_id('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'

# Generated at 2022-06-12 17:15:50.147366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert(x.IE_NAME == 'archive.org')
    assert(x.IE_DESC == 'archive.org videos')


# Generated at 2022-06-12 17:15:51.367867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:12.160131
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
   assert ArchiveOrgIE != None


# Generated at 2022-06-12 17:16:14.720613
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    inst.suite()

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:16:17.834945
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(test_url)
    assert ie._type == 'archive_org'

# Generated at 2022-06-12 17:16:25.097746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        ('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/', False),
        ('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', True)
    ]
    for url, video in test_cases:
        ie = ArchiveOrgIE()
        result = ie._real_extract(url)
        assert video == 'id' in result

# Generated at 2022-06-12 17:16:26.229547
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-12 17:16:31.808853
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:16:34.768381
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._VIE_NAME == ie.IE_NAME
    assert ie._VIE_DESC == ie.IE_DESC

# Generated at 2022-06-12 17:16:40.603001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("Testing ArchiveOrgIE")
    dirname = os.path.dirname(__file__)
    sys.path.append(dirname)
    video_url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video_id = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ie = ArchiveOrgIE()
    ie.suitable(video_url)
    ie.extract(video_url)

# Generated at 2022-06-12 17:16:41.380652
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:16:42.846494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:17:08.330577
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        print('>> Test constructor of class ArchiveOrgIE')
        ArchiveOrgIE()
        print('ok')
    except Exception as e:
        print('fail', e)


# Generated at 2022-06-12 17:17:11.744193
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:14.800143
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Just a quick test for construction of ArchiveOrgIE instance."""
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-12 17:17:24.333336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    def assert_informat(item, expected):
        if not isinstance(item, dict) or expected[0] not in item or \
            item[expected[0]] != expected[1]:
            raise RuntimeError('%s not in %s' % (expected, item))
    # Test: With a sample video
    # Source: https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    clip = ArchiveOrgIE()._real_extract(url)

    assert clip.get('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'


# Generated at 2022-06-12 17:17:25.824995
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:17:27.020516
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:17:31.181227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:38.840850
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit tests for the ArchiveOrgIE class.
    
    Test cases for the constructor of class ArchiveOrgIE.
    
    """
    # Test a dummy url of an archive.org video
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    
    # Test the case in which the constructor fails
    assert "archive.org" not in ["youtube.com", "dailymotion.com", "archive.org"]
    
    # Test the case in which the constructor succeeds
    assert "archive.org" in ["youtube.com", "dailymotion.com", "archive.org"]
    
    # Test the case in which the constructor fails
    assert "yt.org" not in ["youtube.com", "dailymotion.com", "archive.org"]
    
    #

# Generated at 2022-06-12 17:17:40.079799
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:17:41.365664
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.test()

# Generated at 2022-06-12 17:18:35.684502
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.__version__ == '0.0.1'
    assert ie.__date__ == '2015-12-21'


# Generated at 2022-06-12 17:18:37.705664
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-12 17:18:38.858176
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:18:40.586079
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._TEST.get('title') == 'Cops1922'

# Generated at 2022-06-12 17:18:48.591354
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for constuctor of class ArchiveOrgIE
    # Constructor accepts both http and https url
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.suitable(url) == True
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.suitable(url) == True

    # Test for invalid url

# Generated at 2022-06-12 17:18:54.092737
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-12 17:18:57.428855
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoe = ArchiveOrgIE()
    assert aoe._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:19:07.063931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    my_constructor = ArchiveOrgIE
    # test if constructed correctly
    assert(my_constructor.__name__ == 'ArchiveOrgIE')
    assert(my_constructor.__doc__ == 'archive.org videos')
    assert(my_constructor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-12 17:19:08.915914
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert type(instance) == ArchiveOrgIE

# Generated at 2022-06-12 17:19:09.618960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor('archive.org')

# Generated at 2022-06-12 17:21:16.107027
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();

# Generated at 2022-06-12 17:21:19.798961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """
    extractor = ArchiveOrgIE().from_url("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    assert(extractor.IE_NAME == ArchiveOrgIE.IE_NAME)

# Generated at 2022-06-12 17:21:31.228626
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:36.551263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor and class variables"""
    ie = ArchiveOrgIE()
    assert ie._WORKING == True, 'ArchiveOrgIE is broken'
    assert ie.IE_NAME == 'archive.org', 'Wrong ie name'
    assert ie.IE_DESC == 'archive.org videos', 'Wrong ie description'

# Unit test to test ArchiveOrgIE._real_extract()
# Since it's a unit test, it only bothers to test the functionality of the
# main extract() method, and doesn't check for any exceptions thrown.

# Generated at 2022-06-12 17:21:38.241570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, object)

# Generated at 2022-06-12 17:21:42.292848
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_info_extractor = ArchiveOrgIE()

    assert archive_org_info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive_org_info_extractor.IE_NAME == 'archive.org'
    assert archive_org_info_extractor.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:21:44.194046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:47.734382
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE(None).IE_DESC == ArchiveOrgIE._IE_DESC

# Generated at 2022-06-12 17:21:48.264755
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE()

# Generated at 2022-06-12 17:21:49.106619
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()