

# Generated at 2022-06-12 17:14:23.692159
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:26.097300
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'


# Generated at 2022-06-12 17:14:28.744620
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL


# class ArchiveOrgIE(InfoExtractor)

# Generated at 2022-06-12 17:14:29.737275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-12 17:14:34.602259
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:14:39.676111
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ( ao.IE_NAME == 'archive.org' )
    assert ( ao.IE_DESC == 'archive.org videos' )
    assert ( ao._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' )
    assert( len(ao._TESTS) == 4 )

# Generated at 2022-06-12 17:14:41.762988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert ie.IE_NAME == 'archive.org';
    assert ie.IE_DESC == 'archive.org videos';
# Test url

# Generated at 2022-06-12 17:14:47.259106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # We have to use the constructor and set the URL directly
    # as archive.org will detect the actual URL and return
    # a different page.
    ArchiveOrgIE({}, {'url': "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"})

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:14:55.196413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for construction of ArchiveOrgIE"""
    test = ArchiveOrgIE()
    assert test.IE_NAME == 'archive.org'
    assert test.IE_DESC == 'archive.org videos'
    assert test._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:04.821177
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test_with_url(url):
        ArchiveOrgIE()._real_extract(url)
    # Normal usage
    test_with_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    test_with_url('https://archive.org/details/Cops1922')
    test_with_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    test_with_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    # Not valid url

# Generated at 2022-06-12 17:15:16.651859
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:15:17.602623
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(ArchiveOrgIE())

# Generated at 2022-06-12 17:15:25.519687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import youtube_dl
    import os
    class Opts(object):
        pass
    os.environ['YouTubeDL_TRACE'] = '1'
    opts = Opts()
    opts.quiet = False
    opts.debug = True
    opts.gen_epub = False
    opts.simulate = False
    opts.outtmpl = None
    opts.dump_pages = False
    opts.writeinfojson = True
    opts.writedescription = True
    opts.writeannotations = False
    opts.writeinfojson = True
    opts.writesubtitles = False
    opts.writeautomaticsub = False
    opts.allsubtitles = False
    opts.listsubtitles = False

# Generated at 2022-06-12 17:15:28.493057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test for constructor of class ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:15:29.548104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'ArchiveOrgIE' in globals()

# Generated at 2022-06-12 17:15:30.469453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:32.103834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'



# Generated at 2022-06-12 17:15:40.971179
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL.search('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').groupdict()['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._VALID_URL.search('https://archive.org/details/Cops1922').groupdict()['id'] == 'Cops1922'
    assert ie._VALID_URL.search('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect').groupdict()['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:15:42.430080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    #assert(IE.name == 'ArchiveOrgIE')

# Generated at 2022-06-12 17:15:43.334811
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    newArchiveOrgIE()

# Generated at 2022-06-12 17:16:08.082955
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    print (aorg.IE_DESC)
    print (aorg.IE_NAME)
    print (aorg.VALID_URL)

# test_ArchiveOrgIE()

# Generated at 2022-06-12 17:16:18.829374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.utils import ENDS_WITH_DASH
    from youtube_dl.extractor.archiveorg import ArchiveOrgIE
    result = ArchiveOrgIE()._match_id(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert result == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    result = ArchiveOrgIE()._match_id(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert result == 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    assert ENDS_WITH_DASH.match('the-end-of-the-world')
   

# Generated at 2022-06-12 17:16:23.572160
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # test_ArchiveOrgIE_valid_url()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:16:24.955186
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie,InfoExtractor)

# Generated at 2022-06-12 17:16:27.045470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:28.471419
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC

# Generated at 2022-06-12 17:16:30.132519
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.set_downloader(None)
    assert ie == 'archive.org videos'

# Generated at 2022-06-12 17:16:33.587941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == 'archive.org'
    assert instance.IE_DESC == 'archive.org videos'
    assert instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:38.944829
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Create instance of ArchiveOrgIE
    ie = ArchiveOrgIE()
    result = ie.extract('http://archive.org/details/test/test')
    assert result['title'] == 'test'
    assert result['id'] == 'test'
    assert result['uploader'] == 'Archive Team'
    assert result['upload_date'] == '20121008'
    assert result['timestamp'] == 1349646580
    assert result['description'] == 'test'

# Generated at 2022-06-12 17:16:40.867162
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:17:32.311598
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE.__dict__['_VALID_URL']

# Generated at 2022-06-12 17:17:34.578827
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj

# Generated at 2022-06-12 17:17:35.562484
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE(): 
	ie = ArchiveOrgIE()
	pass

# Generated at 2022-06-12 17:17:37.244447
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    assert ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-12 17:17:41.539467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert_true(len(ie.IE_NAME)>0)
    assert_true(len(ie.IE_DESC)>0)
    assert_true(len(ie._VALID_URL)>0)

# Generated at 2022-06-12 17:17:42.482973
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(ie)

# Generated at 2022-06-12 17:17:50.611981
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert ie._T

# Generated at 2022-06-12 17:17:52.044863
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC

# Generated at 2022-06-12 17:17:56.841687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .youtube import YoutubeIE
    from .common import InfoExtractor
    ie = InfoExtractor("youtube", YoutubeIE.ie_key())
    assert ie.ie_key() == YoutubeIE.ie_key()

    ie = InfoExtractor("archive.org", ie_key=ArchiveOrgIE.ie_key())
    assert ie.ie_key() == ArchiveOrgIE.ie_key()

# Generated at 2022-06-12 17:18:04.467709
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check a valid video
    ie = ArchiveOrgIE().extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    expected_output = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }

# Generated at 2022-06-12 17:20:12.156041
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:20:13.100115
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        pass


# Generated at 2022-06-12 17:20:14.246470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:20:15.589594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    inst.extract(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:20:23.383013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE().suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')
    assert ArchiveOrgIE().suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ArchiveOrgIE().suitable('http://archive.org/')
    assert not ArchiveOrgIE().suitable('http://archive.org/videos/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')

# Generated at 2022-06-12 17:20:28.317548
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Used to test various instances of objects of class ArchiveOrgIE
    """
    test_urls = [
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/',
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/',
        'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    ]

    for url in test_urls:
        archive_org = Archive

# Generated at 2022-06-12 17:20:30.571834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
   from .test_IEs import UnitTestIE
   UnitTestIE('archive.org').test()

# Generated at 2022-06-12 17:20:31.064757
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-12 17:20:33.198876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-12 17:20:36.494569
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-12 17:23:00.196803
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:23:03.015334
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = globals()['ArchiveOrgIE']
    assert class_ is not None
    obj = class_()
    assert obj is not None

# Generated at 2022-06-12 17:23:12.372148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url'], ie._VALID_URL
    ie = ArchiveOrgIE({})
    assert ie._VALID_URL == ie._TESTS[0]['url'], ie._VALID_URL
    ie = ArchiveOrgIE({}, {})
    assert ie._VALID_URL == ie._TESTS[0]['url'], ie._VALID_URL
    ie = ArchiveOrgIE({'params',''}, {})
    assert ie._VALID_URL == ie._TESTS[0]['url'], ie._VALID_URL
    ie = ArchiveOrgIE({'params','','src','','src','','src','','src','','src','','src','','src',''}, {})
    assert ie._VALID_URL

# Generated at 2022-06-12 17:23:16.253299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    # test ArchiveOrgIE object creation
    ArchiveOrgIE("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # test ArchiveOrgIE object creation with an invalid url
    ArchiveOrgIE("http://archive.org/embed/")

# Generated at 2022-06-12 17:23:22.607652
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # unit test case for ArchiveOrgIE
    obj = ArchiveOrgIE()
    print("\nVideo id: "+obj._match_id("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"))

# Generated at 2022-06-12 17:23:24.866003
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test instance of ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-12 17:23:25.672194
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")


# Generated at 2022-06-12 17:23:26.728374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()

# Generated at 2022-06-12 17:23:30.542569
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    assert ie.__name__ == "ArchiveOrgIE"
    assert ie.ie_key() == "ArchiveOrg"
    assert ie.ie_desc() == "archive.org videos"

# Generated at 2022-06-12 17:23:32.345606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    #TODO: add more tests
    #TODO: potentially add a unit test for _real_extract but only after
    #      the scraping algorithms are finalized
    pass