

# Generated at 2022-06-12 17:14:32.396730
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:33.953847
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:39.339057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)

    assert ie != None, 'Constrution of ArchiveOrgIE failed'
    assert ie.id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'Extraction of id failed'
    assert ie.url == url, 'Extraction of url failed'



# Generated at 2022-06-12 17:14:41.121334
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # Test 'real' instance (an ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:14:43.726834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().extract("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/") is not None

# Generated at 2022-06-12 17:14:50.409924
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..jsinterp import JSInterpreter
    from ..extractor import gen_extractors
    from .common import InfoExtractor

    ie = InfoExtractor({})
    for t in gen_extractors(ie, {}):
        print(t)
        e = t(ie)
        if isinstance(e, ArchiveOrgIE):
            break
    assert e.IE_NAME == "ArchiveOrg"
    assert e.IE_DESC == "archive.org videos"
    assert isinstance(e.js_to_json, JSInterpreter)

# Generated at 2022-06-12 17:14:58.523903
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    test._download_webpage = lambda url, video_id: ''
    test._download_json = lambda url, video_id, query: ''
    assert test._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert test._real_extract('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:15:02.738301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:04.149719
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    test.extract("https://archive.org/details/Cops1922")

# Generated at 2022-06-12 17:15:09.868571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:16.228374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie2 = ArchiveOrgIE()
    assert (ie != ie2)

# Generated at 2022-06-12 17:15:24.566706
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )

    video_id = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    webpage = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_url = "https://archive.org/download/%s/%s_archive.mp4" % (video_id, video_id)
    video_size = "7249893"
    video_title = "1968 Demo - FJCC Conference Presentation Reel #1"
    duration = "22"
    description = "Options for augmenting human intellect"

# Generated at 2022-06-12 17:15:25.581175
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-12 17:15:26.351086
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:15:27.471262
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-12 17:15:28.593320
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor(ArchiveOrgIE)

# Generated at 2022-06-12 17:15:29.684946
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().supported_ie

# Generated at 2022-06-12 17:15:30.950590
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(isinstance(ArchiveOrgIE("www.archive.org"), ArchiveOrgIE))

# Generated at 2022-06-12 17:15:32.225285
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()

    assert archiveorg is not None

# Generated at 2022-06-12 17:15:34.171752
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:15:46.724648
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC
    assert ie.IE_NAME

# Generated at 2022-06-12 17:15:50.612399
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # We may want to consider changing the class's constructor to take in a URL as a parameter.
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'


# Generated at 2022-06-12 17:15:52.484400
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE is not None


# Generated at 2022-06-12 17:15:52.995702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:54.074087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This unit test checks if the class ArchiveOrgIE can be instantiated.
    """
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:04.476496
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert i.valid_url('https://archive.org/details/Cops1922')
    assert i.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert i.valid_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    


# Generated at 2022-06-12 17:16:04.995846
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:06.793147
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .archiveorg import ArchiveOrgIE

    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-12 17:16:10.115858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructing an object with an empty argument should raise a TypeError.
    """
    with pytest.raises(TypeError):
        ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:19.657031
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)" 

# Generated at 2022-06-12 17:16:42.307773
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ia = ArchiveOrgIE()
    assert ia._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:48.877006
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert re.match(ie._VALID_URL, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert re.match(ie._VALID_URL, 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not re.match(ie._VALID_URL, 'http://archive.org/search?query=XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:16:51.225562
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=redefined-outer-name
    archive_org_ie = ArchiveOrgIE()
    # Test for constructor
    assert type(archive_org_ie) is ArchiveOrgIE



# Generated at 2022-06-12 17:16:52.761791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    from .common import InfoExtractor

    assert InfoExtractor.ie_key('archive.org') == ArchiveOrgIE

# Generated at 2022-06-12 17:17:00.535938
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert ie._

# Generated at 2022-06-12 17:17:06.544576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    import youtube_dl

    class MyTestCase(unittest.TestCase):

        def test_ArchiveOrgIE(self):
            constructor = youtube_dl.extractor.archiveorg.ArchiveOrgIE
            self.assertEqual(constructor.ie_key(), 'archive.org')
            self.assertEqual(
                constructor.ie_key(), constructor.ie_key_from_url('archive.org'))

    unittest.main(module=__name__, verbosity=2)

# Generated at 2022-06-12 17:17:08.832814
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from mediaFromWeb.tests.test_archive_org import ArchiveOrgTests
    tests = ArchiveOrgTests()
    tests.test_ArchiveOrgIE()

# Generated at 2022-06-12 17:17:14.736080
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:17:24.272040
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:17:30.165620
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import try_get

    class MockIE(InfoExtractor):
        _WORKING = False

        def _real_extract(self, url):
            ie = ArchiveOrgIE(self.ydl)
            return try_get(ie.extract(url), lambda i: i, dict(url=url))

    MockIE(None)._real_extract('http://localhost/'),

# Generated at 2022-06-12 17:18:20.947361
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:18:32.453586
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # A fresh instance
    ie = ArchiveOrgIE()
    assert ie is not None, "Failed to create ArchiveOrgIE instance"
    # A fresh instance and download webpage
    webpage = ie._download_webpage("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect","XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert webpage is not None, "Failed to download webpage"
    # A fresh instance and match the given URL using regular expression
    re_match = ie._match_id("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-12 17:18:33.790374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE


# Generated at 2022-06-12 17:18:45.419897
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:46.689812
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-12 17:18:49.011612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Create class ArchiveOrgIE for unit testing."""
    test_ArchiveOrgIE = ArchiveOrgIE()
    assert test_ArchiveOrgIE.IE_NAME == 'archive.org'
    assert test_ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:18:54.624687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:18:56.119055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()

# Generated at 2022-06-12 17:18:58.908282
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE()
    assert infoExtractor.IE_NAME == 'archive.org'
    assert infoExtractor.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:18:59.491321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:10.347362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    assert result.IE_NAME == 'archive.org'
    assert result.IE_DESC == 'archive.org videos'
    assert result._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:11.231702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:21:11.677142
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:17.154048
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Inspect a specific instance of ArchiveOrgIE
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test the matching of ArchiveOrgIE
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:18.311694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''Just test the constructor of class ArchiveOrgIE'''
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:21.382368
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from .common import InfoExtractor
	def test_constructor():
		ie = InfoExtractor()
		ie = InfoExtractor(params={})
		ie = InfoExtractor(params=None)
		ie = InfoExtractor(params="")
	test_constructor()


# Generated at 2022-06-12 17:21:23.813314
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:21:30.390563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test for video
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'


# Generated at 2022-06-12 17:21:34.989148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# Get the URL for the unit test
	url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	# Create temporary object of class ArchiveOrgIE
	ArchiveOrgIE_obj = ArchiveOrgIE(url)
	# Get the result and print

# Generated at 2022-06-12 17:21:38.812325
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor('archive.org', 'archive.org videos')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'