

# Generated at 2022-06-12 17:14:26.457227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

if __name__ == '__main__':
    test = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:36.977770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # URL with mp4 is the best case for testing
    info = ArchiveOrgIE()._real_extract("http://archive.org/details/Cops1922")
    assert("Buster Keaton's \"Cops\" (1922)" == info["title"])
    assert("md5:43a603fd6c5b4b90d12a96b921212b9c" == info["description"])
    assert("mp4" == info["ext"])

    # URL with non-mp4 is the worst case for testing
    info = ArchiveOrgIE()._real_extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert("1968 Demo - FJCC Conference Presentation Reel #1" == info["title"])

# Generated at 2022-06-12 17:14:38.662109
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        assert False
    assert True


# Generated at 2022-06-12 17:14:39.255203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:39.798343
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:14:40.713441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None


# Generated at 2022-06-12 17:14:45.028142
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:53.911043
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=line-too-long
    test_url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    expected_info_dict = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'ext': 'ogg',
        'release_date': '19681210',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'timestamp': 1268695290,
        'creator': 'SRI International',
        'upload_date': '20100315',
        'uploader': 'SRI International',
    }
   

# Generated at 2022-06-12 17:14:59.706705
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.display_id('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'

# Generated at 2022-06-12 17:15:01.301481
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    args = ['https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect']
    ArchiveOrgIE()._real_initialize(*args)

# Generated at 2022-06-12 17:15:10.733420
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:12.406099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        return False
    return True

# Generated at 2022-06-12 17:15:14.526544
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:19.875736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Initialize a ArchiveOrgIE instance with given url
    ie = ArchiveOrgIE(
        url='http://archive.org/video.php?id=XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test _VALID_URL
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

    # Test _TESTS
    assert len(ie._TESTS) == 2

    # Test _real_extract
    assert ie._real_extract(
        url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test _real_extract when given url is "http://archive.org/embed/

# Generated at 2022-06-12 17:15:20.756068
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:24.499779
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE constructor
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:26.484439
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE.IE_NAME

# Generated at 2022-06-12 17:15:30.432433
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    i = ArchiveOrgIE(url)
    assert i.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:15:32.414220
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("\n***** test_ArchiveOrgIE *****")
    assert ArchiveOrgIE().IE_NAME.startswith("archive.org")

# Generated at 2022-06-12 17:15:33.949679
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC

# Generated at 2022-06-12 17:15:54.402431
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ans = InfoExtractor("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ans.IE_NAME == 'archive.org'
    assert ans.IE_DESC == 'archive.org videos'
    assert ans._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ans._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ans._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-12 17:16:05.191142
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:08.733498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:19.256770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ArchiveOrgIE._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ArchiveOrgIE._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert Archive

# Generated at 2022-06-12 17:16:24.244835
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert isinstance(ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'), ArchiveOrgIE)

# Generated at 2022-06-12 17:16:26.745017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    ArchiveOrgIE(url)

# Generated at 2022-06-12 17:16:30.375105
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE._TESTS[0]['info_dict'] == ArchiveOrgIE._TESTS[1]['info_dict']
	assert ArchiveOrgIE._TESTS[1]['info_dict'] == ArchiveOrgIE._TESTS[2]['info_dict']

# Generated at 2022-06-12 17:16:30.907893
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:34.841430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == "archive.org")
    assert(ie.IE_DESC == "archive.org videos")
    assert(ie._VALID_URL == "https?://(?:www.?)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)")


# Generated at 2022-06-12 17:16:36.094208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:16:58.509493
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:58.986605
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:59.743961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor should take only one argument, the URL
    ArchiveOrgIE('dummy')

# Generated at 2022-06-12 17:17:05.983343
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE()
    o.IE_NAME = 'archive.org'
    o.IE_DESC = 'archive.org videos'
    o.IE_VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    o._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:13.459680
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-12 17:17:17.172386
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Unit test for ArchiveOrgIE. """
    infoextractor_class = InfoExtractor.get_info_extractor(ArchiveOrgIE.IE_NAME)
    assert isinstance(infoextractor_class(), ArchiveOrgIE)

# Generated at 2022-06-12 17:17:19.599522
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-12 17:17:21.514794
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Dummy test to check if the class can be instantiated
    ArchiveOrgIE()


# Generated at 2022-06-12 17:17:24.769056
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == '^https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:26.296804
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(ArchiveOrgIE(None))

# Generated at 2022-06-12 17:18:23.088718
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE(url)

test_ArchiveOrgIE()

# Generated at 2022-06-12 17:18:30.177744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testing constructor of class ArchiveOrgIE
    archiveorg = ArchiveOrgIE()
    print(archiveorg.IE_NAME)
    print(archiveorg.IE_DESC)

    # Testing ArchiveOrgIE._VALID_URL
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    url_regex = archiveorg._VALID_URL
    assert url_regex.match(url)

# Generated at 2022-06-12 17:18:34.609867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:45.672434
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ok = ArchiveOrgIE()
    assert ok.IE_NAME == 'archive.org'
    assert ok.IE_DESC == 'archive.org videos'
    assert ok._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:46.216394
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:18:46.678181
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:18:52.829877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/', None)
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:58.998695
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE
    """
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(None) # without passing a downloader
    info = ie._real_extract(url)
    assert info['creator'] == "SRI International"
    assert info['description'].startswith("<p><br>1968 Demo")

# Generated at 2022-06-12 17:19:06.677937
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290

# Generated at 2022-06-12 17:19:09.077997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        # Check that the constructor of class ArchiveOrgIE exists.
        ArchiveOrgIE('archive.org')
    except AttributeError:
        assert False

# Generated at 2022-06-12 17:21:25.766313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:34.360858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:34.877663
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:35.353424
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:21:36.363864
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:21:36.795114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:43.238154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case 1
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    
    # Test case 2
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    result = ie._real_extract(url)
    assert result['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert result['ext'] == 'ogg'

# Generated at 2022-06-12 17:21:48.463413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-12 17:21:49.343756
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', '/details/id')

# Generated at 2022-06-12 17:21:51.596322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()._real_initialize()
    except Exception as e:
        assert False, 'ArchiveOrgIE._real_initialize failed with error: '+ str(e)