

# Generated at 2022-06-12 17:14:35.800685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(obj._TESTS) == 4
    assert obj._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert obj._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-12 17:14:39.093529
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.__doc__ != "...", "You must replace the test_ArchiveOrgIE stub with a real test."

# Generated at 2022-06-12 17:14:42.879892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = ["http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect", "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"]
    
    for url in test_cases:
        assert ArchiveOrgIE._VALID_URL == ArchiveOrgIE._match_id(url)

# Generated at 2022-06-12 17:14:52.231625
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    # Test for validation of URL:
    match = ie._VALID_URL in ie._downloader.urlopen('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert match == True
    match = ie._VALID_URL in ie._downloader.urlopen('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert match == True
    match = ie._VALID_URL in ie._downloader.urlopen('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')
   

# Generated at 2022-06-12 17:14:54.732713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:15:04.505656
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie_name = ie.IE_NAME
    expected_ie_name = "archive.org"
    ie_desc = ie.IE_DESC
    expected_ie_desc = "archive.org videos"
    valid_url = ie.valid_url("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    expected_valid_url = True
    valid_url_1 = ie.valid_url("https://archive.org/details/Cops1922")
    expected_valid_url_1 = True

# Generated at 2022-06-12 17:15:07.676206
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Pass URL to constructor and make sure no exception is raised
    ArchiveOrgIE(ie._VALID_URL)
    # Pass empty URL to constructor and make sure exception is raised
    ArchiveOrgIE('')

# Generated at 2022-06-12 17:15:13.035442
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = "dummy"
    url = "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    webpage = "dummy"

    test_object = ArchiveOrgIE(x, url);
    assert test_object._match_id(url) == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert test_object._real_extract(url)

# Generated at 2022-06-12 17:15:14.389610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie



# Generated at 2022-06-12 17:15:15.618923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:15:27.419933
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:31.900410
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:36.254522
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-12 17:15:37.486632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE("ArchiveOrgIE", "archive.org videos")

# Generated at 2022-06-12 17:15:39.851775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()

    # Call constructor of InfoExtractor class
    InfoExtractor._call_ie()


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:15:50.068941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[1]['info_dict']['id'] == 'Cops1922'

# Generated at 2022-06-12 17:15:52.911396
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:54.025361
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:15:55.385092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:15:57.111689
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE('ArchiveOrgIE', 'archive.org/')
    return a

# Generated at 2022-06-12 17:16:20.561199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:21.967872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test parameters not yet known.
    # Not run it.
    pass

# Generated at 2022-06-12 17:16:22.708623
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:16:24.657842
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.name == 'archive.org'
    assert ArchiveOrgIE.description == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-12 17:16:28.920159
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	"""Test case for ArchiveOrgIE"""
	test_dict = {'test': 1}
	test_IE = ArchiveOrgIE('test_ArchiveOrgIE.py', test_dict)
	assert test_IE.test_dict == test_dict
	assert test_IE.ie_key() == 'ArchiveOrg'
	assert test_IE.ie_name() == 'ArchiveOrg'



# Generated at 2022-06-12 17:16:33.745653
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    wtt = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._match_id(wtt)

    wtf = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/'
    assert ArchiveOrgIE()._match_id(wtf)

# Generated at 2022-06-12 17:16:34.241125
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:16:38.651139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:16:43.153811
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    module = sys.modules[__name__]
    archiveorg = ArchiveOrgIE(module)
    assert archiveorg._match_id('XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', "Update Constructor of ArchiveOrgIE"

# Generated at 2022-06-12 17:16:45.045831
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:17:11.883816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME == 'archive.org'
    ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL.startswith('https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-12 17:17:12.383199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:17:16.028278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    import pytest
    assert isinstance(ie, ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:17:22.599742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # the testcase of ArchiveOrgIE will be tested in test_get_video_info.
    # the testcase in this file are actually for testing the constructor of
    # class ArchiveOrgIE.
    ie=ArchiveOrgIE()
    assert ie.IE_DESC == "archive.org videos"
    assert ie.IE_NAME == "archive.org"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:23.588051
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-12 17:17:26.040016
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert issubclass(ArchiveOrgIE, InfoExtractor)

# Generated at 2022-06-12 17:17:35.368548
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:17:38.659757
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:39.355914
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:17:40.618889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-12 17:18:36.452624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None


# Generated at 2022-06-12 17:18:37.927745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:18:40.244539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:18:45.312767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert  ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS
    assert ie.ie_key() == 'archiveorg'
    assert ie.name() == 'archive.org videos'
    assert ie.description() == 'archive.org videos'

# Generated at 2022-06-12 17:18:51.203755
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    assert aorg.IE_NAME == 'archive.org'
    # Test the _VALID_URL regular expression

# Generated at 2022-06-12 17:18:52.919850
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:19:03.221975
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj.IE_DESC == 'archive.org videos'
    assert bool(obj._VALID_URL.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')) == True
    assert bool(obj._VALID_URL.match('https://archive.org/details/Cops1922')) == True
    assert bool(obj._VALID_URL.match('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')) == True

# Generated at 2022-06-12 17:19:10.334391
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = ie._download_webpage(url, 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    playlist = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    attrs = extract_attributes(playlist)
    playlist_string = attrs.get('value')

# Generated at 2022-06-12 17:19:11.775937
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-12 17:19:13.026409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME =='archive.org'

# Generated at 2022-06-12 17:21:34.141765
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    ie = ArchiveOrgIE(ie=None)
    assert ie.IE_NAME == ""
    assert ie.IE_DESC == ""
    assert ie._VALID_URL == ""

# Generated at 2022-06-12 17:21:40.933931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }

# Generated at 2022-06-12 17:21:46.097315
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = ArchiveOrgIE
    instance_ = class_('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert instance_.IE_NAME == 'archive.org'
    assert instance_.IE_DESC == 'archive.org videos'
    assert instance_._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:48.906019
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("ArchiveOrg").IE_NAME == 'archive.org'
    assert ArchiveOrgIE("ArchiveOrg").IE_DESC == 'archive.org videos'


# Generated at 2022-06-12 17:21:52.745142
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE."""
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:53.503945
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org videos')

# Generated at 2022-06-12 17:21:56.239626
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie2 = ArchiveOrgIE()
    ie3 = ArchiveOrgIE()
    # See [1] for test cases for ArchiveOrgIE
    # [1] http://archive.org/details/ImTryingToBreakYourHeart
    assert ie == ie2
    assert ie != ie3

# Generated at 2022-06-12 17:21:57.231608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE()

# Generated at 2022-06-12 17:21:58.235296
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:22:03.862428
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test object creation
    ie = ArchiveOrgIE()
    # test type of instance
    assert isinstance(ie, ArchiveOrgIE)
    #test methods of object
    assert callable(getattr(ie, '_real_extract', None))
    assert callable(getattr(ie, '_parse_jwplayer_data', None))
    assert callable(getattr(ie, '_parse_html5_media_entries', None))