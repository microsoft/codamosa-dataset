

# Generated at 2022-06-12 17:14:28.801467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.url_regex() == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:30.568485
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())._default_search_title('Cops1922')

# Generated at 2022-06-12 17:14:34.384289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """

    """
    igrab = ArchiveOrgIE()
    try:
        igrab._constructor()
        print("Unit test for constructor of class ArchiveOrgIE was successful.")
    except:
        print("Unit test for constructor of class ArchiveOrgIE failed.")



# Generated at 2022-06-12 17:14:35.309627
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:43.466285
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Encoding is required from Python 3.5.0
    # TODO make this test work on Python 3.4 too
    import sys
    if sys.version_info >= (3, 5, 0):
        tst = globals()["test_ArchiveOrgIE"]
        archive_org_IE = ArchiveOrgIE()
        assert archive_org_IE.IE_NAME == 'archive.org'
        assert archive_org_IE.IE_DESC == 'archive.org videos'
        assert archive_org_IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:44.440547
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:53.453690
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:14:54.496013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-12 17:14:58.435104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE

    ie = InfoExtractor.for_site('archive.org')
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-12 17:14:59.699978
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL

# Generated at 2022-06-12 17:15:15.657771
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from . import rtmp
	from . import smbc
	from . import vimeo
	from . import youtu

	ArchiveOrgIE()
	rtmp.RtmpIE()
	smbc.RealMediaIE()
	vimeo.VimeoIE()
	youtu.YoutubeIE()
	youtu.YoutubePlaylistIE()
	youtu.YoutubeIE()

# Generated at 2022-06-12 17:15:16.526103
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:20.002046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = InfoExtractor()
    ie.add_info_extractor(ArchiveOrgIE())
    info = ie.extract('https://archive.org/details/Cops1922')
    assert info.get('title') == 'Buster Keaton\'s "Cops" (1922)'

# Generated at 2022-06-12 17:15:23.254342
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Check if the class constructor works correctly
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'
    assert ie.ie_params() == {'username': None, 'password': None}
    assert ie.ie_info() == {'title': ie.ie_name(), 'id': ie.ie_key()}

# Generated at 2022-06-12 17:15:31.860477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    # Create a mock object for input
    class MockUrl(object):
        def __init__(self, url):
            self.url = url
    mockurl = MockUrl("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # Execute constructor
    aorg.extract(mockurl)
    # Check the result
    assert(aorg.ie_key() == 'ArchiveOrg')
    assert(aorg.ie_name() == 'archive.org')
    assert(aorg.ie_description() == 'archive.org videos')

# Generated at 2022-06-12 17:15:34.851398
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    assert info.ie_key() == 'archive.org'
    assert info.ie_desc() == 'archive.org videos'


# Generated at 2022-06-12 17:15:35.986960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:37.644671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:15:46.249738
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:50.527750
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    return True

# Generated at 2022-06-12 17:16:06.099635
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(test_url)
    assert ie.url == test_url
    assert ie.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:16:07.203845
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None


# Generated at 2022-06-12 17:16:08.309278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:11.421445
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    input = 'https://archive.org/details/FunnyCatsVideosCompilation'
    ie = ArchiveOrgIE()
    ie.match(input)

# Generated at 2022-06-12 17:16:15.737514
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    InfoExtractor._downloader = None
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:17.213434
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.ie_key() == 'archive.org')


# Generated at 2022-06-12 17:16:28.180124
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # unit test for ArchiveOrgIE extract function

# Generated at 2022-06-12 17:16:36.164282
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie.valid_url.match('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.valid_url.match('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.valid_url.match('https://archive.org/')
    assert not ie.valid_url.match('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:16:41.939984
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check the type of returned object
    ie = ArchiveOrgIE('http://archive.org', 'Archive.org videos')
    assert type(ie) == ArchiveOrgIE
    # check IE_NAME
    assert ie.IE_NAME == 'archive.org'
    # check if _VALID_URL is correct
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:16:47.358958
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    mocker = Mocker()
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', None)
    assert ie.url == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:17:21.558993
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Initialize the class
    ie = ArchiveOrgIE()

    # Extract info from the URL and print it
    #url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    url = 'https://archive.org/details/EssereLInnocentiSubtitled'
    url = 'https://archive.org/details/TheBigShort15'
    url = 'https://archive.org/details/TutorialCursodePythonEnMenosdeUnaHora'
    print(ie.extract(url))

# Generated at 2022-06-12 17:17:22.718157
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert type(ie) == ArchiveOrgIE

# Generated at 2022-06-12 17:17:27.289931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract("http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    assert(info['title'] == 'To Catch a Predator S8 E26')

# Generated at 2022-06-12 17:17:28.214280
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    pass

# Generated at 2022-06-12 17:17:34.662890
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == '__main__':
        url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
        video = ArchiveOrgIE()._real_extract(url)

# Generated at 2022-06-12 17:17:35.473887
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:17:36.358297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:17:39.675130
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:40.623430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ArchiveOrgIE()

# Generated at 2022-06-12 17:17:49.059359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:45.453183
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.ie_desc() == 'archive.org videos'

# Function called by pytest to test __main__.py for import errors.

# Generated at 2022-06-12 17:18:45.986877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:18:46.702355
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:18:58.765505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.url == 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url']

# Generated at 2022-06-12 17:19:08.741086
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    from ..extractor import gen_extractors
    extractors = gen_extractors()
    InfoExtractor.extractors.append(
        gen_extractors()
    )
    #search youtube_dl's extractors
    assert ArchiveOrgIE('archive.org') in extractors
    assert ArchiveOrgIE('archive.org') not in InfoExtractor.extractors
    #search my added extractors
    InfoExtractor.extractors.append(
        gen_extractors(os.path.dirname(__file__))
    )
    assert ArchiveOrgIE('archive.org') in extractors

# Generated at 2022-06-12 17:19:10.100688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-12 17:19:11.144265
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(object())

# Generated at 2022-06-12 17:19:12.040603
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testObj = ArchiveOrgIE()

# Generated at 2022-06-12 17:19:12.915728
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:19:18.201738
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE with a particular url
    assert 'archive.org' in ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert 'archive.org' in ArchiveOrgIE()._real_extract('https://archive.org/details/Cops1922')


# Generated at 2022-06-12 17:21:31.264424
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:21:31.740554
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-12 17:21:35.062825
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Test ArchiveOrgIE._real_extract( )
test_ArchiveOrgIE._real_extract = ArchiveOrgIE._real_extract

# Generated at 2022-06-12 17:21:36.066185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:21:37.538618
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_archive_org = ArchiveOrgIE()
    assert isinstance(ie_archive_org, InfoExtractor)


# Generated at 2022-06-12 17:21:43.780536
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.suitable(None) is False
    assert ie.working(None) is False
    assert ie._build_url_result(None) is None
    assert ie.url_result(None) is None
    assert ie._extract_id(None) is None
    assert ie._real_extract(None) is None
    assert ie._real_initialize() is None
    assert ie._html_search_meta(None, None, None) is None
    assert ie._html_search_regex(None, None, None, None) is None
    assert ie._parse_jwplayer_data(None, None) is None
    assert ie._parse_html5_

# Generated at 2022-06-12 17:21:46.954583
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:21:47.978632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ = ArchiveOrgIE(None)

# Generated at 2022-06-12 17:21:51.857235
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, 'IE_DESC')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-12 17:21:53.443392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_instance = ArchiveOrgIE()
    return test_instance