

# Generated at 2022-06-12 17:14:28.001534
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:14:29.451141
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-12 17:14:30.810120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:32.355404
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check ArchiveOrgIE.__init__() is not None
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:34.635007
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	a = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:36.144166
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tester = InfoExtractor(params={})
    assert tester._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:14:39.250818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    matches = ie._VALID_URL.findall(url)
    assert len(matches) == 1
    assert matches[0] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:14:39.888139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-12 17:14:43.296196
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:14:44.304185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:04.338197
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest

    class ArchiveOrgIETest(unittest.TestCase):
        def setUp(self):
            self.ie = ArchiveOrgIE()

        def test_constructor(self):
            self.assertTrue(hasattr(self.ie, '_VALID_URL'))
            self.assertTrue(hasattr(self.ie, '_TESTS'))
            self.assertTrue(hasattr(self.ie, 'IE_NAME'))
            self.assertTrue(hasattr(self.ie, 'IE_DESC'))

        def test_working(self):
            self.assertEqual(
                ArchiveOrgIE._WORKING,
                True)
    unittest.main(verbosity=2)


# Generated at 2022-06-12 17:15:13.354462
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Set an archive.org cookie to simulate log in
    from os.path import join as path_join
    from .common import temp_filename
    from .extractor._cookie_jar import MozillaCookieJar
    path = path_join(temp_filename(create=False), 'cookies.txt')
    with MozillaCookieJar(path, None) as cj:
        cj.set_cookie(
            None, 'logged-in-user', 'USERNAME', None, False, 'archive.org',
            False, False, '/', True, False, None, None, None, False)
        cj.save(ignore_expires=True)
    try:
        ie = ArchiveOrgIE(path)
        assert ie.cookiejar is not None
    finally:
        import os

# Generated at 2022-06-12 17:15:13.799206
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:14.731257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('http://archive.org')

# Generated at 2022-06-12 17:15:15.928099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-12 17:15:17.089831
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-12 17:15:17.648856
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:15:18.189558
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert True

# Generated at 2022-06-12 17:15:20.632612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:21.636611
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:34.299308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == ArchiveOrgIE.IE_NAME

# Generated at 2022-06-12 17:15:35.332437
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor of class ArchiveOrgIE.
    """
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:42.704134
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Test for module ArchiveOrgIE
# Required:
import datetime
import time

# These are the other parameters you can pass
# to the constructor of module ArchiveOrgIE
# extractor_key=None, downloader=None, downloader_params={}, ie=None, ie_key=None, force_player=None
test = ArchiveOrgIE(extractor_key=None, downloader=None, downloader_params={}, ie=None, ie_key=None, force_player=None)

# Set the test values for the variables
# Required:

# Test for _real_extract() of class ArchiveOrgIE
# Test for _real_extract() of class ArchiveOrgIE

# Generated at 2022-06-12 17:15:45.763982
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This is the only static method in ArchiveOrgIE
    ArchiveOrgIE.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:15:47.581256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    assert(aorg.IE_DESC == 'archive.org videos')

# Generated at 2022-06-12 17:15:50.483059
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    my_archiveorg = ArchiveOrgIE()
    assert my_archiveorg.extract(
        "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-12 17:15:53.650098
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert isinstance(ie._VALID_URL, type(re.compile('')))

# Generated at 2022-06-12 17:16:00.104549
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import _TEST_ARCHIVEORG_URL

    ao = ArchiveOrgIE()
    assert ao.IE_NAME == "archive.org"
    assert ao.IE_DESC == "archive.org videos"
    assert ao._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:16:04.621786
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_ie = InfoExtractor.ie_key_map['archive.org']()._real_initialize()
    archive_org_ie.http_headers = {'Cookie': 'logged-in-user=yes'}
    archive_org_ie._download_webpage = lambda *args: 'webpage'
    archive_org_ie._parse_jwplayer_data = lambda *args: {'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'}

# Generated at 2022-06-12 17:16:05.369367
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-12 17:16:34.841424
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	import logging
	import json
	from contextlib import closing
	from urllib2 import urlopen
	from urllib2 import Request
	from urllib2 import HTTPError
	from urllib2 import URLError

	logging.basicConfig(format='%(asctime)s %(levelname)s %(message)s',
						level=logging.INFO)

	archive = ArchiveOrgIE()
	
	url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	result = archive.extract(url)
	
	logging.info('%s',result)
	
	



# Generated at 2022-06-12 17:16:36.407001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:40.521802
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:41.073517
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:42.737830
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:48.911931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

if __name__ == '__main__':
    import unittest, sys
    from . import utils
    test_classes = [
        test_ArchiveOrgIE,
    ]
    suite = unittest.TestSuite(map(unittest.TestLoader().loadTestsFromTestCase, test_classes))
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if not result.wasSuccessful():
        sys.exit(1)

# Generated at 2022-06-12 17:16:55.851098
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for a non playlist video
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    with open('archiveorg_result.json') as f:
        expected = json.load(f)
    assert(expected == ie.result)

    # Test for video with playlist
    ie = ArchiveOrgIE('https://archive.org/details/10X_A_Ride_Through_The_Solar_Systems_and_Galaxies')
    with open('archiveorg_result2.json') as f:
        expected = json.load(f)
    assert(expected == ie.result)

# Generated at 2022-06-12 17:17:00.781758
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:10.178503
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['ext'] == 'ogg'

# Generated at 2022-06-12 17:17:12.004495
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)


# Generated at 2022-06-12 17:18:04.728570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    data = ie.extract(url)
    assert data['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:18:14.477502
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        (
            "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
            "/details", "embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        ),
        (
            "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
            "/embed", "embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        ),
    ]
    for url, url_middle, url_end in test_cases:
        ao = ArchiveOrgIE(url)

# Generated at 2022-06-12 17:18:18.174262
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj._VALID_URL is not None
    assert obj.IE_NAME is not None
    assert obj.IE_DESC is not None


# Generated at 2022-06-12 17:18:19.615707
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'id')._real_extract()

# Generated at 2022-06-12 17:18:23.956967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', {})
    assert ie.ie_key() == 'archive.org'

    with pytest.raises(AssertionError):
        ie = ArchiveOrgIE('archive.org', {})
        ie.suitable('archive.org')

# Generated at 2022-06-12 17:18:24.888666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:18:26.589936
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testing constructor of ArchiveOrgIE
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:18:36.355119
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.description == 'archive.org videos'
    assert x.name == 'archive.org'
    assert x.ie_key() == 'archive.org'
    assert x.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert x.valid_url('https://archive.org/details/Cops1922')
    assert x.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert x.valid_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-12 17:18:37.833459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except Exception as e:
        raise e

# Generated at 2022-06-12 17:18:45.983426
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._download_webpage == ie._download_webpage
    assert ie._match_id == ie._match_id
    assert ie._search_regex == ie._search_regex
    assert ie._parse_json == ie._parse_json
    assert ie._parse_jwplayer_data == ie._parse_jwplayer_data
    assert ie._parse_html5_media_entries == ie._parse_html5_media_entries
    assert ie._real_extract == ie._real_extract

# Generated at 2022-06-12 17:21:01.737371
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This test passes only if the constructor of class ArchiveOrgIE has been called.
    return True

# Generated at 2022-06-12 17:21:06.808974
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.ie_description() == 'archive.org videos'


# Generated at 2022-06-12 17:21:08.554868
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE."""
    s = "__main__"
    a = ArchiveOrgIE()
    # Ensure that constructor will not fail
    assert a is not None

# Generated at 2022-06-12 17:21:11.089496
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._name == 'archive.org'
    assert ie._description == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:12.426324
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ArchiveOrgIE = ArchiveOrgIE(InfoExtractor())

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:21:13.047698
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    return ie

# Generated at 2022-06-12 17:21:14.214536
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('')

# Generated at 2022-06-12 17:21:14.703267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:17.561128
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-12 17:21:18.678600
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    im = ArchiveOrgIE()
    im._match_id(im._VALID_URL)