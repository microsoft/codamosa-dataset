

# Generated at 2022-06-12 17:14:25.725048
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._TESTS is not None

# Generated at 2022-06-12 17:14:36.477095
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:14:39.555729
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # We'll test by passing the url to constructor of class ArchiveOrgIE
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ArchiveOrgIE(url)


# Generated at 2022-06-12 17:14:44.067495
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4


# Generated at 2022-06-12 17:14:45.809215
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:14:46.947245
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")

# Generated at 2022-06-12 17:14:49.065044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Nothing special to be done here as all attributes have been tested
    # in __init__
    pass


# Generated at 2022-06-12 17:14:49.614616
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:14:55.125792
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-12 17:14:56.955280
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:15:09.296033
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #TODO: Better way to test constructor
    ArchiveOrgIE(1)

# Generated at 2022-06-12 17:15:11.772512
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	info = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:12.409318
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor

# Generated at 2022-06-12 17:15:13.516969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:15:22.277734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    assert t.test_valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', '8af1d4cf447933ed3c7f4871162602db')
    assert t.test_valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/', '8af1d4cf447933ed3c7f4871162602db')
    assert t.test_valid_url('https://archive.org/details/Cops1922', '0869000b4ce265e8ca62738b336b268a')

# Generated at 2022-06-12 17:15:27.233198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    Test.assertTrue(hasattr(ArchiveOrgIE, '_download_webpage'))
    Test.assertTrue(hasattr(ArchiveOrgIE, '_download_json'))
    Test.assertTrue(hasattr(ArchiveOrgIE, '_real_extract'))
    Test.assertTrue(hasattr(ArchiveOrgIE, 'IE_NAME'))
    Test.assertTrue(hasattr(ArchiveOrgIE, 'IE_DESC'))
    Test.assertTrue(hasattr(ArchiveOrgIE, '_VALID_URL'))
    Test.assertTrue(hasattr(ArchiveOrgIE, '_TESTS'))

# Generated at 2022-06-12 17:15:35.410515
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-12 17:15:37.857204
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = ArchiveOrgIE()
    assert class_.IE_NAME == "archive.org"
    assert class_.IE_DESC == "archive.org videos"

# Generated at 2022-06-12 17:15:39.016771
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_raises(TypeError, lambda: ArchiveOrgIE())

# Generated at 2022-06-12 17:15:48.903202
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:16:13.367387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("https://archive.org")

# Generated at 2022-06-12 17:16:13.975390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:21.706717
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert(ie.IE_NAME == 'archive.org');
    assert(ie.IE_DESC == 'archive.org videos');
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)');

# Generated at 2022-06-12 17:16:25.188281
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        print("Unit test for constructor of class ArchiveOrgIE passed\n")
    except Exception as e:
        print(e)
        print("Unit test for constructor of class ArchiveOrgIE failed\n")


# Generated at 2022-06-12 17:16:30.004355
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:37.405880
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    if instance.IE_NAME != 'archive.org':
        raise AssertionError('expected "archive.org" as IE_NAME')
    if instance.IE_DESC != 'archive.org videos':
        raise AssertionError('expected "archive.org videos" as IE_DESC')
    if instance._VALID_URL != r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)':
        raise AssertionError('expected "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)" as VALID_URL')

# Generated at 2022-06-12 17:16:44.955713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.get_info_extractor('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.get_info_extractor('http://archive.org/details/Cops1922')
    assert ie.get_info_extractor('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.get_info_extractor('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-12 17:16:53.195816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:55.014017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE constructor
    (test_class, _) = globals().items()[0]
    assert test_class == "IE_NAME"

# Generated at 2022-06-12 17:16:58.029275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info = ArchiveOrgIE()._real_extract(url)
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-12 17:17:47.295013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
   ArchiveOrgIE

# Generated at 2022-06-12 17:17:48.319628
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_extractor import TestExtractor
    TestExtractor(ArchiveOrgIE)

# Generated at 2022-06-12 17:17:51.716858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert str(ie) == '<ArchiveOrgIE>'

# Unit test to check the checking of return value of method _real_extract

# Generated at 2022-06-12 17:18:00.306347
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    cls = globals()['ArchiveOrgIE']
    ie = cls()
    assert ie.suitable('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie.suitable('http://archive.org/embed/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert not ie.suitable('http://archive.org/about/')
    assert not ie.suitable('http://archive.org/')
    assert not ie.suitable('http://archive.org/#details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-12 17:18:09.510087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# initialization
	video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	url = 'http://archive.org/details/%s' % video_id

	archiveOrgIE = ArchiveOrgIE()
	webpage = archiveOrgIE._download_webpage(
            'http://archive.org/embed/' + video_id, video_id)

	playlist = None
	play8 = archiveOrgIE._search_regex(
            r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
            'playlist', default=None)
	if play8:
		attrs = extract_attributes(play8)
		playlist = attrs.get('value')

# Generated at 2022-06-12 17:18:10.746641
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-12 17:18:12.854808
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org" # must be equal to IE_NAME
    assert ie.IE_DESC == "archive.org videos" # must be equal to IE_DESC

# Generated at 2022-06-12 17:18:14.392995
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-12 17:18:16.922527
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:18:27.949782
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'ArchiveOrg'
    assert ie.IE_DESC == 'Videos from Archive.org'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:19:24.430362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie
    assert_raises(Exception, ie, 'test')

# Generated at 2022-06-12 17:19:26.528994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    f = ArchiveOrgIE()
    assert f.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:19:28.834194
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE()._real_extract(test_url)

# Generated at 2022-06-12 17:19:31.121742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:19:37.755661
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    To run this test, you need pytest
    https://pypi.python.org/pypi/pytest
    """
    import unittest
    from .test_common import TestCommon
    class TestArchiveOrgIE(unittest.TestCase, TestCommon):
        def setUp(self):
            self.class_name = "ArchiveOrgIE"
            self.instance = ArchiveOrgIE()

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-12 17:19:42.501389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "ArchiveOrgIE"
    assert ie.IE_DESC == "ArchiveOrg videos"
    assert ie._VALID_URL == "(?i)https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-12 17:19:45.790232
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of class InfoExtractor should be called
    infoExtractor = InfoExtractor()
    # Constructor of class ArchiveOrgIE should be called
    ArchiveOrgIE(infoExtractor)

# Generated at 2022-06-12 17:19:51.338351
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archive.org", "archive.org videos")
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')


# Generated at 2022-06-12 17:19:52.298077
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_initialize()
    return ie

# Generated at 2022-06-12 17:19:53.969918
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import archiveorg
    assert archiveorg.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:22:21.582696
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert archive.IE_NAME == 'archive.org'
    assert archive.IE_DESC == 'archive.org videos'
    assert archive._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:22:22.777419
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:22:31.091160
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:22:36.994040
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == "archive.org"
    assert archive_org_ie.IE_DESC == "archive.org videos"
    assert archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
# Unit test over


# Generated at 2022-06-12 17:22:44.385189
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:22:48.539172
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Construct an instance of ArchiveOrgIE and call test_video_id()."""
    ArchiveOrgIE().test_video_id('XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:22:50.036634
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	print(ArchiveOrgIE.__doc__)
	print(InfoExtractor.__doc__)


# Generated at 2022-06-12 17:22:50.880689
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE('https://archive.org')
	print(ie)

# Generated at 2022-06-12 17:22:51.890726
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(test_ArchiveOrgIE)
    except:
        return False
    return True

# Generated at 2022-06-12 17:22:53.432888
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.from_url(r'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') is not None

