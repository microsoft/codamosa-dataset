

# Generated at 2022-06-12 17:14:28.061720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.name == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor.IE_NAME == 'archive.org'
    assert len(info_extractor._TESTS) > 0

# Generated at 2022-06-12 17:14:33.616012
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.extractor.archiveorg import ArchiveOrgIE

    ydl = YoutubeDL({'forcejson': True})
    for t in ArchiveOrgIE._TESTS:
        e = ArchiveOrgIE(ydl, t['url'])
        assert e.ie_key() == ArchiveOrgIE.ie_key()

# Generated at 2022-06-12 17:14:34.629432
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    return

# Generated at 2022-06-12 17:14:39.092929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert len(ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')) > 0
    assert len(ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')) > 0

# Generated at 2022-06-12 17:14:39.490373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-12 17:14:41.236632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert str(a)=='<class ArchiveOrgIE at 0x7f24d2b75300>'

# Generated at 2022-06-12 17:14:46.468138
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoIE = ArchiveOrgIE("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert aoIE.url == "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert aoIE.ie_key() == 'archive.org:XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert aoIE.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert aoIE.video_url == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:14:47.896931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Constructor test
    '''
    return ArchiveOrgIE()

# Generated at 2022-06-12 17:14:55.549815
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ArchiveOrgIE.suitable('https://archive.org/details/NBC_News_1984-11-06_15-20_NIC_NOV_84?q=%22NIC+NOV+84%22')

# Generated at 2022-06-12 17:14:57.364489
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()
    return True

# Generated at 2022-06-12 17:15:04.682032
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  a = ArchiveOrgIE()
  assert a.IE_NAME == 'archive.org'
  assert a.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:05.878231
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'ArchiveOrgIE')

# Generated at 2022-06-12 17:15:07.676575
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testIE = ArchiveOrgIE()
    assert testIE.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:15:10.252416
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    return

# Generated at 2022-06-12 17:15:19.534891
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE constructor
    """
    unsupported_urls = ['https://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/']
    ies = [ArchiveOrgIE()]
    for url in unsupported_urls:
        content = 'main_content_area'
        for ie in ies:
            if ie.suitable(url):
                ie.download(url)
                ie = ie.result
                assert ie[0]
                assert ie[1]
                assert ie[2]
                assert ie[3]
                print('Successfully test constructor of ArchiveOrgIE for url: ' + url)
    print('Successfully test constructor of ArchiveOrgIE for all urls')

# Generated at 2022-06-12 17:15:20.481342
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    if __name__ == '__main__':
        test_ArchiveOrgIE()

# Generated at 2022-06-12 17:15:20.882436
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:25.715681
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:30.225066
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of class InfoExtractor
    ie = InfoExtractor('archive.org', True, "archive.org")
    assert ie.ie_key() == 'archive.org'
    assert ie.working == True
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-12 17:15:30.756256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:42.472732
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # No assertion
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:47.581969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id('http://archive.org/details/Cops1922') == 'Cops1922'

# Generated at 2022-06-12 17:15:52.134689
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:52.988264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()

# Generated at 2022-06-12 17:15:53.710868
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert(ie)

# Generated at 2022-06-12 17:15:55.127026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t1 = ArchiveOrgIE()

    # Test that get_id is not None
    assert t1.get_id() is not None

    # Test that get_version is not None
    assert t1.get_version() is not None

# Generated at 2022-06-12 17:15:56.698371
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    # Test instantiation of ArchiveOrgIE
    assert result

# Generated at 2022-06-12 17:15:58.824575
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # testing constructor ArchiveOrgIE
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:15:59.448084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()()

# Generated at 2022-06-12 17:16:00.611451
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ieObj = ArchiveOrgIE()

# Generated at 2022-06-12 17:16:24.390325
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-12 17:16:32.513555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/Cops1922')
    assert ie._match_id('http://archive.org/details/Cops1922') == 'Cops1922'
    assert ie._match_id('https://archive.org/embed/Cops1922') == 'Cops1922'
    assert ie._match_id('http://archive.org/details/Cops1922/') == 'Cops1922'
    assert ie._match_id('http://archive.org/details/Cops1922/asdf') == 'Cops1922'
    assert ie._match_id('http://archive.org/details/Cops1922/?aa=bb') == 'Cops1922'

# Generated at 2022-06-12 17:16:34.164033
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:34.681561
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:38.775402
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:42.222527
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    archive_org= InfoExtractor('archive.org')

    if archive_org.suitable(url='https://archive.org/details/Cops1922'):
        assert archive_org.IE_NAME == 'archive.org'



# Generated at 2022-06-12 17:16:50.973252
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Ensure that the class is set up correctly
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.suitable(None) is False
    assert ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Test for parsing of an example URL
    ie.parse('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:16:52.425044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.ie_key() == 'archive.org'

# Generated at 2022-06-12 17:16:53.667110
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:59.194252
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archiveorg_ie = ArchiveOrgIE()
    assert archiveorg_ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert archiveorg_ie.ie_key() == ArchiveOrgIE.ie_key()
    assert archiveorg_ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert archiveorg_ie.IE_DESC == ArchiveOrgIE.IE_DESC
    

# Generated at 2022-06-12 17:17:58.934184
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=protected-access
    assert ArchiveOrgIE._VALID_URL.match('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE._VALID_URL.match('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    # TODO: Add this test
    #assert ArchiveOrgIE._VALID_URL.match('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')
    #assert ArchiveOrgIE._VALID_URL.match('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:18:01.143104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)


# Generated at 2022-06-12 17:18:08.819215
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:09.887393
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-12 17:18:15.955743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._match_id('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?view=1up&seq=4') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id('https://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?view=1up&seq=4') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-12 17:18:18.269734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	info = ArchiveOrgIE()
	assert "archive.org" == info.IE_NAME
	assert "archive.org videos" == info.IE_DESC

# Generated at 2022-06-12 17:18:29.887677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:18:34.723430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:18:36.878511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:18:38.575695
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:20:47.064349
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:20:48.878607
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    # Test without priviledge escalation
    ArchiveOrgIE()

# Generated at 2022-06-12 17:20:49.845151
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-12 17:20:56.847290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC = 'archive.org videos' 
    ie.IE_NAME = 'archive.org'
    ie.validate_url=r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.validate_url == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_desc == 'archive.org videos' 
    assert ie.ie_name == 'archive.org'



# Generated at 2022-06-12 17:21:01.202191
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE
    """
    # Test attributes of class
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:02.496172
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None


# Generated at 2022-06-12 17:21:03.177351
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:21:07.465655
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE('http://www.archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator', '', '')
  assert ie.IE_NAME == 'archive.org', "Constructor should set the IE_NAME"
  assert ie.IE_DESC == 'archive.org videos', "Constructor should set the IE_DESC"

# Generated at 2022-06-12 17:21:08.202951
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-12 17:21:08.761199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()