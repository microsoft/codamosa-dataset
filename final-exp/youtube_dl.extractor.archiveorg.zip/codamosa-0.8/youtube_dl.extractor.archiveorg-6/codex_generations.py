

# Generated at 2022-06-12 17:14:24.804344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert True


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:14:25.479331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:14:28.953535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    sys.stderr.write('This test is incomplete\n')
    sys.stderr.write('Please help complete it\n')
    sys.stderr.flush()

# Generated at 2022-06-12 17:14:32.962409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('')
    assert ie.SUCCESS == 0
    assert ie.FAILING == 1
    assert ie.IGNORE == 2

    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-12 17:14:41.613706
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class TestArchiveOrgIE(ArchiveOrgIE):
        def __init__(self):
            self._initialize_cache()
            self._downloader = Mock()
            self._downloader.cache.get.return_value = None
            self._downloader.cache.set.return_value = None
            self._PARSE_JSON = re.compile(r'(?s)\(({[^)]+})\)')

    ie = TestArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_type() == 'archive'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:14:43.883197
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:14:45.998068
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_DESC == 'archive.org videos'
    assert obj.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:14:54.576410
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:55.615876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:15:00.451222
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:06.929949
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-12 17:15:07.504062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:15:14.157949
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testcase: https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    # Testcase: https://hdl.handle.net/2027/uc2.ark:/13960/t70v9xj0v
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE()._real_extract(url)
    assert u'1968 Demo - FJCC Conference Presentation Reel #1' in ArchiveOrgIE()._real_extract(url)['title']



# Generated at 2022-06-12 17:15:16.978498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:20.129959
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # Constructor should set the name of the class
    assert ie.IE_NAME == 'archive.org'

    # Constructor should set the description of the class
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:15:23.708705
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-12 17:15:27.209911
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testing instance creation
    ie = ArchiveOrgIE()
    # check if the url is accepted
    assert ie.suitable('http://archive.org/details/TheColorOfPomegranates')


# Generated at 2022-06-12 17:15:28.732275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-12 17:15:30.211516
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE() is not None

# Generated at 2022-06-12 17:15:31.117267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("http://archive.org")

# Generated at 2022-06-12 17:15:42.063072
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:15:44.337419
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None,dict(url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'))

# Generated at 2022-06-12 17:15:47.376312
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('https://archive.org/deatils/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:15:49.613466
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveIE = ArchiveOrgIE()
    assert(archiveIE is not None)
    assert(archiveIE.IE_NAME == 'archive.org')

# Generated at 2022-06-12 17:15:55.766492
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_link1 = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_link2 = 'https://archive.org/details/<>'
    test_link3 = 'https://archive.org/details/asdasd_21_98'
    print(ArchiveOrgIE._match_id(test_link1))
    print(ArchiveOrgIE._match_id(test_link2))
    print(ArchiveOrgIE._match_id(test_link3))
test_ArchiveOrgIE()

# Generated at 2022-06-12 17:15:57.737886
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'
    assert ie.IE_DESC == ie.ie_desc()


# Generated at 2022-06-12 17:15:59.447018
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Test for various functions of class ArchiveOrgIE

# Generated at 2022-06-12 17:16:01.960373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test constructor of class ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:16:03.327380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instantiate object of ArchiveOrgIE
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:07.515297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

    return ie

# Generated at 2022-06-12 17:16:33.477825
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # base class has no implementation of __init__() and
    # no meaningful logic in _real_extract(), so we only
    # test the constructor here
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert i.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:16:42.396435
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:43.675526
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IETest.instantiateTest(ArchiveOrgIE, True)

# Generated at 2022-06-12 17:16:52.233611
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global IE_NAME, IE_DESC
    ie = ArchiveOrgIE(IE_NAME, IE_DESC)
    obj = ie.__dict__
    assert obj['_VALID_URL'] == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)', \
           'ArchiveOrgIE._VALID_URL is incorrect'
    assert obj['IE_NAME'] == 'archive.org', \
           'ArchiveOrgIE.IE_NAME is incorrect'
    assert obj['IE_DESC'] == 'archive.org videos', \
           'ArchiveOrgIE.IE_DESC is incorrect'

# Generated at 2022-06-12 17:16:53.787963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-12 17:16:55.341231
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for class ArchiveOrgIE
    """
    ArchiveOrgIE('archive.org')


# Generated at 2022-06-12 17:16:56.160879
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE()
    return o

# Generated at 2022-06-12 17:16:56.981088
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-12 17:17:01.905254
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:17:06.949800
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    test_array = ie._downloader.urlopen("https://archive.org/details/Cops1922")
    total_size = 0
    chunk_size = 8192
    while True:
        chunk = test_array.read(chunk_size)
        if not chunk:
            break
        total_size += len(chunk)
    assert total_size == 8248465

# Generated at 2022-06-12 17:18:01.168250
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.IE_NAME == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-12 17:18:08.818736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Construct a ArchiveOrgIE object
    archive_org_ie = ArchiveOrgIE()
    # Test if the IE object is a instance of InfoExtractor
    assert isinstance(archive_org_ie, InfoExtractor)
    # Test if the IE object is able to extract video information
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_info = archive_org_ie.extract('http://archive.org/details/' + video_id)
    assert video_info['id'] == video_id
    assert video_info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-12 17:18:09.869870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:18:15.955745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    result = ie._real_extract("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # check for the presence of 'info'
    assert('info' in result)
    assert(result['title'] == '1968 Demo - FJCC Conference Presentation Reel #1')
    assert(result['creator'] == 'SRI International')
    # check for the presence of 'formats'
    assert('formats' in result)
    assert(len(result['formats']) == 1)
    # check for the presence of 'url' in formats
    assert('url' in result['formats'][0])

# Generated at 2022-06-12 17:18:17.895390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # TODO: test for method _real_extract
    pass

# Generated at 2022-06-12 17:18:29.510683
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['ext'] == 'ogg'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290

# Generated at 2022-06-12 17:18:30.514301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE.IE_NAME



# Generated at 2022-06-12 17:18:34.302937
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    assert test.IE_NAME == 'archive.org'
    assert test.IE_DESC == 'archive.org videos'
    assert type(test._VALID_URL) == RegexType
    assert type(test._TESTS) == list

# Generated at 2022-06-12 17:18:38.325204
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    assert result.IE_NAME == 'archive.org'
    assert result.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:18:39.935778
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tests that ArchiveOrgIE can be constructed without crashing
    archiveOrg = ArchiveOrgIE()

# Generated at 2022-06-12 17:20:43.964060
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();

test_ArchiveOrgIE();

# Generated at 2022-06-12 17:20:46.840003
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-12 17:20:51.656355
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_object = ArchiveOrgIE('ArchiveOrgIE', 'archive.org videos')
    assert class_object._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert class_object.IE_NAME == 'ArchiveOrgIE'
    assert class_object.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:20:52.488050
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:20:55.080777
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-12 17:20:56.846984
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:21:03.541589
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test that a constructor is created when
    the class is called with a URL
    """
    # Test with a URL
    video_constructor = ArchiveOrgIE(url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Test that the instance has a working download method
    video_constructor.download()
    # Test that a nonexistent URL is not accepted
    url_with_no_results = 'http://archive.org/details/WOW_YES_THIS_VIDEO_IS_NOT_AVAILABLE_AT_ALL'
    error_caught = False
    try:
        ArchiveOrgIE(url=url_with_no_results)
    except Exception:
        error_caught = True
    assert error_caught

# Generated at 2022-06-12 17:21:10.887868
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:21:16.479471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-12 17:21:19.633827
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    data = 'mock://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE.ie_key() == ArchiveOrgIE.ie_key_from_url(data)

