

# Generated at 2022-06-12 17:14:26.555200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test the second test case in ArchiveOrgIE._TESTS (see above)
    url = 'https://archive.org/details/Cops1922'
    ie = ArchiveOrgIE(url)
    assert ie.video_id == 'Cops1922'

# Generated at 2022-06-12 17:14:29.254405
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-12 17:14:31.920744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-12 17:14:33.049059
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:14:35.968949
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-12 17:14:38.652689
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    exp = object()
    i = ArchiveOrgIE('http://www.youtube.com/watch?v=BaW_jenozKc', exp)
    assert i._expected_status == exp
    assert i._val_url == 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 17:14:42.655020
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == "archive.org"
    assert instance.IE_DESC == "archive.org videos"
    assert instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert type(instance._TESTS) == list

# Generated at 2022-06-12 17:14:43.640953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(ArchiveOrgIE())

# Generated at 2022-06-12 17:14:52.823092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(1)
    actual_output = ie._real_extract(url)

# Generated at 2022-06-12 17:14:55.415977
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())._real_extract('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-12 17:15:10.440341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ieClass = ArchiveOrgIE()
    assert ieClass.IE_NAME == 'archive.org'
    assert ieClass.IE_DESC == 'archive.org videos'
    assert ieClass._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:20.216260
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ar = ArchiveOrgIE()
    ar._VALID_URL = r'http://archive.org/details/.*'
    url = "http://archive.org/details/1968Demo-fjccConferencePresentationReel#1"
    video_id = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ar.url = url
    ar.ie_key = "ArchiveOrg"
    ar.params = {}
    ar.info_dict = {}
    ar.add_ie(ar.ie_key, ar)
    ar.extract(url)
    assert ar.info_dict["title"] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert ar.info_dict["creator"] == "SRI International"
    assert ar.info_dict['id']

# Generated at 2022-06-12 17:15:20.822390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-12 17:15:22.471046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    # Constructor should throw exception if invalid URL is passed
    try:
        ArchiveOrgIE('')
        assert False
    except:
        assert True

# Generated at 2022-06-12 17:15:24.544741
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == "archive.org"

# Generated at 2022-06-12 17:15:27.777644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor_test(ArchiveOrgIE, ['http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'])

# Generated at 2022-06-12 17:15:30.028175
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert ie.IE_NAME == 'archive.org'
  assert ie.IE_DESC == 'archive.org videos'
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:33.756417
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:41.909313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:15:47.700210
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test sample URL with no video
    url = "http://www.archive.org/"
    ie = ArchiveOrgIE(url)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-12 17:16:15.699065
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE('archive.org')
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:16:16.550044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # no error should be raised
    ArchiveOrgIE()

# Generated at 2022-06-12 17:16:21.520358
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == '(?i)(https?://(?:www\.)?archive\.org/(?:details|embed)/|https?://(?:www\.)?(?:openlibrary|archive\.org)/stream/)(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:16:30.390091
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    #try:
    #    ArchiveOrgIE(url)
    #except:
    #    print("Test failed")
    #else:
    #    print("Test successed")
    aorgie = ArchiveOrgIE(url)
    video_page = aorgie._download_webpage(url, "XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    video_id = aorgie._match_id(url)
    #print(video_id)
    #video_page = aorgie._download_webpage(url, video_id)


# Generated at 2022-06-12 17:16:37.682487
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    
    import unittest
    class TestArchiveOrgIE(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls.video_id = 'MSNBCW_20131125_040000_To_Catch_a_Predator'

# Generated at 2022-06-12 17:16:38.277741
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-12 17:16:41.188936
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://www.archive.org/details/Sdn")
    assert ie.IE_NAME == "archive.org"
    assert ie.NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-12 17:16:50.211202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test if constructor of ArchiveOrgIE works correctly."""
    """Test for jwplayer."""
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    import re
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )

    IE_NAME = 'archive.org'
    IE_DESC = 'archive.org videos'

    assert ArchiveOrgIE._VALID_URL == re.compile(
        r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')


# Generated at 2022-06-12 17:16:55.433262
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()


## Unit test cases for ArchiveOrgIE.
## The following tests are in order:
##   - Use case 1: test extraction of video with JWPLAYER
##   - Use case 2: test extraction of video without JWPLAYER
##   - Use case 3: test extraction of audio with JWPLAYER
##   - Use case 4: test extraction of audio without JWPLAYER
##   - Use case 5: test extraction of playlist
##   - Use case 6: test extraction of html5-only audio
##   - Use case 7: test extraction of html5-only video
##   - Use case 8: test extraction of html5-only audio with smil manifest
##   - Use case 9: test extraction of html5-only audio with smil manifest and jwplayer
##   - Use case 10: test extraction of html5-only audio

# Generated at 2022-06-12 17:17:00.366262
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def _test(url, *args, **kwargs):
        ie = ArchiveOrgIE(url, *args, **kwargs)
        assert ie._VALID_URL == url
        assert ie.IE_NAME == 'archive.org'
        assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-12 17:17:26.424664
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:17:27.521038
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:17:28.801805
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name() == 'archive.org'

# Generated at 2022-06-12 17:17:38.200345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Conditions
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    playlist = '(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)'

# Generated at 2022-06-12 17:17:45.946610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor_test(ArchiveOrgIE, [
        "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "https://archive.org/details/Cops1922",
        "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/",
    ], {
        'skip': 'Requires rtmpdump'
    })

# Generated at 2022-06-12 17:17:53.795580
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"
    ie = ArchiveOrgIE(url)
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-12 17:17:58.665573
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Unit test for constructor of class ArchiveOrgIE """
    # ArchiveOrgIE(youtube_ie) should raise an exception
    try:
        ArchiveOrgIE(youtube_ie)
        assert False, "ArchiveOrgIE(youtube_ie) should raise an exception"
    except NameError:
        pass
    # ArchiveOrgIE(None) should work
    ie = ArchiveOrgIE(None)
    assert str(ie) == 'archive.org'

# Generated at 2022-06-12 17:17:59.183743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:18:01.169093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert "archive.org videos" == ArchiveOrgIE.IE_DESC

# Generated at 2022-06-12 17:18:03.802139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE.__init__() method
    # with an empty argument.
    ie = ArchiveOrgIE()

    # Test whether the instance is created successfully
    assert isinstance(ie, InfoExtractor) is True



# Generated at 2022-06-12 17:19:01.418423
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-12 17:19:10.334746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..utils import extract_attributes
    from ..extractor.common import InfoExtractor

    attrs = extract_attributes(u'<embed id="movie_player"\n\ttype="application/x-shockwave-flash"\n\tflashvars="playlist=https://archive.org/playlists/1.xml"\n\tsrc="https://archive.org/download/Movie_player/movie_player.swf"\n\tallowscriptaccess="always"\n\tallowfullscreen="true"\n\tquality="high"\n\tbgcolor="#000000"\n\tname="movie_player"\n\twidth="400"\n\theight="300">')

    assert attrs[u'playlist'] == u'https://archive.org/playlists/1.xml'

# Generated at 2022-06-12 17:19:11.182477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-12 17:19:12.655683
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == 'archive.org'

# Generated at 2022-06-12 17:19:22.923664
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    #Here is a short set of tests, to show if the regular expression match the urls of videos from archive.org
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    #Here we test if the regular expression in the url of the videos from archive.org is valid
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-12 17:19:23.469010
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-12 17:19:24.314474
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor)

# Generated at 2022-06-12 17:19:28.045823
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()
    test_ArchiveOrgIE.extract(
        "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-12 17:19:32.028364
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-12 17:19:40.443940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info_dict = instance.extract(test_url)
    assert info_dict['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info_dict['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info_dict['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info_dict['creator'] == 'SRI International'
    assert info_dict['release_date'] == '19681210'
    assert info_dict['uploader'] == 'SRI International'
    assert info_dict

# Generated at 2022-06-12 17:22:05.357668
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class TestArchiveOrgIE(ArchiveOrgIE):
        def _real_extract(self, url):
            return super(TestArchiveOrgIE, self)._real_extract(url)
    TestArchiveOrgIE('')._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-12 17:22:07.480953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test the ability to create ArchiveOrgIE class object
    """

    # Testing construction of ArchiveOrgIE class object
    ie = ArchiveOrgIE()

    # Making sure the class object was constructed properly
    assert ie is not None


# Generated at 2022-06-12 17:22:18.342111
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.ie_key() == "ArchiveOrg", "ArchiveOrgIE.ie_key = %s" % ie.ie_key()
    assert ie.ie_name() == "archive.org", "ArchiveOrgIE.ie_name() = %s" % ie.ie_name()
    assert ie.ie_desc() == "archive.org videos", "ArchiveOrgIE.ie_desc = %s" % ie.ie_desc()
    assert ie.ie_matches("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"), "ArchiveOrgIE.ie_matches = %s" % ie.ie_matches

# Generated at 2022-06-12 17:22:27.862307
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  """
  Unit test for constructor of class ArchiveOrgIE
  """
  archiveOrgClass = ArchiveOrgIE(ArchiveOrgIE)
  assert(archiveOrgClass.IE_NAME == "archive.org")
  assert(archiveOrgClass.IE_DESC == "archive.org videos")
  assert(archiveOrgClass._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)")

# Generated at 2022-06-12 17:22:31.631663
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_ArchiveOrg = ArchiveOrgIE()
    assert ie_ArchiveOrg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie_ArchiveOrg.IE_NAME == 'archive.org'
    assert ie_ArchiveOrg.IE_DESC == 'archive.org videos'


# Generated at 2022-06-12 17:22:32.349607
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-12 17:22:37.281385
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == "archive.org"
    assert ArchiveOrgIE().IE_DESC == "archive.org videos"
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-12 17:22:38.810480
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Initialize an Archive.org extractor
    """
    url = "http://example.com/test"

    ie = ArchiveOrgIE(url)

    assert ie._VALID_URL == ie._VALID_URL

    return

# Generated at 2022-06-12 17:22:45.548527
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.__class__.__name__ == "ArchiveOrgIE"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-12 17:22:46.415013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._TESTS[0]