

# Generated at 2022-06-24 12:03:09.857451
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:11.502760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    temp = ArchiveOrgIE()

# Generated at 2022-06-24 12:03:17.654696
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:18.509791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()


# Generated at 2022-06-24 12:03:25.170203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor when _VALID_URL creates a match
    from .common import InfoExtractor


    class DummyIE(InfoExtractor):
        IE_NAME = 'Dummy'
        _VALID_URL = r'(?i).*'

        def _real_extract(self, url):
            pass

    dummy_ie = DummyIE(DummyIE._create_ie_instance({}))
    # Test valid URL
    assert dummy_ie._match_id('http://foo.com/') == 'http://foo.com/'
    assert dummy_ie._match_id('http://foo.com/bar.flv') == 'http://foo.com/bar.flv'

# Generated at 2022-06-24 12:03:34.339762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():  
    import unittest
    # test for constructor
    class ArchiveOrgIETest(unittest.TestCase):
        def test_ArchiveOrgIE(self):
            input = 'cops1922'
            url = 'https://archive.org/details/' + input
            self.assertEqual(ArchiveOrgIE().match_url(url), input)

    unittest.main(argv=['First-arg-is-ignored'], exit=False, verbosity=2)

# Generated at 2022-06-24 12:03:34.987440
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:03:39.324931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert(ie.IE_NAME == 'archive.org');
    assert(ie.IE_DESC == 'archive.org videos');
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)');

# Generated at 2022-06-24 12:03:39.875966
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:03:41.922162
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:51.911892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__module__ == 'youtube_dl.extractor.archiveorg'
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'
    assert ArchiveOrgIE.ie_key() == 'archive.org'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:03:56.323455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE("http://www.archive.org/details/")
    except Exception:
        pass
    else:
        AssertionError(
            "ArchiveOrgIE() constructor should raise exception with no url")

# Generated at 2022-06-24 12:04:04.753430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # ArchiveOrgIE.suitable is not implemented so it always returns True
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:04:15.457022
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case 1
    test1_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test1_info = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }
    test1_obj = ArchiveOrgIE

# Generated at 2022-06-24 12:04:17.846619
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE
    :return: none
    """
    i = ArchiveOrgIE()
    assert i is not None
    # pass


# Generated at 2022-06-24 12:04:20.746573
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-24 12:04:25.870797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:27.393660
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    I = ArchiveOrgIE()
    assert I.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:37.255588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        (
            'http://www.archive.org/details/test_video',
            'http://archive.org/details/test_video',
        ),
        (
            'http://www.archive.org/details/test_video',
            'http://www.archive.org/details/test_video',
        ),
    ]
    for input_url, expected_url in test_cases:
        assert ArchiveOrgIE._build_url(input_url) == expected_url



# Generated at 2022-06-24 12:04:38.327179
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:39.510841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:04:40.036800
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:44.837023
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import extractor
    extractor.IE_DETAILS['archive.org'] = ArchiveOrgIE

    archive = extractor.gen_extractors('archive.org')

    assert str(archive) == '<archive.org: ArchiveOrgIE>'
    assert repr(archive) == '<archive.org: ArchiveOrgIE>'

# Generated at 2022-06-24 12:04:51.608080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' 
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'


# Generated at 2022-06-24 12:04:58.345138
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert info_extractor._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info_extractor._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:04:59.467956
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:02.668763
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x is not None

# Generated at 2022-06-24 12:05:09.709857
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ie.__class__.__name__
    assert ie.IE_DESC == ie.__class__.IE_DESC
    assert ie.VALID_URL == ie.__class__._VALID_URL
    assert ie.TESTS == ie.__class__._TESTS

EmbedArchiveOrgIE = ArchiveOrgIE.from_ie('ArchiveOrg')

# Generated at 2022-06-24 12:05:14.960261
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:05:18.541180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:19.530870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:25.068092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Tests XML
    assert ie._extract_urls('''<item><content src="https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect" /></item>''') == [
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    ]

# Generated at 2022-06-24 12:05:32.374564
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_common import TestDownloader
    from .test_youtube import YoutubeIE

    test_downloader = TestDownloader()
    test_youtube_ie = YoutubeIE()

    test_youtube_ie.download = lambda x: {
      'id': 'e-fA-gxRHB8',
      'title': 'test video'
    }

    test_ArchiveOrgIE = ArchiveOrgIE(test_downloader)
    test_ArchiveOrgIE.download = lambda x: {
      '_type': 'url',
      'url': 'http://archive.org/details/e-fA-gxRHB8',
      'title': 'test video'
    }

    test_downloader.add_info_extractor(test_ArchiveOrgIE)

# Generated at 2022-06-24 12:05:40.584818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE
    """
    # Good test case
    url = "http://archive.org/details/XD300-23_68Highlights..."
    # Instantiate an ArchiveOrgIE object
    archiveOrgIE = ArchiveOrgIE()
    # Call the extract method from the ArchiveOrgIE object
    archiveOrgIE.extract(url)


# Generated at 2022-06-24 12:05:45.598128
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    test_input = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie.suitable(test_input) == True
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:56.363804
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=protected-access
    from ..extractor.common import InfoExtractor
    from ..utils import (
        compat_str,
        compat_urlparse
    )
    ie = InfoExtractor()
    ie._ies = [ArchiveOrgIE] # pylint: disable=protected-access
    ie._downloader = None # pylint: disable=protected-access
    ie._working_dir = None # pylint: disable=protected-access
    assert isinstance(ie, ArchiveOrgIE)
    test_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    parsed = compat_urlparse.urlparse(test_url)
    assert parsed
    assert isinstance(parsed.netloc, compat_str)

# Generated at 2022-06-24 12:06:01.804414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'


# Unit tests for function _real_extract()

# Generated at 2022-06-24 12:06:02.691231
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is ArchiveOrgIE

# Generated at 2022-06-24 12:06:09.731777
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.name() == 'ArchiveOrg'
    assert ie.description() == 'archive.org videos'

# Generated at 2022-06-24 12:06:16.445249
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(ArchiveOrgIE.ie_key(), 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.url == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:06:27.170282
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)
    
    playlist = ''
    play8 = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    if play8:
        attrs = extract_attributes(play8)
        playlist = attrs.get('value')
    if not playlist:
        # Old jwplayer fallback
        playlist = ie._search_

# Generated at 2022-06-24 12:06:28.867455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test1 = ArchiveOrgIE()
    assert test1 is not None


# Generated at 2022-06-24 12:06:32.936828
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Basic test of ArchiveOrgIE.
    """
    ArchiveOrgIE()._real_extract('http://archive.org/details/FedFlix_1602_INTERNATIONAL_FALLS')

# Generated at 2022-06-24 12:06:34.497248
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:06:45.319717
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:53.842275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    result = ie._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect');
    assert 'XD300-23_68HighlightsAResearchCntAugHumanIntellect' == result['id']
    assert '68 Demo - FJCC Conference Presentation Reel #1' == result['title']
    assert 'md5:8af1d4cf447933ed3c7f4871162602db' == result['md5']
    
if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:06:58.907017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(bool(ie._TESTS))

# Generated at 2022-06-24 12:07:09.731067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:16.063470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ('http://www.archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect_512kb.mp4',
            'mp4') in info['formats']

# Generated at 2022-06-24 12:07:17.509304
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:07:20.276113
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    for k in ['module', 'IE_DESC', '_VALID_URL', '_TESTS']:
        assert getattr(inst, k)
    assert inst._real_extract({'url': 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'})

# Generated at 2022-06-24 12:07:23.515881
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = type('ArchiveOrgIE', (ArchiveOrgIE,), {})()
    using_copyrighted_content = IE._is_using_copyrighted_content('Watching Paint Dry')
    assert using_copyrighted_content is False

# Generated at 2022-06-24 12:07:24.467321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:27.320768
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # the url is private so it wont work, but at least we can test this
    YouTubeIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:29.204515
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:07:30.717376
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:34.953131
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from six import assertRaisesRegex
    from six.moves.urllib.error import URLError
    with assertRaisesRegex(URLError, '404'):
        # The following invalid URL should raise URLError(404, -2, "Name or service not known")
        ArchiveOrgIE()._download_webpage('https://www.this-is-invalid.example.org', 'invalid')

# Generated at 2022-06-24 12:07:37.177722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS

# Generated at 2022-06-24 12:07:48.723921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert a.__class__.__name__ == 'ArchiveOrgIE'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert a.IE_DESC == 'archive.org videos'
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:54.116413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:56.594940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:08:05.842623
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This objects is the "constructor" of class ArchiveOrgIE.
    It is called for downloading the video.
    """
    import sys
    import os
    import unittest

    from ytdl.extractor.archiveorg import ArchiveOrgIE
    from ytdl.utils import age_restricted

    def get_t(*args, **kwargs):
        return args[0].format(*args[1:], **kwargs)

    @classmethod
    def setUpClass(cls):
        cls.temp_dir = os.path.join(os.path.dirname(__file__), 'temp_dir')
        if not os.path.exists(cls.temp_dir):
            os.makedirs(cls.temp_dir)


# Generated at 2022-06-24 12:08:06.957839
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:08:15.892688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:17.874806
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_ = ArchiveOrgIE()
    assert ie_.IE_NAME == 'archive.org'
    assert ie_.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:19.839158
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-24 12:08:22.858488
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert(ie.IE_NAME == 'archive.org');
    assert(ie.IE_DESC == 'archive.org videos');


# Generated at 2022-06-24 12:08:23.718108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-24 12:08:24.809713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:08:28.635870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(ie.IE_NAME)
    print(ie.IE_DESC)
    print(ie._VALID_URL)
    print(ie._TESTS)

# Generated at 2022-06-24 12:08:33.184809
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:37.955024
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE()
    assert arch.__class__.__name__ == 'ArchiveOrgIE'
    assert arch.IE_NAME == 'archive.org'
    assert arch.IE_DESC == 'archive.org videos'
    assert arch._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:08:38.826413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	
  assert 1 == 1

# Generated at 2022-06-24 12:08:49.247176
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test regex matching
    result = ie._match_id(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert result == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', "Failed to match archive.org URL"

    # Test URL building
    assert ie._build_url('XD300-23_68HighlightsAResearchCntAugHumanIntellect') == \
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', "Failed to build archive.org URL"

    # Test URL parsing

# Generated at 2022-06-24 12:08:49.862776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert True

# Generated at 2022-06-24 12:08:53.375450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor should accept both of 'https://archive.org/details/Cops1922' and 'Cops1922'
    ArchiveOrgIE('https://archive.org/details/Cops1922')
    ArchiveOrgIE('Cops1922')

# Generated at 2022-06-24 12:08:53.998595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:56.195519
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.info()
    pass

# Generated at 2022-06-24 12:08:59.990161
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:02.286427
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    assert info.IE_NAME == 'archive.org'
    assert info.IE_DESC == 'archive.org videos'
# Test for instance method _real_extract

# Generated at 2022-06-24 12:09:03.772988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    inst._real_extract()

# Generated at 2022-06-24 12:09:13.722903
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re, sys
    from types import ModuleType, FunctionType
    from ..utils import ExtractorError

    #############################################################
    #### Test code generation/execution and compilation #########
    #############################################################

    def init(self, url):
        self.url = url

    def extract_from_url(self, url):
        return 'extract_from_url'

    def extract_from_playlist(self, playlist, playlist_id):
        return 'extract_from_playlist'

    def _assert(result, expected_result, exception=None):
        assert result == expected_result, exception

    def runner(code, assert_func, expected_result, exception=None):
        if exception:
            assert_func_name = 'assertRaisesRegexp'
        else:
            assert_func_name

# Generated at 2022-06-24 12:09:24.843334
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for the constructor of the ArchiveOrgIE module. """
    extractor = ArchiveOrgIE()

    if extractor.name != 'archive.org':
        raise Exception('ArchiveOrgIE.name is incorrect.')

    if extractor.description != 'archive.org videos':
        raise Exception('ArchiveOrgIE.description is incorrect')

    if extractor._VALID_URL != 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)':
        raise Exception('ArchiveOrgIE._VALID_URL is incorrect')


# Generated at 2022-06-24 12:09:29.613324
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == "archive.org"
    assert obj.IE_DESC == "archive.org videos"
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(obj._TESTS) == 4

# Generated at 2022-06-24 12:09:36.870412
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE with one of the test cases
    if __name__ == '__main__':
        test = ArchiveOrgIE()
        test.download(
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:09:37.732097
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE(None)

# Generated at 2022-06-24 12:09:39.167663
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:41.278747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for contructor of ArchiveOrgIE
    """
    assert ArchiveOrgIE().ie_key() == 'archive.org'

# Generated at 2022-06-24 12:09:46.812154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test.
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL is None
    assert ie._TESTS is None
    assert ie._WORKING is None
    assert ie._downloader is None

# Generated at 2022-06-24 12:09:48.607685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert type(IE) is ArchiveOrgIE


# Generated at 2022-06-24 12:09:49.795864
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie


# Generated at 2022-06-24 12:09:53.714357
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert issubclass(ArchiveOrgIE, InfoExtractor)
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:54.699428
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE("engine")

# Generated at 2022-06-24 12:09:58.335783
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:09:58.739285
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:10:04.396632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert archiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:10:05.168807
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:10:06.165483
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:17.909732
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:10:19.186633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor("archive.org"))


# Generated at 2022-06-24 12:10:20.116540
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert True

# Generated at 2022-06-24 12:10:26.301856
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/Frodo')

# Generated at 2022-06-24 12:10:27.440955
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:35.048866
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .compat import compat_urllib_request
    from .compat import compat_urlparse

    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # create a instance of class ArchiveOrgIE
    archive_org = ArchiveOrgIE()
    # use a test file to replace real webpage
    webpage_file = open('test/test_files/archive_org/archive.org_details_xd300.response', 'rb')
    webpage_string = webpage_file.read()
    webpage_file.close()
    archive_org._download_webpage = lambda url, video_id: webpage_string
    # use a test file to replace real json request

# Generated at 2022-06-24 12:10:41.330800
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test_ArchiveOrgIE_instantiation(url):
        return ArchiveOrgIE(ArchiveOrgIE.ie_key())._real_initialize()

    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    print(test_ArchiveOrgIE_instantiation(url))

# Generated at 2022-06-24 12:10:52.943358
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t1 = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    t2 = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    t3 = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    t4 = 'https://archive.org/details/Ftghf'
    t5 = 'http://archive.org/details/Ftghf'
    t6 = 'https://archive.org/details/Ftghf'
    t7 = 'https://archive.org/details/5584_The_Finest_Hours_12_10_55_00'

# Generated at 2022-06-24 12:10:57.722069
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert(hasattr(ArchiveOrgIE,'_VALID_URL'))
	assert(hasattr(ArchiveOrgIE,'_TESTS'))
	assert(hasattr(ArchiveOrgIE,'IE_NAME'))
	assert(hasattr(ArchiveOrgIE,'IE_DESC'))
	assert(hasattr(ArchiveOrgIE,'_download_xml'))
	assert(hasattr(ArchiveOrgIE,'_real_extract'))

# Generated at 2022-06-24 12:11:03.176030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Converts the given string to a Request object and returns it.
    """
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    m = ArchiveOrgIE._VALID_URL.match(url)

# Generated at 2022-06-24 12:11:15.051773
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:20.717715
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_youtube_dl import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ie = ydl._ies['archive.org']
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:21.409633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:22.149833
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:23.088845
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:11:23.769258
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-24 12:11:25.022725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-24 12:11:32.123730
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:11:38.782436
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
	#print(info)
	print('%s\n%s' % (info['title'], info['creator']))
	return info['creator']

if __name__ == '__main__':
	test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:44.379803
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:46.206582
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie=ArchiveOrgIE()
    #
    # FIXME: add a test
    #
    pass

# Generated at 2022-06-24 12:11:48.379546
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert not hasattr(ArchiveOrgIE, '_LOGGER')

# Generated at 2022-06-24 12:11:50.329535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    assert result.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:11:52.514102
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:11:55.283508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: split to different test cases?
    global ArchiveOrgIE
    ArchiveOrgIE._real_extract(ArchiveOrgIE, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:12:03.034408
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import copy
    import types
    if not hasattr(types, 'ClassType'):  # New in Python 2.2
        types.ClassType = type
    if not hasattr(types, 'InstanceType'):  # New in Python 2.5
        types.InstanceType = object

    class A(object):
        pass
    a = A()
    a.__name__ = 'foo'
    a.__doc__ = 'bar'
    a.a = 1
    a.b = 2

    a_copy = copy.copy(a)
    assert a_copy is not a
    assert a_copy.__class__ is A
    assert a_copy.__name__ == 'foo'
    assert a_copy.__doc__ == 'bar'
    assert a_copy.a == 1

# Generated at 2022-06-24 12:12:04.287514
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:12:10.430337
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:12:18.470847
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', {'archive_org': ArchiveOrgIE})
    # test vid names
    assert ie.get_id(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie.get_id(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/start=0/'
    )
    assert ie.get_id(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator&output=json'
    )

# Generated at 2022-06-24 12:12:22.929235
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL is not None
    assert obj._TESTS is not None


# Generated at 2022-06-24 12:12:33.247216
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:44.060892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_download import fake_get_test
    url_na_uuid = 'http://archive.org/details/na_uuid'
    url_not_found = 'http://archive.org/details/not_found'
    url_no_media = 'http://archive.org/details/no_media'
    url_with_media = 'http://archive.org/details/with_media'
    url_with_media_same_name = 'http://archive.org/details/with_media_same_name'

    extractor = ArchiveOrgIE()
    # Because it's an abstract class, it will throw an exception if we try to
    # instantiate it.

# Generated at 2022-06-24 12:12:44.888543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:46.686602
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie1 = InfoExtractor(ArchiveOrgIE)
    assert ie1.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:12:49.334988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:58.585842
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of ArchiveOrgIE
    ie_obj= ArchiveOrgIE()
    assert ie_obj.name == 'archive.org'
    assert ie_obj.description == 'archive.org videos'
    assert ie_obj.valid_urls == [(re.compile(r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'), ie_obj.name)]
    assert ie_obj.ie_key() == 'archive.org'
    assert ie_obj.ie_key() == ie_obj.ie_key()
    assert ie_obj.ie_key() == ie_obj.ie_key()
    assert ie_obj.ie_key() == ie_obj.ie_key()


# Generated at 2022-06-24 12:12:59.477892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:13:00.629825
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL

# Generated at 2022-06-24 12:13:09.633344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    from .youtube import YoutubeIE

    def assert_raises_exception(method, url, exception, *args, **kwargs):
        try: 
            method(url, *args, **kwargs)
            assert False
        except exception:
            pass

    assert_raises_exception(InfoExtractor.suitable, "http://archive.org/details/movies", UnsupportedError)
    assert ArchiveOrgIE.suitable("http://archive.org/details/movies")
    assert not ArchiveOrgIE.suitable("https://youtube.com")

    assert not ArchiveOrgIE()._VALID_URL.search("https://youtube.com")
    assert ArchiveOrgIE()._VALID_URL.search("https://archive.org/embed/")