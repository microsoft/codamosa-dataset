

# Generated at 2022-06-24 12:03:11.502995
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Unit test mkv files

# Generated at 2022-06-24 12:03:17.389573
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert "archive.org videos" == info_extractor.IE_DESC
    assert "archive.org" == info_extractor.IE_NAME

# Generated at 2022-06-24 12:03:18.181174
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE(ctx=None)

# Generated at 2022-06-24 12:03:20.736554
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if ie.IE_NAME == 'archive.org':
        assert ie == ArchiveOrgIE(ie.ie_key())

# Generated at 2022-06-24 12:03:22.078141
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test constructor of class ArchiveOrgIE"""
    a = ArchiveOrgIE()
    assert a.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:03:27.935931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor_test(
        lambda x: ArchiveOrgIE(x),
        [
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'https://archive.org/details/Cops1922',
            'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
        ],
    )

# Generated at 2022-06-24 12:03:34.552007
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Construct an instance of ArchiveOrgIE
    # with mandatory arguments
    ie = ArchiveOrgIE()

    # test the name of instance
    assert ie.IE_NAME is not None

    # test the description of instance
    assert ie.IE_DESC is not None

    # test the valid pattern of instance
    assert ie._VALID_URL is not None


# Generated at 2022-06-24 12:03:39.836873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_test = ArchiveOrgIE()
    expected_test_result = {"id": "XD300-23_68HighlightsAResearchCntAugHumanIntellect",
                            "ext": "ogg",
                            "title": "1968 Demo - FJCC Conference Presentation Reel #1",
                            "description": "md5:da45c349df039f1cc8075268eb1b5c25",
                            "creator": "SRI International",
                            "release_date": "19681210",
                            "uploader": "SRI International",
                            "timestamp": 1268695290,
                            "upload_date": "20100315"}

# Generated at 2022-06-24 12:03:41.026016
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE.VALID_URL

# Generated at 2022-06-24 12:03:43.672341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE

    ie = ArchiveOrgIE()
    if not isinstance(ie, InfoExtractor):
        raise TypeError("ArchiveOrgIE constructor must have a superclass InfoExtractor!")

# Generated at 2022-06-24 12:03:47.910263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME != None
    assert ArchiveOrgIE().IE_DESC != None


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:03:48.672489
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:59.099045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:01.607293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:04:10.034609
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for archived page.
    # First, obtain the content of the page we want to test.
    pageURL = "http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"

# Generated at 2022-06-24 12:04:10.652360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:12.144545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)

# Generated at 2022-06-24 12:04:13.041875
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-24 12:04:14.053050
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:17.535973
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:23.149467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE

    ie = ArchiveOrgIE()
    ie = InfoExtractor()

    ie = ArchiveOrgIE()
    ie = InfoExtractor()

# Generated at 2022-06-24 12:04:31.191384
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test_ArchiveOrgIE_get_info():
        test_url1 = 'http://www.archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
        test_url2 = 'http://www.archive.org/details/starwarstheempirestrikesback80'
        test_url3 = 'http://www.archive.org/details/VocaPeople_20131104'

        test_info1 = ArchiveOrgIE()._real_extract(test_url1)
        test_info2 = ArchiveOrgIE()._real_extract(test_url2)
        test_info3 = ArchiveOrgIE()._real_extract(test_url3)


# Generated at 2022-06-24 12:04:34.501319
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:04:43.126948
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:04:45.926850
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:46.472559
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:47.676504
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:04:49.557915
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test creation of ArchiveOrgIE object"""
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:56.950638
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:05:03.303351
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test 1
    urls = [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    ]
    for url in urls:
        ie = ArchiveOrgIE()
        # test that it can be constructed
        ie.suitable(url)
        ie.working

# Generated at 2022-06-24 12:05:07.093155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for Constructor - ArchiveOrgIE
    if __name__ == '__main__':
        test_obj = ArchiveOrgIE()
        print(test_obj)

# Generated at 2022-06-24 12:05:08.709979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'


# Generated at 2022-06-24 12:05:16.822477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Method test_ArchiveOrgIE tests whether the constructor
    # of the class ArchiveOrgIE is implemented correctly
    archive_org_ie = ArchiveOrgIE()
    assert(archive_org_ie.IE_NAME == 'archive.org')
    assert(archive_org_ie.IE_DESC == 'archive.org videos')
    assert(archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:05:18.332743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:28.841775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert (ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie._test_urls == ['https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'https://archive.org/details/Cops1922', 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'])


# Unit test

# Generated at 2022-06-24 12:05:32.489378
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # The rule pattern should contain the main domain name
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:05:33.307524
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('ArchiveOrgIE')


# Generated at 2022-06-24 12:05:36.953213
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    module_test = ArchiveOrgIE(None)
    assert module_test is not None

# Generated at 2022-06-24 12:05:39.836004
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ia = InfoExtractor("archive.org")
    assert isinstance(ia, ArchiveOrgIE)
    assert ia.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:05:43.157733
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(
        ArchiveOrgIE(
            youtube_dl.YoutubeDL({}),
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
        ),
        ArchiveOrgIE
    )

# Generated at 2022-06-24 12:05:48.036005
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie
    assert ie._download_webpage
    assert ie._match_id
    assert ie._search_regex
    assert ie._parse_json

# Generated at 2022-06-24 12:05:49.574030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()


# Generated at 2022-06-24 12:05:50.578173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:05:51.200970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:05:59.345101
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Parameter: None
    archive_orgIE = ArchiveOrgIE()
    # Test with non existing URL

# Generated at 2022-06-24 12:06:01.847549
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if 'archive.org' in sys.argv[1:]:
        inst = ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:06:07.718728
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('https://archive.org/details/Cops1922')
    assert ie.suitable('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:06:09.245755
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    return ie

# Generated at 2022-06-24 12:06:10.277336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-24 12:06:19.098780
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    from string import ascii_lowercase
    from random import choice
    from . import _test_extract
    ie = ArchiveOrgIE(url, ascii_lowercase, choice)
    assert ie.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert _test_extract(ie)
test_ArchiveOrgIE.get_id = lambda x: 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
del test_ArchiveOrgIE

# Generated at 2022-06-24 12:06:21.428280
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None, '')
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:06:22.599931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_initialize()

# Generated at 2022-06-24 12:06:30.031054
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:30.434889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE({})

# Generated at 2022-06-24 12:06:38.101173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    sample_url = 'https://archive.org/details/Cops1922'
    sample_video_id = 'Cops1922'
    
    assert IE_NAME in globals()
    ie = globals()[IE_NAME]()
    # make sure that fetching of url works
    ie.extract(sample_url)
    # make sure that you get an instance of InfoExtractor
    assert isinstance(ie, InfoExtractor)
    # test ie_key
    assert ie.ie_key() == IE_NAME
    # test ext
    assert ie.ext(sample_url) == 'mp4'
    # test _match_id
    assert ie._match_id(sample_url, sample_video_id) == sample_video_id
    # test _real_extract
    info = ie._real_extract

# Generated at 2022-06-24 12:06:46.458549
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj.IE_NAME == "archive.org"
    assert obj.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:06:47.300107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")


# Generated at 2022-06-24 12:06:58.207899
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'test')
    assert ie.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'test')
    assert ie.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'test')
    assert ie.valid_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'test')

# Generated at 2022-06-24 12:07:09.499398
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:11.038043
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archie = ArchiveOrgIE()
    assert archie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:13.103841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:15.403468
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    args = ['https://archive.org/details/Cops1922']
    return ArchiveOrgIE(*args)

# Generated at 2022-06-24 12:07:18.095125
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:21.967594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case: Pass
    assert(str(ArchiveOrgIE('archive.org', 'archive.org')) == "<class 'youtube_dl.extractor.archive.IE_NAME'>")


# Generated at 2022-06-24 12:07:23.822661
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    test._parse_jwplayer_data({}, "123")

# Generated at 2022-06-24 12:07:33.178163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:34.538688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:37.605017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:07:39.720554
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:07:41.763133
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-24 12:07:46.202059
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test of ArchiveOrgIE"""
    object_ie = InfoExtractor()
    object_ie.add_info_extractor(ArchiveOrgIE)
    object_ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:47.555676
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .archiveorg import test_ArchiveOrgIE
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:07:51.647090
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:53.367486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:56.539452
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:57.534239
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archorg1 = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:58.610296
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:07:59.075612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:01.218072
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-24 12:08:01.647253
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:05.083803
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:07.931572
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')
    ArchiveOrgIE('archive.org', 'archiveorg')

# Generated at 2022-06-24 12:08:19.500915
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = globals()['ArchiveOrgIE']
    ie = class_('')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_search_regex')
    assert hasattr(ie, '_parse_json')
    assert hasattr(ie, '_parse_jwplayer_data')
    assert hasattr(ie, '_parse_html5_media_entries')
    assert hasattr(ie, '_download_json')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:08:20.286481
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:27.543888
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie._get_video_id(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == \
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._get_video_id(
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == \
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:08:35.741701
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE.IE_NAME initialization
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    # test ArchiveOrgIE.IE_DESC initialization
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"
    # test ArchiveOrgIE._VALID_URL initialization
    valid_url = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._VALID_URL == valid_url

# Generated at 2022-06-24 12:08:39.857265
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:44.514354
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # test the overall class
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:08:47.572226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    pass

# Generated at 2022-06-24 12:08:52.102887
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.load_template(['playlist']) == [{
            'id': 'playlist',
            'player_url': 'http://archive.org/services/player/jsplayer',
            'flash_player': 'http://archive.org/player.swf',
            'template': 'archiveorg_js5player',
        }]

# Generated at 2022-06-24 12:09:03.285272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:05.227750
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE == type(ArchiveOrgIE())

# Generated at 2022-06-24 12:09:13.249843
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    If a constructor of a class raises an exception, it should be in the __init__
    method, not in the body of the class.
    """
    ie = ArchiveOrgIE('http://www.archive.org/')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:09:13.796307
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:15.863977
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:16.852487
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:09:18.292093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('example', 'example') == 'example'

# Generated at 2022-06-24 12:09:21.104321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
   archiveOrgIE = ArchiveOrgIE()
   assert archiveOrgIE
   assert archiveOrgIE.IE_NAME == "archive.org"
   assert archiveOrgIE.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:09:23.105510
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:25.205049
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of ArchiveOrgIE class."""
    # archive.org has been hosted at archive.org since 1996.
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:27.020224
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:09:34.236306
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE._get_video_info
    import sys
    import platform
    import unittest
    from .test_common import TestCommon
    from .test_youtube import TestYoutube

    if platform.system() != 'Windows':
        from .test_archiveorg import TestArchiveOrgIE
        from .test_publichd import TestPublichd
    from .test_dailymotion import TestDailymotion
    from .test_facebook import TestFacebookIE
    from .test_vine import TestVine
    from .test_generic import TestGeneric

    # Construct test suite for ArchiveOrgIE
    test_classes = []
    test_classes.append(TestArchiveOrgIE)
    test_classes.append(TestCommon)
    test_classes.append(TestYoutube)
    test_classes.append(TestPublichd)
   

# Generated at 2022-06-24 12:09:35.558430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:39.431734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # type: () -> None
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:41.418355
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:09:49.436505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archorg_ie = ArchiveOrgIE()
    info = archorg_ie._real_extract(url)
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['ext'] == 'ogg'
    assert info['uploader'] == 'SRI International'
    assert info['language'] == 'eng'


# Generated at 2022-06-24 12:09:59.364563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert (type(ie.IE_NAME) == str)
    assert (type(ie.IE_DESC) == str)
    assert (ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert (ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')

# Generated at 2022-06-24 12:10:03.780425
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == 'archive.org'
    assert x._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert x._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert x._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:10:09.103740
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instantiate an object of class ArchiveOrgIE
    test_obj = ArchiveOrgIE()
    assert test_obj.IE_NAME == "archive.org"
    assert test_obj.IE_DESC == "archive.org videos"
    assert test_obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:10:22.166104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:35.002801
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:10:40.494226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE().IE_DESC == ArchiveOrgIE.IE_DESC
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:10:42.305613
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE
    assert IE.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-24 12:10:43.293887
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:10:44.624392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(object())

# Generated at 2022-06-24 12:10:54.503632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(info['url'] == 'http://ia800906.us.archive.org/6/items/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect.ogv')
    assert(info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1')
    assert(info['description'] != '')

# Generated at 2022-06-24 12:10:57.125726
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:11:04.428275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archive.org")
    assert ie.name == "archive.org" or ie.name == "archive.org videos"
    assert ie.description == "archive.org videos"
    assert ie.valid_url("http://archive.org/details/Cops1922")
    assert ie.valid_url("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.valid_url("https://archive.org/details/")

# Generated at 2022-06-24 12:11:06.211583
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE.IE_NAME == 'archive.org')
    assert(ArchiveOrgIE.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:11:11.555753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This is a test case for ArchiveOrgIE
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:12.952604
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:11:19.870299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url = 'https://archive.org/details/' + video_id
    webpage = 'https://archive.org'
    ie = ArchiveOrgIE(webpage)
    assert ie.ie_key() == 'ArchiveOrg', 'ie_key should be ArchiveOrg'
    assert ie.suitable(None), 'IE should be suitable for empty URL'
    assert not ie.suitable(webpage), 'IE should not be suitable for non-video URL'
    assert ie.suitable(url), 'IE should be suitable for video URL'

# Generated at 2022-06-24 12:11:31.264063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test instantiation of class ArchiveOrgIE
    downloads = [
        'http://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect_512kb.mp4',
        'http://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect_archive.torrent',
    ]

# Generated at 2022-06-24 12:11:33.172968
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'

# Generated at 2022-06-24 12:11:35.932289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check if it's initialized properly
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:11:46.099875
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect')._TEST_IE_NAME == 'archive.org'
    assert ArchiveOrgIE('Cops1922')._TEST_IE_NAME == 'archive.org'
    assert ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect')._TEST_IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE('Cops1922')._TEST_IE_DESC == 'archive.org videos'

    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:52.749941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.check_valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert ie.check_valid_url('http://archive.org/details/Cops1922') == True
    assert ie.check_valid_url('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert ie.check_valid_url('https://www.archive.org/details/Cops1922') == True

# Generated at 2022-06-24 12:11:54.824173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:58.897757
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:10.136077
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:12:10.534221
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:12.203083
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:12:13.436638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ia = ArchiveOrgIE()
    assert ia is not None

# Generated at 2022-06-24 12:12:20.385087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	AE = ArchiveOrgIE()
	assert AE.IE_NAME == 'archive.org'
	assert AE.IE_DESC == 'archive.org videos'
	assert AE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:27.850274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    class TestArchiveOrgIE(unittest.TestCase):
        def test_constructor(self):
            ie = ArchiveOrgIE()
            self.assertEqual(ie.ie_key(), 'ArchiveOrg')
            self.assertEqual(ie.ie_name(), 'archive.org')
            self.assertEqual(ie.ie_desc(), 'archive.org videos')
    unittest.main()


# Generated at 2022-06-24 12:12:28.458735
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:12:32.281463
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	a = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
	list(a.next())
	list(a.next())

# Generated at 2022-06-24 12:12:33.717109
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:12:36.726973
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructing a ArchiveOrgIE should not result in an exception.
    """
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:41.352055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for "Cops1922" Video
    test_url = "https://archive.org/details/Cops1922"
    expected_video_id = "Cops1922"
    # Call constructor and test for all inputs
    ArchiveOrgIE(test_url, expected_video_id)
    

# Generated at 2022-06-24 12:12:42.608389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:12:54.720255
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:13:02.225643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Wizard to generate unit test for ArchiveOrgIE
    
    The following parameters are used to generate this unit test.
    To get these values, execute the following code in your browser's console:
    
    > const [url, post_data] = window.JQuery('#download-form form').serializeArray().reduce((acc, { name, value }) => { acc[0][name] = value; return acc; }, [{}, {}]);
    > console.log('\'' + url + '\'');
    > console.log('\'' + JSON.stringify(post_data) + '\'');
    """
    url = 'https://archive.org/download/SRI_International_1968_Demo_FJCC_Conference_Presentation_Reel_1'

# Generated at 2022-06-24 12:13:04.909539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'



# Generated at 2022-06-24 12:13:07.119670
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:13:16.825892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from zhihu_oauth.constant import Constant
    from zhihu_oauth.zhcls.url import Url
    url = 'http://archive.org/details/Cops1922'
    url_obj = Url(url)
    archive_org_ie = ArchiveOrgIE(url_obj)
    assert (archive_org_ie.url == url)
    assert (archive_org_ie.domain == 'archive.org')
    assert (archive_org_ie.site_key == 'archive.org')
    assert (archive_org_ie.video_id == 'Cops1922')
    assert (archive_org_ie.extractor_key == 'ArchiveOrg')
    assert (archive_org_ie.url_object == url_obj)