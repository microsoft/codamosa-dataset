

# Generated at 2022-06-24 12:03:18.184447
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        (0,
         'Cops1922', 'http://archive.org/embed/Cops1922',
         'Buster Keaton\'s "Cops" (1922)'),
        (1,
         'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
         'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
         '1968 Demo - FJCC Conference Presentation Reel #1')
    ]
    for (id, video_id, expected_url, expected_title) in test_cases:
        archive_orgIE = ArchiveOrgIE(id)
        url, title = archive_orgIE._real_extract(video_id)

# Generated at 2022-06-24 12:03:21.507213
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE._TESTS
    assert IE._VALID_URL
    assert IE._WORKING
    assert IE.IE_NAME
    assert not IE.IE_DESC

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:03:22.878065
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:03:25.218340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructing ArchiveOrgIE object
    ie = ArchiveOrgIE()
    # Test calling _download_webpage
    # (not checking the return value since the test webpage is highly volatile)
    ie._download_webpage('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'testid')

# Generated at 2022-06-24 12:03:26.927285
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:03:28.162457
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Perform test on ArchiveOrgIE
    """
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:31.980043
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC

# Generated at 2022-06-24 12:03:32.541679
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:03:41.832252
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, 'IE_NAME')
    assert ie.IE_NAME == 'archive.org'
    assert hasattr(ie, 'IE_DESC')
    assert ie.IE_DESC == 'archive.org videos'
    assert hasattr(ie, '_VALID_URL')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert hasattr(ie, '_TESTS')
    tests = ie._TESTS
    assert len(tests) == 4
    # test 1
    url = tests[0]['url']

# Generated at 2022-06-24 12:03:51.815314
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda *args, **kw: '<html></html>'
    ie._parse_jwplayer_data = lambda *args, **kw: None
    ie._parse_html5_media_entries = lambda *args, **kw: None
    ie._download_json = lambda *args, **kw: None
    ie._parse_jwplayer_data(None, None)
    ie._parse_html5_media_entries(None, None, None)
    ie._download_json(None, None)
    ie._parse_jwplayer_data = lambda *args, **kw: []
    ie._parse_html5_media_entries = lambda *args, **kw: []
    ie._download_json = lambda *args, **kw: {}
    ie._parse

# Generated at 2022-06-24 12:04:02.852581
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = ArchiveOrgIE._VALID_URL
    ie._TESTS = ArchiveOrgIE._TESTS
    ie._real_extract = ArchiveOrgIE._real_extract
    ie._match_id = ArchiveOrgIE._match_id
    ie._download_webpage = ArchiveOrgIE._download_webpage
    ie._search_regex = ArchiveOrgIE._search_regex
    ie._parse_json = ArchiveOrgIE._parse_json
    ie._parse_jwplayer_data = ArchiveOrgIE._parse_jwplayer_data
    ie._parse_html5_media_entries = ArchiveOrgIE._parse_html5_media_entries
    ie._download_json = ArchiveOrgIE._download_json
    ie.clean_html = ArchiveOrgIE.clean_

# Generated at 2022-06-24 12:04:03.893218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:06.058680
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    module = __import__('archiveorg')
    test_instance = module.ArchiveOrgIE()
    assert(test_instance.__class__.__name__ == 'ArchiveOrgIE')

# Generated at 2022-06-24 12:04:07.249088
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie


# Generated at 2022-06-24 12:04:08.934742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_instance = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:10.137289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:19.570200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    id = ie.extract_id(url)
    assert id == expected_id

    # Pass in a filename from test video.
    # It must be present in archive.org.
    filename = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect.ogg'
    info = ie.extract_video_info(filename)
    assert info['id'] == archive_video_id

# Generated at 2022-06-24 12:04:21.220055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:25.828937
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert str(info) == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-24 12:04:28.258577
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:31.665555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:04:40.437021
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert ie._TESTS[2]['only_matching'] == True
    assert ie._TESTS[3]['only_matching'] == True

# Generated at 2022-06-24 12:04:42.779455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    assert str(extractor) == extractor.IE_NAME

# Generated at 2022-06-24 12:04:44.413361
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of class ArchiveOrgIE should not fail
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:45.927288
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:04:48.984828
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_obj = ArchiveOrgIE()
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'

    assert ie_obj.suitable(url), True
    assert ie_obj._VALID_URL == ie_obj._TESTS[-1]['url'], True


# Generated at 2022-06-24 12:04:50.930036
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    IE = ArchiveOrgIE()
    IE.extract(url)

# Generated at 2022-06-24 12:04:51.552097
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:55.809219
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test class constructor
    # Note: Class constructor must be called first for __name__ module variable
    #       to be defined, so it is not duplicated here.
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') # pylint: disable=invalid-name

    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' # pylint: disable=protected-access
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' # pylint: disable=protected-access

# Generated at 2022-06-24 12:05:00.152290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	"""
	Unit test for constructor of class ArchiveOrgIE
	"""
	import archiveorg
	ArchiveOrgIE = archiveorg.ArchiveOrgIE()
	assert ArchiveOrgIE.IE_DESC == "archive.org videos"

# Test for method _real_extract()

# Generated at 2022-06-24 12:05:05.455473
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    youtube_ie = ArchiveOrgIE('archive.org')
    assert youtube_ie.IE_NAME == 'archive.org'
    assert youtube_ie.IE_DESC == 'archive.org videos'
    assert youtube_ie.VALID_URL == 'https?:\/\/(?:www\.)?archive\.org\/(?:details|embed)\/(?P<id>[^\/?#&]+)'

# Generated at 2022-06-24 12:05:07.931547
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 12:05:08.522039
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:05:10.813925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test that ArchiveOrgIE() constructor does not fail
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE(params={'add_foo': 'bar'})

# Generated at 2022-06-24 12:05:21.515747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test for constructor of class ArchiveOrgIE
    """
    IE = ArchiveOrgIE()
    assert IE.ie_key() == 'archive.org'
    assert IE.ie_desc() == 'archive.org videos'
    assert IE.is_extractable(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is True
    assert IE.is_extractable(
        'http://archive.org/details/Cops1922') is True
    assert IE.is_extractable('https://archive.org/details/Cops1922') is True
    assert IE.is_extractable(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') is True


# Generated at 2022-06-24 12:05:29.130384
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:05:31.197685
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:05:31.994707
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None

# Generated at 2022-06-24 12:05:40.544441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert isinstance(ie._VALID_URL, basestring)
    assert ie._TESTS, "Class isn't initialized properly"


# Generated at 2022-06-24 12:05:42.109137
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    A simple unit test for the ArchiveOrgIE constructor.
    """
    assert ArchiveOrgIE is not None

# Generated at 2022-06-24 12:05:43.333202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'archive.org'


# Generated at 2022-06-24 12:05:55.525055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:57.440217
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoIE = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:59.279260
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    ao.IE_NAME

# Generated at 2022-06-24 12:06:00.780558
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()


test_ArchiveOrgIE()

# Generated at 2022-06-24 12:06:01.336872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:08.628684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE
    """
    ie = ArchiveOrgIE()

    assert(ie.ie_key() == 'archive.org')
    assert(ie.ie_desc() == 'archive.org videos')
    assert(ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'))
    assert(ie.valid_url('https://archive.org/details/Cops1922'))
    assert(ie.valid_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'))

# Generated at 2022-06-24 12:06:09.487592
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:11.002838
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:06:19.195665
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE
    """
    input_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archiveorg = ArchiveOrgIE()
    #regex of archive.org
    exp_real_url = "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert_equals(archiveorg._real_extract(input_url), {'_type': 'url', 'url': exp_real_url, 'ie_key': 'ArchiveOrg'})

# Generated at 2022-06-24 12:06:24.418467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor = ArchiveOrgIE
    constructor.__name__ = 'ArchiveOrgIE'
    constructor.__doc__ = 'Archive.org videos'
    instance = constructor()
    assert isinstance(instance, InfoExtractor)
    assert instance.IE_NAME == 'archive.org'
    assert instance.IE_DESC == 'Archive.org videos'

# Generated at 2022-06-24 12:06:38.562404
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:42.931163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:46.976595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE('http://archive.org/details/')
    class_name = str(obj.__class__)
    # check if class name is defined
    print('Class: ' + class_name)
    # check if class is subclass of InfoExtractor class
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 12:06:47.787368
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:48.902374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:06:51.463737
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE([])
    except:
        print("Failed to create ArchiveOrgIE")

# Generated at 2022-06-24 12:06:55.993323
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:05.418309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    url, md5, info_dict = x._TESTS[0]['url'], x._TESTS[0]['md5'], x._TESTS[0]['info_dict']
    assert x._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'
    assert x._real_extract(url)['md5'] == md5
    assert x._real_extract(url) == info_dict

# Generated at 2022-06-24 12:07:08.278993
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Constructor test
    '''
    ie = InfoExtractor(None, {}, None)
    assert hasattr(ie, "ArchiveOrgIE")



# Generated at 2022-06-24 12:07:12.876051
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert isinstance(ie._VALID_URL, str)
    assert isinstance(ie._TESTS, list)

# Generated at 2022-06-24 12:07:24.046961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert(a.IE_NAME == 'archive.org')
    assert(a.IE_DESC == 'archive.org videos')
    assert(a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:07:28.548154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:30.628760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    wget_test = InfoExtractor(ArchiveOrgIE)
    assert 'archive.org' == wget_test.IE_NAME

# Generated at 2022-06-24 12:07:35.101816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:07:43.365608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # The purpose of this unit test is to check that the class's constructor
    # works as expected, so no need to check the other methods.
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'https')
    assert not ie.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'http')
    assert not ie.valid_url('https://google.com/', 'https')

# Generated at 2022-06-24 12:07:45.260858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == "archive.org"

# Test ArchiveOrgIE

# Generated at 2022-06-24 12:07:48.222282
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..YTB_IE import YTB_IE
    assert YTB_IE.__bases__[0] is ArchiveOrgIE
    assert ArchiveOrgIE.__bases__[0] is InfoExtractor
    


# Generated at 2022-06-24 12:07:49.187809
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:51.818933
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:53.423113
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-24 12:07:54.788343
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('https://www.google.com')

# Generated at 2022-06-24 12:08:03.289129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE with a valid URL and no URL and invalid URL
    """
    args = [
        "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
    ]
    test = list()
    # Test valid URL
    try:
        test.append(ArchiveOrgIE(*args))
    except:
        test.append(None)
    assert(test[-1] is not None)
    # Test no URL given

# Generated at 2022-06-24 12:08:04.767066
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:12.478380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    content = '<div id="videoTitle" class="section">\
<div class="box">\
<h1>Fake title of the Fake video</h1>\
<p>Video details</p>\
</div>\
</div>'
    # content.css('#videoTitle > div > h1'):
    expected_meta = {'title': 'Fake title of the Fake video'}

    assert (ArchiveOrgIE._parse_webpage(content) == expected_meta)

# Generated at 2022-06-24 12:08:16.560776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:08:17.477870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(str(ArchiveOrgIE))

# Generated at 2022-06-24 12:08:21.110810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._NAME == 'archive.org'
    assert ie._DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:22.205790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 12:08:29.802998
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'test_ArchiveOrgIE'
    ie.IE_DESC = 'test_ArchiveOrgIE'

# Generated at 2022-06-24 12:08:38.419394
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert isinstance(a, InfoExtractor)
    assert isinstance(a._VALID_URL, type(a._VALID_URL))
    assert isinstance(a.IE_NAME, type(a.IE_NAME))
    assert isinstance(a._TESTS, type(a._TESTS))
    assert isinstance(a.IE_DESC, type(a.IE_DESC))
    assert isinstance(a._match_id, type(a._match_id))
    assert isinstance(a._real_extract, type(a._real_extract))
    assert isinstance(a._download_webpage, type(a._download_webpage))
    assert isinstance(a._search_regex, type(a._search_regex))

# Generated at 2022-06-24 12:08:41.382942
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ao_ie = ArchiveOrgIE(None)
    ao_ie.url = test_url
    ao_ie._match_id = None
    ao_ie._real_extract(ao_ie.url)

# Generated at 2022-06-24 12:08:46.532543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-24 12:08:51.079263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:56.726706
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:08:57.750266
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:09:07.009287
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert obj._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert obj._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:09:10.903322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:09:11.566171
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:09:13.016656
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # should not raise
    ie = ArchiveOrgIE({})

# Generated at 2022-06-24 12:09:18.197818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    u = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    a = ArchiveOrgIE()
    assert a._match_id(u) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:09:20.274118
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:09:22.489114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:09:25.511416
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'


# Generated at 2022-06-24 12:09:28.516335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:29.338193
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-24 12:09:37.497180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	"""
	Test constructor of class ArchiveOrgIE.
	"""
	x = ArchiveOrgIE()
	assert x.toString() == "[ArchiveOrgIE: name: archive.org, description: archive.org, valid_url: r'https?://(?:www\.|static\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)']"

# Generated at 2022-06-24 12:09:38.326930
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    return

# Generated at 2022-06-24 12:09:40.373260
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert 'archive.org videos' == ie.IE_DESC

# Generated at 2022-06-24 12:09:41.462277
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(ie)

# Generated at 2022-06-24 12:09:42.973348
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = IE_TESTS['archive.org']
    ie.suite()

# Generated at 2022-06-24 12:09:51.573741
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    # testing for constructor without actions
    assert ao.ie_key() == 'ArchiveOrg'
    assert ao.ie_desc() == 'archive.org videos'
    # testing for suitable url
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ao.suitable(url) == True
    # testing for non suitable url
    url = 'https://www.archive.org/'
    assert ao.suitable(url) == False
    # testing for suitable url
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ao.suitable(url) == True

# Generated at 2022-06-24 12:09:53.102388
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:03.792691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:04.396520
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("faketype","fake id")

# Generated at 2022-06-24 12:10:12.430974
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test with a real url
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    assert ie.suitable(url) == True
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.__module__ == 'youtube_dl.extractor.archiveorg'

    # Test with a fake url
    url = 'www.fake.com'
    res = ie.suitable(url)
    assert res == False
    assert ie._VALID_

# Generated at 2022-06-24 12:10:20.341167
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # url of a video
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # create an instance of the class for the video
    instance = ArchiveOrgIE(url)

    # check the video id
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert instance.video_id == video_id

    # check the video URL
    video_url = 'http://archive.org/embed/' + video_id
    assert instance.video_url == video_url

# Generated at 2022-06-24 12:10:30.839418
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:38.706560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor.test()


# Generated at 2022-06-24 12:10:41.381989
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:52.993057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:53.940767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:11:05.766329
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:11:06.601185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:11:13.995507
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL.search('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie._VALID_URL.search('https://archive.org/embed/ProfilesInHistory2016-01-22T00:00:00-05:00/12.mp4')
    assert (ie.IE_DESC == 'archive.org videos')
    assert (ie.IE_NAME == 'archive.org')

# Generated at 2022-06-24 12:11:18.298925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE(
        downloader=None,
        url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        ie_key='ArchiveOrg')
    assert test.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:11:19.902453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:11:20.392080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:25.884385
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:33.732498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:38.644480
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    actual_url = ie._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test URL
    assert actual_url == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Test for ArchiveOrgIE extract() method

# Generated at 2022-06-24 12:11:43.395455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from utils import test_utils
    try:
        test_utils.get_testdata_video_url('XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    except:
        raise Exception("Unit test for class ArchiveOrgIE has failed")

# Generated at 2022-06-24 12:11:44.641599
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # No exception raise
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:51.649494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert ie.IE_NAME == 'archive.org'
  assert ie.IE_DESC == 'archive.org videos'
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:56.468238
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:57.781683
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:11:58.827638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)

# Generated at 2022-06-24 12:12:00.164753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This doesn't make any assertion, only construct an ArchiveOrgIE() to check its code
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:10.674620
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_DESC = "archive.org videos"
    assert ArchiveOrgIE().IE_DESC == IE_DESC
    # assert ArchiveOrgIE().IE_NAME == IE_NAME
    assert ArchiveOrgIE().IE_NAME == "archive.org"
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # assert ArchiveOrgIE()._TESTS == {
    #     'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    #     'md5': '8af1d4cf447933ed3c7f4871162602db',
    #     'info_dict': {
    #         'id

# Generated at 2022-06-24 12:12:11.981292
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie=ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:12:16.842799
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor should raise exception if invalid URL is given
    from ..exceptions import RegexNotFoundError
    with pytest.raises(RegexNotFoundError):
        ArchiveOrgIE('https://otherarchive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Constructor should not raise exception if valid URL is given
    ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
# Unit test function get_info()

# Generated at 2022-06-24 12:12:29.008578
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test with a valid url
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    extractor = ArchiveOrgIE()
    assert extractor.suitable(url)
    assert extractor.IE_NAME == 'archive.org'
    assert extractor.IE_DESC == 'archive.org videos'
    assert extractor._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # test with an invalid url
    invalid_url = "https://archive.org/search.php?query=test"
    assert not extractor.suitable(invalid_url)
    # test with a valid url which is actually an invalid url
    # this url is being

# Generated at 2022-06-24 12:12:32.234975
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:32.822446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:12:39.587921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# create instance ArchiveOrgIE
	ie = ArchiveOrgIE()
	assert(ie.IE_NAME == 'archive.org')
	assert(ie.IE_DESC == 'archive.org videos')
	assert(ie._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
	return True

# Generated at 2022-06-24 12:12:44.336467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE(None)
    assert test._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    test._VALID_URL = r"https://archive.org/details/Cops1922"
    assert test._VALID_URL == r"https://archive.org/details/Cops1922"

# Generated at 2022-06-24 12:12:47.225115
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for construcotr of class 'ArchiveOrgIE'
    """
    youtubedl_instance = YoutubeDL(params={})
    ie_instance = ArchiveOrgIE(ydl=youtubedl_instance)
    assert ie_instance.ydl == youtubedl_instance

# Generated at 2022-06-24 12:12:51.458255
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME is ArchiveOrgIE.IE_NAME



# Generated at 2022-06-24 12:13:00.020450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # constructor of ArchiveOrgIE()
    ie = ArchiveOrgIE()
    # assert that ArchiveOrgIE contains these attributes
    assert ie.IE_NAME is not None
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    # assert that ArchiveOrgIE inherits from InfoExtractor class
    assert issubclass(ArchiveOrgIE, InfoExtractor)
    # assert that ArchiveOrgIE _real_extract method is overrided
    assert ArchiveOrgIE._real_extract is not InfoExtractor._real_extract

# Generated at 2022-06-24 12:13:01.169806
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-24 12:13:05.627749
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor = ArchiveOrgIE
    # First test with valid URL
    valid_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    i = constructor(url=valid_url)
    assert(i != None)
    # Second test with invalid URL
    invalid_url = 'http://www.google.com'
    i = constructor(url=invalid_url)
    assert(i == None)

# Generated at 2022-06-24 12:13:06.328279
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:13:10.741936
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
