

# Generated at 2022-06-24 12:03:20.998200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re
    import unittest

    # Test URL of new style
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    match = re.search(ArchiveOrgIE._VALID_URL, url)
    assert match is not None, 'new style URL scheme is not compliant to the regexp'

    # Test URL of old style
    url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    match = re.search(ArchiveOrgIE._VALID_URL, url)
    assert match is not None, 'old style URL scheme is not compliant to the regexp'

    # Test bad URLs: a random string to the ID

# Generated at 2022-06-24 12:03:29.138507
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect");
    expected_IE_NAME = 'archive.org'
    assert ie.IE_NAME == expected_IE_NAME, 'expected_IE_NAME == %s but found %s' % (expected_IE_NAME, ie.IE_NAME)
    expected_IE_DESC = 'archive.org videos'
    assert ie.IE_DESC == expected_IE_DESC, 'expected_IE_DESC == %s but found %s' % (expected_IE_DESC, ie.IE_DESC)
    expected_JWP_KEY = 'JW Player'
    assert ie.JWP_KEY == expected_JWP_KEY, 'expected_JWP_KEY == %s but found %s'

# Generated at 2022-06-24 12:03:33.750765
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	test_ie = ArchiveOrgIE()
	test_ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:03:35.026253
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 1 == len(str(ArchiveOrgIE))

# Generated at 2022-06-24 12:03:40.039824
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # TODO: assert ie._TESTS == [ ... ]

# Generated at 2022-06-24 12:03:45.066809
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == True
    assert ie.valid_url('https://invalid.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == False

# Generated at 2022-06-24 12:03:50.883497
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE() constructor"""
    from youtube_dl.extractor import ArchiveOrgIE
    assert ArchiveOrgIE("archive.org", "archive.org")

# Generated at 2022-06-24 12:03:53.767931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:54.342307
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(ie)

# Generated at 2022-06-24 12:03:55.565923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:59.772263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    d = ArchiveOrgIE()
    assert d != None


# Generated at 2022-06-24 12:04:01.432450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.IE_NAME

# Generated at 2022-06-24 12:04:02.853840
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:04.962679
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE."""
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:04:10.093761
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:10.694508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:20.153413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_ArchiveOrg = ArchiveOrgIE()
    assert ie_ArchiveOrg.ie_key() == 'archive.org'
    assert ie_ArchiveOrg.ie_desc() == 'archive.org videos'
    assert ie_ArchiveOrg.is_supported(r'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie_ArchiveOrg.is_supported(r'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellectA')
    assert not ie_ArchiveOrg.is_supported(r'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:04:27.772158
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/A.Cinderella.Story.2004.1080p.BluRay.x264.DTS-FGT')
    ie.extract('http://archive.org/details/Cops1922')
    ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-24 12:04:34.877408
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert "archive.org" == ie._VALID_URL
    assert "archive.org videos" == ie._IE_DESC
    assert "archive.org" == ie._IE_NAME
    assert ie._TESTS

# Generated at 2022-06-24 12:04:37.386948
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Basic unit test to make sure that constructor of class ArchiveOrgIE doesn't fail. """
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:40.072380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    myVideo = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ArchiveOrgIE(None)._real_extract("http://archive.org/details/" + myVideo)

# Generated at 2022-06-24 12:04:42.087597
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(callable(ArchiveOrgIE))

# Generated at 2022-06-24 12:04:42.934065
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:04:52.723001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    import datetime
    t = datetime.timedelta(milliseconds=124)

# Generated at 2022-06-24 12:04:54.370982
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:55.667145
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:04:57.800954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        assert False
    except:
        assert True


# Generated at 2022-06-24 12:04:58.498452
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:05:03.612624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = ArchiveOrgIE
    info_extractor = class_()
    assert(info_extractor.IE_NAME == 'archive.org')
    assert(info_extractor.IE_DESC == 'archive.org videos')
    assert(info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:05:14.268195
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:15.581991
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-24 12:05:26.994976
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:29.868873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE("archive.org", "archive.org videos", "archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert(x.IE_NAME == "archive.org")
    assert(x.IE_DESC == "archive.org videos")

# Generated at 2022-06-24 12:05:38.006366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )

    ie = InfoExtractor()
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:40.544636
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-24 12:05:46.134898
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC = 'test'
    ie.IE_NAME = 'test'
    ie._VALID_URL = '%s://%s/%s' % (ie.ie_key(), ie.host, ie.ie_key())
    assert ie._real_extract({'url': 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'}) is not None
    assert ie._real_extract({'url': 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'}) is not None

# Generated at 2022-06-24 12:05:49.364349
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:05:54.805677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS is not None

# Generated at 2022-06-24 12:05:57.334587
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  print(ie)

# Generated at 2022-06-24 12:05:58.428926
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor = lambda: ArchiveOrgIE()

# Generated at 2022-06-24 12:06:00.909477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test for create instance of class ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    ie.extract('')


# Generated at 2022-06-24 12:06:06.766296
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor = ArchiveOrgIE
    ie = constructor('archieve.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:06:11.681456
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/Moog')
    assert ie.get_url_re() == '(?P<id>[^/?#&]+)'
    assert ie.get_url_name() == 'archive.org'
    assert ie.get_description() == 'archive.org videos'

# Generated at 2022-06-24 12:06:16.947097
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:22.928650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    classArgs = {
        'ie_key': 'ArchiveOrg',
        '_VALID_URL': ArchiveOrgIE._VALID_URL
    }
    instance = ArchiveOrgIE(**classArgs)
    assert(instance.ie_key() == 'ArchiveOrg')
    assert(instance._VALID_URL == ArchiveOrgIE._VALID_URL)

# Generated at 2022-06-24 12:06:26.036968
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test object creation
    url = 'https://archive.org/details/Cops1922'
    obj = ArchiveOrgIE(url)
    assert obj is not None
    assert obj.url == url


# Generated at 2022-06-24 12:06:26.673396
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:31.368954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:06:33.666618
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert (ArchiveOrgIE.IE_NAME == "archive.org")
    assert (ArchiveOrgIE.IE_DESC == "archive.org videos")

# Generated at 2022-06-24 12:06:37.254609
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:06:38.239614
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_kaltura import TestKalturaIE
    ie = TestKalturaIE.test_constructor(ArchiveOrgIE)

# Generated at 2022-06-24 12:06:45.089000
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert(info_extractor.IE_NAME == 'archive.org')
    assert(info_extractor.IE_DESC == 'archive.org videos')



# Generated at 2022-06-24 12:06:55.469153
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert (ArchiveOrgIE()._VALID_URL[0] == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert (ArchiveOrgIE()._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert (ArchiveOrgIE()._TESTS[1]['url'] == 'https://archive.org/details/Cops1922')
    assert (ArchiveOrgIE()._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:01.034778
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class TestArchiveOrgIE(ArchiveOrgIE):
        def __init__(self, *args, **kwargs):
            # Test the constructor of the base class
            InfoExtractor.__init__(self, *args, **kwargs)

    testarch = TestArchiveOrgIE()

    # Make sure ArchiveOrgIE is initialized
    assert testarch

    assert testarch.IE_NAME == 'archive.org'
    assert testarch.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:07:02.649850
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ''

# Generated at 2022-06-24 12:07:11.689527
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda *args, **kwargs: (
        '<div id="DIDA-48035856">Buster Keaton\'s "Cops" (1922)</div>')
    ie._parse_jwplayer_data = lambda *args, **kwargs: ({
        '_type': 'url',
        'id': 'Cops1922',
        'url': 'http://archive.org/download/Cops1922/Cops1922_512kb.mp4',
    },)
    info = ie.extract('http://archive.org/details/Cops1922')
    assert info['title'] == 'Buster Keaton\'s "Cops" (1922)'

# Generated at 2022-06-24 12:07:13.011829
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:14.881594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:17.994964
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    
    # Set dummy values and initialize the class 
    a = ArchiveOrgIE();
    # Assert a, "ArchiveOrgIE() should not be None"
    # Assert a._VALID_URL, "_VALID_URL should not be None"
    # Assert a.IE_NAME, "IE_NAME should not be None"
    
    

# Generated at 2022-06-24 12:07:19.038191
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE(None)

    assert archive_org_ie is not None

# Generated at 2022-06-24 12:07:21.642601
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor ArchiveOrgIE expects a url parameter as well.
    # Constructor of parent class InfoExtractor implicitly calls
    # _real_initialize() method of class InfoExtractor with
    # the url provided as argument to the constructor.
    IE = ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:22.443486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(ie)

# Generated at 2022-06-24 12:07:24.373772
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:07:26.478304
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == x.ie_key()
    assert x.IE_NAME == x.ie_key()

# Generated at 2022-06-24 12:07:35.228098
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    assert t.IE_NAME == "archive.org"
    assert t.IE_DESC == "archive.org videos"
    assert t._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:07:37.184779
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:07:48.724399
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test1 = ArchiveOrgIE()
    assert test1._match_id('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert test1._match_id('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert test1._valid_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:49.431293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global instance
    instance = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:53.643672
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:08:05.344330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Method to create an instance of class ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:15.503413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    instance._downloader = getattr(instance, '_downloader')
    instance._valud_url = getattr(instance, '_valud_url')
    instance._real_extract = getattr(instance, '_real_extract')
    instance._download_webpage = getattr(instance, '_download_webpage')
    instance._search_regex = getattr(instance, '_search_regex')
    instance._match_id = getattr(instance, '_match_id')
    instance._parse_jwplayer_data = getattr(instance, '_parse_jwplayer_data')
    instance._parse_html5_media_entries = getattr(instance, '_parse_html5_media_entries')

# Generated at 2022-06-24 12:08:17.009341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj


# Generated at 2022-06-24 12:08:17.917116
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:18.894142
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' in ArchiveOrgIE.IE_NAME

# Generated at 2022-06-24 12:08:22.158510
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_names = ['ArchiveOrgIE']
    assert class_names == [cls.__name__ for cls in ArchiveOrgIE.__bases__ + (ArchiveOrgIE,)]



# Generated at 2022-06-24 12:08:23.357116
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert len(ArchiveOrgIE._TESTS) > 0

# Generated at 2022-06-24 12:08:28.505383
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_obj = ArchiveOrgIE()
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie_obj.IE_NAME == 'archive.org'
    assert ie_obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:31.208425
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor, InfoExtractorException

    try:
        ArchiveOrgIE()
    except InfoExtractorException:
        pass
    #No exception must be thrown, otherwise the constructor has an error

# Generated at 2022-06-24 12:08:32.559419
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        assert True
    except:
        assert False

# Generated at 2022-06-24 12:08:34.333198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	a = ArchiveOrgIE()
	assert(a.IE_NAME == 'archive.org')

# Generated at 2022-06-24 12:08:35.949615
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:08:37.819166
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_NAME == 'archive.org'
    assert inst.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:39.358128
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Unit tests for class ArchiveOrgIE

# Generated at 2022-06-24 12:08:49.857906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from collections import OrderedDict
	from .common import InfoExtractor
	from ..utils import (
		clean_html,
		extract_attributes,
		unified_strdate,
		unified_timestamp,
	)
	try:
		from urllib.parse import urlparse
		from urllib.request import urlopen, url2pathname
		from urllib.error import URLError
	except ImportError:
		from urlparse import urlparse
		from urllib2 import urlopen, URLError
		from urllib import url2pathname
	from .common import InfoExtractor
	from ..utils import (clean_html, extract_attributes, unified_strdate, unified_timestamp)


# Generated at 2022-06-24 12:08:50.890067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:08:52.663402
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL

# Generated at 2022-06-24 12:09:00.654723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test 1
    # url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator'
    # info = ArchiveOrgIE()._real_extract(url)
    # print(info)

    # Test 2
    url = 'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator'
    info = ArchiveOrgIE()._real_extract(url)
    print(info)


# Generated at 2022-06-24 12:09:02.443032
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    loaded_constructor = True
    try:
        ArchiveOrgIE()
    except:
        loaded_constructor = False
    assert(loaded_constructor == True)

# Generated at 2022-06-24 12:09:07.696180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    import sys
    import io
    import io
    import unittest

    class ArchiveOrgIETest(unittest.TestCase):
        """Unit test case for ArchiveOrgIE"""

        def setUp(self):
            """Set up some test envrionment"""
            self.ie = ArchiveOrgIE()

        def tearDown(self):
            """Clear the test environment"""
            self.ie = None

        def test_ArchiveOrgIE_constructor(self):
            """test if the constructor works"""
            self.assertEqual(self.ie.IE_NAME, 'archive.org')
            self.assertEqual(self.ie.IE_DESC, 'archive.org videos')


# Generated at 2022-06-24 12:09:10.638540
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        print('Unit test for class ArchiveOrgIE: Success')
    except:
        print('Unit test for class ArchiveOrgIE: Fail')


# Generated at 2022-06-24 12:09:12.507120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.__class__ == ArchiveOrgIE

# Generated at 2022-06-24 12:09:15.312194
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:09:25.554366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    test_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_video_title = '1968 Demo - FJCC Conference Presentation Reel #1'
    expected_video_description = 'md5:da45c349df039f1cc8075268eb1b5c25'
    expected_video_creator = 'SRI International'
    expected_video_release_date = '19681210'
    expected_video_uploader = 'SRI International'
    expected_video_timestamp = 1268695290
    expected_video_upload_date = '20100315'
    expected_video

# Generated at 2022-06-24 12:09:26.484770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:30.155052
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
# End unit test

# Generated at 2022-06-24 12:09:41.060822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'
    assert ie.get_example_video_urls() == [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/Cops1922',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
    ]

# Generated at 2022-06-24 12:09:49.401250
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._valid_url("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect", i.IE_NAME)
    assert i._valid_url("https://archive.org/details/Cops1922", i.IE_NAME)
    assert not i._valid_url("https://archive.org/details/Cops1922/", i.IE_NAME)
    assert not i._valid_url("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/", i.IE_NAME)

# Generated at 2022-06-24 12:09:51.194081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:10:00.330094
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_ArchiveOrg= ArchiveOrgIE()
    assert IE_ArchiveOrg.name == 'archive.org'
    assert IE_ArchiveOrg.description == 'archive.org videos'
    assert "Reel #1" in IE_ArchiveOrg.extract_info(url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')['title']
    assert "Buster Keaton" in IE_ArchiveOrg.extract_info(url='https://archive.org/details/Cops1922')['title']
    assert IE_ArchiveOrg.extract_info(url='http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:04.713708
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check whether the test of ArchiveOrgIE class constructor is failed or passed
    assert ArchiveOrgIE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:10:07.549053
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == 'archive.org'
    assert archive_org_ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:10.834674
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE();
    assert archive_org_ie.IE_NAME == "archive.org"
    assert archive_org_ie.IE_DESC == "archive.org videos"


# Generated at 2022-06-24 12:10:14.480798
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archiveorg:XD300-23_68HighlightsAResearchCntAugHumanIntellect' )
    ie.get_info('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:16.364206
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Simple check the module exists
    ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:10:18.005962
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test for class ArchiveOrgIE"""
    ArchiveOrgIE(IE_NAME)

# Generated at 2022-06-24 12:10:18.943520
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:20.378539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None

# Generated at 2022-06-24 12:10:23.445940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:25.281566
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie =  ArchiveOrgIE()
    pass


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:10:36.089828
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:37.991085
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:43.479118
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.embed_webpage

# Generated at 2022-06-24 12:10:47.466652
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:57.314977
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')
    assert(ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:10:59.630360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE('https://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:11:11.602849
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:11:15.920030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:11:23.651810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''Test ArchiveOrgIE'''
    # Get the instance of ArchiveOrgIE
    archiveOrg = ArchiveOrgIE()

    # Check the parser

# Generated at 2022-06-24 12:11:30.870838
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert issubclass(ArchiveOrgIE, InfoExtractor)
    assert issubclass(ArchiveOrgIE, YoutubePlaylistBaseInfoExtractor)
    assert issubclass(ArchiveOrgIE, JWPlatformIE)
    assert issubclass(ArchiveOrgIE, Html5BaseIE)

# Generated at 2022-06-24 12:11:31.690285
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:34.891454
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:11:35.845691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorgIE = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:46.042671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == "archive.org"
    assert obj.IE_DESC == "archive.org videos"
    assert obj._VALID_URL == r"https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert obj._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert obj._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"
    # Verify that the constructor is private
    try:
        ArchiveOrgIE.__init__()
    except AttributeError as e:
        pass

# Generated at 2022-06-24 12:11:50.704076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.ie_key() == 'archive.org'
    assert inst.ie_desc() == 'archive.org videos'
    assert inst._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:59.395499
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_urls = (
        'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator',
        'http://archive.org/details/Cops1922',
        'https://archive.org/details/Cops1922',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    )
    for url in test_urls:
        ie = ArchiveOrgIE()
        ie.extract(url)

# Generated at 2022-06-24 12:12:01.681646
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (ie.IE_NAME == 'archive.org')



# Generated at 2022-06-24 12:12:10.627298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert isinstance(ie, ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_DOWNLOAD_URL')
    assert hasattr(ie, '_WORKING')
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, 'IE_DESC')
    assert hasattr(ie, '_downloader')
    assert hasattr(ie, '_download_webpage_handle')
    #assert hasattr(ie, 'su')

# Generated at 2022-06-24 12:12:13.353812
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == "archive.org"
    assert ArchiveOrgIE().ie_name() == "archive.org videos"
    assert ArchiveOrgIE().ie_description() == "archive.org videos"
    assert ArchiveOrgIE().can_handle_url("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:12:14.926409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    # Assert that ArchiveOrgIE is an instance of InfoExtractor
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-24 12:12:16.062082
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of class should not raise any exception
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:24.008284
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Create a :class:`ArchiveOrgIE` instance and verify that it works.
    """
    ie = ArchiveOrgIE()
    info = ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['ext'] == 'ogg'

# Generated at 2022-06-24 12:12:25.327976
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:33.919691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:44.615511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:49.092233
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:54.464437
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:13:02.160557
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(1)
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie.ie_key() == 'archive.org'
    assert ie.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')


# Generated at 2022-06-24 12:13:04.503595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:13:14.583178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_class=ArchiveOrgIE()
    assert test_class._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert test_class._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert test_class._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert test_class._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'