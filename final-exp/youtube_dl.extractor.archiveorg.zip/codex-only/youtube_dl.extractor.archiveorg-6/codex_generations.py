

# Generated at 2022-06-24 12:03:18.672422
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:25.288095
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:03:27.271173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL



# Generated at 2022-06-24 12:03:28.163208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-24 12:03:29.132752
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:33.316391
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:03:35.107236
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:03:35.628766
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:38.634020
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:03:42.628617
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Tests ArchiveOrgIE constructor.
    """
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org', 'ie_key() is incorrect'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('https://archive.org/details/Cops1922')
    assert ie.valid_url('https://archive.org/embed/Cops1922')
    assert not ie.valid_url('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-24 12:03:50.519083
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    for url in [
      'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
      'https://archive.org/details/Cops1922',
      'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
      'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    ]:
        ie.suitable(url)

# Generated at 2022-06-24 12:03:54.624067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert hasattr(ArchiveOrgIE(), 'IE_NAME')
    assert hasattr(ArchiveOrgIE(), 'IE_DESC')
    assert hasattr(ArchiveOrgIE(), '_VALID_URL')


# Generated at 2022-06-24 12:04:04.302726
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:04:10.677702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: move this to a unit test
    from .youtube import YoutubeIE
    # Test class initialisation without embedding and with embedding
    with YoutubeIE.ie_key():
        archive_org_ie = YoutubeIE(False)._get_ie(ArchiveOrgIE.ie_key())
        assert archive_org_ie.name == ArchiveOrgIE.IE_NAME
        assert archive_org_ie.description == ArchiveOrgIE.IE_DESC
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.name == ArchiveOrgIE.IE_NAME
    assert archive_org_ie.description == ArchiveOrgIE.IE_DESC

# Generated at 2022-06-24 12:04:13.513723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert(IE.IE_NAME == 'archive.org')
    assert(IE.IE_DESC == 'archive.org videos')
    assert(IE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:04:21.896884
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Set up an instance of the IE for testing purposes.
    ie = ArchiveOrgIE()

    # Test the regex pattern on a url to an .ogg file.
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # Test the regex pattern on a url to an embed page.
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # Test the regex pattern on a url to an .mp4 file.
   

# Generated at 2022-06-24 12:04:23.542548
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:24.897062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:04:26.165200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:39.785958
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:04:42.380326
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test._assertClass(ArchiveOrgIE)
# Unit tests for _real_extract method of class ArchiveOrgIE

# Generated at 2022-06-24 12:04:43.466578
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-24 12:04:44.880789
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:48.958638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    a.to_screen("Testing constructor of class ArchiveOrgIE")
    assert isinstance(a, ArchiveOrgIE)


# Generated at 2022-06-24 12:04:49.854256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:50.715177
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' in ArchiveOrgIE.ie_keywords()


# Generated at 2022-06-24 12:05:01.881831
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

    assert obj.ie_key() == 'archive.org'

    assert obj.ie_name() == 'archive.org videos'

    # Ensure re.compile is called only once
    assert obj._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:05:12.788723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:05:14.264717
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:05:26.210706
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    # test for _VALID_URL
    assert instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

    # test for _TESTS
    assert len(instance._TESTS) == 4
    test = instance._TESTS[0]

    # test for _TEST `url`
    assert test['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # test for _TEST `md5`
    assert test['md5'] == '8af1d4cf447933ed3c7f4871162602db'

    # test for _TEST `info_dict`

# Generated at 2022-06-24 12:05:27.809898
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for correct import of ArchiveOrgIE
    archiveOrgIE = ArchiveOrgIE([])

# Generated at 2022-06-24 12:05:30.012200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:31.167545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:05:38.504927
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie_info = ie._real_extract(url)
    assert ie_info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie_info['title'] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert ie_info['description'] == "md5:da45c349df039f1cc8075268eb1b5c25"
    assert ie_info['creator'] == 'SRI International'
    assert ie_info['release_date'] == '19681210'
    assert ie_info['uploader'] == 'SRI International'

# Generated at 2022-06-24 12:05:46.047303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:47.921701
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE.VALID_URL

# Generated at 2022-06-24 12:05:57.622208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:02.732721
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_class = ArchiveOrgIE()
    assert test_class.IE_NAME == 'archive.org'
    assert test_class.IE_DESC == 'archive.org videos'
    assert test_class._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:07.200280
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.get_info_extractors() != None

# Generated at 2022-06-24 12:06:17.470255
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # json url is hardcoded
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)
    assert ie.url == url, "Failed to test ArchiveOrgIE constructor."
    assert ie.url.find('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') != -1, "Failed to test ArchiveOrgIE constructor."
    assert ie.url.find('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 0, "Failed to test ArchiveOrgIE constructor."

# Generated at 2022-06-24 12:06:18.349473
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:22.819459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'



# Generated at 2022-06-24 12:06:23.677182
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:06:24.219368
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    main()

# Generated at 2022-06-24 12:06:27.744106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Reconstitute a valid ArchiveOrgIE object."""
    ie = ArchiveOrgIE('archive.org')
    assert str(ie) == 'archive.org videos'

# Generated at 2022-06-24 12:06:31.875289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._VALID_URL == ie._TESTS[1]['url']

# Generated at 2022-06-24 12:06:32.488265
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:34.761822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Arrange
    # Act
    from .. import ArchiveOrgIE
    # Assert


# Generated at 2022-06-24 12:06:40.716402
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    test_url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    result = ie.suitable(test_url)
    assert result, "ArchiveOrgIE: URL should be valid"
    result = ie.extract(test_url)
    assert result, "ArchiveOrgIE: URL should return a dict"

# Generated at 2022-06-24 12:06:41.293349
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:06:46.899188
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS

# Generated at 2022-06-24 12:06:57.733565
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:08.996290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:11.661299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from six import assertRaisesRegex

    assertRaisesRegex(Exception, "this constructor expect to receive a URL",
                      ArchiveOrgIE, None)

# Generated at 2022-06-24 12:07:16.737951
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE({})
    assert archiveorg.IE_NAME == 'archive.org'
    assert archiveorg.IE_DESC == 'archive.org videos'
    assert archiveorg._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:17.548906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:24.113632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Test basic constructor
    ie1 = ArchiveOrgIE()

    # Test constructor by url
    ie2 = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test constructor by regex
    ie3 = ArchiveOrgIE(_VALID_URL)

    # Test if IEs have the same class type
    assert(type(ie1) == type(ie2) == type(ie3))

# Generated at 2022-06-24 12:07:25.819185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:31.402918
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoe = ArchiveOrgIE(None)
    assert aoe is not None

# Generated at 2022-06-24 12:07:39.096398
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    md5 = '22d61315f8d7cf1aa2a94ca7c3e3d836'
    ie.match(url)  # should not raise
    info = ie.download(url)
    assert info['md5'] == md5
    assert info['title'] == 'To Catch a Predator'
    assert info['creator'] == 'MSNBC'
    assert info['release_date'] == '20131101'



# Generated at 2022-06-24 12:07:39.769059
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:07:41.376928
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:07:51.415624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE constructor
    """
    class TestClass:
        """
        Class to be used in the test.
        """
        def __init__(self, kwargs, *args, **kwargs2):
            """
            Constructor of the test class

            kwargs: Keyword arguments to be passed to constructor
            """
            self.assertEqual(len(args), 0)
            assert isinstance(kwargs, dict)
            assert isinstance(kwargs2, dict)
            self.assertEqual(kwargs, kwargs2)
            self.assertTrue('class_' in kwargs)
            self.assertEqual(kwargs['class_'], TestClass)
            self.assertNotIn('name', kwargs)
            self.assertTrue('ie' in kwargs)
           

# Generated at 2022-06-24 12:08:01.977217
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor, expected_warnings

    ie = InfoExtractor(
        { 'params': {} },
        'https://archive.org/details/Cops1922',
    )
    assert ie.suitable(
        'https://archive.org/details/Cops1922'
    )
    # test_ArchiveOrgIE() calls test_suitable()
    with expected_warnings(['require additional configuration']):
        ie.test_suitable('https://archive.org/details/Cops1922')
    assert ie.suitable(
        'https://archive.org/details/Cops1922/'
    )
    assert not ie.suitable(
        'https://archive.org/'
    )

# Generated at 2022-06-24 12:08:02.653989
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ArchiveOrgIE

# Generated at 2022-06-24 12:08:14.178027
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    archive_org = ArchiveOrgIE(url)
    assert archive_org.IE_NAME == 'archive.org'
    assert archive_org.IE_DESC == 'archive.org videos'
    assert archive_org._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:18.667105
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL\
        == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:19.743443
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org videos')

# Generated at 2022-06-24 12:08:22.459562
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    fail_param = {}
    ie = ArchiveOrgIE(fail_param)
    ie.prepare()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == u'archive.org videos'


# Generated at 2022-06-24 12:08:25.128565
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE."""
    url = 'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # Test constructor of class ArchiveOrgIE
    archive_org_ie = ArchiveOrgIE(url)

# Generated at 2022-06-24 12:08:28.593350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert ie.IE_NAME == 'archive.org'
	assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:08:29.857228
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # instantiation of ArchiveOrgIE class
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:38.450047
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/Cops1922'
    obj = ArchiveOrgIE()
    assert(obj is not None)
    assert(obj._VALID_URL == '^https?://(?:www\\.)?archive\\.org/(?:details|embed)/([^/?#&]+)$')

# Generated at 2022-06-24 12:08:39.141217
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:08:46.294988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    yt = ArchiveOrgIE()
    yt._download_json = lambda url, video_id, query: {'metadata': {}}
    yt._parse_html5_media_entries = lambda url, webpage, video_id: [{}]
    yt._parse_jwplayer_data = lambda data, video_id, base_url: {'_type': 'playlist'}
    yt._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:47.045951
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:47.683668
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:55.511960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    # These data change often, so I can't predict their exact values to check them.
    # A large number of edge cases are covered in ./test/test_archiveorg.py
    #assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    #assert ie._TESTS == [{
    #    'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    #    'md5': '8af1d4cf447933ed3c7f4871162602db',


# Generated at 2022-06-24 12:09:07.616780
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # valid urls
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('https://archive.org/details/Cops1922')
    assert ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('http://archive.org/details/Cops1922')

    # url without id
    assert not ie.suitable('http://archive.org/details/')
    assert not ie.suitable('http://archive.org/details')
    assert not ie.suitable('http://archive.org/details/abc')

    # invalid urls
    assert not ie.suitable

# Generated at 2022-06-24 12:09:11.409886
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == '__main__':
        extractor = ArchiveOrgIE()
        assert extractor

# Generated at 2022-06-24 12:09:22.210113
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').IE_NAME == 'archive.org'
    assert ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/').IE_NAME == 'archive.org'
    assert ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').IE_NAME == 'archive.org'
    assert ArchiveOrgIE('archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:30.906639
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:09:34.520392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie)


# Generated at 2022-06-24 12:09:38.005511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_NAME == 'archive.org'
    assert inst.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:09:42.472767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert(ie.IE_NAME == 'archive.org');
    assert(ie.IE_DESC == 'archive.org videos');
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)');

# Generated at 2022-06-24 12:09:49.250736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This test should fail without --refetch, since the JSON file
    # requested from archive.org has been modified in the past to
    # return an empty object.
    #
    # With --refetch it should work as expected, retrieving the
    # right JSON file.
    # # TODO: move back to tests once #1034 is fixed
    ArchiveOrgIE()._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:09:51.762225
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:09:52.483617
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:53.157762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:56.080486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:58.964939
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:09:59.370996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:02.970690
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:04.304989
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:07.202493
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE('http://archive.org/')
    except Exception as e:
        raise AssertionError('Constructor of ArchiveOrgIE failed: %s' % str(e))

# Generated at 2022-06-24 12:10:09.281743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #Prototype of ArchiveOrgIE has no explicit constructor
    a = ArchiveOrgIE()


# Generated at 2022-06-24 12:10:10.921575
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_obj = ArchiveOrgIE()
    assert ie_obj

# Generated at 2022-06-24 12:10:21.041104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL[0] == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:26.622480
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:27.992326
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('')

# Generated at 2022-06-24 12:10:32.698421
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"


# Generated at 2022-06-24 12:10:33.892396
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-24 12:10:37.486734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__module__ == 'youtube_dl.extractor.archiveorg'
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:42.780959
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:54.291448
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # ensure we are able to get the list of formats by only supplying the video ID
    video_id = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    info = ArchiveOrgIE(None)._real_extract(video_id)
    info = ArchiveOrgIE(None)._real_extract("http://archive.org/details/" + video_id)
    assert info["id"] == video_id
    assert info["title"] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'

# Generated at 2022-06-24 12:10:59.475373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:01.620302
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE().IE_NAME
    assert 'archive.org videos' == ArchiveOrgIE().IE_DESC

# Generated at 2022-06-24 12:11:04.636571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE(test_url)

# Generated at 2022-06-24 12:11:06.384746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:11:13.817502
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.html_attributes == ('width', 'height')

# Generated at 2022-06-24 12:11:16.897225
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = "http://archive.org/details/file"
    ie = ArchiveOrgIE()
    print("%s: %s" % (ie._VALID_URL, test_url))
    assert ie._VALID_URL.match(test_url)

# Generated at 2022-06-24 12:11:26.167969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = ArchiveOrgIE
    from .common import InfoExtractor
    EE = class_
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = class_(InfoExtractor())
    assert isinstance(ie, EE)
    print(class_.__module__)
    print(InfoExtractor.__module__)
    assert EE.__module__.startswith(InfoExtractor.__module__)
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.ie_description() == 'archive.org videos'

# Generated at 2022-06-24 12:11:28.604495
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Some tests (mostly the first one) here are wrong. They are here just to not break tests and should be fixed or removed.
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:11:29.347951
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:40.312789
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:11:41.172113
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''Test constructor of ArchiveOrgIE'''
    assert ArchiveOrgIE != None

# Generated at 2022-06-24 12:11:50.115906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:51.990165
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None, None)
    except:
        pass
    else:
        assert False

# Generated at 2022-06-24 12:11:54.372661
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import IPython
        IPython.embed()
    except ImportError:
        pass


# Generated at 2022-06-24 12:12:00.231002
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # files in /tests/data that are used for testing
    test_files = [
        u'68HighlightsAResearchCntAugHumanIntellect.ogv',
        u'Cops1922.mp4',
        u'MSNBCW_20131125_040000_To_Catch_a_Predator',
        u'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ]
    for file in test_files:
        assert ArchiveOrgIE(file).IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:01.015345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:05.105953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Unit test for constructor of class ArchiveOrgIE
    # It tests by checking the class name of the ie instance
    ie = ArchiveOrgIE()
    assert (ie.__module__ + '.' + ie.IE_NAME) == ArchiveOrgIE.__module__ + '.' + ArchiveOrgIE.IE_NAME

# Generated at 2022-06-24 12:12:06.481930
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL



# Generated at 2022-06-24 12:12:07.956889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:12:09.869498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    return 0

# Unit test to automatically test each method in the class ArchiveOrgIE

# Generated at 2022-06-24 12:12:13.272387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE."""
    my_test = ArchiveOrgIE()
    if my_test:
        print("Unit test for constructor of class ArchiveOrgIE: OK")
    else:
        print("Unit test for constructor of class ArchiveOrgIE: FAIL")

# Generated at 2022-06-24 12:12:14.768055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:15.161743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()

# Generated at 2022-06-24 12:12:15.817446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:18.095313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:12:25.374227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    parser = ArchiveOrgIE()
    assert parser.IE_NAME == 'archive.org'
    assert parser.IE_DESC == 'archive.org videos'
    assert parser._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # assert len(parser._TESTS) == 3


# Generated at 2022-06-24 12:12:33.950569
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie._match_id(url)
    websitepage = ie._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)

    playlist = None
    play8 = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', websitepage,
        'playlist', default=None)
    if play8:
        attrs = extract_attributes(play8)
        playlist = attrs.get('value')

# Generated at 2022-06-24 12:12:39.143380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # No error raised when constructed with url and base url
    ArchiveOrgIE('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-24 12:12:44.267377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:53.338687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    assert aorg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:55.834173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Unit test for constructor of class ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 12:13:02.386338
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor_test(ArchiveOrgIE, {
        'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    }, expected_status=False)

# Generated at 2022-06-24 12:13:03.492592
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()

# Generated at 2022-06-24 12:13:04.865860
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tester = ArchiveOrgIE()
    assert tester is not None

# Generated at 2022-06-24 12:13:14.701826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE()
    o.IE_DESC 
    o.IE_NAME
    o.IE_VERSION
    o.IE_DESC
    o._VALID_URL
    o.add_ie()
    o.ie_key()
    o.extract()
    o.suitable()
    o.working
    o.webpage_url_basename()
    o.working 
    o.add_ie()
    o.ie_key()
    o._real_extract()
    o._download_webpage()
    o._parse_webpage()
    o._download_json()
    o._search_regex()
    o._og_search_title()
    o._og_search_description()
    o._og_search_thumbnail()
    o._html_search_meta