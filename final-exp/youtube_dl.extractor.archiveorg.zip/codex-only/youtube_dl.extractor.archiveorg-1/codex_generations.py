

# Generated at 2022-06-24 12:03:16.542485
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_download_webpage')
    assert hasattr(ie, '_match_id')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:03:17.896058
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(downloader=None)
    assert ie.name == 'archive.org'

# Generated at 2022-06-24 12:03:21.893809
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:23.623159
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:03:31.239133
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert ie._

# Generated at 2022-06-24 12:03:32.344036
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()

# Generated at 2022-06-24 12:03:41.672543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    # If you want to run tests with the test data from archive.org
    # you can use the lines below (but you need to be connected to the internet)
    #ie = ArchiveOrgIE('http://archive.org')
    #internet.set_user_agent('TestUserAgent')
    #internet.set_proxy('http://127.0.0.1:8118')
    #internet._custom_http_header['Host'] = 'archive.org'
    #internet._custom_http_header['User-Agent'] = 'TestUserAgent'
    #internet.options.set('proxy', 'http://127.0.0.1:8118')

    # a simple test for the constructor of ArchiveOrgIE

# Generated at 2022-06-24 12:03:43.316571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:03:52.805966
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:00.965518
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:09.503819
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_NAME == 'archive.org'
    assert inst.IE_DESC == 'archive.org videos'
    assert inst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:10.510522
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:12.519331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:15.728798
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-24 12:04:17.759770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Basic test for instantiating ArchiveOrgIE subclass
    ie = ArchiveOrgIE()
    assert ie.SUFFIX == 'archive.org'



# Generated at 2022-06-24 12:04:25.362834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Method to test the constructor of the ArchiveOrgIE class.
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:32.527747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from unittest import mock
        import sys
        ArchiveOrgIE._download_json = mock.Mock(return_value={'metadata': {}})
        sys.modules['jwplatform'] = mock.Mock()
    except ImportError as e:
        print('Failed to import module:', e)
        return
    
    ArchiveOrgIE._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    Archive

# Generated at 2022-06-24 12:04:40.870309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:50.573703
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.name == 'archive.org'
    assert ie.url == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.valid_url == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.valid_url_regex == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Unit test that the test_ArchiveOrgIE is working properly

# Generated at 2022-06-24 12:04:52.413119
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check that ArchiveOrgIE calls the ArchiveOrgIE constructor
    # assert ArchiveOrgIE.__init__([])
    return ArchiveOrgIE()

# Generated at 2022-06-24 12:04:58.897284
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:12.517956
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    m = ArchiveOrgIE._VALID_URL.search(url)
    video_id = m.group('id')
    webpage = 'http://archive.org/embed/' + video_id
    playlist = '<div class=\'js-play8-playlist\' data-videoid=\'%s\' value=\'[{"sources":[{"default":true,"file":"https://archive.org/download/%s/%s_512kb.mp4"}]}]\'></div>' % (video_id, video_id, video_id)

# Generated at 2022-06-24 12:05:18.775218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS != None


# Generated at 2022-06-24 12:05:21.020388
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(ArchiveOrgIE)

# Generated at 2022-06-24 12:05:27.190275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	
	# Confirm that the test constructor does not throw an exception
	ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-24 12:05:31.308136
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    assert result.IE_NAME == 'archive.org'
    assert result.IE_DESC == 'archive.org videos'
    assert result._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert result.__class__.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-24 12:05:35.789314
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(ie._download_webpage('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'))
    print(ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'))

# Generated at 2022-06-24 12:05:44.856864
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.downloader.http import HttpFD
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:50.674298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:51.672263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-24 12:05:53.319698
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    instance.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:06:01.673923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_obj = ArchiveOrgIE()
    assert ie_obj.IE_NAME == 'archive.org'
    assert ie_obj.IE_DESC == 'archive.org videos'
    assert ie_obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:03.851925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert ie.ie_key() == 'archive.org'
	assert ie.ie_desc() == 'archive.org videos'


# Generated at 2022-06-24 12:06:08.116103
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if not isinstance(ie, InfoExtractor):
        raise TypeError('object not an instance of InfoExtractor')


# Generated at 2022-06-24 12:06:18.453024
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    from ..compat import compat_str
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    from .youtube import YoutubeIE

    # Check that archive.org does not match as youtube
    ie = InfoExtractor._get_info_extractor('youtube')
    assert(isinstance(ie, YoutubeIE))
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert(not ie._match_id(url))
    # Check that archive.org does match and is the right class
    ie = InfoExtractor._get_info_extractor('archive.org')
    assert(isinstance(ie, ArchiveOrgIE))
    assert(ie._match_id(url))

# Generated at 2022-06-24 12:06:28.603740
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-24 12:06:32.755433
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:06:33.712096
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-24 12:06:44.385726
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.ie_name() == 'archive.org'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.valid_url('http://www.archive.org/')
    assert not ie.valid_url('http://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.valid_url('ftp://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:06:54.707814
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:04.537658
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert ArchiveOrgIE._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ArchiveOrgIE._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"
    assert ArchiveOrgIE._TESTS[0]["info_dict"]["id"] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ArchiveOrgIE._TESTS[0]["info_dict"]["ext"] == "ogg"
    assert Archive

# Generated at 2022-06-24 12:07:06.672745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():  # noqa
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:07.779737
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:19.397841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    url = 'http://archive.org/details/MyVideo'
    id = 'MyVideo'
    match = archive._match_id(url)
    assert match == id

    url = 'http://archive.org/embed/MyVideo'
    match = archive._match_id(url)
    assert match == id

    url = 'https://archive.org/details/MyVideo'
    match = archive._match_id(url)
    assert match == id

    url = 'http://www.archive.org/embed/MyVideo'
    match = archive._match_id(url)
    assert match == id

    url = 'http://archive.org/embed/MyVideo?start=50'
    match = archive._match_id(url)
    assert match == id


# Generated at 2022-06-24 12:07:22.369345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = "TEST"
    ie.IE_DESC = "TEST"

# Generated at 2022-06-24 12:07:32.101722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    import types

    if sys.version_info.major == 2:
        def new_class(name, *args, **kwargs):
            return types.ClassType(name, *args, **kwargs)
    else:
        def new_class(name, *args, **kwargs):
            return type(name, *args, **kwargs)

    ArchiveOrgIE.__name__ = 'ArchiveOrgTest'
    ie = new_class('ArchiveOrgTest',
        (ArchiveOrgIE,),
        {'_VALID_URL': ArchiveOrgIE._VALID_URL})()


# Generated at 2022-06-24 12:07:32.709769
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:36.887691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	ie = ArchiveOrgIE(url)
	assert ie.__class__.__name__ == 'ArchiveOrgIE'


# Generated at 2022-06-24 12:07:48.336903
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class fake_info:
        def __init__(self):
            self.title = None
            self.description = None
            self.creator = None
            self.release_date = None
            self.uploader = None
            self.timestamp = None
            self.upload_date = None
            self.language = None
    class fake_webpage:
        def __init__(self):
            self.title = None
    class fake_metadata:
        def __init__(self):
            self.title = None
            self.description = None
            self.creator = None
            self.date = None
            self.publisher = None
            self.publicdate = None
    class fake_jwplayer_data:
        def __init__(self):
            self.duration = None
            self.thumbnail = ''
            self

# Generated at 2022-06-24 12:07:50.351033
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.ie_key() == 'ArchiveOrg'


# Generated at 2022-06-24 12:07:58.595118
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    archiveOrgIE = ArchiveOrgIE(url)
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:08:02.682441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:08:03.576826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    assert test != None

# Generated at 2022-06-24 12:08:09.841140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?:\/\/(?:www\.)?archive\.org\/(?:details|embed)\/(?P<id>[^/?#&]+)'
    return

# Generated at 2022-06-24 12:08:20.465467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert str(ie._VALID_URL) == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:27.544970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    archiveOrgIE = ArchiveOrgIE()
    archiveOrgIE._download_webpage = lambda url, video_id: None
    archiveOrgIE._parse_html5_media_entries = lambda url, webpage, video_id: None
    archiveOrgIE._parse_jwplayer_data = lambda jwplayer_data, video_id: None
    archiveOrgIE._real_extract(url)

# Generated at 2022-06-24 12:08:32.474559
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # This should be the class name of IE
    assert ie.ie_key() == 'ArchiveOrg'

    # This should be the internal name of IE
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:33.056384
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:08:36.943733
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:38.326145
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE("")
    assert(type(test_obj) == ArchiveOrgIE)


# Generated at 2022-06-24 12:08:39.750591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:40.348276
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:08:41.117790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    test1 = ArchiveOrgIE()
    assert test1


# Generated at 2022-06-24 12:08:51.285923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:02.439164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .generic_extractor import GenericIE
    from .archiveorg import ArchiveOrgIE
    from .youtube import YoutubeIE
    from .vimeo import VimeoIE
    from .youtube_dl.extractor.archiveorg import (
        _VALID_URL as ArchiveOrgIE_VALID_URL,
        _is_valid as ArchiveOrgIE_is_valid,
    )
    from .youtube_dl.extractor.vimeo import (
        _VALID_URL as VimeoIE_VALID_URL,
        _is_valid as VimeoIE_is_valid,
    )
    from .youtube_dl.extractor.youtube import (
        _VALID_URL as YoutubeIE_VALID_URL,
        _is_valid as YoutubeIE_is_valid,
    )

    # set up

# Generated at 2022-06-24 12:09:05.194558
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test the constructor of ArchiveOrgIE
    """
    base_url = 'http://archive.org/details/'
    archiveorg_ie = ArchiveOrgIE(base_url)
    return archiveorg_ie

# Generated at 2022-06-24 12:09:10.847841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:18.882495
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()

    test._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    test._real_extract('http://archive.org/details/Cops1922')
    test._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    test._real_extract('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-24 12:09:23.757479
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import IPython
        if IPython.get_ipython():
            # Prevent IPython from creating an ipython session while
            # Importing this module
            IPython.embed = lambda: None
    except ImportError:
        pass
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:31.954386
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_DESC == 'archive.org videos'
    assert obj.IE_NAME == 'archive.org'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert obj._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:09:33.146892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:41.586119
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:09:43.802624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert issubclass(ArchiveOrgIE, InfoExtractor)


# Generated at 2022-06-24 12:09:53.358116
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Test whether test case list is not empty
    assert ie._TESTS

    # Test download of a sample video
    ie.download("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # Test download of a sample video
    ie.download("https://archive.org/details/Cops1922")
    # Test whether test case list is not empty
    test_cases = ie.get_testcases()

# Generated at 2022-06-24 12:09:56.263594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from tests.test_archiveorg import TestArchiveOrgIE

    TestArchiveOrgIE.test_ArchiveOrgIE()


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:10:02.173093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Test constructor and get_info()
    '''
    import time
    import xml.dom.minidom
    class TestIO:
        def __init__(self, content_filename, content):
            self.content_filename = content_filename
            self.content = content
        def __enter__(self):
            self.f = open(self.content_filename, 'wb')
            self.f.write(self.content)
            self.f.flush()
        def __exit__(self, type, value, traceback):
            self.f.close()


# Generated at 2022-06-24 12:10:11.351408
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [(ArchiveOrgIE, "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"),
                  (ArchiveOrgIE, "https://archive.org/details/Cops1922"),
                  (ArchiveOrgIE, "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"),
                  (ArchiveOrgIE, "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")]
    for test in test_cases:
        assert test[0]().IE_NAME == test[0].__name__.split('.')[-1]
        assert test[0]().IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:10:12.480412
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:10:18.467466
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Consider that the tests are updated, _TESTS variable is not updated
    # assert ie._TESTS == []

# Generated at 2022-06-24 12:10:23.246498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    yield assert_raises, 'parse_jwplayer_data() takes at least 3 arguments (2 given)', ArchiveOrgIE

# Generated at 2022-06-24 12:10:32.176675
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [IE]
    extracted_entries = []
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    for ie in test_cases:
        ie = ie()
        extracted_entry = ie.extract(url)
        extracted_entries.append(extracted_entry)
    assert extracted_entries[0].get('title') == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert extracted_entries[0].get('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert extracted_entries[0].get('creator') == 'SRI International'
    assert extracted_entries[0].get('uploader') == 'SRI International'

# Generated at 2022-06-24 12:10:41.688640
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of class ArchiveOrgIE requires youtube-dl version >= 2014.02.18
    # So we check if class ArchiveOrgIE's constructor raises an exception.
    import youtube_dl
    import sys
    if sys.version_info[0] == 2:
        import sys
        reload(sys)
        sys.setdefaultencoding('utf8')
    assert youtube_dl.version.__version__ >= '2014.02.18'
    assert 'ArchiveOrgIE' in youtube_dl.list_extractors()
    assert ArchiveOrgIE is not None
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:47.213973
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:50.654366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    res = ArchiveOrgIE()
    assert res.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:53.083947
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tester = ArchiveOrgIE()
    assert tester.get_info_extractor.__name__ == '_real_extract_info'

# Generated at 2022-06-24 12:11:05.024228
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:08.197364
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # test the contents of IE_NAME
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:11:09.199938
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.set_downloader(None) # A hack to make sure unit tests doesn't fail

# Generated at 2022-06-24 12:11:09.855940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:11:10.885264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:11:12.519473
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check that we can create an ArchiveOrgIE instance
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:18.071303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ao_ie = ArchiveOrgIE(url)
    assert ao_ie.url == url
    assert ao_ie.test_url == url
    assert ao_ie.IE_NAME == 'archive.org'
    assert ao_ie.IE_DESC == 'archive.org videos'


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:19.870722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:27.944560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:36.950043
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of class ArchiveOrgIE
    TestArchiveOrgIE = type(
        'TestArchiveOrgIE',
        (ArchiveOrgIE,),
        {'_parse_json': lambda s, x, y: y,
         '_download_json': lambda s, x, y, z: y}
    )
    # Test ArchiveOrgIE._parse_json
    assert TestArchiveOrgIE._parse_json({}, '') == ''
    # Test constructor of ArchiveOrgIE
    Testie = TestArchiveOrgIE('')
    # Test ArchiveOrgIE._download_json
    Testie._download_json(None, "", None)

# Generated at 2022-06-24 12:11:39.056108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:11:42.282319
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    sample_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    temp = ArchiveOrgIE._real_extract(ArchiveOrgIE(), sample_url)
    assert(temp['uploader'] == 'SRI International')
    assert(temp['title'] == "1968 Demo - FJCC Conference Presentation Reel #1")
    assert(temp['creator'] == 'SRI International')

# Generated at 2022-06-24 12:11:46.369108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test a unit of ArchiveOrgIE
    assert str(ArchiveOrgIE) == 'archive.org: Archive.org videos'
    assert isinstance(ArchiveOrgIE, InfoExtractor)
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:11:48.322675
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:52.071027
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Test that the constructor of class ArchiveOrgIE
    '''
    # Multiple instances
    ArchiveOrgIE()
    ArchiveOrgIE()
    return


if __name__ == '__main__':
    # Unit test for ArchiveOrgIE
    print(test_ArchiveOrgIE())

# Generated at 2022-06-24 12:11:55.794534
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    (archiveorgie, archiveorgie_url) = test_ArchiveOrgIE.archiveorgie_init()
    archiveorgie
    assert archiveorgie_url == 'https://www.archive.org/details/Test'


# Generated at 2022-06-24 12:11:56.675297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:05.112441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def runCheck(check, url, expectedResult):
        assert check(ArchiveOrgIE, url), '{0} failed'.format(url)
        assert check(ArchiveOrgIE, url + '&a=b'), '{0} failed'.format(url + '&a=b')
        assert check(ArchiveOrgIE, url.replace('http://', 'https://')), '{0} failed'.format(url.replace('http://', 'https://'))
        if expectedResult:
            assert check(ArchiveOrgIE, expectedResult), '{0} failed'.format(expectedResult)
        elif expectedResult is not None:
            assert not check(ArchiveOrgIE, expectedResult), '{0} failed'.format(expectedResult)

# Generated at 2022-06-24 12:12:14.293143
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:12:16.720309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Created on 10/02/2016
    @author: Cesar Barron <cesarb14@gmail.com>
    '''
    ie = ArchiveOrgIE()
    ie.test()
    print('test_ArchiveOrgIE: OK')


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:12:21.671317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:27.517998
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This is a unit test for constructor of class ArchiveOrgIE
    """
    print('Starting test_ArchiveOrgIE')
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/Cops1922')
    print('Ending test_ArchiveOrgIE')

# Generated at 2022-06-24 12:12:32.508390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:35.220896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:12:40.570321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS

# Generated at 2022-06-24 12:12:44.331810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:49.976647
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:13:00.684996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import glob
    import os
    from .test_mixins import CommonTests

    base_path = os.path.join('test', 'resources', 'test_ArchiveOrgIE')
    test_cases = [json.loads(open(f).read()) for f in glob.glob(os.path.join(base_path, '*', 'test_cases.json'))]

# Generated at 2022-06-24 12:13:05.672826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()
    assert archiveorg.IE_NAME == "archive.org"
    assert archiveorg.IE_DESC == "archive.org videos"
    assert archiveorg._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:13:07.920465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # To test whether constructor of class ArchiveOrgIE doesn't raise
    # any exception
    try:
        ArchiveOrgIE()
    except:
        assert False

# Generated at 2022-06-24 12:13:08.491071
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:13:12.917342
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_ArchiveOrgIE = ArchiveOrgIE()
    assert ie_ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ie_ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ie_ArchiveOrgIE.IE_VERSION == '0.1'
