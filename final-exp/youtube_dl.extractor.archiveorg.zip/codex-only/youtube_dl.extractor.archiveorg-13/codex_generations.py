

# Generated at 2022-06-24 12:03:18.320435
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie._match_id(url)
    webpage = ie._download_webpage('http://archive.org/embed/' + video_id, video_id)
    playlist = None
    play8 = ie._search_regex(r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage, 'playlist', default=None)
    if play8:
        attrs = extract_attributes(play8)
        playlist = attrs.get('value')

# Generated at 2022-06-24 12:03:19.823234
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:03:28.292919
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE().IE_NAME == 'archive.org')
    assert(ArchiveOrgIE().IE_DESC == 'archive.org videos')
    assert(ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:03:31.979919
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Not sure whether it's necessary
    assert type(ArchiveOrgIE()) == object

# Generated at 2022-06-24 12:03:41.401203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:43.948073
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:03:46.542945
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE([])

# Generated at 2022-06-24 12:03:48.960461
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('')

# Generated at 2022-06-24 12:03:59.273103
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = 'http://archive.org/details/1234'
    ie._TESTS = []
    ie._REQUEST_HEADERS = {}
    ie._TEST = {
        'url': 'http://archive.org/details/1234',
        'only_matching': True,
    }
    ie._download = lambda url, video_id, *a, **kw: url
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie.ie = None
    ie.GOOD_DOWNLOAD_URL = 'a'
    ie.geo_verification_headers = None
    ie.parameters = None
    ie.set_cookie = lambda *a, **kwargs: None
    ie.tr

# Generated at 2022-06-24 12:04:08.230798
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:04:11.094389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    t.suite()

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:04:20.295775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    expected_info_dict = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }
    ie = ArchiveOrgIE()
    info_dict = ie.extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-24 12:04:21.091026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:22.104407
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-24 12:04:24.118456
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:04:31.759859
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie._match_id(url)
    assert video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = ie._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)
    attrs = extract_attributes(self._search_regex(
            r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
            'playlist', default=None))
    assert attrs.get('value') is not None

# Generated at 2022-06-24 12:04:38.971964
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from archive import Archive
    except ImportError:
        from .archive import Archive
    from .common import InfoExtractor
    from .youtube import YoutubeIE
    assert issubclass(ArchiveOrgIE, InfoExtractor)
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    # the url contains the video_id(IE_NAME)
    archive_org_ie = ArchiveOrgIE('archive.org')
    assert archive_org_ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:04:42.608526
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.url == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
test_ArchiveOrgIE.skip = "test not implemented"

# Generated at 2022-06-24 12:04:43.173321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:44.703171
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    GetVideoInfo(ArchiveOrgIE(), "archive.org")


# Generated at 2022-06-24 12:04:45.784030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor)

# Generated at 2022-06-24 12:04:47.045395
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:47.561069
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:52.425140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE('http://127.0.0.1/')
    assert a._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert a.IE_NAME == 'archive.org'
    assert a.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:54.565354
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:04.642503
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE()
    video_file = arch._download_webpage('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                                  'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    playlist = arch._search_regex(r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)',
                                  video_file, 'playlist', default=None)
    attrs = extract_attributes(playlist)

# Generated at 2022-06-24 12:05:07.230869
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL

# Generated at 2022-06-24 12:05:11.346591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE.__init__()
    """
    assert(ArchiveOrgIE.__name__ == "ArchiveOrgIE")
    assert(ArchiveOrgIE.__doc__ != None)
    assert(ArchiveOrgIE._VALID_URL != None)
    assert(ArchiveOrgIE.IE_NAME != None)
    assert(ArchiveOrgIE.IE_DESC != None)
    assert(ArchiveOrgIE.__init__ != None)

# Generated at 2022-06-24 12:05:12.377168
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")

# Generated at 2022-06-24 12:05:14.534698
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:05:22.502601
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS
    ie._real_extract()
    ie._match_id()
    ie._download_webpage()
    ie._search_regex()
    ie._parse_jwplayer_data()
    ie._parse_json()
    ie._parse_html5_media_entries()
    ie._download_json()
    # method 'test_ArchiveOrgIE'
    return ie

# Generated at 2022-06-24 12:05:29.527753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert 'archive.org' in ie.IE_NAME
    assert 'archive.org videos' in ie.IE_DESC
    assert 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' in ie.IE_URL
    assert ie.IE_TYPE == 'video'
    assert ie.IE_DESC_BASEURL == 'http://archive.org/embed/'
    assert ie.IE_URL_BASEURL == 'http://archive.org/details/'

# Generated at 2022-06-24 12:05:31.273769
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:34.144985
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('youtube')
    assert ie.ie_key() == 'youtube'
    assert ie.suitable(None) == False
    assert ie.suitable('foo') == False
    assert ie.suitable('http://www.youtube.com') == True
    

# Generated at 2022-06-24 12:05:38.031901
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = InfoExtractor(archive_org.ArchiveOrgIE.ie_key())
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:05:40.233822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org videos')


# Generated at 2022-06-24 12:05:41.395132
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  print("hello")
  ie = ArchiveOrgIE()
  print("hello2")

# Generated at 2022-06-24 12:05:46.676162
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
        webpage = '<html><body><p>' + url + '</p></body></html>'
        result = ArchiveOrgIE._make_valid_url(webpage, 'https://archive.org')
        expected = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
        assert(result == expected)
    except Exception:
        print("ArchiveOrgIE.__make_valid_url() failed: " + traceback.format_exc())
        return False
    return True

# Generated at 2022-06-24 12:05:48.828821
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    print(type(info_extractor))

# Generated at 2022-06-24 12:05:53.595660
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.supported_extensions() == ['ogg', 'mkv', 'mp4', 'm4a', 'webm', 'webmv']


# Generated at 2022-06-24 12:06:05.751796
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from validators import url as urlValidator
	from pytube import YouTube
	from pytube.exceptions import RegexMatchError, VideoUnavailable
	import unittest

# Generated at 2022-06-24 12:06:07.792806
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    

# Generated at 2022-06-24 12:06:18.806811
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Ensure that ArchiveOrgIE is instantiable and works as expected
    from . import gen_extractors_test

# Generated at 2022-06-24 12:06:21.522770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()

# Generated at 2022-06-24 12:06:23.029393
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:06:30.279341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.info_extractors == [
        'archive.org'
    ]
    assert ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('https://archive.org/details/Cops1922')
    assert ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert not ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/something')

# Generated at 2022-06-24 12:06:31.414840
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-24 12:06:35.646448
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE_is_constructed = False
    try:
        archiveOrgIE = ArchiveOrgIE(None)
        archiveOrgIE_is_constructed = True
    except Exception:
        archiveOrgIE_is_constructed = False
    return archiveOrgIE_is_constructed

# Generated at 2022-06-24 12:06:38.405963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:06:40.797759
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-24 12:06:49.895126
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert ie._T

# Generated at 2022-06-24 12:06:57.773154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    q = ie._download_json('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator?output=json')
    assert q['metadata']['description'][0].startswith('To Catch a Predator') == True
    assert ie._download_json('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator?output=json')['metadata']['description'][0].startswith('To Catch a Predator') == True


# Generated at 2022-06-24 12:07:01.286983
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from . import archiveorg
    # Test constructor
    if not archiveorg.ArchiveOrgIE()._WORKING:
        raise Exception('Unit test for constructor of class ArchiveOrgIE is fail')


# Generated at 2022-06-24 12:07:02.556173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:05.216251
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 12:07:10.533891
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == "archive.org"
    assert ie.ie_desc() == "archive.org videos"
    assert ie.valid_url("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:07:14.627767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_class = ArchiveOrgIE(InfoExtractor())
    assert test_class.IE_NAME == "archive.org"
    assert test_class.IE_DESC == "archive.org videos"


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:07:25.516350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ArchiveOrgIE.suitable("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ArchiveOrgIE.suitable("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ArchiveOrgIE.suitable("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")
    assert ArchiveOrgIE.suitable("https://archive.org/details/Cops1922")

# Generated at 2022-06-24 12:07:27.599967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:36.012319
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    instance._download_webpage = lambda *args, **kargs: 'foo'
    instance._search_regex = lambda *args, **kargs: 'foo'
    instance._parse_json = lambda *args, **kargs: [{
        'sources': [{'file': 'foo'}],
    }]
    instance._download_json = lambda *args, **kargs: {
        'metadata': {
            'title': ['title'],
            'creator': ['creator'],
            'date': ['2016-09-01'],
            'publisher': ['publisher'],
            'publicdate': ['2016-09-02'],
            'description': ['description'],
            'language': ['en'],
        },
    }


# Generated at 2022-06-24 12:07:39.210390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if ie.IE_NAME != 'archive.org':
        raise NameError('Constructor failed. Incorrect IE name')
    if ie.IE_DESC != 'archive.org videos':
        raise NameError('Constructor failed. Incorrect IE description')

# Generated at 2022-06-24 12:07:44.946270
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'



# Generated at 2022-06-24 12:07:46.398731
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'archive.org'

# Generated at 2022-06-24 12:07:46.989409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:07:50.118855
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._VALID_URL
    assert ie._TESTS == ie._TESTS
    assert ie.IE_NAME == ie.IE_NAME
    assert ie.IE_DESC == ie.IE_DESC

# Test to ensure that _real_extract works (when it has value)

# Generated at 2022-06-24 12:08:03.140703
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test the object construction
    archive_org = ArchiveOrgIE()
    assert archive_org.IE_NAME == 'archive.org'
    assert archive_org.IE_DESC == 'archive.org videos'
    assert archive_org._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:14.400651
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:20.259079
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """
    # Constructor should accept url with missing 'http(s)://'
    ie = ArchiveOrgIE('archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'ArchiveOrg'

# Generated at 2022-06-24 12:08:23.413198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import ExtractorError
    e = InfoExtractor(['archive.org'])
    assert isinstance(e, ArchiveOrgIE)
    with ExtractorError(r'URL must be a string or a unicode string', 'Unsupported format'):
        e(1)

# Generated at 2022-06-24 12:08:27.510222
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r"https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:08:30.219345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for constructor of class ArchiveOrgIE."""
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:08:32.671264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # Returns true if an instance of InfoExtractor passed
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:08:38.744565
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    sample_url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    sample_webpage = '<html><head><title>Archive.org</title></head><body>Archive.org</body></html>'
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda url: sample_webpage
    ie.extract(sample_url)

# Generated at 2022-06-24 12:08:42.402962
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test for constructor of class ArchiveOrgIE.

    The purpose is to test if the constructor of the class ArchiveOrgIE is
    working properly.
    """
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:52.309329
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    from .archive_org import ArchiveOrgIE
    import sys
    import unittest
    import unittest.mock

    ret=InfoExtractor._call_api(
        ArchiveOrgIE, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        {'_type': 'url'})

# Generated at 2022-06-24 12:09:01.762436
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    config = {'_type': 'video', 'params': ['object-id=XD300-23_68HighlightsAResearchCntAugHumanIntellect']}
    # test if the class ArchiveOrgIE is initialized correctly
    assert issubclass(ArchiveOrgIE, InfoExtractor)
    assert (info_extractor.ie_key() == 'archive.org')
    assert (info_extractor.suitable(None, config))
    assert (info_extractor.url_re.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'))


# Generated at 2022-06-24 12:09:05.987173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_DESC == ArchiveOrgIE.IE_DESC
    assert inst.IE_NAME == ArchiveOrgIE.IE_NAME
    assert inst._VALID_URL == ArchiveOrgIE._VALID_URL
    assert inst._TESTS == ArchiveOrgIE._TESTS


# Generated at 2022-06-24 12:09:07.979845
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert hasattr(ie, '_VALID_URL')

# Generated at 2022-06-24 12:09:10.329830
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # 
    ao_ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:17.391588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    parser = ArchiveOrgIE()
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video_id = parser._match_id(url)
    video_id_expected = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert video_id == video_id_expected, "Expected video_id " + video_id_expected + " but got " + video_id

# Generated at 2022-06-24 12:09:23.211139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        # First, get a video (with HTTP 200 OK)
        ie = ArchiveOrgIE()
        ie.download_webpage(
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            None)
    except Exception as e:
        # Don't let our test fail due to connection issue
        if not isinstance(e, IOError):
            raise e



# Generated at 2022-06-24 12:09:24.252263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:24.956401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-24 12:09:27.297376
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for ArchiveOrgIE constructor"""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:27.842664
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:09:29.918952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Test to see if the class has the method _real_extract()

# Generated at 2022-06-24 12:09:36.244790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check whether class ArchiveOrgIE is initialized correctly
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:40.367303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:42.074751
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert 'archive.org' == ie.extractor_key(ie.ie_key())

# Generated at 2022-06-24 12:09:51.357136
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.downloader import Downloader
    from youtube_dl.postprocessor import FFmpegMetadataPP
    from youtube_dl.utils import DateRange

    d = Downloader()
    dp = FFmpegMetadataPP(d)
    d.postprocessor = dp
    d.add_info_extractor(ArchiveOrgIE())


    # Test URL in the form https://archive.org/details/{id}
    sample_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = d.extract_info(sample_url)
    assert ie.get('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie.get('ext') == 'ogg'

# Generated at 2022-06-24 12:09:55.986293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:10:06.809362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:14.525742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # NOTE(jmatousek): The code below is testing if the code
    #                   is running (and not throwing an error)
    #                   when the video has a jwplayer_playlist
    # TODO(jmatousek): Add a new test case for this scenario
    assert ArchiveOrgIE()._real_extract('http://archive.org/embed/Cops1922')

# Generated at 2022-06-24 12:10:17.755190
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE().IE_DESC == ArchiveOrgIE.IE_DESC
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:10:18.338267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:19.226902
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:24.903007
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:26.621545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # No exception should be raised
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:34.828293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['ext'] == 'ogg'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290

# Generated at 2022-06-24 12:10:39.858443
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_ie = ArchiveOrgIE()
    result = archive_org_ie.extract(test_url)
    print(result)


# Generated at 2022-06-24 12:10:43.246603
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=DeprecationWarning)
        import doctest
        doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 12:10:43.852995
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:10:45.557317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)


# Generated at 2022-06-24 12:10:51.155100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for normal constructor
    video_url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    videos = ArchiveOrgIE().extract(video_url)
    assert "-23_68HighlightsAResearchCntAugHumanIntellect" in videos[0]
    assert "ogg" in videos[0]

# Generated at 2022-06-24 12:10:52.499992
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Construct an instance of ArchiveOrgIE
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == 'archive.org'
    # assert ie.IE_DESC == 'Internet Archive'

# Generated at 2022-06-24 12:10:58.318028
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_url = 'https://archive.org/details/' + id
    video_id = ie._match_id(video_url)
    assert id == video_id


# Generated at 2022-06-24 12:11:10.319939
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    reload(sys)
    sys.setdefaultencoding('utf-8')
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:11:12.880784
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE constructor
    """
    # Test without argument
    ArchiveOrgIE()
    # Test with a non existent argument
    ArchiveOrgIE(num=2)

# Generated at 2022-06-24 12:11:16.149553
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    assert ie.suitable(test_url)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:11:16.711579
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:19.284797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:11:27.683209
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME == 'archive.org'
    ie.IE_DESC == 'archive.org videos'
    ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:29.147979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:31.133748
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check if constructor of ArchiveOrgIE class is working properly
    if "archive.org" in globals()['__name__']:
        # Initialize constructor
        ArchiveOrgIE()

# Generated at 2022-06-24 12:11:31.977244
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:38.599498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == 
    r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')


# Generated at 2022-06-24 12:11:42.452251
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None
    assert ie.IE_NAME == 'archive.org'


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:46.925406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    assert isinstance(info.name, str)
    assert isinstance(info.description, str)
    assert isinstance(info.valid_urls, str)
    assert isinstance(info.valid_urls, str)
    assert len(info.valid_urls) > 0
    assert isinstance(info.test, dict)
    assert len(info.test) > 0
    assert isinstance(info.test[0], dict)
    assert len(info.test[0]) > 0
    assert len(info.test[0]['url']) > 0



# Generated at 2022-06-24 12:11:52.473849
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert sorted(x.IE_NAME) == ["archive.org"]
    assert x.IE_DESC == "archive.org videos"
    assert len(x.VALID_URL) == (1)
    assert len(x.IE_NAME) > 0
    assert len(x.TESTS) > 0


# Generated at 2022-06-24 12:11:54.420684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This will raise an exception if the constructor fails
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:58.555901
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:59.673332
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:01.097693
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:12:06.163960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ai = ArchiveOrgIE()
    assert ai.IE_NAME == 'archive.org'
    assert ai.IE_DESC == 'archive.org videos'
    assert ai._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ai._TESTS



# Generated at 2022-06-24 12:12:09.821979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/WaltDisneyTreasuresMickey')
    ie.extract('http://archive.org/embed/WaltDisneyTreasuresMickey')

# Generated at 2022-06-24 12:12:10.765154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-24 12:12:14.411203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')


# Generated at 2022-06-24 12:12:14.929104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:12:18.789570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Create instance of ArchiveOrgIE
    archive_org = ArchiveOrgIE()
    # Call method _real_extract which returns a dictionary
    # containing all the metadata of the video
    info = archive_org._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Check if the returned dictionary contains some metadata
    assert 'title' in info.keys()

# Generated at 2022-06-24 12:12:30.819378
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test 1,
    #       test of constructor with input url as "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    #   expected output: "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    archiveOrgIE = ArchiveOrgIE()
    video_id = archiveOrgIE._match_id(url)
    assert video_id == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    # Test 2,
    #       test of constructor with input url as "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanInt

# Generated at 2022-06-24 12:12:36.773713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # downloader = FakeDownloader()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:39.917345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    if instance._DOWNLOADER_CLS != 'internetarchive':
        raise Exception('Wrong downloader class')
    return instance


# Generated at 2022-06-24 12:12:46.837794
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.MAX_REDIRS == 10
    assert ie.VALID_URL == _VALID_URL
    assert ie.TESTS == _TESTS

# Generated at 2022-06-24 12:12:54.727937
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:58.000834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:13:05.777395
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    VideoInfo.objects.all().delete()
    media_entries = [{}, {'playlist': []}]
    video_info = ArchiveOrgIE()._parse_jwplayer_data(media_entries[0], "undefined", "undefined", "undefined")
    assert len(VideoInfo.objects.all()) == 0
    video_info = ArchiveOrgIE()._parse_jwplayer_data(media_entries[1], "undefined", "undefined", "undefined")
    assert len(VideoInfo.objects.all()) == 0
    assert video_info['id'] == 'undefined'
    assert len(video_info['formats']) == 0
    assert video_info['age_limit'] == 0
    assert video_info['tags'] == []
    assert video_info['thumbnails'] == []

# Generated at 2022-06-24 12:13:09.905260
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS