

# Generated at 2022-06-24 12:03:12.028300
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    instance = ArchiveOrgIE()
    instance.url_result(test_url)

# Generated at 2022-06-24 12:03:16.295883
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Used to check for changes in URLs for items that are otherwise not
    # publicly accessible
    ie.download_webpage(
        'https://archive.org/details/msdos_factorio_1_9_alpha_201503101003',
        ie.ie_key())

# Generated at 2022-06-24 12:03:20.948911
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC
    ie.IE_NAME
    ie._TESTS
    ie._VALID_URL
    ie._download_webpage
    ie._match_id
    ie._parse_html5_media_entries
    ie._parse_json
    ie._parse_jwplayer_data
    ie._real_extract
    ie._search_regex

# Generated at 2022-06-24 12:03:21.514016
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:22.389130
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('ArchiveOrgIE')


# Generated at 2022-06-24 12:03:27.365725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._match_id(url + '/') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:03:30.812662
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        return False
    return True

# Generated at 2022-06-24 12:03:37.588207
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290
    assert info['upload_date'] == "20100315"

# Generated at 2022-06-24 12:03:45.656027
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = {
        "Test Extractor": {
            "url": "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
            "expected_name": "XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        },
        "Test constructor": {
            "url": "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
            "expected_name": "XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        },
        "Test constructor with no parameters": {
            "url": None,
            "expected_name": "None",
        },
    }

# Generated at 2022-06-24 12:03:58.602535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    from .test_youtube import YoutubeIE
    from .test_generic import FakeYDL, FakeYDL
    from .extractor.common import InfoExtractor
    from .compat import compat_urllib_parse
    from .compat import compat_urllib_parse_urlparse

# Generated at 2022-06-24 12:04:01.032891
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extractor_key
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 12:04:03.039269
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:04:04.347741
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    "Test for constructor of ArchiveOrgIE"
    infoExtractor = ArchiveOrgIE()
    assert infoExtractor.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:15.094686
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_name = ArchiveOrgIE.__name__
    from .test_archiveorg import (
        _COPS1922_URL, _XD300_23_68HIGHLIGHTSARESEARCHCNTAUGHUMANINTELLECT_URL
    )
    _EMPTY_ATTRS = {'class': 'js-play8-playlist'}
    _EMPTY_PLAYLIST = "[{}]"
    _DATE_IMAGE_PATTERN = '//archive.org/services/img/%s'
    _FILENAME = 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    _FILE_URL = 'https://archive.org/download/' + _FILENAME + '/' + _FILENAME + '.mp4'

# Generated at 2022-06-24 12:04:22.021919
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test of class ArchiveOrgIE"""
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    archiveOrgIE = ArchiveOrgIE(info_extractors=[])
    assert archiveOrgIE.suitable(url) is True
    url = "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert archiveOrgIE.suitable(url) is True
    url = "http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"
    assert archiveOrgIE.suitable(url) is True

# Generated at 2022-06-24 12:04:25.447276
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # the following line would raise ImportError if the regex fails
    re.compile(ie._VALID_URL, flags=re.VERBOSE | re.MULTILINE)

# Generated at 2022-06-24 12:04:26.997350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:04:30.391959
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:31.522733
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IA = ArchiveOrgIE()
    assert IA.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:36.135329
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert (ArchiveOrgIE()._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert (ArchiveOrgIE().IE_NAME == 'archive.org')

# Generated at 2022-06-24 12:04:39.123749
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# Construct an instance of ArchiveOrgIE
	archiveOrgIE = ArchiveOrgIE()
	# Test the following attributes
	assert archiveOrgIE.IE_NAME == 'archive.org'
	assert archiveOrgIE.IE_DESC == 'archive.org videos'
	assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:40.944590
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor= ArchiveOrgIE()

# Generated at 2022-06-24 12:04:41.957990
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None

# Generated at 2022-06-24 12:04:46.470087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'archive.org'
    assert ArchiveOrgIE.__doc__ == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:04:47.064390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:55.610874
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_DESC == 'archive.org videos'
    assert a.IE_NAME == 'archive.org'
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:04.163058
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    test.ie_name()
    test.ie_desc()
    test._VALID_URL
    test._TESTS
    test._real_extract(
        'http://archive.org/details/'
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    test._real_extract(
        'https://archive.org/details/'
        'MSNBCW_20131125_040000_To_Catch_a_Predator/')
    test._real_extract(
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:05:07.927711
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:05:14.154530
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    # Test for valid URL
    testUrl = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url = ie._match_id(testUrl)
    assert (testUrl is url)
    # Test for invalid URL
    invalidUrl = 'http://archive.org/details/xd300-23_68highlightsaresearchcntaugHumanIntellect'
    url = ie._match_id(invalidUrl)
    assert (url is None)

# Generated at 2022-06-24 12:05:17.289308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE()
    assert o.IE_NAME == 'archive.org'
    assert o.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:27.644716
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simple test cases to test constructor of class ArchiveOrgIE
    """
    # Test case with normal URL
    print("test_ArchiveOrgIE1")
    ie = ArchiveOrgIE("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # Test case with embed URL
    print("test_ArchiveOrgIE2")
    ie = ArchiveOrgIE("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    # Test case with invalid URL
    print("test_ArchiveOrgIE3")
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/invalid")

# Generated at 2022-06-24 12:05:31.863710
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    # ext_to_formats is not static and has been modified after creation
    assert ie._TEST.get('info_dict', {}).get('id') == ArchiveOrgIE._TEST.get('info_dict', {}).get('id')

# Generated at 2022-06-24 12:05:32.676030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:05:33.614666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:05:41.999200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Check the constructor of class ArchiveOrgIE.
    """
    # Test the constructor
    ie = ArchiveOrgIE()

    # Check an example URL
    example_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # Check the correct information is extracted
    info = ie.extract(example_url, download=False)

    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['ext'] == 'ogg'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'

# Generated at 2022-06-24 12:05:43.377870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE();
    print(test_obj.IE_NAME);
    print(test_obj._VALID_URL);
    print(test_obj._TESTS[0]);

if __name__ == "__main__":
    test_ArchiveOrgIE();

# Generated at 2022-06-24 12:05:49.621923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:57.871716
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    fixture_1 = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(fixture_1)
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    assert ie._downloader == None
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert (not ie.suitable('https://archive.org/details/'))
    assert (not ie.suitable('https://archive.org/details'))



# Generated at 2022-06-24 12:06:00.910139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Do not remove this test.
    # This is a call to the class constructor,
    # and is needed to ensure the class is registered.
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:01.804880
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-24 12:06:03.969464
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrgIE'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:06:06.426714
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    b = a._real_extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert b['title'] == "1968 Demo - FJCC Conference Presentation Reel #1"

# Generated at 2022-06-24 12:06:07.951608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:06:18.905576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    input = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test = ArchiveOrgIE()
    assert test.suitable(input)
    assert test.IE_NAME in test.ie_key()
    assert test.IE_NAME == ArchiveOrgIE.IE_NAME
    assert test.IE_DESC == ArchiveOrgIE.IE_DESC
    assert test._VALID_URL == ArchiveOrgIE._VALID_URL

    output = test.extract(input)
    assert output['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert output['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:06:20.970949
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    d = ArchiveOrgIE()._constructor()
    assert d is not None

# Generated at 2022-06-24 12:06:21.899218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE({}) is not None

# Generated at 2022-06-24 12:06:27.277090
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert hasattr(ArchiveOrgIE, '_VALID_URL')
    assert hasattr(ArchiveOrgIE, '_TESTS')
    test_video_url = ArchiveOrgIE._TESTS[0]['url']
    ie = ArchiveOrgIE()
    ie.extract(test_video_url)

# Generated at 2022-06-24 12:06:30.851215
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:06:33.711567
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test whether ArchiveOrgIE object is properly initialized
    yt = ArchiveOrgIE()
    assert yt.extractor_key == 'archive.org'

# Generated at 2022-06-24 12:06:44.386256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archiveorg = ArchiveOrgIE()
    assert archiveorg.IE_NAME == 'archive.org'
    assert archiveorg.IE_DESC == 'archive.org videos'
    assert archiveorg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:46.976680
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:06:53.591630
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    ie_getter = getattr(ie, '_TESTS', None)
    assert ie_getter != None

# Generated at 2022-06-24 12:06:58.661958
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # test for invalid url
    invalid_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    res = ie.suitable(invalid_url)
    assert res == False
    assert ie.IE_NAME not in invalid_url

    # valid url test
    assert ie.IE_NAME in ie.get_url()

# Generated at 2022-06-24 12:07:01.924106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:03.390541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:07:06.167346
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:07:07.254552
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:07:08.921384
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:11.618336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:07:22.670228
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print('test_ArchiveOrgIE')
    # Test an URL
    archive = ArchiveOrgIE()
    archive._download_webpage = lambda url, params: 'webpage'
    archive._parse_html5_media_entries = lambda url, webpage, video_id: []
    archive._parse_jwplayer_data({"playlist": [{
        "sources": [
            {"file": "http://some_url"},
            {"file": "http://some_other_url"},
        ]
    }]}, "video_id", url)
    assert archive.playlist == []
    # Assure there are no errors if jwplayer_playlist is empty
    archive._parse_jwplayer_data({"playlist": []}, "")
    assert archive.playlist == []

# Generated at 2022-06-24 12:07:25.030004
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Validate a test case by constructing an instance of the class ArchiveOrgIE """
    _ = ArchiveOrgIE('test', None, None)

# Generated at 2022-06-24 12:07:26.760233
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('Cops1922')
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:36.624422
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import os
    from tempfile import NamedTemporaryFile
    from .jwplayer import DUMMY_DATA

    fd = NamedTemporaryFile(delete=False)
    fd.write(DUMMY_DATA)
    fd.close()
    try:
        tmp_filename = fd.name
        ie = ArchiveOrgIE(tmp_filename)
        assert ie.name == 'archive.org'
    finally:
        os.unlink(tmp_filename)

# Generated at 2022-06-24 12:07:37.464504
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor_test(ArchiveOrgIE)

# Generated at 2022-06-24 12:07:39.417203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie= ArchiveOrgIE()
    print("\nUnit test for constructor of class ArchiveOrgIE")
    print("\tThe type of 'ie' is :\n\t\t %s" %type(ie))


# Generated at 2022-06-24 12:07:46.049682
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4


# Generated at 2022-06-24 12:07:49.430870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ArchiveOrgIE()._TESTS) > 0

# Generated at 2022-06-24 12:07:54.792960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:59.059942
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE()
    assert o.IE_NAME == 'archive.org'
    assert o.IE_DESC == 'archive.org videos'
    assert o._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:01.218376
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor()

# Generated at 2022-06-24 12:08:06.257367
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == '__main__':
        url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
        info = ArchiveOrgIE()._real_extract(url)
        assert_equals(info.get("id"), "XD300-23_68HighlightsAResearchCntAugHumanIntellect")
        assert_equals(info.get("title"), "1968 Demo - FJCC Conference Presentation Reel #1")
        assert_equals(info.get("creator"), "SRI International")

# Generated at 2022-06-24 12:08:08.819614
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie_test = ie.test()
    assert ie_test.get('passed'), ie_test.get('errors')

# Generated at 2022-06-24 12:08:11.904995
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE._VALID_URL is not None

# Generated at 2022-06-24 12:08:13.679203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC
    ie.IE_NAME
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 12:08:22.096173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.valid_url('https://archive.org/details/Cops1922')
    assert not ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')
    assert not ie.valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:23.318545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org').IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:31.938816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:32.876651
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i=ArchiveOrgIE()
    return i

# Generated at 2022-06-24 12:08:40.389636
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:44.701112
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test"""
    archive_org = ArchiveOrgIE()
    assert archive_org.ie_key() == 'ArchiveOrg'
    assert archive_org.ie_name() == ArchiveOrgIE.IE_NAME
    assert archive_org.ie_description() == ArchiveOrgIE.IE_DESC

# Integration test for ArchiveOrgIE

# Generated at 2022-06-24 12:08:49.813482
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:53.316584
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    testobj = ArchiveOrgIE()
    assert testobj.IE_DESC is not None
    assert testobj.IE_NAME is not None
    assert testobj._VALID_URL is not None
    assert testobj._TESTS is not None

# Generated at 2022-06-24 12:08:59.928744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Unit test for constructor of class ArchiveOrgIE
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:09:08.690278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:11.337321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..jsinterp import JSInterpreter
    from .test_common import make_instance
    ao_ie= make_instance(ArchiveOrgIE)
    assert isinstance(ao_ie, InfoExtractor)
    assert isinstance(ao_ie, JSInterpreter)

# Generated at 2022-06-24 12:09:14.014923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.IE_DESC == ie.ie_desc()

# Generated at 2022-06-24 12:09:25.161269
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    TestInfoExtractor = type('TestInfoExtractor',
                             (ArchiveOrgIE,), {
                                 '_download_json': lambda _, __, ___: None,
                                 '_parse_jwplayer_data': lambda _, __, ___, ____: None,
                                 '_parse_html5_media_entries': lambda _, __, ___: None
                             })
    info_extractor = TestInfoExtractor()

# Generated at 2022-06-24 12:09:27.424563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    # Test downloading in tests/test_archive_org.py

# Generated at 2022-06-24 12:09:28.176858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:40.865764
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:42.214496
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.set_test()



# Generated at 2022-06-24 12:09:47.442717
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:57.084694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_common import make_test_data_path, determine_ext
    from .common import InfoExtractor
    from .aenetworks import AENetworksBaseIE

    IE_NAME = 'archive.org'
    video = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = make_test_data_path(IE_NAME + '/' + video + '.html')
    expected_ext = determine_ext(IE_NAME, video)

# Generated at 2022-06-24 12:09:58.516707
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i= ArchiveOrgIE();
    assert i.IE_NAME=='archive.org'

# Generated at 2022-06-24 12:09:59.104107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:10:01.107326
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if not hasattr(ie, "IE_NAME"):
        ie.IE_NAME = "archive.org"
    return ie

# vim:set ts=4 sw=4 sts=4 et

# Generated at 2022-06-24 12:10:10.971288
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test ArchiveOrgIE._VALID_URL
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'

# Generated at 2022-06-24 12:10:21.040374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert (ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert (ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')
    assert (ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:27.971359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_ie = ArchiveOrgIE(url)
    archive_org_ie.extract(url)

# Generated at 2022-06-24 12:10:28.843925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-24 12:10:31.612511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor

    # Unit test for class constructor
    ie = InfoExtractor()
    result = ie.extract('http://archive.org/details/BusterKeaton')
    assert result['id'] == 'BusterKeaton'

# Generated at 2022-06-24 12:10:33.598795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	class_object = ArchiveOrgIE(1, 2)

# Generated at 2022-06-24 12:10:35.001575
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:36.045961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrg = ArchiveOrgIE
    type(archiveOrg)

# Generated at 2022-06-24 12:10:39.002462
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:43.944218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:47.558967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    check_invalid_IE('archive.org', invalid=False)
    ie = ArchiveOrgIE('https://archive.org/'),

# Generated at 2022-06-24 12:10:52.305454
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE();
    archive.IE_NAME = "archive.org";
    archive.IE_DESC = "archive.org videos";
    archive._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)';

# Generated at 2022-06-24 12:10:56.863715
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert hasattr(ie, "IE_NAME")
    assert hasattr(ie, "IE_DESC")
    assert hasattr(ie, "_VALID_URL")
    assert hasattr(ie, "_TESTS")

# Generated at 2022-06-24 12:10:58.274939
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj is not None

# Generated at 2022-06-24 12:11:00.444581
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == "__main__":
        info_extractor = ArchiveOrgIE()
        print(info_extractor)

# Generated at 2022-06-24 12:11:01.866494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:11:02.965056
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    d = ArchiveOrgIE()
    assert d

# Generated at 2022-06-24 12:11:04.733001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:11:05.611208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE class constructor"""
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:09.539202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    const = ArchiveOrgIE()
    assert const.ie_key() == "archive.org"
    assert const.ie_desc() == "archive.org videos"
    assert const.work() == True

# Generated at 2022-06-24 12:11:12.105476
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:11:12.881950
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')



# Generated at 2022-06-24 12:11:21.031503
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert i._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert i._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:11:29.931969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract(None)
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    ie.extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:11:30.430707
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:31.199401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:11:43.355266
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import doctest
    from .common import end_of_playlist, playlist_result
    from ..utils import HEADRequest

    headers = {'Range': 'bytes=0-10'}
    res = HEADRequest('http://ia801405.us.archive.org/15/items/MSNBCW_20131125_040000_To_Catch_a_Predator/'
            'MSNBCW_20131125_040000_To_Catch_a_Predator.mp4',
            headers=headers)
    _test_ArchiveOrgIE = doctest.DocTestSuite()
    _test_ArchiveOrgIE.globs['res'] = res
    _test_ArchiveOrgIE.globs['playlist_result'] = playlist_result
    _test_ArchiveOrgIE.globs['end_of_playlist']

# Generated at 2022-06-24 12:11:48.626703
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg_ie = ArchiveOrgIE()

    assert archiveorg_ie.IE_NAME == 'archive.org'
    assert archiveorg_ie.IE_DESC == 'archive.org videos'
    assert archiveorg_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Test jwplayer extraction

# Generated at 2022-06-24 12:11:57.783326
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global pass_flag
    pass_flag = True

    def test(str1, str2):
        """Test for equality of two strings, used for unit test.

        :param str1: first string for compare
        :param str2: second string for compare
        :return:
        """
        if str1 == str2:
            print('PASS')
        else:
            print('FAIL. {0} IS NOT EQUAL TO {1}'.format(str1, str2))
            global pass_flag
            pass_flag = False

    print('Testing ArchiveOrgIE...')

    # Test _VALID_URL
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    regex = ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:12:04.799979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.downloader import YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.ExtractorError import ExtractorError
    from youtube_dl.options import Options
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    try:
        #Test that extractor is called properly
        YoutubeDL(Options({})).extract_info(url, download=False)
    except ExtractorError as e:
        assert(e.msg == 'None')
    #Test that extractor is called properly
    YoutubeDL(Options({})).extract_info(url, download=False)

# Generated at 2022-06-24 12:12:05.998687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    this = ArchiveOrgIE()
    assert this.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:15.835666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    dict_result = ie.extract(url)
    assert dict_result['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert dict_result['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert dict_result['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert dict_result['creator'] == 'SRI International'
    assert dict_result['release_date'] == '19681210'
    assert dict_result['uploader'] == 'SRI International'
    assert dict_result['timestamp']

# Generated at 2022-06-24 12:12:17.511358
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:29.690148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert ie.IE_NAME == 'archive.org'
	assert ie.IE_DESC == 'archive.org videos'
	assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

	# test parsing of test 1
	test = ie._TESTS[0]
	assert test['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	assert test['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:12:41.398878
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    assert info.IE_DESC == 'archive.org videos'
    assert info.IE_NAME == 'archive.org'
    assert info._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:43.045490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("Test ArchiveOrgIE class constructor")
    ie_obj = ArchiveOrgIE()
    assert ie_obj.IE_NAME == 'archive.org'
    assert ie_obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:55.834456
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:13:04.504798
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert 'archive.org' in ie._VALID_URL # pylint: disable=protected-access
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:13:14.583342
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of class ArchiveOrgIE"""