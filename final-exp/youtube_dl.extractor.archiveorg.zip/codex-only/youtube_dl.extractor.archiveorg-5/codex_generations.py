

# Generated at 2022-06-24 12:03:13.582229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie._download_webpage('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:03:15.144085
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:03:16.541606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert type(ArchiveOrgIE) == type


# Generated at 2022-06-24 12:03:17.682335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE(object)
    assert x != None

# Generated at 2022-06-24 12:03:21.639731
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:26.037425
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from .common import InfoExtractor
        from .archiveorg import ArchiveOrgIE
    except ImportError:
        from test.test_archiveorg import ArchiveOrgIE

    ie = InfoExtractor(ArchiveOrgIE.ie_key())
    assert ie.ie_key() == 'ArchiveOrg'
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:03:30.554221
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorgie = ArchiveOrgIE()
    assert aorgie

# Generated at 2022-06-24 12:03:32.642873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert issubclass(ArchiveOrgIE, InfoExtractor)

# Generated at 2022-06-24 12:03:35.821032
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Only check if instantiation is successful
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:40.536366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL is ArchiveOrgIE._VALID_URL
    assert ie.IE_NAME is ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC is ArchiveOrgIE.IE_DESC
    assert ie.NAME is ArchiveOrgIE.IE_NAME
    assert ie.DESC is ArchiveOrgIE.IE_DESC

# Generated at 2022-06-24 12:03:44.403137
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org = ArchiveOrgIE()
    assert_equal(archive_org.ie_key(), 'ArchiveOrg')
    assert_equal(archive_org.ie_name(), 'archive.org')
    assert_equal(archive_org.ie_desc(), 'archive.org videos')
    assert_equal(archive_org.ie_version(), 'test for unittest')

# Generated at 2022-06-24 12:03:50.472979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    obj = object.__new__(ie.__class__)
    ie.__init__(obj)

# Generated at 2022-06-24 12:03:52.203237
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'


# Generated at 2022-06-24 12:03:54.654536
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org", "archive.org videos")

# Generated at 2022-06-24 12:03:56.323149
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:05.855810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:13.138584
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org = ArchiveOrgIE('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert archive_org.IE_NAME == 'archive.org'
    assert archive_org.IE_DESC == 'archive.org videos'
    assert archive_org._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:18.653300
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for url in [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/details/Cops1922',
    ]:
        print('Testing constructor for IE: %s' % url)
        ie = ArchiveOrgIE()
        assert(ie)
        assert(ie.ie_key() == 'archive.org')
        assert(ie.ie_name() == 'archive.org')
        assert(ie.ie_description() == 'archive.org videos')

# Generated at 2022-06-24 12:04:20.735980
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:04:24.468362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ext = ArchiveOrgIE('archive.org')
    assert ext._downloader is not None

    ext = ArchiveOrgIE('archive.org', 'senora')
    assert ext._downloader is not None



# Generated at 2022-06-24 12:04:27.079145
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == '__main__':
        # Testing ArchiveOrgIE constructor
        from . import get_testcases

        get_testcases(IE=ArchiveOrgIE(), module_name='archive_org')

# Generated at 2022-06-24 12:04:30.386189
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:33.223783
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test the ArchiveOrgIE constructor."""
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:33.763713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE("archive.org")

# Generated at 2022-06-24 12:04:37.308972
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(ArchiveOrgIE.ie_key())

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:04:39.351223
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Here you can test the method '_real_extract' of class ArchiveOrgIE.
    pass

# Generated at 2022-06-24 12:04:40.507246
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    pass



# Generated at 2022-06-24 12:04:42.130149
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:42.972895
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:43.947224
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:53.259304
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor

    ie = InfoExtractor({
        '_type': 'playlist',
    })
    assert ie._type == 'playlist'
    assert ie.ie_key() == 'Playlist'
    assert ie.suitable(None) is False
    assert ie.suitable('') is False
    assert ie.suitable(list()) is False
    assert ie.suitable(dict()) is True

    ie = InfoExtractor({
        'url': 'http://www.youtube.com/watch?v=BaW_jenozKc',
        '_type': 'url',
    })
    assert ie._type == 'url'
    assert ie.ie_key() == 'Youtube'
    assert ie.suitable(None) is False
    assert ie.suitable('') is False

# Generated at 2022-06-24 12:04:54.890694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:58.440933
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie=ArchiveOrgIE()
    assert ie._VALID_URL==r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:59.521535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-24 12:05:03.117540
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:05:05.557981
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract(self._VALID_URL)

# Generated at 2022-06-24 12:05:10.570513
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # ArchiveOrgIE() is a constructor for ArchiveOrgIE class
    # that gets called if no arguments are supplied and it returns the instance of class ArchiveOrgIE
    assert ArchiveOrgIE() is not None
    # the above command will return a new instance of class ArchiveOrgIE if successful and this method can be used to get the instance of ArchiveOrgIE class
    assert ArchiveOrgIE() is ArchiveOrgIE()

# Generated at 2022-06-24 12:05:17.429832
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.get_info("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie.get_info("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie.get_info("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")

# Generated at 2022-06-24 12:05:18.004680
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:22.656033
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    sample_url = "http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    aorg = ArchiveOrgIE(sample_url)
    assert aorg._match_id(sample_url) == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-24 12:05:25.598826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:05:28.591677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():  
    assert issubclass(ArchiveOrgIE, InfoExtractor) == True


# Generated at 2022-06-24 12:05:37.089419
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:45.404335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = ie._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)

    playlist = None
    play8 = ie._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    if play8:
        attrs = extract_attributes(play8)
        playlist = attrs.get('value')

# Generated at 2022-06-24 12:05:48.035972
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test login
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:05:49.881532
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:05:57.764943
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    with open('test.html', 'r') as f:
        webpage = f.read()
    assert ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', webpage) == {'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'ext': 'ogg', 'title': '1968 Demo - FJCC Conference Presentation Reel #1', 'author': 'SRI International', 'release_date': '19681210', 'uploader': 'SRI International', 'timestamp': 1268695290, 'upload_date': '20100315'}

# Generated at 2022-06-24 12:06:07.063463
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:06:12.389771
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:06:17.554580
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    r = ArchiveOrgIE()
    assert r._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert r.IE_NAME == 'archive.org'
    assert r.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:06:28.405708
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test info extraction
    expected_values = (
        {
            'title': '1968 Demo - FJCC Conference Presentation Reel #1',
            'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'ext': 'ogg',
            'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
            'creator': 'SRI International',
            'release_date': '19681210',
            'uploader': 'SRI International',
            'timestamp': 1268695290,
            'upload_date': '20100315',
        },
    )

# Generated at 2022-06-24 12:06:34.678531
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  assert ArchiveOrgIE(None).IE_NAME == 'archive.org'
  assert ArchiveOrgIE(None).IE_DESC == 'archive.org videos'
  assert ArchiveOrgIE(None)._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:45.444920
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from urlparse import urljoin
    except ImportError:
        from urllib.parse import urljoin
    import unittest

    class ConstructorTest(unittest.TestCase):
        """Test whether the constructor of ArchiveOrgIE works as expected."""
        def setUp(self):
            self.expectedValues = {
                'archiveOrgIE':IE_NAME,
                'embed':True,
                'videoId':'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
            }
            self.archive = ArchiveOrgIE(
                'http://archive.org/embed/' + self.expectedValues['videoId'])

        def test_expectedValues(self):
            self.assertEqual(
                self.archive.ie_key(), self.expectedValues['archiveOrgIE'])
           

# Generated at 2022-06-24 12:06:46.604257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print('Successfully created ArchiveOrgIE')

# Generated at 2022-06-24 12:06:51.632214
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:06:52.865328
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        assert ArchiveOrgIE
    except:
        pass

# Generated at 2022-06-24 12:06:59.683600
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    expected_instance_IE_NAME = "archive.org"
    expected_instance_IE_DESC = "archive.org videos"
    expected_instance__VALID_URL = r"https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

    assert instance.IE_NAME == expected_instance_IE_NAME
    # assert instance.IE_DESC == expected_instance_IE_DESC
    # assert instance._VALID_URL == expected_instance__VALID_URL

# Generated at 2022-06-24 12:07:01.415908
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:07:05.125526
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert 'archive.org/details/' in ie._VALID_URL

# Generated at 2022-06-24 12:07:06.817497
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    'Unit test for constructor of class ArchiveOrgIE'
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:07:12.238145
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.ie_key() == 'archive.org')
    assert(ie.ie_desc() == 'archive.org videos')
    assert(ArchiveOrgIE.ie_key() == 'archive.org')
    assert(ArchiveOrgIE.ie_desc() == 'archive.org videos')

# Generated at 2022-06-24 12:07:23.521291
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:29.109795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorgIE = ArchiveOrgIE()
    url = 'https://archive.org/details/popeye_dizzy_dancers'
    webpage = archiveorgIE._download_webpage(
               'https://archive.org/embed/popeye_dizzy_dancers',
               'popeye_dizzy_dancers')
    print(archiveorgIE._parse_html5_media_entries(url, webpage, 'popeye_dizzy_dancers'))

# Generated at 2022-06-24 12:07:35.660900
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.set_progress_hook(lambda x: x)

    # Test URLs
    ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie.extract("http://archive.org/details/Cops1922")
    ie.extract("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie.extract("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")

# Generated at 2022-06-24 12:07:36.435600
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        assert True
    except Exception:
        assert False

# Generated at 2022-06-24 12:07:37.892566
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:49.557455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.__name__ == 'archiveorg'
    assert ie.SUFFIX == '.ogg'
    assert ie.src == 'http://www.archive.org/download/'
    assert ie._TEMPLATE_URL == 'http://www.archive.org/download/%s/%s_archive.mp4'
    assert ie._video_direct_url == 'http://www.archive.org/download/%s/%s_archive.mp4'
    assert ie.url_trans

# Generated at 2022-06-24 12:08:03.012638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: remove when https://github.com/rg3/youtube-dl/pull/1878 is merged
    from ..YoutubeDL import YoutubeDL
    from ..compat import compat_urllib_parse
    from .common import InfoExtractor
    url = 'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    ie.to_screen("test: initiating download of %s" % url)
    data = ie._download_webpage(url, video_id="test", fatal=True)
    assert data, "data is empty"
    assert ie.IE_NAME, "ie.IE_NAME is empty"
    assert ie.IE_DESC, "ie.IE_DESC is empty"
    assert ie._VALID_

# Generated at 2022-06-24 12:08:10.208037
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert (r'https://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/'
        r'XD300-23_68HighlightsAResearchCntAugHumanIntellect.ogg') == (
            ArchiveOrgIE()._real_extract(
                'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')[
                    'url'])

# Generated at 2022-06-24 12:08:15.847606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:17.820115
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:26.635816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda url, video_id: '<meta name="mediatorrent" content="http://ia601600.us.archive.org/31/items/Vuze-4.4.0.0-18108-01-20-2012-Windows/Vuze_4.4.0.0_18108-01-20-2012_Windows.torrent"/>'
    result = ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:33.229724
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Make sure it works with a YouTube URL
    ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Make sure it works with a direct link to a video
    ArchiveOrgIE('https://www.youtube.com/watch?v=BaW_jenozKc')
    # Make sure it works with a direct link to a video with the embed URL
    ArchiveOrgIE('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:33.805539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:08:35.071028
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:41.600632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_info = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        #'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        #'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        #'release_date': '19681210',
        'uploader': 'SRI International',
        #'timestamp': 1268695290,
        #'upload_date': '20100315',
    }
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description()

# Generated at 2022-06-24 12:08:51.703572
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:53.729940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  archiveorg = ArchiveOrgIE()
  assert archiveorg.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:56.356359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:09:00.608963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Make sure 'url' is a required parameter
    with pytest.raises(TypeError):
        ArchiveOrgIE()

    # Make sure url is a 'unicode' string
    with pytest.raises(AssertionError):
        ArchiveOrgIE('http://archive.org')

    ie = ArchiveOrgIE('http://archive.org')
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:09:01.137409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:09:02.483935
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'


# Generated at 2022-06-24 12:09:05.699036
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie.ie_key() == 'archive.org'
    assert ie.host == 'archive.org'
    assert ie.url_re == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.working == True
    assert ie.age_limit == 0

# Generated at 2022-06-24 12:09:10.394490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:09:22.117387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .common import SearchInfoExtractor
    from .common import httpretrieve
    ie = ArchiveOrgIE({"downloader": None, "httpretrieve": httpretrieve, "extractor": InfoExtractor({"downloader": None, "httpretrieve": httpretrieve})})
    assert ie.__class__ == ArchiveOrgIE
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'
    assert ie.httpretrieve == httpretrieve
    assert ie.extractor == InfoExtractor({"downloader": None, "httpretrieve": httpretrieve})
    assert ie.downloader == None
    assert ie.extractor.__class__ == InfoExtractor
    assert ie.extractor.downloader == None
    assert ie.extractor

# Generated at 2022-06-24 12:09:23.658729
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME is not None

# Generated at 2022-06-24 12:09:27.715094
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:09:29.806816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test:
    #     constructor of ArchiveOrgIE
    # Expect:
    #     instance of ArchiveOrgIE should be returned
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-24 12:09:34.057695
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('test')

# Generated at 2022-06-24 12:09:39.723963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test the initial constructor of ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:45.601474
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of class ArchiveOrgIE
    
    # Create new class
    archive_org_ie = ArchiveOrgIE()
    # Check member variables
    assert archive_org_ie.IE_NAME == 'archive.org'
    assert archive_org_ie.IE_DESC == 'archive.org videos'
    assert archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:55.511735
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:09:57.218373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:09:58.289858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:00.329862
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:10.569858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org', {})._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }


# Generated at 2022-06-24 12:10:22.225298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE.suitable(url)
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE.VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:23.289078
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE())

# Generated at 2022-06-24 12:10:24.225322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:10:35.204714
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:10:37.667127
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:10:40.145662
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        archive_org_ie = ArchiveOrgIE()
    except Exception as e:
        print("Exception occurred : " + str(e))

# Generated at 2022-06-24 12:10:52.025716
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class args(object):
        def __init__(self, tmplt):
            self.tmplt = tmplt
    testargs = args("%(title)s-%(id)s.%(ext)s")
    testUrl = "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    testVideoId = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    testVideoTitle = "1968 Demo - FJCC Conference Presentation Reel #1"

    returnArchiveOrgIE = ArchiveOrgIE()

    # Testing the constructor of ArchiveOrgIE class
    assert (returnArchiveOrgIE.ie_key() == 'ArchiveOrg')

# Generated at 2022-06-24 12:10:54.587123
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    AO = ArchiveOrgIE()
    assert(AO.IE_NAME == "archive.org")

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:01.870622
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test for legacy jwplayer playlist
    ie = ArchiveOrgIE({'url': 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'})
    assert ie.media_id == "MSNBCW_20131125_040000_To_Catch_a_Predator"

    # test for non jwplayer playlist
    ie = ArchiveOrgIE({'url': 'https://archive.org/details/Cops1922'})
    assert ie.media_id == "Cops1922"

# Generated at 2022-06-24 12:11:04.533062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:11:07.438951
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:17.339216
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    original_call_method = ArchiveOrgIE.call_method
    original_urlopen = ArchiveOrgIE.urlopen
    try:
        ArchiveOrgIE.call_method = lambda *a: None
        ArchiveOrgIE.urlopen = lambda *a: None

        # The last test case doesn't have a valid URL because the URL and
        # the video id are not the same, so it will cause an unexpected
        # situation because it will download the web page for the video id,
        # not for the URL.
        tests = ArchiveOrgIE._TESTS
        ArchiveOrgIE._TESTS = tests[:2]
        ArchiveOrgIE('test')
    finally:
        ArchiveOrgIE.call_method = original_call_method
        ArchiveOrgIE.urlopen = original_urlopen
        ArchiveOrgIE._TESTS = tests

# Generated at 2022-06-24 12:11:18.224414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    p = ArchiveOrgIE()
    assert p

# Generated at 2022-06-24 12:11:18.740773
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:11:20.134143
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()
    raise Exception("Construction of ArchiveOrgIE failed.")


# Generated at 2022-06-24 12:11:26.834272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_CLASS = ArchiveOrgIE
    # Test case for constructing ArchiveOrgIE class
    murl = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect&output=json'
    vid = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:11:28.809096
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #constructor of ArchiveOrgIE class
    assert(str(ArchiveOrgIE ) == "<class 'youtube_dl.extractor.archive.org.ArchiveOrgIE'>")

# Generated at 2022-06-24 12:11:29.583253
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE({})

# Generated at 2022-06-24 12:11:36.705033
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        extract_attributes,
        unescapeHTML,
    )
    from .archiveorg import ArchiveOrgIE

# Generated at 2022-06-24 12:11:38.304153
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE


# Generated at 2022-06-24 12:11:47.443070
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    import os.path
    import urllib
    from .common import InfoExtractor
    from .common import ExtractorError
    from .common import SearchInfoExtractor
    from .common import FileDownloader


# Generated at 2022-06-24 12:11:48.640557
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org')


# Generated at 2022-06-24 12:11:52.519820
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:55.172913
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'

# Generated at 2022-06-24 12:11:57.387756
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a is not None
    return True

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:59.122665
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # This test will capture any new warnings introduced.
    assert ie

# Generated at 2022-06-24 12:12:00.295015
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:12:06.018896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print(repr(ie))
    assert(ie.IE_NAME == 'iarchiveorg')
    assert(ie.IE_DESC == 'Internet Archive')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie._TESTS == [
        {'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'}
        ]
    )

# Generated at 2022-06-24 12:12:10.810965
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """testing constructor of the class ArchiveOrgIE"""
    _inst = ArchiveOrgIE("archive.org")
    assert _inst.IE_NAME == "archive.org", "IE Name should be archive.org"
    assert _inst.IE_DESC == "archive.org videos", "IE Description should be archive.org videos"

# Generated at 2022-06-24 12:12:13.149099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    with pytest.raises(AttributeError):
        infoExtractor = ArchiveOrgIE('smile.org', 'smile.org')
        infoExtractor._real_initialize()

# Generated at 2022-06-24 12:12:14.008049
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:14.753428
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:12:15.518266
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:17.733594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:22.759886
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:29.863109
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('test_ArchiveOrgIE', {})
    assert ie != None
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS != None

# Generated at 2022-06-24 12:12:33.985908
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test when there is no video in the given url
    url = 'http://archive.org/details/'
    ie = ArchiveOrgIE(url)
    assert ie.url == url
    with pytest.raises(ExtractorError):
        ie.extract()

# Generated at 2022-06-24 12:12:34.785643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:38.482644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.ie_name() == 'archive.org'

# Generated at 2022-06-24 12:12:46.306308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archive.org")
    assert ie.name == "archive.org"
    assert ie.description == "archive.org videos"
    assert ie.valid_url("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.valid_url("https://archive.org/details/Cops1922")
    assert ie.valid_url("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.valid_url("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/") == False

# Generated at 2022-06-24 12:12:49.089931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:58.680183
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    assert extractor.IE_NAME == 'archive.org'
    assert extractor.IE_DESC == 'archive.org videos'
    assert extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:13:00.117682
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ = ArchiveOrgIE('dummy')

# Generated at 2022-06-24 12:13:07.128470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tests if video url is correct
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_url = 'http://archive.org/details/' + video_id
    assert ArchiveOrgIE(video_url).video_id == video_id

    video_url = 'http://archive.org/embed/' + video_id
    assert ArchiveOrgIE(video_url).video_id == video_id

    video_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE(video_url).video_id == video_id

    video_url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:13:13.135291
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'