

# Generated at 2022-06-24 12:03:17.863568
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for an Invalid URL
    invalid_url = 'https://archive.org/embed/Cops1922?playlist=1'
    ie = ArchiveOrgIE()
    assert ie.suitable(invalid_url) == False

    # Test for a valid URL
    valid_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    assert ie.suitable(valid_url) == True

    # Test for a valid URL with 'embed'
    valid_url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    assert ie.suitable(valid_url) == True

# Generated at 2022-06-24 12:03:20.498246
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    unit_test = ArchiveOrgIE({})
    unit_test.IE_NAME = 'archive.org'
    unit_test.IE_DESC = 'archive.org videos'
    unit_test.init()

# Generated at 2022-06-24 12:03:28.793679
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE("")
    assert inst.IE_NAME == "archive.org"
    assert inst.IE_DESC == "archive.org videos"
    assert inst._VALID_URL[1] == "^https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)$"
    assert inst._TESTS[1]["url"] == "https://archive.org/details/Cops1922"
    assert inst._TESTS[1]["md5"] == "0869000b4ce265e8ca62738b336b268a"
    assert inst._TESTS[1]["info_dict"]["id"] == "Cops1922"

# Generated at 2022-06-24 12:03:32.040163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-24 12:03:38.839236
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME is 'archive.org'
    assert ie.IE_DESC is 'archive.org videos'
    #assert ie.VALID_URL is 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.VALID_URL is 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:43.951720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('ArchiveOrgIE')
    # tests that are run as part of this file

# Generated at 2022-06-24 12:03:47.795537
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    assert ArchiveOrgIE
    #c = ArchiveOrgIE()
    #assert c
    #assert ArchiveOrgIE == type(c)


# Generated at 2022-06-24 12:03:58.698613
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test regular URLs
    for url in ('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                'https://archive.org/details/Cops1922'):
        ie._match_id(url)
    # Test URLs for the player for the video

# Generated at 2022-06-24 12:04:07.691630
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    ie = ArchiveOrgIE("https://archive.org/details/Cops1922")
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:04:18.330262
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:22.033906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE().suitable(url)

# Generated at 2022-06-24 12:04:24.423335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:04:28.258444
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:39.848164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:04:41.229672
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:42.256690
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:52.093912
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:02.792550
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:05.662144
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_object = ArchiveOrgIE()
    assert ie_object.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:05:06.402392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.initialize()

# Generated at 2022-06-24 12:05:12.776467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:16.813841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:05:18.916775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE().IE_NAME
    assert 'archive.org videos' == ArchiveOrgIE().IE_DESC

# Generated at 2022-06-24 12:05:19.900648
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:05:30.092331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:38.179489
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE"""
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)

    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:05:40.622185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie.ie_key() == 'ArchiveOrg')

# Generated at 2022-06-24 12:05:44.341067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:48.986921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert(ie.IE_NAME == 'archive.org')
	assert(ie.IE_DESC == 'archive.org videos')
# test_ArchiveOrgIE()

# Generated at 2022-06-24 12:05:58.263884
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class ArchiveOrgIE_test(ArchiveOrgIE):
        def _real_extract(self, url):
            return super(ArchiveOrgIE_test, self)._real_extract(url)

    youtube_ie = ArchiveOrgIE_test()

# Generated at 2022-06-24 12:06:00.023104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE([])
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:06:02.605172
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(
        {'extractor': ArchiveOrgIE.IE_NAME})._search_regex(
        "http://archive.org/details/", "testtext",
        "testregex") == ""

# Generated at 2022-06-24 12:06:06.297705
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:06:17.802092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test_ArchiveOrgIEAssertions():
        ie = ArchiveOrgIE()
        assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
        assert ie.IE_NAME == 'archive.org'
        assert ie.IE_DESC == 'archive.org videos'
        assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
        assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:06:22.970760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  archiveorg = ArchiveOrgIE()
  assert archiveorg.ie_key() == 'archive.org'
  assert archiveorg.ie_desc() == 'archive.org videos'
  assert archiveorg.ie_name() == 'archive.org'

# Generated at 2022-06-24 12:06:30.994486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        # 1. Normal video
        {
            'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'object': ArchiveOrgIE(
                name = 'archive.org',
                ie_key = 'ArchiveOrg',
                ie = 'archive.org',
                ie_desc = 'archive.org videos'
            )
        },

        # 2. Not found
        {
            'url': 'http://archive.org/details/XXD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'object': None
        }
    ]

    # Test
    for test_case in test_cases:
        url = test_case['url']
        object = test_case.get('object')
       

# Generated at 2022-06-24 12:06:40.367154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'
    assert ArchiveOrgIE(None).IE_DESC == 'archive.org videos'
    #assert ArchiveOrgIE(None)._VALID_URL == r'(https?)://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE(None)._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE(None)._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:06:46.862374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    fra = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    fra = 'http://archive.org/details/Cops1922'
    info = ArchiveOrgIE()._real_extract(fra)
    assert type(info) == dict
    for i in info:
        print(i, info[i])

# Generated at 2022-06-24 12:06:57.693462
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:02.974335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:07:06.319044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:07:08.182062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE."""
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-24 12:07:12.040748
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie.IE_NAME, basestring)
    assert isinstance(ie.IE_DESC, basestring)
    assert ie._VALID_URL

# Generated at 2022-06-24 12:07:12.970169
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)


# Generated at 2022-06-24 12:07:22.191874
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # file object
    fileobj = open('files/UploadArchiveOrg.json')
    ArchiveOrgIE()._get_json_data(fileobj)
    # unicode string
    ArchiveOrgIE()._get_json_data('{"e": "\\u03c0", "z": 1.618}')
    # byte string
    ArchiveOrgIE()._get_json_data(b'{"e": "\xe0\xa4\xb9", "z": 1.618}')
    # malformed string
    ArchiveOrgIE()._get_json_data('{"e": "\\u03c0", "z": 1.618')

# Generated at 2022-06-24 12:07:30.215555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for instatiation of ArchiveOrgIE objects.
    """
    classname = 'ArchiveOrgIE'
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    class_ = globals()[classname]
    ie = class_(None)
    obj = class_.suitable(url) and class_.ie_key()
    assert obj == classname
    assert(ie.ie_key() == classname)
    assert(ie.suitable(url))

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:07:37.616997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:39.720124
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ArchiveOrgIE = ArchiveOrgIE()
    assert(isinstance(_ArchiveOrgIE, InfoExtractor))

# Generated at 2022-06-24 12:07:41.763155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:42.390298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    TestArchiveOrgIE = ArchiveOrgIE()



# Generated at 2022-06-24 12:07:52.061723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import Options
    from .downloader import FileDownloader
    from .extractor import gen_extractors
    from .utils import match_filter_func
    opts = Options()
    opts.age_limit = 18
    opts.ssl_verify = False
    # python unit testing issue: https://bugs.python.org/issue1927
    if not hasattr(opts, 'format'):
        opts.format = ''
    fd = FileDownloader(opts)
    ie = ArchiveOrgIE()
    ie.gen_extractors = gen_extractors.copy()
    ie.gen_extractors['playlist'].append(ie)
    ie.match_filter_func = match_filter_func

# Generated at 2022-06-24 12:07:55.855571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    

# Generated at 2022-06-24 12:08:01.498606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    testsuite = unittest.TestSuite()

    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # URL to test
    url = 'http://archive.org/details/' + video_id

    # init an instance
    ie = ArchiveOrgIE()

    # If the instance has a _real_initialize method, run() it
    if hasattr(ie, '_real_initialize'):
        ie._real_initialize()

    testsuite.addTest(ArchiveOrgIE(ie, url))

    return testsuite

if __name__ == "__main__":
    import unittest
    unittest.main(defaultTest='test_ArchiveOrgIE')

# Generated at 2022-06-24 12:08:03.240932
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  ie = ArchiveOrgIE('archive.org')


# Generated at 2022-06-24 12:08:09.266164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testing constructor without any arguments
    ArchiveOrgIE()
    # Testing constructor with arguments:
    # ie_key can be any string
    ArchiveOrgIE(ie_key = "test_key")
    # If invalid ie_key is passed, it still makes an instance of class.
    ArchiveOrgIE(ie_key = "invalid_ie_key")

# Generated at 2022-06-24 12:08:13.886129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    playback_url = 'https://archive.org/download/' + video_id + '/XD300-23_68HighlightsAResearchCntAugHumanIntellect_512kb.mp4'

    ex = ArchiveOrgIE(None)
    info = ex._extract_info_dict(video_id, playback_url, None, None, {}, 'test title')
    assert info['id'] == video_id
    assert info['title'] == 'test title'

# Generated at 2022-06-24 12:08:21.984718
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._match_id("https://archive.org/details/Cops1922") == "Cops1922"
    assert ie._match_id("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect") == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"


# Generated at 2022-06-24 12:08:23.192471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Just test the constructor of ArchiveOrgIE class"""
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:24.283045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:08:30.251832
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_utils import TestIE
    global ArchiveOrgIE
    ArchiveOrgIE = TestIE(ArchiveOrgIE)
    # only run this test once after class ArchiveOrgIE is created
    ArchiveOrgIE.test()

# Generated at 2022-06-24 12:08:40.974163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_constructor = getattr(ArchiveOrgIE, 'suitable')
    assert class_constructor('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert class_constructor('https://archive.org/details/Cops1922')
    assert not class_constructor('https://archive.org/details/Cops1922/')
    assert not class_constructor('https://www.archive.org/details/Cops1922')
    assert class_constructor('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert class_constructor('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-24 12:08:41.929487
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:51.925959
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    m = ArchiveOrgIE()

    assert m.IE_NAME == 'archive.org'
    assert m.IE_DESC == 'archive.org videos'
    assert m._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert m._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert m._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert m._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:08:52.617444
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:08:55.169471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-24 12:08:56.409846
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:57.442518
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_initialize()

# Generated at 2022-06-24 12:09:00.102122
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    assert result

# Generated at 2022-06-24 12:09:03.270006
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:04.072625
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test ArchiveOrgIE.__init__
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:07.118075
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:09:08.710736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:09:09.530249
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:11.253048
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL



# Generated at 2022-06-24 12:09:13.791251
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from unittest import makeSuite, TestSuite, TextTestRunner
    suite = TestSuite()
    suite.addTest(makeSuite(test_ArchiveOrgIE))
    TextTestRunner().run(suite)

# Generated at 2022-06-24 12:09:15.863357
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:16.883026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("test")

# Generated at 2022-06-24 12:09:18.330554
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:27.923027
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert not ie._WORKING

# Generated at 2022-06-24 12:09:34.679392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:39.402705
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:42.928038
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    I = ArchiveOrgIE()
    assert I._TESTS[0]['url'] == url
    assert I._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:09:44.369911
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:46.297849
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Tests that ArchiveOrgIE is a valid class."""
    i = ArchiveOrgIE()
    assert i.__name__ == 'ArchiveOrg'

# Generated at 2022-06-24 12:09:50.461309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    instance.suitable("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    instance.suitable("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:09:53.913432
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect", "http://archive.org/details")
    assert test_obj != None


# Generated at 2022-06-24 12:09:54.553301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:09:55.506093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ar = ArchiveOrgIE()
    ar.IE_NAME

# Generated at 2022-06-24 12:10:00.199360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert 'archive.org' == ie.IE_NAME
    assert 'archive.org videos' == ie.IE_DESC
    assert 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' == ie._VALID_URL
    assert _TESTS == ie._TESTS

# Generated at 2022-06-24 12:10:00.762391
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:05.182733
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:10:05.589153
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:10:11.287446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert_true('description' in info, info)
    assert_true('timestamp' in info, info)
    assert_true('upload_date' in info, info)
    assert_true('uploader' in info, info)
    assert_true('release_date' in info, info)
    assert_true('creator' in info, info)

# Generated at 2022-06-24 12:10:13.501595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    str_represention = unicode(obj)
    assert 'ArchiveOrgIE' in str_represention

# Generated at 2022-06-24 12:10:22.599243
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(url, video_id)
    playlist = ie._search_regex(r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage, 'playlist', default=None)
    attrs = extract_attributes(playlist)
    playlist = attrs.get('value')
    jwplayer_playlist = ie._parse_json(playlist, video_id, fatal=False)

# Generated at 2022-06-24 12:10:31.651535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    v = ArchiveOrgIE(params)
    res = v.extract("http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert(res['id'] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert(res['ext'] == "ogg")
    assert(res['title'] == "1968 Demo - FJCC Conference Presentation Reel #1")
    assert(res['description'] == "1968 Demo - FJCC Conference Presentation Reel #1")
    assert(res['creator'] == "SRI International")
    assert(res['release_date'] == "19681210")
    assert(res['uploader'] == "SRI International")
    assert(res['timestamp'] == 1268695290)

# Generated at 2022-06-24 12:10:32.474299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    result = ArchiveOrgIE()
    assert result is not None

# Generated at 2022-06-24 12:10:33.346767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:34.738555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert isinstance(ArchiveOrgIE().IE_NAME, str)

# Generated at 2022-06-24 12:10:36.095691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME in list(list(InfoExtractor.get_info_extractors().items()))[0]

# Generated at 2022-06-24 12:10:39.001610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie
    assert archive_org_ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:47.321293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # check _real_extract function

# Generated at 2022-06-24 12:10:57.086995
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:58.937216
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test if ArchiveOrgIE can be constructed
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:00.629994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'



# Generated at 2022-06-24 12:11:01.673285
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-24 12:11:13.817459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Testing ArchiveOrgIE function """
    # Basic test: extract ID from URL
    x = ArchiveOrgIE()
    assert x._is_valid_url(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Basic test 2: clip ()
    assert x._is_valid_url(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Basic test 3: clip ()
    assert x._is_valid_url(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Basic test 4: clip ()

# Generated at 2022-06-24 12:11:21.338795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:25.885167
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:32.270498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE._real_extract(url)
    """
    url = 'https://archive.org/details/Cops1922'
    from ..test import get_testcases
    try:
        with get_testcases(url, None, None) as testcases:
            if len(testcases) == 0:
                print("No test case found for url: " + url)
            else:
                for testcase in testcases:
                    ArchiveOrgIE()._real_extract(url=url)
                    break
    except BaseException as error:
        print("Error: ", error)
        return False
    return True

# Generated at 2022-06-24 12:11:44.532935
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    ytdl = YouTubeDL()

    url_1 = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url_2 = 'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    url_3 = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    ie = ytdl.extract_info(url_1, download=False)
    assert ie.get('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # Test whether the timestamp is valid
    assert ie.get('timestamp') == 1268695290

    # Test whether the description is valid
   

# Generated at 2022-06-24 12:11:49.669994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    INIT_TEST = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test = type('Test', (ArchiveOrgIE,), {})(None)
    assert test._VALID_URL == ArchiveOrgIE._VALID_URL, '__init__ should not update class instance attributes'
    assert test._match_id(INIT_TEST) == ArchiveOrgIE._match_id(INIT_TEST), '__init__ should not update to class instance attributes'

# Generated at 2022-06-24 12:11:51.578770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect");

# Generated at 2022-06-24 12:11:52.196654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:54.873875
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.to_screen("test")
    ie.report_warning("test2")

# Generated at 2022-06-24 12:11:55.752910
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None


# Generated at 2022-06-24 12:11:57.954123
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    unit_test(ArchiveOrgIE, [
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ])

# Generated at 2022-06-24 12:12:01.576080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Fetch a web page and return the page source back
    """
    url='http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)
    page = ie._download_webpage(url)
    return page

# Generated at 2022-06-24 12:12:11.937660
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:15.171743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:20.469671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test if constructor of ArchiveOrgIE is working
    """
    ao_ie = ArchiveOrgIE()
    assert ao_ie.IE_NAME is 'archive.org'
    assert ao_ie.IE_DESC is 'archive.org videos'
    assert ao_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:25.372856
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
        Unit tests for constructor of ArchiveOrgIE
    """
    from .common import InfoExtractor

    ie = InfoExtractor(True, {'extractor': 'archive.org'}, True, None)
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:12:26.848150
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_equal(ArchiveOrgIE().ie_key(),'archive.org')

# Generated at 2022-06-24 12:12:29.689484
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    AuToIE.test_ArchiveOrgIE(ArchiveOrgIE, url)

# Generated at 2022-06-24 12:12:30.893629
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	v = ArchiveOrgIE()


# Generated at 2022-06-24 12:12:42.307373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:44.141614
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class TestArchiveOrgIE(ArchiveOrgIE):
        def _real_extract(self, url):
            return None
    assert TestArchiveOrgIE({}).ie_key() == ArchiveOrgIE.ie_key()


# Generated at 2022-06-24 12:12:49.432762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['ext'] == 'ogg'
    assert ie

# Generated at 2022-06-24 12:12:58.804863
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/starwars_game_commercial')
    jwplayer_playlist = info['formats']
    video_id = info['id']
    assert video_id == 'starwars_game_commercial'
    assert info['title'] == 'Star Wars: Rebel Assault (1993) - PC CD-ROM Commercial'
    assert info['description'] == 'A commercial for the CD-ROM game Star Wars: Rebel Assault.'
    assert info['creator'] == 'Abandoned Arcade'
    assert info['release_date'] == '20110101'
    assert info['uploader'] == 'Abandoned Arcade'
    assert info['timestamp'] == 1294335057
    assert len(jwplayer_playlist) == 1

# Generated at 2022-06-24 12:13:01.048224
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert test_obj.IE_NAME == 'archive.org'
    assert test_obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:13:03.892698
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:13:06.775125
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:13:08.213264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'