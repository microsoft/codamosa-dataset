

# Generated at 2022-06-24 12:03:10.639535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()
	assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:15.386330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url() == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:17.325608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test failed initialisation
    with pytest.raises(AttributeError, message="This should fail"):
        ArchiveOrgIE()

# Generated at 2022-06-24 12:03:18.790206
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test creation of ArchiveOrgIE"""
    ie = ArchiveOrgIE()
    ie._download_xml

# Generated at 2022-06-24 12:03:20.126349
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:03:22.361284
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    info = info_extractor.extract('https://archive.org/details/test')
    assert(info['id'] == 'test')

# Generated at 2022-06-24 12:03:23.061798
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:23.861691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("archive.org").IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:03:24.650402
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  assert ArchiveOrgIE().IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:03:26.401698
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:36.868417
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:45.386556
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import logging
    logging.getLogger().setLevel(logging.DEBUG)
    url_list = [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/Cops1922',
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator',
        ]
    myIE = ArchiveOrgIE()
    for url in url_list:
        a = myIE.url_result(url)

# Generated at 2022-06-24 12:03:58.603355
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class TestArchiveOrgIE(ArchiveOrgIE):
        def _download_json(self, *args, **kwargs):
            return {
                'metadata': {
                    'contributor': 'contributor_value',
                    'creator': 'creator_value',
                    'date': 'date_value',
                    'description': 'description_value',
                    'language': 'language_value',
                    'publisher': 'publisher_value',
                    'title': 'title_value'
                }
            }
    # Check that the extractor returns a valid title if the json has no media
    info = TestArchiveOrgIE().extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info.get('title') == 'title_value'



# Generated at 2022-06-24 12:04:00.501991
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:03.609615
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('http://ia600401.us.archive.org/31/items/Holmes_Arthur_Drake_1912_Giants_in_the_earth/bigfellascene.mp4')

# Generated at 2022-06-24 12:04:11.495963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect');
    expected_results = {'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                        'ext': 'ogg',
                        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
                        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
                        'creator': 'SRI International',
                        'release_date': '19681210',
                        'uploader': 'SRI International',
                        'timestamp': 1268695290,
                        'upload_date': '20100315'}

    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_

# Generated at 2022-06-24 12:04:13.615391
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'

# Generated at 2022-06-24 12:04:16.463797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org', 'Wrong ie_key value'
    assert ie.ie_desc() == 'archive.org videos', 'Wrong ie_desc value'
    assert ie.ie_name() == 'archive.org', 'Wrong ie_name value'

# Generated at 2022-06-24 12:04:20.546694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tests to see if ArchiveOrgIE can be instantiated when running this file
    return ArchiveOrgIE()

# Generated at 2022-06-24 12:04:29.859482
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:30.629014
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE.ie_key('archive.org');

# Generated at 2022-06-24 12:04:40.185858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import json
    import os
    import sys

    # Load the test cases from module data
    json_data = open(os.path.join(os.path.dirname(__file__), 'test/data/archive_org.json'))
    archive_org_testcases = json.load(json_data)

    # Register the IE so _real_extract can be tested
    ie = archiveorg.ie.ArchiveOrgIE()

    # Iterate through the test cases and run _real_extract on each
    test_failures = list()
    for index, testcase in enumerate(archive_org_testcases):
        print("Running test case " + str(index + 1) + " for " + testcase['url'])

# Generated at 2022-06-24 12:04:44.177822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert archive.IE_NAME == 'archive.org'
    assert archive.IE_DESC == 'archive.org videos'

# Unit tests for _real_extract method of class ArchiveOrgIE

# Generated at 2022-06-24 12:04:44.708178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:53.961908
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:00.151826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if not hasattr(InfoExtractor, '_get_id_from_url'):
        return

    ie = ArchiveOrgIE()
    e = ie.extract('https://example.com/details/Cops1922')

# Generated at 2022-06-24 12:05:03.224155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:11.194545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructing ArchiveOrgIE instance
    archiveorg_ie = ArchiveOrgIE()
    # Check if the properties are correctly set
    assert archiveorg_ie.IE_NAME == 'archive.org'
    assert archiveorg_ie.IE_DESC == 'archive.org videos'
    assert archiveorg_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(archiveorg_ie._TESTS) > 0

# Generated at 2022-06-24 12:05:17.384114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = InfoExtractor()
    infoExtractor.add_info_extractor(ArchiveOrgIE())
    InfoExtractor.test_video_url.__func__(infoExtractor, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'md5:8af1d4cf447933ed3c7f4871162602db')

# Generated at 2022-06-24 12:05:20.712448
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({})
    # If this is not a class, exception should be raised
    if inspect.isclass(ArchiveOrgIE):
        return
    else:
        raise TypeError("ArchiveOrgIE is not a class")

# Generated at 2022-06-24 12:05:27.893244
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("http://archive.org/details/BigBuckBunny_328")
    ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie.extract("http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:05:28.777856
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-24 12:05:37.218054
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:05:40.889437
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This is the test for constructor of the class ArchiveOrgIE.
    """
    obj = ArchiveOrgIE()
    assert obj._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:05:41.853191
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    yt = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:43.962140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

    obj = ie.ie_key()
    assert obj == 'ArchiveOrg'

# Generated at 2022-06-24 12:05:49.725264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..extractor import gen_extractors

    # TODO: gen_extractors should not return None
    tester = gen_extractors(ArchiveOrgIE)[0]
    assert tester is not None
    test = tester()
    assert test is not None

# Generated at 2022-06-24 12:05:58.695890
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:05:59.327330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:00.822674
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of class ArchiveOrgIE"""
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:01.391283
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:02.605722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:06:10.653257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:12.868261
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        print("Exception in ArchiveOrgIE")
        return 0
    return 1

# Generated at 2022-06-24 12:06:16.211422
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test for class constructor ArchiveOrgIE
    # initialize with valid URL
    ArchiveOrgIE()._real_initialize() # doctest: +ELLIPSIS
    

# Generated at 2022-06-24 12:06:16.644777
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:21.814723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:25.572046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .constructor import construct_ie
    ie = construct_ie(ArchiveOrgIE.ie_key())
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name == 'archive.org'

# Generated at 2022-06-24 12:06:27.782666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-24 12:06:34.541175
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import oauth2client
        oauth2client.__version__
    except ImportError:
        # Without oauth2client installed, you will see error if run unit test.
        # To avoid it, "return" after "raise" as below
        raise(ImportError('Import Error: oauth2client library is not found!'))
        return
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:37.164867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:06:40.500632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie.extract(url)

# Generated at 2022-06-24 12:06:45.445171
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:46.302115
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:06:47.116208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:52.234742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Basic test
    ArchiveOrgIE(None)._real_initialize()
    # Test Exception
    try:
        ArchiveOrgIE(None)._real_extract("https://archive.org/")
    except Exception as e:
        assert(e.__class__.__name__ == "ExtractorError")

# Generated at 2022-06-24 12:06:59.240986
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:07:09.771876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #create the test object
    ie = ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

    #look at the generated directory structure
    #ie.tree.write("testarchiveorg.html")

    #check the url
    urlmatch = ie._VALID_URL
    #urlmatch = re.compile(r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)', re.IGNORECASE)
    assert(ie.check_url("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"))

# Generated at 2022-06-24 12:07:13.437160
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test the constructor of ArchiveOrgIE.
    """
    ie = ArchiveOrgIE()
    # Test regular expression to extract id.
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie._match_id(url)
    assert video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:07:15.694508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:20.025096
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:20.943846
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:07:21.812615
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:07:28.122291
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert hasattr(ArchiveOrgIE, '_VALID_URL')
    assert hasattr(ArchiveOrgIE, '_TESTS')
    assert hasattr(ArchiveOrgIE, 'IE_NAME')
    assert hasattr(ArchiveOrgIE, 'IE_DESC')
    assert hasattr(ArchiveOrgIE, '_real_extract')
    assert hasattr(ArchiveOrgIE, '_parse_jwplayer_data')

# Test for valid url for class ArchiveOrgIE

# Generated at 2022-06-24 12:07:29.574274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == "ArchiveOrgIE"

# Generated at 2022-06-24 12:07:39.925515
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    extracted_info = {'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                      'ext': 'ogg',
                      'title': '1968 Demo - FJCC Conference Presentation Reel #1',
                      'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
                      'creator': 'SRI International',
                      'release_date': '19681210',
                      'uploader': 'SRI International',
                      'timestamp': 1268695290,
                      'upload_date': '20100315'}

    ie = ArchiveOrgIE()
    info = ie._real_extract(url)

    #

# Generated at 2022-06-24 12:07:45.787272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:50.860615
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    mArchiveOrgIE = ArchiveOrgIE()
    assert mArchiveOrgIE.IE_NAME == 'archive.org'
    assert mArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert mArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:08:03.140489
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import webvtt
        assert webvtt
    except ImportError:
        raise ImportError('Please install webvtt-py with `pip install webvtt-py` for testing ArchiveOrgIE')
    archive_org_test_url = 'https://archive.org/details/BigBuckBunny_328'
    archive_org_test_obj = ArchiveOrgIE(archive_org_test_url)
    assert archive_org_test_obj.IE_NAME == 'archive.org'
    assert archive_org_test_obj.IE_DESC == 'archive.org videos'
    assert archive_org_test_obj._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive_org_test_

# Generated at 2022-06-24 12:08:06.527263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:15.768292
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:16.738121
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:17.654396
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:24.645888
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert test_ArchiveOrgIE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert test_ArchiveOrgIE._match_id(url) == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert test_ArchiveOrgIE._real_extract(url)["id"] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-24 12:08:27.392267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-24 12:08:30.760719
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor doesn't contain any logic, just pass
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:31.347797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:36.826365
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:46.724710
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Example test case used to verify if class constructor is working
    """
    ie_instance = ArchiveOrgIE()
    assert ie_instance.IE_NAME == 'archive.org'
    assert ie_instance.IE_DESC == 'archive.org videos'
    assert ie_instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert not ie_instance.SUPPORTED_FORMATS
    assert not ie_instance.SUPPORTED_EXTENSIONS
    assert ie_instance.IE_VERSION == '2017.10.26.02'

# Generated at 2022-06-24 12:08:51.203526
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert instance.IE_NAME == 'archive.org'
    assert instance.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:09:02.303321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'
    assert a.IE_DESC == 'archive.org videos'
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert a._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert a._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:09:03.110146
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:09:05.033543
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch_org_ie = ArchiveOrgIE()
    assert(arch_org_ie.IE_NAME == 'archive.org')


# Generated at 2022-06-24 12:09:08.218609
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Basic test with example data
    example = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(example)
    assert ie.video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:09:12.657133
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:18.149929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:09:19.091360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-24 12:09:28.523314
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """ Unit tests for ArchiveOrgIE """
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/')
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect#')
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?')

# Generated at 2022-06-24 12:09:41.497618
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .simple_downloader import FakeYDL
    f = FakeYDL()
    video_id = 'Cops1922'
    # Use second test case with video file
    ie = ArchiveOrgIE(f, ArchiveOrgIE._TESTS[1]['url'])
    v = ie._real_extract(ie.url)
    file_url = ie._download_webpage(
        'http://archive.org/download/' + video_id + '/' + video_id + '.mp4', video_id,
        'Downloading video file')
    f._match_filter(file_url, v)
    # Test HTML5 media fallback using third test case
    ie = ArchiveOrgIE(f, ArchiveOrgIE._TESTS[2]['url'])
    v = ie._real_extract(ie.url)

# Generated at 2022-06-24 12:09:51.132216
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda url, filename, *args, **kwargs: '1'
    ie._parse_jwplayer_data = lambda jwplayer_data, video_id, base_url: '2'
    ie._parse_html5_media_entries = lambda url, webpage, video_id: '3'
    ie._download_json = lambda url, video_id, *args, **kwargs: {'metadata': {'title': [None]}}
    assert ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == '2'
    assert ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', download=False)

# Generated at 2022-06-24 12:09:52.074488
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ = ArchiveOrgIE(InfoExtractor("archive.org"))

# Generated at 2022-06-24 12:10:02.664667
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.init()
    # test _VALID_URL
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ie.extract_id(url)
    expected_video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert video_id == expected_video_id
    # test _real_extract
    result = ie._real_extract(url)
    assert result['id'] == expected_video_id
    assert result['ext'] == 'ogg'
    assert result['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:10:06.021268
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This test will check the constructor of the class ArchiveOrgIE by printing its name
    :return:
    """
    obj = ArchiveOrgIE()
    print(obj.IE_NAME)



# Generated at 2022-06-24 12:10:13.362114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a=ArchiveOrgIE()
    assert a.IE_NAME == "archive.org"
    assert a.IE_DESC == "archive.org videos"
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:14.533494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (ie.IE_NAME == ArchiveOrgIE.IE_NAME)
    assert (ie.IE_DESC == ArchiveOrgIE.IE_DESC)

# Generated at 2022-06-24 12:10:16.113864
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    youtube_ie = ArchiveOrgIE()
    assert youtube_ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:10:22.288776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:28.237812
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:29.084769
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()


# Generated at 2022-06-24 12:10:30.916303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        a = ArchiveOrgIE()
        assert(a!=None)
    except:
        assert(False)


# Generated at 2022-06-24 12:10:32.620488
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE

    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:10:33.104277
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:33.580482
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:10:38.951387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:42.828089
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # These are not real tests. This is only a test to make sure that these will
    # not cause a syntax error or exception
    ie._parse_jwplayer_data({'playlist': []}, '1234567890')

# Generated at 2022-06-24 12:10:53.626760
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie._search_regex(r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', 'webpage', 'playlist', default=None)
    ie._download_json('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', query={'output': 'json'})

# Generated at 2022-06-24 12:10:56.056747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(__name__)
    # Instantiate the ArchiveOrgIE class
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:59.387510
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert re.match(ie._VALID_URL, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-24 12:11:11.365746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._is_valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._is_valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._is_valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._is_valid_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:11:12.183061
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:11:21.758864
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    
    # Test the constructor
    ArchiveOrgIE()
    
    # Test the get_media_node function
   
    # create a sample webpage as a string

# Generated at 2022-06-24 12:11:27.213089
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:28.316649
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:11:39.624827
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()

    # Unit test for the method '_real_extract'
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    instance._real_extract(url)
    # print(instance._real_extract(url))

    # Unit test for the method '_parse_html5_media_entries'
    url = 'https://archive.org/details/Cops1922'
    instance._parse_html5_media_entries(url, instance._download_webpage(url, url), url)
    # print(instance._parse_html5_media_entries(url, instance._download_webpage(url, url), url))

    # Unit test for the method '_parse_jwplayer_data'
    url

# Generated at 2022-06-24 12:11:40.578943
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:43.930251
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ia = ArchiveOrgIE()
    assert ia.IE_NAME == 'archive.org'

# Unit test to validate whether ArchiveOrgIE uses the constructor of class InfoExtractor

# Generated at 2022-06-24 12:11:52.394058
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert issubclass(ArchiveOrgIE, InfoExtractor)
    assert ie._VALID_URL is ArchiveOrgIE._VALID_URL
    assert ie._TESTS is ArchiveOrgIE._TESTS
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'

# Generated at 2022-06-24 12:11:53.806091
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:12:02.234691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:12.689613
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:19.467342
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_common import construct_test
    from .test_common import urlopen
    from .test_common import MOCK_URLOPEN
    from .test_common import DummyIE

    DummyIE.ie_key = 'ArchiveOrg'

# Generated at 2022-06-24 12:12:31.035889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # not testing against a real URL, since it is hard to get a consistent result
    # use a fake URL instead
    url = "http:/www.archive.org/path/to/video"

    # constructor should throw an error
    try:
        ie = ArchiveOrgIE()
        ie.extract(url)
    except ValueError:
        pass
    else:
        raise Exception("Should have raised ValueError!")

    # create an instance and call extract()
    ie = ArchiveOrgIE()
    ie.extract(url)

    # check if instance has a set of attributes
    assert ie.url == "http:/www.archive.org/path/to/video"
    assert ie.video_id == "path/to/video"
    assert ie.is_suitable(url) == True

# Generated at 2022-06-24 12:12:42.437044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:43.015841
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:50.218984
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test."""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS

# Generated at 2022-06-24 12:12:52.202215
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE().extract(url)

# Generated at 2022-06-24 12:12:56.047858
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_class = ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:13:00.299465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # We must construct the class and ensure it works for its intended purpose
    ArchiveOrgIE()

# Generated at 2022-06-24 12:13:05.713650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-24 12:13:06.764271
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()



# Generated at 2022-06-24 12:13:08.212283
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    res = ArchiveOrgIE()
    assert isinstance(res, ArchiveOrgIE)