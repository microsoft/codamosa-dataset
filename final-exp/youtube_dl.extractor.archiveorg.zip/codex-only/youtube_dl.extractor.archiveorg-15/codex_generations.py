

# Generated at 2022-06-24 12:03:18.285754
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:03:20.068976
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    assert(ie != None);

# Generated at 2022-06-24 12:03:27.405509
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # test some valid urls
    test_urls = [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/Cops1922',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    ]
    for url in test_urls:
        assert ie._match_id(url)

# Generated at 2022-06-24 12:03:28.549415
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst

# Generated at 2022-06-24 12:03:32.040083
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	archive_org_ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:03:41.433164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import try_get, get_element_by_attribute
    from ..utils import unescapeHTML

    # Test archive.org basic
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.__version__

    # Test archive.org video
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    meta = ie.extract(url)
    assert try_get(meta, lambda x: x['id']) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert try_get(meta, lambda x: x['ext']) == 'ogg'

# Generated at 2022-06-24 12:03:42.616715
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    ao.IE_NAME

# Generated at 2022-06-24 12:03:52.380036
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:03:54.750081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert 'archive.org' == ie._VALID_URL

# Generated at 2022-06-24 12:03:56.406415
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None)
    except Exception as e:
        raise AssertionError(str(e))

# Generated at 2022-06-24 12:03:59.271588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    input = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ArchiveOrgIE(input)

# Generated at 2022-06-24 12:04:03.605533
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:07.491982
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:08.608126
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

# Generated at 2022-06-24 12:04:09.101791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:04:12.274528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert(a.IE_NAME == "archive.org")
    assert(a.IE_DESC == "archive.org videos")
    assert(a._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)")

# Generated at 2022-06-24 12:04:14.727081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:17.134303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"



# Generated at 2022-06-24 12:04:21.966036
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    return a

# Generated at 2022-06-24 12:04:25.111303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE('archive.org').extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:04:27.038265
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert type(ArchiveOrgIE(False)) is ArchiveOrgIE
    # Only check that the constructor doesn't raise
    ArchiveOrgIE(True)

# Generated at 2022-06-24 12:04:38.731900
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test if ArchiveOrgIE constructor can catch an exception
    # where an argument is invalid
    try:
        ie = ArchiveOrgIE(None, 'archive.org', 'archive.org')
    except TypeError:
        pass
    else:
        raise Exception('Failed to throw a TypeError exception. \
                        The constructor of ArchiveOrgIE should catch the exception.')

    # Test if ArchiveOrgIE constructor can catch an exception
    # where an argument is missing
    try:
        ie = ArchiveOrgIE()
    except TypeError:
        pass
    else:
        raise Exception('Failed to throw a TypeError exception. \
                         The constructor of ArchiveOrgIE should catch the exception.')


# Generated at 2022-06-24 12:04:46.305865
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:47.517595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(1)._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:04:49.044840
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:04:49.775311
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:04:54.103097
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None);
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.provides() == ['http', 'https']

# Generated at 2022-06-24 12:04:58.006508
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE();
    # we can not check if unit test is working without this line
    # follow this style to check if unit test is working
    assert(info.ie_key() == 'archive.org');

# Generated at 2022-06-24 12:04:59.942869
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archieveOrgIE = ArchiveOrgIE()
    assert archieveOrgIE.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:05:06.255916
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE.__init__

    This function is intended to be used by test_archive_org_playlist.py
    to ensure that the class ArchiveOrgIE can be constructed.
    """

    _ = ArchiveOrgIE(None, None)

# Generated at 2022-06-24 12:05:12.654905
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie.valid_urls == [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect']

# Generated at 2022-06-24 12:05:23.800672
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    import filecmp, os
    test_cases = [
        # (IE_NAME, expected results)
        # check if an empty InfoExtractor object is constructed correctly
        ('ArchiveOrgIE', {'_downloader': None, 'pwd_inp': None,
                          'params': None, '_ies': [],
                          '_progress_hooks': [], 'ie_key': None,
                          '_num_downloads': None, '_pps': None,
                          '_screen_file': None}),
        ]
    for test_case in test_cases:
        ie = ArchiveOrgIE(test_case[0])
        # check if the IE object is constructed correctly

# Generated at 2022-06-24 12:05:34.301381
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instance of ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:05:36.513778
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:45.226228
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS
    assert ArchiveOrgIE()._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._real_extract('http://archive.org/details/Cops1922')['id'] == 'Cops1922'

# Generated at 2022-06-24 12:05:56.253359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archive.org")
    print("archive.org info extractor: " + ie.IE_NAME)
    print("archive.org info extractor: " + ie.IE_DESC)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    testurl = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info = ie.extract(testurl)
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info

# Generated at 2022-06-24 12:06:05.706082
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instantiate the class
    ie = ArchiveOrgIE()
    # Some tests to prove the class is instantiated correctly
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:09.326038
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._TESTS

# Generated at 2022-06-24 12:06:11.262477
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:06:20.823908
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE
    """
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info_dict = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'release_date': '19681210',
        'upload_date': '20100315',
    }

    ie = ArchiveOrgIE()
    ie.extract(url)

    assert ie.video_info.__dict__ == info_dict

# Generated at 2022-06-24 12:06:29.237929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE(): 
    """ Unit test for constructor of class ArchiveOrgIE"""
    assert type(ArchiveOrgIE._TESTS[1]['url']) == unicode
    assert type(ArchiveOrgIE._TESTS[1]['md5']) == unicode
    assert type(ArchiveOrgIE._TESTS[1]['info_dict']['id']) == unicode
    assert type(ArchiveOrgIE._TESTS[1]['info_dict']['ext']) == unicode
    assert type(ArchiveOrgIE._TESTS[1]['info_dict']['title']) == unicode
    assert type(ArchiveOrgIE._TESTS[1]['info_dict']['description']) == unicode

# Generated at 2022-06-24 12:06:32.484067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE();
    o._real_extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect");

# Generated at 2022-06-24 12:06:42.375290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test import get_testcases
    (test, video_id, video_url, video_title) = get_testcases('youtube')[0]
    assert video_url == 'https://www.youtube.com/watch?v=BaW_jenozKc'
    assert video_id == 'BaW_jenozKc'
    assert video_title == 'youtube-dl test video "\'/\\ä↭'
    (test, video_id, video_url, video_title) = get_testcases('archiveorg')[0]
    assert video_url == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:06:45.293776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:06:47.373031
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org = ArchiveOrgIE()
    assert archive_org
    assert archive_org.IE_NAME == 'archive.org'
    assert archive_org.IE_DESC

# Generated at 2022-06-24 12:06:52.840520
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor_ie = ArchiveOrgIE()
    import logging
    logging.info('__dict__ : {0}'.format(info_extractor_ie.__dict__))
    import pprint
    logging.info('__dict__ : {0}'.format(pprint.pformat(info_extractor_ie.__dict__)))

# Generated at 2022-06-24 12:07:01.628450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/Cops1922'
    archiveorg = ArchiveOrgIE()
    archiveorg.IE_NAME = 'archive.org'
    archiveorg.IE_DESC = 'archive.org videos'
    archiveorg._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:04.941550
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_suite import CommonTests
    CommonTests.test_constructor(ArchiveOrgIE)


# Generated at 2022-06-24 12:07:09.100338
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ok_(info.get('title') != None)

# Generated at 2022-06-24 12:07:13.238892
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE.ie = ArchiveOrgIE()
    assert test_ArchiveOrgIE.ie.IE_NAME == 'archive.org'
    assert test_ArchiveOrgIE.ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:07:24.311962
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	import unittest

	class ArchiveOrgIETest(unittest.TestCase):
		def setUp(self):
			self.ie = ArchiveOrgIE(downloader=None)
			self.url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
			self.id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

		def test_constructor(self):
			self.assertEqual(self.ie.ie_key(), 'archive.org')
			self.assertEqual(self.ie.ie_desc(), 'archive.org videos')

# Generated at 2022-06-24 12:07:33.564312
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).ie_key() == "archive.org"
    assert ArchiveOrgIE(None).ie_desc() == "archive.org videos"
    assert ArchiveOrgIE(None)._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE(None)._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE(None)._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:07:34.362680
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()



# Generated at 2022-06-24 12:07:39.057921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == '(?i)(?:https?://)?(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:41.971157
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-24 12:07:46.792803
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    input = 'Cops1922'
    expected = 'https://archive.org/details/'+input
    assert(ArchiveOrgIE()._real_extract(expected)[0]['url'] == expected)
    assert(ArchiveOrgIE()._real_extract(expected)[0]['id'] == input)



# Generated at 2022-06-24 12:07:49.692216
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:07:53.645377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME is not None

# Generated at 2022-06-24 12:08:01.419855
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    video_id = ie._match_id(url)
    webpage = ie._download_webpage(
            'http://archive.org/embed/' + video_id, video_id)
    assert webpage

# Generated at 2022-06-24 12:08:02.854447
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == "archive.org"

# Generated at 2022-06-24 12:08:04.099226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org');

# Generated at 2022-06-24 12:08:07.982842
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME
    assert ie.IE_DESC
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-24 12:08:13.530584
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    function to test ArchiveOrgIE instance
    """
    ArchiveOrgIE("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:08:22.529769
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from . import videoinfo


    # assert(videoinfo.video_info.func_code.co_argcount == 2)
    assert(videoinfo.video_info.func_code.co_argcount == 1+2)
    assert(videoinfo.video_info.func_code.co_varnames == ('self', 'url'))


    # assert(videoinfo.video_info.im_func.func_code.co_argcount == 2)
    assert(videoinfo.video_info.im_func.func_code.co_argcount == 1+2)
    assert(videoinfo.video_info.im_func.func_code.co_varnames == ('self', 'url'))


    assert(isinstance(videoinfo.video_info.im_class, type))

# Generated at 2022-06-24 12:08:24.284911
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_archive_org import test_ArchiveOrgIE
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:08:25.682345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE().IE_NAME == 'archive.org')


# Generated at 2022-06-24 12:08:26.919927
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor())

# Generated at 2022-06-24 12:08:30.219478
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    yt_ie = ArchiveOrgIE()

    # test url
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    yt_ie._match_id(url)

# Generated at 2022-06-24 12:08:30.811003
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:34.287683
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:08:36.226031
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:37.066017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:39.046034
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:08:49.540310
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE."""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']


# Generated at 2022-06-24 12:08:51.161643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """
    assert ArchiveOrgIE.IE_NAME

# Generated at 2022-06-24 12:08:53.159046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE_DESC = 'archive.org videos'
    assert ArchiveOrgIE.IE_DESC == IE_DESC

# Generated at 2022-06-24 12:08:55.169171
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from .common import InfoExtractor
	ArchiveOrgIE() # Raises but does not fail

# Generated at 2022-06-24 12:08:56.828898
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=invalid-name
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:03.728775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test archive.org constructor with valid URL
    valid_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    valid_test_instance = ArchiveOrgIE(valid_url)
    valid_test_instance.test()
    # Test archive.org constructor with invalid URL
    invalid_url = 'http://archive.org/details/InvalidVideoID'
    invalid_test_instance = ArchiveOrgIE(invalid_url)
    invalid_test_instance.test()

# Generated at 2022-06-24 12:09:04.304133
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:09:04.916465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:13.815094
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of ArchiveOrgIE
    """
    # Test for normal case
    arch = ArchiveOrgIE()
    assert arch.IE_NAME == 'archive.org'
    assert arch.IE_DESC == 'archive.org videos'
    # Without 'r', url doesn't match
    assert not re.match(r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)', 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # 're', but with 'r', url will match

# Generated at 2022-06-24 12:09:16.275826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_exe import ArchiveOrgIE
    test = ArchiveOrgIE()
    return test

# Generated at 2022-06-24 12:09:16.887498
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:17.967029
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()

# Generated at 2022-06-24 12:09:18.574464
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:09:28.123610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    clazz = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(clazz.IE_NAME == 'archive.org')
    assert(clazz.IE_DESC == 'archive.org videos')
    assert(clazz._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(clazz._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(clazz._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')


# Generated at 2022-06-24 12:09:28.641654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:35.270657
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:39.433934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-24 12:09:45.535504
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie.IE_NAME == 'archive.org')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:09:55.415134
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from .test_parser import TestParser
	test_parser = TestParser()
	archive_org_ie = ArchiveOrgIE()
	assert archive_org_ie.IE_NAME == "archive.org"
	assert archive_org_ie.IE_DESC == "archive.org videos"
	assert (archive_org_ie.valid_url("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect") == True)
	assert (archive_org_ie.valid_url("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect") == True)

# Generated at 2022-06-24 12:10:05.489430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    t.to_screen([{
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }])


if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:10:08.172413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import types
    ie = ArchiveOrgIE()
    assert isinstance(ie.extract, types.MethodType)
    assert isinstance(ie._real_extract, types.MethodType)


# Generated at 2022-06-24 12:10:12.924411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:13.859919
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE


# Generated at 2022-06-24 12:10:14.787203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE, InfoExtractor)

# Generated at 2022-06-24 12:10:15.961317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(str(ArchiveOrgIE('archive.org')))

# Generated at 2022-06-24 12:10:22.224485
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:10:23.365921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:28.682462
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_instance = ArchiveOrgIE()
    assert test_instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert test_instance._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    return True

# Generated at 2022-06-24 12:10:30.839088
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'


# Generated at 2022-06-24 12:10:31.836069
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:10:39.194568
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    Video = ArchiveOrgIE("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/?view=1up&amp;playlist=1")
    Video = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    Video = ArchiveOrgIE("https://archive.org/details/Cops1922")

# Generated at 2022-06-24 12:10:40.249965
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)

# Generated at 2022-06-24 12:10:50.881091
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test constructor of class ArchiveOrgIE
    """
    obj = ArchiveOrgIE()
    assert obj.ie_key()== 'ArchiveOrg'
    assert obj.ie_desc()== 'archive.org videos'
    assert obj.ie_name()== 'archive.org'
    assert obj.IE_DESC =='archive.org videos'
    assert obj.IE_NAME =='archive.org'
    assert obj.meta().get('id') == 'archive.org'
    assert obj.meta().get('extractor') == 'ArchiveOrgIE'
    assert obj.meta().get('extractor_key') == 'ArchiveOrg'
    assert obj.meta().get('title') == 'archive.org'

# Generated at 2022-06-24 12:10:52.940554
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE
        assert(True)
    except NameError:
        assert(False)

# Generated at 2022-06-24 12:10:55.178976
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:06.805534
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:11:16.974380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:18.504996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    assert extractor.ie_key() == 'archive.org'


# Generated at 2022-06-24 12:11:19.411944
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:11:23.155764
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:23.686447
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert True

# Generated at 2022-06-24 12:11:30.280190
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    client = ArchiveOrgIE()
    assert client.IE_NAME.lower()
    assert client.IE_DESC
    assert client._VALID_URL
    assert client._TESTS
    assert client.__doc__

# Generated at 2022-06-24 12:11:31.380984
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None, None)



# Generated at 2022-06-24 12:11:37.091748
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:39.718481
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:11:40.667201
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:11:46.558931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

	def test_create_ArchiveOrgIE():
	    assert ArchiveOrgIE, "ArchiveOrgIE does not exist"
	
	def create_test_instance_for_ArchiveOrgIE():
		test_instance = ArchiveOrgIE()	
		assert isinstance(test_instance, ArchiveOrgIE), "create_test_instance_for_ArchiveOrgIE() returned a non-ArchiveOrgIE instance"
		return test_instance
	
	def test_ArchiveOrgIE_creates_IE_instance_with_name_and_description():
		test_instance = create_test_instance_for_ArchiveOrgIE()
		assert test_instance.IE_NAME == "archive.org", "ArchiveOrgIE instance needs to have IE_NAME of 'archive.org'"

# Generated at 2022-06-24 12:11:59.089513
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME == 'archive.org'
    assert archive_org_ie.IE_DESC == 'archive.org videos'
    assert archive_org_ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive_org_ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert archive_org_ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:12:01.536236
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:08.568605
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:11.892819
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('')
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    assert ie._real_extract == ArchiveOrgIE._real_extract

# Generated at 2022-06-24 12:12:13.477241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print('ArchiveOrgIE', ie)



# Generated at 2022-06-24 12:12:17.979182
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if ie._downloader is None:
        assert False, 'No downloader created'
    if ie._WORKAROUND is None:
        assert False, 'No workaround created'
    if ie._downloader_options is None:
        assert False, 'No downloader options created'
    if ie._num_downloads is None:
        assert False, 'No number of downloads created'
    if ie._ies is None:
        assert False, 'No IE created'


# Generated at 2022-06-24 12:12:18.540487
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:12:21.619661
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao.IE_NAME == 'archive.org'
    assert ao.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:12:23.687226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:27.613936
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test case for archive.org.

    Note that it is impossible to unit test this IE (let alone the
    constructor) separately.
    """
    ie = ArchiveOrgIE()



# Generated at 2022-06-24 12:12:28.695120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Make sure zero-argument constructor does not crash
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:36.356186
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch = ArchiveOrgIE()
    assert arch._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:43.100207
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Test if the test cases are not broken
    assert len(ie._TESTS) >= 2
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']

# Generated at 2022-06-24 12:12:55.875091
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	archive_org_IE = ArchiveOrgIE('', {})
	result = archive_org_IE.extract('https://archive.org/details/Cops1922')

	assert result['creator'] == u"Buster Keaton"
	assert result['title'] == u"Buster Keaton's \"Cops\" (1922)"

# Generated at 2022-06-24 12:13:00.298459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:13:02.171434
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Construct an instance of ArchiveOrgIE
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:13:06.520449
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test with object of InfoExtractor
    url = r'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(InfoExtractor())
    assert ie._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:13:08.661650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert type(ArchiveOrgIE) == type
    ArchiveOrgIE.__init__(ArchiveOrgIE)


# Generated at 2022-06-24 12:13:18.009559
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .constructor import make_test
    ie = ArchiveOrgIE()
    ie_urls = ['http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
               'https://archive.org/details/Cops1922',
               'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
               'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
               'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect']