

# Generated at 2022-06-24 12:03:11.456483
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print(ArchiveOrgIE._TESTS)
    print(ArchiveOrgIE._VALID_URL)

# Generated at 2022-06-24 12:03:17.870453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE()
    assert_equal(test_ArchiveOrgIE.IE_NAME, 'archive.org')
    assert_equal(test_ArchiveOrgIE.IE_DESC, 'archive.org videos')

# Generated at 2022-06-24 12:03:21.645538
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	module_name = 'archive.org'
	class_name = 'ArchiveOrgIE'
	# When adding new tests here, please uncomment these lines and
	# update the test_archive_org.py file
	#module = importlib.import_module(module_name)
	#class_ = getattr(module,class_name)
	#ytdl = class_()
	#assert ytdl
	#print "Initialization of " + class_name + " in " + module_name + " passed."

# Generated at 2022-06-24 12:03:27.495443
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    test_IE = ArchiveOrgIE(url)
    assert test_IE.IE_NAME == 'archive.org'
    assert test_IE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:33.875745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:34.820293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-24 12:03:37.251106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:03:40.660706
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org'

# Generated at 2022-06-24 12:03:41.413718
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:47.119069
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:53.424001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO(msteffan): This is a very minimalistic unit test.
    # Consider adding more test cases.
    TestClass = type('TestClass', (object,), dict(ArchiveOrgIE=ArchiveOrgIE))
    with TestClass() as ie:
        # Initialization of the ArchiveOrgIE should not fail
        pass

# Generated at 2022-06-24 12:03:58.607791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:07.612416
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_name = 'ArchiveOrgIE'
    ie = globals()[class_name]()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:18.330557
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global ArchiveOrgIE
    from .common import InfoExtractor

    class EncodingTestIE(InfoExtractor):
        def _real_extract(self, url, data):
            return self._get_information_from_url(url, data, False)['_type']

        def _get_information_from_url(self, url, data, download):
            return {
                '_type': 'playlist',
                'entries': [{
                    '_type': 'url',
                    'url': '%s_%s' % (url, data),
                }]
            }

        def report_warning(self, msg):
            pass

    ie = ArchiveOrgIE(EncodingTestIE('test'))

# Generated at 2022-06-24 12:04:23.252003
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:26.996999
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor for class ArchiveOrgIE
    test_class = ArchiveOrgIE()
    # Ensure return values to be strings
    assert isinstance(test_class.IE_NAME, str)
    assert isinstance(test_class.IE_DESC, str)
    assert isinstance(test_class._VALID_URL, str)

# Generated at 2022-06-24 12:04:33.137855
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None)
    except Exception as e:
        raise AssertionError('Unit test of ArchiveOrgIE constructor failed. %s' % e)



# Generated at 2022-06-24 12:04:36.431948
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    dl = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:38.131474
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()._real_extract
    except:
        print(
            "test_ArchiveOrgIE(): ERROR occurred while testing constructor of \
            class ArchiveOrgIE.")

# Generated at 2022-06-24 12:04:39.951180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:50.706158
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert info_extractor._TYPE == 'playlist'
    assert info_extractor._downloader == None
    assert info_extractor._WORKING == True
    assert info_extractor._html_search_regex == None
    assert info_extractor._html_search_meta == None
    assert info_extractor._json_search_regex == None

# Generated at 2022-06-24 12:04:51.531417
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:54.173624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()
    assert info.IE_NAME == 'archive.org'
    assert info.IE_DESC == 'archive.org videos'
    assert info._VALID_URL != None
    assert info._TESTS != None

# Generated at 2022-06-24 12:04:55.666969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arOrg = ArchiveOrgIE()
    assert arOrg

# Generated at 2022-06-24 12:05:03.114957
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:05:09.017625
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.name == 'archive.org'
    assert ie.description == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:09.827180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    temp = ArchiveOrgIE()
    assert temp


# Generated at 2022-06-24 12:05:13.885239
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:19.672470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:22.279429
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:32.149472
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Initialise class and get object of the class
    test_obj_1 = ArchiveOrgIE()
    assert test_obj_1.IE_NAME == 'archive.org'
    assert test_obj_1.IE_DESC == 'archive.org videos'
    assert test_obj_1._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert test_obj_1.IE_NAME == 'archive.org'
    assert test_obj_1.IE_DESC == 'archive.org videos'
    assert test_obj_1._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:38.689997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE().extract_info(
        'http://archive.org/embed/'
        'XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-24 12:05:40.152511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    assert isinstance(test, ArchiveOrgIE)

# Generated at 2022-06-24 12:05:43.161362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE("archive.org")._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')


# Generated at 2022-06-24 12:05:49.725549
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:56.190752
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:58.185956
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-24 12:06:07.353202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Constructor test ("archive.org" videos)"""

    ie = ArchiveOrgIE(None)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:06:15.280390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """
    ie = ArchiveOrgIE()
    ie.to_screen('Initializing ArchiveOrgIE...')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0].get('url') == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:06:16.367538
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x=ArchiveOrgIE()

# Generated at 2022-06-24 12:06:17.791759
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class FakeArchiveOrgIE(ArchiveOrgIE):
        def _real_extract(self, url):
            pass
    ArchiveOrgIE("test")

# Generated at 2022-06-24 12:06:22.638121
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert not ArchiveOrgIE().working()
    ArchiveOrgIE()._download_json = lambda *args, **kwargs: {'metadata': {}}
    AbcInfoExtractorTest.test_IE(ArchiveOrgIE())

# Generated at 2022-06-24 12:06:24.174266
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 12:06:28.179896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tmp_class = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:29.946734
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoe = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:33.027188
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor test
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_label() == 'Internet Archive'

# Generated at 2022-06-24 12:06:39.636644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test code goes here
    # Test for jwplayer
    assert ArchiveOrgIE({'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'params': {'video_id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'}})
    # Test for HTML5 media
    assert ArchiveOrgIE({'url': 'http://archive.org/details/Cops1922', 'params': {'video_id': 'Cops1922'}})

# Generated at 2022-06-24 12:06:46.183850
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:52.191372
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert isinstance(ao, InfoExtractor)
    assert ao.IE_NAME == 'archive.org'
    assert ao.IE_DESC == 'archive.org videos'
    assert ao._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:56.034796
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc == 'archive.org videos'
    assert ie.extractor_key() == 'archiveOrg'
    assert ie.extractor_desc == 'archive.org videos'

# Generated at 2022-06-24 12:07:05.448031
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archiveorg'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert ie.suitable('http://http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == False
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True

# Generated at 2022-06-24 12:07:07.113340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None)
    except:
        pass

# Generated at 2022-06-24 12:07:14.881872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE('Cops1922', 'http://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:07:20.775812
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:30.674252
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._

# Generated at 2022-06-24 12:07:37.905467
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('test_archive_org_ie.py', 'https://archive.org/details/TEST')
    assert ie.ie_name == 'archive.org'
    assert ie.ie_desc == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:39.150371
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:39.769226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:07:43.116878
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME in globals()
    globals()[ie.IE_NAME] == ie

# Generated at 2022-06-24 12:07:52.458729
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import warnings
    warnings.filterwarnings('ignore')
    ie_test = ArchiveOrgIE('')
    assert ie_test.IE_NAME == 'archive.org'
    assert ie_test.IE_DESC == 'archive.org videos'
    assert ie_test._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:58.261594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-24 12:07:58.639256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:04.014971
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:07.108938
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test that the class can be instantiated.
    ie = ArchiveOrgIE()
    assert type(ie) == ArchiveOrgIE

# Generated at 2022-06-24 12:08:15.961974
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Check that
    # http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    # is extracted correctly.
    xd300_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    xd300_data = ie.extract(xd300_url)
    assert xd300_data['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert xd300_data['ext'] == 'ogg'
    assert xd300_data['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:08:18.178129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:20.068243
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if __name__ == '__main__':
        ie.download_playlist('http://www.archive.org/details/Basic10-01')

# Generated at 2022-06-24 12:08:22.158092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie


# Generated at 2022-06-24 12:08:23.027044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:30.970684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE.IE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE.IE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ArchiveOrgIE.IE._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-24 12:08:35.459347
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('ArchiveOrgIE', 'archive.org videos')
    assert ie.ie_name == 'archive.org'
    assert ie.ie_desc == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:36.163722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()

# Generated at 2022-06-24 12:08:45.552093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    assert (test.IE_NAME == 'archive.org')
    assert (test.IE_DESC == 'archive.org videos')
    assert (test._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:08:52.926612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('test', 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._match_id('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._match_id('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._match_id('http://archive.org/embed/test')
    assert ie._match_id('http://archive.org/details/test')

# Generated at 2022-06-24 12:08:59.358208
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE("archive.org")
    assert archive.IE_NAME == "archive.org"
    assert archive.IE_DESC == "archive.org videos"
    assert archive._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive._TESTS != None
    

# Generated at 2022-06-24 12:09:03.583322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()

    input = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    et = ao._real_extract(input)
    assert et['title'] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert et['creator'] == "SRI International"
    assert et['release_date'] == "19681210"

# Generated at 2022-06-24 12:09:05.605330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("")

# Generated at 2022-06-24 12:09:20.562259
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:09:29.753317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test to see if ArchiveOrgIE is lacking support for an Archive.org video webpage.
    webpage_url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    # Get webpage and parse it to extract a video id.
    webpage = InfoExtractor._download_webpage(
        "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        'Downloading web page',
        """
        <html><head><title>www.archive.org</title></head>
        <body>
        </body></html>
        """)
    # Get the video id within the webpage.
    video_id = InfoExtractor

# Generated at 2022-06-24 12:09:37.537120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:38.364854
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-24 12:09:47.528939
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Check the regex
    assert ie._VALID_URL.search('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').group('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._VALID_URL.search('https://archive.org/details/Cops1922').group('id') == 'Cops1922'
    assert ie._VALID_URL.search('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect').group('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:09:49.012198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)


# Generated at 2022-06-24 12:09:49.600286
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-24 12:09:54.248254
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .common import InfoExtractorTest
    
    # Test constructor
    ie = InfoExtractor({"_type": "private"})
    assert(ie._type == "private")
    ie = InfoExtractor({"_type": "playlist"})
    assert(ie._type == "playlist")

# Generated at 2022-06-24 12:09:59.012203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info.__class__.__name__ == 'ArchiveOrgIE'
    assert info.info_extractor_key == 'archive.org'
    assert info.IE_NAME == 'archive.org'
    assert info.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:04.049768
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: rename method to setUp
    def _set_up(self):
        self.archiveOrgIE = ArchiveOrgIE()
    from unittest import TestCase
    TestCase._setUp = TestCase.setUp
    TestCase.setUp = _set_up


# Generated at 2022-06-24 12:10:08.341326
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:18.859563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import parse_iso8601


# Generated at 2022-06-24 12:10:23.289373
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(InfoExtractor()).IE_NAME == 'archive.org'


# Generated at 2022-06-24 12:10:32.178087
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert ie._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-24 12:10:34.870386
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:10:47.213753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    ie = ArchiveOrgIE()

    # Constructor test case:
    # url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # audio/video stream
    assert ie._VALID_URL.match(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Constructor test case:
    # url = 'http://archive.org/details/Cops1922'
    # audio/video stream
    assert ie._VALID_URL.match(
        'http://archive.org/details/Cops1922')

    # Constructor test case:
    # url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect

# Generated at 2022-06-24 12:10:52.641269
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:10:56.569344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()._download_webpage('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    except:
        return False
    return True


# Generated at 2022-06-24 12:10:58.663067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    h = ie.IE_DESC
    print(h)

# Generated at 2022-06-24 12:11:00.443967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (isinstance(ie,InfoExtractor))

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:11:02.255084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']

# Generated at 2022-06-24 12:11:14.392541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:22.563946
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("foo")
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:31.994748
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:11:37.806606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ie.extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:11:47.235861
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def test(archiveorg_id, upload_date, title, format, width, height, fps, tbr, filesize, expected_filename):
        assert expected_filename == ArchiveOrgIE()._make_filename(archiveorg_id, upload_date, title, format, width, height, fps, tbr, filesize)

    test('test-movie', '20090310', 'test movie title', 'mp4', 640, 480, 29.97, '30', '123456789', 'test-movie-20090310-test_movie_title_640x480-30.mp4')

# Generated at 2022-06-24 12:11:51.676241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (ie.IE_NAME == 'archive.org')
    assert (ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:11:56.805898
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test constructor of ArchiveOrgIE, ie_name, ie_desc and ie_key
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_name == 'archive.org'
    assert ie.ie_key == 'archive.org'
    assert ie.ie_desc == 'archive.org videos'
    # test constructor of InfoExtractor
    ie = InfoExtractor('archive.org')
    assert ie is not None

# Generated at 2022-06-24 12:12:03.637256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test Case #1
    testcase_url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    testcase_re = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ArchiveOrgIE._match_id(testcase_url) == testcase_re
    # Test Case #2
    testcase_url = "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ArchiveOrgIE._match_id(testcase_url) == testcase_re

# Generated at 2022-06-24 12:12:09.666225
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:10.227296
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:18.355797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie._VALID_URL.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL.match('https://archive.org/details/Cops1922')
    assert ie._VALID_URL.match('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._VALID_URL.match('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie._VALID_URL.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?output=json') == None

# Generated at 2022-06-24 12:12:24.299045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie.get_IE_NAME() == 'archive.org'
    assert ie.get_IE_DESC() == 'archive.org videos'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:29.508696
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:41.398369
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.http_headers['User-Agent'] == 'iTunes/9.1.1'
    assert ie.http_headers['Accept'] == 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8'
    assert ie.http_headers['Accept-Charset'] == 'ISO-8859-1,utf-8;q=0.7,*;q=0.7'

# Generated at 2022-06-24 12:12:42.649270
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:12:49.211013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_instance = archiveorg.ArchiveOrgIE()

    # check url
    url = test_instance._match_id(test_url)
    assert url == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # check video id
    video_id = test_instance._real_extract('https://www.youtube.com/watch?v=J5vrFKpmGSg')
    assert video_id == 'J5vrFKpmGSg'

    # check title
    title = test_instance._real_extract('title')
    assert title == '1968 Demo - FJCC Conference Presentation Reel #1'

    # check description

# Generated at 2022-06-24 12:12:49.751036
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:13:00.420233
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Run the default test on ArchiveOrgIE class constructor
    """
    import unittest
    from .common import InfoExtractor

    class NoClass(InfoExtractor):
        def __init__(self,  **kwargs):
            pass

    # Test 1
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.__class__.__name__ is not NoClass.__name__
    assert ie.__class__.__bases__ is not NoClass.__bases__
    # Test 2
    ie = ArchiveOrgIE

# Generated at 2022-06-24 12:13:05.461595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:13:06.853425
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == "ArchiveOrgIE"


# Generated at 2022-06-24 12:13:09.035043
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")


# Generated at 2022-06-24 12:13:13.437594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"