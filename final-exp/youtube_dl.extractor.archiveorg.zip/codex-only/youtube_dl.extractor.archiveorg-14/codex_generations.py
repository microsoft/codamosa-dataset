

# Generated at 2022-06-24 12:03:15.061738
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:03:15.583882
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:24.369819
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:03:26.308201
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:03:27.912015
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'


# Generated at 2022-06-24 12:03:32.331714
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        assert False, 'constructor of class ArchiveOrgIE should not raise Exception'


# Generated at 2022-06-24 12:03:33.806795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.test_constructor()

# Generated at 2022-06-24 12:03:35.107098
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import doctest
    return doctest.DocTestSuite(ArchiveOrgIE)

# Generated at 2022-06-24 12:03:42.681295
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor, FakeIE
    from ..utils import ExtractorError
    from .test_youtube import assertRegex

    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()

    # Invalid URL should raise exception
    try:
        ie.extract('https://invalid.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    except ExtractorError as e:
        assertRegex(ie, e.args[0], r'failed to download m3u8 information')


# Generated at 2022-06-24 12:03:48.709093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_name == 'archive.org'
    assert ie.ie_desc == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:58.338469
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoi_test = ArchiveOrgIE()
    test_url = 'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert aoi_test._match_id(test_url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert aoi_test._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert aoi_test._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:03:59.526227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:04:03.038050
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:06.302708
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE()
    assert (infoExtractor.ie_key() == 'archive.org')
    assert (infoExtractor.ie_name() == 'archive.org videos')
    assert (infoExtractor.ie_desc() == 'archive.org videos')

# Generated at 2022-06-24 12:04:09.611439
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testing constructor with a valid url
    ArchiveOrgIE(None, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Testing constructor with an invalid url - should raise an error
    assert ArchiveOrgIE(None, 'http://archive.org/') is None

# Generated at 2022-06-24 12:04:12.696512
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:15.590876
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simply tests that the constructor of the class ArchiveOrgIE works
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:16.436180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE.IE_TEST = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:17.981648
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:29.025739
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:04:29.789311
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")

# Generated at 2022-06-24 12:04:36.457958
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("http://archive.org/details/XD300-23-68HighlightsAResearchCntAugHumanIntellect")._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE("https://archive.org/embed/XD300-23-68HighlightsAResearchCntAugHumanIntellect")._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:04:44.646969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.utils import CatalogNode
    from youtube_dl.extractor import gen_extractors

    # Test the init method for the ArchiveOrgIE class
    # It is expected that the class will will not raise an exception
    ArchiveOrgIE.ie_key = 'archive_org'
    gen_extractors()
    # The first two arguments construct the url
    # The third argument is the expected video id

# Generated at 2022-06-24 12:04:53.889854
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:05:04.563639
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:05:11.502215
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:17.430401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj._VALID_URL  == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj._TESTS is not None
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:20.353745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    result = ie._parse_info({'playlist': [{'file': 'test', 'title': 'test'}]})
    assert result['title'] == 'test'

# Generated at 2022-06-24 12:05:20.974096
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:05:26.429645
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    match = info_extractor._VALID_URL.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(match)
    assert(info_extractor._real_extract(match.group(0)))

# Generated at 2022-06-24 12:05:30.342546
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'archive.org'



# Generated at 2022-06-24 12:05:31.576953
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:38.758239
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ != '__main__':
        raise RuntimeError('This must be run as a standalone program, not imported')
    print('Testing archive.org IE')

    from . import _download_json, _download_webpage
    from .common import InfoExtractor
    from .compat import compat_urllib_parse
    from .extractor import gen_extractors, list_extractors

    # Dump a list of extractors
    print('Available extractors:')
    for ie in list_extractors(gen_extractors()):
        print('%s\t%s' % (ie.IE_NAME, ie.IE_DESC))

    ie = InfoExtractor('archive.org')
    ie.http = ie.ie._downloader.http
    ie.add_default_header = ie.ie._download

# Generated at 2022-06-24 12:05:40.234163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'ArchiveOrg'

# Generated at 2022-06-24 12:05:41.041492
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # constructor of an InfoExtractor
    ArchiveOrgIE()

# Generated at 2022-06-24 12:05:47.155152
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.suitable(False, 'https://archive.org/details/Cops1922')
    assert ie.suitable(False, 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable(False, 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie.suitable(False, 'https://www.archive.org/details/myvideo') == False
    assert ie.suitable(True, 'https://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:05:51.957535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert ie.IE_NAME == 'archive.org'
  assert ie.IE_DESC == 'archive.org videos'
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:59.992568
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    # unit testing for _VALID_URL
    assert (ie._VALID_URL ==
        r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    # unit testing for _TESTS
    # *NOTE*: there are currently 2 video tests
    assert len(ie._TESTS) == 3
    assert (ie._TESTS[0]['url'] ==
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert (ie._TESTS[0]['md5'] ==
        '8af1d4cf447933ed3c7f4871162602db')

# Generated at 2022-06-24 12:06:03.891272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:06:06.055772
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE('archive.org')
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:10.129856
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test case for the constructor of ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:06:11.733421
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    f = ArchiveOrgIE("ArchiveOrgIE")
    assert f is not None

# Generated at 2022-06-24 12:06:17.719925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC = 'Test ArchiveOrgIE'
    ie.IE_NAME = 'TestArchiveOrgIE'
    ie.IE_VERSION = 'Test Version 1.0'
    assert ie.ie_key() == 'TestArchiveOrgIE'
    assert ie.ie_desc() == 'Test ArchiveOrgIE'
    assert ie.ie_version() == 'Test Version 1.0'

# Generated at 2022-06-24 12:06:20.687603
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    constructor = ArchiveOrgIE()
    return constructor



# Generated at 2022-06-24 12:06:23.387178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"



# Generated at 2022-06-24 12:06:24.257229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()


# Generated at 2022-06-24 12:06:25.916337
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:28.353081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.support_count() == 0

# Generated at 2022-06-24 12:06:30.103055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    newArchiveOrg = ArchiveOrgIE();

# Generated at 2022-06-24 12:06:37.627772
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..compat import compat_b64decode
    from ..utils import (
        clean_html,
        compat_urllib_parse_urlparse,
        compat_urllib_parse_urlunparse,
        compat_urllib_parse_urlencode,
        extract_attributes,
        ExtractorError,
        js_to_json,
        sanitized_Request,
        unified_strdate,
        unified_timestamp,
        url_or_none,
    )
    from ..aes import (
        aes_cbc_decrypt,
        aes_cbc_decrypt_text,
    )
    from ..compat import (
        compat_parse_qs,
    )
    from ..exceptions import RegexNotFoundError


# Generated at 2022-06-24 12:06:43.843923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE())

# Test if an instance of ArchiveOrgIE can be created

# Generated at 2022-06-24 12:06:46.901057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE().IE_DESC == ArchiveOrgIE.IE_DESC
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:06:51.293222
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/Cops1922')

# Generated at 2022-06-24 12:06:56.640088
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE().extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'

# Generated at 2022-06-24 12:07:00.334576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test constructor of ArchiveOrgIE is configured properly
    assert hasattr(ArchiveOrgIE, 'IE_NAME')
    assert hasattr(ArchiveOrgIE, 'IE_DESC')
    assert hasattr(ArchiveOrgIE, '_VALID_URL')
    assert hasattr(ArchiveOrgIE, '_TESTS')

# Generated at 2022-06-24 12:07:06.319327
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.IE_NAME == 'archive.org'
    assert archiveOrgIE.IE_DESC == 'archive.org videos'
    assert archiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:07:17.854097
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE.IE_NAME == 'archive.org'
	assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
	assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
	assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
	assert ArchiveOrgIE._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
	assert ArchiveOrgIE

# Generated at 2022-06-24 12:07:19.117991
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    # non-exists URL, it must not cause any exception
    instance.url_result('http://example.org/test')

# Generated at 2022-06-24 12:07:20.166684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoe = ArchiveOrgIE()
    assert aoe.IE_NAME == "archive.org"

# Generated at 2022-06-24 12:07:20.775940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()


# Generated at 2022-06-24 12:07:30.673843
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test the ArchiveOrgIE constructor.
    import re
    import unittest

    # Make sure the expected _VALID_URL contructor is found
    url_regexp = re.compile("https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)")
    assert ArchiveOrgIE._VALID_URL == url_regexp

    # Make sure no other _VALID_URL contructors exist
    assert len(ArchiveOrgIE._VALID_URL_RE) == 1

    # Test the _TESTS object
    #   (should be in the form of a list of dicts)
    test_object = ArchiveOrgIE._TESTS
    assert type(test_object) == list
    assert len(test_object) == 4

# Generated at 2022-06-24 12:07:38.304600
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Test for fallback cases
    assert ie._parse_jwplayer_data({'playlist': None}, 'test') == {}
    assert ie._parse_jwplayer_data({'playlist': []}, 'test') == []

# Generated at 2022-06-24 12:07:49.960983
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_constructed = ArchiveOrgIE()
    assert class_constructed._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:57.129802
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inp, outp = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    outp = archiveorg(inp, outp)
    assert outp=='8af1d4cf447933ed3c7f4871162602db'


# Generated at 2022-06-24 12:07:58.577360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert isinstance(obj, ArchiveOrgIE)


# Generated at 2022-06-24 12:07:59.211301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE()


# Generated at 2022-06-24 12:08:07.216542
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    TestIE = type('TestIE', (ArchiveOrgIE,), {'_VALID_URL': ArchiveOrgIE._VALID_URL})
    tIE = TestIE(InfoExtractor())
    assert tIE._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:08:20.174767
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:25.326971
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:08:26.879352
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-24 12:08:30.221383
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of class ArchiveOrgIE"""
    try:
        ArchiveOrgIE(None)
    except TypeError as exception:
        assert True
    else:
        assert False, "No exception has been thrown"


# Generated at 2022-06-24 12:08:32.671612
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 12:08:42.918571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global ArchiveOrgIE
    from YoutubeDL import YoutubeDL
    from YoutubeDL.utils import DateRange
    from YoutubeDL.extractor.archiveorg import ArchiveOrgIE
    from YoutubeDL.extractor import common
    import re
    ie = ArchiveOrgIE()
    assert isinstance(ie, common.InfoExtractor)
    assert ie.ie_key() == 'archive.org'
    metadata = ie._download_json('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', query={'output': 'json'})['metadata']

# Generated at 2022-06-24 12:08:51.244528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp, )
    from .test_archive import get_test_suite_archive, get_test_suite_archive_comment
    from .test_youtube import get_test_suite_youtube_common
    ie = ArchiveOrgIE()
    suite = get_test_suite_archive(ie)
    suite.addTest(get_test_suite_archive_comment(ie))
    suite.addTest(get_test_suite_youtube_common())
    return suite

# Generated at 2022-06-24 12:08:52.310854
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-24 12:08:53.528169
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive_org')

# Generated at 2022-06-24 12:08:55.710762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    globals()['ArchiveOrgIE']('archive.org')


# Generated at 2022-06-24 12:08:59.683198
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:09:08.353026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Test: Test URL before and after IE initialization
    with open(get_testdata_filepath(__file__), 'r') as f:
        test_html = f.read()
    proxies = None
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # Test: Test URL before IE initialization
    i = ArchiveOrgIE(proxies=proxies)
    assert_equal(i.suitable(url), False)
    assert_equal(i.working(), False)
    assert_equal(i.valid_url(url), True)

    # Test: IE initialization
    i = ArchiveOrgIE(proxies=proxies)
    i.initialize()

    # Test: Test URL after IE initialization

# Generated at 2022-06-24 12:09:11.913135
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME == 'archive.org'

    # Constructor with ieflag set to False
    ie2 = ArchiveOrgIE(ieflag=False)
    ie2 == ie


# Generated at 2022-06-24 12:09:13.834327
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:09:16.327960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert (ie.IE_NAME == 'archive.org')

# Generated at 2022-06-24 12:09:20.737588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:21.842818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:30.643757
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao_ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ao_ie.name == 'archive.org'
    assert ao_ie.title == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert ao_ie.ie_key() == 'archive.org:XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ao_ie.thumbnail == 're:^https?://(?:s3|ia)\.media\.archive\.org/[a-z0-9]+/[a-z0-9]+\.jpg$'

# Generated at 2022-06-24 12:09:38.913546
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE constructor
    """
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:40.860539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:09:50.536754
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # _VALID_URL is defined in class ArchiveOrgIE
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org\.?(?:/details/|/embed/)?(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:00.373390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert hasattr(IE, '_download_webpage')
    assert hasattr(IE, '_search_regex')
    assert hasattr(IE, '_parse_jwplayer_data')
    assert hasattr(IE, '_parse_json')
    assert hasattr(IE, '_match_id')
    assert hasattr(IE, '_parse_html5_media_entries')

# Generated at 2022-06-24 12:10:02.112987
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:05.828139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test that ArchiveOrgIE doesn't throw any errors
    ie = ArchiveOrgIE()
    # Test that ArchiveOrgIE can be instantiated from a string
    ie = InfoExtractor.for_site(ArchiveOrgIE.ie_key())

# Generated at 2022-06-24 12:10:09.107337
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:22.166106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:23.705345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:10:30.313139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie._real_extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.ie_key() == 'archive.org'
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['ext'] == 'ogg'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['uploader'] == 'SRI International'

# Generated at 2022-06-24 12:10:42.873567
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    print ("Testing ArchiveOrgIE, the constructor of class ArchiveOrgIE")
    print ("The value of attribute _VALID_URL is {}".format(archive_org_ie._VALID_URL))
    print ("The value of attribute IE_NAME is {}".format(archive_org_ie.IE_NAME))
    print ("The value of attribute IE_DESC is {}".format(archive_org_ie.IE_DESC))
    print ("The value of attribute _TESTS is {}".format(archive_org_ie._TESTS))
    print ("The value of attribute _VALID_URL_RE is {}".format(archive_org_ie._VALID_URL_RE))

# Generated at 2022-06-24 12:10:46.785421
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract(
        "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")



# Generated at 2022-06-24 12:10:50.927569
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst_ArchiveOrgIE = ArchiveOrgIE()
    assert isinstance(inst_ArchiveOrgIE, object)

# Generated at 2022-06-24 12:10:52.070211
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE({})

# Generated at 2022-06-24 12:10:52.691972
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:10:55.764761
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()
test_ArchiveOrgIE.func_name = 'test_ArchiveOrgIE'

# Generated at 2022-06-24 12:10:56.776017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.ie_key

# Generated at 2022-06-24 12:11:00.491263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS

# Generated at 2022-06-24 12:11:02.306387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:04.900100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    
    # Test regular URL
    url = "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"

# Generated at 2022-06-24 12:11:13.501152
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check with valid url.
    extractor = ArchiveOrgIE()
    assert extractor
    # Check with invalid url.
    extractor = ArchiveOrgIE(url='')
    assert extractor
    # Check with valid url, but with a name different from class.
    extractor = ArchiveOrgIE(url='', ie_name="test")
    assert extractor
    # Check with valid url, but with a name different from class and a null parameter
    extractor = ArchiveOrgIE(url='', ie_name="test", params=None)
    assert extractor

# Generated at 2022-06-24 12:11:14.433914
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	info_extractor = ArchiveOrgIE()
	return

# Generated at 2022-06-24 12:11:17.534387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE()._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-24 12:11:22.751990
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Usually in doctest, we can only do an import statement and will get some info of module.
    # But in this test_ArchiveOrgIE function, we can do some other things.
    assert ArchiveOrgIE({}) # here we can do a constructor because a instance defined in global scope.
    assert ArchiveOrgIE.suitable({'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'})

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 12:11:25.506289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    infoExtractor = ArchiveOrgIE()
    assert infoExtractor.IE_NAME == 'archive.org'
    assert infoExtractor.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:11:26.450690
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:29.840301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:36.914015
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .. import mocks
    test_cases = []
    for test_case in mocks.mock_jwplayer_urls():
        for config in ['jwplayer6', 'jwplayer7']:
            # Set a wide variety of attributes to ensure that all values are
            # passed to the constructor
            test_cases.append({
                'url': test_case['url'],
                'config': config,
                'downloader': mocks.FakeYDL(),
                'expected_ie_key': 'JWPlatform',
                'expected_re': test_case['expected_re'],
            })
    for test_case in test_cases:
        ie = ArchiveOrgIE(**test_case)
        assert ie.ie_key() == test_case['expected_ie_key']
        assert ie._VALID_URL

# Generated at 2022-06-24 12:11:46.447143
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id = 'test'
    url = 'http://archive.org/details/' + video_id
    ie = ArchiveOrgIE(False)
    metadata = ie._download_json(url, video_id, query={'output': 'json'})['metadata']
    assert video_id == ie._get_optional(metadata, 'title')
    assert video_id == ie._get_optional(metadata, 'creator')
    assert video_id == ie._get_optional(metadata, 'identifier')
    assert ie._get_optional(metadata, 'date') == ie._get_optional(metadata, 'date')
    assert ie._get_optional(metadata, 'publicdate') == ie._get_optional(metadata, 'publicdate')

# Generated at 2022-06-24 12:11:49.258391
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:11:52.344673
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    assert isinstance(extractor, ArchiveOrgIE)

# Generated at 2022-06-24 12:11:53.758459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    raise NotImplementedError

# Generated at 2022-06-24 12:11:54.918209
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:11:55.464970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-24 12:11:56.676060
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({})
    assert(ie is not None)

# Generated at 2022-06-24 12:11:59.739339
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_DESC = 'archive.org'  # No need to include archive.org twice in the description
    ie.IE_NAME = 'archive.org'  # Change name since by default it is 'archive'

# Generated at 2022-06-24 12:12:04.337934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test archive.org url
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE().suitable(url) == True
    ie = ArchiveOrgIE()
    ie.extract(url)
    assert ie.extract(url)['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:12:14.212591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This function unit test for constructor of class ArchiveOrgIE
    """
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video = ArchiveOrgIE()._real_extract(url)
    assert video['id'] == video_id
    assert video['url'] == url
    assert video['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert video['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'

# Generated at 2022-06-24 12:12:14.998114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:18.855979
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.__name__ == 'archive.org'
    assert ie.__doc__ == 'archive.org videos'

# Generated at 2022-06-24 12:12:30.820157
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
   """Test ArchiveOrgIE class instantiation"""

   video_url = 'https://archive.org/details/Cops1922'
   video_name = 'Buster Keaton\'s "Cops" (1922)'
   video_id = 'Cops1922'

   expected_info = {
        'id': 'Cops1922',
        'ext': 'mp4',
        'title': 'Buster Keaton\'s "Cops" (1922)',
        'description': 'md5:43a603fd6c5b4b90d12a96b921212b9c',
        'timestamp': 1387699629,
        'upload_date': '20131222',
   }
   ie = ArchiveOrgIE(video_url,video_name,video_id)
   ie.result()

# Generated at 2022-06-24 12:12:31.393940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:12:37.233643
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:46.339302
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:49.138678
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test Archive.Org video extraction"""
    # Test for constructor
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:58.432688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	import unittest
	class TestArchiveOrgIE(unittest.TestCase):
		def test_constructor(self):
			TestArchiveOrgIE = ArchiveOrgIE()
			self.assertEquals(TestArchiveOrgIE.IE_NAME, 'archive.org')
			self.assertEquals(TestArchiveOrgIE.IE_DESC, 'archive.org videos')
			self.assertEquals(TestArchiveOrgIE._VALID_URL, r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
	unittest.main()

# Generated at 2022-06-24 12:13:02.240624
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert isinstance(ie._VALID_URL, str)
    assert len(ie._TESTS) > 0
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 12:13:03.755424
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-24 12:13:04.540704
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-24 12:13:06.111727
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-24 12:13:15.901393
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'