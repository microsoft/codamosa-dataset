

# Generated at 2022-06-24 12:03:12.115356
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # calling the constructor without any arguments
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:15.109019
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('http://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23.ogv') is not None

# Generated at 2022-06-24 12:03:18.590092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()

    assert ie.extract(url)['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-24 12:03:22.446063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    assert aorg.IE_NAME == "archive.org"
    assert aorg.IE_DESC == "archive.org videos"
    assert aorg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:24.541907
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:36.478502
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert(ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
  assert(ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
  assert(ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')
  assert(ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
  assert(ie._TESTS[0]['info_dict']['ext'] == 'ogg')

# Generated at 2022-06-24 12:03:38.588781
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:46.187735
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archiveOrgIE = ArchiveOrgIE(url)
    videoinfo = archiveOrgIE._real_extract(url)
    assert archiveOrgIE._download_webpage == webpage
    assert archiveOrgIE._match_id == video_id
    assert videoinfo['id'] == video_id
    assert videoinfo['ext'] == 'ogg'
    assert videoinfo['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:03:55.071401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    ArchiveOrgIE Test Class
    """
    IE_TEST = ArchiveOrgIE('archive.org')
    assert IE_TEST.IE_NAME == 'archive.org'
    assert IE_TEST.IE_DESC == 'archive.org videos'
    assert IE_TEST.VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:03:56.364505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'

# Generated at 2022-06-24 12:04:02.374236
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie=ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

	assert ie.IE_NAME=='archive.org'

# Generated at 2022-06-24 12:04:04.383030
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check if ArchiveOrgIE can be constructed.
    # ArchiveOrgIE should be constructible with empty constructor.
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:15.139099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:17.536212
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage("https://archive.org/details/african_prince/african_prince_512kb.mp4")

# Generated at 2022-06-24 12:04:20.692245
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:30.105865
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"

    expected_result = "8af1d4cf447933ed3c7f4871162602db"
    result = ArchiveOrgIE._download_webpage("", url)
    assert result.find("1968 Demo - FJCC Conference Presentation Reel #1") != -1

    expected_result = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    result = ArchiveOrgIE._match_id(url)
    assert result == expected_result


# Generated at 2022-06-24 12:04:36.261080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test of class ArchiveOrgIE.

    Each invocation of the constructor of ArchiveOrgIE should be followed by the
    invocation of the test function of the following class, which can be either
    the same class or a subclass of ArchiveOrgIE.
    """
    ie = ArchiveOrgIE("https://archive.org")  # pylint: disable=redefined-outer-name
    ie.test()

# Generated at 2022-06-24 12:04:37.269339
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-24 12:04:45.316523
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:04:47.280794
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
# Test the class ArchiveOrgIE

# Generated at 2022-06-24 12:04:49.471352
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg_ie = ArchiveOrgIE()
    assert archiveorg_ie._real_initialize()

# Generated at 2022-06-24 12:04:52.332610
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert "archive.org" in ie.IE_NAME
    assert "archive.org videos" in ie.IE_DESC
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None

# Generated at 2022-06-24 12:04:52.841163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert True

# Generated at 2022-06-24 12:05:04.405126
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:08.353525
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test archive.org
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-24 12:05:09.710776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE({}).IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:05:20.560180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:30.532880
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Function to call private function of ArchiveOrgIE class.
    def call_private_func(*args):
        inst = ArchiveOrgIE()
        return args[0](inst, *args[1:])

    # Test that _match_id function is identified correctly.
    valid_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert call_private_func(ArchiveOrgIE._match_id,
                             "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect") == valid_id
    assert call_private_func(ArchiveOrgIE._match_id,
                             "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect?start=2000") == valid_id
   

# Generated at 2022-06-24 12:05:32.227388
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-24 12:05:36.412274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:43.230555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    'Unit test for constructor of class ArchiveOrgIE'
    ai = ArchiveOrgIE()

    url = 'http://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect_512kb.mp4'
    # Check that it is a file
    assert ai._is_valid_url(url, True)
    # Check that it is not a directory
    assert not ai._is_valid_url(url, False)

# Generated at 2022-06-24 12:05:43.721780
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-24 12:05:47.435232
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    x = ie
    assert x.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:05:49.938376
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except:
        raise AssertionError("Unit test for constructor ArchiveOrgIE failed")


# Generated at 2022-06-24 12:05:50.582289
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:05:55.912102
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie.ie_description() == 'archive.org videos'
    assert ie.is_suitable('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')



# Generated at 2022-06-24 12:06:02.502915
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from ..utils import TestDownloader
	from ..utils import TestOnDemandPagedList
	from ..utils import TestPagedList
	from ..utils import TestSoup
	dler = TestDownloader()
	soup_processor = TestSoup(dler)
	ondemand_paged_list_processor = TestOnDemandPagedList(dler)
	paged_list_processor = TestPagedList(dler, ondemand_paged_list_processor)
	ie = ArchiveOrgIE(dler, soup_processor, ondemand_paged_list_processor, paged_list_processor)

# Generated at 2022-06-24 12:06:11.896653
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert not ie._VALID_URL == ''
    assert not ie._TESTS == ''
    assert not ie._real_extract == ''
    assert not test_ArchiveOrgIE == ''
    assert not get_optional == ''
    assert not unified_timestamp == ''

# Generated at 2022-06-24 12:06:20.745181
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This should test the ArchiveOrgIE.__init__ function
    import os
    import tempfile
    temp_dir = tempfile.gettempdir()
    temp_file = tempfile.NamedTemporaryFile(delete=False)
    temp_file.close()
    temp_file_location = os.path.join(temp_dir, temp_file.name)
    try:
        archive_org = ArchiveOrgIE()
        archive_org.download(temp_file_location, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    finally:
        if os.path.exists(temp_file_location):
            os.remove(temp_file_location)

# Generated at 2022-06-24 12:06:22.096725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:30.693492
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    #
    # Test some video URLs
    #
    assert ie._extract_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._extract_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    #
    # Test some image URLs
    #
    assert ie._extract_url('https://archive.org/details/BusterKeatonCops1922') is None

# Generated at 2022-06-24 12:06:40.081411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE().extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['description'] == 'md5:da45c349df039f1cc8075268eb1b5c25'
    assert info['creator'] == 'SRI International'
    assert info['release_date'] == '19681210'
    assert info['uploader'] == 'SRI International'
    assert info['timestamp'] == 1268695290
    assert info['upload_date'] == '20100315'

# Generated at 2022-06-24 12:06:42.505709
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:06:44.599296
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE(None)
    assert IE.get_id() == 'archive.org'


# Generated at 2022-06-24 12:06:45.586125
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:06:46.749555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert(isinstance(IE, InfoExtractor))

# Generated at 2022-06-24 12:06:49.055365
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-24 12:06:53.802006
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    info = ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert(info["id"] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:07:00.305038
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_download import options, FakeYDL
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    options = options(url)
    options.update({
        'quiet': True,
        'format': 'default'
    })
    arch = ArchiveOrgIE()
    with FakeYDL() as ydl:
        info = arch.extract(url)
        arch.url_result(url)
        arch._real_extract(url)
        arch._real_extract(url)
        arch._real_download(url)
        arch._download_webpage(url)
        arch._download_webpage(url, 'test_video')
        ydl.extract_info(url, download=True)
        ydl.extract_

# Generated at 2022-06-24 12:07:04.475744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    try:
        ArchiveOrgIE()
    except Exception as e:
        raise AssertionError("Unexpected exception raised: %s" % e)

# Generated at 2022-06-24 12:07:07.861241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    except Exception:
        assert False

# Generated at 2022-06-24 12:07:10.091207
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:11.524435
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Simple test for archive.org constructor"""
    ArchiveOrgIE()

# Generated at 2022-06-24 12:07:12.504535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    raise NotImplementedError('Test not implemented yet')

# Generated at 2022-06-24 12:07:13.465714
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test constructor without fail
    ArchiveOrgIE()

# Generated at 2022-06-24 12:07:17.364661
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:07:20.886258
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:07:30.851797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = ArchiveOrgIE._match_id(url)
    assert 'XD300-23_68HighlightsAResearchCntAugHumanIntellect' == video_id
    info = ArchiveOrgIE._real_extract(ArchiveOrgIE(), url)
    assert 'XD300-23_68HighlightsAResearchCntAugHumanIntellect' == info['id']
    assert '1968 Demo - FJCC Conference Presentation Reel #1' == info['title']
    assert '1968 Demo - FJCC Conference Presentation Reel #1' in info['description']
    assert 'Tobey' in info['description']
    assert 'creator' in info
    assert 'release_date' in info

# Generated at 2022-06-24 12:07:31.625740
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE.test()

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:07:32.679625
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie=ArchiveOrgIE()

# Generated at 2022-06-24 12:07:34.688890
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:43.092996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    This unit test is used to test the initialization of the class ArchiveOrgIE.
    """
    # What cases can be considered when we want to test the initialization of
    # the class ArchiveOrgIE?

    # Case 1: The class is initialized properly.
    archive_object = ArchiveOrgIE()
    assert isinstance(archive_object, InfoExtractor)
    # Case 2: The class is initialized with an invalid url.
    # How do we know if it is an invalid url?
    # invalid_url = 'https://www.youtube.com/watch?v=-WpM9tiNu-0'
    # archive_object = ArchiveOrgIE(invalid_url)
    # assert isinstance(archive_object, InfoExtractor)
    # Case 3: The class is initialized with valid url.

# Generated at 2022-06-24 12:07:52.430186
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tester = ArchiveOrgIE()
    assert tester.IE_NAME == 'archive.org'
    assert tester.IE_DESC == 'archive.org videos'
    assert tester._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:57.324928
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archOrgInstance = ArchiveOrgIE()
    assert isinstance(archOrgInstance, InfoExtractor)

# Generated at 2022-06-24 12:08:06.181195
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).get_host() == "archive.org"
    assert ArchiveOrgIE(None).get_content_type() == "video"
    assert ArchiveOrgIE(None).get_id("http://archive.org/details/test.test") == "test.test"
    assert ArchiveOrgIE(None).extract_link_name("http://archive.org/details/test.test") == "test.test"
    assert ArchiveOrgIE(None).get_url_type("http://archive.org/details/test.test") == 2
    assert ArchiveOrgIE(None).get_url_type("http://archive.org/embed/test.test") == 2
    assert ArchiveOrgIE(None).get_url_type("http://archive.org") == 0

# Generated at 2022-06-24 12:08:06.564997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:08:11.729362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert "archive.org" == ArchiveOrgIE.IE_NAME
    assert "archive.org videos" == ArchiveOrgIE.IE_DESC

# Generated at 2022-06-24 12:08:17.171122
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test the ArchiveOrgIE, the class of the module
    """

    # Test this class
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC

# Generated at 2022-06-24 12:08:25.092323
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = """
    <html>
    <head>
    <meta name="og:video" content="https://archive.org/download/XD300-23_68HighlightsAResearchCntAugHumanIntellect/XD300-23_68HighlightsAResearchCntAugHumanIntellect-1680x1050.ogv">
    </head>
    <body>
    </body>
    </html>
    """
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda url: webpage
    ie._download_json = lambda url: {'metadata': {'title': 'test title'}}
    ie._parse_jwplayer_data = lambda info, video_id, base_url: info

# Generated at 2022-06-24 12:08:28.592158
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    from .common import test_ArchiveOrgIE
    test_ArchiveOrgIE.test_ArchiveOrgIE(ArchiveOrgIE, unittest.TestCase)

# Generated at 2022-06-24 12:08:30.576392
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:35.778414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This test is a unit test for the ArchiveOrgIE constructor
    # It checks if a ArchiveOrgIE object is instantiated correctly
    ie = ArchiveOrgIE() 

    # Check for class name
    assert ie._match_id('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == 'MSNBCW_20131125_040000_To_Catch_a_Predator'

# Generated at 2022-06-24 12:08:45.076375
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    assert t.IE_NAME == 'archive.org'
    assert t._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:46.438211
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    pass

# Generated at 2022-06-24 12:08:54.819655
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('http://archive.org')

# The following code is based on
# https://github.com/rg3/youtube-dl/blob/master/youtube_dl/extractor/udemy.py

import os
import json
import re
import urllib
import base64

from ..compat import compat_urllib_parse
from ..compat import compat_urllib_request
from ..utils import (
    float_or_none,
    int_or_none,
    strip_jsonp,
    try_get,
    unescapeHTML
)

from ..aes import (
    aes_cbc_decrypt,
)

from ..downloader.common import (
    FileDownloader,
    http_head,
    http_get,
)


# Generated at 2022-06-24 12:09:01.366107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie.__name__
    assert isinstance(ie, InfoExtractor)
  

# Generated at 2022-06-24 12:09:03.989032
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie == ArchiveOrgIE
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:09:13.754847
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test_video_url and test_video_metadata are generated in utils.py
    archiveorg_test_video_metadata = {
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'ext': 'ogg',
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'release_date': '19681210',
        'creator': 'SRI International',
        'timestamp': 1268695290,
        'uploader': 'SRI International',
        'upload_date': '20100315',
    }

# Generated at 2022-06-24 12:09:17.873547
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').IE_NAME == 'archive.org'

test_ArchiveOrgIE()

# Generated at 2022-06-24 12:09:23.211565
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructors and methods in ArchiveOrgIE"""
    # assert that the constructor works
    obj = ArchiveOrgIE()

    # assert that the method _extract_urls works
    url = "https://archive.org/details/Cops1922"
    obj._extract_urls(url)

    # assert that the method _real_extract works
    obj._real_extract(url)

    return

# Generated at 2022-06-24 12:09:25.242686
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._TESTS[0]['md5'] == i.event_video_information('XD300-23_68HighlightsAResearchCntAugHumanIntellect')['md5']

# Generated at 2022-06-24 12:09:28.202272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	print("check archive.org's constructor")
	print()
	ie = ArchiveOrgIE()
	print("	ArchiveOrgIE initialized")
	print()
	return ie


# Generated at 2022-06-24 12:09:32.921162
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 12:09:38.246023
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')
    ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Passes
    assert True



# Generated at 2022-06-24 12:09:47.404947
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Args:
        url (str): An url that points to the desired page.
        test (True|False|None): Whether or not to run a test.

    Return:
        An ArchiveOrgIE object.

    Raises:
        AssertionError: If the url is not valid.
        AssertionError: If the test fails.
    """
    import pytest

    from .common import ExtractorError

    from .common import InfoExtractor

    from .common import unescapeHTML

    from .common import update_url_query

    from .youtube import YoutubeIE

    from ..compat import (
        compat_HTTPError,
        compat_str,
    )


# Generated at 2022-06-24 12:09:48.282988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:09:48.816217
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-24 12:09:49.221771
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:09:50.598212
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoie = ArchiveOrgIE()
    pass


# Generated at 2022-06-24 12:09:57.086007
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE()._real_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    ArchiveOrgIE()._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:09:58.875720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:02.062770
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    InfoExtractor(ArchiveOrgIE()).extract('http://archive.org/details/miracle_on_34th_street_the_1947')

# Generated at 2022-06-24 12:10:06.536789
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.domain() == 'archive.org'
    assert ie.get_metadata == ArchiveOrgIE._get_metadata

# Generated at 2022-06-24 12:10:11.132281
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_urls = ['https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect']
    for url in test_urls:
        ie = ArchiveOrgIE()
        ie.extract(url)

# Generated at 2022-06-24 12:10:21.176257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import unittest
    import sys
    reload(sys)
    sys.setdefaultencoding('utf8')
    class TestArchiveOrgIE(unittest.TestCase):
        def test_constructor_base_url(self):
            a = ArchiveOrgIE()
            b = ArchiveOrgIE(base_url="https://www.archive.org")
            # When the base url is different the md5s of playlist entries should
            # be different
            self.assertNotEqual(a._real_extract(
                "http://archive.org/details/Cops1922")["entries"][0]["id"],
                b._real_extract("http://archive.org/details/Cops1922")[
                "entries"][0]["id"])

# Generated at 2022-06-24 12:10:25.394532
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:10:28.699465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:34.037052
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..compat import compat_urllib_request
    ie = InfoExtractor()
    ie.add_info_extractor(ArchiveOrgIE)
    ie.developer_key = compat_urllib_request.urlopen('''https://archive.org/account/login.php''').read()
    # example video pulled from Archive.org homepage
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:35.658300
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-24 12:10:43.570766
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'

# Generated at 2022-06-24 12:10:49.006127
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie._TESTS[0]["url"]
    assert ie._download_webpage(ie._TESTS[0]["url"], ie._TESTS[0]["url"][29:]) == ie._TESTS[0]["url"]

# Generated at 2022-06-24 12:10:57.315137
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")
    ArchiveOrgIE("details")
    ArchiveOrgIE("embed")
    ArchiveOrgIE("details/embed")
    ArchiveOrgIE("embed/details")
    ArchiveOrgIE("embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ArchiveOrgIE("details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    ArchiveOrgIE("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:10:59.874551
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:00.495711
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ArchiveOrgIE()

# Generated at 2022-06-24 12:11:01.914641
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-24 12:11:14.086504
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    # Verify that id is None
    print('\nUnit test for ArchiveOrgIE class constructor')
    print('field "id" is %s\n' % archive_org_ie.id)
    # Verify that url is None
    print('field "url" is %s\n' % archive_org_ie.url)
    # Verify that title is None
    print('field "title" is %s\n' % archive_org_ie.title)
    # Verify that ie_key is none
    print('field "ie_key" is %s\n' % archive_org_ie.ie_key)
    # Verify that thumbnail is none
    print('field "thumbnail" is %s\n' % archive_org_ie.thumbnail)
    # Verify that description is none
   

# Generated at 2022-06-24 12:11:15.937961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:17.005071
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:11:26.237328
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:27.114452
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:11:29.658754
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # The test archive.org URL
    assert ArchiveOrgIE()(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/').get('title', None) != None

# Generated at 2022-06-24 12:11:36.765163
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:38.545940
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorgIE = ArchiveOrgIE()
    assert (aorgIE is not None)

# Generated at 2022-06-24 12:11:40.666681
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"


# Generated at 2022-06-24 12:11:44.016844
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie

# Generated at 2022-06-24 12:11:46.934178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:11:50.826247
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:11:52.667986
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:57.227389
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:59.614556
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._TESTS[0].get('md5') == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-24 12:12:04.618071
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:05.369713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test that constructor doesn't fail
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:06.245364
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();



# Generated at 2022-06-24 12:12:08.274340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE().extract('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert '/header-img/' not in info['thumbnail']
    assert info['formats'] is not None

# Generated at 2022-06-24 12:12:12.689112
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:14.542345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert_true(isinstance(ie.IE_DESC, basestring))
    assert_true(bin(ie.age_limit) < 0)

# Generated at 2022-06-24 12:12:20.867156
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-24 12:12:22.339385
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("archive.org")._real_extract("http://archive.org")

# Generated at 2022-06-24 12:12:26.433912
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:12:34.559761
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Successful construction
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    # Successful match of url
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    # Successful match of id
    match = ie._match_id('http://archive.org/details/test')
    assert(match == 'test')
    # Successful real extraction after mock is set to true
    ie._download_webpage = lambda url, video_id: 'window.archive_setup={"id":"test", "playlist":"[]"};'

# Generated at 2022-06-24 12:12:44.654086
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:49.503408
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test only that the class was initialized properly,
    # the actual working of the class will be tested
    # in the other unit tests
    assert ie is not None
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:13:00.106526
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:13:01.634379
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert isinstance(info_extractor, InfoExtractor)

# Generated at 2022-06-24 12:13:06.360743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:13:10.788302
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:13:14.458570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    ie._download_webpage("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect","XD300-23_68HighlightsAResearchCntAugHumanIntellect")