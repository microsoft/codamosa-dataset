

# Generated at 2022-06-24 12:03:09.904056
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:03:10.473114
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:19.256107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:27.970866
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    expected = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/format=json'
    assert ie._construct_url(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
        {'output': 'json'}, True) == expected
    expected = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/output=json'
    assert ie._construct_url(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
        {'output': 'json'}, False) == expected

# Generated at 2022-06-24 12:03:37.868361
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    dummy_url = ArchiveOrgIE._VALID_URL
    dummy_id = 'dummy_id'
    dummy_play8 = '<div class=\'js-play8-playlist\' data-play8-id=\'dummy_id\' data-play8-version=\'v3>'
    dummy_jwplayer_playlist = '[{"title": "title"}]'
    dummy_html5_media_entries = [{'title': 'title'}]

    # test_html5_media_entries
    ie = ArchiveOrgIE()
    ie._search_regex = lambda *args: None
    ie._download_webpage = lambda *args: None
    ie._parse_html5_media_entries = lambda *args: dummy_html5_media_entries

# Generated at 2022-06-24 12:03:38.475148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:42.293562
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:03:43.356899
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE({})

# Generated at 2022-06-24 12:03:48.824316
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("https://archive.org/details/ArchiveDotOrgPrototype")
    ie = ArchiveOrgIE("https://archive.org/embed/ArchiveDotOrgPrototype")
    ie = ArchiveOrgIE("https://archive.org/details/ArchiveDotOrgPrototype/")

# Generated at 2022-06-24 12:03:50.659286
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME != None

# Generated at 2022-06-24 12:03:51.223810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:03:54.282053
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == 'archive.org'

# Generated at 2022-06-24 12:04:03.933268
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for ArchiveOrgIE"""
    from .youtube import YoutubeIE
    from .common import InfoExtractor
    from .dailymotion import DailymotionIE
    from .vimeo import VimeoIE
    from .archiveorg import ArchiveOrgIE

    assert YoutubeIE.suitable('https://www.youtube.com/watch?v=BaW_jenozKc') is True
    assert YoutubeIE.suitable('https://www.google.com/watch?v=BaW_jenozKc') is False

    assert ArchiveOrgIE.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is True
    assert ArchiveOrgIE.suitable('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is True

    assert V

# Generated at 2022-06-24 12:04:04.802060
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:04:05.558765
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:04:10.642597
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE.ie_key()
    try:
        string = type(info_extractor)
    except:
        raise Exception("ArchiveOrgIE is not a class")
    assert type(info_extractor) == type(type)
    assert issubclass(info_extractor, InfoExtractor)
    assert info_extractor.__name__ == ArchiveOrgIE.IE_NAME
    assert info_extractor.__doc__ == ArchiveOrgIE.IE_DESC


# Generated at 2022-06-24 12:04:11.236835
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:04:16.228931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id = 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator'
    a = ArchiveOrgIE(archiveOrgIE())
    assert a._match_id(url) == video_id

# Generated at 2022-06-24 12:04:17.311960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:20.596971
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:04:22.349563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO(shlomi): Remove is_type_playlist when it's no longer needed
    assert issubclass(ArchiveOrgIE, object)

# Generated at 2022-06-24 12:04:24.206691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE(InfoExtractor()).suitable(None, None)

# Generated at 2022-06-24 12:04:28.072243
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test that can create an instance of ArchiveOrgIE"""
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    ie = ArchiveOrgIE()
    ie._match_id(url)
    assert ie.IE_NAME == 'archive.org'
    return

# Generated at 2022-06-24 12:04:31.311539
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', {})
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:04:35.172588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert(ao._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:04:37.167333
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit tests for the constructor of the class ArchiveOrgIE.
    """
    ArchiveOrgIE('http://localhost/', None, None)

# Generated at 2022-06-24 12:04:43.524588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .. import _get_testcases_from_file
    testcases = _get_testcases_from_file('archive_org.txt')

    i = ArchiveOrgIE()
    assert(i != None)
    for t in testcases:
#         print(t[1])
        print("Testing " + t[0])
        try:
            i._real_extract(t[0])
        except Exception as e:
            assert(t[1] == str(e))
            print("Exception: " + str(e))
        except:
            assert(False)
test_ArchiveOrgIE()

# Generated at 2022-06-24 12:04:45.929893
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .. import _download_json
    ie = ArchiveOrgIE()
    ie._download_json = _download_json
    ie._real_extract("http://archive.org/details/Cops1922", "Cops1922")

# Generated at 2022-06-24 12:04:46.950785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE().extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:04:50.486776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE class.
    """
    ie = ArchiveOrgIE()
    ie.extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-24 12:04:51.688713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert test_obj

# Generated at 2022-06-24 12:04:53.743592
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"


# Generated at 2022-06-24 12:04:55.620713
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()

# Generated at 2022-06-24 12:05:05.079360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert_equal(ie.IE_NAME, 'archive.org')
    assert_equal(ie.IE_DESC, 'archive.org videos')
    assert_equal(ie._VALID_URL, 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert_equal(ie._TESTS[1]['url'], 'https://archive.org/details/Cops1922')
    assert_equal(ie._TESTS[1]['md5'], '0869000b4ce265e8ca62738b336b268a')
    assert_equal(ie._TESTS[1]['info_dict']['id'], 'Cops1922')

# Generated at 2022-06-24 12:05:06.336100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.download("https://archive.org/details/Cops1922")

# Generated at 2022-06-24 12:05:12.728980
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE's constructor
    p = ArchiveOrgIE()
    # Test whether the regexes match
    assert p.IE_NAME == 'archive.org'
    assert p._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Test whether extractor works
    assert p.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect').get('id') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert p.extract('https://archive.org/details/Cops1922').get('id') == 'Cops1922'

# Generated at 2022-06-24 12:05:15.968233
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-24 12:05:20.936683
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:22.454312
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:05:27.603429
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:05:33.461454
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4 #Test for the 3 test-cases and for the existence of Extractor


# Generated at 2022-06-24 12:05:41.741219
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE."""
    import archiveorg
    ie = archiveorg.ArchiveOrgIE()
    ie.input_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie.get_video_id()
    ie._real_extract()

    ie.input_url = 'https://archive.org/details/Cops1922'
    ie.get_video_id()

# Generated at 2022-06-24 12:05:42.793601
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-24 12:05:54.851229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:04.614797
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_html5 import test_html5_media_entries_meta
    from .test_playlist import test_playlist_for_playlist_url
    def test_constructor(url, expected_type, expected_id=None):
        instance = ArchiveOrgIE(helpers.FakeYDL())
        m = instance._VALID_URL.match(url)
        assert m
        assert expected_type == instance._real_extract(url)['_type']
        if expected_id:
            assert expected_id == m.group('id')
    yield test_constructor, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'video'
    yield test_constructor, 'https://archive.org/details/Cops1922', 'video'
   

# Generated at 2022-06-24 12:06:10.804742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:06:11.837873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:14.675227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert issubclass(ArchiveOrgIE, InfoExtractor)

# Generated at 2022-06-24 12:06:17.650299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():  # pragma: no cover
    class FakeClass():
        pass

    try:
        ArchiveOrgIE(FakeClass())
    except Exception as e:
        assert False,e
    else:
        assert True

# Generated at 2022-06-24 12:06:28.561929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:30.449893
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-24 12:06:40.164774
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:06:44.419885
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"

# Generated at 2022-06-24 12:06:45.420113
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ar = ArchiveOrgIE()

# Generated at 2022-06-24 12:06:56.035384
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Extracting data from url of videos on archive.org site,
    convert to format common for other downloader,
    return extracted data"""
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:06:57.403553
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')._generate_extractors()

# Generated at 2022-06-24 12:06:58.148912
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:07:09.423506
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:07:10.742085
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-24 12:07:12.142393
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:07:17.260917
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:22.670164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    c = ArchiveOrgIE()

# Generated at 2022-06-24 12:07:32.101649
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Instantiate class ArchiveOrgIE
    ie = ArchiveOrgIE()

    # Call extract method with a valid url
    # For the sake of testing, it uses the first entry of test list
    # But there is no reason to suppose this assumption is wrong
    ie.extract(ArchiveOrgIE._TESTS[0]['url'])
    
    # Call extract method with a valid url, but the link has changed
    ie.extract('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    
    # Call extract method with an invalid url
    ie.extract('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator///')

# Generated at 2022-06-24 12:07:33.786973
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._downloader = DummyDownloader()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-24 12:07:38.389499
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for the instance of class ArchiveOrgIE."""
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    tester = InfoExtractor(ArchiveOrgIE.ie_key())
    tester.suite()

# Generated at 2022-06-24 12:07:43.684019
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME in globals().keys()
    assert ArchiveOrgIE.IE_DESC in globals().keys()
    assert ArchiveOrgIE._VALID_URL in globals().keys()
    assert ArchiveOrgIE._TESTS in globals().keys()



# Generated at 2022-06-24 12:07:44.317331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()

# Generated at 2022-06-24 12:07:46.984511
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:07:48.388616
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()



if __name__ == '__main__':
    pass

# Generated at 2022-06-24 12:07:53.368791
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import youtube_dl
    ydl = youtube_dl.YoutubeDL({})
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_url_invalid = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect_invalid'
    ie = ArchiveOrgIE(ydl)

    assert ie._match_id(test_url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._match_id(test_url_invalid) == None



# Generated at 2022-06-24 12:07:57.290414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE().suitable(url)
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:08:06.161677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/Buster_Keatons_Cops_1922')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.valid_url('https://archive.org/details/Buster_Keatons_Cops_1922')
    assert ie.url_result('https://archive.org/details/Buster_Keatons_Cops_1922').video_id == 'Buster_Keatons_Cops_1922'
    assert ie.valid_url('https://archive.org/embed/Buster_Keatons_Cops_1922')
    assert ie.url_result('https://archive.org/embed/Buster_Keatons_Cops_1922').video_

# Generated at 2022-06-24 12:08:11.782985
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert isinstance(ie, ArchiveOrgIE)


# Generated at 2022-06-24 12:08:13.373444
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:08:15.660317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:08:18.567445
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE
    """
    obj = ArchiveOrgIE()
    assert obj._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:19.924190
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()
    assert archiveorg.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:08:24.850820
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:08:32.289286
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = ArchiveOrgIE
    # sample media file with md5
    # 8af1d4cf447933ed3c7f4871162602db for file
    # XD300-23_68HighlightsAResearchCntAugHumanIntellect
    instance = class_(None)
    assert instance._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:08:34.286814
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:08:41.166518
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a_ie = ArchiveOrgIE()
    assert a_ie.IE_NAME == 'archive.org'
    assert a_ie.IE_DESC == 'archive.org videos'
    assert a_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:47.190664
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	print ("Testing ArchiveOrgIE constructor")
	archive_org_extractor = ArchiveOrgIE()
	assert archive_org_extractor.IE_NAME == 'archive.org'
	assert archive_org_extractor.IE_DESC == 'archive.org videos'
	assert archive_org_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:08:51.517418
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-24 12:08:53.102599
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    foo = ArchiveOrgIE()

    assert 'archive.org' in foo.IE_NAME

# Generated at 2022-06-24 12:08:56.570968
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-24 12:09:01.173908
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    # test if instance is of class ArchiveOrgIE
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-24 12:09:05.434364
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-24 12:09:07.982843
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    if archive_org_ie is not None:
        print("archive_org_ie is not None")
    else:
        print("archive_org_ie is None")

# Generated at 2022-06-24 12:09:12.732751
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert hasattr(ie, '_TESTS')

# Generated at 2022-06-24 12:09:15.811835
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE().extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:09:18.424226
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test creation of class ArchiveOrgIE"""
    try:
        ArchiveOrgIE(None)
    except Exception:
        raise Exception('Instantiation of ArchiveOrgIE failed')


# Generated at 2022-06-24 12:09:23.004930
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert(ie.IE_DESC == 'archive.org videos')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:09:24.750377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract(ArchiveOrgIE._TESTS[0]['url'])

# Generated at 2022-06-24 12:09:27.382024
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.get_info('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')



# Generated at 2022-06-24 12:09:31.058282
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    if not ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'):
        raise ValueError('Suitable function failed!')
    if ie.suitable('http://www.google.com'):
        raise ValueError('Suitable function failed!')

# Generated at 2022-06-24 12:09:37.484092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-24 12:09:38.327394
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None

# Generated at 2022-06-24 12:09:40.074848
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org videos')

# Generated at 2022-06-24 12:09:41.245746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE.
    """
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:09:50.900035
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:00.715747
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert test_obj.IE_NAME == "archive.org"
    assert test_obj.IE_DESC == "archive.org videos"
    assert test_obj._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)" 
    assert test_obj._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert test_obj._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db"

# Generated at 2022-06-24 12:10:10.902668
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Initialise the class instance to be tested
    cls = ArchiveOrgIE()
    # Test the regex used to match a test site
    # Construct the regex that matches a test site
    regex = r'(http://)(www\.)?archive.org/(details/)(XD300-23_68HighlightsAResearchCntAugHumanIntellect)'
    # Compile the regex into a pattern
    pattern = re.compile(regex)
    # Check if match is successful
    assert(pattern.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None)
    # Check if match is unsuccessful
    assert(pattern.match('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect/download') is None)

# Generated at 2022-06-24 12:10:12.746725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:13.335721
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:14.960484
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Should create an instance of ArchiveOrgIE
    """
    assert ArchiveOrgIE() != None



# Generated at 2022-06-24 12:10:23.122212
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert isinstance(ie, InfoExtractor)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:25.281844
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-24 12:10:27.835687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")


# Generated at 2022-06-24 12:10:35.392284
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:10:47.837168
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test URL with a single video
    info_dict = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315'
    }
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-24 12:10:49.718576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # expect that archive.org InfoExtractor can be initialized
    ArchiveOrgIE()

# Generated at 2022-06-24 12:10:51.933644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('www.archive.org', {'id':'test_ArchiveOrgIE'}, 'archive.org', 'archive.org videos')

# Generated at 2022-06-24 12:10:56.068956
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:01.723759
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("test", "desc", "http://example.com")
    assert(ie.IE_NAME == "archive.org")
    assert(ie.IE_DESC == "archive.org videos")
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-24 12:11:03.224115
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE() is not None)


# Generated at 2022-06-24 12:11:07.887544
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Arrange
    from . import ArchiveOrgIE
    archiveorg = ArchiveOrgIE()
    
    # Act
    actual = archiveorg.ie_key()
    expected = 'archive.org'

    # Assert
    assert actual == expected

# Generated at 2022-06-24 12:11:17.598913
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchivOrgIE = type('ArchivOrgIE', (), {})
    ArchivOrgIE.IE_NAME = ArchiveOrgIE.IE_NAME
    inst = ArchivOrgIE({})
    assert inst.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert inst.suitable('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not inst.suitable('http://archive.org/details/BearCity2TheProposal2012VODRipXviDAC3-aAF.en')
    assert not inst.suitable('http://archive.org/details/PL_20150305_16_20_CET_S01_E25')

# Generated at 2022-06-24 12:11:26.734387
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = u'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    info = ie._real_extract(url)
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert info['timestamp'] == 1268695290
    assert info['upload_date'] == '20100315'
    assert info['uploader'] == 'SRI International'
    assert len(info['formats']) > 0
    assert info['duration'] > 0


# Generated at 2022-06-24 12:11:34.892453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    R = ArchiveOrgIE()
    # URL matches:
    assert R.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert R.suitable('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # URL does not match:
    assert not R.suitable('https://youtube.com/')

# Test for method _real_extract of class ArchiveOrgIE

# Generated at 2022-06-24 12:11:38.405705
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # pylint: disable=W0613
    def create_test_class(test_url, test_data):
        class NewArchiveOrgIE(ArchiveOrgIE):
            IE_DESC = 'archive.org videos'
            _VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
            _TESTS = [test_data]
        return NewArchiveOrgIE()
    ie = ArchiveOrgIE(create_test_class)
    assert ie is not None

# Generated at 2022-06-24 12:11:42.199792
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:43.303700
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO
    pass


# Generated at 2022-06-24 12:11:45.498857
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-24 12:11:48.649585
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check if the ArchiveOrgIE fails properly without an URL
    ArchiveOrgIE(None)

# Generated at 2022-06-24 12:11:55.420178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:11:59.432947
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()
    assert t.IE_NAME == 'archive.org'
    assert t.IE_DESC == 'archive.org videos'
    assert t._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-24 12:12:01.118784
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extractor_key = 'archive.org'
    ie.ie_key_map = {}

# Generated at 2022-06-24 12:12:01.686522
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:11.717369
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # testing a possible url that would cause false positives on url checking
    url = u'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    assert ie.suitable(url), 'Should be suitable'
    assert ie.IE_NAME in ie.suitable(url), 'Should be suitable'
    # testing real cases
    assert ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.suitable('http://www.archive.org/')

# Generated at 2022-06-24 12:12:13.313290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for valid URL
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-24 12:12:14.169988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = ArchiveOrgIE()

# Generated at 2022-06-24 12:12:20.862971
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    res = ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert res['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert res['ext'] == 'ogg'
    assert res['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:12:21.924710
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x

# Generated at 2022-06-24 12:12:24.064814
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._TESTS

# Generated at 2022-06-24 12:12:28.966103
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_class = ArchiveOrgIE(url)
    assert_equals(test_class.url, url)
    assert_equals(test_class.ie_key(), 'archive.org')

# Generated at 2022-06-24 12:12:41.306743
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-24 12:12:49.847278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #TODO: find better way to test ArchiveOrgIE
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE().suitable(url) == True
    assert ArchiveOrgIE()._real_extract(url)['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-24 12:12:50.968172
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE().IE_NAME

# Generated at 2022-06-24 12:12:54.999790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = globals()['ArchiveOrgIE']
    assert class_ is not None
    instance = class_()
    assert instance is not None


# Generated at 2022-06-24 12:12:55.673787
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:12:59.197840
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-24 12:13:04.997491
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-24 12:13:14.852367
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'