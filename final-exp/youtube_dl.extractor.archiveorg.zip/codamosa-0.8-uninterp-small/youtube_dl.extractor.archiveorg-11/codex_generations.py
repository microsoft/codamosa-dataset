

# Generated at 2022-06-26 11:36:44.818129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  return ArchiveOrgIE()

# Generated at 2022-06-26 11:36:46.463081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

# Generated at 2022-06-26 11:36:52.030518
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:36:53.430830
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:04.676506
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = archive_org_i_e_0._match_id(url)
    webpage = archive_org_i_e_0._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)
    playlist = None
    play8 = archive_org_i_e_0._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage, 'playlist',
        default=None)
    if play8:
        attrs = extract_attributes(play8)
        playlist = attrs.get('value')
    if not playlist:
        playlist

# Generated at 2022-06-26 11:37:06.164707
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:09.048127
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e_0 is not None


# Generated at 2022-06-26 11:37:10.479742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
# test_case_0()

# Generated at 2022-06-26 11:37:12.178542
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    by_keyword_0 = ArchiveOrgIE('download', 'archive.org', 'archive.org videos')

# Generated at 2022-06-26 11:37:23.342366
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_i_e = ArchiveOrgIE()
    assert_equals(archive_org_i_e.ie_key(), 'ArchiveOrg')
    assert_equals(archive_org_i_e.suitable(url), True)

# Generated at 2022-06-26 11:37:34.602766
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE)

# Generated at 2022-06-26 11:37:44.280298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_1 = ArchiveOrgIE()

    # unit tests for class ArchiveOrgIE
    # def _real_extract(self, url)
    # unit tests for _real_extract method for ArchiveOrgIE class
    # def test_cases_for__real_extract(self):
    # test cases for _real_extract method
    # Input arguments:
    #   url - url of the webpage
    # Expect output:
    #   md5 hash of an expected result

    # test case 1
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_i_e_1._real_extract(url)
    # expected md5 hash of result
    # 8af1d4cf447933ed3c

# Generated at 2022-06-26 11:37:45.907126
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:47.758057
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

# Generated at 2022-06-26 11:37:49.152147
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:00.530923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = archive_org_i_e_0._match_id(url)
    webpage = archive_org_i_e_0._download_webpage(
        'http://archive.org/embed/' + video_id, video_id)
    play8 = archive_org_i_e_0._search_regex(
        r'(<[^>]+\bclass=["\']js-play8-playlist[^>]+>)', webpage,
        'playlist', default=None)
    attrs = extract_attributes(play8)
    playlist = attrs.get('value')
    jwplayer_playlist = archive_org_i_e_0._parse

# Generated at 2022-06-26 11:38:01.845969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:05.329594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _ArchiveOrgIE = ArchiveOrgIE()
    assert_equals(_ArchiveOrgIE.IE_NAME, 'archive.org')
    repr_output = repr('function')
    repr_expected = repr_output
    assert_equals(repr_output, repr_expected)


# Generated at 2022-06-26 11:38:07.500642
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:12.118947
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

test_cases = [
    test_case_0,
    test_ArchiveOrgIE,
]


# Generated at 2022-06-26 11:38:34.059955
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:41.587303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:38:49.061556
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:38:50.185681
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:39:02.254528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:39:04.788287
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url="http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ie = ArchiveOrgIE()
    ie.download(url)

# Generated at 2022-06-26 11:39:08.302223
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == "archive.org"
    assert info_extractor.IE_DESC == "archive.org videos"


# Generated at 2022-06-26 11:39:08.891733
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:11.500092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # It is important to run constructor of the tested class
    # so archive.org's full site name (Internet Archive) is displayed in output
    # instead of __main__.ArchiveOrgIE
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:15.005915
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:39:42.199228
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'
    assert x._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:46.511194
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:48.204457
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-26 11:39:50.882189
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:39:52.228327
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 11:39:57.524677
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.l_code() == 'en'
    assert ie.URL_RE == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:08.858322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org', ie.IE_NAME
    assert ie.IE_DESC == 'archive.org videos', ie.IE_DESC
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)', ie._VALID_URL
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', ie._TESTS[0]['url']

# Generated at 2022-06-26 11:40:10.465259
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie=ArchiveOrgIE()

# Generated at 2022-06-26 11:40:14.230024
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE('archive.org')
    assert isinstance(inst, ArchiveOrgIE)
    inst = ArchiveOrgIE('archive.org')
    assert isinstance(inst, ArchiveOrgIE)

# Test archive.org API
# Test archive.org API

# Generated at 2022-06-26 11:40:15.052921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None


# Generated at 2022-06-26 11:41:16.759200
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:41:17.426362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:41:19.520124
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'



# Generated at 2022-06-26 11:41:19.988902
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-26 11:41:23.443171
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for ArchiveOrgIE class.
    """
    # Test each subclass of ArchiveOrgIE
    for extractor_name in ArchiveOrgIE.__dict__['_ies']:
        if extractor_name == 'ArchiveOrgIE':
            continue
        extractor_class = ArchiveOrgIE._ies[extractor_name]
        extractor_class()

    # Test ArchiveOrgIE itself
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:26.246529
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME is not None
    assert ArchiveOrgIE.IE_DESC is not None
    assert ArchiveOrgIE._VALID_URL is not None
    assert ArchiveOrgIE._TESTS is not None

# Generated at 2022-06-26 11:41:28.673531
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.get_info("https://archive.org/details/do_you_love_me_1962_lynn")

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:41:31.774463
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except TypeError:
        pass # OK, it is a static class
    else:
        raise AssertionError('ArchiveOrgIE must be a static class!')

# Generated at 2022-06-26 11:41:40.708488
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test1 = ArchiveOrgIE()._real_initialize(
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    test2 = ArchiveOrgIE()._real_initialize('http://archive.org/details/Cops1922/')
    test3 = ArchiveOrgIE()._real_initialize('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    # Test with a youtube video pointing to an archive.org video
    test4 = ArchiveOrgIE()._real_initialize('http://www.youtube.com/watch?v=zOiE1MRHby8')
    print("Testing Archive.org extractor is completed")

# Generated at 2022-06-26 11:41:42.741810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE().get_info(url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-26 11:43:52.165815
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import HEADRequest
    ret = ArchiveOrgIE()
    assert ret.ie_key() == 'archive.org'
    assert ret.ie_desc() == 'archive.org videos'
    assert ret._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:53.870098
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.download("XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-26 11:43:55.749560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Make sure that the class is correctly constructed
    assert(isinstance(ArchiveOrgIE(), InfoExtractor))

# Generated at 2022-06-26 11:43:57.847313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 11:43:59.861781
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:44:02.908388
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # initial variable declaration
    # make instance of class ArchiveOrgIE
    Extractor = ArchiveOrgIE()
    # check created instance of class ArchiveOrgIE, there is no exception while instance creation
    assert Extractor

# Generated at 2022-06-26 11:44:10.130719
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Checks the constructor of class ArchiveOrgIE
    """
    iedata = "archive.org videos"
    sampleurl = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ie = ArchiveOrgIE(iedata)
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]["url"] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-26 11:44:18.163885
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print("test ArchiveOrgIE constructor")
    # First test case
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    ie = ArchiveOrgIE()
    match = ie._match_id(url)
    if (match != 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'):
        print("error finding video ID")
    # Second test case
    url = "https://archive.org/details/Cops1922"
    match = ie._match_id(url)
    if (match != 'Cops1922'):
        print("error finding video ID")

test_ArchiveOrgIE()

# Generated at 2022-06-26 11:44:20.742840
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

test_ArchiveOrgIE()

# Generated at 2022-06-26 11:44:29.910494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._TESTS[0].get('url') == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1].get('url') == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[2].get('url') == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'