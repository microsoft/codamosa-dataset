

# Generated at 2022-06-26 11:36:40.903240
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:46.150686
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()(url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE()(url='http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-26 11:36:52.534494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:36:53.154829
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:36:53.778780
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:57.325286
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(_VALID_URL, IE_NAME, IE_DESC)._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-26 11:36:59.208040
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0.IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:37:10.874278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    archive_org_i_e.IE_NAME = 'archive.org'
    archive_org_i_e.IE_DESC = 'archive.org videos'
    archive_org_i_e._VALID_URL = 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:12.606945
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_raises(NotImplementedError,
                  lambda : ArchiveOrgIE()
                  )

# Generated at 2022-06-26 11:37:12.998818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:37:24.449873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert ie.IE_NAME == 'archive.org'
  assert ie.IE_DESC == 'archive.org videos'
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
  assert ie._TESTS

# Generated at 2022-06-26 11:37:29.808540
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:40.645703
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:42.357795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of ArchiveOrgIE, to ensure that it can be instantiated."""
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:54.867035
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    #assert ie._TESTS is not None

# Generated at 2022-06-26 11:37:59.978782
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoi = ArchiveOrgIE()
    assert aoi.IE_NAME == 'archive.org'
    assert aoi.IE_DESC == 'archive.org videos'
    assert aoi._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:38:05.623409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test constructor of ArchiveOrgIE"""
    ie = ArchiveOrgIE('http://archive.org', 'test_archive_org.test')
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.ie_key() == 'archive.org'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:07.329715
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE is not None

# Generated at 2022-06-26 11:38:07.937369
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
     ArchiveOrgIE()

# Generated at 2022-06-26 11:38:09.284358
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: Add unit test for constructor
    assert True

# Generated at 2022-06-26 11:38:21.371173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
        x = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:22.894682
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org', 'archive.org videos') == ArchiveOrgIE


# Generated at 2022-06-26 11:38:28.715811
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ArchiveOrgIE.IE_NAME
    assert ie.IE_DESC == ArchiveOrgIE.IE_DESC
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL
    assert ie._TESTS == ArchiveOrgIE._TESTS

# Generated at 2022-06-26 11:38:29.670308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')


# Generated at 2022-06-26 11:38:31.413335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie is not None

# Test if extracting video information from the URL succeeds

# Generated at 2022-06-26 11:38:32.322447
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-26 11:38:34.808309
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_tests import _TEST
    assert ArchiveOrgIE._TESTS == [ _TEST ]

# Generated at 2022-06-26 11:38:45.702204
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert archive.IE_NAME == 'archive.org'
    assert archive.IE_DESC == 'archive.org videos'
    assert archive._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert archive._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:38:46.353446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:59.669063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Source: https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    new = ArchiveOrgIE()
    new.to_screen('Title: %s ' % new.get_title())
    new.to_screen('URL: %s ' % (new.get_og_url()))
    new.to_screen('Description: %s ' % new.get_description())
    new.to_screen('Creator: %s ' % new.get_creator())
    new.to_screen('Release date: %s ' % new.get_release_date())
    new.to_screen('Uploader: %s ' % new.get_uploader())
    new.to_screen('Timestamp: %s ' % new.get_timestamp())

# Generated at 2022-06-26 11:39:23.228130
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Todo: Test ArchiveOrgIE
    pass

# Generated at 2022-06-26 11:39:26.996501
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archiveorg")

# Generated at 2022-06-26 11:39:30.275711
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractorTestCase
    import ArchiveOrgIE
    import unittest
    test = unittest.TestCase("__init__")
    test.assertIsInstance(ArchiveOrgIE.ArchiveOrgIE(), InfoExtractor)

# Generated at 2022-06-26 11:39:37.782135
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)

    assert ie.ie_key() == "archive.org"
    assert ie.ie_desc() == "archive.org videos"
    assert ie.construct_id(ie.ie_key(), ArchiveOrgIE._VALID_URL) == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie.is_suitable(ArchiveOrgIE._VALID_URL) == True
    assert ie.is_suitable("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect") == False
    assert ie._build_url(ArchiveOrgIE._VALID_URL) == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:39:42.418071
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:52.270633
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor(None))._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE(InfoExtractor(None))._real_extract(url='https://archive.org/details/Cops1922')
    ArchiveOrgIE(InfoExtractor(None))._real_extract(url='http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE(InfoExtractor(None))._real_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-26 11:39:56.549350
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:02.914493
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-26 11:40:04.738434
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.utils import SearchInfoExtractor
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert isinstance(ie, SearchInfoExtractor) == True

# Generated at 2022-06-26 11:40:06.114521
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:40:57.947952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-26 11:40:59.919400
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # See https://github.com/rg3/youtube-dl/issues/4903
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE.VALID_URL

# Generated at 2022-06-26 11:41:00.699732
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:02.009710
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.get_setting_value('_type', 'generic') == 'generic'
    assert x.get_setting_value('_fallback_is_disabled', 'fallback_disabled') == 'fallback_disabled'

# Generated at 2022-06-26 11:41:04.081821
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:08.536545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-26 11:41:09.054025
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ArchiveOrgIE()

# Generated at 2022-06-26 11:41:09.868164
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:17.779698
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Run unit test for an instance of ArchiveOrgIE
    """
    from .common import InfoExtractor
    from . import extract
    from . import gen_extractors_test
    from . import tools

    ie = InfoExtractor()
    gen_extractors_test(ie, [])
    assert ie.__class__.__name__ == 'ArchiveOrgIE'
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.server_location() == 'San Francisco, CA, USA'
    assert ie.server_hostname() == 'archive.org'
    assert ie.content_license() == 'See archival records'
    assert ie.__version__ == extract.__version__
    assert ie.suitable(ie.http_test()) == True

    ie = InfoExtractor()
    ie.add

# Generated at 2022-06-26 11:41:22.194482
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    def _run_test_class_constructor(self):
        """Call ArchiveOrgIE constructor with different values of _TESTS's variable 'url'.
        Passed variable url is used to create object of class ArchiveOrgIE.
        """
        url = self.get('url')
        ArchiveOrgIE(url)

    for test_variable in ArchiveOrgIE._TESTS:
        _run_test_class_constructor(test_variable)

# Generated at 2022-06-26 11:43:34.434905
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == "archive.org videos"
    assert ie.IE_NAME == "archive.org"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:41.370413
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME=='archive.org')
    assert(ie.IE_DESC=='archive.org videos')
    assert(isinstance(ie._VALID_URL,str))
    assert(isinstance(ie._TESTS,list))
    assert(isinstance(ie.extract,types.MethodType))
    assert(isinstance(ie._real_extract,types.MethodType))
    assert(isinstance(ie._download_webpage,types.MethodType))
    assert(isinstance(ie._match_id,types.MethodType))

# Generated at 2022-06-26 11:43:42.187732
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:49.703628
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import fake_get
    from .test import get_testcases_and_expected
    from .test import test_main

    def test_ArchiveOrgIE_constructor():
        ie = ArchiveOrgIE()

    def test_ArchiveOrgIE_constructor_with_params(expected):
        ArchiveOrgIE(get_testcases_and_expected()[1], get_testcases_and_expected()[0], fake_get, expected)

    def test_ArchiveOrgIE_class_test_test_constructor():
        test_ArchiveOrgIE_constructor()
        
    # skip test of ArchiveOrgIE_class_test_test_constructor_with_params() for now
    # test_ArchiveOrgIE_constructor_with_params(get_testcases_and_expected()[2])

    # Call test

# Generated at 2022-06-26 11:43:57.019314
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_object_type = 'InfoExtractor'

    # Create instance of class ArchiveOrgIE
    ArchiveOrgIE_instance = ArchiveOrgIE()

    # Verify instance of class
    assert isinstance(ArchiveOrgIE_instance, ArchiveOrgIE)

    # Verify constructor method called
    assert getattr(ArchiveOrgIE_instance, '_download_webpage', 'Constructor method not invoked') is not None

    # Verify _real_extract function
    assert ArchiveOrgIE_instance._real_extract(test_url) is not None

# Generated at 2022-06-26 11:43:57.851187
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:58.624218
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:59.745871
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:44:08.194374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()

    # No media found for url http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    assert(IE.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')==True)
    assert(IE.suitable('https://archive.org/details/Cops1922')==True)
    assert(IE.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')==True)
    assert(IE.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')==True)

# Generated at 2022-06-26 11:44:09.138183
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()
