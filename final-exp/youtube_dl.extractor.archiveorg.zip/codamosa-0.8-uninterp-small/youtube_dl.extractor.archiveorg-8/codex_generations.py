

# Generated at 2022-06-26 11:36:44.242571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(test_case_0) == ArchiveOrgIE


# Generated at 2022-06-26 11:36:48.121081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg = ArchiveOrgIE()
    assert aorg.IE_NAME == 'archive.org'
    assert aorg.IE_DESC == 'archive.org videos'
    assert aorg._VALID_URL is not None
    assert aorg._TESTS is not None


# Generated at 2022-06-26 11:36:51.102578
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-26 11:36:52.521277
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-26 11:36:56.843264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    archive_org_ie = ArchiveOrgIE(ydl)
    assert archive_org_ie._downloader == ydl
    assert archive_org_ie.ie_key() == 'archive.org'

# Generated at 2022-06-26 11:36:58.349230
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:36:59.748524
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE, "Class not defined"



# Generated at 2022-06-26 11:37:07.165609
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert test_case_0.archive_org_i_e_0.IE_NAME == 'archive.org'
    assert test_case_0.archive_org_i_e_0.IE_DESC == 'archive.org videos'
    assert test_case_0.archive_org_i_e_0._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:37:09.254660
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IES[0] ==  ArchiveOrgIE


# Generated at 2022-06-26 11:37:10.241941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE)

# Generated at 2022-06-26 11:37:16.438274
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-26 11:37:24.610132
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda *x: '<page></page>'
    ie._download_json = lambda *x: {'metadata': {}}
    ie._search_regex = lambda *x: ''
    ie._parse_jwplayer_data = lambda *x: {}
    ie._parse_html5_media_entries = lambda *x: ({}, {}, {})
    ie._parse_json = lambda *x: {}
    ie._real_extract('http://example.com')

# Generated at 2022-06-26 11:37:27.103542
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:37:29.337883
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:37:31.783022
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-26 11:37:35.147275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE('test_input', 'test_output', '1')
    assert x.input == 'test_input'
    assert x.output == 'test_output'
    assert x.num == 1

# Generated at 2022-06-26 11:37:40.276576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        d = Dir(path.join(path.dirname(path.realpath(__file__)), '..', 'tests', 'data', 'archive.org'))
        l = list(d.glob('*.html'))
        ArchiveOrgIE.extract(l[0].resolve().as_uri())
    except Exception as e:
        raise e

# Generated at 2022-06-26 11:37:44.244688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:45.487077
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_archiveorg = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:46.950852
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:37:57.680902
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE(): 
	assert True

# Generated at 2022-06-26 11:38:02.058692
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE()._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'




# Generated at 2022-06-26 11:38:03.962141
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    # Next line is to test the constructor
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:05.101168
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.ie_key() == 'archive.org'

# Generated at 2022-06-26 11:38:06.198181
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("archive.org").IE_DESC == "archive.org videos"

# Generated at 2022-06-26 11:38:08.691331
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch_ie = ArchiveOrgIE()
    assert arch_ie.IE_NAME == "archive.org"

# Generated at 2022-06-26 11:38:11.710110
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-26 11:38:21.256071
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:38:32.362154
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aoi = ArchiveOrgIE()
    assert aoi.IE_NAME == "archive.org"
    assert aoi.IE_DESC == "archive.org videos"
    assert aoi._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 11:38:44.269062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:10.321023
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:17.411582
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:39:19.605651
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:39:31.314746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert ao.IE_NAME == 'archive.org'
    assert ao.IE_DESC == 'archive.org videos'
    assert ao._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:32.477382
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:39:35.847923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == \
           r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:38.327065
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


test_ArchiveOrgIE()

# Generated at 2022-06-26 11:39:39.425758
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie

# Generated at 2022-06-26 11:39:50.636776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    assert ie.BR_DESC is not None
    assert ie.IE_NAME is not None
    assert ie.IE_DESC is not None
    assert ie.IE_VERSION is not None
    assert ie._WORKING is not None
    assert ie.js_to_json is not None
    assert ie._download_json is not None
    assert ie._search_regex is not None
    assert ie._html_search_meta is not None
    assert ie._json_ld is not None
    assert ie._parse_jwplayer_data is not None
    assert ie._parse_html5_media_entries is not None
    assert ie._real_extract is not None


# Generated at 2022-06-26 11:39:56.108970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #Test bad URL
    url = 'http://www.archive.org/badurl/'
    assert ArchiveOrgIE(url)._VALID_URL is None
    #Test URL
    url = 'http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE(url)._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:40:48.200941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
   archiveorg = ArchiveOrgIE()
   assert archiveorg.IE_NAME=='archive.org'
   assert archiveorg.IE_DESC=='archive.org videos'

# Generated at 2022-06-26 11:40:51.658571
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'archive.org')
    assert ie.IE_NAME == "archive.org" and ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-26 11:40:55.186045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:02.015335
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4
    assert ie._tests[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._tests[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:41:04.393600
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:05.709470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:09.831178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({'_type': 'playlist'})
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:41:10.356433
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:41:11.470128
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE"""
    ArchiveOrgIE()


# Generated at 2022-06-26 11:41:13.525188
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(None)
    except TypeError:
        pass

# Generated at 2022-06-26 11:43:18.747108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    object = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:25.482190
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert(ie.IE_NAME == 'archive.org')
  assert(ie.IE_DESC == 'archive.org videos')
  assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

  # Test that the class has an IE_DESC attribute
  ie = ArchiveOrgIE()
  assert(hasattr(ie, 'IE_DESC'))

  # Test that the class has an _TESTS attribute
  assert(hasattr(ie, '_TESTS'))
  # Assert that _TESTS is a non-empty list
  assert(len(ie._TESTS) > 0)
  # Assert that each entry in _TESTS is a tuple


# Generated at 2022-06-26 11:43:31.379374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_VERSION == '20200506.01'

# Generated at 2022-06-26 11:43:36.410084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:45.151807
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[2]['url'] == 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-26 11:43:51.753476
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        ('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', '8af1d4cf447933ed3c7f4871162602db'),
        ('https://archive.org/details/Cops1922', '0869000b4ce265e8ca62738b336b268a'),
        ('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect', None),
        ('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/', None),
    ]

# Generated at 2022-06-26 11:43:52.693872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:44:02.354175
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:44:03.713844
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.get_info('https://archive.org/details/Cops1922')

# Generated at 2022-06-26 11:44:10.727579
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert isinstance(inst.IE_DESC,unicode)
    assert inst._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'