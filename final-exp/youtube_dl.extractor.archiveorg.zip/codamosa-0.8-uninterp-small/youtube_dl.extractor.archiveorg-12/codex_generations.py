

# Generated at 2022-06-26 11:36:43.147090
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:44.522123
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:47.149012
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    return archive_org_i_e_0


# Generated at 2022-06-26 11:36:48.635041
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

# Generated at 2022-06-26 11:36:49.438106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-26 11:36:55.671267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

#  Unit test for _real_extract() function of class ArchiveOrgIE

# Generated at 2022-06-26 11:36:56.780011
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE()



# Generated at 2022-06-26 11:36:58.725100
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:37:01.902093
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Should raise a ValueError since parameters are invalid
    archive_org_i_e_1 = ArchiveOrgIE('a', 'b', 'c')
    

# Generated at 2022-06-26 11:37:03.563738
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:10.030792
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:37:10.623960
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:37:13.552636
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    instance = ie()
    msg = 'Object of class ArchiveOrgIE must be an instance of InfoExtractor'
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-26 11:37:20.923928
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:23.478739
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
    except Exception:
        assert False

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:37:25.107705
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:37:28.231913
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    my_ArchiveOrgIE = ArchiveOrgIE()
    assert my_ArchiveOrgIE != None, "ArchiveOrgIE failed to construct"
    return (True)

# Generated at 2022-06-26 11:37:33.859684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:35.361407
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract_info('')

# Generated at 2022-06-26 11:37:38.963474
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This is a bogus URL.
    # Source: https://stackoverflow.com/questions/2682745/how-do-i-create-a-class-variable-in-python
    ArchiveOrgIE('test', 'c', 'd')

# Generated at 2022-06-26 11:37:51.459494
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Unit test
    assert isinstance(ArchiveOrgIE(), ArchiveOrgIE)

# Generated at 2022-06-26 11:37:52.209054
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:37:54.732316
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys
    from ..test import get_testcases
    for case in get_testcases(sys.modules[__name__]):
        yield case

# Generated at 2022-06-26 11:37:56.791537
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:37:58.227583
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE == ArchiveOrgIE

# Generated at 2022-06-26 11:37:58.860242
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:38:03.335321
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_name() == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:04.209518
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-26 11:38:10.043077
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:14.661112
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
#

# Test for non-playlist URL
# Testcase 1: Constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:38:42.562802
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    r = ArchiveOrgIE()._call_rpc_api(
        method_name='talk-search', params={'query':'a'})
    assert r.get('title', '') == 'Talk Search' and len(r.get('results', [])) == 10

# Generated at 2022-06-26 11:38:43.499301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:45.431470
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:52.262023
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:53.193821
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-26 11:38:57.877374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == "archive.org"
    assert info_extractor.IE_DESC == "archive.org videos"
    assert type(info_extractor._VALID_URL) is str

# Generated at 2022-06-26 11:38:58.834837
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE.IE_DESC

# Generated at 2022-06-26 11:39:03.539834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check constructor without arguments
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:39:04.121761
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-26 11:39:04.748145
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:39:53.707241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert not ArchiveOrgIE()._login_required()

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:39:55.392180
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:39:56.916406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie=ArchiveOrgIE()
    assert ie.get_value()=="archive.org"

# Generated at 2022-06-26 11:40:00.723749
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info = ie._real_extract(url)
    print(info)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:40:02.591780
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor('archive.org')

# Generated at 2022-06-26 11:40:13.453586
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:15.551731
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.test()

# Generated at 2022-06-26 11:40:16.594358
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Assert the constructor is callable without any error
    assert ArchiveOrgIE

# Generated at 2022-06-26 11:40:21.109353
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.codec_support() == False
    assert ie.url_regex() == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.is_video() == True
    assert ie.is_enabled() == True
    assert ie.is_copyrighted() == False
    assert ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:40:31.153795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# Testing for extracting IE
	ie = ArchiveOrgIE()
	test_url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
	test_url2 = "http://archive.org/details/Cops1922"
	test_url3 = "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
	test_url4 = "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"

	check_extract_info_1 = ie.extract(test_url)
	check_extract_info_2 = ie.extract(test_url2)

# Generated at 2022-06-26 11:42:39.853536
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:42:45.940725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_raises(AssertionError, ArchiveOrgIE, 'foo')
    assert_raises(AssertionError, ArchiveOrgIE, 'foo', 'bar')
    assert_raises(AssertionError, ArchiveOrgIE, 'foo', 'bar', 'baz')
    assert_raises_regexp(AssertionError, 'foo', ArchiveOrgIE, 'foo', 'bar', 'baz', 'qux')
    assert_raises_regexp(AssertionError, 'foo', ArchiveOrgIE, 'foo', 'bar', 'baz', 'qux', 'quux')
    assert_raises_regexp(AssertionError, 'foo', ArchiveOrgIE, 'foo', 'bar', 'baz', 'qux', 'quux', 'corge')
    assert_raises_regexp

# Generated at 2022-06-26 11:42:46.761313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:42:55.197133
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:42:58.677523
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert (info["title"] == "1968 Demo - FJCC Conference Presentation Reel #1")



# Generated at 2022-06-26 11:42:59.682682
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("ArchiveOrgIE", "archive.org videos")

# Generated at 2022-06-26 11:43:00.400019
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:01.126673
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._download_webpage
    return None

# Generated at 2022-06-26 11:43:02.630241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst.ie_key() == 'archive.org'

# Generated at 2022-06-26 11:43:07.897961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    test_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(test_url)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == test_url
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'