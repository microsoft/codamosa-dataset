

# Generated at 2022-06-26 11:36:43.334264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

# Generated at 2022-06-26 11:36:48.386474
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test without any arguments
    archive_org_i_e_0 = ArchiveOrgIE()
    assert 'common' == archive_org_i_e_0.IE_DESC
    assert 'archive.org' == archive_org_i_e_0.IE_NAME
    assert 'archive.org videos' == archive_org_i_e_0.IE_DESC

# Generated at 2022-06-26 11:36:49.473374
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:00.894220
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    archive_org_i_e = ArchiveOrgIE()
    # Test with test_case_0
    info = archive_org_i_e._real_extract(url)

    assert info["id"] == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert info["ext"] == "ogg"
    assert info["title"] == "1968 Demo - FJCC Conference Presentation Reel #1"
    assert info["description"] == "md5:da45c349df039f1cc8075268eb1b5c25"
    assert info["creator"] == "SRI International"
    assert info["release_date"] == "19681210"

# Generated at 2022-06-26 11:37:06.377438
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        assert test_case_0() == "test_case_0__test_ArchiveOrgIE"
    except AssertionError as e:
        raise(AssertionError(str(e) + "\n" + "test_case_0__test_ArchiveOrgIE()"))
    return "test_case_0__test_ArchiveOrgIE"


# Generated at 2022-06-26 11:37:11.586654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:19.928464
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _input = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_i_e_1 = ArchiveOrgIE()
    # check whether it is an instance of class InfoExtractor
    if not (isinstance(archive_org_i_e_1, InfoExtractor)):
        raise TypeError('archive_org_i_e_1 should be an instance of class InfoExtractor')
    # check whether it is an instance of class ArchiveOrgIE
    if not(isinstance(archive_org_i_e_1, ArchiveOrgIE)):
        raise TypeError('archive_org_i_e_1 should be an instance of class ArchiveOrgIE')
    # check whether it is an instance of class YoutubeIE

# Generated at 2022-06-26 11:37:23.064541
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:37:24.158485
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:25.622691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:32.601254
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0 is ArchiveOrgIE()


# Generated at 2022-06-26 11:37:42.973750
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    # ArchiveOrgIE
    assert archive_org_i_e.IE_NAME == 'archive.org', 'Invalid name of ArchiveOrgIE'
    assert archive_org_i_e.IE_DESC == 'archive.org videos', 'Invalid description of ArchiveOrgIE'
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)', 'Invalid valid url of ArchiveOrgIE'

# Generated at 2022-06-26 11:37:44.446694
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch_org = ArchiveOrgIE()
    assert arch_org == archive_org_i_e_0


# Generated at 2022-06-26 11:37:47.852499
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE == type(archive_org_i_e_0)


# Generated at 2022-06-26 11:37:58.942106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)', 'Invalid value for _VALID_URL'

# Generated at 2022-06-26 11:38:03.714161
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()

    assert archive_org_i_e_0.IE_NAME == ArchiveOrgIE.IE_NAME
    assert archive_org_i_e_0.IE_DESC == ArchiveOrgIE.IE_DESC
    assert archive_org_i_e_0._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:38:04.905542
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:07.286631
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e == ArchiveOrgIE()

# Generated at 2022-06-26 11:38:12.254931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e == archive_org_i_e_0


# Generated at 2022-06-26 11:38:15.212899
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global archive_org_i_e_0
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e_0.ie_key() == 'ArchiveOrg'



# Generated at 2022-06-26 11:38:30.377950
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e_0.IE_NAME == 'archive.org'
    assert archive_org_i_e_0.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:38:31.731473
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()



# Generated at 2022-06-26 11:38:33.122340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:42.570724
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ar = ArchiveOrgIE()
    ar._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ar._real_extract('https://archive.org/details/Cops1922')
    ar._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ar._real_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-26 11:38:44.873989
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert isinstance(archive_org_i_e_0, IE_DESC)


# Generated at 2022-06-26 11:38:45.686799
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:46.986818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:39:00.250994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    fields = ['IE_NAME', 'IE_DESC', '_VALID_URL', '_TESTS', '__doc__', '_real_extract', '_download_webpage', '_match_id', '_search_regex', '_parse_json', '_parse_jwplayer_data', '_parse_html5_media_entries', '_download_json', 'suitable', '_downloader', 'url_result', '_ready', '_download_webpage_handle', '_download_json', '_sleep', '_request_webpage', '_request_webpage_handle', '_webpage_read_content', '_is_valid_url', '_request_webpage', 'report_warning', 'report_warning', '_sleep', '_webpage_read_content']

# Generated at 2022-06-26 11:39:00.855925
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:11.582011
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:39:37.866844
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e_0.IE_NAME == 'archive.org'
    assert archive_org_i_e_0.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:39:40.179261
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_1 = ArchiveOrgIE()
    assert archive_org_i_e_1


# Generated at 2022-06-26 11:39:41.351216
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE


# Generated at 2022-06-26 11:39:42.955035
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    return archive_org_i_e_0

# Generated at 2022-06-26 11:39:54.195576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e_0._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:01.823039
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    sample_url_0 = "https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert archive_org_i_e_0.suitable(sample_url_0) == True, "suitable fails when it should not"
    assert archive_org_i_e_0.IE_NAME == "archive.org", "IE_NAME is incorrect"
    assert archive_org_i_e_0.IE_DESC == "archive.org videos", "IE_DESC is incorrect"
    assert archive_org_i_e_0._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)", "_VALID_URL is incorrect"
    assert archive_org_i_e

# Generated at 2022-06-26 11:40:03.213104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:40:09.471182
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:40:10.899978
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:40:11.801241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()


# Generated at 2022-06-26 11:40:41.038294
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect');
    pass

# Generated at 2022-06-26 11:40:41.568955
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:40:44.121471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE is subclass of InfoExtractor
    assert issubclass(ArchiveOrgIE, InfoExtractor)

# Test ArchiveOrgIE.ie_key()

# Generated at 2022-06-26 11:40:54.593906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:58.347052
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:00.317064
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-26 11:41:02.664140
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert test_obj.ie_key() == 'archive.org'
    assert test_obj.ie_desc() == 'archive.org videos'

# Unit tests for the _parse_jwplayer_data function

# Generated at 2022-06-26 11:41:12.418244
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:15.824104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    mod = __import__("ytdlg.ie.archiveorg", fromlist=["ArchiveOrgIE"])
    ie = mod.ArchiveOrgIE(mod.InfoExtractor())
    # Unit test: check if an arbitrary object is created
    assert ie.IE_NAME == "archive.org"

# Generated at 2022-06-26 11:41:19.448576
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	z = ArchiveOrgIE("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
	status = z.go()
	assert status == True
	assert z.title == '1968 Demo - FJCC Conference Presentation Reel #1'

test_ArchiveOrgIE()

# Generated at 2022-06-26 11:42:32.309148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test passing of 'constructor' parameter
    archiveorg_ie = ArchiveOrgIE(constructor=1)
    assert archiveorg_ie.constructor == 1
    # Test passing of 'constructor' and 'ie_key' parameters
    archiveorg_ie = ArchiveOrgIE(constructor=1, ie_key='ie_key')
    assert archiveorg_ie.constructor == 1 and archiveorg_ie._IE_KEY == 'ie_key'

# Generated at 2022-06-26 11:42:32.810000
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:42:33.335313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:42:34.170056
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:42:39.499749
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    oi = ArchiveOrgIE()
    assert oi is not None
    assert oi.IE_NAME == 'archive.org'
    assert oi.IE_DESC == 'archive.org videos'
    assert oi._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:42:39.973625
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:42:46.043084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:42:46.861166
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(str(ArchiveOrgIE('class ArchiveOrgIE')))

# Generated at 2022-06-26 11:42:50.617931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_CONFIG['age_limit'] == 0
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:42:55.501717
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4

# Generated at 2022-06-26 11:45:12.473951
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """test ArchiveOrgIE constructor using the test_example.url"""

# Generated at 2022-06-26 11:45:14.523618
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-26 11:45:17.342693
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:45:21.199020
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:45:25.297257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:45:27.767123
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-26 11:45:28.650177
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org')

# Generated at 2022-06-26 11:45:36.385654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''Unit test for constructor of class ArchiveOrgIE
    '''
    from .common import InfoExtractor
    from ..utils import (
        strip_jsonp,
        url_basename,
        urljoin,
        unescapeHTML,
        int_or_none,
        float_or_none,
    )
    from urllib import urlencode
    from json import loads
    from time import time
    from datetime import datetime
    from hashlib import md5

    # Test extract()
    ie = InfoExtractor('archive.org', 'archive.org')
    ie.IE_DESC = 'archive.org videos'
    ie.test_video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    # test extract_info()

# Generated at 2022-06-26 11:45:38.420299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie_first = ie

# Generated at 2022-06-26 11:45:40.628489
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'