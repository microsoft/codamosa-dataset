

# Generated at 2022-06-26 11:36:48.849211
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.get_info_extractor() == ArchiveOrgIE

# Generated at 2022-06-26 11:36:50.687012
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_raises(TypeError, ArchiveOrgIE)


# Generated at 2022-06-26 11:36:51.282984
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:36:53.149644
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:56.568679
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:36:59.654436
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:37:01.080311
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()


# Generated at 2022-06-26 11:37:04.109297
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _archive_org_i_e_0 = ArchiveOrgIE()
    _archive_org_i_e_1 = ArchiveOrgIE(downloader=None)


# Generated at 2022-06-26 11:37:05.114451
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

# Generated at 2022-06-26 11:37:07.308628
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    archive_org_i_e = ArchiveOrgIE(InfoExtractor)

# Generated at 2022-06-26 11:37:13.188693
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    unittest.main()

# Generated at 2022-06-26 11:37:20.748288
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    # Create an object of class ArchiveOrgIE
    ao = ArchiveOrgIE()
    # Check if the url matches
    m = ao._VALID_URL.search(url)
    assert m is not None, 'URL must match'
    # Check if the video id from the url matches the id specified in the tests
    video_id = ao._match_id(url)
    assert video_id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'ID must match'
    # Test the constructor's _real_extract method, and check if the output matches the expected output
    # Create an object of class InfoExtractor for unit testing
    ie = InfoExtractor()


# Generated at 2022-06-26 11:37:21.733339
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    mozunit.main()

# Generated at 2022-06-26 11:37:24.018981
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS

# Generated at 2022-06-26 11:37:27.287161
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Create a object of class ArchiveOrgIE
    arch = ArchiveOrgIE()

    # Test the method of constructor
    assert arch._compat_kwargs({'test':True}) == {'test':True}

# Generated at 2022-06-26 11:37:28.607614
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:36.391689
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    o = ArchiveOrgIE()
    o._match_id("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    o._match_id("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    with pytest.raises(ExtractorError):
        o._match_id("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator")


# Generated at 2022-06-26 11:37:37.913932
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def TestInfoExtractorConstructor(self):
        ie = archiveorg.ArchiveOrgIE()
        self.assertEqual(ie.headers, None)

    TestInfoExtractorConstructor.__doc__ = None
    TestInfoExtractorConstructor.__name__ = None
    TestInfoExtractorConstructor(None)

# Generated at 2022-06-26 11:37:43.134403
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4


# Generated at 2022-06-26 11:37:47.807701
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re
    x = ArchiveOrgIE(None)
    assert x._VALID_URL == re.compile(r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')

# Generated at 2022-06-26 11:38:06.647879
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractorInstance = ArchiveOrgIE()
    assert (infoExtractorInstance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)') == True

# Generated at 2022-06-26 11:38:08.394054
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE.IE_NAME

# Generated at 2022-06-26 11:38:14.826941
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:19.650514
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()
    assert test_obj.IE_NAME == 'archive.org'
    assert test_obj.IE_DESC == 'archive.org videos'
    assert test_obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:22.854085
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simple unit test for ArchiveOrgIE
    """
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    test = ArchiveOrgIE()
    test._real_extract(url)

# Generated at 2022-06-26 11:38:33.873158
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.construct_class(ArchiveOrgIE)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:35.264919
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:37.723185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        assert ArchiveOrgIE('Test', 'http://www.archive.org/embed/example_video')
    except ValueError:
        pass

# Generated at 2022-06-26 11:38:41.831050
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.IE_NAME == 'archive.org'
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:38:43.223318
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({})
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-26 11:39:04.248564
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:39:13.856370
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg = ArchiveOrgIE()
    # Test for class instantiation and private helper functions
    assert archiveorg._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 11:39:19.817537
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE.suitable('http://archive.org/details/Cops1922')
    assert ArchiveOrgIE.suitable('http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert not ArchiveOrgIE.suitable('http://archive.org/')
    assert not ArchiveOrgIE.suitable('http://archive.org/download')
    assert not ArchiveOrgIE.suitable('http://archive.org/about/terms.php')

# Generated at 2022-06-26 11:39:31.433883
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    
    print(ie)
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Test 'IE_NAME'
    expected_ie_name = 'archive.org'
    actual_ie_name = ie.IE_NAME
    
    assert expected_ie_name == actual_ie_name, 'IE_NAME is "%s", should be "%s".' % (actual_ie_name, expected_ie_name)
    
    # Test 'IE_DESC'
    expected_ie_desc = 'archive.org videos'
    actual_ie_desc = ie.IE_DESC
    

# Generated at 2022-06-26 11:39:40.308595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_IEs import _extract_info_dict
    from .generic import GenericIE
    from .youtube import YoutubeIE
    
    original_extractors = ArchiveOrgIE._extractors
    ArchiveOrgIE._extractors = [YoutubeIE.ie_key(), GenericIE.ie_key()]

    try:
        args = (ArchiveOrgIE(),)
        _extract_info_dict(*args, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

        _extract_info_dict(*args, 'https://archive.org/details/Cops1922')
    finally:
        ArchiveOrgIE._extractors = original_extractors

# Generated at 2022-06-26 11:39:42.538910
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    arch_org_ie = ArchiveOrgIE()
    assert arch_org_ie._VALID_URL is None


# Generated at 2022-06-26 11:39:44.635419
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-26 11:39:47.987380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

if __name__ == '__main__':
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:39:50.678156
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:39:54.067351
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Tests instantiation of ArchiveOrgIE"""
    test_ie = ArchiveOrgIE()
    assert test_ie.IE_NAME == 'archive.org'
    assert test_ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:40:39.753772
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:40:43.974229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:44.462899
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:40:49.820414
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
     ie = ArchiveOrgIE('archive.org')
     assert ie.IE_NAME == 'archive.org'
     assert ie.IE_DESC == 'archive.org videos'
     assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

#  Unit test for extract method for class ArchiveOrgIE

# Generated at 2022-06-26 11:40:51.701712
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:40:59.358045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    example_urls = ['https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/', 'https://archive.org/details/TheCuriousCaseOfCurt Flood', 'https://archive.org/details/last_man_standing-122', 'https://archive.org/details/SRC_ft_SammyGordon_TheBlueBeaters_-_Sessoin_1', 'https://archive.org/details/The-Birds-1963-DVD', 'https://archive.org/details/The birds']
    for url in example_urls:
        assert ArchiveOrgIE._match_id(url)


# Generated at 2022-06-26 11:41:04.344341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    u = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    a = ArchiveOrgIE()
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert a._TESTS[0]["url"] == u, "Error in ArchiveOrgIE"
    assert a._TESTS[0]["md5"] == "8af1d4cf447933ed3c7f4871162602db", "Error in ArchiveOrgIE"

# Generated at 2022-06-26 11:41:07.229691
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ..extractor import Extractor
    extractor = Extractor()
    assert isinstance(extractor, Extractor)
    assert isinstance(extractor, ArchiveOrgIE)

# Generated at 2022-06-26 11:41:11.710415
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'https://archive.org/details/Cops1922',
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/',
    ]
    for url in test_cases:
        ArchiveOrgIE(url)

# Generated at 2022-06-26 11:41:12.525505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:43:14.321446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:15.064062
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:15.800317
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-26 11:43:18.540275
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:43:19.012465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:43:25.701332
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'
    assert ie._TESTS[1]['md5'] == '0869000b4ce265e8ca62738b336b268a'
    assert ie._

# Generated at 2022-06-26 11:43:36.631161
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_1 = ArchiveOrgIE()
    assert ie_1.IE_NAME == "archive.org"
    assert ie_1.IE_DESC == "archive.org videos"
    ie_2 = ie_1._real_extract("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie_2.get("id") == "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    assert ie_2.get("ext") == "ogg"
    assert ie_2.get("title") == "1968 Demo - FJCC Conference Presentation Reel #1"

# Generated at 2022-06-26 11:43:45.448440
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE(InfoExtractor())
    assert archiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert archiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert archiveOrgIE._TESTS[0]['info_dict']['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-26 11:43:46.292225
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()



# Generated at 2022-06-26 11:43:47.394217
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'