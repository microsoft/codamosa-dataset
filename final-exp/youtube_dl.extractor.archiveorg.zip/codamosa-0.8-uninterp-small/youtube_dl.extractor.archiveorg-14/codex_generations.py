

# Generated at 2022-06-26 11:36:44.697638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert callable(ArchiveOrgIE)

# Generated at 2022-06-26 11:36:46.697531
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_1 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:47.855558
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:36:53.796815
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert (ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert (ArchiveOrgIE().IE_NAME == 'archive.org')
    assert (ArchiveOrgIE().IE_DESC == 'archive.org videos')


# Generated at 2022-06-26 11:36:57.770800
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e_0.IE_NAME == 'archive.org'
    assert archive_org_i_e_0.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:37:09.492013
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/Cops1922'
    archive_org_i_e_1 = ArchiveOrgIE()
    assert archive_org_i_e_1.suitable(url) is True
    assert archive_org_i_e_1.IE_NAME.lower() == 'archive.org'
    assert archive_org_i_e_1.IE_DESC == 'archive.org videos'
    assert archive_org_i_e_1.valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is True
    assert archive_org_i_e_1.vlearn_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is True
    assert archive

# Generated at 2022-06-26 11:37:10.129666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:37:11.494536
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:13.281872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert callable(ArchiveOrgIE)
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:15.641099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert (ArchiveOrgIE._VALID_URL, 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'archive.org videos')

# Generated at 2022-06-26 11:37:23.157544
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({})
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:37:24.650646
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:37:29.666259
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 11:37:33.273410
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    info_extractor.IE_DESC = 'tetst'

    info_extractor = ArchiveOrgIE()
    info_extractor._VALID_URL = 'tetst'

# Generated at 2022-06-26 11:37:43.489301
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    jwplayer_playlist = {
        'playlist': [
            {
                'file': 'foo',
                'title': 'baz',
                'description': 'qux',
            },
            {
                'file': 'bar',
                'title': 'baz2',
            },
        ]
    }
    html5_media = {
        'title': 'html5 title',
        'description': 'html5 description',
    }
    metadata = {
        'metadata': {
            'title': ['metadata title'],
            'description': ['metadata description'],
            'date': ['20131225'],
            'creator': ['metadata creator'],
            'publicdate': ['1360169197'],
            'language': ['en'],
        }
    }

# Generated at 2022-06-26 11:37:56.049406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(ie._TESTS[0]['info_dict']['name'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert(ie._TESTS[0]['info_dict']['ext'] == 'ogg')
    assert(ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db')

# Generated at 2022-06-26 11:37:56.394069
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:37:59.058050
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:05.867671
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test with a jwplayer-based URL
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_output = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._match_id(url) == expected_output

    # Test with an HTML5 media-based URL
    url = 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    expected_output = 'MSNBCW_20131125_040000_To_Catch_a_Predator'
    assert ArchiveOrgIE._match_id(url) == expected_output

# Generated at 2022-06-26 11:38:11.560517
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:26.752785
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test the constructor of class ArchiveOrgIE.
    """
    ArchiveOrgIE.__init__()

# Generated at 2022-06-26 11:38:31.168722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test = ArchiveOrgIE()
    assert test.IE_NAME == 'archive.org'
    assert test.IE_DESC == 'archive.org videos'
    assert test._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:43.362650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "^https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)$"

# Generated at 2022-06-26 11:38:45.860121
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:38:56.456342
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'
    assert a.IE_DESC == 'archive.org videos'

    # unit test for _real_extract()
    # test case 1: extract data from jwplayer json format
    assert a._real_extract({'url': 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'})

    # test case 2: extract data from HTML5 media format
    assert a._real_extract({'url': 'https://archive.org/details/Cops1922'})

# Generated at 2022-06-26 11:38:59.802445
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    assert ie.suitable(url)

# Generated at 2022-06-26 11:39:08.528486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')

# Generated at 2022-06-26 11:39:16.240318
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
	ie = ArchiveOrgIE()
	assert ie.IE_NAME == "archive.org"
	assert ie.IE_DESC == "archive.org videos"
	assert ie._VALID_URL == "https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
	assert ie.IE_VERSION == None

# Generated at 2022-06-26 11:39:17.661653
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()
    assert(archive_org_ie.IE_NAME == 'archive.org')

# Generated at 2022-06-26 11:39:18.323427
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:46.253294
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for constructor
    ie = ArchiveOrgIE()

    # Test for methods
    assert ie.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True

# Generated at 2022-06-26 11:39:48.086681
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_initialize()

# Generated at 2022-06-26 11:39:50.425872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inst = ArchiveOrgIE()
    assert inst._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:39:59.353737
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME = 'archive.org'
    ie.IE_DESC = 'archive.org videos'
    ie._VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:04.551322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    instance = ie._build_url_result('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._match_id(instance) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-26 11:40:08.857566
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME=='archive.org'
    assert a.IE_DESC=='archive.org videos'
    assert a._VALID_URL=='https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:11.283336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test the constructor
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    # Test the regular expression
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:13.963245
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert "ArchiveOrgIE" in dir(__import__("youtube_dl.extractor.archiveorg", globals(), locals(), ['ArchiveOrgIE']))
    

# Generated at 2022-06-26 11:40:16.151089
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:17.679557
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:41:18.160459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test the constructor of class ArchiveOrgIE."""
    aoe = ArchiveOrgIE()
    assert aoe._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"
    assert aoe.IE_NAME == "archive.org"

# Generated at 2022-06-26 11:41:19.447095
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().ie_key() == 'archive.org'

# Generated at 2022-06-26 11:41:20.432595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.IE_NAME

# Generated at 2022-06-26 11:41:22.656625
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Unit test for ArchiveOrgIE constructor.
    The constructor will be called implicitly in the test_download_webpage()
    method so don't explicitly call it in other unit test methods.
    '''
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:23.558801
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

test_ArchiveOrgIE()

# Generated at 2022-06-26 11:41:24.428873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:41:26.909239
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:27.471377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:28.233421
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Ensure that we do not crash when we construct an instance of ArchiveOrgIE
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:28.562563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:48.883303
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-26 11:43:51.105748
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE('https://archive.org/details/Cops1922')
    except TypeError:
        raise Exception('ArchiveOrgIE constructor test failed')

# Generated at 2022-06-26 11:43:52.864313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	("Test ArchiveOrgIE")
	ArchiveOrgIE()

test_ArchiveOrgIE()

# Generated at 2022-06-26 11:43:54.185073
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:43:57.565914
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for constructor of class ArchiveOrgIE"""
    ie = ArchiveOrgIE(None)

    assert ie.IE_DESC == 'archive.org videos'
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:44:03.237736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Constructor test
    """
    ie = ArchiveOrgIE()
    # Ensure that it's always callable
    ie.suitable('http://archive.org/details/')
    # Ensure that it's always has the name and description
    assert ie.IE_NAME
    assert ie.IE_DESC
    # Ensure that it's always has an extractor group
    ie.gen_extractors()
    assert ie.extractor

# Generated at 2022-06-26 11:44:06.734506
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.get_info_extractor() is ArchiveOrgIE
    assert obj.ie_name == ArchiveOrgIE.IE_NAME
    assert obj.ie_description == ArchiveOrgIE.IE_DESC
    assert obj.ie_id == ArchiveOrgIE.IE_DESC

# Generated at 2022-06-26 11:44:15.941220
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert not ArchiveOrgIE().can_extract('https://archive.org/details/')
    assert not ArchiveOrgIE().can_extract('https://archive.org/')
    assert not ArchiveOrgIE().can_extract('https://archive.org/details/MSNBCW')
    assert ArchiveOrgIE().can_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ArchiveOrgIE().can_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator')

# Generated at 2022-06-26 11:44:18.386676
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('archive.org')._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:44:22.240987
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'