

# Generated at 2022-06-26 11:36:49.473836
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

    # Check attributes of class ArchiveOrgIE
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:36:50.538887
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0



# Generated at 2022-06-26 11:36:52.655475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    generalIE_0 = ArchiveOrgIE()
    print('Unit test for class ArchiveOrgIE is called.')


# Generated at 2022-06-26 11:36:54.449884
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:57.982958
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_equal(archive_org_i_e_0.IE_NAME, 'archive.org')
    assert_equal(archive_org_i_e_0.IE_DESC, 'archive.org videos')


# Generated at 2022-06-26 11:36:59.399138
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:11.049955
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:37:11.998185
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:17.226968
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'
    assert archive_org_i_e._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:37:22.608794
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_parameter_type_string(ArchiveOrgIE, 'name', 'ie_name')
    assert_parameter_type_string(ArchiveOrgIE, 'description', 'ie_desc')
    assert_parameter_type_string(ArchiveOrgIE, 'url', '_VALID_URL')


# Generated at 2022-06-26 11:37:28.656998
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:37:29.904430
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:30.941001
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-26 11:37:41.674986
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from .test_common import TestCommon
        from .test_generic_info_extractor import TestGenericInfoExtractor
    except ImportError:
        from test_common import TestCommon
        from test_generic_info_extractor import TestGenericInfoExtractor

    def test_entry_for_frame(self, info_dict, entry_index, expected_urls):
        video_info = info_dict['entries'][entry_index]
        if 'url' not in video_info:
            return
        actual_urls = []
        for assoc_url, assoc_value in video_info['url'].items():
            if assoc_url == 'class' and assoc_value == 'playlist':
                continue
            actual_urls.append(assoc_url)

# Generated at 2022-06-26 11:37:42.079176
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:37:43.000826
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-26 11:37:55.605291
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:56.932607
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'archive.org videos')

# Generated at 2022-06-26 11:37:59.486298
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("archive.org")
    assert(ie.IE_NAME == "archive.org")

# Constructor for ArchiveOrgIE 

# Generated at 2022-06-26 11:38:03.586170
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:16.191223
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Method that will be used by the Unit Test
    """
    return ArchiveOrgIE()

# Generated at 2022-06-26 11:38:19.569323
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for class ArchiveOrgIE"""
    instance = ArchiveOrgIE()
    instance.IE_NAME



if __name__ == '__main__':
    import sys

    sys.exit(test_ArchiveOrgIE())

# Generated at 2022-06-26 11:38:28.715722
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveorg_ie = ArchiveOrgIE()
    assert archiveorg_ie.IE_NAME == 'archive.org'
    assert archiveorg_ie.IE_DESC == 'archive.org videos'
    assert archiveorg_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archiveorg_ie._TESTS[3] == {
        'url': 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'only_matching': True,
    }

# Generated at 2022-06-26 11:38:29.639026
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: add a real unit test for this class
    pass

# Generated at 2022-06-26 11:38:36.118228
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Set data for testing
    data = [{'id': '1', 'url': 'http://archive.org/details/1'}]
    test_class = ArchiveOrgIE(ArchiveOrgIE._download_webpage,
                              ArchivesOrgIE._parse_html5_media_entries,
                              ArchiveOrgIE._parse_jwplayer_data,
                              ArchiveOrgIE._download_json,
                              ArchiveOrgIE._search_regex,
                              ArchiveOrgIE._match_id,
                              ArchiveOrgIE._parse_json)
    test_class._real_extract(data[0]['url'])



# Generated at 2022-06-26 11:38:39.914569
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test whether a instance of class ArchiveOrgIE can be constructed."""
    # This will raise exception if construction fails.
    ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:40.872076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    InfoExtractor("ArchiveOrgIE")

# Generated at 2022-06-26 11:38:41.824945
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') != None

# Generated at 2022-06-26 11:38:43.886015
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:44.989007
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:39:09.506092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # sanity check
    class_name = 'ArchiveOrgIE'
    ie = globals()[class_name]()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-26 11:39:16.976092
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:17.390080
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:19.825618
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == ie.ie_key()
    assert ie.IE_DESC == ie.ie_desc()
    assert ie._VALID_URL == ie.valid_url()


# Generated at 2022-06-26 11:39:21.048650
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return ArchiveOrgIE()

# Generated at 2022-06-26 11:39:32.004205
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	from .common import InfoExtractor
	from ..utils import (
	    clean_html,
	    extract_attributes,
	    unified_strdate,
	    unified_timestamp,
	)
	_VALID_URL = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
	video_id = r'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
	url = r'http://archive.org/details/' + video_id
	webpage = r'http://archive.org/embed/' + video_id
	playlist = None

# Generated at 2022-06-26 11:39:35.439997
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    y = x.get_url_re()
    y = re.findall(y, 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    print(y[0])
    # assert y[0] == 'MOOC2015_001'

# Generated at 2022-06-26 11:39:36.647638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:39.515833
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  from .common import InfoExtractor
  ie = InfoExtractor()
  ie.constructor('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:39:47.897969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._match_id(url) == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._match_id(url + '/') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._match_id(url + '#whatever') == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'


# Generated at 2022-06-26 11:40:39.499235
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ia_instance = ArchiveOrgIE()
    obj = ia_instance.ie_key()
    assert obj == 'archive.org'


# Generated at 2022-06-26 11:40:41.712851
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    

# Generated at 2022-06-26 11:40:52.673637
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    video_id = 'test_id'
    webpage = '<html></html>'
    download_webpage = lambda self, url, video_id: webpage
    search_regex = lambda self, *x, **y: None
    parse_html5_media_entries = lambda self, *x, **y: [{'id': 'test_id'}]
    parse_jwplayer_data = lambda self, *x, **y: [{'id': 'test_id'}]
    parse_json = lambda self, *x, **y: None
    a = ArchiveOrgIE()
    a._download_webpage = download_webpage
    a._search_regex = search_regex
    a._parse_jwplayer_data = parse_jwplayer_data
    a._parse_json = parse_json

# Generated at 2022-06-26 11:40:57.070380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    print("ie.IE_NAME = %s" % ie.IE_NAME)
    print("ie.IE_DESC = %s" % ie.IE_DESC)
    print("ie._VALID_URL = %s" % ie._VALID_URL)
    print("ie._TESTS = %s" % ie._TESTS)


# Generated at 2022-06-26 11:41:00.492591
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:01.249816
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE._TESTS

# Generated at 2022-06-26 11:41:04.296263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    ie = InfoExtractor.for_site(ArchiveOrgIE)
    ie = InfoExtractor(ArchiveOrgIE.ie_key())
    assert ie.ie_key() == ArchiveOrgIE.ie_key()
    assert ie.suitable(ArchiveOrgIE._VALID_URL)

# Generated at 2022-06-26 11:41:07.531982
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    # TODO: Add more unit tests for ArchiveOrgIE
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:41:09.493668
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-26 11:41:12.194311
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.get_domain() == "archive.org"
    assert ie.get_source_name() == "ArchiveOrg"
    assert ie.get_source_id() == "archive.org"

# Generated at 2022-06-26 11:43:27.141319
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda url, id, data=None : 'abc'
    ie._parse_jwplayer_data = lambda jwplayer_data, video_id, **kwargs: { 'abc':123, 'url': '', 'id': '' }
    ie._parse_html5_media_entries = lambda page_url, webpage, video_id: []
    ie.prepare_url = lambda url: url
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:28.570076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:38.042812
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import json
    import sys
    if sys.version_info.major == 2:
        import urllib
        import urllib2
    else:
        import urllib.request as urllib2

    # Python 2.7 doesn't have json.loads method, and it doesn't have a
    # corresponding packaging for python2.7!
    # See Python bug https://bugs.python.org/issue27762.
    # In Python 3.4 and later, json.loads should be able to handle data
    # returned from urllib2.urlopen, but not in Python 2.7.
    # See python bug https://bugs.python.org/issue16835.
    # So, we need to decode response.read() before parsing it.
    #
    # Meanwhile, urllib2.urlopen in Python 2.7 will raise htt

# Generated at 2022-06-26 11:43:42.413362
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:43:43.675721
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    is_instance_of(ArchiveOrgIE,InfoExtractor)

# Generated at 2022-06-26 11:43:47.565530
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) > 0

# Generated at 2022-06-26 11:43:56.860213
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        from ..utils import determine_ext
    except ImportError:
        from ytdl.utils import determine_ext

    ie = ArchiveOrgIE()
    # From https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect

# Generated at 2022-06-26 11:44:03.559468
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == {
        '_type': 'url_transparent',
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ie_key': 'ArchiveOrg',
        'url': 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    }


# Generated at 2022-06-26 11:44:10.610752
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    webpage = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'

# Generated at 2022-06-26 11:44:13.793486
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    inp = ['http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
           'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect']