

# Generated at 2022-06-26 11:36:46.343659
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(isinstance(archive_org_i_e_0, InfoExtractor))


# Generated at 2022-06-26 11:36:47.502999
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    s_archiv_org_ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:48.925632
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(isinstance(archive_org_i_e_0, ArchiveOrgIE))
 

# Generated at 2022-06-26 11:36:52.567017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0.extract_info("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-26 11:37:04.157159
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if not hasattr(classmethod, '__call__'):
        return


# Generated at 2022-06-26 11:37:05.218243
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:06.281859
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:12.606476
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # gen_ut_logging_func_case(test_case_0, arg_list_0)
    # gen_ut_logging_func_case(test_case_1, arg_list_1)
    # gen_ut_logging_func_case(test_case_2, arg_list_2)
    # gen_ut_logging_func_case(test_case_3, arg_list_3)
    pass

# Generated at 2022-06-26 11:37:14.369638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e


# Generated at 2022-06-26 11:37:18.529790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL.__eq__(r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert ArchiveOrgIE.IE_DESC.__eq__('archive.org videos')
    assert ArchiveOrgIE.IE_NAME.__eq__('archive.org')

# Generated at 2022-06-26 11:37:36.007507
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org = ArchiveOrgIE()
    archive_org.IE_NAME = 'archive.org'
    archive_org.IE_DESC = 'archive.org videos'
    archive_org._VALID_URL = r'https?://archive\.org/details/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:39.528160
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Unit test for constructor of ArchiveOrgIE class.
    '''
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'ArchiveOrg'
    assert ie.ie_name() == 'archive.org'

# Generated at 2022-06-26 11:37:42.358380
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:48.964839
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_ArchiveOrgIE = ArchiveOrgIE()
    if ie_ArchiveOrgIE.IE_NAME != 'archive.org':
        raise AssertionError('ArchiveOrgIE.IE_NAME must be archive.org')
    if ie_ArchiveOrgIE.IE_DESC != 'archive.org videos':
        raise AssertionError('ArchiveOrgIE.IE_DESC must be archive.org videos')

# Generated at 2022-06-26 11:37:52.787765
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:57.495290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:06.617240
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

    # validate regex
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    id = ie._match_id(url)
    assert id == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    url = 'https://archive.org/details/Cops1922'
    id = ie._match_id(url)
    assert id == 'Cops1922'
    url = 'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    id = ie._match_id(url)

# Generated at 2022-06-26 11:38:07.586800
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:14.133885
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:16.495684
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert archive.IE_DESC == 'archive.org videos'
    assert archive.IE_NAME == 'archive.org'
# Test actual test websites

# Generated at 2022-06-26 11:38:36.507852
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE('www.archive.org', 'archive.org')
    a.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    a.suitable('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    a.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    a.suitable('https://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    a.suitable('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:38:38.041934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(True)
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 11:38:40.309598
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()._get_info_extractor('archive.org')

# Generated at 2022-06-26 11:38:40.922488
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:38:45.309256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:38:45.796868
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:46.439079
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:48.400920
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:39:00.938319
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    info_dict = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'mp4',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }
    extractor = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:05.615068
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:39:37.604921
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tests below use an example of youtube-dl's archive.org entry.
    # http://archive.org/details/Y3K3_CD_06-16-11_SATURATION_3
    archive_org_ie = ArchiveOrgIE()
    assert archive_org_ie.IE_NAME in archive_org_ie.ie_key()

    url = 'http://archive.org/details/Y3K3_CD_06-16-11_SATURATION_3'
    assert archive_org_ie.suitable(url)
    assert archive_org_ie.IE_NAME == archive_org_ie.ie_key_from_url(url)


# Generated at 2022-06-26 11:39:39.785184
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    return ie

# Generated at 2022-06-26 11:39:42.468838
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:39:51.506629
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert not ie.is_suitable_url("http://google.com/")
    assert not ie.is_suitable_url("http://archive.org/")
    assert ie.is_suitable_url("http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.is_suitable_url("https://archive.org/details/Cops1922")
    assert ie.is_suitable_url("https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/")


# Generated at 2022-06-26 11:39:53.325025
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive = ArchiveOrgIE()
    assert(hasattr(archive, '_download_webpage'))
    

# Generated at 2022-06-26 11:40:01.416546
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:03.112450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check if ArchiveOrgIE is not None
    assert ArchiveOrgIE(None) is not None

# Generated at 2022-06-26 11:40:06.805237
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Ensure that ArchiveOrgIE is not affected by
    # https://github.com/rg3/youtube-dl/issues/4773
    assert ArchiveOrgIE('archive.org')._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:40:08.574119
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    ExtractorTest(info_extractor, 'random_url').run()

# Generated at 2022-06-26 11:40:10.861593
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:41:17.685108
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try: 
        archive_org_ie = ArchiveOrgIE()
    finally:
        ArchiveOrgIE._download_webpage = archive_org_ie._download_webpage
        ArchiveOrgIE._search_regex = archive_org_ie._search_regex
        ArchiveOrgIE._parse_json = archive_org_ie._parse_json
        ArchiveOrgIE._parse_jwplayer_data = archive_org_ie._parse_jwplayer_data
        ArchiveOrgIE._parse_html5_media_entries = archive_org_ie._parse_html5_media_entries
        ArchiveOrgIE._download_json = archive_org_ie._download_json
        ArchiveOrgIE._match_id = archive_org_ie._match_id

# Generated at 2022-06-26 11:41:20.557535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    m = ie.match(url)
    ie.get_video_info(url)
    ie.extract(url)

# Generated at 2022-06-26 11:41:26.510952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert ie._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['info_dict']['ext'] == 'ogg'
    assert ie

# Generated at 2022-06-26 11:41:28.107737
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'
    assert ArchiveOrgIE(None).IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:41:38.255528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:45.233173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:47.672583
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ifile = ArchiveOrgIE()
    file_1 = ifile.extract(url)
    return file_1

# Generated at 2022-06-26 11:41:48.557651
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    print('Constructing ArchiveOrgIE')
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-26 11:41:49.003725
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:55.037423
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info = ArchiveOrgIE()._real_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert(info['title']=='MSNBCW (MSNBCW)_2013-11-25_040000_To_Catch_a_Predator')

# Generated at 2022-06-26 11:44:13.265248
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ''' Unit tests for constructor of class ArchiveOrgIE. '''
    ArchiveOrgIE()

# Generated at 2022-06-26 11:44:15.255464
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.add_ie(ArchiveOrgIE.ie_key())
    return ie

# Generated at 2022-06-26 11:44:18.823367
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:44:27.457739
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # test construction of ArchiveOrgIE using local files
    import os.path
    from .test_common import fake_getaddrinfo
    from .test_downloader import FakeYDL
    fake_getaddrinfo()
    ydl = FakeYDL()
    ydl.params['simulate'] = True
    ydl.params['nooverwrites'] = True
    ydl.params['skip_download'] = True
    ydl.add_info_extractor(ArchiveOrgIE())

    test_root = os.path.dirname(os.path.abspath(__file__))
    filename = os.path.join(test_root, 'test.html')
    with open(filename) as web_page:
        webpage = web_page.read()

    # Test old jwplayer
    ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:44:29.318832
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-26 11:44:30.152686
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    tester = ArchiveOrgIE()

# Generated at 2022-06-26 11:44:34.937446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE
    """
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:44:36.938948
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:44:39.165851
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', 'ArchiveOrgIE', 'archive.org videos')

# Generated at 2022-06-26 11:44:41.935347
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert(IE.IE_NAME == 'archive.org')
    assert(IE.IE_DESC == 'archive.org videos')