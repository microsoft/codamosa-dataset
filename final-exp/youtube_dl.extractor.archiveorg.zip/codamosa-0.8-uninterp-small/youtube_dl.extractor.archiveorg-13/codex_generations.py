

# Generated at 2022-06-26 11:36:44.454089
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:45.467446
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:36:55.952663
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:36:56.935390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    e = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:02.188871
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:04.206783
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test case 0
    # Instance ArchiveOrgIE
    archive_org_i_e_0 = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:06.477338
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Assert that ArchiveOrgIE constructs object successfully
    assert isinstance(archive_org_i_e_0, ArchiveOrgIE)

# Generated at 2022-06-26 11:37:07.870790
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_1 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:17.932985
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:21.545313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


test_case_0()
test_ArchiveOrgIE()

# Generated at 2022-06-26 11:37:32.961428
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:38.295045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # For constructor ArchiveOrgIE()
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:37:39.114822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:37:41.583854
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    assert type(archive_org_i_e_0) == ArchiveOrgIE


# Generated at 2022-06-26 11:37:42.962931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(isinstance(archive_org_i_e_0, ArchiveOrgIE))

# Test for method extract

# Generated at 2022-06-26 11:37:44.122992
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()



# Generated at 2022-06-26 11:37:44.988316
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE


# Generated at 2022-06-26 11:37:50.374669
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0.IE_NAME == 'archive.org'
    assert archive_org_i_e_0.IE_DESC == 'archive.org videos'
    

# Generated at 2022-06-26 11:37:52.696257
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tests ArchiveOrgIE constructor
    assert(test_ArchiveOrgIE.__name__ == "test_ArchiveOrgIE")
    # Should not throw any exceptions

# Generated at 2022-06-26 11:37:56.341595
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

if __name__ == '__main__':
    # When run as a script, these tests
    # will create an instance of the object
    # and run all its methods.
    test_case_0()

# Generated at 2022-06-26 11:38:07.804872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:11.662793
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:38:12.983996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert issubclass(ArchiveOrgIE, InfoExtractor)

# Generated at 2022-06-26 11:38:14.087077
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:15.087267
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:17.690594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE
    """
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:28.942889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)

    # Test some simple URLs
    assert ie._check_valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._check_valid_url('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._check_valid_url('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._check_valid_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

    # Test URL with some GET parameters

# Generated at 2022-06-26 11:38:29.900879
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME

# Generated at 2022-06-26 11:38:31.582764
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test that class ArchiveOrgIE can be instantiated."""
    assert ArchiveOrgIE('archive.org') is not None

# Generated at 2022-06-26 11:38:34.277398
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.json_ld is not None
    assert obj.ie_key() == ArchiveOrgIE.ie_key()


# Unit testing for method _real_extract() of class ArchiveOrgIE

# Generated at 2022-06-26 11:39:04.964172
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    expected = {
            'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'ext': 'mp4',
            'title': '1968 Demo - FJCC Conference Presentation Reel #1',
            'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
            'creator': 'SRI International',
            'release_date': '19681210',
            'uploader': 'SRI International',
            'timestamp': 1268695290,
            'upload_date': '20100315',
        }

# Generated at 2022-06-26 11:39:07.760967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for testing of constructor of class ArchiveOrgIE.
    """
    ie = ArchiveOrgIE()
    return ie

# Generated at 2022-06-26 11:39:11.120777
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # build the class object to test
    ie = ArchiveOrgIE()
    try:
        ie.IE_DESC
        ie.IE_NAME
        ie._VALID_URL
        ie.__init__()
    finally:
        ie.__del__()


# Generated at 2022-06-26 11:39:14.066302
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"

# Generated at 2022-06-26 11:39:15.156450
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert issubclass(ArchiveOrgIE, InfoExtractor)


# Generated at 2022-06-26 11:39:21.520334
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'



# Generated at 2022-06-26 11:39:30.721849
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    from .. import ArchiveOrgIE

    assert hasattr(ArchiveOrgIE, '_VALID_URL')
    assert ArchiveOrgIE._VALID_URL is not None
    assert hasattr(ArchiveOrgIE, '_TESTS')
    assert ArchiveOrgIE._TESTS is not None
    assert hasattr(ArchiveOrgIE, 'IE_NAME')
    assert hasattr(ArchiveOrgIE, 'IE_DESC')

    return True

# Generated at 2022-06-26 11:39:34.954908
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    It is hard to test for the existence of the ArchiveOrgIE class.
    So we use the class constructor to test for existence,
    by trying to instantiate the class.
    """
    print("Testing for existence of class ArchiveOrgIE")
    ie = ArchiveOrgIE()
    print("class ArchiveOrgIE exists.")
    return

# Generated at 2022-06-26 11:39:36.239067
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	import doctest
	doctest.testmod()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 11:39:40.664295
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:25.810011
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ie._TESTS) == 4
    

# Generated at 2022-06-26 11:40:27.311555
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    return assertEqual(ie.IE_NAME, 'archive.org')

# Generated at 2022-06-26 11:40:29.129524
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert hasattr(ie, '_download_webpage')

# Generated at 2022-06-26 11:40:38.550519
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE

###test

# Generated at 2022-06-26 11:40:39.300896
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:40:40.130905
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:40:49.754889
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test archive.org
    info_extractor = ArchiveOrgIE({})
    assert info_extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert info_extractor._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info_extractor._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert info_extractor._TESTS[0]['info_dict']['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info_

# Generated at 2022-06-26 11:40:53.530665
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.ie_key() == 'archive.org'
    assert obj.ie_name() == 'archive.org videos'
    assert obj.test()


# Generated at 2022-06-26 11:40:54.630149
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__ == 'ArchiveOrgIE'


# Generated at 2022-06-26 11:40:55.153248
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:42:52.118016
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    AssertionError

# Generated at 2022-06-26 11:42:52.543976
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:02.070500
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_dict = {
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'creator': 'SRI International',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE(url)
    info = ie._real_extract

# Generated at 2022-06-26 11:43:05.867120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from ytdl.tests.test_videoinfoextractor import MockIE
    for attribute in ArchiveOrgIE.__dict__:
        if not attribute.startswith('_') and attribute != 'suitable':
            setattr(MockIE, attribute, getattr(ArchiveOrgIE, attribute))
    MockIE(ArchiveOrgIE.ie_key(), ArchiveOrgIE.ie_name())

# Generated at 2022-06-26 11:43:16.125181
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # The url was copied from
    # https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archiveorg_ie = ArchiveOrgIE()
    archiveorg_ie._real_extract(url)


    # The url was copied from https://archive.org/details/Cops1922
    url = 'https://archive.org/details/Cops1922'
    ArchiveOrgIE()._real_extract(url)

    # The url was copied from
    # http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect

# Generated at 2022-06-26 11:43:20.089561
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.ie_key() == 'archive.org', ie.ie_key()
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-26 11:43:23.361675
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert hasattr(ArchiveOrgIE, '_VALID_URL')
    assert hasattr(ArchiveOrgIE, 'IE_NAME')
    assert hasattr(ArchiveOrgIE, 'IE_DESC')
    assert hasattr(ArchiveOrgIE, '_TESTS')


# Generated at 2022-06-26 11:43:25.404063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Passing any url to the constructor should be successful
    ArchiveOrgIE("http://www.youtube.com/watch?v=BaW_jenozKc")

# Generated at 2022-06-26 11:43:29.531813
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for entry in ArchiveOrgIE._TESTS:
        extractor = ArchiveOrgIE()
        extractor.suitable(entry['url'])
        extractor.extract(entry['url'])
    return True

# Generated at 2022-06-26 11:43:34.081552
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	filename = 'ArchiveOrgIE.py'
	test_ArchiveOrgIE = ArchiveOrgIE()
	test_ArchiveOrgIE._real_extract
	test_ArchiveOrgIE.suitable