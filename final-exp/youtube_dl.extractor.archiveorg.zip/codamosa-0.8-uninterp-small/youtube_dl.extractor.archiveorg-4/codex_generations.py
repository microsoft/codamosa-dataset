

# Generated at 2022-06-26 11:36:42.129130
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

#Unit test for method _real_extract

# Generated at 2022-06-26 11:36:43.085188
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE


# Generated at 2022-06-26 11:36:45.251822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    archive_org_i_e_1 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:50.244863
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	archive_org_i_e = ArchiveOrgIE()
	assert archive_org_i_e.IE_DESC == 'archive.org videos'
	assert archive_org_i_e.IE_NAME == 'archive.org'
	assert archive_org_i_e._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:36:51.273654
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()

# Generated at 2022-06-26 11:36:53.079011
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:54.839662
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:06.072535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:06.685437
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:37:10.757336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_equal(archive_org_i_e_0.ie_name(),'archive.org')
    assert_equal(archive_org_i_e_0.ie_desc(),'archive.org videos')


# Generated at 2022-06-26 11:37:20.597622
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # missing archive.org hostname in URL
    try:
        ArchiveOrgIE('https://example.org/embed/12345')
    except AssertionError:
        pass
    else:
        assert False, 'did not raise AssertionError'

# Generated at 2022-06-26 11:37:31.682376
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE with a simple test case
    case1_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    case1_test = ArchiveOrgIE()._real_extract(case1_url)

# Generated at 2022-06-26 11:37:42.227139
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:54.743968
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'
    assert sorted(info_extractor._VALID_URL.split('|')) == [
        r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)',
        r'https?://(?:www\.)?archive\.org/details/\w+'
    ]
    # assert info_extractor._TESTS == [
    #     {
    #         'md5': '8af1d4cf447933ed3c7f4871162602db',
    #         'info_dict': {
    #             'description': 'md5:da

# Generated at 2022-06-26 11:37:56.239017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.__name__=='ArchiveOrgIE'


# Generated at 2022-06-26 11:37:57.133872
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:37:58.465948
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:38:07.140721
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_ = globals()['ArchiveOrgIE']
    assert class_._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert class_._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert class_._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'
    assert class_._TESTS[1]['url'] == 'https://archive.org/details/Cops1922'

# Generated at 2022-06-26 11:38:14.446855
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  video_id = "XD300-23_68HighlightsAResearchCntAugHumanIntellect"
  url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
  ie = ArchiveOrgIE(url)
  assert ie.url == url
  assert ie.video_id == video_id
  assert ie.ie_key() == "archive.org"

# Generated at 2022-06-26 11:38:16.818517
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'



# Generated at 2022-06-26 11:38:29.032304
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert isinstance(ArchiveOrgIE, InfoExtractor)

# Generated at 2022-06-26 11:38:31.124670
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("http://https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-26 11:38:33.032042
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(display_id='XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None


# Generated at 2022-06-26 11:38:33.939821
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:37.019148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();
    ie.download('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect');


# Generated at 2022-06-26 11:38:38.502461
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE.suite()

# Generated at 2022-06-26 11:38:39.978204
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:41.371736
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:42.225999
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:46.116150
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # If a URL is supplied to the constructor, it should be the same as the one returned by url_result
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    obj = ArchiveOrgIE(test_url)
    assert obj.url_result() == test_url

# Generated at 2022-06-26 11:39:11.825409
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:13.839120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Note: constructor of ArchiveOrgIE will be called in _real_extract method
    # of class InfoExtractor
    pass

# Generated at 2022-06-26 11:39:17.032931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.ie_key() == 'archive.org'
    assert i.ie_desc() == 'archive.org videos'
    assert i.extract('https://archive.org/details/foo')
    assert not i.extract('https://archive.org/foo')

# Generated at 2022-06-26 11:39:17.417244
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	pass

# Generated at 2022-06-26 11:39:21.043051
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    A unit test for testing ArchiveOrgIE constructor
    """
    archive_org_ie = ArchiveOrgIE()
    assert(archive_org_ie.IE_NAME == 'archive.org')
    assert(archive_org_ie.IE_DESC == 'archive.org videos')

# Generated at 2022-06-26 11:39:21.891521
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:23.099045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:29.280174
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    assert extractor.IE_NAME == 'archive.org'
    assert extractor.IE_DESC == 'archive.org videos'
    assert extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:39:32.898500
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "http://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 11:39:33.989121
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass # test on archive.org.test_ArchiveOrgIE.py

# Generated at 2022-06-26 11:40:29.245833
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE = ArchiveOrgIE('archive.org')
    assert test_ArchiveOrgIE.IE_NAME == 'archive.org'
    assert test_ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert test_ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert test_ArchiveOrgIE._TESTS
    assert test_ArchiveOrgIE._real_extract
    assert test_ArchiveOrgIE._download_webpage
    assert test_ArchiveOrgIE._match_id
    assert test_ArchiveOrgIE._search_regex
    assert test_ArchiveOrgIE._parse_json
    assert test_ArchiveOrgIE._parse_jw

# Generated at 2022-06-26 11:40:30.937075
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(isinstance(ArchiveOrgIE(), ArchiveOrgIE))

# Generated at 2022-06-26 11:40:35.648272
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie.info_extractors[0].ie_key()
    assert ie.suitable(info) is True
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-26 11:40:40.209877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # We can use the usual constructor
    ie = ArchiveOrgIE(system=None, http_adapter=None)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    # We can query our dictionary of 'known URLs'
    assert ArchiveOrgIE._VALID_URL is 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:48.970469
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import youtube_dl
        YoutubeDL = youtube_dl.YoutubeDL
    except ImportError:
        YoutubeDL = None

    if YoutubeDL:
        # Verify if constructor of ArchiveOrgIE is correct
        youtube_dl.utils.std_headers['User-Agent'] = 'Mozilla/5.0 (X11; Linux i686; rv:8.0) Gecko/20100101 Firefox/8.0'
        ydl = YoutubeDL({
            'quiet': True,
        })
        ydl.add_default_info_extractors()
        ydl.prepare_filename('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:40:57.512751
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    expected_result = {'url': 'http://archive.org', 'playlist': []}
    ie = ArchiveOrgIE('http://archive.org')
    assert ie._VALID_URL == 'https?://(?:www\\.)?archive\\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS == []
    assert ie._downloader == None
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie._WORKING == True
    assert ie._real_initialize() == True
    assert ie._real_extract('http://archive.org') == expected_result

# Generated at 2022-06-26 11:41:00.354983
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.name == "archive.org"
    assert ie.description == "archive.org videos"
    return

# Unit tests for class ArchiveOrgIE
from .test_archiveorg import *

# Integrational test for class ArchiveOrgIE

# Generated at 2022-06-26 11:41:03.180560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive_org'
    assert ie.ie_name() == 'archive.org'
    assert ie.ie_description() == 'archive.org videos'
    assert ie.ie_info_page_url() == 'http://www.archive.org'

# Generated at 2022-06-26 11:41:12.456188
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:20.343038
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:31.032594
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._download_webpage = lambda *args, **kwargs: '<html></html>'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:43:31.773051
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:33.404358
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # constructor of class ArchiveOrgIE
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:34.940538
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-26 11:43:38.633202
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"


# Generated at 2022-06-26 11:43:43.598666
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(len(ie._TESTS) == 4)

# Generated at 2022-06-26 11:43:47.168394
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:43:51.285622
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE()
    info = ie.extract(url)
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'

# Generated at 2022-06-26 11:43:53.351708
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')


# Generated at 2022-06-26 11:44:03.055081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE
    assert i.IE_NAME=='archive.org'
    assert i.IE_DESC=='archive.org videos'
    assert i._VALID_URL== r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'