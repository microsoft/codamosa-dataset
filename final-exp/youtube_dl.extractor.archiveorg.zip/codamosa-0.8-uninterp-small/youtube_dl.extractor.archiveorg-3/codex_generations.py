

# Generated at 2022-06-26 11:36:43.274066
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    return

# Generated at 2022-06-26 11:36:44.110359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:36:45.395497
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:49.038934
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:36:50.225499
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert_raises (Exception, test_case_0)

# Generated at 2022-06-26 11:36:55.764535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:36:57.217242
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:57.825870
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:36:58.452129
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(True)

# Generated at 2022-06-26 11:36:59.844838
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 11:37:10.915465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect").name == "archive.org"
    assert ArchiveOrgIE().name == "archive.org"
    assert ArchiveOrgIE("http://archive.org/").name == "archive.org"

# Name this test something that will be run before the above test.

# Generated at 2022-06-26 11:37:19.523153
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == "archive.org"
    assert ArchiveOrgIE.IE_DESC == "archive.org videos"
    assert ArchiveOrgIE._VALID_URL == "https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 11:37:30.889894
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # Test for _real_extract method of ArchiveOrgIE
    assert ie._real_extract(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie._real_extract(
        'https://archive.org/details/Cops1922')

# Generated at 2022-06-26 11:37:36.104241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:37.502504
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None)._VALID_URL == ArchiveOrgIE.VALID_URL

# Generated at 2022-06-26 11:37:40.966982
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        assert ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') is not None
    except AssertionError:
        print('test_ArchiveOrgIE fail')

# Generated at 2022-06-26 11:37:41.961084
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:37:44.095672
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Call ArchiveOrgIE constructor, which calls the constructor of InfoExtractor
    """
    ie = ArchiveOrgIE([], {}, {}, None)

# Generated at 2022-06-26 11:37:50.902457
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:01.545570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    file_path = os.path.dirname(os.path.abspath(__file__))
    config_path = os.path.join(file_path, "test.cfg")
    ydl = YoutubeDL({'config_filename': config_path})
    ie = ArchiveOrgIE(ydl=ydl)
    url = "https://archive.org/details/MSNBCW_20131125_040000_" \
        "To_Catch_a_Predator/"
    res = ie._real_extract(url)
    assert res["id"] == "MSNBCW_20131125_040000_To_Catch_a_Predator"
    assert res["title"] == "To Catch a Predator"

# Generated at 2022-06-26 11:38:15.087356
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    info_extractor._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:38:15.944877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-26 11:38:16.899056
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(None)

# Generated at 2022-06-26 11:38:19.234773
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:30.197753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    x = InfoExtractor()
    assert x.IE_NAME == 'archive.org'
    assert x.IE_DESC == 'archive.org videos'
    assert x._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:31.168676
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE.ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:32.386000
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE(): assert ArchiveOrgIE()


# Generated at 2022-06-26 11:38:34.850314
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()._real_extract("http://archive.org/details/BusterKeatonsCops1922")

# Generated at 2022-06-26 11:38:45.738505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.IE_DESC == "archive.org videos"
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:59.020447
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:22.440535
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:26.372775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE(downloader=None)
    assert infoExtractor.IE_NAME == "archive.org"
    assert infoExtractor.IE_DESC == "archive.org videos"


# Generated at 2022-06-26 11:39:27.839745
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:28.797203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	pass


# Generated at 2022-06-26 11:39:30.069533
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE == ArchiveOrgIE(None).__class__

# Generated at 2022-06-26 11:39:34.509475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:40.314063
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	try:
		from ydl.extractor.archiveorg import ArchiveOrgIE
	except ImportError:
		return None
	extractor = ArchiveOrgIE(None)
	assert extractor.IE_NAME == 'archive.org'
	assert extractor.IE_DESC == 'archive.org videos'
	assert extractor._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:42.869942
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Verify that ArchiveOrgIE inherits from InfoExtractor
    ie = ArchiveOrgIE('http://www.archive.org/details/example')
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-26 11:39:44.337906
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(isinstance(ie, InfoExtractor))

# Generated at 2022-06-26 11:39:50.565199
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    # We need to test if the regexp match all valid URLs
    valid_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'

    assert re.match(ie._VALID_URL, valid_url) is not None

# Generated at 2022-06-26 11:40:46.449412
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	# Create an instance of class ArchiveOrgIE
	archive_org_ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:40:47.864669
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test method for ArchiveOrgIE
    """
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-26 11:40:48.641822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('')

# Generated at 2022-06-26 11:40:51.811296
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #def __init__(self, ie, name, description, *args):
    ArchiveOrgIE(None, 'name', 'description', None, None)

# Generated at 2022-06-26 11:40:59.749010
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Initializing instances of ArchiveOrgIE
    # Test with url
    ArchiveOrgIE(url='http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE(url='https://archive.org/details/Cops1922')
    ArchiveOrgIE(url='http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE(url='https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    # Test with id
    ArchiveOrgIE(id='XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE(id='Cops1922')

# Generated at 2022-06-26 11:41:05.732569
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .. import test_main
    # test ArchiveOrgIE with jwplayer playback

# Generated at 2022-06-26 11:41:07.151843
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE("archive.org")

# Generated at 2022-06-26 11:41:09.718796
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-26 11:41:10.851626
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE.main_function()


# Generated at 2022-06-26 11:41:12.566340
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:43:23.449418
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()
        assert True
    except:
        assert False


# Generated at 2022-06-26 11:43:25.188567
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    assert instance.IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:43:25.684562
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:27.494753
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:28.491231
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:30.540453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for url in ArchiveOrgIE._TESTS:
        print(url['url'])
        print(url['md5'])

# Generated at 2022-06-26 11:43:40.041746
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:48.404795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test empty id
    ie = ArchiveOrgIE()
    ie.IE_NAME = None
    with pytest.raises(ExtractorError) as err:
        assert ie.IE_NAME
    assert 'expected IE_NAME attribute' in str(err.value)

    # Test empty id
    ie = ArchiveOrgIE(None)
    with pytest.raises(TypeError) as err:
        assert ie._valid_url(None, 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert 'missing 1 required positional argument' in str(err.value)
    
    # Test empty url
    ie = ArchiveOrgIE('XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not ie._valid_url(None, None)

# Generated at 2022-06-26 11:43:52.520933
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    d = ArchiveOrgIE()
    assert d._VALID_URL == ArchiveOrgIE._VALID_URL
    assert d._TESTS == ArchiveOrgIE._TESTS
    assert d.name == 'archive.org'
    assert d.IE_NAME == 'archive.org'
    assert d.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:43:54.677621
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org', 'https://www.archive.org/details/example')
    assert ie.ie_name == 'archive.org'
    assert ie.video_id == 'example'