

# Generated at 2022-06-26 11:36:47.661038
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()
    url_0 = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    video_id_0 = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    return_value_0 = archive_org_i_e_0._real_extract(url_0)


# Generated at 2022-06-26 11:36:48.771299
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:50.680619
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:55.169106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Constructor of the class ArchiveOrgIE (Unsupported test)
    archive_org_i_e = ArchiveOrgIE()
    archive_org_i_e_0 = ArchiveOrgIE()
    assert archive_org_i_e == archive_org_i_e_0


# Generated at 2022-06-26 11:36:57.066306
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

if __name__ == '__main__':
    test_case_0()
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:36:58.513442
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_1 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:03.279360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:37:04.990621
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:37:06.072112
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-26 11:37:07.069191
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    

# Generated at 2022-06-26 11:37:14.902107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:16.489122
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert type(archiveorg.ArchiveOrgIE) == type(common.InfoExtractor)


# Generated at 2022-06-26 11:37:26.848912
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Description: tests the constructors of ArchiveOrgIE class
    """

    # Create one single object of class InfoExtractor inherited by ArchiveOrgIE class
    archiveOrgIE_obj = InfoExtractor()

    # Check if object of class InfoExtractor created successfully
    assert isinstance(archiveOrgIE_obj, InfoExtractor)

    # Check if class ArchiveOrgIE is inherited from class InfoExtractor
    assert issubclass(ArchiveOrgIE, InfoExtractor)

    # Call the constructor of class ArchiveOrgIE
    # This should be successful
    archiveOrgIE_obj = ArchiveOrgIE()

    # Check if object of class ArchiveOrgIE created successfully
    assert isinstance(archiveOrgIE_obj, ArchiveOrgIE)

# Generated at 2022-06-26 11:37:35.306560
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from youtube_dl.extractor import (
        YoutubeIE,
        BlipTVIE,
        BreakIE,
        CollegeHumorIE,
        CommonIE,
        OpenloadIE,
        SoundcloudIE,
        VimeoIE,
        YoukuIE
    )
    expected = [
        YoutubeIE,
        BlipTVIE,
        BreakIE,
        CollegeHumorIE,
        CommonIE,
        OpenloadIE,
        SoundcloudIE,
        VimeoIE,
        YoukuIE
    ]
    assert ArchiveOrgIE._get_ies() == expected

# Generated at 2022-06-26 11:37:44.710079
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from contextlib import contextmanager
    from types import MethodType
    from unittest import TestCase
    import sys

    class _fakeMethodType(object):
        def __init__(self, func, class_):
            self.__func = func
            self.__class = class_

        def __get__(self, obj, class_=None):
            if obj is None:
                return self.__class
            if self.__func.__name__ in ('test_ArchiveOrgIE',):
                return MethodType(self.__func, obj)
            return MethodType(self.__func, self.__class)

    class _fakeMethodDescriptor(_fakeMethodType):
        def __init__(self, func):
            self.__func = func


# Generated at 2022-06-26 11:37:48.600076
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'



# Generated at 2022-06-26 11:37:50.334452
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_object = ArchiveOrgIE('www')

# Generated at 2022-06-26 11:37:53.982330
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._login_token is None # login_token should be None before login
    ie.login()
    assert ie._login_token is not None # login_token should be not None after login

# Generated at 2022-06-26 11:37:54.446081
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:57.884290
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:20.508044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:30.471263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    input_url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_id = 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    expected_class = ArchiveOrgIE
    ie = ArchiveOrgIE('ArchiveOrg', input_url)
    assert ie._URL_PATTERN == input_url
    assert ie._VALID_URL == expected_url
    assert ie._match_id(input_url) == expected_id
    assert ie.__class__ == expected_class

# Generated at 2022-06-26 11:38:32.424356
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:38:32.928175
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:38.041930
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test if construction of ArchiveOrgIE instance tests
    for the presence of dependency
    """

    # Create an instance of ArchiveOrgIE
    ie = ArchiveOrgIE(None)
    # Call of _get_dependencies to test if dependency
    # 'json' is found
    ie._get_dependencies()

# Generated at 2022-06-26 11:38:42.474359
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor

    ao = ArchiveOrgIE() # Instantiate ArchiveOrgIE class
    assert ao.IE_NAME == 'archive.org'


extractor = test_ArchiveOrgIE()

# Generated at 2022-06-26 11:38:43.452263
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-26 11:38:45.355880
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	instance = ArchiveOrgIE();
	instance._real_initialize();

# Generated at 2022-06-26 11:38:45.832120
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-26 11:38:50.610593
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE();
    assert archive_org_ie.IE_NAME == 'archive.org';
    assert archive_org_ie.IE_DESC == 'archive.org videos';

# Generated at 2022-06-26 11:39:18.513410
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for url in (
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'https://archive.org/details/Cops1922',
            'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
        ):
        assert archiveorg_ie.suitable(url), url
        ie = archiveorg_ie(url)
        assert ie.url == url, url
        assert ie.video_id == archiveorg_ie._match_id(url), url

# Generated at 2022-06-26 11:39:21.520406
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:23.099621
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of ArchiveOrgIE class
    """
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:24.437514
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC

# Generated at 2022-06-26 11:39:28.381955
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # try to test instantiating object

    ie = ArchiveOrgIE()

if __name__ == "__main__":
    # run unit test
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:39:29.323343
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()


# Generated at 2022-06-26 11:39:36.077772
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_common import TestFailure
    ie = ArchiveOrgIE()

    # test for failure in ArchiveOrgIE.constructor
    if (ie is None):
        raise TestFailure("ArchiveOrgIE.__init__() returns null")
    if (ie.ie_key() != 'archive.org'):
        raise TestFailure("ArchiveOrgIE.ie_key() returns invalid key")
    if (ie.IE_NAME != 'archive.org'):
        raise TestFailure("ArchiveOrgIE.IE_NAME returns invalid value")
    if (ie.IE_DESC != 'archive.org videos'):
        raise TestFailure("ArchiveOrgIE.IE_DESC returns invalid value")

# Generated at 2022-06-26 11:39:39.785748
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:39:43.119211
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE()._real_extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-26 11:39:47.656465
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Smoke test
    ie.extract('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie.extract('https://archive.org/details/Cops1922')

# Generated at 2022-06-26 11:40:42.841045
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')


# Generated at 2022-06-26 11:40:46.989155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ins = ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert str(ins) == '<ArchiveOrgIE 8af1d4cf447933ed3c7f4871162602db>'

# Generated at 2022-06-26 11:40:48.680155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test if the first argument of the constructor contains
    # the initials of the parent class
    assert ArchiveOrgIE._initials == 'archiveorg'

# Generated at 2022-06-26 11:40:53.681322
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:01.484579
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:41:03.472731
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE('archive.org')).IE_NAME == 'archive.org'
    assert(ArchiveOrgIE('archive.org')).IE_DESC == 'archive.org videos'
    assert(ArchiveOrgIE('archive.org'))._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:07.981640
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    #export_js_test(ArchiveOrgIE, 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ArchiveOrgIE._build_url_result(ArchiveOrgIE._VALID_URL, ArchiveOrgIE._TESTS[0]['url'])

# Generated at 2022-06-26 11:41:11.239490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:41:12.048003
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:12.847191
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    unittest.main()

# Generated at 2022-06-26 11:43:29.078390
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == "archive.org"
    assert ie.ie_key() == "archive.org"

# Generated at 2022-06-26 11:43:29.894360
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:31.068843
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE._download_json(None, None, None)

# Generated at 2022-06-26 11:43:40.545900
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:47.132337
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():

    # Test variable initialization
    archive_org = ArchiveOrgIE()

    assert archive_org._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert archive_org._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert archive_org._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:43:48.974638
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj_test = ArchiveOrgIE()
    obj_test.test_archiveorg_ie()

# Generated at 2022-06-26 11:43:54.712369
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    for input_url in ['http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                      'https://archive.org/details/Cops1922',
                      'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
                      'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/']:
        assert ArchiveOrgIE().suitable(input_url) == True

# Generated at 2022-06-26 11:43:55.770528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:44:00.087947
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive = ArchiveOrgIE()
    archive.suitable(url)
    archive.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:44:04.303929
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'