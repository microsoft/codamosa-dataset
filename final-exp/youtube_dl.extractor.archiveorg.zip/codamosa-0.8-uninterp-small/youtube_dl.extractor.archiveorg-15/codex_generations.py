

# Generated at 2022-06-26 11:36:49.226400
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from ..utils import (
        clean_html,
        extract_attributes,
        unified_strdate,
        unified_timestamp,
    )
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.IE_NAME == 'archive.org', 'wrong IE_NAME'
    assert archive_org_i_e.IE_DESC == 'archive.org videos', 'wrong IE_DESC'
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:36:50.718779
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'


# Generated at 2022-06-26 11:37:02.401256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE().IE_NAME
    assert 'archive.org videos' == ArchiveOrgIE().IE_DESC
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert len(ArchiveOrgIE()._TESTS) == 4
    assert dict == type(ArchiveOrgIE()._TESTS[0])
    assert 'url' in ArchiveOrgIE()._TESTS[0]
    assert 'md5' in ArchiveOrgIE()._TESTS[0]
    assert 'info_dict' in ArchiveOrgIE()._TESTS[0]
    assert dict == type(ArchiveOrgIE()._TESTS[0]['info_dict'])
   

# Generated at 2022-06-26 11:37:03.675813
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_case_0()

# Generated at 2022-06-26 11:37:04.627728
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-26 11:37:05.314613
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-26 11:37:06.376403
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:08.848345
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    return archive_org_i_e


# Generated at 2022-06-26 11:37:11.766843
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # check attributes of instance
    assert ArchiveOrgIE._VALID_URL
    assert ArchiveOrgIE._TESTS
    assert ArchiveOrgIE.IE_NAME
    assert ArchiveOrgIE.IE_DESC


# Generated at 2022-06-26 11:37:20.035727
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    u_r_l = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    r_e = r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    m_d_5 = '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:37:36.440834
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:38.867066
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-26 11:37:39.858148
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-26 11:37:43.293761
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .constructor_test import ConstructorTest

    _ = ConstructorTest(ArchiveOrgIE, [{
        'url': 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
    }])

# Generated at 2022-06-26 11:37:50.329743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''Unit test for constructor of class ArchiveOrgIE'''
    # This is not a valid URL for ArchiveOrgIE
    url = "http://archive.org"
    assert ArchiveOrgIE._VALID_URL in url
    assert ArchiveOrgIE._TESTS.__len__() > 0
    assert ArchiveOrgIE._TESTS[0].__len__() == 3

# Generated at 2022-06-26 11:38:00.950352
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_url2 = 'https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    test_url3 = 'http://archive.org/details/test/'
    assert ie.suitable(test_url)
    assert ie.suitable(test_url2)
    assert ie.suitable(test_url3)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:02.904653
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:38:04.128455
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:06.676744
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/"
    ie = ArchiveOrgIE(url)
    assert ie.url == url
    assert ie.valid_url(url)

# Generated at 2022-06-26 11:38:13.940048
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test including a constructor unit test for each subclass
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:30.056814
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:30.655902
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:37.025507
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_inst = ArchiveOrgIE()
    assert(isinstance(test_inst, InfoExtractor))
    test_tuple = test_inst.IE_NAME, test_inst.IE_DESC
    actual_tuple = "archive.org", "archive.org videos"
    assert(test_tuple == actual_tuple)
    assert(test_inst.IE_DESC == actual_tuple[1])


# Generated at 2022-06-26 11:38:39.474702
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(None).IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:44.100782
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    extractor = ArchiveOrgIE()
    url_data = extractor._match_id('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert url_data == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'


# Generated at 2022-06-26 11:38:57.098480
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE.__init__()"""
    ArchiveOrgIE.__init__()
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._html_get_attribute('id') == '<^>id="(.+?)">'
    assert ArchiveOrgIE._html_get_attribute('id', None, '<^>id="(.+?)"') == '<^>id="(.+?)">'
    assert ArchiveOrgIE._html_search_regex('<^>id="(.+?)">', '<^>id="(.+?)">') == '<^>id="(.+?)">'
    assert ArchiveOrgIE._html_search_re

# Generated at 2022-06-26 11:39:01.394528
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    def _assert_IE_pass(InfoExtractor, url):
        extractor = InfoExtractor()
        # This IE cannot handle URL without host and path
        url_type, _, _, _, _ = url_handle_gv(url)
        assert url_type != 'video'
        video_url_type = url_type + ':video'
        video_id = extractor._match_id(url)
        assert info_dict == extractor.suitable(
            url, video_url_type, video_id) and info_dict == extractor.extract(url)

    _assert_IE_pass(ArchiveOrgIE, 'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    print('ArchiveOrgIE constructor test has passed!')

# Generated at 2022-06-26 11:39:03.300012
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE._VALID_URL.startswith('https://')

# Generated at 2022-06-26 11:39:06.779323
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:09.194343
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Check that ArchiveOrgIE implementation is not broken
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org' # just for linter and for myself

# Generated at 2022-06-26 11:39:38.252055
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME == 'archive.org'
    ie.IE_DESC == 'archive.org videos'
    ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:40.867313
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Test for static method ArchiveOrgIE._build_regex
    assert ie._build_regex(ie.IE_NAME) == ie._VALID_URL

# Generated at 2022-06-26 11:39:41.930810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_obj = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:47.854651
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    mgstudio_ie = ArchiveOrgIE()
    assert mgstudio_ie.IE_NAME == 'archive.org'
    assert mgstudio_ie.IE_DESC == 'archive.org videos'
    assert mgstudio_ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'



# Generated at 2022-06-26 11:39:57.724241
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('url')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:58.696229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:40:10.180980
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  ie = ArchiveOrgIE()
  assert isinstance(ie, InfoExtractor)
  assert ie.ie_name == "archive.org"
  assert ie.ie_desc == "archive.org videos"
  assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:13.309988
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE('ArchiveOrgIE')
    assert info_extractor.IE_NAME == 'archive.org'
    assert info_extractor.IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:40:15.685727
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Pylint complains about missing class attributes
    # pylint: disable=E1101
    ArchiveOrgIE('ArchiveOrgIE', 'archive.org')
    # pylint: enable=E1101

# Generated at 2022-06-26 11:40:17.490308
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:41:09.980950
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:41:11.086336
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-26 11:41:11.932574
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:14.777969
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # This should not raise an exception
    ie._real_extract(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:41:16.661405
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')

# Generated at 2022-06-26 11:41:22.067729
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    instance = ArchiveOrgIE()
    instance.url_result('http://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    instance.url_result('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    instance.url_result('https://archive.org/details/Cops1922')
    instance.url_result('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:41:29.452633
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:41:31.222291
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:40.577993
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    archiveOrgIE.IE_NAME = 'archive.org'
    archiveOrgIE.IE_DESC = 'archive.org videos'
    archiveOrgIE.IE_METADATA = {
        'creator': 'SRI International',
        'id': 'XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        'ext': 'ogg',
        'title': '1968 Demo - FJCC Conference Presentation Reel #1',
        'description': 'md5:da45c349df039f1cc8075268eb1b5c25',
        'release_date': '19681210',
        'uploader': 'SRI International',
        'timestamp': 1268695290,
        'upload_date': '20100315',
    }

# Generated at 2022-06-26 11:41:44.822687
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        # pylint: disable=unused-variable
        ie = class_constructor(ArchiveOrgIE.__module__, ArchiveOrgIE.__name__)()
    except TypeError as e:
        if 'unexpected keyword argument' in str(e):
            # The unittest framework passes 'request' argument to
            # the constructor of the tested class. We don't pass
            # this argument to constructor, hence the TypeError.
            pass
        else:
            raise

# Generated at 2022-06-26 11:43:50.711629
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:51.777831
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(InfoExtractor(None)).IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:44:01.806712
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()
    assert( ao.IE_DESC == 'archive.org videos' )
    assert( ao.IE_NAME == 'archive.org' )
    assert( ao._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)' )
    assert( ao._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect' )
    assert( ao._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db' )

# Generated at 2022-06-26 11:44:09.213688
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:44:12.319091
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("input", "output")
    print("Unit test for class ArchiveOrgIE")
    print("Successfully created instance of class ArchiveOrgIE")

# Generated at 2022-06-26 11:44:16.615505
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie_test = ArchiveOrgIE()
    assert ie_test.IE_NAME == 'archive.org'
    assert ie_test.IE_DESC == 'archive.org videos'
    assert ie_test._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:44:25.103810
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS
    ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ie._real_extract('http://archive.org/details/Cops1922')
    ie._real_extract('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')


# Generated at 2022-06-26 11:44:34.562992
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
        '67f6a15a7db9a54cfe1c0f1bfea1596d',
        '8af1d4cf447933ed3c7f4871162602db')._real_extract(
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:44:36.501827
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE("http://archive.org/video/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert i.__class__ == ArchiveOrgIE


# Generated at 2022-06-26 11:44:37.660886
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert str(ie) == 'archive.org videos'
