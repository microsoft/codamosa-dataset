

# Generated at 2022-06-26 11:36:44.488915
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:52.102570
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:36:53.986411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert archive_org_i_e_0 != null

# Generated at 2022-06-26 11:36:56.754818
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    if archive_org_i_e:
        test_case_0()
    else :
        assert False


# Generated at 2022-06-26 11:36:59.460768
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
#
# def test_suite():
#     return unittest.TestSuite([
#
#     ])

# Generated at 2022-06-26 11:37:01.243034
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_1 = ArchiveOrgIE()

# Generated at 2022-06-26 11:37:02.894401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_test_1 = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:07.731967
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Note: the following code is not usable at this moment
    #       because this method is class method
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:37:09.491278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass


# Generated at 2022-06-26 11:37:10.527069
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE


# Generated at 2022-06-26 11:37:20.805273
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    ArchiveOrgIE('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:37:22.608459
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('archive.org', {'username': 'example', 'password': 'FooBar'})

# Generated at 2022-06-26 11:37:33.027658
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie._real_extract == ie.real_extract
    assert ie._match_id == ie.match_id
    assert ie._search_regex == ie.search_regex
    assert ie._parse_json == ie.parse_json
    assert ie._parse_jwplayer_data == ie.parse_jwplayer_data
    assert ie._parse_html5_media_entries == ie.parse_html5_media_entries
    assert ie._download_webpage == ie.download_webpage
    assert ie._download_json == ie.download_json

# Generated at 2022-06-26 11:37:36.006127
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('archive.org')
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'

# Generated at 2022-06-26 11:37:37.404279
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    p = ArchiveOrgIE()
    assert p.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:37:45.938776
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE.__init__()."""
    from . import ArchiveOrgIE
    from . import InfoExtractor
    from .common import InfoExtractor
    
    ArchiveOrgIE_inst = ArchiveOrgIE()
    InfoExtractor_inst = InfoExtractor()
    ArchiveOrgIE_type = type(ArchiveOrgIE)
    InfoExtractor_type = type(InfoExtractor)
    assert isinstance(ArchiveOrgIE_inst, ArchiveOrgIE)
    assert isinstance(ArchiveOrgIE_inst, InfoExtractor)
    assert isinstance(ArchiveOrgIE_inst, object)
    assert isinstance(ArchiveOrgIE, ArchiveOrgIE_type)
    assert isinstance(ArchiveOrgIE, InfoExtractor_type)
    assert isinstance(ArchiveOrgIE, object)

# Generated at 2022-06-26 11:37:47.048253
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE

# Generated at 2022-06-26 11:37:48.825771
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-26 11:38:00.220620
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import re
    from .common import InfoExtractor
    from ..compat import compat_urllib_parse_urlparse, compat_urllib_parse_unquote

    # Basic test for constructor of ArchiveOrgIE
    org = ArchiveOrgIE()

    # Basic test for extract()
    ex = org.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ex['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ex['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert ex['ext'] == 'ogg'
    assert ex['creator'] == 'SRI International'
    assert ex['release_date'] == '19681210'

# Generated at 2022-06-26 11:38:00.798651
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:38:12.500019
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    e = ArchiveOrgIE()
    assert_equal(e.IE_NAME, ArchiveOrgIE.IE_NAME)
    assert_equal(e.IE_DESC, ArchiveOrgIE.IE_DESC)

# Generated at 2022-06-26 11:38:13.076711
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:14.134106
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE())

# Generated at 2022-06-26 11:38:23.401035
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys

    try:
        IEClass = globals()[sys.argv[1]]
    except IndexError:
        print('usage: run.py %s <class name>' % __name__)
        sys.exit(3)

    if 'ArchiveOrgIE' not in IEClass.__name__:
        print('%s not an instance of ArchiveOrgIE' % IEClass.__name__)
        sys.exit(3)

    if '_VALID_URL' not in IEClass.__dict__:
        print('_VALID_URL not defined in %s' % IEClass.__name__)
        sys.exit(3)

    if '_TESTS' not in IEClass.__dict__:
        print('_TESTS not defined in %s' % IEClass.__name__)
        sys

# Generated at 2022-06-26 11:38:34.205874
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    aorg_instance = ArchiveOrgIE()

    assert aorg_instance._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:40.452545
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie.IE_NAME == 'archive.org')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')
    assert(ie._TESTS)

# Generated at 2022-06-26 11:38:41.463910
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ao = ArchiveOrgIE()

# Generated at 2022-06-26 11:38:46.001418
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    check_py3 = True

    # Check for python 3
    if check_py3:
        assert issubclass(ArchiveOrgIE, InfoExtractor)
        assert ArchiveOrgIE.__name__ == "ArchiveOrgIE"
        assert ArchiveOrgIE.IE_NAME == "archive.org"
        assert ArchiveOrgIE.IE_DESC == "archive.org videos"

# Generated at 2022-06-26 11:38:50.014010
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS

# Generated at 2022-06-26 11:38:59.577201
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        (
            'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect',
            ('XD300-23_68HighlightsAResearchCntAugHumanIntellect', '8af1d4cf447933ed3c7f4871162602db')
        ),
    ]

    for test_case in test_cases:
        response = ArchiveOrgIE()._real_extract(test_case[0])
        assert response['id'] == test_case[1][0]
        assert response['md5'] == test_case[1][1]

# Generated at 2022-06-26 11:39:23.401716
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    # Unit test for constructor of class ArchiveOrgIE
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:39:33.876606
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:34.961515
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:39:36.801329
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: The test of ArchiveOrgIE should be implemented
    pass

# Generated at 2022-06-26 11:39:47.336399
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Unit test for ArchiveOrgIE constructor."""
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:39:50.165621
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == 'archive.org'
    assert ArchiveOrgIE().IE_DESC == 'archive.org videos'

# Generated at 2022-06-26 11:39:54.936759
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
	assert ArchiveOrgIE().IE_NAME == 'archive.org'
	assert ArchiveOrgIE().IE_DESC == 'archive.org videos'
	assert ArchiveOrgIE()._TESTS != None

# Generated at 2022-06-26 11:39:56.396256
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-26 11:40:07.264884
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    # test that we can create an instance of class ArchiveOrgIE
    i = ArchiveOrgIE('archive.org', 'archive.org videos')
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:11.154510
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE
    vie = InfoExtractor(True, ArchiveOrgIE.IE_NAME, ArchiveOrgIE.IE_DESC)
    assert isinstance(vie, InfoExtractor)

# Generated at 2022-06-26 11:41:07.268656
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'


# Generated at 2022-06-26 11:41:08.283197
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:41:16.199385
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:41:23.355207
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-26 11:41:24.645954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test ArchiveOrgIE constructor"""
    youtube_ie = ArchiveOrgIE()
    assert youtube_ie.ie_key() == 'archive.org'

# Generated at 2022-06-26 11:41:28.469167
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:41:30.573107
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # An url should have IE_NAME
    url = 'http://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/'
    assert ie._get_IE_name(url) == ie.IE_NAME

    # An url should have IE_DESC
    assert ie.IE_DESC in ie.description

# Generated at 2022-06-26 11:41:31.090230
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:34.567155
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Test for instantiation of class ArchiveOrgIE"""
    import ytdl.extractor.archiveorg
    assert ytdl.extractor.archiveorg.ie_info is not None


# Generated at 2022-06-26 11:41:37.193293
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == ie.VALID_URL
    assert ie._TESTS == ie.TESTS
    assert ie.IE_NAME == ie.ie_key()

# Generated at 2022-06-26 11:43:47.283248
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    p = ArchiveOrgIE()
    assert p.suitable('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not p.suitable('http://www.archive.org')
    assert not p.suitable('http://youtube.com')

# Generated at 2022-06-26 11:43:48.784832
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE('', '')

# Generated at 2022-06-26 11:43:51.900196
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Check if the constructor of ArchiveOrgIE works
    """
    ie = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:53.326044
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)

# Generated at 2022-06-26 11:43:59.862618
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Test ArchiveOrgIE constructor
    """
    ie = ArchiveOrgIE("https://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    assert(ie.IE_NAME == 'archive.org')
    assert(ie.IE_DESC == 'archive.org videos')
    assert(ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)')


# Generated at 2022-06-26 11:44:01.468932
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()

# Generated at 2022-06-26 11:44:08.930682
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_cases = [
        "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
        "https://archive.org/details/Cops1922",
        "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/",
        "https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator",
        "http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect",
    ]
    for test_case in test_cases:
        ie = ArchiveOrgIE(downloader=None)
        assert ie.suitable(test_case)
        assert ie.IE_NAME in test_case

# Generated at 2022-06-26 11:44:18.317762
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    ArchiveOrgIE constructor should support custom url for detail and embed url
    """
    archieOrg = ArchiveOrgIE(None)
    archieOrg._VALID_URL = r'https?://(?:www\.)?archive\.org/.*(?:details|embed)/(?P<id>[^/?#&]+)'
    archieOrg._real_initialize()
    assert archieOrg._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    archieOrg = ArchiveOrgIE(None)
    archieOrg._real_initialize()

# Generated at 2022-06-26 11:44:20.880723
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:44:22.362341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    result = "Unit test for constructor of class ArchiveOrgIE"
    print(result)
