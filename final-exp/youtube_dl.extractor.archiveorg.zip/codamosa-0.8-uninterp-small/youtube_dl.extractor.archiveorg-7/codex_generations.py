

# Generated at 2022-06-26 11:36:42.222911
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()



# Generated at 2022-06-26 11:36:43.334718
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO Test ArchiveOrgIE prepends scheme to ID
    pass


# Generated at 2022-06-26 11:36:44.765970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e_0 = ArchiveOrgIE()


# Generated at 2022-06-26 11:36:48.006453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == "archive.org"
    assert ArchiveOrgIE().IE_DESC == "archive.org videos"

if __name__ == "__main__":
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:36:52.188344
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    assert archive_org_i_e.IE_NAME == 'archive.org'
    assert archive_org_i_e.IE_DESC == 'archive.org videos'
    assert archive_org_i_e._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

if __name__ == '__main__':
    test_case_0()
    test_ArchiveOrgIE()

# Generated at 2022-06-26 11:37:03.773985
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:06.024109
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()
    archive_org_i_e_0 = ArchiveOrgIE()
    assert True


# Generated at 2022-06-26 11:37:07.449714
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archive_org_i_e = ArchiveOrgIE()


# Generated at 2022-06-26 11:37:16.941994
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    archive_org_i_e = ArchiveOrgIE()
    archive_org_i_e_info = archive_org_i_e._real_extract(url)
    assert archive_org_i_e_info['creator'] == 'SRI International'
    assert archive_org_i_e_info['release_date'] == '19681210'
    assert archive_org_i_e_info['uploader'] == 'SRI International'
    assert archive_org_i_e_info['timestamp'] == 1268695290
    assert archive_org_i_e_info['upload_date'] == '20100315'

# Generated at 2022-06-26 11:37:17.442780
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    pass

# Generated at 2022-06-26 11:37:28.372704
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

test_ArchiveOrgIE()

# Generated at 2022-06-26 11:37:30.389879
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE(ArchiveOrgIE.IE_NAME, ArchiveOrgIE.IE_DESC)

# Generated at 2022-06-26 11:37:33.797041
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:43.718846
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:56.339426
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:37:58.898424
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    class_name = "ArchiveOrgIE"
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()
    ie = ArchiveOrgIE()


# Generated at 2022-06-26 11:38:01.677683
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	archiveorg = ArchiveOrgIE()
	expected = "archive.org videos"
	result = archiveorg.ie_desc
	assert expected == result

# Unit tests for report_lang

# Generated at 2022-06-26 11:38:02.903970
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Simple unit test for ArchiveOrgIE
    """
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:04.873411
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    # Initializer of object for test must be a valid URL using default set
    # of arguments
    ArchiveOrgIE(InfoExtractor._WORKING_URL)

# Generated at 2022-06-26 11:38:17.141479
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE(None)
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.ie_name == 'archive.org'
    assert ie.valid_url('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.valid_url('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.valid_url('https://archive.org/details/Cops1922')
    assert ie.valid_url('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') is False

# Generated at 2022-06-26 11:38:29.991178
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import datetime
    from .common import InfoExtractor

    ie = ArchiveOrgIE('archive.org')


# Generated at 2022-06-26 11:38:32.679104
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:38:35.940782
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie.ie_key() == 'archive.org')
    assert(ie.ie_desc() == 'archive.org videos')

# Generated at 2022-06-26 11:38:37.994952
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        ArchiveOrgIE(InfoExtractor())
    except:
        assert False
    assert True

# Generated at 2022-06-26 11:38:39.527356
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:40.125795
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:38:43.281640
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-26 11:38:47.966943
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == "archive.org"
    assert ArchiveOrgIE().IE_DESC == "archive.org videos"
    assert ArchiveOrgIE()._VALID_URL == r"https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)"

# Generated at 2022-06-26 11:39:00.848401
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """Create class ArchiveOrgIE and check attributes"""
    url = "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'
    assert obj._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert obj._TESTS
    assert obj._TESTS[0]['url'] == "http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect"

# Generated at 2022-06-26 11:39:02.211923
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:24.943787
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    if 'archive.org' in globals():
        # Constructor of ArchiveOrgIE
        print(ArchiveOrgIE)

# Generated at 2022-06-26 11:39:27.700408
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # testing will fail if ArchiveOrgIE() is called without argument
    ie = ArchiveOrgIE()
    assert ie!=None

# Generated at 2022-06-26 11:39:28.651922
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie != None

# Generated at 2022-06-26 11:39:29.240857
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:39:30.437678
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Testing correct constructor
    assert ArchiveOrgIE() != None

# Generated at 2022-06-26 11:39:31.810947
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Just create an object of class ArchiveOrgIE
    ArchiveOrgIE()


# Generated at 2022-06-26 11:39:33.325015
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)

# Generated at 2022-06-26 11:39:37.093320
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    _instance = ArchiveOrgIE()
    assert _instance is not None
    assert _instance.IE_NAME is not None
    assert _instance.IE_DESC is not None
    assert _instance._VALID_URL is not None
    assert _instance._TESTS is not None

test = test_ArchiveOrgIE

# Generated at 2022-06-26 11:39:38.165276
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    infoExtractor = ArchiveOrgIE()

# Generated at 2022-06-26 11:39:40.753229
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-26 11:40:34.761382
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    try:
        import jinja2
    except ImportError:
        pytest.skip('requires jinja2 support')

    # Test template rendering
    template = jinja2.Environment().from_string(
        '{{ x }} {{ y }} {{ z }}{% if w %} {{ w }}{% endif %}')
    assert '1 2 3' == template.render(x=1, y=2, z=3)
    assert '1 2 3 4' == template.render(x=1, y=2, z=3, w=4)

    # Test function definition and function call from within template
    template = jinja2.Environment().from_string(
        '{{ define_func() }}{{ func() }}')
    def define_func():
        def func():
            return 'x'
    assert 'x'

# Generated at 2022-06-26 11:40:35.575961
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() != None

# Generated at 2022-06-26 11:40:39.499273
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test ArchiveOrgIE before using it in the code below.
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:40:40.654441
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == "archive.org"

# Generated at 2022-06-26 11:40:51.735880
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_playlist import playlist_result
    from .test_dummycc import DummyCCIE
    from .test_generic_extractor import GenericIE

    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    playlist_md5 = '366b91817ee5f27e5d2d5f5ce5f5e5ca'
    ie = ArchiveOrgIE()
    ie.add_ie(DummyCCIE.ie_key(), DummyCCIE)
    info = ie._real_extract(url)
    assert info['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert info['title'] == '1968 Demo - FJCC Conference Presentation Reel #1'
   

# Generated at 2022-06-26 11:40:57.617867
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    ArchiveOrgIE()
    """
    import unittest
    from .common import InfoExtractor
    from .archiveorg import ArchiveOrgIE

    class TestArchiveOrgIE(InfoExtractor):
        IE_NAME = ArchiveOrgIE.IE_NAME
        IE_DESC = ArchiveOrgIE.IE_DESC

    archiveOrgIE = TestArchiveOrgIE()
    assert archiveOrgIE.ie_key() == 'archive.org'
    assert archiveOrgIE.ie_name() == 'archive.org'
    assert archiveOrgIE.ie_desc() == 'archive.org videos'

# Generated at 2022-06-26 11:40:58.134525
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-26 11:41:03.061095
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    info = ie._real_extract('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # These are just a few that happen to be defined
    assert 'id' in info
    assert 'title' in info
    assert 'description' in info
    assert 'creator' in info
    assert 'release_date' in info
    assert 'uploader' in info
    assert 'timestamp' in info
    assert 'upload_date' in info

# Generated at 2022-06-26 11:41:07.607243
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # TODO: remove unit test for ArchiveOrgIE(InfoExtractor) after
    # https://github.com/rg3/youtube-dl/pull/12778 is merged
    assert (ArchiveOrgIE.__bases__ == (InfoExtractor,))

# Generated at 2022-06-26 11:41:08.686017
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie




# Generated at 2022-06-26 11:43:13.613831
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test that the 'archive.org videos' information extractor is
    # created correctly.

    assert isinstance(ie.get_info_extractor('archive.org'), ArchiveOrgIE)

# Generated at 2022-06-26 11:43:15.998890
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-26 11:43:17.897442
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE(None) != None)

# Generated at 2022-06-26 11:43:22.307173
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .test_dash import TestDash
    from .test_theplatform import TestThePlatform
    from .test_youtube import TestYoutube
    from .test_udemy import TestUdemy
    TestArchiveOrgIE = type('TestArchiveOrgIE',
                            (TestDash, TestThePlatform, TestYoutube, TestUdemy),
                            {'IE': ArchiveOrgIE})
    TestArchiveOrgIE('test_ArchiveOrgIE')

# Generated at 2022-06-26 11:43:23.027948
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i is not None

# Generated at 2022-06-26 11:43:24.096453
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    '''
    Test ArchiveOrgIE constructor
    '''
    ArchiveOrgIE()

# Generated at 2022-06-26 11:43:35.320046
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ArchiveOrgIE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ArchiveOrgIE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-26 11:43:40.073822
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    c = ArchiveOrgIE()
    c._real_extract('http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    # Test it does not crash for a video with a large number of files
    # https://github.com/rg3/youtube-dl/issues/13240
    c._real_extract('https://archive.org/details/BQC-1_DVD')

# Generated at 2022-06-26 11:43:43.413788
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()

# Generated at 2022-06-26 11:43:50.586804
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.IE_NAME == 'archive.org'
    assert ArchiveOrgIE.IE_DESC == 'archive.org videos'
    assert ArchiveOrgIE._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'