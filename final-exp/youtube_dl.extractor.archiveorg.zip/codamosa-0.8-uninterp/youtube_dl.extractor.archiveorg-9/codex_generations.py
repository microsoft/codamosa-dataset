

# Generated at 2022-06-14 16:03:01.086739
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.ie_key() == 'archive.org'
    assert i.ie_name() == 'archive.org'

# Generated at 2022-06-14 16:03:03.229692
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'ArchiveOrgIE' in globals()

# Generated at 2022-06-14 16:03:05.350294
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
  try:
    ArchiveOrgIE('archive.org')
    assert(True)
  except:
    assert(False)

# Generated at 2022-06-14 16:03:06.421877
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    return a

# Generated at 2022-06-14 16:03:07.248686
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie

# Generated at 2022-06-14 16:03:08.080954
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE();

# Generated at 2022-06-14 16:03:11.968254
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-14 16:03:13.229015
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIEClass()


ArchiveOrgIEClass = ArchiveOrgIE

# Generated at 2022-06-14 16:03:14.324663
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
	example = ArchiveOrgIE()

# Generated at 2022-06-14 16:03:15.812041
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._TESTS.__len__() > 0

# Generated at 2022-06-14 16:03:21.526197
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-14 16:03:23.878835
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Tests for a new object creation and attributes accessor.
    a = ArchiveOrgIE()
    assert a.IE_NAME == 'archive.org'

# Generated at 2022-06-14 16:03:25.322720
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._real_initialize()


# Generated at 2022-06-14 16:03:32.657742
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    a = ArchiveOrgIE()
    assert a._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-14 16:03:35.321471
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert test_ArchiveOrgIE.count == 0
    test_ArchiveOrgIE.count +=1
    assert test_ArchiveOrgIE.count == 1
    return

# Generated at 2022-06-14 16:03:40.020396
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert(ie._VALID_URL == ArchiveOrgIE._VALID_URL)
    assert(ie._TESTS == ArchiveOrgIE._TESTS)

# Generated at 2022-06-14 16:03:45.141209
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    g = ArchiveOrgIE()
    assert g.IE_NAME == "archive.org"
    assert g.IE_DESC == "archive.org videos"
    assert g._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-14 16:03:50.569349
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-14 16:04:01.221010
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    i = ArchiveOrgIE()
    assert i.IE_NAME == 'archive.org'
    assert i.IE_DESC == 'archive.org videos'
    assert i._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-14 16:04:02.167203
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-14 16:04:13.829428
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-14 16:04:16.211160
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.__class__.__name__ == 'ArchiveOrgIE'

# Generated at 2022-06-14 16:04:18.022341
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    x = ArchiveOrgIE()
    assert x.ie_key() == 'archive.org'

# Generated at 2022-06-14 16:04:19.511973
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE().IE_NAME == ArchiveOrgIE.IE_NAME



# Generated at 2022-06-14 16:04:21.124166
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'IE_NAME'

# Generated at 2022-06-14 16:04:23.326264
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test that constructor doesn't crash with any of the arguments
    ArchiveOrgIE(url='', downloader=None, params=None)

# Generated at 2022-06-14 16:04:34.676743
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE({})
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-14 16:04:45.580407
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    IE = ArchiveOrgIE()
    assert IE.IE_NAME == 'archive.org'
    assert IE.IE_DESC == 'archive.org videos'
    assert IE._VALID_URL == 'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert isinstance(IE._TESTS, list)
    assert isinstance(IE._TESTS[0], dict)
    assert IE._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert IE._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-14 16:04:46.152227
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-14 16:04:55.428490
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    import sys

    # Test constructor - Test empty instance
    archive_org = ArchiveOrgIE()
    assert(archive_org._downloader is not None)
    assert(archive_org._WORKING_DIR is not None)

    # Test constructor - Test instance with downloader instance
    # (should be stored in _downloader)
    archive_org = ArchiveOrgIE(downloader=True)
    assert(archive_org._downloader is True)

    # Test constructor - Test instance with downloader instance
    # that is set to None
    archive_org = ArchiveOrgIE(downloader=None)
    assert(archive_org._downloader is None)

    # Test constructor - Test instance with _WORKING_DIR instance
    # (should be stored in _WORKING_DIR)
    archive_org = ArchiveOrgIE(working_dir=True)
   

# Generated at 2022-06-14 16:05:18.202279
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'

# Generated at 2022-06-14 16:05:21.865223
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .common import InfoExtractor
    ie = InfoExtractor()
    ie.add_info_extractor(ArchiveOrgIE)
    ie.extract("https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")

# Generated at 2022-06-14 16:05:23.830101
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie._VALID_URL = ArchiveOrgIE._VALID_URL

# Generated at 2022-06-14 16:05:34.919458
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

    # Define the input and expected output values for constructor

# Generated at 2022-06-14 16:05:35.496377
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-14 16:05:39.040809
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    t = type('Test', (object,), {
        'IE_NAME': 'archive.org',
        '_VALID_URL': 'http://archive.org/details/test_test'
    })
    t.__bases__ = (ArchiveOrgIE,)
    return t(t.IE_NAME)

# Generated at 2022-06-14 16:05:40.215996
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert str(ArchiveOrgIE()) == 'archive.org'


# Generated at 2022-06-14 16:05:42.767835
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    global ArchiveOrgIE
    aoe = ArchiveOrgIE()
    assert aoe.IE_NAME == "archive.org"

# Generated at 2022-06-14 16:05:47.022963
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    ie.get_url_info('https://archive.org/details/this_is_an_archive_org_url')
    ie.get_url_info('https://archive.org/embed/this_is_an_archive_org_url')

# Generated at 2022-06-14 16:05:49.832112
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    obj = ArchiveOrgIE()
    assert obj.IE_NAME == 'archive.org'
    assert obj.IE_DESC == 'archive.org videos'

# Generated at 2022-06-14 16:06:42.898475
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE.suitable('https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True
    assert ArchiveOrgIE.suitable('https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/') == True
    assert ArchiveOrgIE.suitable('https://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect') == True

# Generated at 2022-06-14 16:06:54.027608
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert ie._TESTS[0]['md5'] == '8af1d4cf447933ed3c7f4871162602db'

# Generated at 2022-06-14 16:06:54.967534
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE(InfoExtractor)

# Generated at 2022-06-14 16:07:03.526314
# Unit test for constructor of class ArchiveOrgIE

# Generated at 2022-06-14 16:07:04.664718
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-14 16:07:06.508857
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    info_extractor = ArchiveOrgIE()
    assert info_extractor.IE_NAME == 'archive.org'

# Generated at 2022-06-14 16:07:12.702278
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_func = ArchiveOrgIE(None)._real_extract
    assert test_func(
        'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')\
        ['id'] == 'XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    assert test_func(
        'http://archive.org/details/Cops1922')\
        ['id'] == 'Cops1922'

# Generated at 2022-06-14 16:07:16.445735
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'


# Generated at 2022-06-14 16:07:17.193964
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()

# Generated at 2022-06-14 16:07:18.243588
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ArchiveOrgIE()

# Generated at 2022-06-14 16:09:20.778382
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Construct an ArchiveOrgIE object
    ie = ArchiveOrgIE()
    # Construct an ArchiveOrgIE object again
    ie = ArchiveOrgIE()

# Generated at 2022-06-14 16:09:21.834641
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE() is not None

# Generated at 2022-06-14 16:09:31.555219
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # Test for a URL that leads to a video.
    test_url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    ie = ArchiveOrgIE('')
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    assert ie.__name__ == 'ArchiveOrgIE'
    assert ie._downloader is None
    assert ie._match_id('garbage') is None

# Generated at 2022-06-14 16:09:35.439099
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    url = 'http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect'
    inst = ArchiveOrgIE()
    inst.url = url
    inst.match(url)

# Generated at 2022-06-14 16:09:41.410457
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE("http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect")
    print("ie.__class__ == ", ie.__class__)
    print("ie._VALID_URL == ", ie._VALID_URL)
    print("ie.IE_NAME == ", ie.IE_NAME)
    print("ie.IE_DESC == ", ie.IE_DESC)

# Generated at 2022-06-14 16:09:42.575873
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert(ArchiveOrgIE != None)


# Generated at 2022-06-14 16:09:44.894672
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    test_ArchiveOrgIE.archive_org_ie = None
    test_ArchiveOrgIE.archive_org_ie = ArchiveOrgIE()


# Generated at 2022-06-14 16:09:46.042789
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert 'archive.org' == ArchiveOrgIE().IE_NAME

# Generated at 2022-06-14 16:09:48.289931
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-14 16:09:57.187726
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'
    q = ie._download_json('http://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect', 'XD300-23_68HighlightsAResearchCntAugHumanIntellect', query={
                'output': 'json',
            })['metadata']
    assert q['title'][0] == '1968 Demo - FJCC Conference Presentation Reel #1'
    assert q['creator'][0] == 'SRI International'
    assert q['date'][0] == '19681210'
    assert q['publisher'][0] == 'SRI International'


# Generated at 2022-06-14 16:12:18.019260
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'
    assert ie._VALID_URL == r'https?://(?:www\.)?archive\.org/(?:details|embed)/(?P<id>[^/?#&]+)'

# Generated at 2022-06-14 16:12:20.340926
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    """
    Unit test for constructor of class ArchiveOrgIE.
    """

    ArchiveOrgIE()

# Generated at 2022-06-14 16:12:21.028161
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()

# Generated at 2022-06-14 16:12:26.567617
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    # This test is to check whether the constructor of ArchiveOrgIE has been changed.
    # If the constructor has been changed, the test would fail.
    # And then, the following codes should be included in the approperiate place of the new constructor.
    #
    # self.login()
    # self.populate_video_password()
    ie = ArchiveOrgIE()
    ie.login()
    ie.populate_video_password()

# Generated at 2022-06-14 16:12:29.391590
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert isinstance(ie, ArchiveOrgIE)
    assert ie.IE_NAME == 'archive.org'
    assert ie.IE_DESC == 'archive.org videos'

# Generated at 2022-06-14 16:12:36.921775
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    ie = ArchiveOrgIE()
    assert ie.ie_key() == 'archive.org'
    assert ie.ie_desc() == 'archive.org videos'
    assert ie.is_suitable(
        'https://archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert ie.is_suitable(
        'https://archive.org/details/Cops1922')
    assert ie.is_suitable(
        'https://archive.org/details/MSNBCW_20131125_040000_To_Catch_a_Predator/')
    assert ie.is_suitable(
        'http://archive.org/embed/XD300-23_68HighlightsAResearchCntAugHumanIntellect')

# Generated at 2022-06-14 16:12:39.133032
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    from .. import YoutubeIE
    assert ArchiveOrgIE._ie_key() == ArchiveOrgIE.ie_key()
    assert ArchiveOrgIE._test() == YoutubeIE._test()

# Generated at 2022-06-14 16:12:40.265563
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL

# Generated at 2022-06-14 16:12:46.332365
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    archiveOrgIE = ArchiveOrgIE()
    assert archiveOrgIE.ie_key() == 'archive.org'
    assert archiveOrgIE.ie_desc() == 'archive.org videos'
    assert archiveOrgIE.suitable('https://www.archive.org/details/XD300-23_68HighlightsAResearchCntAugHumanIntellect')
    assert not archiveOrgIE.suitable('https://www.youtube.com/watch?v=8aE_AVhjOyY')


# Generated at 2022-06-14 16:12:47.610149
# Unit test for constructor of class ArchiveOrgIE
def test_ArchiveOrgIE():
    assert ArchiveOrgIE()._VALID_URL == ArchiveOrgIE._VALID_URL