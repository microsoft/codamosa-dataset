

# Generated at 2022-06-25 10:33:00.424568
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'foo'

    ret = LookupModule().run(terms)

    assert ret == [u'1\n2\n3\n4\n5\n6\n7\n8\n9\n10\n11\n12\n13\n14\n15\n16\n17\n18\n19\n20\n21\n22\n23\n24\n25\n26\n27\n28\n29\n30\n31\n32\n33\n34\n35\n36\n37\n38\n39\n40\n41\n42\n43\n44\n45\n46\n47\n48\n49\n50\n']

# Generated at 2022-06-25 10:33:02.960832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[u'foo.txt'], variables=None) == [u'success']



# Generated at 2022-06-25 10:33:05.613178
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    lookup_module.run([])

# Generated at 2022-06-25 10:33:10.639369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupModule
    lookup_module_0 = LookupModule()
    terms_0 = (
        ("test_file.txt",),
    )
    # LookupModule.run() must raise exceptions.AnsibleError
    with pytest.raises(exceptions.AnsibleError):
        lookup_module_0.run(terms_0)

# Generated at 2022-06-25 10:33:20.947037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    with pytest.raises(AnsibleError):
        lookup_module_0.run(terms=["abcd"])

    """
    When `__file__`(file name containing the code for the current module) is
    not defined, the current working directory is used to find the file.
    So, when executing the test case from the root directory of the project,
    the `LookupModule` should find the file.
    A robust solution for testing the `LookupModule` would be to create a
    temporary file and pass a path to the temporary file to `LookupModule.run`
    """
    assert lookup_module_0.run(terms=["test/files/test_data.txt"]) == ["This is a test data file."]

# Generated at 2022-06-25 10:33:32.460148
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Params for run function
  lookup_module = LookupModule()
  terms = ['/etc/prelude-correlator.conf']
  variables = None
  # These values will be mocked by the mock library
  kwargs = {'rstrip': True, 'lstrip': False}

  # The expected return value

# Generated at 2022-06-25 10:33:40.942169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    test_file_name_0=u'testfile'
    test_file_path_0=None
    test_terms_0=[u'test']
    test_variables_0={}
    test_variables_0[u'ANSIBLE_LOOKUP_PLUGINS']=u'.'
    test_variables_0[u'ANSIBLE_ROLES_PATH']=u'../'
    test_variables_0[u'ANSIBLE_LIBRARY']=u'lib/ansible/modules/'
    test_variables_0[u'ANSIBLE_EXECUTABLE']=u'/usr/bin/ansible'
    test_kwargs_0={}
    test_kwargs_0[u'warn']=False
    test_ret_

# Generated at 2022-06-25 10:33:48.172943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    testcase_0_args = [
        [
            ' foo.txt ',
        ],
    ]

    testcase_0_kwargs = {
        'variables': None,
    }

    try:
        retval_0 = lookup_module_0.run(**testcase_0_kwargs)
    except Exception as e:
        retval_0 = e

    with open("test/results/test_LookupModule_run_0.txt", 'r') as fh:
        expected_result_0 = fh.read()
    assert retval_0 == expected_result_0



# Generated at 2022-06-25 10:33:58.266054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/passwd']

# Generated at 2022-06-25 10:34:02.493788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = list()
    print(lookup_module_0.run(terms))

'''
if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()
'''

# Generated at 2022-06-25 10:34:14.326334
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_args = {}
    test_run_args['terms']=['/etc/ansible/foofile.txt']
    test_run_args['variables']=None
    test_run_args['**kwargs']={}

    lookup_module = LookupModule()
    # Return the file definition
    files = lookup_module.run(**test_run_args)
    print(files)

# Generated at 2022-06-25 10:34:25.640764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_0 = LookupModule()
    lookup_module_0.run.args = {'terms': ['/etc/group', 'ansible']}
    lookup_module_0.run.kwargs = {'lstrip': False, 'variables': None}
    lookup_module_1.run.args = {'terms': ['/etc/group', 'ansible']}
    lookup_module_1.run.kwargs = {'lstrip': False, 'variables': None, 'rstrip': True}
    lookup_module_2.run.args = {'terms': ['/etc/group', 'ansible']}

# Generated at 2022-06-25 10:34:36.872185
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['/etc/passwd']
    variables = None
    ret = lookup_module_0.run(terms, variables)
    print(ret)
    #example_data = [u'root:x:0:0:root:/root:/bin/bash', u'daemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin', u'bin:x:2:2:bin:/bin:/usr/sbin/nologin', u'sys:x:3:3:sys:/dev:/usr/sbin/nologin', u'sync:x:4:65534:sync:/bin:/bin/sync', u'games:x:5:60:games:/usr/games:/usr/sbin/nologin', u'man:x:

# Generated at 2022-06-25 10:34:46.069587
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(loader=None)
    lookup_module_0.get_loader.__annotations__ = {'return': 'AnsibleLoader'}
    lookup_module_0.get_loader.__defaults__ = (None,)
    lookup_module_0.run.__annotations__ = {'terms': 'list', 'variables': 'dict', 'return': 'list'}
    lookup_module_0.run.__defaults__ = (None,)
    lookup_module_0.run.__kwdefaults__ = {'kwargs': None}
    ansible_loader = object()
    kwargs = dict()
    kwargs['kwargs'] = dict()
    kwargs['kwargs']['variables'] = None
   

# Generated at 2022-06-25 10:34:47.600884
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run is not None


# Generated at 2022-06-25 10:34:54.045292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_1 = ['test1_file_content.txt']
    variables_1 = {'playbook_dir': '/ansible'}
    kwargs_1 = {}
    setattr(lookup_module_0, 'finder', '/ansible/TestFinder')
    setattr(lookup_module_0, 'basedir', '/ansible')
    #Parameters (2)
    ret = lookup_module_0.run(terms_1, variables_1, **kwargs_1)
    print(ret)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:04.696530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = []
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    terms_0 = ['file0.txt']

# Generated at 2022-06-25 10:35:06.134201
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
#    lookup_module.set_options(var_options=variables, direct=kwargs)
#    lookup_module.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 10:35:14.789046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup import LookupBase
    from ansible.utils.display import Display
    display = Display()

    try:
        lookup_module_0 = LookupModule()
        lookup_module_0.run(host_list_0, host_vars_0, vars_0, new_plugin_0, self_0, task_vars_0, play_context_0, loader_0, templar_0, all_vars_0, variables_0, debug_0, foo_0)
    except Exception as e:
        message_0 = str(e)
        assert False, "Raised exception: " + message_0


# Generated at 2022-06-25 10:35:17.613657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj = LookupModule()
    result = lookup_module_obj.run(['test_file'])
    assert result == ['Hello']

# Generated at 2022-06-25 10:35:35.674922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test_value_0']
    variables_0 = {'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1'}
    kwargs_0 = {'test_key_0': 'test_value_0', 'test_key_1': 'test_value_1'}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []

# Generated at 2022-06-25 10:35:39.034331
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    test_case_0()

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:47.096213
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/etc/foo.txt', 'bar.txt', '/path/to/biz.txt']
    variables = dict(foo=1, bar=dict(baz=2))
    kwargs = dict(lstrip=True, rstrip=False)
    file_contents = lookup_module_0.run(terms, variables, **kwargs)
    print (file_contents)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:35:50.590930
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # this is what a call via the lookup pluggin API would look like and is also the format test_cases expects
    lookup.run([], dict(path=["foo"]), variable_manager=[], loader=[], templar=[])

# Generated at 2022-06-25 10:35:51.129619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:35:54.170458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['local_file.txt'])

# Generated at 2022-06-25 10:35:58.773353
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


# Generated at 2022-06-25 10:36:04.582001
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test function without parametrs passed
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct=dict())
    lookup_module_0._loader = DummyLoader()
    lookup_module_0._loader._get_file_contents = DummyLoader._get_file_contents
    lookup_module_0.run(terms=['file1.txt'], variables=None)
    assert lookup_module_0._file_cache == dict()
    assert lookup_module_0._file_cache == dict()
    assert lookup_module_0._file_vault is None
    assert lookup_module_0._display == display
    assert lookup_module_0._options == dict()
    assert lookup_module_0._extra_dirs is None
    assert lookup_module_0._loader is not None

# Generated at 2022-06-25 10:36:14.415614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print()
    print('--- test_LookupModule_run ---')
# .travis.yml:      'tests/plugins/lookup/test_file.py::test_LookupModule_run'

    print('    CHECK: LookupModule().run()')
    ok = True
    lookup_module = LookupModule()
    try:
        result = lookup_module.run()
    except Exception as e:
        print('    CHECK: LookupModule().run() -> result: exception "' + str(e) + '"')
        ok = False

    if ok:
        print('    CHECK: LookupModule().run() -> result: ' + str(result))
        if result != []:
            ok = False
        print('    CHECK: len(LookupModule().run() -> result) == 0')

# Generated at 2022-06-25 10:36:19.024539
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Class object is required to call run method of class LookupModule
    lookup_module_obj_0 = LookupModule()

    # Arguments for the run method of class LookupModule are defined in the args local namespace.
    # Argument for run method of class LookupModule is initialized to a dynamic value defined in a python lambda function.
    args = {'terms': [lambda _=None: 'test_value_1'], 'variables': {'test_value_2': 'test_value_3'}, 'rs': True, 'ls': True}
    results = lookup_module_obj_0.run(**args)

    assert results == ['test_value_1']


# Generated at 2022-06-25 10:36:34.570835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.log = MagicMock()
    lookup_module_0._loader = MagicMock()
    lookup_module_0._loader._get_file_contents = MagicMock(return_value=[b'123.txt', 'value'])
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:36:37.750999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:36:44.810158
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['foo.txt', 'bar.txt', 'fooz.txt'])
    assert len(var_0) == 3
    assert var_0[0] == '1234\n'
    assert var_0[1] == 'bar\n'
    assert var_0[2] == 'this is a test\n'

# Generated at 2022-06-25 10:36:46.074327
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 10:36:51.100652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    lookup_module_1.run(list_0)
    var_0 = lookup_module_1.run(list_0)
    assert var_0 == lookup_module_0



# Generated at 2022-06-25 10:36:56.471733
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:37:01.334117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0  = ['file']
    int_0 = -2604
    int_1 = 4546
    lookup_module_1 = LookupModule(int_0, int_1)
    int_2 = 9984
    int_3 = -5465
    lookup_module_1.run(list_0, int_2, int_3)
    # AssertionError
    list_1  = [lookup_module_1]
    lookup_module_2 = LookupModule(int_0, int_1)
    int_4 = 7538
    int_5 = -3010
    lookup_module_2.run(list_1, int_4, int_5)
    # AssertionError

# Generated at 2022-06-25 10:37:03.192936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)

# Generated at 2022-06-25 10:37:13.301573
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = [None]
    variables_0 = {'list_0': [terms_0]}
    lookup_module_0 = LookupModule(variables=variables_0)
    lookup_module_0.set_options(var_options=variables_0, direct=variables_0)
    file_path_0 = variables_0['list_0'][0]
    lookupfile_0 = lookup_module_0.find_file_in_search_path(variables_0, 'files', file_path_0)
    lookup_module_0._loader._get_file_contents(lookupfile_0)
    b_contents_0, show_data_0 = lookup_module_0._loader._get_file_contents(lookupfile_0)

# Generated at 2022-06-25 10:37:21.530408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [""]
    float_0 = 4.33
    int_0 = 4
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)
    list_1 = [""]
    list_2 = [list_0, list_1]
    var_1 = lookup_module_1.run(list_2)
    list_3 = [list_0]
    list_4 = [list_0, list_1, list_2, list_3]
    var_2 = lookup_module_1.run(list_4)

# Generated at 2022-06-25 10:37:49.408962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Setup
    lookup_module = LookupModule()
    terms = ["test/test_lookup_plugins.py", "test.lookup_plugins.yml", "test/lookup_plugins.not_json.json"]
    # Exercise
    result = lookup_module.run(terms)
    # Verify

# Generated at 2022-06-25 10:37:55.391411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    list_1 = [lookup_module_2]
    float_1 = -1299.7
    int_1 = 4287
    lookup_module_3 = LookupModule(float_1, int_1)
    var_1 = lookup_module_3.run(list_1)

test_LookupModule_run()

# Generated at 2022-06-25 10:38:02.541365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    list_1 = [lookup_module_2]
    int_1 = -7373
    float_1 = -5303.6
    lookup_module_3 = LookupModule(int_1, float_1)
    var_1 = lookup_module_3.run(list_1)

# Generated at 2022-06-25 10:38:08.714666
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_1 = [lookup_module_0]
    float_1 = 80.62729
    int_1 = 7637
    lookup_module_2 = LookupModule(float_1, int_1)
    var_1 = lookup_module_2.run(list_1)

# Generated at 2022-06-25 10:38:17.205590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    import sys
    import ansible.module_utils.basic

    # Testing a method that wasn't part of any task or other code
    args = dict(
        _raw=['sample output'],
        _terms=[],
    )
    obj = ansible.module_utils.basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False,
    )
    commands = list()

    def exec_command(cmd, tmp_path, environ_update=None, data=None, binary_data=False):
        commands.append(cmd)

    def run_command(cmd, check_rc=True):
        commands.append(cmd)
        return 0, '', ''

    original_run_command = ansible.module_utils

# Generated at 2022-06-25 10:38:24.453507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        builtins.t_lookup_module_0 = LookupModule()
        list_0 = [builtins.t_lookup_module_0]
        float_0 = -1299.7
        int_0 = 4287
        lookup_module_0 = LookupModule(float_0, int_0)
        var_0 = lookup_module_0.run(list_0)
        builtins.t_lookup_module_0 = var_0
    except Exception as exception_0:
        var_1 = type(exception_0)
        pass
    return builtins.t_lookup_module_0


# Generated at 2022-06-25 10:38:27.879283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:38:30.834330
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Local variables definition
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:38:33.727045
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)


if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:38:35.635561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_0 = LookupModule(float_0, int_0)
    list_0 = [lookup_module_0]
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:39:28.149410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule.run
    var_0 = lookup_module
    var_0 = lookup_module()
    int_0 = -2194
    bool_0 = True
    int_1 = -1599
    bool_1 = False
    int_2 = 1704
    var_1 = lookup_module(int_0, bool_0, int_1, bool_1, int_2)


# Generated at 2022-06-25 10:39:32.523797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list()

    # test with normal parameters
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)

    # test with parameters float and int
    lookup_module_1 = LookupModule()
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1.run(terms, float_0, int_0)


# Generated at 2022-06-25 10:39:37.510448
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms_0 = ['foo.txt']
    variables_0 = {'var_0': 'bar.txt'}
    variable_options_0 = variables_0
    display_0 = Display()
    display_0.vvvv = True
    lookup_module_0 = LookupModule(display_0)
    int_0 = 73
    lookup_module_0.set_options(variable_options_0, direct=int_0)
    assert lookup_module_0.run(terms_0) == ['foo.txt']

# Generated at 2022-06-25 10:39:41.985782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_1 = lookup_module_1.run(list_0)
    assert var_1 == None

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:49.551060
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:39:53.706618
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # A list of string objects.
    list_0 = ['']
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)

if __name__ == "__main__":
    test_case_0()
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:56.847348
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:40:00.686215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    int_1 = 9413
    float_1 = -64.169
    lookup_module_3 = LookupModule(int_1, float_1)
    var_1 = lookup_module_3.run([lookup_module_2])
    float_2 = -7583.173
    lookup_module_4 = LookupModule(float_2)
    var_2 = lookup_module_4.run([lookup_module_2])
    int_2 = 9492
    lookup_module_5 = LookupModule(int_2)
    var_3 = lookup_module_5.run([lookup_module_2])

# Generated at 2022-06-25 10:40:08.904052
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0, lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)
    assert var_0 == [lookup_module_0, lookup_module_0], "lookup_module_1 = lookup_module_1.run(list_0) returned " + str(var_0)

# Generated at 2022-06-25 10:40:16.040927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)

# Generated at 2022-06-25 10:42:16.659472
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options('_terms')
    lookup_module_0.run('_terms')
    lookup_module_0.rstrip

# Generated at 2022-06-25 10:42:25.506314
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_2 = LookupModule(float_0, int_0)
    str_0 = lookup_module_2.run([lookup_module_0, lookup_module_1])    
    assert str_0 == 1231
    str_1 = lookup_module_2.run([lookup_module_1, lookup_module_0])    
    assert str_1 == 611

test_LookupModule_run()
test_case_0()

# Generated at 2022-06-25 10:42:27.531054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # first command line argument is the file name
    test_case_0()

# Generated at 2022-06-25 10:42:29.303457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'lookup module run'
    assert lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:42:34.833990
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    str_0 = 'files'
    float_1 = -1299.7
    int_1 = 4287
    lookup_module_3 = LookupModule(float_1, int_1)
    lookup_module_4 = LookupModule(float_1, int_1, str_0)
    file_0 = lookup_module_4
    var_1 = lookup_module_3.run(file_0)
    str_1 = 'LookupModule.run'
    file_1 = lookup_module_3.run(str_1)


# Generated at 2022-06-25 10:42:37.535239
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [lookup_module_0]
    float_0 = -1299.7
    int_0 = 4287
    lookup_module_1 = LookupModule(float_0, int_0)
    var_0 = lookup_module_1.run(list_0)


# Generated at 2022-06-25 10:42:40.007114
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    list_1 = [lookup_module_2]
    str_0 = 'file'
    lookup_module_3 = LookupModule(str_0)
    var_1 = lookup_module_3.run(list_1)


# Generated at 2022-06-25 10:42:45.757086
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    float_0 = -1823.3
    int_0 = -85
    lookup_module_1.run(float_0, int_0)
    lookup_module_0.run(float_0, int_0)
    lookup_module_1.run(float_0, int_0)
    int_1 = 1795
    float_1 = -1722.3
    int_2 = 5730
    lookup_module_1 = LookupModule(int_1, float_1, int_2)
    int_3 = -2089
    float_2 = 766.4
    float_3 = 681.4
    lookup_module_1.run(int_3, float_2, float_3)


# Generated at 2022-06-25 10:42:48.089233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(lookup_module_0)
