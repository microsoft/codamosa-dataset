

# Generated at 2022-06-25 10:32:57.124726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = lambda *args, **kwargs: 'file_name'
    lookup_module._loader._get_file_contents = lambda *args, **kwargs: 'content', True
    assert_equal(lookup_module.run(['some_term']), ['content'])

# Generated at 2022-06-25 10:33:03.053992
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([['test_ansible_data/file.txt']]) == ['{"a": 1, "b": 2, "c": 3}\n']
    assert lookup_module_0.run([['test_ansible_data/file_multiline.txt']]) == ['{\'a\': 1, \'b\': 2, \'c\': 3}\n']

# Generated at 2022-06-25 10:33:13.523531
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    #  File: /etc/foo.txt
    #    line 1
    #    line 2
    #    line 3

    #  File: /tmp/test.txt
    #    line 4
    #    line 5
    #    line 6

    terms = [
        '/etc/foo.txt',
        '/tmp/test.txt',
    ]
    variables = {
        'files': [
            '/',
        ],
    }
    kwargs = {
        'rstrip': True,
        'lstrip': False,
    }
    expected_result = [
        'line 1\nline 2\nline 3',
        'line 4\nline 5\nline 6',
    ]
    result = lookup_module.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:33:18.346387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [0,]
    variables = [0,]
    kwargs = {
        'var_options' : variables,
        'direct' : kwargs,
    }

    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == [], "Expected {}, but got: {}".format([], result)

# Generated at 2022-06-25 10:33:19.690515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(["/root/file"])

# Generated at 2022-06-25 10:33:22.917717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = ["/etc/hosts"]
  kwargs = {"var_options": test_case_0()}
  assert lookup_module.run(terms, **kwargs) == ["127.0.0.1\tlocalhost\n127.0.1.1\tlocal.localdomain\n"]

# Generated at 2022-06-25 10:33:29.843705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    tempdir = tempfile.mkdtemp()
    filename = os.path.join(tempdir, "test")
    with open(filename, "w") as f:
        f.write("my value")

    lookup_module_run = LookupModule()

    result = lookup_module_run.run(["test"], dict(), base_path=[tempdir], **{})
    assert result == ["my value"]

# Generated at 2022-06-25 10:33:33.377006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([u'terms']) is None


# Generated at 2022-06-25 10:33:41.730633
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils.six.moves import StringIO
    lookup_module = LookupModule()
    terms = ['hello_world.yml']
    lookup_module._loader = DictDataLoader({u'hello_world.yml': u'Hello World!'})
    result = lookup_module.run(terms)
    assert result == [u'Hello World!']

    lookup_module = LookupModule()
    terms = ['hello_world.yml']
    lookup_module.set_options(direct={'rstrip': False})
    lookup_module._loader = DictDataLoader({u'hello_world.yml': u'Hello World!\n'})
    result = lookup_module.run(terms)
    assert result == [u'Hello World!\n']

    lookup_module = LookupModule()
   

# Generated at 2022-06-25 10:33:51.070483
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1._loader == None
    lookup_module_1.run(terms=["/path/to/file"],
                        variables={"ansible_lookup_plugin_basedir": "/var/folders/ch/4hs6xh8j0zb0wq3rqr24kz700000gq/T/tmp0GJH9X"})
    lookup_module_1.run(terms=["/path/to/file"],
                        variables={"ansible_lookup_plugin_basedir": "/var/folders/ch/4hs6xh8j0zb0wq3rqr24kz700000gq/T/tmp0GJH9X"},
                        rstrip=True,
                        lstrip=True)

# Generated at 2022-06-25 10:34:01.512156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([]) == []

# unit test for method run of class LookupModule

# Generated at 2022-06-25 10:34:06.293319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:34:16.038909
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result_1 = lookup_module_1.run(terms=['/usr/bin/python'], variables={'ansible_playbook_python': '/usr/bin/python3'}, direct={'lstrip': False, 'rstrip': False})
    assert result_1 == ['/usr/bin/python\n'], "Result: {}".format(result_1)

    lookup_module_2 = LookupModule()
    result_2 = lookup_module_2.run(terms=['/etc/passwd'], variables={'ansible_playbook_python': '/usr/bin/python3'}, direct={'lstrip': False, 'rstrip': False})
    assert result_2[0].startswith('root') is True, "Result: {}".format(result_2)



# Generated at 2022-06-25 10:34:22.108278
# Unit test for method run of class LookupModule
def test_LookupModule_run():

	test_run_0_arguments = {'terms': ['test_run_0_arguments'], 'variables': ['test_run_0_arguments']}
	try:
		result = test_case_0.run(**test_run_0_arguments)
	except Exception:
		raise Exception("Incorrect arguments")

	return result

test_LookupModule_run()

# Generated at 2022-06-25 10:34:27.275575
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_0 = None
  variables_0 = None
  kwargs_0 = dict()
  kwargs_0['rstrip'] = True
  kwargs_0['lstrip'] = False
  ret_0 = lookup_module_0.run(terms_0, variables_0, **kwargs_0)
  assert ret_0 == []


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:27.813819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:34:31.770908
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert lookup_module_run.run()==[], "The test that tests run method of class LookupModule has failed"

# Generated at 2022-06-25 10:34:35.841034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'rstrip': False, 'lstrip': False})
    terms_0 = ['/etc/foo.txt']
    lookup_module_0.run(terms_0, variables=None)

# Generated at 2022-06-25 10:34:43.055844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [1, 2, 3]
    variables = None
    kwargs = {'foo': 'bar'}

    lookup_mod_0 = LookupModule()
    txt = lookup_mod_0.run(terms, variables, **kwargs)
    assert txt == [] # Expected an empty List

# This is a manual test for the test script, i.e. the test is manualy executed using
# the invoke.py script

# Generated at 2022-06-25 10:34:47.274209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()

    # default
    result = lookup_instance.run('/home/vagrant/ansible/sandbox/inventory/hosts')

    assert result[0] == u'localhost ansible_connection=local\n'


# Generated at 2022-06-25 10:34:58.336808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = test_case_0()
    dict_0 = {int_0: int_0, int_0: int_0}
    var_0 = lookup_run(dict_0)
    assert var_0 == lookup_module_0
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 10:35:07.305075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'K8OvY>X9'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_module_0.run(dict_0)
    str_1 = 'Xc`P'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1, str_1: str_1}
    var_1 = lookup_module_0.run(dict_1)
    str_2 = '}Dz='

# Generated at 2022-06-25 10:35:15.780284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = _loader
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.set_options()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.set_options()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()
    lookup_module_0.run()


# Generated at 2022-06-25 10:35:22.500288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'foo': 'foo', 'bar': 'bar'}
    lookup_module_0 = LookupModule()
    terms_0 = ['foo', 'foo', 'foo', 'foo']
    var_0 = lookup_module_0.run(terms=terms_0, variables=dict_0)
    assert var_0 is not None

if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:35:28.385792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'key_0': 'value_2', 'key_3': 'value_3', 'key_2': 'value_1', 'key_1': 'value_0'}
    lookup_module_0 = LookupModule()
    try:
        lookup_module_0.run([], dict_0, lstrip=True, rstrip=False)
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 10:35:34.069980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 't8jx`3q*4,!'
    dict_1 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_1)

# Generated at 2022-06-25 10:35:35.873875
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False


# Generated at 2022-06-25 10:35:39.894170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'qB4>'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:35:43.922368
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run(terms)
    assert var is not None


# Generated at 2022-06-25 10:35:47.558118
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert true


# Generated at 2022-06-25 10:36:02.013442
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'qB4>'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:36:07.117781
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '`&2Y9y'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0.run(list_0)


# Generated at 2022-06-25 10:36:15.157443
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '+b`'
    str_1 = '7tW'
    str_2 = 'Y)1'
    str_3 = '/Qv'
    var_0 = {str_0: str_0, str_1: str_2, str_3: str_0}
    list_0 = [str_0, str_1, str_2, str_3]
    # TODO : Need to replace with implementation of method run
    raise NotImplementedError()


# Generated at 2022-06-25 10:36:19.213409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ''
  variables = ''
  instance = LookupModule()
  assert instance.run(terms, variables) == 'foo'

# Generated at 2022-06-25 10:36:24.599839
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = "|b8_"
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}


# Generated at 2022-06-25 10:36:31.107023
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '`)xw'
    str_1 = '4&V>'
    str_2 = '+PQ.'
    str_3 = '^]q3'
    str_4 = 'fRX9'
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:36:36.137708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms=terms, variables=variables, **kwargs)

# Generated at 2022-06-25 10:36:42.185205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'qB4>'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule()



# Generated at 2022-06-25 10:36:48.893965
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = lookup_module_0
    lookup_module_1 = lookup_module_0
    lookup_module_2 = lookup_module_0
    lookup_module_2 = lookup_module_0
    lookup_module_3 = lookup_module_0
    lookup_module_2.run('/etc/foo.txt')
    lookup_module_1.run(lookup_module_0)
    lookup_module_3.run(lookup_module_3)
    lookup_module_3.run('foo.txt')
    lookup_module_3.run('foo.txt')
    lookup_module_3.run('bar.txt')
    lookup_module_3.run('bar.txt')
    lookup_module_3.run('biz.txt')
   

# Generated at 2022-06-25 10:36:56.780410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Nb_c%:N'
    str_1 = 'Nb_c%:N'
    str_2 = 'Nb_c%:N'
    str_3 = 'Nb_c%:N'
    str_4 = 'Nb_c%:N'
    str_5 = 'Nb_c%:N'
    str_6 = 'Nb_c%:N'
    str_7 = 'Nb_c%:N'
    str_8 = 'Nb_c%:N'
    str_9 = 'Nb_c%:N'
    str_10 = 'Nb_c%:N'
    str_11 = 'Nb_c%:N'
    str_12 = 'Nb_c%:N'

# Generated at 2022-06-25 10:37:20.078860
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:37:30.735413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert lookup_module_0.run(terms_0) == var_0
  assert lookup_module_1.run(terms_1) == var_0
  assert lookup_module_2.run(terms_2) == var_0
  assert lookup_module_3.run(terms_3) == var_0
  assert lookup_module_4.run(terms_4) == var_0
  assert lookup_module_5.run(terms_5) == var_0
  assert lookup_module_6.run(terms_6) == var_0
  assert lookup_module_7.run(terms_7) == var_0
  assert lookup_module_8.run(terms_8) == var_0
  assert lookup_module_9.run(terms_9) == var_0

# Generated at 2022-06-25 10:37:32.395133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    for v_0 in range(15, 20):
        for v_1 in range(15, 20):
            test_case_0()


# Generated at 2022-06-25 10:37:42.958732
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:37:47.846460
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run of class LookupModule')
    str_0 = 'ZT'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule()

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:37:57.660283
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lu = LookupModule()
    lookup_run = lu.run

    # Test for function run()
    lu.terms = 'lookup/file/test'
    lu.variables = None
    lu.kwargs = {'direct': {}}
    lu.set_options(var_options=lu.variables, direct=lu.kwargs)

    lookupfile = lu.find_file_in_search_path(lu.variables, 'files', lu.terms)
    b_contents, show_data = lu._loader._get_file_contents(lookupfile)
    contents = to_text(b_contents, errors='surrogate_or_strict')
    assert contents == "some data\n"

# Generated at 2022-06-25 10:38:00.854270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Unit test for method run of class LookupModule')
    lookup_module_0 = LookupModule()
    str_0 = '|n=a'
    str_1 = 'Uj'
    var_0 = lookup_module_0.run(str_0, str_1)


# Generated at 2022-06-25 10:38:07.601005
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'0': '', '8': '', '1': '', '4': '', '2': '', '3': '', '6': '', '5': '', '7': '', '9': ''}
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:38:11.527402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'pJ'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_run(dict_0)


# Generated at 2022-06-25 10:38:17.285009
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = list([1, 2, 3])
    list_1 = list(['W}c%', '7'])
    lookup_module_0.run(terms = list_0, kwargs = dict({dict({2: 3}): list(['u', 'vDA'])}), variables = dict({3: dict({'t': list_1, 'r': None}), 'Md\x07': list_1}))



# Generated at 2022-06-25 10:39:08.254473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['qB4>', 'qB4>', 'qB4>', 'qB4>', 'qB4>']
    variables = {'qB4>': 'qB4>', 'qB4>': 'qB4>', 'qB4>': 'qB4>', 'qB4>': 'qB4>'}
    lookup_module = LookupModule()
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 10:39:10.566243
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'qB4>'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(dict_0)


# Generated at 2022-06-25 10:39:14.242080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fname_0 = 'qB4>'
    str_1 = 'qB4>'
    lookup_module_2 = LookupModule()
    var_0 = lookup_module_2.run(fname_0, str_1)
    assert var_0 is None


# Generated at 2022-06-25 10:39:17.904804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert LookupModule.run(None,None)==None


# Generated at 2022-06-25 10:39:24.271547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'R:!'
    int_0 = -2
    str_1 = '@l&#H'
    str_2 = 'n_#1'
    str_3 = 'N?r'
    lookup_module_0 = LookupModule()
    var_0 = lookup_run('m_#')
    lookup_module_1 = LookupModule()
    var_1 = (lookup_module_0.run(var_0, int_0))
    assert (len(var_1)) == 0
    lookup_module_2 = LookupModule()
    assert (len(lookup_module_1.run(['(^', '2Vl'], int_0))) == 0

# Generated at 2022-06-25 10:39:28.822365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:39:29.914812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert callable(LookupModule.run)


# Generated at 2022-06-25 10:39:37.893319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    # unit test for term: "\n"
    ret_1 = lookup_module_run.run('\\n')
    dict_1 = '[\'\']'
    str_1 = 'run'
    display.vvvv('FileLookupEx1.png')
    # unit test for term: "[dict(b=3, a=2, c=1), 2, 3, 2.]"
    ret_2 = lookup_module_run.run('[dict(b=3, a=2, c=1), 2, 3, 2.]')
    dict_2 = '[{\'b\': 3, \'a\': 2, \'c\': 1}, 2, 3, 2.0]'
    str_2 = 'run'
    display.vvvv('FileLookupEx2.png')


# Generated at 2022-06-25 10:39:43.731745
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'a'
    lookup_module_0 = LookupModule()
    terms_0 = str_0
    variables_0 = str_0
    lookup_module_0.run(terms_0, variables_0)
    lookup_module_1 = LookupModule()
    var_0 = test_case_0()
    lookup_module_1.run(var_0, var_0)
    lookup_module_2 = LookupModule()
    lookup_module_2.run(var_0, var_0)
    lookup_module_2.run(var_0, var_0)
    lookup_module_1.run(var_0, var_0)
    lookup_module_1.run(var_0, var_0)

# Generated at 2022-06-25 10:39:54.123143
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'qB4>'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    var_0 = lookup_run(dict_0)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(var_0)
    lookup_module_2 = LookupModule()
    str_1 = '0Q<j'
    dict_1 = {str_1: str_0, str_1: str_0, str_1: str_0, str_1: str_0}
    var_1 = lookup_run(dict_1)
    lookup_module_2.run(var_1)
    lookup_module_

# Generated at 2022-06-25 10:41:50.359296
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None)


# Generated at 2022-06-25 10:41:52.427787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_c = {}
    dict_c['terms'] = ['ansible/test_utils/test.txt']
    lookup_module = LookupModule()
    assert 'abc' == to_text(lookup_module.run(**dict_c)[0])


# Generated at 2022-06-25 10:41:58.149977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 10:42:03.161960
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options(var_options=dict_0, direct=dict_0)
    list_0 = []
    lookup_module_2.run(list_0, dict_0, **dict_0)
    lookup_module_3 = LookupModule()
    lookup_module_3.set_options(var_options=dict_0, direct=dict_0)
    lookup_module_3.run(list_0, dict_0, **dict_0)
    lookup_module_4 = LookupModule()
    lookup_module_4.set_options(var_options=dict_0, direct=dict_0)
    lookup_module_4.run(list_0, dict_0, **dict_0)
    lookup_module_5 = Lookup

# Generated at 2022-06-25 10:42:05.922863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.run()


# Generated at 2022-06-25 10:42:09.835432
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '42#'
    dict_0 = {str_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule()
    lookup_module_0.find_file_in_search_path(dict_0,'files','term1')
    list_0 = ['term1', 'term2']
    var_0 = lookup_module_0.run(list_0, dict_0)
    assert var_0 == ['term1\n', 'term2\n']


# Generated at 2022-06-25 10:42:14.175895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:42:17.194922
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    keywords_0 = {  }
    keyword_0 = 'O:6:\"LookupModule\"'
    # Make sure that run returns a list
    list_0 = [  ]
    assert isinstance(test_case_0(), list_0)


# Generated at 2022-06-25 10:42:22.017635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  pass

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 10:42:29.067405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Testing run of LookupModule')
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('qB4>', dict(), lstrip=True, rstrip=True)
    assert len(var_0) == 1
    assert var_0[0] == 'qB4>'
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run('qB4>', dict(), lstrip=True, rstrip=True)
    assert len(var_1) == 1
    assert var_1[0] == 'qB4>'

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4