

# Generated at 2022-06-25 10:32:56.011708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()
    lookup_module_0.run(['test_file_0'], 'test_variables_0')

# Generated at 2022-06-25 10:32:58.676606
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = ['/etc/foo.txt']
    variables = None
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms, variables)


# Generated at 2022-06-25 10:33:01.187081
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '/etc/foo.txt'
    variables = None
    lookup_module.run(terms, variables)


# Generated at 2022-06-25 10:33:09.734761
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert lookup_module_run.run(terms=['abc'], variables=None, **kwargs) == 0
    assert lookup_module_run.run(terms=['abc'], variables=None, kwargs='dict') == 0
    assert lookup_module_run.run(terms=['abc'], variables=None, kwargs='dict') != 1

# Generated at 2022-06-25 10:33:10.768409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule_run_0 = None
    assert lookup_module_0.run(LookupModule_run_0) == None


# Generated at 2022-06-25 10:33:21.216634
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import pytest
    from ansible.utils.display import Display
    display = Display()
    lookup_module_1 = LookupModule()

    # Case 0:
    # Terms is a list of invalid paths, do not raise any exception
    terms = ['etc/hosts', 'etc/hosts1']
    variables = {}

    # Unit test for method run
    ret = lookup_module_1.run(terms, variables)
    assert type(ret) == list

    # Case 1:
    # Terms is a valid path, do not raise any exception
    variables = {}
    terms = [os.path.abspath('test_fileio.py')]

    # Unit test for method run
    ret = lookup_module_1.run(terms, variables)
    assert type(ret) == list

    # Case 2:

# Generated at 2022-06-25 10:33:26.418831
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    arg0 = []
    arg1 = dict()

    # Test path from CWD
    lookup_module_0.run(arg0, arg1)
    

# Generated at 2022-06-25 10:33:28.317555
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [ 'test/ansible_test_file' ]

    lookup_module_0.run(terms)



# Generated at 2022-06-25 10:33:31.424157
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []

# Generated at 2022-06-25 10:33:41.277924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arguments_0 = [
        "tests/data/file_lookup_test1.txt",
        "tests/data/file_lookup_test2.txt",
    ]

# Generated at 2022-06-25 10:33:47.038136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'file_name']
    variables = {}
    kwargs = {}
    lookup_module_0.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:33:52.752852
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["ansible"]
    variables = {"ansible": "ansible"}
    args = dict()
    args["variables"] = variables
    args["kwargs"] = dict()
    kwargs = dict()
    kwargs["_original_file"] = "ansible"
    kwargs["_variable_manager"] = "ansible"
    args["kwargs"] = kwargs
    r_0 = lookup_module_0.run(terms=terms, variables=variables, **kwargs)
    r_0 = r_0[0]
    r_0 = r_0.strip()


# Generated at 2022-06-25 10:33:58.643053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    # __init__()
    assert not hasattr(m, '_templar')
    assert not hasattr(m, '_loader')
    assert not hasattr(m, '_basedir')
    assert not hasattr(m, '_display')
    assert not hasattr(m, '_options')
    assert not hasattr(m, 'basedir')

# Generated at 2022-06-25 10:34:01.143325
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(['*'], '/home/pankaj/ansible_tut')
    assert result == True, "run of class LookupModule "


# Generated at 2022-06-25 10:34:02.381238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    result = lookup_module.run(terms = u'/etc/foo.txt')
    assert result == []

# Generated at 2022-06-25 10:34:07.027074
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert not lookup_module.run(terms = [])


# Generated at 2022-06-25 10:34:12.242047
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  term_0 = "../../ansible/test/files/content.txt"
  variables_0 = {}
  kwargs_0 = {'lstrip': False, 'rstrip': False}
  try:
    result_0 = lookup_module_0.run(term_0, variables_0, **kwargs_0)
  except Exception as inst:
    result_0 = False
  return result_0


# Generated at 2022-06-25 10:34:22.156641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = [u'/etc/ansible/foobar.conf']
    vars_1 = None
    assert lookup_module_1.run(terms_1, vars_1) == [u'# This is a test file for the Ansible file lookup plugin.\n# It is NOT a real Ansible configuration file.\n'], 'Test of method run of class LookupModule failed.'
    lookup_module_2 = LookupModule()
    terms_2 = [u'/etc/ansible/hosts']
    vars_2 = None

# Generated at 2022-06-25 10:34:25.793912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run_obj = LookupModule()
    terms = "foo"
    variables = None
    kwargs = {}
    lookup_module_run_obj.run(terms, variables, **kwargs)

if __name__ == '__main__':
    import sys
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:32.894874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case = {
      "terms": [
        "/path/to/foo.txt"
      ],
      "variables": {},
      "kwargs": {}
    }
    lookup_module_0 = LookupModule()
    assert hasattr(lookup_module_0, 'run') and callable(getattr(lookup_module_0, 'run'))
    assert isinstance(lookup_module_0.run(**test_case), list)

# Generated at 2022-06-25 10:34:42.387475
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_loader(None)
    lookup_module._loader = None
    lookup_module._templar = None
    assert lookup_module.run(['/etc/foo.txt']) == ['42\n']

# Generated at 2022-06-25 10:34:47.283008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_run_0 = LookupModule()
  lookup_module_run_1 = LookupModule()
  # Test run method of class LookupModule
  lookup_module_run_0.run()
  # Test run method of class LookupModule
  lookup_module_run_1.run()

# Generated at 2022-06-25 10:34:48.433979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
   # TODO : add more tests here
   assert False


# Generated at 2022-06-25 10:34:52.234297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_option = MagicMock(return_value=None)
    lookup_module._loader = FakeLoader()
    lookup_module.run('test_file.txt')

test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:34:56.633140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  result = lookup_module.run(["path1"," path2"], None, **{"_options": {"_args":{
    "lstrip": True, "rstrip": False
  }}})
  print(result)


# Generated at 2022-06-25 10:35:04.295089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = list()
    terms.append('../../../../../../../../etc/passwd')
    terms.append('../../../../../../../../etc/hosts')
    variables = None
    kwargs = dict()
    #Test case with term from current directory
    kwargs['lstrip'] = True
    kwargs['rstrip'] = True
    # Call LookupModule.run()
    lookup_module_1.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:35:07.170233
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# Generated at 2022-06-25 10:35:11.751821
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Execution of run method by passing the values
    # var_options = variables = None, **kwargs = {}
    lookup_module_0.run(terms=['test.txt'], variables=None, **dict())

# Generated at 2022-06-25 10:35:18.010405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:35:27.866501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()

    # Test 1: No value passed for terms
    # Expected Result: Exception due to insufficient arguments
    # Actual Result: Exception due to insufficient arguments
    try:
        lookup_module_0.run()
    except SystemExit as e:
        assert e.code == 1

    # Test 2: Valid value passed for terms, valid value passed for variables
    # Expected Result: Returns contents of file
    # Actual Result: Returns contents of the file
    terms = "file_0.txt"
    variables = None

# Generated at 2022-06-25 10:35:35.171020
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:35:38.075820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    terms = ['foo.txt', 'bar.txt']
    result = lookupModule.run(terms)
    assert not(result is None)

# Generated at 2022-06-25 10:35:50.439162
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # FIXME: AnsibleError() parameter 'message' doesn't have a default value
    # lookup_module_2 = AnsibleError()
    lookup_module_3 = LookupBase()
    # FIXME: AnsibleParserError() parameter 'message' doesn't have a default value
    # lookup_module_4 = AnsibleParserError()
    # FIXME: AnsibleError() parameter 'message' doesn't have a default value
    # lookup_module_5 = AnsibleError()
    # FIXME: AnsibleError() parameter 'message' doesn't have a default value
    # lookup_module_6 = AnsibleError()
    # FIXME: AnsibleParserError() parameter 'message' doesn't have a default value
    # lookup_module_7 = AnsibleParserError()
    # FIXME: Ans

# Generated at 2022-06-25 10:35:59.711326
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    assert lookup_module_0.run(bool_0) == None
    bool_0 = True
    assert lookup_module_0.run(bool_0) == None
    bool_0 = False
    assert lookup_module_0.run(bool_0) == None
    bool_0 = True
    assert lookup_module_0.run(bool_0) == None
    bool_0 = False
    assert lookup_module_0.run(bool_0) == None
    bool_0 = True
    assert lookup_module_0.run(bool_0) == None
    bool_0 = False
    assert lookup_module_0.run(bool_0) == None
    bool_0 = True

# Generated at 2022-06-25 10:36:04.916156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)



# Generated at 2022-06-25 10:36:14.631526
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()

    # Create an object of class LookupBase
    lookup_base_0 = LookupBase()
    assert isinstance(lookup_base_0, LookupBase) == True
    assert callable(lookup_base_0) == True
    assert isinstance(lookup_base_0, LookupBase) == True

    # Create an object of class LookupBase
    lookup_base

# Generated at 2022-06-25 10:36:20.852037
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    bool_1 = True
    var_0 = lookup_module_0.run(bool_1)
    bool_2 = False
    var_1 = lookup_module_0.run(bool_2)

# Generated at 2022-06-25 10:36:25.313842
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run('file', terms=[])


# Generated at 2022-06-25 10:36:27.046103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 10:36:28.717647
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.run()


# Generated at 2022-06-25 10:36:43.530183
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    lookup_module_0._loader = False
    lookup_module_0.find_file_in_search_path(bool_0, ' ', False)
    lookup_module_0.get_option(bool_0)
    lookup_module_0.set_options(bool_0)
    var_0 = lookup_run(bool_0)
    assert type(var_0) == list
    assert len(var_0) == 0

# Generated at 2022-06-25 10:36:46.916883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['.', '..', '/', '\\', 'foo', 'foo/bar;ls', 'etc/passwd', 'x' * 500, 'file.txt', 'file', 'file.txt']
    bool_0 = False
    lookup_module_0.run(terms_0, bool_0)

# Generated at 2022-06-25 10:36:47.347674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:36:48.800242
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_1 = False
    assert isinstance(lookup_module_0.run(bool_1), list)

# Generated at 2022-06-25 10:36:58.085642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    str_0 = "daemon"
    list_0 = [str_0]
    str_1 = "module_utils/_text.py"
    list_1 = [str_1]
    dict_0 = dict()
    dict_0['searchpath'] = list_1
    dict_0['current_task'] = None
    dict_0['current_task_vars'] = dict()
    dict_0['playbook_dir'] = None
    dict_0['play_context'] = dict_0
    list_2 = lookup_module_0.run(list_0, dict_0)
    assert len(list_2) == 1


# Generated at 2022-06-25 10:37:02.095211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = len(string_0)
    var_1 = ''
    for var_2 in range(1,var_0):
        var_3 = var_1
        var_4 = ord(string_0[var_2])
        var_1 = var_3 + var_4
        print(var_1)

# Unit tests for file

# Generated at 2022-06-25 10:37:05.333768
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    var_1 = lookup_module_0.run(["/etc/foo.txt"])
    var_2 = lookup_module_0.run(["/etc/foo.txt", "/etc/bar.txt"])



# Generated at 2022-06-25 10:37:12.504545
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.var_loader = DictDataLoader({})
    lookup_module_0.var_templar = Templar({})
    lookup_module_0.var_vars = dict()
    lookup_module_0.var_basedir = None
    lookup_module_0.var_filters = None
    lookup_module_0.var_environment = None
    lookup_module_0.var_shared_loader_obj = None
    lookup_module_0.var_context = dict()
    lookup_module_0.run(var_0)



# Generated at 2022-06-25 10:37:20.998720
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  m0 = Mock()
  with patch.multiple(LookupModule,run=DEFAULT,run_0=DEFAULT,run_1=DEFAULT,run_2=DEFAULT,run_3=DEFAULT,run_4=DEFAULT,run_5=DEFAULT,run_6=DEFAULT,run_7=DEFAULT,run_8=DEFAULT,run_9=DEFAULT,run_10=DEFAULT,run_11=DEFAULT,run_12=DEFAULT,run_13=DEFAULT,run_14=DEFAULT,run_15=DEFAULT,run_16=DEFAULT):
    m0.run('test_value_0', str_0='test_value_1', str_1='test_value_2')

# Generated at 2022-06-25 10:37:31.015936
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mocker = Mocker()
    mocker.patch.object(os.path, 'exists')
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(mocker.mock(AnsibleLoader))
    lookup_module_0.set_basedir(mocker.mock(str))
    lookup_module_0.set_environment(mocker.mock(dict))
    list_0 = [mocker.mock(str), mocker.mock(SearchPath)]
    fake_terms_0 = mocker.mock(list)
    mocker.result(list_0)
    fake_terms_0.__str__ = mocker.mock(str)
    fake_terms_0.__str__ = mocker.mock(str)

# Generated at 2022-06-25 10:37:58.094210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    terms_0 = ("etc/foo.txt",)
    var_0 = lookup_module_0.run(terms_0, bool_0)
    assert len(var_0) == 1
    assert var_0[0] == "foo"


# Generated at 2022-06-25 10:38:05.383172
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In arguments
    # Variable (name, value, type)
    var_0 = LookupModule()
    var_1 = 'foo.txt'
    # Variable (name, value, type)
    var_2 = LookupBase()
    var_3 = 'foo.txt'
    # Variable (name, value, type)
    var_4 = LookupModule()
    var_5 = 'foo.txt'
    # Variable (name, value, type)
    var_6 = LookupModule()
    var_7 = 'foo.txt'
    # Variable (name, value, type)
    var_8 = LookupModule()
    var_9 = 'foo.txt'
    # Variable (name, value, type)
    var_10 = LookupModule()
    var_11 = 'foo.txt'
    #

# Generated at 2022-06-25 10:38:12.385981
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_module_0.run(bool_0)
    assert var_0 == None

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:38:21.225958
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:38:28.840269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    searchpath_0 = None
    name_0 = "ansible"
    data_0 = "/home/ansible"
    data_1 = "/home/ansible/files"
    var_0 = []
    for file_0 in data_1:
        var_0.append(file_0)
    for file_0 in data_0:
        var_0.append(file_0)
    ansible_0 = var_0
    vars_0 = {}
    vars_0['ansible_search_path'] = ansible_0
    vars_0['ansible_path'] = ansible_0
    path_0 = "/home/ansible/vars.txt"
    lookupfile_0 = lookup_module_0.find_file_in_search

# Generated at 2022-06-25 10:38:32.765940
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.run(terms=[], variables={})


# Generated at 2022-06-25 10:38:33.987337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()


# Generated at 2022-06-25 10:38:42.775543
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    terms_0 = ['lstrip', 'rstrip', 'terms']
    # Assigning a type to the variable 'variables' (line 160)
    module_type_store.set_type_of(stypy.reporting.localization.Localization(__file__, 160, 4), 'variables', remove_type_from_union(variables_0, *[list_0, dict_0]))
    
    # Call to run(...): (line 160)
    # Processing the call arguments (line 160)
    # Getting the type of 'terms_0' (line 160)
    terms_0_3 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 160, 21), 'terms_0', False)
   

# Generated at 2022-06-25 10:38:49.646457
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    par_0 = ['test_0.py']
    par_1 = None
    par_2 = None
    lookup_module_0.run(par_0, par_1, par_2)
    # assert True
    # assert lookup_module_0.run(par_0, par_1, par_2) == var_0
    raise NotImplementedError("Need to implement test_LookupModule_run")

# Generated at 2022-06-25 10:38:50.794895
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:39:40.349583
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    bool_0 = False
    str_0 = "tests/data/lookup_fixtures/file.txt"
    lookup_run = lookup_module.run(bool_0, str_0)
    assert lookup_run == "this is the contents of the file"

# Generated at 2022-06-25 10:39:42.512710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'foo.txt'
    dict_0 = {}
    var_0 = lookup_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 10:39:54.104051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

if __name__ == '__builtin__':
    def lookup_run(bool_0):
        options = {'rstrip': bool_0, 'lstrip': bool_0}
        lookup_module_0.run(terms=['boolean'], variables={'lookup_file_test': 'boolean'}, **options)
    test_case_0()
else:
    def lookup_run(bool_0):
        options = {'rstrip': bool_0, 'lstrip': bool_0}
        lookup_module_0.run(terms=['boolean'], variables={'lookup_file_test': 'boolean'}, **options)
    test_case_0()

# Generated at 2022-06-25 10:39:55.157641
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	lookup_module_0 = LookupModule()
	bool_0 = False


# Generated at 2022-06-25 10:39:57.038531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    str_0 = "foo.txt"
    str_1 = "bar.txt"
    str_2 = "biz.txt"
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:39:59.129699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = new_instance(LookupModule)
    bool_0 = False
    assert lookup_module_0.run(bool_0) == []

test_case_0()

# Generated at 2022-06-25 10:40:02.575017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_1 = "foo.txt"
    variables_1 = None

    # Invoke method
    result_1 = lookup_module_1.run(terms_1, variables_1)
    assert result_1 == "foo.txt"

# Generated at 2022-06-25 10:40:04.054245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    lookup_module_0.run(bool_0)


# Generated at 2022-06-25 10:40:08.488571
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)

# Generated at 2022-06-25 10:40:15.448031
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 10:42:12.111783
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({})
    str_0 = "mytestfile"
    lookup_module_0.run([str_0])
#if __name__ == '__main__':
#    test_LookupModule_run()

# Generated at 2022-06-25 10:42:18.831979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    # Load module and test function
    lookup_module_1 = LookupModule()
    lookup_loader.add_directory(realpath('../../lookup_plugins'), with_subdir=True)
    # Check value returned by Ansible
    variables_1 = dict()
    lookup_plugin_1 = lookup_loader.get('file')
    lookup_loader.add_directory(realpath('../../lookup_plugins'), with_subdir=True)
    result_1 = lookup_plugin_1.run(variables_1, to_native([]), basedir=realpath('../../lookup_plugins'), variables=variables_1)
    # Check result
    assert result_1 == ""

# Generated at 2022-06-25 10:42:21.910344
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms, variables=None, rstrip=True, lstrip=False) == ret


# Generated at 2022-06-25 10:42:31.932945
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = "str_0"
    bool_0 = False
    dict_0 = dict()
    dict_0["key_0"] = "value_0"
    dict_0["key_1"] = "value_1"
    dict_0["key_2"] = "value_2"
    dict_0["key_3"] = "value_3"
    dict_0["key_4"] = "value_4"
    dict_0["key_5"] = "value_5"
    dict_0["key_6"] = "value_6"
    list_0 = list()
    list_0.append("list_value_0")
    list_0.append("list_value_1")
    list_0.append("list_value_2")

# Generated at 2022-06-25 10:42:39.123742
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = None
    var_2 = []
    var_2.append('/etc/foo.txt')
    lookup_module_1.run(var_1, var_2)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:42:41.296211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    str_0 = 'foo.txt'
    var_0 = lookup_module_0.run(bool_0, str_0)

    assert var_0 == ['The quick brown fox jumps over the lazy dog.']

# Generated at 2022-06-25 10:42:42.844722
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = False
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 10:42:51.838508
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  terms_0 = ["t1.txt"]
  # Call of LookupModule.run
  # [t1.txt]
  lookup_module_0.run(terms_0)
  print("====================")
  terms_1 = ["t2.txt"]
  # Call of LookupModule.run
  # [t2.txt]
  lookup_module_0.run(terms_1)
  print("====================")
  terms_2 = ["t1.txt","t2.txt"]
  # Call of LookupModule.run
  # [t1.txt, t2.txt]
  lookup_module_0.run(terms_2)


test_LookupModule_run()