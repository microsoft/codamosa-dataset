

# Generated at 2022-06-25 10:32:50.782567
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.set_options(dict())
    lookup_module_0.get_options()

    lookup_module_0.run(["file.txt"])

# Generated at 2022-06-25 10:32:54.988490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run('/etc/foo.txt') == None


# Generated at 2022-06-25 10:32:55.891901
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

# Generated at 2022-06-25 10:32:57.864880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """LookupModule.run()"""
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms=None, variables=None)

# Generated at 2022-06-25 10:33:00.039705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True


# Generated at 2022-06-25 10:33:01.557434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = {}
    lookup_module_0.run(terms_0)


# Generated at 2022-06-25 10:33:11.755430
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=None, direct=None)

    # This is not a good value to read from file
    answer_run_1 = lookup_module.run("/tmp/file_read.txt")
    assert isinstance(answer_run_1, list)
    assert answer_run_1 == []

    lookup_module.set_options(var_options=None, direct=None)
    answer_run_2 = lookup_module.run("/tmp/file_read_1.txt")
    assert isinstance(answer_run_2, list)
    assert answer_run_2 == []

# Generated at 2022-06-25 10:33:13.728302
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options({ 'rstrip': True })
    lookup_module_0.set_options({ 'lstrip': False })
    terms_0 = [ 'foo.txt' ]
    variables = {}
    lookup_module_0.run(terms_0, variables)


# Generated at 2022-06-25 10:33:14.756785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:33:20.153530
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test_value']
    assert isinstance(lookup_module_0.run(terms_0), list)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(terms_0)
    terms_1 = ['test_value']
    assert isinstance(lookup_module_1.run(terms_1), list)
    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms_1)


# Generated at 2022-06-25 10:33:29.094448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)
    assert var_0 == ['Hello!\n'], "'Hello!\\n'"

# Generated at 2022-06-25 10:33:39.875312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x05\x83\x9a\xac\x8f\xd8\xc2\x98~\xc3\x7f\x9a\x9d\xb4\xc4\xb7'

# Generated at 2022-06-25 10:33:46.052912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Return value of the method run
    # is of type str, None or None.
    return_value_0 = lookup_module_0.run(
       ['etc/passwd', '/etc/passwd'])
    if str(return_value_0) == '[]':
        display.error('Case 0: Failed')
    else:
        display.notify('Case 0: Passed')


# Generated at 2022-06-25 10:33:51.547827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xbc\xcc\x9e\x92\xaa\xd5\x99\xad\x8c\xad\xa5\xd1\x9f\xdd\x8d\xb7'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['foo'] = 'bar'
    dict_0['lookupfile'] = dict_1
    lookup_module_run_0 = lookup_module_0.run(bytes_0, dict_0)


# Generated at 2022-06-25 10:33:56.797670
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # From Ansible docs:
    #
    # This example demonstrates how to use the M(file) lookup plugin to retrieve the contents of a file.
    #

    import os
    import building
    import configparser

    config = configparser.ConfigParser()
    config.read('../test.ini')
    cfg = config['blah']

    lookup_module_0 = LookupModule()
    terms_0 = [cfg['filename']]
    variables_0 = cfg['variables']
    lookup_module_0.run(terms_0, variables_0)
    lookup_module_0.run(terms_0, variables_0, **kwargs)
    lookup_module_0.run(terms_0, variables_0)
    lookup_module_0.run(terms_0, variables_0, **kwargs)




# Generated at 2022-06-25 10:34:07.016779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    bytes_0 = b'\xffH'
    var_0 = lookup_module_run.run(bytes_0)
    var_1 = lookup_module_run.run(bytes_0)
    var_2 = lookup_module_run.run(bytes_0)
    var_3 = lookup_module_run.run(bytes_0)
    var_4 = lookup_module_run.run(bytes_0)
    var_5 = lookup_module_run.run(bytes_0)
    var_6 = lookup_module_run.run(bytes_0)
    var_7 = lookup_module_run.run(bytes_0)
    var_8 = lookup_module_run.run(bytes_0)

# Generated at 2022-06-25 10:34:11.969931
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)
    var_0 = lookup_module_0.run(bytes_0)


# Generated at 2022-06-25 10:34:21.952068
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = MagicMock()
    lookup_mock.run.return_value = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    lookup_mock.run.return_value = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_mock.run('file', '/etc/hosts')


# Generated at 2022-06-25 10:34:23.460090
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    a = {}
    a.update({'a': 'b'})
    test_case_0()


# Generated at 2022-06-25 10:34:27.067161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_1 = b'#\xa7\x02\x96\xb9\xd8\x1d\xb4\xba\x18\xfa\xcfz\xfc\x19\x97\xab'
    var_1 = lookup_run(bytes_1)


# Generated at 2022-06-25 10:34:37.992202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)
    assert var_0 == 'RFB 003.009\n'

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:34:46.288809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader(loader_0)
    str_0 = 'rstrip'
    bytes_0 = b'\xe0\x1a\x89\x8e'
    str_1 = 'lstrip'
    str_2 = 'files'
    str_3 = '_loader'
    str_4 = '_options'

# Generated at 2022-06-25 10:34:54.263824
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:35:04.831958
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = lookup_module_0.run(bytes_0, var_0)
    assert lookup_0 == None

if __name__ == '__main__':
    from units.mock.loader import DictDataLoader
    from units.mock.lookup_loader import LookupModuleLoader

    loader = DictDataLoader({
        "my_hosts": [
            "foo.bar.com",
            "bar.baz.com",
            "baz.qux.com",
        ]
    })

    lookup_loader = LookupModuleLoader(None, loader=loader)

    my_test = TestLookupModule()

# Generated at 2022-06-25 10:35:10.968546
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)


# Generated at 2022-06-25 10:35:13.443323
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['./terms']
    result = lookup_module.run(terms)
    assert result == ['a\nb\nc\n']


# Generated at 2022-06-25 10:35:24.905398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    variables = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'

    lookup_module_1 = LookupModule()
    bytes_1 = b'\xbbG\x04\xf4\x1f\x88\xdc\xa8\x8a\x1a\xde\xaa\x12K\x90\x98'
    lookup_module_1.run(terms, variables)

    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:35:28.188101
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModuleObj = LookupModule()
    terms = 'foo.txt'
    variables = 'bar.txt'
    retVar = lookupModuleObj.run(terms, variables)
    assert retVar == ['foo.txt', 'bar.txt']


# Generated at 2022-06-25 10:35:33.661170
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test for method run of class LookupModule
    #
    # We want to check if given term will be within variables
    #
    # TERM = "test_value"
    #
    # Fail case
    #
    # assert TERM in variables
    #
    # Success case
    #
    # assert TERM in variables
    assert test_case_0() == 'Success'

# Generated at 2022-06-25 10:35:34.367746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert "append" == lookup.run(['ansible'])


# Generated at 2022-06-25 10:35:53.988988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_0.set_options({'lookup_vars':'./var'})
    lookup_module_1.set_options({'lookup_vars':'./var'})
    lookup_module_2.set_options({'lookup_vars':'./var'})
    lookup_module_3.set_options({'lookup_vars':'./var'})

# Generated at 2022-06-25 10:36:03.872146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    int_0 = lookup_module_3.run(0)
    int_1 = lookup_module_3.run(1)
    int_2 = lookup_module_3.run(2)
    int_3 = lookup_module_3.run(3)
    int_4 = lookup_module_3.run(4)
    int_5 = lookup_module_3.run(5)
    int_6 = lookup_module_3.run(6)
    int_7 = lookup_module_3.run(7)
    int_8 = lookup_module_3.run(8)
    int_9 = lookup_module_3.run(9)
    int_10 = lookup_module_3.run(10)

# Generated at 2022-06-25 10:36:11.951900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict = dict()
    dict['rstrip'] = False
    dict['lstrip'] = False
    dict['_orig_basename'] = 'bar.txt'
    var_1 = lookup_module_0.run([dict], None)
    assert var_1 == ['bar contents\n']
    dict['_terms'] = ['foo.txt']
    var_2 = lookup_module_0.run([dict], None)
    assert var_2 == ['foo contents']

# Generated at 2022-06-25 10:36:17.767598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'

# Generated at 2022-06-25 10:36:21.400231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)
    var_1 = lookup_run(var_0)

# Generated at 2022-06-25 10:36:31.081321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    var_5 = to_text(b'\r\x9f\xb0\x00\x0e\xe1\xe2M\x04\xd0\x03\xa8\xe9\x9f\x1b2\x0e\n\x83\x08%\xdf\xd6\x81\x96\x02\xfa\xf1\x8a\x1c\x1e\xcc\xdc\xc6\xad\x9b\x0f\xe8}\xeb', errors='surrogate_or_strict')

# Generated at 2022-06-25 10:36:31.925084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  pass


# Generated at 2022-06-25 10:36:41.932977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:36:43.774167
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None, **kwargs)

# Generated at 2022-06-25 10:36:49.302935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x9f\x08\x91\x1b;\xf8\x86\x187\x0e\x010\x12\x89\x00\xb6'
    assert lookup_run(bytes_0) == 42


# Generated at 2022-06-25 10:37:13.508649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert(lookup_module_0.run() == None)

# Generated at 2022-06-25 10:37:18.811770
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)


import random


# Lookup module run method

# Generated at 2022-06-25 10:37:20.478143
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Setup

    # Execution: If the lookup module is valid
    test_case_0()



# Generated at 2022-06-25 10:37:28.823996
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_1 = lookup_module_0.run(bytes_0)

if __name__ == '__main__':
    test_LookupModule_run()
    test_case_0()

# Generated at 2022-06-25 10:37:34.293649
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)

# Generated at 2022-06-25 10:37:38.365902
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:37:41.953482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)
    assert var_0 > str()


# Generated at 2022-06-25 10:37:44.500401
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


# Generated at 2022-06-25 10:37:53.901753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = [
    ('192.168.1.1',),
    ('192.168.2.2',),
    ('192.168.3.3',),
    ('192.168.4.4',),
    ('192.168.5.5',),
    ('192.168.6.6',),
    ('192.168.7.7',),
    ('192.168.8.8',),
    ('192.168.9.9',),
    ('192.168.10.10',),
    ('192.168.11.11',),
    ]

    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:38:02.324967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(['/etc/foo.txt']) == ['']
    assert lookup_module_0.run(['randomfile']) == ['']
    assert lookup_module_0.run(['/non-existant/foo.txt']) == ['']
    assert lookup_module_0.run(['/etc/passwd']) == ['']
    assert lookup_module_0.run(['/etc/passwd']) == ['']
    assert lookup_module_0.run(['/etc/passwd']) == ['']
    assert lookup_module_0.run(['/etc/passwd']) == ['']
    assert lookup_module_0.run(['/etc/passwd']) == ['']
   

# Generated at 2022-06-25 10:38:48.948130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)



# Generated at 2022-06-25 10:38:57.436712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_run(bytes_0)
    assert '\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d' == var_0
    return None


# Generated at 2022-06-25 10:38:59.023600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    # Rreplace with your code here
    raise Exception('Test not implemented')


# Generated at 2022-06-25 10:39:05.471538
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:39:15.709328
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'

    var_0 = lookup_module_0.run(bytes_0)
    assert var_0 == [""]

    bytes_1 = b'\x8e\x03\xd1\xab\x87\x9d-\xd7\xfc\xee\x93\xfc8\x03\xc0\xab\xf6'
    var_1 = lookup_module_0.run(bytes_1)
    assert var_1 == [""]


# Generated at 2022-06-25 10:39:23.207426
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    config_module = ConfigParser()
    option_0 = config_module.get('term', 'option')
    config_module.add_section('module')
    option_1 = config_module.get('section', 'options')
    terms_1 = []
    terms_2 = []
    terms_3 = []
    terms_4 = []
    terms_5 = []
    terms_6 = []
    terms_7 = []
    terms_8 = []
    terms_9 = []
    terms_10 = []
    terms_11 = []
    terms_12 = []
    terms_13 = []
    terms_14 = []
    terms_15 = []
    terms_16 = []
    terms_17 = []
    terms_18 = []
    terms_19 = []
   

# Generated at 2022-06-25 10:39:28.306312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_3 = LookupModule()
    bytes_3 = b'\x07\xe7\x87\x9f\xb3\x15\xf3\x00\xd2\x84\x03\xc0\xce\xa9tH'
    var_0 = lookup_run(bytes_3)


# Generated at 2022-06-25 10:39:31.895018
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
    var_0 = lookup_module_0.run(bytes_0)

# Generated at 2022-06-25 10:39:39.550008
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    str_0 = '\xe4\xb7\xd5\x1b\xcd\x92\xe7\x84\xf4\x03\xfb\xd7'
    str_1 = '5\xa0\x91\xc4\x15{\xda\x07\xbb\x11\x9e\xfc\x1b\x8f\xb3'
    bytes_0 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'

# Generated at 2022-06-25 10:39:45.897760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_1 = bytes_0
    var_2 = lookup_run(var_1)
    var_3 = "popen"
    var_4 = "config"
    var_5 = "6"
    var_6 = "omitted"
    var_7 = var_6
    var_8 = "y"
    var_9 = "2"
    var_10 = "omitted"
    var_11 = var_10
    var_12 = var_7
    var_13 = var_9
    var_14 = var_11
    var_15 = "2"
    var_16 = var_15
    var_17 = "omitted"
    var_18 = var_17
    var_19 = var_16
    var_20 = var_

# Generated at 2022-06-25 10:41:39.954387
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x8b\xad\xca\xdf\xb6\x8c"\x16\x83\x95\xda\x12\xce\xba\x87\xcf\xaa\xeb\x1c'
    var_0 = lookup_run(bytes_0)
    assert var_0 == 'foobar'


# Generated at 2022-06-25 10:41:46.429154
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_1 = LookupModule()
  bytes_1 = b'\xb5C\xbaf5\xf7\x97\x18\x82\xa31\xe7/T\x03\xf8\x0f2\xd8\x9d'
  lookup_module_1.run(lookup_module_1, bytes_1)



# Generated at 2022-06-25 10:41:47.456297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms = '', variables = None)


# Generated at 2022-06-25 10:41:48.920891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_instance_1 = lookup_module_1.run(terms=['variable1'])


# Generated at 2022-06-25 10:41:54.251229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = list()
    terms.append(b'/usr/bin/git')
    terms.append(b'../.git/HEAD')
    terms.append(b'../../../.git/HEAD')
    variables = dict()
    variables['bootstrap_password'] = b'b*\x19\xc6'
    variables['run_once'] = True
    variables['install_virtualenv_arguments'] = b'\xc7\x8b\xae\x05\xb1\x80\xe8\xbc\x10\xbc\x1d\xa8'
    variables['ansible_managed'] = b'\x88\x87\xab\xd5@\xc4\x95\xba\xe7\x11\xf9\x1d\xac\x07\xac'
   

# Generated at 2022-06-25 10:41:57.386121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xe8\xd0\x93\x9f\xf0\x85\xc1\x93\xe2\xb5\xa0\xdd\x19\xac\x9b\xfc\xa4j<\x83\xd4\xfd\xe7\xd3\xde\x17\xd9\x8a\xfa\x95\xc4\x84\xb7>\xfc\x06\x87\x9c\x81\xb1\xc1\xef\x87\x8a\x1d\xa7\xde'
    var_0 = lookup_run(bytes_0)


# Generated at 2022-06-25 10:42:02.694214
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = '\xd6\x02\x9a\x00\xc0\x00\x95\xeeb\x80\x00\x01d\x8a\x00\x01\x006\x80\xff<\x01\xe0{\xeeb\x80\x00\x01d\x8a\x00\x01\x006\x80\xff<\x01\xe0\x00\x00$\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-25 10:42:03.685264
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()



# Generated at 2022-06-25 10:42:07.336812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'test'
    var_0 = lookup_run(bytes_0)
    assert var_0 == "test"


# Generated at 2022-06-25 10:42:12.299134
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_run = LookupModule.run
    lookup_run_0 = lookup_run
    lookup_module_0 = lookup_run_0
