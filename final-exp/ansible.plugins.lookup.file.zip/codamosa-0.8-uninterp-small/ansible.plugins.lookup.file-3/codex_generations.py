

# Generated at 2022-06-25 10:32:52.934063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    f = open("file.txt", "w")
    f.write("Hello World")
    f.close()
    lookup_module.run("file.txt", rstrip=False, lstrip=False)
    os.remove("file.txt")

# Generated at 2022-06-25 10:32:53.543576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True is not False

# Generated at 2022-06-25 10:32:55.228087
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True

# Generated at 2022-06-25 10:33:02.192532
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    lookup_module_0.run(['abc', 'abc'], ['abc', 'abc'], lstrip=['abc', 'abc'], rstrip=['abc', 'abc'])
    lookup_module_0.run(['abc', 'abc'], ['abc', 'abc'], lstrip=['abc', 'abc'], rstrip=['abc', 'abc'])
    lookup_module_0.run(['abc', 'abc'], ['abc', 'abc'], lstrip=['abc', 'abc'], rstrip=['abc', 'abc'])



# Generated at 2022-06-25 10:33:05.513225
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 10:33:08.985776
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_1 = LookupModule()
    assert isinstance(lookup_module_1, LookupBase)

    assert isinstance(lookup_module_1, LookupModule)



# Generated at 2022-06-25 10:33:10.139484
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run([])

# Generated at 2022-06-25 10:33:17.657827
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms = [
        "/etc/hosts",
        "other.txt",
        "/usr/share/ansible/distro_facts/other_facts.py"
    ]
    variables = dict()
    kwargs = dict(
        os_module="linux"
    )
    ret = lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:33:22.610923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_file = '/tmp/test_file'
    expected_data = b"hello world\n"
    f = open(test_file, 'wb')
    f.write(expected_data)
    f.close()

    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader(None)
    lookup_module_1.set_basedir(None)

    ret = lookup_module_1.run([test_file], {})
    assert ret == [expected_data]

# Generated at 2022-06-25 10:33:30.930122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables = {}
    kwargs = {}
    expect = []
    actual = lookup_module_0.run(terms_0)
    assert actual == expect, actual
    terms_1 = [
        'test/test',
        'test/example',
        'test/test',
        'test/example',
        'test/test'
    ]
    variables = {}
    kwargs = {}
    expect = []
    actual = lookup_module_0.run(terms_1)
    assert actual == expect, actual



# Generated at 2022-06-25 10:33:39.078141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:33:42.751402
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '}'
    int_0 = 1844
    terms_0 = "'"
    var_0 = lookup_run(terms_0, variables=int_0)

if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:50.300292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Generate and read in test data
    x = '''{\n'''
    y = '''.txt\n'''
    z = random_string_generator(42, string.ascii_letters)
    w = []
    for i in range(0, random.randint(1, 10)):
        w.append(random.randint(1, 45))
    # Define the function inputs
    terms = x
    variables = {y:z}
    kwargs = {w:w}
    # Run the Ansible module
    r = LookupModule(terms, variables, kwargs)

    # run the Ansible module
    if r.run == str:
        return True
    else:
        return False


# Generated at 2022-06-25 10:33:57.247974
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    variable = 42
    lst = [['value_01']]
    lst_0 = [1]
    lookup_module_0 = LookupModule(lst_0)
    str_0 = 'value_02'
    list_0 = lookup_module_0.run(str_0)
    assert list_0 == [1]
    str_1 = 'value_03'
    list_1 = lookup_module_0.run(str_1)
    assert list_1 == [1]
    str_2 = 'value_04'
    list_2 = lookup_module_0.run(str_2)
    assert list_2 == [1]
    str_3 = 'value_05'
    int_0 = 1
    lookup_module_1 = LookupModule(int_0)
    list_3

# Generated at 2022-06-25 10:34:02.141469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # checks if run of LookupModule called with parameters does work properly
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:34:05.842559
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule([])
    lookup_module_1 = LookupModule([])
    lookup_get_option_0 = lookup_module_0.get_option([], dict(), dict())
    lookup_get_option_1 = lookup_module_1.get_option([], dict(), dict())
    lookup_module_2 = LookupModule([])
    lookup_module_3 = LookupModule([])
    lookup_set_option_0 = lookup_module_2.set_option([], dict(), dict())
    lookup_set_option_1 = lookup_module_3.set_option([], dict(), dict())
    lookup_module_4 = LookupModule([])
    lookup_module_5 = LookupModule([])

# Generated at 2022-06-25 10:34:15.057590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'jA@ '
    int_0 = 8266
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)
    assert var_0 == None
    str_0 = '!+{'
    int_0 = 8072
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)
    assert var_0 == None
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)
    assert var_0 == None
    str_0 = 'u)7'
    int_0 = 1172

# Generated at 2022-06-25 10:34:18.492176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1904
    str_0 = '}'
    LookupModule_0 = LookupModule(int_0)
    LookupModule_0.run(str_0)

# Generated at 2022-06-25 10:34:21.167337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert(False) # TODO: Add test cases, this method is not tested.


# Generated at 2022-06-25 10:34:23.687841
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 276
    str_0 = '#'
    lookup_module_0 = LookupModule(int_0)
    test_dict = {}
    lookup_run(str_0)


# Generated at 2022-06-25 10:34:35.333343
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:43.228163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '#LookupModule_run'
    int_0 = 1305
    list_0 = []
    dict_0 = {
        'a': lookup_module_0, 
        'b': str_0, 
        'c': int_0, 
        'd': list_0, 
    }
    assert lookup_module_0.run(str_0, dict_0)

test_LookupModule_run()

# Generated at 2022-06-25 10:34:52.221164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """Unit test for method run of class LookupModule"""
    lookup_module_0 = LookupModule()
    int_0 = 9672
    str_0 = 'E8@v'
    str_1 = ':cW<'
    int_1 = 8175
    dict_0 = dict(a='z\\m,^', b=']@O', c=9138)
    str_2 = 'u]'
    str_3 = '6M3qI'
    str_4 = '9^j'
    str_5 = 'R=r'
    str_6 = 'N'
    str_7 = '/9M'
    str_8 = '=A'
    str_9 = 'K!'
    str_10 = 'm@'

# Generated at 2022-06-25 10:34:55.961853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'c=}-F2U4xB]9XLE#_yb?I'
    int_0 = 775
    list_0 = []
    dict_0 = {}
    list_1 = []
    int_1 = 0
    while int_1 < int_0:
        dict_0[str_0] = ''
        int_1 += 1
    list_0.append(dict_0)
    lookup_module_0 = LookupModule(list_0)
    var_0 = lookup_module_0.__init__(str_0)
    var_1 = lookup_module_0.run(list_1)
    return var_1

# Generated at 2022-06-25 10:35:01.054282
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module_0 = AnsibleError('AnsibleError')
    int_0 = 789
    str_0 = 'UU'
    module_1 = LookupModule(str_0)
    str_1 = 'p4'
    lookup_run(str_1)
    #str_2 = ' 
    #str_3 = ' 
    #str_4 = ' 


# Generated at 2022-06-25 10:35:03.027321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 9039
    lookup_module_0 = LookupModule(int_0)
    str_0 = 'WIJ'
    int_1 = 34
    var_0 = lookup_run(str_0)
    var_1 = lookup_run(int_1)


# Generated at 2022-06-25 10:35:07.371732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms, variables=None, **kwargs)


# Generated at 2022-06-25 10:35:16.252941
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)

    str_1 = '}'
    int_1 = 1916
    lookup_module_1 = LookupModule(int_1)
    var_1 = lookup_run(str_1)

    str_2 = '}'
    int_2 = 1916
    lookup_module_2 = LookupModule(int_2)
    var_2 = lookup_run(str_2)

    str_3 = '}'
    int_3 = 1916
    lookup_module_3 = LookupModule(int_3)
    var_3 = lookup_run(str_3)

# Generated at 2022-06-25 10:35:19.222962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:35:22.376933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(str.isspace(str_0))
    try:
        test_case_0()
    except AssertionError:
        return False
    return True

# Generated at 2022-06-25 10:35:37.520820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '|'
    lookup_module_0 = LookupModule(str_0)
    lookup_module_0.run()


# Generated at 2022-06-25 10:35:45.094336
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = '*'
    tuple_0 = (var_0,)
    lookup_module_0 = LookupModule(tuple_0, var_0)
    var_0 = lookup_module_0.run(tuple_0, var_0)

# Generated at 2022-06-25 10:35:53.978513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 2917
    lstrip_0 = '\x8b\xf1'
    lstrip_1 = '\x8b\xf1'
    lstrip_2 = '\x8b\xf1'
    lstrip_3 = '\x8b\xf1'
    lstrip_4 = '\x8b\xf1'
    lstrip_5 = '\x8b\xf1'
    lstrip_6 = '\x8b\xf1'

    str_0 = '|'
    str_1 = '|'
    str_2 = '|'
    str_3 = '|'
    str_4 = '|'
    str_5 = '|'
    str_6 = '|'
    lookup_module_0 = LookupModule(int_0)


# Generated at 2022-06-25 10:35:55.012313
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO: write unit test for method run of class LookupModule
    pass


# Generated at 2022-06-25 10:36:00.604453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test 1
    # str_0 = '}'
    # int_0 = 1916
    # lookup_module_0 = LookupModule(int_0)
    # var_0 = lookup_run(str_0)
    # assert var_0 == '}'
    assert True

# Generated at 2022-06-25 10:36:03.750013
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test for a set of the given arguments
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    assert_equal(lookup_module_0.run(str_0), 'B{}')

# Generated at 2022-06-25 10:36:14.274897
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms_0 = '}'
    methods_0 = lookup_module_1.run(terms_0)
    test_0_0 = dict()
    test_0_1 = dict()
    test_0_2 = dict()
    test_0_3 = dict()
    test_0_0.update({'ldap': '', 'client': '', 'client_path': '/usr/local/lib', 'server': '', 'server_path': '/usr/local/lib', 'lookup': '', 'lookup_path': '/usr/local/lib', 'module_utils': '', 'module_utils_path': '/usr/lib/python3.8/site-packages/ansible/module_utils'})

# Generated at 2022-06-25 10:36:19.440454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:36:25.448221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'a'
    str_1 = '1'
    lookup_module_0 = LookupModule('b')
    result = lookup_module_0.run(str_0, {}, terms=str_1)
    assert result == ''


# Generated at 2022-06-25 10:36:27.762552
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test_case_0
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:36:55.501332
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'f'
    int_0 = 1924
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)
    if var_0:
        raise Exception("Unexpected: %s" % var_0)


# Generated at 2022-06-25 10:37:04.948190
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'Be9q'
    str_1 = 'C'
    str_2 = 'Zv{nW@V'
    str_3 = '7\u0015'
    str_4 = ']\x1c'
    str_5 = '\x02X'
    str_6 = 'b\x13'
    str_7 = '\nC'
    str_8 = '\x04\x1f'
    str_9 = '\x10'
    str_10 = '\x19q'
    str_11 = '='
    str_12 = '4\u0013'
    int_0 = 1915

# Generated at 2022-06-25 10:37:10.661851
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = {1, 2, 3}
    variables = {4, 5, 6}
    int_0 = 7
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_module_0.run(terms, variables)
    assert var_0 == [], 'Failed test'


# Generated at 2022-06-25 10:37:15.387132
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 474
    lookup_module_0 = LookupModule(int_0)
    str_0 = '\x6c'
    var_0 = lookup_module_0.run(str_0)
    assert var_0 == '}'

# Generated at 2022-06-25 10:37:26.795488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 921
    str_0 = 'lstrip'
    lookup_module_0 = LookupModule(int_0)
    str_1 = 'variable(default)'
    str_2 = 'files'
    str_3 = 'files'
    str_4 = 'files'
    lookup_module_1 = LookupModule(int_0)
    str_5 = 'files'
    str_6 = 'files'
    lookup_module_2 = LookupModule(int_0)
    str_7 = 'files'
    str_8 = 'files'
    str_9 = 'files'
    lookup_module_3 = LookupModule(int_0)
    str_10 = 'files'
    str_11 = 'files'
    str_12 = 'files'

# Generated at 2022-06-25 10:37:32.572613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/etc/foo.txt'
    int_0 = 0
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_module_0.run(str_0)
    assert var_0 == 'test', 'expected test, got ' + var_0

# Generated at 2022-06-25 10:37:34.229616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(int())
    var_0 = run(str(), str())



# Generated at 2022-06-25 10:37:44.139668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = ']~'
    str_1 = str_0[1:]
    str_2 = '#'
    str_3 = '{f'
    str_4 = ':a'
    str_5 = 'k'
    str_6 = '}'
    str_7 = '2'
    str_8 = 'y'
    str_9 = '~p'
    str_10 = 'h'
    str_11 = 'Kb'
    str_12 = 'x'
    str_13 = '3'
    str_14 = 'S'
    str_15 = 'R'
    str_16 = 's'
    str_17 = 'B'
    str_18 = '#'
    str_19 = '1'
    str_20 = 'Y'
    str

# Generated at 2022-06-25 10:37:46.630531
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "dns/ansible/example.com/A.json"
    variables = None
    kwargs = None
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms,variables,kwargs)
    print(result)

# Generated at 2022-06-25 10:37:52.610051
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 1918
    lookup_module_0 = LookupModule(int_0)
    arg_0 = ['']
    arg_1 = {'file': 'biz.txt', 'lstrip': True, 'rstrip': True}
    result_0 = lookup_module_0.run(arg_0, arg_1)
    assert result_0 == ['']



# Generated at 2022-06-25 10:38:46.220599
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '{'
    int_0 = 636
    str_1 = 'foo.txt'
    int_1 = 603
    str_2 = 'files'
    str_3 = '{'
    str_4 = '{'
    lookup_module_0.run(str_0, str_1, int_0)
    lookup_module_0.run(str_2, str_3, int_1)
    lookup_module_0.run(str_4, str_2, str_3)

# Generated at 2022-06-25 10:38:48.251054
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:38:54.667202
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Set test values
    terms = [terms]
    variables = {}
    direct = {}

    # Instantiate an instance of the LookupModule class
    self.lookup_module_0 = LookupModule()

    # Test the run method
    lookup_run(terms, variables, direct)


# Generated at 2022-06-25 10:39:00.352209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '_'
    str_1 = 'z'
    str_2 = 'j'
    str_3 = '8xc'
    int_0 = -1235089482
    str_4 = '-'
    str_5 = 'j'
    str_6 = '/'
    ret_0 = lookup_module_0.run(str_0, str_1, str_2, str_3, int_0, str_4, str_5, str_6)

# Generated at 2022-06-25 10:39:05.389643
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(str_0, int_0)

# Generated at 2022-06-25 10:39:09.569512
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Test lookup module")
    test_case_0()

# Generated at 2022-06-25 10:39:11.569978
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # test case
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)
    assert var_0
    assert var_0 is not None


# Generated at 2022-06-25 10:39:13.417389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:39:20.888288
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '){(v+}oqJl2N)w[,6{o+$Ea/c%5'
    int_0 = -7701
    bool_0 = True
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_module_0.run(str_0, bool_0)
    print(var_0)


# Generated at 2022-06-25 10:39:23.833962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)


# Generated at 2022-06-25 10:41:16.869590
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = False
    var_1 = True
    lookup_module_0 = LookupModule(var_0)
    lookup_module_1 = LookupModule(var_1)
    int_0 = -3
    str_0 = '}'
    str_1 = '}'
    ret_0 = lookup_module_0.run(str_0, int_0)
    assert ret_0[0] == str_1


# Generated at 2022-06-25 10:41:20.340592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:41:27.025347
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'h'
    char_0 = '8'
    lookup_module_0 = LookupModule(char_0)
    var_0 = lookup_run(str_0)
    str_1 = 'N'
    char_1 = 'N'
    lookup_module_1 = LookupModule(char_1)
    var_1 = lookup_run(str_1)
    str_2 = '}'
    int_2 = 1916
    lookup_module_2 = LookupModule(int_2)
    var_2 = lookup_run(str_2)
    str_3 = 'Q'
    char_3 = 'Z'
    lookup_module_3 = LookupModule(char_3)
    var_3 = lookup_run(str_3)
    str_4 = 'Q'


# Generated at 2022-06-25 10:41:28.027977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # self.run('/etc/foo.txt')
    # assertEquals('{"greeting": "hello world"}', file_0)
    pass


# Generated at 2022-06-25 10:41:29.952256
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_4 = LookupModule()
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    lookup_module_1 = lookup_module_0.run(str_0)
    lookup_module_4.run(str_0, lookup_module_1)


# Generated at 2022-06-25 10:41:31.490295
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    string = ','
    int = 4713
    module = LookupModule(int)
    list = module.run(string)

    assert list == None, "Expected: %s, Actual: %s" % (None, list)


# Generated at 2022-06-25 10:41:32.569309
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = '}'
    lookup_module_0.run(var_0)

# Generated at 2022-06-25 10:41:38.449147
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '}'
    int_0 = 1916
    lookup_module_0 = LookupModule(int_0)
    var_0 = lookup_run(str_0)
    var_1 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:41:43.805312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:41:49.143423
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '┼┐'
    int_0 = 0
    lookup_module_0 = LookupModule(int_0)
    lookup_module_0.run(str_0)
    assert lookup_module_0.run(str_0) == '┼┐'