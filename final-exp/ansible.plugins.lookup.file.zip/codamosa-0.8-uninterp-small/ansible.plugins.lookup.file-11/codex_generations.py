

# Generated at 2022-06-25 10:32:51.031312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(["/etc/foo.txt"]) == []


# Generated at 2022-06-25 10:33:02.353231
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options()
    lookup_module_2 = LookupModule()
    lookup_module_2.set_options()
    lookup_module_3 = LookupModule()
    lookup_module_3.set_options()
    lookup_module_4 = LookupModule()
    lookup_module_4.set_options()
    lookup_module_5 = LookupModule()
    lookup_module_5.set_options()
    lookup_module_6 = LookupModule()
    lookup_module_6.set_options()
    lookup_module_7 = LookupModule()
    lookup_module_7.set_options()

# Generated at 2022-06-25 10:33:13.459017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Get the content of files and returns it as list.

# Generated at 2022-06-25 10:33:21.906434
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("\n\n\n\t\t *****\nTesting run(terms, variables=None, **kwargs) of class LookupModule\n\t\t*****")
    
    # test case 1
    print("\n\t\tTest Case 1\n")
    lookup_module_1 = LookupModule()
    lookup_module_1.run('/etc/hosts')

    # test case 2
    print("\n\t\tTest Case 2\n")
    lookup_module_2 = LookupModule()

# Generated at 2022-06-25 10:33:30.156725
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader()
    lookup_module_1._loader.set_basedir()
    lookup_module_1.set_options(direct={})
    lookup_module_1._templar = None
    lookup_module_1.set_environment()
    terms_1 = [u'/etc/ansible/hosts']
    ret_1 = lookup_module_1.run(terms_1, variables=None)
    assert ret_1 == ['localhost']


# Generated at 2022-06-25 10:33:32.483790
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ['lookup_test_file_0']
    variables = {}

    ret = lookup_module_0.run(terms, variables=variables)

    assert 1 == len(ret)

# Generated at 2022-06-25 10:33:37.132495
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['test/resources/test_file.txt', 'test/resources/test_file.txt']
    variables_0 = {}
    ret = lookup_module_0.run(terms_0, variables_0)
    assert len(ret) == 2
    assert ret[0] == 'Hello world'
    assert ret[1] == 'Hello world'

# Generated at 2022-06-25 10:33:46.667121
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(var_options=None, direct=None)
    lookup_module_1._templar = ansible.template.Template()
    lookup_module_1._loader = ansible.parsing.dataloader.DataLoader()
    lookup_module_1._display = ansible.utils.display.Display()
    lookup_module_1._env = ansible.utils.unsafe_proxy.UnsafeProxy({})
    lookup_module_1._fail_on_undefined = ansible.utils.unsafe_proxy.UnsafeProxy(False)

# Generated at 2022-06-25 10:33:48.096757
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    assert ('hello world' == lookup_module.run("hello.txt"))


# Generated at 2022-06-25 10:33:50.615752
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    # The method run's body is empty
    # <insert your test here>


# Generated at 2022-06-25 10:34:06.237161
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    file_1 = '/etc/ansible/roles/fake_role/vars/main.yml'
    lookup_module_0.run([file_1])


if __name__ == "__main__":
    #test_LookupModule_run()
    lookup_module_0 = LookupModule()
    #file_1 = '/etc/ansible/roles/fake_role/vars/main.yml'
    #lookup_module_0.run([file_1])
    file_1 = '../../../../../../../../../../../../../etc/passwd'
    lookup_module_0.run([file_1])

# Generated at 2022-06-25 10:34:17.356455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_file_path_0 = "ansible/plugins/lookup/file.py"

    test_term_0 = "test_term"

    test_variables_0 = ["test_variables"]

    test_rstrip_0 = True

    test_lstrip_0 = False

    test_kwargs_0 = {"test_kwargs": "test_kwargs"}

    test_options_0 = {"var_options": test_variables_0, "direct": test_kwargs_0}

    test_loader_loader_get_file_contents_0 = ["test_loader_loader_get_file_contents", "test_loader_loader_get_file_contents"]

    # Parameters
    test_terms_0 = [test_term_0]

# Generated at 2022-06-25 10:34:18.852389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_run = LookupModule()
    assert True == lookup_module_run.run


# Generated at 2022-06-25 10:34:26.728497
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    # test no args
    with pytest.raises(AnsibleError):
        lookup_module_1.run([], dict())

    # test no file
    with pytest.raises(AnsibleError):
        lookup_module_1.run(["/path/to/file.txt"], dict())

    # test file exists
    data = "foo"
    with tempfile.NamedTemporaryFile(mode="w") as f:
        f.write(data)
        f.flush()
        result = lookup_module_1.run([f.name], dict())
        assert result[0] == data

# Generated at 2022-06-25 10:34:37.512850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [ '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '' ]
    variables_0 = None
    kwargs_0 = {}
    kwargs_0['lstrip'] = False
    kwargs_0['rstrip'] = True
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)

# Generated at 2022-06-25 10:34:42.921439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.set_options({'_raw_params': 'C:\\Users\\Dell\\Desktop\\Ansible_Automation\\ansible.cfg', '_uses_shell': False}, direct={})
    lookup_module_0.run(['ansible.cfg'])


# Generated at 2022-06-25 10:34:49.364639
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.find_file_in_search_path = MagicMock()
    lookup_module_0.find_file_in_search_path.return_value = None
    lookup_module_0._loader = MagicMock()
    lookup_module_0._loader._get_file_contents = MagicMock(return_value=('', 0))
    assert lookup_module_0.run(terms=['', '', '', ''], variables='') == []

# Generated at 2022-06-25 10:34:54.381836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    filename = 'C:\\Users\\RHITVIK~1.DES\\AppData\\Local\\Temp\\tmp_fpr5x5'
    term = '/etc/passwd'
    terms = [
        '/etc/passwd',
        'bar.txt'
    ]
    variables = {
        'ansible_check_mode': False,
        'ansible_loop_var': 'item',
        'ansible_play_batch': [
            '/etc/passwd',
            'bar.txt'
        ],
        'ansible_play_hosts_all': [
            'localhost'
        ],
        'ansible_play_hosts_count': 1,
        'ansible_play_hosts_remaining': [
            'localhost'
        ]
    }
    # Create an object of the class.
   

# Generated at 2022-06-25 10:34:56.231570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["/path/to/file"])

# Generated at 2022-06-25 10:34:58.752614
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ["/etc/hosts", "myhosts"]
    lookup_module.run(terms)


# Generated at 2022-06-25 10:35:12.944635
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arg0 = ['hosts']
    lookup_module_0.run(arg0)
    arg0 = ['hosts']
    lookup_module_0.run(arg0)

# Generated at 2022-06-25 10:35:24.368999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    testcases = [
        (  # First testcase
            {
                'terms': ['terms_0'],
                'variables': 'variables_0'
            },
            [
                'ret_0'
            ]
        ),
        (  # Second testcase
            {
                'terms': ['terms_1'],
                'variables': 'variables_1'
            },
            [
                'ret_1'
            ]
        ),
        (  # Third testcase
            {
                'terms': ['terms_2'],
                'variables': 'variables_2'
            },
            [
                'ret_2'
            ]
        ),
    ]

    # Iterate over testcases
    # Enclosing function scope maintains loop variables'

# Generated at 2022-06-25 10:35:28.446437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None # It's a mock
    variables = None # It's a mock
    kwargs = {} # It's a mock
    try:
        result = lookup_module_0.run(terms, variables, **kwargs)
        assert True
    except AnsibleError as e:
        print("AnsibleError: %s" % e.message)
        assert False

# Generated at 2022-06-25 10:35:34.851365
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    print("test_LookupModule_run")
    # TODO: Call the run method of lookup_module_0
    # TEST_CASE_1
    # Assign result to variables: test_case_1_result, test_case_1_error
    # print("Result: " + test_case_1_result)
    # print("Error: " + tes

# Generated at 2022-06-25 10:35:42.807469
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    result_0 = lookup_module_0.run(terms_0, variables_0, **variables_0)
    assert result_0 == [], (result_0, [])
    terms_1 = ['foo', 'bar']
    variables_1 = {}
    result_1 = lookup_module_0.run(terms_1, variables_1, **variables_1)
    assert result_1 == [], (result_1, [])
    terms_2 = ['foo', 'bar']
    variables_2 = {}
    result_2 = lookup_module_0.run(terms_2, variables_2, **variables_2)
    assert result_2 == [], (result_2, [])
    terms_

# Generated at 2022-06-25 10:35:53.842414
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['lookup_terms_0']

# Generated at 2022-06-25 10:36:00.347140
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.get_option = lambda x: 'foo'
    lookup_module_0.find_file_in_search_path = lambda x, y, z: 'foo'
    lookup_module_0._loader = 'foo'
    lookup_module_0._loader._get_file_contents = lambda x: 'foo'
    lookup_module_0.get_option = lambda x: 'foo'
    lookup_module_0.get_option = lambda x: 'foo'
    lookup_module_0._loader = 'foo'
    lookup_module_0._loader._get_file_contents = lambda x: (['list item'], 'foo')
    lookup_module_0.get_option = lambda x: 'foo'
    lookup_module_0.get_

# Generated at 2022-06-25 10:36:06.827209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  lookup_module.set_loader({'_get_file_contents': lambda x: ('Lorem\nipsum\ndolor', '')})
  r = lookup_module.run(['foo'], {}, lstrip=True, rstrip=True)
  assert r == ['Lorem\nipsum\ndolor']


# Generated at 2022-06-25 10:36:16.662904
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # set up object
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options(None, direct={'lstrip': True, 'rstrip': True})

    # set up tests
    # test 1
    # call run with correct parameters
    lookup_module_1._loader = Mock_LookupBase__loader()
    terms_1 = ['file1']

    assert lookup_module_1.run(terms_1) == ['testfile1']

    # test 2
    # call run with correct parameters
    lookup_module_1._loader = Mock_LookupBase__loader()
    terms_2 = ['file2']

    assert lookup_module_1.run(terms_2) == ['testfile2']

    # test 3
    # call run with correct parameters
    lookup_module_1._loader = Mock

# Generated at 2022-06-25 10:36:22.252970
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [["/etc/foo.txt"], ["/etc/bar.txt"]]
    variables = {"test_key1": "test_value1", "test_key2": "test_value2"}
    direct = {"rstrip": True}
    lookup_module = LookupModule()
    lookup_module.set_options(var_options=variables, direct=direct)
    lookup_module.run(terms, variables)



# Generated at 2022-06-25 10:36:54.194509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    test_case_0_terms = ['test_file1.txt', 'test_file2.txt']
    # Make sure test files exist
    create_file(test_case_0_terms[0])
    create_file(test_case_0_terms[1])
    test_case_0_variables = {}
    test_case_0_kwargs = {'lstrip': False, 'rstrip': False}
    try:
        lookup_module_0.run(terms=test_case_0_terms, variables=test_case_0_variables, **test_case_0_kwargs)
    except AnsibleError as ansible_error_1:
        print("AnsibleError: {}".format(ansible_error_1))
        raise AssertionError

# Generated at 2022-06-25 10:36:59.014791
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [ '/etc/foo.txt' ]
    variables = {  }
    kwargs = {  }
    assert lookup_module_1.run(terms, variables, **kwargs) == [ None ]


# Generated at 2022-06-25 10:37:02.359197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    assert to_bytes(lookup_module_0.run(["~/foo.txt"], {"_ansible_tmpdir": "."}), errors='surrogate_or_strict') == b"contents of foo.txt\n"

# Generated at 2022-06-25 10:37:05.068470
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Return the contents from a file on the Ansible controller's file system.
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    ret = lookup_module_0.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:37:09.871417
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Arrange
    # Define class LookupModule
    lookup_module = LookupModule()

    lookup_module._loader = MagicMock()
    lookup_module._loader._get_file_contents = MagicMock(return_value=('Test contents1\n', False))
    lookup_module._loader._get_file_contents = MagicMock(return_value=('Test contents2\n', False))


    # Act
    ret = lookup_module.run(['test1.txt', 'test2.txt'], None, rstrip=True, lstrip=True)

    # Assert
    assert ret==['Test contents1', 'Test contents2']

# Generated at 2022-06-25 10:37:18.771206
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # test_case_0
    lookup_module_0 = LookupModule()
    expected_output_0 = [
        """\
Hello world !
""",
        """\
Hello galaxy !
""",
        """\
Hello universe !
""",
    ]
    try:
        result_0 = lookup_module_0.run(["file1.txt", "file2.txt", "file3.txt"])
        assert expected_output_0 == result_0
    except Exception as e:
        print(e)
        assert False

# Generated at 2022-06-25 10:37:19.523105
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    pass

# Generated at 2022-06-25 10:37:21.377715
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = '-test_task_0'
    variables_0 = 'var_0'
    assert LookupModule().run(terms_0, variables_0) == [], 'The returned value did not match expected value'


# Generated at 2022-06-25 10:37:23.495988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:37:24.584947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 10:37:58.239395
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    int_0 = 200
    list_0 = []
    str_0 = lookup_run(int_0)
    lookup_module_1 = LookupModule(list_0)
    str_1 = lookup_run(int_0)
    lookup_module_2 = LookupModule(list_0)
    str_2 = lookup_run(int_0)
    lookup_module_3 = LookupModule(list_0, str_1)
    str_3 = lookup_run(int_0)
    lookup_module_4 = LookupModule(str_1)
    str_4 = lookup_run(int_0)
    lookup_module_5 = LookupModule(str_1, list_0)
    str_5 = lookup_run(int_0)
   

# Generated at 2022-06-25 10:38:03.167478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    term_0 = None
    variables_0 = None
    kwargs_0 = None
    result_0 = lookup_module_1.run(term_0, variables_0, **kwargs_0)
    result_1 = lookup_module_1.run()

if __name__ == '__main__':
    # This is a simple test to make sure the code compiles.
    # Run this in the test directory.
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:38:10.197230
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    fd_int_0 = 200
    str_0 = "abc"

    lookup_module_0 = LookupModule()
    lookup_module_0.display = display
    lookup_module_0._loader = DictDataLoader({str_0: "efg"})
    var_0 = lookup_module_0.run([str_0], dict(int_0 = fd_int_0))
    assert type(var_0) == list
    assert var_0 == ["efg"]

# Generated at 2022-06-25 10:38:11.492956
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(terms_0, variables_0) == ret_0


# Generated at 2022-06-25 10:38:14.619210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 200
    lookup_module_1 = LookupModule()
    run_0 = lookup_module_1.run(int_0)
    display.vvv(run_0)


# Generated at 2022-06-25 10:38:20.400312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run([])
    assert var_0 == [], "var_0 should be empty"



# Generated at 2022-06-25 10:38:24.268572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule_0 = LookupModule()
    # Test function call with only mandatory arguments
    lookupmodule_0.run(terms, variables)

    # Test function call with mandatory and optional arguments
    lookupmodule_0.run(terms, variables, lstrip, rstrip)

# Generated at 2022-06-25 10:38:25.238238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

# Generated at 2022-06-25 10:38:29.758753
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    term = "test"
    variables = None
    kwargs = None
    # test for return value not none
    assert lookup_module.run(terms, variables, **kwargs) != None


# Generated at 2022-06-25 10:38:33.116574
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 200
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)

# Generated at 2022-06-25 10:39:23.874247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_1 = 200
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(int_1)

# Generated at 2022-06-25 10:39:25.631041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0()

# Generated at 2022-06-25 10:39:26.120732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass



# Generated at 2022-06-25 10:39:29.557813
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 400
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    assert var_0 == int_0


# Generated at 2022-06-25 10:39:30.321278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test = 200
    assert test == 200

# Generated at 2022-06-25 10:39:31.604710
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print(test_case_0.__name__)
    test_case_0()

# Generated at 2022-06-25 10:39:33.500665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 200
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(int_0)

# Generated at 2022-06-25 10:39:34.281843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:39:35.081817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 0 == 1



# Generated at 2022-06-25 10:39:37.929169
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # No error

# Generated at 2022-06-25 10:41:38.448602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 200
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)


# Generated at 2022-06-25 10:41:44.215128
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 200
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)

# Generated at 2022-06-25 10:41:47.282578
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options(var_options={'a': 'A'}, direct={'b': 'B'})

# Generated at 2022-06-25 10:41:48.918428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = "Merry Christmas! And now, the end is near, the end of Christmas. And we"
    lookup_module = LookupModule()
    var_0 = lookup_module.run()


# Generated at 2022-06-25 10:41:53.673014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    v0 = 200
    v1 = False
    v2 = False
    v3 = "files"
    v4 = "files"
    v5 = {}
    v6 = {'rstrip': v1, 'lstrip': v2}
    v7 = True
    v8 = True
    v9 = [v3, v4]
    x0 = LookupModule(loader=v0, variable_manager=v1, templar=v2)
    x1 = x0.run(terms=v9, variables=v5, rstrip=v6['rstrip'], lstrip=v6['lstrip'])
    assert x1 in (v7, v8)


test_LookupModule_run()

# Generated at 2022-06-25 10:41:54.437674
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(1)
    assert result == False


# Generated at 2022-06-25 10:41:56.100804
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Entering test_LookupModule_run")
    test_case_0()
    print("Exiting test_LookupModule_run")

# Standalone tests
if __name__ == "__main__":
    test_LookupModule_run()

# Generated at 2022-06-25 10:41:57.147755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(lookup_module_0, lookup_module_0)

# Generated at 2022-06-25 10:41:57.661756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True
    
    

# Generated at 2022-06-25 10:41:59.845801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Run test for method run of class LookupModule")
    int_0 = 200
    lookup_module_0 = LookupModule()
    lookup_module_0.run(int_0)