

# Generated at 2022-06-25 10:32:56.375219
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test case: basic test
    lookup_module_1 = LookupModule()
    terms_1=['test1.txt']
    #actual_result_1 = lookup_module_1.run(terms_1)
    expected_result_1 = ["line 1", "line 2"]
    #assert actual_result_1 == expected_result_1
    lookup_module_2 = LookupModule()
    terms_2=['test2.txt']
    #actual_result_2 = lookup_module_2.run(terms_2)
    expected_result_2 = ["line 1", "line 2", "line 3"]
    #assert actual_result_2 == expected_result_2



# Generated at 2022-06-25 10:33:03.223747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(["test.txt"],variables={"ansible_distribution":"Red Hat"})
    lookup_module.run(["test.txt"],variables={"ansible_distribution":"Ubuntu"})
    lookup_module.run(["test.txt"],variables={"ansible_distribution":"SuSE"})
    lookup_module.run(["test.txt"],variables={"ansible_distribution":"Fedora"})

# Generated at 2022-06-25 10:33:08.554880
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/Users/shailen/Documents/ansible_tut/ansible-development/test/unit/lookup_plugins/file/a.txt']
    lookup_module_0 = LookupModule()
    lookup_module_0.run(terms)


# Generated at 2022-06-25 10:33:12.296777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test with term : /path/to/tstfile.txt
    # Test with variables : None
    # Test with kwargs : None
    term = "/path/to/tstfile.txt"
    variables = None
    kwargs = None
    ret = lookup_module.run(term, variables, **kwargs)

# Generated at 2022-06-25 10:33:22.512864
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    ansible_file = lookup_module.find_file_in_search_path(variables, 'files', 'ansible.cfg')

    # Test without providing the 'variables' argument
    # EAFP principle
    try:
        lookup_module.run(terms=["ansible.cfg"], variables=None, **kwargs)
    except Exception as e:
        if isinstance(e, AnsibleError):
            pass
        else:
            raise
    except:
        pass

    try:
        lookup_module.run(terms=["ansible.cfg"], variables=variables, **kwargs)
    except Exception as e:
        if isinstance(e, AnsibleError):
            pass
        else:
            raise
    except:
        raise

# Generated at 2022-06-25 10:33:30.264702
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(dict())
    terms = [
        './generated/foo.txt',
        './generated/dummy.txt',
    ]
    variables = dict()
    kwargs = dict()
    try:
        result = lookup_module_0.run(terms, variables, **kwargs)
    except Exception as exception_0:
        raise
    else:
        print(result)


# Generated at 2022-06-25 10:33:33.829408
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("Executing unit test for method 'run' of class 'LookupModule'")
    lookup_module = LookupModule()
    lookup_module.run([], {})


# Generated at 2022-06-25 10:33:40.180245
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [u'file.txt']
    variables = {}
    function_call_result_0 = lookup_module_0.run(terms=terms, variables=variables)
    assert function_call_result_0 == [u'The contents of the specified file']

# Generated at 2022-06-25 10:33:48.235277
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # lookup_module.run(
    #     terms=["../files/debug_file.txt"],
    #     autoescape=None,
    #     variables=dict(
    #         files_dir="",
    #         role_path=["C:\\Users\\Himanshu\\.ansible\\roles\\abc"],
    #         role_name="abc",
    #         task_path="C:\\Users\\Himanshu\\.ansible\\roles\\abc\\tasks\\main.yml"
    #     )
    # )

# Generated at 2022-06-25 10:33:58.301324
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Attempting to call run with "terms" of type <str> throws an exception
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run("terms")

    # Attempting to call run with "terms" of type <int> throws an exception
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(1)

    # Attempting to call run with "terms" of type <bool> throws an exception
    with pytest.raises(AnsibleLookupError):
        lookup_module_0.run(True)

    # Attempting to call run with "terms" of type <dict> throws an exception

# Generated at 2022-06-25 10:34:07.715576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    lookup_module_0.run(terms_0, variables_0)

# Generated at 2022-06-25 10:34:08.679957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:34:12.642142
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=[], variables=None, **{}) == []


# Generated at 2022-06-25 10:34:18.913110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()

    terms_1 = "terms_1"
    variables_1 = "variables_1"
    kwargs_1 = {"kwargs_1": "kwargs_1"}
    # Run the test command
    result = lookup_module_1.run(terms_1, variables_1, **kwargs_1)

    assert result is not None
    assert isinstance(result, list)


# Generated at 2022-06-25 10:34:24.210565
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_required_params = [
        "msg"
    ]
    args = to_text(mock_required_params)
    mock_required_params_args = [
        "msg"
    ]

    if args == mock_required_params_args:
        print("Passed: " + args)
    else:
        print("Failed: " + args)


# Generated at 2022-06-25 10:34:28.299062
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    result = lookup_module_0.run(terms, variables, **kwargs)

    if result is None:
        print("Success")
    else:
        print("ERROR")


if __name__ == "__main__":
    print("TEST 1")
    test_case_0()
    print("TEST 2")
    test_LookupModule_run()

# Generated at 2022-06-25 10:34:34.574611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Params for run:
    terms_0 = 'foo.txt'
    run_0 = lookup_module_0.run(terms=terms_0)

    assert(run_0) is not None
    return

test_case_0()

# Generated at 2022-06-25 10:34:38.746859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [None]
    variables_0 = {'foo': 'bar'}
    assert lookup_module_0.run(terms_0, variables_0) == [None]
    terms_1 = [{'key': 'value'}]
    variables_1 = {'foo': 'bar'}
    assert lookup_module_0.run(terms_1, variables_1) == [{'key': 'value'}]

# Generated at 2022-06-25 10:34:40.829882
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:34:45.608174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = None
    variables = None
    kwargs = None
    lookup_module_0.run(terms, variables, kwargs)

# Generated at 2022-06-25 10:34:53.432141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:35:02.670481
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    tuple_0 = (bool_0, str_1)
    str_2 = '/servers/socket/'
    str_3 = 'ansible'
    str_4 = 'ansible'
    tuple_1 = (str_2, str_3, str_4)
    list_0 = [tuple_1, tuple_0]
    list_1 = lookup_run(str_1)
    assert list_1 == list_0

# Generated at 2022-06-25 10:35:08.585613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'ABCDE'
    lookup_module_0 = LookupModule({})
    var_0 = lookup_run(str_0)
    assert var_0 == 1

# Generated at 2022-06-25 10:35:09.147409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return

# Generated at 2022-06-25 10:35:11.792287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:35:15.368262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert test_case_0() == [{'contents': 'None'}]
    assert test_case_1() == {'contents': 'None'}
    assert test_case_2() == [{'contents': 'None'}]
    assert test_case_3() == [{'contents': 'None'}]



# Generated at 2022-06-25 10:35:21.635926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/ ser/vers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(str_0)
    print(var_0)

# Generated at 2022-06-25 10:35:27.846211
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(str_0)
    print(var_0)

# Generated at 2022-06-25 10:35:33.660125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    #LookupModule.run(terms, variables=None, **kwargs)
    with pytest.raises(AnsibleError) as excinfo:
        result = lookup_module_0.run('/etc/passwd')
    assert type(excinfo.value) == type(eq)


# Generated at 2022-06-25 10:35:38.801576
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    var_0 = 'abc'
    dict_0['terms'] = var_0
    lookup_module_0 = LookupModule(dict_0)
    str_0 = '/servers/socket/'
    dict_0 = {str_0: str_0}
    var_1 = lookup_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 10:35:55.949975
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(dict())
    str_0 = '/servers/socket/'
    dict_1 = {None: None, str_0: str_0, str_0: str_0}
    var_1 = lookup_run(str_0)
    lookup_module_0.run(var_1)

# Generated at 2022-06-25 10:36:04.129598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(dict_0)
    lookup_module_2 = LookupModule(dict_0)
    lookup_module_3 = LookupModule(dict_0)
    terms_0 = [str_0, str_1, str_2]
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    variables_0 = dict_1
    bool_0 = lookup_module_3.run(terms_0, variables_0, **dict_0)
    bool_1 = lookup_module_2.run(terms_0, variables_0, **dict_0)

# Generated at 2022-06-25 10:36:11.432868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['/servers/socket/', '0.0.0.0', 'test']
    variables = dict()
    # Unit test for run
    lookup_module_1 = LookupModule(variables)
    result_1 = lookup_module_1.run(terms)
    assert result_1[0] == '127.0.0.1'
    assert result_1[1] == '11.11.111.11'
    assert result_1[2] == ''

# Generated at 2022-06-25 10:36:17.490234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import copy
    lookup_module_0 = LookupModule({'rstrip': True, 'direct': {'rstrip': True}, 'var_options': True, '_options': True, '_templar': True, '_loader': True, '_task': True, 'lstrip': True})
    bool_0 = True
    str_0 = 'localhost'
    list_0 = [str_0, 'socket', 'var']
    set_0 = set(list_0)
    int_0 = 666

# Generated at 2022-06-25 10:36:24.175966
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    list_0 = [dict_0, dict_0, dict_0]
    var_0 = lookup_module_0.run(list_0)
    assert var_0 == list_0

# Generated at 2022-06-25 10:36:28.611491
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'test run'
    bool_0 = True
    str_1 = 'test run'
    dict_0 = {str_0: str_1, str_0: str_1}
    var_0 = lookup_module_0.run(str_0, dict_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:36:32.683594
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 't'
    str_1 = 'f'
    dict_0 = {str_0: str_0, str_1: str_1, str_0: str_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(['t', 'f', 't'])


# Generated at 2022-06-25 10:36:36.292417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(str_0)


test_case_0()

# Generated at 2022-06-25 10:36:46.139836
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {str_0: str_0, '.+\\.txt': str_0}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = lookup_module_0.run(str_0)
    item_0 = list_0[0]
    dict_0 = {bool_0: bool_0, '.+\\.txt': str_0}
    lookup_module_0 = LookupModule(dict_0)
    list_0 = lookup_module_0.run(str_0)
    item_1 = list_0[0]
    assert item_1 == item_0

# Generated at 2022-06-25 10:36:54.999033
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test args.
    terms = '/servers/socket/'
    variables = [True]
    kwargs = {'rstrip': True}

    # Unreachable code
    # lookup_module_0 = LookupModule(variables, kwargs)
    # assert lookup_module_0.run(terms) == "/home/app/socket"

    # Unreachable code
    # lookup_module_1 = LookupModule(variables, kwargs)
    # assert lookup_module_1.run(terms) == "file_content"

    # No exception raised.
    lookup_module_2 = LookupModule(variables, kwargs)
    assert lookup_module_2.run(terms) is None

    # No exception raised.
    lookup_module_3 = LookupModule(variables, kwargs)

# Generated at 2022-06-25 10:37:20.501240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:37:29.715255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Error: keyword: lstrip, expected one of: [False]
    lookup_module_0 = LookupModule()
    lookup_module_0._get_file_contents()
    # Error: keyword: lstrip, expected one of: [False]
    lookup_module_0 = LookupModule()
    lookup_module_0._get_file_contents()

    # The contents of this function is generated by:
    # $ python -m testtools.run lookup_plugins.file_test
    # If you need to update it, please run that command again and then update this function manually.
    pass  # noqa: E742

# Generated at 2022-06-25 10:37:34.292380
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  args_0 = {'rstrip': True, 'lstrip': False}
  args_1 = '../../template/index.html'
  lookup_module_0 = LookupModule(args_0)
  var_0 = lookup_module_0.run(args_1)
  if (var_0 != False):
    return var_0


# Generated at 2022-06-25 10:37:44.315141
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule({})
    terms_2 = ['ansible.cfg']
    bool_0 = False
    ansible_options_2 = {'module_setup': bool_0}
    dict_0 = {'module_setup': bool_0, 'forks': bool_0, 'extra_vars': [], 'become': bool_0}
    dict_1 = {'module_setup': bool_0, 'forks': bool_0, 'extra_vars': [], 'become': bool_0}
    dict_2 = {'module_setup': bool_0, 'forks': bool_0, 'extra_vars': [], 'become': bool_0}
    variables_2 = [dict_0, dict_1, dict_2]

# Generated at 2022-06-25 10:37:53.541826
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup = LookupModule({})

# Generated at 2022-06-25 10:37:58.453598
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    var_0 = lookup_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 10:38:02.212330
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:38:10.915863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    str_1 = '/servers/socket/'
    bool_1 = True
    dict_1 = {bool_1: bool_1, bool_1: bool_1, bool_1: bool_1}
    var_0 = lookup_module_0.run(str_1, dict_1)

# Generated at 2022-06-25 10:38:13.013272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'terms'
    variables = 'variables'
    kwargs = {'lstrip': True, 'rstrip': True}
    lookup_module_0 = LookupModule
    lookup_module_0.run()

# Generated at 2022-06-25 10:38:22.923468
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule({})
    str_0 = '/servers/socket/'
    str_1 = '/etc/ansible/ansible.cfg'
    bool_0 = True
    str_2 = '\n'
    str_3 = '\t'
    str_4 = '\r'
    str_5 = ' '
    str_6 = ''
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    list_0 = [str_3, str_2, str_4]
    list_1 = [str_2, str_3]

# Generated at 2022-06-25 10:39:12.149938
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule({})
    str_0 = '/servers/socket/'
    str_1 = 'file'
    var_1 = lookup_run(str_1)



# Generated at 2022-06-25 10:39:14.268654
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_0 = 'var_0'
    lookup_module_0 = LookupModule({term_0: term_0})
    var_0 = lookup_run(term_0)
    var_0.pop()


# Generated at 2022-06-25 10:39:20.770329
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    # str_0 = '/servers/socket/'
    # lookup_module_0 = LookupModule(dict_0)
    # var_0 = lookup_module_0.run(str_0)

# Generated at 2022-06-25 10:39:27.075610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = LookupModule.run(str_0, str_0)


# Generated at 2022-06-25 10:39:31.567346
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = LookupBase()
    var_1 = ()
    if True:
        var_1 = var_1 + (True)
    var_2 = {True: var_0, True: True, True: True}
    var_0 = LookupModule(var_2)
    var_3 = lookup_run(var_1)



# Generated at 2022-06-25 10:39:35.229136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    var_0 = lookup_module_0.run(str_0, dict_0)

# Generated at 2022-06-25 10:39:39.710447
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_0.set_options(var_options=dict_0, direct=dict_0)
    assert isinstance(lookup_module_0.run([str_0]), list)

# Generated at 2022-06-25 10:39:44.944504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_0['foo'] = 'bar'
    dict_0['baz'] = 'glorb'
    lookup_module_0 = LookupModule(dict_0)
    str_0 = "test_file.txt"
    var_0 = lookup_module_0.run(str_0)
    assert var_0 == ['test_file.txt', 'test_file.txt']
    str_1 = "test_file2.txt"
    var_1 = lookup_module_0.run(str_1)
    assert var_1 == ['test_file2.txt', 'test_file2.txt']

# Generated at 2022-06-25 10:39:49.630927
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}

    test_LookupModule_run_obj = LookupModule(dict_0)
    test_LookupModule_run_obj.run(lookup_module_0)

    assert True


# Generated at 2022-06-25 10:39:51.185479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert lookup_module_0.run(terms_0, variables_0) == bool_0


# Generated at 2022-06-25 10:41:46.772028
# Unit test for method run of class LookupModule
def test_LookupModule_run():
	# Test case 0
	str_0 = '/servers/socket/'
	bool_0 = True
	dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
	lookup_module_0 = LookupModule(dict_0)
	var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:41:53.796222
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    str_1 = '/servers/socket/'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1}
    var_0 = lookup_run(str_0, dict_1)



# Generated at 2022-06-25 10:41:56.864488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:41:59.276964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  # TODO:
  #  change code to assert the side effect of run()
  #  Example:
  #  assert len(result) == 1
  #  assert result[0]['name'] == 'foo'
  pass

# Generated at 2022-06-25 10:42:03.154944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:42:07.301287
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    lookup_module_0.run()


# User defined test cases

# Program
if __name__ == '__main__':
    # Call test case functions
    test_case_0()
    # Call main function
    main()

# Generated at 2022-06-25 10:42:14.056198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'advance'
    bool_0 = True
    dict_0 = {str_0: bool_0, bool_0: str_0, str_0: str_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(str_0)

# Generated at 2022-06-25 10:42:16.401843
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    assert True

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:42:22.910079
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    str_0 = 'file'
    list_0 = [str_0]
    dict_0 = {str_0: list_0, str_0: list_0}
    var_0 = lookup_module_1.run(str_0, dict_0)
    assert var_0 == list_0

# Generated at 2022-06-25 10:42:30.344932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = '/servers/socket/'
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_run(str_0)
    assert (var_0 == None and lookup_module_0 == None)


test_case_0()
test_LookupModule_run()