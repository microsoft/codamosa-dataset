

# Generated at 2022-06-25 10:32:55.049881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with an empty lookupmodule
    lookupmodule = LookupModule()
    lookup_dict = dict(
        _terms = ['/home/cadams/ansible-tests/roles/test-role-1/files/test-variable-0.txt'],
        rstrip = True,
        lstrip = True
    )
    lookup_vars = dict()
    print(lookupmodule.run(terms, variables=lookup_vars, **lookup_dict))

# Generated at 2022-06-25 10:33:03.335398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'roles/celar-yaml/files/celar-deployment.tar.gz',
        'roles/celar-yaml/tasks/main.yml',
        'roles/ftp_server/tasks/config.yml',
        'roles/ftp_server/tasks/service.yml',
        'roles/ftp_server/vars/main.yml',
    ]
    variables_0 = {}
    ret_0 = lookup_module_0.run(terms_0, variables_0, **variables_0)

# Generated at 2022-06-25 10:33:03.937511
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = []


# Generated at 2022-06-25 10:33:07.363057
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert lookup_module_0.run("term0") == "value0"
    assert lookup_module_0.run("term1") == "value1"

# Generated at 2022-06-25 10:33:12.263258
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # In this test case, the file /etc/foo.txt does not exist
    # The test case LookupModule_run_file_not_exist_check is for this
    lookup_module = LookupModule()
    result = lookup_module.run(terms=[u'/etc/foo.txt'])
    assert result == [u''] or result == [u' '], 'Ansible is not able to read file contents'



# Generated at 2022-06-25 10:33:20.498362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    terms_0 = ['...']
    variables_0 = {
        u'files_dir': u'files',
        u'name': u'ping'}
    try:
        lookup_module_0.run(terms_0, variables=variables_0)
    except AnsibleError as exc_0:
        pass
    assert exc_0.message == u"could not locate file in lookup: ..."
    assert exc_0.obj is not None


# vim:sw=4:ts=4:et:

# Generated at 2022-06-25 10:33:28.038039
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options([u'_terms', u'rstrip', u'lstrip'], var_options=None, direct=None)
    lookup_module_0.run([u'/etc/foo.txt'])


if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:32.339170
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [u'ansible.cfg']
    result = lookup_module_0.run(terms_0)
    assert len(result) > 0

    assert result[0].startswith(u'[defaults]')
    assert result[0].endswith(u' (INI-formatted)')

# Generated at 2022-06-25 10:33:34.390980
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = '/etc/foo.txt'
    lookup_module_0 = LookupModule()
    print(lookup_module_0.run(terms))

# Generated at 2022-06-25 10:33:40.097775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["term_0"]
    variables_0 = dict()
    kwargs_0 = dict()
    assert type(lookup_module_0.run(terms_0, variables_0, **kwargs_0)) is list

# Generated at 2022-06-25 10:33:43.357361
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:33:51.366146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'filter',
        'filter',
        'filter',
        'filter',
        'filter',
        'filter',
    ]
    variables_0 = [
        'filter',
        'filter',
    ]
    kwargs_0 = {
        'direct': 'filter',
        'var_options': 'filter',
    }
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == [
        'filter',
        'filter',
        'filter',
        'filter',
        'filter',
        'filter',
    ]


if __name__ == "__main__":

    # In case you want to test manually
    lookup_module_0 = LookupModule()
    terms_

# Generated at 2022-06-25 10:33:54.229692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms0 = []
    variables0 = {}
    run0 = lookup_module_0.run(terms = terms0, variables = variables0)
    assert run0 == []


# Generated at 2022-06-25 10:33:54.629915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:34:02.006425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters = {"A", "B", "C", "D", "E", "F"}
    lookup_module_0 = LookupModule()
    try:
        assert(lookup_module_0.run(parameters, variables={'test': 'test_value'}, **{'some_kwarg': 'kwarg_value'}) is not None)
    except Exception as e:
        print('Exception raised: ' + str(e))

#TODO: Test for method _get_file_contents of class LookupModule

#TODO: Test for method _Loader__get_file_contents of class LookupModule

#TODO: Test for method _Loader__get_plugin_path of class LookupModule

#TODO: Test for method _Loader__get_file_of_type of class LookupModule

# Generated at 2022-06-25 10:34:07.898184
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run('/etc/passwd') is not None, "lookup_module_1.run('/etc/passwd') is not None"

# Generated at 2022-06-25 10:34:13.121556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  term = "foo"
  variables = {"bar": 3}
  result_0 = lookup_module_0.run(term, variables)
  print(result_0)


# Generated at 2022-06-25 10:34:17.676002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.term_0 = "Some data"
    lookup_module_0.run("Some data")
    


# Generated at 2022-06-25 10:34:19.205845
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    print(lookup_module_1.run())

# Generated at 2022-06-25 10:34:24.997782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    res = lookup_module_0.run(terms = ['/etc/hosts'], variables = None, **{'rstrip': True, 'lstrip': False})
    assert (res == ['127.0.0.1\tlocalhost localhost.localdomain localhost4 localhost4.localdomain4\n::1\tlocalhost localhost.localdomain localhost6 localhost6.localdomain6\n'])

# Generated at 2022-06-25 10:34:38.289825
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lstrip_0 = u'nil'
    bytes_0 = b'\x1bm\x82E8'
    str_0 = ']GTSkt#5.]yOk|) EuD'
    str_1 = 'F$9'
    dict_0 = {str_0: str_0, str_1: str_0, str_1: str_0, str_1: bytes_0}
    str_2 = lookup_module_run(**dict_0)
    lookup_module_0 = LookupModule()
    dict_1 = {str_0: str_0, str_1: str_0, str_1: str_0, str_1: bytes_0}
    str_3 = lookup_module_run(**dict_1)
   

# Generated at 2022-06-25 10:34:46.624337
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Works with a default-initialized dictionary as an argument?
    var_0 = lookup_module_0.run({}, {})
    # Works with a list as an argument?
    var_1 = lookup_module_0.run([])
    # Works with a default-initialized dictionary as an argument?
    var_2 = lookup_module_0.run({}, {})
    # Works with a list as an argument?
    var_3 = lookup_module_0.run([])
    # Does not accept NULL instead of a list as an argument?
    var_4 = lookup_module_0.run(None)
    # Does not accept NULL instead of a dictionary as an argument?
    var_5 = lookup_module_0.run([], None)
    # Works with a list as an argument?

# Generated at 2022-06-25 10:34:53.504490
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'x'
    str_1 = 'I'
    str_2 = 'b3'
    str_3 = 'I'
    str_4 = 'Ri'
    str_5 = 'J'
    str_6 = 'P'
    str_7 = '#'
    str_8 = 'Q'
    str_9 = 'b5'
    str_10 = 'l4'
    str_11 = 'x'
    str_12 = 'b3'
    str_13 = 'I'
    str_14 = 'Ri'
    str_15 = 'J'
    str_16 = 'P'
    str_17 = '#'
    str_18 = 'k'
    str_19 = 'N'
   

# Generated at 2022-06-25 10:34:57.804898
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'U`~hU\x15\x03\x06\x1b\x0f\x07'
    array_0 = lookup_run(str_0)
    assert array_0 == [str_0]



# Generated at 2022-06-25 10:35:07.052622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'WEiXZzj`'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    lookup_run(str_0, **dict_0)
    str_1 = '3K5'
    dict_1 = {str_1: str_1, str_1: str_1, str_1: str_1, str_1: str_1, str_1: str_1}
    lookup_run(str_1, **dict_1)
    str_2 = 'E>7'

# Generated at 2022-06-25 10:35:10.219817
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options()
    lookup_module_0.run(term, variables=var)


# Generated at 2022-06-25 10:35:17.943756
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    if PY3:
        argument_0 = b'\x7f\x1e1\x0c\x8d'
    else:
        argument_0 = '\x7f\x1e1\x0c\x8d'
    argument_1 = {'\x7f\x1e1\x0c\x8d': '\x7f\x1e1\x0c\x8d'}
    return_value_0 = lookup_module_0.run(argument_0, **argument_1)


# Generated at 2022-06-25 10:35:22.049498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(bytes_0, **dict_0)
    var_0 = lookup_run(bytes_0)

# Generated at 2022-06-25 10:35:27.362453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'EJHr_r$^p'
    list_0 = [str_0]
    lookup_run_0 = lookup_module_0.run(list_0)
    assert lookup_run_0 is not None


# Generated at 2022-06-25 10:35:38.504932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['5'])
    var_0 = lookup_module_0.run([])
    var_0 = lookup_module_0.run(["\x1bm\x82E8"])
    var_0 = lookup_module_0.run(["!UNKNOWN"])
    var_0 = lookup_module_0.run([('3', '3', '3', '3')])
    var_0 = lookup_module_0.run([{}])
    var_0 = lookup_module_0.run(['3'])
    var_0 = lookup_module_0.run([[]])
    var_0 = lookup_module_0.run([None])

# Generated at 2022-06-25 10:35:48.757502
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'hN``2Hd60S'
    str_1 = '*'
    list_0 = [str_1]
    dict_0 = {str_1: list_0, str_0: list_0, str_0: list_0, str_0: list_0}
    lookup_module_0.run(list_0, **dict_0)



# Generated at 2022-06-25 10:35:59.617049
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
   
    # Test case 0:
    dict_0 = dict()
    dict_0['lstrip'] = False
    dict_0['rstrip'] = False
    dict_0['var_options'] = dict()
    dict_0['var_options']['filter'] = 'exclude_nested_types'
    dict_0['var_options']['_original_file'] = 'key_value'
    dict_0['var_options']['_filestorage_source'] = 'key_value'
    dict_0['var_options']['_ansible_no_log'] = False
    dict_0['var_options']['_ansible_selection'] = 'key_value'

# Generated at 2022-06-25 10:36:00.396362
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:36:08.981957
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    path_0 = 'X;szOJ'
    list_0 = [path_0]
    str_0 = 'nZDx|'
    str_1 = '@nRg|'
    bytes_0 = b'w?\xd4'
    int_0 = 1
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={str_0: int_0, str_1: bytes_0})
    lookup_module_0._loader._get_file_contents = lambda : ({})
    lookup_module_0.find_file_in_search_path = lambda **kwargs_0: (path_0)


# Generated at 2022-06-25 10:36:16.493556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x1bm\x82E8'
    str_0 = ']GTSkt#5.]yOk|) EuD'
    str_1 = 'F$9'
    dict_0 = {str_0: str_0, str_1: str_0, str_1: str_0, str_1: bytes_0}
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(bytes_0, **dict_0)
    var_1 = lookup_module_0.run(bytes_0, **dict_0)
    var_2 = lookup_module_0.run(bytes_0, **dict_0)
    var_3 = lookup_module_0.run(bytes_0, **dict_0)

# Generated at 2022-06-25 10:36:19.905678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(_terms=_terms, variables=variables, **kwargs)
    assert var_0 == None


# Generated at 2022-06-25 10:36:26.664448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run()
    var_1 = lookup_module_0.run()
    var_2 = lookup_module_0.run()
    var_3 = lookup_module_0.run()
    var_4 = lookup_module_0.run()


# Generated at 2022-06-25 10:36:33.244619
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\xf0\x9f\x8d\xa3'
    bytes_1 = b'!8\x1d\xa5\xbd'
    str_0 = '\x15\xb7\xecy\x8c'
    str_1 = '\x19n\xea\xdd\xe5\x1f'
    str_2 = '9\x1d'
    str_3 = '\x05u\x81\x82V\xeb\x8bJ'
    str_4 = '\x1b[\xb1,\r\xd6\xef\x0b2\xed\t'

# Generated at 2022-06-25 10:36:38.174652
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x00\x00\x00'
    str_0 = 'Dcv'
    tuple_0 = (True, True, True)
    dict_0 = {str_0: list(), tuple_0: None, 'Z\x8cs': bytes_0, '\xef\xca\x8d': bytes_0}

# Generated at 2022-06-25 10:36:47.879345
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Using a list of different values as '_raw':
    lst_lookup_base_0 = get_copy()
    lst_lookup_base_0 = [
        'iBw-7\'',
        'u^\\VpC>",u\\',
        '/]Yf&G-{:dDw?',
        'ex;t)X~E/eQzB',
        '@M4$Ny:IK|{wN',
    ]
    lookup_module_1 = LookupModule()
    var_0 = lookup_run(lst_lookup_base_0, **get_copy())

    # Using a dict as '_raw':
    dict_lookup_base_0 = get_copy()

# Generated at 2022-06-25 10:37:00.261130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True


# Generated at 2022-06-25 10:37:06.712919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    dict_0 = { }
    var_0 = lookup_module_0.run('path/to/file.txt', **dict_0)
    assert var_0 == 'file contents'
    dict_0 = { }
    var_0 = lookup_module_0.run('path/to/file.txt', **dict_0)
    assert var_0 == 'file contents'
    dict_0 = { }
    var_0 = lookup_module_0.run('path/to/file.txt', **dict_0)
    assert var_0 == 'file contents'
    dict_0 = { }
    var_0 = lookup_module_0.run('path/to/file.txt', **dict_0)
    assert var_0 == 'file contents'
    dict_

# Generated at 2022-06-25 10:37:12.769026
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x13\x19C\x0f\x0c'
    str_0 = '_ \x1b'
    int_0 = 4
    list_0 = [(int_0, int_0, int_0), (int_0, int_0, int_0)]
    dict_0 = {str_0: int_0, str_0: None, str_0: list_0}
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(bytes_0, **dict_0)
    print(var_0)
    return var_0

# Generated at 2022-06-25 10:37:20.998160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0._loader = None
  lookup_module_0._display = Display()
  int_0 = 0
  int_1 = 255
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}
  dict_0 = {int_0: int_1}


# Generated at 2022-06-25 10:37:23.753925
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    assert True


# Generated at 2022-06-25 10:37:26.566621
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run() == None

# Generated at 2022-06-25 10:37:28.724412
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms=['contents']) is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-25 10:37:36.592032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run("x_1")
    contents_0 = dir()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run("x_2")
    contents_1 = dir()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run("x_3")
    contents_2 = dir()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run("x_4")
    contents_3 = dir()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run("y_1")
    contents_4 = dir()
    lookup_module_0 = LookupModule()
    var_0 = lookup_run("z_1")
    contents_

# Generated at 2022-06-25 10:37:39.248678
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # AssertionError: "expected to be equal to:
    # <...test_LookupModule_run.<locals>.test_case_0 at 0x7fe22e8ee898>:
    test_case_0()

# vim: tabstop=4 expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-25 10:37:45.026462
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

# Generated at 2022-06-25 10:38:09.993504
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('term_0', variables='variables_0', attr_0='attr_0')


# Generated at 2022-06-25 10:38:14.902122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    class_0 = lookup_module_0
    str_0 = 'y[R]|l r'
    bool_0 = False
    var_4 = lookup_module_0.run(str_0, bool_0)
    var_5 = lookup_module_0.run(str_0, bool_0)

# Generated at 2022-06-25 10:38:25.205017
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = lookup_module_0
    bytes_0 = b''
    str_0 = '+Ou)'
    str_1 = '\x2c'
    str_2 = 'S:~.\x17q&\x01\x07'
    var_0 = (str_0, str_1)
    var_1 = {str_0: str_2}
    var_2 = lookup_module_1.run(var_0, **var_1)
    int_0 = 0
    if (var_2 is not None):
        int_0 = int_0 + 1
    var_3 = (str_1, str_2)
    var_4 = {str_0: str_0}
    var_5 = lookup_module

# Generated at 2022-06-25 10:38:29.311138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('/etc/passwd')
    print(str(var_0))


# Generated at 2022-06-25 10:38:34.760655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = 'terms'
    variables = {'variables': 'variables'}
    kwargs = {'kwargs': 'kwargs'}
    lu = LookupModule()
    # test_case_0
    var_0 = lu.run(terms, variables, **kwargs)
    assert var_0 == 'method run of class LookupModule returned value'

# Generated at 2022-06-25 10:38:40.832514
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test for method run()
    # Case 1
    lookup_module_0.set_options(var_options='variables', direct='kwargs')
    terms_0 = create_str_list(10, 10)
    dict_0 = {'kwargs': 'kwargs', 'variables': 'variables'}
    assert lookup_module_0.run(terms_0, **dict_0)[0] == 'zUg0vK8V14'
    assert lookup_module_0.run(terms_0, **dict_0)[1] == '-:|!Dd@"jK'
    assert lookup_module_0.run(terms_0, **dict_0)[2] == 'o/r-yT1/h'
    assert lookup_module_0

# Generated at 2022-06-25 10:38:46.521286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x1bm\x82E8'
    str_0 = ']GTSkt#5.]yOk|) EuD'
    str_1 = 'F$9'
    dict_0 = {str_0: str_0, str_1: str_0, str_1: str_0, str_1: bytes_0}
    lookup_module_2 = LookupModule()
    var_2 = lookup_module_run(bytes_0, **dict_0)
    test_case_0(var_2)

# Generated at 2022-06-25 10:38:48.647446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = (to_text(str_0, errors='surrogate_or_strict'),)
    variables = None
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(terms, variables)

# Generated at 2022-06-25 10:38:59.057106
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bytes_0 = b'\x1bm\x82E8'
    integer_0 = 666131313
    str_0 = '3ilA}K'
    str_1 = '#x%c'
    str_2 = 'T$2\x7f'
    str_3 = 'l1\x7f'
    str_4 = '+|T'
    str_5 = 'e#y'
    str_6 = 'vJHG'
    str_7 = '+P\x7f'
    tuple_0 = (str_0, str_1, str_2, bytes_0, integer_0)
    tuple_1 = (str_0, str_1, str_2, bytes_0, integer_0)

# Generated at 2022-06-25 10:39:05.495482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'f@y+NC2-!^;'
    str_1 = '1S'
    str_2 = '"'
    int_0 = -81613092
    int_1 = -8150697837
    str_3 = '<'
    int_2 = -81606595
    str_4 = 'Z=.0K'
    str_5 = '2'
    int_3 = -81601491
    str_6 = 'hKWf/D"O-w?g"#KvN'
    str_7 = ';D'
    str_8 = 'H\r'
    str_9 = '-M[^I1}'
    str_10 = 'KG}'
    int_

# Generated at 2022-06-25 10:39:56.518556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bytes_0 = b'\x1bm\x82E8'
    str_0 = ')_^FFhC,N\x04'
    str_1 = '\x0e,\x1b\x1e\x1d\x1d'
    int_0 = 0
    dict_0 = {str_0: int_0, str_1: str_0}
    float_0 = 8.28974050954e+35
    var_1 = lookup_module_0.run(bytes_0, float_0, **dict_0)
    var_0 = {'var_1': var_1}

    return var_0


# Generated at 2022-06-25 10:40:00.565805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([u'1.txt']) == [u'abc']
    assert lookup_module_0.run([u'2.txt']) == [u'\xce\xa9']
    assert lookup_module_0.run([u'_no_file_']) == []
    assert lookup_module_0.run([u'1.txt', u'2.txt']) == [u'abc', u'\xce\xa9']
    assert lookup_module_0.run([u'2.txt', u'1.txt']) == [u'\xce\xa9', u'abc']


# Generated at 2022-06-25 10:40:07.581151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = '\x1a;w\\'
    list_0 = [str_0]
    dict_0 = {str_0: str_0, str_0: list_0, str_0: list_0}
    list_1 = lookup_module_0.run(list_0, **dict_0)


# Generated at 2022-06-25 10:40:10.566312
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_0.run(["/home/pdupont/ansible/test/test_data/file/test_file.txt"])
    lookup_module_0.run("/home/pdupont/ansible/test/test_data/file/test_file.txt")

# Generated at 2022-06-25 10:40:14.445306
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Test Case Getter for run')


# Generated at 2022-06-25 10:40:19.395075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == []


# Generated at 2022-06-25 10:40:21.484439
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert file_0 == [var_0, str_0]


if __name__ == "__main__":
    test_file_0()

# Generated at 2022-06-25 10:40:22.396419
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(str(), str()) == str()

# Generated at 2022-06-25 10:40:24.242787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(['file.txt'])
    assert var_0 == None


# Generated at 2022-06-25 10:40:25.734455
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# Generated at 2022-06-25 10:42:23.496680
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'm\x81\xdc\x15\x8a\x13\x9d\xa7\xf3\x84\x86\xdd\xf5'
    var_str_0 = '2'
    lookup_module_0.run(str_0, var_str_0)
test_LookupModule_run()

# Generated at 2022-06-25 10:42:28.721730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run('abc')

    assert var_0 == 'abc'


# Generated at 2022-06-25 10:42:33.942160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_0 = LookupModule()
    lookup_1 = LookupModule()
    str_0 = '.dNb'
    lookup_2 = LookupModule()
    lookup_3 = LookupModule()
    lookup_4 = LookupModule()
    lookup_5 = LookupModule()
    lookup_6 = LookupModule()
    lookup_7 = LookupModule()
    lookup_8 = LookupModule()
    str_1 = 'G'
    var_0 = 'k'
    var_1 = '1'
    lookup_9 = LookupModule()
    lookup_10 = LookupModule()
    lookup_11 = LookupModule()
    lookup_12 = LookupModule()
    lookup_13 = LookupModule()
    lookup_14 = LookupModule()
    lookup_15 = LookupModule()
   

# Generated at 2022-06-25 10:42:42.406939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'U:F6Zs\\E~T9X+)0C[u<i,HQA7xu"%\x84IZI,U6^s@WH'
    str_1 = ''
    any_0 = -7391765016893461327
    bytes_0 = b'$)^9C*v1@'
    dict_0 = {str_0: str_0, str_1: any_0, str_1: str_0, str_1: bytes_0}
    str_2 = 'YK\n'
    str_3 = '4L\x1f'
    int_0 = 18
    list_0 = lookup_module_0.run(['9X\x0e'], **dict_0)

# Generated at 2022-06-25 10:42:49.551760
# Unit test for method run of class LookupModule