

# Generated at 2022-06-25 10:32:54.915548
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_option = Mock(return_value='abcdef')
    lookup_module._loader = Mock()
    lookup_module._loader._get_file_contents = Mock(return_value=['abcdef'])
    lookup_module.find_file_in_search_path = Mock(return_value='abcdef')
    lookup_module.run(['abcdef'])


# Generated at 2022-06-25 10:33:03.268066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_run_0 = LookupModule()
        lookup_module_run_0.run(['/var/lib/libreswan/nsspassword.conf'])
    except Exception as e:
        print(e)
        return False

    try:
        lookup_module_run_1 = LookupModule()
        lookup_module_run_1.run(['/var/lib/libreswan/nsspassword.conf'], {'variable_0': False})
    except Exception as e:
        print(e)
        return False


# Generated at 2022-06-25 10:33:04.499385
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0.run('/?{asdf')

# Generated at 2022-06-25 10:33:05.785126
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()

# Generated at 2022-06-25 10:33:11.891613
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [
        'foo.txt',
    ]
    var_options_0 = None
    kwargs_0 = dict(
        rstrip=True,
    )
    setattr(lookup_module_0, '_display', display)
    setattr(lookup_module_0, '_options', kwargs_0)
    ret_0 = lookup_module_0.run(terms_0, var_options_0)

# Generated at 2022-06-25 10:33:15.678311
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
#    lookup_module_1.run(terms, variables)



# Generated at 2022-06-25 10:33:22.634670
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    arguments = [ {"arg_0": 'ansible_system'} ]
    variables = [ {"var_0": 'ansible_system'} ]
    options = [ {"option_0": True} ]
    ansible_system = lookup_module_0.run(arguments, variables, **options)
    assert ansible_system == [ "Linux \n", "Linux \n" ]

# Generated at 2022-06-25 10:33:30.724712
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    args = [
        [
        "/etc/foo.txt"
        ],
        {
        "hostvars" : {
            "host_0": {
                "hostvars": {
                    "ansible_host": "host_0"
                    }
                }
            }
        },
        {
        "rstrip": True,
        "lstrip": False
        }
    ]
    assert lookup_module.run(*args) == [
        [
        "/etc/foo.txt"
        ]
    ]

# Generated at 2022-06-25 10:33:40.357547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_run_exception = False
    try:
        test_run_exception = 'lookup module'
        lookup_module_1 = LookupModule()
        test_run_exception = True
        lookup_module_2 = LookupModule()
        test_run_exception = False
    except Exception as e:
        if test_run_exception:
            print("raised exception at run of class LookupModule from module " + str(test_run_exception))
            print("raised exception: " + str(e))
            assert False
        else:
            print("raised exception at run of class LookupModule from module " + str(test_run_exception))
            print("raised exception: " + str(e))
            assert True

# Generated at 2022-06-25 10:33:48.207665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct=None)
    lookup_module_0._loader._get_file_contents = lambda x: ('file contents', 'show data')
    lookup_module_0.get_option = lambda x: None
    lookup_module_0.find_file_in_search_path = lambda x, y, z: None
    args = (['terma', 'termb', 'termc'],)
    kwargs = {'variables': None}
    expected = ['file contents', 'file contents', 'file contents']
    retval = lookup_module_0.run(*args, **kwargs)
    assert retval == expected

# Generated at 2022-06-25 10:33:56.202862
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run(terms, variables=variables, **kwargs)

# Generated at 2022-06-25 10:33:58.121513
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_instance = LookupModule()
    lookup_instance.set_options({'direct': {'lstrip': False, 'rstrip': False}})
    lookup_instance.run([''])

# Generated at 2022-06-25 10:34:07.106769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_obj_0 = LookupModule()
    lookup_module_obj_0._loader_args = {}
    lookup_module_obj_0._loader = None
    lookup_module_obj_0._templar = None
    lookup_module_obj_0._loader_config = None
    lookup_module_obj_0._loader_config_dict = {}
    lookup_module_obj_0._tmp_dir = None
    lookup_module_obj_0._registries = {}
    lookup_module_obj_0._file_cache = {}
    lookup_module_obj_0._file_cache_timeout = None
    lookup_module_obj_0._file_cache_max_age = None
    lookup_module_obj_0._arbitrary_attributes = {}
    lookup_module_obj_0._set_att

# Generated at 2022-06-25 10:34:17.766014
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    terms_1 = [None]
    terms_2 = [None, None]
    terms_3 = ['ansible_managed']
    terms_4 = ['ansible_managed', None]
    terms_5 = ['ansible_managed', '']
    terms_6 = ['ansible_managed', 'ansible_managed']
    variables_0 = None
    variables_1 = {'item': None}
    variables_2 = {'item': None, 'y': None}
    assert_1 = []
    assert_2 = ['']
    assert_3 = ['# Ansible managed:\n']
    assert_4 = ['# Ansible managed:\n']
    assert_5 = ['# Ansible managed:\n']

# Generated at 2022-06-25 10:34:20.969227
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    result = lookup_module_1.run(terms=['foo.txt'], variables={'playbook_dir': 'foo.txt', 'role_path': 'foo.txt'})
    assert result == ['foo.txt'], "Should be equal"

# Generated at 2022-06-25 10:34:24.738163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader({'get_basedir': lambda loader, path: 'files/' })
    terms = ['file1.txt', 'file2.txt']
    assert lookup_module_1.run(terms) == ['file1 contents', 'file2 contents']


# Generated at 2022-06-25 10:34:28.132478
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = dict(terms=['/etc/foo.txt'])
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(**args)

    assert ret == [to_text('this is a test file for lookup plugins')]

# Generated at 2022-06-25 10:34:34.407453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ' '
    try:
        lookup_module_0.run(terms_0)
    except AnsibleError as e:
        assert 'could not locate file in lookup:  ' == str(e)
    else:
        assert False


# Generated at 2022-06-25 10:34:36.576003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['path']
    variables_0 = None
    try:
        ret_0 = lookup_module_0.run(terms_0, variables_0)
    except AnsibleError as e_0:
        ret_0 = str(e_0)
    return ret_0

# Generated at 2022-06-25 10:34:38.391015
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run([], {}) == []
    assert lookup_module_0.run(['/etc/passwd'], {}) == []

# Generated at 2022-06-25 10:34:47.704146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = ['/etc/foo.txt', 'foo.txt']
    variables = {}
    kwargs = {'rstrip': True, 'lstrip': False}
    try:
        lookup_module.run(terms, variables, kwargs)
        print('Test case 0 successful')
    except Exception as e:
        print('Test case 0 failed')
        print('Exception raised is: ')
        print(e)


# Generated at 2022-06-25 10:34:50.845206
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_test_var = {'foo': 'bar'}
    my_test_term = ['bar.txt', 'biz.txt']
    lookup_module = LookupModule()
    lookup_module.run(my_test_term, my_test_var)

# Generated at 2022-06-25 10:34:56.878777
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        assert lookup_module_0 is not None
    except Exception:
        assert False
    lookup_module_1 = LookupModule()
    try:
        lookup_module_1.run(terms=[], variables=None, **{'lstrip': False, 'rstrip': True})
        assert False
    except AnsibleError:
        pass
    try:
        lookup_module_1.run(terms=[], variables=None, **{'lstrip': False, 'rstrip': True})
        assert False
    except AnsibleError:
        pass
    try:
        lookup_module_1.run(terms=[], variables=None, **{'lstrip': True, 'rstrip': True})
        assert False
    except AnsibleError:
        pass

# Generated at 2022-06-25 10:35:04.521962
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.file import LookupModule
    lookup_module_0 = LookupModule()

    # Testcase0: exception
    with pytest.raises(Exception) as ex_0:
        lookup_module_0.run('tests/ansible/test_data/test_file.in')

    # Testcase1: exception
    with pytest.raises(Exception) as ex_1:
        lookup_module_0.run('test_file.in')


test_case_0()
test_LookupModule_run()

# Generated at 2022-06-25 10:35:10.925879
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    args_0_0 = { 'lstrip': True, 'rstrip': True }
    data_0_0 = [ 'file' ]

    # run the lookup_module.run method to test with the given test data

    lookup_module_0.run( data_0_0, **args_0_0)

# Generated at 2022-06-25 10:35:11.470409
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-25 10:35:13.917881
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run([u'everything'])
    assert result == [u'anything goes\n'], "HUH?"


# Generated at 2022-06-25 10:35:20.697541
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        lookup_module.run(terms=['/etc/ansible/ansible.cfg'], variables={'ansible_playbook_python': '/usr/bin/python3.6'})
    except Exception as err:
        print('Exception: {}'.format(err))
    else:
        pass
    finally:
        pass

# Generated at 2022-06-25 10:35:26.985083
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with correct arguments
    try:
        assert lookup_module_0.run(['abcd']) == []
    except Exception:
        fail('test_LookupModule_run failed')



# Generated at 2022-06-25 10:35:30.369465
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    assert lookup_module_0.run("1") is None

# Generated at 2022-06-25 10:35:39.006924
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as excinfo:
        test_case_0()
    assert excinfo.value.args[0] == "could not locate file in lookup: 3313.7"


# Generated at 2022-06-25 10:35:42.623943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    var = lookup_run()



# Generated at 2022-06-25 10:35:46.982488
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:35:54.314971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = "0x41.34f0555c9a08e"
    var_1 = "0x41.34f0555c9a08e"
    var_2 = "Ch8nRwzfhD"
    var_3 = "Ch8nRwzfhD"
    var_4 = "rZwJxbbHk5"
    var_5 = "rZwJxbbHk5"
    var_6 = "PxOuN7VU1bQ"
    var_7 = "PxOuN7VU1bQ"
    var_8 = "j"
    var_9 = "j"
    var_10 = "PxOuN7VU1bQ"
    var

# Generated at 2022-06-25 10:35:58.813138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()


# Testing of f() method

# Generated at 2022-06-25 10:36:00.184164
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_2 = LookupModule()
  lookup_module_2.run(float_0)

# Generated at 2022-06-25 10:36:04.161010
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True == True




# Generated at 2022-06-25 10:36:08.568310
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 244.8
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    # Make sure the compile is working
    var_1 = lookup_run(float_0)



# Generated at 2022-06-25 10:36:12.805917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module_0 = LookupModule()
        try:
            var_0 = lookup_module_0.run(var_0, var_0)
            raise Exception('AnsibleError: could not locate file in lookup')
        except Exception:
            assert True
    finally:
        var_0 = None


# Generated at 2022-06-25 10:36:15.366398
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    int_0 = 694
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(int_0)
    var_0 = lookup_run(int_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:36:31.687904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    terms = list()
    ret = lookup_module_0.run(terms)
    assert ret == []
    # assert lookup_module_0.run(terms) == []


# Generated at 2022-06-25 10:36:33.252904
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Tests the run method
    # var1 = lookup_run(terms, variables=variables, **kwargs)
    assert False


# Generated at 2022-06-25 10:36:33.974016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "not implemented"



# Generated at 2022-06-25 10:36:42.073954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    loader = DataLoader()
    inv_host = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    VariableManager.set_inventory(inv_host)
    play_source = dict(
            name="Ansible Play",
            hosts='localhost',
            gather_facts='no',
            tasks=[
                dict(action=dict(module='debug', args=dict(msg='{{lookup("file", "/etc/hosts")}}')))
            ]
        )
    play = Play().load(play_source, variable_manager=VariableManager(), loader=loader)
    t

# Generated at 2022-06-25 10:36:48.801337
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    str_0 = '/etc/hosts'
    var_0 = lookup_module_0.run(str_0)
    lookup_module_1 = LookupModule()
    str_0 = '/etc/hosts'
    var_0 = lookup_module_1.run(str_0)
    lookup_module_2 = LookupModule()
    str_0 = '/etc/hosts'
    var_0 = lookup_module_2.run(str_0)
    lookup_module_3 = LookupModule()
    str_0 = '/etc/hosts'
    var_0 = lookup_module_3.run(str_0)
    lookup_module_4 = LookupModule()
    str_0 = '/etc/hosts'
    var_0 = lookup_

# Generated at 2022-06-25 10:36:54.648036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)


# Generated at 2022-06-25 10:36:57.750019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert True # TODO: implement your test here


# Generated at 2022-06-25 10:36:59.306944
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    float_1 = float_0
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_1)


test_case_0()

# Generated at 2022-06-25 10:37:02.392979
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    lookup_module_1 = LookupModule()
    lookup_module_1 = LookupModule('3313.7')


# test case for run look module

# Generated at 2022-06-25 10:37:04.132883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(var_0, var_0)


# Generated at 2022-06-25 10:37:28.757640
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    ret_0 = lookup_module_2.run(var_0, var_1)
    ret_1 = lookup_module_2.run(var_0, var_1)

# Generated at 2022-06-25 10:37:33.405266
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run(var_0)

# Generated at 2022-06-25 10:37:39.896506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [
        'foo',
        'bar.txt',
        'biz.txt'
    ]
    variables = LookupModule()

    lookup_module_2 = LookupModule()
    lookup_module_2.run(terms, variables)


# Generated at 2022-06-25 10:37:45.894257
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    filename_0 = '/etc/foo.txt'
    var_1 = AnsibleError(filename_0, lookup_module_1)
    lookup_module_1.run(var_0, filename_0)
    assert var_1 == var_0


# Generated at 2022-06-25 10:37:48.560066
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:37:50.360638
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('')


# Generated at 2022-06-25 10:37:56.577431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    lookup_module_1 = LookupModule()
    lookup_module_1.run(float_0)
    lookup_module_2 = LookupModule()
    var_1 = lookup_run(float_0)
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 10:37:59.728389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    unit test: test the run method of class LookupModule
    '''
    print("hello")
    lookup_module_0 = LookupModule()
    run = lookup_module_0.run("foo.txt")
    return run


# Generated at 2022-06-25 10:38:02.287208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 10:38:08.182281
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    import tempfile
    from ansible.module_utils._text import to_bytes
    lookup_module_0 = LookupModule()
    terms_0 = [None, 'a']
    
    with tempfile.NamedTemporaryFile() as file_0:
        file_0.write(to_bytes("{}\n"))
        file_0.flush()
        
        # for ansible 2.7
        # with open(file_0.name) as file_1:
            # contents = file_1.read()
            # print(contents)
        # for ansible 2.8
        with open(file_0.name, 'r') as file_1:
            contents = file_1.read()
            print(contents)
    # run_module(module_name='os', module_args={'path

# Generated at 2022-06-25 10:38:58.374663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['foo.bar'])

# Generated at 2022-06-25 10:39:00.719050
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0)

# Generated at 2022-06-25 10:39:06.345229
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:39:14.635955
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_1 = 2383.0
    var_2 = [ '3313.7', "2383.0" ]
    var_3 = [ 2337.1 ]
    lookup_module_1 = LookupModule()
    var_4 = 2383.0
    var_5 = 2337.1
    var_6 = [ '2383.0', "2337.1" ]
    var_7 = [ 2337.1 ]
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()

# Generated at 2022-06-25 10:39:19.901133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 3313.7
    lookup_module_2 = LookupModule()
    var_1 = lookup_run(float_1)


# Test of method run() of class LookupModule:: testcase with (wrong inputs)

# Generated at 2022-06-25 10:39:24.261218
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = 3313.7
    lookup_module_1 = LookupModule()
    float_2 = 2313.7
    var_2 = lookup_run(float_1, float_2)


# Generated at 2022-06-25 10:39:29.413547
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    term_0 = [Var1]
    variables_0 = lookup_module_0.run(term_0)

# Generated at 2022-06-25 10:39:37.331612
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -11.0
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(float_0)
    lookup_module_2 = LookupModule()
    var_2 = lookup_run(float_0)
    lookup_module_3 = LookupModule()
    var_3 = lookup_run(float_0)
    lookup_module_4 = LookupModule()
    var_4 = lookup_run(float_0)
    lookup_module_5 = LookupModule()
    var_5 = lookup_run(float_0)
    lookup_module_6 = LookupModule()
    var_6 = lookup_run(float_0)

# Generated at 2022-06-25 10:39:39.964420
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    global lookup_module_0
    global var_0
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    global var_0
    var_0 = lookup_run(3313.7)



# Generated at 2022-06-25 10:39:42.379204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:41:44.282928
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)

# Generated at 2022-06-25 10:41:45.709558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    double_0 = 0.0
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(double_0)


# Generated at 2022-06-25 10:41:51.194728
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_term_0 = 'test_term_0'
    mock_term_1 = 'test_term_1'
    mock_term_2 = 'test_term_2'
    mock_terms = [mock_term_0, mock_term_1, mock_term_2]
    float_0 = 3313.7
    float_1 = 3313.7
    float_2 = 3313.7
    float_3 = 3313.7
    float_4 = 3313.7
    float_5 = 3313.7
    int_0 = 3313
    int_1 = 3313
    int_2 = 3313
    int_3 = 3313
    int_4 = 3313
    int_5 = 3313

# Generated at 2022-06-25 10:41:53.376699
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 2718.1
    float_1 = 274.0
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    var_1 = lookup_run(float_1)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:41:55.650692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_module_0.run(float_0)
    lookup_module_1 = LookupModule()
    var_1 = lookup_module_1.run(float_0)
    assert var_1 == var_0

# Generated at 2022-06-25 10:41:58.187787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = [1,2,3]
    var_1 = [1,2,3]
    lookup_module_0 = LookupModule()
    result = LookupModule.run(var_0, var_1)
    assert result == var_1


# Generated at 2022-06-25 10:41:59.505319
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print('Running test_LookupModule_run')
    test_case_0()

# Generated at 2022-06-25 10:42:07.988156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    var_0 = lookup_run()
    lookup_module_1 = LookupModule()

if __name__ == "__main__":
    import sys
    print(' '.join(sys.argv))
    import doctest
    doctest.testmod(sys.modules[__name__])

    def lookup_run(*args, **kwargs):
        return LookupModule().run(*args, **kwargs)

    test_case_0()

# Generated at 2022-06-25 10:42:17.951726
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = '===  expected:'
    terms_1 = '===  actual:'

# Generated at 2022-06-25 10:42:22.310672
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 3313.7
    lookup_module_0 = LookupModule()
    var_0 = lookup_run(float_0)
    lookup_module_1 = LookupModule()