

# Generated at 2022-06-25 10:32:50.889084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert isinstance(lookup_module_0, LookupModule)
    lookup_module_0.run(['/etc/ansible/hosts'])
    lookup_module_0.run(['/etc/ansible/hosts', 'hosts'])

# Generated at 2022-06-25 10:33:01.943923
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # This is a unit test created during the development of the 'file' lookup plugin.
    # The lookup plugin is still in development and this test case may not
    # yet be correct for the finished version of the plugin.
    # If you have an idea of how to properly test the lookup plugin,
    # please improve this test case or let us know!
    terms = []
    variables = {}
    # Testcase fails with the following message:
    # "AnsibleError: could not locate file in lookup: {}"
    assert lookup_module.run(terms, variables) == []

if __name__ == '__main__':

    import pytest
    pytest.main([__file__, '-v', '-s'])
    # test_case_0()

# Generated at 2022-06-25 10:33:09.507833
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {}
    kwargs = {}
    ret = lookup_module_0.run(terms=terms, variables=variables, **kwargs)
    print(ret)

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:13.855246
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options=None, direct={'lstrip': 'lstrip', 'rstrip': 'rstrip'})
    display_0 = Display()
    terms_0 = []
    variables_0 = None
    lookup_module_0.run(terms_0, variables_0, lstrip='lstrip', rstrip='rstrip')


# Generated at 2022-06-25 10:33:16.533506
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert  lookup_module.run(['/etc/foo.txt'], {}) == "the value of foo.txt is ansible"

# Generated at 2022-06-25 10:33:20.940198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_file_0 = 'test_file_0'
    lookup_module_0 = LookupModule()
    test_return_0 = lookup_module_0.run([test_file_0])

# Generated at 2022-06-25 10:33:26.419913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    assert lookup_module_1.run([['/etc/ansible/hozac/Ansible_0.0.0.zip']], None, None) != None

# Generated at 2022-06-25 10:33:28.597868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()


# Generated at 2022-06-25 10:33:39.209731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_loader()

    lookup_module_0.set_basedir('/home/jianan/github/ansible/lib/ansible/plugins/lookup')

# Generated at 2022-06-25 10:33:47.760879
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.module_utils._text import to_bytes
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    import pytest
    import os.path

    test_directory = os.path.dirname(os.path.realpath(__file__))

    test_vars = dict(
        ansible_loader = DataLoader(),
        ansible_variable_manager = VariableManager(),
        ansible_loookup_plugin_terms = 'test',
        ansible_lookup_plugin_rstrip = True,
        ansible_lookup_plugin_lstrip = False,
    )

    lookup_module_0 = LookupModule()

    test_str = to_bytes(u'TestString\n')
    test_file_name = to_bytes

# Generated at 2022-06-25 10:33:55.780561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run()

# Generated at 2022-06-25 10:34:00.681292
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        lookup_module = LookupModule()
        lookup_module.run([])

    except Exception as err:
        print(str(err))
        raise err


# Generated at 2022-06-25 10:34:04.008586
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = []
    variables = {"ansible_check_mode": False, "omit": "__omit_place_holder__4bf7fd0ee384c1eda766b9c9d3fb3bf2"}
    assert lookup_module_0.run(terms=terms, variables=variables)

# Generated at 2022-06-25 10:34:14.882718
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.vault import VaultLib, VaultSecret
    from ansible.plugins.lookup.file import LookupModule
    from ansible.parsing.dataloader import DataLoader

    loader_0 = DataLoader()
    vault_secret_0 = VaultSecret('ansible')
    vault_lib_0 = VaultLib(loader_0, vault_secret_0)
    lookup_module_0 = LookupModule()

    # Test with ansible.plugins.lookup.file.LookupModule and ansible.parsing.dataloader.DataLoader and ansible.parsing.vault.VaultSecret
    # and ansible.parsing.vault.VaultLib and ansible.plugins.lookup.file.LookupModule

# Generated at 2022-06-25 10:34:19.125610
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_obj = lookup_module_0.run(['/etc/host'])
    assert isinstance(lookup_obj, list)
    assert lookup_obj[0] in ['localhost\n127.0.0.1\n\n']

# Generated at 2022-06-25 10:34:23.461473
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Set up
    lookup_module_1 = LookupModule()
    # Tests
    for term in ['a', 'b']:
        lookup_module_1.run(terms, variables=None, **kwargs)

    # Tear down
    pass



# Generated at 2022-06-25 10:34:25.478657
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """ 
    LookupModule run method unit test stub 
    """
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:34:26.302688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # TODO:
    pass


# Generated at 2022-06-25 10:34:28.717762
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # nothing to assert here, just calls.
    lookup_module_0.run('1', '2')


# Generated at 2022-06-25 10:34:38.675089
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    
    # Test with first two parameters having valid values and third parameter having invalid value.
    try:
        lookup_module_1.run([lookup_module_1], [lookup_module_2])
        assert False
    except AnsibleError as e:
        assert str(e) == "could not locate file in lookup: %s"
        print("AnsibleError exception raised")
    
    # Test with all three parameters having valid values.
    lookup_module_3 = LookupModule()
    lookup_module_3.run(["/etc/foo.txt", "bar.txt", "/path/to/biz.txt"])

if __name__ == '__main__':
    test_case_0()
    test_Look

# Generated at 2022-06-25 10:34:47.887796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    lookup_module_0.run(bool_0)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:34:54.884413
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    param_0 = ["/Users/jeff/Downloads/hosts", "/Users/jeff/Downloads/hosts"]
    param_1 = None
    param_2 = None
    param_3 = None
    param_4 = None
    param_5 = None
    param_6 = None
    param_7 = None
    param_8 = None
    ret_0 = lookup_module_2.run(param_0, param_1, param_2, param_3, param_4, param_5, param_6, param_7, param_8)
    assert type(ret_0) is list

# Test that the lookup_module_2 is correct.

# Generated at 2022-06-25 10:35:00.044870
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    with pytest.raises(AnsibleError):
        lookup_module_0.run("terms")

# Generated at 2022-06-25 10:35:05.236019
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {
        'bool' : True,
        'list' : ['list_0'],
        'None' : None
    }
    lookup_module_0 = LookupModule(**dict_0)
    int_0 = 1
    test_case_0(int_0)

# Called when testing if the file exists in the search path

# Generated at 2022-06-25 10:35:10.219375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    

# Generated at 2022-06-25 10:35:11.927063
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:35:18.069604
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    dict_2 = {}
    dict_3 = {}
    lookup_module_1 = LookupModule(dict_2, **dict_3)
    list_0 = []
    var_0 = lookup_run(bool_0)
    dict_4 = {}
    dict_5 = {}
    lookup_module_2 = LookupModule(dict_4, **dict_5)
    dict_6 = {}
    dict_7 = {}
    lookup_module_3 = LookupModule(dict_6, **dict_7)
    dict_8 = {}
    dict_9 = {}

# Generated at 2022-06-25 10:35:22.699297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:35:25.905080
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    assert_equal(str_0, lookup_module_0.run([str_0, str_0]))


# Generated at 2022-06-25 10:35:29.525493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:35:45.379835
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    input_0 = []
    input_1 = None
    input_2 = {}
    expected_0 = []
    # Call the method with all arguments
    result = LookupModule.run(input_0, input_1, input_2)
    assert expected_0 == result

# Generated at 2022-06-25 10:35:54.004156
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    lookup_module_5 = LookupModule()
    lookup_module_6 = LookupModule()
    lookup_module_7 = LookupModule()
    lookup_module_8 = LookupModule()
    lookup_module_9 = LookupModule()
    lookup_module_10 = LookupModule()
    lookup_module_11 = LookupModule()
    lookup_module_12 = LookupModule()
    lookup_module_13 = LookupModule()
    lookup_module_14 = LookupModule()
    lookup_module_15 = LookupModule()

# Generated at 2022-06-25 10:35:57.412278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:36:00.805673
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:36:06.275580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:36:13.732205
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with arguments used for unit tests.
    term = "test_run_0"
    variables = "test_run_1"
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(term, variables)
    assert ret == "test_run_2"


# Generated at 2022-06-25 10:36:20.083987
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    assert lookup_module_1 == lookup_module_1


# Generated at 2022-06-25 10:36:25.676799
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    lookup_module_0.run()



# Generated at 2022-06-25 10:36:31.181729
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    str_0 = 'test_str'
    str_1 = 'test_str'
    lookup_module_1 = lookup_module_0.run(str_0, **str_1)


# Generated at 2022-06-25 10:36:31.990194
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass


# Generated at 2022-06-25 10:37:00.542846
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule(**dict_1)
    lookup_module_3 = LookupModule(dict_0)
    lookup_module_4 = LookupModule(**dict_0)
    lookup_module_5 = LookupModule(dict_1)
    lookup_module_6 = LookupModule(**dict_0)
    lookup_module_7 = LookupModule(dict_1)
    lookup_module_8 = LookupModule(**dict_0)
    lookup_module_9 = LookupModule(dict_1)

# Generated at 2022-06-25 10:37:09.023631
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    dict_0 = {}
    list_0 = []
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule(dict_0, **dict_0)
    lookup_module_2 = LookupModule(dict_0, **dict_0)
    lookup_module_3 = LookupModule(dict_0, **dict_0)
    lookup_module_4 = LookupModule(dict_0, **dict_0)
    lookup_module_5 = LookupModule(dict_0, **dict_0)
    lookup_module_6 = LookupModule(dict_0, **dict_0)
    lookup_module_7 = LookupModule(dict_0, **dict_0)

# Generated at 2022-06-25 10:37:13.654642
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)


# Generated at 2022-06-25 10:37:24.040297
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    int_0 = lookup_module_0.run(bool_0)
    bool_1 = bool_0
    dict_2 = {}
    dict_3 = {}
    lookup_module_1 = LookupModule(dict_2, **dict_3)
    list_0 = lookup_module_1.run(bool_1)
    bool_2 = True
    str_0 = 'path(s)'
    list_1 = ['foo.txt']
    dict_4 = {}
    dict_5 = {}
    lookup_module_2 = LookupModule(dict_4, **dict_5)

# Generated at 2022-06-25 10:37:30.736580
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = []
    variables = None
    kwargs = {}
    LookupModule_0 = LookupModule()
    LookupModule_2 = LookupModule()
    LookupModule_3 = LookupModule()
    ret_1 = LookupModule_3.run(terms, variables, **kwargs)
    ret_0 = LookupModule_2.run(terms, variables, **kwargs)
    str_0 = ret_0[0]
    ret_0 = LookupModule_0.run(terms, variables, **kwargs)
    ret_0 = LookupModule_1.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:37:34.904943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()
    assert var_0 == 1
    assert var_0 == 1

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:37:40.600866
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:37:46.408900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    display_0 = Display()

    try:
        lookup_module_0.run(list_0, **dict_1)
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-25 10:37:48.254934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.run({}, {})


# Generated at 2022-06-25 10:37:49.803061
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:38:37.544507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    terms = {}; variables = {}; kwargs = {}; dict_2 = {}
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    json_var_0 = json.loads(var_0.decode())
    terms = {}; variables = {}; kwargs = {}; dict_3 = {}
    var_1 = lookup_module_0.run(terms, variables, **kwargs)
    json_var_1 = json.loads(var_1.decode())


# Generated at 2022-06-25 10:38:42.411007
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)


# Generated at 2022-06-25 10:38:45.072838
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    lookup_module_0.run(['', ''])


# Generated at 2022-06-25 10:38:48.388853
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    # Occur Exception
    assert bool_0


# Generated at 2022-06-25 10:38:52.821551
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    lookup_module_0.run()



# Generated at 2022-06-25 10:38:56.885454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    list_0 = lookup_module_0.run(bool_0)
    lookup_module_1 = LookupModule()

# Tests for module lookup.file

# Test for class LookupModule
# Test for method run of class LookupModule

# Generated at 2022-06-25 10:39:03.939964
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    # Test with helper classes

    # dict_1 = dict()
    # dict_0 = dict()
    # dict_2 = dict()
    # dict_3 = dict()
    # dict_4 = dict()
    # dict_5 = dict()
    # dict_6 = dict()
    # dict_7 = dict()
    # dict_8 = dict()
    # dict_9 = dict()
    # dict_10 = dict()
    # dict_11 = dict()
    # dict_12 = dict()
    # dict_13 = dict()
    # dict_14 = dict()
    # dict_15 = dict()
    # dict_16 = dict()
    # dict_17 = dict()
    # dict_18 = dict()
    # dict_19 = dict()


# Generated at 2022-06-25 10:39:05.997212
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:39:15.907667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:39:21.867939
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule(**dict_1)
    lookup_module_2 = lookup_run(bool_0)
    lookup_module_3 = lookup_run(bool_0)
    lookup_module_4 = lookup_run(bool_0)
    lookup_module_5 = lookup_run(bool_0)
    lookup_module_6 = lookup_run(bool_0)

# Generated at 2022-06-25 10:41:03.116815
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:41:05.254616
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:41:09.008308
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    str_0 = lookup_module_0.run()
    assert str_0 == None


# Generated at 2022-06-25 10:41:14.720591
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_run(bool_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:41:18.785446
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    list_0 = [dict_0, dict_1, dict_2]
    dict_4 = {}
    dict_5 = {}
    lookup_module_0 = LookupModule(dict_4, **dict_5)
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(list_0, **dict_3)
    return var_0

# Generated at 2022-06-25 10:41:23.111378
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    str_0 = "qW"
    list_0 = lookup_module_0.run(str_0)


# Generated at 2022-06-25 10:41:26.402600
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}

    # Call method run of class LookupModule
    test_object = LookupModule()
    result = test_object.run(**dict_0)
    class_name = result.__class__.__name__
    assert class_name == "list"


if __name__ == "__main__":
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 10:41:26.885656
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module.run(terms) == results

# Generated at 2022-06-25 10:41:28.323434
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    dict_0 = {}
    dict_1 = {}
    lookup_module_0 = LookupModule(dict_0, **dict_1)
    var_0 = lookup_module_0.run(bool_0)

# Generated at 2022-06-25 10:41:29.219558
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()  # dummy assertion

