

# Generated at 2022-06-25 10:33:00.492650
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(var_options={}, direct={})
    lookup_module_0.get_option('lstrip')
    lookup_module_0.get_option('rstrip')
    lookup_module_0._loader.path_dwim('foo.txt')
    lookup_module_0.find_file_in_search_path({}, 'files', 'foo.txt')
    try:
        lookup_module_0.run(['foo.txt'])
        assert False # Should not reach this line
    except Exception as e:
        assert isinstance(e, AnsibleError)

# Generated at 2022-06-25 10:33:02.737732
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    # Check whether the module run method behaves as expected
    terms = ["/etc/partitions"]
    variables = None
    kwargs = {}
    lookup_module.run(terms, variables, **kwargs)

# Generated at 2022-06-25 10:33:04.918896
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:33:13.922765
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    #
    # Basic tests
    #
    # Creating an object
    lookup_module_0 = LookupModule()
    # Calling run method of object lookup_module_0
    ret_0 = lookup_module_0.run(["/etc/passwd"], {}, **{})
    print(ret_0)
    # Creating an object
    lookup_module_1 = LookupModule()
    # Calling run method of object lookup_module_1
    ret_1 = lookup_module_1.run(["/etc/passwd"], {}, **{})
    print(ret_1)
    # Creating an object
    lookup_module_2 = LookupModule()
    # Calling run method of object lookup_module_2
    ret_2 = lookup_module_2.run(["/etc/hosts"], {}, **{})
   

# Generated at 2022-06-25 10:33:20.271668
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    terms = [
        '/bin/cat',
        './test/test_data/testlookup/testlookup.yaml',
    ]
    variables = None
    kwargs = {}
    lookup_module_1.run(terms, variables, **kwargs)


# Generated at 2022-06-25 10:33:21.504428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run([])

# Generated at 2022-06-25 10:33:32.248847
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    keyword_1 = ('/etc/hosts', 'hosts')
    keyword_2 = '/etc/hosts'
    keyword_3 = '/etc/hosts'
    result_1 = lookup_module_0.run(keyword_1, keyword_2, keyword_3)
    #result_2 = lookup_module_0.run(keyword_2, keyword_2, keyword_3)
    #result_3 = lookup_module_0.run(keyword_3, keyword_2, keyword_3)
    #assert result_1 == result_2
    #assert result_1 == result_3
    #assert result_2 == result_3
    #assert type(result_1) == bool
    #assert type(result_2) == bool
    #assert type(result

# Generated at 2022-06-25 10:33:36.892355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # Variable test_case_0 initialized, do test
    terms_0 = "test_string"
    variables_0 = "test_string"
    lookup_kwargs_0 = "test_string"
    result_0 = lookup_module_0.run(terms_0, variables_0, **lookup_kwargs_0)
    return result_0

# Generated at 2022-06-25 10:33:42.492389
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_options({'_ansible_tmpdir': 'tmpdir'})
    tmpdir = lookup_module_1.get_option('_ansible_tmpdir')
    assert tmpdir == 'tmpdir'
    terms = (u'a', u'b')
    variables = {'a': 'a', 'b': 'b'}
    ret = lookup_module_1.run(terms, variables)
    assert ret == [u'a', u'b']



# Generated at 2022-06-25 10:33:44.234075
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run('foo.txt') == ["Hello, world!"]

# Generated at 2022-06-25 10:33:56.630602
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit test for method run of class LookupModule
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

# Generated at 2022-06-25 10:34:03.079466
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = dict()
    dict_1 = dict()
    lookup_module_0 = LookupModule(dict_0)
    set_0 = set()
    str_0 = 'U6Zu}g`h`7'
    dict_2 = {str_0: lookup_module_0}
    str_1 = '='
    dict_3 = {str_1: set_0}
    var_0 = lookup_run(str_1, **dict_2)
    var_1 = lookup_run(str_1, **dict_3)

# Generated at 2022-06-25 10:34:14.818580
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = '@'
    str_1 = 'W_e'
    str_2 = 'w~8V'
    str_3 = '4N:NnLQ@'
    set_1 = {str_0, str_1, str_2, str_3}
    str_4 = 'L'
    str_5 = '7'
    str_6 = 'g'
    str_7 = 'O&~'
    set_2 = {str_4, str_5, str_6, str_7}
    str_8 = ',I'
    str_9 = ' Z'
    str_10 = '2B'
    str_11 = 'mo'
    set_3 = {str_8, str_9, str_10, str_11}

# Generated at 2022-06-25 10:34:21.979262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_0 = 'w'
    str_0 = 'MnYnD}'
    var_1 = {str_0: var_0}
    str_1 = '-'
    var_2 = {str_1: str_1}
    lookup_module_0 = LookupModule(var_2)
    assert_equal(lookup_module_0.run(), var_1)

# Generated at 2022-06-25 10:34:28.878123
# Unit test for method run of class LookupModule
def test_LookupModule_run():

  # Test case with parameter terms and variables, return value _raw
  set_0 = set()
  str_0 = ';p`^B)=g#8W<'
  dict_0 = {str_0: set_0}
  lookup_module_0 = LookupModule(dict_0)
  var_0 = lookup_run(set_0, **dict_0)

  # Test case with parameter terms and variables, return value _raw
  set_0 = set()
  str_0 = ','
  dict_0 = {str_0: set_0}
  lookup_module_0 = LookupModule(dict_0)
  var_0 = lookup_run(set_0, **dict_0)

  # Test case with parameter terms and variables, return value _raw
  set_0 = set()
  str_

# Generated at 2022-06-25 10:34:36.395915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)


# Generated at 2022-06-25 10:34:43.089022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

# Generated at 2022-06-25 10:34:47.126428
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    var_0 = lookup_run(set())
    for var_1 in var_0:
        print(var_1)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:34:49.007516
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    var_0 = lookup_module_1.run(terms, **variables)


# Generated at 2022-06-25 10:34:52.454814
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set(['V5*'])
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_1 = LookupModule(dict_1)
    var_0 = lookup_module_1.run(set_0, **dict_0)
    assert var_0 == None

# Generated at 2022-06-25 10:35:06.765757
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.lookup.file import LookupModule
    import __builtin__
    set_0 = set()
    dict_0 = {'fake_data': set_0}
    dict_1 = {'fake_data': set_0}
    lookup_module_0 = LookupModule(dict_0)
    lookup_module_1 = LookupModule(dict_1)
    lookup_module_0.set_options(var_options=dict_1)
    lookup_module_1.set_options(var_options=dict_0)
    str_0 = 'B[0Zk|A=+xq3J9?Wc%'
    set_1 = {str_0}
    lookup_module_0.run(set_1)

# Generated at 2022-06-25 10:35:13.006138
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'y:bA0G3d;wU5^'
    dict_0 = {str_0: set_0}
    str_1 = 'p'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)


# Generated at 2022-06-25 10:35:23.097917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a mock for the call run
    lookup_run = LookupModule.run
    # Setting up the mock's return_value
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)
    assert var_0 == []

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 10:35:27.835219
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(**dict_0)

# Generated at 2022-06-25 10:35:35.318723
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)
    assert var_0 == []


# Generated at 2022-06-25 10:35:40.713422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    params_0 = {'rstrip': True, 'lstrip': True}
    set_0 = set()
    str_0 = '0A)N.3>r'
    dict_0 = {str_0: set_0}

    try:
        lookup_module_0 = LookupModule(params_0)
        var_0 = lookup_module_0.run(**dict_0)
        assert (var_0 is None)
    except:
        raise


# Generated at 2022-06-25 10:35:45.092988
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = {'rstrip': True, 'lstrip': False}
    lookup_module_0 = LookupModule(dict_0)
    assert lookup_module_0.run(set_0) == []

# Generated at 2022-06-25 10:35:54.030335
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = ')'
    dict_0 = {str_0: set_0}
    str_1 = '?'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)
    assert var_0 == []
    set_0 = set()
    str_0 = '9XW,e"Q'
    dict_0 = {str_0: set_0}
    str_1 = '\'~(9,W_y/'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)

# Generated at 2022-06-25 10:36:00.440646
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = '=+W,P'
    str_1 = 'w/-v'
    list_2 = [str_1, str_0]
    str_2 = '`:u`i'
    list_3 = [str_0, str_2]
    list_4 = [list_2, list_3]
    str_3 = ';'
    str_4 = 'I'
    str_5 = '#Qb'
    str_6 = 'n#t~'
    str_7 = 'z'
    list_5 = [str_4, str_7, str_6, str_5]
    str_8 = 'w'
    str_9 = 'I;D'
    set_1 = set(list_5)
    list_6

# Generated at 2022-06-25 10:36:07.040750
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'oRiK{sGt'
    dict_0 = {str_0: set_0}
    str_1 = 'f!EP'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

# Generated at 2022-06-25 10:36:21.075197
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 'j$0zAYXZQ2GvS8W' in LookupModule.run(LookupModule('d:D"l"-l'), '{J-k6I3q6m', **{'A(mTfzCv%":W@': '^"FksAN)`'})


# Generated at 2022-06-25 10:36:25.850403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule('')
    str_0 = 'w[sZ@a-6];'
    str_1 = '#!9N'
    str_2 = '{C8/n1/{{v6 7'
    str_3 = '#W9XQY'
    str_4 = '8c'
    str_5 = ':0'
    list_0 = [str_0, str_1, str_2, str_3, str_4, str_5]
    var_0 = lookup_module_0.run(list_0)
    print(var_0)

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:36:33.638187
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = 'ev0d/i'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)
    var_1 = lookup_module_0.run(set_0, **dict_0)

# Generated at 2022-06-25 10:36:37.122664
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run()


# Generated at 2022-06-25 10:36:44.378651
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(set_0, **dict_0)

# Generated at 2022-06-25 10:36:49.071948
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    dict_0 = {'rstrip': True, 'lstrip': False}
    lookup_module_0 = LookupModule(dict_0)

    set_0 = {'L-0w$)%cR*NN&H:0G*)}gq0f*'}
    lookup_module_1 = lookup_module_0.run(set_0, **dict_0)

    assert type(lookup_module_0) == LookupModule
    assert type(lookup_module_1) == list

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-25 10:36:57.150307
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(set_0, dict_0)
    assert var_0 == []
    assert dict_0[str_0] == {}



# Generated at 2022-06-25 10:37:03.823290
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    try:
        str_0 = 'q%#-pN'
        lookup_module_0 = LookupModule(str_0)
        var_0 = lookup_module_0.run()
        import set
        set_0 = set.set_intersection(set_0, set_0)
        lookup_module_0 = LookupModule(str_0)
        set_0 = lookup_module_0.run(set_0)
        print(set_0)
    except Exception as err_0:
        print(err_0)


# Generated at 2022-06-25 10:37:10.215252
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # this is the first test of this module
    lookup_module_0 = LookupFile()
    terms = ['foo.bar']
    lookup_module_0.run(terms, {}, rstrip=True, lstrip=False)

    # LookupModule.run is not a coroutine, do not yield
    # yield

# Generated at 2022-06-25 10:37:12.841379
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:37:43.524952
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_0 = LookupModule()
    str_0 = 'terms'
    str_1 = ''
    str_2 = 'variables'
    str_3 = 'kwargs'
    str_4 = 'rstrip'
    str_5 = 'lstrip'
    str_6 = 'term'
    str_7 = 'Y{@_2:r: 7U-6#k*gN,'
    str_8 = '_'
    str_9 = 'lookup_run'
    str_10 = 'lookup_module_1.run(set_0, **dict_0)'
    lookup_module_2 = LookupModule()
    lookup_module_0 = LookupModule()
    str_

# Generated at 2022-06-25 10:37:44.396863
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    x = LookupModule(dict())
    x.run(set())

# Generated at 2022-06-25 10:37:47.394217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    var_0 = lookup_run(set_0, **dict_0)
    assert var_0 == []


# Generated at 2022-06-25 10:37:55.088917
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(set_0, dict_0)
    assert var_0 == ['']

# Generated at 2022-06-25 10:38:03.234418
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(set_0, **dict_0)
    assert var_0 == []


# Generated at 2022-06-25 10:38:09.608825
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    expected_value = "test"
    test_file = "test_file.txt"
    w = open(test_file, 'w')
    w.write(expected_value)
    w.close()


# Generated at 2022-06-25 10:38:13.617174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.set_loader({'file_exists': lambda str_0: True})  # set_loader for method run of class LookupModule



# Generated at 2022-06-25 10:38:17.970210
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

# Generated at 2022-06-25 10:38:23.156946
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'y'
    dict_0 = {str_0: set_0}
    lookup_module_0 = LookupModule(dict_0)
    var_0 = lookup_module_0.run(set_0, **dict_0)
    assert var_0 == []

# Test for method _get_file_contents of class AnsibleFile

# Generated at 2022-06-25 10:38:27.634902
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    display_0 = Display()
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(set_0, **dict_0)


# Generated at 2022-06-25 10:39:15.155224
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule({})
    result = lookup_module_0.run([])
    assert result == []
    result = lookup_module_0.run({})
    assert result == []
    result = lookup_module_0.run([], **{})
    assert result == []
    result = lookup_module_0.run({}, **{})
    assert result == []
    result = lookup_module_0.run({}, **{})
    assert result == []
    result = lookup_module_0.run(**{})
    assert result == []
    result = lookup_module_0.run([], **{})
    assert result == []

if __name__ == '__main__':
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:23.188855
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set([])
    str_0 = 'zgU6>'
    str_1 = 'q'
    str_2 = 'x$!.'
    str_3 = '*5&F'
    list_0 = [str_0, str_1, str_2, str_3]
    dict_0 = {str_0: list_0}
    lookup_module_0 = LookupModule(dict_0)
    str_4 = ' g'
    str_5 = '-'
    str_6 = 'Gt9Mb\'<'
    str_7 = '|Qwa'
    str_8 = 's'
    str_9 = '4?c%a'
    str_10 = 'W`'

# Generated at 2022-06-25 10:39:24.016027
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()

# Generated at 2022-06-25 10:39:31.229607
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    str_1 = '4+g8a'
    str_2 = '_'
    str_3 = "fP'U"
    str_4 = '_'
    str_5 = "'1wO'"
    lookup_module_0 = LookupModule(None)
    lookup_module_0.set_options(var_options=None, direct={str_2: str_3, str_4: str_5})
    lookup_module_0.run([str_0, str_1])


# Generated at 2022-06-25 10:39:35.780910
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(set_0, **dict_0)

# Generated at 2022-06-25 10:39:38.076779
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    with pytest.raises(AnsibleError) as excinfo:
        lookup_module_0 = LookupModule()
        var_0 = lookup_module_0.run(var_0)

# Generated at 2022-06-25 10:39:39.871199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str = ']'
    dict = {str: str}
    lookupModule = LookupModule(dict)
    assert lookupModule.run([str]) == [str]


# Generated at 2022-06-25 10:39:46.124451
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    dict_0 = {'rstrip': False, '_terms': set_0}
    lookup_module_0 = LookupModule(dict_0)
    dict_1 = dict_0
    dict_1['rstrip'] = True
    dict_1['_terms'] = set_0
    lookup_module_1 = LookupModule(dict_1)
    dict_2 = dict_0
    dict_2['rstrip'] = False
    dict_2['_terms'] = set_0
    lookup_module_2 = LookupModule(dict_2)
    dict_3 = dict_0
    dict_3['rstrip'] = False
    dict_3['_terms'] = set_0
    lookup_module_3 = LookupModule(dict_3)
    dict_4 = dict_

# Generated at 2022-06-25 10:39:49.975285
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(**dict_0)

# Generated at 2022-06-25 10:39:53.120421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if (1):
        fixture_0 = [set(), set(), set()]
        var_1 = fixture_0[1]
        fixture_1 = [set(), set(), set()]
        var_2 = fixture_1[1]

    lookup_module_0 = LookupModule(var_1)
    lookup_module_0.run(var_2)


# Generated at 2022-06-25 10:41:48.455333
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    str_0 = 'F'
    str_1 = '('
    str_2 = '\x04{'
    str_3 = 'Y{@_2:r: 7U-6#k*gN,'
    str_4 = 'z'
    str_5 = '*\x14\x0c\x12'
    str_6 = '\x06'
    str_7 = '\x10\r \x06\x1d,'
    str_8 = '}'
    str_9 = '\x05\x1d\b\x1e\x1f'
    str_10 = '\x17)D\x19\x1c'
    str_11 = ','
    str_12 = '\x0f\x0c'
    str_13 = '='


# Generated at 2022-06-25 10:41:53.055146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None)
    set_0 = set()
    str_0 = 'Xp[^R8'
    dict_0 = {str_0: set_0}
    str_1 = '.'
    dict_1 = {str_1: str_1}
    lookup_run(set_0, **dict_0)


# Generated at 2022-06-25 10:41:56.762695
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

# Generated at 2022-06-25 10:42:02.217454
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test object
    lookup_module_0 = LookupModule(dict())

    # Create test objects
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_1 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

    # Check results
    assert var_0 == var_0
    assert lookup_module_0 != lookup_module_1
    assert lookup_module_0 == lookup_module_0
    assert lookup_module_1 != lookup_module_0


# Generated at 2022-06-25 10:42:08.857038
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    lookup_module_0.run(**dict_0)

if __name__ == "__main__":
    # Unit test for method run of class LookupModule
    test_LookupModule_run()

# Generated at 2022-06-25 10:42:12.685760
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(private__variable_name='private__variable_name')

    try:
        lookup_module_0.run()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 10:42:14.602369
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0 = run('examples', type='example')


# Generated at 2022-06-25 10:42:16.710476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = []
    var = lookup_module_0.run(list_0)
    return var

# Generated at 2022-06-25 10:42:19.171503
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_run(set_0, **dict_0)

# Generated at 2022-06-25 10:42:26.091053
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    set_0 = set()
    str_0 = 'Y{@_2:r: 7U-6#k*gN,'
    dict_0 = {str_0: set_0}
    str_1 = '_'
    dict_1 = {str_1: str_1}
    lookup_module_0 = LookupModule(dict_1)
    var_0 = lookup_module_0.run(**dict_0)
    assert var_0 == '_'