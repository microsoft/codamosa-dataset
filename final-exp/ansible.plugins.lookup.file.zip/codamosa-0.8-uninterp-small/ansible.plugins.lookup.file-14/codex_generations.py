

# Generated at 2022-06-25 10:32:55.439109
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1619.8
    lookup_module_0 = LookupModule(float_0)
    


# Generated at 2022-06-25 10:33:03.518376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1619.8
    lookup_module_0 = LookupModule(float_0)
    bool_0 = False
    bool_1 = False
    str_0 = '*0@'
    str_1 = 'foo_bar'
    str_2 = 'foo_bar'
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()
    float_5 = float()
    float_6 = float()
    float_7 = float()
    float_8 = float()
    float_9 = float()
    float_10 = float()
    float_11 = float()

# Generated at 2022-06-25 10:33:09.658509
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule(100)
    ansible_vars_1 = {}
    lookup_module_1._loader = None
    lookup_module_1._templar = None
    # TODO: implement check for LookupModule.run()


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:33:13.914954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_1 = -1619.8
    lookup_module_1 = LookupModule(float_1)
    list_1 = ['foo', 'bar', 'baz']
    dict_1 = {}
    dict_1['lstrip'] = True
    dict_1['rstrip'] = True
    lookup_module_1.run(list_1, dict_1)
    float_2 = -1619.8
    lookup_module_2 = LookupModule(float_2)
    list_2 = ['foo', 'bar', 'baz']
    dict_2 = {}
    dict_2['lstrip'] = True
    dict_2['rstrip'] = True
    lookup_module_2.run(list_2, dict_2)
    float_3 = -1619.8
    lookup_module_3 = Look

# Generated at 2022-06-25 10:33:15.961912
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -1619.8
    lookup_module_0 = LookupModule(float_0)
    float_1 = -1619.8
    variables_0 = float_1
    float_2 = -1619.8
    terms_0 = float_2
    str_0 = lookup_module_0.run(terms_0, variables_0, )
    assert str_0 is None

# Generated at 2022-06-25 10:33:19.526823
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_str = 'lookup_str'
    lookup_module_1 = LookupModule(lookup_str, terms=[])
    assert lookup_module_1.run(['file_name']) == []
    lookup_module_2 = LookupModule(lookup_str, terms=['file_name'])
    assert lookup_module_2.run(['file_name']) == []
    lookup_module_3 = LookupModule(lookup_str, terms=[], rstrip=True)
    assert lookup_module_3.run(['file_name']) == []
    lookup_module_4 = LookupModule(lookup_str, terms=[], rstrip=True, lstrip=True)
    assert lookup_module_4.run(['file_name']) == []

# Generated at 2022-06-25 10:33:25.583392
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    bits_0 = -3785
    lookup_module_0.run(bits_0)
    bits_1 = -7684
    lookup_module_0.run(bits_1)
    lookup_module_0.run(bits_0)
    bits_2 = -2161
    lookup_module_0.run(bits_2)
    bits_3 = -839
    lookup_module_0.run(bits_3)
    bits_4 = 0
    lookup_module_0.run(bits_4)
    lookup_module_0.run(bits_2)
    lookup_module_0.run(bits_4)
    bits_5 = -1514
    lookup_module_0.run(bits_5)

# Generated at 2022-06-25 10:33:28.983278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("\n--- test_LookupModule_run ---\n")

    float_0 = -1619.8
    lookup_module_0 = LookupModule(float_0)
    lookup_module_0.run(terms=terms)

    print("\n---------------------------------\n")


# Generated at 2022-06-25 10:33:35.557482
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(0.5)
    terms_0 = (0.1, 0.3)
    ret_0 = lookup_module_0.run(terms_0)
    assert "rstrip" in ret_0
i = 0
while i < 10:
    test_LookupModule_run()
    i += 1
test_case_0()

# Generated at 2022-06-25 10:33:43.340453
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = -130.8
    LookupModule_0 = LookupModule(float_0)
    boolean_0 = True
    float_1 = 4.8E-322
    float_2 = -0.0
    float_3 = 0.0
    str_0 = 'false'
    float_4 = -9.9
    str_1 = 'undefined'
    float_5 = 4294967295.0
    float_6 = -0.9
    float_7 = 6.088E-307
    float_8 = 739.8
    float_9 = 4.9E-324
    float_10 = -0.0
    float_11 = -1.8E-322
    float_12 = -0.0
    str_2 = 'true'
    str_3 = 'false'

# Generated at 2022-06-25 10:33:48.803818
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  terms = ["/path/to/foo.txt"]
  ret = lookup_module.run(terms, variables=None, **{})
  assert(isinstance(ret, list))


# Generated at 2022-06-25 10:33:53.854809
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    config_data = """
    - debug: msg="the value of foo.txt is {{lookup('file', '/etc/foo.txt') }}"

    - name: display multiple file contents
      debug: var=item
      with_file:
        - "/path/to/foo.txt"
        - "bar.txt"  # will be looked in files/ dir relative to play or in role
        - "/path/to/biz.txt"
    """
    config_data = yaml.load(config_data)
    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(config_data)


# Generated at 2022-06-25 10:34:00.767774
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test a string with no variables ( terms )
    lookup_module_0 = LookupModule()

    terms = ["  a  "]
    variables = {}
    kwargs = {}

    expected = ["  a  "]
    result = lookup_module_0.run(terms, variables, **kwargs)

    # check if length of result matches length of expected
    assert( len(result) == len(expected) )

    # check if each element of the result matches the
    # expected element for its corresponding index 
    for index in range(len(result)):
        assert(result[index] == expected[index])


# Generated at 2022-06-25 10:34:02.909022
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    args_0 = ['test', 'test']
    res_0 = lookup_module_0.run(args_0)
    assert res_0 is None

# Generated at 2022-06-25 10:34:04.829425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run('/etc/passwd','/var/log/foo.log')

# Generated at 2022-06-25 10:34:06.867808
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(terms=['../../../../../../etc/passwd'])
    assert ret == []

# Generated at 2022-06-25 10:34:17.605133
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = ['C:/Users/anura/AppData/Local/Temp/ansible_file_payload_xnmx/ansible_file_payload_1twn/', 'C:/Users/anura/AppData/Local/Temp/ansible_file_payload_xnmx/ansible_file_payload_col7/']
  variables = None
  kwargs = {'rstrip':'True', 'lstrip':'False'}
  expected = to_text(open('').read(), errors='surrogate_or_strict')
  try:
    result = lookup_module_0.run(terms, variables=variables, kwargs=kwargs)
    assert result == expected
  except AssertionError:
    print('\ntest_LookupModule_run assertion error')


# Generated at 2022-06-25 10:34:26.762597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # declare args
    terms = None
    variables = None
    kwargs = {}

    lookup_module_0 = LookupModule()
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == []
    kwargs = { '_terms' : [ u'foo.txt', u'bar.txt' ], 'lstrip' : False, 'rstrip' : True}
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == []
    kwargs = { '_terms' : [ u'foo.txt', u'bar.txt' ], 'lstrip' : False, 'rstrip' : False}
    result = lookup_module_0.run(terms, variables, **kwargs)
    assert result == []

# Generated at 2022-06-25 10:34:29.007800
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    lookup_module_1.run([])
    lookup_module_1.run(['lookup_file'])

# Generated at 2022-06-25 10:34:35.516747
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ["hostvars.yml"]
    variables_0 = None
    kwargs_0 = {}
    assert lookup_module_0.run(terms_0, variables_0, **kwargs_0) == ["{{ hostvars }}"]


# Generated at 2022-06-25 10:34:46.643665
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.set_options()
    lookup_module.run = LookupModule.run
    lookup_module.run(['file1.yml'])
    lookup_module.run(['file2.yml'])

# Generated at 2022-06-25 10:34:52.912785
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()

    # Getting test results
    _test_results = dict()
    _test_results['terms'] = [
        'test_terms_0.txt'
    ]

    _test_results['variables'] = {}

    _test_results['kwargs'] = {}

    # Getting expected results
    _expected_results = ['test_terms_0\n']

    # Actual function call
    _actual_results = lookup_module_0.run(_test_results['terms'])

    # Check if expected results match actual results
    assert _expected_results == _actual_results

# Generated at 2022-06-25 10:34:57.681884
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    lookup_module_run = lookup_module.run(terms=['a', 'b'], variables=None, **{'lstrip': True, 'rstrip': True})
    display.display(lookup_module_run)
    assert lookup_module_run is not None

# Generated at 2022-06-25 10:34:58.217489
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-25 10:35:01.372603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    my_lookup_module = LookupModule()
    terms = ["/etc/hosts"]
    lookup_module_0 = LookupModule.run(my_lookup_module, terms, None)

# Generated at 2022-06-25 10:35:05.314891
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  #lookup_module_0.run(terms, variables=None, **kwargs)
  lookup_module_0.run("test")
  assert "test" in lookup_module_0.run("test")

# Generated at 2022-06-25 10:35:08.896339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  lookup_module_0.set_options(direct=dict())
  assert lookup_module_0.run([]) == []

# Generated at 2022-06-25 10:35:13.801168
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_arg_0 = [u'/tmp/files/file.txt']
    lookup_arg_1 = {}
    test_result = lookup_module_0.run(lookup_arg_0, lookup_arg_1)
    print("test_result = " + str(test_result))
    return

test_LookupModule_run()

# Generated at 2022-06-25 10:35:15.695788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module = LookupModule()
  assert lookup_module.run(['']) == []

# Generated at 2022-06-25 10:35:26.044289
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    # 
    var_terms = ""
    # 
    var_variables = ""
    # 
    var_kwargs = ""
    # Pass argument test_case_0 to run()
    var_kwargs['test_case_0'] = test_case_0;
    # Calling run() with arguments (var_terms, var_variables, var_kwargs)
    lookup_module_0.run(var_terms, var_variables, **var_kwargs)
    # Pass argument test_case_1 to run()
    var_kwargs['test_case_1'] = test_case_1;
    # Calling run() with arguments (var_terms, var_variables, var_kwargs)

# Generated at 2022-06-25 10:35:39.770868
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = "\r'zVt!(k8rz&\x0c"
    bytes_0 = b'F\xc8]\x19\xa0J\x1b_d\x17\xbf[\x88\xbc\nm\x81\xa6\x03\xa1'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(bool_0, str_0)

# Generated at 2022-06-25 10:35:49.907883
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms_0 = "a2\x1f\x1c"
    variables_0 = "\x0bC\x0bP?\x11\x1e\x0fO\x15\x1c\x0e8\x17\x14\x11\x18\x1d\x12T\x02\x1e\x13\r\r\x006?\x16\x1e\x06\x02\x0e\x1a\x1b\x1b\x05\x1e"
    __tracebackhide__ = True
    try:
        LookupModule.run(terms_0, variables_0)
    except:
        pass


# Generated at 2022-06-25 10:35:53.074584
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:36:03.121541
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:36:13.861195
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(b'\x1cy\xb9\x18\xbd\x16i\xac\xc8\x14\x1c\x16\xfd\x9e\x0c\x0e\xcb\xc3\x0f\x1d\x10\xfc\x9f\x0d\x0f\xca\xc2\x0e')
    str_0 = ":h\x8e\xcd\xcf=e\xac\xc8\x14\x1c\x16\xfd\x9e\x0c\x0e\xcb\xc3\x0f\x1d\x10\xfc\x9f\x0d\x0f\xca\xc2\x0e"

# Generated at 2022-06-25 10:36:23.733300
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    if bool_0:
        var_1 = lookup_module_0.run('w|.I-\x1c\r\\\x7f"N\x82\xa7\x03M\x8a\x93\x06\xfc\x13\xe5')
        var_2 = lookup_module_0.run('\xdc\x90\xac\x1c\x17\x05e\x7f\xa2^\x8a\x93\x06\xfc\x13\xe5')
    else:
        var_3 = lookup_module_0.run("\xeaL\x04\x17\x05e\x7f\xa2^\x8a\x93\x06\xfc\x13\xe5")

# Generated at 2022-06-25 10:36:25.891171
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    var_0 = lookup_module_0.run(str_0, str_0)


# Generated at 2022-06-25 10:36:36.077321
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  
  # Set up test case
  bool_0 = True
  str_0 = "3q\x1d\x82'S\x15\x1d\x89\xd8!\xdf\x81\x00\xb6\x00>\x06\x80\xfd\x89\x8a\xa0\x04\xac\x91\xb8\xa7\x92\x91"
  bytes_0 = b'k'
  lookup_module_0 = LookupModule(bytes_0)
  var_0 = lookup_run(bool_0, str_0)

  # Test method
  # Test name
  test_name = "test_run_0"
  test_desc = "LookupModule.run"

# Generated at 2022-06-25 10:36:42.945196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(str_0)
    lookup_module_0.set_options(var_options=variables, direct=kwargs)
    assert (lookup_module_0.run(terms, variables=None, **kwargs) == ret), "lookup_module_0.run(terms, variables=None, **kwargs) != ret"

# Functional test for method run of class LookupModule

# Generated at 2022-06-25 10:36:49.204692
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  bool_0 = False
  str_0 = "`\x1d\x9f\x84\xc8\x02\x00\x80\x14\x8d\x93\x99\x9e\x9f\x0c\xd2D\x00\xaa\x01\x7fx\x9e\x84\xcf"
  bytes_0 = b'\xcb~\xec\x0e\x93\x9fZ}L\x0b\xbd\r\xb6\xed\xdb\x02\xeb~\x9b\x19\x1b\xb7\x15\xd3'
  lookup_module_0 = LookupModule(bytes_0)
  var_0 = lookup_run(bool_0, str_0)

# Generated at 2022-06-25 10:37:05.242204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = '1.0\x0c'
    bytes_0 = b'\xe0\x9b\x8e\x04\x0e\xbf\xe2z\x96\xcc\x1d\x8b\x9b\x82\xac\x0c\x8a\x90\x94\xe3\x91'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_module_0.run(bool_0, str_0)
    assert True


# Generated at 2022-06-25 10:37:15.225746
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = "h\xbf\x8b\x0f\xa6\x88\xddC\xd0"
    bytes_0 = b'\xab\xfa\x07\xb7T\xd1\x9a\xefs\xb3\xd3\x0c\xe8\x14\t\xac'
    lookup_module_0 = LookupModule(bytes_0)
    str_1 = "wG{|\x00\xeb2I\x9f\xbe\xaa\x1c\xd0"
    dict_0 = dict()
    dict_0['rstrip'] = True
    dict_0['lstrip'] = True
    var_0 = lookup_module_0.run(str_1, dict_0)


# Generated at 2022-06-25 10:37:26.674901
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Run method
    # test_case_0

    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.loader import lookup_loader

    yaml_data = u"""
    name: foo
    bar: "{{ lookup('file', './tests/unit/lookup_plugins/test.txt') }}"
    baz: "{{ lookup('file', '/should/not/exist') }}"
    """

    lookup_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'lookup_plugins'))

    results = ansible_runner.run(yaml_data, python_interpreter='python3')
    assert len(results['contacted']) == 1
    result = results['contacted']['localhost']
   

# Generated at 2022-06-25 10:37:36.306515
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(None, None)
    str_0 = "\tV'\t9\x7f\x93\r\r7$\r"
    str_1 = "\tV'\t9\x7f\x93\r\r7$\r"
    str_2 = "\tV'\t9\x7f\x93\r\r7$\r"
    str_3 = "\tV'\t9\x7f\x93\r\r7$\r"
    str_4 = "\tV'\t9\x7f\x93\r\r7$\r"
    str_5 = "\tV'\t9\x7f\x93\r\r7$\r"

# Generated at 2022-06-25 10:37:44.292160
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule(b'p\xed\xb1\x9c\xa3\xc3\xd3\x8d\xd5\x04\xfcN\x8f\xdb\x9f\xc4\x19\xbe\x80')

# Generated at 2022-06-25 10:37:53.500805
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  assert type(lookup_module_0).__name__ == 'LookupModule'
  assert lookup_module_0.run('var' in globals()) == [u'var']
  assert lookup_module_0.run(['var', 'a', 'b']) == [u'var', u'a', u'b']
  # TODO: add unit test for LookupModule.run when var_options is None
  # TODO: add unit test for LookupModule.run when terms is None
  # TODO: add unit test for LookupModule.run when module_path is None
  # TODO: add unit test for LookupModule.run when lookup_plugin_templar is None
  # TODO: add unit test for LookupModule.run when loader is None
  # TODO: add unit test for LookupModule.run when

# Generated at 2022-06-25 10:37:54.460221
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_case_0()


# Generated at 2022-06-25 10:37:58.020967
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  terms = str(42)
  variables = str(42)
  kwargs = str(42)
  lookup_module_0 = LookupModule(terms, variables, kwargs)
  lookup_module_0.run(terms, variables, kwargs)



# Generated at 2022-06-25 10:38:02.922887
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    str_1 = "}%\x92\xef\x8c\x06\xdf\xa9\x95\x1c\xf9\xfd\xf1\xfe\xe8\n\x81\x99"
    lookup_module_1 = LookupModule(str_1)
    str_2 = "/"
    dict_1 = {"a": "y"}
    lstrip = lookup_module_1.run(str_2, dict_1)
    assert 1 == len(lstrip)

# Generated at 2022-06-25 10:38:08.544810
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:38:34.184280
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Parameters (args)
    terms = "L7"
    variables = None
    kwargs = {u"rstrip": False, u"lstrip": False}

    # Return type
    ret = []
    lookup_module_0 = LookupModule(ret)
    var_0 = lookup_module_0.run(terms, variables, **kwargs)
    return var_0



# Generated at 2022-06-25 10:38:40.436932
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run(['/']) == ['/']
    assert lookup_module_0.run

# Generated at 2022-06-25 10:38:42.154724
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0:
    test_case_0()



# Generated at 2022-06-25 10:38:46.866708
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = '{i)$'
    bytes_0 = b'W\xdd\xab\x08,\xe8\xbf\xbc\x9b\xe3\x8e\xc6\xe1\x12\xa2\x11'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(bool_0, str_0)


# Generated at 2022-06-25 10:38:51.644370
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_1 = LookupModule()
    lookup_module_2 = LookupModule()
    lookup_module_3 = LookupModule()
    lookup_module_4 = LookupModule()
    # From parameter test case 0
    bool_0 = False
    str_0 = "\r'zVt!(k8rz&\x0c"
    bytes_0 = b'F\xc8]\x19\xa0J\x1b_d\x17\xbf[\x88\xbc\nm\x81\xa6\x03\xa1'
    # From parameter test case 1

# Generated at 2022-06-25 10:38:59.349690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    str_0 = "\x15t\x0cuQ\x18\x0fQ\x1c\x1b\x1b\x1b\x16\x18]"
    lookup_module_0 = LookupModule(str_0)
    str_1 = "\x15t\x0cuQ\x18\x0fQ\x1c\x1b\x1b\x1b\x16\x18]"
    str_2 = "\x15t\x0cuQ\x18\x0fQ\x1c\x1b\x1b\x1b\x16\x18]"

# Generated at 2022-06-25 10:39:07.857391
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    parameters_0 = {'rstrip': True, 'lstrip': True}
    lookup_module_0 = LookupModule(parameters_0)
    terms_0 = {'path': 'V8W1]dcYex'}
    lookup_module_0.run(terms_0, False)
    lookup_module_0.run(terms_0, False)


if __name__ == "__main__":
    test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:11.417034
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = "2'&"
    bytes_0 = b'\x1822\xeb\xdc\xc5[\x8f\x12\xab\xad\xf3\x8e)\x00\xe3\xca\x11\x8d\xb6\xf0\t\xda\x9c\xbe\xbe\x14\xbb'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(bool_0, str_0)

# Generated at 2022-06-25 10:39:15.815036
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False

# Generated at 2022-06-25 10:39:23.226255
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.run()
    lookup_module_0.run(term=None, variables=None, lstrip=None, rstrip=None)
    lookup_module_0.run(term=var_0, variables=lookup_module_0, lstrip=lookup_run(bool_0, str_0), rstrip=lookup_run(bool_0, str_0))
    lookup_module_0.run(term=var_0, variables=var_0, lstrip=lookup_run(bool_0, str_0), rstrip=lookup_run(bool_0, str_0))

    lookup_module_0 = LookupModule(loader=None, templar=None, **kwargs)
    lookup_module_0.run()
    lookup

# Generated at 2022-06-25 10:40:21.184416
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = "\r'zVt!(k8rz&\x0c"
    bytes_0 = b'F\xc8]\x19\xa0J\x1b_d\x17\xbf[\x88\xbc\nm\x81\xa6\x03\xa1'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(bool_0, str_0)
    print(var_0)

test_LookupModule_run()

# Generated at 2022-06-25 10:40:29.576069
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = "L\n\x00i\x14\x7f\x82j)\\\x1b\x8f"
    bytes_0 = b'\x1d\xaf\xdd\x0c\x12Z\xab\xa7\x9d\xb1O\xc1\x8a*a\x1c\x84\x0f'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(bool_0, str_0)

# Generated at 2022-06-25 10:40:35.015727
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = True
    bytes_0 = b'z\xba\xbe\x9c\x9e\xa3>\x1a|\xa4\xd3\xe0\xec\xe4\xfa\x9b\x9d\x04\xf8\xc2\xa7\x16\x19\x88\xc9\xeb'
    str_1 = "ls"
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_module_0.run(str_1, bool_0)
    assert var_0 == []


# Generated at 2022-06-25 10:40:39.354820
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = "\r'zVt!(k8rz&\x0c"
    bytes_0 = b'F\xc8]\x19\xa0J\x1b_d\x17\xbf[\x88\xbc\nm\x81\xa6\x03\xa1'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_module_0.run(bool_0, str_0)

# Generated at 2022-06-25 10:40:43.514857
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    var_2 = "\r'zVt!(k8rz&\x0c"
    lookup_module_0 = LookupModule(var_2)
    var_0 = False
    var_1 = False
    var_3 = lookup_module_0.run(var_0, var_1)
    assert var_3 == True

# Generated at 2022-06-25 10:40:47.666589
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    bool_0 = True
    str_0 = ")"
    bytes_0 = b'k\x8a\x89\xc4\xcd\x8e\xe9'
    # params: terms, variables, **kwargs
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_module_0.run(bool_0, str_0)



# Generated at 2022-06-25 10:40:53.393540
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from types import GeneratorType
    var_0 = b'_\x9e\xa5\xd2\x1f\x0fF\xc8]\x19\xa0J\x1b_d\x17\xbf[\x88\xbc\nm\x81\xa6\x03\xa1'
    module_0 = LookupModule(var_0)
    str_0 = "L8h'<\x15#:r\x1a\xe8\xab\xe0\xec"

# Generated at 2022-06-25 10:40:59.004801
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    bool_0 = False
    str_0 = "<\xdb\xbb\xeb\x8b\x02\x99\x03\xd9\xba\xaf\xdf\x10\xeb\x81\x04\xf4\x91\x9e\x01\x93\x13)"
    bytes_0 = b'W\xd2\x94\x05\x9f\xed\x06\xfb\x81\xd6\x80\x8d\x15\xea\x9a\x98\xf6\x02\x08\x05\xa6\x15\xfe\xdf'
    lookup_module_0 = LookupModule(bytes_0)
    var_0 = lookup_run(bool_0, str_0)

# Unit

# Generated at 2022-06-25 10:41:04.052785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = "terms"
    variables = "variables"
    kwargs = "kwargs"
    lookup_module_0 = LookupModule(terms, variables, kwargs)
    assert lookup_module_0.run() == None

# Generated at 2022-06-25 10:41:11.724690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.lookup import LookupBase
    from ansible.template.safe_eval import safe_eval
    from ansible.utils.display import Display
    from ansible.vars.hostvars import HostVars
    from collections import MutableMapping
    import json
    import os
    import string
    import sys
    import time
    import types
    __loader__ = None