

# Generated at 2022-06-25 10:32:56.212788
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = []
    variables_0 = {}
    kwargs_0 = {}
    lookup_module_0.run(terms_0, variables_0, **kwargs_0)


# Generated at 2022-06-25 10:33:01.789441
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0._loader = ModuleLoader()
    lookup_module_0.run(['/etc/ansible/ansible.cfg'], {}, lstrip=True, rstrip=True)


# Generated at 2022-06-25 10:33:13.381603
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize the class
    lookup_module = LookupModule()
    # Declare variable terms and assign value
    terms = [u'/etc/hosts']
    # Retrieve method run from class LookupModule and store in variable run_0
    run_0 = lookup_module.run(terms)
    # Check if variable run_0 has the expected value
    assert run_0 == [u'# This is a sample hosts file\n#\n#\n127.0.0.1 localhost localhost.localdomain localhost4 localhost4.localdomain4\n::1 localhost localhost.localdomain localhost6 localhost6.localdomain6'], "Incorrect value returned by LookupModule.run"
    # Declare variable terms and assign value
    terms = [u'some_file']
   

# Generated at 2022-06-25 10:33:16.571556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(["ansible.cfg"]) == [u'[defaults]\nhost_key_checking = False']


# Generated at 2022-06-25 10:33:18.034886
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = [
        '/etc/passwd',
    ]
    variables = dict()
    kwargs = dict()
    lookup_module_0.run(terms, variables, **kwargs)



# Generated at 2022-06-25 10:33:22.574003
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {}
    args['terms'] = ['test1.txt']
    args['variables'] = None
    args['rstrip'] = True
    args['lstrip'] = False
    # rstrip and lstrip are optional
    lookup_module = LookupModule()
    result = lookup_module.run(**args)
    assert result == ['TEST1: test file1']


# Generated at 2022-06-25 10:33:28.950247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a lookup module
    lookup_module = LookupModule()

    # Create a list of arguments to pass to the method under test
    args_0 = ['path/of/file']

    # Create an expected result
    result_expected = ['']

    # Execute the run method
    result_returned = lookup_module.run(args_0)

    # Check if the result we got back is as expected
    assert result_returned == result_expected


# Generated at 2022-06-25 10:33:34.518417
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert lookup_module_0.run(terms   ="lookup_terms_0", variables ="lookup_variables_0", **"lookup_kwargs_0") == "lookup_return_0"

# Generated at 2022-06-25 10:33:36.361795
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module is not None
    lookup_module.run('/etc/hosts')


# Generated at 2022-06-25 10:33:44.470151
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()

    res = lookup_module_0.run(terms=['/etc/foo.txt'], variables={}, **{})

    assert len(res) == 1
    assert res[0] != list()
    assert res[0] != dict()
    assert res[0] != tuple()
    assert res[0] != type(u'')
    assert res[0] != type(b'')
    assert res[0] != type(0)
    assert res[0] != type(0.0)

    res = lookup_module_0.run(terms=['/etc/foo.txt'], variables={}, **{'rstrip': True})

    assert len(res) == 1
    assert res[0] != list()
    assert res[0] != dict()

# Generated at 2022-06-25 10:33:54.959415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = 'test_case_0'
    variables = {'test_case': '0'}
    lookup_module.run(terms, variables)

# Generated at 2022-06-25 10:33:58.437754
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(direct={'rstrip':True,'lstrip':False})
    lookup_module_0.set_options(var_options={'playbook_dir':u'/'})
    lookup_module_0.run([u'/etc/foo.txt'])

# Generated at 2022-06-25 10:34:05.576234
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    args = {
        '_terms': ['/usr/local/bin/file.txt'],
    }
    lookup_module_0 = LookupModule(**args)
    lookup_module_0.set_loader('/tmp/ansible_lookup_module_test/')
    result = lookup_module_0.run(["/usr/local/bin/file.txt"],None)
    assert result == ['\n']
    result = lookup_module_0.run(["/usr/local/bin/file.txt", "/usr/local/bin/"],None)
    assert result == ['\n', '\n']


# Generated at 2022-06-25 10:34:11.625371
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # lookups/file.py:LookupModule.run
    lookup_module_0 = LookupModule()
    terms = ["etc/resolv.conf"]
    variables = {}
    ret = lookup_module_0.run(terms, variables=variables)
    assert isinstance(ret, list)
# end of lookup/file.py

# Generated at 2022-06-25 10:34:13.704215
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['/etc/hosts']
    variables_0 = [None]
    assert lookup_module_0.run(terms_0, variables_0) == True

# Generated at 2022-06-25 10:34:25.083688
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = [(1, 2, 3)]
    variables_0 = (1, 2, 3)
    lookup_module_0.run(terms_0, variables_0)
    terms_1 = [(1, 2, 3)]
    variables_1 = (1, 2, 3)
    lookup_module_0.run(terms_1, variables_1)
    terms_2 = [(1, 2, 3)]
    variables_2 = (1, 2, 3)
    lookup_module_0.run(terms_2, variables_2)
    terms_3 = [(1, 2, 3)]
    variables_3 = (1, 2, 3)
    lookup_module_0.run(terms_3, variables_3)

# Generated at 2022-06-25 10:34:32.814893
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  lookup_module_0 = LookupModule()
  b_contents_0_0 = b'bqZhbHNleQ==\n'
  contents_0 = "b'bqZhbHNleQ==\\n'"
  terms_0 = ['tasks/main.yml']
  try:
    resd_0 = lookup_module_0.run(terms_0, False, False)
  except Exception as e_0:
    resd_0 = str(e_0)

  assert resd_0 == contents_0

# Generated at 2022-06-25 10:34:39.777642
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:34:47.761058
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    '''
    Unit test for method run of class LookupModule
    '''

    # Create a fixture
    lookup_module_1 = LookupModule()
    terms_1 = ['/etc/hosts']

    # Call method run of lookup_module
    if lookup_module_1.run(terms_1) is None:
        print('Method run of class LookupModule has no return statement')


# Generated at 2022-06-25 10:34:49.958775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(('/etc/hosts',), {'role_path': ['/etc/hosts']})

# Generated at 2022-06-25 10:35:01.135016
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 10:35:05.068730
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    lookup_module_1 = LookupModule()
    terms_0 = ''
    lookup_module_1.run(terms_0)
    assert True


# Generated at 2022-06-25 10:35:13.564627
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(lstrip=True)
    lookup_module_0.set_options(rstrip=True)
    lookup_module_0.set_options(var_options=None)
    lookup_module_0.set_options(direct=None)
    lookup_module_0.find_file_in_search_path(None, 'files', 'foo.txt')
    lookup_module_0._loader._get_file_contents('bar.txt')
    lookup_module_0.run(['foo.txt', 'bar.txt'])

# Generated at 2022-06-25 10:35:24.526744
# Unit test for method run of class LookupModule

# Generated at 2022-06-25 10:35:27.948971
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arguments = dict(
        terms=['/etc/hosts'],
        variables=None,
        rstrip=False,
        lstrip=False
    )
    lookup_module_0 = LookupModule()
    ret = lookup_module_0.run(**arguments)
    assert type(ret) == list

# Generated at 2022-06-25 10:35:38.341262
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    setattr(lookup_module_0, '_display', Display())

    args = {'rstrip': True, 'lstrip': False}

    test_cases = [
        # args: terms, variables, kwargs
        {
            'args': [
                ['examples/file_examples.txt'],
                None,
                args
            ],
            'result': ['# This is an example of a file lookup\n# and the resultant lookup plugin output\n']
        }
    ]

    for test_case in test_cases:
        assert test_case['result'] == lookup_module_0.run(*test_case['args'][0], **test_case['args'][1], **test_case['args'][2])

# Generated at 2022-06-25 10:35:50.440358
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms_0 = ['./test_data/test_file.txt']
    lookup_module_0.run(terms_0)
    # Asserting the object lookup_module_0.run is of type LookupModule
    assert isinstance(lookup_module_0.run, LookupModule)
    # Asserting the object lookup_module_0.run is of type list
    assert isinstance(lookup_module_0.run, list)
    # Asserting the value of lookup_module_0.run is equal to ['Line 1\n, Line 2\n, Line 3\n, Line 4\n']
    assert lookup_module_0.run == ['Line 1\n', 'Line 2\n', 'Line 3\n', 'Line 4\n']

# Generated at 2022-06-25 10:35:58.476731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    terms = ["/path/to/foo.txt"]
    variables = {}
    __kwargs = {'lstrip': False, 'rstrip': True}
    assert lookup_module_0.run(terms, variables) == [lookup_module_0.run.__wrapped__(lookup_module_0, terms, variables)]
    assert lookup_module_0.run(terms, variables, **__kwargs) == [lookup_module_0.run.__wrapped__(lookup_module_0, terms, variables, **__kwargs)]


# Generated at 2022-06-25 10:36:03.219410
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.find_file_in_search_path = lambda x, y, z: 'some file'
    lookup_module_0._loader = lambda: 0
    lookup_module_0._loader._get_file_contents = lambda x: (b'Zm9v', False)
    lookup_module_0.set_options = lambda x, y, z=None: None
    lookup_module_0.get_option = lambda x: True
    lookup_module_0.run(['some.file'])



# Generated at 2022-06-25 10:36:06.665501
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(terms = [ "foo.txt" ])

# Generated at 2022-06-25 10:36:19.060145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run()


# Generated at 2022-06-25 10:36:25.176286
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    assert not lookup_module_0.run(None)
    lookup_module_0.run(None, None)
    lookup_module_1 = LookupModule()
    assert not lookup_module_1.run(None)
    lookup_module_1.run(None, None)
    lookup_module_2 = LookupModule()
    assert not lookup_module_2.run(None)
    lookup_module_2.run(None, None)
    lookup_module_3 = LookupModule()
    assert not lookup_module_3.run(None)
    lookup_module_3.run(None, None)
    lookup_module_4 = LookupModule()
    assert not lookup_module_4.run(None)
    lookup_module_4.run(None, None)

# Generated at 2022-06-25 10:36:29.240458
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_1 = LookupModule()
    long_0 = 1234567890123456789012345678901234567890
    float_1 = -7.28
    float_2 = -9.45
    var_0 = lookup_run(long_0, float_1, float_2, False)
    lookup_module_2 = LookupModule()


# Generated at 2022-06-25 10:36:31.023421
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test for function LookupModule.run
    lookup.run("foo.bar")
    assert(False)

# Generated at 2022-06-25 10:36:41.322925
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = [0]
    float_0 = float()
    float_1 = float()
    int_0 = int()
    str_0 = str()
    str_1 = str({}, {})
    str_2 = str(list_0, {}, {}, {}, {})
    str_3 = str(list_0, list_0, list_0, list_0, {})
    str_4 = str(list_0, {})
    str_5 = str(list_0, list_0, list_0, {})
    str_6 = str(list_0, list_0, list_0, list_0, {})
    str_7 = str(list_0, list_0, {})

# Generated at 2022-06-25 10:36:53.136498
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    int_1 = 6656
    str_0 = 'Id'
    float_1 = Float(str_0)
    float_2 = 2624.0
    float_3 = Byte(int_1)
    float_4 = 5376.0
    dict_0 = dict()
    var_1 = lookup_run(float_1, float_2, float_3, float_4, dict_0)
    try:
        var_2 = 'Ci'
        str_1 = 'Ot'
        lookup_module_3 = LookupModule('Re', var_0, 'As', var_1, var_2, str_1)
    except:
        print('AnsibleError: could not locate file in lookup: %s')

# Generated at 2022-06-25 10:37:04.842278
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    try:
        var_0 = lookup_run(float_0, int_0)
    except:
        var_0 = None
    assert var_0 is not None, "Unable to get the variable for sure"
    lookup_module_1 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_1 = lookup_module_1.run(float_0, int_0)
    if not isinstance(var_1, list) or var_1:
        assert False, "Method failed"
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    lookup_module

# Generated at 2022-06-25 10:37:09.725893
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192

    var_0 = lookup_module_0.run(float_0, int_0)

# Generated at 2022-06-25 10:37:14.428411
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)

# Test with a file containing a string

# Generated at 2022-06-25 10:37:19.089648
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run
    float_1 = 512.0
    int_1 = 2192
    var_1 = lookup_module_2.run(float_1, int_1)
    lookup_module_2.run
    return



# Generated at 2022-06-25 10:37:49.246755
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 590.0
    int_0 = 2193
    string_0 = 'test_data/hello'
    dict_0 = dict()
    dict_0['test'] = string_0
    dict_0['another'] = string_0
    var_0 = lookup_run(float_0, int_0, variables=dict_0)
    lookup_module_1 = LookupModule()
    float_1 = 785.0
    int_1 = 2301
    dict_1 = dict()
    dict_1['test'] = string_0
    dict_1['another'] = string_0
    var_1 = lookup_run(float_1, int_1, variables=dict_1)
    lookup_module_2 = LookupModule()
    int

# Generated at 2022-06-25 10:37:51.904542
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    lookup_module_2.run()


# Unit test to verify method run of class LookupModule

# Generated at 2022-06-25 10:37:59.837125
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    var_0 = lookup_module.run(["/etc/passwd"], variables)

    # Unit test for method run of class LookupModule
    def test_LookupModule_run_0():
        lookup_module = LookupModule()
        float_0 = 512.0
        int_0 = 2192
        var_0 = lookup_run(float_0, int_0)
        var_0 = lookup_module.run(["/etc/passwd"], variables)



# Generated at 2022-06-25 10:38:02.683163
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    assert (var_0 == [False, 512.0, 2192])


# Generated at 2022-06-25 10:38:12.849376
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    list_0 = ['foo', 'bar', 'baz']
    dict_0 = dict()
    var_0 = lookup_module_0.run(list_0, dict_0)
    str_0 = str()
    bytes_0 = bytes(str_0, 'utf-8')
    bytes_1 = to_text(bytes_0, errors='surrogate_or_strict')
    float_0 = 512.0
    int_0 = 2192
    lookup_module_1 = LookupModule()
    var_1 = lookup_run(float_0, int_0)
    dict_1 = dict()
    var_2 = lookup_module_1.run(list_0, dict_1)
    str_1 = str()
    bytes_2 = bytes

# Generated at 2022-06-25 10:38:16.813272
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    lookup_module_1 = LookupModule()


# Generated at 2022-06-25 10:38:20.558787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)


# Generated at 2022-06-25 10:38:23.914131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)



# Generated at 2022-06-25 10:38:25.963525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_2 = LookupModule()
    long_0 = long(2**54)
    long_1 = long(4294967296)
    long_2 = long(2**50)
    int_0 = 2192
    var_0 = lookup_run(long_0, long_1, long_2, int_0)

# Generated at 2022-06-25 10:38:27.605797
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_mock = LookupModule()


if __name__ == '__main__':
    # test_case_0()
    test_LookupModule_run()

# Generated at 2022-06-25 10:39:12.919918
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    assert var_0 == 512.0


# Generated at 2022-06-25 10:39:19.007196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 870.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    assert var_0 == 'baz'

# Generated at 2022-06-25 10:39:23.908088
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)

# Generated at 2022-06-25 10:39:32.635534
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    format_0 = 'https://app.datadoghq.com/logs/v1/destinations/'
    float_0 = 512.0
    int_0 = 2192
    lookup_module_0 = LookupModule()
    lookup_module_0.run(format_0, float_0, int_0)
    var_1 = lookup_run(float_0, int_0)
    lookup_module_1 = LookupModule()
    int_1 = 4134
    lookup_module_1.run(format_0, float_0, int_1)
    lookup_module_2 = LookupModule()
    int_2 = 8686
    lookup_module_2.run(format_0, float_0, int_2)



# Generated at 2022-06-25 10:39:35.266152
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = float()
    int_0 = int()
    var_0 = lookup_module.run(float_0, int_0)
    lookup_module_1 = LookupModule()

# Generated at 2022-06-25 10:39:42.797425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    str_0 = lookup_module_0.run(float_0, int_0)
    lookup_module_1 = LookupModule()
    str_1 = lookup_module_1.run(float_0, int_0)
    lookup_module_2 = LookupModule()
    str_2 = lookup_module_2.run(float_0, int_0)
    lookup_module_3 = LookupModule()
    lookup_module_3.run(float_0, int_0)
    lookup_module_4 = LookupModule()
    str_3 = lookup_module_4.run(float_0, int_0)
    lookup_module_5 = LookupModule()
    str_4

# Generated at 2022-06-25 10:39:54.103900
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    assert (var_0 is not None)
    lookup_module_1 = LookupModule()
    float_0 = 64.0
    int_0 = 12032
    var_0 = lookup_run(float_0, int_0)
    assert (var_0 is not None)
    lookup_module_2 = LookupModule()
    float_0 = 64.0
    int_0 = 27904
    var_0 = lookup_run(float_0, int_0)
    assert (var_0 is not None)
    lookup_module_3 = LookupModule()
    float_0 = 128.0
    int_0

# Generated at 2022-06-25 10:39:55.015375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['term'])


# Generated at 2022-06-25 10:39:55.987921
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Parameterized test for method run
    # fixme: add tests
    pass


# Generated at 2022-06-25 10:39:58.014065
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_module.run(float_0, int_0)
    lookup_module_0 = LookupModule()


# Generated at 2022-06-25 10:41:50.947787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_module.run(float_0, int_0)
    var_1 = '<h1>Hello world</h1>'
    lookup_module_1 = LookupModule()
    int_1 = 3
    int_2 = 7
    var_2 = lookup_module_1.run(var_1, int_1, int_2)
    lookup_module_2 = LookupModule()
    int_3 = 4
    int_4 = 8
    var_3 = lookup_module_2.run(var_1, int_3, int_4)

# Generated at 2022-06-25 10:41:52.573706
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 816.0
    int_0 = 2576
    var_0 = LookupModule()
    var_1 = lookup_run(float_0, int_0)


# Generated at 2022-06-25 10:41:58.537422
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192

    # Run a 2nd test
    lookup_module_1 = LookupModule()
    float_1 = float_0
    int_1 = int_0


main()

# Generated at 2022-06-25 10:42:03.390199
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    lookup_module_1 = LookupModule()
    float_1 = 88.0
    int_1 = 1024
    var_1 = lookup_run(float_1, int_1)
    lookup_module_2 = LookupModule()
    float_2 = 1024.0
    int_2 = 2048
    var_2 = lookup_run(float_2, int_2)
    lookup_module_3 = LookupModule()
    float_3 = 16.0
    int_3 = 512
    var_3 = lookup_run(float_3, int_3)
    lookup_module_4 = LookupModule()
    float

# Generated at 2022-06-25 10:42:10.873719
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    float_0 = 592.0
    int_0 = 2770
    var_0 = lookup_run(float_0, int_0)
    str_0 = "Pickle Rick"
    str_1 = "Pickle Rick"
    var_1 = lookup_run(str_0, str_1)
    int_0 = 2496
    str_0 = "veni, vidi, vici"
    var_2 = lookup_run(int_0, str_0)
    int_0 = 2496
    str_0 = "veni, vidi, vici"
    var_3 = lookup_run(int_0, str_0)
    int_0 = 2496
    str_0 = "veni, vidi, vici"

# Generated at 2022-06-25 10:42:16.352174
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    lookup_module_0.set_options(timeout=var_0, min_age=int_0)
    lookup_module_0.get_option("timeout")
    lookup_module_0.run(terms, variables=None, **kwargs)
    lookup_module_0.get_option("min_age")


if __name__ == "__main__":
    import sys
    import doctest

    old_stdout = sys.stdout
    sys.stdout = open("pylookup.out", "w")
    result = doctest.testmod()
    sys.stdout.close()
    sys.stdout = old_stdout
    sys.exit(result)

# Generated at 2022-06-25 10:42:18.960934
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    var_1 = lookup_module_0.run(float_0, int_0)
    assert (var_0 == var_1)


# Generated at 2022-06-25 10:42:22.450267
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Case 0
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_module_0.run(float_0, int_0)
    lookup_module_1 = LookupModule()
    # Case 1
    lookup_module_2 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_module_2.run(float_0, int_0)
    lookup_module_3 = LookupModule()


# Generated at 2022-06-25 10:42:29.647247
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    float_0 = 256.0
    int_0 = 2192
    int_1 = 2192
    lookup.run(float_0, int_0, *[], **{'_terms':'foo'})
    lookup.run(float_0, int_1, *[], query={})


# Generated at 2022-06-25 10:42:33.170596
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module_0 = LookupModule()
    float_0 = 512.0
    int_0 = 2192
    var_0 = lookup_run(float_0, int_0)
    lookup_module_1 = LookupModule()

test_LookupModule_run()