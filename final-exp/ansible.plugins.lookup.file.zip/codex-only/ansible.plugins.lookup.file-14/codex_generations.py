

# Generated at 2022-06-23 11:28:39.561744
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    In this test function, if the code is syntax error free then this
    module can run
    :return:
    """
    test_result = LookupModule()

# Generated at 2022-06-23 11:28:48.655501
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create an instance of LookupModule for testing
    t_LookupModule = LookupModule()

    # Create a variable values for testing
    test_vars = {
        'ansible_pkg_mgr': 'pacman',
        'conf_path': '/etc/ansible',
        'pkg_mgr_cache_valid_time': 1209600,
        'pkg_mgr': 'apt'}

    # Check the given term is in the given search path
    find_file_in_search_path_data = [
        ('/tmp/file1', {}, '/tmp/file1'),
        ('/tmp/file2', {}, '/tmp/file2'),
        ('/tmp/file3', {}, '/tmp/file3'),
        ('/tmp/file4', {}, '/tmp/file4')]


# Generated at 2022-06-23 11:28:49.711043
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    dir(LookupModule())
    assert True

# Generated at 2022-06-23 11:28:51.246787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = ['foo']
    ret = run_LookupModule_LookupModule_run(terms)
    assert ret == ['foo']


# Generated at 2022-06-23 11:28:53.320613
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.rstrip == True
    assert lookup.lstrip == False

# Generated at 2022-06-23 11:28:53.960270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("hello")

# Generated at 2022-06-23 11:28:54.571237
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:28:55.921371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:29:01.520954
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.path import unfrackpath
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    # Create 'test_file' for use in multiple tests
    f = open('test_file', 'w')
    f.write('test\n')
    f.close()

    # Test a simple, single file
    test_lookup = LookupModule()
    res = test_lookup.run(['test_file'])
    assert 1 == len(res)
    assert 'test' == res[0]

    # Test multiple files using a single argument
    res = test_lookup.run([unfrackpath('/test_file')])
    assert 1 == len(res)

# Generated at 2022-06-23 11:29:02.505727
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:29:04.122341
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:29:07.504592
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    result = LookupModule.run(['test-data.txt'])
    print(result)
    # => ['hello\n']

if __name__ == '__main__':
    test_LookupModule_run()

# Generated at 2022-06-23 11:29:09.023264
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myobj = LookupModule()
    assert type(myobj) == LookupModule

# Generated at 2022-06-23 11:29:17.333243
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    mock_loader = MockLoader({'test.txt': 'content'})

    module = LookupModule()
    module.set_loader(mock_loader)
    module.set_options({'lstrip': False, 'rstrip': False})

    terms = ['test.txt']
    result = module.run(terms)
    assert result == ['content']

    module.set_options({'lstrip': True, 'rstrip': False})
    result = module.run(terms)
    assert result == ['content']

    module.set_options({'lstrip': False, 'rstrip': True})
    result = module.run(terms)
    assert result == ['content']

    module.set_options({'lstrip': True, 'rstrip': True})
    result = module.run(terms)
    assert result == ['content']

# Generated at 2022-06-23 11:29:25.138994
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    term_object = [
        '/etc/dummy1.txt',
        'dummy2.txt',
        '/etc/dummy3.txt'
    ]

    # No loader to pass to LookupBase
    lookup_object = LookupModule()

    # Method run() returns a list
    result = lookup_object.run(terms=term_object)

    assert result[0] == "This is dummy1\n"
    assert result[1] == "This is dummy2\n"
    assert result[2] == "This is dummy3\n"

# Generated at 2022-06-23 11:29:27.276908
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        lm = LookupModule()
    except:
        print('could not initialize lookup module')
        raise


# Generated at 2022-06-23 11:29:30.470238
# Unit test for constructor of class LookupModule
def test_LookupModule():
    user_variable = dict(one="test_one")
    test_LookupModule = LookupModule(loader=None,
                                     variables=user_variable,
                                     paths=["/tmp"])
    assert test_LookupModule is not None

# Generated at 2022-06-23 11:29:39.727535
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print()
    lookup_obj = LookupModule()
    # need to mock _loader._get_file_contents(filename)
    my_mock_loader = MagicMock()
    my_mock_loader.get_file_contents.return_value = b'this is a test file'
    lookup_obj._loader = my_mock_loader

    # test invalid lookup
    lookup_obj.run('this is an invalid lookup')
    my_mock_loader.get_file_contents.assert_not_called()

    # test lookup with empty file
    lookup_obj.run('empty')
    my_mock_loader.get_file_contents.assert_called_with('files/empty')

    # test lookup of non-empty file
    lookup_obj.run('non-empty')
    my_m

# Generated at 2022-06-23 11:29:41.291879
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)


# Generated at 2022-06-23 11:29:42.167036
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-23 11:29:52.893489
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupBase)
    assert lookup.get_option('lstrip') == False
    lookup.set_options(direct={'a': 1, 'b': 2, 'c': 3})
    assert lookup.get_option('lstrip') == False
    lookup.set_options(direct={'lstrip': False, 'rstrip': True})
    assert lookup.get_option('lstrip') == False
    assert lookup.get_option('rstrip') == True
    lookup.set_options(direct={'lstrip': True, 'rstrip': True})
    assert lookup.get_option('lstrip') == True
    assert lookup.get_option('rstrip') == True
    lookup.set_options(direct={'lstrip': False, 'rstrip': False})
    assert lookup

# Generated at 2022-06-23 11:29:55.879781
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)
    assert hasattr(l, 'run')
# this is not a real test. This just shows the behavior
# test_LookupModule()

# Generated at 2022-06-23 11:30:06.851375
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    import ansible.errors
    import ansible.constants

    # Initialize ansible.constants and ansible.context.CLIARGS

    ################################################################################
    # WARNING: DO NOT CHANGE THE FOLLOWING CODE
    # This is needed to initialize ansible.constants and ansible.context.CLIARGS
    # as this method will be called out of the ansible-playbook process
    # This will fail if you change the code below
    ################################################################################
    import imp
    import sys
    import shutil
    import tempfile
    import contextlib
    import json
    import os


# Generated at 2022-06-23 11:30:11.844134
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test run method without specified file
    lookup = LookupModule()
    assert lookup.run(['']) == []

    # Test run method with specified file
    lookup = LookupModule()
    assert lookup.run(['./test/files/file.txt']) == ['This is a fake\nfile']

    # Test run method with specified non-existent file
    lookup = LookupModule()
    try:
        lookup.run(['./test/files/file1.txt'])
    except AnsibleError:
        pass


# Generated at 2022-06-23 11:30:13.308211
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:30:23.271920
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    enum LookupModule::run {
        terms,
        variables,
        kwargs
    }
    """
    h_LookupModule = LookupModule()
    imp.reload(h_LookupModule)
    h_LookupBase = h_LookupModule.LookupBase
    imp.reload(h_LookupBase)
    h_ansible_lookup = h_LookupModule.ansible_lookup_plugin
    imp.reload(h_ansible_lookup)
    h_ansible_module_common = h_ansible_lookup.ansible_module_common
    imp.reload(h_ansible_module_common)
    class ansible_module_common_mock:
        def __init__(self):
            self.params = dict()
            self.params

# Generated at 2022-06-23 11:30:27.482819
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.loader import lookup_loader
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import merge_hash

    class Options(object):
        verbosity = 0
        connection = None
        remote_user = None
        private_key_file = None
        remote_pass = None
        become = None
        become_method = None
        become_user = None


# Generated at 2022-06-23 11:30:35.919270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test file which exists in the directory
    assert lookup_module.run(terms = ['file_which_exists.txt'], variables = {}) == ['this is a test file']
    # Test file which does not exist in the directory
    try:
        lookup_module.run(terms = ['non_existent_file.txt'], variables = {})
        assert False
    except:
        assert True

    # Test options rstrip and lstrip
    assert lookup_module.run(terms = ['file_which_exists.txt'], variables = {}, rstrip = True, lstrip = True) == ['this is a test file']

# Generated at 2022-06-23 11:30:45.545011
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_options = {
        'lstrip': False,
        'rstrip': True,
        '_original_file': '../../tests/test_lookup_plugins/test_file.yml',
        '_original_score': 100,
        '_search_path': ['../../tests/test_lookup_plugins/test_file_lookup/', './']
    }
    oh_lookup = LookupModule()
    oh_lookup.set_options(var_options={}, direct=lookup_options)
    # Test1
    terms = ['test_file.txt']
    result = oh_lookup.run(terms, variables=None, **lookup_options)
    assert result == ['a test file']
    # Test2
    terms = ['test_file_with_newline.yml']


# Generated at 2022-06-23 11:30:47.111740
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, 'run')

# Generated at 2022-06-23 11:30:57.499448
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check whether we process simple file content correctly
    lm = LookupModule()
    lm.set_options({'lstrip': True, 'rstrip': True})
    assert lm.run(['misc/file_lookup_content']) == [u'line1\nline2']
    assert lm.run(['misc/file_lookup_content_with_leading_whitespace']) == [u'line1\nline2']
    assert lm.run(['misc/file_lookup_content_with_trailing_whitespace']) == [u'line1\nline2']
    assert lm.run(['misc/file_lookup_content_with_leading_and_trailing_whitespace']) == [u'line1\nline2']

    # check whether we return empty list

# Generated at 2022-06-23 11:30:58.950257
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:30:59.532105
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-23 11:31:02.837238
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader._get_file_contents = get_file_contents_mock
    terms = ['file1']
    variables = {}
    result = lookup_module.run(terms, variables)
    assert result == [u'Test file 1 content\n']


# Generated at 2022-06-23 11:31:04.257460
# Unit test for constructor of class LookupModule
def test_LookupModule():
    with pytest.raises(AnsibleParserError):
        LookupModule()

# Generated at 2022-06-23 11:31:06.861864
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    Check if constructor of LookupModule class is working.
    """
    lookupModule = LookupModule()

# Generated at 2022-06-23 11:31:15.715105
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # create a mock and set it to look like the searchpath has been found
    mock_self = type('obj', (object,), {'find_file_in_search_path': lambda self, variables, path, term: 'The correct searchpath'})

    # create a mock and set it to look like the file exists
    mock_self._loader = type('obj', (object,), {'_get_file_contents': lambda self, lookupfile: [b'The contents', True]})

    # run the lookupmodule
    ret = LookupModule.run(mock_self, ["example.txt"])

    # check if the lookup module ran correctly
    assert ret[0] == "The contents"

# Generated at 2022-06-23 11:31:24.167874
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.find_file_in_search_path = lambda x,y,z : None
    # Test no file is found
    assert [] == l.run(['c'])
    # Test error is raised
    l.find_file_in_search_path = lambda x,y,z : 'a'
    l._loader = MockLoader()
    l._loader._get_file_contents = lambda x : (b'a', True)
    l.set_options(direct=dict(lstrip=True, rstrip=True))
    assert ['a'] == l.run(['c'])
    l.set_options(direct=dict(lstrip=False, rstrip=True))
    assert ['a'] == l.run(['c'])

# Generated at 2022-06-23 11:31:26.438011
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert type(l) == LookupModule


# Generated at 2022-06-23 11:31:27.831758
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    # Act
    # Assert
    assert True

# Generated at 2022-06-23 11:31:33.854667
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Check for file in search path
    example_lookupfile = lookup.find_file_in_search_path(
        variables=None,
        file_type='files',
        name='foobar.txt'
    )
    assert example_lookupfile is not None
    try:
        lookup.run(terms=['foobar.txt'])
    except AnsibleError:
        assert False

# Generated at 2022-06-23 11:31:38.531916
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import __builtin__
    if sys.version_info < (2, 7):
        import mock
        builtins = __builtin__
        builtins.open = mock.mock_open()

        contents = "foo\nbar\nbaz"
        builtins.open.return_value.read.return_value = contents

    l = LookupModule()
    assert l



# Generated at 2022-06-23 11:31:47.746696
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.mod_args

    # Create a MockLookupModule
    lookup = LookupModule()
    # Create a MockConnectionBase
    host = 'localhost'
    connection = ansible.parsing.mod_args.ConnectionBase(play_context=None, new_stdin=None)
    # Create a MockDataLoader
    loader = ansible.parsing.dataloader.DataLoader()
    # Create a MockVars
    variables = ansible.parsing.mod_args.VarsModule(loader=loader, play_context=None, version_info=ansible.__version__)
    # Define possible arguments for run method
    terms = ['/tmp/a.txt']
    # Execute the run method

# Generated at 2022-06-23 11:31:58.376464
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.constants as C

    class TestLookupModule(LookupModule):

        def __init__(self):
            pass

    # init ansible modul
    C.HOST_KEY_CHECKING = False

    # set test constants
    TESTFILE = "lookuptest"
    TESTFILE2 = "lookuptest2"
    TESTCONTENT = "bla"
    TESTCONTENT2 = "blub"

    # create test files
    testfile = open(C.DEFAULT_LOCAL_TMP + "/" + TESTFILE, "w")
    testfile.write(TESTCONTENT)
    testfile.close()
    testfile = open(C.DEFAULT_LOCAL_TMP + "/" + TESTFILE2, "w")

# Generated at 2022-06-23 11:31:59.293317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()


# Generated at 2022-06-23 11:32:06.192153
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # check for the given file
    import os
    import sys
    import inspect
    from ansible.utils.display import Display
    from ansible.plugins.lookup import LookupBase
    from ansible.errors import AnsibleError, AnsibleParserError

    module = sys.modules[__name__]
    file = os.path.dirname(os.path.abspath(inspect.getfile(module)))

    display = Display()
    display.debug("File lookup term: %s" % file)
    lookupfile = LookupBase.find_file_in_search_path(None, 'files', file)
    display.vvvv(u"File lookup using %s as file" % lookupfile)

# Generated at 2022-06-23 11:32:17.123390
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['a', 'b']
    variables = None
    assert module.run(terms, variables) == []

    # unit test for iosxr_config.py
    module = LookupModule()
    # /usr/lib/python3/dist-packages/ansible/plugins/lookup/file.py
    search_path = ['/etc', '/usr/lib/python3/dist-packages/ansible/plugins/lookup/iosxr_config/data', '/usr/lib/python3/dist-packages/ansible/plugins/lookup/iosxr_config/data']
    file = "path.txt"
    assert module.find_file_in_search_path(variables, 'files', file) == search_path[1] + "/" + file

# Generated at 2022-06-23 11:32:19.361297
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert hasattr(lookup_plugin, 'run')

# Generated at 2022-06-23 11:32:23.473110
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.get_option = lambda x: True
    lookup_module.set_options(var_options={'a': 'value_a'}, direct={'b': 'value_b'})
    lookup_module.run([1, 2, 3], variables={'a': 'value_a'})

# Generated at 2022-06-23 11:32:31.051375
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    import ansible.inventory.manager
    import os
    import pytest

    lookup_module = LookupModule()

    # test file not exists
    with pytest.raises(AnsibleError, match='could not locate file in lookup: /path/to/foo.txt'):
        lookup_module.run(['/path/to/foo.txt'])

    # test file exists
    file_path = os.path.join(os.path.dirname(__file__), '../../../files/test_file.txt')
    result = lookup_module.run([file_path])
    assert result[0] == 'bar\n'

# Generated at 2022-06-23 11:32:32.713463
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup._options[u'rstrip'] == True

# Generated at 2022-06-23 11:32:33.629125
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 11:32:34.729886
# Unit test for method run of class LookupModule

# Generated at 2022-06-23 11:32:38.150692
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # Testing class variable initialization
    assert lookup.name == 'file'
    assert lookup.ext_to_class['file'] == [lookup]


# Generated at 2022-06-23 11:32:40.011634
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ret = LookupModule().run(['/tmp/foo.txt'])
    assert ret == [''], ret

    # FIX - mock loader

# Generated at 2022-06-23 11:32:41.895788
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule.run.__code__.co_argcount == 5

# Generated at 2022-06-23 11:32:42.807681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()


# Generated at 2022-06-23 11:32:45.441425
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:32:46.059832
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-23 11:32:48.765198
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    return

# After doing a major refactoring of the code, this unit test no longer applies.
# It's not clear to me at this time if the code should be reverted to the
# previous implementation of the method, or if this test case should be
# removed.  The latter seems more likely.
#
# # Unit test for method run of class LookupModule - negative test (i.e. return failure)
# def test_LookupModule_run_negative():
#     return

# Generated at 2022-06-23 11:32:49.886375
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()

# Generated at 2022-06-23 11:32:50.803857
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None


# Generated at 2022-06-23 11:32:52.183954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-23 11:32:53.126208
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert x is not None

# Generated at 2022-06-23 11:32:56.048082
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mod = LookupModule()
    ret = mod.run(['/etc/passwd'])
    assert 'root' in ret[0]

# Generated at 2022-06-23 11:33:01.676032
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module.run(['../doc/man_pages/ansible-doc.rst'], variables={'ansible_managed': b'Ansible managed: /tmp/ansible/file.py modified on 2017-12-21 16:56:43 by root on localhost'})
    # TODO: add other unit tests

# Generated at 2022-06-23 11:33:10.726355
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    # lookup._options is a dict
    assert isinstance(lookup._options, dict)
    # lookup._templates is a dict
    assert isinstance(lookup._templates, dict)
    # lookup._display is an object of class Display
    assert isinstance(lookup._display, Display)
    # lookup._display_lock is a Lock
    assert hasattr(lookup._display_lock, "acquire")
    assert hasattr(lookup._display_lock, "release")
    assert hasattr(lookup._display_lock, "__enter__")
    assert hasattr(lookup._display_lock, "__exit__")

# Generated at 2022-06-23 11:33:11.482749
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(callable(LookupModule))

# Generated at 2022-06-23 11:33:14.607058
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not hasattr(LookupModule(), 'run')
    assert not hasattr(LookupModule(), 'run')
    assert not hasattr(LookupModule(), 'run')
    assert not hasattr(LookupModule(), 'run')

# Generated at 2022-06-23 11:33:15.680259
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  module = LookupModule()
  terms = [
    'foo',
    'bar',
    'baz'
    ]
  module.run(terms)

# Generated at 2022-06-23 11:33:19.571755
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookupModule = LookupModule()
    assert lookupModule.run(["/path/to/foo.txt", "bar.txt", "/path/to/biz.txt"], 
                       variables={"path_name": ['/path/to/']}, lookupfile='/path/to/foo.txt') == ["/path/to/foo.txt", "bar.txt", "/path/to/biz.txt"]

# Generated at 2022-06-23 11:33:31.069270
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupmodule = LookupModule()
    result = lookupmodule.run(['index.html'], variables={'cwd': "../../lookup_plugins"})
    assert result == ["<html>\n<body>\n<h1>Hello World!</h1>\n</body>\n</html>"]

    result = lookupmodule.run(['index.html', 'LICENSE'],
                              variables={'cwd': "../../lookup_plugins"})
    assert result == ["<html>\n<body>\n<h1>Hello World!</h1>\n</body>\n</html>",
                      "BSD 3-Clause License\n\nCopyright (c) 2016, Red Hat, Inc. and others\nAll rights reserved.\n"]


# Generated at 2022-06-23 11:33:39.714478
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible_collections.ansible.community.plugins.lookup.file import LookupModule

    # Test the run method with an invalid type for the 'terms' argument:
    with pytest.raises(TypeError) as excinfo:
        LookupModule().run(None, variables=None)

    # Test the run method with an invalid entry for the 'terms'
    # argument:
    with pytest.raises(AnsibleError) as excinfo:
        LookupModule().run(['/path/to/invalid/file'], variables=None)
    assert 'could not locate file in lookup' in str(excinfo.value)
    assert '/path/to/invalid/file' in str(excinfo.value)

    # Test the run method with a valid entry for the 'terms'
    # argument:

# Generated at 2022-06-23 11:33:42.262909
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    assert(lu.get_options().get("lstrip", True))

# Generated at 2022-06-23 11:33:44.597599
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_test_class = LookupModule()
    return my_test_class


# Generated at 2022-06-23 11:33:55.733382
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    empty_file = "empty-file"
    empty_content = ""
    valid_file = "valid-file"
    valid_content = "valid-content"
    invalid_file = "invalid-file"
    invalid_content = "invalid-content"

    class FakeLoader:

        def __init__(self):
            self.files = {}

        def set_file_content(self, filename, content):
            self.files[filename] = content

        def get_file_content(self, filename):
            if filename in self.files:
                return self.files[filename]
            else:
                raise AnsibleParserError("could not locate file in lookup: %s" % filename)

    fake_loader = FakeLoader()
    fake_loader.set_file_content(empty_file, empty_content)
    fake_

# Generated at 2022-06-23 11:33:56.714735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-23 11:33:58.802868
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)


# Generated at 2022-06-23 11:34:09.827440
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    arg = ['/etc/ansible/hosts']
    arg_dict = {'rstrip': True, 'lstrip': False}
    arg_dict_2 = {'rstrip': True, 'lstrip': True}
    arg_dict_3 = {'rstrip': False, 'lstrip': True}
    arg_dict_4 = {'rstrip': False, 'lstrip': False}
    my_display = Display()
    my_display.set_verbosity(4)
    my_loader = None
    # LookupModule_run test with default option
    my_lookup = LookupModule(my_loader, my_display)
    my_lookup.set_options(var_options=None, direct=arg_dict)

# Generated at 2022-06-23 11:34:11.015175
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()


# Generated at 2022-06-23 11:34:18.738767
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Load lookup module (and dependencies)
    import sys
    sys.path.insert(0, 'plugins/lookup')

# Generated at 2022-06-23 11:34:29.474130
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # define some test variables
    test_path = '/tmp/ansible/test/lookup_plugins/file/sample.txt'
    # create a test class
    class TestClass:
        u''' Test variables. '''
        def __init__(self):
            self.vars = {
                'key1': 'val1',
                'key2': 'val2',
                'key3': {'key31': 'val31', 'key32': 'val32'},
            }
            self.files = {
                'files': {'file': [
                    {'path': test_path, 'contents': 'test1\n'},
                    {'path': test_path, 'contents': 'test2\n'},
                ]}
            }
    # create a TestLookup

# Generated at 2022-06-23 11:34:30.731227
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule().run(["some_file"])

# Generated at 2022-06-23 11:34:39.025240
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader()
    result = lookup.run(['README.md'])
    readme_md = "ansible-test - Manage ansible test resources\n======================\n\nThis is a tool that assists in using Ansible for testing.\n\nIt has one main\nfunction, a callback plugin to introduce test resources as Ansible facts.\n\nThat way you can use Ansible to create a test environment with anything you\nneed, and then create a test file that verifies your pre-conditions with\nassertions.\n\n"
    assert result[0] == readme_md

# Generated at 2022-06-23 11:34:40.698869
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)


# Generated at 2022-06-23 11:34:47.150403
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    assert lookup_module.run(terms=["ansible.cfg"],
                             variables={'playbook_dir': "~/.ansible/roles",
                                        'searchpath': [u'/Users/me/.ansible/roles']}) == "~/.ansible/roles/ansible.cfg"

test_LookupModule_run()

# Generated at 2022-06-23 11:34:48.201854
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()


# Generated at 2022-06-23 11:34:48.968318
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    print(l)

# Generated at 2022-06-23 11:34:55.570024
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    import shutil
    file_content = 'foo'
    temp_dir_path = tempfile.mkdtemp()
    test_file_path = os.path.join(temp_dir_path, "foobar.txt")
    with open(test_file_path, 'w') as test_file:
        test_file.write(file_content)
    module = LookupModule()
    result = module.run(['foobar.txt'], variables=dict(file_root=temp_dir_path))[0]
    shutil.rmtree(temp_dir_path)
    assert result == "foo"

# Generated at 2022-06-23 11:35:03.256819
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # class_instance = LookupModule(None, None)
    class_instance = LookupModule()
    assert class_instance.get_option('rstrip') == True
    assert class_instance.get_option('lstrip') == False
    options = {}
    options['rstrip'] = False
    options['lstrip'] = True
    class_instance.set_options(var_options=None, direct=options)
    assert class_instance.get_option('rstrip') == False
    assert class_instance.get_option('lstrip') == True

# Generated at 2022-06-23 11:35:05.651202
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert len(LookupModule.__doc__) > 0
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:35:06.896441
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule # constructor test for an UnexpectedException

# Generated at 2022-06-23 11:35:07.836474
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-23 11:35:09.393038
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()

    # Constructor has no return value, so just test it
    # runs without error
    assert True

# Generated at 2022-06-23 11:35:11.023941
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-23 11:35:20.890404
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()

    # Testing absence of file
    assert lookup_module.run(['foobar'], {}) == []

    # Testing presence of a file
    assert lookup_module.run(['hello_world.txt'], {}) == ["hello world"]
    assert lookup_module.run(['hello_world.txt'], {'lstrip': True}) == ["hello world"]

    # Testing presence of a file with whitespaces
    assert lookup_module.run(['hello_world_whitespace.txt'], {}) == ["hello world"]
    assert lookup_module.run(['hello_world_whitespace.txt'], {'lstrip': True}) == ["hello world"]


# Generated at 2022-06-23 11:35:26.700426
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup.set_options(direct={'lstrip': True, 'rstrip': True})
    assert lookup._options == {
        '_terms': (),
        'lstrip': True, 'rstrip': True
    }
    assert lookup._display is not None
    assert lookup._fail_on_undefined_errors == True
    assert lookup._templar is not None
    assert lookup._loader is not None
    assert lookup._variable_manager is not None

# Generated at 2022-06-23 11:35:33.974219
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import pytest_ansible_plugins.module_utils.ansible_lookup
    sys.modules['ansible.plugins.lookup.file'] = pytest_ansible_plugins.module_utils.ansible_lookup
    assert hasattr(pytest_ansible_plugins.module_utils.ansible_lookup, 'LookupModule')
    lookup = pytest_ansible_plugins.module_utils.ansible_lookup.LookupModule()
    assert lookup is not None
    assert lookup.run(['/some/path']) is None

# Generated at 2022-06-23 11:35:37.427628
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    display = Display()
    display.display(u'I am Ansible Output')

    lookup = LookupModule()
    # Run
    terms = ['/etc/ansible/roles/role_under_test/vars/main.yml']
    variables = {}
    lookup.run(terms)

# Generated at 2022-06-23 11:35:48.497817
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile

    # Test when the file is not found
    look = LookupModule()
    # Test when a file is found
    try:
        (fd, path) = tempfile.mkstemp()
        os.close(fd)

        terms = [("bogus"),"doesnotexist",(path)]
        result = look.run(terms)
        assert result == ['']
    except:
        raise
    finally:
        os.unlink(path)

    # Test when a file contains whitespace and whitespace stripping is requested

# Generated at 2022-06-23 11:35:51.006668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupModule = LookupModule()
    assert lookupModule.get_option('lstrip') == False

# Generated at 2022-06-23 11:35:52.399179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule(None, None)

# Generated at 2022-06-23 11:35:53.776954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-23 11:35:55.643131
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookupFile = LookupModule()
    assert (lookupFile)

# Generated at 2022-06-23 11:36:05.096784
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize objects
    l = LookupModule()
    l.set_loader(None)
    l.set_templar(None)
    l.set_context(None)
    l.set_environment(None)
    # Create terms object
    terms = []
    terms.append('test.txt')
    # Create variables object
    variables = {}
    # Create kwargs object
    kwargs = {}
    # Run the run method from class LookupModule
    assert l.run(terms, variables, **kwargs) == ['contents of test.txt']
    # Create terms object
    terms = []
    terms.append('test.txt')
    terms.append('test1.txt')
    # Run the run method from class LookupModule

# Generated at 2022-06-23 11:36:15.340521
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test file lookups
    lookup_module = LookupModule()
    lookup_term = {
        'roles/test/files/test.txt': ['Test file content', '\n'],
        'roles/test/files/test2.txt': ['Test file content 2', '\n'],
        '/tmp/test.txt': ['Test file  content', '\n']
    }
    for term, result in lookup_term.items():
        rv = lookup_module.run([term])
        assert rv[0] == result[0]
        assert rv[1] == result[1]
    # Test with stripped value
    lookup_module = LookupModule(rstrip=True)
    term = 'roles/test/files/test.txt'
    rv = lookup_module.run([term])


# Generated at 2022-06-23 11:36:16.557866
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module is not None

# Generated at 2022-06-23 11:36:24.242485
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Call constructor of class LookupModule
    lookup_module = LookupModule()
    # Call run() of class LookupModule
    #terms = 'dict_file'
    #variables = {'inventory_dir': './test/utils/plugins/lookup/', '_hostvars': 'hostvars'}
    #kwargs = {'help': 'call run() of class LookupModule'}
    #lookup_module.run(terms, variables, **kwargs)
    pass


# Generated at 2022-06-23 11:36:25.576709
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert hasattr(lookup, 'run')

# Generated at 2022-06-23 11:36:31.106196
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create a class of type LookupModule
    lookup = LookupModule()

    # Creating a dictionary to pass in the parameters
    options = dict(
        rstrip = True,
        lstrip = False
    )

    # Creating a list of terms
    terms = ['ansible/test/test_lookup_plugin/test_files/file1.txt',
             'ansible/test/test_lookup_plugin/test_files/file2.txt']

    # Creating a dictionary to pass in the variables
    variables = dict(
        foobar = "bar"
    )

    # Asserting the expected result of the run method
    assert lookup.run(terms, variables, **options) == ["this is file1", "this is file2"]

# Generated at 2022-06-23 11:36:42.537245
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import tempfile
    from ansible import constants as C
    from ansible.module_utils.six import PY3
    import os
    import sys

    if PY3:
        unicode = str

    # Save the current CWD
    oldcwd = os.getcwd()
    # Test outside the default search path
    os.chdir('/tmp')

    # Create temp file with content
    (handle, name) = tempfile.mkstemp()
    with os.fdopen(handle, 'w') as f:
        f.write('# This is a ansible lookup test file')

    # Create a lookup module
    lookup_module = LookupModule()

    # Read the file
    ret = lookup_module.run([name])

    assert len(ret) == 1
    assert type(ret[0]) == unicode

# Generated at 2022-06-23 11:36:44.912216
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Generalized test for constructor of parent class.
    # As this class does not have any additional parameters,
    # no additional tests are performed.
    l = LookupModule()

# Generated at 2022-06-23 11:36:45.757535
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule({}) is not None)

# Generated at 2022-06-23 11:36:46.496483
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    return lookup

# Generated at 2022-06-23 11:36:52.636746
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert not LookupModule('')
    assert not LookupModule(None)
    assert not LookupModule(1)
    assert not LookupModule(1.0)
    assert not LookupModule({})
    assert not LookupModule([])
    assert not LookupModule(True)
    assert not LookupModule(False)

# Generated at 2022-06-23 11:37:01.657989
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # If a file path is passed as a parameter, it must return the content of that file.
    params = {'_raw': ['/path/to/file'], '_terms': ['/test']}
    with patch("os.path.exists", return_value=True):
        with patch("ansible.plugins.lookup.file.LookupBase.find_file_in_search_path") as mock_find_file_in_search_path:
            mock_find_file_in_search_path.return_value = "/test"

# Generated at 2022-06-23 11:37:03.988963
# Unit test for constructor of class LookupModule
def test_LookupModule():
    ms = LookupModule()
    assert isinstance(ms,LookupModule)

# Generated at 2022-06-23 11:37:10.274070
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # This test needs the file lookup_plugins/file.py to
    # be updated with this content before running
    # - lines with '# Unit test' are to be removed after the test
    # - lines with '# Unit test' have to be replaced by original one when the test is done

    # Unit test start
    #
    # Set mocks and attributes

    content = 'I am the content of the file'
    lookupBase = LookupModule()

    # args
    terms = ['test_file'] # test_file.txt exists in ./lookup_plugins folder
    lookupBase.set_options(direct=dict(rstrip=True, lstrip=False))

    # Unit test body
    ret = lookupBase.run(terms)
    assert ret == [content]

    # Unit test end

# Generated at 2022-06-23 11:37:11.506228
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_mod = LookupModule()

# Generated at 2022-06-23 11:37:12.710162
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()


# Generated at 2022-06-23 11:37:15.162371
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import sys
    import parent
    result = sys.modules['parent'].LookupModule()

    assert type(result) == parent.LookupModule

# Generated at 2022-06-23 11:37:16.047347
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupModule)

# Generated at 2022-06-23 11:37:18.351480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    m = LookupModule()
    assert m.run(['/home/toto'], {}) == []
    assert m.run([], {}) == []

# Generated at 2022-06-23 11:37:22.379214
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.plugins.lookup import LookupBase

    module = LookupModule()
    assert isinstance(module, LookupBase)
    assert hasattr(module, 'run')


# Generated at 2022-06-23 11:37:33.119525
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # unit test for method run of class LookupBase
    lookups_lookupbase_test()
    # unit test for method run of class LookupModule
    lookup.set_loader(dict(get_basedir=lambda x: ""))
    lookup.set_options(direct=dict(lstrip=False))
    assert lookup.run([u"lookup_base_test.txt"],
                 variables=dict(ansible_basedir="../ansible")) == [u"this is a test of the file lookup\n"]
    lookup.set_options(direct=dict(lstrip=True))
    assert lookup.run([u"lookup_base_test.txt"],
                 variables=dict(ansible_basedir="../ansible")) == [u"this is a test of the file lookup\n"]
    lookup

# Generated at 2022-06-23 11:37:41.815217
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

    #Run on terms "value1" and "value2" with variable options "dict1" and "dict2"

    #Should return ["dict1 is value1"]
    #Run with variable options "dict1" and "dict2", looking for term "value1"
    result = lookup.run(["value1"], {"dict1":"value1", "dict2":"value2"}, lstrip=True)
    assert result == ["value1"]

    #Should return ["dict2 is value2"]
    #Run with variable options "dict1" and "dict2", looking for term "value2"
    result = lookup.run(["value2"], {"dict1": "value1", "dict2": "value2"}, lstrip=True)
    assert result == ["value2"]

    #Should return ["dict1 is value1", "

# Generated at 2022-06-23 11:37:51.432203
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class DummyModule(object):
        class DummyFile(object):
            def __init__(self, *args, **kwds):
                pass

        def __init__(self, *args, **kwds):
            self._result = (2, ('', ['', '']))

        def _get_file_contents(self, path):
            return (b'test\ncontents', self.DummyFile(path, 'r'))
    dummy_module = DummyModule()

    lookup_module = LookupModule()
    lookup_module._loader = dummy_module
    result = lookup_module.run([''], variables={}, rstrip=True)
    assert result == ['test', 'contents']

# Generated at 2022-06-23 11:38:00.791693
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test empty terms
    lookup = LookupModule()
    terms = []
    result = lookup.run(terms=terms)
    assert result == []

    # Test with all valid terms
    lookup = LookupModule()
    path1 = '/tmp/test.txt'
    path2 = '/tmp/test.md'
    with open(path1, 'w') as fh:
        fh.write('contents of test.txt')
    with open(path2, 'w') as fh:
        fh.write('contents of test.md')
    terms = [path1, path2]
    result = lookup.run(terms=terms)
    assert result == ['contents of test.txt', 'contents of test.md']

    # Test with all invalid terms
    lookup = LookupModule()

# Generated at 2022-06-23 11:38:03.057566
# Unit test for constructor of class LookupModule
def test_LookupModule():
     foo = LookupModule()
     assert foo is not None, "foo should be a LookupModule"

# Generated at 2022-06-23 11:38:05.265589
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lu = LookupModule()
    # TODO: test this out more
    assert lu is not None

# Generated at 2022-06-23 11:38:10.492317
# Unit test for constructor of class LookupModule
def test_LookupModule():
    from ansible.plugins.loader import lookup_loader
    lookup_class, lookup_provider, lookup_loader_obj = lookup_loader._get_lookup_plugin_loader(LookupModule.__name__)
    lookup_loader_obj.get('/not/existing/path', {}, {})

# Generated at 2022-06-23 11:38:13.112528
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert module != None

# Generated at 2022-06-23 11:38:22.810204
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create the file in the path: /tmp/ansible_test_file_lookup_module (no ending /)
    path_to_file = '/tmp/ansible_test_file_lookup_module'
    lookup_path = [path_to_file]
    content_of_file = 'lorem ipsum'
    with open(path_to_file, 'w') as f:
        f.write(content_of_file)
    lookup_module = LookupModule(loader=None, basedir='/tmp/')
    content_of_file_loaded = lookup_module.run(terms=['ansible_test_file_lookup_module'], variables=None, **{'path' : lookup_path})
    assert content_of_file == content_of_file_loaded[0]

# Generated at 2022-06-23 11:38:31.225789
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    # File exists
    results = lm.run(terms=["test_data/test_file.txt"], variables={'inventory_dir': 'test_inventory'})
    assert results == ["The contents of test_data/test_file.txt."]
    # File does not exist
    results = lm.run(terms=["test_data/file_does_not_exist.txt"], variables={'inventory_dir': 'test_inventory'})
    assert results == []

# Generated at 2022-06-23 11:38:41.450555
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Dummy class for unit testing purposes only
    class DummyLookupModule(LookupModule):

        # Dummy method for unit testing purposes only
        def _get_file_contents(self, lookupfile):
            return "contents of the file", True

        # Dummy method for unit testing purposes only
        def find_file_in_search_path(self, variables, dirname, filename):
            return "path of the file"

    # Instantiate a DummyLookupModule object
    dummy_lookup_module = DummyLookupModule()
    # Instantiate a LookupModule object
    module = LookupModule()

    # Test run method of LookupModule object
    terms = ["foo.txt", "bar.txt", "biz.txt"]
    variables = None
    kwargs = {'_terms': terms}
    expected