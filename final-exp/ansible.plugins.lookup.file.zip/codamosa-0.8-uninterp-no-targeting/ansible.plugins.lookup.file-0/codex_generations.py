

# Generated at 2022-06-21 05:53:16.204002
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:53:26.518611
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.get_basedir = lambda: "/path/to/ansible"
    l.get_search_paths = lambda: ["/path/to/ansible/tests/test_utils/lookup/file/"]
    # test reading from file
    result = l.run([u"test.txt"])[0]
    assert result == u"Hello World\n"
    result = l.run([u"/path/to/ansible/tests/test_utils/lookup/file/test.txt"])[0]
    assert result == u"Hello World\n"

# Generated at 2022-06-21 05:53:38.550678
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Mock modules and config
    from ansible.plugins.loader import LookupModule as LookupModuleMock
    lookup_mock = LookupModuleMock(name='file', basedir='./')

    # Test for parameter terms
    terms = ['foo.txt']
    result = lookup_mock.run(terms=terms)
    assert result[0] == 'foo content'

    # Test for parameter variables
    variables = {'a': 1, 'b': 2}
    lookup_mock.set_options(var_options=variables)
    result = lookup_mock.run(terms=terms, variables=variables)
    assert result[0] == 'foo content'

    # Test for parameter kwargs
    kwargs = {'rstrip': True, 'lstrip': False}
    lookup_mock.set

# Generated at 2022-06-21 05:53:50.893623
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = AnsibleModule(argument_spec=dict(
        _terms=dict(type='list', elements='str', required=True),
        rstrip=dict(type='bool', default=True),
        lstrip=dict(type='bool', default=False),
    ))

    lu = LookupModule()
    # test content

# Generated at 2022-06-21 05:53:51.391668
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:54:01.985830
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import json
    import sys
    import os
    import tempfile

    (fd, fname) = tempfile.mkstemp()
    os.write(fd, b"one\n")
    os.write(fd, b"two\n")
    os.write(fd, b"three\n")
    os.close(fd)

    # insert this module into the module path, so we can import it
    sys.path.insert(0, os.path.dirname(__file__))

    my_args = {
        '_terms': [fname],
        '_raw': True,
        '_dont_log': True,
        '_dont_log_results': True,
        '_lookup_plugin': 'file',
        'run_once': True
    }

# Generated at 2022-06-21 05:54:04.320787
# Unit test for constructor of class LookupModule
def test_LookupModule():

    result = LookupModule()

    assert type(result) == LookupModule

# Generated at 2022-06-21 05:54:12.214202
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.utils.display import Display
    from ansible import context
    import pytest

    options = context.CLIOptions()
    options.connection = 'local'
    options.module_path = ''
    context._init_global_context(options)

    display = Display()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

# Generated at 2022-06-21 05:54:21.900717
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case where file is present and has a correct value
    test_case_1 = dict(
        terms=[u''],
        variables=dict(
            ansible_facts=dict(
                ansible_all_ipv4_addresses=[u'192.168.122.236', u'192.168.122.1']
            )
        ),
        kwargs=dict(
            lstrip=False,
            rstrip=False,
            vault_password=None,
            convert_data=True,
            wantlist=True
        ),
        result=[u'']
    )

    # Test case where file is present and has a correct value

# Generated at 2022-06-21 05:54:32.677878
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test object initialization
    lu = LookupModule()
    
    # Test file lookup
    lookupfile = lu._loader._find_file_in_search_path(lu._loader.module_loader.get_all_search_paths(),'','test.txt')

    lu.set_options()

    assert 'test lookup' == lu.find_file_in_search_path(None,'files','test.txt')

    # Assert the test-generated file's contents
    assert lu.run(['test.txt']) == ['test lookup']
    
    # Assert the test-generated file's contents with options lstrip=True and rstrip=True
    assert lu.run(['test.txt'],lstrip=True,rstrip=True) == ['test lookup']

    # Assert the test-generated file's

# Generated at 2022-06-21 05:54:39.625325
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # The test case
    terms = ['foo.txt', 'bar.txt', 'baz.txt']
    variables = None
    kwargs = {}

    # The object under test
    look = LookupModule()

    # The expected result
    exp = ['foo', 'bar', 'baz']

    # Get the actual result
    act = look.run(terms, variables, **kwargs)

    # Test
    assert exp == act

# Generated at 2022-06-21 05:54:50.231209
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Create test LookupModule
    lm = LookupModule()

    # Create test file (test.txt) in "files" folder
    test_file = open('files/test.txt', 'w')
    test_file.write('test')
    test_file.close()

    # Create test file (subfolder/test.txt) in "files" folder
    test_file = open('files/subfolder/test.txt', 'w')
    test_file.write('subfolder test')
    test_file.close()

    # Test with correct path (no search path)
    ret = lm.run(terms=['files/test.txt'], variables={})
    assert ret[0] == 'test'

    # Test with correct path (with search path)

# Generated at 2022-06-21 05:54:58.306302
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with valid file path
    test_lookup_module = LookupModule()
    assert test_lookup_module.run('file_path') == ['The content of file at file_path']

    # Test with invalid file path
    test_lookup_module = LookupModule()
    try:
        assert test_lookup_module.run('file_path_invalid')
        # control should not come here as an exception should be thrown
        assert False
    except AnsibleError:
        assert True

# Generated at 2022-06-21 05:55:06.442230
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Test with file that doesn't have any variable
    lookup_module = LookupModule()

    # Test file with variable
    lookup_module.set_options(var_options={})
    lookup_module.set_options(direct={'lstrip': True, 'rstrip': False})

    # Use the internal ansible library to locate the file
    lookup_module.find_file_in_search_path = MagicMock(return_value="/home/test/test.txt")

    # Use the internal ansible loader to get the file contents
    b_contents = b"Test file contents"
    show_data = b''
    lookup_module._loader.get_file_contents = MagicMock(return_value=(b_contents, show_data))

    # Result of the test
    result = [b'Test file contents']

   

# Generated at 2022-06-21 05:55:08.571735
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert lookup.lookup_type == 'file'

    


# Generated at 2022-06-21 05:55:10.643972
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup = LookupModule()
    assert my_lookup is not None

# Generated at 2022-06-21 05:55:19.666396
# Unit test for constructor of class LookupModule
def test_LookupModule():
    import os
    import sys

    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest

    class TestLookupModule(unittest.TestCase):
        ''' Unit tests for LookupModule '''

        def test_constructor(self):
            lm = LookupModule()
            self.assertEqual(lm.__class__, LookupModule)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLookupModule)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-21 05:55:21.676722
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 05:55:31.562792
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import tempfile
    from ansible.compat.tests import unittest
    from ansible.module_utils._text import to_bytes

    class TestLookupModule(unittest.TestCase):

        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()
            self.addCleanup(os.rmdir, self.tmpdir)
            self.test_file = os.path.join(self.tmpdir, 'testfile')
            with open(self.test_file, 'wb') as testfile:
                testfile.write(b'foobar')

        def test_simple_run(self):
            lookup_module = LookupModule()

# Generated at 2022-06-21 05:55:32.693874
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:55:39.097381
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)


# Generated at 2022-06-21 05:55:44.806564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os

    class FakeVarsModule:
        class FakeVarsModuleVars:
            def __init__(self):
                self.host_vars = {}
                self.group_vars = {}
                self.options = {'role': {}}

            def __getitem__(self, item):
                return self.__dict__[item]

        def __init__(self):
            self.vars = FakeVarsModule.FakeVarsModuleVars()

    class FakePluginLoader:
        def __init__(self):
            pass

        def get_basedir(self, basedir):
            return os.path.join(os.path.dirname(__file__), '../lookup_plugins/files')


# Generated at 2022-06-21 05:55:53.803108
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # Test with no search path
    result = lookup.run([], variables={'foo': 'bar'})
    assert result == []
    # Test with a search path
    lookup = LookupModule()
    result = lookup.run([], variables={'foo': 'bar', 'ansible_lookup_paths': ['/etc/templates']})
    assert result == []
    # Test with a search path, and a string term
    lookup = LookupModule()
    result = lookup.run(['/etc/hosts'], variables={'foo': 'bar', 'ansible_lookup_paths': ['/etc/templates']})
    assert result == [u"127.0.0.1\tlocalhost\n"]
    # Test with a search path, and a string term with a variable
    lookup

# Generated at 2022-06-21 05:55:57.929775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    assert lookup_plugin.run('foo.txt') == []
    assert lookup_plugin.run('hello world') == []
    assert lookup_plugin.run('/etc/foo.txt') == []

# Generated at 2022-06-21 05:55:58.747459
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 05:56:01.413195
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert 'LookupModule' in str(lm)



# Generated at 2022-06-21 05:56:04.840960
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the type of an empty instance
    lookup_module = LookupModule()
    assert isinstance(lookup_module, LookupModule)

# Generated at 2022-06-21 05:56:09.587963
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test arguments and return values
    path = '../../tmp/lookup_plugin_file.txt'
    lookup_obj = LookupModule()
    result = lookup_obj.run([path])
    assert isinstance(result, list)
    # The result list should contains 1 item
    assert len(result) == 1
    # The result should be a text
    assert isinstance(result[0], text_type)

# Generated at 2022-06-21 05:56:11.388174
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:56:12.694041
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:56:31.523299
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # return empty list when lookupfile not found
    lookup = LookupModule()
    assert lookup.run(terms=["/path/to/non/existing/file/or/dir"],
                      variables={"ansible_playbook_python": "/bin/false"}) == []


# Generated at 2022-06-21 05:56:32.933033
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # TODO: tests
    pass

# Generated at 2022-06-21 05:56:37.204284
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    tb = LookupModule()
    assert tb.run(['/etc/hosts', '/non/existent/file.txt']) == ['# This is a sample hosts file\n127.0.0.1	localhost\n', '']

# Generated at 2022-06-21 05:56:41.712000
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    # Test construct of class LookupModule
    assert lookup is not None
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-21 05:56:44.333624
# Unit test for constructor of class LookupModule
def test_LookupModule():
    try:
        l = LookupModule()
    except NameError:
        print("NameError")


# Generated at 2022-06-21 05:56:44.994933
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, "TODO: Implement"

# Generated at 2022-06-21 05:56:47.265524
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test for class LookupModule
    lookup = LookupModule()
    assert lookup


# Generated at 2022-06-21 05:56:48.655199
# Unit test for constructor of class LookupModule
def test_LookupModule():
    t = LookupModule()
    assert t is not None

# Generated at 2022-06-21 05:56:50.634817
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass
# Test the module and its properties

# Generated at 2022-06-21 05:56:53.626561
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert type(lm) == LookupModule

# Generated at 2022-06-21 05:57:22.978932
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    mock

    :return:
    """
    import ansible.plugins.lookup.file
    lookup_mod = ansible.plugins.lookup.file.LookupModule()
    assert isinstance(lookup_mod, ansible.plugins.lookup.file.LookupModule)


if __name__ == "__main__":
    # test at command line
    print(__doc__)
    print(test_LookupModule())

# Generated at 2022-06-21 05:57:31.190131
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    def get_test_param(test_file):
        test_file = os.path.join(os.path.dirname(__file__), '..', '..', '..', 'test', 'units', 'data', 'file', test_file)
        handle = open(test_file, 'r')
        args = None
        for line in handle.readlines():
            if line.startswith('#'):
                continue
            if not args:
                try:
                    args = json.loads(line)
                    handle.close()
                    return args
                except ValueError:
                    args = None
                    break
        raise Exception("Could not find test parameter in " + test_file)

    test_param = get_test_param("file_lookup_module.txt")

    test_loader = DataLoader()
    test_path

# Generated at 2022-06-21 05:57:37.416977
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    j = LookupModule()
    search_path = []
    variables = {'adc_password': 'adcpwd'}
    terms = ['/ansible/adc.yml']
    assert j.run(terms, variables, search_path=search_path) == ['adcpwd']

# Generated at 2022-06-21 05:57:39.315745
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()



# Generated at 2022-06-21 05:57:41.388846
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()

# Generated at 2022-06-21 05:57:44.328989
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # The constructor of LookupModule does not take any parameters.
    # So just call it and see if it returns an object.
    assert LookupModule()

# Generated at 2022-06-21 05:57:46.366406
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module is not None

# Generated at 2022-06-21 05:57:48.819974
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.find_file_in_search_path(None, None, None) is None

    # TODO: add tests for the rest of the class methods.

# Generated at 2022-06-21 05:58:01.331999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible
    import ansible.plugins.loader
    import ansible.plugins.lookup.file
    from ansible.module_utils import six

    test_dir = os.path.dirname(__file__)
    dummy_file = os.path.join(test_dir, 'test_file.txt')
    playbook_path = os.path.join(test_dir, 'fake_playbook.yml')

    # Create a dummy file for testing.
    if not os.path.exists(dummy_file):
        with open(dummy_file, 'wt') as fd:
            fd.write('dummy')
    else:
        os.chmod(dummy_file, 0o700)

    assert os.path.exists(dummy_file)

    # Create a fake playbook.
   

# Generated at 2022-06-21 05:58:11.508671
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize mock objects
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.common.collections import ImmutableDict
    import io
    import os
    mock_file = io.BytesIO(to_bytes('{"key": "value"}'))
    mock_loader = type('', (object,), {'_get_file_contents': classmethod(lambda self, f: (mock_file.read(), True))})()
    mock_path_exists = os.path.exists
    os.path.exists = lambda x: True
    vars = ImmutableDict()

    # Perform the test
    lookup_plugin = LookupModule()
    lookup_plugin.set_loader(mock_loader)

# Generated at 2022-06-21 05:59:03.239915
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.vault import VaultLib

    vault_secret = 'dummy'
    vault_password_file = 'dummy'
    vault_identity_list = 'dummy'
    vault_kv_engine_version = None

    vault = VaultLib(vault_secret, vault_password_file, vault_identity_list, vault_kv_engine_version)

    results = LookupModule().run(["/dummy/dummy.txt"], dict(), vault_password=vault)

    assert isinstance(results, list)
    assert len(results) == 0

    results = LookupModule().run(["unittest/sample_file.txt"], dict(), vault_password=vault)

    assert isinstance(results, list)
    assert len(results) == 1
    assert results[0]

# Generated at 2022-06-21 05:59:04.305765
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 05:59:06.582323
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert(isinstance(lm, LookupModule))

# Generated at 2022-06-21 05:59:07.962882
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lm = LookupModule()

# Generated at 2022-06-21 05:59:13.686850
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.plugins.lookup import LookupBase
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    from io import BytesIO

    lookup_module = LookupModule()
    terms = ['/home/isak/ansible/terms']
    variables={}
    kwargs={}
    lookup_module.run(terms, variables, **kwargs)
    assert lookup_module.run(terms, variables, **kwargs) == ''

# Generated at 2022-06-21 05:59:22.153793
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    # with lstrip and rstrip options
    ret=lookup.run(terms=['/tmp/test.txt'], variables={}, lstrip=True, rstrip=True)
    assert ret == [u'1234']
    # without lstrip and rstrip options
    ret=lookup.run(terms=['/tmp/test.txt'], variables={}, lstrip=False, rstrip=False)
    assert ret == [u'    1234']

# Generated at 2022-06-21 05:59:25.032176
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()

# Generated at 2022-06-21 05:59:29.270834
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test the instantiation of class LookupModule
    lookup = LookupModule()
    assert lookup.get_option('lstrip') == False
    assert lookup.get_option('rstrip') == True


# Generated at 2022-06-21 05:59:32.146505
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test that the base class is properly set
    assert LookupModule.__bases__ == (LookupBase,)


# Generated at 2022-06-21 05:59:37.426999
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    class TestVarsModule(object):
        def __init__(self):
            self.environment = { 'AAA': '111', 'BBB': '222' }
    class TestLoaderModule(object):
        def __init__(self, fail=True):
            self.__fail = fail
            self.__b_data = b'hello world'
        def _get_file_contents(self, file_name):
            if self.__fail:
                raise ValueError()
            return (self.__b_data, u'file_name')
    class TestDisplayModule(object):
        def __init__(self):
            self.verbosity = 3
        def display(self, msg, **kwargs):
            pass
        def debug(self, msg, **kwargs):
            pass

# Generated at 2022-06-21 06:01:18.923200
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import shutil
    from ansible.module_utils.six import BytesIO

    # Create a temp directory
    tmpdir = 'test_ansible_config_dir'
    os.mkdir(tmpdir)
    os.mkdir(os.path.join(tmpdir, 'templates'))

    # Create a test file
    testfile = os.path.join(tmpdir, 'testfile')
    with open(testfile, 'w') as fw:
        fw.write('hello world')
    with open(testfile+'.j2') as fw:
        fw.write('hello world')

    # Create a test variable file
    testfile = os.path.join(tmpdir, 'testfile.yml')
    with open(testfile, 'w') as fw:
        f

# Generated at 2022-06-21 06:01:25.999450
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a test object
    lookup_module = LookupModule()

    # Test with empty terms
    test_terms = []
    content = lookup_module.run(test_terms)
    assert(content == [])

    # Test with multiple terms
    test_terms = ['HelloWorld.txt', 'Hemant.txt', 'README.md']
    content = lookup_module.run(test_terms)
    assert(content == ['Hello World!', 'Hemant Kaushik', 'README\n'])

# Generated at 2022-06-21 06:01:27.282289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule)

# Generated at 2022-06-21 06:01:35.709775
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import __main__
    setattr(__main__, '__loader__', None)
    setattr(__main__, '__file__', 'file.py')

    dummy_self = type('dummy', (object,), {})()

    def set_options_mock(self, var_options=None, direct=None):
        self.var_options = var_options
        self.direct = direct

    dummy_self.set_options = set_options_mock.__get__(dummy_self, dummy_self.__class__)

    dummy_self.find_file_in_search_path = lambda x, y, z: "/foo/bar"
    dummy_self.get_option = lambda x: True

# Generated at 2022-06-21 06:01:36.537282
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:01:41.545645
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    assert lm.run(['']) == []
    assert lm.run(['/etc/shadow', 'example'], variables={'role': {}, 'playbook_dir': '.'}) == ['lookup_failed']

# Generated at 2022-06-21 06:01:43.639678
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert not lookup.get_option('lstrip')
    assert lookup.get_option('rstrip')
    assert not lookup.get_option('missing')

# Generated at 2022-06-21 06:01:55.694046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
  test_lookupModule = LookupModule()
  terms = ['/etc/passwd']
  variables = {'foo': 'bar'}
  result = test_lookupModule.run(terms, variables)

# Generated at 2022-06-21 06:02:06.786561
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.plugins.loader import lookup_loader
    from ansible.errors import AnsibleError
    import os

    #setup the test
    obj = lookup_loader.get('file',class_only=True)()
    obj.set_options(var_options={},direct={})

    os.chdir('/tmp')
    #create some test files
    f = open('foo.txt', 'w')
    f.write('foo\n')
    f.close()
    f = open('bar.txt', 'w')
    f.write('bar\n')
    f.close()

    lookupfiles = [
        '/foo.txt',
        'foo.txt',
        'bar.txt',
        '/bar.txt',
        '/baz.txt',
        'baz.txt'
    ]
    results

# Generated at 2022-06-21 06:02:08.475594
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None