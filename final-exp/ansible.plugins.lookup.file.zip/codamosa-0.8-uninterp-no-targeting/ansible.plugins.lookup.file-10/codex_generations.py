

# Generated at 2022-06-21 05:53:21.373698
# Unit test for constructor of class LookupModule
def test_LookupModule():
    terms = ["blahblah.txt", "files/blahblah.txt", "foobar.txt"]
    variables = {
        'ansible_basedir':
        '/home/xiaolin/xiaolin_repo/ansible',
        'myvar': 'foobar.txt'
    }
    lookup_module = LookupModule()
    ret = lookup_module.run(
        terms,
        variables=variables)
    print(ret)
    terms = ["blahblah.txt", "files/blahblah.txt", "foobar.txt"]
    variables = {
        'ansible_basedir':
        '/home/xiaolin/xiaolin_repo/ansible',
        'myvar': 'foobar.txt'
    }
    lookup_module = LookupModule()
    ret = lookup

# Generated at 2022-06-21 05:53:25.116943
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test case run with two_args
    lookup = LookupModule()
    with pytest.raises(AnsibleError):
        lookup.run(["/etc/foo.txt"],[{}],{})

    # Test case run with one_arg
    lookup = LookupModule()
    with pytest.raises(AnsibleError):
        lookup.run(["/etc/foo.txt"],{})

# Generated at 2022-06-21 05:53:27.131601
# Unit test for constructor of class LookupModule
def test_LookupModule():
    global lookup_module
    lookup_module = LookupModule()

# Generated at 2022-06-21 05:53:27.920196
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule is not None

# Generated at 2022-06-21 05:53:33.713913
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_plugin = LookupModule()
    lookup_plugin.set_environment()
    example_terms = ["/path/to/foo.txt", "bar.txt", "/path/to/biz.txt"]
    print(lookup_plugin.run(example_terms))

# Generated at 2022-06-21 05:53:35.012925
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # _init_
    assert LookupModule()
    # run
    assert LookupModule().run(terms=[])

# Generated at 2022-06-21 05:53:35.866564
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:53:37.167707
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:53:47.584431
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()

    args = {
        '_terms': ['/etc/hosts'],
        '_variables': None,
        'rstrip': True,
        'lstrip': False,
        '_depth': 0,
        '_task': None,
        '_loader': None,
        '_templar': None,
        '_task_vars': None,
        '_add_newline': False,
    }

    assert lm.run(**args)[0].startswith('127.0.0.1')

# Generated at 2022-06-21 05:53:50.621837
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup != None
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 05:53:55.826411
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #Initiate lookupmodule with a specific loader
    lookupmodule = LookupModule()
    assert lookupmodule

# Generated at 2022-06-21 05:53:57.840123
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:53:59.254065
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    print(lookup)

# Generated at 2022-06-21 05:54:10.709803
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
    this is a bit of a hack since I don't see a better way to test
    the constructor and init function
    """
    # if this is invoked with --test, the first argument will be the test filename (here)
    # the second argument will be the string "--test"
    options = {'_terms': ["foo", "bar"]}
    mock_loader = 'This is a mock loader'
    test_options = {'_loader': mock_loader}
    test_variable_manager = 'This is a mock variable manager'
    test_inventory = 'This is a mock inventory'

    lookup_plugin = LookupModule(loader=mock_loader, variable_manager=test_variable_manager, inventory=test_inventory)

    assert lookup_plugin._options == test_options

    # AnsibleOptions is immutable, so we can't actually

# Generated at 2022-06-21 05:54:13.014719
# Unit test for constructor of class LookupModule
def test_LookupModule():
  module = LookupModule()
  print(module.run(["test"]))

# Generated at 2022-06-21 05:54:18.664915
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # testing with a string value
    assert LookupModule().run(['/home/test'], ['/home/test']) == ['/home/test']
    # testing with a list value
    assert LookupModule().run(['/home/test1','/home/test2']) == ['/home/test1','/home/test2']

# Generated at 2022-06-21 05:54:20.270526
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:54:31.477578
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.plugins.loader import LookupModule as TestLookupModule
    test_lookup = TestLookupModule()

    test_lookup.set_loader( DictDataLoader({ "files": ["/etc/foo.txt"]}) )

    assert test_lookup.run(["foo.txt"]) == ["/etc/foo.txt"]
    assert test_lookup.run(["foo.txt"], variables={"role_path": "/etc/bar.txt"}) == ["/etc/foo.txt"]
    assert test_lookup.run(["foo.txt"], variables={"role_path": "/etc/bar.txt"}) == ["/etc/foo.txt"]

    test_lookup.set_loader( DictDataLoader({ "role_path": ["/etc/bar.txt"]}) )

    assert test_lookup

# Generated at 2022-06-21 05:54:38.029671
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

'''
Running the following command:

ansible-playbook file_lookup_module.yml -i localhost,

gives the following output:

PLAY [all] *************************************************************************************************

TASK [debug] ************************************************************************************************
task path: /tmp/file_lookup_module.yml:3
ok: [localhost] => {
    "msg": "the value of foo.txt is This is the content of the file"
}

PLAY RECAP ****************************************************************************************************
localhost                  : ok=1    changed=0    unreachable=0    failed=0    skipped=0    rescued=0    ignored=0
'''

# Generated at 2022-06-21 05:54:40.324448
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    lookup._display = Display()
    assert lookup is not None

# Generated at 2022-06-21 05:54:50.684208
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Unit test for method run of class LookupModule
    """
    lookup = LookupModule()
    terms = ["show_version.txt"]
    variables = {}
    result = lookup.run(terms, variables, lstrip=True, rstrip=False)
    assert result == [u'Cisco IOS Software, C2960S Software (C2960S-UNIVERSALK9-M), Version 15.0(2)SE4, RELEASE SOFTWARE (fc1)']

# Generated at 2022-06-21 05:54:52.164209
# Unit test for constructor of class LookupModule
def test_LookupModule():

    l = LookupModule()
    assert l

# Generated at 2022-06-21 05:54:55.834668
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print(LookupModule())
    print(LookupModule.__doc__)


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:54:56.870078
# Unit test for constructor of class LookupModule
def test_LookupModule():
    foo = LookupModule()
    assert foo is not None

# Generated at 2022-06-21 05:55:00.307828
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.lookup_type == 'file'

# Generated at 2022-06-21 05:55:01.636161
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert True

# Generated at 2022-06-21 05:55:04.669822
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LM = LookupModule()
    LM.run(["foo.txt"], variables={'role_path': '/my/path'})

# Generated at 2022-06-21 05:55:08.144748
# Unit test for constructor of class LookupModule
def test_LookupModule():
    c = LookupModule()
    assert c is not None, "test_LookupModule: constructor failed"
    assert isinstance(c, LookupBase)

# Generated at 2022-06-21 05:55:20.105145
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    class DummyLoader:
        def __init__(self, pass_thru):
            self.pass_thru = pass_thru
            self.file_contents = {}
        def get_basedir(self, task_ds):
            return 'base_dir'
        def _get_file_contents(self, filename):
            if filename in self.file_contents:
                return self.file_contents[filename], self.pass_thru
            return ('contents', self.pass_thru)
    class DummyVariableManager:
        def get_vars(self, play=None, host=None, task=None, include_delegate_to=True):
            return {}
    loader = DummyLoader('pass_thru')
    variable_manager = DummyVariableManager()

# Generated at 2022-06-21 05:55:28.937103
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.test = True
    lookup = LookupModule()
    lookup.set_options(var_options={}, direct={})
    lookup.set_runner({'_loader': None, '_var_manager': None})
    lookup._loader._get_file_contents = lambda x: (open(x).read().encode(), True)
    lookup.find_file_in_search_path = lambda x: 'plugin/lookup/tests/test_var.txt'
    terms = ['var/test_var.txt', 'test_var.txt']
    assert lookup.run(terms) == [b'var_value\n']

# Generated at 2022-06-21 05:55:50.212493
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Needed for TestAnsibleCore.setUp to correctly set up
    # lookups and filters plugins.
    from ansible.plugins.loader import lookup_loader

    lookup = lookup_loader.get('file', class_only=True)(None, {})
    internal_examples = VariableManager().get_vars(play=Play().load(dict(
        name="test for lookup module",
        hosts=['127.0.0.1'],
        gather_facts='no',
        tasks=[dict(action=dict(module='debug',
                                args=dict(msg="{{lookup('file', '/etc/passwd')}}")))]
    )))

# Generated at 2022-06-21 05:55:57.571769
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    LookupModule = lookup_loader.get('file')
    terms = ['test.txt']
    variables = {'hostvars': {'host1': {'var': 'value'}}}
    with patch.object(LookupModule, 'run', return_value=['this is a test']) as mock_lookup:
        assert mock_lookup.return_value == LookupModule.run(terms, variables)

# Generated at 2022-06-21 05:56:04.987572
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # data for run()
    terms = ['/etc/foo.txt', 'bar.txt']
    lookup_module = LookupModule()
    result = lookup_module.run(terms=terms)

    # run() returns list
    assert isinstance(result, list)
    assert isinstance(result[0], str)
    assert isinstance(result[1], str)

# Generated at 2022-06-21 05:56:08.589597
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display.verbosity = 3
    print("\n\nTESTING: file lookup\n")
    lookup = LookupModule()
    terms = []
    terms.append("clusternodes.list")
    print(lookup.run(terms, variables=None, rstrip=False))

# Generated at 2022-06-21 05:56:16.204437
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class TestLookupModule(LookupModule):
        def __init__(self, **kw):
            self.test_args = kw
    d = dict(test1=1, test2=2, test3=3)
    tlm = TestLookupModule(**d)
    assert tlm.test_args['test1'] == d['test1']
    assert tlm.test_args['test2'] == d['test2']
    assert tlm.test_args['test3'] == d['test3']

# Generated at 2022-06-21 05:56:19.596954
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # noinspection PyCallingNonCallable
    lookup_module = LookupModule()


# Generated at 2022-06-21 05:56:24.886140
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)
    assert LookupModule(None, None).run(["foo"]) == []
    assert LookupModule(None, None).run(["/nonexistent_path"]) == []

# Generated at 2022-06-21 05:56:31.496365
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    kwargs = {}

    # Check file lookup of a file in the 'files' subdir of the lookup plugin directory
    lookup = LookupModule()
    lookup.set_loader('', '')
    terms = [u'specify-vault-id.py']
    lookup.run(terms, **kwargs)
    assert lookup._loader.path_dwim(u'files') == u'/files'

    # Check file lookup of a file in the lookup plugin directory
    lookup = LookupModule()
    lookup.set_loader('', '')
    terms = [u'specify-vault-id.py']
    lookup.run(terms, **kwargs)
    assert lookup._loader.path_dwim(u'') == u''

# Generated at 2022-06-21 05:56:40.180775
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_loader(object())
    lookup.set_options(rstrip=False, lstrip=False)

    # Test case: when term is valid, the content of the file should be returned
    terms = ['/etc/passwd']
    display.vvvv = Mock()
    display.debug = Mock()
    lookup.run(terms)
    display.debug.assert_called_once_with("File lookup term: /etc/passwd")
    display.vvvv.assert_called_once_with(u"File lookup using /etc/passwd as file")

    # Test case: when term is invalid, an Ansible error should be raised
    terms = ['invalid_file']
    display.vvvv = Mock()
    display.debug = Mock()
    lookup.run(terms)

# Generated at 2022-06-21 05:56:42.353576
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm.run is not None

# Generated at 2022-06-21 05:57:04.688540
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 05:57:11.831355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    assert list(module.run(['./test_file'])) == ["Test file\n"]

    module = LookupModule()
    assert list(module.run(['./test_file_to_be_removed'])) == ["Test file\n"]
    assert list(module.run(['./test_file_to_be_removed'], lstrip=True, rstrip=True)) == ["Test file"]

# Generated at 2022-06-21 05:57:16.580339
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Initialize a LookupModule object with a given arguments
    lookup_module_obj = LookupModule()
    lookup_module_obj.set_loader(None)
    lookup_module_obj.set_basedir(None)

    # Mock file_name_args
    file_name_args = ["/path/to/file.txt"]

    # Call method run on the given argument
    assert lookup_module_obj.run(file_name_args) == ['']

# Generated at 2022-06-21 05:57:19.525453
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:57:26.985533
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_instance = LookupModule()
    assert lookup_instance.get_option('_terms') is None
    assert lookup_instance.get_option('_raw_params') is None
    assert lookup_instance.get_option('__file__') is None
    assert lookup_instance.get_option('__line__') is None
    assert lookup_instance.get_option('rstrip') == True
    assert lookup_instance.get_option('lstrip') == False

# Generated at 2022-06-21 05:57:27.681501
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Create an object of class LookupModule
    obj = LookupModule()

# Generated at 2022-06-21 05:57:29.039308
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    l.run()

# Generated at 2022-06-21 05:57:34.816929
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_test = LookupModule()
    lookup_test.set_options({'lstrip': True, 'rstrip': True})
    lookup_test.run(terms=['/etc/passwd'])

    lookup_test.set_options({'lstrip': False, 'rstrip': False})
    contents = lookup_test.run(terms=['/etc/passwd'])

    assert contents == [u'root:x:0:0:root:/root:/bin/bash\ndaemon:x:1:1:daemon:/usr/sbin:/usr/sbin/nologin\n...']

    #Test with 'files' directory
    lookup_test.set_options({'lstrip': True, 'rstrip': True})
    lookup_test.run(terms=['/etc/passwd'])

# Generated at 2022-06-21 05:57:43.505517
# Unit test for constructor of class LookupModule
def test_LookupModule():
    '''
    Unit test for constructor of class LookupModule
    '''
    class Name():
        '''
        Class Name
        '''
        def __init__(self, types=None, loaders=None, baseobjects=None):
            '''
            Constructor test
            '''
            self.types = types
            self.loaders = loaders
            self.baseobjects = baseobjects
    class Display():
        '''
        Class Dislay
        '''
        def __init__(self):
            '''
            Constructor of class Display
            '''
            self.warning = False
            self.deprecated = False
            self.verbosity = 0
            self.skipped = False
            self.aborted = False
            self.error = False
            self.info = False
            self.ok = False

# Generated at 2022-06-21 05:57:51.587124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible import AnsibleException
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.lookup import LookupModule
    from ansible.vars import VariableManager
    from io import BytesIO
    from tempfile import TemporaryDirectory, NamedTemporaryFile

    # Create a temporary file for testing
    with NamedTemporaryFile(mode="w+b") as tmp_file:
        # Set desired contents of file
        tmp_file.write(bytes("temporary file contents", 'utf-8'))
        tmp_file.flush()

        # Create a temporary directory for testing
        with TemporaryDirectory(prefix="ansible_test_file_lookup") as tmp_dir:
            # Create a test lookup file object
            lookupModule = LookupModule()

            # Set up the variable manager

# Generated at 2022-06-21 05:58:43.786393
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    import shutil
    import sys
    import tempfile
    import unittest

    test_dir = os.path.dirname(__file__)
    lookup_dir = os.path.join(test_dir, '../../../lib/ansible/plugins/lookup')
    sys.path.append(lookup_dir)
    from file import LookupModule

    orig_path = os.environ['PATH']
    os.environ['PATH'] = lookup_dir

    script_dir = os.path.dirname(__file__)
    module_dir = os.path.join(script_dir, '..', '..', '..', 'hacking', 'testdata', 'library')
    module_path_win = os.path.join(module_dir, 'win_ping.ps1')
    module

# Generated at 2022-06-21 05:58:45.869945
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

    assert not lookup.run(None)
    assert not lookup.run([])
    assert not lookup.run([""])

    assert len(lookup.run(["non-existing-file"])) == 1
    assert lookup.run(["non-existing-file"])[0] == "lookup_plugin.py"

# Generated at 2022-06-21 05:58:54.252355
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import ansible.parsing.yaml.objects
    import io

    # This test expects the following file structure
    # file
    #   +-- LookupModule.py
    #   +-- test_LookupModule_run.py
    #   +-- files
    #        +-- test_file_1.txt
    #        +-- test_file_2.txt
    #
    # Note: An additional file 'test_file_1_NONEXISTENT.txt' is used in some tests
    # Note: An additional file 'test_file_1_NONSTRING.yaml' is used in some tests
    # Note: An additional file 'test_file_1_LIST.yaml' is used in some tests

    # Build an instance of LookupModule
    lookup_instance = LookupModule()

    # The configured

# Generated at 2022-06-21 05:58:55.670945
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None

# Generated at 2022-06-21 05:59:03.968006
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from collections import namedtuple
    Options = namedtuple('Options', ['lstrip', 'rstrip'])
    l = LookupModule()
    l.set_display(Display())
    lm_terms = {'terms': ['/etc/path/to/openssl.cnf']}
    lm_variables = {'role_path': 'my_role_path'}
    l.set_options(var_options=lm_variables, direct=lm_terms)
    options = Options(lstrip=False, rstrip=False)
    l.set_options(options)

    expected_value = 'Hello World!\n'
    dummyfilepath = 'tests/fixtures/dummyfile'

# Generated at 2022-06-21 05:59:13.748998
# Unit test for method run of class LookupModule
def test_LookupModule_run():
        class mock_display():
            def __init__():
                self.debug = True
        display = mock_display()
        class mock_LookupBase():
            def __init__():
                self.set_options(var_options=variables, direct=kwargs)
                self.get_option(option)
        lookup_base = mock_LookupBase()
        class mock_AnsibleError():
            def __init__():
                self.display()
        ansible_error = mock_AnsibleError()
        ansible_parser_error = mock_AnsibleError()
        class mock_to_text:
            def __init__():
                return 'data'
        to_text = mock_to_text()
        class mock_str():
            def __init__():
                self.rstrip = 'rstrip'


# Generated at 2022-06-21 05:59:14.822281
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    print(lookup_module.run([u'file_test_content'], {}))


# Generated at 2022-06-21 05:59:16.231926
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False, 'Not Implemented'

# Generated at 2022-06-21 05:59:20.064271
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.find_file_in_search_path({}, 'files', './file_exists') == './file_exists'

# Generated at 2022-06-21 05:59:20.901333
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 06:00:55.050657
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:00:56.037242
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()


# Generated at 2022-06-21 06:01:05.694556
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import pytest
    from ansible.plugins.loader import lookup_loader

    def _get_file_contents(self, path):
        '''
        Test method for the private method _get_file_contents which is used to mock the search for a file in
        the play path.  By default, it will return the file contents of "sample_content" and the path "/sample_path/".
        '''
        if path == '/my_terms/sample_path/':
            return 'sample content', path
        elif path == '/my_terms/sample_path_2/':
            return 'sample content 2', path

        return None, None

    sample_terms = [
        'sample_path',
        'sample_path_2'
    ]

    sample_vars = {'some_var': 'some_value'}



# Generated at 2022-06-21 06:01:08.002889
# Unit test for constructor of class LookupModule
def test_LookupModule():

    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 06:01:18.224459
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    from ansible.errors import AnsibleError
    
    # str -> str
    def tmp_file(content):
        fd, path = tempfile.mkstemp(prefix="ansible")
        os.write(fd, content)
        os.close(fd)
        return path
    
    # str -> bool
    def is_file(path):
        return os.path.isfile(path)

    x = LookupModule()
    ret = x.run(terms=["nothing"], variables=None)
    assert isinstance(ret, list)
    assert ret == [], "Expected empty list, got %s" % ret

    # Test with one file
    file = tmp_file("abc")

# Generated at 2022-06-21 06:01:27.878180
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # i.e: /path/to/file/foo/bar.txt
    lookupfile1 = 'foo/bar.txt'

    # i.e: /path/to/file
    lookupfile2 = 'somefile.txt'

    # i.e: /path/to/file/temp/somefile.txt
    lookupfile3 = 'temp/somefile.txt'

    # 1st possible search path
    first_possible_search_path = '/path/to/file'

    # 2nd possible search path
    second_possible_search_path = '/path/to/file/foo'

    # 3rd possible search path
    third_possible_search_path = '/path/to/file/temp'

    # Prepare a _loader object to be used in the mock_open
    # so, when we run the mocked version

# Generated at 2022-06-21 06:01:29.873895
# Unit test for constructor of class LookupModule
def test_LookupModule():
    a = LookupModule()
    assert isinstance(a, LookupBase)

# Generated at 2022-06-21 06:01:31.232795
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LM = LookupModule()


# Generated at 2022-06-21 06:01:36.928663
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Unsupported params
    terms = ['tests/test_file.ini']
    assert module.run(terms, variables={'test_var': 'test_val'}) == ['test_val\n', 'test_val\n']
    # lstrip
    terms = ['tests/test_file.ini']
    assert module.run(terms, variables={'test_var': 'test_val'}, lstrip=True) == ['test_val\n', 'test_val\n']
    # rstrip
    terms = ['tests/test_file.ini']
    assert module.run(terms, variables={'test_var': 'test_val'}, rstrip=True) == ['test_val', 'test_val']


# Generated at 2022-06-21 06:01:38.377553
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()