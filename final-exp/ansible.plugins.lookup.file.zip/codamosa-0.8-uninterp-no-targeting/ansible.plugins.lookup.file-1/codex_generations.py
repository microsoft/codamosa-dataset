

# Generated at 2022-06-21 05:53:12.430872
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:53:20.046122
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    
    # Test Read file
    # Test without options
    lookup_obj = LookupModule()
    lookup_obj.set_loader(DummyLoader())
    
    terms = ["files/foo"]
    expected_result = ["This is foo file"]
    result = lookup_obj.run(terms)
    assert result == expected_result
    
    # Test with options
    terms = ["files/foo"]
    expected_result = ["This is foo file"]
    result = lookup_obj.run(terms, lstrip=True)
    assert result == expected_result
    expected_result = ["This is foo file "]
    result = lookup_obj.run(terms, rstrip=True)
    assert result == expected_result
    expected_result = ["is foo file "]

# Generated at 2022-06-21 05:53:23.570812
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mock_terms = ["test/test_file.txt"]
    mock_loader = "fake_loader"
    mock_templar = "fake_templar"
    mock_variables = "fake_variables"

    lookup_instance = LookupModule(loader=mock_loader, templar=mock_templar, variables=mock_variables)

    assert lookup_instance.run(terms=mock_terms) == ['hello world']
    assert lookup_instance.set_options() is None

# Generated at 2022-06-21 05:53:25.220597
# Unit test for constructor of class LookupModule
def test_LookupModule():
  lookup = LookupModule()
  assert lookup is not None


# Generated at 2022-06-21 05:53:27.814815
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """Unit test for constructor of class LookupModule"""

    # Create a 'LookupModule' object
    look_up_mod = LookupModule()

# Generated at 2022-06-21 05:53:39.391534
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import re
    import shutil
    import sys
    import tempfile

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file in temporary directory
    FilePath = tempfile.mkstemp(dir=tmpdir)[1]

    # Create a object of class  LookupModule
    Lu = LookupModule()

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()
    # Create a temporary file in temporary directory
    FilePath = tempfile.mkstemp(dir=tmpdir)[1]

    ## Test case for LookupBase.run(self, terms, inject=None, variables=None, **kwargs)
    Lu.run(terms=FilePath, variables=None)

# Generated at 2022-06-21 05:53:51.388339
# Unit test for method run of class LookupModule

# Generated at 2022-06-21 05:53:53.688986
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print('Testing')
    lookup_plugin = LookupModule()
    print(lookup_plugin)

if __name__ == "__main__":
    # test_LookupModule()
    print('testing')

# Generated at 2022-06-21 05:53:56.648291
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    results = lookup.run(['README.md'])
    assert results[0].startswith('# Ansible')

# Generated at 2022-06-21 05:53:57.384588
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:54:11.107202
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    lookup_module = LookupModule()
    
    # method run of class LookupModule
    # no option
    terms = ['file1.txt']
    variables = {'ansible_check_mode': False, 'ansible_connection': 'smart', 'hostvars': {}}
    kwargs = {'_terms': terms, '_raw_params': '', '_task': None, '_is_conditional': False, '_use_cache': True, '_is_role_task': False, 'ansible_filter_plugins': ['display'], 'ansible_version': {'full': '2.2.2.0', 'major': 2, 'minor': 2, 'revision': 2, 'string': '2.2.2.0'}, 'ansible_playbook_python': '/usr/bin/python'}

# Generated at 2022-06-21 05:54:21.478269
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Example data used in test
    example_data = "\n".join([
        "foo: Hello world!",
        "123:",
        "    - Hello",
        "    - world!",
        "bar:",
        "    - Hello world!",
        "    - 123: 321"
    ])

    # Test 0: No terms
    terms = []

    lookup = LookupModule()
    assert lookup.run(terms) == []

    # Test 1: One term with contents
    terms = ["example.yml"]

    lookup = LookupModule()
    assert lookup.run(terms) == [example_data]

    # Test 2: One term without contents
    terms = ["not-example.yml"]

    lookup = LookupModule()
    assert lookup.run(terms) == [""]

    # Test 3: Multiple terms with contents

# Generated at 2022-06-21 05:54:22.532635
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert type(lm) == LookupModule


# Generated at 2022-06-21 05:54:23.111017
# Unit test for constructor of class LookupModule
def test_LookupModule():
    my_lookup_module = LookupModule()

# Generated at 2022-06-21 05:54:31.795183
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Ensure the docstring contains the following:
    assert 'name: file' in LookupModule.__doc__
    assert 'author:' in LookupModule.__doc__
    assert 'version_added:' in LookupModule.__doc__
    assert 'description:' in LookupModule.__doc__
    assert 'short_description:' in LookupModule.__doc__
    assert 'notes:' in LookupModule.__doc__
    assert 'examples:' in LookupModule.__doc__
    assert 'return:' in LookupModule.__doc__
    assert 'options:' in LookupModule.__doc__

# Generated at 2022-06-21 05:54:37.083097
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookupModule = LookupModule()
    # Testing with a file in a directory
    data = lookupModule.run(["../lookup_plugins/file.py"])[0].split("\n")
    assert data[0].startswith("#!python") is True
    # Testing with a file in a file
    data = lookupModule.run(["../lookup_plugins/file.py"])[0].split("\n")
    assert data[0].startswith("#!python") is True

# Generated at 2022-06-21 05:54:40.684344
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert lookup_module
    assert lookup_module.run
    assert lookup_module.run_terms


# Generated at 2022-06-21 05:54:50.304479
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.utils.display import Display
    from __main__ import display as global_display
    from ansible.plugins.lookup.file import LookupModule

    module_run_args = {
        '_terms': ['../tests/data/lookup.ini'],
        'var_options': {},
        'direct': {'lstrip': True, 'rstrip': True}
    }
    lookup_module_var = LookupModule()
    global_display.verbosity = 4
    global_display.debug("Running test")
    result = lookup_module_var.run(**module_run_args)
    assert result == [u"# commented line\n[first]\nkey1 = value1\nkey2 = value2\n[second]\nkey3 = value3\nkey4 = value4"]
   

# Generated at 2022-06-21 05:54:52.385134
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin != None

# Generated at 2022-06-21 05:54:53.263250
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 05:55:00.875705
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:55:08.326001
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # setup testing organism
    my_lookup = LookupModule()

    # create a fake file in the module search path
    with open('./lookup_plugins/tmp_test_file', 'w') as test_file:
        test_file.write('Ansible')

    # create a fake file in the ansible.cfg search path
    with open('/tmp/tmp_test_file', 'w') as test_file:
        test_file.write('Ansible')

    # create a fake file in the role search path
    with open('/tmp/roles/test_role/files/tmp_test_file', 'w') as test_file:
        test_file.write('Ansible')

    # file in module search path

# Generated at 2022-06-21 05:55:12.068253
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print()
    lookup = LookupModule()
    print(lookup.__dict__)


if __name__ == '__main__':
    test_LookupModule()

# Generated at 2022-06-21 05:55:14.300200
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Tests: Try to create an instance of class LookupModule
    lookup = LookupModule()

# Generated at 2022-06-21 05:55:22.124046
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Test with a file in the search path
    contents = {'lookup_file': lookup_file}
    lookup_module = LookupModule()
    result = lookup_module.run([u"/path/to/file.txt"], contents, lstrip=True, rstrip=True)
    assert result[0] == u'file contents'

    # Test with a file in the search path with lstrip and rstrip turned off
    contents = {'lookup_file': lookup_file}
    lookup_module = LookupModule()
    result = lookup_module.run([u"/path/to/file2.txt"], contents, lstrip=False, rstrip=False)
    assert result[0] == u'file contents\n\n'

    # Test with file not in search path

# Generated at 2022-06-21 05:55:31.626425
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = sys.modules[__name__]
    setattr(module, 'LookupBase', MagicMock())
    lookup_base_instance = getattr(module, 'LookupBase')()
    setattr(lookup_base_instance, 'run', MagicMock())
    lookup_base_instance.run.return_value = ['foo']
    # pylint: disable=unused-variable
    obj = LookupModule()
    # Test with empty terms
    with pytest.raises(AnsibleError) as excinfo:
        obj.run(['/file1'], variables={'file': '/file2'})
    excinfo.match('could not locate file in lookup: /file1')
    # Test with terms = ['foo']
    lookup_base_instance.run.return_value = ['foo']

# Generated at 2022-06-21 05:55:32.976480
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert True

# Generated at 2022-06-21 05:55:36.323346
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule().find_file_in_search_path({}, 'files', 'a.config') == 'a.config'

# Generated at 2022-06-21 05:55:37.489404
# Unit test for constructor of class LookupModule
def test_LookupModule():
    LookupModule()

# Generated at 2022-06-21 05:55:48.427437
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    terms = ['foo.yaml']
    variable = dict()
    fake_system_plugin_path = 'ansible/plugins/test/system'
    variable['ansible_system_plugins'] = fake_system_plugin_path
    variable['ansible_managed'] = "Ansible managed: {file}\n"
    variable['ansible_playbook_python'] = 'ansible/playbook/play_context.py'
    variable['ansible_version'] = dict()
    variable['ansible_version']['full'] = 'v2.9.1'
    variable['ansible_version']['major'] = 2
    variable['ansible_version']['minor'] = 9
    variable['ansible_version']['revision'] = 1

# Generated at 2022-06-21 05:55:59.336281
# Unit test for constructor of class LookupModule
def test_LookupModule():

    module = LookupModule()
    assert module != None

# Generated at 2022-06-21 05:56:01.340844
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Not much to check
    assert LookupModule().run([]) == []

# Generated at 2022-06-21 05:56:03.611681
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin is not None

# Generated at 2022-06-21 05:56:06.737726
# Unit test for constructor of class LookupModule
def test_LookupModule():
    test = LookupModule()

    # Check that LookupModule is a class
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 05:56:17.054117
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    data = [
        {'terms': ['/etc/foo.txt']},
        {'terms': ['foo.txt']},
        {'terms': ['bar.txt']},
        {'terms': ['biz.txt']},
    ]
    assert LookupModule().run(data[0]['terms'], variables={'inventory_dir': '/etc'}) == ['foo.txt']
    assert LookupModule().run(data[1]['terms'], variables={'inventory_dir': 'bar.txt'}) == ['foo.txt']
    assert LookupModule().run(data[2]['terms'], variables={'inventory_dir': '/etc'}) == ['bar.txt']
    assert LookupModule().run(data[3]['terms'], variables={'inventory_dir': '/etc'}) == ['biz.txt']

# Generated at 2022-06-21 05:56:19.736667
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert hasattr(lookup_module, 'run')

# Generated at 2022-06-21 05:56:30.140476
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    import os
    from ansible.plugins.loader import lookup_loader
    from ansible.module_utils.six import StringIO

    lookup = lookup_loader.get('file', basedir=os.getcwd())
    assert isinstance(lookup, LookupModule)

    # file lookup returns lookup value instead of array for a single file
    assert lookup.run(['.travis.yml']) == u'language: python\npython:\n  - "2.7"\n  - "3.5"\n'

    lookup.set_options(plugin_args={'rstrip': True, 'lstrip': True})
    assert lookup.run(['.travis.yml']) == u'language: python\npython:\n  - "2.7"\n  - "3.5"\n'

    lookup.set_

# Generated at 2022-06-21 05:56:34.445439
# Unit test for constructor of class LookupModule
def test_LookupModule():
    mylookupmodule = LookupModule()
    lookupfile = mylookupmodule.find_file_in_search_path(None, 'files', './fake/filename')
    assert lookupfile == './fake/filename'

# Generated at 2022-06-21 05:56:36.972916
# Unit test for constructor of class LookupModule
def test_LookupModule():
    p=LookupModule()
    assert p is not None


# Generated at 2022-06-21 05:56:49.924703
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # file object contains a string which can be converted to bytes
    file_obj = 'The quick brown fox jumps over the lazy dog'
    # set the method run of class LookupModule to the variable lookup_run
    # it is an instance method which requires an instance of the class, which is created later
    lookup_run = LookupModule.run
    # create an instance of the class
    lookup_module = LookupModule()
    # mock the appropriate methods to provide the required input arguments
    # and to catch output, also check if methods are called correctly

# Generated at 2022-06-21 05:57:14.557179
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """ AnsibleLookupModule is an abstract base class. create a mock of it and test that the constructor fails """
    class LookupModule(LookupBase):
        def __init__(self, *args, **kwargs):
            super(LookupModule, self).__init__(*args, **kwargs)

    lookup_mock = LookupModule()

    # Assert that the class didn't construct without error
    assert lookup_mock is not None

# Generated at 2022-06-21 05:57:15.345715
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:57:16.495629
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l is not None

# Generated at 2022-06-21 05:57:18.230747
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert hasattr(lm, 'run')

# Generated at 2022-06-21 05:57:28.300598
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    def find_file_in_search_path(self, variables, search_path, file_name):
        return [file_name]

    lookup_module = LookupModule()
    lookup_module.set_loader = lambda x: lookup_module
    lookup_module._loader = lambda: lookup_module
    lookup_module.find_file_in_search_path = find_file_in_search_path
    lookup_module._loader.get_basedir = lambda x: ''
    lookup_module._loader._get_file_contents = lambda x: (b'dummy_content', '')

    lookup_module.run(['dummy_file']) # Should not raise an exception

# Generated at 2022-06-21 05:57:28.906539
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 05:57:31.607705
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    l.set_options(var_options={}, direct={'defer_things': True})
    l.set_context(loader=None)
    # Expecting error when lookup doesn't find the file

# Generated at 2022-06-21 05:57:35.693655
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Arrange
    class MockLoader:

        def _get_file_contents(self, filename):
            if filename == 'path/to/file1.txt':
                return ('file1 contents', True)
            elif filename == 'path/to/file2.txt':
                return ('file2 contents', True)
            elif filename == 'path/to/file3.yml':
                return ('file3 contents', True)
            else:
                raise ValueError('file name expected: path/to/file1.txt, path/to/file2.txt or path/to/file3.txt')

    class MockDisplay:
        def __init__(self):
            self.calls = []

        def debug(self, msg):
            self.calls.append(('debug', msg))


# Generated at 2022-06-21 05:57:43.942996
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    results = []
    lookup = LookupModule()
    results.append(lookup.run(terms=["lookup_plugins/file/test.txt"], variables={}, rstrip=True, lstrip=True))
    results.append(lookup.run(terms=["lookup_plugins/file/test.txt"], variables={}, rstrip=False, lstrip=True))
    results.append(lookup.run(terms=["lookup_plugins/file/test.txt"], variables={}, rstrip=False, lstrip=False))
    results.append(lookup.run(terms=["lookup_plugins/file/test.txt"], variables={}, rstrip=True, lstrip=False))
    assert results[0][0] == 'This is a test\n'

# Generated at 2022-06-21 05:57:45.881614
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 05:58:37.353133
# Unit test for constructor of class LookupModule
def test_LookupModule():

    # Create object
    obj = LookupModule()

    # Test method 'run'
    # Should be 2 items and they should be different
    result1 = obj.run(["foo.txt","bar.txt"])
    result2 = obj.run(["foo.txt","bar.txt"])
    assert len(result1) == 2
    assert result1 != result2

    # Test method 'run'
    # Should be 2 items and the first one should be identical to 'this is a test'
    testString = "this is a test"
    obj.run(["foo.txt","bar.txt"])
    result3 = obj.run(["foo.txt"])
    assert len(result3) == 1
    assert result3[0] == testString

# Generated at 2022-06-21 05:58:44.321969
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=None)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create play with tasd as host and one task
    play_source = dict(
        name="insane test task",
        hosts="localhost",
        gather_facts="no",
        tasks=[]
    )
    play = Play().load(play_source, variable_manager=variable_manager, loader=loader)

    # create task

# Generated at 2022-06-21 05:58:52.602787
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    arguments = {}

    variable_manager = VariableManager()
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager, [])

    lookup_plugin = LookupModule(loader=loader, inventory=inventory, **arguments)

    terms = ['/tmp/does_not_exist.txt', '/etc/hosts']
    result = lookup_plugin.run(terms, None)
    assert result[0] == u''

# Generated at 2022-06-21 05:58:57.639785
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    b_data = b"Hello, World!"
    lookup = LookupModule()
    assert b_data == lookup.run(["/etc/welcome.txt"], loader=MockLoader())



# Generated at 2022-06-21 05:59:05.136006
# Unit test for constructor of class LookupModule
def test_LookupModule():
    class test_class():
        def __init__(self):
            pass

    test_obj = test_class()
    test_obj.params = {
        'rstrip': True,
        'lstrip': False
    }
    test_obj.set_options = test_class()
    test_obj.set_options.var_options = None
    test_obj.set_options.direct = None
    test_obj.set_options.lstrip = True
    test_obj.set_options.rstrip = False
    test_obj._loader = test_class()
    test_obj._loader._get_file_contents = test_class()
    test_obj._loader._get_file_contents.return_value = "test_string"
    test_obj.find_file_in_search_path = test_class

# Generated at 2022-06-21 05:59:12.021911
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # noinspection PyUnresolvedReferences
    """
    Run the method under test
    :return:
    """
    test_instance = LookupModule()
    terms_list = ['/etc/foo.txt']
    ret = test_instance.run(terms=terms_list)
    print(ret)
    # assert ret ==
    # expected =
    # assert expected == ret

# noinspection PyUnresolvedReferences

# Generated at 2022-06-21 05:59:24.469731
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()

    os_path_exists_count = 0
    os_path_isfile_count = 0
    os_path_isfile_return_value = True
    os_path_isfile_side_effect = [None, True, None]
    os_path_isfile_mock = mocker.patch('os.path.isfile')
    os_path_isfile_mock.side_effect = os_path_isfile_return_value
    os_path_isfile_mock.side_effect = os_path_isfile_side_effect

    os_path_isfile_return_value = True
    os_path_isfile_side_effect = [os_path_isfile_return_value, None]

# Generated at 2022-06-21 05:59:27.343135
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    # Exceptions are not being raised
    assert module.run(['invalid_file_or_dir']) == []

# Generated at 2022-06-21 05:59:32.175120
# Unit test for constructor of class LookupModule
def test_LookupModule():

  # Test with no options
  lookup = LookupModule()
  assert lookup is not None

  # Test with options
  vars = dict(
    test = 'test'
  )
  options = dict(
    rstrip = False,
    lstrip = False
  )
  lookup = LookupModule(loader=None, templar=None, variables=vars, **options)
  assert lookup is not None


# Generated at 2022-06-21 05:59:45.043151
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.playbook.play import Play

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = Inventory(loader, variable_manager, 'localhost')
    variable_manager.set_inventory(inventory)


# Generated at 2022-06-21 06:01:20.659792
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup.get_option('lstrip') == False
    assert lookup.get_option('rstrip') == True

# Generated at 2022-06-21 06:01:28.907570
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # create a test-instance of LookupModule
    lm = LookupModule()

    # create a test-instance of AnsibleOptions
    ao = ansible.utils.module_docs.AnsibleOptions()
    # call the method set_options of class LookupModule
    lm.set_options(var_options=ao, direct={})

    # create a test-file
    with open('/tmp/foo.txt', 'w') as f:
        f.write('foo')
    # create a test-file
    with open('/tmp/bar.txt', 'w') as f:
        f.write('bar')

    # call the method run of class LookupModule
    result = lm.run(terms=['/tmp/foo.txt'], variables=ao)
    assert result == ['foo']

    # call

# Generated at 2022-06-21 06:01:31.796718
# Unit test for constructor of class LookupModule
def test_LookupModule():
    """
        Unit test for LookupModule() class
    """
    lookup = LookupModule()
    assert lookup is not None


# Generated at 2022-06-21 06:01:37.346271
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    This test must be run in the same directory as test_ansible_module.py
    """
    import os
    import inspect
    import ansible.plugins.lookup.file as testclass
    tc_instance = testclass.LookupModule()

    # Save the current working directory
    cwd_old = os.getcwd()
    # Change current working directory to the directory of the testfile
    os.chdir(os.path.dirname(inspect.getfile(testclass)))
    # Save the current loader
    loader_old = tc_instance._loader

# Generated at 2022-06-21 06:01:40.147386
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    terms = [
        'test_file1.txt',
        'test_file2.txt',
        'test_file3.txt',
        ]

    lookup = LookupModule()
    result = lookup.run(terms)

    assert len(result) == 3
    assert result[0].strip() == 'test_file1'
    assert result[1].strip() == 'test_file2'
    assert result[2].strip() == 'test_file3'

# Generated at 2022-06-21 06:01:46.593876
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    ####################################################
    # pylint: disable=unused-argument
    class MockDisplay():
        def __init__(self):
            self.error = ''
            self.warn = ''
            self.vvv = ''

        def display(self, msg, color=None):
            self.error = msg
        def debug(self, msg, host=None):
            self.warn = msg
        def vvvv(self, msg):
            self.vvv = msg

    class MockVarsModule():
        def __init__(self):
            self.vars = {}
        def get_vars(self, play, host, task, include_delegate_to=True):
            return self.vars
        def get_vars_for_scope(self, scope):
            if 'task' in scope:
                return

# Generated at 2022-06-21 06:01:53.013662
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    terms = '/path/to/foo.txt'
    variables = {}
    kwargs = {'lstrip': False, 'rstrip': False}
    result = lookup_module.run(terms, variables, **kwargs)

    assert result is not None

# Generated at 2022-06-21 06:01:54.729002
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert isinstance(LookupModule(), LookupModule)

# Generated at 2022-06-21 06:01:56.672838
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert isinstance(module, LookupModule)

# Generated at 2022-06-21 06:02:00.471802
# Unit test for constructor of class LookupModule
def test_LookupModule():
    x = LookupModule()
    assert isinstance(x, LookupModule)
    assert x.run(["test.txt"]) == []