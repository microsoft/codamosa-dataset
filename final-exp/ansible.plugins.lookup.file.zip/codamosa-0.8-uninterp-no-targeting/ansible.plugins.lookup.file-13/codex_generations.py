

# Generated at 2022-06-21 05:53:18.703622
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    path = '/path/to/file.txt'
    path_list = ['/path/to/file.txt','/path/to/file.txt']

    #  Testing with valid input data
    result = module.run( terms=[path], rstrip=True, lstrip=False )
    #  Read the content of the file and compare if both are equal
    assert result == [open(path, 'r').read()]

    # Testing with invalid input data
    result = module.run( terms=path_list, rstrip=True, lstrip=False )
    # result should be an empty list
    assert result == []

# Generated at 2022-06-21 05:53:27.494865
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    """
    Simple unit test for method 'run' of class LookupModule.
    """
    lookup = LookupModule()

    # Test already existing file.
    contents = lookup.run(terms=['/bin/ls'])
    assert contents[0].startswith('#!/bin/bash')

    # Test non-existing file.
    contents = lookup.run(terms=['/bin/__should_not_exist__'])
    assert contents[0] == ''

# Generated at 2022-06-21 05:53:38.978704
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    print("")
    print("Test with default options")
    lm = LookupModule()
    ret = lm.run(terms=["file_example.txt"], variables= dict())
    print(ret)

    print("")
    print("Test with lstrip option")
    lm = LookupModule()
    ret = lm.run(terms=["file_example.txt"], variables= dict(), lstrip=True)
    print(ret)

    print("")
    print("Test with rstrip option")
    lm = LookupModule()
    ret = lm.run(terms=["file_example.txt"], variables= dict(), rstrip=True)
    print(ret)


# Generated at 2022-06-21 05:53:45.211764
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    l = LookupModule()
    
    data = l.run(['/path/to/file.txt', 'file2.txt'], variables={'/path/to/file.txt': 'displayed content'})
    
    assert data == ["displayed content",'displayed content'], data


# Generated at 2022-06-21 05:53:47.081378
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert( isinstance( LookupModule(), LookupModule) )

# Generated at 2022-06-21 05:53:49.055020
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()



# Generated at 2022-06-21 05:54:01.221150
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    modules_path = os.path.join(os.path.dirname(__file__), '..', '..')
    if os.path.isdir(modules_path):
        sys.path.insert(0, modules_path)

    # load the module and its dependencies
    mock_module = imp.load_source('ansible.module_utils.basic', 'lib/ansible/module_utils/basic.py')

    # Test that errors occur with invalid file names
    print('Test that errors occur with invalid file names')
    terms = ["alice", "bob", "charlie"]
    display_stub = imp.load_source('ansible.utils.display', 'lib/ansible/utils/display.py')
    display_stub.Display.debug = lambda s, m: print("DEBUG: " + m)

   

# Generated at 2022-06-21 05:54:05.041796
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    # Test no values
    assert lookup_module.run([], {}) == []


# Generated at 2022-06-21 05:54:12.435166
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    contents = """
    yum:
        name: git
    """
    assert LookupModule.run({0: "test_file"}, {"foo": "bar"}, rstrip=False, lstrip=False) == ["foo"]
    assert LookupModule.run({0: "test_file"}, {"spaces": "  foo  "}, rstrip=True, lstrip=True) == ["foo"]
    assert LookupModule.run({0: "test_file"}, {"spaces": "  foo  "}, rstrip=True, lstrip=False) == ["  foo"]
    assert LookupModule.run({0: "test_file"}, {"spaces": "  foo  "}, rstrip=False, lstrip=True) == ["foo  "]

# Generated at 2022-06-21 05:54:21.983436
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    display = Display()
    display.verbosity = 4
    import os.path

    # Create sample files
    s = "HI, I'm a sample file."
    with open('/tmp/test_file', 'w') as f:
        f.write(s)
    with open('/tmp/test_file_not_found', 'w') as f:
        f.write(s)

    # Test with existing file
    # Calling run
    lookup_file = LookupModule()
    lookup_file.set_options(direct={'lstrip': False, 'rstrip': False})
    s_returned = lookup_file.run(['/tmp/test_file'], {'files': '/tmp'})
    assert s_returned[0] == s, "returned string is not the expected one"

    # Test with unex

# Generated at 2022-06-21 05:54:35.534947
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()

    mod.set_options(var_options=None, direct={})

    mod.find_file_in_search_path = lambda x, y, z: "./found_file.txt"

    # it is not possible to mock a _loader object with the necessary methods, so we use stubs
    def _loader_get_file_contents(filename):
        if filename == u"./found_file.txt":
            return (to_text(u"hello world", errors='surrogate_or_strict'), u"")
        else:
            raise AnsibleParserError()

    mod._loader = type('_loader', (), {'_get_file_contents': _loader_get_file_contents})

    ret = mod.run(['fake_file', 'fake_file2'])

# Generated at 2022-06-21 05:54:36.553127
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert lookup

# Generated at 2022-06-21 05:54:41.807507
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.set_options({'lstrip': False, 'rstrip': True})
    contents = lookup.run(['/etc/passwd'])
    assert(contents is not None)

# Generated at 2022-06-21 05:54:45.095044
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert issubclass(LookupModule, LookupBase)

# Generated at 2022-06-21 05:54:45.902415
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:54:47.533717
# Unit test for constructor of class LookupModule
def test_LookupModule():
    myLookupModule = LookupModule()
    return


# Generated at 2022-06-21 05:54:51.023270
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)
    assert isinstance(lookup, LookupBase)

# Generated at 2022-06-21 05:54:51.937360
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert False

# Generated at 2022-06-21 05:54:55.616987
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Test if object is created as expected
    lookup = LookupModule()

    # Test that object is of correct type
    assert isinstance(lookup, LookupModule)



# Generated at 2022-06-21 05:54:56.706614
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # run: not tested with unit test
    pass

# Generated at 2022-06-21 05:55:03.247493
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    print("Testing LookupModule.run")
    pass

# Generated at 2022-06-21 05:55:09.725405
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lm = LookupModule()
    terms = ['list_of_strings', 'another_list_of_strings']
    r1 = lm.run(terms, variables={})
    r2 = lm.run(terms, variables={})
    for x in r1:
        r2.remove(x)
    if r2 != []:
        raise AssertionError("Results for the same terms are not equal")

    lm = LookupModule()
    terms = ['list_of_strings', 'another_list_of_strings']
    variables = {'foo':'foo'}
    r1 = lm.run(terms, variables)
    r2 = lm.run(terms, variables)
    for x in r1:
        r2.remove(x)
    if r2 != []:
        raise Assert

# Generated at 2022-06-21 05:55:15.734713
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Generate a dummy test class
    class DummyClass(object):
        class DummyLoader(object):
            class DummyVars(dict):
                pass
            class DummyVarsOptions(object):
                pass
            class DummyTemplateVars(object):
                pass
            _templar = DummyTemplateVars()
            def get_basedir(self, terms):
                if terms[0] == 't1':
                    return '/path/to/my/file'

        _vars_cache = {}
        _vars_cache_lock = None
        _inventory = None

        class DummyOptions(object):
            connection = ''
            module_path = '.'
            forks = 10
            become = False
            become_method = ''
            become_user = ''
            check = False
            diff = False


# Generated at 2022-06-21 05:55:19.226247
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert isinstance(lm, LookupBase)
    # LookupLoader is a subclass of DataLoader, which is an Iterator.
    assert isinstance(lm._loader, LookupLoader)

# Test loading of the raw file value without any manipulation

# Generated at 2022-06-21 05:55:29.697431
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Create a mock api object
    class MockAPI:

        def __init__(self):
            self.display = Display()

        def __getattr__(self, name):
            return None

        def __call__(self, *args, **kwargs):
            pass

    api = MockAPI()

    # Create an instance of the class LookupModule
    lookup_module = LookupModule()

    # Create a mock variable manager
    class MockVariableManager:

        def __init__(self):
            self.variables = { }

        def get_vars(self, loader=None, play=None, task=None, include_hostvars=True, include_delegate_to=True):
            return self.variables

    variable_manager = MockVariableManager()

    # Create a mock loader

# Generated at 2022-06-21 05:55:30.496280
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    pass

# Generated at 2022-06-21 05:55:32.690295
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()
    assert 'rstrip' in lookup_module.options

# Generated at 2022-06-21 05:55:34.942919
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #TODO: test lookup, if possible

# Generated at 2022-06-21 05:55:35.906173
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()

# Generated at 2022-06-21 05:55:36.960178
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup = LookupModule()
    assert isinstance(lookup, LookupModule)

# Generated at 2022-06-21 05:55:50.264556
# Unit test for constructor of class LookupModule
def test_LookupModule():
    # Constructor of class LookupModule with valid arguments
    assert LookupModule()

# Generated at 2022-06-21 05:55:55.055935
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    lookup.find_file_in_search_path = lambda x,y,z: z
    lookup._loader = lambda: None
    lookup._loader._get_file_contents = lambda x: ('contents', 'show_data')
    assert lookup.run(['foo']) == ['contents']

# Generated at 2022-06-21 05:55:56.732333
# Unit test for constructor of class LookupModule
def test_LookupModule():
    #lm = LookupModule()
    #assert lm is not None
    pass

# Generated at 2022-06-21 05:56:09.357690
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    mod = LookupModule()
    mod.set_options(direct={'rstrip': False})
    mod._loader = DictDataLoader({
        '/etc/foo.txt': b'foo',
        '/etc/bar.txt': b'bar\n',
        '/etc/baz.txt': b'baz\n',
    })

    r = mod.run([
        '/etc/foo.txt',
        '/etc/bar.txt',
        '/etc/baz.txt',
    ])
    assert r == ["foo", "bar\n", "baz\n"]
    r = mod.run([
        '/etc/foo.txt',
        '/etc/bar.txt',
        '/etc/baz.txt',
    ], rstrip=True)
    assert r == ["foo", "bar", "baz"]

# Generated at 2022-06-21 05:56:17.869677
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Generate a LookupModule object with a mocked find_file_in_search_path method
    find_file_in_search_path = lambda a, b, c: "path/"+c
    lookup_module = LookupModule()
    lookup_module.find_file_in_search_path = find_file_in_search_path

    # Generate a mocked _loader object and inject it in lookup_module
    loader = Mock()
    loader.construct_mock({"_get_file_contents": lambda a: ("content", "show_data")})
    lookup_module._loader = loader

    # Test with no option
    result = lookup_module.run(["bar.txt"])
    assert result == ["content"]

    # Test with rstrip option
    lookup_module.rstrip = True
    result = lookup_module

# Generated at 2022-06-21 05:56:19.962479
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l,LookupModule)

# Generated at 2022-06-21 05:56:21.553046
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert(LookupModule)

# Generated at 2022-06-21 05:56:28.335084
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    terms = [ '/etc/passwd', 'test_file.txt' ]
    lookup_fail = ['test_file.txt']
    module = LookupModule()
    try:
        ret = module.run(terms, variables=None, **{})
        if ret == lookup_fail:
            raise UnitTestError('unit test failed')
    except Exception as e:
        raise UnitTestError('unit test failed with exception: {}'.format(repr(e)))


# Generated at 2022-06-21 05:56:31.078288
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin.get_option('rstrip')

# Generated at 2022-06-21 05:56:33.075111
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_plugin = LookupModule()
    assert lookup_plugin

# Generated at 2022-06-21 05:56:57.612164
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup1 = LookupModule()
    # Unit test of constructor of class LookupModule
    return

# Generated at 2022-06-21 05:56:58.712824
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert isinstance(l, LookupModule)

# Generated at 2022-06-21 05:57:09.298406
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import io
    import re
    import textwrap
    import os
    import sys
    import sys
    import shutil
    import tempfile
    import json
    import unittest

    from ansible.compat.tests import mock

    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    from ansible.parsing.vault import VaultLib
    from ansible.parsing.vault import VaultEditor

    from ansible.plugins.loader import lookup_loader
    from ansible.plugins.loader import action_loader
    from ansible.plugins.loader import filter_loader
    from ansible.plugins.lookup import LookupBase

    # Create a lookup mock class
    class TestLookupModule(LookupModule):

        def __init__(self):
            pass

       

# Generated at 2022-06-21 05:57:13.586951
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    terms = [
        "foo.txt"
    ]

    options = {
        "lstrip": True,
        "rstrip": False
    }

    opts = {}

    # See what happens without any options
    assert module.run(terms, variables=None, **opts) == [u"contents of foo.txt"]
    assert module.run(terms, variables=None, **opts) == [u"contents of foo.txt"]

    # See what happens with an option
    assert module.run(terms, variables=None, **options) == [u"contents of foo.txt "]
    assert module.run(terms, variables=None, **options) == [u"contents of foo.txt "]

    # See what happens with a second option

# Generated at 2022-06-21 05:57:20.309136
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Dummy content for file.txt
    dummy_content = '{"key": "value"}'

    # Dummy directory for lookup
    dummy_directory = "dummy"
    module_name = "file"
    lookup_mock = LookupModule()

    # Dummy path for lookup
    dummy_file = "file.txt"

    # Lookup file
    result = lookup_mock.run(terms=[dummy_file], variables={"path": [dummy_directory]}, **{"_raw_params": module_name})

    # Check that result is a list
    assert isinstance(result, list)

    # Check that result is not empty
    assert result

    # Check that result is equal to dummy_content
    assert result[0] == dummy_content

# Generated at 2022-06-21 05:57:22.222641
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert type(lm) == LookupModule

# Generated at 2022-06-21 05:57:24.930676
# Unit test for constructor of class LookupModule
def test_LookupModule():
    print("Testing LookupModule")
    # String
    assert LookupModule() is not None

# Generated at 2022-06-21 05:57:31.890782
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup = LookupModule()
    #  return_val = lookup._loader._get_file_contents(file_name)
    #  return_val[1] = True

    #  def return_file_contents(file_name):
    #  return_val = lookup._loader._get_file_contents(file_name)
    #  return_val[1] = True
    #  return lookup._loader._get_file_contents(file_name)

    return_val = ['1', '2', '3', '4']

    #  lookup._loader.get_file_contents = return_file_contents
    lookup._loader.get_file_contents = lambda x: (''.join(return_val), True)

    #  lookup._loader.get_file_contents = return_file_contents

# Generated at 2022-06-21 05:57:34.894548
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()

    assert module is not None, 'LookupModule object is not initialized.' 


# Generated at 2022-06-21 05:57:36.684493
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lm = LookupModule()
    assert lm is not None

# Generated at 2022-06-21 05:58:32.386859
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Unit Tests
    # Create an instance of LookupModule
    import os
    test = LookupModule()
    test.set_options(direct={'lstrip': False, 'rstrip': False})
    # Create a temporary file to use for testing
    testdir = os.path.dirname(os.path.realpath(__file__))
    testfile = os.path.join(testdir,"testfile.txt")
    f = open(testfile,"w")
    f.write("testing")
    f.close()
    # Test
    assert test.run(['testfile.txt']) == ['testing']
    # Cleanup
    os.unlink(testfile)


# Generated at 2022-06-21 05:58:33.695210
# Unit test for constructor of class LookupModule
def test_LookupModule():
    l = LookupModule()
    assert l != None

# Generated at 2022-06-21 05:58:43.216333
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # When lstrip and rstrip options are set, trailing and leading spaces are removed.
    # When lstrip and rstrip options are not set, they are not removed.
    lookup_instance = LookupModule()
    lookup_instance.set_options(direct={'rstrip': True, 'lstrip': True})
    lookup_instance.set_options(direct={'rstrip': False, 'lstrip': False})

    # When the file is found in 'files' directory, the contents of the file is returned
    # When the file is not found in 'files' directory, AnsibleError is raised
    # When the file is found but the contain is not valid YAML, AnsibleError is raised

    # parameters for a file that is found and contains valid YAML

# Generated at 2022-06-21 05:58:53.613040
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # Preparation
    class TestLookupModule(LookupModule):
        def __init__(self, *args, **kwargs):
            super(TestLookupModule, self).__init__(*args, **kwargs)
            self._loader = DummyClass()

    class DummyClass(object):
        def find_file_in_search_path(self, variables, directory, filename):
            return filename

        def _get_file_contents(self, filename):
            contents = ["a", "b", "c"]
            return contents, False


    class DummyAnsibleError(object):
        def __init__(self, message):
            self.message = message

    class DummyAnsibleParserError(DummyAnsibleError):
        pass


    test_lookup_module = TestLookupModule()


# Generated at 2022-06-21 05:58:55.384918
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert hasattr(LookupModule, "run")

# Generated at 2022-06-21 05:59:02.279436
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    # Import modules that are needed
    import os
    import tempfile

    # Create temporary file which will be read in LookupModule.run
    fd, temp_file = tempfile.mkstemp()
    os.close(fd)

    # Create an instance of the LookupModule class
    lookup_plugin = LookupModule()

    # Call run with temporary file
    lookup_plugin.run([temp_file])

    # Test if file was read and the content was returned
    assert lookup_plugin.run([temp_file]) == [""]

# Generated at 2022-06-21 05:59:13.449073
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    output = []
    # testing list of files
    test_list_of_file = dict(
        _terms = ['/tmp/does_not_exist', '/tmp/test_file'],
        rstrip = True,
        lstrip = False
    )
    lookup_module = LookupModule()
    lookup_module.run = MagicMock(side_effect = lambda _terms, variables = None, **kwargs : ['test_file'])
    lookup_module.find_file_in_search_path = MagicMock(side_effect = lambda variables, search_path, term : '/tmp/test_file' if term == '/tmp/test_file' else None)
    results = lookup_module.run(**test_list_of_file)

# Generated at 2022-06-21 05:59:14.237347
# Unit test for constructor of class LookupModule
def test_LookupModule():

    foo = LookupModule()
    print ( foo )


# Generated at 2022-06-21 05:59:24.864633
# Unit test for method run of class LookupModule
def test_LookupModule_run():

    import os
    import tempfile
    from ansible.plugins.lookup.file import LookupModule
    from ansible.module_utils._text import to_native

    def create_file(content):
        fd, path = tempfile.mkstemp()
        with os.fdopen(fd, 'w') as f:
            f.write(content)
        return path

    # Create a lookupmodule that can be used

    lookupmodule = LookupModule()
    lookupmodule.set_loader(None)

    # Create a temp file that can be looked up

    tmpfile = create_file('these are some contents\n')

    # Create a temporary search path with the temp file

    searchpath = ['.']

# Generated at 2022-06-21 05:59:27.210236
# Unit test for constructor of class LookupModule
def test_LookupModule():
        # Test object creation
        lookup_module = LookupModule()
        assert lookup_module


# Generated at 2022-06-21 06:01:07.469146
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    test_obj = LookupModule()
    test_terms = ["test1","test2"]
    test_variables = {"test_var1":"value1","test_var2":"value2"}
    test_kwargs = {"test_kwarg1":"value3","test_kwarg2":"value4"}
    test_obj.run(test_terms,test_variables,**test_kwargs)

# Generated at 2022-06-21 06:01:08.287124
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    assert 1 == 1

# Generated at 2022-06-21 06:01:09.735579
# Unit test for constructor of class LookupModule
def test_LookupModule():
    pass

# Generated at 2022-06-21 06:01:18.614605
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    lookup_module = LookupModule()
    lookup_module._loader = DictDataLoader({'/etc/foo.txt': 'Hello world'})
    lookup_module._templar = DummyTemplar()
    
    assert lookup_module.run(['/etc/foo.txt'], None) == ['Hello world']
    assert lookup_module.run(['/etc/foo.txt'], None, lstrip=True) == ['Hello world']
    assert lookup_module.run(['/etc/foo.txt'], None, rstrip=True) == ['Hello world']
    assert lookup_module.run(['/etc/foo.txt'], None, lstrip=True, rstrip=True) == ['Hello world']
    assert lookup_module.run(['/etc/bar.txt']) == []


# Generated at 2022-06-21 06:01:26.953459
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    # set args
    args = ['/home/bar.txt']
    
    kargs = {}
    kargs['mydict'] = {'foo': 'bar'}
    kargs['you'] = 'you'
    
    # set up the lookup module
    lookup = LookupModule()
    
    # set options
    lookup.set_options(direct=kargs)
    
    # perform the lookup
    response = lookup.run(terms=args,
                          variables='test',
                          mydict=kargs)
    
    # perform tests
    # assert response[0] is not None
    print(response[0])

# Generated at 2022-06-21 06:01:27.745675
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule

# Generated at 2022-06-21 06:01:30.845182
# Unit test for constructor of class LookupModule
def test_LookupModule():
    module = LookupModule()
    assert len(str(LookupModule)) > 0
    assert len(str(module)) > 0

# Generated at 2022-06-21 06:01:36.976861
# Unit test for method run of class LookupModule
def test_LookupModule_run():
    module = LookupModule()
    contents = to_text(b"Hello World!")
    assert module.run(["test.txt"], dict(), variables=dict(), **{"_fqpn": "test.txt"}) == [contents]
    assert module.run(["test.txt"], dict(), **{"_fqpn": "test.txt"}) == [contents]
    assert module.run(["test.txt"], dict(), **{"_fqpn": "test.txt", "lstrip": True}) == [contents.lstrip()]
    assert module.run(["test.txt"], dict(), **{"_fqpn": "test.txt", "rstrip": True}) == [contents.rstrip()]

# Generated at 2022-06-21 06:01:37.368379
# Unit test for constructor of class LookupModule
def test_LookupModule():
    assert LookupModule()

# Generated at 2022-06-21 06:01:41.063289
# Unit test for constructor of class LookupModule
def test_LookupModule():
    lookup_module = LookupModule()

    # Check the default
    assert lookup_module.get_option('lstrip') is False
    assert lookup_module.get_option('rstrip') is True

    # Check set_options()
    assert lookup_module.set_options(True, False, False) is None
    assert lookup_module.get_option('lstrip') is True
    assert lookup_module.get_option('rstrip') is False
    assert lookup_module.set_options(direct={'lstrip': False, 'rstrip': True}) is None
    assert lookup_module.get_option('lstrip') is False
    assert lookup_module.get_option('rstrip') is True