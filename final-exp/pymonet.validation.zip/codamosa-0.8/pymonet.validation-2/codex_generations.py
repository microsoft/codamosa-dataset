

# Generated at 2022-06-12 05:48:43.890924
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Try to compare two Validations. Validation should be equal only when values and errors are equal.
    """
    validation_1 = Validation.success(1)
    validation_2 = Validation.success(1)
    assert validation_1 == validation_2

    validation_3 = Validation.success(2)
    assert validation_1 != validation_3

    validation_4 = Validation.fail([])
    validation_5 = Validation.fail([])
    assert validation_4 == validation_5

    validation_6 = Validation.fail(['error'])
    assert validation_4 != validation_6


# Generated at 2022-06-12 05:48:52.393848
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.validation import Validation

    assert Validation.success() == Validation.success()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.success(1) != Validation.fail([])
    assert Validation.fail([1, 2]) == Validation.fail([1, 2])
    assert Validation.fail([1, 2]) != Validation.success([1, 2])


# Generated at 2022-06-12 05:49:00.289692
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert not Validation.success(1) == Validation.success(2)
    assert not Validation.success(1) == Validation.fail()
    assert Validation.fail(['1']) == Validation.fail(['1'])
    assert not Validation.fail(['1']) == Validation.fail(['2'])
    assert not Validation.fail(['1']) == Validation.success()


# Generated at 2022-06-12 05:49:02.923151
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().eval() == 1
    assert Validation.fail().to_lazy().eval() is None


# Generated at 2022-06-12 05:49:08.240239
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_validation = Validation.success(2)
    lz = success_validation.to_lazy()

    assert lz == Lazy(lambda: 2)

# Generated at 2022-06-12 05:49:18.173626
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation
    """
    from pymonet.either import Left, Right

    assert Validation.fail(['Error']) == Validation.fail(['Error'])
    assert Validation.fail(['Error']) != Validation.fail([])
    assert Validation.fail() == Validation.fail()
    assert Validation.fail() != Validation.success('Other')
    assert Validation.success('Other') == Validation.success('Other')
    assert Validation.success('Other') != Validation.success('Test')
    assert Validation.success('Other') != Left('Test')
    assert Validation.success('Other') != Right('Test')


# Generated at 2022-06-12 05:49:23.438137
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.fail(['error', 'error2'])


# Generated at 2022-06-12 05:49:32.789956
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Two Validations are equals when values and errors lists are equal.
    """
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, []) == Validation(1, [''])
    assert Validation(1, []) == Validation(1, [1, '', 2])
    assert Validation(1, [1]) == Validation(1, [1])
    assert Validation(1, [1, 2, 3]) == Validation(1, [1, 2, 3])
    assert Validation(1, ['']) == Validation(1, [1])
    assert Validation(1, ['', '']) == Val

# Generated at 2022-06-12 05:49:39.300127
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, [1, 2, 3]) == Validation(1, [1, 2, 3])
    assert Validation(1, []) != Validation(1, 2)
    assert Validation(1, []) != Validation(2, 1)
    assert Validation(1, []) != Validation('', [])
    assert Validation(1, []) != Validation(1, [1])
    assert Validation(1, [1]) != Validation('', [])


# Generated at 2022-06-12 05:49:44.639617
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    valid = Validation.success(5)
    invalid = Validation.fail(['Bad input'])

    lazy_valid = Lazy(lambda: 5)
    lazy_invalid = Lazy(lambda: None)

    # Act & Assert
    assert valid.to_lazy() == lazy_valid
    assert invalid.to_lazy() == lazy_invalid


# Generated at 2022-06-12 05:49:50.690875
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def unit_test():
        validation = Validation.success(3)
        assert validation.to_lazy() == Lazy(lambda: 3)

    unit_test()


# Generated at 2022-06-12 05:49:56.191499
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:50:00.837682
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    value = 5
    assert Validation.success(value).to_lazy() == Lazy(lambda: value)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:06.031601
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['test']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:11.861174
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_func():
        return 'lazy value'

    assert Validation.success('lazy value').to_lazy() == Lazy(lazy_func)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:14.946041
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(42).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.get() == 42


# Generated at 2022-06-12 05:50:20.333851
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    x = Validation.success(2)
    assert isinstance(x.to_lazy(), Lazy)
    assert x.to_lazy().evaluate() is 2
    y = Validation.fail(['error'])
    assert isinstance(y.to_lazy(), Lazy)
    assert y.to_lazy().evaluate() is None


# Generated at 2022-06-12 05:50:26.135114
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 9).equals(Validation.success(9).to_lazy())
    assert Lazy(lambda: None).equals(Validation.fail([
        'Error 1',
        'Error 2'
    ]).to_lazy())



# Generated at 2022-06-12 05:50:28.580414
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(10)
    lazy = validation.to_lazy()
    assert lazy.get() == 10


# Generated at 2022-06-12 05:50:33.163128
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('value')
    assert validation.to_lazy() == Lazy(lambda: 'value')

    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:37.808663
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy().force() == 1
    assert Validation(1, []).to_lazy().value == 1


# Generated at 2022-06-12 05:50:46.757358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.functors import compose, filter_maybe

    lazy_func = compose(lambda: 2, lambda x: x + x, lambda x: 2 * x)
    validation = Validation.success(1)

    result = filter_maybe(validation.map(lambda x: Lazy(lazy_func).map(lambda y: x * y)).value.value)

    assert result == Lazy(lambda: lazy_func() * validation.value).value

# Generated at 2022-06-12 05:50:52.880449
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    # Show that to_lazy works correctly:
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)

    # Show that to_lazy is correctly implemented
    # Test that:
    # 1. Validation.to_lazy() == Lazy(lambda: Validation.to_optional().getOrElse(None))
    assert Validation.success(1).to_lazy() == Lazy(lambda: Validation.success(1).to_maybe().getOrElse(None))

    # 2. Validation.to_lazy().flatMap(lambda

# Generated at 2022-06-12 05:50:56.779476
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy
    from pymonet.monad_try import Try

    def foo():
        return Try.success(2 / 3)

    lazy = Validation.success(foo).to_lazy()
    assert lazy == Lazy(foo)


# Generated at 2022-06-12 05:51:03.014506
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success(10).to_lazy()
    assert isinstance(success, Lazy)
    assert success.__evaluate__() == 10

    fail = Validation.fail([100, 200]).to_lazy()
    assert isinstance(fail, Lazy)
    assert fail.__evaluate__() is None


# Generated at 2022-06-12 05:51:04.754890
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1


# Generated at 2022-06-12 05:51:16.169962
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """

    # Unit test for success Validation with number as boxed value
    validation_success_number = Validation(Box(10), [])
    val = validation_success_number.to_lazy().value()
    assert val == 10

    # Unit test for success Validation with string as boxed value
    validation_success_string = Validation(Box('test'), [])
    val = validation_success_string.to_lazy().value()
    assert val == 'test'

    # Unit test for success Validation with list as boxed value
    validation_success_list = Validation(Box([1, 2, 3]), [])
    val = validation_success_list.to_lazy().value()
    assert val == [1, 2, 3]

    # Unit test

# Generated at 2022-06-12 05:51:20.775799
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_success():
        v = Validation.success('a')
        l = v.to_lazy()
        assert l.get() == v.value

    def test_fail():
        v = Validation.fail()
        l = v.to_lazy()
        assert l.get() == v.value


# Generated at 2022-06-12 05:51:25.378728
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # success validation
    validation = Validation(42, [])
    assert validation.to_lazy() == Lazy(lambda: 42)

    # fail validation
    validation = Validation.fail([])
    assert validation.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:51:29.157902
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation."""

    test_value = 1

    lazy_val = Validation.success(test_value).to_lazy()

    assert lazy_val.evaluate() == 1


# Generated at 2022-06-12 05:51:34.783737
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(9).to_lazy() == Lazy(lambda: 9)
    assert Validation.fail(['Something wrong']).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:51:39.747898
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Success
    from pymonet.lazy import Lazy

    validation = Validation.success(Success('result'))
    lazy_val = validation.to_lazy()
    assert lazy_val.value().value == 'result'
    assert isinstance(lazy_val, Lazy)


# Generated at 2022-06-12 05:51:45.811088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests if to_lazy is working properly.
    """
    # Testing with errors
    validation = Validation.fail(['error'])
    try_lazy_monad = validation.to_lazy()
    assert try_lazy_monad.value == None
    assert try_lazy_monad.errors == ['error']
    assert try_lazy_monad.is_success() == False

    # Testing with value
    validation = Validation.success(100)
    try_lazy_monad = validation.to_lazy()
    assert try_lazy_monad.value == 100
    assert try_lazy_monad.errors == []
    assert try_lazy_monad.is_success() == True



# Generated at 2022-06-12 05:51:49.479080
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(1).to_lazy()
    assert lazy.get() == 1

    lazy = Validation.fail([2]).to_lazy()
    assert lazy.get() is None



# Generated at 2022-06-12 05:51:56.965039
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_fun():
        return 'Hello!'

    success_validation = Validation.success(lazy_fun)
    fail_validation = Validation.fail(['Error1', 'Error2'])

    assert success_validation.to_lazy() == Lazy(lazy_fun)
    assert fail_validation.to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:52:00.883472
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:09.238397
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    This test checking correctness of method Validation.to_lazy

    :returns: True for successful test
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def mapper():
        return Validation.success(1)

    val = Validation.success(2)

    assert val.to_lazy() == Lazy(lambda: 2)
    assert val.to_lazy().value() == 2
    assert val.map(mapper).to_lazy().value().value == 1

    def mapper2():
        return Validation.fail(['test'])

    val2 = Validation.fail(['test2'])

    assert val2.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:52:17.237152
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(10).to_lazy() == Lazy(lambda: None)
    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.fail(10).to_try() == Try(None, is_success=False)

# Generated at 2022-06-12 05:52:22.445589
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def success_lazy():
        return 'lazy'

    def fail_lazy():
        raise Exception('LazyException')

    assert Validation.success('success').to_lazy() == Lazy(success_lazy)
    assert Validation.fail('fail').to_lazy() == Lazy(fail_lazy)


# Generated at 2022-06-12 05:52:28.174398
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation

    :returns: True when unit test passed
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation(1, [])
    assert validation.to_lazy() == Lazy(1)

# Generated at 2022-06-12 05:52:33.825785
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    actual_result = Validation.success(10).to_lazy()
    expected_result = Lazy(lambda: 10)

    assert actual_result == expected_result



# Generated at 2022-06-12 05:52:37.409568
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail(['m']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:43.648286
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure

    success_value = 1
    success_validation = Validation.success(success_value)
    assert success_validation.to_lazy() == Lazy(lambda: success_value)

    error_value = [ValueError('error')]
    error_validation = Validation.fail(error_value)
    assert error_validation.to_lazy() == Lazy(lambda: error_value)


# Generated at 2022-06-12 05:52:50.284913
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_func():
        return 'success'

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(test_func).to_lazy() == Lazy(lambda: test_func)

# Generated at 2022-06-12 05:52:54.653598
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success([1,2,3]).to_lazy() == Lazy(lambda: [1,2,3])
    assert Validation.fail([1,2,3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:58.067463
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:02.178047
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation method to_lazy
    """
    assert Validation.success().to_lazy().value() is None
    assert Validation.success(5).to_lazy().value() == 5


# Generated at 2022-06-12 05:53:09.385593
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert(Validation.success(10).to_lazy() == Lazy(lambda: 10))
    assert(Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-12 05:53:12.367351
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    lazy_monad = Validation.success(1).to_lazy()
    assert 1 == lazy_monad.value()



# Generated at 2022-06-12 05:53:17.789922
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def test_function():
        return "hello lazy"

    lazy = Lazy(test_function)
    validation = Validation.success(lazy)

    assert validation.to_lazy().run()() == lazy.run()()

# Generated at 2022-06-12 05:53:25.900380
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Test with success Validation

    success_validation = Validation.success(1)
    assert success_validation.to_lazy() == Lazy(lambda: 1)

    # Test with fail Validation

    fail_validation = Validation.fail([1, 2])
    assert fail_validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:30.882325
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    import random

    def producer():
        return random.randint(1, 100)

    monad = Validation.success(producer())
    assert monad.to_lazy() == Lazy(producer)


# Generated at 2022-06-12 05:53:39.390945
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation

    .. code-block:: python

        def test_Validation_to_lazy():
            value = Validation.success('john')
            assert value.to_lazy() == Lazy(lambda: value.value)

            assert Validation.fail('error').to_lazy() == Lazy(lambda: None)
    """
    value = Validation.success('john')
    assert value.to_lazy() == Lazy(lambda: value.value)

    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:43.136011
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    b = Box('a')
    l = b.to_lazy()
    assert isinstance(l, Lazy) and l == Lazy(lambda: 'a')


# Generated at 2022-06-12 05:53:48.317999
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    assert validation.to_lazy().value == 1

    validation = Validation.success(None)
    assert validation.to_lazy().value is None

    validation = Validation.fail()
    try:
        validation.to_lazy().value
    except Exception as e:
        assert e.__class__ == Exception



# Generated at 2022-06-12 05:53:54.727315
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.functools import identity, constant

    validation = Validation.success(Lazy(identity)).to_lazy()

    assert validation.value() == Lazy(identity)

    validation = Validation.fail(['error']).to_lazy()

    assert validation.value() is None


# Generated at 2022-06-12 05:53:59.063930
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover

    def inner_sum(x):
        return x + 1

    def outer_sum(x):
        return x + inner_sum(x)

    validation = Validation.success(1).to_lazy().value().map(outer_sum)

    assert validation == Validation(3, [])

# Generated at 2022-06-12 05:54:01.653852
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def f():
        return 1

    v = Validation.success(1)
    l = v.to_lazy()

    assert l == Lazy.defer(f)

# Generated at 2022-06-12 05:54:05.516274
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover

    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation.fail(["error"])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:07.612365
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    lazy = Lazy(lambda: Validation.success('test'))
    assert lazy.value() == Validation.success('test')



# Generated at 2022-06-12 05:54:13.941200
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy().get() == 10
    assert Validation.fail().to_lazy().get() == None

# Generated at 2022-06-12 05:54:18.040220
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # when
    lazy = Validation.success(10).to_lazy()

    # then
    assert lazy.get() == 10
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:54:24.869480
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from operator import add
    from pymonet.lazy import Lazy
    from pymonet.functional import curry

    @curry
    def validate_length(length, string):
        from pymonet.validation import Validation

        if len(string) == length:
            return Validation.success(string)
        return Validation.fail([])

    lazy_value = validate_length(3)("Hello").to_lazy().map(len).map(add(1)).value()
    assert lazy_value == 6

# Generated at 2022-06-12 05:54:31.883628
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v1 = Validation.success(123)
    v2 = Validation.fail(['Error 1', 'Error 2'])
    assert v1.to_lazy().eval() == 123
    assert v2.to_lazy().eval() is None
    assert v1.to_lazy() == Lazy(lambda: 123)
    assert v2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:35.349434
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:45.429359
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)
    assert Validation.success([]).to_lazy() == Lazy(lambda: [])
    assert Validation.success([1]).to_lazy() == Lazy(lambda: [1])
    assert Validation.success([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Validation.success({1: 2}).to_lazy() == Lazy(lambda: {1: 2})
    assert Validation.success({}).to

# Generated at 2022-06-12 05:54:50.890122
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(lambda: 'success').to_lazy() == Lazy(lambda: 'success')
    assert Validation.fail(['fail']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:54:57.606053
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    validation = Validation.success('value')

    lazy_from_validation = validation.to_lazy()
    assert type(lazy_from_validation) == Lazy
    assert lazy_from_validation.invoke() == 'value'

    validation = Validation.fail([])

    lazy_from_validation = validation.to_lazy()
    assert type(lazy_from_validation) == Lazy
    assert lazy_from_validation.invoke() is None

# Generated at 2022-06-12 05:55:01.192887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(12).to_lazy() == Lazy(lambda: 12)
    assert Validation.fail([12]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:05.899170
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)
    assert lazy == Validation.success(1).to_lazy()
    assert lazy == Validation.success(lambda: 1).to_maybe().bind(Validation.success).to_lazy()


# Generated at 2022-06-12 05:55:20.461649
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    test_list = []
    def func():
        test_list.append(1)
        return 1
    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.evaluate() == 1
    assert test_list == [1]


# Generated at 2022-06-12 05:55:24.796683
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:29.983894
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    laz = Validation.success('value').to_lazy()
    assert isinstance(laz, Lazy)
    assert callable(laz.value)
    assert laz.value() == 'value'



# Generated at 2022-06-12 05:55:33.398243
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for to_lazy method of class Validation"""
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:55:36.317991
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert_that(Validation.success(5).to_lazy().evaluate(), is_(5))
    assert_that(Validation.success(None).to_lazy().evaluate(), is_(None))
    assert_that(Validation.fail(['one', 'two']).to_lazy().evaluate(), is_(None))


# Generated at 2022-06-12 05:55:41.654484
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.functools import partial

    assert Validation.success(5).to_lazy() == Lazy(partial(Validation.success, 5))
    assert Validation.fail(5).to_lazy() == Lazy(partial(Validation.fail, 5))



# Generated at 2022-06-12 05:55:48.229659
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda : 2)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda : None)


# Generated at 2022-06-12 05:55:54.174361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """It test Validation.to_lazy method"""
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    validation = Validation(5, [])
    assert validation.to_lazy() == Lazy(lambda: 5)
    assert validation.to_lazy().value() == 5


# Generated at 2022-06-12 05:55:59.737022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.monad_try import Failure

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: Failure(['error']))



# Generated at 2022-06-12 05:56:03.301616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:19.584867
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(value=1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(errors=[1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:56:26.478204
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """ Unit test for method to_lazy of class Validation """
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Lazy(lambda: Validation.success(Box(1))).to_lazy().value().value.value == 1

# Generated at 2022-06-12 05:56:29.072480
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'foo'

    rv = Validation.success(f)
    assert rv.to_lazy() == Lazy(f)

# Generated at 2022-06-12 05:56:34.445369
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:39.236196
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:56:50.008668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from nose.tools import assert_equal
    from pymonet.lazy import Lazy

    # Success value is None
    validation = Validation.success()
    assert_equal(validation.to_lazy(), Lazy(lambda: None))

    # Success value is 1
    validation = Validation.success(1)
    assert_equal(validation.to_lazy(), Lazy(lambda: 1))

    # Fail value
    validation = Validation.fail(['error', 'error2'])
    assert_equal(validation.to_lazy(), Lazy(lambda: None))

    # Success value is 1
    validation = Validation.success(1)
    assert_equal(validation.to_lazy(), Lazy(lambda: 1))

    # Fail value

# Generated at 2022-06-12 05:56:55.191155
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def func():
        return "Value"

    assert Validation.success().to_lazy() == Lazy(func)

# Generated at 2022-06-12 05:57:04.807487
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for Validation.to_lazy method"""
    # pylint: disable=C0103
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # when: to_lazy is called on successful Validation with value
    validation = Validation.success(42)
    lazy = validation.to_lazy()

    # then: lazy is lazy evaluation wrapper around 42
    assert isinstance(lazy, Lazy)
    assert lazy() == 42

    # when: to_lazy is called on failed Validation with value
    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()

    # then: lazy is lazy evaluation wrapper around None
    assert isinstance(lazy, Lazy)
    assert lazy() is None


# Generated at 2022-06-12 05:57:07.742543
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monads import Lazy

    assert Validation.success(1).to_lazy() == Lazy.unit(1)
    assert Validation.fail([]).to_lazy() == Lazy.unit(None)


# Generated at 2022-06-12 05:57:11.912726
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success(1)
    assert val.to_lazy() == Lazy(lambda: 1)

    val = Validation.fail([1])
    assert val.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:30.223130
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy().run() == 0

# Generated at 2022-06-12 05:57:40.363344
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    import unittest
    from pymonet.lazy import Lazy

    class ValidationTest(unittest.TestCase):
        """
        Validation test suite
        """

        def test_to_lazy(self):
            """
            Test to_lazy
            """
            result = Validation.fail().to_lazy()
            self.assertTrue(isinstance(result, Lazy))
            self.assertIsNone(result.value())

            result = Validation.success('value').to_lazy()
            self.assertTrue(isinstance(result, Lazy))
            self.assertEqual(result.value(), 'value')

    unittest.main()


# Generated at 2022-06-12 05:57:45.911743
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    success_val = Validation.success('test1')
    assert success_val.to_lazy() == Lazy(lambda: 'test1')

    fail_val = Validation.success(Try.fail(ValueError('error')))
    assert fail_val.to_lazy() == Lazy(lambda: Try.fail(ValueError('error')))


# Generated at 2022-06-12 05:57:54.121243
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Testing method to_lazy of class Validation.

    Function should transforms Validation in Lazy monad.
    """
    from pymonet.lazy import Lazy

    success = Validation.success('text')
    fail = Validation.fail()

    def lazy_value():
        return success.value

    def lazy_fail():
        return fail.value

    assert success.to_lazy() == Lazy(lazy_value)
    assert fail.to_lazy() == Lazy(lazy_fail)


# Generated at 2022-06-12 05:57:57.048635
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    assert Validation("Test", []).to_lazy().run() is "Test"



# Generated at 2022-06-12 05:58:07.003717
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation class.
    """
    from pymonet.either import Left
    from pymonet.lazy import Lazy

    def counter():
        counter.count += 1
        return counter.count

    counter.count = 0

    lazy_one = Validation.success(1).to_lazy()
    lazy_two = Validation.success(2).to_lazy()
    lazy_three = Validation.success(3).to_lazy()
    lazy_four = Validation.success(4).to_lazy()
    lazy_fail = Validation.fail(['f1', 'f2']).to_lazy()

    lazy_one.bind(counter).bind(counter).bind(counter)

    assert lazy_one == Lazy(lambda: 1)
    assert lazy_

# Generated at 2022-06-12 05:58:11.126191
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(2, []).to_lazy() == Lazy(lambda: 2)
    assert Validation(None, [1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:15.493718
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_lazy import Lazy

    validation = Validation.success()

    assert Lazy(lambda: None) == validation.to_lazy()

    validation = Validation.success(12)

    assert Lazy(lambda: 12) == validation.to_lazy()


# Generated at 2022-06-12 05:58:18.125360
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy().get() == 10


# Generated at 2022-06-12 05:58:19.701860
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(10)
    assert result.to_lazy().get() == 10

