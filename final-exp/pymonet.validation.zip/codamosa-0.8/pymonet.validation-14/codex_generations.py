

# Generated at 2022-06-12 05:48:42.158970
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    assert Lazy(lambda: 1).to_lazy() == Lazy(lambda: 1)
    assert Monad.bind(Validation.success(1), lambda x: Lazy(x).to_lazy()).value == 1
    assert Monad.bind(Validation.fail([1]), lambda x: Lazy(x).to_lazy()).is_fail() is True


# Generated at 2022-06-12 05:48:46.857248
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['error 1']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(41).to_lazy() == Lazy(lambda: 41)



# Generated at 2022-06-12 05:48:49.915033
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(200, [])

    assert validation.to_lazy() == Lazy(lambda: 200)


# Generated at 2022-06-12 05:48:53.498934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    >>> from pymonet.validation import Validation
    >>> validation = Validation.success(12)
    >>> validation.to_lazy()
    <pymonet.lazy.Lazy object at 0x...>
    """
    pass


# Generated at 2022-06-12 05:48:59.366178
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def run_function(function):
        return function()

    def lazy_function():
        return "evaluated lazy function"

    lazy_creation = Lazy(lazy_function)
    assert run_function(lazy_creation.get) == "evaluated lazy function"


# Generated at 2022-06-12 05:49:05.183296
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_function():
        return "test"

    lazy_validation = Validation.success(test_function).to_lazy()

    assert lazy_validation.force() == test_function.__call__()



# Generated at 2022-06-12 05:49:08.904229
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    @Lazy
    def x():
        return 1

    assert Validation.success(x).to_lazy() == Lazy(lambda: x.value)
    assert Validation.fail(x).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:13.396500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success("value").to_lazy().value() == "value"
    assert Validation.fail("err").to_lazy().value() is None


# Generated at 2022-06-12 05:49:18.050358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:49:23.672981
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.box import Box

    assert(Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None))
    assert(Validation.success(1).to_lazy() == Lazy(lambda: 1))


# Generated at 2022-06-12 05:49:28.933441
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def return_int():
        return 42

    lazy_int = Lazy(return_int)

    assert Validation.fail(['x']).to_lazy() == lazy_int


# Generated at 2022-06-12 05:49:33.390340
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(5)
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value == 5
    assert lazy_monad.is_success() == True

    validation = Validation.fail([])
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value == None
    assert lazy_monad.is_success() == False


# Generated at 2022-06-12 05:49:34.669145
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(10).to_lazy()
    assert result == Lazy(lambda: 10)

# Generated at 2022-06-12 05:49:37.546529
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_lazy import Lazy

    result = Validation.success(1).to_lazy()
    assert result == Lazy(lambda: 1)



# Generated at 2022-06-12 05:49:40.787230
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Validation.fail(['error']).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.fn() is None

# Generated at 2022-06-12 05:49:43.925018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success('py-monet').to_lazy()

    assert isinstance(result, Lazy)
    assert result.value() == 'py-monet'


# Generated at 2022-06-12 05:49:48.438696
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test of method to_lazy of class Validation.
    """
    # Generate test data
    validation = Validation.success(value=100)

    # Test
    lazy = validation.to_lazy()

    # Assert
    assert lazy.force() == validation.value


# Generated at 2022-06-12 05:49:52.934254
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([0]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:56.609964
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:59.554658
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    result = Validation.success(1)
    assert result.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:50:08.127693
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    val = Validation(42, [])
    lazy = LambdaWrapper(Lazy(lambda: 42))
    lazy.memoize = lambda: LambdaWrapper(Lazy(lambda: 42))
    assert val.to_lazy() == lazy
    val = Validation(None, ["error"])
    assert val.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:50:12.575356
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    assert(Lazy(lambda: 'value') == Validation.success('value').to_lazy())


# Generated at 2022-06-12 05:50:16.973461
# Unit test for method to_lazy of class Validation

# Generated at 2022-06-12 05:50:22.514756
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from nose.tools import *
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Left, Right

    val = Validation.fail()
    assert_equal(val.to_lazy(), Lazy(lambda: None))

    val = Validation.success(1)
    assert_equal(val.to_lazy(), Lazy(lambda: 1))


# Generated at 2022-06-12 05:50:26.708671
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Given
    from pymonet.lazy import Lazy

    # When
    actual = Validation.success(1).to_lazy()

    # Then
    assert isinstance(actual, Lazy)
    assert actual.value() == 1


# Generated at 2022-06-12 05:50:29.144023
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')

# Generated at 2022-06-12 05:50:31.710684
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success('a')
    l = v.to_lazy()

    assert l() == v.value


# Generated at 2022-06-12 05:50:36.166387
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(3)
    assert validation.to_lazy() == Lazy(lambda: 3)

    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:48.350897
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    def f():
        return 1
    a = Validation.fail()
    assert a.to_lazy() == Lazy(lambda: None)
    assert a.to_lazy().to_try() == Try(None, is_success=False)
    assert a.to_lazy().to_try().to_lazy() == Lazy(lambda: None)
    assert a.to_lazy().to_try().to_lazy().to_maybe().to_lazy() == Lazy(lambda: None)
    b = Validation.success(4)
    assert b.to_lazy() == Lazy(lambda: 4)
    assert b.to_lazy().to_try() == Try(4)

# Generated at 2022-06-12 05:50:55.287144
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy

    lazy_success = Validation.success([1, 2, 3]).to_lazy()
    assert isinstance(lazy_success, Lazy)
    assert lazy_success.get() == [1, 2, 3]

    lazy_fail = Validation.fail(['1']).to_lazy()
    assert isinstance(lazy_fail, Lazy)
    assert lazy_fail.get() is None


# Generated at 2022-06-12 05:51:01.114562
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success(5)
    lazy = val.to_lazy()
    assert val == lazy.value()


# Generated at 2022-06-12 05:51:05.308761
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([10]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:10.824641
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:14.896918
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    value = 1
    validation = Validation.success(value)

    result = validation.to_lazy()

    assert isinstance(result, Lazy)
    assert result.force() == value

# Generated at 2022-06-12 05:51:16.985707
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.fun import id

    # Test for success Validation should be Lazy where function
    # return Validation value
    assert Validation(1, []).to_lazy() == Lazy(id(1))

    # Test for failed Validation
    assert Validation(1, [2]).to_lazy() == Lazy(id(1))


# Generated at 2022-06-12 05:51:21.100130
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success(5).to_lazy()
    assert val.value() == 5

    val = Validation.fail(['error']).to_lazy()
    assert val.value() is None

    assert val.__class__ == Lazy



# Generated at 2022-06-12 05:51:23.678446
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()


# Generated at 2022-06-12 05:51:27.546804
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(10).to_lazy()() == 10


# Generated at 2022-06-12 05:51:34.783725
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)

    def f():
        raise RuntimeError('Error')

    assert Validation.success(f).to_lazy() == Lazy(f)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:51:40.451171
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # when:
    # validation is successful value
    validation = Validation.success(123)
    lazy = validation.to_lazy()

    # then:
    # lazy should be monad with function returning value of the validation
    assert(isinstance(lazy, Lazy))
    assert(lazy() == validation.value)


# Generated at 2022-06-12 05:51:47.632473
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['Error']).to_lazy()

# Generated at 2022-06-12 05:51:52.225541
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)
    validation = Validation.fail([1, 2])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:55.392224
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Lazy(lambda: 'a') == Validation('a', []).to_lazy()
    assert Lazy(lambda: None) == Validation(None, ['error']).to_lazy()



# Generated at 2022-06-12 05:52:01.625813
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.monad_lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1), 'should return Lazy monad for success case'
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None), 'should return Lazy monad for fail case'


# Generated at 2022-06-12 05:52:03.645987
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:06.827377
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, ForceException

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    try:
        Validation.fail([1]).to_lazy().force()
        assert False  # Exception was not raised
    except ForceException:
        assert True


# Generated at 2022-06-12 05:52:15.436054
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.tuple import Tuple
    from pymonet.monad_try import Try

    # given

    # when
    validation = Validation.success(Tuple(Try.success(4), 1))

    # then
    assert validation.to_lazy().value().value.value == 4

    # given

    # when
    validation = Validation.fail([1, 2, 3])

    # then
    assert validation.to_lazy().value().value is None

    return True


# Generated at 2022-06-12 05:52:27.543688
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_lazy import Lazy

    validation = Validation.success('42')
    assert validation.to_lazy() == Lazy(lambda: '42')
    validation = Validation.success(42)
    assert validation.to_lazy() == Lazy(lambda: 42)
    validation = Validation.success(Try(lambda: 1 / 0))
    assert validation.to_lazy() == Lazy(lambda: 1 / 0)
    validation = Validation.success(Lazy(lambda: 1 / 0))
    assert validation.to_lazy() == Lazy(lambda: 1 / 0)
    validation = Validation.success(Lazy(lambda: 42))
    assert validation.to_lazy() == Lazy(lambda: 42)

# Unit

# Generated at 2022-06-12 05:52:31.592630
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail([]).to_lazy() == Validation.success(None).to_lazy()
    assert Validation.fail(['a']).to_lazy() == Validation.fail(['a']).to_lazy()



# Generated at 2022-06-12 05:52:34.879372
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # when creating lazy monad with successful Validation
    lazy = Validation.success('test').to_lazy()
    # then it should be Successful Try with value 'test'
    assert lazy.value() == 'test'


# Generated at 2022-06-12 05:52:45.794379
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def fn(x):
        return x + 1 if x < 5 else None

    validation = Validation.fail([]) >> (lambda x: Validation.success(fn(x))) >> (lambda x: Validation.success(fn(x)))

    assert validation.is_success()

    assert validation.to_lazy() == Lazy(lambda: 6)
    assert validation.to_lazy().value() == 6

    validation = Validation.fail([]) >> (lambda x: Validation.success(fn(x))) >> (lambda x: Validation.success(fn(x))) >> (lambda x: Validation.success(fn(x)))

    assert not validation.is_success()

    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.to_lazy().value() == None



# Generated at 2022-06-12 05:52:52.889949
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def function():
        return 'input'

    success_validation = Validation.success()
    lazy_monad = success_validation.to_lazy()
    assert (lazy_monad == Lazy(lambda: success_validation.value))

    fail_validation = Validation.fail()
    lazy_monad = fail_validation.to_lazy()
    assert (lazy_monad == Lazy(lambda: fail_validation.value))



# Generated at 2022-06-12 05:52:56.026634
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    method = lambda: 'value'
    lazy_value = Validation.success(method).to_lazy().get()()

    assert lazy_value == 'value'


# Generated at 2022-06-12 05:53:02.334389
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Success, Failure

    assert Success(5).to_monad().to_lazy().to_monad().is_success()
    assert Success(5).to_monad().to_lazy().to_monad().get() == 5
    assert Failure(5).to_monad().to_lazy().to_monad().is_failure()
    assert Failure(5).to_monad().to_lazy().to_monad().error == 5

# Generated at 2022-06-12 05:53:10.383840
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(12).to_lazy() == Lazy(lambda: 12)
    assert Validation.success(Right(12)).to_lazy() == Lazy(lambda: Right(12))
    assert Validation.fail(Left(12)).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:18.048916
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy() != Lazy(lambda: 2)
    assert Validation.success(1).to_lazy() != Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() != Lazy(lambda: 1)


# Generated at 2022-06-12 05:53:20.508216
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 05:53:24.304254
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def _f():
        return Validation.success('value1')

    validation = Validation.success('value')
    lazy_val = validation.to_lazy()
    assert lazy_val == Lazy(_f)


# Generated at 2022-06-12 05:53:26.785098
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(1).to_lazy().eval()
    assert result == 1, "Validation.to_lazy() should return Lazy monad with function returning Validation value"


# Generated at 2022-06-12 05:53:32.242114
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_lazy = Lazy(lambda: 1)
    fail_lazy = Lazy(lambda: None)

    assert Validation.success(1).to_lazy() == success_lazy
    assert Validation.fail([1]).to_lazy() == fail_lazy


# Generated at 2022-06-12 05:53:44.668421
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.Validation import Validation
    from pymonet.monad_try import Try

    validation = Validation.fail(['foo error'])
    assert validation.to_lazy() == Lazy(lambda: validation.value)
    validation = Validation.fail(['foo error'])
    assert validation.to_try() == Try(validation.value, is_success=False)
    validation = Validation.success('foo')
    assert validation.to_lazy() == Lazy(lambda: validation.value)
    validation = Validation.success('foo')
    assert validation.to_try() == Try(validation.value, is_success=True)



# Generated at 2022-06-12 05:53:52.999205
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_try() == Try(5, is_success=True)
    # assert Validation.fail([1, 2]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-12 05:53:56.807559
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation."""
    assert Validation(1, []).to_lazy().get() == 1
    assert Validation(1, [2]).to_lazy().get() == 1


# Generated at 2022-06-12 05:54:00.239445
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(0, []).to_lazy() == Lazy(lambda : 0)
    assert Validation(None, [0, 1]).to_lazy() == Lazy(lambda : None)


# Generated at 2022-06-12 05:54:04.867690
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Test for Validation.to_lazy returns Lazy with function returning Validation value
    """
    from pymonet.monad_lazy import Lazy

    validation = Validation('value', ['error'])
    lazy = validation.to_lazy()

# Generated at 2022-06-12 05:54:11.429942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import has_errors
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()
    assert lazy.get() == 1

    lazy = Validation.fail([1]).to_lazy()
    assert lazy.get() == None

    lazy = Validation.fail([1]).to_lazy()
    assert lazy.value == None

    assert has_errors(lazy)
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:54:13.651010
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10).to_lazy() == Validation.success(10)

# Generated at 2022-06-12 05:54:22.807699
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Either
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    validation_1 = Validation.success(2)
    lazy_1 = validation_1.to_lazy()
    assert (lazy_1.value == 2)

    validation_2 = Validation.fail([1, 2, 3])
    lazy_2 = validation_2.to_lazy()
    assert (lazy_2.value is None)

    # Check that all monads are same
    assert (validation_1.to_lazy() == validation_1.to_try().to_lazy())

# Generated at 2022-06-12 05:54:29.623035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def f():
        return 1/0

    lazy = Validation.success('value').to_lazy()
    assert lazy == Lazy(lambda: 'value')
    assert lazy.value() == 'value'

    lazy = Validation.fail(['error']).to_lazy()
    assert lazy.value() == None

# Generated at 2022-06-12 05:54:37.729244
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def test_Success():
        assert Validation.success(1).to_lazy() == Lazy(lambda: 1), 'Validation.success() are not Lazy(1)'

    def test_Fail():
        assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None), 'Validation.fail() are not Lazy(None)'

    test_Success()
    test_Fail()



# Generated at 2022-06-12 05:54:55.523365
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.try_ import Try

    success_validation = Validation.success(lambda: 1)
    assert success_validation.to_lazy() == Lazy(lambda: lambda: 1)

    fail_validation = Validation.fail([lambda: 1])
    assert success_validation.to_lazy() == Lazy(lambda: None)

    success_try = Try.success(lambda: 1)
    assert success_try.to_lazy() == Lazy(lambda: lambda: 1)

    fail_try = Try.fail(lambda: 1)
    assert fail_try.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:59.727222
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    assert Validation.success(Try.just(5)).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:55:05.232295
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 05:55:07.757694
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('a string').to_lazy() == Lazy(lambda: 'a string')



# Generated at 2022-06-12 05:55:11.621616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    f = lambda x: x + 1
    validation = Validation.success(f)
    lazy = validation.to_lazy()
    assert lazy.value == f


# Generated at 2022-06-12 05:55:23.562465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monoid import Monoid
    from pymonet.lazy import Lazy

    # Test for successful Validation
    validation1 = Validation(
        value=Monoid(
            operation=(lambda x, y: None),
            identity_element=None
        ),
        errors=[]
    )
    lazy1 = validation1.to_lazy()
    assert lazy1.is_instance(Lazy)
    assert lazy1.value() == validation1.value
    assert lazy1 == Lazy(
        value=(lambda: Monoid(
            operation=(lambda x, y: None),
            identity_element=None
        ))
    )

    # Test for fail Validation
    validation2 = Validation(
        value=None,
        errors=[
            None,
            None
        ]
    )
    lazy2

# Generated at 2022-06-12 05:55:27.666604
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(1)
    assert v.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:55:35.577496
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(1).to_lazy()
    assert lazy.get() == 1, 'Lazy monad expected to contains 1, but was: ' + str(lazy.get())

    lazy = Validation.fail(1).to_lazy()
    assert lazy.get() is None, 'Lazy monad expected to contains 1, but was: ' + str(lazy.get())

    lazy = Validation.success([1, 2, 3]).to_lazy()
    assert lazy.get() == [1, 2, 3], 'Lazy monad expected to contains [1,2,3], but was: ' + str(lazy.get())



# Generated at 2022-06-12 05:55:37.923591
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('Hello').to_lazy() == Lazy(lambda: 'Hello')

# Generated at 2022-06-12 05:55:44.104640
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Test method to_lazy of class Validation.
    """
    from pymonet import Lazy
    from pymonet.monad_try import Try

    assert Validation.fail(['bad news']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('yay!').to_lazy() == Lazy(lambda: 'yay!')
    assert Validation.success('yay!').to_lazy().get_or_raise() == Try('yay!', is_success=True)


# Generated at 2022-06-12 05:55:58.812199
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    # pylint: disable=W0613
    @Lazy
    def lazy_success():
        """
        This function returns Lazy monad that stores successful Validation with value.
        """
        return Validation.success(22)

    @Lazy
    def lazy_fail():
        """
        This function returns Lazy monad that stores failed Validation with value.
        """
        return Validation.fail()

    assert lazy_success().get() == Validation.success(22)
    assert lazy_fail().get() == Validation.fail()


# Generated at 2022-06-12 05:56:01.495377
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    val = Validation.success('test')
    result = val.to_lazy()

    assert isinstance(result, Lazy)

    assert 'test' == result.value()

# Generated at 2022-06-12 05:56:05.939791
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(True, [])

    lazy_box = validation.to_lazy()

    assert lazy_box is not None
    assert isinstance(lazy_box, Lazy)
    assert lazy_box.get_value() is True


# Generated at 2022-06-12 05:56:11.316022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:20.979798
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def test1():
        return Validation.success(10)

    assert test1() == Validation.success(10)
    assert test1().to_lazy().resolve() == Validation.success(10)
    assert test1().to_lazy() == Lazy(lambda: Validation.success(10))

    def test2():
        return Validation.fail([1, 2, 3])

    assert test2() == Validation.fail([1, 2, 3])
    assert test2().to_lazy().resolve() == Validation.fail([1, 2, 3])
    assert test2().to_lazy() == Lazy(lambda: Validation.fail([1, 2, 3]))


# Generated at 2022-06-12 05:56:25.586651
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def returned_value():
        return 3

    def lazy():
        return returned_value()

    assert Validation.success(returned_value).to_lazy() == Lazy(lazy)


# Generated at 2022-06-12 05:56:28.509481
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:34.009947
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_except import MonadExcept

    assert Validation.success(1).to_lazy().value() == 1
    assert MonadExcept[Validation, Exception](Validation.fail([1, 2, 3])).to_try().failure is not None

# Unit tests for method to_try of class Validation

# Generated at 2022-06-12 05:56:39.880278
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, LazyValueError
    from pymonet.validation import Validation

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    try:
        assert Validation.fail(['error']).to_lazy() == Lazy(lambda: 2)
    except LazyValueError:
        assert True


# Generated at 2022-06-12 05:56:43.725316
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test successful Validation
    assert Validation.success(5).to_lazy().get() == 5

    # Test failed Validation
    assert Validation.fail(['Internal server error']).to_lazy().get() is None

# Generated at 2022-06-12 05:57:03.395790
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    def val_maybe_val():
        return Validation.success(1)

    lazy = Lazy(val_maybe_val)

    assert lazy.to_lazy().eval() == lazy.eval()


# Generated at 2022-06-12 05:57:05.835019
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(5)

    assert validation.to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:57:08.538878
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:11.873427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:14.982511
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Validation(10, []).to_lazy()
    assert Lazy(lambda: None) == Validation(None, [1]).to_lazy()


# Generated at 2022-06-12 05:57:18.425982
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation.
    """
    from pymonet.lazy import Lazy

    value = 'value'
    lazy = Validation.success(value).to_lazy()

    assert lazy == Lazy(lambda: value)



# Generated at 2022-06-12 05:57:22.363543
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail(['Error 1', 'Error 2']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:24.637580
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pytest

    def fn():
        return 3

    assert Validation.success(3).to_lazy() == Lazy(fn)


# Generated at 2022-06-12 05:57:27.936519
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return Validation(3, [])

    assert Lazy(f).to_validation() == Validation(3, [])


# Generated at 2022-06-12 05:57:32.444403
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    success = Validation.success('OK')
    failure = Validation.fail()
    assert (success.to_lazy() == Lazy(lambda: 'OK'))
    assert (failure.to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-12 05:57:58.682171
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # pylint: disable=anomalous-backslash-in-string
    from pymonet.lazy import Lazy

    # Success Validation
    val1 = Validation.success('Value')
    assert Lazy(lambda: 'Value') == val1.to_lazy()

    # Failed Validation
    val2 = Validation.fail(['Error'])
    assert val2.to_lazy() == Lazy(lambda: None)

    # Empty Success Validation
    val3 = Validation.success()
    assert val3.to_lazy() == Lazy(lambda: None)

    # Empty Failed Validation
    val4 = Validation.fail()
    assert val4.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:00.933479
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([]).to_lazy().get() is None


# Generated at 2022-06-12 05:58:07.628567
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from functools import reduce
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    # Given
    validation = Validation.success(1)

    # When
    lazy = validation.to_lazy()
    result = reduce(lambda x, y: x + y, [1, 2, 3, 4, 5, 6, 7], lazy)

    # Then
    assert lazy == Lazy(1)
    assert result == 28


# Generated at 2022-06-12 05:58:18.589993
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.list import List
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import SuccessfulTry, FailedTry

    # when Validation is successful
    actual = Validation.success(1).to_lazy()
    expect = Lazy(lambda: 1)
    assert actual == expect

    # when Validation is failed
    actual = Validation.fail().to_lazy()
    expect = Lazy(lambda: None)
    assert actual == expect

    # when Validation is successful, but Lazy is failed
    actual = Validation.success(1).to_lazy()
    expect = Lazy(lambda: Try(1, is_success=True))
    assert actual == expect

    # when Validation is failed, but Lazy

# Generated at 2022-06-12 05:58:22.208574
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def return_three():
        return 3

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.success(3).to_lazy() != Lazy(return_three)


# Generated at 2022-06-12 05:58:24.074368
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 10) == Validation.success(10).to_lazy()


# Generated at 2022-06-12 05:58:29.309001
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Validation success
    assert Validation.success(30).to_lazy() == Lazy(lambda: 30)

    # Validation fail
    assert Validation.fail(30).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:39.980860
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for to_lazy of class Validation"""
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.success(42).to_lazy().bind(lambda x: Lazy(lambda: x * 2)) == Lazy(lambda: 84)
    assert Validation.success(42).to_lazy().map(lambda x: x * 2) == Lazy(lambda: 84)
    assert Validation.success(42).to_lazy().ap(Lazy(lambda x: x * 2)) == Lazy(lambda: 84)
    assert Validation.success(42).to_l