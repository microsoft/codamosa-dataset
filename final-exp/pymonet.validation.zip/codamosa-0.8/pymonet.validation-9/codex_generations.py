

# Generated at 2022-06-12 05:48:41.080459
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_with_value = lambda: 1

    assert Validation.success(1).to_lazy() == Lazy(lazy_with_value)
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy().get() is None


# Generated at 2022-06-12 05:48:44.150252
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    assert Validation.fail(['Failed']).to_lazy().get() is None
    assert Validation.success('Success').to_lazy().get() == 'Success'

# Generated at 2022-06-12 05:48:48.312600
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    errors = ['error1', 'error2']
    assert Validation(2, errors).to_lazy() == Lazy(lambda: 2)
    assert Validation(None, errors).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:51.532436
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:49:00.195072
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(123).to_lazy()
    assert lazy
    assert lazy.value == Lazy(lambda: 123).value
    assert Validation.fail([1, 2, 3]).to_lazy().value == Lazy(lambda: None).value
    assert Validation.success(123).to_lazy().value() == Lazy(lambda: 123).value()
    assert Validation.fail([1, 2, 3]).to_lazy().value() == Lazy(lambda: None).value()



# Generated at 2022-06-12 05:49:03.255539
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """ Unit test for method to_lazy of class Validation """
    subject = Validation(True, [])
    expected = Lazy(lambda: True)
    actual = subject.to_lazy()

    assert actual == expected

# Generated at 2022-06-12 05:49:06.757677
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:11.743372
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    lazy = validation.to_lazy()

    assert lazy.get() == 1

    validation = Validation.fail([1, 2, 3])
    lazy = validation.to_lazy()

    assert lazy.get() == None


# Generated at 2022-06-12 05:49:15.414208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(123, [])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.force() == 123


# Generated at 2022-06-12 05:49:22.231728
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test successful Validation
    validation = Validation.success(1)
    lazy_value = validation.to_lazy()

    assert isinstance(lazy_value, Lazy)
    assert lazy_value.value() == 1

    # Test failed Validation
    validation = Validation.fail([1, 2])
    lazy_value = validation.to_lazy()

    assert isinstance(lazy_value, Lazy)
    assert lazy_value.value() is None


# Generated at 2022-06-12 05:49:29.586098
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Maybe(42).to_lazy() == Lazy(lambda: 42)

    assert Try(42).to_lazy() == Lazy(lambda: 42)

    assert TryNone().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:49:37.252565
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def fun():
        return 42

    validation = Validation.success(42)
    lz = validation.to_lazy()
    assert lz.iterator.next() == validation.value

    validation = Validation.fail(['Boom!'])
    lz = validation.to_lazy()
    assert lz.iterator.next() == validation.value

    validation = Validation.success(fun)
    lz = validation.to_lazy()
    assert lz.iterator.next()() == 42

    validation = Validation.success(fun)
    lz = validation.to_lazy()
    assert lz.iterator.next()() == 42


# Generated at 2022-06-12 05:49:40.484383
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(8).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:46.542471
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""
    from pymonet.lazy import Lazy

    def lazy_multiply_two(value):
        return Lazy(lambda: value * 2)

    assert Validation.success(1).map(lazy_multiply_two).to_lazy().force() == 2
    assert Validation.fail(1).map(lazy_multiply_two).to_lazy().force() == None

# Generated at 2022-06-12 05:49:53.173163
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_value = 'test'
    validation_success = Validation.success(test_value)
    lazy_success = validation_success.to_lazy()
    assert lazy_success.value() == test_value
    assert lazy_success.is_success()
    validation_fail = Validation.fail(test_value)
    lazy_fail = validation_fail.to_lazy()
    assert lazy_fail.value() == None
    assert lazy_fail.is_success()


# Generated at 2022-06-12 05:50:00.886538
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    # Test of successful validation
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1

    # Test of failed validation
    validation = Validation.fail([1])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None



# Generated at 2022-06-12 05:50:05.421508
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:16.543420
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy

    def assert_lazy(value, is_success):
        success_box = Validation.success(value).to_lazy()
        assert isinstance(success_box, Lazy)
        assert is_success(success_box.get_value())

        fail_box = Validation.fail().to_lazy()
        assert isinstance(fail_box, Lazy)
        assert not is_success(fail_box.get_value())

    assert_lazy(1, lambda x: isinstance(x, int))
    assert_lazy(Right(1), lambda x: isinstance(x, Right))
    assert_lazy(Left(1), lambda x: isinstance(x, Left))



# Generated at 2022-06-12 05:50:19.845860
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validation = Validation.success(10)

    assert validation.to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 05:50:25.816048
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy = Validation.success('test').to_lazy()
    assert lazy == Lazy(lambda: 'test')
    assert lazy.value() == Lazy(lambda: 'test').value()


# Generated at 2022-06-12 05:50:31.092103
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value == 1
    assert Validation.fail([]).to_lazy().value is None


# Generated at 2022-06-12 05:50:36.302897
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def get_lazy_val():
        return Validation.success(123)

    lazy_val = get_lazy_val()
    assert lazy_val == Validation.success(123)
    assert lazy_val.to_lazy() == Lazy(lambda: Validation.success(123))



# Generated at 2022-06-12 05:50:41.214134
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Object Validation contains value and list of errors.

    Validation constructor has two parameters. Value of any type and list of errors.

    Class has method to_lazy that return Lazy monad.
    """
    validation = Validation.success(9)
    assert validation.to_lazy() == Lazy(lambda: 9)

    validation = Validation.success()
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:45.056924
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:45.930378
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-12 05:50:48.614924
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def _():
        return 'a'

    assert Validation.success('a').to_lazy() == Lazy(_)


# Generated at 2022-06-12 05:50:52.852323
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'String') == Validation.success('String').to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['Error']).to_lazy()


# Generated at 2022-06-12 05:51:00.913436
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Success, Failure

    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.get(), Success)
    assert lazy.get().value == 1

    validation = Validation.fail([])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.get(), Failure)
    assert lazy.get().value is None

# Generated at 2022-06-12 05:51:03.762085
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-12 05:51:07.706846
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def to_lazy(initial_value, is_success=True):
        return Validation(
            value=initial_value,
            errors=[] if is_success else [initial_value]
        ).to_lazy()

    assert to_lazy(2) == Lazy(lambda: 2)
    assert to_lazy(2, False) == Lazy(lambda: 2)



# Generated at 2022-06-12 05:51:14.847127
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([1, 2, 3]).to_lazy().get() is None


# Generated at 2022-06-12 05:51:18.193077
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_value = 1984
    validation = Validation.success(test_value)
    lazy = validation.to_lazy()
    assert lazy.is_success()
    assert lazy.get() == test_value



# Generated at 2022-06-12 05:51:20.884132
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(2, []).to_lazy() == Lazy(lambda: 2)
    assert Validation(None, [1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:26.278232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    v = Validation.success(2)
    assert v.to_lazy() == Lazy(lambda: 2)

    v = Validation.fail([1])
    assert v.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:31.454788
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation class.
    """
    # pylint: disable=unused-variable
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:34.538142
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success("value").to_lazy().get()("") == "value"
    assert Validation.fail("error").to_lazy().get()("") == None


# Generated at 2022-06-12 05:51:40.574531
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Validation.success(Box(1)).to_lazy() == Lazy(lambda: Box(1))
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:45.925366
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation = Validation.success(5)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 5)


# Generated at 2022-06-12 05:51:49.582654
# Unit test for method to_lazy of class Validation

# Generated at 2022-06-12 05:51:55.448977
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:03.869907
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy_monad = Validation(1, []).to_lazy()

    assert isinstance(lazy_monad, Lazy)
    assert isinstance(lazy_monad.value(), Try)
    assert lazy_monad.value().is_success()
    assert lazy_monad.value().value == 1
    assert lazy_monad.value().is_fail() is False


# Generated at 2022-06-12 05:52:13.659354
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test for to_lazy method of class Validation"""
    from pymonet.lazy import Lazy

    test_data = [
        (lambda: 5, lambda: Validation.success(5), Lazy(lambda: 5)),
        (lambda: 'test', lambda: Validation.success('test'), Lazy(lambda: 'test')),
        (lambda: lambda x: x + 3, lambda: Validation.success(lambda x: x + 3), Lazy(lambda: lambda x: x + 3)),
    ]
    test_results = list(map(lambda test: test[1]().to_lazy() == test[2], test_data))
    assert all(test_results)


# Generated at 2022-06-12 05:52:19.457716
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:23.463461
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Validation('1', []).to_lazy()
    assert lazy.value() == '1'
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:52:28.405842
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.curry import curry
    from operator import add

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:36.398451
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation class
    """
    from pymonet.lazy import Lazy

    def lazy_factory():
        """
        Factory function of lazy object
        """
        # pylint: disable=W0703
        try:
            return 100 / 0
        except Exception as error:
            return error

    lazy = Lazy(lazy_factory)
    validation = Validation.success(lazy)
    assert type(validation.to_lazy()) == Lazy
    assert validation.to_lazy().value() is lazy


# Generated at 2022-06-12 05:52:39.186152
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:42.964522
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # when
    validation_try = Validation('value', [])

    # then
    assert validation_try.to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:52:49.005276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation."""
    from pymonet.lazy import Lazy
    from pymonet import Validation

    validation = Validation.success(42)
    assert validation.to_lazy() == Lazy(lambda: 42)

    validation = Validation.fail([])
    assert validation.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:52:52.074553
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    box = Box(34)
    assert box.map(lambda x: x * 2).to_lazy() == Lazy(lambda: box.value * 2)


# Generated at 2022-06-12 05:52:59.652556
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    f = lambda: Validation.success(1)
    l = Lazy(f)

    assert f() == l.run()

    f = lambda: Validation.fail(2)
    l = Lazy(f)

    assert f() == l.run()


# Generated at 2022-06-12 05:53:09.807171
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Testing of Validation.to_lazy method.
    """
    from pymonet.lazy import Lazy

    def mapper(value):
        return value + 5

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(10).to_lazy().map(mapper) == Lazy(lambda: 15)
    assert Validation.fail(['error']).to_lazy().map(mapper) == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:17.950960
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    lazy_value = Lazy(lambda: 'value')

    # test case:
    # Validation.success -> Lazy
    assert Validation.success('value').to_lazy() == lazy_value, 'Validation.success should be converted to Lazy'

    # test case:
    # Validation.fail -> Lazy
    assert Validation.fail([]).to_lazy() == lazy_value, 'Validation.fail should be converted to Lazy'


# Generated at 2022-06-12 05:53:22.873710
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Check to_lazy method.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:25.589142
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy().get() == 5
    assert Validation.fail().to_lazy().get() is None


Validation.success = staticmethod(Validation.success)
Validation.fail = staticmethod(Validation.fail)

# Generated at 2022-06-12 05:53:37.622660
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def get_successful_value():
        return True

    def get_failure_value():
        return ValueError('Some error')

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(True).to_lazy() == Lazy(lambda: True)

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    # assert Validation.fail(['Some error']).to_lazy() == Lazy(lambda: ValueError("Some error")) # Handled by python
    assert Validation.fail(get_successful_value).to_lazy() == Lazy(lambda: True)
    assert Validation.fail(get_failure_value).to_lazy() == Lazy(get_failure_value)


# Generated at 2022-06-12 05:53:47.048086
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.list_ import List
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Either

    assert Box(Validation.success('foo')).to_lazy().call() == 'foo'
    assert Box(Validation.fail()).to_lazy().call() == None
    assert List(Validation.success('foo')).to_lazy().call() == 'foo'
    assert List(Validation.fail()).to_lazy().call() == None
    assert Lazy(lambda: Validation.success('foo')).to_lazy().call() == 'foo'

# Generated at 2022-06-12 05:53:53.891786
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """

    val = Validation.success("abc")
    lazy = val.to_lazy()
    assert lazy.evaluate() == "abc"

    val = Validation.fail("def")
    lazy = val.to_lazy()
    assert lazy.evaluate() == None



# Generated at 2022-06-12 05:53:58.295946
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.fail(errors=['error'])
    assert val.to_lazy() == Lazy(lambda: None)

    val = Validation.success(1)
    assert val.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:01.237639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.fail([1, 2, 3])
    assert validation.to_lazy().__call__() == None
    val = validation.to_lazy().__call__()
    assert val == None


# Generated at 2022-06-12 05:54:10.552318
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tests that to_lazy returns correct Lazy monad.

    :returns: True when test passes
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    lazy = validation.to_lazy()

    return lazy == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:14.402541
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail('a').to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:54:23.114978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().value == 1
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy().value == None
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:54:28.019134
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail('some_error').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:34.876465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success('Hello')
    success_lazy = success.to_lazy()
    assert isinstance(success_lazy, Lazy)
    assert success_lazy.computed is False
    assert success_lazy.value() == 'Hello'

    fail = Validation.fail(['Error'])
    fail_lazy = fail.to_lazy()
    assert isinstance(fail_lazy, Lazy)
    assert fail_lazy.computed is False
    assert fail_lazy.value() is None


# Generated at 2022-06-12 05:54:36.909801
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation('abc', []).to_lazy() == Lazy(lambda: 'abc')


# Generated at 2022-06-12 05:54:45.626920
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.assertions import assert_that
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert_that(Validation.success(True).to_lazy()).is_instance_of(Lazy)
    assert_that(Validation.success(True).to_lazy().value()).is_instance_of(Try)
    assert_that(Validation.success(True).to_lazy().value().is_success()).is_true()
    assert_that(Validation.success(True).to_lazy().value().value()).is_true()

# Generated at 2022-06-12 05:54:49.869367
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1]).to_lazy()


# Generated at 2022-06-12 05:54:55.107982
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    import pytest

    validation = Validation.success()
    lazy = validation.to_lazy()
    assert lazy.force(lambda: 42) == validation.value

    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: validation.value)


# Generated at 2022-06-12 05:55:00.072322
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    a_success = Validation.success(1)
    assert Lazy(lambda: 1) == a_success.to_lazy()

    a_fail = Validation.fail(["Error 1", "Error 2"])
    assert Lazy(lambda: None) == a_fail.to_lazy()


# Generated at 2022-06-12 05:55:06.991030
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return "value"
    f = Validation.success(f)

    assert f.to_lazy() == Lazy(lambda: f)


# Generated at 2022-06-12 05:55:14.773206
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Success
    def success_test():
        return 1
    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()

    # Fail
    def fail_test():
        raise AssertionError('fail')

    assert Lazy(fail_test).to_try() == Try(fail_test, is_success=False)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:20.616345
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:26.795935
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def method1(x):
        return 2 * x

    # Test when Validation has no errors
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert lazy.value == lazy.value() == 1
    assert lazy.map(method1).value() == 2
    assert lazy.map(method1).map(method1).value() == 4

    # Test when Validation has some errors
    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()
    assert lazy.value == lazy.value() is None
    assert lazy.map(method1).value() is None
    assert lazy.map(method1).map(method1).value() is None


# Generated at 2022-06-12 05:55:31.026321
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(2).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:36.420000
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad.lazy import Lazy

    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')
    assert Validation.fail(['some_error']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:41.126407
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.success(2).to_lazy().get() == 2
    assert Validation.fail([1]).to_lazy().get() == None
    assert Validation.fail([2]).to_lazy().get() == None


# Generated at 2022-06-12 05:55:47.854209
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It checks if returned value from lazy is successful when Validation has no errors

    >>> from pymonet.validation import Validation
    >>> from pymonet.lazy import Lazy
    >>> validation = Validation.success(42)
    >>> lazy = validation.to_lazy()
    >>> lazy.get_value()
    42
    """


# Generated at 2022-06-12 05:55:55.029237
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, _is_lazy

    success = Validation.success(1)
    assert _is_lazy(success.to_lazy())
    assert Lazy(lambda: 1) == success.to_lazy()

    fail = Validation.fail(['Error'])
    assert _is_lazy(fail.to_lazy())
    assert Lazy(lambda: None) == fail.to_lazy()


# Generated at 2022-06-12 05:55:59.119978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()

    assert lazy == Lazy(lambda: 1)


# Generated at 2022-06-12 05:56:07.474873
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(10).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:56:09.854668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def value():
        return 10

    assert Validation.success(10).to_lazy() == Lazy(value)


# Generated at 2022-06-12 05:56:15.824897
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def evaluate_lazy(lazy):
        return lazy()

    lazy1 = Validation.success(1).to_lazy()
    assert isinstance(lazy1, Lazy)
    assert evaluate_lazy(lazy1) == 1

    lazy2 = Validation.fail(['fail']).to_lazy()
    assert isinstance(lazy2, Lazy)
    assert evaluate_lazy(lazy2) == None



# Generated at 2022-06-12 05:56:17.562380
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:56:20.884292
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('test')
    result = validation.to_lazy()
    assert result == Lazy(lambda: 'test')



# Generated at 2022-06-12 05:56:30.092114
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.dictionaries import Dictionaries
    from pymonet.lazy import Lazy

    dictionary = Dictionaries.from_obj({'name': 'Leo Tolstoy', 'birth': 1828, 'death': 1910})

    Validation.success().ap(dictionary.get('name')).ap(dictionary.get('birth')).ap(dictionary.get('death')).to_maybe()
    # Result: Maybe.just('Leo Tolstoy')

    result = Validation.success().ap(dictionary.get('name')).ap(dictionary.get('birth')).ap(dictionary.get('death')).to_lazy()
    print(result)
    # Result: Lazy[Function() -> 'Leo Tolstoy']

    print(result.value())
    # Result: 'Leo Tol

# Generated at 2022-06-12 05:56:40.077546
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_list import List
    from pymonet.lazy import Lazy

    def get_42():
        return Validation.success(42)

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.fail(errors=[1, 2]).to_lazy() == Lazy(lambda: None)
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.success(range(2)).to_lazy() == Lazy(lambda: List.range(2))
    assert Validation.success(get_42).to_lazy() == Lazy(get_42)


# Generated at 2022-06-12 05:56:47.928716
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    # method success()
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    # method fail()
    assert Validation.fail(['foo']).to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:51.212494
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:56:55.186498
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:57:03.203260
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(2).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:57:07.619995
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test behaviour when Validation transformed to Lazy monad.
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail(errors=[1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:11.765150
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v1 = Validation.success(2)
    v2 = Validation.fail([])
    assert v1.to_lazy() == Lazy(lambda: 2)
    assert v2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:15.153966
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_validation = Validation.fail(['error 1']).to_lazy()

    assert isinstance(lazy_validation, Lazy)
    assert lazy_validation.value == 'error 1'



# Generated at 2022-06-12 05:57:20.096223
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.lazy import Strict

    def test_Validation_to_lazy_with_success_Validation_returns_Lazy_with_Validation_value():
        validation = Validation.success(10)
        lazy = validation.to_lazy()
        assert lazy == Lazy(10)


# Generated at 2022-06-12 05:57:24.935025
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test case for Validation to_lazy method"""
    assert isinstance(Validation.success(1).to_lazy(), Lazy)
    assert Validation.success(1).to_lazy().value == 1

    assert isinstance(Validation.fail([1]).to_lazy(), Lazy)
    assert Validation.fail([1]).to_lazy().value is None


# Generated at 2022-06-12 05:57:28.654656
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(10).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:34.447551
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(True)
    assert validation.to_lazy() == Lazy(lambda: True)
    assert validation.to_lazy().get() == True

    validation = Validation.fail('error')
    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.to_lazy().get() is None


# Generated at 2022-06-12 05:57:37.837494
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().success == 1
    assert Validation.success(1).to_lazy().is_success() == True
    assert Validation.fail().to_lazy().is_success() == False

# Generated at 2022-06-12 05:57:41.117531
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'a')
    val = Validation.success('a')
    assert val.to_lazy() == lazy


# Generated at 2022-06-12 05:57:54.660254
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    valid = Validation.success(5)
    assert (valid.to_lazy() == Lazy(lambda: valid.value))

    valid = Validation.success(8)
    assert (valid.to_lazy() == Lazy(lambda: valid.value))

    valid = Validation.fail([])
    assert (valid.to_lazy() == Lazy(lambda: valid.value))

    valid = Validation.fail(['error'])
    assert (valid.to_lazy() == Lazy(lambda: valid.value))


# Generated at 2022-06-12 05:57:57.450103
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 3) == Validation.success(3).to_lazy()


# Generated at 2022-06-12 05:58:00.000581
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    Lazy(lambda: 1) == Validation.success(1).to_lazy()
    Lazy(lambda: None) == Validation.fail().to_lazy()

# Generated at 2022-06-12 05:58:00.892845
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-12 05:58:04.363479
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import identity

    validation = Validation(3, [])

    assert validation.to_lazy() == Lazy(identity, value=3)


# Generated at 2022-06-12 05:58:08.577871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['test']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:11.907564
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:17.271582
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 05:58:18.166485
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert False, 'Tests not implemented!'

# Generated at 2022-06-12 05:58:24.103032
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success('X').to_lazy() == Lazy(lambda: 'X')
    assert Lazy(lambda: 2) == Lazy(lambda: 2)
    assert Lazy(lambda: 'Y') == Lazy(lambda: 'Y')
    assert Lazy(lambda: 'X') != Lazy(lambda: 'Y')


# Generated at 2022-06-12 05:58:31.291983
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:58:33.546489
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)