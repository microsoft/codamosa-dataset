

# Generated at 2022-06-12 05:48:34.790897
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(10).to_lazy().get_value()
    assert result == 10


# Generated at 2022-06-12 05:48:39.838499
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f(a):
        return a

    v = Validation.success('value')
    l = v.to_lazy()
    assert 'value' == l(f)

    v = Validation.fail([])
    l = v.to_lazy()
    assert None == l(f)


# Generated at 2022-06-12 05:48:44.359186
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success

    val = Validation.success(3)
    assert val.to_lazy() == Lazy(lambda: 3)

    val = Validation.fail(["3"])
    assert val.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:47.532380
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.

    :returns: True when test passes
    :rtype: Boolean
    """
    assert Validation.fail(['first_error']).to_lazy().eval_lazy() is None

    return True


# Generated at 2022-06-12 05:48:49.750041
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success(1).to_lazy().get() == 1



# Generated at 2022-06-12 05:48:55.346390
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 0) == Validation.success(0).to_lazy()

    assert Lazy(lambda: Try(0, True)) == Validation.success(0).to_lazy()

    assert Lazy(lambda: None) == Validation.fail([1]).to_lazy()

    assert Lazy(lambda: Try(None, False)) == Validation.fail([1]).to_lazy()


# Generated at 2022-06-12 05:49:03.972638
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import identity
    from pymonet.lazy import Lazy

    lazy = Validation.success(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == 42
    lazy = Validation.fail(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == None
    lazy = Validation.fail(42).map(identity).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == None


# Generated at 2022-06-12 05:49:06.176324
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def get_value():
        return 10

    assert Validation.success(10).to_lazy() == Lazy(get_value)


# Generated at 2022-06-12 05:49:12.441184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v1 = Validation.success(1)
    v2 = Validation.fail([])

    assert v1.to_lazy().eval() == 1
    assert v2.to_lazy().eval() == None
    assert v1.to_lazy().map(lambda x: x*2).eval() == 2
    assert v1.to_lazy().map(lambda x: x*2).map(lambda x: x*2).eval() == 4
    assert v2.to_lazy().map(lambda x: x*2).eval() == None

    assert v1.to_lazy().map(lambda x: x*2).to_validation().value == 2
    assert v2.to_lazy().map(lambda x: x*2).to_validation().value == None

# Generated at 2022-06-12 05:49:17.908290
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test with empty errors list
    assert Lazy(lambda: 1) == Validation(1, []).to_lazy()
    # Test with not empty errors list
    assert Lazy(lambda: None) == Validation(None, [1]).to_lazy()


# Generated at 2022-06-12 05:49:22.325698
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail(['fail']).to_lazy().get() == None

# Generated at 2022-06-12 05:49:25.342019
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 5) == Validation.success(5).to_lazy()



# Generated at 2022-06-12 05:49:29.907245
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:35.893464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_monad = Validation.success(5).to_lazy()
    assert 5 == lazy_monad.evaluate()
    assert 5 == Validation.success(5).to_lazy().evaluate()
    assert not Validation.fail(['error']).to_lazy().is_success
    assert Lazy.string_lazy('hello') == Validation.fail(['error']).to_lazy().map(lambda x: x + ' world').to_lazy()
    assert Validation.fail(['error']).to_lazy().get() == None
    assert Validation.fail(['error']).to_lazy().or_else(lambda: 2) == 2


# Generated at 2022-06-12 05:49:39.539051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('Some error').to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:42.952730
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def fn():
        return 2

    monad = Validation.success(fn)
    assert monad.to_lazy().eval() == fn

    monad = Validation.fail(fn)
    assert monad.to_lazy().eval() == fn


# Generated at 2022-06-12 05:49:47.262044
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """

    from pymonet.lazy import Lazy

    def f():
        return 'value'

    value = Lazy(f)
    validation = Validation.success(value)
    assert validation.to_lazy() == value

# Generated at 2022-06-12 05:49:53.078935
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)

    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(None).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:50:00.364851
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def get_maybe():
        return Maybe.just(7)

    assert Validation.success(7).to_lazy() == Lazy(lambda: 7)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.success(get_maybe).to_lazy() == Lazy(lambda: Maybe.just(7))


# Generated at 2022-06-12 05:50:05.701306
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    validation = Validation.fail([1, 2])
    assert(validation.to_lazy() == Lazy(lambda: None))

    validation = Validation.success(1)
    assert(validation.to_lazy() == Lazy(lambda: 1))


# Generated at 2022-06-12 05:50:11.510201
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(10).to_lazy().eval() == 10


# Generated at 2022-06-12 05:50:17.544525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    successful_validation = Validation(123, [])
    result = successful_validation.to_lazy()
    assert result.value() == 123
    assert result == Lazy(lambda: 123)

    failed_validation = Validation(None, [1, 2, 3])
    result = failed_validation.to_lazy()
    assert result.value() is None
    assert result == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:22.818748
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_1 = Lazy(lambda: 'lazy_1')
    validation_1 = Validation.success(lazy_1)
    assert validation_1.to_lazy().force() == lazy_1

    lazy_2 = Lazy(lambda: 'lazy_2')
    validation_2 = Validation.fail(0)
    assert validation_2.to_lazy().force() is None

# Generated at 2022-06-12 05:50:30.482019
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # Test with passed errors
    def test_function():
        return 1
    v = Validation(None, [0])
    assert v.to_lazy() == Lazy(test_function)

    # Test with no passed errors
    def test_function2():
        return 2
    v = Validation(2, [])
    assert v.to_lazy() == Lazy(test_function2)


# Generated at 2022-06-12 05:50:33.343415
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:50:36.720234
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method to_lazy of class Validation.
    """
    assert Validation(123, []).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:50:40.441526
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_val = Validation.success(42)
    failure_val = Validation.fail(['failure'])

    assert success_val.to_lazy() == Lazy(lambda: 42)
    assert failure_val.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:46.757444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy.unit(5)

    validation_fail = Validation.fail('fail string')
    assert validation_fail.to_lazy().evaluate() == Try.fail('fail string').evaluate()


# Generated at 2022-06-12 05:50:49.887576
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 123) == Validation.success(123).to_lazy()

# Generated at 2022-06-12 05:50:57.564786
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success([]).to_lazy() == Lazy(lambda: [])
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.success(()).to_lazy() == Lazy(lambda: ())
    assert Validation.success({}).to_lazy() == Lazy(lambda: {})


# Generated at 2022-06-12 05:51:02.678784
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['error']).to_lazy() == Lazy(None)
    assert Validation.success(4).to_lazy() == Lazy(4)


# Generated at 2022-06-12 05:51:05.570929
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:12.891246
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def unit_test_success():
        lazy = Validation.success(100).to_lazy()
        assert isinstance(lazy, Lazy)
        assert lazy.value() == 100
    def unit_test_fail():
        lazy = Validation.fail().to_lazy()
        assert isinstance(lazy, Lazy)
        assert lazy.value() is None
    unit_test_success()
    unit_test_fail()


# Generated at 2022-06-12 05:51:16.757899
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Create Some
    some_maybe = Validation.success(1)
    # Call method to_lazy
    lazy_maybe = some_maybe.to_lazy()
    # Check result
    assert lazy_maybe.is_lazy()
    assert lazy_maybe.call() == 1

# Generated at 2022-06-12 05:51:19.370766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:51:24.828327
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    :return: None
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()

# Generated at 2022-06-12 05:51:28.056548
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert(Validation.success(1).to_lazy().unwrap()() == 1)
    assert(Validation.fail(1).to_lazy().unwrap()() is None)


# Generated at 2022-06-12 05:51:33.520708
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    success_validation = Validation.success(42)
    fail_validation = Validation.fail([1, 2, 3])

    # When/Then
    value = success_validation.to_lazy().value()
    assert value == success_validation.value

    value = fail_validation.to_lazy().value()
    assert value == fail_validation.value


# Generated at 2022-06-12 05:51:36.244866
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success('test_value').to_lazy()
    assert lazy() == 'test_value'


# Generated at 2022-06-12 05:51:40.574672
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy(lambda: 5)

    validation = Validation.fail([])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:52.086471
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from random import randint
    from pymonet.lazy import Lazy

    assert(Validation.success().to_lazy() == Lazy(lambda: None))
    assert(Validation.fail().to_lazy() == Lazy(lambda: None))
    assert(Validation.success(1).to_lazy() == Lazy(lambda: 1))
    assert(Validation.success(randint(1, 1000)).to_lazy() == Lazy(lambda: randint(1, 1000)))
    assert(Validation.fail([]).to_lazy() == Lazy(lambda: None))
    assert(Validation.fail([1]).to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-12 05:51:56.334279
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success('success value').to_lazy()
    assert callable(lazy.value)
    assert lazy.value() == 'success value'
    assert Validation.fail(['firt error', 'second error']).to_lazy().value is None


# Generated at 2022-06-12 05:52:00.596073
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def test_to_lazy_success():
        assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    test_to_lazy_success()


# Generated at 2022-06-12 05:52:03.171291
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def _value():
        return 'value'

    assert Lazy(_value) == Validation('value', []).to_lazy()

# Generated at 2022-06-12 05:52:06.902149
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:12.013944
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_validation import Validation
    from pymonet.lazy import Lazy

    v = Validation(10, [])
    assert v.to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:52:16.539472
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:22.443337
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:52:26.730223
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # When
    lazy = Validation.success(2).to_lazy()

    # Then
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 2


# Generated at 2022-06-12 05:52:33.687187
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import compose

    lazy = Validation.success(4).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 4

    lazy = compose(
        lambda value: Validation.success(value * 2),
        lambda value: Validation.success(value + 3)
    )
    assert isinstance(lazy, Lazy)
    assert lazy.get() == Validation.success(12)


# Generated at 2022-06-12 05:52:39.585393
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    def _to_lazy(monad):
        return monad.to_lazy()
    _to_lazy.__name__ = 'to_lazy'

    ut.check_monad_law_identity(_to_lazy, Validation.success)
    ut.check_monad_law_composition(_to_lazy, Validation.success)

# Generated at 2022-06-12 05:52:49.882058
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryException
    from pymonet.either import Left

    def f(a):
        return Try(a * 10)

    validation = Validation.success(10)
    lazy = validation.to_lazy()
    lazy2 = lazy.fmap(f)
    assert type(lazy2.get()) == Try
    assert lazy2.get().get_or(None) == 100

    validation = Validation.success('str')
    lazy = validation.to_lazy()
    lazy2 = lazy.fmap(f)
    assert type(lazy2.get()) == Try
    assert lazy2.get().get_or(None) == TryException

    validation = Validation.fail

# Generated at 2022-06-12 05:52:51.940810
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-12 05:52:56.815855
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:08.738877
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(20.1).to_lazy() == Lazy(lambda: 20.1)
    assert Validation.success([10, 20]).to_lazy() == Lazy(lambda: [10, 20])
    assert Validation.success((10, 20)).to_lazy() == Lazy(lambda: (10, 20))

# Generated at 2022-06-12 05:53:13.057573
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    try_ = Try.success(1)
    validation = Validation.success(try_)
    lazy = validation.to_lazy()
    assert(isinstance(lazy, Lazy))
    assert(lazy.value() == try_)


# Generated at 2022-06-12 05:53:15.980893
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:53:22.125781
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Setup
    success = Validation.success('correct')
    fail = Validation.fail([])

    # Exercise & Verify
    assert success.to_lazy() == Lazy(lambda: 'correct')
    assert fail.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:26.714025
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    unit = Validation.success(1)
    lazy = Lazy(lambda: 1)
    assert unit.to_lazy() == lazy

    unit = Validation.fail(['error'])
    lazy = Lazy(lambda: None)
    assert unit.to_lazy() == lazy


# Generated at 2022-06-12 05:53:32.942003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_box import Box
    from pymonet.monad_lazy import Lazy

    # Create Validation
    validation = Validation.success(Maybe.just(Box(Lazy(lambda: 10))))
    assert validation.to_lazy() == Lazy(lambda: Maybe.just(Box(Lazy(lambda: 10))))


# Generated at 2022-06-12 05:53:37.251947
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 42).to_validation() == Validation.success(42)


# Generated at 2022-06-12 05:53:39.677991
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:53:41.590199
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().eval() == 1


# Generated at 2022-06-12 05:53:46.442212
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(20)
    lazy = validation.to_lazy()

    assert lazy == Lazy(lambda: 20)

    validation = Validation.fail([])
    lazy = validation.to_lazy()

    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:52.704468
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    x = 1
    y = 2
    assert Validation.success(x).to_lazy() == Lazy(lambda: x)
    assert Validation.fail(y).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:56.532277
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet import Validation
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:02.775910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    is_valid_number = lambda x: x if isinstance(x, int) else None
    is_even = lambda x: x if x % 2 == 0 else None

    validation = Validation.success(5)
    validation = validation.map(is_valid_number)
    validation = validation.map(is_even)

    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.to_lazy().unsafe_evaluate() == None


# Generated at 2022-06-12 05:54:06.415024
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail(['some error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:11.901608
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    result = Validation.success(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 1

    result = Validation.success().to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() is None


# Generated at 2022-06-12 05:54:15.400296
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(1).to_lazy()
    assert lazy == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:24.382906
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: Try(10)).to_lazy() == Lazy(lambda: Try(10))
    assert Lazy(lambda: Try(10, is_success=False)).to_lazy() == Lazy(lambda: Try(10, is_success=False))

# Generated at 2022-06-12 05:54:32.387766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy.
    """
    from pymonet.lazy import Lazy

    # Test for success validation
    validation = Validation.success(1)
    result = validation.to_lazy()
    assert isinstance(result, Lazy)
    assert result.get_value() == 1

    # Test for fail validation
    validation = Validation.fail([1, 2])
    result = validation.to_lazy()
    assert isinstance(result, Lazy)
    assert result.get_value() is None



# Generated at 2022-06-12 05:54:36.079236
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
  from pymonet.lazy import Lazy
  from pymonet.monad_try import Try

  assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
  assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:40.729478
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(1)
    assert v.to_lazy() == Lazy(lambda: 1)

    v = Validation.fail()
    assert v.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:44.956662
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    # Given
    errors = [1, 2, 3]
    validation = Validation.fail(errors)
    # When
    lazy = validation.to_lazy()
    # Then
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:54.928434
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def compute_lazy_value():
        return 100

    success_validation = Validation.success(100)
    success_try = success_validation.to_try()

    assert isinstance(success_try, Try)
    assert success_try.is_success()
    assert success_try.get_value() == 100

    lazy = success_validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == 100

    assert success_try.to_lazy() == lazy
    assert lazy() == compute_lazy_value()



# Generated at 2022-06-12 05:55:00.268491
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1) == (Validation.success(1).to_lazy())

    assert Lazy(lambda: None) == (Validation.fail(['error']).to_lazy())


# Generated at 2022-06-12 05:55:02.126020
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')


# Generated at 2022-06-12 05:55:10.669722
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Validation(123, []).to_lazy() == Lazy(lambda: 123)
    assert Validation('abc', []).to_lazy() == Lazy(lambda: 'abc')
    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    assert Validation(Try(123), []).to_lazy() == Lazy(lambda: Try(123))
    assert Validation(Try('abc'), []).to_lazy() == Lazy(lambda: Try('abc'))
    assert Validation(Try(None), []).to_lazy() == Lazy(lambda: Try(None))


# Generated at 2022-06-12 05:55:14.549249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: None) == Validation.success(None).to_lazy()
    assert Lazy(lambda: 'some string') == Validation.success('some string').to_lazy()
    assert Lazy(lambda: []).func() is None


# Generated at 2022-06-12 05:55:25.760908
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Assert that Validation.to_lazy return a Lazy monad with lambda returning the Validation value.
    """
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_try import Try

    try_value = Try('test', is_success=True)
    lazy_value = Lazy(lambda: 'test')
    validation_value = Validation.success('test')

    assert validation_value.to_lazy() == lazy_value
    assert validation_value.to_lazy().value() == try_value
    assert validation_value.to_lazy() == Validation.success('test').to_try().value().to_lazy()


# Generated at 2022-06-12 05:55:30.931568
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v = Validation.success(1)
    assert v.to_lazy() == Lazy(lambda: 1)
    v = Validation.fail([1])
    assert v.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:36.606569
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation.to_lazy method returning Lazy with function returning Validation value.
    """
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()
    assert lazy == Lazy(lambda: 10)


# Generated at 2022-06-12 05:55:40.137081
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 2)
    assert lazy.get() == 2


# Generated at 2022-06-12 05:55:44.430841
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-12 05:55:52.387409
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import identity, negate

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Validation.success("test").to_lazy() == Lazy(lambda: "test")
    assert Validation.success(identity).to_lazy() == Lazy(identity)
    assert Validation.fail("error").to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:01.868473
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.applicative_functor import ApplicativeFunctor
    from pymonet.monad import Monad
    from pymonet.monad_lazy import MonadLazy
    from pymonet.monad_try import MonadTry

    assert issubclass(Validation, Functor)
    assert issubclass(Validation, ApplicativeFunctor)
    assert issubclass(Validation, Monad)
    assert issubclass(Validation, MonadLazy)
    assert issubclass(Validation, MonadTry)
    assert Validation.success('foo').to_lazy().get() == 'foo'

# Generated at 2022-06-12 05:56:04.782477
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:56:08.167658
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_function():
        return "2"

    lazy = Validation.success(test_function).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == "2"


# Generated at 2022-06-12 05:56:13.691274
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    # 1. Set up
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # 2. Exercise
    result = Validation.success(1).to_lazy()

    # 3. Verify
    assert isinstance(result, Lazy)
    assert result.get() == 1

    # 4. Cleanup - none


# Generated at 2022-06-12 05:56:25.634017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_lazy import Lazy
    from pymonet.monad import Monad

    assert Maybe.just(5).to_lazy() == Lazy(lambda: Maybe.just(5).value)
    assert isinstance(Maybe.nothing().to_lazy(), Lazy)
    assert isinstance(Maybe.just(5).to_lazy(), Lazy)
    assert isinstance(Maybe.just(5).to_lazy(), Monad)


# Generated at 2022-06-12 05:56:27.920200
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)
    assert Validation.success(1).to_lazy() == lazy


# Generated at 2022-06-12 05:56:31.257495
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    assert Validation.success(Box(2)).to_lazy() == Lazy(lambda: Box(2))


# Generated at 2022-06-12 05:56:39.559226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def fn(value):
        return value

    assert Validation.success(1).to_lazy().unbox() == 1
    assert Validation.success(1).to_lazy().unbox() == 1
    assert fn(Validation.success(1).to_lazy().unbox()) == 1
    assert Validation.success(1).to_lazy().map(lambda x: x + 1).unbox() == 2
    assert Validation.success(1).to_lazy().flat_map(lambda x: Lazy(lambda: x + 1)).unbox() == 2


# Generated at 2022-06-12 05:56:44.897333
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.try_ import Try

    lazy = Validation.success(1).to_lazy()
    assert lazy.value() == 1

    assert Validation.fail([1]).to_lazy().value() == None
    assert Validation.fail([1]).to_lazy().to_try() == Try.fail(None)


# Generated at 2022-06-12 05:56:48.941356
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:54.149334
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.success(None).to_lazy().value() is None
    assert Validation.fail([1, 2]).to_lazy().value() is None

# Generated at 2022-06-12 05:56:58.040275
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = Validation.success(2)
    lazy = value.to_lazy()
    assert lazy.__class__ == Lazy
    assert lazy.value() == 2


# Generated at 2022-06-12 05:57:00.997459
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success("success").to_lazy() == Lazy("success")
    assert Validation.fail("fail").to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:57:03.777153
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def wrapper():
        return Validation.success(10)
    assert (Validation.success(10).to_lazy() == Lazy(wrapper))


# Generated at 2022-06-12 05:57:13.155172
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(10).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:17.124272
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # validation = Try.success(1)
    # lazy = validation.to_lazy()

    # assert isinstance(lazy, Lazy)
    # assert lazy.eval() == 1
    pass



# Generated at 2022-06-12 05:57:26.542486
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def f():
        return 'test'
    lazy_value = Lazy(f)
    validation_value = Validation('test', [])

    assert lazy_value == validation_value.to_lazy()

    validation_fail = Validation(None, [1])
    assert isinstance(validation_fail.to_lazy(), Lazy)
    assert validation_fail.to_lazy().force_value() is None

    try_success = validation_value.to_try()
    assert isinstance(try_success, Try)
    assert validation_value.value == try_success.force_value()

    try_failure = validation_fail.to_try()
    assert isinstance(try_failure, Try)
   

# Generated at 2022-06-12 05:57:34.161486
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Validation.success(42).to_lazy(), Lazy)
    assert Validation.success(42).to_lazy().call() == 42
    assert Validation.success(42).to_lazy().is_success is True
    assert Validation.fail(['Error ocurred']).to_lazy().call() is None
    assert Validation.fail(['Error ocurred']).to_lazy().is_success is False



# Generated at 2022-06-12 05:57:37.966519
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def fn():
        return True

    lazy = Validation.success(fn).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy == Lazy(fn)


# Generated at 2022-06-12 05:57:42.366910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:44.869569
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:47.113814
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(42)
    assert validation.to_lazy() is Lazy(lambda: 42)

# Generated at 2022-06-12 05:57:52.588214
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.fail(['error1', 'error2']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:57:56.644349
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def get_val():
        return 3
    assert Validation.success(get_val()).to_lazy().eval() == 3
    assert Validation.fail([None]).to_lazy().eval() is None



# Generated at 2022-06-12 05:58:06.592410
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().evaluate() == 1
    assert Validation.fail([1]).to_lazy().evaluate() is None

# Generated at 2022-06-12 05:58:08.717331
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(90).to_lazy()
    assertLazy(lazy, 90)



# Generated at 2022-06-12 05:58:12.049261
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'result')
    validation = Validation.success('result')

    assert validation.to_lazy() == lazy



# Generated at 2022-06-12 05:58:15.332088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:58:22.966676
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad import Identity
    from pymonet.monad_try import Failure, Success
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(Identity(1)).to_lazy() == Lazy(lambda: Identity(1))
    assert Validation.fail(Exception('Error')).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:28.532591
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It trasforms Validation to Lazy monad.

    It returns Lazy with function returning Validation value.
    """
    def lazy_function():
        return "Lazy"

    assert Validation.success(lazy_function).to_lazy() == Lazy(lazy_function)


# Generated at 2022-06-12 05:58:31.644367
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy().eval() == 5
    assert Validation.fail([]).to_lazy().eval() is None
