

# Generated at 2022-06-12 05:48:39.592231
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.fail(['error'])
    assert val.to_lazy() == Lazy(lambda: None)

    val = Validation.success(4)
    assert val.to_lazy() == Lazy(lambda: 4)


# Generated at 2022-06-12 05:48:43.020540
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:48:49.367506
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_validation = Validation(value='success')

    assert success_validation.to_lazy() == Lazy(lambda: 'success')

    failure_validation = Validation(value='failure', errors=['error'])

    assert failure_validation.to_lazy() == Lazy(lambda: 'failure')

# Generated at 2022-06-12 05:48:53.940930
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def divide(numerator, denominator):
        if denominator == 1:
            return Validation.success(1)
        return Validation.fail(["Division by zero."])

    assert divide(1, 1).to_lazy() == Lazy(lambda: 1)
    assert divide(1, 2).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:59.035423
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    valid = Validation.success(True)
    lazy = valid.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == True


# Generated at 2022-06-12 05:49:06.244432
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    @Lazy
    def return_2():
        return 2
    @Lazy
    def return_4():
        return 4

    validation = Validation.success(return_2())
    validation2 = Validation.success(return_4())
    assert validation.to_lazy() + validation2.to_lazy() == Try((2 + 4), is_success=True)

# Generated at 2022-06-12 05:49:14.096859
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Test successful Validation
    test_value = 'some value'
    test_validation = Validation.success(test_value)
    lazy_monad = test_validation.to_lazy()
    assert lazy_monad.force() == test_validation.value

    # Test failed Validation
    test_validation = Validation.fail()
    lazy_monad = test_validation.to_lazy()
    assert lazy_monad.force() == test_validation.value



# Generated at 2022-06-12 05:49:18.803634
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:21.995156
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test validation to lazy"""
    from pymonet.either import Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    right = Validation.success(1)
    assert right.to_lazy() == Lazy(lambda: 1)

    right = Validation.fail([1, 2])
    assert right.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:24.458301
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()

# Generated at 2022-06-12 05:49:29.862988
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return 2 + 2

    lazy = Validation.success(2).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy == Lazy(lambda: 2)


# Generated at 2022-06-12 05:49:31.909264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation(1, [])
    assert validation.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:49:33.839863
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:49:36.113048
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('alpha').to_lazy().get() == 'alpha'
    assert Validation.fail(['beta']).to_lazy().get() is None


# Generated at 2022-06-12 05:49:40.836250
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Validation[A, E] => Lazy[Function() ->  A | None]
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:45.126841
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    value = Validation.success(123)
    assert value.to_lazy() == Lazy(lambda: 123)
    value = Validation.fail(['Error'])
    assert value.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:53.490173
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import MonadTry

    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.unwrap() == 1

    validation = Validation.fail(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.unwrap(), MonadTry)
    assert lazy.unwrap().is_fail()
    assert lazy.unwrap().get_exception() == 1

# Generated at 2022-06-12 05:49:58.051181
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:01.041904
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)



# Generated at 2022-06-12 05:50:06.422566
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success('qwerty').to_lazy() == Lazy(lambda: 'qwerty')
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:11.729017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)

    lazy_validation = validation.to_lazy()

    assert lazy_validation.get() == 1


# Generated at 2022-06-12 05:50:14.504266
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    a = 10
    v = Validation.success(a)
    l = v.to_lazy()
    assert l._value == a
    assert l.value == a

# Generated at 2022-06-12 05:50:23.451149
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_test import MonadTest, unit_test

    # Unit test for lazy monad
    unit_test(
        expected=True,
        to_test=Lazy(lambda: Validation.success(2).to_lazy().eval()).eval().is_success()
    )

    # Unit test for lazy monad
    unit_test(
        expected=2,
        to_test=Lazy(lambda: Validation.success(2).to_lazy().eval()).eval().value
    )

    # Unit test for lazy monad
    unit_test(
        expected=False,
        to_test=Lazy(lambda: Validation.fail([2]).to_lazy().eval()).eval().is_success()
    )

    # Unit test for lazy monad

# Generated at 2022-06-12 05:50:31.402276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method Validation.to_lazy.
    """
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy

    lazy_monad = Monad.do(lambda: Validation.success(1)
                                    .to_lazy()
                                    .bind(lambda x: Lazy(lambda: x + 1))
                                    .bind(lambda x: Lazy(lambda: x + 1)))

    assert lazy_monad == Lazy(lambda: 3)


# Generated at 2022-06-12 05:50:34.256468
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:50:36.858764
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()

# Generated at 2022-06-12 05:50:49.285187
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def validate_age(value):
        if isinstance(value, dict):
            if 'age' in value.keys():
                age = value['age']
                if isinstance(age, int) and age >= 0:
                    return Validation.success()
                return Validation.fail(['age must be int and >= 0'])
            return Validation.fail(['age not in dict'])
        return Validation.fail(['value must be dict'])

    from pymonet.lazy import Lazy

    def validate(value):
        return validate_age(value).to_lazy().bind(Lazy(lambda: value))

    assert validate(dict(age=1)) == Lazy(lambda: dict(age=1))
    assert validate(dict(age=1)).lazy_value() == dict(age=1)

# Generated at 2022-06-12 05:50:53.316572
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:54.703421
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def _function():
        return 'value'

    validation = Validation('value', [])
    assert validation == validation.to_lazy()()

# Generated at 2022-06-12 05:50:59.158919
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('A')
    lazy = validation.to_lazy()
    assert lazy.value() == 'A'


# Generated at 2022-06-12 05:51:05.019110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def return_validation():
        from pymonet.validation import Validation
        return Validation.success(1)

    from pymonet.lazy import Lazy

    assert Lazy(return_validation) == Lazy(lambda: Validation.success(1))


# Generated at 2022-06-12 05:51:09.808448
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:15.220465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # When Validation doesn't have errors it's converted to value
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

    # When Validation has errors it's converted to None
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:51:21.242952
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert lazy(lambda: Validation.success(4)).map(lambda val: val + 3).value == 7
    assert lazy(lambda: Validation.success(4)).bind(lambda val: lazy(lambda: val + 1)).value == 5
    assert lazy(lambda: Validation.fail([1, 2, 3])).map(lambda val: val + 3).value is None
    assert lazy(lambda: Validation.fail([1, 2, 3])).bind(lambda val: lazy(lambda: val + 1)).value is None

# Generated at 2022-06-12 05:51:25.857529
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Validation to Lazy Unit Test.
    """
    from pymonet.lazy import Lazy

    value = Lazy(lambda: 1).to_validation(lambda: [])
    assert value.to_lazy() == Lazy(lambda: value.value)


# Generated at 2022-06-12 05:51:28.100910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        pass

    assert Validation.fail(errors=[1, 2]).to_lazy() == Lazy(f)

# Generated at 2022-06-12 05:51:35.603973
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation = Validation.success('test')
    try_ = validation.to_try()
    assert isinstance(try_, Try)
    assert isinstance(try_.get_or_else(None), str)

    validation = Validation.fail(['Something went wrong'])
    try_ = validation.to_try()
    assert isinstance(try_, Try)
    assert try_.get_or_else(None) is None


# Generated at 2022-06-12 05:51:37.506825
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:51:41.362981
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)

    succ = Validation.success(1)
    assert succ.to_lazy() == lazy

    fail = Validation.fail([])
    assert fail.to_lazy() == lazy


# Generated at 2022-06-12 05:51:43.117225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    assert Validation.success(1).to_lazy().get() == 1


# Generated at 2022-06-12 05:51:50.343952
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    val = Validation.success(10)
    assert val.to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 05:51:53.362777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Lazy(lambda: 2).evaluate() == Validation.success(2).to_lazy().evaluate()

# Generated at 2022-06-12 05:51:56.386028
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation(1, [])
    result_lazy = validation.to_lazy()
    assert result_lazy.value == 1


# Generated at 2022-06-12 05:52:01.919265
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success('some value').to_lazy() == Lazy(lambda: 'some value')
    assert Validation.fail(['some error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:04.436668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    lazy = Validation.success("test").to_lazy()

    assert lazy.value() == "test"


# Generated at 2022-06-12 05:52:07.483721
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    validation = Validation.fail(['True', 'False'])
    from pymonet.lazy import Lazy

    assert validation.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:52:13.818562
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:23.553428
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    t = Validation.success(12)
    assert t.to_lazy() == Lazy(get=12)
    assert type(t.to_lazy().get()) == int
    assert t.to_lazy().get() == 12

    f = Validation.fail([1])
    assert f.to_lazy() == Lazy(get=None)
    assert type(f.to_lazy().get()) == type(None)
    assert f.to_lazy().get() == None

# Unit tests for method to_try of class Validation

# Generated at 2022-06-12 05:52:27.773818
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    lazy = validation.to_lazy()
    assert callable(lazy.value)
    assert validation.value == lazy.value()


# Generated at 2022-06-12 05:52:32.234617
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'Lazy value'

    assert Validation.success(Lazy(f)).to_lazy() == Lazy(f)
    assert Validation.fail(['Lazy error']).to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:52:39.262548
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    res = Validation.success(1).to_lazy()
    assert res == Lazy(lambda: 1)
    assert res.get() == 1
    assert Validation.fail(1).to_lazy().get() is None

# Generated at 2022-06-12 05:52:44.692244
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success().to_lazy()
    assert lazy == Lazy(None)

    lazy = Validation.fail().to_lazy()
    assert lazy == Lazy(None)

    lazy = Validation.success(1).to_lazy()
    assert lazy == Lazy(1)

    lazy = Validation.fail([1]).to_lazy()
    assert lazy == Lazy(None)



# Generated at 2022-06-12 05:52:49.314234
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1


# Generated at 2022-06-12 05:52:51.590942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:53:00.948503
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import do_monad
    from pymonet.functor import fmap
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    @do_monad(Validation)
    def test_monad():
        a = yield Validation.success(1)
        b = yield Validation.success(2)
        raise StopIteration(a + b)

    assert isinstance(test_monad().to_lazy(), Lazy)

    def add(value):
        return Validation.success(value + 1)

    def add2(value):
        return Validation.success(value + 2)

    lazy_function = Lazy(lambda: 2)

    assert Validation.success(2).to_lazy() == lazy_function

# Generated at 2022-06-12 05:53:12.683933
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def to_lazy(x):
        return Lazy(lambda: x)

    validation = Validation(1, []).to_lazy()
    assert validation.value() == 1

    validation = Validation.success(1).to_lazy()
    assert validation.value() == 1

    validation = Validation.fail([]).to_lazy()
    assert validation.value() is None

    validation = Validation.fail([1, 2]).to_lazy()
    assert validation.value() is None

    validation = Validation.success(1).to_lazy()
    assert validation.value() == 1

    validation = Validation.fail([1, 2]).to_lazy()
    assert validation.value() is None


# Generated at 2022-06-12 05:53:15.381909
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail(1).to_lazy().value() == None


# Generated at 2022-06-12 05:53:20.452651
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:23.116122
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation(1, [])
    assert isinstance(validation.to_lazy(), Lazy)


# Generated at 2022-06-12 05:53:25.589460
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    expected_lazy = Lazy(lambda: 'hello')
    validation = Validation('hello', None)
    lazy = validation.to_lazy()
    assert expected_lazy == lazy


# Generated at 2022-06-12 05:53:39.107405
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """

    from pymonet.lazy import Lazy

    lazy_monad = Validation.success('Satoshi Nakamoto').to_lazy()

    assert isinstance(lazy_monad, Lazy)
    assert lazy_monad.value == 'Satoshi Nakamoto'
    assert lazy_monad.is_eager is True


# Generated at 2022-06-12 05:53:44.020374
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(10) == Validation.success(10).to_lazy()
    assert Lazy(Try(10, is_success=True)) == Validation.success(10).to_lazy().map(lambda x: Try(x, is_success=True))



# Generated at 2022-06-12 05:53:47.238374
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:49.884830
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(1)


# Generated at 2022-06-12 05:53:54.190342
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(2)
    assert val.to_lazy().evaluate() == 2

    val = Validation.fail(['error'])
    assert val.to_lazy().evaluate() is None


# Generated at 2022-06-12 05:53:59.276971
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    Validation.success(4).to_lazy().value() == 4


# Generated at 2022-06-12 05:54:04.283567
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return Validation.success(100)

    lazy = Validation.success(100).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 100

    lazy = Validation.fail([100, 200]).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() is None


# Generated at 2022-06-12 05:54:07.822926
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    box = Box('string')
    assert box.to_lazy() == Lazy(lambda: 'string')

    try_ = Try(1)
    assert try_.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:12.576717
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def do_increment(value): return value + 1
    validation = Validation.success(Lazy(lambda: 1)).map(do_increment)
    assert validation.to_lazy().force() == Lazy.pure(2)



# Generated at 2022-06-12 05:54:15.305436
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == \
        Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:36.379353
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    VALIDATION = Validation.success(5)
    assert VALIDATION.to_lazy() == Lazy(lambda: 5)
    assert VALIDATION.to_lazy() == Lazy(lambda: Try(5, is_success=True))


# Generated at 2022-06-12 05:54:40.087119
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    Validation.success(10).to_lazy() == Lazy(lambda: 10)
    Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:43.919850
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 05:54:51.098307
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert validation.value == lazy.value()

    validation = Validation.fail()
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert validation.value == lazy.value()

# Generated at 2022-06-12 05:54:54.481694
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('test')

    assert validation.to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-12 05:54:58.578799
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success(2)

    l = v.to_lazy()
    assert l.value() == 2

    l = v.to_lazy()
    assert l.value() == 2

# Generated at 2022-06-12 05:55:00.836104
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    basis = Validation.success('2')
    assert '2' == basis.to_lazy().get()



# Generated at 2022-06-12 05:55:05.139740
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: Validation.fail()) == Try.fail()
    assert Lazy(lambda: Validation.success(1)) == Try.successful(1)

# Generated at 2022-06-12 05:55:08.980035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['test']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:12.139944
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(1, []).to_lazy() == Lazy.of(1)


# Generated at 2022-06-12 05:55:32.328220
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1, 2]).to_lazy()

# Generated at 2022-06-12 05:55:39.185185
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Lazy(lambda: Try.success(True)) == Validation.success(True).to_lazy()
    assert Lazy(lambda: Try.fail(ValueError())) == Validation.fail([ValueError()]).to_lazy()


# Generated at 2022-06-12 05:55:42.267242
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('a')
    assert validation.to_lazy() == Lazy(lambda: 'a')
    assert validation.to_lazy().value() == 'a'


# Generated at 2022-06-12 05:55:51.959257
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()
    assert Lazy(lambda: 'a') == Validation.fail(['err']).to_lazy()

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()
    assert Lazy(lambda: 'a') == Validation.fail(['err']).to_lazy()


# Generated at 2022-06-12 05:55:54.384577
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:55:59.586996
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    valid = Validation.success("some")
    lazy = valid.to_lazy()

    assert lazy == Lazy(lambda: "some")


# Generated at 2022-06-12 05:56:08.678391
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Validation.success(1).to_lazy()

    assert isinstance(lazy, Lazy)

    assert lazy() == 1

    lazy = Validation.success(1).to_lazy()
    lazy_map = lazy.map(lambda a: a + 2)

    assert isinstance(lazy_map, Lazy)
    assert lazy_map() == 3

    lazy_flat_map = lazy.flat_map(lambda a: Try(a + 2))

    assert isinstance(lazy_flat_map, Lazy)
    assert lazy_flat_map() == 3

    lazy_flat_map = lazy_map.flat_map(lambda a: Try(a + 2))


# Generated at 2022-06-12 05:56:16.621748
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """

    def test_function():
        """
        This function is used in Validation.to_lzy tests.
        """
        return 'the value'

    v_success = Validation.success('the value')
    v_fail = Validation.fail(['the error'])

    lazy_success = v_success.to_lazy()
    lazy_fail = v_fail.to_lazy()

    assert lazy_success.value == 'the value'
    assert lazy_fail.value is None
    assert lazy_success.get_value(test_function()) == 'the value'
    assert lazy_fail.get_value(test_function()) == 'the value'


# Generated at 2022-06-12 05:56:20.381148
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:29.874835
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation."""

    # Success case
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)

    # Fail case
    assert Validation.fail([10, 5]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([0, 4, 1]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:49.422058
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    print('test_Validation_to_lazy')

    value = 12
    lazy = Validation.success(value).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == value


# Generated at 2022-06-12 05:56:57.506294
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.iterable import iterable_to_string

    assert Lazy(lambda: 5) == Validation(5, []).to_lazy()
    assert Lazy(lambda: iterable_to_string([1, 2, 3])) == Validation(iterable_to_string([1, 2, 3]), []).to_lazy()



# Generated at 2022-06-12 05:57:01.044317
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:57:07.435113
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    try:
        expected = Lazy(lambda: Box(Try(42)))
        assert Validation.success(Box(Try(42))).to_lazy() == expected
    except AssertionError:
        print("test_Validation_to_lazy: Failed")
        raise AssertionError

    print("test_Validation_to_lazy: Success")


# Generated at 2022-06-12 05:57:11.576323
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'success') == Validation.success('success').to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['error']).to_lazy()


# Generated at 2022-06-12 05:57:15.280111
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:18.052165
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validate = Validation.success(10).to_lazy()
    assert isinstance(validate, Lazy)

    assert validate.value() == 10


# Generated at 2022-06-12 05:57:20.718946
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    fn = lambda v: Validation(v, v)
    result = Validation.success(42).to_lazy().flat_map(fn).value()

    assert result == Validation(42, 42)



# Generated at 2022-06-12 05:57:23.816220
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def call():
        from pymonet.lazy import Lazy

        def function():
            return 42

        return Validation.success(Lazy(function)).to_lazy().run()

    assert call() == 42


# Generated at 2022-06-12 05:57:29.800804
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """

    # WHEN
    lazy = Validation.success(10).to_lazy()

    # THEN
    assert lazy.get() == 10

    # WHEN
    lazy = Validation.fail(10).to_lazy()

    # THEN
    assert lazy.get() == None


# Generated at 2022-06-12 05:58:11.662636
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    result = Validation.success('a').to_lazy()
    assert isinstance(result, Lazy)
    assert result.force() == 'a'

    result = Validation.fail(['error1']).to_lazy()
    assert isinstance(result, Lazy)
    assert isinstance(result.force(), Try)
    assert result.force().is_fail()
    assert result.force().is_success() == False
    assert result.force().get_errors() == ['error1']


# Generated at 2022-06-12 05:58:15.329797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monads import Lazy#, Try

    assert Validation.success(7).to_lazy() == Lazy(lambda: 7)
    assert Validation.fail(None).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:58:20.013074
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_success = Validation(15, [])
    lazy = validation_success.to_lazy()
    assert lazy.get() == 15

    validation_fail = Validation(None, ['error'])
    lazy = validation_fail.to_lazy()
    assert lazy.get() == None


# Generated at 2022-06-12 05:58:25.379514
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # Testing method to_lazy from Validation
    test1 = Validation.success(10)
    assert test1.to_lazy() == Lazy(lambda: 10)
    assert test1.to_lazy().value() == 10

    test2 = Validation.fail(['Error1', 'Error2'])
    assert test2.to_lazy() == Lazy(lambda: None)
    assert test2.to_lazy().value() is None


# Generated at 2022-06-12 05:58:36.079695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy


    def add5(x):
        return x + 5


    def add3(x):
        return x + 3

    vs = Validation.success(5)
    vf = Validation.fail([])
    ls = Lazy(lambda: 5)
    lf = Lazy(lambda: 5/0)
    assert vs.to_lazy() == ls
    assert vf.to_lazy() == lf
    assert vf.to_lazy().map(add3).map(add5).eval() == 10
    assert vs.to_lazy().map(add3).map(add5).eval() == add5(add3(5))
