

# Generated at 2022-06-12 05:48:37.712257
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'a') == Validation.success('a').to_lazy()


# Generated at 2022-06-12 05:48:40.322641
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    assert validation.to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:48:46.034301
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy(lambda: 5)
    validation = Validation.fail(['error1'])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:53.068116
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Successfully Validation
    def successful_Validation():
        return Validation.success(100)

    validation = Validation(100, [])
    assert (validation.to_lazy() == Lazy(successful_Validation))

    # Failed Validation
    def failed_Validation():
        return Validation(None, ['1'])

    validation = Validation(None, ['1'])
    assert (validation.to_lazy() == Lazy(failed_Validation))


# Generated at 2022-06-12 05:48:59.840895
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success('hello').to_lazy()
    assert lazy.is_equal(Lazy(lambda: 'hello'))
    assert lazy.get() == 'hello'

    lazy = Validation.success('hello').to_lazy()
    assert lazy.is_equal(Lazy(lambda: 'hello'))
    assert lazy.get() == 'hello'


# Generated at 2022-06-12 05:49:07.572442
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test to check Validation.to_lazy method.

    :returns: nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    validation_1 = Validation.success(10)
    assert validation_1.to_lazy() == Lazy(lambda: 10)

    validation_2 = Validation.fail(['error'])
    assert validation_2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:16.071613
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def div(a, b):
        if b == 0:
            return Validation.fail(["Can't divide by 0"])
        return Validation.success(a / b)

    assert Validation.success(2).to_lazy().eval() == 2
    assert Validation.fail(["Division by 0"]).to_lazy().eval() is None

    assert div(5, 2).to_lazy().eval() == 2.5
    assert div(5, 0).to_lazy().eval() is None


# Generated at 2022-06-12 05:49:22.243551
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.seq import Seq

    def f():
        return 123

    lazy_123 = Lazy(f)
    validation = Validation.success(lazy_123)
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.get().get() == 123

# Generated at 2022-06-12 05:49:26.794546
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation

    :return: no value
    :rtype: None
    """
    assert Validation.success(200).to_lazy().value() == 200
    assert Validation.fail().to_lazy().value() is None


# Generated at 2022-06-12 05:49:34.803986
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.exceptions import MonetException
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)

    def throws_exception():
        raise MonetException('MonetException')

    assert Validation.success(10).to_lazy().fmap(throws_exception).value == Lazy(lambda: None)
    assert Validation.success(10).to_lazy().fmap(throws_exception).exc == MonetException('MonetException')

    def throws_exception():
        raise MonetException('MonetException')


# Generated at 2022-06-12 05:49:41.177756
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    add_1_or_error = lambda v: Validation.success(v + 1) if type(v) is int else Validation.fail(['error'])
    add_1 = Validation.success(1).map(add_1_or_error)

    assert Validation.success(2).to_lazy().value() == add_1.to_lazy().value()

# Generated at 2022-06-12 05:49:48.250008
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success()
    assert success.to_lazy() == Lazy(lambda: None)

    success = Validation.success(5)
    assert success.to_lazy() == Lazy(lambda: 5)

    success = Validation.fail([])
    assert success.to_lazy() == Lazy(lambda: None)

    success = Validation.fail([Exception()])
    assert success.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:50.431035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(3).to_lazy()
    assert callable(result.value)
    assert result.value() == 3

# Generated at 2022-06-12 05:49:55.414297
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_lazy import Lazy

    assert Validation.success(Maybe.just(2)).to_lazy() == Lazy(lambda: Maybe.just(2))
    assert Lazy(lambda: Validation.success(Maybe.just(2))).get() == Lazy(lambda: Maybe.just(2))

# Generated at 2022-06-12 05:50:01.395821
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:05.281125
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def fn():
        print('lazy')
        return 'lazy'

    validation = Validation.success(fn)

    assert validation.to_lazy() == Lazy(fn)


# Generated at 2022-06-12 05:50:13.342718
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success('success')
    failure = Validation.fail(['failure'])

    success_lazy = success.to_lazy()
    failure_lazy = failure.to_lazy()

    assert isinstance(success_lazy, Lazy)
    assert isinstance(failure_lazy, Lazy)

    assert success_lazy.value() == 'success'
    assert failure_lazy.value() is None


# Generated at 2022-06-12 05:50:17.728397
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(2)
    assert v.to_lazy() == Lazy(lambda: 2)

    v = Validation.success()
    assert v.to_lazy() == Lazy(lambda: None)

    v = Validation.fail([])
    assert v.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:24.662411
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    from pymonet.class_methods import apply_to_all_methods

    def test_to_lazy(fn, value, is_success, expected):
        """
        Unit test for method to_lazy of class Validation

        :param fn: function to test
        :type fn: A -> Validation[A, List[E]]
        :params value: value to test
        :type value: A
        :params is_success: True for success validation and False for fail validation
        :type is_success: Boolean
        :params expected: expected result
        :type expected: A
        :returns: True when test passed
        :rtype: Booelan
        """
        from pymonet.monad_try import Try

# Generated at 2022-06-12 05:50:29.296088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:35.041431
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:50:38.336944
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.get() == 10

# Generated at 2022-06-12 05:50:43.019526
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure, Success

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:48.155159
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:57.805537
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    maybe = Validation.success(1).to_lazy()
    assert maybe.eval() == Validation(1, []).value
    assert maybe.fmap(lambda x: x * 2).eval() == Validation(1, []).value * 2
    assert maybe.ap(lambda x: Validation.success(x * 2)).eval() == Validation(4, []).value
    assert maybe.bind(lambda x: Validation.success(x * 3)).eval() == Validation(3, []).value
    assert maybe.to_either().is_right()
    assert maybe.to_maybe().is_just()
    assert maybe.to_try() == Try(1, is_success=True)



# Generated at 2022-06-12 05:51:04.905044
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def value():
        return 'value'

    lazy = Validation.success(value).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.run() == value()

    lazy = Validation.fail().to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.run() is None


# Generated at 2022-06-12 05:51:08.557033
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert(Validation.success(5).to_lazy() == Lazy(Box(5)))



# Generated at 2022-06-12 05:51:15.981062
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def _to_lazy(value):
        return Validation.success(value).to_lazy()

    assert _to_lazy(100) == Lazy(lambda : 100)
    assert _to_lazy('value') == Lazy(lambda: 'value')
    assert _to_lazy([1, 2, 3]) == Lazy(lambda : [1, 2, 3])
    assert _to_lazy({'x': 1, 'y': 2}) == Lazy(lambda: {'x': 1, 'y': 2})


# Generated at 2022-06-12 05:51:23.044730
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    def assert_equals(lhs, rhs):
        """
        Unit testing function.
        """
        assert lhs == rhs, "{} != {}".format(lhs, rhs)

    # Successful Validation
    success_lazy = Validation.success(10).to_lazy()
    assert_equals(10, success_lazy.value)

    # Failed Validation
    fail_lazy = Validation.fail(['some error']).to_lazy()
    assert_equals(None, fail_lazy.value)


# Generated at 2022-06-12 05:51:28.344477
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tests for 'to_lazy' method of class Validation.
    """
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:37.682332
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(Validation.success(3).value) == Validation.success(3).to_lazy()
    assert Lazy(Validation.fail(['error']).value) == Validation.fail(['error']).to_lazy()

    assert Validation.success(3).to_lazy().value() == 3
    assert Validation.fail(['error']).to_lazy().value() == None


# Generated at 2022-06-12 05:51:39.573377
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('string').to_lazy() == Lazy(lambda: 'string')


# Generated at 2022-06-12 05:51:41.577047
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(4).to_lazy().get() == 4
    assert Validation.success(4).to_lazy().get() == 4


# Generated at 2022-06-12 05:51:46.683428
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['no access']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:51:51.095134
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation(10, []).to_lazy() == Lazy(lambda: 10) and \
           Validation(None, [10, 20]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:55.339822
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success('Hello').to_lazy()
    assert 'Hello' == lazy.strict()

    lazy = Validation.fail().to_lazy()
    assert None == lazy.strict()



# Generated at 2022-06-12 05:52:01.967549
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Success, Failure

    try_ = Success(1)
    validation = Validation.fail()
    validation_ = validation.to_try()
    assert try_ == validation_

    try_ = Failure(None)
    validation = Validation.success()
    validation_ = validation.to_try()
    assert try_ == validation_


# Generated at 2022-06-12 05:52:04.479237
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy().value() == 1


# Generated at 2022-06-12 05:52:11.539112
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    def _throw():
        raise ValueError('error')

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:16.812112
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy()  == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:24.785737
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Validation.success
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    # Validation.fail
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:27.687471
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy().value() == 1
    assert Validation(1, ['error']).to_lazy().value() == 1


# Generated at 2022-06-12 05:52:32.478626
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:37.959898
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.success([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:45.676902
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    # id = -1

    def fail_lazy_mapper():
        # global id
        # id += 1
        # print('it is bad')
        raise Exception('it is bad')

    validation = Validation.success()
    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.map(lambda x: 'a').to_lazy() == Lazy(lambda: 'a')

    validation = Validation.fail(['error 1', 'error 2'])
    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.map(lambda x: 'a').to_lazy() == Lazy(lambda: None)

    validation = Validation.success(42)
    assert validation.to_

# Generated at 2022-06-12 05:52:53.527902
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that method to_lazy of Validation class converted Validation to Lazy.

    :returns: None
    :rtype: None
    """

    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success('test').to_lazy() != Try('test').to_lazy()
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.success('test').to_lazy() != Lazy(lambda: None)
    assert Validation.success('test').to_lazy() != Lazy(lambda: 'test again')


# Generated at 2022-06-12 05:52:56.864378
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that to_lazy convert Validation value to function that returns stored value.
    """

    assert Validation.success('abc').to_lazy() == Lazy(lambda: 'abc')

# Generated at 2022-06-12 05:52:59.007194
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:07.854190
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['test']).to_lazy() == Lazy(lambda: None)

if __name__ == '__main__':  # pragma: no cover
    test_Validation_to_lazy()

# Generated at 2022-06-12 05:53:11.058807
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    value = 'test value'
    validation = Validation.success(value)

    # When
    result = validation.to_lazy()

    # Then
    assert result() == value


# Generated at 2022-06-12 05:53:21.005839
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Box(14).to_lazy() == Lazy(lambda: 14)
    assert Box(None).to_lazy() == Lazy(lambda: None)
    assert Try(14).to_lazy() == Lazy(lambda: 14)
    assert Try(None).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:53:24.021553
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert validate('aaaa') == Lazy(lambda: 'aaaa')
    assert validate(None) == Lazy(lambda: None)



# Generated at 2022-06-12 05:53:27.114762
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation_monad = Validation.success(100)
    lazy_monad = validation_monad.to_lazy()

    assert lazy_monad.get() == 100, "Unit test for method to_lazy of class Validation failed."


# Generated at 2022-06-12 05:53:32.086612
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:36.063602
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:37.908633
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(True)
    assert validation.to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-12 05:53:44.962811
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # define Validation with value
    val = Validation.success(5)
    # transform Validation to Lazy
    lazy_val = val.to_lazy()
    # evaluate Lazy
    res = lazy_val.eval()
    # create expected Lazy
    expected = Lazy(lambda: 5)
    # assert two Lazy are equal
    assert lazy_val == expected
    # assert Lazy value is 5
    assert res == Try.success(5)


# Generated at 2022-06-12 05:53:54.140341
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    value = 'value'
    f = lambda: value
    assert Try.from_fn(f   ) == Validation.from_fn(f   ).to_try()
    assert Try.from_fn(f, 1) == Validation.from_fn(f, 1).to_try()
    assert Lazy(f) == Validation.from_fn(f   ).to_lazy()
    assert Lazy(f) == Validation.from_fn(f, 1).to_lazy()


# Generated at 2022-06-12 05:53:57.461113
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().eval() == Validation.success(1).value
    assert Validation.fail().to_lazy().eval() == Validation.fail().value


# Generated at 2022-06-12 05:54:02.933213
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().map(lambda v: v + 1) == 2
    assert Validation.fail([1]).to_lazy().map(lambda v: v + 1) == 1
    assert Validation.success(1).to_lazy().map_try(lambda v: v / 0) == None
    assert Validation.fail([1]).to_lazy().map_try(lambda v: v / 0) == None


# Generated at 2022-06-12 05:54:07.585100
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['err1']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:19.208839
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tests Validation.to_lazy method
    """
    def to_lazy(val):
        """
        Function to test mapping to_lazy

        :params val: value to map
        :type val: A
        :returns: Lazy with function returning current val
        :rtype: Lazy[Function() -> (A | None)]
        """
        return val.to_lazy()

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:25.580628
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(True).map(lambda value: value).to_lazy().get()

    assert not Validation.fail([]).map(lambda value: value).to_lazy().get()

    assert Validation.success(False).map(lambda value: value).to_lazy().get()

    assert not Validation.fail([1, 2]).map(lambda value: value).to_lazy().get()



# Generated at 2022-06-12 05:54:31.198168
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    def something(param):
        return param * 2

    validation = Validation.success(1)

    # When
    lazy_result = validation.to_lazy()

    # Then
    assert isinstance(lazy_result, Lazy)
    assert lazy_result.get() == validation.value


# Generated at 2022-06-12 05:54:38.288834
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    assert Lazy(lambda: Validation.success(1).value) == Lazy(lambda: 1)
    assert Lazy(lambda: Validation.success(1).value) == Lazy(lambda: 1)
    assert Lazy(lambda: Validation.fail([1]).value) == Lazy(lambda: None)
    assert Lazy(lambda: Validation.fail([1]).value) == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:44.885019
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def no_errors_lazy():
        return Validation.success('test')

    def errors_lazy():
        return Validation.fail(['error'])

    from pymonet.lazy import Lazy

    # Success Validation
    assert Validation.success('test').to_lazy() == Lazy(no_errors_lazy)

    # Fail Validation
    assert Validation.fail(['error']).to_lazy() == Lazy(errors_lazy)


# Generated at 2022-06-12 05:54:52.635110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v1 = Validation.success(5)

    assert v1.to_lazy() == Lazy(lambda: 5)
    assert v1.to_lazy().value() == 5

    v2 = Validation.fail([0])

    assert v2.to_lazy() == Lazy(lambda: None)
    assert v2.to_lazy().value() is None


# Generated at 2022-06-12 05:54:55.000350
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    assert validation.to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:54:59.195472
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:03.985664
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:11.621516
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:55:22.404021
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def add_1(x):
        return x + 1

    def square(x):
        return x * x

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(10).to_lazy().apply(add_1).apply(square).get_value() == Try.success(121)
    assert Validation.fail([1, 2, 3]).to_lazy().apply(add_1).apply(square).get_value() == Try.fail([1, 2, 3])


# Unit tests for method to_try of class Validation

# Generated at 2022-06-12 05:55:23.560430
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(1)
    lazy = success.to_lazy()

    assert lazy.get() == 1

# Generated at 2022-06-12 05:55:30.382398
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:37.252472
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success().to_lazy() == Validation.success(None).to_lazy()
    assert Validation.success(1).to_lazy() == Validation.success(1).to_lazy()
    assert Validation.success(2).to_lazy() == Validation.success(2).to_lazy()

    assert Validation.fail().to_lazy() != Validation.fail([]).to_lazy()
    assert Validation.fail([1]).to_lazy() != Validation.fail([2]).to_lazy()
    assert Validation.fail([1]).to_lazy() != Validation.fail([1, 2]).to_lazy()

    assert Validation.success().to_lazy() != Validation.fail([]).to_lazy()


# Generated at 2022-06-12 05:55:39.936277
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:55:42.197308
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_function():
        return 1

    lazy = Validation.success(1).to_lazy()

    assert lazy.get() == test_function()



# Generated at 2022-06-12 05:55:49.315108
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import either_to_try

    lazy = Validation.success(1).to_lazy()
    assert lazy.value() == 1

    assert either_to_try(lazy.to_either()) == Try(1)

    lazy = Validation.fail([1, 2]).to_lazy()
    assert lazy.value() == None
    assert isinstance(lazy.to_either(), Left)


# Generated at 2022-06-12 05:55:56.483582
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    x = Validation.success(4)
    assert type(x.to_lazy()) is Lazy
    assert x.to_lazy() == Lazy(lambda: 4)

    x = Validation.fail('test')
    assert type(x.to_lazy()) is Lazy
    assert x.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:56:01.641450
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    assert Validation(True, []).to_lazy() == Lazy(lambda: True)
    assert Validation(False, []).to_lazy() == Lazy(lambda: False)
    assert Validation(None, []).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:56:13.521362
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def validation():
        return Validation(1, [])

    assert Validation.success(1).to_lazy().value() == validation().value



# Generated at 2022-06-12 05:56:19.157789
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:27.317656
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def fn(a):
        if a == 1:
            return 2
        return 1

    validation = Validation.success(2).to_lazy()

    assert isinstance(validation, Lazy)
    assert validation.lazy() == Validation.success(2)
    assert fn(validation.lazy().to_lazy().lazy()) == 1
    assert fn(validation.lazy().to_lazy().lazy()) == 1


# Generated at 2022-06-12 05:56:31.694832
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    assert List(None).to_try() == Try(None, is_success=False)
    assert List(1).to_try() == Try(1, is_success=True)


# Generated at 2022-06-12 05:56:41.151429
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def test_value_extract_from_lazy_for_validation_success():
        success_lazy = Validation.success(1).to_lazy()
        assert_that(success_lazy.call(), is_(equal_to(1)))

    def test_value_extract_from_lazy_for_validation_fail():
        fail_lazy = Validation.fail([]).to_lazy()
        assert_that(fail_lazy.call(), is_(equal_to(None)))

    test_value_extract_from_lazy_for_validation_success()
    test_value_extract_from_lazy_for_validation_fail()


# Generated at 2022-06-12 05:56:47.520693
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test unit methods to_lazy() of class Validation.
    """

    # Test with successful validation
    assert Validation.fail().to_try().is_success()
    # Test with failed validation
    assert Validation.success(10).to_try().is_success() is True
    assert Validation.success(10).to_try().get_value() == 10


# Generated at 2022-06-12 05:56:57.944268
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe

    assert Validation.success('hello').to_lazy().value() == 'hello'
    assert Validation.fail(1).to_lazy().value() is None

    assert Validation.success(2).to_lazy().to_try().is_success()
    assert Validation.fail(1).to_lazy().to_try().is_fail()

    assert Validation.success(2).to_lazy().to_maybe().is_just()
    assert Validation.fail(1).to_lazy().to_maybe().is_nothing()


# Generated at 2022-06-12 05:57:03.874934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success("some").to_lazy() == Lazy("some")
    assert Validation.success(None).to_lazy() == Lazy(None)
    assert Validation.fail("some").to_lazy() == Lazy(None)
    assert Validation.fail(["some"]).to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:57:08.250999
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def fail_validation():
        return Validation.fail(["message 1", "message 2"])

    def success_validation():
        return Validation.success(2)

    success_lazy = success_validation().to_lazy()
    assert success_lazy() == success_validation().value

    fail_lazy = fail_validation().to_lazy()
    assert fail_lazy() == fail_validation().value

# Generated at 2022-06-12 05:57:11.538535
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy
    lazy = Validation.success('one').to_lazy()
    assert pymonet.lazy.Lazy(lambda: 'one') == lazy


# Generated at 2022-06-12 05:57:22.389475
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 'ABC')
    monad = Validation.success(lazy)
    assert monad.to_lazy() == lazy


# Generated at 2022-06-12 05:57:24.974176
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail(["test"]).to_lazy() == Lazy(lambda: None)
    assert Validation.success([1]).to_lazy() == Lazy(lambda: [1])


# Generated at 2022-06-12 05:57:29.896516
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('Error').to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:57:40.030854
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import SuccessfulTry, FailedTry
    from pymonet.functions import curry

    assert Lazy(lambda: Validation.success(1)) == Validation.success(1).to_lazy()

    f = curry(lambda x, y: x + y)

    assert Lazy(lambda: SuccessfulTry(1).fmap(f(2))) == SuccessfulTry(1).fmap(f(2)).to_lazy()
    assert Lazy(lambda: FailedTry('error', is_success=False)).to_try() == FailedTry('error', is_success=False).to_lazy()


# Generated at 2022-06-12 05:57:44.793342
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_success = Validation.success(20)
    value = validation_success.to_lazy().get_value()
    assert value == 20

    validation_fail = Validation.fail([])
    value = validation_fail.to_lazy().get_value()
    assert value is None



# Generated at 2022-06-12 05:57:54.452780
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    def eq(a, b):
        if not isinstance(a, Validation):
            assert a == b
            return True
        return a == b

    assert_equal = partial(assert_that, custom_matcher=eq)

    assert_equal(Validation.success(2), Validation.success(2).to_lazy().value())
    assert_equal(Validation.fail([2]), Validation.fail([2]).to_lazy().value())

    assert_equal(Validation.fail([2]), Validation.success(2).to_lazy().failure())


# Generated at 2022-06-12 05:57:57.931838
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(1).to_lazy()
    assert lazy == Lazy(lambda: 1)


# Generated at 2022-06-12 05:58:00.160065
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def square(x):
        return x ** 2

    lazy = Validation.success(square).to_lazy()

    assert lazy.force() == square


# Generated at 2022-06-12 05:58:05.837832
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure, Success

    assert Lazy(lambda: 5) == Try.success(5).to_lazy()
    assert Lazy(lambda: ValueError) == (Try.failure(ValueError)
                                        .to_lazy())



# Generated at 2022-06-12 05:58:10.774586
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # empty error list validation
    value = Validation.success(10)
    assert value.to_lazy().get() == value.value
    assert value.value == 10

    # non empty error list validation
    value = Validation.fail([10, 20])
    assert value.to_lazy().get() == value.value
    assert value.value is None

# Generated at 2022-06-12 05:58:25.150887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def fn1(a):
        return a

    def fn2(a):
        return a

    # function Lazy(fn) -> Lazy[Function() -> A]
    a = Lazy(fn1).lift(fn2)
    # function Validation.success(a) -> Validation[A, []]
    a = Validation.success(a)

    assert a.to_lazy() == Lazy(a.value)
    assert a.to_lazy().value() == a.value


# Generated at 2022-06-12 05:58:34.146846
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    '''
    Validation.to_lazy should return successfully Try with Validation value value. Try is successful when Validation has no errors
    '''
    from pymonet.monad_try import Try

    def run():
        return Validation.success(1).to_lazy().get()

    assert run() == 1
    assert Validation.success(1).to_lazy().is_success == True
    assert Validation.fail([]).to_lazy().is_success == False
    assert Validation.fail([]).to_lazy().get() == None

