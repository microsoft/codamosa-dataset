

# Generated at 2022-06-12 05:48:41.650295
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_success():
        """Test for success value"""
        assert Lazy(lambda: 3) == Validation.success(3).to_lazy()

    def test_fail():
        """Test for fail value"""
        assert Lazy(lambda: None) == Validation.fail([0]).to_lazy()

    test_success()
    test_fail()


# Generated at 2022-06-12 05:48:45.038828
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success('Test').to_lazy()

    assert result == Lazy(lambda: 'Test')



# Generated at 2022-06-12 05:48:47.317059
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success('success').to_lazy()
    assert lazy == Lazy(lambda: 'success')


# Generated at 2022-06-12 05:48:55.693519
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.monad_list import List
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 2 + 2)

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(lazy).to_lazy() == lazy
    assert Validation.fail([ValueError()]).to_lazy() == Lazy(lambda: None)

    monad_try = Try(2)
    assert Validation.success(monad_try).to_lazy() == monad_try.to_lazy()

    maybe = Maybe.just(2)
    assert Validation.success(maybe).to_lazy() == maybe.to_lazy()

# Generated at 2022-06-12 05:49:00.243326
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['message']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:10.156370
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def function():
        return 'function'

    def function_returning_value():
        return Validation.success('some_value')

    # to_lazy should call folder
    assert Validation.fail().to_lazy().map(function) == Lazy(function)

    # to_lazy should call folder
    assert Validation.success('some_value').to_lazy().map(function_returning_value) == Lazy(function_returning_value)

    # to_lazy should return Lazy with folder result
    assert Validation.success('some_value').to_lazy().map(lambda x: function_returning_value()).eval() == \
        Lazy(function_returning_value).map(lambda x: function_returning_value()).eval()

# Generated at 2022-06-12 05:49:17.595063
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tested with pytest.
    """

    # method to_lazy should return Lazy monad with function which returning Validation value
    assert Validation(1, []).to_lazy().value() == 1

    # method to_lazy should return Lazy monad with function which returning Validation value
    assert Validation(1, [2]).to_lazy().value() == 1

    # method to_lazy should return Lazy monad with function which returning Validation value
    assert Validation(None, [1, 2]).to_lazy().value() is None


# Generated at 2022-06-12 05:49:20.473842
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    input = 'test'
    validate = Validation.success(input).to_lazy()

    assert validate == Lazy(lambda: input)



# Generated at 2022-06-12 05:49:27.423774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    success = Validation.success(10).to_lazy()
    fail = Validation.fail([1,2,3]).to_lazy()

    assert(isinstance(success, Lazy))
    assert(isinstance(fail, Lazy))
    assert(success.eval() == 10)
    assert(fail.eval() == None)


# Generated at 2022-06-12 05:49:30.935184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['error_1', 'error_2']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:36.115718
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert (Validation.fail(['Error']).to_lazy() == Lazy(lambda: None))
    assert (Validation.success('OK').to_lazy() == Lazy(lambda: 'OK'))

# Generated at 2022-06-12 05:49:38.212458
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    expected = Lazy(lambda: 1)
    actual = Validation.success(1).to_lazy()

    assert(expected == actual)

# Generated at 2022-06-12 05:49:41.350794
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.run() == 10



# Generated at 2022-06-12 05:49:48.439777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(Validation.success)

    val = Validation.success(1)

    assert val.to_lazy().value() == 1

    val = Validation.fail(1)
    assert val.to_lazy().value() == 1


# Generated at 2022-06-12 05:49:52.548310
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:50:03.327696
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def comp(a, b):
        if a < b:
            return -1
        return 1

    valid_val = Validation.success(5)
    valid_val_2 = Validation.success(comp)
    invalid_val = Validation.fail(['error'])
    invalid_val_2 = Validation.fail([])

    assert valid_val.to_lazy().value() == valid_val.value
    assert invalid_val.to_lazy().value() == invalid_val.value

    assert valid_val_2.to_lazy().value()(4, 5) == -1
    assert invalid_val_2.to_lazy().value() is None


# Generated at 2022-06-12 05:50:06.761041
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(0)

    assert validation.to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-12 05:50:08.163922
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:50:13.092672
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == \
        Lazy(lambda: 3)
    assert Validation.success('test').to_lazy() == \
        Lazy(lambda: 'test')



# Generated at 2022-06-12 05:50:16.695898
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import K
    from pymonet.lazy import Lazy

    assert Validation(10, []).to_lazy() == Lazy(K(10))
    assert Validation(None, [10]).to_lazy() == Lazy(K(None))


# Generated at 2022-06-12 05:50:25.578453
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy().

    :returns: nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    assert Validation.success(value=1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:36.764401
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: lambda: 1) == Validation.success(lambda: 1).to_lazy()
    assert Try(1, is_success=True) == Validation.success(1).to_try()
    assert Try(None, is_success=False) == Validation.fail([]).to_try()
    assert Right(1) == Validation.success(1).to_either()
    assert Box(1) == Validation.success(1).to_box()

# Generated at 2022-06-12 05:50:43.781712
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """Unit test for to_lazy method"""
    from pymonet.functions import identity

    assert identity(Validation.success(123).to_lazy().value) == 123
    assert (identity(Validation.fail(['some error']).to_lazy().value)
            == Validation.fail(['some error']).value)

# Generated at 2022-06-12 05:50:51.754291
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    result = Validation.success('success').to_lazy()
    assert(isinstance(result, Lazy))
    assert(result.value() == 'success')
    assert(result.to_try().get() == Try('success', is_success=True).get())

    result = Validation.fail(['error']).to_lazy()
    assert(isinstance(result, Lazy))
    assert(result.value() is None)
    assert(result.to_try().is_success() == Try(None, is_success=False).is_success())


# Generated at 2022-06-12 05:50:54.911523
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy().get() == 2
    assert Validation.fail().to_lazy().get() is None


# Generated at 2022-06-12 05:51:00.066915
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:02.655291
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1,2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:05.946784
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('something').to_lazy() == Lazy(lambda: 'something')

    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:15.317065
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.box import Box

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    v = Validation.fail(['bla'])
    assert v.to_lazy() == Lazy(lambda: None)
    assert v.to_try() == Try(None, is_success=False)
    assert v.to_either() == Right(None)
    assert v.to_box() == Box(None)


# Generated at 2022-06-12 05:51:19.034643
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:24.549544
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()


# Generated at 2022-06-12 05:51:27.598134
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Validation.success(10).to_lazy()


# Generated at 2022-06-12 05:51:32.314709
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success('test value').to_lazy() == Lazy(lambda: 'test value')
    assert Validation.fail(['test error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:35.799871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.fail(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:42.196720
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad_try import MonadTry
    from pymonet.monad_validation import MonadValidation

    validation = Validation('test', [])
    assert isinstance(validation, Functor)
    assert isinstance(validation, MonadTry)
    assert isinstance(validation, MonadValidation)
    assert validation.value == 'test'
    assert validation.errors == []
    assert validation.value == validation.to_lazy().call()


# Generated at 2022-06-12 05:51:48.588047
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func(x):
        if x == 5:
            return Validation.success(x)
        return Validation.fail([x])

    assert Lazy(lambda: 5) == func(5).to_lazy()
    assert Lazy(lambda: 5) != func(1).to_lazy()


# Generated at 2022-06-12 05:51:51.942765
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy
    from pymonet.validation import Validation

    validation = Validation.success('Hello world!')
    lazy = Lazy(lambda: 'Hello world!')

    assert validation.to_lazy() == lazy


# Generated at 2022-06-12 05:51:57.464880
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_function(param):
        return Validation.success(42)

    validation = Validation.success(42)

    assert Lazy(lambda: 42) == validation.to_lazy()
    assert Lazy(lambda: lazy_function(67)).get() == validation.to_lazy().get()


# Generated at 2022-06-12 05:52:03.217037
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    v = Validation('test', []).to_lazy()
    assert isinstance(v, Lazy)
    assert v.eval() == 'test'
    v = Validation(None, ['error']).to_lazy()
    assert v.eval() == None


# Generated at 2022-06-12 05:52:06.057146
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:52:15.515549
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:18.154583
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    validation = Validation.success(100)
    lazy = Lazy(lambda: 100)
    assert validation.to_lazy() == lazy


# Generated at 2022-06-12 05:52:29.362002
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    v = Validation.success('a')
    t = Validation.success(2)
    f = Validation.fail(['error 1', 'error 2'])

    assert Functor.is_functor(v.to_lazy())
    assert Functor.is_functor(t.to_lazy())
    assert Functor.is_functor(f.to_lazy())

    assert issubclass(v.to_lazy().__class__, Lazy)
    assert isinstance(v.to_lazy(), Lazy)

    assert v.to_lazy().value() == 'a'
    assert t.to_lazy().value() == 2
   

# Generated at 2022-06-12 05:52:35.538009
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    f = Validation.success(12)
    v = f.to_lazy()
    assert isinstance(v, Lazy) and v.value() == 12 and v.is_success()

    f = Validation.fail('error')
    v = f.to_lazy()
    assert isinstance(v, Lazy) and v.value() is None and not v.is_success()



# Generated at 2022-06-12 05:52:41.237272
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 1
    assert result.is_valid()
    assert result.get() == 1
    assert result.get_or_raise() == 1
    assert result.get_or_raise(KeyError) == 1
    assert result.get_or_else(0) == 1

    result = Validation.success(1).to_lazy()
    assert result == Lazy(1)
    assert result != Lazy(0)



# Generated at 2022-06-12 05:52:45.889497
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def computes_value():
        return 'success'

    lazy = Validation.success(computes_value).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy == Lazy(computes_value)


# Generated at 2022-06-12 05:52:49.996506
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(None, ['error']).to_lazy() == Lazy(lambda: None)
    assert Validation('value', []).to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:52:53.614613
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 05:52:57.277090
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().__class__.__name__ == 'Lazy'
    assert Validation.fail('error').to_lazy().__class__.__name__ == 'Lazy'


# Generated at 2022-06-12 05:53:09.569719
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(lambda x: x).to_lazy() == Lazy(lambda: lambda x: x)
    assert Validation.success(Left(1)).to_lazy() == Lazy(lambda: Left(1))
    assert Validation.success(Box(1)).to_lazy() == Lazy(lambda: Box(1))

# Generated at 2022-06-12 05:53:17.435578
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation(1, [])
    assert validation.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:53:27.393648
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_Value():
        return 1

    def test_Value_mapping():
        return test_Value() + 1

    def test_Value_mapping_with_multiple_values():
        return test_Value() + 1 + 2 + 3

    def test_Value_mapping_function_with_multiple_values():
        return lambda: test_Value() + 1 + 2 + 3

    assert (Lazy(test_Value).to_lazy() ==
            Lazy(test_Value))

    assert (Lazy(test_Value_mapping).to_lazy() ==
            Lazy(test_Value_mapping))


# Generated at 2022-06-12 05:53:30.476575
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:53:38.639959
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(errors=[1, 2, 3]).to_lazy() == Lazy(lambda: None)

    assert Validation.success(1).to_lazy().then(lambda x: x + 1) == Lazy(lambda: 2)
    assert Validation.fail(errors=[1, 2, 3]).to_lazy().then(lambda x: x) == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:48.946815
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy().force() == 1
    assert Validation.fail().to_lazy().force() is None

    # is_lazy_value_equal_to_lazy_value_of_try_success = Validation.success(1).to_lazy().force() == Try(1).to_lazy().force()
    # is_lazy_value_equal_to_lazy_value_of_try_failure = Validation.fail().to_lazy().force() == Try(None).to_lazy().force()

    # assert is_lazy_value_equal_to_lazy_value_of_try_success and is_lazy_value_equal_to_l

# Generated at 2022-06-12 05:53:52.957469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:55.243307
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation(100, []).to_lazy()
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:53:59.485162
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 0) == Validation.success(0).to_lazy()
    assert Lazy(lambda: 1) == Validation.fail(['Some error']).to_lazy()

# Generated at 2022-06-12 05:54:01.739261
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()

    assert lazy == Lazy(lambda: 10)



# Generated at 2022-06-12 05:54:05.894518
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation(Lazy(lambda: ValueError()), []).to_lazy() == Lazy(lambda: ValueError())
    assert Validation(Try(Lazy(lambda: ValueError()), is_success=False), []).to_lazy() == Lazy(lambda: ValueError())

# Generated at 2022-06-12 05:54:23.089483
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.monad_try import Try

    def test_function():
        return 1

    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail([]).to_lazy().value() == None
    assert Validation.success(1).to_lazy().to_maybe().get() == 1
    assert Validation.fail([]).to_lazy().to_maybe().is_nothing() == True
    assert Validation.success(1).to_lazy().to_list() == [1]
    assert Validation.fail([]).to_lazy().to_list() == [None]

# Generated at 2022-06-12 05:54:27.192464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def test_function():
        return 'test_function'

    validation = Validation.success(test_function())
    lazy_monad = validation.to_lazy()

    assert lazy_monad.value == validation



# Generated at 2022-06-12 05:54:33.789803
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try, ExceptionMonadValue

    # given
    no_errors = Validation(333, [])
    has_errors = Validation(None, [ExceptionMonadValue(ValueError('Some error'))])

    # then
    assert type(no_errors.to_lazy()) == Lazy
    assert no_errors.to_lazy().get() == 333
    assert type(has_errors.to_lazy()) == Lazy
    assert has_errors.to_lazy().get() == None

# Generated at 2022-06-12 05:54:35.435462
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert lazy.value == 1


# Generated at 2022-06-12 05:54:36.910728
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Lazy(lambda: 'a') == Validation.success('a').to_lazy()


# Generated at 2022-06-12 05:54:44.885548
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test suite for to_lazy function.
    """
    import unittest

    class TestValidationToLazy(unittest.TestCase):
        """
        Test suite for to_lazy function.
        """
        def test_with_success(self):  # pragma: no cover
            """
            Base test for testing to_lazy function.
            """
            validation = Validation.success(1)
            lazy = validation.to_lazy()
            assert lazy.call() == 1

    unittest.main()



# Generated at 2022-06-12 05:54:49.869851
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail(["error"]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:54.172039
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:00.507549
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validation = Validation.fail(['Absence of value'])
    assert validation.to_lazy() == Lazy(lambda: None)
    validation = Validation('Value', ['Wrong type'])
    assert validation.to_lazy() == Lazy(lambda: 'Value')


# Generated at 2022-06-12 05:55:04.461427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:16.178916
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()
    assert lazy == Lazy(lambda: 1)


# Generated at 2022-06-12 05:55:20.872817
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    val = Validation.success('foo')
    lazy = val.to_lazy()

    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.value(), Box)

# Generated at 2022-06-12 05:55:23.864275
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy method
    """
    from pymonet.monad_try import Try

    validation = Validation.success('value')

    assert validation.to_lazy() == Lazy(lambda: 'value')
    assert validation.to_try() == Try('value', is_success=True)


# Generated at 2022-06-12 05:55:29.472522
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def any_function():
        return "Hello World"

    validation = Validation.success(any_function)
    lazy_monad = validation.to_lazy()

    assert lazy_monad.value() == any_function



# Generated at 2022-06-12 05:55:33.902673
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('e').to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:55:38.121093
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def get_validation_value():
        return Validation.success(10)

    assert Validation.success(10).to_lazy() == Lazy(get_validation_value)



# Generated at 2022-06-12 05:55:42.124480
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def fn(x):
        return x + 1

    lazy = Validation.success(1).to_lazy().map(fn)
    assert isinstance(lazy, Lazy)
    assert lazy.get_value() == fn(1)


# Generated at 2022-06-12 05:55:48.585143
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().run() == 1
    assert Validation.fail(["error"]).to_lazy().run() == None


# Generated at 2022-06-12 05:55:53.867944
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert(Validation.success('a').to_lazy() == Lazy(lambda: 'a'))
    assert(Validation.fail(['e']).to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-12 05:55:59.445995
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_function():
        return 'test'

    validation = Validation(None, ['error1', 'error2'])
    assert validation.to_lazy() == Lazy(test_function)


# Generated at 2022-06-12 05:56:15.110609
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_lazy = Validation.success('result').to_lazy()
    assert isinstance(success_lazy, Lazy)
    assert success_lazy.value() == 'result'

    fail_lazy = Validation.fail(['error1']).to_lazy()
    assert isinstance(fail_lazy, Lazy)
    assert fail_lazy.value() is None


# Generated at 2022-06-12 05:56:18.951727
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    try_value = Try(4)
    validation = Validation.success(4)
    assert validation.to_lazy() == Lazy(lambda: try_value)


# Generated at 2022-06-12 05:56:21.757524
# Unit test for method to_lazy of class Validation

# Generated at 2022-06-12 05:56:26.335695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:29.256677
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(42).to_lazy()
    assert isinstance(result, Lazy)
    assert result.__value() == 42
    assert Validation.fail([42]).to_lazy().__value() is None



# Generated at 2022-06-12 05:56:38.949363
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Verification of method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    # Test Validation.success
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.success().to_lazy() == Lazy(lambda: None)

    # Test Validation.fail
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:47.426208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test of method to_lazy of class Validation.
    """

    from pymonet.monad_lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()
    assert Try(1, True) == Validation.success(1).to_lazy().force()
    assert Try(None, False) == Validation.fail().to_lazy().force()


# Generated at 2022-06-12 05:56:51.388097
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func_to_lazy(value):
        assert isinstance(value, Lazy)
        assert value.value() == 1
    func_to_lazy(Validation.success(1).to_lazy())


# Generated at 2022-06-12 05:56:58.862359
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 10)
    assert lazy.eval() == 10

    validation = Validation.fail([1, 2, 3])
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: None)
    assert lazy.eval() == None


# Generated at 2022-06-12 05:57:03.538311
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    value = 1
    validation = Validation(value, [])

    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy._lazy_value() == value



# Generated at 2022-06-12 05:57:16.873603
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy_ = Lazy(lambda: 2 / 0)
    expec = Validation(None, [ValidationError('/ by zero', None, is_successful=False)])
    val = Validation(None, [ValidationError('/ by zero', None, is_successful=False)]).to_lazy().to_validation()
    assert val == expec


# Generated at 2022-06-12 05:57:22.573704
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Check behavior of to_lazy method of class Validation.
    """
    from pymonet.lazy import Lazy

    def test_function():
        return Validation.success(1)

    validation = Lazy(test_function).to_validation()

    assert validation.to_lazy().force() == Validation.success(1)
    assert validation.to_lazy().force() == Validation.success(1)


# Generated at 2022-06-12 05:57:25.766581
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It should transform Validation to Lazy.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:57:31.158142
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(errors=['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:33.017613
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy().eval() == 1


# Generated at 2022-06-12 05:57:41.477361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation class to_lazy method.
    """
    from pymonet.lazy import Lazy
    from pymonet.monad import monad_test_suite
    from pymonet.monad_test_suite import assert_lazy, assert_success_value, assert_failure_value

    assert_lazy(assert_failure_value, monad_test_suite, Validation.fail(['Error']), Lazy(lambda: None))
    assert_lazy(assert_success_value, monad_test_suite, Validation.success(42), Lazy(lambda: 42))


# Generated at 2022-06-12 05:57:45.878082
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_validation = Validation.success('success')
    fail_validation = Validation.fail('fail')

    assert success_validation.to_lazy() == Lazy(lambda: 'success')
    assert fail_validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:57.494067
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def computation():
        return 45

    def computation_exception():
        raise Exception

    assert Try.success(Validation.success(45).to_lazy()).get == computation
    assert Try.success(Validation.fail().to_lazy()).get == computation
    assert Try.fail(Validation.fail().to_lazy()).or_else(lambda: 45) == 45
    assert Try.success(Validation.success(Lazy(computation))).get == computation
    assert Try.fail(Validation.success(Lazy(computation_exception))).or_else(lambda: 45) == 45

# Generated at 2022-06-12 05:58:03.033328
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy

    def succeed(value):
        return Validation.success(value)

    def fail(value):
        return Validation.fail([value])

    assert Lazy(lambda: succeed('success')).to_validation().to_lazy().value() == succeed('success').value
    assert Lazy(lambda: fail('fail')).to_validation().to_lazy().value() == fail('fail').value

# Generated at 2022-06-12 05:58:08.201097
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    validation = Validation.success('bla')
    assert validation.to_lazy().get() == 'bla'

    validation = Validation.fail()
    assert validation.to_lazy().get() is None

    validation = Validation.success(None)
    assert validation.to_lazy().get() is None


# Generated at 2022-06-12 05:58:20.901571
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy().get() == Validation.success(0).value
    assert Validation.fail([]).to_lazy().get() == Validation.fail([]).value



# Generated at 2022-06-12 05:58:24.322367
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_validation = Validation.success(2)
    lazy_validation = success_validation.to_lazy()

    # isinstance check
    assert isinstance(lazy_validation, Lazy)

    # monad value
    assert lazy_validation.value() == 2


# Generated at 2022-06-12 05:58:35.741626
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def validate(value) -> Validation:
        if value > 5:
            return Validation.success(value)
        return Validation.fail([f'value: {value} must be grater than 5'])

    def validate_twice(value) -> Validation:
        return validate(value).bind(validate)

    result = validate_twice(30)

    assert result == Validation.success(30), 'It must return valid Validation'
    assert result.errors == [], 'It must have empty errors'

    result = validate_twice(2)
