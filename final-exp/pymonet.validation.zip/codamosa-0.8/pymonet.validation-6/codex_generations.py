

# Generated at 2022-06-12 05:48:36.050013
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(15).to_lazy() == Lazy(lambda: 15)
    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:40.465961
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(5)

    assert validation.to_lazy() == Lazy(lambda: 5)

    validation = Validation.fail()

    assert validation.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:48:51.976042
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation(False, []).to_lazy() == Lazy(lambda: False)
    assert Validation('foo', []).to_lazy() == Lazy(lambda: 'foo')
    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    assert Validation(False, ['error']).to_lazy() == Lazy(lambda: False)
    assert Validation('foo', ['error']).to_lazy() == Lazy(lambda: 'foo')
    assert Validation(None, ['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:59.979768
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Validation.success(Try.success("Hello")).to_lazy()
    assert lazy.is_instance_of(Lazy)
    assert lazy.eval() == "Hello"

    lazy = Validation.success(Try.fail("Error")).to_lazy()
    assert lazy.is_instance_of(Lazy)
    assert lazy.eval() is None


# Generated at 2022-06-12 05:49:06.414232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def id(x):
        return x
    assert Validation.success(1).to_lazy() == Lazy(id, 1)
    assert Validation.fail([1]).to_lazy() == Lazy(id, None)
    assert Validation.success(1).to_lazy().force() == 1
    assert Validation.fail([1]).to_lazy().force() is None


# Generated at 2022-06-12 05:49:09.046560
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail([1, 2, 3]).to_lazy().f() == None
    assert Validation.success('Validation.success').to_lazy().f() == 'Validation.success'



# Generated at 2022-06-12 05:49:12.569944
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success('value').to_lazy()

    assert lazy.value() == 'value'


# Generated at 2022-06-12 05:49:23.672647
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation, ValidationError
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def value():
        return 100

    v = Validation.success()
    lazy = v.to_lazy()

    assert isinstance(lazy, Lazy)
    assert Callable(lazy.fn)
    assert Try(value()) == lazy.run()

    v = Validation.fail(ValidationError(['Validation failed']))
    lazy = v.to_lazy()

    assert isinstance(lazy, Lazy)
    assert Callable(lazy.fn)
    assert Try(None) == lazy.run()


# Generated at 2022-06-12 05:49:28.974615
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([
        'error1',
        'error2'
    ]).to_lazy() == Lazy(lambda: None)


# Unit test when Validation is equal to Failure

# Generated at 2022-06-12 05:49:31.678748
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    def returnValue():
        return 'value'

    validation = Validation.success(value=returnValue)

    assert(validation.to_lazy() == Lazy(returnValue))


# Generated at 2022-06-12 05:49:36.063781
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['fail']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:40.442645
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:48.200208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Try(5, is_success=True) == Validation.success(5).to_try()
    assert Try(5, is_success=False) == Validation.fail([1]).to_try()
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success(5).to_box() == Box(5)
    assert Validation.fail([]).to_box() == Box(None)


# Generated at 2022-06-12 05:49:50.382417
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test that Validation is converted to Lazy
    assert type(Validation.success(10).to_lazy()) is Lazy


# Generated at 2022-06-12 05:49:54.041503
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, fn_lazy_to_maybe

    assert fn_lazy_to_maybe(Validation(1, []).to_lazy()) == Lazy(lambda: Validation(1, []).to_maybe())


# Generated at 2022-06-12 05:49:58.202291
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy().get() == 10
    assert Validation.fail([1, 'twice']).to_lazy().get() is None

# Unit tests for method to_try of class Validation

# Generated at 2022-06-12 05:50:01.190175
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:50:04.717525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():   # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:50:10.228726
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for to_lazy method.
    """

    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(1, ['test']).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:50:13.911837
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    @do
    def do_example():
        validation = yield Validation.success(10)

# Generated at 2022-06-12 05:50:19.195783
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'Lazy'

    lazy = Lazy(f)
    assert lazy == Validation.success('Lazy').to_lazy()

# Generated at 2022-06-12 05:50:31.355477
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # value that is not None
    some_value = 1

    # value that is None
    none_value = None

    # Validation.success with some value
    success = Validation.success(some_value)

    # Validation.fail with some value
    fail = Validation.fail(some_value)

    # Validation.success with None
    none_success = Validation.success(none_value)

    # Validation.fail with None
    none_fail = Validation.fail(none_value)

    # assert that Lazy with Validation value is Validation.success(some_value).to_lazy()
    assert Lazy(lambda: success.value) == success.to_lazy()

    # assert that Lazy with Validation value is Validation.fail(some_

# Generated at 2022-06-12 05:50:35.768166
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    :return: None
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:50:38.884607
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(1, [1, 'foo']).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:50:45.165561
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """unit test for method to_lazy of class Validation"""

    from pymonet.lazy import Lazy

    validation = Validation.success('Value')
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.value(), str)


# Generated at 2022-06-12 05:50:48.350196
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    lazy = validation.to_lazy()
    assert lazy.evaluate() == validation.value
    assert lazy == Lazy(lambda: 10)


# Generated at 2022-06-12 05:50:53.461241
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success("test").to_lazy() == Lazy(lambda: "test")
    assert Validation.success("test").to_lazy().strict_value() == "test"
    assert Validation.fail("test").to_lazy().strict_value() is None


# Generated at 2022-06-12 05:50:57.666592
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    m = Validation.success('value')
    assert isinstance(m.to_lazy(), Lazy)
    assert m.to_lazy().value() == 'value'



# Generated at 2022-06-12 05:51:01.014101
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def func():
        return 1

    lazy = Validation.success(func).to_lazy()
    assert lazy is not None
    assert lazy.func() == 1


# Generated at 2022-06-12 05:51:04.264530
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validate = Validation.success(5)
    assert Lazy(lambda: 5) == validate.to_lazy()


# Generated at 2022-06-12 05:51:12.520396
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v = Validation.success(1)
    assert isinstance(v.to_lazy(), Lazy)
    assert callable(v.to_lazy().get())
    assert v.to_lazy().get() == 1

# Generated at 2022-06-12 05:51:18.368385
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # when Validation is successful
    validation = Validation.success('some value')
    # then Validation.to_lazy should return Lazy monad
    assert validation.to_lazy() == Lazy(lambda: 'some value')

    # when Validation is failed
    validation = Validation.fail()
    # then Validation.to_lazy should return Lazy monad
    assert validation.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:51:24.765732
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(10).to_lazy().get() == 10
    assert Validation.fail(['some error']).to_lazy() == Lazy(lambda: None)

    assert Validation.success(True).to_lazy().filter(lambda v: v).get() == True
    assert Validation.success(True).to_lazy().filter_not(lambda v: v).is_empty()
    assert Validation.success(False).to_lazy().filter_not(lambda v: v).get() == False
    assert Validation.success(False).to_lazy().filter(lambda v: v).is_empty()


# Generated at 2022-06-12 05:51:33.376524
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Function to test Validation.to_lazy method.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success(5)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert Try(lazy()()) == Try(5, True)
    validation = Validation.fail(['Error'])
    lazy = validation.to_lazy()
    assert Try(lazy()(), True) == Try(None, True)


# Generated at 2022-06-12 05:51:38.503154
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:44.269309
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_loader():
        return 1
    lazy = Lazy(lazy_loader)

    result_loaded = Validation.success(lazy.value()).to_lazy()
    result_not_loaded = Validation.success(lazy).to_lazy()

    assert result_loaded == result_not_loaded

    assert result_loaded.value() == lazy.value()


# Generated at 2022-06-12 05:51:49.691871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Lazy(lambda: 1)
    validation = validation.success(1)

    assert validation.to_lazy() == lazy

    value = lazy.__value()
    assert validation.to_lazy().__value() == value


# Generated at 2022-06-12 05:51:53.413654
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.success(1).to_lazy().get() == 1


# Generated at 2022-06-12 05:52:02.894763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy().get() == 1
    assert Validation(1, [1]).to_lazy().get() == 1
    assert Validation(1, []).to_lazy().to_list() == [1]
    assert Validation(1, [1]).to_lazy().to_list() == [1]
    assert Validation(1, []).to_lazy().map(lambda x: 2).to_list() == [2]
    assert Validation(1, [1]).to_lazy().map(lambda x: 2).to_list() == [2]


# Generated at 2022-06-12 05:52:05.046465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-12 05:52:18.019130
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from unittest import TestCase, main
    from pymonet.monad_try import Try

    class TestTryLazy(TestCase):
        def test_lazy(self):
            validation = Validation.success(1)
            lazy = validation.to_lazy()
            self.assertEqual(lazy, Lazy(lambda: 1))

    main()


# Generated at 2022-06-12 05:52:22.814635
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests success and fail cases of method to_lazy of class Validation.
    """
    assert Validation(12, []).to_lazy() == Lazy(lambda: 12)
    assert Validation(12, ['error']).to_lazy() == Lazy(lambda: 12)


# Generated at 2022-06-12 05:52:27.775823
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation to_lazy method.

    :returns: Nothing
    :rtype: Nothing
    """
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 10)

    assert lazy == Validation.success(lazy).to_lazy()


# Generated at 2022-06-12 05:52:31.110806
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()


# Generated at 2022-06-12 05:52:37.327286
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test transform Validation to Lazy monad.
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 100) == Validation.success(100).to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1.0]).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()


# Generated at 2022-06-12 05:52:43.649110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(errors=[1, 2]).to_lazy() == Lazy(lambda: None)

    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)
    assert Validation(None, [1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:50.680313
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, LazyValueError

    validation = Validation.success(10)
    assert validation.to_lazy() == Lazy(lambda: 10)

    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(lambda: None)

    validation = Validation.fail([1])
    assert validation.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:53:00.498695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    assert Validation(None, ['error']).to_lazy() == Lazy(lambda: None)
    assert Validation(0, []).to_lazy() == Lazy(lambda: 0)
    assert Validation(0, ['error']).to_lazy() == Lazy(lambda: 0)
    assert Validation(3.14, []).to_lazy() == Lazy(lambda: 3.14)
    assert Validation(3.14, ['error']).to_lazy() == Lazy(lambda: 3.14)
    assert Validation("string", []).to_lazy() == Lazy(lambda: "string")

# Generated at 2022-06-12 05:53:09.223228
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def side_effect():
        raise Exception('Exception')

    assert isinstance(Validation.fail(errors=['Some error']).to_lazy(), Lazy)
    assert isinstance(Validation.success(value=1).to_lazy(), Lazy)

    assert Validation.fail(errors=['Some error']).to_lazy().run() == None
    assert Validation.success(value=1).to_lazy().run() == 1



# Generated at 2022-06-12 05:53:12.220948
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(4)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.__run__() == 4


# Generated at 2022-06-12 05:53:32.188500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    def test_lazy():
        return Validation(10, [])

    test = Lazy(test_lazy)

    assert test.value() == Validation(10, [])


# Generated at 2022-06-12 05:53:33.344102
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-12 05:53:37.454500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(5).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.get() == 5


# Generated at 2022-06-12 05:53:41.056568
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Validation.success('test').to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 'test'
    assert lazy.eager is False


# Generated at 2022-06-12 05:53:44.625636
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:50.095890
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Validation to_lazy() unit test.
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(7).to_lazy() == Lazy(lambda: 7)
    assert Validation.fail(7).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:52.457178
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation = Validation.success('test')
    lazy_result = validation.to_lazy()
    assert isinstance(lazy_result, Lazy)
    assert lazy_result.get() == 'test'

    validation = Validation.fail(['test'])
    lazy_result = validation.to_try()
    assert isinstance(lazy_result, Try)
    assert not lazy_result.is_success()

# Generated at 2022-06-12 05:54:01.904221
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Successful case
    validation = Validation.success('success')
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy), 'to_lazy method should return Lazy class instance'
    assert lazy.fn() == 'success', 'to_lazy method should return function that return previous value'

    # Failed case
    validation = Validation.fail(errors=['error'])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy), 'to_lazy method should return Lazy class instance'
    assert lazy.fn() == None, 'to_lazy method should return function that return previous value'



# Generated at 2022-06-12 05:54:06.631691
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:12.094400
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    class Person:
        def __init__(self, name, surname):
            self.name = name
            self.surname = surname

    from pymonet.lazy import Lazy

    person = Validation.success(Person('John', 'Smith'))

    assert person.to_lazy() == Lazy(lambda: Person('John', 'Smith'))


# Generated at 2022-06-12 05:54:43.820969
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() is 1
    assert Validation.fail([1]).to_lazy().value() is None



# Generated at 2022-06-12 05:54:48.907173
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(1)
    failure = Validation.fail()
    assert success.to_lazy() == Lazy(lambda: 1)
    assert failure.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:54:53.690624
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: "Hello") == Validation.success("Hello").to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()


# Generated at 2022-06-12 05:54:58.201611
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy() method.
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    res = Validation.success(1).to_lazy()
    assert res.is_success()
    assert res.get_val()() == 1
    res = Validation.fail([1,2,3]).to_lazy()
    assert res.is_fail()
    assert res.get_val()() is None


# Generated at 2022-06-12 05:55:02.355560
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(Lazy(lambda: 2).value)
    assert validation.to_lazy().evaluate() == 2

    validation = Validation.success(Lazy(lambda: 4).value)
    assert validation.to_lazy().evaluate() == 4

# Generated at 2022-06-12 05:55:05.525215
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:55:08.641912
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 'test'
    validation = Validation.success(value)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: value)



# Generated at 2022-06-12 05:55:14.698747
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """

    from pymonet.lazy import Lazy

    success = Validation.success(10)
    assert success.to_lazy() == Lazy(lambda: 10)
    assert success.to_lazy().get() == 10

    failed = Validation.fail(['Error 1', 'Error 2'])
    assert failed.to_lazy().get() is None


# Generated at 2022-06-12 05:55:19.048126
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Validation.success(1).to_lazy()

    assert(isinstance(lazy, Lazy))
    assert(lazy.value == 1)


# Generated at 2022-06-12 05:55:21.978716
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)


# Generated at 2022-06-12 05:56:29.481872
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given: some Validation
    validation = Validation(1, [])
    # When: call to_lazy method
    lazy = validation.to_lazy()
    # Then: lazy should be wrapped value
    assert lazy.force() == 1


# Generated at 2022-06-12 05:56:40.969545
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import identity, try_get_first_item_of_empty_list
    from pymonet.functions import compose

    assert(Validation.success(10).to_lazy() == Lazy(lambda: 10))
    assert(Validation.fail([10, 20]).to_lazy() == Lazy(lambda: None))
    assert(Validation.fail([10, 20]).to_lazy().flat_map(
        lambda x: Lazy(lambda: x.value + 10)) == Lazy(lambda: None))
    assert(Validation.success(10).to_lazy().flat_map(
        lambda x: Lazy(lambda: x.value + 10)) == Lazy(lambda: 20))

# Generated at 2022-06-12 05:56:47.377608
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)

    def get_lazy():
        try:
            '123' / 0
        except Exception as error:
            return Lazy(lambda: error.__class__)

    assert Validation.fail([RuntimeError]).to_lazy() == get_lazy()


# Generated at 2022-06-12 05:56:53.458366
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success('123').to_lazy() == Lazy(lambda: '123')
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:56.681110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 05:57:03.319071
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    success_validation = Validation.success('Hello')
    lazy = success_validation.to_lazy()
    assert lazy == Lazy(lambda: 'Hello'), f'Expect Lazy with function returns "Hello" but {lazy}'

    fail_validation = Validation.fail(['Oops'])
    lazy = fail_validation.to_lazy()
    assert lazy == Lazy(lambda: None), f'Expect Lazy with function returns None but {lazy}'


# Generated at 2022-06-12 05:57:06.643267
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail("error").to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:57:11.242455
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_lazy import Lazy

    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
    assert Validation.fail(['error1', 'error2']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:17.041781
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        from pymonet.lazy import Lazy
        from pymonet.lazy import LazyException
    except ImportError:
        print("Cannot test method Validation.to_lazy without module lazy")

    lazy = Lazy(lambda: 1 / 0)
    assert lazy.to_lazy() == lazy

    try:
        lazy.get()
        raise AssertionError("Lazy should raise LazyException")
    except LazyException:
        pass


# Generated at 2022-06-12 05:57:19.077249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success(value=2)
    assert v.to_lazy().value() == 2
