

# Generated at 2022-06-12 05:48:39.740870
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1]).to_lazy()


# Generated at 2022-06-12 05:48:44.300628
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1,2,3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:47.256830
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:52.152630
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    from pymonet.lazy import Lazy

    validation = Validation.fail([1, 2, 3])

    # when
    lazy = validation.to_lazy()

    # than
    assert isinstance(lazy, Lazy)
    assert lazy() == validation.value



# Generated at 2022-06-12 05:48:56.716394
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Test for successful Validation
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    # Test for failed Validation
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:08.467140
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    # Test success to_lazy
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

    # Test fail to_lazy
    assert Validation.fail(5).to_lazy() == Lazy(lambda: None)

    # Test to_try with success validation
    assert Validation.success(5).to_try() == Try(5, is_success=True)

    # Test to_try with fail validation
    assert Validation.fail(5).to_try() == Try(None, is_success=False)

    # Test to_maybe with success validation
    assert Validation.success(5).to_maybe() == Maybe.just(5)

    #

# Generated at 2022-06-12 05:49:13.742109
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(2)

    t = v.to_lazy()

    assert isinstance(t, Lazy)
    assert t.get() == 2


# Generated at 2022-06-12 05:49:19.594305
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def _false_lazy_fn():
        return False

    def _true_lazy_fn():
        return True

    assert Validation.success().to_lazy() == Lazy(_false_lazy_fn)
    assert Validation.success('a').to_lazy() == Lazy(_true_lazy_fn)



# Generated at 2022-06-12 05:49:23.299437
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert lazy.eval() == 1

    validation = Validation.fail(1)
    lazy = validation.to_lazy()
    assert lazy.eval() is None

# Generated at 2022-06-12 05:49:30.593060
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def __square(value):
        return value ** 2

    def __return_5():
        return 5

    def __return_not_5():
        return 6

    assert Validation.success(5).to_lazy() == Lazy(__return_5)
    assert Validation.fail(5).to_lazy() == Lazy(__return_not_5)
    assert Validation.success(5).to_lazy().flat_map(__square) == Lazy(lambda: __square(5))


# Generated at 2022-06-12 05:49:36.994226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1

    lazy = Validation.fail().to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None


# Generated at 2022-06-12 05:49:40.271108
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(True).to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-12 05:49:44.496063
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def get_value():  # pragma: no cover
        return 3

    assert Validation.success(get_value()).to_lazy().evaluate() == 3
    assert Validation.fail([]).to_lazy().evaluate() is None
    assert Validation.fail([1, 2, 3]).to_lazy().evaluate() is None


# Generated at 2022-06-12 05:49:50.642546
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    validation = Validation.success(2)
    result = validation.to_lazy()
    assert result == Lazy(lambda: 2)
    validation = Validation.fail(["Error"])
    result = validation.to_lazy()
    assert result == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:00.630611
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # Test with successful Validation. Lazy should contain return of asser_true
    assert_true = Lazy(lambda: Validation.success(True))
    assert_true_return = Validation.success(True).to_lazy().run()
    assert assert_true == assert_true_return

    # Test with failed Validation. Lazy should contain return of asser_false
    assert_false = Lazy(lambda: Validation.fail(['This is message']))
    assert_false_return = Validation.fail(['This is message']).to_lazy().run()
    assert assert_false == assert_false_return

# Generated at 2022-06-12 05:50:07.041125
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy1 = Validation.success(5).to_lazy()
    assert isinstance(lazy1, Lazy)
    assert lazy1.eval() == 5

    lazy2 = Validation.fail([1]).to_lazy()
    assert isinstance(lazy2, Lazy)
    assert lazy2.eval() == None



# Generated at 2022-06-12 05:50:14.684518
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_lazy import thunk

    assert Validation.success(42).to_lazy() == Lazy(thunk(42))
    assert Validation.fail('boom').to_lazy() == Lazy(thunk(None))
    assert Validation.success('correct').to_lazy() == Lazy(thunk('correct'))


# Generated at 2022-06-12 05:50:20.483967
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def get_five():
        return 5

    def get_six():
        return 6

    assert Validation.success(5).to_lazy() == Lazy(get_five)
    assert Validation.success(6).to_lazy() == Lazy(get_six)
    assert Validation.fail([]).to_lazy() == Lazy(get_none)


# Generated at 2022-06-12 05:50:27.322000
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try

    validation = Validation.success(10)
    result = validation.to_lazy()

    assert isinstance(result, Functor)
    assert isinstance(result.value, Lazy)
    assert isinstance(result.value.value, Callable)
    assert result.value() == 10


# Generated at 2022-06-12 05:50:31.306201
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test for method to_lazy of class Validation"""
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail().to_lazy().value() == None


# Generated at 2022-06-12 05:50:41.998943
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def compute():
        return 1 + 1

    validation = Validation(1, []).to_lazy()

    assert isinstance(validation, Lazy)
    assert validation == Lazy(1)
    assert validation.get() == 1

    assert validation.map(lambda x: x * 2) == Lazy(2)
    assert validation.map(lambda x: x * 2).get() == 2

    assert validation.ap(Lazy(lambda x: Try(x * 2))) == Lazy(2)
    assert validation.ap(Lazy(lambda x: Try(x * 2))).get() == 2


# Generated at 2022-06-12 05:50:48.074818
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success('success')
    assert success.to_lazy() == Lazy(lambda: 'success')
    assert success.to_lazy()() == 'success'

    fail = Validation.fail(['fail'])
    assert fail.to_lazy() == Lazy(lambda: None)
    assert fail.to_lazy()() is None

# Generated at 2022-06-12 05:50:53.817224
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that Validation.to_lazy returns Lazy monad
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:57.894423
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:04.598858
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    check_lazy = lambda: Validation.success(123)
    check_lazy_fail = lambda: Validation.fail(['fail'])

    assert Validation.success(123).to_lazy() == Lazy(check_lazy)
    assert Validation.fail(['fail']).to_lazy() == Lazy(check_lazy_fail)


# Generated at 2022-06-12 05:51:09.354928
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, ['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:14.742579
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def assertion(value):
        value.to_lazy() == Lazy(lambda : value)

    assertion(Validation.success(42))

    value = Validation.fail(['error1', 'error2'])
    assertion(value)


# Generated at 2022-06-12 05:51:17.657628
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(["error"]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:51:22.408448
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    validation = Validation(1, [])
    lazy = validation.to_lazy()
    assert lazy.value() == 1

    validation = Validation(None, [])
    lazy = validation.to_lazy()
    assert lazy.value() == None


# Generated at 2022-06-12 05:51:27.547510
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validation = Validation.success('A')

    assert validation.to_lazy() == Lazy(lambda: 'A')

    validation = Validation.fail(['Error message'])

    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:35.943738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_function():
        return 5

    assert Validation.success(5).to_lazy() == Lazy(test_function)

    def test_function2():
        return None

    assert Validation.fail([1]).to_lazy() == Lazy(test_function2)



# Generated at 2022-06-12 05:51:38.863053
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    val = Validation.success(5)
    lazy = val.to_lazy()

    assert lazy == Lazy(5)



# Generated at 2022-06-12 05:51:40.908175
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Validation.success(1).to_lazy()


# Generated at 2022-06-12 05:51:44.345586
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    # Test cases for method to_try of class Validation
    assert Validation.success(5).to_lazy() == Try(5, is_success=True)
    assert Validation.fail(5).to_lazy() == Try(5, is_success=False)



# Generated at 2022-06-12 05:51:49.326727
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    validation = Validation.success(Box(32))
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: Box(32))


# Generated at 2022-06-12 05:51:53.212171
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().force() == 1
    assert Validation.fail().to_lazy().force() is None


# Generated at 2022-06-12 05:51:58.567797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:05.896845
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    val = Validation.success('value')
    assert val.to_lazy() == Lazy(lambda: 'value')
    assert val.to_lazy().value() == 'value'

    val = Validation.fail(['some error'])
    assert val.to_lazy() == Lazy(lambda: None)
    assert val.to_lazy().value() is None


# Generated at 2022-06-12 05:52:08.636098
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:52:12.365215
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 3) == Validation.success(3).to_lazy()

# Generated at 2022-06-12 05:52:21.340706
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:26.118085
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:52:27.744437
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:52:31.875988
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    value = 1

    assert Validation.success(value).to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:52:35.158822
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def add(x):
        return x + 3

    assert Lazy(lambda: add(3)) == Validation.success(3).to_lazy().map(add)


# Generated at 2022-06-12 05:52:36.908925
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(30).to_lazy() == Lazy(lambda: 30)


# Generated at 2022-06-12 05:52:40.986685
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value is None

    validation = Validation.success('value')
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value == 'value'


# Generated at 2022-06-12 05:52:46.371873
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # given
    validation = Validation.success(2)

    # when
    lazy = validation.to_lazy()

    # then
    assert isinstance(lazy, Lazy)
    assert lazy.eval() == Try.just(2)


# Generated at 2022-06-12 05:52:49.985045
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v1 = Validation.success(1)
    assert v1.to_lazy().evaluate() == v1.value
    v2 = Validation.fail()
    assert v2.to_lazy().evaluate() == v2.value

# Generated at 2022-06-12 05:52:56.276342
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation methods to_lazy.
    """
    from pymonet.lazy import Lazy

    assert(Lazy(lambda: 1) == Validation.success(1).to_lazy())
    assert(Lazy(lambda: None) == Validation.fail([]).to_lazy())
    assert(Lazy(lambda: None) == Validation.fail(['a']).to_lazy())


# Generated at 2022-06-12 05:53:08.072668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def return_value(_):
        return 100

    lazy_1 = Validation.success(100).to_lazy()
    lazy_2 = Validation.success(100).to_lazy()

    assert isinstance(lazy_1, Lazy)
    assert lazy_1 == lazy_2
    assert lazy_1.eval() == 100


# Generated at 2022-06-12 05:53:13.277817
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    value, errors = 'Hello World', ['is error']

    validation = Validation(value, errors)
    lazy = Lazy(lambda: value)
    assert validation.to_lazy() == lazy

    validation = Validation(None, errors)
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:19.273797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:22.725225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def add_numbers(x, y):
        return x + y

    validation = Validation.success(3)
    assert validation.to_lazy() == Lazy(lambda: 3)

# Generated at 2022-06-12 05:53:26.470338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-12 05:53:36.779501
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['x']).to_lazy() == Lazy(lambda: None)
    assert Validation.fail('x').to_lazy() == Lazy(lambda: 'x')


# Generated at 2022-06-12 05:53:44.920596
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def res():
        return 'Lazy with value'
    return Validation(res(), [])       \
        .to_lazy()                     \
        .map_lazy(lambda x: x())       \
        .to_either()                   \
        .map(lambda x: x)              \
        .to_maybe()                    \
        .map(lambda x: x)              \
        .to_try()                      \
        .map(lambda x: x)              \
        .to_box()                      \
        .map(lambda x: x)              \
        .to_try()                      \
        .get() == 'Lazy with value'


# Generated at 2022-06-12 05:53:49.621563
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    a = Validation.success(2)
    b = Validation.fail(['error'])

    assert a.to_lazy() == Lazy(lambda: 2)
    assert b.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:54.724426
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def _():
        return 10

    v = Validation.success(10)
    l = v.to_lazy()

    assert l.get_value() == _()
    assert l.get_value() == 10
    assert l.get_value() == l.get_value()


# Generated at 2022-06-12 05:53:58.349667
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that to_lazy method of class Validation works as expected
    """
    from pymonet.lazy import Lazy

    assert(Validation.success(1).to_lazy() == Lazy(lambda: 1))


# Generated at 2022-06-12 05:54:05.803892
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Prepare data
    value = 'test value'
    validation = Validation(value, [])

    # Assert
    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:54:07.442706
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:17.282264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    values = [10, "Hello", True]
    for value in values:  # pragma: no branch
        v = Validation.success(value)
        l = v.to_lazy()
        assert isinstance(l, Lazy) and l() == value

    values2 = [10, "Hello", True]
    for value in values:  # pragma: no branch
        v = Validation.fail([value])
        l = v.to_lazy()
        assert isinstance(l, Lazy) and l() is None

# Generated at 2022-06-12 05:54:20.237190
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:31.848087
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import do_monad
    from pymonet.monad_try import bind
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    data = {
        'a': {
            'b': {
                'c': 'd'
            }
        }
    }

    def get_path(name):
        def get_value(data):
            def get_item(key):
                try:
                    value = data[key]
                    return Try(value)
                except Exception:
                    return Try(data, is_success=False)


# Generated at 2022-06-12 05:54:34.973095
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(3, []).to_lazy() == Lazy(lambda: 3)
    assert Validation(2, [1]).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:54:41.501228
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Try(1).to_lazy() == Lazy(lambda: 1)
    assert Maybe.just(2).to_lazy() == Lazy(lambda: 2)
    assert Maybe.nothing().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:54:46.761000
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy
    test_value = [1, 2, 3]
    validation_success = Validation.success(test_value)
    lazy_validation_success = validation_success.to_lazy()
    assert(lazy_validation_success.value() == test_value)
    assert(isinstance(validation_success.to_lazy(), Lazy))



# Generated at 2022-06-12 05:54:53.118594
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_function():
        time.sleep(1)
        return Validation.success('test result')

    lazy_function_monad = lazy_function()
    assert lazy_function_monad.to_lazy() == Lazy(lazy_function)


# Generated at 2022-06-12 05:54:55.557382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    valid = Validation.success(10)
    lazy = valid.to_lazy()

    assert lazy == Lazy(lambda: 10)


# Generated at 2022-06-12 05:55:06.077691
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = "value"
    validation = Validation.success(value)

    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:55:12.071332
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.monad_try import Try

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:17.011257
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:25.514303
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test to check Validation.to_lazy() method.

    This test starts with Validation.success(10) and Validation.fail(['error']).
    It checks that result of Validation.to_lazy().value() returns 10 for first case and raises exception for second case.
    """

    # Case 1
    validation = Validation.success(10)
    lazy = validation.to_lazy()
    value = lazy.value()

    assert value == 10

    # Case 2
    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()

    try:
        lazy.value()
        assert False, 'Lazy value must throw an exception'
    except TypeError:
        pass

# Generated at 2022-06-12 05:55:29.472775
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy.success('value')
    validation = Validation('value', [])
    assert validation.to_lazy() == lazy



# Generated at 2022-06-12 05:55:32.097838
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'A').to_lazy() == Lazy(lambda: 'A')
    assert Lazy(lambda: 2).to_lazy() == Lazy(lambda: 2)
    assert Lazy(lambda: 'A') == Lazy(lambda: 'A')
    assert Lazy(lambda: 2) == Lazy(lambda: 2)


# Generated at 2022-06-12 05:55:41.275620
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success('value').to_lazy()
    data = validation.value()
    assert isinstance(data, Try), 'should return Try monad'
    assert data.is_successful(), 'should return successful Try monad'
    assert data.value == 'value', 'should return successful Try monad with correct value'
    assert data.errors == [], 'should return successful Try monad with no errors'



# Generated at 2022-06-12 05:55:49.526082
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Try(None, is_success=True).to_lazy() == Lazy(lambda: None)
    assert Try(1, is_success=True).to_lazy() == Lazy(lambda: 1)
    assert Try(Box(1), is_success=True).to_lazy() == Lazy(lambda: Box(1))


# Generated at 2022-06-12 05:55:59.149309
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy
    from pymonet.monad_try import Try

    lazy = Validation.success(1).to_lazy()

    assert lazy == pymonet.lazy.Lazy(lambda: 1)
    assert lazy.eval == 1
    assert lazy.eval() == 1
    assert lazy.try_get() == Try(1)
    assert lazy.try_get().is_success
    assert lazy.try_get().is_fail == False
    assert lazy.try_get().get() == 1
    assert lazy.try_get().get_or_else == 1
    assert lazy.try_get().get_or_else(2) == 1
    assert lazy.try_get().get_or_else(lambda: 2) == 1

# Generated at 2022-06-12 05:56:03.106365
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(1)
    new_val = val.to_lazy()

    assert new_val.value() == 1
    assert new_val.is_success() is True
    assert new_val.is_fail() is False


# Generated at 2022-06-12 05:56:18.701468
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(1, []).to_lazy().value() == 1
    assert Validation(1, [1, 2, 3]).to_lazy().value() is None


# Generated at 2022-06-12 05:56:21.843867
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test():
        return 5

    validation = Validation(None, [])

    assert validation.to_lazy() == Lazy(test)


# Generated at 2022-06-12 05:56:26.779711
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy = Validation.success(42).to_lazy()
    assert lazy.__class__ == Lazy
    assert lazy.compute() == Try(42).compute()


# Generated at 2022-06-12 05:56:38.401240
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    v = Validation.success('happy')
    lz = v.to_lazy()
    assert isinstance(lz, Lazy)
    assert str(lz) == "Lazy[Function]"
    assert lz.get() == 'happy'
    assert lz.flat_map(lambda v: Try.success(v + ' day')).get() == 'happy day'

    v = Validation.fail(['error 1', 'error 2'])
    lz = v.to_lazy()
    assert isinstance(lz, Lazy)
    assert str(lz) == "Lazy[Function]"
    assert lz.get() == None

# Generated at 2022-06-12 05:56:47.082463
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from random import random
    from pymonet.try_ import Try

    def funk():
        if random() < 0.5:
            raise Exception('test')
        return 1

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation.fail(['test'])
    assert validation.to_lazy() == Lazy(lambda: None)

    validation = Validation.success(funk())
    assert validation.to_lazy() == Lazy(lambda: funk())


# Generated at 2022-06-12 05:56:48.956863
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(3).to_lazy().get() == 3
    assert Validation.fail([3]).to_lazy().get() == None


# Generated at 2022-06-12 05:56:56.630914
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Test for to_lazy method.
    """
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:02.520980
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, LazyNone

    assert Validation.success(1).to_lazy() != LazyNone
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() != LazyNone
    assert Validation.fail().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:57:05.754600
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()

    assert lazy is not None
    assert isinstance(lazy, Lazy)
    assert lazy.evaluate() == 1

# Generated at 2022-06-12 05:57:08.190712
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 2

    val = Validation.success(f)
    assert val.to_lazy() == Lazy(f)

# Generated at 2022-06-12 05:57:26.258011
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def to_lazy():
        return Validation.success(42)
    assert isinstance(to_lazy(), Lazy)


# Generated at 2022-06-12 05:57:35.277596
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def validator(a):
        if a < 10:
            return Validation.success(a)
        else:
            return Validation.fail(['a should be less than 10'])

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert validator(5).to_lazy() == Lazy(lambda: 5)
    assert validator(20).to_lazy() == Lazy(lambda: None)
    assert validator(20).to_lazy().get_value() is None

# Unit tests for method to_try of class Validation

# Generated at 2022-06-12 05:57:38.047798
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # GIVEN
    validation = Validation.fail()

    # WHEN
    lazy = validation.to_lazy()

    # THEN
    assert lazy.eval() is None


# Generated at 2022-06-12 05:57:42.415687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('error1', 'error2').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:47.609743
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    empty = Validation.fail()
    value = Validation.success(10)
    assert empty.to_lazy().to_maybe().is_nothing()
    assert empty.to_lazy().to_try() == Try(None, False)
    assert value.to_lazy().to_maybe() == Maybe.just(10)
    assert value.to_lazy().to_try() == Try(10, True)


# Generated at 2022-06-12 05:57:51.922073
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that method to_lazy transforms Validation to Lazy.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:57:55.585876
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:00.578431
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    v = Validation.success('test')
    l = v.to_lazy()
    assert isinstance(l, Lazy), 'Validation to_lazy returns not Lazy'
    assert Lazy(lambda: 'test') == l, 'Validation to_lazy returns wrong Lazy'


# Generated at 2022-06-12 05:58:06.858799
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Check that to_lazy method of Validation function return Lazy monad
    with function that returns Validation value
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:09.062078
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def func():
        return 5
    assert Validation.success(func).to_lazy() == Lazy(func)
