

# Generated at 2022-06-12 05:48:35.937846
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:45.425396
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """A unit test for Validation.to_lazy()."""
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.functions import compose
    from pymonet.monad_lazy import compose_lazy

    def wrap(value):
        return Try.success(value)

    validation1 = Validation.success(value=1)
    validation2 = Validation.success(value=2)
    validation3 = Validation.fail(errors=[10, 20, 30])

    assert validation1.to_lazy() == Lazy(lambda: 1)
    assert validation2.to_lazy() == Lazy(lambda: 2)
    assert validation3.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:49.309549
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    test_Validation_to_lazy
    """
    from pymonet.lazy import Lazy

    x = Validation.success("a").to_lazy()
    assert x == Lazy(lambda: "a")


# Generated at 2022-06-12 05:48:56.297359
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def lazy_function():
        return 'value'

    result = Validation.success().to_lazy().get_value()
    assert result() == None

    result = Validation.fail().to_lazy().get_value()
    assert result() == None

    result = Validation.success('value').to_lazy().get_value()
    assert result() == 'value'

    result = Validation.fail(['error']).to_lazy().get_value()
    assert result() == 'error'

    result = Validation.success(lazy_function).to_lazy().get_value()
    assert result() == 'value'

    result = Validation.success(lambda: lazy_function()).to_lazy().get_value()
    assert result() == 'value'


# Generated at 2022-06-12 05:49:00.901588
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = Validation.success(1)
    result = value.to_lazy()
    assert isinstance(result, Lazy)
    assert result() == 1
    assert result.is_computed()


# Generated at 2022-06-12 05:49:10.465627
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def _test_Validation_to_lazy():
        from pymonet.either import Left, Right
        from pymonet.lazy import Lazy
        from pymonet.maybe import Maybe
        from pymonet.monad_try import Try
        from pymonet.box import Box

        lazy = Validation.success(1).to_lazy()
        assert lazy == Lazy(lambda: 1)

        lazy = Validation.fail(['error']).to_lazy()
        assert lazy == Lazy(lambda: None)

        assert Validation.success(1).to_either() == Right(1)
        assert Validation.fail(['error']).to_either() == Left(['error'])

        assert Validation.success(1).to_maybe() == Maybe.just(1)

# Generated at 2022-06-12 05:49:14.651276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Success Validation
    Validation.success('success').to_lazy() == \
        Lazy(lambda: 'success')

    # Fail Validation
    Validation.fail(['fail']).to_lazy() == \
        Lazy(lambda: None)


# Generated at 2022-06-12 05:49:19.547829
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail(['error1', 'error2']).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:49:24.026763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success('Success!')
    assert Validation.success(Lazy(lambda: 'Success!')) == validation.to_lazy()


# Generated at 2022-06-12 05:49:28.018248
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def calculation():
        return 20

    validation = Validation.success(Lazy(calculation))
    assert validation.to_lazy() == Lazy(lambda: 20)


# Generated at 2022-06-12 05:49:32.057044
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:36.484949
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    def test_fn():
        return 'Text'

    validation1 = Validation.success('Text')
    lazy1 = validation1.to_lazy()
    assert isinstance(lazy1, Lazy)
    assert lazy1.value == 'Text'

    lazy2 = Lazy(test_fn).to_validation()
    assert isinstance(lazy1, Validation)
    assert lazy2.value == 'Text'


# Generated at 2022-06-12 05:49:39.394192
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(1).to_lazy()
    assert lazy.run() == 1
    lazy = Validation.fail([]).to_lazy()
    assert lazy.run() is None


# Generated at 2022-06-12 05:49:43.174662
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # When Validation is successful
    assert Validation.success(42).to_lazy().get_value() == 42

    # When Validation is failed
    with pytest.raises(AttributeError):
        Validation.fail([42]).to_lazy().get_value()


# Generated at 2022-06-12 05:49:49.277174
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation.success(10).to_lazy().eval() == Lazy(lambda: 10).eval()
    assert Validation.fail([1,2,3]).to_lazy().eval() == Lazy(lambda: None).eval()


# Generated at 2022-06-12 05:49:52.167704
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:57.392043
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    result = Validation.fail('error').to_lazy()
    assert Lazy(lambda: None) == result

    result = Validation.success(1).to_lazy()
    assert Lazy(lambda: 1) == result

# Generated at 2022-06-12 05:50:05.502865
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def dummy_func():
        return 'result'

    assert Validation.success().to_lazy() == Lazy(lambda: None)

    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)

    assert Validation.success(dummy_func).to_lazy() == Lazy(lambda: dummy_func)

    assert Validation.fail(['error'], dummy_func).to_lazy() == Lazy(lambda: dummy_func)


# Generated at 2022-06-12 05:50:09.029693
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Try.unit(123) == Lazy(lambda: 123).bind(Try.unit)

# Generated at 2022-06-12 05:50:13.771839
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    validation = Validation.success(value)
    lazy = validation.to_lazy()
    assert(isinstance(lazy, Lazy))
    assert(lazy() == value)


# Generated at 2022-06-12 05:50:19.395248
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(42).to_lazy().get_value() == 42
    assert Validation.fail(['Error1']).to_lazy().get_value() is None

# Generated at 2022-06-12 05:50:24.025568
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Params(1).to_lazy()
    assert Lazy(lambda: None) != Params(1).to_lazy()


# Generated at 2022-06-12 05:50:30.386306
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""
    from pymonet.lazy import Lazy

    validation = Validation(1, None)

    assert isinstance(validation.to_lazy(), Lazy)
    assert validation.to_lazy().__repr__() == '<Lazy: <lambda>>'
    assert validation.to_lazy().take() == 1


# Generated at 2022-06-12 05:50:32.882755
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    some_func = lambda: 1
    some_exec = Validation.success(some_func)
    assert some_exec.to_lazy() == Lazy(some_func)

# Generated at 2022-06-12 05:50:38.416668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Assert that Validation.to_lazy convert Validation to Lazy monad
    """
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1
    assert Validation.fail([]).to_lazy().get() is None


# Generated at 2022-06-12 05:50:45.003917
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    # Check when Validation is successful
    try_value = Validation.success(0).to_lazy().get()
    assert try_value == 0

    # Check when Validation is failed
    try_value = Validation.fail([1]).to_lazy().get()
    assert try_value == None


# Generated at 2022-06-12 05:50:49.175713
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.success(2).to_lazy().value() == 2
    assert Validation.success(None).to_lazy().value() is None
    assert Validation.fail('error').to_lazy().value() is None


# Generated at 2022-06-12 05:50:50.973014
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(1).to_lazy()
    assert lazy.value() == 1



# Generated at 2022-06-12 05:50:59.771891
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Right

    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy) and lazy == Lazy(lambda: lazy._func()) and lazy._func() == None

    validation = Validation.success(5)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy) and lazy == Lazy(lambda: lazy._func()) and lazy._func() == 5

    validation = Validation.success(5)
    box = validation.to_box()
    assert isinstance(box, Box) and box == Box(5)

    validation = Validation.fail(['error'])
    either = validation.to_either

# Generated at 2022-06-12 05:51:03.062420
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('a').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:14.422145
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def _test_success(value):
        validation = Validation.success(value)
        lazy = validation.to_lazy()
        assert lazy.get() == value

    _test_success(1)
    _test_success('a')
    _test_success(True)
    _test_success(object())
    print('test_Validation_to_lazy :: Success')


# Generated at 2022-06-12 05:51:16.242272
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:51:19.905483
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:51:23.273895
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:51:27.136126
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from operator import add
    from pymonet.lazy import Lazy

    validation = Validation.success(5).map(add(1))
    assert validation.to_lazy() == Lazy(lambda: 6)



# Generated at 2022-06-12 05:51:31.502831
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success('value')
    assert success.to_lazy() == Lazy(lambda: 'value')
    fail = Validation.fail('errors')
    assert fail.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:51:32.938166
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:51:40.277879
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monoid import is_null
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation

    assert is_null(Validation.success(1).to_lazy(), Try(lambda: 1))
    assert is_null(Validation.fail([1]).to_lazy().map(lambda: None), Try(None))
    assert is_null(Validation.fail([1]).to_lazy().map(lambda: None), Try(None))


# Generated at 2022-06-12 05:51:43.359398
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 1
    assert Validation.success(f).to_lazy() == Lazy(f)


# Generated at 2022-06-12 05:51:52.957922
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.

    :return: None
    """
    from pymonet.lazy import Lazy

    # When successful Validation is transformed to Lazy monad, returned Lazy value should be
    # resolved to Validation value.
    successful_validation = Validation.success(12)
    lazy = successful_validation.to_lazy()
    assert lazy == Lazy(lambda: 12)

    # When failed Validation is transformed to Lazy monad, returned Lazy value should be
    # resolved to Validation value.
    failed_validation = Validation.fail(['error'])
    lazy = failed_validation.to_lazy()
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:08.805633
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:52:16.098430
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit tests for validation to_lazy method.
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # Unit test for function with one argument
    assert Validation.fail(errors=['test']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(value=43).to_lazy() == Lazy(lambda: 43)



# Generated at 2022-06-12 05:52:27.917232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test method to_lazy of class Validation.
    """
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def _test_lazy(x):
        assert x == Lazy(lambda: 1)

    _test_lazy(Lazy(lambda: 1))
    _test_lazy(Lazy(lambda: 1) >> Lazy(lambda: 2))
    _test_lazy(Lazy(lambda: 1) >> Box(2))
    _test_lazy(Lazy(lambda: 1).map(lambda x: x + 2))
    _test_lazy(Lazy(lambda: 1).ap(Lazy(lambda x: x + 2)))

# Generated at 2022-06-12 05:52:30.293948
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    x = Validation(None, [1, 2, 3])

    assert Lazy(lambda: x.value).get() is None


# Generated at 2022-06-12 05:52:33.451942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.fail(['1', '2'])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:36.351184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(True)
    lazy = Lazy(lambda: True)
    assert validation.to_lazy() == lazy


# Generated at 2022-06-12 05:52:40.874869
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    monad = Validation(1, [])

    assert monad.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:52:43.003385
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail(['error']).to_lazy().get() == None


# Generated at 2022-06-12 05:52:50.678686
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad import Thunk
    from pymonet.monad_try import Try
    from pymonet.monad import identity

    assert Lazy.unit(Validation.fail()).to_try(identity) == Try.fail()
    assert Lazy.unit(Validation.success(1)).to_try(identity) == Try.success(1)

    lazy = Lazy.unit(Validation.success(1))


# Generated at 2022-06-12 05:52:55.767666
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def executor():
        return 'test'

    assert Validation.success('test').to_lazy() == Lazy(executor)
    assert Validation.fail('test').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:27.423120
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        # GIVEN: Successful Validation with int value
        validation = Validation.success(42)

        # WHEN: Lazy monad created
        lazy = validation.to_lazy()

        # THEN: Lazy monad have to contain value from Validation
        assert lazy.value() == 42

        # GIVEN: Failed Validation
        validation = Validation.fail(["Error"])

        # WHEN: Lazy monad created
        lazy = validation.to_lazy()

        # THEN: Lazy monad have to contain None value
        assert lazy.value() is None

    except AssertionError as e:
        # THEN: AssertionError is raised
        raise e
    else:
        # THEN: no error is raised
        pass
    finally:
        # THEN: no error is raised
        pass

# Generated at 2022-06-12 05:53:32.085607
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation.to_lazy function.
    """
    from pymonet.lazy import Lazy

    _lazy = Lazy(lambda: ValueError('error'))

    assert Validation.fail([ValueError('error')]).to_lazy() == _lazy


# Generated at 2022-06-12 05:53:37.117695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy
    Lazy = pymonet.lazy.Lazy

    assert (Validation.fail(['error']).to_lazy() ==
            Lazy(lambda: None))
    assert (Validation.success(5).to_lazy() ==
            Lazy(lambda: 5))


# Generated at 2022-06-12 05:53:44.920091
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test of instance Validation to_lazy method. Validation is transformed to Lazy monad.
    """

    # given
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    validation = Validation(5, [])

    # when
    result = validation.to_lazy()

    # then
    assert result == Lazy(lambda: 5)


# Generated at 2022-06-12 05:53:48.316939
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    validation = Validation.fail(['error'])

    # when
    lazy = validation.to_lazy()

    # then
    assert callable(lazy.value)



# Generated at 2022-06-12 05:53:50.972454
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:53:53.696161
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:53:58.851052
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation(12, [])
    assert validation.to_lazy() == Lazy(lambda: 12)

    validation = Validation(None, ['error'])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:01.110796
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def unit():
        return 1

    assert unit() == 1

    lazy = Validation.success(1).to_lazy()
    assert lazy.get() == 1


# Generated at 2022-06-12 05:54:04.713685
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success(10)
    assert success.to_lazy() == Lazy(lambda: 10)

    fail = Validation.fail('error')
    assert fail.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:51.715708
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Validation.success(5).to_lazy()


# Generated at 2022-06-12 05:54:56.938930
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()
    assert Try(2) == Validation.success(2).to_lazy().force()
    assert Try(None, is_success=False) == Validation.fail([1, 2, 3]).to_lazy().force()


# Generated at 2022-06-12 05:55:01.397270
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy


    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:04.509658
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validate = Validation.success
    assert validate(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:55:09.258606
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Function that test to_lazy method of class Validation.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.monad_try import Try

    m = Validation.success(10)
    assert m.to_lazy().get() == 10

    m = Validation.fail([10, 20])
    assert isinstance(m.to_lazy().get(), Try)

# Generated at 2022-06-12 05:55:12.628044
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:21.179447
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success_value = 1
    success_validation = Validation.success(success_value)
    lazy_success_validation = success_validation.to_lazy()
    assert lazy_success_validation() == success_value

    fail_value = 1
    fail_validation = Validation.fail(fail_value)
    lazy_fail_validation = fail_validation.to_lazy()
    assert lazy_fail_validation() == lazy_fail_validation.value


# Generated at 2022-06-12 05:55:27.458728
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """ Unit test for method to_lazy of class Validation. """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 5) == Validation.success(5).to_lazy()
    assert Lazy(lambda: 5) == Validation.fail([]).to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['error']).to_lazy()


# Generated at 2022-06-12 05:55:32.898853
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_validation = Validation.success(5)
    assert success_validation.to_lazy() == Lazy(lambda: 5)

    fail_validation = Validation.fail(['error'])
    assert fail_validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:35.736777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.fail(['Error'])
    assert val.to_lazy() == Lazy(lambda: None)

    val = Validation.success('Value')
    assert val.to_lazy() == Lazy(lambda: 'Value')


# Generated at 2022-06-12 05:57:12.314223
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:57:16.070959
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(Box(1)).to_lazy() == Lazy(lambda: Box(1))


# Generated at 2022-06-12 05:57:19.232740
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(20).to_lazy() == Lazy(lambda: 20)
    assert Validation.fail([20]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:21.753410
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().force() == 1
    assert Validation.fail(1).to_lazy().force() is None



# Generated at 2022-06-12 05:57:26.621243
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(2).to_lazy()

    assert not result.is_evaluated()
    assert result.value == 2
    assert result.is_evaluated()

    result = Validation.fail([1]).to_lazy()
    
    assert not result.is_evaluated()
    assert result.value is None
    assert result.is_evaluated()


# Generated at 2022-06-12 05:57:36.222919
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def lazy_function():
        return "lazy world"

    def try_function():
        return "try world"

    assert Validation.success(lazy_function).to_lazy() == Lazy(lazy_function)
    assert Validation.fail(["e1", "e2"]).to_lazy() == Lazy(lambda: None)

    assert Validation.success(try_function).to_try() == Try(try_function)
    assert Validation.fail(["e1", "e2"]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-12 05:57:45.111904
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.monad import Monad
    from pymonet.monad_lazy import Lazy
    lazy = Lazy(lambda: Try.success(10))
    assert Validation.success(10).to_lazy() == Validation.success(lazy)
    assert Validation.success(10).to_lazy() == Validation.success(Lazy(lambda: 10))
    assert Validation.fail([]).to_lazy() == Validation.success(Lazy(lambda: None))
    assert Validation.fail([]).to_lazy() == Validation.success(Lazy(lambda: None))



# Generated at 2022-06-12 05:57:47.345237
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(1, [1, 2, 3]).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:57:54.607037
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:01.450929
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy
    import unittest

    class TestValidationToLazy(unittest.TestCase):
        """Test validation to lazy"""

        def test_to_lazy(self):
            """Test to_lazy"""
            value = 'Hello, world!'
            validation = Validation.success(value)
            self.assertEqual(Lazy(lambda: value), validation.to_lazy())

    unittest.main()
