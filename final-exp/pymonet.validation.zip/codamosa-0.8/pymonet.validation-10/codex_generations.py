

# Generated at 2022-06-12 05:48:39.741364
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    value = 3

    # When
    result = Validation.success(value).to_lazy()

    # Then
    assert isinstance(result, Lazy)

    assert result.value() == value


# Generated at 2022-06-12 05:48:43.785404
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success([1, 2, 3])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert Try([1, 2, 3]) == lazy._value()

# Generated at 2022-06-12 05:48:53.824901
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    # Successful case
    result = Validation.success(5).to_lazy()
    assert result.get() == 5
    # Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert result == Lazy(lambda: 5)
    # Fail case
    result = Validation.fail([1, 2, 3]).to_lazy()
    assert result.get() is None
    # Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)
    assert result == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:01.216494
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def plus_two():
        return 2 + 2

    value = Lazy(plus_two)
    assert Validation.success(value).to_lazy() == value

    value = Lazy(lambda: Box.from_value(5).map(lambda x: x * x))
    assert Validation.success(value).to_lazy() == value


# Generated at 2022-06-12 05:49:06.065656
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    >>> from pymonet.validation import Validation
    >>> v = Validation.success(True)
    >>> t = v.to_lazy()
    >>> assert t == Lazy(lambda: True)
    """
    pass


# Generated at 2022-06-12 05:49:11.494704
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def _get_success_lazy():
        return Validation.success(5).to_lazy()

    def _get_fail_lazy():
        return Validation.fail([5]).to_lazy()

    assert _get_success_lazy().value() == 5
    assert _get_fail_lazy().value() is None


# Generated at 2022-06-12 05:49:15.205320
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = Validation.success(5).to_lazy()
    assert isinstance(value, Lazy)
    assert callable(value.value)
    assert value.value() == 5


# Generated at 2022-06-12 05:49:19.826520
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    a = Validation.fail(["error1"])
    assert Lazy(lambda: None) == a.to_lazy()
    b = Validation.success(1)
    assert Lazy(lambda: 1) == b.to_lazy()


# Generated at 2022-06-12 05:49:27.627348
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    success_validation = Validation.success(lambda: 'value')
    result = success_validation.to_lazy()
    assert isinstance(result, Lazy)
    assert result.get()() == 'value'

    fail_validation = Validation.success(lambda: None)
    result = fail_validation.to_lazy()
    assert isinstance(result, Lazy)
    assert result.get()() is None


# Generated at 2022-06-12 05:49:29.822674
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-12 05:49:35.808992
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success({'a': 1}).to_lazy() == Lazy(lambda: {'a': 1})
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:38.650059
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.call() == 1


# Generated at 2022-06-12 05:49:41.731012
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert(Validation.success(10).to_lazy() == Lazy(lambda: 10))
    assert(Validation.fail().to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-12 05:49:44.163632
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = Lazy(lambda: 'value')
    validation = Validation.success(value)

    assert validation.to_lazy() == value

# Generated at 2022-06-12 05:49:54.517952
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Testing method to_lazy of Validation class"""
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Successful validation, lazy should be also successful
    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    # Failed validation, lazy should be also failed
    assert Validation(None, ['a']).to_lazy() == Lazy(lambda: None)
    # Value not None, result of lazy function should return function value
    assert Validation('a', []).to_lazy() == Lazy(lambda: 'a')
    # Value not None, result of lazy function should return function value
    assert Validation(Try(5), []).to_lazy() == Lazy(lambda: Try(5))


# Generated at 2022-06-12 05:50:00.682440
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, LazyObject
    def test_function():
        raise Exception("test")

    validation = Validation.fail([])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert isinstance(lazy, LazyObject)
    assert [[]] == lazy.call()


# Generated at 2022-06-12 05:50:04.976556
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:05.828022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass



# Generated at 2022-06-12 05:50:11.594799
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(13).to_lazy() == Lazy(lambda: 13)
    assert Validation.fail(['error_1']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:18.344760
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1
    assert lazy.is_success()

    lazy = Validation.fail([1, 2]).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() is None
    assert lazy.is_success() is False


# Generated at 2022-06-12 05:50:27.705145
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def check_validation_to_lazy(expected):
        assert Validation.success(expected).to_lazy() == Lazy(lambda: expected)
        assert Validation.fail().to_lazy() == Lazy(lambda: None)

    check_validation_to_lazy(42)
    check_validation_to_lazy([])
    check_validation_to_lazy('aaa')


# Generated at 2022-06-12 05:50:31.618616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:39.226907
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    def to_lazy(self):
        Transform Validation to Try.

        :returns: Lazy monad with function returning Validation value
        :rtype: Lazy[Function() -> (A | None)]
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(0)
    lazy = validation.to_lazy()
    assert(lazy == Lazy(lambda: 0))

    validation = Validation.fail(0)
    lazy = validation.to_lazy()
    assert(lazy == Lazy(lambda: None))


# Generated at 2022-06-12 05:50:50.025117
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from operator import add, truediv
    from pymonet.monad_try import Failure
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    add_five = lambda v: add(v, 5)

    def raise_exception():
        raise Exception('Division by zero')

    def divide(v):
        d = truediv(7, v)
        if v == 0:
            return Failure(Exception('Division by zero'))
        return Validation.success(d)

    assert Validation.success(5).to_lazy() == \
           Lazy(lambda: 5)

    assert Validation.success(5).map(add_five).to_lazy() == \
           Lazy(lambda: 10)


# Generated at 2022-06-12 05:50:54.014664
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:50:58.953298
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:01.974968
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail(["error"]).to_lazy() == Lazy(lambda: None)
    assert Validation.success("value").to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:51:07.527978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Success, Failure

    validation = Validation.success(Box(1))
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value == 1

    validation = Validation.fail('A')
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value is None



# Generated at 2022-06-12 05:51:09.555385
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-12 05:51:14.529225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation.to_lazy method.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(val).to_lazy() == Lazy(lambda : val)
    assert Validation.fail(errors).to_lazy() == Lazy(lambda : None)


# Generated at 2022-06-12 05:51:21.616369
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    error = ValueError()
    validation = Validation.fail([error])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value.evaluate() == validation.value

# Generated at 2022-06-12 05:51:26.277176
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    
    value = '42'

    validation = Validation(value, [])

    def checker():
        return validation.to_lazy() == Lazy(lambda: value)

    assert checker()


# Generated at 2022-06-12 05:51:31.454668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """Test to_lazy method of class Maybe"""
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
    assert Validation.fail("Error").to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:34.487393
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(5).to_lazy()
    assert result.get() == 5

    assert Validation.fail(['error']).to_lazy().get() is None


# Generated at 2022-06-12 05:51:37.543036
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().call() == 1
    assert Validation.fail(['Not a number']).to_lazy().call() is None


# Generated at 2022-06-12 05:51:44.065214
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): 
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy


    assert Validation.success([]).to_lazy() == Lazy(lambda: [])
    assert Validation.success([1, 2]).to_lazy() == Lazy(lambda: [1, 2])
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(Try.success('a')).to_lazy() == Lazy(lambda: 'a')


# Generated at 2022-06-12 05:51:48.077466
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success('value').to_lazy()
    assert isinstance(val, Lazy)
    assert val.get_value() == 'value'



# Generated at 2022-06-12 05:51:53.771203
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Validation.success(1).to_lazy()
    assert lazy.get() == 1

    lazy = Validation.fail(['error']).to_lazy()
    assert lazy.get() is None

    lazy = Validation.success(1).to_lazy().map(lambda value: value + 1).get()
    assert lazy == 2

    lazy = Lazy(lambda: Try(1)).to_lazy()
    assert lazy.get().value == 1


# Generated at 2022-06-12 05:51:57.679045
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit tests to prove correctness of Validation to_lazy method.
    """
    from pymonet.lazy import Lazy

    assert Validation(2, []).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:52:03.407832
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:12.177414
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('success').to_lazy().value() == 'success'

# Generated at 2022-06-12 05:52:17.575468
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    from pymonet.monad_try import Try

    validation = Validation.success('value')
    assert validation.to_lazy() == Lazy(lambda: 'value')

    validation = Validation.fail(['error'])
    assert validation.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:52:20.805044
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('a')
    assert validation.to_lazy().value() == 'a'

    validation = Validation.fail(['a'])
    assert validation.to_lazy().value() == None

# Generated at 2022-06-12 05:52:22.592813
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy() == 1


# Generated at 2022-06-12 05:52:27.591271
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: "to_lazy_success") == Validation("to_lazy_success", []).to_lazy()
    assert Validation(None, ["to_lazy_fail"]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:52:32.015813
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    # Given
    validation_value = Validation('value')

    # When
    lazy = validation_value.to_lazy()

    # Then
    assert lazy.force() == validation_value.value


# Generated at 2022-06-12 05:52:36.447758
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    from pymonet.lazy import Lazy

    value = 1
    assert Validation.success(value).to_lazy() == Lazy(lambda: value)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:42.423341
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def add_one(value):
        return value + 1

    validation = Validation.success(10)
    assert validation.to_lazy().map(add_one).value() == 11

    validation = Validation.fail([WrongTypeError])
    assert validation.to_lazy().map(add_one).value() is None
    assert validation.to_lazy().map(add_one).is_fail() is True


# Generated at 2022-06-12 05:52:46.588078
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Should create Lazy monad with function returning Validation value.
    """
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-12 05:52:52.856822
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.fail([1, 2])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    lazy_value = lazy.value
    assert validation.value == lazy_value

    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    lazy_value = lazy.value
    assert validation.value == lazy_value

# Generated at 2022-06-12 05:53:15.147226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    maybe1 = Maybe.just(2)
    try1 = Try.success(2)
    validation1 = Validation.success(2)

    assert (maybe1.join().to_lazy() ==
            try1.join().to_lazy() ==
            validation1.to_lazy() ==
            Lazy(2))

    maybe2 = Maybe.nothing()
    try2 = Try.fail(ValueError('error'))
    validation2 = Validation.fail(['error'])

    assert (maybe2.join().to_lazy() ==
            try2.join().to_lazy() ==
            validation2.to_lazy() ==
            Lazy(None))



# Generated at 2022-06-12 05:53:20.678683
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    v = Validation.success(Try(42, is_success=True))
    assert v.to_lazy() == Lazy(lambda: Try(42, is_success=True))

# Generated at 2022-06-12 05:53:24.871929
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # success
    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy(5)

    # fail
    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:53:30.273902
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:34.495975
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Try.success(Validation.success(1)).to_lazy().get() == 1
    assert Try.fail(Validation.fail([])).to_lazy().get() is None



# Generated at 2022-06-12 05:53:37.762314
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_validation = Validation.success(5).to_lazy()

    assert isinstance(lazy_validation, Lazy)
    assert lazy_validation.value() == 5


# Generated at 2022-06-12 05:53:43.410465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation.fail([1, 2, 3])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:53.199851
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    success = Validation.success(value='success')
    f = Functor(functor=success).map(lambda x: x)
    assert f(Lazy(lambda: Try(lambda: 'success'))) == Validation.success(value='success')

    fail = Validation.fail(errors=['fail'])
    f = Functor(functor=fail).map(lambda x: x)
    assert f(Lazy(lambda: Try(lambda: 'success'))) == Validation.fail(errors=['fail'])


# Generated at 2022-06-12 05:53:58.031711
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(-90.0).to_lazy() == Lazy(lambda: -90.0)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:06.562409
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.test.test_lazy import test_lazy_with_param
    from pymonet.test.test_monad_try import test_Try_success, test_Try_fail

    def test_lazy_with_param_on_Validation(value):
        return test_lazy_with_param(lambda: value, Validation.success(value).to_lazy())

    def test_lazy_with_param_on_Validation_fail(value):
        return test_lazy_with_param(lambda: value, Validation.fail(value).to_lazy())

    def test_Try_success_on_Validation(value):
        return test_Try_success(value, Validation.success(value).to_try())


# Generated at 2022-06-12 05:54:39.390466
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_monad = Validation.success('foo').to_lazy()

    assert lazy_monad == Lazy(lambda: 'foo')

# Generated at 2022-06-12 05:54:43.632294
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['Err']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:50.172613
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def test_function():
        return 'Test'
    validation = Validation.success(test_function)
    assert validation.to_lazy() == Lazy(test_function)
    validation = Validation.fail(['Error'])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:54.744764
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def a():
        return 1

    lazy = Validation.success().map(a).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1


# Generated at 2022-06-12 05:55:00.220958
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    validation = Validation.success(10).to_lazy()

    assert isinstance(validation, Lazy)

    # Validation should be evaluated due to usage of to_maybe method
    assert validation.to_maybe().value == Just(10)



# Generated at 2022-06-12 05:55:04.172745
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Maybe, Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:07.882739
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v1 = Validation.success(1)
    v2 = Validation.fail([])
    assert v1.to_lazy() == Lazy(lambda : 1)
    assert v2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:12.627515
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_monad = Validation(5, []).to_lazy()
    assert lazy_monad.force() == 5
    lazy_monad = Validation(None, [5]).to_lazy()
    assert lazy_monad.force() is None


# Generated at 2022-06-12 05:55:18.029187
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def check(value):
        return Validation.fail([]) if value else Validation.success(value)

    validation_value = Validation(100, [])

    assert validation_value == validation_value.to_lazy().get_lazy()


# Generated at 2022-06-12 05:55:23.301254
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """ Test case for Validation to_lazy method """
    from pymonet.lazy import Lazy

    # Test for successful Validation
    assert Lazy(4) == Validation.success(4).to_lazy()

    # Test for failed Validation
    assert Lazy(None) == Validation.fail([]).to_lazy()


# Generated at 2022-06-12 05:56:28.926226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([1]).to_lazy().get() == 1


# Generated at 2022-06-12 05:56:31.843422
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')

# Generated at 2022-06-12 05:56:38.730648
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert isinstance(Validation.success(1).to_lazy(), Lazy)
    assert Validation.success(1).to_lazy().value() == 1
    assert isinstance(Validation.fail([1]).to_lazy(), Lazy)
    assert Validation.fail([1]).to_lazy().value() is None



# Generated at 2022-06-12 05:56:44.191792
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    def _success_lazy_func():
        return 1

    def _fail_lazy_func():
        return None

    assert Lazy(_success_lazy_func) == Validation.success(1).to_lazy()
    assert Lazy(_fail_lazy_func) == Validation.fail().to_lazy()


# Generated at 2022-06-12 05:56:47.233428
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1 + 1)
    lazy = validation.to_lazy()
    assert lazy.value() == 2


# Generated at 2022-06-12 05:56:53.712170
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Success Validation to Lazy
    validation = Validation.success(10)
    lazy = validation.to_lazy()
    value = lazy.value
    assert (value == 10)

    # Fail Validation to Lazy
    validation = Validation.fail([10])
    lazy = validation.to_lazy()
    value = lazy.value
    assert (value is None)


# Generated at 2022-06-12 05:56:56.880848
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1).get() == Validation.success(1).to_lazy().get()



# Generated at 2022-06-12 05:57:00.883520
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(5)  # Create Validation with value 5
    lazy = val.to_lazy()  # Convert Validation to Lazy
    assert lazy.get() == val.value  # Check that Lazy returns the same value


# Generated at 2022-06-12 05:57:04.839565
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.fail(['message 1', 'message 2']).to_lazy()
    assert result.value() is None, 'fail value should be None'
    result = Validation.success(1).to_lazy()
    assert result.value() == 1


# Generated at 2022-06-12 05:57:10.451702
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    def f():
        return 'foo'

    assert Validation.success(f()).to_lazy() == Lazy(f)
    assert Validation.success(f()).to_try() == Try('foo')