

# Generated at 2022-06-12 05:48:34.262160
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(3)
    assert v.to_lazy() == Lazy.of(3)


# Generated at 2022-06-12 05:48:39.847729
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:48:47.800048
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Either
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def assert_lazy_value(lazy, expected_value):
        assert lazy.value() == expected_value

    assert_lazy_value(Validation.success(1).to_lazy(), 1)
    assert_lazy_value(Validation.success(Box(1)).to_lazy(), Box(1))
    assert_lazy_value(Validation.fail([1]).to_lazy(), None)
    assert_lazy_value(Validation.success(Either.success(1)).to_lazy(), Either.success(1))
    assert_lazy_value(Validation.fail([1]).to_lazy(), None)

# Generated at 2022-06-12 05:48:51.031546
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('A').to_lazy().force() == 'A'
    assert Validation.fail(['A']).to_lazy().force() is None


# Generated at 2022-06-12 05:48:57.688069
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Either
    from pymonet.monad_lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:03.350013
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from prymon.lazy import Lazy

    test_cases = [
        (Validation.success(10), Lazy(lambda: 10)),
        (Validation.fail(['Error']), Lazy(lambda: None))
    ]

    for test_case in test_cases:
        assert test_case[0].to_lazy() == test_case[1]


# Generated at 2022-06-12 05:49:07.278735
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    _value = 'value'
    _validation = Validation.success(_value)

    actual = _validation.to_lazy()
    assert isinstance(actual, Lazy)

    lazy_value = actual.value()
    assert lazy_value == _value


# Generated at 2022-06-12 05:49:12.723879
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
    assert Validation.fail([100, 200]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:19.083410
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.try_ import Failure
    from pymonet.lazy import Lazy

    f_lazy = Validation(1, [1, 2, 3]).to_lazy()
    s_lazy = Validation(1, []).to_lazy()

    assert f_lazy.value() is None
    assert s_lazy.value() == 1


# Generated at 2022-06-12 05:49:24.629893
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert isinstance(Validation.success(42).to_lazy(), Lazy)
    assert Validation.success(42).to_lazy().force() == 42
    assert isinstance(Validation.success(42).to_lazy(), Lazy)
    assert Validation.fail([42]).to_lazy().force() is None



# Generated at 2022-06-12 05:49:30.709623
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation.
    """
    from pymonet.lazy import Lazy

    value = 'value'
    assert Validation.success(value).to_lazy() == Lazy(lambda: value)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:37.106023
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure, Success

    def divide(x, y):
        """
        Divide function to test Lazy catch block.
        """
        return x / y

    def divide_to_try(x, y):
        """
        Divide function to test Try catch block.
        """
        return Try.wrap(lambda: x / y).on_failure(lambda: 0)

    validation = Validation.success(10)
    lazy_value_1 = validation.to_lazy().map(lambda x: divide(x, 2)).eval()
    lazy_value_2 = validation.to_lazy().map(lambda x: divide(x, 0)).eval()

# Generated at 2022-06-12 05:49:39.631189
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    assert validation.to_lazy() == Lazy(10)


# Generated at 2022-06-12 05:49:44.594390
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Function that tests method to_lazy of class Validation.
    """
    from pymonet.monad_try import Try

    test_value = 'test'
    test_validation = Validation.success(test_value)
    test_lazy = test_validation.to_lazy()

    assert test_validation.value == test_lazy()


# Generated at 2022-06-12 05:49:48.710385
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.functions import pipeable
    from pymonet.lazy import Lazy

    lazy = pipeable(Validation.success(10)) | Validation.to_lazy

    assert lazy | Lazy.get == 10



# Generated at 2022-06-12 05:49:50.880048
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 05:49:54.509358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def lazy_function():
        return 'asd'
    lazy = Lazy(lazy_function)
    validation = Validation.success(lazy_function)
    assert validation.to_lazy() == lazy


# Generated at 2022-06-12 05:49:57.899908
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(9).to_lazy().evaluate() == 9
    assert Validation.fail(errors=['Error']).to_lazy().evaluate() == None


# Generated at 2022-06-12 05:50:02.835992
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['KeyError']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-12 05:50:06.000105
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == (
        Lazy(lambda: 1)
    )

# Generated at 2022-06-12 05:50:10.732615
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-12 05:50:13.586853
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('test_value')
    assert validation.to_lazy() == Lazy(lambda: 'test_value')


# Generated at 2022-06-12 05:50:17.584122
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validation = Validation.success().to_lazy()

    assert validation.value() == None
    assert validation == Lazy(lambda: validation.value)


# Generated at 2022-06-12 05:50:21.348125
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:27.099513
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(2).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 2

    result = Validation.fail(['error 1', 'error 2']).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() is None



# Generated at 2022-06-12 05:50:31.489753
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    actual = Validation.success('hello').to_lazy()
    expected = Lazy(lambda: 'hello')
    print(actual, expected)
    assert actual == expected


# Generated at 2022-06-12 05:50:35.188344
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert (Validation.success(Box.just(2)).to_lazy() ==
            Lazy(Box.just(2).get))



# Generated at 2022-06-12 05:50:42.844395
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_list import List
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success('1').to_lazy() == Lazy(lambda: '1')
    assert Validation.success([1, 2]).to_lazy() == Lazy(lambda: [1, 2])
    assert Validation.success((1, 2)).to_lazy() == Lazy(lambda: (1, 2))

# Generated at 2022-06-12 05:50:48.044315
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['a', 'b', 'c']).to_lazy()


# Generated at 2022-06-12 05:50:52.029414
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == \
        Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == \
        Lazy(lambda: None)


# Generated at 2022-06-12 05:50:58.905727
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success('test')
    lazy = v.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 'test'


# Generated at 2022-06-12 05:51:02.378695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    validation = Validation(value, ['error'])
    lazy = Lazy(lambda: value)
    assert lazy == validation.to_lazy()


# Generated at 2022-06-12 05:51:07.312886
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_lazy = Validation.success('value').to_lazy()
    assert(isinstance(success_lazy, Lazy))
    assert(success_lazy.value() == 'value')

    fail_lazy = Validation.fail(['error']).to_lazy()
    assert(isinstance(fail_lazy, Lazy))
    assert(fail_lazy.value() is None)


# Generated at 2022-06-12 05:51:13.639694
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    v = Validation.success(2)
    # Test lazy monad for success Validation
    assert v.to_lazy() == Lazy(lambda: 2)

    v = Validation.fail([1])
    # Test lazy monad for success Validation
    assert v.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:16.341641
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(1)
    assert v.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:51:22.280468
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy

    lazy = Lazy(Functor(lambda: 1))

    assert Validation.success(1).to_lazy() == lazy
    assert Validation.success(1).to_lazy() != lazy
    assert Validation.success(1).to_lazy() != Lazy(Functor(Validation.success(1)))
    assert Validation.success(1).to_lazy() == Lazy(Functor(Validation.success(1)))


# Generated at 2022-06-12 05:51:25.326946
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def lazy_factory():
        return 100

    monad = Validation.success(100)
    assert monad.to_lazy() == Lazy(lazy_factory)

# Generated at 2022-06-12 05:51:30.985561
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation_success = Validation.success(Try(1))
    validation_fail = Validation.fail([1])

    assert validation_success.to_lazy() == Lazy(lambda: Try(1))
    assert validation_fail.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:36.150694
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method Validation.to_lazy
    """
    from pymonet.lazy import Lazy

    assert Validation.success('abc').to_lazy() == Lazy(lambda : 'abc')

    assert Validation.fail(['err']).to_lazy() == Lazy(lambda : None)


# Generated at 2022-06-12 05:51:39.842227
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    f = lambda: 'foo'
    value = f()
    lazy = Validation(value, []).to_lazy()

    assert lazy.is_success() is True
    assert lazy.value == f
    assert lazy.value() == value



# Generated at 2022-06-12 05:51:48.232505
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation to_lazy method.
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:52.294070
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:04.119017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    from pymonet.monad import Monad
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.lazy import Lazy

    from pymonet.monad_test import assert_monad, assert_functor, assert_applicative
    from pymonet.lazy_test import assert_lazy

    def get_test_instances():
        """
        Returns instances of Validation for Functor, Applicative and Monad.

        :returns: list of Functor/Applicative/Monad instances
        :rtype: List[Validation[Int, String]]
        """

# Generated at 2022-06-12 05:52:09.108140
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def lazy_mapper(x):
        return x + 1

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.is_forced is False
    assert lazy.value() == 1

    lazy2 = Validation.success(1).map(lazy_mapper).to_lazy()
    assert isinstance(lazy2, Lazy)
    assert lazy2.is_forced is False
    assert lazy2.value() == 2

# Generated at 2022-06-12 05:52:15.345669
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy function.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(errors=['failure']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:18.422336
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('foo')
    lazy = validation.to_lazy()

    assert lazy.call() == validation.value
    assert lazy.get() == validation.value


# Generated at 2022-06-12 05:52:20.006993
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(None).to_lazy().unit == None

# Generated at 2022-06-12 05:52:27.823184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail('1').to_lazy() == Lazy(lambda: None)
    assert Validation.success('1').to_lazy() == Try('1', True)
    assert Validation.fail(1).to_lazy() == Try(None, False)


# Generated at 2022-06-12 05:52:33.058873
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test function tests if Validation is transformed to Lazy successfully.
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get_value() == 1


# Generated at 2022-06-12 05:52:39.586271
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(5, [])
    lazy_val = validation.to_lazy()
    assert lazy_val.is_success
    assert lazy_val.value == 5
    assert lazy_val is Lazy(lambda: 5)

    validation = Validation(None, ['error'])
    lazy_val = validation.to_lazy()
    assert not lazy_val.is_success
    assert lazy_val.value is None
    assert lazy_val is Lazy(lambda: None)


# Generated at 2022-06-12 05:52:44.232399
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:50.872363
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def ten():
        return 10

    def ten_lazy():
        return Lazy(ten)

    assert Validation.success(ten_lazy()).to_lazy() == Lazy(ten_lazy)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:56.719362
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    """Test to_lazy method of class Validation"""

    from pymonet.lazy import Lazy

    lazy_function = Lazy(lambda: 2 + 2)
    Validation.success(4).to_lazy() == lazy_function
    assert Validation.success(4).to_lazy() == lazy_function


# Generated at 2022-06-12 05:52:59.761373
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(2).to_lazy()
    assert callable(result.value)
    assert result.value() == 2

    result = Validation.fail([2]).to_lazy()
    assert callable(result.value)
    assert result.value() == None

# Generated at 2022-06-12 05:53:08.021007
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def check(value):
        success = Validation.success(value)
        failure = Validation.fail()
        assert success.to_lazy() == Lazy(lambda: value)
        assert failure.to_lazy() == Lazy(lambda: None)
    check(None)
    check('t')
    check(2)


# Generated at 2022-06-12 05:53:11.810345
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1,2,3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:15.330017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.fail(['error1', 'error2']).to_lazy()
    assert isinstance(v, Lazy)
    assert v() == None


# Generated at 2022-06-12 05:53:21.204226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(10)
    assert validation.to_lazy().run() == 10, 'Validation[10] should be 10'

    validation = Validation.fail([1, 2])
    assert validation.to_lazy().run() is None, 'Validation[None] should be None'


# Generated at 2022-06-12 05:53:24.209803
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 10
    result = Validation.success(value).to_lazy()

    assert isinstance(result, Lazy)
    assert result.value == value

# Generated at 2022-06-12 05:53:28.118072
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test cases for to_lazy method"""
    from ..lazy import Lazy
    from . import assert_lazy, assert_value

    assert_lazy(lambda: Lazy(lambda: 10), Validation(10, []).to_lazy())
    with pytest.raises(Exception):
        assert_value(10, Validation(None, [10]).to_lazy())


# Generated at 2022-06-12 05:53:35.548910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:37.209022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:53:43.183576
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation.
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(True).map(lambda x: x + 1).to_lazy() == Lazy(lambda: True)
    assert Validation.success(Try.success(lambda: 4)).to_lazy() == Lazy(lambda: Try.success(lambda: 4))


# Generated at 2022-06-12 05:53:48.848916
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def lazy_func():
        return 1

    validated = Validation(1, [])
    assert validated.to_lazy() == Lazy(lazy_func)


# Generated at 2022-06-12 05:53:58.596661
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Initialize lazy
    lazy = Validation.success(42).to_lazy()

    # Check lazy class
    assert(isinstance(lazy, Lazy))

    # Check lazy callable
    assert(lazy() == 42)

    # Initialize lazy
    lazy = Validation.fail(['bad']).to_lazy()

    # Check lazy class
    assert(isinstance(lazy(), Try))

    # Check lazy failure value
    assert(not lazy().is_success())



# Generated at 2022-06-12 05:54:00.858758
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = Lazy(lambda: 'abc').to_validation().to_lazy()
    assert 'abc' == value()

# Generated at 2022-06-12 05:54:05.096912
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    def test_func():
        return 'test'
    validation = Validation.success('test')
    assert validation.to_lazy() == Lazy(test_func)
    validation = Validation.fail('error')
    assert validation.to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:54:11.760062
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation

    Validation.to_lazy() should:
        - return Lazy which returns value for Validation when is successful
        - return Lazy which returns None for Validation when is failed
    """
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:13.990135
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = lambda: 2 + 2
    result = Validation.success(value).to_lazy().value
    assert result == 4


# Generated at 2022-06-12 05:54:18.083336
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'value'

    validation = Validation.success('value')
    assert validation.to_lazy() == Lazy(f)

# Generated at 2022-06-12 05:54:31.265934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success([1, 2, 3])
    assert validation.to_lazy() == Lazy(lambda: [1, 2, 3])

    validation = Validation.fail([1, 2, 3])
    assert validation.to_lazy() == Lazy(lambda: None)

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation.fail(1)
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:35.577538
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation('a', []).to_lazy() == Lazy(lambda: 'a')
    assert Validation(None, ['error', 'another error']).to_lazy() == Lazy(None)



# Generated at 2022-06-12 05:54:39.606805
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:42.108961
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v = Validation.success(2)
    assert v.to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-12 05:54:46.737546
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy () method
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:54:53.856469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy() != Lazy(lambda: 2)


# Generated at 2022-06-12 05:55:02.125763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.

    :returns: nothing
    :rtype: None
    """
    monad = Validation.success(5)

    assert monad.to_lazy().evaluate() == 5
    assert monad.to_lazy().map(lambda x: x + 1).evaluate() == 6
    assert monad.to_lazy().flat_map(lambda x: Lazy(lambda: x + 1)).evaluate() == 6


# Generated at 2022-06-12 05:55:05.285335
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        pass

    lazy = Lazy(func)

    assert lazy.to_lazy() is lazy

# Generated at 2022-06-12 05:55:08.485942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:12.071286
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(42)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 42)


# Generated at 2022-06-12 05:55:18.181464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:55:22.693672
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:29.313781
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:55:31.119326
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1


# Generated at 2022-06-12 05:55:39.734859
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test function
    """
    # Given
    success_validation = Validation.success('value')
    fail_validation = Validation.fail()

    # When
    success_lazy = success_validation.to_lazy()
    fail_lazy = fail_validation.to_lazy()

    # Then
    assert success_lazy() == 'value'
    assert success_lazy().is_success()

    assert fail_lazy() == None
    assert not fail_lazy().is_success()


# Generated at 2022-06-12 05:55:46.226019
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.success(Maybe.just(5)).to_lazy() == Lazy(lambda: Maybe.just(5))
    assert Validation.success(Maybe.nothing()).to_lazy() == Lazy(lambda: Maybe.nothing())
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:51.633232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # When Validation is failure
    validation = Validation.fail([1, 2, 3])
    expected = Lazy(lambda: None)
    actual = validation.to_lazy()
    assert actual == expected

    # When Validation is successful
    validation = Validation.success(5)
    expected = Lazy(lambda: 5)
    actual = validation.to_lazy()
    assert actual == expected


# Generated at 2022-06-12 05:55:53.961323
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(1).to_lazy().to_monad()
    assert(result.value == 1)



# Generated at 2022-06-12 05:56:00.811497
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy as lazy

    def func(value):
        return value

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(func(validation.value))
    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(func(validation.value))


# Unit tests for method ap of class Validation

# Generated at 2022-06-12 05:56:06.365690
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy_val = Validation.success(2).to_lazy()
    assert lazy_val == Lazy(lambda:2)

    lazy_val = Validation.fail([1, 2, 3]).to_lazy()
    assert lazy_val == Lazy(lambda:None)


# Generated at 2022-06-12 05:56:19.881509
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [0]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:22.353256
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    try_val = Try(1)
    assert Validation.success(1).to_lazy() == try_val

# Generated at 2022-06-12 05:56:24.866951
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def calc():
        return 10

    lazy = Lazy(calc)
    validation = Validation.success(lazy)
    assert validation.to_lazy() == lazy

# Generated at 2022-06-12 05:56:27.599724
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(Box(5)).to_lazy() == Lazy(lambda: Box(5))



# Generated at 2022-06-12 05:56:31.254841
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 10


# Generated at 2022-06-12 05:56:34.217434
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')


# Generated at 2022-06-12 05:56:43.305982
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.functor import Function

    def _map_f(x):
        return x + 1

    # Successful validation
    successful_val = Validation.success(1)
    # Transform validation to Lazy
    lazy_val = successful_val.to_lazy()

    # Apply function to Validation
    lazy_val_applied = lazy_val.map(_map_f)
    # Call Lazy value
    lazy_val_applied_value = lazy_val_applied.value()

    # Assert that lazy is successfully evaluated
    assert lazy_val_applied_value.value == 2

    # Failed validation
    failed_val = Validation.fail([])
    # Transform validation to Lazy
    lazy_val = failed_val.to_lazy()

    # Apply function

# Generated at 2022-06-12 05:56:47.615018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(33).to_lazy() == Lazy(lambda: 33)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:49.777889
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation(2, [])

    assert val.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:56:55.673919
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success("string").to_lazy() == Lazy(lambda: "string")
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:57:15.037264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Test with success
    result = Validation.success(10).to_lazy()
    assert isinstance(result, Lazy)
    assert result.to_value() == 10

    # Test with fail
    result = Validation.fail([1, 2, 3]).to_lazy()
    assert isinstance(result, Lazy)
    assert result.to_value() is None

# Generated at 2022-06-12 05:57:24.132255
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit tests for Validation.to_lazy().

    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    val1 = Validation.success(100)
    assert val1.to_lazy() == Lazy(lambda: 100)
    assert val1.to_lazy().get() == 100

    val2 = Validation.fail()
    assert val2.to_lazy() == Lazy(lambda: None)

    val3 = Validation.fail(errors=['some error'])
    assert val3.to_lazy() == Lazy(lambda: None)
    assert val3.to_lazy().get() == None


# Generated at 2022-06-12 05:57:28.228375
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Validation.success("value").to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy == Lazy(lambda: "value")


# Generated at 2022-06-12 05:57:33.162868
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_validation = Validation.success(2)
    assert success_validation.to_lazy() == Lazy(lambda: 2)

    fail_validation = Validation.fail([])
    assert fail_validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:39.789299
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test method Validation.to_lazy."""
    from pymonet.lazy import Lazy

    value = 5
    funct = lambda: 5
    success_validation = Validation.success(value)
    fail_validation = Validation.fail(['error'])
    assert success_validation.to_lazy() == Lazy(funct)
    assert fail_validation.to_lazy() == Lazy(funct)


# Generated at 2022-06-12 05:57:46.044244
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(15).to_lazy() == Lazy(lambda: 15)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([None]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:50.837818
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:58:00.852494
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Validation
    """
    print('Testing to_lazy method of Validation')

    from pymonet.lazy import Lazy

    def assert_lazy(lazy_val_success, err_msg):
        """
        Asserts whether it is Lazy monad with value equal to val_success.

        :param lazy_val_success: expected value stored in Lazy monad
        :type lazy_val_success: Any
        :param err_msg: error message
        :type err_msg: str
        """
        assert isinstance(lazy_val_success, Lazy), '{} -> Lazy monad expected'.format(err_msg)
        assert lazy_val_success() == val_success, '{} -> {} expected'.format

# Generated at 2022-06-12 05:58:03.981131
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val1 = Validation.success(1)
    val2 = Validation.fail([])

    assert val1.to_lazy().get() == 1
    assert val2.to_lazy().get() is None

# Generated at 2022-06-12 05:58:10.369285
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.lazy import LazyMonad

    def f():
        return 1

    val1 = Validation.success(1)
    val2 = val1.to_lazy()

    assert isinstance(val2, LazyMonad)
    assert isinstance(val2, Lazy)
    assert val2 == Lazy(f)
