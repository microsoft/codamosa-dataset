

# Generated at 2022-06-12 05:48:40.127719
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy(lambda: 5)
    validation = Validation.success(None)
    assert validation.to_lazy() == Lazy(lambda: None)
    validation = Validation.fail(['error'])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:52.547949
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests to_lazy function of Validation class.
    """
    from pymonet.lazy import Lazy

    def test_Validation_to_lazy_success():
        """
        It tests to_lazy function of Validation class when Validation is successful.
        """
        def value():
            return "value"

        lazy = Validation.success(value()).to_lazy()

        assert isinstance(lazy, Lazy)
        assert lazy.value() == value()

    def test_Validation_to_lazy_fail():
        """
        It tests to_lazy function of Validation class when Validation is failed.
        """
        def value():
            return None

        lazy = Validation.fail(["no value"]).to_lazy()
        assert lazy.value() is value()

# Generated at 2022-06-12 05:48:55.948679
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success([1, 2, 5])
    lazy = validation.to_lazy()

    assert lazy.success() == validation.value

# Generated at 2022-06-12 05:49:02.590734
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    val_success = Validation(1, [])
    lazy_success = val_success.to_lazy()
    assert lazy_success.value() == (1)

    val_fail = Validation(None, ['error'])
    lazy_fail = val_success.to_lazy()
    assert lazy_fail.value() == (1)


# Generated at 2022-06-12 05:49:08.388474
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Success, Failure
    from pymonet.lazy import Lazy

    result = Lazy(lambda: Success(1)).to_validation().to_lazy()
    assert result == Lazy(lambda: Success(1))

    result = Lazy(lambda: Failure('Error')).to_validation().to_lazy()
    assert result == Lazy(lambda: Failure('Error'))


# Generated at 2022-06-12 05:49:17.743958
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def dummy_func(x):
        return x

    lazy = Validation(1, []).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1
    assert lazy.map(dummy_func).map(dummy_func).get() == 1

    errors = [ValueError('value was wrong'), TypeError('bad typos')]
    lazy = Validation(None, errors).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None
    assert lazy.map(dummy_func).map(dummy_func).get() is None



# Generated at 2022-06-12 05:49:22.184755
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
    assert Validation.fail(['error']).to_lazy() == Lazy(None)

# Generated at 2022-06-12 05:49:26.357777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    f = Lazy(lambda: 1)
    assert Validation.success(f).to_lazy() == f
    assert Maybe.just(f).to_lazy() == f



# Generated at 2022-06-12 05:49:28.852249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Validation.success(5).to_lazy()
    assert lazy == Lazy(lambda: 5)


# Generated at 2022-06-12 05:49:31.566963
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert_that(Validation(1, []).to_lazy().get(), equal_to(1))
    assert_that(Validation(1, ['error']).to_lazy().get(), equal_to(1))


# Generated at 2022-06-12 05:49:36.851209
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # given
    val = Validation.success(1)

    # when
    lazy = val.to_lazy()

    # then
    assert isinstance(lazy, Lazy)
    assert lazy.value == 1


# Generated at 2022-06-12 05:49:40.484441
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.success(None).to_lazy().get() is None
    assert Validation.fail().to_lazy().get() is None


# Generated at 2022-06-12 05:49:48.648788
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    def _to_lazy(success, value):
        if success:
            return Validation.success(value).to_lazy()
        return Validation.fail(value).to_lazy()

    assert _to_lazy(True, 1) == Lazy(lambda: 1)
    assert _to_lazy(True, None) == Lazy(lambda: None)
    assert _to_lazy(False, [1]) == Lazy(lambda: None)
    assert _to_lazy(False, []) == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:51.569469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()
    assert lazy == Lazy(lambda: Box(10))

# Generated at 2022-06-12 05:49:54.090644
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success(50)
    assert val.to_lazy() == Lazy(lambda: 50)


# Generated at 2022-06-12 05:50:06.029793
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    def mapper(value):
        return '{}_mapped'.format(value)

    def folder(_):
        return Validation('success')

    assert(Validation('success', []).to_lazy() == Lazy(lambda: 'success'))
    assert(Validation('success', []).to_lazy().map(mapper) == Lazy(lambda: 'success_mapped'))
    assert(Validation('success', []).to_lazy().bind(folder) == Lazy(lambda: Validation('success')))

# Generated at 2022-06-12 05:50:12.390923
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functools import curry
    from pymonet.functools import compose

    assert compose(lambda lazy: lazy.eval(), curry(Validation.success)(), Lazy)\
        (lambda: 'curry')\
        .to_lazy()\
        .eval() == 'curry'

# Generated at 2022-06-12 05:50:15.876003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Validation(10, []).to_lazy().evaluate() == 10
    assert Validation(None, ['Error']).to_lazy().evaluate() is None
    assert Validation(10, []).is_success() is True
    assert Validation(10, []).is_fail() is False
    assert Validation(None, ['Error']).is_success() is False
    assert Validation(None, ['Error']).is_fail() is True


# Generated at 2022-06-12 05:50:19.240215
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def ret_try():
        return Validation.fail(['a'])

    lazy = Validation.fail(['a']).to_lazy()

    assert lazy.eval() == ret_try()


# Generated at 2022-06-12 05:50:22.731794
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:50:28.090938
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test if lazy contains Validation value
    """
    from pymonet.lazy import Lazy

    value = 5
    assert Lazy(lambda: value).value == value


# Generated at 2022-06-12 05:50:38.730248
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 42) == Box(42).to_lazy()
    assert Lazy(lambda: 'some_value') == Validation.success('some_value').to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()
    assert Lazy(lambda: None) == Try(None).to_lazy()
    assert Lazy(lambda: 12 / 4) == Try(12 / 4).to_lazy()
    try:
        Lazy(lambda: 12 / 0) == Try(12 / 0).to_lazy()
    except Exception as e:
        assert str(e) == 'division by zero'

# Unit test

# Generated at 2022-06-12 05:50:48.075477
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    x = Validation.success(1)
    assert x.to_lazy() == Lazy(lambda: 1)

    y = Validation.success([1, 2, 3])
    assert y.to_lazy() == Lazy(lambda: [1, 2, 3])

    z = Validation.success(Maybe.just(1))
    assert z.to_lazy() == Lazy(lambda: Maybe.just(1))


# Generated at 2022-06-12 05:50:55.550134
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    val1 = Validation.success(42)
    lazy1 = val1.to_lazy()
    assert val1.value == lazy1.resolve()

    val2 = Validation.fail(['some error'])
    lazy2 = val2.to_lazy()
    assert val2.value == lazy2.resolve()

    assert isinstance(lazy1, Lazy)
    assert isinstance(lazy2, Lazy)


# Generated at 2022-06-12 05:51:02.277869
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2, 3, 4]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:07.028619
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test case for Validation method to_lazy.
    """
    from pymonet.lazy import Lazy
    def lazy_function():
        return "lazy"
    assert Validation.success(lazy_function()).to_lazy() == Lazy(lazy_function)
    assert Validation.fail(["lazy"]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:11.169649
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 100) == Validation.success(100).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1, 2, 3]).to_lazy()


# Generated at 2022-06-12 05:51:13.976106
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Map(lambda x: x + 2, Lazy(lambda: 5)).to_lazy().run_lazy() == 7

# Generated at 2022-06-12 05:51:17.752814
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def get_validation():  # pragma: no cover
        return Validation.success('Hello')

    assert Lazy(lambda: 'Hello') == get_validation().to_lazy()



# Generated at 2022-06-12 05:51:24.855161
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation.

    :returns: Nothing
    :rtype: Nothing
    """
    from pymonet.success import Success
    assert Validation.success().to_lazy() == Validation.success().value

    assert Validation.fail().to_lazy() == Validation.fail().value
    assert Validation.success(1).to_lazy() == Validation.success(1).value
    assert Validation.fail(1).to_lazy() == Validation.fail(1).value
    assert Validation.success('hello').to_lazy() == Validation.success('hello').value
    assert Validation.fail('hello').to_lazy() == Validation.fail('hello').value
    assert Validation.success([1, 2, 3]).to_lazy() == Val

# Generated at 2022-06-12 05:51:32.410960
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy
    assert Validation.success('hello').to_lazy() == Lazy(lambda: 'hello')
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1,2,3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:37.171236
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    result = Validation.success("test").to_lazy()
    assert isinstance(result, Try)

    result = Validation.success("test").to_lazy()
    assert result.get() == "test"


# Generated at 2022-06-12 05:51:42.533499
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    Validation.success(1).to_lazy() == Lazy(lambda: 1)

    Validation.success(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    Validation.success(Try(1, is_success=True)).to_lazy() == Lazy(lambda: Try(1, is_success=True))



# Generated at 2022-06-12 05:51:52.875065
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of module Validation.
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    tests = [
        {
            'input': Validation.success(1),
            'expected': Lazy(lambda: 1),
        },
        {
            'input': Validation.fail(1),
            'expected': Lazy(lambda: None),
        },
    ]

    for i, test in enumerate(tests):
        print('Test {}:'.format(i))
        print('Input: {}'.format(test['input']))
        print('Expected: {}'.format(test['expected']))
        actual = test['input'].to_lazy()
        print('Actual: {}'.format(actual))

# Generated at 2022-06-12 05:51:57.624429
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:02.255399
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success(1)
    result = success.to_lazy()

    assert isinstance(result, Lazy)
    assert result._value is None
    assert result.value() == 1


# Generated at 2022-06-12 05:52:04.194525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(3).to_lazy()
    assert success.get() is 3

    fail = Validation.fail().to_lazy()
    assert fail.get() is None

# Generated at 2022-06-12 05:52:06.799332
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return '42'

    lazy = Validation.success(42).to_lazy()
    assert lazy == Lazy(f)



# Generated at 2022-06-12 05:52:17.005458
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    assert Validation.success(1).map(lambda x: x + 1).to_lazy() == \
           Validation.success(2).map(Lazy)
    assert Validation.fail(['err1', 'err2']).to_lazy() == \
           Validation.fail().map(Lazy)
    assert Validation.success().map(lambda x: Failure('2', '3')).to_lazy() == \
           Validation.fail(['2', '3']).map(Lazy)


# Generated at 2022-06-12 05:52:19.558104
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:52:28.484963
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_either import Left, right
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(Validation.success(1).value)
    assert Validation.fail(['error']).to_lazy() == Lazy(Validation.fail(['error']).value)


# Generated at 2022-06-12 05:52:33.451989
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try

    def func():
        return "test"
    val = Validation.success(Maybe.just(Try(func)))
    assert val.to_lazy().value().to_maybe().value.to_try().is_success()

# Generated at 2022-06-12 05:52:36.732339
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 123) == Validation.success(123).to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()


# Generated at 2022-06-12 05:52:41.086047
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: None) == Validation.success().to_lazy()
    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()
    assert Lazy(lambda: 1) == Validation.fail([1]).to_lazy()


# Generated at 2022-06-12 05:52:45.718024
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validation = Validation(4, [])
    lazy_validation = validation.to_lazy()
    assert lazy_validation == Lazy(lambda: 4)
    assert lazy_validation.get() == 4


# Generated at 2022-06-12 05:52:48.527846
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()



# Generated at 2022-06-12 05:52:50.455107
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def function():
        return 42
    validation = Validation.success(function())
    assert validation.to_lazy() == Lazy(function)


# Generated at 2022-06-12 05:52:57.007331
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert_equal(Validation.success(1).to_lazy(), Lazy(lambda: 1))
    assert_equal(Validation.success(1).to_lazy().run(), 1)
    assert_equal(Validation.success(1).to_lazy().run().to_try(), Try.success(1))


# Generated at 2022-06-12 05:53:05.894556
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation_failure import ValidationFailure
    from pymonet.lazy import Lazy


    validation = Validation.fail([ValidationFailure('fail', 'fail message')])
    lazy = validation.to_lazy()
    assert(isinstance(lazy, Lazy))
    assert(lazy == Lazy(lambda: None))
    validation = Validation.success('success')
    lazy = validation.to_lazy()
    assert(isinstance(lazy, Lazy))
    assert(lazy == Lazy(lambda: 'success'))


# Generated at 2022-06-12 05:53:09.434800
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()

# Generated at 2022-06-12 05:53:15.813303
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')


# Generated at 2022-06-12 05:53:24.681088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    val = Validation.success('foo')
    assert val.to_lazy().run() == 'foo'

    val = Validation.fail(['ping'])
    assert val.to_lazy().run() is None

    assert val.to_maybe() == Maybe.nothing()

    assert val.to_try() == Try.failure(['ping'])

    assert val.to_box() == 'ping'



# Generated at 2022-06-12 05:53:30.016395
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    validation = Validation(Try(5), [])
    assert validation.to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:53:40.479160
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Validation.success(1).to_lazy()
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Validation.fail([]).to_lazy()
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['error 1']).to_lazy() == Validation.fail(['error 1']).to_lazy()
    assert Validation.fail(['error 1']).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy().value() == None
    assert Validation.success(1).to_lazy().value() == 1

# Generated at 2022-06-12 05:53:50.507409
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that method to_lazy of class Validation returns Lazy monad with Validation value
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    v = Validation.success(1)
    l = v.to_lazy()
    assert l == Lazy(lambda: 1)
    assert l.get() == 1
    assert l.get() == 1
    assert l.get() == 1
    v = Validation.fail()
    l = v.to_lazy()
    assert l == Lazy(lambda: None)
    assert l.get() == None
    assert l.get() == None
    assert l.get() == None


# Generated at 2022-06-12 05:53:55.144151
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation.success(Box(5)).to_lazy() == Lazy(lambda: Box(5))
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:59.021133
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')
    assert Validation.fail(['errors']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:01.279138
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert(Validation.success(1).to_lazy() == Lazy(lambda: 1))



# Generated at 2022-06-12 05:54:03.910711
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1


# Generated at 2022-06-12 05:54:07.364528
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    assert isinstance(Validation.success(2).to_lazy(), Lazy)
    assert Monad.unit(Lazy, Validation.success(2)).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:54:18.827609
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = {'a': 1}
    validation = Validation.success(value)
    lazy = validation.to_lazy()
    assert lazy.value() == value

# Generated at 2022-06-12 05:54:24.292057
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    test_cases = [
        (Validation.success(1), Lazy(lambda: 1)),
        (Validation.fail([]), Lazy(lambda: None))
    ]

    for test_case, expected in test_cases:
        assert test_case.to_lazy() == expected


# Generated at 2022-06-12 05:54:33.584283
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy

    v = Validation.fail().to_lazy()
    assert isinstance(v, Lazy)
    assert v() is None
    v = Validation.fail([1, 2, 3]).to_lazy()
    assert v() is None
    v = Validation.success(1).to_lazy()
    assert v() == 1
    v = Validation.success(None).to_lazy()
    assert v() is None
    v = Validation.success(False).to_lazy()
    assert v() is False
    assert v() is v().value
    v = Validation.fail([1, 2, 3, 5]).to_lazy()
    assert v() is None


# Generated at 2022-06-12 05:54:35.771994
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.fail().to_lazy()
    assert isinstance(result, Lazy)
    assert result() is None


# Generated at 2022-06-12 05:54:42.160796
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail(3).to_lazy() == Lazy(lambda: None)

    assert Validation.success(Try.success(3)).to_lazy() == Lazy(lambda: Try.success(3))

# Generated at 2022-06-12 05:54:53.872528
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Right

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().flat_map(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda: 2)
    Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)
    Validation.fail(['Error']).to_lazy().flat_map(lambda x: Lazy(lambda: x + 1)) == Lazy(lambda: None)

    # Converting Validation to Lazy and then to Maybe, Try and Either
    assert Validation

# Generated at 2022-06-12 05:55:00.122094
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Lazy(lambda: Try(1, is_success=False)) == Validation.fail([1]).to_lazy()
    assert Lazy(lambda: Try('test')) == Validation.success('test').to_lazy()


# Generated at 2022-06-12 05:55:03.385651
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy(5)


# Generated at 2022-06-12 05:55:11.945770
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It is unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    unit = 'foo'
    try_unit = Try(unit)

    validation = Validation.success(unit).to_lazy()
    assert validation.value() == unit
    assert validation.value() == 'foo'
    assert validation == Lazy(lambda: unit)

    validation = Validation.fail([]).to_lazy()
    assert validation.value() is None
    assert validation.value() is None
    assert validation == Lazy(lambda: None)

    validation = Validation.success(unit).to_lazy().map(lambda x: Try(x)).bind(lambda y: y)
    assert validation == try_unit


# Generated at 2022-06-12 05:55:15.456845
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: "a") == Validation.fail(["error"]).to_lazy()


# Generated at 2022-06-12 05:55:32.758792
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(42).to_lazy()

    assert lazy.value() == 42



# Generated at 2022-06-12 05:55:35.289343
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_test():
        return Validation.success(1)

    assert Validation.success(1).to_lazy() == Lazy(lazy_test)


# Generated at 2022-06-12 05:55:38.017910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    assert Validation.success(1).to_lazy()


# Generated at 2022-06-12 05:55:43.109635
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    try:
        raise ValueError
    except ValueError:
        error = sys.exc_info()[1]

        assert Lazy(lambda: Validation.success(1).value) == Validation.success(1).to_lazy()
        assert Lazy(lambda: Validation.fail([error]).value) == Validation.fail([error]).to_lazy()



# Generated at 2022-06-12 05:55:52.113733
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    assert Validation.success(11).to_lazy() == Lazy(11)
    assert Validation.success(11).to_lazy() != Lazy(lambda: 11)
    assert Validation.success(None).to_lazy() == Lazy(None)

    def unit_test_every_method():
        # Unit test for Lazy map method
        assert Functor.map(lambda x: x + 1, Validation.success(11).to_lazy()) == Validation.success(12).to_lazy()
        assert Functor.map(lambda x: x + 1, Validation.success(None).to_lazy()) == Validation.success(None).to_lazy()

# Generated at 2022-06-12 05:55:54.828983
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.evaluate() == 42


# Generated at 2022-06-12 05:56:05.329887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation.

    :returns: True
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy

    success = Validation.success(1)
    result = success.to_lazy()
    assert(isinstance(result, Lazy))
    assert(result.value() == 1)
    assert(result.is_success())

    fail = Validation.fail([1, 2])
    result = fail.to_lazy()
    assert(isinstance(result, Lazy))
    assert(result.value() == None)
    assert(result.is_fail())

    return True


# Generated at 2022-06-12 05:56:07.542584
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    test_val = Validation.success(2)

    assert test_val.to_lazy() == Lazy(lambda: test_val.value)


# Generated at 2022-06-12 05:56:14.560131
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test class Validation method to_lazy.
    """

    # Test case when success Validation is transforming to Lazy monad
    value = 10
    validation = Validation.success(value)
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value() == value

    # Test case when failed Validation is transforming to Lazy monad
    validation = Validation.fail()
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value() is None


# Generated at 2022-06-12 05:56:19.255793
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    testing_value = 'value'

    def test_function():
        return testing_value

    assert Validation.success(testing_value).to_lazy() == \
           Lazy(test_function)


# Generated at 2022-06-12 05:56:39.841255
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy


# Generated at 2022-06-12 05:56:46.595261
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation class method to_lazy.
    """
    from pymonet.lazy import Lazy

    some_lazy = Validation.success(5).to_lazy()
    assert some_lazy == Lazy(lambda: 5)

    none_lazy = Validation.fail().to_lazy()
    assert none_lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:56.033605
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_validation import Validation

    assert Lazy(lambda: 123) == Validation.success(123).to_lazy()
    assert Lazy(lambda: 'abc') == Validation.success('abc').to_lazy()
    assert Lazy(lambda: None) == Validation.success(None).to_lazy()
    assert Lazy(lambda: [1, 2, 3]) == Validation.success([1, 2, 3]).to_lazy()
    assert Lazy(lambda: {'key': 1}) == Validation.success({'key': 1}).to_lazy()


# Generated at 2022-06-12 05:56:59.128663
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    v = Validation.success(2)
    assert v.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-12 05:57:06.289280
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def test(x):
        return x >= 2

    def test2(x):
        return x

    result = Validation.success(2)
    assert result.to_lazy() == Lazy(lambda: 2)

    result = Validation.fail([1, 2, 3]).bind(lambda x: Validation.success(x == 2))
    assert result.to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-12 05:57:11.165604
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def assert_result(result):
        if result.is_success():
            assert result.value == 'success'
        else:
            assert result.value.message == 'invalid error'

    assert_result(Validation('success', []).to_lazy().force())
    assert_result(Validation(Exception('invalid error'), []).to_lazy().force())


# Generated at 2022-06-12 05:57:18.754598
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Validation(123, []).to_lazy() == Lazy(lambda: 123)
    assert Validation(Try(123), []).to_lazy() == Lazy(lambda: Try(123))
    assert Validation(Right(321), []).to_lazy() == Lazy(lambda: Right(321))
    assert Validation(Maybe.just(123), []).to_lazy() == Lazy(lambda: Maybe.just(123))


# Generated at 2022-06-12 05:57:23.001554
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test mapping Validation to Lazy monad."""
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    value = 1
    result = Validation.success(value).to_lazy()

    assert isinstance(result, Lazy)
    assert result.value() == value


# Generated at 2022-06-12 05:57:25.221666
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()


# Generated at 2022-06-12 05:57:28.468051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-12 05:58:06.907014
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # GIVEN
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # WHEN
    validation = Validation.fail(errors=['A'])
    lazy = validation.to_lazy()

    # THEN
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None

# Generated at 2022-06-12 05:58:09.708276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy().value() == 10
    assert Validation.fail().to_lazy().value() == None


# Generated at 2022-06-12 05:58:14.274080
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f(x):
        if x > 5:
            return Validation.success(x)
        return Validation.fail(x)

    v = f(7)
    assert f(7) == v
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 7) == v.to_lazy()


# Generated at 2022-06-12 05:58:16.189338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy().force() == 5


# Generated at 2022-06-12 05:58:18.844866
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(123).to_lazy().get_or(None)

    assert result == 123


# Generated at 2022-06-12 05:58:24.104440
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1
    assert lazy.get() == 1

    lazy = Validation.fail(['error']).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None
    assert lazy.get() is None


# Generated at 2022-06-12 05:58:34.831020
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation.to_lazy method.
    """
    from pymonet.lazy import Lazy

    def insert_into_db(user):
        return user

    def user_validation(user):
        if user.name is None:
            raise ValueError('User name is missing')
        return Validation.success(user)

    def create_user(name):
        return insert_into_db(name)

    data = create_user('John')
    validation = user_validation(data)
    assert validation == Validation(data, [])
    lazy = validation.to_lazy()
    assert lazy.value() == Lazy(lambda: data).value()
