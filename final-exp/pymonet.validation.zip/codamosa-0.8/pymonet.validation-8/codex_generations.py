

# Generated at 2022-06-12 05:48:39.059783
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # GIVEN
    from pymonet.lazy import Lazy

    validation = Validation(10, [])

    # WHEN
    lazy = validation.to_lazy()

    # THEN
    assert lazy == Lazy(10)

# Generated at 2022-06-12 05:48:43.608033
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # given
    validation = Validation.success('hello')

    # when
    lazy = validation.to_lazy()
    result = lazy.value()

    # then
    assert result == 'hello'
    assert lazy == Lazy(lambda: 'hello')


# Generated at 2022-06-12 05:48:54.221081
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """ Testing function to_lazy """

    from pymonet.monad import do_monad
    from pymonet.lazy import Lazy

    def validate(x):
        if x is None:
            return Validation.fail(["Field is None"])
        elif x == "":
            return Validation.fail(["Field is empty"])
        else:
            return Validation.success(x)

    validation = do_monad(Validation)(
        validate("test")
    )

    assert validation.value == "test"
    assert len(validation.errors) == 0

    lazy_value = validation.to_lazy()
    assert isinstance(lazy_value, Lazy)
    assert lazy_value.get() == "test"


# Generated at 2022-06-12 05:48:59.312668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [2]).to_lazy() == Lazy(lambda: None)
    assert Validation(3, [4]).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:49:04.800058
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_func():
        return "Lazy Func"

    assert Validation.success(lazy_func()) == Validation.success(lazy_func()).to_lazy()
    assert Validation.fail("Error") != Validation.fail("Error").to_lazy()


# Generated at 2022-06-12 05:49:08.867979
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    val = Validation.success('success')
    lzy = val.to_lazy()

    assert isinstance(lzy, Lazy)
    assert lzy() == val.value


# Generated at 2022-06-12 05:49:18.402630
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import is_lazy, is_monet_func
    from pymonet.functor import is_functor
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    val = Validation.success(Lazy(lambda: Box(2)))
    assert is_lazy(val.value)
    assert is_monet_func(val.value.value)

    val = Validation.fail([1, 2, 3])
    assert is_lazy(val.value)
    assert is_monet_func(val.value.value)
    assert val.value.value() == None

# Generated at 2022-06-12 05:49:23.252253
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    f = lambda: 2
    lazy_f = Validation.success(f).to_lazy()
    assert isinstance(lazy_f, Lazy)
    assert lazy_f.value()() == 2


# Generated at 2022-06-12 05:49:26.648319
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('some').to_lazy() == Lazy(lambda: 'some')
    assert Validation.fail('some').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:30.398647
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    val = Validation.success(1)
    lazy = val.to_lazy()

    assert isinstance(lazy, Lazy) and lazy.value() == val.value


# Generated at 2022-06-12 05:49:41.351928
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def mock_function_with_parameter(param):
        return param + 1

    # Mock function
    validated_val = Validation(42, [])

    lazy = Validation.success(42).to_lazy()
    assert Lazy(lambda: 42) == lazy

    # Test map method
    lazy = lazy.map(mock_function_with_parameter)
    # We need to evaluate lazy monad with method evaluate
    assert 43 == lazy.evaluate()

    # Test bind method
    lazy = lazy.bind(lambda val: Lazy(lambda: val * 2))
    assert 86 == lazy.evaluate()

    # Test ap method
    lazy = lazy.ap(Validation.success(mock_function_with_parameter))
    assert 87 == lazy.evaluate()

#

# Generated at 2022-06-12 05:49:43.785505
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def get_validation() -> Validation[int, str]:
        return Validation.success(12)

    assert Lazy(get_validation).get() == 12


# Generated at 2022-06-12 05:49:48.647410
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: 5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:49:56.557356
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def evaluate(val):
        return val

    # given
    v1 = Validation.success(1)
    v2 = Validation.fail([1, 'error'])

    # when
    lv1 = v1.to_lazy()
    lv2 = v2.to_lazy()

    # then
    assert evaluate(lv1) == v1.value
    assert lv1 == Lazy(lambda: v1.value)
    assert lv2 == Lazy(lambda: v2.value)



# Generated at 2022-06-12 05:50:01.190833
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_function():
        return 100

    val = Validation.success(test_function())

    lazy = val.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 100


# Generated at 2022-06-12 05:50:04.892325
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:10.399751
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tests to_lazy method of class Validation.
    """
    from pymonet.lazy import Lazy

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:50:15.750124
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def dummy_func():
        return Validation.success(10)

    lazy = Validation.success(10).to_lazy()

    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.eval(), Validation)
    assert lazy.eval() == Validation.success(10)


# Generated at 2022-06-12 05:50:24.029620
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def func():
        return 'test'

    validation = Validation.success(func)
    lazy = Lazy(lambda: func)
    assert validation.to_lazy() == lazy

    validation = Validation.success([1, 2, 3])
    lazy = Lazy(lambda: [1, 2, 3])
    assert validation.to_lazy() == lazy

    validation = Validation.success(None)
    lazy = Lazy(lambda: None)
    assert validation.to_lazy() == lazy

    validation = Validation.success(123)
    lazy = Lazy(lambda: 123)
    assert validation.to_lazy() == lazy

    validation = Validation.fail(['error'])
    lazy = Lazy

# Generated at 2022-06-12 05:50:31.532064
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Failure

    v1 = Validation.fail([1, 2])
    v2 = Validation.success(3)

    assert v1.to_lazy() == Lazy(lambda: None)
    assert v1.to_lazy().eval() == None

    assert v2.to_lazy() == Lazy(lambda: 3)
    assert v2.to_lazy().eval() == 3



# Generated at 2022-06-12 05:50:39.188892
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    try:
        Lazy(1 / 0)
    except ZeroDivisionError:
        assert Validation.success(1 / 0).to_lazy() == Lazy(lambda: 1 / 0)



# Generated at 2022-06-12 05:50:43.461778
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_value():
        return 'to_lazy'

    assert Validation.success('to_lazy').to_lazy() == Lazy(lazy_value)


# Generated at 2022-06-12 05:50:49.354078
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    v = Validation.fail(['a', 'b'])
    lazy = v.to_lazy()
    assert lazy.value() is None
    assert lazy.is_success() is False

    v = Validation.success(['a', 'b'])
    lazy = v.to_lazy()
    assert lazy.value() == ['a', 'b']
    assert lazy.is_success() is True



# Generated at 2022-06-12 05:50:54.159330
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    v = Validation.success(1)
    f = v.to_lazy()
    assert v is not f
    assert isinstance(f, Lazy)
    assert v == f.run()



# Generated at 2022-06-12 05:51:03.061530
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # Given
    v1 = Validation.success(1)
    v2 = Validation.fail(['error'])

    # When
    lazy1 = v1.to_lazy()
    lazy2 = v2.to_lazy()

    # Then
    assert lazy1.get() == 1
    assert lazy2.get() is None


# Generated at 2022-06-12 05:51:05.381938
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(100).to_lazy()
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:51:09.199956
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_lazy = Validation.fail([]).to_lazy()
    assert validation_lazy.get() == None
    validation_lazy = Validation.success(2).to_lazy()
    assert validation_lazy.get() == 2

# Generated at 2022-06-12 05:51:14.156947
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validate = Validation.fail()
    assert validate.to_lazy() == Lazy(lambda: None)

    validate = Validation(10, [])
    assert validate.to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-12 05:51:21.063891
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    GIVEN
    Validation success value

    WHEN
    `to_lazy` method is called on this Validation

    THEN
    Lazy monad is returned with lambda expression returning Validation value
    """
    from pymonet.lazy import Lazy

    value = 'ok'
    validation = Validation.success(value)
    assert validation.to_lazy() == Lazy(lambda: value)

    value = 'fail'
    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:51:25.214076
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('some value').to_lazy() == Lazy(lambda: 'some value')

    assert Validation.fail(['some error']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:51:30.150669
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return 2

    validation = Validation.success(2)
    actual = validation.to_lazy()
    expected = Lazy(f)
    assert actual == expected

# Generated at 2022-06-12 05:51:33.155727
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_value = Lazy(lambda: 2)
    validation = Validation(lazy_value, [])
    assert(validation.to_lazy() == lazy_value)
    assert(validation == Validation(lazy_value, []))


# Generated at 2022-06-12 05:51:39.006205
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Successful Validation
    validation = Validation.success('test')
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 'test')

    # Failed Validation
    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:41.610007
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:47.738646
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try, Failure
    from pymonet.lazy import Lazy

    lazy_validation = Lazy(lambda: Validation.success(5))

    assert lazy_validation.to_lazy() == Lazy(lambda: Try(5)), 'Validation was not transformed to Lazy'


# Generated at 2022-06-12 05:51:50.832733
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)
    assert Validation(None, ['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:56.387833
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy(lambda: 'Test') == Validation.success('Test').to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['Error 1']).to_lazy()


# Generated at 2022-06-12 05:52:00.643743
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:03.308613
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_validation import Validation

    validation = Validation.success(1)
    lazy_obj = validation.to_lazy()
    assert isinstance(lazy_obj, Lazy)
    assert lazy_obj.value() == 1

# Generated at 2022-06-12 05:52:10.733681
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def mapper(value):
        return value * 2

    def folder(value):
        return Validation.success(value * 2)

    assert Validation.success(5).map(mapper).value == 10
    assert Validation.success(5).bind(folder).value == 10
    assert Validation.success(5).to_maybe().get_or_else(None) == 5
    assert Validation.success(5).to_try().is_success()
    assert Validation.success(lambda: 5).to_lazy().value()() == 5
    assert Validation.success(5).ap(lambda x: Validation.success(x * 2)).value == 10
    assert Validation.fail([]).ap(lambda x: Validation.success(x * 2)).value is None

# Generated at 2022-06-12 05:52:18.014426
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert isinstance(Validation.success().to_lazy(), Lazy)
    assert isinstance(Validation.success(100).to_lazy(), Lazy)
    assert Validation.success().to_lazy().force() is None
    assert Validation.success(100).to_lazy().force() == 100


# Generated at 2022-06-12 05:52:23.597348
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    v = Validation.success(5)
    assert v.to_lazy() == Lazy(lambda: 5)

    v = Validation.fail([])
    assert v.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:52:28.171637
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success([1, 2, 3])
    assert validation.to_lazy() is Lazy(lambda: validation.value)
    assert validation.to_lazy().get() == validation.value


# Generated at 2022-06-12 05:52:37.641607
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    # Test successfully validation
    def test_success():
        """
        Unit test for successfully Validation.
        """
        from pymonet.lazy import Lazy
        from pymonet.monad_try import Try

        value = 'value'
        assert Lazy(lambda: value) == Validation.success(value).to_lazy()

    # Test failed validation
    def test_fail():
        """
        Unit test for failed Validation.
        """
        from pymonet.lazy import Lazy

        value = None
        assert Lazy(lambda: value) == Validation.fail().to_lazy()

    test_success()
    test_fail()

# Generated at 2022-06-12 05:52:41.669600
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:52:46.905046
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['']).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:52:51.972406
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test if to_lazy method convert Validation to Lazy monad.
    """
    from pymonet.lazy import Lazy

    input_value = '123'
    actual = Validation.success(input_value).to_lazy()
    expected = Lazy(lambda: input_value)
    assert(actual == expected)



# Generated at 2022-06-12 05:52:57.231580
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:53:02.545457
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def square(x): return x ** 2

    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    assert Validation(square, []).to_lazy() == Lazy(square)
    assert Validation(3, []).to_lazy() == Lazy(lambda: 3)



# Generated at 2022-06-12 05:53:10.214407
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 3

    assert Validation.success(3).to_lazy() == Lazy(f)
    assert Validation.success(3).to_lazy().value() == 3
    assert not Validation.fail([]).to_lazy().is_success()
    assert not Validation.fail([1, 2]).to_lazy().is_success()


# Generated at 2022-06-12 05:53:19.778393
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.fail(['a']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:25.078140
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation(56, []).to_lazy() == Lazy(lambda: 56)
    assert Validation(None, [1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:30.321623
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([ValueError('error')]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:34.674766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    validation = Validation.success()
    lazy_val = validation.to_lazy()

    assert lazy_val == Lazy(lambda: None)
    assert lazy_val.get() == None


# Generated at 2022-06-12 05:53:37.580415
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['aaa']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:39.295003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-12 05:53:44.156834
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # create Validation object with value 'Hello' and no errors
    validation = Validation('Hello', [])

    # convert Validation to Lazy
    lazy = validation.to_lazy()

    # try to call function that return value stored in Lazy when Lazy is successful
    result = lazy.get()

    # check that result is equal 'Hello'
    assert result == 'Hello'


# Generated at 2022-06-12 05:53:47.045934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:52.301371
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('value')
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == 'value'


# Generated at 2022-06-12 05:53:56.530752
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def fn():
        return 5

    validation = Validation.success(fn)
    assert validation.to_lazy().value()() == 5

    validation = Validation.fail()
    assert validation.to_lazy().value()() is None


# Generated at 2022-06-12 05:54:06.596502
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def return_one():
        return 1

    assert Validation.success(1).to_lazy() == Lazy(return_one)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-12 05:54:10.957289
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation(5, []).to_lazy() == Lazy(lambda: 5)
    assert Validation(None, [1, 2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:54:16.346972
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    validation = Validation.fail(['error'])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)

    lazy_value = lazy.value

    assert lazy_value == Try.fail('error')

# Generated at 2022-06-12 05:54:19.967532
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:54:25.112547
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    val = Validation.success('123')
    lazy_val = val.to_lazy()

    assert lazy_val.get() == '123'

    val = Validation.fail(['error1', 'error2'])
    lazy_val = val.to_lazy()

    assert lazy_val.get() is None

# Generated at 2022-06-12 05:54:29.029801
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(4).to_lazy() == Lazy(lambda: 4)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:32.343246
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Lazy(lambda: 'a').map(lambda value: Validation.success(value)).to_lazy()
    assert result.get() == 'a'



# Generated at 2022-06-12 05:54:36.767379
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Lazy.success(10) == Validation.success(10).to_lazy()
    assert Lazy.fail() == Validation.fail().to_lazy()
    assert Validation.fail().to_lazy() == Lazy.fail()


# Generated at 2022-06-12 05:54:45.766528
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    value = Try(1, is_success=True)
    lazy = Lazy(lambda: Box(1))
    assert Validation.success(value).to_lazy() == lazy

    value = Try(1, is_success=False)
    lazy = Lazy(lambda: None)
    assert Validation.success(value).to_lazy() == lazy

    value = Try(1, is_success=True)
    lazy = Lazy(lambda: None)
    assert Validation.fail([value]).to_lazy() == lazy

# Generated at 2022-06-12 05:54:54.090776
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test method to_lazy of class Validation.
    """
    validation = Validation.success(1)
    assert (validation.to_lazy().value() == 1)
    assert (validation.to_lazy().is_success() == True)

    validation = Validation.fail(['Error'])
    assert (validation.to_lazy().value() == None)
    assert (validation.to_lazy().is_success() == False)


# Generated at 2022-06-12 05:55:01.129934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def success_factory(value):
        return Validation.success(value)

    def fail_factory(value):
        return Validation.fail([value])

    def get_value():
        return 'value'

    def get_error():
        return 'error'

    # Validation.success
    assert success_factory(get_value()).to_lazy() == Lazy(get_value)

    # Validation.fail
    assert fail_factory(get_error()).to_lazy() == Lazy(get_error)


# Generated at 2022-06-12 05:55:08.405668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    lazy = Validation.success('text').to_lazy()
    assert lazy == Lazy(lambda: 'text')

    lazy = Validation.success(None).to_lazy()
    assert lazy == Lazy(lambda: None)

    lazy = Validation.success(10).to_lazy()
    assert lazy == Lazy(lambda: 10)

    lazy = Validation.fail(['error']).to_lazy()
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:11.668770
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(123)

    assert validation.to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:55:17.321650
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation = Validation.success('value')
    lazy = validation.to_lazy()
    assert lazy.value() == 'value'

    validation = Validation.fail(['error1', 'error2'])
    lazy = validation.to_lazy()
    assert lazy.value() == None



# Generated at 2022-06-12 05:55:21.477381
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Validation.success({ "field": "value" }).to_lazy().get() == {"field": "value"}
    assert Validation.fail(['error']).to_lazy().get() is None


# Generated at 2022-06-12 05:55:27.400235
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.functor import Functor

    # when
    result = Validation.success('test').to_lazy()

    # then
    assert isinstance(result, Lazy)
    assert result.value() == 'test'
    assert result.evaluate() is None
    assert result.is_evaluated() is False


# Generated at 2022-06-12 05:55:32.280687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests if Validation is successfully transformed to Lazy monad.
    """
    from pymonet.lazy import Lazy

    def test_function(value):
        return value * 2

    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')

# Generated at 2022-06-12 05:55:36.264082
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    monad = Validation.success('value')
    assert monad.to_lazy().eval() == 'value'


# Generated at 2022-06-12 05:55:40.532190
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Should transform Validation to Lazy.
    """
    from pymonet.lazy import Lazy

    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:55:50.102160
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    # Test with Just
    test_value = 5
    validation = Validation(test_value, [])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy() == test_value
    assert validation == lazy.to_validation()

    # Test with Nothing
    lazy = Validation.fail().to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy() is None
    assert lazy.to_validation().is_fail()



# Generated at 2022-06-12 05:56:06.498791
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def attempt(x):
        return x * 2

    value = Validation.success(10)

    try:
        assert value.to_lazy().map(attempt) == Lazy(lambda: 20)
    except AssertionError:
        print('Test 1. Failed.\nExpected: Lazy(lambda: 20)\nActual: {}'.format(value.to_lazy().map(attempt)))

    value = Validation.fail()

    try:
        assert value.to_lazy().map(attempt) == Lazy(lambda: None)
    except AssertionError:
        print('Test 2. Failed.\nExpected: Lazy(lambda: None)\nActual: {}'.format(value.to_lazy().map(attempt)))

#

# Generated at 2022-06-12 05:56:12.478588
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # When: create Lazy instance from successful Validation
    lazy = Validation.success(10).to_lazy()
    # Then: lazy contains success lazy value
    assert lazy.value() == 10
    # When: create Lazy instance from failed Validation
    lazy = Validation.fail(['err']).to_lazy()
    # Then: lazy contains failed lazy value
    assert lazy.value() is None


# Generated at 2022-06-12 05:56:17.867869
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)
    validation = Validation.fail([1])
    assert validation.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:56:21.125482
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    v = Validation.success('abc')
    assert isinstance(v.to_lazy(), Lazy)

# Generated at 2022-06-12 05:56:26.098658
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy_value = Validation.success(12).to_lazy()
    assert isinstance(lazy_value, Lazy)
    assert lazy_value.value() == 12


# Generated at 2022-06-12 05:56:27.858100
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy().value() == 2


# Generated at 2022-06-12 05:56:31.546907
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It is test for method to_lazy of class Validation
    """
    value = 'value'
    validation = Validation.success(value)
    assert Lazy(lambda: value) == validation.to_lazy()



# Generated at 2022-06-12 05:56:41.874183
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_functor import test_functor_identity
    from pymonet.monad_functor import test_functor_composition
    from pymonet.monad_applicative import test_applicative_identity
    from pymonet.monad_applicative import test_applicative_homomorphism
    from pymonet.monad_applicative import test_applicative_interchange
    from pymonet.monad_applicative import test_applicative_composition
    from pymonet.monad_monad import test_monad_left_identity
    from pymonet.monad_monad import test_monad_right_identity


# Generated at 2022-06-12 05:56:47.378287
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:49.776800
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy_validation = Validation.success(1).to_lazy()

# Generated at 2022-06-12 05:56:58.567419
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation

    """
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    validation = Validation(Box(4), [])
    assert validation.to_lazy() == Lazy(validation.value)


# Generated at 2022-06-12 05:57:04.383528
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Test to_lazy method of class Validation.
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:06.852422
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return "foo"

    validation = Validation.success(f)
    lazy = validation.to_lazy()

    assert lazy.value == f
    assert lazy.get() == "foo"


# Generated at 2022-06-12 05:57:13.949795
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    validation_success = Validation.success(3)
    validation_fail = Validation.fail([1, 2, 3])

    lazy_success = validation_success.to_lazy()
    lazy_fail = validation_fail.to_lazy()

    try:
        lazy_fail()
        assert False
    except Exception as _:
        assert True

    assert lazy_success() == 3
    assert isinstance(lazy_success, Lazy)


# Generated at 2022-06-12 05:57:19.311596
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.fail()
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.eval() is None

    validation = Validation(2)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.eval() == 2

# Generated at 2022-06-12 05:57:22.200044
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def prepare():
        return Validation.success(10)

    def check(monad):
        assert monad.to_lazy().value() == 10

    prepare() | check


# Generated at 2022-06-12 05:57:27.334404
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    success_lazy = Validation.success('foo').to_lazy()
    fail_lazy = Validation.fail(['error']).to_lazy()

    assert success_lazy == Lazy(lambda: 'foo')
    assert fail_lazy == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:32.444744
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation class.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:38.752518
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Exception

    # Validation with value
    v = Validation.success(lambda: 1)

    # Validation with None as value
    v2 = Validation.fail()

    assert v.to_lazy() == Lazy(lambda: 1)
    assert v2.to_lazy() == Lazy(None)


# Generated at 2022-06-12 05:57:42.976893
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 2
    lazy = Validation.success(value).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.eval() == value
    assert lazy.eval() == value



# Generated at 2022-06-12 05:57:57.290305
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    v_success = Validation.success([0, 1, 2])
    v_fail = Validation.fail(['error'])

    assert v_success.to_lazy() == Lazy(lambda: [0, 1, 2])
    assert v_fail.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:57:59.126829
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def function():
        return 1

    result = Validation.success(function).to_lazy().call()
    assert result == 1


# Generated at 2022-06-12 05:58:04.321687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method to_lazy of class Validation.
    """
    assert (Validation.success(3).to_lazy() == Lazy(lambda: 3))
    assert (Validation.fail().to_lazy() == Lazy(lambda: None))
    assert (Validation.fail(['lala']).to_lazy() == Lazy(lambda: None))



# Generated at 2022-06-12 05:58:11.225416
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def f(value):
        return Lazy(lambda: value)

    result = Validation.success(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() == 1

    result = Validation.fail([1]).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value() is None


# Generated at 2022-06-12 05:58:14.557706
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation(3, [])

    assert Lazy(lambda: 3) == validation.to_lazy()


# Generated at 2022-06-12 05:58:17.916894
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:58:20.860358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(1).to_lazy()
    assert result.run() == 1

    result = Validation.fail([1, 2, 3]).to_lazy()
    assert result.run() is None


# Generated at 2022-06-12 05:58:23.590283
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    v = Validation.success(1)

    assert v.to_lazy() == Lazy(v.value)

# Generated at 2022-06-12 05:58:34.783331
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    success = Validation.success(20)
    assert success.to_lazy() == Lazy(lambda: 20)

    failure = Validation.fail('Failure')
    assert failure.to_lazy() == Lazy(lambda: None)

    success2 = success.ap(lambda v: Try(_throw_error, is_success=False))
    assert success2.to_lazy() == Lazy(lambda: None)

    failure2 = failure.ap(lambda v: Try(_throw_error, is_success=False))
    assert failure2.to_lazy() == Lazy(lambda: None)
