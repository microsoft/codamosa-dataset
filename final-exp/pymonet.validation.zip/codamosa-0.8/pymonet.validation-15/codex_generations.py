

# Generated at 2022-06-12 05:48:36.167949
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def method():
        return 'b'

    assert Lazy(method) == Validation.success().to_lazy()
    assert Validation.fail(['a']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')

# Generated at 2022-06-12 05:48:40.176225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:45.932249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(10).map(Lazy.of).to_lazy() == Lazy(10)
    assert Validation.success(10).to_lazy() == Lazy(10)


# Generated at 2022-06-12 05:48:49.804833
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return 'value'
    assert Validation.success(f).to_lazy().eval() == 'value'
    assert Validation.fail(['error']).to_lazy().eval() == None



# Generated at 2022-06-12 05:48:53.700405
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    validation = Validation.success(Maybe.just(10)).to_lazy()

    assert isinstance(validation, Lazy)
    assert validation.value() == Maybe.just(10)


# Generated at 2022-06-12 05:48:56.668449
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:48:59.982525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_monad = Validation.fail([1, 2, 3]).to_lazy()

    assert lazy_monad.value() is None


# Generated at 2022-06-12 05:49:03.020697
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return Validation.success('thrown')

    lazy = Validation.success('thrown').to_lazy()
    assert lazy.evaluate() == f()


# Generated at 2022-06-12 05:49:05.594232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(10).to_lazy()

    assert lazy.get() == 10
    assert lazy.get() == 10


# Generated at 2022-06-12 05:49:08.353766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)
    assert Validation(10, [20]).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:49:19.334249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation_with_err = Validation.fail(['some error'])
    validation_successfully = Validation.success('value')

    validation_with_err_to_lazy = validation_with_err.to_lazy()
    validation_successfully_to_lazy = validation_successfully.to_lazy()

    assert isinstance(validation_with_err_to_lazy, Lazy)
    assert isinstance(validation_successfully_to_lazy, Lazy)

    assert validation_with_err_to_lazy.get() is None
    assert validation_successfully_to_lazy.get() == 'value'


# Generated at 2022-06-12 05:49:21.129223
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(42)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 42)


# Generated at 2022-06-12 05:49:26.067565
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import identity

    assert identity(Validation.success(123).to_lazy().value()) == Validation.success(123).value
    assert identity(Validation.fail([]).to_lazy().value()) == Validation.fail([]).value


# Generated at 2022-06-12 05:49:29.587660
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:31.641276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert(Lazy(lambda: 1) == Validation.success(1).to_lazy())


# Generated at 2022-06-12 05:49:33.087876
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    validation = Validation.success(value=17)

    # when
    lazy = validation.to_lazy()

    # then
    assert lazy.value == 17


# Generated at 2022-06-12 05:49:40.050935
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_map(x):
        return x + 1

    def success_func(x):
        return Validation.success(x)

    monad1 = Validation.fail(['err']).to_lazy()
    monad2 = Validation.success(1).to_lazy()
    assert monad1.map(test_map).value() == None
    assert monad1.bind(success_func).value() == None
    assert monad2.map(test_map).value() == 2
    assert monad2.bind(success_func).value() == 1


# Generated at 2022-06-12 05:49:42.380465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)

    assert isinstance(validation.to_lazy(), Lazy) is True

# Generated at 2022-06-12 05:49:52.310075
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(123).to_lazy().value() == 123
    assert Validation.fail([1, 'a']).to_lazy().value() is None
    assert Validation.success(Box(123)).to_lazy().value() == 123
    assert Validation.fail(['a', Try(lambda: 1 / 0)]).to_lazy().value() is None
    assert Validation.success(Box(Try(1 / 0))).to_lazy().value() is None
    assert Validation.success(Lazy(lambda: 1 / 0)).to_lazy().value() is None


# Generated at 2022-06-12 05:50:00.362400
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.future import Future

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()

    assert Future(lambda: 2) == Validation.success(2).to_lazy().to_future()

    assert Future(lambda: 2) == Validation.success(2).to_future()

    assert Future(lambda: 2) == Validation.success(2).to_lazy().to_future().to_lazy().to_future()


# Generated at 2022-06-12 05:50:10.358106
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # mock a function for Lazy
    # test function is value-returning, so we don't have to deal with non-value-returning functions now
    def test_func():
        return 42

    # mock a Lazy object
    def test_lazy(function):
        return function()

    # mock a Try object
    def test_try(value, is_success=False):
        return value

    # mock a Box object
    def test_box(value):
        return value

    # Before mocking any object, we want to make sure the mock objects would not change the test result
    assert Validation(42, []).to_lazy() == Lazy(lambda: 42)
    assert Val

# Generated at 2022-06-12 05:50:15.073382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(124)
    assert success.to_lazy() == Lazy(lambda: 124)
    assert success.to_lazy().value() == 124

    success = Validation.fail([])
    assert success.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:50:21.138149
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    assert validation.to_lazy().eval() == 1
    validation = Validation.fail([2])
    assert validation.to_lazy().eval() is None
    validation = Validation.success(None)
    assert validation.to_lazy().eval() is None
    validation = Validation.fail([])
    assert validation.to_lazy().eval() is None


# Generated at 2022-06-12 05:50:26.596756
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    validation = Validation.success(Box(Lazy(lambda: Try.fail())))
    assert validation.to_lazy() == Lazy(lambda: validation.value)

# Generated at 2022-06-12 05:50:30.680953
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(2)
    assert isinstance(validation.to_lazy(), Lazy)
    assert validation.to_lazy().value() == 2
    assert validation == validation.to_lazy().to_validation()

# Generated at 2022-06-12 05:50:34.305344
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    val = Validation.success(42)
    lazy = val.to_lazy()

    assert lazy == Lazy(lambda: 42)

# Generated at 2022-06-12 05:50:36.906885
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('foo').to_lazy() == Lazy(lambda: 'foo')


# Generated at 2022-06-12 05:50:48.996657
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left

    assert Lazy(lambda: 42) == Validation.success(42).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1, 2, 3]).to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['wrong']).to_lazy()
    assert Lazy(lambda: 42) == Validation(42, []).to_lazy()
    assert Lazy(lambda: None) == Validation(None, [1, 2, 3]).to_lazy()

# Generated at 2022-06-12 05:50:51.507283
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = Validation.success('123').to_lazy()

    assert isinstance(value, Lazy)
    assert value() == '123'


# Generated at 2022-06-12 05:50:57.336727
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_unit_test import MonadUnitTest

    def _get_expected():
        return Lazy(lambda: Box(2))

    def _get_tested():
        return Validation.fail([1, 2, 3]).to_lazy()

    MonadUnitTest.verify(
        _get_expected,
        _get_tested
    )


# Generated at 2022-06-12 05:51:03.265913
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def call_me():
        return 3

    lazy = Validation.success(call_me).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.call() == 3


# Generated at 2022-06-12 05:51:06.291943
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Try(3, True).to_lazy().unsafe_get() == 3
    assert Try(3, False).to_lazy().unsafe_get() is None


# Generated at 2022-06-12 05:51:14.846462
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Unit test for method Validation.to_lazy()
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert Validation.success(1).value == validation.to_lazy().get()

    validation = Validation.fail(['a'])
    assert Validation(None, ['a']).value == validation.to_lazy().get()

    def f():
        return 1
    assert Lazy(f).get() == Lazy(f).to_validation().get()


# Generated at 2022-06-12 05:51:16.547663
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert(validation.to_lazy() == Lazy(lambda: 1))

    validation = Validation.fail([])
    assert(validation.to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-12 05:51:19.511764
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(10).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:26.069909
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    assert Validation.success('Hello').to_lazy() == Lazy(lambda: 'Hello')
    assert Validation.success('Hello').to_try() == Try('Hello', is_success=True)



# Generated at 2022-06-12 05:51:29.779452
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success('hello')
    result = validation.to_lazy()
    assert result == Lazy(lambda: 'hello')
    assert result() == 'hello'


# Generated at 2022-06-12 05:51:34.783180
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for to_lazy method of class Validation.
    """
    from pymonet.try_ import Try

    assert Validation.success(10).to_lazy() == Try(10).to_lazy()
    assert Validation.fail([1, 2]).to_lazy() == Try(None, is_success=False).to_lazy()


# Generated at 2022-06-12 05:51:42.300417
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    result = Validation.success(5).to_lazy()
    assert result == Lazy(lambda: 5)

    assert Validation.success(5).to_lazy().get() == 5
    assert Validation.success(5).to_lazy().get() == 5

    result = Validation.fail([]).to_lazy()
    assert result == Lazy(lambda: None)

    assert Validation.fail([]).to_lazy().get() is None
    assert Validation.fail([]).to_lazy().get() is None


# Generated at 2022-06-12 05:51:47.045028
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'value') == Validation.success('value').to_lazy()


# Generated at 2022-06-12 05:51:56.809584
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['some error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:01.125649
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    fn = lambda: 'Test value'
    lazy = Lazy(fn)
    validation = Validation.success(fn)

    assert validation.to_lazy() == lazy


# Generated at 2022-06-12 05:52:08.523066
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from tests.helpers import equality_test

    # Test for successful validation
    def func():
        return 'value'

    lazy_validation = Validation.success(func).to_lazy()
    assert isinstance(lazy_validation, Lazy)
    equality_test(lazy_validation, Lazy(func))

    # Test for failed validation
    def func():
        return 'value'

    lazy_validation = Validation.fail().to_lazy()
    assert isinstance(lazy_validation, Lazy)
    equality_test(lazy_validation, Lazy(lambda: None))


# Generated at 2022-06-12 05:52:13.109073
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:18.985339
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    success_validation = Validation.success(1)
    lazy = success_validation.to_lazy()
    assert lazy.unwrap() == 1
    assert isinstance(lazy, Lazy)

    failed_validation = Validation.fail([])
    lazy = failed_validation.to_lazy()
    assert lazy.unwrap() == None
    assert isinstance(lazy, Lazy)


# Generated at 2022-06-12 05:52:23.768469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('Success').to_lazy() == Lazy(lambda: 'Success')
    assert Validation.success('').to_lazy() == Lazy(lambda: '')
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:26.825797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('hoge').to_lazy() == Lazy(lambda: 'hoge')

# Generated at 2022-06-12 05:52:30.481464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validate = Validation.success(1)
    assert validate.to_lazy() == Lazy(lambda: 1)

    validate = Validation.fail([1, 2, 3])
    assert validate.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:52:33.200260
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-12 05:52:37.161970
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def add(n):
        return lambda: n + 1

    n = 10

    validation = Validation.success(n)
    assert validation.to_lazy().value() == n

    validation = Validation.fail(['error'])
    assert validation.to_lazy().value() is None



# Generated at 2022-06-12 05:52:47.988144
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success("value").to_lazy() == Lazy(lambda: "value")


# Generated at 2022-06-12 05:52:52.656202
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.fail([1, 2, 3])
    assert isinstance(validation.to_lazy(), Lazy)
    assert validation.to_lazy().eval() is None

    validation = Validation.success(1)
    assert isinstance(validation.to_lazy(), Lazy)
    assert validation.to_lazy().eval() == 1


# Generated at 2022-06-12 05:52:57.187491
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Success value
    assert Validation.success(1).to_lazy().eval() == 1
    # Failed value
    assert Validation.fail([]).to_lazy().eval() is None

test_Validation_to_lazy()


# Generated at 2022-06-12 05:53:06.674200
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def validator():
        return Validation(1, [])

    def invalidator():
        return Validation(None, [])

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(validator).to_lazy() == Lazy(validator)
    assert Validation.fail(invalidator).to_lazy() == Lazy(invalidator)



# Generated at 2022-06-12 05:53:10.505500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Validation.success(3).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()


# Generated at 2022-06-12 05:53:14.996364
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success('test')
    assert val.value == 'test'
    assert val.errors == []

    lazy_val = val.to_lazy()
    assert lazy_val.value() == 'test'
    val.value = 'new_test'
    assert lazy_val.value() == 'test'


# Generated at 2022-06-12 05:53:22.573971
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.fail(['Error'])
    assert v.to_lazy().run() is None
    assert v.map('to_lazy').to_lazy().run() == 'to_lazy'

    v = Validation.success('success')
    assert v.to_lazy().run() == 'success'
    assert v.map('to_lazy').to_lazy().run() == 'success'


# Generated at 2022-06-12 05:53:33.040484
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail(['a', 'b']).to_lazy() == Validation.fail(['a', 'b']).to_lazy()
    assert Validation.fail(['a', 'b']).to_lazy() != Validation.fail(['a', 'b', 'c']).to_lazy()
    assert Validation.fail(['a', 'b']).to_lazy() != Validation.success(['a', 'b']).to_lazy()
    assert Validation.success(['a', 'b']).to_lazy() != Validation.fail(['a', 'b', 'c']).to_lazy()
    assert Validation.success(['a', 'b']).to_lazy() != Validation.success(['a', 'b', 'c']).to_lazy()


# Generated at 2022-06-12 05:53:37.581724
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().call() == 1
    assert Validation.fail().to_lazy().call() == None


# Generated at 2022-06-12 05:53:45.340889
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test should convert Validation to Lazy value:

    >>> from pymonet.monad_try import Try
    >>> from decimal import Decimal
    >>> from pymonet.validation import Validation
    >>> from pymonet.functor import Functor
    >>> def f(x):
    ...     return Validation.success(x + 1)
    >>> validation = Functor.of(Try.of(Decimal(2))).map(f)
    >>> validation.to_lazy().eval().is_success()
    True
    >>> validation.to_lazy().eval().value
    Decimal('3')
    """
    pass

# Generated at 2022-06-12 05:54:02.813797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:54:09.010738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left

    # When Validation is successful
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    # When Validation is failed
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)

    # When Validation is unsuccessful
    assert Validation.fail(['error1', 'error2']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:54:15.139054
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success_value_validation = Validation.success(5)
    failure_value_validation = Validation.fail(5)

    assert success_value_validation.to_lazy() == Lazy(lambda: 5)
    assert success_value_validation.value == 5

    assert failure_value_validation.to_lazy() == Lazy(lambda: None)
    assert failure_value_validation.value is None



# Generated at 2022-06-12 05:54:18.998855
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # when
    validation = Validation.success(1)

    # then
    assert validation.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:22.368576
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:54:31.919172
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success('abc').to_lazy() == Lazy(lambda: 'abc')
    assert Validation.success(Try.success(5)).to_lazy() == Lazy(lambda: Try.success(5))
    assert Validation.success(Try.fail(5)).to_lazy() == Lazy(lambda: Try.fail(5))
    assert Validation.success('abc').to_lazy().value == 'abc'


# Generated at 2022-06-12 05:54:41.689779
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import compose, prop
    from pymonet.lazy import Lazy
    import pymonet.monad_try as monad_try

    # Function for composing Lazy monad
    def lazy_compose(f):
        return lambda m: Lazy(lambda: f(m.force()))

    # Compose function for Lazy monad
    compose_lazy = lambda f, g: lambda x: g(x).bind(lazy_compose(f))

    # Function for creating function that returns double of parameter
    def mul_by(n):
        return lambda x: x * n

    # Function for creating function that returns Validation with value that is equal to sum of input parameters
    def sums(xs):
        return sum(xs)

    # Creating functions and combining them
    # Function find_user_

# Generated at 2022-06-12 05:54:44.848616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    validation = Validation(value, [])

    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-12 05:54:50.684035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    lazy1 = Validation.success(Try.success(42)).to_lazy()
    assert lazy1.evaluate() == 42
    lazy2 = Validation.fail([1, 2, 3]).to_lazy()
    assert lazy2.evaluate() is None


# Generated at 2022-06-12 05:54:54.481913
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('hello').to_lazy().eval() == 'hello'
    assert Validation.fail(['some errors']).to_lazy().eval() == None


# Generated at 2022-06-12 05:55:27.065735
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:55:34.998272
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Test with successful Validation
    validation = Validation.success(1)
    lazy_validation = validation.to_lazy()
    assert isinstance(lazy_validation, Lazy)
    assert lazy_validation.get_value() == 1
    assert validation.value == 1

    # Test with failed Validation
    validation = Validation.fail([])
    lazy_validation = validation.to_lazy()
    assert isinstance(lazy_validation, Lazy)
    assert lazy_validation.get_value() is None
    assert validation.value is None



# Generated at 2022-06-12 05:55:37.771520
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()
    assert lazy == Lazy(lambda: 1)

# Generated at 2022-06-12 05:55:41.539906
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert(Validation.success(value='apple').to_lazy().value() == 'apple')
    assert(Validation.success().to_lazy().value() is None)
    assert(Validation.fail('error').to_lazy().value() is None)


# Generated at 2022-06-12 05:55:47.408753
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:55.028146
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It checks for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:59.492846
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:03.454008
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail(['some error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('some value').to_lazy() == Lazy(lambda: 'some value')



# Generated at 2022-06-12 05:56:10.565525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from unittest import TestCase
    from unittest.mock import Mock
    from unittest.mock import patch

    class TestValidationLazy(TestCase):

        @patch('pymonet.lazy.Lazy')
        @patch('pymonet.monad_validation.Validation')
        def test_to_lazy(self, mock_Validation, mock_Lazy):
            mock_validation = Mock(spec=Validation)
            mock_validation.value = 'a'
            mock_validation.is_success.return_value = True
            mock_validation.to_lazy.return_value = Lazy(lambda: 'a')
            mock_validation.to_lazy()
            mock_Lazy.assert_called_once

# Generated at 2022-06-12 05:56:13.289245
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It test to_lazy method.
    """
    assert Validation(5, []).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:57:18.552959
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(value=1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(value=None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(errors=[1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:57:22.127287
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        from pymonet.lazy import Lazy
        from pymonet.box import Box
        assert Validation.success(Box(3)).to_lazy() == Lazy(lambda: Box(3))
    except ImportError:
        pass



# Generated at 2022-06-12 05:57:31.572334
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Test with no errors
    v  = Validation.success(5)
    l  = Lazy(lambda: 5)
    assert v.to_lazy() == l

    # Test with errors
    v  = Validation.fail([1, 2, 3])
    l  = Lazy(lambda: None)
    assert v.to_lazy() == l

    # Test with no errors and error
    v  = Validation.fail([1, 2, 3]).success(5)
    l  = Lazy(lambda: 5)
    assert v.to_lazy() == l


# Generated at 2022-06-12 05:57:37.925034
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(7).to_lazy()
    assert isinstance(validation, Lazy)
    assert validation.is_success()
    assert validation.value() == 7

    validation = Validation.fail([1, 2, 3]).to_lazy()
    assert isinstance(validation, Lazy)
    assert validation.is_fail()
    assert validation.value() is None


# Generated at 2022-06-12 05:57:40.836535
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().value() == 1



# Generated at 2022-06-12 05:57:45.138414
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation.
    """
    from pymonet.lazy import Lazy

    assert Validation.success(7).to_lazy() == Lazy(lambda: 7)
    assert Validation.success('foo').to_lazy() == Lazy(lambda: 'foo')


# Generated at 2022-06-12 05:57:47.343684
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(1).to_lazy()

    assert isinstance(result, Lazy)
    assert result.get() == 1


# Generated at 2022-06-12 05:57:55.027519
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It is testing Validation.to_lazy() method.
    It is expected that Validation.to_lazy() will return Lazy monad with function returning previous value.
    """
    from pymonet.lazy import Lazy

    v = Validation(1, [])
    l1 = Lazy(lambda: 1)
    l2 = v.to_lazy()
    assert l1.to_value() == l2.to_value()



# Generated at 2022-06-12 05:57:58.727147
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Fail, Success

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(12).to_lazy() == Lazy(lambda: 12)



# Generated at 2022-06-12 05:58:08.201809
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    #
    # method to_lazy
    #

    # when:
    m = Validation.fail(['error'])
    result = m.to_lazy()

    # then:
    assert result == Lazy(lambda: m.value)

    # when:
    m = Validation.success('success')
    result = m.to_lazy()

    # then:
    assert result == Lazy(lambda: m.value)
