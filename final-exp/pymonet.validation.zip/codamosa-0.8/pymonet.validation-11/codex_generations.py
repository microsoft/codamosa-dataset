

# Generated at 2022-06-12 05:48:38.400200
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success([1, 2, 3]).to_lazy() == Lazy(lambda: [1, 2, 3])
    assert Validation.fail(10).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:43.070791
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success('foo').to_lazy() == Lazy(lambda: 'foo')
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:48:50.353395
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    errors = ['a']
    value = '4'
    validation = Validation.fail(errors)
    lazy = validation.to_lazy()

    assert validation.value == None
    assert lazy.evaluate() == None

    validation = Validation.success(value)
    lazy = validation.to_lazy()

    assert validation.value == value
    assert lazy.evaluate() == value


# Generated at 2022-06-12 05:48:52.314985
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('value').to_lazy().eval() == 'value'


# Generated at 2022-06-12 05:48:55.956437
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Lazy.of(lambda: 1) == Validation.success(1).to_lazy()



# Generated at 2022-06-12 05:49:07.892962
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Testing Validation.to_lazy on a simple example.
    """
    fn = Validation.success(lambda x, y: x + y)
    even_odd = Validation.success(lambda x: 'even' if x % 2 == 0 else 'odd')
    odd_even = Validation.success(lambda x: 'odd' if x % 2 == 0 else 'even')

    assert fn.to_lazy() == Lazy(lambda: lambda x, y: x + y)
    assert even_odd.to_lazy() == Lazy(lambda: lambda x: 'even' if x % 2 == 0 else 'odd')
    assert odd_even.to_lazy() == Lazy(lambda: lambda x: 'odd' if x % 2 == 0 else 'even')


# Generated at 2022-06-12 05:49:18.714481
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_test_helpers import should_return_success, should_return_fail
    from pymonet.lazy import Lazy

    def assert_validation_to_lazy(x, expected):
        value = Lazy(x)
        assert Validation.success(value).to_lazy() == expected

    def assert_validation_fail_to_success_lazy(x, expected):
        assert Validation.fail(x).to_lazy() == expected

    # Success validation to success lazy
    assert_validation_to_lazy(
        value=lambda: 1,
        expected=Lazy(lambda: 1)
    )

    # Success validation to fail lazy

# Generated at 2022-06-12 05:49:24.289216
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    >>> v = Validation.success(2)
    >>> v.to_lazy()
    Lazy[Function() -> 2]
    >>> v.to_lazy().value()
    2
    >>> v2 = Validation.fail([])
    >>> v2.to_lazy()
    Lazy[Function() -> None]
    >>> v2.to_lazy().value()
    """

# Generated at 2022-06-12 05:49:28.572660
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test():
        return 3

    validate = Validation.success(test)

    assert validate.to_lazy() == Lazy(test)


# Generated at 2022-06-12 05:49:31.604552
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(None)
    assert v.to_lazy() == Lazy(None)

    v = Validation.success(1)
    assert v.to_lazy() == Lazy(1)



# Generated at 2022-06-12 05:49:37.404824
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """

    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:49:43.174790
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success([1,2,3]) == Validation.success([1,2,3]).to_lazy().to_validation()
    assert Validation.fail(errors=['some error']) == Validation.fail(errors=['some error']).to_lazy().to_validation()
    assert None is Validation.success().to_lazy().value()
    assert None is Validation.fail(errors=[]).to_lazy().value()

# Generated at 2022-06-12 05:49:46.722181
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: None)
    validation = Validation.success(1).to_lazy()

    assert validation == lazy
    assert validation.value() == 1


# Generated at 2022-06-12 05:49:50.289751
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Object of Validation class transformed to Lazy returns Validation value"""
    validation = Validation(10, [])
    assert Lazy(lambda: 10) == validation.to_lazy(), 'Validation.to_lazy failed'


# Generated at 2022-06-12 05:50:01.095941
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success(42)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.evaluate() == 42

    validation = Validation.fail(['failure'])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.evaluate(), Try)
    assert lazy.evaluate().is_fail() is True

Validation.unit = classmethod(Validation.success)
Validation.plus = classmethod(lambda cls, x, y: Validation(x.value, x.errors + y.errors))

# Generated at 2022-06-12 05:50:05.295131
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return Validation.success(2)

    assert func() == Validation.success(2)
    assert func().to_lazy() == Lazy(func)


# Generated at 2022-06-12 05:50:09.523569
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_func():
        return 2

    validation = Validation.success(test_func())
    assert validation.to_lazy().get() == Validation.success(2).value
    assert validation.to_lazy().map(lambda x: x * 2).get() == 4
    assert validation.to_lazy().flat_map(lambda x: lazy(lambda: x * 2)).get() == 4


# Generated at 2022-06-12 05:50:12.575557
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success([1, 2, 3]).to_lazy()
    assert lazy.value() == [1, 2, 3]

# Generated at 2022-06-12 05:50:15.074184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy().get() == 10
    assert Validation.fail(10).to_lazy().get() == None


# Generated at 2022-06-12 05:50:21.682330
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_function_when_success():
        validation = Validation.success(1)
        lazy = validation.to_lazy()

        assert lazy == Lazy(lambda: 1)

    def test_function_when_fail():
        validation = Validation.fail()
        lazy = validation.to_lazy()

        assert lazy == Lazy(lambda: None)

    test_function_when_success()
    test_function_when_fail()


# Generated at 2022-06-12 05:50:26.497725
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def action():
        return 1

    assert Validation.success().to_lazy() == Lazy(action)


# Generated at 2022-06-12 05:50:30.626004
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy().value == Lazy(1).value
    assert Validation.fail().to_lazy().value == Lazy(None).value

# Generated at 2022-06-12 05:50:32.396525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success("Python").to_lazy().eval() == "Python"


# Generated at 2022-06-12 05:50:40.089561
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test that transform Validation to Lazy. Result is Lazy with function returns None.

    :return: True when test finished without exceptions
    """
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy

    validation_true = Validation.success()
    validation_false = Validation.fail()

    assert validation_true.to_lazy() == Lazy(lambda: validation_true.value)
    assert validation_false.to_lazy() == Lazy(lambda: validation_false.value)

    return True


# Generated at 2022-06-12 05:50:42.392753
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_inner():
        return Validation.success(1).value

    assert Lazy(test_inner).force() == 1



# Generated at 2022-06-12 05:50:47.705903
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:50:49.693833
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:50:56.920882
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Union[ 'Unit -> Unit',
          '[E] -> (None | A) -> Lazy[Function() -> Union[None, A]]',
         'A -> Lazy[Function() -> A]'
    """
    from pymonet.lazy import Lazy

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(['error']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')



# Generated at 2022-06-12 05:51:05.580873
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_validation import Validation

    lazy_failure = Validation.fail().to_lazy()
    assert lazy_failure == Lazy(lambda: None)
    assert Failure(None).equals(lazy_failure.evaluate())

    lazy_success = Validation.success("value").to_lazy()
    assert lazy_success == Lazy(lambda: "value")
    assert "value" == lazy_success.evaluate()


# Generated at 2022-06-12 05:51:10.247373
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.success(3).to_lazy().value() == 3
    assert Validation.fail(['a', 'b']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:19.729098
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def extract_value(value):
        return value

    lazy_fun = Validation.success(1).to_lazy()
    assert isinstance(lazy_fun, Lazy)
    assert lazy_fun.value(extract_value) == 1

    lazy_fun = Validation.fail(['err']).to_lazy()
    assert isinstance(lazy_fun, Lazy)
    assert lazy_fun.value(extract_value) is None


# Generated at 2022-06-12 05:51:24.444623
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    @lazy
    def get_sum(a, b):
        return a + b

    validation = Validation.success(5).map(get_sum.set(1, 2)).to_lazy()
    assert validation.value() == 3


# Generated at 2022-06-12 05:51:27.927879
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.fail(['test']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:30.749660
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:51:35.014925
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation([42], []).to_lazy() == Lazy(lambda: [42])
    assert Validation(["data"], ["error1", "error2"]).to_lazy() == Lazy(lambda: ["data"])


# Generated at 2022-06-12 05:51:38.406196
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(1, []).to_lazy()
    assert validation == Lazy(lambda: 1)
    assert validation.value() == 1


# Generated at 2022-06-12 05:51:42.056118
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success(1)
    assert val.to_lazy() == Lazy(lambda: 1)

    val = Validation.fail([])
    assert val.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:51:46.515756
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert(Validation.success(2).to_lazy() == Lazy(lambda: 2))
    assert(Validation.fail('Error').to_lazy() == Lazy(lambda: None))

# Generated at 2022-06-12 05:51:52.193685
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success([1, 2, 3])
    assert success.to_lazy() == Lazy([1, 2, 3])
    assert success.to_lazy().value_or_default() == [1, 2, 3]

    fail = Validation.fail()
    assert fail.to_lazy() == Lazy(None)
    assert fail.to_lazy().value_or_default() == None


# Generated at 2022-06-12 05:51:58.779313
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def side_effect(value): return value

    assert Lazy(lambda: side_effect(Validation.success(2).value)) == Validation.success(2).to_lazy()
    assert Lazy(lambda: side_effect(Validation.fail([]).value)) == Validation.fail([]).to_lazy()



# Generated at 2022-06-12 05:52:05.013511
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:52:08.115610
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    _iter = [Validation.success(1).to_lazy(),
             Validation.fail(['Something wrong']).to_lazy()]

    for element in _iter:
        assert isinstance(element, Lazy)
        assert isinstance(element.value, int) or element.value is None


# Generated at 2022-06-12 05:52:18.851356
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # GIVEN: Empty errors list
    errors = []

    # AND: Value
    value = 1

    # AND: Validator function
    def validate(value):
        """
        Validate value and returns

        :param value: value to validate
        :type value: Any
        :returns: Validation with value and errors list
        :rtype: Validation[Any, List[Any]]
        """
        return Validation(value, errors)

    # WHEN: Validating value
    validation = validate(value)

    # THEN: Errors list should be empty
    assert len(errors) == 0

    # AND: Validation should be successful
    assert validation.is_success()

    # AND: Validation should have value
    assert validation.value == 1

    # AND: Validating value

# Generated at 2022-06-12 05:52:28.987028
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(5)
    assert validation.to_lazy() == Lazy(lambda: 5)
    assert validation.to_lazy().__repr__() == 'Lazy(lambda: 5)'
    assert validation.to_lazy().__str__() == 'Lazy(lambda: 5)'

    validation = Validation.fail(['error'])
    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.to_lazy().__repr__() == 'Lazy(lambda: None)'
    assert validation.to_lazy().__str__() == 'Lazy(lambda: None)'


# Generated at 2022-06-12 05:52:33.967424
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_success = Validation.success('Success')
    validation_fail = Validation.fail(['Fail'])

    assert validation_success.to_lazy() == Lazy(lambda: 'Success')
    assert validation_fail.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:52:36.448732
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    assert validation.to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:52:39.526226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def check(value, is_success):
        lz = Validation(value, [] if is_success else [0]).to_lazy()
        return lz.run() == value

    assert check(1, True)
    assert check(1, False)



# Generated at 2022-06-12 05:52:42.798264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 'test') == Validation.success('test').to_lazy()
    assert Lazy(lambda: Validation.fail()).to_try() == Try(Validation.fail(), False)

# Generated at 2022-06-12 05:52:50.034571
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def exception_generator():
        raise True

    def value_generator():
        return True

    validation_error = Validation.fail(True)
    assert validation_error.to_lazy() == Lazy(lambda: None)
    validation = Validation.success(True)
    assert validation.to_lazy() == Lazy(value_generator)


# Generated at 2022-06-12 05:52:59.961526
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(4).to_lazy() == Lazy(lambda: 4)
    assert Validation.success(4).to_lazy().run() == 4
    assert Validation.success(4).to_lazy().run() == Box(4)
    assert Validation.success(4).to_lazy().run() == Try(4, is_success=True)
    assert Validation.success(4).to_lazy().run() == Validation.success(4)
    assert Validation.success(4).to_lazy().run() == Validation.success(4).to_box()
    assert Validation.success(4).to_lazy().run() == Validation.success(4).to_maybe()
   

# Generated at 2022-06-12 05:53:11.016185
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:13.423427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-12 05:53:19.376711
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(7).to_lazy() == Lazy(lambda: 7)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:25.828220
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def to_lazy(x): return x + 10

    validation = Validation(10, []).to_lazy().fmap(to_lazy)
    assert validation.if_value(True) == 20
    assert validation.if_value(False) == 10

    validation = Validation(10, [20]).to_lazy().fmap(to_lazy)
    assert validation.if_value(True) == 10
    assert validation.if_value(False) == 10


# Generated at 2022-06-12 05:53:30.477363
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-12 05:53:36.427302
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Validation.success(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() == 42

    lazy = Validation.fail([1, 2]).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.force() is None


# Generated at 2022-06-12 05:53:40.304564
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: Validation(None, [])) == Validation.success().to_lazy()

    assert Validation(Try(1), []).to_lazy() == Lazy(lambda: Try(1))

    assert Validation(None, [1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:53:49.989543
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(True).to_lazy() == Lazy(lambda: True)
    assert Validation.success({'a':1}).to_lazy() == Lazy(lambda: {'a':1})
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(Try(1)).to_lazy() == Lazy(lambda: Try(1))
    assert Validation.fail(["Error"]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(["Error"]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:53:53.445198
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:53:59.358672
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    validation = Validation.success(5)
    assert validation.value == 5
    assert validation.is_success()
    assert validation.to_lazy().force() == 5

    validation = Validation.fail([])
    assert validation.value is None
    assert validation.is_fail()
    assert validation.to_lazy().force() is None



# Generated at 2022-06-12 05:54:11.047134
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('Hello').to_lazy() == Lazy(lambda:'Hello')
    assert Validation.fail(['ERROR']).to_lazy() == Lazy(lambda:None)


# Generated at 2022-06-12 05:54:15.356502
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(1, [])
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation(1, [1])
    assert validation.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-12 05:54:21.207394
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success([]).to_lazy() == Lazy(lambda: [])
    assert Validation.success({}).to_lazy() == Lazy(lambda: {})


# Generated at 2022-06-12 05:54:26.943025
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    validation = Validation.success(value=1)
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)

    try_ = lazy.get()
    assert isinstance(try_, Try)

    assert try_.is_success()
    assert try_.get() == 1



# Generated at 2022-06-12 05:54:30.627184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation('valid', []).to_lazy() == Lazy(lambda: 'valid')
    assert Validation(None, ['Not valid']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:54:36.032709
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    val = Validation.success('a')
    lazy = val.to_lazy()
    assert(lazy.get() == 'a')
    assert(isinstance(lazy, Lazy) and isinstance(lazy.get(), Try))


# Generated at 2022-06-12 05:54:42.107894
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_success():
        assert Lazy(lambda: Validation.success(2).value) == Lazy(lambda: 2)

    def test_fail():
        assert Lazy(lambda: Validation.fail([]).value) == Lazy(lambda: None)

    test_success()
    test_fail()


# Generated at 2022-06-12 05:54:47.110464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    Validation.success(Maybe.just(1)).to_lazy().get() == Maybe.just(1)
    Validation.success(Lazy(lambda: 1)).to_lazy().get() == Lazy(lambda: 1)
    Validation.success(Maybe.nothing()).to_lazy().get() == Maybe.nothing()
    Validation.fail(1).to_lazy().get() is None


# Generated at 2022-06-12 05:54:48.960173
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    assert validation.to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:54:57.867443
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    def validate_user(user):
        if len(user.name) < 3:
            return Validation.fail(['{} is too short'.format(user.name)])
        return Validation.success(user)

    user = User('John')
    validation = validate_user(user)
    if validation.is_fail():
        print('Validation failed with: {}'.format(validation.errors))
    else:
        print('Validation success with: {}'.format(validation.value))

    validation = validation.to_lazy()
    if validation.get().is_fail():
        print('Validation failed with: {}'.format(validation.get().errors))
    else:
        print('Validation success with: {}'.format(validation.get().value))


# Generated at 2022-06-12 05:55:12.546513
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def returns_value():
        return 'abc'

    def returns_nothing():
        return None

    assert Validation.success(returns_value()).to_lazy() == Lazy(lambda: returns_value())
    assert Validation.success(returns_nothing()).to_lazy() == Lazy(lambda: returns_nothing())
    assert Validation.fail().to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-12 05:55:18.384357
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    from pymonet.lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:55:21.730341
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation = Validation.success(42)

    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.force() == 42


# Generated at 2022-06-12 05:55:27.457018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    lazy = Validation.success(10).to_lazy()
    assert hasattr(lazy, 'get')

    assert lazy.get() == 10
    assert lazy.get() == 10

    lazy = Validation.fail([20, 40]).to_lazy()
    assert hasattr(lazy, 'get')

    assert lazy.get() == None
    assert lazy.get() == None



# Generated at 2022-06-12 05:55:32.008222
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    validation = Validation.fail(["ERROR"])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.execute(), Try)


# Generated at 2022-06-12 05:55:37.873002
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-12 05:55:45.759089
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""
    from pymonet.monad import is_monad
    from pymonet.lazy import Lazy

    assert is_monad(Validation.success(1).to_lazy())
    assert is_monad(Validation.fail([]).to_lazy())
    assert is_monad(Validation.success([1]).to_lazy())
    assert is_monad(Validation.fail([1]).to_lazy())
    assert is_monad(Validation.success(True).to_lazy())
    assert is_monad(Validation.fail(True).to_lazy())
    assert is_monad(Validation.success({1:1}).to_lazy())

# Generated at 2022-06-12 05:55:49.441786
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)

    assert lazy() == 1

# Generated at 2022-06-12 05:55:57.430633
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    before_success = Validation.success(5)
    before_fail = Validation.fail([ValueError('Error')])
    after_success = before_success.to_lazy()
    after_fail = before_fail.to_lazy()
    assert after_success.value() == 5
    try:
        after_fail.value()
        assert False
    except ValueError as e:
        assert str(e) == 'Error'
    assert after_success.is_success()
    assert not after_fail.is_success()


# Generated at 2022-06-12 05:56:08.021695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        test = Validation.success("hello")
        value = test.to_lazy().evaluate()
        actual = value
        expected = "hello"
        assert actual == expected, "Expected {}, but got: {}".format(expected, actual)

    def test_case_1():
        test = Validation.fail("error")
        value = test.to_lazy().evaluate()
        actual = value
        expected = None
        assert actual == expected, "Expected {}, but got: {}".format(expected, actual)

    def test_case_2():
        test = Validation.success(123)
        value = test.to_lazy().evaluate()
        actual = value
        expected = 123
        assert actual == expected, "Expected {}, but got: {}".format(expected, actual)

# Generated at 2022-06-12 05:56:19.785402
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-12 05:56:24.278528
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    # Given
    lazy = Lazy(lambda: Validation.success(42))

    # When
    result = lazy.to_lazy()

    # Then
    assert result.value().value == 42


# Generated at 2022-06-12 05:56:27.074830
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    assert Validation(42, []).to_lazy().get() == 42
    assert Validation(None, ['error']).to_lazy().get() is None


# Generated at 2022-06-12 05:56:30.561961
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    unit_value = Lazy(lambda: Validation.success(1))
    assert isinstance(unit_value, Lazy)
    assert unit_value() == Validation.success(1)


# Generated at 2022-06-12 05:56:33.243838
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)



# Generated at 2022-06-12 05:56:38.497412
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:56:47.568030
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test method Validation.to_lazy that transforms Validation to Lazy monad.
    """
    from pymonet.lazy import Lazy

    def get_lazy_test_value():
        """
        Function that returns True.

        :returns: True
        :rtype: Boolean
        """
        return True

    validation_lazy = Validation(get_lazy_test_value, []).to_lazy()

    assert isinstance(validation_lazy, Lazy)
    assert callable(validation_lazy.value)
    assert validation_lazy.value() is True


# Generated at 2022-06-12 05:56:59.475399
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation

    >>> test_Validation_to_lazy()
    test_Validation_to_lazy
    - test_Validation_to_lazy.assert_to_lazy: passed
    """

    from pymonet.lazy import Lazy
    from pymonet import identity

    print('test_Validation_to_lazy')

    def assert_to_lazy(val_to_test):
        """
        Assert for method to_lazy of class Validation

        >>> assert_to_lazy(Validation.success(10)) #doctest: +ELLIPSIS
        <Lazy function returning <function <lambda> at 0x...>>
        """

# Generated at 2022-06-12 05:57:07.620650
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test method to_lazy of class Validation.
    """

    print('Test method to_lazy of Validation')

    # success validation
    validation = Validation(10, [])
    lazy_validation = validation.to_lazy()
    assert lazy_validation.get() == 10, 'Validation.to_lazy() is fail'

    # fail validation
    validation = Validation(None, [])
    lazy_validation = validation.to_lazy()
    assert lazy_validation.get() is None, 'Validation.to_lazy() is fail'

    print('Validation.to_lazy(): OK')



# Generated at 2022-06-12 05:57:11.765395
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    test Validation to_lazy method
    """
    from pymonet.lazy import Lazy

    assert Lazy(lambda: '') == Validation.success('').to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()


# Generated at 2022-06-12 05:57:33.442713
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v = Validation.success(12)
    assert isinstance(v.to_lazy(), Lazy)
    assert v.to_lazy().value() == 12

    v = Validation.fail([43])
    assert isinstance(v.to_lazy(), Lazy)
    assert v.to_lazy().value() is None


# Generated at 2022-06-12 05:57:43.928739
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation('first', []).to_lazy().eval() == 'first'
    assert Validation(123, []).to_lazy().eval() == 123
    assert Validation([1, 2, 3], []).to_lazy().eval() == [1, 2, 3]
    assert Validation({'a': 'first', 'b': 'second'}, []).to_lazy().eval() == {'a': 'first', 'b': 'second'}
    assert Validation(None, []).to_lazy().eval() is None
    assert Validation.success('first').to_lazy().eval() == 'first'
    assert Validation.fail([]).to_lazy().eval() is None
    assert Validation('first', ['error1', 'error2']).to_lazy().eval() is None

#

# Generated at 2022-06-12 05:57:50.458717
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    value = 'value'
    monad = Validation.success(value).to_lazy()

    assert isinstance(monad, Lazy)

    result = monad.value()

    assert isinstance(result, Try)
    assert result.is_success()
    assert value == result.value


# Generated at 2022-06-12 05:58:00.540461
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, Function

    def closure(errors):
        def result(value):
            return Validation(value, errors)
        return result

    assert Lazy(lambda: 42).is_equal_to(Validation.success(42).to_lazy())
    assert Lazy(lambda: 42).is_equal_to(Validation.fail(errors=[42]).to_lazy())
    assert Lazy(lambda: 42).is_equal_to(closure([]).call(42).to_lazy())
    assert Lazy(lambda: 42).is_equal_to(closure([]).call(42).to_lazy().to_try().to_lazy())

# Generated at 2022-06-12 05:58:03.696813
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(errors=["ERROR"]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-12 05:58:05.389520
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(1).to_lazy()
    assert val == 1


# Generated at 2022-06-12 05:58:16.189451
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def get_value():
        return 'value'

    validation = Validation.fail()

    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: None)
    assert str(lazy) == 'Lazy[value=None]'
    assert lazy.value() is None
    assert lazy.is_success() is False

    validation = Validation.success(get_value)

    lazy = validation.to_lazy()
    assert lazy == Lazy(get_value)
    assert str(lazy) == 'Lazy[value=value]'
    assert lazy.value() == 'value'
    assert lazy.is_success() is True


# Generated at 2022-06-12 05:58:20.565222
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Validation.fail(['err1']).to_lazy()
    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()


# Generated at 2022-06-12 05:58:23.099426
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Success

    assert (
        Validation.success(1).to_lazy()
        == Success(Lazy(lambda: 1)))

# Generated at 2022-06-12 05:58:28.579445
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation method to_lazy
    """
    validation = Validation([], [])
    try:
        assert Lazy(lambda: validation.value) == validation.to_lazy()
    except:  # pragma: no cover
        print(val)
