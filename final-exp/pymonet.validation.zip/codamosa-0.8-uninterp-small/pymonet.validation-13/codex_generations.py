

# Generated at 2022-06-26 00:18:34.831530
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = Validation.success(int_0)
    var_1 = Validation.success(int_0)
    assert var_0 == var_1
    var_2 = Validation.fail([int_0])
    var_3 = Validation.fail()
    assert var_2 == var_3
    var_4 = Validation.fail([int_0])
    var_5 = Validation.fail()
    assert var_4 == var_5
    var_6 = Validation.fail()
    var_7 = validation_0.map(lambda int_1: int_1)
    var_8 = Validation.fail([int_0, int_0])
    assert var_7 == var_8
   

# Generated at 2022-06-26 00:18:44.267912
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1975

# Generated at 2022-06-26 00:18:56.264648
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def value_func():
        return 'value'

    def err_func():
        raise ValueError('error')

    value_lazy = Lazy(value_func)
    try_value = Try(value_lazy.value())

    assert try_value.is_success == True
    assert try_value.value == 'value'

    err_0 = ValueError('error')
    err_lazy = Lazy(err_func)
    try_err = Try(err_lazy.value(), False)

    assert try_err.is_success == False
    assert try_err.error == ValueError, 'error'



# Generated at 2022-06-26 00:19:01.365498
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_1 = -1995
    validation_1 = Validation(int_1, int_1)
    var_1 = validation_1.to_lazy()
    assert var_1.is_lazy() is True


# Generated at 2022-06-26 00:19:06.163361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda : 5)
    assert Validation.fail(0).to_lazy() == Lazy(lambda : None)
    assert Validation.success(5).is_fail() is False
    assert Validation.fail(0).is_fail() is True


# Generated at 2022-06-26 00:19:13.167789
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def lazy_0():
        validation_0 = Validation(1, [])
        return validation_0.to_lazy()

    try_0 = lazy_0()
    assert isinstance(try_0, Lazy)

    int_0 = try_0.value()
    assert isinstance(int_0, int)
    assert int_0 == 1

    validation_0 = Validation(1, [])
    lazy_0 = validation_0.to_lazy()

    # Test for method value of class Lazy
    def lazy_1():
        return lazy_0.value()

    int_1 = lazy_1()
    assert isinstance(int_1, int)
    assert int_1 == 1


#

# Generated at 2022-06-26 00:19:20.060091
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.fail()
    var_0 = validation_0.to_lazy()
    assert_equal(var_0, Lazy(lambda: None))
    var_1 = validation_0.to_try()
    assert_equal(var_1, Try(None, is_success=False))


# Generated at 2022-06-26 00:19:29.535382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        int_0 = -1995
        validation_0 = Validation(int_0, [])
        var_0 = validation_0.to_lazy()

    def test_case_1():
        int_0 = -1995
        validation_0 = Validation(int_0, [])
        var_0 = validation_0.to_lazy()
        var_1 = var_0.get()
        var_2 = isinstance(var_1, int)
        assert var_2

    def test_case_2():
        int_0 = -1995
        validation_0 = Validation(int_0, [])
        var_0 = validation_0.to_lazy()
        var_1 = var_0.get()
        var_2 = var_1 + (-1995)


# Generated at 2022-06-26 00:19:31.771856
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:42.606320
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import monad_unit
    from pymonet.monad import monad_bind
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.functor import functor_0
    from pymonet.functor import functor_1

    def function_0(_value):
        return Lazy(lambda: _value)

    def function_1(value):
        return Lazy(lambda: value)

    monad_unit(function_0, Validation, functor_0)
    monad_bind(function_1, Validation, functor_0, functor_1)


# Generated at 2022-06-26 00:19:46.779258
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(lambda: 1976)
    assert validation.to_lazy() == Lazy(lambda: lambda: 1976)


# Generated at 2022-06-26 00:19:53.578320
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    success = Validation.success(int_0)
    assert success.to_lazy() == Lazy(lambda: int_0)

    assert isinstance(success.to_lazy(), Monad) == True
    assert success.to_lazy().is_value() == True
    assert success.to_lazy().is_thunk() == True
    assert success.to_lazy().get_value() == int_0


# Generated at 2022-06-26 00:19:57.670414
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def inner_function():
        return 11
    result = Validation.success(11).to_lazy()
    assert isinstance(result, Lazy)
    assert result.value == inner_function
    assert result.value() == 11


# Generated at 2022-06-26 00:20:03.083063
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It takes as parameter function returning another monad.
    Function is called with Validation value and returns new Validation with previous value
    and concated new and old errors.
    """
    validation = Validation.success(10)
    lazy = validation.to_lazy()

    assert lazy.is_callable()
    assert lazy.get_value() == 10


# Generated at 2022-06-26 00:20:07.380572
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy as lazy

    int_0 = 1975
    validation_0 = Validation(int_0, ["Error", "Another error"])
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.evaluate() == int_0
    assert isinstance(lazy_0, lazy.Lazy)


# Generated at 2022-06-26 00:20:10.343028
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    lazy_int_0 = Lazy(lambda: int_0)

    validation = Validation.success(lazy_int_0)

    assert validation.to_lazy().value() is lazy_int_0


# Generated at 2022-06-26 00:20:16.336900
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    int_0 = 1975
    int_1 = 10

    validation = Validation(int_0, [])
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy), 'Validation.to_lazy must return Lazy monad'
    assert lazy() == int_0, 'Validation.to_lazy must return Lazy with value stored in Validation'


# Generated at 2022-06-26 00:20:20.854691
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    _lazy_0 = Validation.success(1975).to_lazy()
    int_1 = _lazy_0.eval()
    assert int_1 == 1975
    _lazy_1 = Validation.fail([1]).to_lazy()
    int_2 = _lazy_1.eval()
    assert int_2 is None


# Generated at 2022-06-26 00:20:25.124978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    test_case_0()
    result_0 = Validation.success(int_0).to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0.value == Box(int_0)

# Generated at 2022-06-26 00:20:35.201312
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Case 0
    print('Case 0')

    validation_0 = Validation.success()
    try_0 = validation_0.to_lazy()

    print('{} == {}'.format(validation_0.to_lazy(), try_0))
    print()

    # Case 1
    print('Case 1')

    validation_1 = Validation.success(7)
    try_1 = validation_1.to_lazy()

    print('{} == {}'.format(validation_1.to_lazy(), try_1))
    print()

    # Case 2
    print('Case 2')

    validation_2 = Validation.fail()
    try_2 = validation_2.to_lazy()



# Generated at 2022-06-26 00:20:40.805035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 1975

    lazy_0 = Validation.success(int_0).to_lazy()
    if isinstance(lazy_0, Lazy) and lazy_0.computation() == int_0:
        print('test_Validation_to_lazy_0 ok')
    else:
        print('test_Validation_to_lazy_0 ERROR!')
        raise ValueError('test_Validation_to_lazy_0 ERROR!')

if __name__ == '__main__':
    #test_case_0()

    test_Validation_to_lazy()

# Generated at 2022-06-26 00:20:43.280084
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(int_0)
    lazy = success.to_lazy()
    assert lazy.value() == int_0


# Generated at 2022-06-26 00:20:52.979781
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Test case: 0 successful validation
    def test_case_0():
        int_0 = 1975
        validation_0 = Validation(int_0, [])
        lazy_0 = validation_0.to_lazy()
        assert lazy_0.evaluate() is int_0

    # Test case: 1 successful validation
    def test_case_1():
        int_0 = 1975
        validation_0 = Validation(int_0, [])
        lazy_0 = validation_0.to_lazy()
        assert lazy_0.evaluate() is int_0

    # Test case: 2 failed validation
    def test_case_2():
        string_0 = 'Boris'
        validation_0 = Validation(None, [string_0])
        lazy_0 = validation_0.to_lazy()
        assert lazy_

# Generated at 2022-06-26 00:20:53.853579
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy().get() == 1975



# Generated at 2022-06-26 00:20:55.520654
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success().to_lazy() == Lazy(lambda: None)

    assert (Validation.success(int_0).to_lazy() == Lazy(lambda: 1975))


# Generated at 2022-06-26 00:20:58.112587
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def int_0():  # noqa
        return 1975

    validation = Validation.success(int_0)

    assert validation.to_lazy() == Lazy(int_0)


# Generated at 2022-06-26 00:21:00.404774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success_test = Validation.success(int_0)
    assert (success_test.to_lazy().eval() == int_0)


# Generated at 2022-06-26 00:21:03.793631
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1975
    result = Validation.success(int_0).to_lazy()
    assert result.value() == int_0
    result = Validation.fail(['error']).to_lazy()
    assert result.value() is None


# Generated at 2022-06-26 00:21:04.343140
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass

# Generated at 2022-06-26 00:21:06.530124
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    m = Validation.success(int_0)
    result = m.to_lazy()
    assert result == Lazy(test_case_0)


# Generated at 2022-06-26 00:21:13.743466
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1861
    validation_0 = Validation.fail([str(int_0)])
    lazy_0 = validation_0.to_lazy()
    int_1 = -1861
    validation_1 = Validation.fail([str(int_1)])
    var_0 = validation_1.to_lazy()


# Generated at 2022-06-26 00:21:17.190335
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = -1995
    validation_0 = Validation(var_0, var_0)
    var_1 = validation_0.to_lazy()
    var_2 = var_1.is_success()
    assert var_2


# Generated at 2022-06-26 00:21:20.724233
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation.fail([int_0])
    var_0 = validation_0.to_lazy()
    var_1 = var_0.__call__()
    assert var_1 == None, "Result : %s" % var_1


# Generated at 2022-06-26 00:21:23.495570
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1745
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert var_0.value() == int_0



# Generated at 2022-06-26 00:21:26.942639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert (var_0.fn() == int_0)


# Generated at 2022-06-26 00:21:36.640910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import dot_assign
    from pymonet.monad_lazy import Lazy
    from pymonet.monad import monad

    var_0 = 1995.0
    int_0 = 1995
    validation_0 = Validation(int_0, int_0)
    lazy_0 = validation_0.to_lazy()
    validation_1 = lazy_0.to_validation()
    validation_2 = monad(lazy_0).bind(lambda var_0: Validation(var_0, var_0)).bind(lambda var_1: lazy_0)
    validation_3 = validation_2.bind(lambda var_0: Validation(var_0, var_0))

# Generated at 2022-06-26 00:21:39.920051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert var_0.immediate() == int_0


# Generated at 2022-06-26 00:21:49.420552
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test case for Validation's method to_lazy
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    from_try = Try(0)
    from_validation = Validation(0, 0)
    to_lazy_try = from_try.to_lazy()
    to_lazy_validation = from_validation.to_lazy()
    to_try_try = to_lazy_try.to_try()
    to_try_validation = to_lazy_validation.to_try()

    assert isinstance(to_lazy_try, Lazy)
    assert isinstance(to_lazy_validation, Lazy)
    assert isinstance(to_try_try, Try)

# Generated at 2022-06-26 00:21:51.875765
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:21:56.226348
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('')
    validation_0 = Validation(1, []).to_lazy()
    print(validation_0)
    validation_1 = Validation(None, ['error']).to_lazy()
    print(validation_1)
    assert validation_0.eval() == 1
    assert validation_1.eval() == None


# Generated at 2022-06-26 00:22:09.018774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.either import Either
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation
    from pymonet.funcs import compose
    from pymonet.utils import assert_equals
    from operator import add
    # Intentionally non-lazy calc
    def multiply(a, b):
        return a * b
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert_equals(var_0, Lazy(lambda: -1995))
    int

# Generated at 2022-06-26 00:22:10.721745
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(1, 1)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:22:12.661615
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_1 = Validation(42, [])
    try_3 = validation_1.to_lazy()


# Generated at 2022-06-26 00:22:13.508330
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()



# Generated at 2022-06-26 00:22:22.692035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_1 = -519
    validation_1 = Validation(int_1, True)
    validation_2 = Validation(-int_1, [int_1])
    validation_3 = Validation(int_1, [])
    validation_4 = Validation(-int_1, [int_1, -int_1])
    validation_5 = Validation(int_1, [])
    validation_6 = Validation(-int_1, [int_1, -int_1])
    validation_7 = Validation(int_1, True)

    assert validation_2.to_lazy() == Lazy(lambda: -int_1), 'test_Validation_to_lazy: 4'

# Generated at 2022-06-26 00:22:30.216794
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = Variable(0)
    var_1 = Variable(1)
    var_2 = Variable(0)
    var_3 = Variable(var_1.data)
    var_4 = Variable(var_2.data)
    var_5 = Variable(var_3.data)
    var_6 = Variable(var_4.data)
    var_7 = Variable(var_5.data)
    var_8 = Variable(var_6.data)
    var_9 = Variable(var_7.data)
    var_10 = Variable(var_8.data)
    var_11 = Variable(var_9.data)
    var_12 = Variable(var_10.data)
    var_13 = Variable(var_11.data)
    var_14 = Variable(var_12.data)
   

# Generated at 2022-06-26 00:22:40.434745
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_1 = 1
    errors = []
    validation_1 = Validation(int_1, errors)
    # this line triggers __str__ method
    to_lazy_result_1 = validation_1.to_lazy()
    assert isinstance(to_lazy_result_1, Lazy)
    assert to_lazy_result_1.run() == int_1

    validation_2 = Validation.fail(errors)
    to_lazy_result_2 = validation_2.to_lazy()
    assert isinstance(to_lazy_result_2, Lazy)
    assert to_lazy_result_2.run() is None



# Generated at 2022-06-26 00:22:54.225180
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # CASE 1: value is None and errors is [].
    # EXPECTED behavior: lazy with function returning None
    value_0 = None
    errors_0 = []
    validation_0 = Validation(value_0, errors_0)
    var_0 = validation_0.to_lazy()
    assert isinstance(var_0, Lazy)
    assert callable(var_0.value)
    assert var_0.value() is None
    # CASE 1: value is None and errors is [1, 2, 3].
    # EXPECTED behavior: lazy with function returning None
    value_0 = None
    errors_0 = [1, 2, 3]
    validation_0 = Validation(value_0, errors_0)

# Generated at 2022-06-26 00:22:54.995361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert test_case_0() == None


# Generated at 2022-06-26 00:22:58.285442
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:09.453389
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('Test #2 has been started')
    test_case_0()
    print('Test #2 has been passed')


if __name__ == '__main__':
    test_Validation_to_lazy()

# Generated at 2022-06-26 00:23:10.265973
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()


# Generated at 2022-06-26 00:23:13.845577
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # AssertionError
    try:
        # Execution of method
        test_case_0()
    except AssertionError as e:
        # Entrance in exception
        assert True
    else:
        # No exception (fail)
        assert False

# Generated at 2022-06-26 00:23:14.682887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert test_case_0()



# Generated at 2022-06-26 00:23:18.975194
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    var_1 = validation_0.to_lazy()
    expected = False
    actual = var_0 == var_1
    assert expected == actual, 'Expected value: {} but actual value: {}'.format(expected, actual)


# Generated at 2022-06-26 00:23:24.529125
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    text = 'abc'
    validation_0 = Validation(text, text.upper())
    var_0 = validation_0.to_lazy()
    var_1 = var_0.is_instance_of_Lazy()
    assert var_1 == True
    var_2 = var_0.get().get_value()
    assert var_2 == text
    var_3 = var_0.get().get_monad_error()
    assert var_3 == text.upper()


# Generated at 2022-06-26 00:23:27.575848
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    import random

    value = Lazy(lambda: random.uniform(1, 100))

    assert value == Validation(value, 0).to_lazy()


# Generated at 2022-06-26 00:23:29.554790
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert repr(test_case_0()) == '<function test_case_0.<locals>.<lambda> at 0x7f028c07b7b8>'


# Generated at 2022-06-26 00:23:31.612731
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:34.859168
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert (isinstance(var_0, Lazy.__class__))
    assert (var_0.get() == int_0)


# Generated at 2022-06-26 00:23:59.422021
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, [])
    var_0 = validation_0.to_lazy()
    var_1 = validation_0.to_lazy()
    var_2 = validation_0.to_lazy()
    var_3 = var_1.get()
    var_4 = var_0.get()
    var_5 = var_2.get()
    assert var_4 == -1995
    assert var_5 == -1995
    assert var_3 == -1995
    assert validation_0.is_success()


# Generated at 2022-06-26 00:24:05.856498
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    var_1 = validation_0.to_maybe()
    var_2 = var_0.to_maybe()
    var_3 = validation_0.to_box()
    var_4 = var_0.to_box()
    var_5 = validation_0.to_either()
    var_6 = var_0.to_either()
    var_7 = validation_0.to_try()
    var_8 = var_0.to_try()
    var_9 = validation_0.ap(lambda x: validation_0)
    int_1 = -5
    validation_1 = Validation(int_1, int_1)
    int_

# Generated at 2022-06-26 00:24:06.797176
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()



# Generated at 2022-06-26 00:24:11.254607
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    var_0.compute()
    assert var_0.value == -1995, """Assertion error. Wrong value for Lazy"""


# Generated at 2022-06-26 00:24:14.542490
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1492
    validation_0 = Validation(int_0, int_0)
    from pymonet.lazy import Lazy

    assert validation_0.to_lazy() == Lazy(lambda: -1492)



# Generated at 2022-06-26 00:24:16.632569
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:24:18.371400
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    x = Validation.success(1)
    y = x.to_lazy()
    z = y()
    assert z == 1


# Generated at 2022-06-26 00:24:26.243705
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # test with int
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert isinstance(var_0, Lazy)

    # test with string
    str_0 = 'qwerty'
    validation_1 = Validation(str_0, str_0)
    var_1 = validation_1.to_lazy()
    assert isinstance(var_1, Lazy)

    # test with class instance
    int_1 = 8
    str_1 = 'qwerty'
    test_class_0 = TestClass(int_1, str_1)
    validation_2 = Validation(test_class_0, test_class_0)
   

# Generated at 2022-06-26 00:24:28.841399
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation.success(int_0)
    var_0 = validation_0.to_lazy()
    assert var_0.value_or_default(None) == int_0


# Generated at 2022-06-26 00:24:36.562821
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, [])
    var_0 = validation_0.to_lazy()
    assert Lazy(lambda: int_0).equals(var_0)

    validation_1 = Validation(int_0, [int_0])
    var_1 = validation_1.to_lazy()
    assert Lazy(lambda: int_0).equals(var_1)

    validation_2 = Validation(int_0, [])
    var_2 = validation_2.to_lazy()
    assert Lazy(lambda: int_0).equals(var_2)

    validation_3 = Validation(int_0, [int_0])
    var_3 = validation_3.to_lazy()

# Generated at 2022-06-26 00:25:21.934390
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1996
    int_1 = 0
    int_2 = 1995
    validation_0 = Validation(int_0, int_0).to_lazy()
    validation_1 = Validation(int_1, int_1).to_lazy()
    validation_2 = Validation(int_2, int_2).to_lazy()
    assert validation_0.get() == int_0
    assert validation_1.get() == int_1
    assert validation_2.get() == int_2


# Generated at 2022-06-26 00:25:28.334064
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    result = validation_0.to_lazy()

    assert(result == Lazy(lambda: int_0))


# Generated at 2022-06-26 00:25:32.071584
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    try:
        validation_0.to_lazy()
    except AssertionError as e:
        print('AssertionError raised: {}'.format(e))


# Generated at 2022-06-26 00:25:39.295035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0_0 = (805 * -1791) + (726 * -383)
    int_0 = -1995
    validation_0 = Validation(int_0_0, int_0_0)
    validation_0 = validation_0.to_lazy()
    assert None is not validation_0
    lazy_0 = validation_0
    list_0_0 = [1559, -608, -1244, -1733, -3734]
    int_0 = -1995
    validation_0 = Validation(list_0_0, list_0_0)
    validation_0 = validation_0.to_lazy()
    lazy_0 = validation_0
    float_0 = (-(-897.54) + 1894.34) - (958.9 - (-169.57))
    float_

# Generated at 2022-06-26 00:25:41.328969
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:44.378350
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -9182
    validation_0 = Validation(int_0, [])
    lazy_0 = validation_0.to_lazy()
    int_1 = lazy_0.map(lambda int_2: int_2 * 2).force()
    assert int_1 == -9182 * 2


# Generated at 2022-06-26 00:25:50.203103
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert type(var_0) == Lazy


# Generated at 2022-06-26 00:25:52.998003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_191 = 1236
    validation_191 = Validation(int_191, int_191)
    var_191 = validation_191.to_lazy()
    assert isinstance(var_191, Lazy)



# Generated at 2022-06-26 00:25:53.798407
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()

# Generated at 2022-06-26 00:25:56.753874
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert var_0.get() == int_0


# Generated at 2022-06-26 00:27:36.302782
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    validation_0 = Validation.success(int_0)
    validation_1 = Validation.fail(int_1)

    assert validation_0.value == int_0
    assert validation_0.errors == []

    assert validation_1.value is None
    assert validation_1.errors == int_1

    var_0 = validation_0.to_lazy()
    var_1 = validation_1.to_lazy()

    assert var_0.get() == int_0
    assert var_1.get() is None


# Generated at 2022-06-26 00:27:40.407500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(1, [])
    validation_1 = Validation(None, [1])

    assert validation_0.to_lazy().get() == 1
    assert validation_0.to_lazy().is_success() is True
    assert validation_1.to_lazy().is_fail() is True



# Generated at 2022-06-26 00:27:41.370745
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('# Unit test for method to_lazy of class Validation')

    test_case_0()

# Generated at 2022-06-26 00:27:44.422238
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # GIVEN.
    from pymonet.lazy import Lazy
    from random import randint

    # WHEN.
    int_0 = randint(1, 9)
    validation_0 = Validation(int_0, [])
    var_0 = validation_0.to_lazy()

    # THEN.
    expected = Lazy(lambda: int_0)
    assert var_0 == expected


# Generated at 2022-06-26 00:27:45.209506
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert test_case_0() == 0

# Generated at 2022-06-26 00:27:50.289831
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    assert var_0.__value() == int_0


# Generated at 2022-06-26 00:27:53.275816
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()
    print(var_0)
    print(var_0.value.eval())


# Generated at 2022-06-26 00:27:57.366437
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = Validation.fail()
    var_1 = Validation.success('a')
    var_2 = Validation.fail('a')
    var_3 = Validation.success(1)
    var_4 = Validation.fail(1)


# Generated at 2022-06-26 00:28:08.160192
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.fail()
    validation_1 = Validation.fail(["Testing error"])
    validation_2 = Validation.success()
    validation_3 = Validation.success(1)
    validation_4 = Validation.success(None)

    result_0 = validation_0.to_lazy()
    result_1 = validation_1.to_lazy()
    result_2 = validation_2.to_lazy()
    result_3 = validation_3.to_lazy()
    result_4 = validation_4.to_lazy()

    assert isinstance(result_0, Lazy)
    assert isinstance(result_1, Lazy)
    assert isinstance(result_2, Lazy)
    assert isinstance(result_3, Lazy)

# Generated at 2022-06-26 00:28:10.726603
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -1995
    validation_0 = Validation(int_0, int_0)
    var_0 = validation_0.to_lazy()

