

# Generated at 2022-06-26 00:18:31.541350
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    int_0 = -812
    bytes_0 = b'\xe6\xb6Qh\xfd\xb4\xe5'
    validation_0 = Validation(int_0, bytes_0)
    maybe_0 = validation_0.to_maybe()
    maybe_1 = maybe_0.get_value()

    assert(maybe_1 == int_0)


# Generated at 2022-06-26 00:18:37.732111
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    string0 = "I am string"
    maybe0 = Validation.success(string0)
    maybe1 = Validation.success()
    empty_list0 = []
    maybe2 = Validation.fail(empty_list0)
    maybe3 = Validation.fail()

    assert maybe0.to_maybe().value == string0
    assert maybe1.to_maybe().value is None
    assert maybe2.to_maybe().value is None
    assert maybe3.to_maybe().value is None



# Generated at 2022-06-26 00:18:41.902808
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    validation_0 = Validation.success(0)
    lazy_0 = validation_0.to_lazy()

    assert not lazy_0.thrown
    assert lazy_0.value == 0
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-26 00:18:54.467757
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    int_0 = -812
    bytes_0 = b'\xe6\xb6Qh\xfd\xb4\xe5'
    validation_0 = Validation(int_0, bytes_0)
    maybe_2 = validation_0.to_maybe()
    maybe_3 = maybe_2.to_list()
    assert maybe_3 == [int_0]
    int_1 = -812
    validation_1 = Validation.success(int_1)
    maybe_5 = validation_1.to_maybe()
    maybe_6 = maybe_5.to_list()
    assert maybe_6 == [int_1]
    int_2 = -812
    validation_2 = Validation(int_2, [])
    maybe_8 = validation_2.to_maybe()

# Generated at 2022-06-26 00:18:55.356297
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()

# Generated at 2022-06-26 00:19:02.694202
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    int_0 = 10
    validation_0 = Validation(int_0, [])
    lazy_0 = validation_0.to_lazy()

    assert lazy_0 == Lazy(lambda: int_0)
    assert lazy_0.value() == int_0


# Generated at 2022-06-26 00:19:06.880101
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = -812
    bytes_0 = b'\xe6\xb6Qh\xfd\xb4\xe5'
    validation_0 = Validation(int_0, bytes_0)

    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == int_0


# Generated at 2022-06-26 00:19:11.045506
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    int_0 = -812
    bytes_0 = b'\xe6\xb6Qh\xfd\xb4\xe5'
    validation_0 = Validation(int_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:19:19.235914
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    int_0 = -812
    bytes_0 = b'\xe6\xb6Qh\xfd\xb4\xe5'
    validation_0 = Validation(int_0, bytes_0)
    maybe = validation_0.to_maybe()
    assert isinstance(maybe, Maybe)
    assert isinstance(maybe.value, int)
    assert maybe.value == int_0


# Generated at 2022-06-26 00:19:22.684837
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(10, []).to_maybe() == Maybe.just(10)
    assert Validation(10, [1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-26 00:19:32.924189
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try, raise_

    # Success case
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    # Success case with None value
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)

    # Fail case for None
    assert Validation.fail().to_lazy() == Lazy(lambda: None)

    # Fail case for errors
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)

    # Fail case for nested Lazy
    assert Validation.fail([Lazy(lambda: 1)]).to_lazy() == Lazy(lambda: None)

    # Fail case for Try

# Generated at 2022-06-26 00:19:40.408469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda: 5)
    lazy_1 = lazy_0.map(lambda mapper: mapper())

    validation_0 = Validation.success(5)
    validation_1 = validation_0.to_lazy()
    assert lazy_1 == validation_1


# Generated at 2022-06-26 00:19:44.525181
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    list_errors = []
    validation = Validation(int_0, list_errors)

    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:19:47.982045
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success_validation = Validation.success(5)
    assert success_validation.to_lazy().value() == 5

    fail_validation = Validation.fail([0])
    assert fail_validation.to_lazy().value() is None



# Generated at 2022-06-26 00:19:52.253962
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Case for Validation.success[0]
    assert Validation.success(int_0).to_lazy() == Lazy(lambda: 0)
    # Case for Validation.fail[0]
    assert Validation.fail(int_0).to_lazy() == Lazy(lambda: 0)



# Generated at 2022-06-26 00:19:55.050642
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-26 00:19:58.740921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_object = Validation.fail(['error'])
    assert test_object.to_lazy().get() == None
    test_object = Validation.success(1)
    assert test_object.to_lazy().get() == 1


# Generated at 2022-06-26 00:20:03.114874
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = Validation(0, [])
    assert int_0.to_lazy() == Lazy(lambda: 0)
    int_2 = Validation(2, [])
    assert int_2.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-26 00:20:04.711661
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    TestCaseValidation.case_0()
    TestCaseValidation.case_1()


# Generated at 2022-06-26 00:20:07.298481
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-26 00:20:17.827659
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(0, None)
    assert validation_0.to_lazy() == Lazy(lambda: 0)

    int_0 = 0
    validation_1 = Validation(int_0, [0])
    assert validation_1.to_lazy() == Lazy(lambda: 0)

    validation_2 = Validation(2, None)
    assert validation_2.to_lazy() == Lazy(lambda: 2)

    int_2 = 2
    validation_3 = Validation(int_2, [2])
    assert validation_3.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-26 00:20:26.971018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_int_0_success = Validation.success(int_0)
    validation_int_0_fail = Validation.fail()
    if not isinstance(validation_int_0_success.to_lazy(), Lazy):
        raise TypeError('Validation.to_lazy() failed on Validation.success')
    if not isinstance(validation_int_0_fail.to_lazy(), Lazy):
        raise TypeError('Validation.to_lazy() failed on Validation.fail')
    if validation_int_0_success.to_lazy().get_value() != int_0:
        raise ValueError('Validation.to_lazy() failed on Validation.success')

# Generated at 2022-06-26 00:20:31.268921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail().to_lazy().value() == None

    try:
        Validation.fail().to_lazy().get()
        assert False
    except NoneValueError:
        pass


# Generated at 2022-06-26 00:20:34.763731
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v1 = Validation.success(int_0)
    l1 = v1.to_lazy()
    assert isinstance(l1, Lazy)
    assert int_0 == l1.force()


# Generated at 2022-06-26 00:20:46.387567
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    Lazy = test_case_0()
    int_0 = 0
    int_1 = 1
    value = int_0
    validation_success = Validation.success(value)
    validation_fail = Validation.fail(value)
    assert validation_success.to_lazy() == Lazy(lambda: int_0)
    assert validation_fail.to_lazy() == Lazy(lambda: int_0)
    assert validation_success.to_lazy().value() == int_0
    assert validation_fail.to_lazy().value() == int_0
    assert validation_success.to_lazy().value() != int_1
    assert validation_fail.to_lazy().value() != int_1


# Generated at 2022-06-26 00:20:49.942687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # testing positive case
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.eval() is int_0
    assert lazy_0.is_success() is True


# Generated at 2022-06-26 00:20:52.748470
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(42).to_lazy()
    assert result.value() is 42

    result = Validation.fail(42).to_lazy()
    assert result.error is 42


# Generated at 2022-06-26 00:20:58.437294
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import lazy

    val1 = Validation.success(int_0).to_lazy()
    val2 = Validation.fail().to_lazy()

    assert isinstance(val1, Lazy)
    assert isinstance(val2, Lazy)

    assert val1.get() == int_0
    assert val2.get() is None

    with pytest.raises(AttributeError) as ex:
        val1.get().get() == int_0


# Generated at 2022-06-26 00:21:00.618113
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy()
    assert Validation.success(0).to_lazy().evaluate() == 0


# Generated at 2022-06-26 00:21:06.333989
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Validate successful Validation
    success_validation = Validation.success(int_0)

    assert isinstance(success_validation.to_lazy(), Lazy)
    assert int_0 == success_validation.to_lazy().value()

    # Validate failed Validation
    fail_validation = Validation.fail()

    assert isinstance(fail_validation.to_lazy(), Lazy)
    assert fail_validation.to_lazy().value() is None


# Generated at 2022-06-26 00:21:15.640571
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    vL = Validation.success(100)
    vF = Validation.fail([])
    null = Validation.success(None)
    # When
    resL = vL.to_lazy()
    resF = vF.to_lazy()
    resN = null.to_lazy()
    # Then
    assert resL.value() == 100
    assert resF.value() is None
    assert resN.value() is None


# Generated at 2022-06-26 00:21:18.629947
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    args = {'value': 0, 'errors': []}
    result = Validation(**args).to_lazy()
    expected = {'value': 0, '_error': None, '_is_success': True}

    assert result == expected

# Generated at 2022-06-26 00:21:19.635119
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Asserts lazy result of Validation.success(0) is 0
    """

    assert Validation.success(0).to_lazy().get() == 0


# Generated at 2022-06-26 00:21:21.181308
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(10)

    assert validation.to_lazy() == Lazy(lambda: 10)

    validation_1 = Validation.fail(['error'])

    assert validation_1.to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-26 00:21:23.621961
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    validation_0 = Validation.success(1)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == 1



# Generated at 2022-06-26 00:21:28.255994
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v1 = Validation.success('value')
    v2 = Validation.fail('error')

    assert v1.to_lazy() == Lazy(lambda: 'value')
    assert v2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:32.363272
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from assertpy import assert_that

    Validation.success(0).to_lazy() |should| equal_to(Lazy(lambda: 0))
    Validation.fail(0).to_lazy() |should| equal_to(Lazy(lambda: 0))


# Generated at 2022-06-26 00:21:34.952679
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy().value() == 0
    assert Validation.fail([1]).to_lazy().value() == None



# Generated at 2022-06-26 00:21:38.774072
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(int_0).to_lazy() == Lazy(int_0)


# Generated at 2022-06-26 00:21:41.232213
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = 'test value'
    validation = Validation.success(value)

    assert validation.to_lazy() == Lazy(lambda: 'test value')


# Generated at 2022-06-26 00:21:53.587297
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    int_0 = 0
    int_1 = 1
    validation_success = Validation.success(int_0)
    validation_failure = Validation.fail([int_1])
    assert validation_failure.to_lazy() == Lazy(lambda: int_0)
    assert validation_success.to_lazy() == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:21:58.964012
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    lazy_1 = validation.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.run() == 1

    validation = Validation.fail()
    lazy_2 = validation.to_lazy()
    assert isinstance(lazy_2, Lazy)
    assert lazy_2.run() == None


# Generated at 2022-06-26 00:22:02.461898
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_0 = Validation.success(int_0).to_lazy()
    assert lazy_0.evaluate() == 0
    assert lazy_0.evaluate() == 0

    lazy_1 = Validation.fail(int_0).to_lazy()
    assert lazy_1.evaluate() is None



# Generated at 2022-06-26 00:22:04.763500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-26 00:22:12.915444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Either
    from pymonet.monad_try import Try
    import math

    v1 = Validation.success()
    v2 = Validation.success(5)
    v3 = Validation.success([1, 2, 3])
    v4 = Validation.success(5.5)
    v5 = Validation.success('test')
    v6 = Validation.success(math)
    v7 = Validation.success(Box(5))
    v8 = Validation.success(Maybe.just(5))
    v9 = Validation.success(Either.right(5))
    v10 = Validation.success(Try.success(5))

    l

# Generated at 2022-06-26 00:22:16.009740
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = Validation.success(0).to_lazy()

    validate_int_0 = int_0.evaluate()

    assert validate_int_0 == 0
    assert isinstance(validate_int_0, int)


# Generated at 2022-06-26 00:22:19.608936
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success(0)

    assert v.value == 0
    assert v.to_lazy() == Lazy(lambda: 0)

    v2 = Validation.fail([0])

    assert v2.value == None
    assert v2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:22.559175
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Arrange
    validation = Validation.success(10)

    # Act
    result = validation.to_lazy()

    # Assert
    assert result.value() == 10

# Generated at 2022-06-26 00:22:25.383444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:30.273488
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    int_1 = 1
    int_2 = 2

    assert Validation.success(int_0).to_lazy() == Lazy(lambda: int_0)
    assert Validation.success(int_2).to_lazy() == Lazy(lambda: int_2)

    try:
        Validation.fail().to_lazy()
        assert False
    except ValueError as err:
        assert err.message == 'cannot be lazy'


# Generated at 2022-06-26 00:22:45.243274
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import bind
    from pymonet.functor import map
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    def test_f():
        int_0 = 0
        return int_0

    res = validate(test_f)

    assert isinstance(res, Validation)
    assert not res.is_success()
    assert res.errors[0] == 'Division by 0'
    assert res.value == 0

    res1 = res.to_lazy()

    assert isinstance(res1, Lazy)

    res2 = res1.get_value()

    assert isinstance(res2, Validation)
    assert not res2.is_success()
    assert res2.errors[0] == 'Division by 0'

# Generated at 2022-06-26 00:22:48.511531
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    validation = Validation.success(int_0)
    assert validation.to_lazy() == Lazy(lambda: int_0)

# Generated at 2022-06-26 00:22:51.341749
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    e1 = Validation(2, [])
    e2 = e1.to_lazy()
    assert e2.value() == 2


# Generated at 2022-06-26 00:22:55.756932
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    for t in range(-5, 5):
        for n in range(0, 3):
            val_0 = Validation.success(t)
            val_1 = Validation.success(n)
            assert val_0.to_lazy() == val_1.to_lazy()


# Generated at 2022-06-26 00:23:04.396067
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import monad
    from pymonet.monad_try import Try
    from pymonet.cont import Cont
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    # GIVEN
    # when Validation is successful
    validation = Validation.success([1, 2])

    # WHEN
    result = validation.to_lazy()

    # THEN
    # lazy should be Lazy
    assert monad(result)

    # Calling inner function should return previous value
    assert result.run() == [1, 2]
    assert result.run() == [1, 2]


# Generated at 2022-06-26 00:23:07.814116
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(["1", "2"]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:10.794750
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('foo')
    lazy = validation.to_lazy()
    assert lazy.run() == 'foo'
    assert lazy.run() == 'foo'
    assert validation == Validation.success('foo')


# Generated at 2022-06-26 00:23:14.175884
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = Validation.success(0).to_lazy()
    print(int_0())
    int_100 = Validation.success(100).to_lazy()
    print(int_100())


# Generated at 2022-06-26 00:23:18.748412
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    int_1 = 1
    validation = Validation(int_0, [])
    lazy_value = validation.to_lazy()
    assert isinstance(lazy_value, Lazy)
    lazy_function = lazy_value.value
    assert isinstance(lazy_function, FunctionType)
    assert lazy_function() == int_0


# Generated at 2022-06-26 00:23:23.436730
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Right, Left

    v_either_right = Right('test')
    v_either_left = Left('test')
    v_either_right_lazy = v_either_right.to_lazy()
    v_either_left_lazy = v_either_left.to_lazy()

    assert v_either_right_lazy() == 'test'
    assert v_either_left_lazy() == 'test'


# Generated at 2022-06-26 00:23:33.823766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = Lazy(lambda: int_0)

    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:23:35.819758
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(1)
    assert Validation.fail([]).to_lazy() == Lazy(None)


# Generated at 2022-06-26 00:23:45.167013
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    import unittest

    class Validation_to_lazy_Test(unittest.TestCase):
        def test_case_0(self):
            int_0 = 0
            validation = Validation.success(int_0)
            actual = validation.to_lazy()
            expected = Lazy(lambda: int_0)
            self.assertEqual(actual, expected, "Expected {}, but got {}".format(expected, actual))
        def test_case_1(self):
            int_0 = 0
            validation = Validation.fail([int_0])
            actual = validation.to_lazy()
            expected = Lazy(lambda: None)

# Generated at 2022-06-26 00:23:47.749987
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    for index in xrange(1000):
        validation = Validation(lambda x: x, [])
        lazy = validation.to_lazy()
        assert lazy.value()(True) is True


# Generated at 2022-06-26 00:23:55.020984
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Testing case when value is None
    validation_0 = Validation.fail(['error 1'])
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.eval() == None
    assert validation_0.to_lazy() is lazy_0
    # Testing case when value is not None
    int_0 = 1
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.eval() == int_0
    assert validation_0.to_lazy() is lazy_0


# Generated at 2022-06-26 00:23:57.752774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()

    validation = Validation.success(int_0)
    lazy_monad = validation.to_lazy()

    assert lazy_monad.value == int_0



# Generated at 2022-06-26 00:24:02.085639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_success = Validation.success(1).to_lazy()
    assert isinstance(lazy_success, Lazy)
    assert lazy_success.get() == 1

    lazy_fail = Validation.fail(None).to_lazy()
    assert isinstance(lazy_fail, Lazy)
    assert lazy_fail.get() is None


# Generated at 2022-06-26 00:24:03.900936
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_success = Validation.success(int_0)
    lazy = validation_success.to_lazy()
    assert lazy.value == 0


# Generated at 2022-06-26 00:24:10.513119
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_success = Validation.success('done')
    lazy = validation_success.to_lazy()
    assert lazy.value == 'done'
    assert isinstance(lazy, Lazy)
    assert lazy.is_memoized is False

    validation_failure = Validation.fail(['error 0', 'error 1'])
    lazy = validation_failure.to_lazy()
    assert lazy.value == None
    assert isinstance(lazy, Lazy)
    assert lazy.is_memoized is False


# Generated at 2022-06-26 00:24:16.890153
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('\nUnit test for Validation.to_lazy')
    int_0 = 0
    int_1 = 1

    def validation_function_0():
        return Validation.success(int_0)

    def validation_function_1():
        return Validation.fail()

    lazy_validation_0 = validation_function_0().to_lazy()
    lazy_validation_1 = validation_function_1().to_lazy()

    assert lazy_validation_0.value() == int_0
    assert lazy_validation_1.value() is None


# Generated at 2022-06-26 00:24:32.938278
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result_0 = Validation.success().to_lazy()
    assert isinstance(result_0, type(Lazy(test_case_0)))
    assert int(result_0.value()) == 0


# Generated at 2022-06-26 00:24:35.323122
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:24:38.285198
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()

    assert Lazy(lambda: None) == Validation.fail(2).to_lazy()


# Generated at 2022-06-26 00:24:40.948022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(0)
    lazy_monad_0 = validation_0.to_lazy()
    test_case_0()
    assert lazy_monad_0.get() == 0


# Generated at 2022-06-26 00:24:45.747225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    validation = Validation.success(0)
    validation_with_fail = Validation.fail([1, 2])

    # When
    lazy_validation = validation.to_lazy()
    lazy_validation_with_fail = validation_with_fail.to_lazy()

    # Then
    assert lazy_validation.run() == 0
    assert lazy_validation_with_fail.run() is None

# Case test for method to_lazy of class Validation

# Generated at 2022-06-26 00:24:49.413671
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # test 1
    v = Validation.success(0)
    assert v.to_lazy() == Lazy(lambda: 0)

    # test 2
    v = Validation.fail(['No value'])
    assert v.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:24:52.931908
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_case_0():
        a = Validation.success("A")
        b = Lazy(lambda: "A")
        assert a.to_lazy() == b

    test_case_0()


# Generated at 2022-06-26 00:24:55.678334
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    res = Validation.success(1).to_lazy()
    res_expr = 'Lazy[<function Validation.success.<locals>..<lambda> at 0x000001B072E2AC80>]'
    assert repr(res) == res_expr


# Generated at 2022-06-26 00:24:58.182102
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    random_errors = ['error1', 'error2']
    validation = Validation(0, random_errors)
    validation_lazy = validation.to_lazy()
    assert validation_lazy.force() == validation.value


# Generated at 2022-06-26 00:25:04.370893
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v1 = Validation.success()
    v2 = Validation.success(2)
    v3 = Validation.fail(['error-1'])
    v4 = Validation.fail(['error-1', 'error-2', 'error-3'])

    from pymonet.lazy import Lazy

    assert v1.to_lazy() == Lazy(lambda: None)
    assert v2.to_lazy() == Lazy(lambda: 2)
    assert v3.to_lazy() == Lazy(lambda: None)
    assert v4.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:25:38.889664
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Validation.fail(List[String]) -> Lazy[Function() -> None]
    assert Validation.fail(['test']).to_lazy() == Lazy(lambda: None)
    # Validation.success(1) -> Lazy[Function() -> Integer]
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    # Validation.success(2.0) -> Lazy[Function() -> Float]
    assert Validation.success(2.0).to_lazy() == Lazy(lambda: 2.0)
    # Validation.success(True) -> Lazy[Function() -> Boolean]

# Generated at 2022-06-26 00:25:43.623291
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy method.
    """

    validation = Validation.success(5)
    lazy = validation.to_lazy()

    assert lazy.obj() == 5

if __name__ == "__main__":
    import unittest

    suite = unittest.TestLoader().loadTestsFromTestCase(test_case_0)
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-26 00:25:49.017737
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value == int_0



# Generated at 2022-06-26 00:25:52.476422
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    test_lazy = Lazy(test_case_0)
    test_validation = Validation.success(test_lazy)
    assert test_validation.to_lazy() == test_lazy and test_validation.errors == []


# Generated at 2022-06-26 00:25:55.069079
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    v_0 = Validation.success(10)
    assert v_0.to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-26 00:26:00.499271
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy

    test_cases = [
        {
            'description': 'Valid value',
            'class_arguments': (5, []),
            'to_lazy': Lazy(lambda: 5),
        },
        {
            'description': 'Invalid value',
            'class_arguments': (None, ['error']),
            'to_lazy': Lazy(lambda: None),
        },
    ]

    for test_case in test_cases:
        result = Validation(*test_case['class_arguments']).to_lazy()
        assert result == test_case['to_lazy'], \
            'Validation.to_lazy test failed for test case: {}'.format(test_case)


# Generated at 2022-06-26 00:26:08.433436
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    tests = [
        ({'value': 0, 'errors': []},
         Validation(0, []),
         'Validation.success[0]',
         Validation.success,
         1),
        ({'value': 0, 'errors': [1,2,3]},
         Validation(0, [1,2,3]),
         'Validation.fail[0, [1, 2, 3]]',
         Validation.fail,
         4),
    ]

    for test in tests:
        args = test[0]
        expectation = test[1]
        expectation_string = test[2]
        validation_constructor = test[3]
        test_case_id = test[4]

        validation = validation_constructor(args['value'], args['errors'])
        assert validation

# Generated at 2022-06-26 00:26:12.174443
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success(int_0).to_lazy()
    assert isinstance(result, Lazy)

    result_value = result.evaluate()
    assert result_value == int_0


# Generated at 2022-06-26 00:26:17.716267
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_case_0():
        int_0 = 0

    value_0 = Validation.success(int_0)
    result = value_0.to_lazy()

    assert(isinstance(result, Lazy))

    try_value = result.get()
    assert(isinstance(try_value, Try))
    assert(try_value.is_success())
    assert(try_value.value == int_0)


# Generated at 2022-06-26 00:26:22.230264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # -- Unit test preparation
    gen_0 = Validation.success(int_0)

    # -- Unit test execution
    gen_1 = gen_0.to_lazy()

    # -- Unit test assertions
    assert gen_1 == Lazy(lambda: int_0), \
        "Validation.to_lazy() when Validation.is_success() should return Lazy(lambda: int_0)"


# Generated at 2022-06-26 00:27:41.059584
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    try_: Try[int] = Try.success(10)
    box: Box[int] = Box(10)
    lazy_: Lazy[int] = Lazy(lambda: 10)

    assert try_.to_lazy() == Lazy(lambda: try_.get())
    assert box.to_lazy() == Lazy(lambda: box.get())
    assert lazy_.to_lazy() == lazy_

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.success(10).to_lazy().get() == 10
    assert Validation.success(10).to_lazy().is_computed() is False


# Generated at 2022-06-26 00:27:43.281029
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 0) == Validation.success(0).to_lazy()
    assert Lazy(lambda: int_0) == Validation.success(int_0).to_lazy()



# Generated at 2022-06-26 00:27:44.653828
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(int_0)
    lazy = validation.to_lazy()
    assert lazy.val() == int_0


# Generated at 2022-06-26 00:27:48.039265
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    from pymonet.validation import Validation

    int_0 = 0

    validation = Validation(int_0, [])

    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy() == int_0

# Generated at 2022-06-26 00:27:53.538658
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Given function:
        def some_function(int):
            return Validation.success(int)
    When passing argument to some_function method and storing it in lazy
        lazy = some_function(0).to_lazy()
    Then value in lazy is return value from some_function method
    """
    def some_function(int):
        return Validation.success(int)
    lazy = some_function(0).to_lazy()
    assert lazy == Lazy(lambda: 0)


# Generated at 2022-06-26 00:27:57.365929
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(int_0)
    assert val.to_lazy().force() == int_0

    val = Validation.fail()
    assert val.to_lazy().force() == None


# Generated at 2022-06-26 00:28:08.130857
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    validation_0 = Validation.success(int_0)
    assert isinstance(validation_0, Validation)
    assert validation_0.is_success()
    assert int_0 == validation_0.value
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert int_0 == lazy_0.get()
    int_1 = 1
    lazy_1 = Lazy(lambda: int_1)
    validation_1 = Validation.success(lazy_1)
    assert isinstance(validation_1, Validation)
    assert validation_1.is_success()
    assert isinstance(validation_1.value, Lazy)
    assert lazy_1 == validation_1.value
    lazy_2 = validation_

# Generated at 2022-06-26 00:28:11.724533
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success(1)

    lazy = v.to_lazy()
    assert lazy.eval() == 1

    v = Validation.fail([])
    lazy = v.to_lazy()
    assert lazy.eval() is None


# Generated at 2022-06-26 00:28:16.899591
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(42).to_lazy().get() == 42
    assert Validation.fail(['error']).to_lazy().get() == None
    assert Validation.success(42).to_lazy().get() == Lazy(lambda: 42).get()
    assert Validation.fail(['error']).to_lazy().get() == Lazy(lambda: None).get()


# Generated at 2022-06-26 00:28:22.547707
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.test import self_test

    def check_Validation_to_lazy(value, expected_result):
        lazy_monad = Validation.success(value).to_lazy()
        result = lazy_monad.get()
        self_test.assert_equals(result, expected_result)

    check_Validation_to_lazy(int_0, int_0)

    x = 2
    y = 3
    check_Validation_to_lazy((lambda: x+y), 5)
