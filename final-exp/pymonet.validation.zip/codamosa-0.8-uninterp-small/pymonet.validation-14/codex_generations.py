

# Generated at 2022-06-26 00:18:34.695113
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.implicits import str_to_Int
    test = Validation(Try(str_to_Int, is_fail=True), ['Test'])
    lazy = test.to_lazy()
    assert lazy.__eq__(Lazy(lambda: test.value))



# Generated at 2022-06-26 00:18:38.128370
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'g#*'
    str_1 = 'Box[value={}]'
    validation_0 = Validation(str_1, str_0)
    assert validation_0.to_lazy().eval() == 'Box[value={}]'


# Generated at 2022-06-26 00:18:41.902805
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    x = Validation.fail()
    y = Validation.success(2)
    sx = x.to_lazy()
    sy = y.to_lazy()
    assert sx.is_fail()
    assert sy.is_success()


# Generated at 2022-06-26 00:18:54.467063
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.either import Either

    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.to_lazy()
    assert isinstance(var_0, Lazy)

    try_0 = validation_0.to_try()
    assert isinstance(try_0, Try)
    assert try_0.is_success() == validation_0.is_success()

    either_0 = validation_0.to_either()


# Generated at 2022-06-26 00:18:58.140921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:03.478213
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    b_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:08.535855
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    str_2 = 'Lazy[Function() -> (A | None)]'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.__str__()
    assert var_0 == str_2


# Generated at 2022-06-26 00:19:21.533252
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success([])
    lazy_monad_1 = validation_0.to_lazy()
    success_0 = lazy_monad_1.is_success()
    assert_equals(success_0, True)
    lazy_monad_0 = validation_0.to_lazy()
    var_0 = lazy_monad_0.__class__
    assert_equals(var_0, Lazy)
    lazy_monad_2 = validation_0.to_lazy()
    var_1 = lazy_monad_2.is_fail()
    assert_equals(var_1, False)
    lazy_monad_3 = validation_0.to_lazy()

# Generated at 2022-06-26 00:19:30.800662
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import failure
    from pymonet.monad_maybe import maybe
    from pymonet.monad_maybe import nothing
    from pymonet.box import Box
    # Validation[String, String].to_lazy()
    val_0 = Validation.success('Box[value={}]').to_lazy()
    assert val_0 == Lazy(lambda: 'Box[value={}]')
    # Validation[Try[String], String].to_lazy()
    val_1 = Validation.success(Try.success('kZlv*~+')).to_lazy()

# Generated at 2022-06-26 00:19:40.218038
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    cases = [
        {
            'name': 'case 0',
            'input': Validation('Box[value={}]', 'kZlv*~+'),
            'expect': 'Lazy[function=<function Validation.to_lazy.<locals>.<lambda> at 0x7f5f5aa0c5f0>]'
        }
    ]
    for case in cases:
        actual = case['input'].to_lazy()
        assert case['expect'] == actual.__str__()


# Generated at 2022-06-26 00:19:52.527400
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()
    assert Lazy(lambda: 3).map(lambda x: x + 1) == Validation.success(2).to_lazy().map(lambda x: x + 1)
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()
    assert Lazy(lambda: 2).bind(lambda x: Lazy(lambda: x + 1)) == Validation.success(2).to_lazy().bind(lambda x: Lazy(lambda: x + 1))

# Generated at 2022-06-26 00:19:58.446639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(2)

    def test_case_0():
        lazy_0 = Lazy(lambda: validation_0.value)

        assert lazy_0.value() == validation_0.value

    def test_case_1():
        lazy_0 = validation_0.to_lazy()

        assert lazy_0.value() == validation_0.value

    test_case_0()
    test_case_1()


# Generated at 2022-06-26 00:20:02.441486
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_1 = Validation.success(int_0   )
    lazy_1       = validation_1.to_lazy()

    assert lazy_1.value == int_0 
    assert lazy_1()     == int_0 


# Generated at 2022-06-26 00:20:05.053110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(2, [])
    lazy_0 = validation_0.to_lazy()
    val_0 = lazy_0.get_value()
    assert val_0 == 2


# Generated at 2022-06-26 00:20:13.451530
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.tryy import Try

    # Test for successful Validation
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert(lazy.get() == 1)
    assert(lazy.is_lazy())
    assert(lazy.ap(lambda x: x + 1).get() == 2)
    assert(lazy.bind(lambda x: Lazy(lambda: x + 1)).get() == 2)
    assert(lazy.flat_map(lambda x: Lazy(lambda: x + 1)).get() == 2)
    assert(str(lazy) == 'Lazy')
    assert(lazy.to_box() == Box(1))

# Generated at 2022-06-26 00:20:14.328003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert test_case_0() == 2

# Generated at 2022-06-26 00:20:17.756129
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 2
    lazy_0 = Validation.success(int_0).to_lazy()
    int_1 = lazy_0.value()
    assert(int_1 == int_0)


# Generated at 2022-06-26 00:20:22.736619
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('Testing Validation.to_lazy')
    int_0 = 2
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.__class__.__name__ == 'Lazy'
    assert lazy_0.__value__.__name__ == '<lambda>'
    assert lazy_0.__value__() == 2


# Generated at 2022-06-26 00:20:32.633474
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    int_1 = 2

    list_0 = []

    validation_0 = Validation.fail([int_0])
    lazy_0 = validation_0.to_lazy()
    assert_true(lazy_0.is_memoized())
    assert_true(lazy_0.is_forced())
    assert_equal(None, lazy_0.get())
    lazy_1 = validation_0.to_lazy()
    assert_true(lazy_0 is lazy_1)

    validation_1 = Validation.success([int_0])
    lazy_2 = validation_1.to_lazy()
    assert_true(lazy_2.is_memoized())
    assert_true(lazy_2.is_forced())

# Generated at 2022-06-26 00:20:43.401676
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(int_0, [])
    validation_1 = Validation(None, [])

    assert validation_0.to_lazy().get() == int_0
    assert validation_0.to_lazy().is_fail() == validation_0.is_fail()
    assert validation_0.to_lazy().is_success() == validation_0.is_success()
    assert validation_1.to_lazy().get() == None
    assert validation_1.to_lazy().is_fail() == validation_1.is_fail()
    assert validation_1.to_lazy().is_success() == validation_1.is_success()


# Generated at 2022-06-26 00:20:51.744729
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test with Validation success
    v = Validation.success(2)
    l = v.to_lazy()
    assert l.value() == 2
    # Test with Validation fail
    v = Validation.fail()
    l = v.to_lazy()
    assert l.value() is None


# Generated at 2022-06-26 00:20:55.270588
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    res0 = Validation.success(12).to_lazy()
    res1 = Validation.fail([1, 2, 3]).to_lazy()

    ret0 = res0.value()
    ret1 = res1.value()

    assert ret0 == 12
    assert ret1 == None


# Generated at 2022-06-26 00:20:57.882592
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy() == Lazy(lambda: int_0)
    assert Validation.fail(int_0).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:04.755924
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 2
    int_1 = 1
    val_0 = Validation.success(int_0)
    lazy_0 = val_0.to_lazy()
    int_2 = lazy_0.map(lambda int_3: int_3 + 1).get()
    print(int_2)
    int_4 = lazy_0.fmap(lambda int_5: int_5 + 1).get()
    print(int_4)
    int_6 = Lazy(lambda: int_1).get()
    print(int_6)


# Generated at 2022-06-26 00:21:14.315712
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_box import Box
    from pymonet.lazy import Lazy

    int_0 = 2
    int_1 = 4
    int_2 = 5
    int_3 = 10
    str_0 = 'str'
    failure_errors = ['error']

    lazy_0 = Lazy(lambda: int_0)
    lazy_1 = Lazy(lambda: int_1)
    lazy_2 = Lazy(lambda: int_2)
    lazy_3 = Lazy(lambda: int_3)
    lazy_fail = Lazy(lambda: None)

    success_0 = Validation.success(int_0)
    success_1 = Validation.success(int_1)


# Generated at 2022-06-26 00:21:15.305444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:21:18.630072
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # success case
    assert Validation.success('my').to_lazy() == Lazy(lambda: 'my')
    # fail case
    assert Validation.fail(['My error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:22.429970
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert lazy.get() == 1
    assert lazy.get() == 1
    lazy.set(lambda: 2)
    assert lazy.get() == 2
    assert lazy.get() == 2

test_case_0()
test_Validation_to_lazy()

# Generated at 2022-06-26 00:21:27.522054
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 2

    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.bind(lambda int_1: Lazy(lambda: int_0 + int_1))

    assert lazy_0.value() == int_0
    assert lazy_1.value() == int_0 * 2


# Generated at 2022-06-26 00:21:32.969370
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation to_lazy evaluates function.
    """
    int_0 = 2
    int_1 = 3

    multiplication = lambda first, second: first * second
    validate_int = Validation.success(int_0)

    validation_to_lazy = validate_int.to_lazy()
    lazy_multiplication = multiplication(validation_to_lazy.run, int_1)

    assert lazy_multiplication == 6

# Generated at 2022-06-26 00:21:42.140868
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def nested_function(str_0):
        str_1 = 'Box[value={}]'
        validation_0 = Validation(str_1, str_0)
        var_0 = validation_0.to_lazy()

    try:
        nested_function('-z=*G;U6')
    except:
        pass


# Generated at 2022-06-26 00:21:51.370841
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """

    """
    # Test case where value is a string
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.get().get()
    assert str == type(var_0)
    assert str_0 == var_0
    # Test case where value is a boolean
    bool_0 = True
    bool_1 = False
    validation_1 = Validation(bool_0, bool_1)
    lazy_1 = validation_1.to_lazy()
    var_1 = lazy_1.get().get()
    assert bool == type(var_1)
    assert bool_0 == var_

# Generated at 2022-06-26 00:21:57.698601
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('Box[value={}]').to_lazy() == Lazy(lambda: 'Box[value={}]')
    assert Validation.fail(['kZlv*~+']).to_lazy() == Lazy(lambda: None)
    assert Validation.success('Box[value={}]').to_lazy() == Lazy(lambda: 'Box[value={}]')
    assert Validation.fail(['kZlv*~+']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:01.672595
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_4 = 'xOA!9a7Y2'
    str_5 = 'wZs*@+~T'
    validation_0 = Validation(str_4, [str_5])
    var_3 = validation_0.to_lazy()
    var_4 = var_3.__str__()


# Generated at 2022-06-26 00:22:05.918487
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.to_lazy()
    UnitTests.myAssertRaisesException(TypeError, lambda: var_0.value, 'calling <lambda> raised')


# Generated at 2022-06-26 00:22:11.228585
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from nose.tools import assert_true

    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.__str__()
    var_1 = validation_0.to_lazy()
    var_2 = isinstance(var_1, Lazy)
    assert_true(var_2)


# Generated at 2022-06-26 00:22:19.619378
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    str_2 = 'Box[value={}]'
    str_3 = 'kZlv*~+'
    validation_1 = Validation(str_2, str_3)
    var_0 = validation_1.to_lazy()
    int_0 = var_0.value().__eq__(str_2)
    var_1 = validation_1.to_lazy()
    int_1 = var_1.value().__eq__(str_0)
    int_2 = var_1.value().__eq__(str_2)


# Generated at 2022-06-26 00:22:23.907179
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.get()


# Generated at 2022-06-26 00:22:27.234775
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:22:33.596447
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:22:54.071979
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method Validation.to_lazy
    """
    def test_case_0():
        str_0 = 'Box[value={}]'
        str_1 = 'kZlv*~+'
        validation_0 = Validation(str_0, str_1)
        lazy_0 = validation_0.to_lazy()
        lazy_1 = lazy_0.flat_map(lambda value_0: Lazy(lambda: value_0))
        lazy_2 = lazy_1.map(lambda value_1: value_1.format('{}'))
        var_0 = lazy_2.to_maybe()


# Generated at 2022-06-26 00:22:56.526862
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    assert str(Validation.fail(['error_message']).to_lazy()) == 'Lazy[Function() -> None]'
    assert str(Validation.success(42).to_lazy()) == 'Lazy[Function() -> 42]'


# Generated at 2022-06-26 00:23:03.881738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()
    expect_0 = Lazy(lambda: str_0)
    assert expect_0 == lazy_0
    
    validation_1 = Validation.fail(list_0)
    lazy_1 = validation_1.to_lazy()
    expect_1 = Lazy(lambda: None)
    assert expect_1 == lazy_1



# Generated at 2022-06-26 00:23:08.547494
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.to_lazy()
    var_1 = Lazy(lambda: str_0)
    var_2 = var_0 == var_1


# Generated at 2022-06-26 00:23:11.365404
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(1)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1


# Generated at 2022-06-26 00:23:17.115719
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        str_0 = "Box[value={}]"
        str_1 = "kZlv*~+"
        validation_0 = Validation(str_0, str_1)
        def test_fn_0():
            return validation_0.value
        lazy_0 = validation_0.to_lazy()
        var_0 = test_fn_0()
        assert var_0 == str_0

    test_case_0()



# Generated at 2022-06-26 00:23:21.747258
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy as L
    from pymonet.validation import Validation as V

    assert V.success(1).to_lazy() == L(lambda: 1)
    assert V.fail([]).to_lazy() == L(None)
    assert V.fail([1]).to_lazy() == L(None)
    assert V.fail([1, 2]).to_lazy() == L(None)

# Generated at 2022-06-26 00:23:29.481363
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'Box[value=kZlv*~+]'
    validation_0 = Validation(str_0, str_1)
    validation_0 = validation_0.to_lazy()

    # Call method to_try of class Lazy
    validation_1 = validation_0.to_try()

    # Call method is_success of class Try
    validation_2 = validation_1.is_success()

    # Call method to_try of class Try
    validation_3 = validation_1.to_try()

    assert(validation_3.is_success())

    # Call method flatten of class Try
    validation_2 = validation_3.flatten()

    # Call method get_value of class Try
    validation_3 = validation_2.get_value()

# Generated at 2022-06-26 00:23:32.781870
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def f():
        print("f")
        return 0

    lazy_0 = Validation(0, []).to_lazy()
    assert lazy_0 == Lazy(f)



# Generated at 2022-06-26 00:23:34.243017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert (Validation.success(1).to_lazy() == Lazy(lambda: 1))

# Generated at 2022-06-26 00:23:54.097849
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('test_Validation_to_lazy ... ', end='')
    assert(Validation.success(12).to_lazy().value() == 12)
    assert(Validation.fail().to_lazy().value() == None)
    print('ok')


# Generated at 2022-06-26 00:23:57.181828
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    validation_0 = Validation.success(str_0)
    lazy = validation_0.to_lazy()
    var_0 = lazy(lambda: True)


# Generated at 2022-06-26 00:24:02.441993
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test it transform Validation to Lazy monad"""
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success('value').to_lazy() == Lazy.of('value')
    assert Validation.success(None).to_lazy() == Lazy.of(None)
    assert Validation.fail('error list').to_lazy() == Lazy.of(None)



# Generated at 2022-06-26 00:24:04.586900
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'pYh7W*y=@'
    validation_0 = Validation(str_0)
    var_0 = validation_0.to_lazy().__str__()


# Generated at 2022-06-26 00:24:14.009274
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        str_0 = 'Box[value={}]'
        str_1 = 'kZlv*~+'
        validation_0 = Validation(str_0, str_1)
        var_0 = validation_0.to_lazy()
        assert(var_0.__class__ == Lazy)
        assert(var_0.value() == str_0)
    def test_case_1():
        str_0 = '+:0gk'
        str_1 = 'Box[value={}]'
        int_0 = -89
        str_2 = '}><'
        validation_0 = Validation(str_0, int_0)
        var_0 = validation_0.to_lazy()
        assert(var_0.__class__ == Lazy)
       

# Generated at 2022-06-26 00:24:17.360234
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = "pymonet.lazy.Lazy[function=lambda: {'value': {}}]"
    validation_0 = Validation.success({'value': {}})
    var_0 = validation_0.to_lazy()
    assert str(var_0) == str_0


# Generated at 2022-06-26 00:24:22.740635
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    str_2 = lazy_0.__str__()
    str_3 = 'Lazy[function=<function Validation_to_lazy.<locals>.<lambda> at 0x7f3af411dd08>]'
    var_0 = (str_2 == str_3)


# Generated at 2022-06-26 00:24:29.084781
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    var_0 = validation_0.to_lazy()
    var_1 = isinstance(var_0, Lazy)
    assert var_1
    var_2 = str(var_0)
    assert var_2 == "Lazy[value=<function test_Validation_to_lazy.<locals>.<lambda> at 0x7ffb647427b8>]"


# Generated at 2022-06-26 00:24:32.330555
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.__str__()


# Generated at 2022-06-26 00:24:35.577451
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.value()


# Generated at 2022-06-26 00:25:16.025401
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    validation_0 = Validation(str_0, [])
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:21.006229
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    assert validation_0.to_lazy() == Lazy('lambda: \'' + str_0 + '\''), 'to_lazy method fails'


# Generated at 2022-06-26 00:25:24.504644
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It should return Lazy Monad
    """
    maybe_0 = Validation.success(1).to_lazy()
    int_0 = maybe_0.value()
    assert int_0 == 1

    maybe_1 = Validation.fail(1).to_lazy()
    int_1 = maybe_1.value()
    assert int_1 is None



# Generated at 2022-06-26 00:25:32.917539
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'

    validation_0 = Validation(str_0, str_1)
    lazy_0 = Lazy(lambda: str_0)

    assert validation_0.to_lazy() == lazy_0

test_Validation_to_lazy()

# Generated at 2022-06-26 00:25:36.980716
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation('!Monads!', [])
    lazy_0 = validation_0.to_lazy()
    validation_1 = lazy_0.get_value()
    validation_2 = Validation(validation_1, ['!Monads!'])
    assert validation_2 == Validation(validation_1, ['!Monads!'])


# Generated at 2022-06-26 00:25:45.410544
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '3-k$^g&'
    str_1 = 'XQD!=x'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.__str__()
    var_1 = lazy_0.value
    var_2 = lazy_0.value
    lazy_1 = lazy_0.map(lambda arg_0: arg_0.find(''))
    lazy_2 = lazy_1.flat_map(lambda arg_0: lazy_0)
    lazy_3 = lazy_2.filter(lambda arg_0: arg_0.find('s') == -2)
    lazy_4 = lazy_3.recover(lambda arg_0: '')

# Generated at 2022-06-26 00:25:52.075167
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def __str__(self):  # pragma: no cover
        return 'Lazy[function]'

    Lazy.__str__ = __str__

    assert Lazy(lambda: 'a') == Validation.success(str_0).to_lazy()



# Generated at 2022-06-26 00:25:56.753795
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy0 = validation_0.to_lazy()
    lazy0.get()
    var_0 = lazy0.get()
    assert var_0 is not None, "var_0 is None"


# Generated at 2022-06-26 00:25:57.692931
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:26:04.308510
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.__str__()
    str_2 = 'Box[value={}]'
    str_3 = 'kZlv*~+'
    validation_1 = Validation(str_2, str_3)
    lazy_1 = validation_1.to_lazy()
    var_1 = lazy_1.__str__()


# Generated at 2022-06-26 00:27:38.666247
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    str_2 = 'Box[value=kZlv*~+]'
    str_3 = 'kZlv*~+'
    validation_1 = Validation(str_2, str_3)
    var_0 = validation_0.__eq__(validation_1)
    str_4 = 'Box[value={}]'
    str_5 = 'kZlv*~+'
    validation_2 = Validation(str_4, str_5)
    str_6 = 'Box[value={}]'
    str_7 = 'kZlv*~+'
    validation_3 = Validation(str_6, str_7)

# Generated at 2022-06-26 00:27:42.278631
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    value_0 = lazy_0.__str__()
    str_2 = 'Lazy[function={}]'
    assert str_2 == value_0



# Generated at 2022-06-26 00:27:45.293613
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.__str__()


# Generated at 2022-06-26 00:27:48.963529
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.utils import value_factory

    validation = Validation(value_factory, [])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == value_factory()
    assert lazy.value() == value_factory()
    assert validation.to_lazy() == lazy

# Generated at 2022-06-26 00:27:53.068820
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    def func():
        return 'something wrong'

    validation = Validation.fail(func)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == func()
    assert not lazy.value().is_success()



# Generated at 2022-06-26 00:27:56.201900
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    validation_0.to_lazy()


# Generated at 2022-06-26 00:28:00.541436
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation_0 = Validation.success(10)
    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.call() == 10


# Generated at 2022-06-26 00:28:06.204755
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value={}]'
    str_1 = 'kZlv*~+'
    validation_0 = Validation(str_0, str_1)
    validation_1 = validation_0.to_lazy()


# Generated at 2022-06-26 00:28:11.105791
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation()
    validation_0.value = 'Box[value={}]'
    validation_0.errors = 'kZlv*~+'
    str_0 = validation_0.to_lazy().__call__().get()


# Generated at 2022-06-26 00:28:17.009130
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Box[value=]'
    validation_0 = Validation.success(str_0)
    str_0 = 'Box[value=]'
    validation_1 = Validation.success(str_0)
    str_0 = str(validation_0)
    str_1 = str(validation_1)
    var_0 = validation_0.to_lazy()
    str_0 = 'Box[value=]'
    expected_0 = Lazy(lambda: str_0)
    assert_equals(var_0, expected_0)
