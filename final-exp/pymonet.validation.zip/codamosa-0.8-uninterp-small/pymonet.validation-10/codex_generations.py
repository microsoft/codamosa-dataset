

# Generated at 2022-06-26 00:18:31.385280
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    str_0 = 'Y'
    validation_0 = Validation(str_0, str_0)
    str_1 = 'Y'
    validation_1 = Validation(str_1, str_1)
    assert validation_0 == validation_1


# Generated at 2022-06-26 00:18:34.742479
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    str_0 = 'V-}y'
    validation_0 = Validation(str_0, str_0)
    boolean_0 = validation_0.__eq__(validation_0)
    assert(boolean_0)


# Generated at 2022-06-26 00:18:39.008776
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # example case
    str_0 = 'JGk? '
    list_0 = list()
    validation_0 = Validation(str_0, list_0)

    str_1 = 'c.A/'
    validation_1 = Validation(str_1, list_0)

    assert validation_0 != validation_1


# Generated at 2022-06-26 00:18:51.671625
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.validation import Validation

    validation_0 = Validation.fail()
    validation_1 = Validation.success([], [])
    assert(validation_0 == validation_1)

    validation_0 = Validation.fail().ap(lambda x: Validation.fail(x))
    validation_1 = Validation.fail().ap(lambda x: Validation.fail(x))
    assert(validation_0 == validation_1)

    validation_0 = Validation.fail(None)
    validation_1 = Validation.success(None)
    assert(not validation_0 == validation_1)

    validation_0 = Validation.fail(None)
    validation_1 = Validation.success(None)


# Generated at 2022-06-26 00:19:03.424487
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation_0 = Validation.success()
    validation_1 = Validation.fail()
    str_0 = 'S1j'
    str_1 = 'S1j'
    validation_2 = Validation(str_0, str_0)
    validation_3 = Validation(str_1, str_1)
    validation_4 = Validation(str_0, str_0)
    validation_5 = Validation(str_0, str_0)
    validation_6 = Validation(str_1, str_1)
    str_2 = 'j+ 8Q'
    validation_7 = Validation(str_2, str_2)
    assert validation_0 == validation_1
    assert validation_0 != validation_2
    assert validation_0 != validation_3
    assert validation_0 != validation_4
   

# Generated at 2022-06-26 00:19:06.497036
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    bool_0 = validation_0 == str_0
    assert bool_0 is False


# Generated at 2022-06-26 00:19:13.328954
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    error = None
    validation_0 = Validation(None, [])
    validation_1 = Validation(None, [])
    print('Comparing validations: ' + str(validation_0) + ' equals to ' + str(validation_1))
    if validation_0 != validation_1:
        error = 'Validation.__eq__() failed'
    validation_0 = Validation({})
    validation_1 = Validation({})
    print('Comparing validations: ' + str(validation_0) + ' equals to ' + str(validation_1))
    if validation_0 != validation_1:
        error = 'Validation.__eq__() failed'
    validation_0 = Validation([])
    validation_1 = Validation([])

# Generated at 2022-06-26 00:19:21.876493
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # 0. string
    str_0 = 'Y%X9'
    # 0. Validation
    validation_0 = Validation(str_0, str_0)
    assert validation_0.__eq__(validation_0)
    # 1. string
    str_1 = 'Jiq'
    # 1. Validation
    validation_1 = Validation(str_1, str_1)
    assert validation_1.__eq__(validation_1)


# Generated at 2022-06-26 00:19:26.369657
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(None, [1]) != None, 'assert failed in test_Validation___eq__'
    assert Validation(None, [1]) == Validation(None, [1]), 'assert failed in test_Validation___eq__'
    assert Validation(None, [1]) == Validation(None, [1]), 'assert failed in test_Validation___eq__'


# Generated at 2022-06-26 00:19:33.269947
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    str_0 = '^dY`P'
    str_1 = '^dY`P'
    validation_0 = Validation(str_0, str_1)
    str_2 = 'DJo'
    validation_1 = Validation(str_2, str_1)
    str_3 = '^dY`P'
    str_4 = '^dY`P'
    validation_2 = Validation(str_3, str_4)

    assert validation_0 == validation_2
    assert not (validation_0 != validation_2)
    assert validation_0 != validation_1
    assert not (validation_0 == validation_1)


# Generated at 2022-06-26 00:19:37.058686
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy = validation_0.to_lazy()
    assert type(lazy) == Lazy
    assert lazy() == str_0


# Generated at 2022-06-26 00:19:39.071382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:19:42.011683
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation.success(str_0)
    lazy = validation_0.to_lazy()
    assert lazy() == str_0


# Generated at 2022-06-26 00:19:47.474979
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monoid import StringMonoid

    str_0 = '^dY`P'
    validation_0 = Validation(str_0, [])

    validation_1 = validation_0.to_lazy()

    assert validation_1.result() == str_0


# Generated at 2022-06-26 00:19:50.324195
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:59.858503
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    str_1 = 'eDWO'
    str_2 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    validation_1 = Validation(str_2, str_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = validation_1.to_lazy()
    try:
        str_3 = lazy_0.get()
        assert str_3 == str_2
    except AssertionError as e:
        print(e)
    try:
        str_3 = lazy_1.get()
        assert str_3 == str_2
    except AssertionError as e:
        print(e)


# Generated at 2022-06-26 00:20:08.417553
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'jt@\x1dE\x14\x15^Xl(F\x02\x05\x19\x13\x0b\x1c\x1d\x1d\x1e\x19\x16\x1e\x13\x18\x1d\x1f\x1c\x1e\x0e\x1a\x0c\x1b\x1c\x1a\x1f\x1e'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-26 00:20:17.392982
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    fail_0 = Validation.fail()
    assert fail_0.to_lazy() == Lazy(None)
    str_0 = 'l\x8f\x1f\xdb\x1f\x00\x00\x00\x00'
    validation_0 = Validation(str_0, str_0)
    assert validation_0.to_lazy() == Lazy(str_0)
    str_0 = 'O`\x9d\xac\\\x1a\xab'
    validation_0 = Validation.fail(str_0)
    assert validation_0.to_lazy() == Lazy(None)
    str_0 = 'd{'
    validation_0 = Validation(str_0, str_0)

# Generated at 2022-06-26 00:20:20.391978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    validation_1 = validation_0.to_lazy()
    assert validation_1.evaluate() == str_0


# Generated at 2022-06-26 00:20:23.627320
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0
    assert lazy_1.value == str_0


# Generated at 2022-06-26 00:20:29.061783
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation.success(65)
    expected_result_0 = Lazy(lambda: 65)
    assert validation_0.to_lazy() == expected_result_0


# Generated at 2022-06-26 00:20:41.556738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('#(:gP').to_lazy().get() == '#(:gP'
    assert Validation.success('9C-jq').to_lazy().get() == '9C-jq'
    assert Validation.success('7!p9j').to_lazy().get() == '7!p9j'
    assert Validation.success('$db`N').to_lazy().get() == '$db`N'
    assert Validation.success(']oh?u').to_lazy().get() == ']oh?u'
    assert Validation.success('-;R_b').to_lazy().get() == '-;R_b'
    assert Validation.success('s%x#x').to_lazy().get() == 's%x#x'


# Generated at 2022-06-26 00:20:47.678906
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method to_lazy of class Validation.
    """
    results = []
    TESTS_COUNT = 100
    for index in range(TESTS_COUNT):
        str_0 = '^dY`P'
        validation_0 = Validation(str_0, str_0)

        lazy_0 = validation_0.to_lazy()

        results.append(lazy_0.get() == str_0)

    return all(results)


# Generated at 2022-06-26 00:20:50.976973
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == str_0


# Generated at 2022-06-26 00:20:55.923726
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Create Lazy[Function() -> str_0].

    """
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)

    result_0 = validation_0.to_lazy()

    def example_0():
        return str_0

    result_1 = Lazy(example_0)

    assert result_0 == result_1


# Generated at 2022-06-26 00:21:05.881837
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # test success
    success_maybe = Maybe.just(3)
    lazy_success_maybe = success_maybe.to_lazy()
    assert lazy_success_maybe == Lazy(lambda: 3)

    # test failure
    failure_maybe = Maybe.nothing()
    lazy_failure_maybe = failure_maybe.to_lazy()
    assert lazy_failure_maybe == Lazy(lambda: None)

    # test success
    success_maybe = Maybe.just(3)
    lazy_success_maybe = success_maybe.to_lazy()
    assert lazy_success_maybe == Lazy(lambda: 3)

    # test success

# Generated at 2022-06-26 00:21:08.188024
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(str('s'), []).to_lazy() == Lazy(lambda : str('s'))


# Generated at 2022-06-26 00:21:14.366076
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    lazy_0.get()
    assert lazy_0 == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:21:17.456857
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test cases for method to_lazy of class Validation
    """

    # Execute test case for method to_lazy with arguments:
    # Validation[value, errors]

    test_case_0()


# Generated at 2022-06-26 00:21:21.944962
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
  from pymonet.box import Box
  from pymonet.lazy import Lazy
  assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
  assert Validation.success(Box(100)).to_lazy() == Lazy(lambda: Box(100))
  assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:33.997470
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_0 = Validation.success(1)
    test_1 = Validation.success('test')
    test_2 = Validation.fail(1)
    test_3 = Validation.fail('test')
    test_4 = Validation.fail([1, 2, 3])
    assert test_0.to_lazy() == Lazy(lambda: 1)
    assert test_1.to_lazy() == Lazy(lambda: 'test')
    assert test_2.to_lazy() == Lazy(lambda: None)
    assert test_3.to_lazy() == Lazy(lambda: None)
    assert test_4.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:37.402834
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(value=True, errors='')
    lazy = Lazy(lambda: validation.value)

    assert validation.to_lazy() == lazy


# Generated at 2022-06-26 00:21:42.141131
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value == str_0


# Generated at 2022-06-26 00:21:46.108274
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    def str_0(str_1):
        return str_1

    validation_0 = Validation(str_0, 'oGH;')
    assert isinstance(validation_0.to_lazy(), Lazy)
    assert validation_0.to_lazy().__class__.__name__ == 'Lazy'

    validation_1 = Validation(str_0, 'oGH;')
    validation_2 = Validation(str_0, 'oGH;')
    assert validation_1.to_lazy() == validation_2.to_lazy()
    assert validation_1.to_lazy() is not validation_2.to_lazy()

    validation_3 = Validation(str_0, 'oGH;')

# Generated at 2022-06-26 00:21:47.582772
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation(1, [])
    assert val.to_lazy().eval() == 1

# Generated at 2022-06-26 00:21:50.475245
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'CpzA'
    validation_0 = Validation(str_0, [str_0])
    assert(validation_0.to_lazy().get_val() == str_0)


# Generated at 2022-06-26 00:21:57.128622
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    val_0_maybe = Validation.success('^dY`P').to_lazy()
    val_0_either = Validation.fail(['^dY`P']).to_lazy()
    val_0_box = Validation.success('^dY`P').to_lazy()
    val_0_lazy = Validation.fail(['^dY`P']).to_lazy()
    val_0_try = Validation.success('^dY`P').to_lazy()



# Generated at 2022-06-26 00:22:00.597350
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'C"Qj'
    validation_0 = Validation.fail([str_0])
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() is None


# Generated at 2022-06-26 00:22:04.888013
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)

    lazy_0 = validation_0.to_lazy()

    assert lazy_0.__class__ == Lazy
    assert lazy_0.value == validation_0.value



# Generated at 2022-06-26 00:22:09.044185
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Prepare mocks
    str_0 = 'W8}3H'
    class MockLazy:
        def __init__(self, func):
            self.func = func

        def __eq__(self, other):
            return (isinstance(other, Lazy) and
                    self.func.__closure__ == other.func.__closure__)

    # Prepare objects
    validation_0 = Validation(str_0, [str_0])
    expeted_lazy = MockLazy(lambda: str_0)
    # Perform action
    lazy = validation_0.to_lazy()
    # Assert results
    assert lazy == expeted_lazy



# Generated at 2022-06-26 00:22:25.561522
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.functions import compose
    from pymonet.monoid import Monoid

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['x']).to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy().map(lambda x: x + 1) == Lazy(lambda: 6)
    assert Validation.fail(['x']).to_lazy().map(lambda x: x + 1) == Lazy(lambda: None)

# Generated at 2022-06-26 00:22:28.915153
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('^dY`P').to_lazy() == Lazy(lambda: '^dY`P')
    assert Validation.fail(['*']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:35.030840
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'P'
    validation_0 = Validation(str_0, [])
    str_1 = 'P'
    lazy_0 = validation_0.to_lazy()
    str_2 = lazy_0.apply()
    assert True


# Generated at 2022-06-26 00:22:38.601485
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.utils import is_lazy

    assert is_lazy(Validation.success(10).to_lazy())
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-26 00:22:45.377689
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)

    lazy_0 = validation_0.to_lazy()

    assert lazy_0.value() == str_0


# Generated at 2022-06-26 00:22:47.875146
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Test Case #0
    test_case_0()



# Generated at 2022-06-26 00:22:56.711326
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy_1 = Validation.success(None).to_lazy()
    assert lazy_1 == Lazy(lambda: None)
    lazy_2 = Validation.fail(None).to_lazy()
    assert lazy_2 == Lazy(lambda: None)
    lazy_3 = Validation.success('!@#$%^&*()_+').to_lazy()
    assert lazy_3 == Lazy(lambda: '!@#$%^&*()_+')
    lazy_4 = Validation.fail('!@#$%^&*()_+').to_lazy()
    assert lazy_4 == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:01.225181
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    expected_0 = Validation(str_0, str_0)
    actual_0 = validation_0.to_lazy()
    assert actual_0 == expected_0


# Generated at 2022-06-26 00:23:03.832017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        str_0 = '^dY`P'
        validation_0 = Validation(str_0, str_0)


# Generated at 2022-06-26 00:23:12.084207
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Kl+Q'
    validation_0 = Validation(str_0, str_0)
    str_1 = 'a'
    validation_1 = Validation(str_1, str_1)
    list_0 = [validation_0]
    list_1 = [validation_1]
    lazy_0 = validation_0.to_lazy()
    lazy_1 = validation_1.to_lazy()
    assert lazy_0.value() == lazy_1.value()
    str_2 = 'zaPu'
    validation_2 = Validation(str_2, str_2)
    str_3 = '"wN'
    validation_3 = Validation(str_3, str_3)

# Generated at 2022-06-26 00:23:30.070355
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'G'
    validation_0 = Validation(str_0, [str_0])
    assert(validation_0.to_lazy().force() == 'G')


# Generated at 2022-06-26 00:23:38.853871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'abcdefghijklmnopqrstuvwxyz'
    validation_0 = Validation(str_0, [])
    lazy_0 = validation_0.to_lazy()
    str_1 = 'qwertyuiopasdfghjklzxcvbnm'
    validation_1 = Validation(str_1, [])
    lazy_1 = validation_1.to_lazy()
    str_2 = 'QWERTYUIOPASDFGHJKLZXCVBNM'
    validation_2 = Validation(str_2, [])
    lazy_2 = validation_2.to_lazy()

    assert lazy_0 == Lazy(lambda: 'abcdefghijklmnopqrstuvwxyz')
   

# Generated at 2022-06-26 00:23:42.959609
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    if True:
        str_0 = '^dY`P'
        validation_0 = Validation.success(str_0)
        lazy_0 = Lazy(lambda: str_0)
        lazy_1 = validation_0.to_lazy()
        assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:23:48.273510
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        str_0 = '^dY`P'
        validation_0 = Validation(str_0, str_0)
        assert validation_0.to_lazy().eval() == str_0

    def test_case_1():
        str_0 = '^dY`P'
        validation_0 = Validation(str_0, [])
        assert validation_0.to_lazy().eval() == str_0



# Generated at 2022-06-26 00:23:53.621078
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Setup environment
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, [])
    expected_0 = 'Lazy[Function() -> (A | None)]'

    # Run actual computation
    result_0 = validation_0.to_lazy()

    # Compare results
    assert str(result_0) == expected_0


# Generated at 2022-06-26 00:23:57.942913
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation_0: Validation[int, str] = Validation.success(1)
    lazy_0 = validation_0.to_lazy()

    assert (isinstance(lazy_0, Lazy))
    assert (lazy_0.value() == 1)


# Generated at 2022-06-26 00:24:05.166311
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, TryError
    from pymonet.monad_err import MonadErr
    from pymonet.either import Left, Right

    result = Try(1).to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 1

    result = Try(1).to_lazy().to_try()
    assert isinstance(result, Try)
    assert result.get() == 1

    result = Try(1).to_lazy().to_try().to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() == 1

    result = Try(None).to_lazy()
    assert isinstance(result, Lazy)
    assert result.get() is None

# Generated at 2022-06-26 00:24:09.358564
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'jWjJ'
    validation_0 = Validation(str_0, str_0)

    assert isinstance(validation_0.to_lazy(), Lazy)


# Generated at 2022-06-26 00:24:14.583921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # test with success
    validation = Validation.success('pymonet')
    lazy_val = validation.to_lazy()
    assert isinstance(lazy_val, Lazy)
    assert lazy_val() == 'pymonet'
    # test with failure
    validation = Validation.fail(['error'])
    lazy_val = validation.to_lazy()
    assert isinstance(lazy_val, Lazy)
    assert lazy_val() == None


# Generated at 2022-06-26 00:24:16.669816
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '!m4'
    validation_0 = Validation.fail(str_0)
    validation_0.to_maybe()


# Generated at 2022-06-26 00:24:53.072765
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success(Lazy(lambda: True))
    assert validation.to_lazy() == validation.value


# Generated at 2022-06-26 00:24:59.600251
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    str_0 = '^dY`P'
    validation_0 = Validation(Try(str_0, is_success=False), [str_0])
    assert validation_0.to_lazy() == Lazy(lambda: Try(str_0, is_success=False))
    str_1 = ';qG[?Sgv=8w'
    validation_1 = Validation(Try(str_1, is_success=True), [str_1])
    assert validation_1.to_lazy() == Lazy(lambda: Try(str_1, is_success=True))


# Generated at 2022-06-26 00:25:02.536705
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_1 == '^dY`P'

# Generated at 2022-06-26 00:25:06.995426
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('Executing test_Validation_to_lazy ...')
    str_0 = 'MfCQb-n'
    validation_0 = Validation.fail([str_0])
    lazy_0 = validation_0.to_lazy()

    print(str(lazy_0))
    print('Successfully finished test_Validation_to_lazy')


# Generated at 2022-06-26 00:25:09.377059
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('^dY`P').to_lazy() == Lazy(lambda: '^dY`P')


# Generated at 2022-06-26 00:25:15.550583
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Xs7sP'
    validation_0 = Validation.success(str_0)
    lazy = validation_0.to_lazy()

    assert lazy.get() == str_0
    assert lazy.get() == str_0


# Generated at 2022-06-26 00:25:23.982989
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    func_0 = lambda: 'Vc%Yf=Fl'
    func_1 = lambda: 'kb6S%eZg'
    func_2 = lambda: '\x4d\x24\x63\x6f\x2a\x76\x70\x22\x5d\x20\x6d\x28\x37\x29\x5d\x30\x61\x22\x00'

# Generated at 2022-06-26 00:25:30.719229
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([10, 20]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:25:35.265719
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Z$!.%J?*L'
    validation_0 = Validation(str_0, [str_0])
    str_1 = '5"bL'
    validation_0 = validation_0.map(lambda s: s + str_1)
    assert validation_0.to_lazy().value() == 'Z$!.%J?*L5"bL'


# Generated at 2022-06-26 00:25:37.468303
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.fail(['zZ|_W'])
    assert(validation_0.to_lazy().execute() is None)



# Generated at 2022-06-26 00:26:51.198374
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'ppH4B'
    lazy_0 = Validation(str_0, None).to_lazy()
    lazy_0.value()


# Generated at 2022-06-26 00:26:51.852017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:26:57.594902
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Check that to_lazy works correctly"""

    test_str_0 = 'Test string 0'
    test_str_1 = 'Test string 1'

    validation_0 = Validation.success(test_str_0)
    validation_1 = Validation.fail([test_str_1])

    result_0 = validation_0.to_lazy()
    result_1 = validation_1.to_lazy()

    assert result_0.value() == test_str_0
    assert result_1.value() is None


# Generated at 2022-06-26 00:27:03.949856
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    str_1 = 'RCp^'
    str_2 = '#hDY'
    validation_1 = validation_0.ap(lambda str_0, str_1=str_1, str_2=str_2:
                                          Validation(str_0 + str_1, str_2))
    validation_2 = validation_1.to_lazy()
    lazy_0 = validation_2.value
    str_3 = '!K'
    str_4 = 'Y#m'
    validation_3 = lazy_0(str_3, str_4)
    str_5 = 'Wz}8'

# Generated at 2022-06-26 00:27:10.938651
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'R^=ju'
    lazy_0 = Validation.success(str_0).to_lazy()
    str_1 = '5q$o5'
    lazy_1 = Validation.success(str_1).to_lazy()
    str_2 = ']y?e9'
    lazy_2 = Validation.success(str_2).to_lazy()
    str_3 = 'C mFd'
    lazy_3 = Validation.success(str_3).to_lazy()
    str_4 = '<5+J9'
    lazy_4 = Validation.success(str_4).to_lazy()
    str_5 = '=NXE7'
    lazy_5 = Validation.success(str_5).to_lazy()
    str_

# Generated at 2022-06-26 00:27:13.120468
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return 'hello world'
    lazy = Lazy(f)
    validation = Validation.success(lazy)
    new_lazy = validation.to_lazy()
    assert new_lazy == lazy


# Generated at 2022-06-26 00:27:14.804502
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success({'bar': 'foo'})
    assert validation.to_lazy().get() == {'bar': 'foo'}



# Generated at 2022-06-26 00:27:22.102922
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    str_0 = '^dY`P'
    validation_0 = Validation.success(str_0)
    try:
        assert validation_0.to_lazy() == Lazy(lambda : str_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 00:27:24.576774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '^dY`P'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0._thunk() == '^dY`P'

# Generated at 2022-06-26 00:27:26.337387
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    to_lazy_0 = \
        Validation.success(
            '^dY`P'
        ).to_lazy()
