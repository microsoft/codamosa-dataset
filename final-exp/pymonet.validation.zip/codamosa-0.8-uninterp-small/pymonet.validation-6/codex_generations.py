

# Generated at 2022-06-26 00:18:33.482466
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0._func() == str_0


# Generated at 2022-06-26 00:18:43.107012
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(None, {})
    lazy_0 = validation_0.to_lazy()
    lazy_0.get()
    validation_1 = Validation(None, {})
    lazy_1 = validation_1.to_lazy()
    lazy_1.get()
    validation_2 = Validation(None, {})
    lazy_2 = validation_2.to_lazy()
    lazy_2.get()
    validation_3 = Validation(None, {})
    lazy_3 = validation_3.to_lazy()
    lazy_3.get()
    validation_4 = Validation(None, {})
    lazy_4 = validation_4.to_lazy()
    lazy_4.get()
    validation_5 = Validation(None, {})
    lazy_5 = validation

# Generated at 2022-06-26 00:18:55.670752
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def func_0(dict_0={}):
        bool_0 = bool()
        bool_1 = bool()
        list_0 = []
        list_1 = []
        list_2 = []
        list_3 = []
        list_4 = []
        list_5 = []
        list_6 = []
        str_0 = str()
        str_1 = str()
        str_2 = str()
        str_3 = str()
        str_4 = str()
        str_5 = str()
        str_6 = str()
        str_7 = str()
        str_8 = str()
        str_9 = str()
        str_10 = str()
        str_11 = str()
        str_12 = str()
        str_13 = str()
        str_14 = str()
       

# Generated at 2022-06-26 00:19:02.939500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    from pymonet.lazy import Lazy

    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0
    assert lazy_0 == Lazy(lambda: None)


# Generated at 2022-06-26 00:19:06.033555
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.call() is None


# Generated at 2022-06-26 00:19:13.100989
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Either

    import datetime

    str_ = 'Hello'
    dict_ = {}
    validation = Validation(str_, dict_)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == 'Hello'

    box = validation.to_box()
    assert isinstance(box, Box)
    assert box.value == 'Hello'

    try_ = validation.to_try()
    assert isinstance(try_, Try)
    assert try_.is_success() == True

    maybe = validation.to_maybe()

# Generated at 2022-06-26 00:19:18.168045
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success({})
    lazy_0 = validation_0.to_lazy()
    get_0 = lazy_0.get()

    assert get_0 == {}


# Generated at 2022-06-26 00:19:22.598313
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.to_lazy()
    assert lazy_1.get() is None


# Generated at 2022-06-26 00:19:30.077676
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    dict_0 = {}
    validation_0 = Validation(int_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    str_0 = lazy_0.get()
    bool_0 = bool()
    bool_1 = bool()
    bool_1 = validation_0.is_success()
    if bool_1:
        bool_0 = bool_1
    else:
        bool_0 = False
    try:
        assert bool_0
    except AssertionError as e:
        print(str_0)
        raise e


# Generated at 2022-06-26 00:19:32.673804
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.evaluate()


# Generated at 2022-06-26 00:19:41.030988
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = "STARTED"
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == str_0

# Generated at 2022-06-26 00:19:51.067037
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert_is_class(Lazy, lazy_0)
    assert_is_function(lazy_0.value)
    assert_is_none(lazy_0.value())
    str_0 = 'Hello, World!'
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert_is_class(Lazy, lazy_0)
    assert_is_function(lazy_0.value)
    assert_equal(lazy_0.value(), str_0)
    dict_0 = {}
    validation_0

# Generated at 2022-06-26 00:19:56.088517
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'value0'
    list_0 = []
    validation_0 = Validation(str_0, list_0)

    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.eval() is str_0



# Generated at 2022-06-26 00:19:58.824968
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:20:08.529186
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    # Create a Validation
    error_0 = 'error_0'
    int_0 = 1
    dict_0 = {error_0: int_0}
    int_1 = 2
    validation_0 = Validation(int_1, dict_0)
    # Get result of call a method to_lazy of class Validation
    result_0 = validation_0.to_lazy()
    # Create a Lazy
    box_0 = Box(int_1)
    lazy_0 = Lazy(lambda : box_0.unbox())
    # Check result instance of
    assert isinstance(result_0, Lazy)
    # Check result
    assert result_0 == lazy_0



# Generated at 2022-06-26 00:20:11.793040
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    _from = 'foo'
    _to = 'bar'
    _call_count = 0
    _result = None
    def _call_function():
        nonlocal _from, _result, _to, _call_count
        _call_count += 1
        _result = _from + _to
        return _result
    _lazy = Validation(_from, {}).to_lazy()
    _lazy_value = _lazy.to_value()
    assert _call_function() == _lazy_value


# Generated at 2022-06-26 00:20:16.461032
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test with success validation

    validation_0 = Validation.success()
    val_0 = validation_0.to_lazy().value()

    assert val_0 is None

    # Test with fail validation

    validation_0 = Validation.fail()
    val_0 = validation_0.to_lazy().value()

    assert val_0 is None


# Generated at 2022-06-26 00:20:20.699908
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()


if __name__ == '__main__':
    str_0 = 0
    dict_0 = {}
    Validation(str_0, dict_0)

# Generated at 2022-06-26 00:20:25.685049
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Lazy[Function() -> (A | None)]
    """
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy = validation_0.to_lazy()

    str_1 = None
    dict_1 = {}
    validation_1 = Validation(str_1, dict_1)
    assert lazy() == validation_1


# Generated at 2022-06-26 00:20:33.962257
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad import monad_test_utils

    def method_test_Validation_to_lazy(cls):
        str_0 = "test_string"
        dict_0 = {}
        validation_0 = Validation(str_0, dict_0)
        lazy_0 = validation_0.to_lazy()
        try_0 = lazy_0.get()
        assert try_0 == Try(str_0)

    monad_test_utils.monad_test(Validation, method_test_Validation_to_lazy)


# Generated at 2022-06-26 00:20:44.740803
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # succesful
    str_0 = "Tau"
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()

    # failed
    list_0 = []
    validation_1 = Validation.fail(list_0)
    lazy_1 = validation_1.to_lazy()


# Generated at 2022-06-26 00:20:49.452987
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)

    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.thunk() == None


# Generated at 2022-06-26 00:20:54.660346
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    str_0 = "foo"
    list_0 = []
    validation_0 = Validation(str_0, list_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.force()
    str_2 = "foo"

    assert str_1 == str_2


# Generated at 2022-06-26 00:20:57.641777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    list_0 = []
    validation_0 = Validation.fail(list_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = None
    assert lazy_0.get() == str_1


# Generated at 2022-06-26 00:21:02.595179
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = "0"
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = lazy_1 = validation_0.to_lazy()
    str_1 = lazy_0.get_value()
    str_2 = lazy_1.get_value()
    assert str_1 == str_2


# Generated at 2022-06-26 00:21:05.495022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-26 00:21:08.444103
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy = validation_0.to_lazy()
    assert lazy.value() == validation_0.value


# Generated at 2022-06-26 00:21:15.346765
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {"key": "value"}
    validation_0 = Validation(str_0, dict_0)
    str_1 = "value"
    dict_1 = {"key": "value"}
    validation_1 = Validation(str_1, dict_1)
    str_2 = None
    assert validation_0.to_lazy().get() == str_2
    str_3 = "value"
    assert validation_1.to_lazy().get() == str_3


# Generated at 2022-06-26 00:21:17.999969
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:21:24.311321
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # test assertion 0
    str_0 = 'value'
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert str_0 == lazy_0.value()
    # test assertion 1
    str_1 = 'value'
    dict_1 = {}
    validation_1 = Validation(str_1, dict_1)
    lazy_1 = validation_1.to_lazy()
    assert str_1 == lazy_1.value()



# Generated at 2022-06-26 00:21:35.563280
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    assert validation_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:21:38.629624
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()

# Generated at 2022-06-26 00:21:41.853815
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # I object lazy_0
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:21:46.855963
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    maybe_0 = lazy_0.map(lambda value: value != None)
    assert maybe_0.is_just()


# Generated at 2022-06-26 00:21:55.866126
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    str_0 = "string"
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    boolean_0 = lazy_0 is not None
    str_1 = "Lazy is not None"
    boolean_1 = boolean_0 is True
    assert boolean_1 is True, "{0}".format(str_1)
    boolean_0 = lazy_0.is_forced()
    boolean_1 = boolean_0 is False
    str_1 = "Lazy is not forced"
    assert boolean_1 is True, "{0}".format(str_1)
    boolean_0 = lazy_0.is_successful()
    boolean_1 = boolean_0 is True
    str_1 = "Lazy is successful"

# Generated at 2022-06-26 00:22:03.644397
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    # Create valid data
    str_0 = 'test_value'
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)

    # Call method
    lazy_0 = validation_0.to_lazy()

    # Test results
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.resolve() == str_0


# Generated at 2022-06-26 00:22:08.219177
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    str_0 = "test"
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = "test"
    assert str_1 == lazy_0()
    str_2 = "test"
    try_0 = Try(str_2, True)
    lazy_1 = try_0.to_lazy()
    str_3 = "test"
    assert str_3 == lazy_1()
    box_0 = Box("text")
    lazy_2 = box_0.to_lazy()
    str_4 = "text"
    assert str_

# Generated at 2022-06-26 00:22:11.751146
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for Validation.to_lazy()"""

    # Define test data
    validation_0 = Validation(None, {})

    # Run tested method
    result = validation_0.to_lazy()

    # Asserts
    assert isinstance(result, Lazy)



# Generated at 2022-06-26 00:22:15.407810
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy = validation_0.to_lazy()
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:17.821929
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('John Doe').to_lazy().run() == 'John Doe'
    assert Validation.fail(['some errors']).to_lazy().run() is None


# Generated at 2022-06-26 00:22:43.008620
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'abc'
    dict_0 = {'abc': 'def', 'ghi': 42}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.is_defined()
    assert str_0 == lazy_0.value()
    lazy_1 = lazy_0.map(lambda s: s.upper())
    assert str_0 == lazy_0.value()
    assert str_0.upper() == lazy_1.value()
    lazy_2 = lazy_0.flat_map(lambda s: Lazy(lambda: s.upper()))
    assert str_0 == lazy_0.value()
    assert str_0.upper() == lazy_2.value()
    str_1 = 'def'
    lazy

# Generated at 2022-06-26 00:22:48.009766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    str_0 = "sample string"
    dict_0 = {str_0: str_0}
    validation_0 = Validation(str_0, dict_0)
    str_1 = "sample string"
    dict_1 = {str_1: str_1}
    validation_1 = Validation(str_0, dict_1)
    maybe_0 = validation_1.to_maybe()
    try_0 = validation_0.to_try()
    either_0 = validation_0.to_either()
    lazy_0 = validation_0.to_lazy()
   

# Generated at 2022-06-26 00:22:53.694276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Define and initialize arguments
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    # Execute method
    lazy_0 = validation_0.to_lazy()
    # Check result
    assert not hasattr(lazy_0, 'value')


# Generated at 2022-06-26 00:22:56.711550
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    function_0 = lazy_0.value

    assert str_0 == function_0()


# Generated at 2022-06-26 00:23:00.829054
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == str_0


# Generated at 2022-06-26 00:23:07.992521
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Case 0:
    # None, {}, Validation.success[None]
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    maybe_0 = validation_0.to_lazy()
    assert(maybe_0.value() == str_0)
    # Case 1:
    # "test_string", {"test_error": 0}, Validation.fail[None, {"test_error": 0}]
    str_0 = "test_string"
    dict_0 = {"test_error": 0}
    validation_0 = Validation(None, dict_0)
    maybe_0 = validation_0.to_lazy()
    assert(maybe_0.value() == None)
    # Case 2:
    # "test_string", {"test

# Generated at 2022-06-26 00:23:10.156004
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {'1': 1}
    validation_0 = Validation(str_0, dict_0)



# Generated at 2022-06-26 00:23:11.214723
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    #TODO
    pass


# Generated at 2022-06-26 00:23:12.606234
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('asdf').to_lazy().get() == 'asdf'



# Generated at 2022-06-26 00:23:19.464552
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # case for success validation
    value_0 = 'value_0'
    test_case_0 = Validation(value_0, {})

    ret_0 = test_case_0.to_lazy()
    assert isinstance(ret_0, Lazy)
    assert ret_0() == value_0

    # case for failed validation
    test_case_1 = Validation.fail([])

    ret_1 = test_case_1.to_lazy()
    assert isinstance(ret_1, Lazy)
    assert ret_1() == None



# Generated at 2022-06-26 00:23:54.363484
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    int_1 = lazy_0.call()
    assert int_0 == int_1


# Generated at 2022-06-26 00:23:56.758224
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(None, dict_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:23:59.303208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:24:03.067919
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    dict_0 = {1: list_0}
    validation_0 = Validation.success((None))
    validation_1 = Validation.success((None))
    validation_1.to_maybe()
    validation_0.to_lazy()
    validation_0.to_lazy()
    validation_1.to_lazy()



# Generated at 2022-06-26 00:24:07.896872
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    valid_0 = Validation.success('value_1')
    valid_0_to_lazy_result = valid_0.to_lazy()
    valid_0_to_lazy_result_lazy_unsafe = valid_0_to_lazy_result.lazy_unsafe()
    assert valid_0_to_lazy_result_lazy_unsafe == 'value_1'


# Generated at 2022-06-26 00:24:16.522842
# Unit test for method to_lazy of class Validation

# Generated at 2022-06-26 00:24:18.809526
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:24:22.118983
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    int_0 = lazy_0.value()
    assert int_0 == str_0


# Generated at 2022-06-26 00:24:26.065526
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = Lazy(lambda: str_0)
    lazy_0.is_successful()
    Maybe.just(str_0)
    Maybe.nothing()
    validation_0.to_lazy()



# Generated at 2022-06-26 00:24:33.836319
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Either

    def test_case_validation_0():
        bool_0 = bool()
        bool_1 = bool()
        bool_2 = bool()
        bool_3 = bool()
        bool_4 = bool()
        bool_5 = bool()
        bool_6 = bool()
        bool_7 = bool()
        bool_8 = bool()
        bool_9 = bool()
        bool_10 = bool()
        bool_11 = bool()
        bool_12 = bool()
        bool_13 = bool()
        bool_14 = bool()
        bool_15 = bool()
        bool_16 = bool()
        bool_17 = bool

# Generated at 2022-06-26 00:25:52.654263
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    print(validation_0.to_lazy())
    str_1 = None
    dict_1 = {}
    validation_1 = Validation(str_1, dict_1)
    print(validation_1.to_lazy())
    str_2 = None
    dict_2 = {}
    validation_2 = Validation(str_2, dict_2)
    print(validation_2.to_lazy())
    str_3 = None
    dict_3 = {}
    validation_3 = Validation(str_3, dict_3)
    print(validation_3.to_lazy())



# Generated at 2022-06-26 00:25:55.107043
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy = validation_0.to_lazy()
    assert lazy.run is None

# Generated at 2022-06-26 00:25:59.134141
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    int_0 = 1
    validation_0 = Validation.success(int_0)
    assert validation_0.to_lazy().get() == int_0

    validation_1 = Validation.fail([])
    assert validation_1.to_lazy().get() is None



# Generated at 2022-06-26 00:26:04.125726
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Test Case 1:
    str_0 = 'test_str_0'
    dict_0 = {"key_0": 'value_0', "key_1": 'value_1'}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = Lazy(lambda: str_0)
    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:26:05.941601
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)


# Generated at 2022-06-26 00:26:07.554296
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    x = Validation.success(2)
    y = x.to_lazy()
    z = y.value()

    assert x == z

# Generated at 2022-06-26 00:26:12.422322
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Arrange
    validation_0 = Validation(None, {})
    mocked_lazy = MagicMock()
    result = mocked_lazy()
    validation_0.to_lazy = mocked_lazy

    # Act
    result = validation_0.to_lazy()

    # Assert
    mocked_lazy.assert_called_once()
    assert result == result


# Generated at 2022-06-26 00:26:20.168909
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, LazyCall
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    # test case 0
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)

    lazy_0 = validation_0.to_lazy()
    assert lazy_0.is_value() == False
    assert lazy_0.is_call() == False
    assert lazy_0.is_exception() == False

    # test case 1
    str_1 = 'abc'
    dict_1 = {'1': 1}
    validation_1 = Validation(str_1, dict_1)
    lazy_1 = validation_1.to_lazy()

# Generated at 2022-06-26 00:26:22.877246
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0[0]()


# Generated at 2022-06-26 00:26:26.776931
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = None
    dict_0 = {}
    validation_0 = Validation(str_0, dict_0)
    expected = Lazy(lambda: str_0)
    actual = validation_0.to_lazy()
    assert expected == actual
