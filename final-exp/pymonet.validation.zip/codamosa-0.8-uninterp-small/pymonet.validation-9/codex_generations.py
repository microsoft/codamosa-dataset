

# Generated at 2022-06-26 00:18:31.796746
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    any_type = '\n    Data type for storage any type of data\n    '
    float_type = 3072.8401
    validation = Validation(any_type, float_type)
    result = validation.to_lazy()
    assert True == isinstance(result, (pymonet.lazy.Lazy))

# Generated at 2022-06-26 00:18:35.500790
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)

    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:41.817382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    val = Validation.fail()
    assert val.to_lazy().eval() == None
    assert val.to_lazy().is_success == False

    val = Validation.fail([1,2,3])
    assert val.to_lazy().eval() == None
    assert val.to_lazy().is_success == False

    val = Validation.success(1)
    assert val.to_lazy().eval() == 1
    assert val.to_lazy().is_success == True


# Generated at 2022-06-26 00:18:51.251914
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    value = '\n    Data type for storage any type of data\n    '
    errors = 3072.8401
    validation_0 = Validation(value, errors)
    lazy_0 = Lazy(lambda: '\n    Data type for storage any type of data\n    ')
    lazy_1 = validation_0.to_lazy()
    assert_equals(lazy_0, lazy_1)


# Generated at 2022-06-26 00:18:53.242027
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.list import List
    from pymonet.lazy import Lazy

# Generated at 2022-06-26 00:18:58.904850
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.unwrap() == str_0


# Generated at 2022-06-26 00:19:03.825601
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    try:
        test_case_0()
    except Exception as e:
        _ = e


# Generated at 2022-06-26 00:19:10.285742
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()

    def assert_lazy_0():
        return str_0

    func_name = assert_lazy_0.__name__
    assert func_name == '\n    Data type for storage any type of data\n    '

    assert lazy_0.value == assert_lazy_0


# Generated at 2022-06-26 00:19:22.982252
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    float_0 = 3072.8401
    validation_0 = Validation(float_0, float_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.bind(lambda x: Lazy(lambda: x * 3).bind(lambda y: Lazy(lambda: y ** 3)))
    lazy_2 = lazy_1.bind(lambda x: Lazy(lambda: x ** 3))
    lazy_3 = lazy_2.bind(lambda x: Lazy(lambda: x ** 3))
    lazy_4 = lazy_3.bind(lambda x: Lazy(lambda: x ** 3))
   

# Generated at 2022-06-26 00:19:27.945248
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    str_1 = validation_0.to_lazy()
    str_2 = str_1.value()
    assert str_2 == str_0, 'Value should be equal'


# Generated at 2022-06-26 00:19:34.075598
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    key = validation_0
    lazy_0 = validation_0.to_lazy()
    function_0 = lazy_0.value
    result = function_0()
    assert result == str_0, \
        'Expected %s, got %s' % (str_0, result)


# Generated at 2022-06-26 00:19:42.142371
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    val_0 = lazy_0.value
    str_1 = val_0
    assert str_1 == str_0


# Generated at 2022-06-26 00:19:52.383344
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation_0 = Validation.success(3072.8401)
    print(validation_0)
    validation_1 = Validation.success(validation_0)
    print(validation_1)
    validation_2 = Validation.fail('\n    Data type for storage any type of data\n    ', validation_1)
    print(validation_2)
    validation_3 = Validation.fail(['\n    Data type for storage any type of data\n    '], validation_2)
    print(validation_3)

    lazy_0 = validation_0.to_lazy()
    print(lazy_0)
    lazy_1 = validation_1.to_lazy()
    print(lazy_1)
    lazy_2 = validation_2.to_lazy()

# Generated at 2022-06-26 00:19:55.981659
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    float_0 = 3072.8401
    validation_0 = Validation(float_0)

    lazy_0 = test_Validation_to_lazy()

    assert lazy_0.get() == float_0


# Generated at 2022-06-26 00:20:01.710583
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = Lazy(lambda: str_0)


# Generated at 2022-06-26 00:20:10.231623
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-26 00:20:14.209677
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == str_0


# Generated at 2022-06-26 00:20:18.423485
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    obj_0 = validation_0.to_lazy()
    assert obj_0 is not None



# Generated at 2022-06-26 00:20:24.001456
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import io

    # Setup
    str_1 = '\n    Data type for storage any type of data\n    '
    float_1 = 3072.8401
    validation_1 = Validation(str_1, float_1)
    expected_1 = Lazy(lambda: '\n    Data type for storage any type of data\n    ')

    # Invocation
    real_1 = validation_1.to_lazy()

    # Verification
    assert real_1 == expected_1



# Generated at 2022-06-26 00:20:34.052912
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.bind(lambda value: Lazy(lambda: value.value))
    str_1 = lazy_1.bind(lambda value: Lazy(lambda: value.value()))
    lazy_2 = lazy_1.bind(lambda value: Lazy(lambda: value.bind(lambda value: Lazy(lambda: value.value))))
    str_2 = lazy_2.value().value()
    lazy_3 = lazy_0.bind(lambda value: Lazy(lambda: value.errors))

# Generated at 2022-06-26 00:20:39.010137
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success()
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)



# Generated at 2022-06-26 00:20:41.305692
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    if lazy_0.get() != str_0:
        raise Exception('Validation.to_lazy[0] failed')


# Generated at 2022-06-26 00:20:44.455978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    box = Validation.success('box').to_lazy()
    assert isinstance(box, Lazy)

    box_2 = Validation.fail('fail').to_lazy()
    assert isinstance(box_2, Lazy)



# Generated at 2022-06-26 00:20:49.594554
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    from pymonet.lazy import Lazy
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-26 00:20:53.138461
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:20:59.827042
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    result = validation_0.to_lazy()
    assert isinstance(result, Lazy)
    result_0 = result.value()
    assert str_0 == result_0
    float_1 = float(float_0)
    float_2 = float(float_1)
    float_3 = float(float_2)
    float_4 = float(float_3)
    float_5 = float(float_4)
    float_6 = float(float_5)

# Generated at 2022-06-26 00:21:08.695411
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy as Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    # case (1)
    validation_0 = Validation.success()
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value == Box(None)
    assert lazy_0.is_success() == Try(Box(None)).is_success()
    lazy_1 = validation_0.to_lazy(validation_0)
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value == Box(None)
    assert lazy_1.is_success() == Try(Box(None)).is_success

# Generated at 2022-06-26 00:21:14.110910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)

    from pymonet.lazy import Lazy

    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-26 00:21:20.197133
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    empty_str = ""
    empty_str_lazy = Lazy(empty_str)
    str_to_int_lazy = Lazy(int, empty_str)
    f1 = Validation(empty_str_lazy, str_to_int_lazy)
    f1_to_lazy = f1.to_lazy()
    assert isinstance(f1_to_lazy, Lazy), "to_lazy returns not Lazy type"


# Generated at 2022-06-26 00:21:29.457723
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Monad'
    validation_0 = Validation(float(0), str_0)
    lazy_0 = validation_0.to_lazy()
    float_0 = float(0)
    float_1 = float(1)
    float_2 = float(2)
    float_3 = float(3)
    float_4 = float(4)
    float_5 = float(5)
    float_6 = float(6)
    float_7 = float(7)
    float_8 = float(8)
    float_9 = float(9)
    float_10 = float(10)
    float_11 = float(11)
    float_12 = float(12)
    float_13 = float(13)
    float_14 = float(14)

# Generated at 2022-06-26 00:21:40.726101
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Prepare a test input
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    # Perform Unit test execution
    result = validation_0.to_lazy()


# Generated at 2022-06-26 00:21:46.571762
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.eval() == str_0


# Generated at 2022-06-26 00:21:53.218004
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0._value(
    ) == '\n    Data type for storage any type of data\n    '
    validation_1 = Validation.fail(float_0)
    lazy_1 = validation_1.to_lazy()
    assert lazy_1._value() == 3072.8401


# Generated at 2022-06-26 00:21:58.249638
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.evaluate() == str_0



# Generated at 2022-06-26 00:22:06.686451
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.maybe import Maybe


# Generated at 2022-06-26 00:22:13.208457
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # It's impossible to compare lazies
    # so we will just instantiate a lazy validation and
    # check the side effect
    str_0 = '\n    Data type for storage any type of data\n    '

    def side_effect_0():
        print(str_0)

    lazy_0 = Validation.success(str_0).to_lazy()

    # Asserts
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.eval(side_effect_0) == str_0
    assert lazy_0.is_success()


# Generated at 2022-06-26 00:22:17.241423
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == lazy_0


# Generated at 2022-06-26 00:22:26.367114
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == str_0
    str_1 = '\n    Data type for storage any type of data\n    '
    float_1 = 3072.8401
    validation_1 = Validation(str_1, float_1)
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.value() == str_1
    str_2 = '\n    Data type for storage any type of data\n    '
    float_2 = 3072.8401

# Generated at 2022-06-26 00:22:37.089137
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    global str_0
    str_0 = '\n    Data type for storage any type of data\n    '
    global float_0
    float_0 = 3072.8401
    global validation_0
    validation_0 = Validation(str_0, float_0)
    global lazy_0
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == str_0

if __name__ == '__main__':
    test_case_0()
    test_Validation_to_lazy()

# Generated at 2022-06-26 00:22:42.932761
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy

    validation_0 = Validation.success(89)
    f = Functor(validation_0)
    assert f == validation_0
    m = Monad(validation_0)
    assert m == validation_0
    assert validation_0.to_lazy() == Lazy(lambda: 89)


# Generated at 2022-06-26 00:23:00.940934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '    Data type for storage any type of data'
    float_0 = 0.0
    validation_0 = Validation(str_0, float_0)
    assert validation_0.to_lazy() == Lazy(lambda: '    Data type for storage any type of data')


# Generated at 2022-06-26 00:23:08.046789
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_instance_of(Monad)
    assert lazy_0.is_instance_of(Either)
    assert lazy_0.is_instance_of(Maybe)

# Generated at 2022-06-26 00:23:13.890769
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success(3)
    validation_1 = Validation.fail(['test'])
    box_0 = validation_0.to_lazy()
    box_1 = validation_1.to_lazy()
    assert validation_0.value == box_0.get()
    assert validation_1.value is None and validation_1.errors == box_1.get()


# Generated at 2022-06-26 00:23:18.042186
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    expected_result = Lazy(lambda: str_0)
    assert validation_0.to_lazy() == expected_result


# Generated at 2022-06-26 00:23:21.609841
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value == str_0


# Generated at 2022-06-26 00:23:25.724763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_1 = Validation(str_0, float_0)
    lazy_0 = validation_1.to_lazy()
    assert(isinstance(lazy_0, Lazy))


# Generated at 2022-06-26 00:23:33.559605
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_8 = '\n    Lazy monad for storing values as functions without arguments\n    '
    float_5 = 2835.31
    str_7 = '\n    Data type for storage any type of data\n    '
    float_4 = 4590.93
    float_3 = 0.62
    str_3 = '\n    Maybe class for storing values or nothing\n    '
    float_2 = 6394.6
    float_1 = 9862.1
    str_2 = '\n    Data type for storage any type of data\n    '
    float_0 = 7113.05
    validation_1 = Validation(str_2, float_0)
    validation_2 = validation_1.to_lazy()
    validation_3 = Validation(str_3, float_1)


# Generated at 2022-06-26 00:23:38.895972
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy), 'Returned variable should be instance of monet lazy'


# Generated at 2022-06-26 00:23:43.768198
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)

    from pymonet.lazy import Lazy

    expected_0 = Lazy(lambda: str_0)
    actual_0 = validation_0.to_lazy()

    assert actual_0 == expected_0


# Generated at 2022-06-26 00:23:44.859034
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)


# Generated at 2022-06-26 00:24:18.001583
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test():
        str_0 = '\n    Data type for storage any type of data\n    '
        float_0 = 3072.8401
        validation_0 = Validation(str_0, float_0)
        validation_1 = validation_0.to_lazy()
        validation_2 = validation_1()
        assert isinstance(validation_1, Lazy)
        assert validation_2 == str_0


# Generated at 2022-06-26 00:24:21.220007
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.eval()


# Generated at 2022-06-26 00:24:24.071287
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:24:29.540691
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    maybe_int_0 = Validation.success(0)
    str_0 = '\n    Data type for storage any type of data\n    '
    maybe_int_1 = Validation.fail(str_0)

    assert maybe_int_0.to_lazy() == Lazy(lambda: 0)
    assert maybe_int_1.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:24:33.509366
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Data type for storage any type of data'
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)

    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == str_0


# Generated at 2022-06-26 00:24:38.795888
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.fail()
    lazy_0 = validation_0.to_lazy()
    lazy_1 = Validation.success('Lazy').to_lazy()
    lazy_2 = Validation.success(Lazy(lambda: 2)).to_lazy()

    assert lazy_0.force() == None
    assert lazy_1.force() == 'Lazy'
    assert lazy_2.force() == 2


# Generated at 2022-06-26 00:24:44.359826
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    to_lazy_0 = Validation(str_0, float_0).to_lazy()
    assert isinstance(to_lazy_0, Lazy)
    to_lazy_1 = to_lazy_0.get()
    assert to_lazy_1 == str_0
    assert to_lazy_0.is_same(to_lazy_0)
    test_case_0()


# Generated at 2022-06-26 00:24:52.402418
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    class Test:
        @staticmethod
        def test_f0():
            validation_0 = Validation.success(10)
            lazy_0 = validation_0.to_lazy()
            assert lazy_0._value() == 10
            lazy_1 = Validation(None, 5).to_lazy()
            assert lazy_1._value() == None
        @staticmethod
        def test_f1():
            validation_0 = Validation(None, 5)
            lazy_0 = validation_0.to_lazy()
            assert lazy_0._value() == None
        @staticmethod
        def test_f2():
            validation_0 = Validation.fail(10)
            lazy_0 = validation_0.to_lazy()
            assert lazy_0._value() == None


# Generated at 2022-06-26 00:24:55.469326
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 4
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:24:59.454077
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 3072.8401
    str_0 = '\n    Data type for storage any type of data\n    '
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.fmap(lambda _: 'Context handler')
    str_1 = lazy_1.force()



# Generated at 2022-06-26 00:26:06.492672
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_location import Location
    from pymonet.monad_state import State

# Generated at 2022-06-26 00:26:10.370008
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    str_1 = validation_0.to_lazy()
    float_1 = float_0



# Generated at 2022-06-26 00:26:15.503284
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Initialization
    str_0 = 'Lazy(function() -> (A | None))'
    lazy_0 = Lazy(str_0)
    float_0 = 1088.6176
    validation_0 = Validation(str_0, float_0)

    # Execution
    lazy_1 = validation_0.to_lazy()

    # Assertion
    assert lazy_0 == lazy_1, 'Wrong lazy monad returned by method to_lazy'



# Generated at 2022-06-26 00:26:21.268285
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '#*'
    float_0 = 449.18
    validation_0 = Validation(str_0, float_0)

    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == str_0

    str_1 = 'I6U'
    float_1 = 598.21
    validation_1 = Validation(str_1, float_1)

    lazy_1 = validation_1.to_lazy()
    assert lazy_1.get() == str_1


# Generated at 2022-06-26 00:26:29.521650
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    assert validation_0.to_lazy().value() is str_0
    str_1 = '= w\x15\xdf\x18\xf6'
    float_1 = 9160.43
    validation_1 = Validation(str_1, float_1)
    assert validation_1.to_lazy().value() is str_1
    str_2 = 'Description: $h = gcd_n(a, b, c, ...) = gcd(gcd(a, b), c, ...)$\n'
    float_2 = 561.84

# Generated at 2022-06-26 00:26:33.946386
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def positive_predicate(x):
        return x > 0

    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)

    lazy_0 = validation_0.to_lazy()
    assert type(lazy_0) == Lazy
    assert lazy_0.value() == str_0


# Generated at 2022-06-26 00:26:37.892842
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'б\tы\nг\rы\x00\x0A\x0D\x20\x7F\x85'
    float_0 = 12.36
    validation_1 = Validation.fail(str_0)
    validation_2 = Validation.success(float_0)
    lazy_0 = validation_1.to_lazy()
    lazy_1 = validation_2.to_lazy()


# Generated at 2022-06-26 00:26:42.572925
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n    Data type for storage any type of data\n    '
    float_0 = 3072.8401
    validation_0 = Validation(str_0, float_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.get()
    assert str_1 == str_0

if __name__ == "__main__":
    test_case_0()
    test_Validation_to_lazy()

# Generated at 2022-06-26 00:26:43.354717
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()


# Generated at 2022-06-26 00:26:45.946699
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    lazy = Validation(31, ['Error']).to_lazy()
    assert lazy == Lazy(lambda: 31)

