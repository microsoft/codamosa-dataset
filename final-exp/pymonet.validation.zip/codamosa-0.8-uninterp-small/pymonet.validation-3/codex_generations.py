

# Generated at 2022-06-26 00:18:31.439464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test for function Validation.to_lazy
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert (lazy_0.force() == str_0)


# Generated at 2022-06-26 00:18:36.251893
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert validation_0.value == lazy_0.get()


# Generated at 2022-06-26 00:18:42.503289
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from tests.lazy_test import test_lazy_case_0

    test_case_0()
    lazy_case_0 = test_lazy_case_0()
    validation_0 = Validation.success(lazy_case_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.__eq__(lazy_case_0)



# Generated at 2022-06-26 00:18:54.070944
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    val_0 = Validation('hello', [])
    val_1 = Validation(None, ['error'])

    res_0 = val_0.to_lazy()
    res_1 = val_1.to_lazy()

    assert (isinstance(res_0, Lazy))
    assert (isinstance(res_1, Lazy))

    assert (res_0.run() == val_0.value)
    assert (res_1.run() == val_1.value)


# Generated at 2022-06-26 00:18:57.785289
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)



# Generated at 2022-06-26 00:19:06.389809
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_1 = Validation.success('string')
    lazy_1 = validation_1.to_lazy()
    test_1 = lazy_1.is_lazy()
    test_2 = isinstance(lazy_1.value, Lazy)
    test_3 = lazy_1.is_lazy()

    assert isinstance(lazy_1, Lazy)
    assert test_1
    assert test_2
    assert test_3
    assert lazy_1.value().value == 'string'


# Generated at 2022-06-26 00:19:08.690624
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.f()
    assert str_0 == str_1

if __name__ == '__main__':  # pragma: no cover
    test_case_0()

# Generated at 2022-06-26 00:19:12.462102
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.monad_lazy import Lazy

    assert Validation.success(23).to_lazy() == Lazy(23)
    assert Validation.fail('error').to_lazy() == Lazy(None)


# Generated at 2022-06-26 00:19:22.249215
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    test_case_0()

    lazy_0 = Validation.success('Lazy[T, W]').to_lazy()
    assert type(lazy_0) is Lazy
    assert lazy_0.run() == 'Lazy[T, W]'

    lazy_0 = Validation.fail('Lazy[T, W]').to_lazy()
    assert type(lazy_0) is Lazy
    assert lazy_0.run() is None


# Generated at 2022-06-26 00:19:25.737449
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation."""
    str_0 = 'Lazy[T, W]'
    lazy_0 = Validation(str_0, str_0).to_lazy()
    assert lazy_0.value() is str_0


# Generated at 2022-06-26 00:19:30.226318
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('foo').to_lazy().force() == 'foo'
    assert Validation.fail('foo').to_lazy().force() is None


# Generated at 2022-06-26 00:19:35.118116
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.success(None).to_lazy().get() is None

    assert Validation.fail(errors=['foo']).is_fail()
    assert Validation.fail(errors=['foo']).to_lazy().get() is None


# Generated at 2022-06-26 00:19:41.066595
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    str_0 = 'Lazy[T, W]'
    val_0 = Validation.success('lazy')

    # assertion
    assert str(val_0.to_lazy()) == str_0


# Generated at 2022-06-26 00:19:46.942774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Check Successful Validation
    val_0 = Validation.success('Lazy[T, W]')
    # call method
    val_1 = val_0.to_lazy()
    # Ensure that returned value is Lazy
    assert isinstance(val_1, Lazy)
    # Ensure that returned value is Lazy with function returning value of successful Validation
    assert val_1.fn() == val_0.value


# Generated at 2022-06-26 00:19:54.094228
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    print('test_Validation_to_lazy')

    # test_Validation_to_lazy_0
    str_0 = 'Lazy[T, W]'

    validation_0 = Validation('T', 'W')
    lazy = validation_0.to_lazy()

    assert isinstance(lazy, Lazy)
    assert str(lazy) == str_0

    print('unit test for method to_lazy of Validation is OK')



# Generated at 2022-06-26 00:19:58.187768
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # It takes as a parameter function returning another Validation.
    # Function is called with Validation value and returns new Validation with previous value
    # and concated new and old errors.
    validation = Validation(None, [])
    result = validation.to_lazy()
    assert result.evaluate() is None

# Generated at 2022-06-26 00:20:03.925759
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    unit_value = Box(1)
    assert Validation.success(unit_value).to_lazy() == Lazy(lambda: unit_value)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:20:06.837598
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.success(1).to_lazy()) == 'Lazy[T, W]'
    assert str(Validation.fail(1).to_lazy()) == 'Lazy[T, W]'


# Generated at 2022-06-26 00:20:12.870358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def lazy_factory(value):
        return Lazy(lambda: value)

    tests = [
        (Validation.success(1), lazy_factory(1)),
        (Validation.success(-1), lazy_factory(-1)),
        (Validation.success(1000), lazy_factory(1000)),
        (Validation.fail(['errors']), lazy_factory(None)),
    ]

    for validation, lazy in tests:
        assert validation.to_lazy() == lazy


# Generated at 2022-06-26 00:20:17.252605
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def fn(val):
        from pymonet.monad_try import Try
        return Try(val)

    val = Validation.success(1)
    assert val.to_lazy() == Lazy(fn(val))

# Generated at 2022-06-26 00:20:22.157031
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test method to_lazy of class Validation."""
    from pymonet.lazy import Lazy

    assert Validation.success(str_0).to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:20:24.711039
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail('Error').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:20:32.960322
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    ## m_0 = Validation.fail([1])
    ## m_1 = m_0.to_lazy()

    ## s_0 = m_1._value()
    ## eq_1 = (s_0, None)
    ## eq_2 = eq_1

    ## s_1 = eq_2

    ## eq_3 = (s_1, None)
    ## eq_4 = eq_3

    ## eqs_2 = eq_4
    ## eqs_3 = eqs_2

    a_0 = 1
    ## eqs = eqs_3

    ## return eqs
    return a_0


# Generated at 2022-06-26 00:20:42.410208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Lazy[T, W]'

    # Empty errors
    actual_0 = Validation.success(str_0).to_lazy()
    expected_0 = Lazy(lambda: str_0)
    assert_equal(actual_0, expected_0)

    actual_1 = Validation.fail().to_lazy()
    expected_1 = Lazy(lambda: None)
    assert_equal(actual_1, expected_1)


# Generated at 2022-06-26 00:20:46.776830
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val_0 = Validation.success('success value')
    val_1 = Validation.fail('fail value')

    assert val_0.to_lazy() == Lazy(lambda: 'success value')
    assert val_1.to_lazy() == Lazy(lambda: 'fail value')


# Generated at 2022-06-26 00:20:49.212439
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(1)

    result = val.to_lazy()
    expected = Lazy(lambda: 1)

    assert result == expected


# Generated at 2022-06-26 00:20:57.816348
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    # Test: Map
    # Monad: Validation[Any, Any]
    # Function: Function(A) -> Lazy[Any, Any]
    # Result: Validation[A, Any]
    result = Validation.success(1).map(lambda x: Lazy(lambda: x)).to_box().get_or(10)
    if result != 1:
        raise AssertionError(
            "Expected: {}, Actual: {}".format(1, result))

    # Test: Bind
    # Monad: Validation[Any, Any]
    # Function: Function(A) -> Lazy[Any, Any]
    # Result: Validation[A, Any]

# Generated at 2022-06-26 00:21:01.861730
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Lazy[T, W]'

    assert Validation.success(str_0).to_lazy() == Lazy(lambda: str_0)

    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:05.249065
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation('lazy', []) == Validation.success('lazy').to_lazy().map(lambda fn: fn()).to_validation()


# Generated at 2022-06-26 00:21:09.333968
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Arrange
    val = Validation(lambda x: x + 1, [])

    # Act
    lazy = val.to_lazy()

    # Assert
    assert lazy == Lazy(lambda: lambda x: x + 1)
    assert lazy.force()(1) == 2

# Generated at 2022-06-26 00:21:18.130428
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('Lazy[T, W]')
    lazy = validation.to_lazy()
    assert lazy.is_lazy() == True
    assert lazy.value() == 'Lazy[T, W]'
    assert lazy.errors == []

    validation = Validation.fail(['Error_1', 'Error_2'])
    lazy = validation.to_lazy()
    assert lazy.is_lazy() == True
    assert lazy.value() == None
    assert lazy.errors == ['Error_1', 'Error_2']

# Generated at 2022-06-26 00:21:24.003449
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Lazy[T, W]'
    str_1 = 'Lazy[T, W]'

    # lazy is Lazy,
    lazy = Lazy(lambda: str_0)

    # value is str.
    value = str_1

    # validation is Validation[str, []].
    validation = Validation(value, [])

    # lazy_0 is Lazy[str, str].
    lazy_0 = validation.to_lazy()

    assert lazy == lazy_0

# Generated at 2022-06-26 00:21:26.471382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    assert (Validation.success('test').to_lazy() == Lazy.just(str_0))


# Generated at 2022-06-26 00:21:31.226355
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success('Lazy[T, W]')
    validation_1 = Validation.fail()

    lazy_0 = validation_0.to_lazy()
    assert lazy_0() == 'Lazy[T, W]'
    lazy_1 = validation_1.to_lazy()
    assert lazy_1() == None


# Generated at 2022-06-26 00:21:36.783175
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success('Lazy[T, W]')
    expected_to_lazy_0 = Lazy(lambda: validation_0.value)
    actual_to_lazy_0 = validation_0.to_lazy()

    if actual_to_lazy_0 == expected_to_lazy_0:
        print("PASS")
    else:
        print("FAIL")



# Generated at 2022-06-26 00:21:38.977561
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(str_0).to_lazy()
    assert result == Lazy[str_0]


# Generated at 2022-06-26 00:21:41.450412
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(str_0)
    lazy = validation_0.to_lazy()
    assert lazy.value() == str_0


# Generated at 2022-06-26 00:21:46.496560
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-26 00:21:51.243367
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('to_lazy -> Lazy[T, W]')
    # Create Validation
    v_0 = Validation.success(1)
    actual = v_0.to_lazy()
    # Create expected Lazy
    from pymonet.lazy import Lazy
    expected = Lazy(lambda: 1)
    # Compare Lazy from Validation and expected Lazy
    assert actual == expected

test_case_0()

# Generated at 2022-06-26 00:21:56.297108
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.__value__() == str_0


# Generated at 2022-06-26 00:22:08.416881
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_validation import Validation

    result = Validation.success().to_lazy()

    assert isinstance(result, Lazy)
    assert callable(result.value)
    assert result.value() is None

    result = Validation.success(1).to_lazy()

    assert isinstance(result, Lazy)
    assert callable(result.value)
    assert result.value() == 1

    result = Validation.fail().to_lazy()

    assert isinstance(result, Lazy)
    assert callable(result.value)
    assert result.value() is None

    result = Validation.fail([1, 2, 3]).to_lazy()

    assert isinstance(result, Lazy)
    assert callable

# Generated at 2022-06-26 00:22:17.019277
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Assertion with string
    assert Validation(str_0, []).to_lazy() == Lazy(lambda: str_0)

    # Assertion with integer
    assert Validation(int_0, []).to_lazy() == Lazy(lambda: int_0)

    # Assertion with float
    assert Validation(float_0, []).to_lazy() == Lazy(lambda: float_0)

    # Assertion with double
    assert Validation(double_0, []).to_lazy() == Lazy(lambda: double_0)

    # Assertion with boolean
    assert Validation(bool_0, []).to_lazy() == Lazy(lambda: bool_0)

    # Assertion with function
    assert Validation(function_0, []).to_lazy()

# Generated at 2022-06-26 00:22:20.768330
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success_val = Validation.success(str_0)
    lazy = success_val.to_lazy()
    assert lazy.resolve() == 'Lazy[T, W]'

    fail_val = Validation.fail()
    lazy = fail_val.to_lazy()
    assert lazy.resolve() is None


# Generated at 2022-06-26 00:22:27.463321
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result_0 = Validation.success(5).to_lazy()
    expected_0 = Lazy(lambda: 5)
    assert expected_0 == result_0

    result_1 = Validation.fail([]).to_lazy()
    expected_1 = Lazy(lambda: None)
    assert expected_1 == result_1

    result_2 = Validation.success('test').to_lazy()
    expected_2 = Lazy(lambda: 'test')
    assert expected_2 == result_2


# Generated at 2022-06-26 00:22:34.394503
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success('value')
    val_to_lazy = val.to_lazy()

    assert val_to_lazy.value() == 'value'
    assert val_to_lazy.is_value()
    assert not val_to_lazy.is_exception()


# Generated at 2022-06-26 00:22:36.715868
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    string = 'Lazy[T, W]'
    res = Validation.success(string).to_lazy()
    assert isinstance(res, Lazy)



# Generated at 2022-06-26 00:22:40.056553
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    case_0 = Validation.success(str_0)
    assert isinstance(case_0.to_lazy(), Lazy)

    case_1 = Validation.success(str_1)
    assert isinstance(case_1.to_lazy(), Lazy)


# Generated at 2022-06-26 00:22:50.146418
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('test_Validation_to_lazy')

    from pymonet.lazy import Lazy

    val_0 = Validation.success(14)
    val_1 = Validation.fail(['error1', 'error2'])

    assert val_0.to_lazy().value() == 14
    assert val_1.to_lazy().value() == None

    assert val_0.to_lazy() == Lazy(lambda: 14)
    assert val_1.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:54.495772
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Simple usage, set of methods and attributes
    validation = Validation.success('a')
    lazy = validation.to_lazy()

    assert lazy.force() == 'a'
    assert repr(lazy) == 'Lazy[Function() -> a]'


# Generated at 2022-06-26 00:22:58.522808
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        from pymonet.lazy import Lazy
        from pymonet.validation import Validation

        def str_0():
            return 'Lazy[T, W]'

        str_0_validation = Validation.success(str_0)
        lazy_0_validation = Lazy(str_0)

        assert str_0_validation.to_lazy() == lazy_0_validation

    test_case_0()


# Generated at 2022-06-26 00:23:04.072636
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

# Generated at 2022-06-26 00:23:12.158500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Case 1: Successful Validation.
    test_value_0 = [
        Lazy(lambda: 'Lazy[A, W]')
    ]

    validation = Validation.success(test_value_0)
    result = validation.to_lazy()

    assert result == Lazy(lambda: test_value_0)

    # Case 2: Failed Validation.
    test_value_1 = None
    test_value_2 = [
        Try(1, is_success=True),
        Try(2, is_success=False)
    ]

    validation = Validation.fail(test_value_1)
    result = validation.to_lazy()


# Generated at 2022-06-26 00:23:15.275222
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validate_0 = Validation(
        'Lazy[T, W]',
        []
    )
    assert validate_0.to_lazy() == Lazy('Lazy[T, W]')


# Generated at 2022-06-26 00:23:17.217038
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success('T')
    assert validation.to_lazy() == Lazy(lambda: 'T')


# Generated at 2022-06-26 00:23:23.034470
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    # Test 0
    validation_0 = Validation.success(3)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == 3

    # Test 1
    validation_1 = Validation.success()
    lazy_1 = validation_1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.value() == None


# Generated at 2022-06-26 00:23:25.689697
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('Lazy[T, W]').to_lazy().get() == 'Lazy[T, W]'
    assert Validation.fail(['Error']).to_lazy().get() == None


# Generated at 2022-06-26 00:23:28.646465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validate_0 = Validation.success()
    validate_1 = Validation.fail()
    assert validate_0.to_lazy() == Lazy(lambda: None)
    assert validate_1.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:31.622208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    string_0 = 'Lazy[T, W]'
    validation_0 = Validation.success(string_0)
    lazy_0 = Lazy(lambda: string_0)
    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:23:39.105289
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    log = []
    str_0 = Validation.success('Lazy[T, W]').to_lazy().eval()
    log.append(str_0)
    str_1 = Validation.success('Lazy[T, W]').to_lazy().map(lambda x: x + '0').eval()
    log.append(str_1)
    str_2 = Validation.fail(['Error']).to_lazy().eval()
    log.append(str_2)
    assert log == ['Lazy[T, W]', 'Lazy[T, W]0', None]

#Unit test for method to_try of class Validation

# Generated at 2022-06-26 00:23:45.722728
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for to_lazy"""
    from pymonet.monad_maybe import Maybe, Nothing
    from pymonet.monad_lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(Maybe.just(1)).to_lazy() == Lazy(lambda: Maybe.just(1))


# Unit tests for method to_maybe of class Validation

# Generated at 2022-06-26 00:23:53.538624
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_0 = Lazy('test')
    validation_0 = Validation('lazy', 'lazy_fail').to_lazy()

    assert validation_0 == lazy_0
    assert validation_0.is_instance(Lazy) is True


# Generated at 2022-06-26 00:23:57.239797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation.success('Lazy[T, W]')
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == Lazy(lambda: 'Lazy[T, W]')


# Generated at 2022-06-26 00:24:02.193000
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.monad import Monad, MonadZero
    from pymonet.monad_writer import Writer

    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-26 00:24:04.639965
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success('Lazy[T, W]')
    lazy_0 = validation_0.to_lazy()
    assert type(lazy_0) == Lazy
    assert lazy_0.value() == 'Lazy[T, W]'


# Generated at 2022-06-26 00:24:10.154083
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    validation_0.to_lazy()
    assert isinstance(validation_0.value, str)
    assert validation_0.value == str_0
    assert isinstance(validation_0.errors, str)
    assert validation_0.errors == str_0


# Generated at 2022-06-26 00:24:17.433857
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    class Case:
        def __init__(self, validation, expected_value):
            self.validation = validation
            self.expected_value = expected_value

    cases = [
        Case(Validation.success('success_value'), Lazy(lambda: 'success_value')),
        Case(Validation.fail(), Lazy(lambda: None)),
        Case(Validation.fail(['error']), Lazy(lambda: None)),
    ]

    def can_assert_case(case):
        assert case.validation.to_lazy() == case.expected_value

    list(map(can_assert_case, cases))


# Generated at 2022-06-26 00:24:23.403762
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy1 = validation_0.to_lazy()
    assert isinstance(lazy1, Lazy)
    assert lazy1.value() == str_0

    str_1 = ''
    validation_1 = Validation(str_1, str_1)
    lazy2 = validation_1.to_lazy()
    assert lazy2.value() is None



# Generated at 2022-06-26 00:24:31.319509
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Success, Failure

    def throw_error():
        raise ValueError('Error')

    valid = Validation.success()
    lazy_empty = valid.to_lazy()
    lazy_empty_evaluated = lazy_empty()
    assert lazy_empty_evaluated == None

    valid = Validation.success(1)
    lazy_value = valid.to_lazy()
    lazy_value_evaluated = lazy_value()
    assert lazy_value_evaluated == 1

    failure = Validation.fail(ValueError('Error'))
    lazy_exception = failure.to_lazy()
    lazy_exception_evaluated = lazy_exception()
    assert isinstance(lazy_exception_evaluated, Exception)

# Generated at 2022-06-26 00:24:34.558359
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # prepare
    str_0 = 'Lazy[T, W]'

    # action
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()

    # assert
    assert str_0 == lazy_0.value()


# Generated at 2022-06-26 00:24:38.716090
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()

    assert (isinstance(lazy_0, Lazy))
    assert (lazy_0.value == str_0)

# Generated at 2022-06-26 00:24:53.528863
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy, LazyWrapper
    from pymonet.monad_try import TryMonad

    try_monad = TryMonad(LazyWrapper(Lazy(lambda: 'Lazy[T, W]')))
    validation = try_monad.to_lazy()
    assert validation.to_lazy() == Lazy(lambda: 'Lazy[T, W]')


# Generated at 2022-06-26 00:24:55.991441
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()()
    assert lazy_0 == str_0



# Generated at 2022-06-26 00:24:59.118950
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)

    from pymonet.lazy import Lazy

    lazy_0 = Lazy(lambda: str_0)

    assert validation_0.to_lazy() == lazy_0



# Generated at 2022-06-26 00:25:01.624920
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = 'Lazy[T, W]'
    validation_1 = Validation(str_1, str_1)
    f_0 = validation_1.to_lazy().value
    assert str_1 == f_0()



# Generated at 2022-06-26 00:25:10.053075
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad import Monad, bind

    def mapper_0(value):
        return Try.just(value)

    def mapper_1(value):
        return Try(value, is_success=value)

    def mapper_2(value):
        try:
            return Try.just(value)
        except:
            return Try.fail()

    def mapper_3(value):
        try:
            return Lazy(lambda: value)
        except:
            return Try.fail()

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()

    assert lazy

# Generated at 2022-06-26 00:25:12.262022
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success("foo").to_lazy() == Lazy("foo"), "Wrong mapping"


# Generated at 2022-06-26 00:25:18.263871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, [])
    val_lazy = validation_0.to_lazy()
    assert val_lazy.value() == str_0



# Generated at 2022-06-26 00:25:26.078680
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    #
    assert Validation.success(10).to_lazy().flat_map(lambda a: Lazy(lambda: a + 10)) == Lazy(lambda: 20)
    assert Validation.fail().to_lazy().flat_map(lambda a: Lazy(lambda: a + 10)) == Lazy(lambda: None)
    #

# Generated at 2022-06-26 00:25:31.526187
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, [])
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.get()
    assert str_0 == str_1

# Generated at 2022-06-26 00:25:36.318477
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_1 = Validation.success('Success')
    validation_2 = Validation.success(123)
    validation_3 = Validation.success(45.67)

    assert validation_1.to_lazy().get_value() == 'Success'
    assert validation_2.to_lazy().get_value() == 123
    assert validation_3.to_lazy().get_value() == 45.67


# Generated at 2022-06-26 00:25:56.304750
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == Lazy(str_0)


# Generated at 2022-06-26 00:26:01.436911
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation(None, [])

    # call success Validation with empty errors
    assert val.to_lazy() == Lazy(lambda: None)

    val = Validation('value', ['error1', 'error2'])

    # call fail Validation with errors
    assert val.to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-26 00:26:07.376512
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation('validation_value', ['validation_error'])
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() == 'validation_value'

    validation_0 = Validation(None, ['validation_error'])
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.get() is None


# Generated at 2022-06-26 00:26:08.397641
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert validation_0.to_lazy()._f() == str_0


# Generated at 2022-06-26 00:26:15.267126
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation_str = Validation('test value', 'test errors')
    lazy_str_check = Lazy(lambda: 'test value')

    assert validation_str.to_lazy() == lazy_str_check

    validation_int = Validation(10, 'test errors')
    lazy_int_check = Lazy(lambda: 10)

    assert validation_int.to_lazy() == lazy_int_check

    validation_function = Validation(test_case_0, 'test errors')
    lazy_function_check = Lazy(lambda: 'test value')

    assert validation_function.to_lazy() == lazy_function_check


# Generated at 2022-06-26 00:26:20.189776
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # test case 0
    validation_0 = Validation.success('Lazy[T, W]')
    lazy_0 = validation_0.to_lazy()
    lazy_value_0 = lazy_0.value()

    assert lazy_value_0 == 'Lazy[T, W]'
    assert lazy_0 == Lazy(lambda: 'Lazy[T, W]')
    assert lazy_0.value() == 'Lazy[T, W]'


# Generated at 2022-06-26 00:26:22.567918
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    tried = Validation.success('Tried')
    assert isinstance(tried, Validation)
    lazy = tried.to_lazy()
    assert lazy.value == tried.value



# Generated at 2022-06-26 00:26:30.505490
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_list import List

    string = 'Lazy[T, W]'
    value = Maybe.just(string)
    lazy_0 = value.to_lazy()
    maybe_0 = lazy_0.to_maybe()
    assert maybe_0 == value

    try_0 = Try(string)
    lazy_1 = try_0.to_lazy()
    assert lazy_1.to_try() == try_0

    box = Box(string)
    lazy_2 = box.to_lazy()
    assert lazy_2.to_box() == box


# Generated at 2022-06-26 00:26:37.280556
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.applyable import Applyable
    from pymonet.monad_lazy import MonadLazy
    from pymonet.monad import Monad
    from pymonet.monad_try import MonadTry
    from pymonet.monad_either import MonadEither
    from pymonet.monad_maybe import MonadMaybe
    from pymonet.monad_list import MonadList

    with raises(TypeError):
        applyable = Applyable(None)
        applyable.to_lazy()

    with raises(TypeError):
        monad_lazy = MonadLazy(None)
        monad_lazy.to_lazy()

    with raises(TypeError):
        monad_try = MonadTry(None)
        monad_try.to_lazy()

   

# Generated at 2022-06-26 00:26:41.408536
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import get_monad_vars, set_monad_vars
    try:
        set_monad_vars(None, None)
        test_case_0()
        assert get_monad_vars() == (None, None)
    finally:
        set_monad_vars(None, None)

# Generated at 2022-06-26 00:27:24.929562
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, [])
    result_0 = validation_0.to_lazy()
    assert result_0 == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:27:29.894189
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    lazy_0 = Lazy(lambda: str_0)
    validation_0 = Validation(str_0, str_0)
    lazy_1 = validation_0.to_lazy()
    assert lazy_0 is not lazy_1
    assert lazy_0.value == lazy_1.value


# Generated at 2022-06-26 00:27:35.286949
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = Lazy(lambda: 'Hello')
    validation = Validation(value, [])
    result = validation.to_lazy()

    assert result == Lazy(lambda: value)
    assert result.value() == Lazy(lambda: 'Hello')


# Generated at 2022-06-26 00:27:41.933247
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def test_case_0():
        """
        Test for
        """

        def test_case_1():
            """
            Test for
            """
            result = Validation.success('result_1')
            expected = Lazy(lambda: 'result_1')
            assert result.to_lazy() == expected
        test_case_1()

        def test_case_2():
            """
            Test for
            """
            result = Validation.fail('result_1')
            expected = Lazy(lambda: None)
            assert result.to_lazy() == expected
        test_case_2()

    test_case_0()


# Generated at 2022-06-26 00:27:54.913799
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, 1).to_lazy() == Lazy(lambda: 1)
    assert Validation('a', 'b').to_lazy() == Lazy(lambda: 'a')
    assert Validation(['a', 'b'], ['a', 'b']).to_lazy() == Lazy(lambda: ['a', 'b'])
    assert Validation({'a': 1, 'b': 2}, {'a': 1, 'b': 2}).to_lazy() == Lazy(lambda: {'a': 1, 'b': 2})
    assert Validation(Validation(1, 1), Validation(1, 1)).to_lazy() == Lazy(lambda: Validation(1, 1))


# Generated at 2022-06-26 00:28:06.760639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.success('').to_lazy() == Lazy(lambda: '')
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success([]).to_lazy() == Lazy(lambda: [])
    assert Validation.success([1]).to_lazy() == Lazy(lambda: [1])
    assert Validation.success([1, 2]).to_lazy() == Lazy(lambda: [1, 2])
    assert Validation.success([]).to_lazy() == Lazy(lambda: [])

# Generated at 2022-06-26 00:28:11.104976
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.monad_maybe as maybe
    maybe_0 = maybe.Maybe.just(Validation.success(2))
    validation_maybe = maybe_0.bind(lambda x: x.to_lazy())
    assert validation_maybe.value() == 2



# Generated at 2022-06-26 00:28:14.915821
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0, validation_0 = 'Lazy[T, W]', Validation('Lazy[T, W]', 'Lazy[T, W]')
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.to_lazy()
    assert str_0 == lazy_1.unwrap()


# Generated at 2022-06-26 00:28:17.614474
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    assert Validation('Lazy[T, W]', 'Lazy[T, W]').to_lazy() == Lazy(lambda: 'Lazy[T, W]')


# Generated at 2022-06-26 00:28:20.498090
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy[T, W]'
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
