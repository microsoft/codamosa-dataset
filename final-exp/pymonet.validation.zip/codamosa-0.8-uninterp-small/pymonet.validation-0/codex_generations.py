

# Generated at 2022-06-26 00:18:33.280358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)

    validation_0.to_lazy()

# Generated at 2022-06-26 00:18:36.907375
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Compare lazy with expected lazy
    lazy_expected = Lazy(lambda: '')
    lazy_result = Validation.success('').to_lazy()
    assert lazy_result == lazy_expected, 'lazy_result is not equals to lazy_expected'



# Generated at 2022-06-26 00:18:44.530354
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Transform Validation to Lazy.

    :returns: Lazy monad with Validation value
    :rtype: Lazy[A]
    """
    # Test 0
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(True, str_0)
    lazy_0 = validation_0.to_lazy()

    # Check
    assert lazy_0.value() == True


# Generated at 2022-06-26 00:18:58.616248
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = lazy(str_0)
    lazy_0 = validation_0.to_box()
    str_1 = 'Transform Try into successful Validation with constructor_fn result.'
    str_2 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '

# Generated at 2022-06-26 00:19:04.649961
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_1 = True
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_1 = Validation(bool_1, str_1)
    assert validation_1.to_lazy() == Lazy(lambda: bool_1)


# Generated at 2022-06-26 00:19:12.278332
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    bool_1 = True
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_1 = Validation(bool_1, str_1)
    lazy_1 = Lazy(validation_0.value)
    lazy_2 = validation_0.to_lazy()

# Generated at 2022-06-26 00:19:18.167934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        assert Validation(bool_0, str_0).to_lazy()
        print('Success. test_Validation_to_lazy')
    except AssertionError:
        print('Failed. test_Validation_to_lazy')


# Generated at 2022-06-26 00:19:21.820184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = True
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_1 = Validation(bool_1, str_1)
    bool_2 = False

# Generated at 2022-06-26 00:19:31.082637
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def call_lazy(bool_0):
        assert isinstance(bool_0, bool)
        return bool_0
    bool_0 = True
    lazy_0 = Lazy(lambda: bool_0)
    validation_0 = lazy_0.to_validation(call_lazy)
    assert isinstance(validation_0, Validation)
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_1 = Validation(bool_0, str_0)
    assert validation_0 == validation_1
    bool_0 = None
   

# Generated at 2022-06-26 00:19:44.111138
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(value='\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        ', errors=str_0)
    lazy_0 = validation_0.to_lazy()

# Generated at 2022-06-26 00:19:50.733219
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Invoke method
    var_1 = Validation.success(var_0).to_lazy()

    # Unit test result
    str_1 = 'Lazy(<pymonet.monad.validation.lambda_0>)'
    assert str(var_1) == str_1, 'Failed test_Validation_to_lazy'


# Generated at 2022-06-26 00:19:52.945942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var = Validation.success(0)
    test_case_0()
    var = var.to_lazy()


# Generated at 2022-06-26 00:19:59.506389
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    global str_0

    # New Validation
    validation = Validation.success("value")

    # Validation to Lazy
    lazy = validation.to_lazy()

    # Test lazy stored function
    stored_function_0 = lazy.unwrap()

    # Test lazy stored function
    stored_function_1 = var_0

    # Test equals functions
    assert stored_function_0 == stored_function_1

    # Test equals by identity functions
    assert not stored_function_0 is stored_function_1


# Generated at 2022-06-26 00:20:02.403525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = Validation.success('ta')
    var_1 = var_0.to_lazy()
    var_1.value()
    pass

# Generated at 2022-06-26 00:20:07.097329
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('Test success function')
    validation_0 = Validation.success(0)
    lazy_0 = validation_0.to_lazy()
    assert 0 == lazy_0.value()
    print('Test fail function')
    validation_1 = Validation.fail([])
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.value() == None


# Generated at 2022-06-26 00:20:08.682666
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = ''
    var_0 = Validation.success(str_0).to_lazy()
    assert var_0.value() == str_0


# Generated at 2022-06-26 00:20:12.998350
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = Validation(10, ['error'])
    var_1 = Validation.success(10)
    var_2 = Validation.fail(['error'])
    var_3 = Validation.fail()
    var_4 = var_0.to_lazy()
    var_5 = var_1.to_lazy()
    var_6 = var_2.to_lazy()
    var_7 = var_3.to_lazy()
    var_8 = var_4.value()
    var_9 = var_5.value()
    var_10 = var_6.value()
    var_11 = var_7.value()

# Generated at 2022-06-26 00:20:18.069305
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = ''
    var_0 = lambda : str_0
    assert Validation.success(value=10).to_lazy().run()() == 10
    assert Validation.success(value=10).to_lazy().run()() == 10
    assert Validation.fail(errors=[
        "First error", "Second error"
    ]).to_lazy().run()() == None



# Generated at 2022-06-26 00:20:21.020966
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    var = Validation.success(1)
    assert var.to_lazy() == Lazy(lambda: 1)
    var = Validation.success(lambda: 1)



# Generated at 2022-06-26 00:20:24.626674
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    str_0 = 'test'
    var_0 = Validation.success(str_0)
    assert var_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:20:29.220426
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)


# Generated at 2022-06-26 00:20:32.252505
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(42).to_lazy().value == str_0
    assert Validation.fail(['error', 'error2']).to_lazy().value == str_0


# Generated at 2022-06-26 00:20:41.607892
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    validation = Validation.success().to_lazy()
    lazy = validation.value()
    try_0 = lazy()
    unbounded_callable = try_0.value
    if unbounded_callable == 'Lazy(<pymonet.monad.validation.lambda_0>)':
        print('passed')
    else:
        print('failed')

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 00:20:51.169221
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    _ = Validation.success('')
    str_0 = _.to_lazy()
    _ = Validation.fail('')
    str_1 = _.to_lazy()
    assert str_0 == str_1, 'str_0 == str_1'
    assert str_0 == 'Lazy(<pymonet.monad.validation.lambda_0>)', 'str_0 == \'Lazy(<pymonet.monad.validation.lambda_0>)\''
    assert str_1 == 'Lazy(<pymonet.monad.validation.lambda_0>)', 'str_1 == \'Lazy(<pymonet.monad.validation.lambda_0>)\''
    assert _.has_value() == False, '_.has_value() == False'

# Unit test

# Generated at 2022-06-26 00:20:57.903504
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.monad

    assert pymonet.monad.Validation.success(0).to_lazy().get() == 0


# Generated at 2022-06-26 00:20:59.937049
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.success(5).to_lazy()) == str_0


# Generated at 2022-06-26 00:21:02.637411
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = str(Validation.success(1).to_lazy())
    str_1 = str(Validation.success(1).to_lazy())
    assert str_0 == str_1


# Generated at 2022-06-26 00:21:06.529988
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:08.526444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_0 = Validation(lambda_0, None)
    assert (str(val_0.to_lazy())) == str_0


# Generated at 2022-06-26 00:21:12.240249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print(Validation.success('test').to_lazy())
    assert str(Validation.success('test').to_lazy()) == 'Lazy(<pymonet.monad.validation.lambda_0>)'


# Generated at 2022-06-26 00:21:15.855338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('abc')
    assert validation.to_lazy().__str__() == str_0

# Generated at 2022-06-26 00:21:21.151390
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    a_0 = Box('test', monad=Validation)
    a_1 = a_0.to_lazy()

    assert isinstance(a_1, Lazy)
    assert a_1 == Lazy(lambda: 'test', monad=Validation)

    str_0 = 'Lazy(<pymonet.monad.validation.lambda_0>)'


# Generated at 2022-06-26 00:21:24.802619
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_lazy import Lazy

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:21:30.531509
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert repr(Validation.success(48).to_lazy()) == 'Lazy(<pymonet.monad.validation.lambda_4>)'
    assert repr(Validation.fail([9, 1, 4]).to_lazy()) == 'Lazy(<pymonet.monad.validation.lambda_5>)'
    str_0 = 'Lazy(<pymonet.monad.validation.lambda_0>)'


# Generated at 2022-06-26 00:21:35.452916
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.monad_try as mond

    val_0 = Validation.success('value')

    val_1 = Validation.fail()

    laz_0 = val_0.to_lazy()

    laz_1 = val_1.to_lazy()

    assert val_0.value == laz_0.run()
    assert val_1.value == laz_1.run()


# Generated at 2022-06-26 00:21:41.030939
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    input_value = "value"
    input_errors = ["first error", "second error"]
    input_validation = Validation(input_value, input_errors)
    expected = "Lazy(<pymonet.monad.validation.lambda_0>)"

    actual = input_validation.to_lazy().__str__()

    assert actual == expected, f"Actual: {actual}, Expected: {expected}"


# Generated at 2022-06-26 00:21:43.652276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail(['error']).to_lazy() == Lazy(None)
    assert Validation.success('success').to_lazy() == Lazy('success')


# Generated at 2022-06-26 00:21:45.924566
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert_true(Validation.success().to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-26 00:21:49.053083
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print(test_case_0.__doc__)
    lazy = Validation.success('S').to_lazy()
    print('Lazy: {}'.format(lazy))
    print('lazy.value: {}'.format(lazy.value))


# Generated at 2022-06-26 00:21:53.835244
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().__repr__() == 'Lazy(<pymonet.monad.validation.lambda_0>)', 'To lazy method produced wrong result - expected: Lazy(<pymonet.monad.validation.lambda_0>) got: {}'.format(str(Validation.success(1).to_lazy()))


# Generated at 2022-06-26 00:21:57.641986
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = 2
    validation = Validation.success(value)
    assert validation.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-26 00:22:00.646094
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test with successful Validation
    assert Validation.success('a').to_lazy() == Lazy('a')
    # Test with failed Validation
    assert Validation.fail([0]).to_lazy() == Lazy(None)


# Generated at 2022-06-26 00:22:03.270926
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    method_0 = Validation.success(1).to_lazy()
    assert str(method_0) == 'Lazy(<pymonet.monad.validation.lambda_0>)'


# Generated at 2022-06-26 00:22:05.767377
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success('x').to_lazy()
    assert str(val) == str_0

str_1 = 'Validation.fail[None, test message]'


# Generated at 2022-06-26 00:22:09.055901
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('hello').to_lazy() == Lazy(lambda : 'hello')
    assert Validation.success('hello').to_lazy() == Lazy(test_case_0)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda : None)


# Generated at 2022-06-26 00:22:15.648734
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import maybe_0, maybe_1, maybe_2
    from pymonet.monad.validation import validation_0, validation_1
    from pymonet.maybe import Maybe

    lazy_0 = validation_0.to_lazy()
    assert 'Lazy(<pymonet.monad.validation.lambda_0>)' == str(lazy_0)

    lazy_1 = validation_1.to_lazy()
    assert 'Lazy(<pymonet.monad.validation.lambda_1>)' == str(lazy_1)


# Generated at 2022-06-26 00:22:17.129173
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert(str(Validation.success(lambda: 1).to_lazy()) ==
           str_0)


# Generated at 2022-06-26 00:22:23.594462
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_0 = Validation.fail('error_0')
    val_1 = val_0.to_lazy()
    assert val_1.__str__() == str_0

    val_2 = Validation.success(1)
    val_3 = val_2.to_lazy()
    assert val_3.__str__() == str_0

    val_4 = Validation.success()
    val_5 = val_4.to_lazy()
    assert val_5.__str__() == str_0


# Generated at 2022-06-26 00:22:24.763517
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.success('ok').to_lazy()) == str_0

# Generated at 2022-06-26 00:22:28.271232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.success(None).to_lazy()) == 'Lazy(<pymonet.monad.validation.lambda_0>)', 'incorrect to_lazy'
    test_case_0()
    print('test_Validation_to_lazy ... ok')


# Generated at 2022-06-26 00:22:35.309759
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.success(1).to_lazy()) == 'Lazy(<pymonet.monad.validation.lambda_0>)'


# Generated at 2022-06-26 00:22:37.545003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = str(Validation.success(5).to_lazy())
    test_case_0()
    assert str_1 == str_0


# Generated at 2022-06-26 00:22:39.564355
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = repr(Validation.success(lambda_0).to_lazy())
    assert str_0 == str_0


# Generated at 2022-06-26 00:22:45.535092
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = str(Validation.success(1).to_lazy())
    str_1 = 'Lazy(<pymonet.monad.validation.lambda_0>)'
    assert str_0 == str_1


# Generated at 2022-06-26 00:22:50.297005
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1,2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-26 00:22:52.894953
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    return str(Validation.success('1').to_lazy()) == str_0


# Generated at 2022-06-26 00:23:05.650433
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from functools import partial

    # Test with success Validation
    validation_0 = Validation.success(2)
    actual_result_0 = validation_0.to_lazy()
    expect_result_0 = Lazy(partial(validation_0.value))
    assert actual_result_0 == expect_result_0, 'Error in test_Validation_to_lazy() 0'

    # Test with fail Validation
    validation_1 = Validation.fail(errors=[])
    actual_result_1 = validation_1.to_lazy()
    expect_result_1 = Lazy(partial(validation_1.value))
    assert actual_result_1 == expect_result_1, 'Error in test_Validation_to_lazy() 1'

#

# Generated at 2022-06-26 00:23:07.140562
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation('', [])
    assert validation_0.to_lazy().value == validation_0.value


# Generated at 2022-06-26 00:23:11.591021
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_cases = [(test_case_0, 'success', '<pymonet.monad.validation.lambda_0>', None), ]

    for test_case in test_cases:
        res = test_case[0]()
        assert getattr(res, test_case[1]) == test_case[2]
        assert res.exception == test_case[3]


# Generated at 2022-06-26 00:23:16.157220
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    try_0 = Try.success(lambda_0)
    validation_0 = Validation.success(lambda_0)
    lazy_0 = try_0.to_lazy()

    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:23:20.829824
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success()
    assert success.to_lazy() == Lazy(lambda: None)

    failure = Validation.fail()
    assert failure.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:23.402695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Validation
    from pymonet.lazy import Lazy

    assert Validation.success('L').to_lazy() == Lazy(lambda: 'L'), 'Successful validation failed to transform to lazy'


# Generated at 2022-06-26 00:23:26.335851
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    if str(Validation.success(0).to_lazy()) == str_0:
        print('Unit test for method to_lazy of class Validation have passed')
        return True
    print('Unit test for method to_lazy of class Validation have failed')
    return False


# Generated at 2022-06-26 00:23:27.501763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.success(lambda_0).to_lazy()) == str_0

# Generated at 2022-06-26 00:23:29.193654
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(1)
    assert val.to_lazy().__str__() == test_case_0()

# Generated at 2022-06-26 00:23:34.624092
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad.validation import Validation
    from pymonet.monad.validation import test_case_0
    from pymonet.lazy import Lazy

    # Case 0
    str_0 = 'Lazy(<pymonet.monad.validation.lambda_0>)'
    laz_0 = Validation.success().to_lazy()
    assert str(laz_0) == str_0

    Validation.success(test_case_0)
    # Case 1


# Generated at 2022-06-26 00:23:37.070469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:41.458178
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import test_Validation_to_try

    validation_0 = Validation.success('Validation.success[Validation.success[True]]')
    assert validation_0.to_lazy() == Lazy(test_Validation_to_try)

# Generated at 2022-06-26 00:23:45.571681
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v_0 = Validation.fail()
    l_0 = v_0.to_lazy()
    assert l_0.get() == None
    v_1 = Validation.success(1)
    l_1 = v_1.to_lazy()
    assert l_1.get() == 1


# Generated at 2022-06-26 00:23:54.172140
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Validation
    from pymonet.lazy import Lazy
    from six import PY2

    def test_case(expected_result, *args):
        actual_result = Validation.to_lazy(*args)
        assert(expected_result == actual_result)

    test_case(Lazy(lambda: None), Validation.fail(['Error']))

    if PY2:
        test_case(Lazy(lambda: 3.2), Validation.success(3.2))
    else:
        test_case(Lazy(lambda: None), Validation.fail(['Error']))
        test_case(Lazy(lambda: 3.2), Validation.success(3.2))


# Generated at 2022-06-26 00:24:00.347838
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """`Validation.to_lazy` should return Lazy(<pymonet.monad.validation.lambda_0>)
    """

    from pymonet.lazy import Lazy

    value = True
    errors = []

    validation = Validation(value, errors)

    assert validation.to_lazy() == Lazy(lambda_0)


# Generated at 2022-06-26 00:24:02.650469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print(Validation.success(10).to_lazy())
    print(Validation.success(0).to_lazy())
    print(Validation.success(lambda_0).to_lazy())


# Generated at 2022-06-26 00:24:04.422676
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()
    assert lazy == Lazy(lambda: 10)



# Generated at 2022-06-26 00:24:08.366403
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Validation

    assert Validation(1, []).to_lazy() == Lazy(1)
    assert Validation(None, ['error']).to_lazy() == Lazy(None)


# Generated at 2022-06-26 00:24:16.854444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
  from pymonet.lazy import Lazy
  import pymonet.monad
  from func_test_utils import assert_equal
  r1 = Validation.success(Lazy(lambda: pymonet.monad.validation.lambda_0))
  r2 = Validation.fail(Lazy(lambda: pymonet.monad.validation.lambda_0))
  # Check if to_lazy return Lazy monad with function that return Validation value
  assert_equal(r1.to_lazy(), Lazy(lambda: Lazy(lambda: pymonet.monad.validation.lambda_0)))
  assert_equal(r2.to_lazy(), Lazy(lambda: Lazy(lambda: pymonet.monad.validation.lambda_0)))


# Generated at 2022-06-26 00:24:17.365469
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:24:25.167668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import validation

    from pymonet.monad_either import Either

    from pymonet.monad_try import Try

    from pymonet.box import Box

    from pymonet.maybe import Maybe

    from pymonet import Lazy

    from pymonet.monad_validation import Validation

    validation = validation.Validation.fail(['1', '2'])
    new_validation = validation.to_lazy()
    assert isinstance(new_validation, Lazy) and new_validation.is_instance() is False
    result = None

    def lambda_0():
        validation = Validation.success('Foo')
        return validation

    result = new_validation.value(lambda_0)

# Generated at 2022-06-26 00:24:29.834252
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    with open('pymonet/monad/validation.py', 'r+') as f:
        source = f.read()

    code = compile(source, 'pymonet/monad/validation.py', 'exec')
    exec(code, globals())

    str_0 = to_lazy_0.__str__()
    assert str_0 == 'Lazy(<pymonet.monad.validation.lambda_0>)'


# Generated at 2022-06-26 00:24:30.609303
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()


# Generated at 2022-06-26 00:24:35.433210
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Lazy(<pymonet.monad.validation.lambda_0>)'
    str_1 = str(Validation.success('a').to_lazy())
    assert str_0 == str_1

    str_0 = 'Lazy(<pymonet.monad.validation.lambda_0>)'
    str_1 = str(Validation.fail(['err']).to_lazy())
    assert str_0 == str_1


# Generated at 2022-06-26 00:24:44.868343
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = 'Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    bool_1 = lazy_0.result_fn()
    assert bool_1 == bool_0


# Generated at 2022-06-26 00:24:52.362466
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)

    # Test if the method to_lazy does the same of method to_lazy of class Validation
    lazy_0 = Validation.lazy(bool_0, str_0) # Call constructor of class Lazy with value and errors of validation_0
    lazy_1 = validation_0.to_lazy() # Call to_lazy of validation_0
    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:24:57.101775
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def lazy_fn():
        return str_0

    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    lazy_0 = Validation(lazy_fn, str_0).to_lazy()
    lazy_0.constructor_fn().is_success()

test_Validation_to_lazy()

# Generated at 2022-06-26 00:25:04.737642
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    lazy_0 = validation_0.to_lazy()

    assert id(str_1) == id(lazy_0.constructor_fn())
    assert lazy_0 == lazy_0
    assert lazy_0 != validation_0


# Generated at 2022-06-26 00:25:08.307678
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Transform Validation to Try.

    :returns: Lazy monad with function returning Validation value
    :rtype: Lazy[Function() -> (A | None)]
    """
    pymonet.to_lazy(validation_0)


# Generated at 2022-06-26 00:25:20.212902
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Define bool_0 with value True
    bool_0 = True
    # Define str_0 with value '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    # Define validation_0 with Validation(bool_0, str_0)
    validation_0 = Validation(bool_0, str_0)
    # Define validation_1 with validation_0.to_lazy()
    validation_1

# Generated at 2022-06-26 00:25:23.209763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Validation with None value, empty errors
    validation = Validation(value=None, errors=[])
    validation_lazy = validation.to_lazy()

    # Lazy with function returns None
    assert validation_lazy.value_fn() is None


# Generated at 2022-06-26 00:25:30.529579
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(bool(0), str('\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '))
    validation_0.to_lazy()


# Generated at 2022-06-26 00:25:36.820873
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)

    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0.constructor_fn(), bool)



# Generated at 2022-06-26 00:25:43.102077
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)

    try:
        lazy_0 = validation_0.to_lazy()
        if not lazy_0:
            return False
    except:
        return False
    return True


# Generated at 2022-06-26 00:25:51.923142
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    validation_0 = Validation(bool_0, None)
    lazy_0 = Lazy(lambda: Validation.success(bool_0))
    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:25:59.177846
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test that method to_lazy() of class Validation returns correct result."""
    # Test 0
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_1 = lazy_0.run(str_1)
   

# Generated at 2022-06-26 00:26:03.489135
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Validation to Lazy.\n\n        :returns: Lazy monad with function returning Validation value\n        :rtype: Lazy[Function() -> (A | None)]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:26:12.067102
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    int_1 = 1
    int_2 = 2
    int_3 = 3
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '

# Generated at 2022-06-26 00:26:14.272411
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    global validation_0
    lazy = validation_0.to_lazy()
    rand_int = randint(0, int_max)
    assert lazy.value() == rand_int


# Generated at 2022-06-26 00:26:18.065428
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test of correct transformion
    assert Validation.success(1).to_lazy().unbox() is 1
    assert Validation.fail([1, 2]).to_lazy().unbox() is None
    # Test of incorrect transformion
    try:
        Validation.fail([1, 2]).to_lazy().unbox()
    except TypeError:
        assert True



# Generated at 2022-06-26 00:26:18.988413
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(0, '').to_lazy()._constructor_fn() == 0

# Generated at 2022-06-26 00:26:26.631289
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Defiantion of the first value
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    # Defiantion of the second value
    lazy_1 = validation_0.to_lazy()
    # AssertVal in the function to_maybe of class Validation
    assertVal(validation_0, lazy_1)

# Generated at 2022-06-26 00:26:31.757742
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    def func_0():
        return validation_0
    try:
        validation_0.to_lazy() == Lazy(func_0)
        verification_0 = True
    except Exception:
        verification_0 = False

    assert verification_0 is True


# Generated at 2022-06-26 00:26:33.631371
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation(10, 'error')
    val = v.to_lazy().map(lambda x: x + 10).run()
    assert val == 20

# Generated at 2022-06-26 00:26:46.838739
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)



# Generated at 2022-06-26 00:26:48.412456
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(1)

    lazy_0 = validation_0.to_lazy()

    assert lazy_0 == Lazy(lambda: 1)


# Generated at 2022-06-26 00:26:52.877623
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('Testing method to_lazy of class Validation')

    bool_0 = True
    str_0 = "\n        Transform Validation to Try.\n\n        :returns: Try with Validation value value. Try is successful when Validation has no errors\n        :rtype: Try[A]\n        "
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()

    print('Test for method to_lazy of class Validation finished')



# Generated at 2022-06-26 00:26:58.592578
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    expectation_0 = Validation.success(lazy(lambda: True))
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == expectation_0


# Generated at 2022-06-26 00:27:02.457818
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    try_0 = validation_0.to_lazy()
    try_0.resolve()


# Generated at 2022-06-26 00:27:08.251676
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Initialize test-case variable(s)
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_expected_0 = Lazy(lambda: bool_0)
    lazy_actual_0 = validation_0.to_lazy()
    assert lazy_actual_0 == lazy_expected_0


# Generated at 2022-06-26 00:27:14.441814
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_1 = Validation(lazy_0, str_1)

# Generated at 2022-06-26 00:27:24.281868
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 is not None
    # Test case with argument None, number 0
    lazy_0 = Validation.fail().to_lazy()
    assert lazy_0 is not None


# Generated at 2022-06-26 00:27:26.238743
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = False
    bool_1 = validation_0.to_lazy().is_successful()
    assert bool_1 == bool_0


# Generated at 2022-06-26 00:27:34.470144
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:28:02.581682
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bool_1 = False
    str_0 = 'Validatn monad'
    validation_0 = Validation(bool_0, bool_1)
    lazy_0 = validation_0.to_lazy()
    bool_2 = True
    bool_3 = lazy_0.is_success()
    assert (bool_2 == bool_3)

# Generated at 2022-06-26 00:28:08.607976
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy = validation_0.to_lazy()



# Generated at 2022-06-26 00:28:17.007200
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    validation_1 = validation_0.to_lazy()
    assert hasattr(validation_1, 'value')
    assert validation_1.value == bool_0
    assert hasattr(validation_1, 'errors')
    assert len(validation_1.errors) == 0
    validation_2 = validation_1.to_lazy()
    assert hasattr(validation_2, 'value')
    assert validation_2.value == bool_0

# Generated at 2022-06-26 00:28:24.285818
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
    lazy_0 = Lazy(lambda: True)
    validation_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.to_validation(lambda: str_0)
    lazy_0 = lazy_0.to_validation(lambda: str_0)
    lazy_2 = lazy_1.to_validation(lambda: str_0)
    assert lazy_0 == lazy_2


# Generated at 2022-06-26 00:28:28.760338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    str_0 = '\n        Transform Lazy into successful Validation with constructor_fn result.\n\n        :returns: successfull Validation monad with previous value\n        :rtype: Validation[A, []]\n        '
    validation_0 = Validation(bool_0, str_0)
# assert validation_0.to_lazy() == Lazy(lambda: bool_0)
    try:
        assert validation_0.to_lazy() == Lazy(lambda: bool_0)
    except AssertionError:
        raise AssertionError()
