

# Generated at 2022-06-26 00:18:37.996545
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    validation_0 = Validation(bool_0, [])
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.fn() == True
    lazy_1 = validation_0.to_lazy()
    assert lazy_1 == lazy_0
    lazy_2 = lazy_0.map(bool)
    assert lazy_2.fn() == True
    lazy_3 = lazy_1.map(max, lazy_2)
    assert lazy_3 == lazy_2
    lazy_4 = lazy_2.flat_map(lambda x: Lazy(lambda: lazy_3.fn()))
    assert lazy_4 == lazy_3
    lazy_5 = lazy_2.map(bool)
    assert lazy_5.fn()


# Generated at 2022-06-26 00:18:43.875511
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success(1)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == 1
    assert isinstance(lazy_0._memo, Lazy)
    assert lazy_0._memo.value() == 1
    assert lazy_0._memo.is_value_evaluated() is True
    assert lazy_0._value_evaluated is True



# Generated at 2022-06-26 00:18:56.909504
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Assert
    validation_0 = Validation.fail()
    lazy_0 = validation_0.to_lazy()

    validation_1 = Validation.success('3')
    lazy_1 = validation_1.to_lazy()

    validation_2 = Validation.fail('3')
    lazy_2 = validation_2.to_lazy()

    validation_3 = Validation.success(3)
    lazy_3 = validation_3.to_lazy()

    validation_4 = Validation.fail(3)
    lazy_4 = validation_4.to_lazy()

    validation_5 = Validation.success(None)
    lazy_5 = validation_5.to_lazy()

    validation_6 = Validation.fail(None)
    lazy_6 = validation_6.to_lazy()



# Generated at 2022-06-26 00:19:01.386746
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = bool_0
    assert bool_1 == lazy_0.value()
    pass


# Generated at 2022-06-26 00:19:04.227088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:19:09.715341
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = validation_0.is_success()
    if bool_1:
        str_0 = lazy_0.value
        assert validation_0.value == str_0


# Generated at 2022-06-26 00:19:14.948004
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    try:
        validation_0.to_lazy()
    except Exception:
        return 0
    return 1


# Generated at 2022-06-26 00:19:22.770959
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = Lazy(lambda: Validation(bool_0, bytes_0).value)
    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:19:28.363887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(True, [False]).to_lazy() == Lazy(lambda: True)
    assert Validation(False, [1]).to_lazy() == Lazy(lambda: False)
    assert Validation(True, [True]).to_lazy() == Lazy(lambda: True)
    assert Validation(True, [True]).to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-26 00:19:33.293458
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.map(lambda value: value)
    lazy_2 = lazy_1.get()
    assert lazy_2 is bool_0


# Generated at 2022-06-26 00:19:37.498801
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    int_0 = 1
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    int_1 = lazy_0.force()
    assert(int_1 == int_0)
    return


# Generated at 2022-06-26 00:19:39.334702
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(int_0)
    fail = Validation.fail([str_0, str_1])
    assert success.to_lazy().get() == int_0
    assert fail.to_lazy().get() == None



# Generated at 2022-06-26 00:19:42.183192
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy().get() == int_0
    assert Validation.fail(["error"]).to_lazy().get() == None


# Generated at 2022-06-26 00:19:43.056546
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:19:46.863259
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(int_0)
    from pymonet.lazy import Lazy

    res = validation.to_lazy()

    exp = Lazy(lambda: int_0)

    assert res == exp


# Generated at 2022-06-26 00:19:53.705956
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    def to_lazy_function(int_0):
        return Lazy(lambda: int_0)

    validation_0 = Validation.success(int_0)
    functor_0 = validation_0.to_lazy()

    assert Functor.is_instance(functor_0)
    assert functor_0.unsafe_value() == to_lazy_function(validation_0.value)


# Generated at 2022-06-26 00:19:57.802432
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:20:03.199802
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1) == Lazy.pure(1).to_validation()
    assert Validation.fail([1,2]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:20:05.801590
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy() == Lazy(int_0)
    assert Validation.fail(int_0).to_lazy() == Lazy(int_0)


# Generated at 2022-06-26 00:20:08.930993
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    ValidationTuple = Validation.success(int_0)
    ValidationTuple.to_lazy()
    ValidationTuple = Validation.fail([])
    ValidationTuple.to_lazy()


# Generated at 2022-06-26 00:20:15.222086
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation.success(True)
    assert validation_0.to_lazy() == Lazy(lambda: True)
    validation_1 = Validation.success(False)
    assert validation_1.to_lazy() == Lazy(lambda: False)


# Generated at 2022-06-26 00:20:21.103251
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # 1. Input
    # Validation with value of type None
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    # 2. Action
    lazy_monad = validation_0.to_lazy()
    # 3. Expectation
    assert lazy_monad.f() == (bool_0)


# Generated at 2022-06-26 00:20:25.402967
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    try:
        lazy_0 = validation_0.to_lazy()
    except Exception:
        lazy_0 = None


# Generated at 2022-06-26 00:20:32.549786
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    bool_0 = Validation.success(False)
    lazy_0 = bool_0.to_lazy()
    assert lazy_0.value() == False
    bool_1 = Validation.fail([])
    lazy_1 = bool_1.to_lazy()
    assert lazy_1.value() == None
    bool_2 = Validation.success(True)
    lazy_2 = bool_2.to_lazy()
    assert lazy_2.value() == True


# Generated at 2022-06-26 00:20:35.948719
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    test_case_0()


# Generated at 2022-06-26 00:20:45.164966
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy = validation_0.to_lazy()
    assert lazy.thunk() == validation_0.value, "AssertionError: Expected lambda: validation_0.value, " \
                                               "but got lambda: lazy.thunk()"


# Generated at 2022-06-26 00:20:49.069696
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:20:57.714882
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.either import Either
    try:
        to_lazy_()
    except TypeError as e:
        assert str(e) == 'to_lazy() missing 1 required positional argument: \'self\''

# Generated at 2022-06-26 00:21:01.499181
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Initialization
    bytes_0 = b''
    validation_0 = Validation(bytes_0, bytes_0)
    # Execution
    lazy_0 = validation_0.to_lazy()
    # Validation
    assert lazy_0(()) is bytes_0


# Generated at 2022-06-26 00:21:05.870978
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == bool_0


# Generated at 2022-06-26 00:21:18.755422
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = lazy_0 == lazy_0
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_1 = Validation(bool_0, bytes_1)
    lazy_1 = validation_1.to_lazy()
    bool_2 = lazy_1 == lazy_0

    assert bool_1
    assert not bool_2



# Generated at 2022-06-26 00:21:23.180858
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    result_0 = lazy_0.value()
    assert result_0 == bool_0



# Generated at 2022-06-26 00:21:28.510294
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.thunk() == bool_0
    assert lazy_0.thunk() == bool_0


# Generated at 2022-06-26 00:21:33.488435
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-26 00:21:41.452154
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = True
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_1 = Validation(bool_1, bytes_1)
    lazy_1 = validation_1.to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:21:47.415000
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    case_0 = True
    case_1 = 23
    case_2 = -34.2
    case_3 = 'sample'

    cases = [case_0, case_1, case_2, case_3]
    for case in cases:
        validation = Validation.success(case)
        lazy = validation.to_lazy()
        assert lazy == Lazy(lambda: case)



# Generated at 2022-06-26 00:21:52.442445
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = False
    bytes_0 = b'\xe0\xce\x0ek\x92\x94\x1e\x9c\x9b'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.map(lambda x: x)


# Generated at 2022-06-26 00:21:53.679505
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()

test_Validation_to_lazy()



# Generated at 2022-06-26 00:21:56.858154
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation.success(True)
    lazy_0 = validation_0.to_lazy()

# Generated at 2022-06-26 00:22:05.616792
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test the method to_lazy for the class Validation.

    Examples:
    >>> Validation.success(True).to_lazy() == Lazy(lambda: True)
    True
    >>> Validation.success(True).to_lazy().value() == Lazy(lambda: True).value()
    True
    >>> Validation.success(True).to_lazy() == Lazy(lambda: False)
    False
    >>> Validation.success(True).to_lazy().value() == Lazy(lambda: False).value()
    False
    >>> Validation.success(True).to_lazy() == Lazy(lambda: None)
    False
    >>> Validation.success(True).to_lazy().value() == Lazy(lambda: None).value()
    False
    """
    pass

# Unit

# Generated at 2022-06-26 00:22:17.425991
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    assert(validation_0.to_lazy()) == (Lazy(True))


# Generated at 2022-06-26 00:22:22.906581
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    lazy_0 = validation_0.to_lazy()
    bool_1 = False
    bool_2 = lazy_0.is_success()
    assert bool_2 == bool_1


# Generated at 2022-06-26 00:22:27.790015
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It takes as a parameter class Validation.
    It calls method to_lazy() of class Validation.
    """
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    validation_0.to_lazy()


# Generated at 2022-06-26 00:22:35.761261
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Setup
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    # Invoke method
    lazy_0 = validation_0.to_lazy()

    # Test
    assert lazy_0.value == bool_0


# Generated at 2022-06-26 00:22:39.416814
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = False
    list_0 = [False, True, True, True, True, False, True]
    str_0 = 'Yes'
    validation_0 = Validation(list_0, str_0)
    assert validation_0.to_lazy() is not None



# Generated at 2022-06-26 00:22:46.349887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:22:51.603533
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    validation_1 = validation_0.to_lazy()
    assert validation_1.value() == True


# Generated at 2022-06-26 00:23:03.523472
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.validation import ValidationError

    # Test exception
    errors = ValidationError("test exception")

    lazy_expected = Lazy(lambda: None)
    lazy_result = Validation.fail(errors).to_lazy()
    assert lazy_expected == lazy_result

    # Test no exception
    value = "exception"
    lazy_expected = Lazy(lambda: value)
    lazy_result = Validation.success(value).to_lazy()

    assert lazy_expected == lazy_result

# Generated at 2022-06-26 00:23:07.491769
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = False
    bytes_0 = b'\x0c\x19\xc8\x88\xd6\xeb\xab'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = None
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:12.870390
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    lazy_0 = validation_0.to_lazy()
    lazy_0 = lazy_0(x = 'a')

    assert_0 = lazy_0.map(bytes_0)
    assert_0 = assert_0(x = 'a')


# Generated at 2022-06-26 00:23:37.336100
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    bool_1 = False
    bytes_1 = b'\x80_\x9a\x1e\x8e\xad\x96\xba\x93\xd7\x10\x95\x11\xfe\xe6<\x84Z\x9e\xf0'
    validation_1 = Validation(bool_1, bytes_1)
    bool_2 = True
    validation_2 = validation_1.ap(validation_0)
    bool_3 = False

# Generated at 2022-06-26 00:23:42.529361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bytes_0, bool_0)
    lazy_0 = validation_0.to_lazy()
    for i in range(20):
        assert lazy_0.value() is validation_0.value


# Generated at 2022-06-26 00:23:48.158489
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_1)
    lazy_0 = validation_0.to_lazy()
    str_0 = '\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    assert lazy_0 == Lazy(lambda: boolean(str_0))


# Generated at 2022-06-26 00:23:53.539261
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = Lazy(lambda: bool_0)
    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:23:55.405082
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = Validation.success(False)
    lazy_0 = bool_0.to_lazy()


# Generated at 2022-06-26 00:24:00.600956
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_1 = False
    bytes_0 = b'\x8e\xac\xe6\xa0\x90\x8e\xb2\xab\x9b\x9b\r\xa1\x97\xda\xbf\x8e'
    validation_0 = Validation(bool_1, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == bool_1


# Generated at 2022-06-26 00:24:08.516116
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = False
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_1 = Validation(bool_0, bytes_0)
    lazy_1 = validation_0.to_lazy()
    bool_2 = True
    bytes_2 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'

# Generated at 2022-06-26 00:24:12.046937
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:24:17.180439
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0_contains_bool_0 = lazy_0.contains(bool_0)
    assert lazy_0_contains_bool_0 is True


# Generated at 2022-06-26 00:24:21.079946
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == bool_0


# Generated at 2022-06-26 00:25:00.973130
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bool_1 = bool_0
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    bytes_1 = bytes_0
    validation_0 = Validation(bool_1, bytes_1)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:06.950272
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = magic_mock_0 = MagicMock(name='mock_call')
    lazy_0 = validation_0.to_lazy()
    lazy_0._lazy_value.call()
    assert magic_mock_0.call_count == 1


# Generated at 2022-06-26 00:25:16.550035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    bool_1 = True
    validation_1 = Validation(bool_1, bytes_0)
    bool_2 = validation_0 == validation_1
    lazy_0 = validation_0.to_lazy()
    bool_3 = lazy_0 == validation_0.value
    bool_4 = validation_0.value == validation_1.value


# Generated at 2022-06-26 00:25:24.400887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import identity_function

    def test_function_0():
        bool_0 = True
        bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
        validation_0 = Validation(bool_0, bytes_0)
        function_0 = identity_function
        lazy_0 = validation_0.to_lazy()
        lazy_1 = lazy_0.map(function_0)
        assert lazy_1.value() == True

    def test_function_1():
        bool_0 = True
        bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'

# Generated at 2022-06-26 00:25:33.204719
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == Lazy(lambda: bool_0)


# Generated at 2022-06-26 00:25:37.284163
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Test case 0
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.evaluate()


# Generated at 2022-06-26 00:25:46.606494
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print("test_Validation_to_lazy")

    # Test if function returns None when errors is empty
    # In this case, Validation is successful
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.result() is bool_0

    # Test if function returns None when errors is not empty
    # In this case, Validation is failed
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S\x9a\x97\x1a'
    validation

# Generated at 2022-06-26 00:25:56.946991
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = False
    bytes_1 = b'\x06\x10\x8d\xd9Pv\xff\xef\t\x8f_\xf7'
    validation_1 = Validation(bool_1, bytes_1)
    lazy_1 = validation_1.to_lazy()
    bool_2 = True
    bytes_2 = b'\x06\x10\x8d\xd9Pv\xff\xef\t\x8f_\xf7'
    validation_

# Generated at 2022-06-26 00:26:02.130687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.is_instance_of(Lazy)


# Generated at 2022-06-26 00:26:07.037772
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.is_success() == validation_0.is_success()
    assert lazy_0.value() == validation_0.value


# Generated at 2022-06-26 00:27:36.568973
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation class.
    """
    from pymonet.lazy import Lazy

    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    assert validation_0.to_lazy() == Lazy(lambda: bool_0)


# Generated at 2022-06-26 00:27:41.569896
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.run() == bool_0


# Generated at 2022-06-26 00:27:43.928758
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success(1)

    lazy = validation.to_lazy()

    assert lazy.is_instance_of(Lazy)
    assert lazy.__value__() == 1



# Generated at 2022-06-26 00:27:50.993240
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)

    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:27:53.505237
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        test_case_0()
    except Exception as e:
        fail_exception_info = '{} ({})'.format(e, type(e))
        assert False, fail_exception_info


# Generated at 2022-06-26 00:27:58.750247
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.run() == True


# Generated at 2022-06-26 00:28:07.926713
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    bool_1 = True
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_1 = Validation(bool_1, bytes_1)
    lazy_1 = validation_1.to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:28:12.507052
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_1 = True
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_1 = Validation(bool_1, bytes_1)
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.value() == bool_1


# Generated at 2022-06-26 00:28:19.566182
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    bool_1 = True
    bytes_1 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_1 = Validation(bool_1, bytes_1)

    from pymonet.lazy import Lazy

    lazy_0 = validation_0.to_lazy()
    lazy_0.get()
    lazy_1 = validation_1.to_lazy()
    lazy_1.get()


# Generated at 2022-06-26 00:28:23.129264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bool_0 = True
    bytes_0 = b'\x14\x80\xaa\xd0d^\xedd\xda\xc5S'
    validation_0 = Validation(bool_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
