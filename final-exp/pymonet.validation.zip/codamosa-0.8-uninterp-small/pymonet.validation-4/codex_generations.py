

# Generated at 2022-06-26 00:18:24.182432
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    dict_0 = {float_0: float_0, float_0: float_0}
    validation_0 = Validation(float_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:26.639145
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 397.17473369685894
    dict_0 = {float_0: float_0, float_0: float_0}
    validation_0 = Validation(float_0, dict_0)
    test_case_0()
    test_case_0()
    test_case_0()



# Generated at 2022-06-26 00:18:30.366827
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 0.32
    int_0 = 0
    validation_0 = Validation(float_0, int_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.fn()
    assert lazy_0.fn() == float_0


# Generated at 2022-06-26 00:18:37.603677
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {0.000020: 1.0, 0.000010: 10.0, 0.000005: 20.0}
    float_0 = 32.000001
    float_1 = 32.000000
    dict_1 = {0.000020: 1.0, 0.000010: 10.0, 0.000005: 20.0}
    validation_0 = Validation(float_1, dict_1)
    float_2 = float_1
    validation_1 = validation_0.to_lazy().get_value()
    validation_2 = validation_0.to_may()



# Generated at 2022-06-26 00:18:42.458127
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 981.6664589697874
    dict_0 = {float_0: float_0, float_0: float_0}
    validation_0 = Validation(float_0, dict_0)
    assert isinstance(validation_0.to_lazy(), Lazy) and validation_0.to_lazy().value() == float_0


# Generated at 2022-06-26 00:18:55.021458
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.monad_try import Try

    def f(val):
        return val

    def g(val):
        return 2 * val

    assert Validation.success(f).ap(Validation.success(g)).to_lazy().run().value == f(g(f).value)
    assert Validation.success(f).ap(Validation.fail(g)).to_lazy().run().value == f(g).errors
    assert Validation.fail(f).ap(Validation.success(g)).to_lazy().run().value == f.errors
    assert Validation.fail(f).ap(Validation.fail(g)).to_lazy().run().value == f.errors

# Generated at 2022-06-26 00:19:06.670540
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    dict_0 = {float_0: float_0, float_0: float_0}
    validation_0 = Validation(float_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    str_0 = "Tf{t8Hv@R"
    str_1 = "m!.f"
    str_2 = "m!.f"
    str_3 = "m!.f"
    lazy_1 = lazy_0.map((lambda str_6: str_6.format(str_1, str_2, str_3)))
    lazy_2 = lazy_1.flat_map((lambda float_1: float_1()))

# Generated at 2022-06-26 00:19:13.404202
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    float_0 = 559.1565299856591
    int_0 = 1612
    dict_0 = {float_0: float_0, int_0: float_0}
    list_0 = [0, 0, 0, 0, 0]
    list_1 = [float_0, float_0, float_0, float_0, float_0]
    validation_0 = Validation(int_0, list_1)
    lazy_0 = lambda: int()
    try_0 = validation_0.to_lazy().fmap(lambda lazy: lazy().fmap(lambda int_1: int_1.is_integer())).value()
    try_1 = validation_0.to_lazy().f

# Generated at 2022-06-26 00:19:19.852653
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    dict_0 = {float_0: float_0, float_0: float_0}
    validation_0 = Validation(float_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:24.766609
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    dict_0 = {float_0: float_0, float_0: float_0}
    validation_0 = Validation(float_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value().value == validation_0.value


# Generated at 2022-06-26 00:19:29.347094
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    validation_0 = Validation(float_0, [])
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == float_0


# Generated at 2022-06-26 00:19:33.193578
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 395.68851408925354
    validation_0 = Validation(float_0, float_0)
    assert(validation_0.to_lazy() == Lazy(lambda: float_0))
    assert(validation_0.to_lazy().force() == float_0)


# Generated at 2022-06-26 00:19:45.462873
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 395.68851408925354
    validation_0 = Validation.success(float_0)
    lazy_0 = validation_0.to_lazy()
    float_1 = lazy_0.get()
    assert float_1 == float_0
    float_2 = validation_0.value
    validation_0.map(lambda float_3: float_3 * float_0)
    float_0 = -2815.642960887419
    lazy_0 = validation_0.to_lazy()
    float_1 = lazy_0.get()
    assert float_1 == float_0


# Generated at 2022-06-26 00:19:48.753852
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = -20.62368286422135
    validation_0 = Validation(float_0, float_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.__str__() == 'Lazy<None>'


# Generated at 2022-06-26 00:19:58.661330
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.target_py3 import to_str

    def test_case_1():
        float = float_0 = 395.68851408925354
        validation = validation_0 = Validation(float, float)
        function = function_0 = _group_0 = lambda: float
        return_value = validation.to_lazy()
        return_value_0 = return_value.to_try()
        success = return_value_0.is_success
        value = return_value_0.value
        _octet_1 = (return_value, success, value)
        return _octet_1

    return_value_1, success_0, value_0 = test_case_1()

# Generated at 2022-06-26 00:20:06.839831
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Expected value:
    expected = Lazy(lambda: 395.68851408925354)
    # Actual value:
    validation_0 = Validation(395.68851408925354, 395.68851408925354)
    actual = validation_0.to_lazy()
    # Assert:
    try:
        assert expected == actual
    except AssertionError as e:
        raise AssertionError(str(e) + 
            '\n Expected: ' + str(expected.__dict__) + 
            '\n Actual: '   + str(actual.__dict__) )


# Generated at 2022-06-26 00:20:10.553018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet import lazy
    from pymonet import Validation
    from pymonet import lazy

    float_0 = 395.68851408925354
    validation_0 = Validation.success(float_0)

    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy.Lazy(lambda : float_0)
    assert lazy_0 == lazy_1, "Expected: %s, Actual: %s" % (lazy_1, lazy_0)



# Generated at 2022-06-26 00:20:19.841451
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Monad
    from pymonet.monad_try import Try
    from pymonet.monad_validation import Validation
    from pymonet.lazy import Lazy

    # Test for successful Validation
    validation_0 = Validation.success(5)
    expected_0 = Lazy(lambda: 5)
    to_lazy_0 = validation_0.to_lazy()
    assert to_lazy_0 == expected_0
    assert to_lazy_0.value == expected_0.value
    assert to_lazy_0.value == 5

    # Test for failed Validation
    validation_1 = Validation.fail()
    to_lazy_1 = validation_1.to_lazy()

# Generated at 2022-06-26 00:20:23.078763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_utils import test_monad_instance

    test_monad_instance(Validation, Lazy, Try)



# Generated at 2022-06-26 00:20:25.355740
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-26 00:20:35.488032
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    def test_lazy(self):
        float_0 = 395.68851408925354
        validation_0 = Validation(float_0, [])
        lazy_expected = Lazy(lambda: float_0)
        lazy = validation_0.to_lazy()
        self.assertEqual(lazy_expected, lazy)

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(test_lazy))
    return suite



# Generated at 2022-06-26 00:20:43.723623
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(True, True)
    lazy_0 = validation_0.to_lazy()
    lazy_0 = validation_0.to_lazy()
    lazy_0 = validation_0.to_lazy()
    validation_0 = Validation.fail(True)
    lazy_0 = validation_0.to_lazy()
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:20:53.388919
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    validation_0 = Validation.success(float_0)
    result_0 = validation_0.to_lazy()
    assert float_0 == result_0.value()
    float_1 = -3.9929789212235934
    validation_1 = Validation.success(float_1)
    result_1 = validation_1.to_lazy()
    assert float_1 == result_1.value()
    float_2 = -856.715861821907
    validation_2 = Validation.success(float_2)
    result_2 = validation_2.to_lazy()
    assert float_2 == result_2.value()
    float_3 = -11.314370839209902
    validation_3 = Validation

# Generated at 2022-06-26 00:20:58.240302
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    float_1 = float('-inf')
    float_1 = float_1
    float_2 = float('inf')
    float_2 = float_2
    float_3 = 0.0
    float_4 = float('nan')
    float_4 = float_4
    float_5 = 1.0
    float_6 = -10.0
    float_7 = -0.0
    float_8 = -1.0
    float_9 = 10.0
    float_10 = float('-nan')
    float_10 = float_10
    float_11 = float('nan')
    float_11 = float_11
    int_0 = 1
    int_1 = -1
    int_1 = int_1
    int_2 = 0


# Generated at 2022-06-26 00:21:07.299602
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    float_0 = 395.68851408925354
    validation_0 = Validation(float_0, float_0)
    validation_1 = validation_0.map(lambda float_5: float_5 + float_5)
    float_1 = float_0 + float_0
    validation_2 = validation_0.to_lazy()
    float_2 = float_1 + float_0
    validation_3 = validation_1.to_lazy()
    float_3 = float_2 + float_1
    validation_4 = validation_0.to_lazy().ap(lambda float_6: validation_1.to_lazy())
    float_4 = float_3 + float_2

# Generated at 2022-06-26 00:21:17.101568
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = float('nan')
    float_1 = float('inf')
    float_2 = float('-inf')
    validation_0 = Validation(float_0, float_0)
    # The method call validation_0.to_lazy()
    lazy_0 = validation_0.to_lazy()
    float_3 = float('nan')
    float_4 = float('inf')
    float_5 = float('-inf')
    validation_1 = Validation(float_4, float_4)
    # The method call validation_1.to_lazy()
    lazy_1 = validation_1.to_lazy()
    # The method call Lazy.get_value(lazy_1)
    lazy_1.get_value()
    float_6 = float('nan')

# Generated at 2022-06-26 00:21:23.542565
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    result_tuple = Validation(5, []).to_lazy().fmap(lambda i: i + 2).extract()
    assert result_tuple == (7, None)
    result_try = Validation(5, []).to_try().fmap(lambda i: i + 2)
    assert result_try == Try(7, True)
    result_box = Validation(5, []).to_box().fmap(lambda i: i + 2)
    assert result_box == Box(7)


# Generated at 2022-06-26 00:21:28.898131
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_true_0 = Validation.success()
    assert validation_true_0.to_lazy() == Lazy(lambda: validation_true_0.value)
    validation_false_0 = Validation.fail()
    assert validation_false_0.to_lazy() == Lazy(lambda: validation_false_0.value)



# Generated at 2022-06-26 00:21:31.664088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    float_0 = 395.68851408925354
    validation_0 = Validation(float_0, float_0)
    assert validation_0.to_lazy() == Lazy(float_0)


# Generated at 2022-06-26 00:21:36.034389
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    validation_0 = Validation.success(Maybe.just(0))
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0() == Maybe.just(0)



# Generated at 2022-06-26 00:21:40.757883
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail(['message']).to_lazy() == Lazy.success(None)
    assert Validation.success(int_0).to_lazy() == Lazy.success(int_0)



# Generated at 2022-06-26 00:21:47.225744
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Testing for successful validation
    validation_success = Validation.success(int_0)
    assert validation_success.to_lazy() == \
           Lazy(lambda: int_0), 'Test for successful Validation is failed'

    # Testing for failed validation
    validation_fail = Validation.fail([int_0])
    assert validation_fail.to_lazy() == \
           Lazy(lambda: None), 'Test for failed Validation is failed'


# Generated at 2022-06-26 00:21:51.369927
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    validation_int_0 = Validation.success(int_0)
    assert validation_int_0.to_lazy().get() == int_0

    validation_int_0 = Validation.fail()
    assert validation_int_0.to_lazy().get() == None


# Generated at 2022-06-26 00:21:54.771057
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_0 = Validation.success(10)
    assert val_0.to_lazy().value() == 10

    val_1 = Validation.fail()
    assert val_1.to_lazy().value() is None


# Generated at 2022-06-26 00:21:59.811003
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Create validation from lazy
    success = Lazy(lambda: 5).to_validation(lambda: 'invalid')
    assert success == Validation.success(5)

    # Create validation from lazy with failed validation
    fail = Lazy(lambda: ValueError('invalid')).to_validation(lambda: 'invalid')
    assert fail == Validation.fail(['invalid'])


# Generated at 2022-06-26 00:22:02.001850
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_0 = Validation.success(3)
    lazy_0 = val_0.to_lazy()
    assert lazy_0.value() == 3


# Generated at 2022-06-26 00:22:05.301040
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value0 = 0
    validation0 = Validation.success(value0)
    expected_result = Lazy(lambda: value0)
    assert validation0.to_lazy() == expected_result


# Generated at 2022-06-26 00:22:08.351471
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    lazy = validation.to_lazy()

    test_case = [
        (lazy.get(), 1),
    ]

    for i, (value, expected) in enumerate(test_case):
        assert value == expected, 'test #{} failed'.format(i)
    print('test #{} OK'.format(i))

if __name__ == '__main__':
    test_Validation_to_lazy()

# Generated at 2022-06-26 00:22:12.537025
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pytest

    with pytest.raises(TypeError) as e_info:
        test_case_0()
    assert str(e_info.value) == "int_0 is not callable"
    assert Validation.success(1).to_lazy().force() == 1
    assert Validation.fail(1).to_lazy().force() is None

# Generated at 2022-06-26 00:22:18.082681
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    valid_0 = Validation.success(5)
    valid_1 = Validation.fail([3, 4])
    expected_0 = Lazy(lambda: 5)
    expected_1 = Lazy(lambda: None)

    # When
    actual_0 = valid_0.to_lazy()
    actual_1 = valid_1.to_lazy()

    # Then
    assert actual_0 == expected_0
    assert actual_1 == expected_1


# Generated at 2022-06-26 00:22:21.595249
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.fail([])
    validation.to_lazy()
    assert True


# Generated at 2022-06-26 00:22:23.747085
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-26 00:22:28.237166
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # When Validation has no errors
    validation_int_0 = Validation.success(value=0)
    assert validation_int_0.to_lazy().value() == 0

    # When Validation has errors
    validation_int_0 = Validation.fail(errors=[0, 1, 2, 3])
    assert validation_int_0.to_lazy().value() is None


# Generated at 2022-06-26 00:22:32.821254
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail().to_lazy().get() == None
    assert Validation.success(0).to_lazy().get() == 0


# Generated at 2022-06-26 00:22:37.463917
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy as lazy
    validation = Validation.success(1)
    assert validation.to_lazy() == lazy.Lazy(lambda: 1)
    validation = Validation.fail(['Validation is fail with this message'])
    assert validation.to_lazy() == lazy.Lazy(lambda: None)


# Generated at 2022-06-26 00:22:45.702007
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Maybe
    from pymonet.either import Right

    validation_0 = Validation.fail([])
    lazy_0 = validation_0.to_lazy()
    assert(isinstance(lazy_0, Lazy))
    assert(Maybe.from_value(lazy_0.value).equals(Maybe.nothing()))

    validation_1 = Validation.fail([1, 2, 3])
    lazy_1 = validation_1.to_lazy()
    assert(isinstance(lazy_1, Lazy))
    assert(Maybe.from_value(lazy_1.value).equals(Maybe.nothing()))

    validation_2 = Validation.success(3)
    lazy_2 = validation_2.to_lazy()

# Generated at 2022-06-26 00:22:48.153425
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    expected = Lazy(lambda: 0)

    assert Validation.success(0).to_lazy() == expected


# Generated at 2022-06-26 00:22:57.529184
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functions import compose
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    # Testing success Validation
    validation_success = compose(
        (lambda x: x[1] * 2),
        (lambda x: x * 3),
        Validation.success
    )

    # assert Lazy(lambda: None) == validation_success(None)
    assert validation_success(6).to_lazy().value() == 36

    # Testing failure Validation
    validation_fail = compose(
        (lambda x: x[1] * 2),
        (lambda x: x * 3),
        Validation.fail
    )

    assert validation_fail(None).to_lazy().value() == None

    # Testing if lazy is lazy

# Generated at 2022-06-26 00:23:00.780345
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy() == Lazy.unit(0)
    assert Validation.fail().to_lazy() == Lazy.unit(None)


# Generated at 2022-06-26 00:23:02.743916
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = 1
    validation = Validation.success(value)
    assert validation.to_lazy().evaluate() == value


# Generated at 2022-06-26 00:23:09.895345
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    validation = Validation(int_0, [])

    def func_0():
        return int_0

    assert validation.to_lazy().run(func_0) == Lazy(func_0).run(func_0)


# Generated at 2022-06-26 00:23:12.717083
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    errors = ['error1', 'error2']
    value = 5
    v = Validation.fail(errors)
    actual = v.to_lazy()
    expected = Lazy(lambda: v.value)

    assert expected == actual


# Generated at 2022-06-26 00:23:15.236014
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success(int_0).to_lazy()
    expected = Lazy(lambda: 0)

    assert result == expected


# Generated at 2022-06-26 00:23:20.159983
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Test function correctness
    lazy_0 = TestValidation.success(int_0).to_lazy()
    assert lazy_0 == TestLazy(lambda: int_0) and lazy_0.value() == int_0

    # Test function corrections
    lazy_1 = TestValidation.fail().to_lazy()
    assert lazy_1 == TestLazy(lambda: None) and lazy_1.value() == None


# Generated at 2022-06-26 00:23:22.410420
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    t1 = Validation.success(int_0)
    t2 = t1.to_lazy()
    assert t2.value() == int_0



# Generated at 2022-06-26 00:23:30.145875
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_5 = 5
    int_6 = 6
    int_7 = 7
    int_8 = 8
    int_9 = 9
    int_abs = abs
    str_0 = '0'
    str_1 = '1'
    str_2 = '2'

    # case0
    # test to_lazy method, expects that Lazy monad will contains returned value
    v0 = Validation.success(int_0).to_lazy()
    assert v0.eval() == int_0, 'Test case 0 failed'
    v1 = Validation.success(int_1).to_lazy()

# Generated at 2022-06-26 00:23:35.593715
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_1 = 1

    validation_1 = Validation.success(int_1)
    validation_2 = Validation.fail()

    lazy_1 = validation_1.to_lazy()
    lazy_2 = validation_2.to_lazy()

    assert isinstance(lazy_1, Lazy)
    assert isinstance(lazy_2, Lazy)

    assert lazy_1.get() == int_1
    assert lazy_2.get() is None

## Unit test for method to_try of class Validation

# Generated at 2022-06-26 00:23:44.546383
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Cases:
    (1) Create Validation and should convert to correct Lazy monad
    """

    print("Test Case 1: Create Validation and should convert to correct Lazy monad")

    # Create Validation
    validation = Validation.success(0)
    print("\t(1) Validation: {}".format(validation))

    lazy_monad = validation.to_lazy()
    print("\t(2) Lazy monad: {}".format(lazy_monad))

    # Test implementation of Callable interface
    lazy_monad_value = lazy_monad()
    print("\t(3) Lazy monad value: {}".format(lazy_monad_value))

    print("--------------------------------------------------")


# Generated at 2022-06-26 00:23:47.456069
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    validation = Validation.success(int_0)
    lazy = validation.to_lazy()

    return lazy == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:23:50.040508
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Lazy(lambda: test_case_0()) == Validation.success(test_case_0()).to_lazy()


# Generated at 2022-06-26 00:24:00.413729
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_result import Result

    validation = Validation.success(Result.success(None))
    assert validation.to_lazy().func() == \
        Result.success(None), "test_case_0 - Func invocation should return successful Result with value None"

# Generated at 2022-06-26 00:24:04.214075
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    int_0 = 0

    validation = Validation.success(int_0)
    lazy = validation.to_lazy()

    assert lazy == Lazy(lambda: int_0)

    validation = Validation.fail(errors=['error1'])
    lazy = validation.to_lazy()

    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-26 00:24:11.477784
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation."""

    # Successful validation with int 0, to_lazy should return Lazy monad with value
    int_0 = 0
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == int_0

    # Failed validation, to_lazy should return Lazy monad with value
    validation_1 = Validation.fail()
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.value() is None


# Generated at 2022-06-26 00:24:14.100368
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    validation = Validation.success(int_0)
    lazy_0 = validation.to_lazy()
    assert lazy_0.value() == int_0


# Generated at 2022-06-26 00:24:22.039212
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    val = Validation.success(10)
    l = val.to_lazy()
    assert l.value() == 10
    assert l.map(lambda x: x * 10) == Lazy(lambda: 100)
    assert l.bind(lambda x: Lazy(lambda: x * 2)) == Lazy(lambda: 20)

    val = Validation.fail([])
    l = val.to_lazy()
    assert l.value() == None
    assert l.map(lambda x: x * 10) == Lazy(lambda: None)
    assert l.bind(lambda x: Lazy(lambda: x * 2)) == Lazy(lambda: None)

# Unit

# Generated at 2022-06-26 00:24:24.821943
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(int_0).to_lazy() == Lazy(lambda: int_0)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:24:32.767273
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    val_1 = Validation.success(1)
    val_2 = Validation.fail([1, 2])

    assert val_1.to_lazy() == Lazy(lambda: 1)
    assert val_2.to_lazy() == Lazy(lambda: None)
    assert val_1.to_lazy().get() == 1
    assert val_2.to_lazy().get() == None

    assert val_1.to_lazy() == Lazy.success(1)
    assert val_2.to_lazy() == Lazy.fail(None)
    assert val_1.to_lazy().get() == 1
    assert val_2.to_lazy().get() == None

# Unit

# Generated at 2022-06-26 00:24:35.721907
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    int_1 = 1
    assert Validation.success(int_0).to_lazy().get_thunk() == int_0
    assert Validation.fail([int_1]).to_lazy().get_thunk() == None


# Generated at 2022-06-26 00:24:38.986191
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.monad_lazy as ml
    assert Validation.success(1).to_lazy().get_or_else(0) == 1
    assert Validation.fail().to_lazy().get_or_else(0) == 0


# Generated at 2022-06-26 00:24:41.307157
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy().get()() == int_0
    assert Validation.fail([int_0]).to_lazy().get()() is None


# Generated at 2022-06-26 00:24:54.127702
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_0 = 0
    validation = Validation.success(int_0)
    lazy = validation.to_lazy()

    assert(lazy == Lazy(lambda: int_0))


# Generated at 2022-06-26 00:24:56.594383
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(int_0)

    lazy_0 = validation_0.to_lazy()

    int_1 = lazy_0.value()

    assert int_0 == int_1


# Generated at 2022-06-26 00:24:59.744186
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Create Validation instance
    validation = Validation.success(5)

    # Convert Validation to Lazy
    lazy = validation.to_lazy()

    # Call function on Lazy
    result = lazy.value()
    assert result == 5, "Returned value is not 5"



# Generated at 2022-06-26 00:25:03.231970
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy

    validation = Validation.success(42)
    lazy = validation.to_lazy()
    # This will not raise an exception, because lazy is not yet evaluated
    assert(isinstance(lazy, pymonet.lazy.Lazy))
    assert(lazy.value() == 42)


# Generated at 2022-06-26 00:25:06.754698
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # test data
    int_0 = 0

    # execute test
    validation = Validation.success()
    result_lazy = validation.to_lazy()

    # check result
    assert result_lazy.evaluate() == int_0


# Generated at 2022-06-26 00:25:18.428774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    bool_0 = bool(int_0)
    str_10 = '10'
    str_0 = str(int_0)
    success = Validation.success(str_10)
    lazy_10 = success.to_lazy()
    assert callable(lazy_10.value)
    assert 10 == int(lazy_10.value())
    assert str_10 == lazy_10.to_box().value
    assert lazy_10.to_maybe().is_nothing()
    assert lazy_10.to_box().to_either().is_right()
    assert lazy_10.to_box().to_maybe().is_just()
    assert lazy_10.to_box().to_maybe().get_value() == str_10
    fail = Validation.fail()

# Generated at 2022-06-26 00:25:22.502051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation = Validation.success(4)
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value() == 4

    validation = Validation.fail(['error'])
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value() == None


# Generated at 2022-06-26 00:25:31.443301
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    int_1 = 1

    validation = Validation.success(int_0)
    validation_lazy = validation.to_lazy()
    assert validation_lazy
    assert callable(validation_lazy.value)

    validation = Validation.fail([int_1])
    validation_lazy = validation.to_lazy()
    assert validation_lazy
    assert callable(validation_lazy.value)


# Generated at 2022-06-26 00:25:38.982704
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Test for Validation.success(0)
    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)

    # Test for Validation.success(-1)
    assert Validation.success(-1).to_lazy() == Lazy(lambda: -1)

    # Test for Validation.success(1)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    # Test for Validation.success(0).map(lambda x: x + 1)
    assert Validation.success(0).map(lambda x: x + 1).to_lazy() == Lazy(lambda: 1)

    # Test for Validation.fail('error')
    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)

    # Test for Val

# Generated at 2022-06-26 00:25:40.448278
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-26 00:25:51.042052
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(0)
    lazy = val.to_lazy()
    assert lazy.computed_value == val.value


# Generated at 2022-06-26 00:25:51.779848
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0


# Generated at 2022-06-26 00:25:53.977787
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(5)
    assert Validation.fail(5).to_lazy() == Lazy(None)


# Generated at 2022-06-26 00:25:57.666480
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.validation import Validation

    validation = Validation.success('value')
    lazy = Lazy(lambda: validation.value)
    assert validation.to_lazy() == lazy
    assert lazy() == Box('value')


# Generated at 2022-06-26 00:26:01.624954
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: Validation.success(1).value)
    assert Validation.fail(["lorem"]).to_lazy() == Lazy(lambda: Validation.fail(["lorem"]).value)


# Generated at 2022-06-26 00:26:10.370287
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test of function that transform Validation to Lazy monad.
    """
    from pymonet.lazy import Lazy

    print('> Start test of Validation.to_lazy')

    def test_0():
        print('> test_to_lazy_0')
        int_0 = 0

        validation = Validation.success(int_0)
        lazy = validation.to_lazy()

        assert lazy.is_instance_of(Lazy)

        assert lazy.value() == 0

    def test_1():
        print('> test_to_lazy_1')
        int_0 = 0
        int_10 = 10

        validation = Validation.success(int_0)
        lazy = validation.to_lazy()

        assert lazy.is_instance_of(Lazy)


# Generated at 2022-06-26 00:26:13.563662
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    result = Validation.success(int_0).to_lazy()

    assert result.is_instance_of(Lazy)
    assert result.value() == int_0


# Generated at 2022-06-26 00:26:15.979300
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation = Validation.success(10)

    assert validation.to_lazy() == Lazy(lambda: validation.value)


# Generated at 2022-06-26 00:26:20.085455
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation_success = Validation.success(100)
    assert validation_success.to_lazy() == Lazy(lambda: 100)

    validation_fail = Validation.fail([])
    assert validation_fail.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:26:22.400166
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    computed_maybe = Validation.success(5).to_lazy()
    expected_maybe = Lazy(lambda: 5)

    assert computed_maybe == expected_maybe

# Generated at 2022-06-26 00:26:33.971122
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = Validation.success(0).to_lazy()
    assert int_0.get() == 0


# Generated at 2022-06-26 00:26:37.649118
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # arrange
    validation_0 = Validation.fail()
    validation_1 = Validation.success(1)

    # act
    validation_0_lazy = validation_0.to_lazy()
    validation_1_lazy = validation_1.to_lazy()

    # assert
    assert validation_0_lazy.unwrap() == 0
    assert validation_1_lazy.unwrap() == 1


# Generated at 2022-06-26 00:26:39.221784
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-26 00:26:42.695561
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(100)
    lazy = validation.to_lazy()
    assert lazy.value == 100
    validation = Validation.success(200)
    assert lazy.value == 100
    lazy = validation.to_lazy()
    assert lazy.value == 200

# Unit tests for method __eq__ of class Validation

# Generated at 2022-06-26 00:26:49.456343
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_state import State
    from pymonet.lazy import Lazy

    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)
    assert Validation.success(0).to_lazy() == Lazy(lambda: 0)
    assert Validation.success(test_case_0).to_lazy() == Lazy(test_case_0)
    assert Validation.success(State(lambda state: (state, state + 1))).to_lazy() == Lazy(State(lambda state: (state, state + 1)))
    assert Validation.success(Try(0)).to_lazy() == Lazy(Try(0))

# Generated at 2022-06-26 00:26:51.460365
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    validation_success = Validation.success(int_0)
    lazy = validation_success.to_lazy()
    assert lazy.get() == int_0


# Generated at 2022-06-26 00:26:52.565502
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(2)
    assert validation.to_lazy().val() == 2


# Generated at 2022-06-26 00:26:59.433141
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.box as box

    # Test 1
    # input
    int_0 = 0
    # expected output
    exp = box.Box(int_0)

    # function
    result = Validation.success(int_0).to_lazy()

    # Test 2
    # input
    int_1 = 1
    # expected output
    exp = box.Box(int_1)

    # function
    result = Validation.success(int_1).to_lazy()

    # Test 3
    # input
    # expected output
    exp = box.Box(None)

    # function
    result = Validation.fail().to_lazy()

    assert result == exp



# Generated at 2022-06-26 00:27:00.609235
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(0).to_lazy() == Validation.success(0).value


# Generated at 2022-06-26 00:27:01.959038
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)



# Generated at 2022-06-26 00:27:25.578025
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:27:33.397890
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    test_value = 10
    validation = Validation.success(test_value)

    result = validation.to_lazy()

    assert isinstance(result, Lazy)
    assert test_value == result.get()
    assert validation == result.get().to_validation()


# Generated at 2022-06-26 00:27:38.518370
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 0
    int_1 = 1

    assert Validation.success(int_0).to_lazy() == Lazy(lambda: int_0)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)

    assert Validation.success(int_0).to_lazy().value() == int_0
    assert Validation.fail([]).to_lazy().value() == None


# Generated at 2022-06-26 00:27:41.170887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail([]).to_lazy().value() == None
    assert Validation.fail([0, 1]).to_lazy().value() == None


# Generated at 2022-06-26 00:27:42.790320
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success(0).to_lazy()

    assert result == Lazy(lambda: 0)



# Generated at 2022-06-26 00:27:45.933735
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success(10)
    assert v.to_lazy() == Lazy(lambda: 10)

    v = Validation.fail([])
    assert v.to_lazy() == Lazy(lambda: None)

    v = Validation.fail([10])
    assert v.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:27:48.080347
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    for f in [test_case_0]:
        validation = Validation.success(f)
        lazy = validation.to_lazy()
        try:
            assert lazy.run() == f
            assert True
        except Exception:
            assert False


# Generated at 2022-06-26 00:27:50.956278
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    succ_val = Validation.success(0)

    assert succ_val.to_lazy() == Lazy(lambda: 0)



# Generated at 2022-06-26 00:27:53.203746
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_case_0():
        int_0 = 0
        lazy = Validation.success(int_0).to_lazy()

        value = lazy.value()
        assert value == int_0


# Generated at 2022-06-26 00:27:58.390215
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Successfull Validation
    validation_0 = Validation.success(True)
    result_0 = validation_0.to_lazy()()
    assert result_0 is True

    # Failed Validation
    validation_1 = Validation.fail([False])
    result_1 = validation_1.to_lazy()()
    assert result_1 is None
