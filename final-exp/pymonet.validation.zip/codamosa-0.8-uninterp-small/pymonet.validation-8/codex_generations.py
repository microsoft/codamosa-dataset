

# Generated at 2022-06-26 00:18:28.136298
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0 == validation_0


# Generated at 2022-06-26 00:18:31.886334
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    validation_0 = Validation(dict_0, dict_1)
    validation_1 = Validation(dict_2, dict_3)
    assert validation_0 == validation_1


# Generated at 2022-06-26 00:18:33.670858
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    val = Validation(1, [])
    assert val == Validation(1, [])


# Generated at 2022-06-26 00:18:37.946209
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    validation_1 = Validation(dict_0, dict_0)
    # AssertionError
    try:
        assert validation_0 == validation_1
    except AssertionError:
        print ('AssertionError')


# Generated at 2022-06-26 00:18:40.561964
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0 == validation_0


# Generated at 2022-06-26 00:18:44.047876
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)

    dict_1 = {}
    validation_1 = Validation(dict_1, dict_1)
    var_0 = validation_0 == validation_1


# Generated at 2022-06-26 00:18:45.970427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(4)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:51.795224
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    It tests that two same Validations are equals.
    """
    result = Validation.success().__eq__(Validation.success())
    assert result is True


# Generated at 2022-06-26 00:18:54.259445
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    actual_0 = Validation.success(Validation.fail()) == Validation.fail()
    expected_0 = False
    assert actual_0 == expected_0



# Generated at 2022-06-26 00:18:58.287257
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    a = Validation.success(3)
    b = Validation.success(3)
    c = Validation.fail([])
    d = Validation.fail([])
    assert a == b
    assert not a == c
    assert c == d


# Generated at 2022-06-26 00:19:03.382709
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy().value() == int_0


# Generated at 2022-06-26 00:19:10.802034
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation_0 = Validation.success(Lazy(lambda: 5))
    try_0 = validation_0.to_lazy()
    assert try_0 == Try(Lazy(lambda: 5), True)

    try_1 = Validation.fail([]).to_lazy()
    assert try_1 == Try(Lazy(lambda: None), False)

    try_2 = Validation.fail([{'value': 'abc'}]).to_lazy()
    assert try_2 == Try(Lazy(lambda: None), False)


# Generated at 2022-06-26 00:19:23.370996
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    v1 = Validation.success(5)
    lazy_1 = v1.to_lazy()
    assert isinstance(lazy_1, Lazy)
    val_1 = lazy_1.get()
    assert isinstance(val_1, Try)
    assert val_1.get() == 5
    v2 = Validation.fail(['Name is required', 'Name is too short'])
    lazy_2 = v2.to_lazy()
    assert isinstance(lazy_2, Lazy)
    val_2 = lazy_2.get()
    assert isinstance(val_2, Try)
    assert val_2.get() is None



# Generated at 2022-06-26 00:19:32.333358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 4
    expected = Lazy(lambda: 4)
    received = Validation.success(int_0).to_lazy()
    assert received == expected

    errors_list_0 = []
    errors_list_1 = ['error_1']
    expected_0 = Lazy(lambda: 4)
    expected_1 = Lazy(lambda: None)
    received_0 = Validation.success(int_0).to_lazy()
    received_1 = Validation.fail(errors_list_1).to_lazy()
    assert received_0 == expected_0
    assert received_1 == expected_1

    errors_list_0 = []
    errors_list_1 = ['error_1']
    errors_list_2 = ['error_2']

# Generated at 2022-06-26 00:19:38.204496
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    a_Validation = Validation.success('A string')
    a_Try = a_Validation.to_lazy()

    assert type(a_Try) == Lazy
    assert a_Try.force() == 'A string'


# Generated at 2022-06-26 00:19:39.432537
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:19:45.215363
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success = Validation.success(42)
    lazy = success.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == 42

    fail = Validation.fail(['error 1'])
    lazy = fail.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() is None


# Generated at 2022-06-26 00:19:47.768336
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(7).to_lazy() == Lazy(lambda: 7)
    assert Validation.fail(['f']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:19:57.800605
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 4
    Validation_0 = Validation(int_0, [])
    Lazy_0 = Validation_0.to_lazy()
    Lazy_0.force()
    print(Lazy_0)
    int_1 = Lazy_0.value
    print(int_1)

    Validation_0 = Validation(int_0, [])
    Lazy_0 = Validation_0.to_lazy()
    Lazy_0.force()
    print(Lazy_0)
    int_1 = Lazy_0.value
    print(int_1)

    Validation_0 = Validation(int_0, [])
    Lazy_0 = Validation_0.to_lazy()
    Lazy_0.force()
    print(Lazy_0)

# Generated at 2022-06-26 00:20:07.617757
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def run(value=None):
        from pymonet.lazy import Lazy

        return Validation(value, []).to_lazy()

    assert run(None) == Lazy(lambda: None)
    assert run(False) == Lazy(lambda: False)
    assert run(True) == Lazy(lambda: True)
    assert run(10) == Lazy(lambda: 10)
    assert run(10.2) == Lazy(lambda: 10.2)
    assert run(set([1, 2, 3])) == Lazy(lambda: set([1, 2, 3]))
    assert run('test') == Lazy(lambda: 'test')
    assert run(['a', 'b', 'c']) == Lazy(lambda: ['a', 'b', 'c'])

# Generated at 2022-06-26 00:20:12.992660
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value_0 == dict_0, "Expected: '%s', Actual: '%s'" % (dict_0, lazy_0.value_0)


# Generated at 2022-06-26 00:20:15.895339
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    validation_0.to_lazy()



# Generated at 2022-06-26 00:20:18.703732
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    dict_0 = Validation(dict_0, dict_0)
    dict_0 = dict_0.to_lazy()

    dict_0 = None



# Generated at 2022-06-26 00:20:21.940346
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(10)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.evaluate()
    var_1 = (var_0 == 10)
    assert var_1 == True



# Generated at 2022-06-26 00:20:31.780828
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.apply() == dict_0

    dict_1 = {}
    validation_1 = Validation(dict_1, dict_0)
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.apply() == dict_1

    dict_2 = {}
    validation_2 = Validation(dict_2, dict_1)
    lazy_2 = validation_2.to_lazy()
    assert lazy_2.apply() == dict_2

    dict_3 = {}
    validation_3 = Validation(dict_3, dict_2)
    lazy_3 = validation_3.to_lazy()
    assert lazy_

# Generated at 2022-06-26 00:20:35.281881
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation(5, []).to_lazy() == Lazy(lambda: 5)
    assert Validation(5, [1, 2]).to_lazy() == Lazy(lambda: 5)


# Generated at 2022-06-26 00:20:40.192984
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:20:43.206785
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    validation_0 = Validation(1, 0)
    assert validation_0.to_lazy() == Lazy(lambda: 1)
    validation_1 = Validation(1, 0)
    assert validation_1.to_lazy() == Lazy(lambda: 1)
    validation_2 = Validation(1, 2)
    validation_3 = Validation(1, 0)
    assert validation_2.to_lazy() != validation_3.to_lazy()


# Generated at 2022-06-26 00:20:46.571899
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()
    assert var_0
    assert var_0.value == dict_0


# Generated at 2022-06-26 00:20:48.979964
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:20:57.203316
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(10).to_lazy() == Lazy(lambda: Box(10).value)
    assert Validation.fail().to_lazy() == Lazy(lambda: Box(None).value)



# Generated at 2022-06-26 00:21:02.167192
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_3 = {}
    validation_3 = Validation(dict_3, dict_3)
    var_3 = validation_3.to_lazy()
    dict_2 = {}
    validation_2 = Validation(dict_2, dict_2)
    var_2 = validation_2.to_lazy()
    assert validation_2 == var_2


# Generated at 2022-06-26 00:21:06.155222
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Unit test for method to_lazy of class Validation
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_var_0 = validation_0.to_lazy()
    try:
        lazy_var_0.get()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 00:21:11.324812
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    # Unit test for method force of class Lazy
    var_0 = lazy_0.force()


# Generated at 2022-06-26 00:21:13.498906
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:21:17.959471
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    validation_0 = validation_0.to_lazy()
    validation_0 = validation_0.get_value()
    lazy_0 = validation_0.endpoint
    assert lazy_0() == dict_0

# Unit tests for method to_maybe of class Validation

# Generated at 2022-06-26 00:21:20.802361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:21:27.866375
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation(mapper, 'K')
    var_0 = validation_0.to_lazy()
    var_1 = True
    var_2 = False
    var_3 = var_0 == var_1
    var_4 = var_2
    var_5 = var_2
    var_6 = var_0 == var_1
    var_7 = var_2
    var_8 = var_0 == Lazy(mapper)
    var_9 = var_8
    var_10 = var_2



# Generated at 2022-06-26 00:21:30.604402
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success([])
    assert isinstance(validation_0.to_lazy(), Lazy)


# Generated at 2022-06-26 00:21:33.665464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = lazy()  # Lazy[Function() -> A]
    validation_0.to_lazy()


# Generated at 2022-06-26 00:21:48.693527
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0: dict
    dict_1: dict
    dict_2: dict
    dict_3: dict
    dict_4: dict
    dict_5: dict
    dict_6: dict
    dict_7: dict
    dict_8: dict
    dict_9: dict
    dict_10: dict
    dict_11: dict
    dict_12: dict
    dict_13: dict
    dict_14: dict
    dict_15: dict
    dict_16: dict
    dict_17: dict
    dict_18: dict
    dict_19: dict
    dict_20: dict
    dict_21: dict
    dict_22: dict
    dict_23: dict
    dict_24: dict
    dict_25: dict
    dict_26: dict
    dict_27: dict
    dict_

# Generated at 2022-06-26 00:21:51.244147
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation.success(42)
    assert validation_0.to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-26 00:21:55.655638
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()

    assert isinstance(var_0, Lazy)
    assert var_0.value().value == dict_0


# Generated at 2022-06-26 00:21:58.749033
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success().to_lazy().get() == None
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([1]).to_lazy().get() == None


# Generated at 2022-06-26 00:22:01.881069
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()
    var_1 = validation_0.to_lazy()
    assert var_0 is not var_1


# Generated at 2022-06-26 00:22:04.184616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation(1, 1)
    assert isinstance(validation_0.to_lazy(), Lazy)

# Generated at 2022-06-26 00:22:06.292805
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    assert validation_0.to_lazy().run() == dict_0


# Generated at 2022-06-26 00:22:08.600984
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == dict_0


# Generated at 2022-06-26 00:22:10.141363
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = None
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:22:12.378634
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success("test")
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == "test"



# Generated at 2022-06-26 00:22:26.630270
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == dict_0


# Generated at 2022-06-26 00:22:33.101047
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()

test_Validation_to_lazy()


# Generated at 2022-06-26 00:22:37.006408
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    expected_0 = validation_0
    actual_0 = validation_0.to_lazy()
    assert_equal(expected_0, actual_0)


# Generated at 2022-06-26 00:22:40.022302
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()
    assert type(var_0) == Lazy



# Generated at 2022-06-26 00:22:53.990328
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def func_0(arg_0: Validation):
        return arg_0.to_lazy()

    def func_1(arg_0: Validation):
        return arg_0.to_lazy()

    def func_3(arg_0: Validation):
        return arg_0.to_lazy()

    Validation.success(1)
    Validation.success(10)
    Validation.success(100)
    Validation.fail([1])
    Validation.fail([10])
    Validation.fail([100])
    Validation.success('a')
    Validation.success('ab')
    Validation.success('abc')
    Validation.fail(['a'])
    Validation.fail(['ab'])
    Validation.fail(['abc'])

# Generated at 2022-06-26 00:22:59.714560
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.lazy import Lazy
    from pymonet.range import Range
    from pymonet.range import RangeNone
    from pymonet.range import Range
    from pymonet.range import Range
    from pymonet.range import RangeNone
    from pymonet.range import RangeNone
    from pymonet.range import Range
    from pymonet.range import RangeRange
    from pymonet.range import RangeNone
    from pymonet.range import RangeRange
    from pymonet.range import RangeNone
    from pymonet.range import Range
    from pymonet.range import RangeRange
    from pymonet.range import RangeNone
    from pymonet.range import RangeNone
    from pymonet.range import RangeNone

# Generated at 2022-06-26 00:23:02.745525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:05.303921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation(4, []).to_lazy() == Lazy(lambda : 4)

# Generated at 2022-06-26 00:23:07.087286
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:15.899520
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    dict_1 = {}
    validation_0 = Validation(dict_0, dict_1)
    result_0 = validation_0.to_lazy()
    validation_1 = Validation(dict_1, dict_0)
    result_1 = validation_1.to_lazy()
    result_2 = validation_0.to_lazy()
    validation_2 = Validation(result_1, validation_0)
    result_3 = validation_2.to_lazy()
    validation_3 = Validation(result_2, validation_2)
    result_4 = validation_3.to_lazy()
    validation_4 = Validation(result_3, validation_3)
    result_5 = validation_4.to_lazy()

# Generated at 2022-06-26 00:23:40.760658
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:43.768565
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()
    assert var_0.value == dict_0


# Generated at 2022-06-26 00:23:53.155002
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Declaration of variable dict_0 of type Dict[str, int]
    dict_0 = {}

    # Declaration of variable validation_0 of type Validation[Dict[str, int], Dict[str, int]]
    validation_0 = Validation(dict_0, dict_0)

    # Declaration of variable var_0 of type Lazy[Function() -> (Dict[str, int] | None)]
    var_0 = validation_0.to_lazy()

    # Calling function f of type function returning None
    f = var_0.f

    # Calling function f of type function returning (Dict[str, int] | None)
    # Calling function f() of type function returning None
    # Calling function f() of type NoneType
    f()



# Generated at 2022-06-26 00:23:55.366317
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:58.287789
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == dict_0


# Generated at 2022-06-26 00:24:00.499428
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    assert validation_0.to_lazy().value() == dict_0


# Generated at 2022-06-26 00:24:02.786642
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == {}


# Generated at 2022-06-26 00:24:04.471678
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:24:09.172756
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()
    var_1 = validation_0.errors

    assert var_0 == Lazy(lambda: var_1)


# Generated at 2022-06-26 00:24:11.654342
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test case 1
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:04.033114
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:07.278799
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0().value == dict_0


# Generated at 2022-06-26 00:25:09.624420
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = Validation(dict_0, dict_0).to_lazy()


# Generated at 2022-06-26 00:25:21.732935
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Maybe
    from pymonet import Lazy
    from pymonet import Monad
    from pymonet.lazy import Lazy
    dict_0 = {}
    dict_1 = {}
    validation_0 = Validation(dict_0, dict_1)
    lazy_0 = validation_0.to_lazy()
    maybe_0 = lazy_0.to_maybe()
    maybe_1 = Maybe.just('monad')
    assertMaybeEquals(maybe_1, maybe_0)
    maybe_2 = maybe_0.bind(lambda data: Maybe.bind(lambda data_1: Maybe.just(data), maybe_1))
    maybe_3 = Maybe.nothing()
    assertMaybeEquals(maybe_3, maybe_0)
    maybe_4 = Maybe.just('monad')
   

# Generated at 2022-06-26 00:25:24.318966
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()




# Generated at 2022-06-26 00:25:30.902556
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation_0 = Validation.fail([])
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:33.992795
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_1 = Validation(dict_0, dict_0)
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:37.174563
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print('Test method to_lazy of class Validation')
    validation_0 = Validation(42, 42)
    monad_0 = validation_0.to_lazy()
    var_0 = monad_0.raw()
    assert var_0 == 42


# Generated at 2022-06-26 00:25:40.669506
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()
    assert var_0.get_value() == dict_0


# Generated at 2022-06-26 00:25:42.638612
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:27:39.947039
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:27:41.615496
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation("string", [])
    lazy_0 = validation_0.to_lazy()
    value = lazy_0.value()
    assert value == "string"


# Generated at 2022-06-26 00:27:49.989512
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.map(lambda x: None)



# Generated at 2022-06-26 00:27:57.525069
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests method to_lazy of class Validation
    """
    from pymonet.lazy import Lazy

    # Validation is success
    map_0 = {}
    validation_0 = Validation(map_0, [])
    lazy_0 = Lazy(lambda: map_0)
    assert(validation_0.to_lazy() == lazy_0)
    # Validation is failure
    list_0 = []
    validation_1 = Validation(None, list_0)
    lazy_1 = Lazy(lambda: None)
    assert (validation_1.to_lazy() == lazy_1)



# Generated at 2022-06-26 00:27:59.370265
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success({})
    assert isinstance(validation_0.to_lazy(), Lazy)


# Generated at 2022-06-26 00:28:09.308957
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert (lazy_0.get() == dict_0)
    assert (isinstance(lazy_0, Lazy))

    dict_1 = {}
    validation_1 = Validation(dict_1, dict_1)
    lazy_1 = validation_1.to_lazy()
    assert (lazy_1.get() == dict_1)
    assert (isinstance(lazy_1, Lazy))

    dict_2 = {}
    validation_2 = Validation(dict_2, dict_2)
    lazy_2 = validation_2.to_lazy()
    assert (lazy_2.get() == dict_2)

# Generated at 2022-06-26 00:28:17.444051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    validation_0 = Validation.success(True)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.value()

    validation_1 = Validation.fail(False)
    lazy_1 = validation_1.to_lazy()
    var_1 = lazy_1.value()

    validation_2 = Validation.success(False)
    lazy_2 = validation_2.to_lazy()
    var_2 = lazy_2.value()

    validation_3 = Validation.fail(False)
    lazy_3 = validation_3.to_lazy()
    var

# Generated at 2022-06-26 00:28:19.600572
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    validation_0.to_lazy()
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:28:22.166582
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_0 = Validation.success("a")
    val_1 = val_0.to_lazy()
    val_2 = val_1.value()
