

# Generated at 2022-06-26 00:18:34.506153
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy."""
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_1 = [str_1]
    validation_1 = Validation(str_1, list_1)
    validation_2 = validation_1.to_lazy()
    str_2 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_2 = [str_2]
    validation_3 = Validation(str_2, list_2)
    validation_4 = validation_3.to_lazy()
    bool_0 = validation_2 == validation_4
    assert bool_0



# Generated at 2022-06-26 00:18:38.797058
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_0 = [str_0]
    validation_0 = Validation(str_0, list_0)

    assert validation_0.to_lazy().value() == validation_0.value


# Generated at 2022-06-26 00:18:46.575106
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_0 = [str_0]
    validation_0 = Validation(str_0, list_0)
    lazy_0 = validation_0.to_lazy()
    bool_0 = isinstance(lazy_0, Lazy)
    assert bool_0
    value = lazy_0.value()
    bool_0 = isinstance(value, str)
    assert bool_0
    bool_1 = (value == str_0)
    assert bool_1


# Generated at 2022-06-26 00:19:01.604592
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # testing monad
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_0 = [str_0]
    validation_0 = Validation(str_0, list_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.is_instance_of(Lazy)
    assert lazy_0.is_instance_of(Lazy)
    assert lazy_0.is_instance_of(Lazy)

# Generated at 2022-06-26 00:19:05.949849
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_0 = [str_0]
    validation_0 = Validation(str_0, list_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:06.837581
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()


# Generated at 2022-06-26 00:19:11.238322
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_0 = [str_0]
    validation_0 = Validation(str_0, list_0)

    # Test method with parameters: ()
    lazy_0 = validation_0.to_lazy()

    # Test method with parameters: ()
    lazy_0.force()
    assert True



# Generated at 2022-06-26 00:19:21.193599
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    :returns: Copy of self
    :rtype: Left[A]
    """
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    list_0 = [str_0]
    validation_0 = Validation(str_1, list_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:24.767527
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy method.
    """
    from pymonet.lazy import Lazy

    validation = Validation.fail(['Sth went wrong'])
    assert validation.to_lazy() == Lazy(validation.value)

# Generated at 2022-06-26 00:19:26.811986
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Test case 0
    lazy_0 = test_case_0()
    # Assertion
    assert False, 'Test case 0'



# Generated at 2022-06-26 00:19:32.728516
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:19:45.910979
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert str(Validation.success(Lazy(lambda: True)).to_lazy()) == 'Lazy({})'.format(str(True))
    assert str(Validation.success(Try(True)).to_lazy()) == 'Lazy({})'.format(str(True))
    assert str(Validation.success(Try(True, is_success=False)).to_lazy()) == 'Lazy({})'.format(str(None))
    try:
        Validation.success(Lazy(lambda: Try(True))).to_lazy()
        assert False
    except Exception:
        pass

# Generated at 2022-06-26 00:19:55.970239
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    lazy_0 = validation_0.to_lazy()

    assert Functor.functor_map(str.upper, lazy_0) == Try(str_0, is_success=None).to_lazy()
    assert Functor.functor_map(str.upper, validation_0.to_lazy()) != validation_0.to_lazy()

    lazy_1 = validation_0.to_lazy()


# Generated at 2022-06-26 00:20:02.488810
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    lazy_0 = Validation(str_0, str_0).to_lazy()
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    lazy_1 = Lazy(lambda: str_1)
    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:20:04.077498
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    function_0 = Validation.to_lazy

    assert isinstance(function_0(), Lazy)


# Generated at 2022-06-26 00:20:05.904963
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    result = validation_0.to_lazy()
    assert isinstance(result, Lazy), 'Expected Lazy. Actual: (%s).' % type(result)


# Generated at 2022-06-26 00:20:11.113525
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit testing class Validation method to_lazy.

    """
    from pymonet.lazy import Lazy

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    lazy_0 = Lazy(lambda: (str_0))
    lazy_1 = validation_0.to_lazy()

    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:20:20.434871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_1 = Validation.success(str_1)
    lazy_2 = validation_1.to_lazy()
    assert lazy_2 == Lazy(lambda: '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')
    assert lazy_2.is_success() == True
    assert lazy_2.is_fail() == False
    str_3 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_2 = Validation.fail(str_3)
    lazy_1 = validation_2.to_lazy()

# Generated at 2022-06-26 00:20:23.657138
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    result_0 = Validation.success(str_0).to_lazy()
    assert result_0.value() == str_0

# Generated at 2022-06-26 00:20:26.507399
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value = 'a'
    errors = 'b'
    validation_0 = Validation(value, errors)
    assert validation_0.to_lazy().get() == value


# Generated at 2022-06-26 00:20:28.876984
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass

# Generated at 2022-06-26 00:20:33.793990
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    val_0 = Validation.success(str_0)
    assert str_0 == val_0.value
    assert val_0.value == Lazy(val_0.value).value


# Generated at 2022-06-26 00:20:44.997696
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')
    assert Validation.success([]).to_lazy() == Lazy(lambda: [])
    assert Validation.success({}).to_lazy() == Lazy(lambda: {})
    assert Validation.success(True).to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-26 00:20:51.650076
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_case(_):
        value_1 = 'fubar'
        input_0 = Validation.success(value_1)
        expected_0 = Lazy(lambda: input_0.value)

        output_0 = input_0.to_lazy()

        assert output_0 == expected_0, 'expected: {:}, obtained: {:}'.format(expected_0, output_0)

    for _ in range(1000):
        test_case(_)


# Generated at 2022-06-26 00:21:00.574254
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    a = Validation.fail("error")
    b = Validation.success("success")

    assert a.to_lazy() == Lazy(lambda: None)
    assert b.to_lazy() == Lazy(lambda: "success")


# Generated at 2022-06-26 00:21:09.505942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Transform Validation to Try.\n\n        :returns: Lazy monad with function returning Validation value\n        :rtype: Lazy[Function() -> (A | None)]\n        '

    # Test Case 1
    validation_0 = Validation.fail()
    lazy_0 = validation_0.to_lazy()
    lazy_0.call()
    assert lazy_0 == None

    # Test Case 2
    validation_1 = Validation.success(5)
    lazy_1 = validation_1.to_lazy()
    lazy_1.call()
    assert lazy_1 == 5

    # Test Case 3
    validation_2 = Validation.fail()
    lazy_2 = validation_2.to_lazy()
    lazy_2.call()
    assert lazy_

# Generated at 2022-06-26 00:21:17.406956
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success('abc')

    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.computed is False
    assert lazy.value == 'abc'
    assert lazy.computed is True

    validation = Validation.fail(['aaaaaaaaaaa'])

    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.computed is False
    assert lazy.value == None
    assert lazy.computed is True


# Generated at 2022-06-26 00:21:22.863994
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    value = Lazy(lambda: Maybe.just(1))
    validation = Validation.success(value)
    actual = validation.to_lazy()

    assert value == actual.value
    assert isinstance(actual, Lazy)
    assert isinstance(actual.value, Maybe)
    assert actual.value.is_just()
    assert actual.value.get_or_else(None) == 1


# Generated at 2022-06-26 00:21:27.663754
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.either import Left

    val_0 = Validation(Left(None), [])

    res_0 = val_0.to_lazy()

    assert res_0.is_instance_of(Lazy)
    assert res_0.is_equal(Lazy(lambda: Left(None)))


# Generated at 2022-06-26 00:21:33.487709
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def mapper(value):
        return Lazy(lambda: value)

    assert mapper(Lazy(lambda: 42)) == Validation.success(42).to_lazy()

    assert mapper(Lazy(lambda: 42)) != Validation.fail(['some error']).to_lazy()


# Generated at 2022-06-26 00:21:38.293238
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(None, None)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.is_equals(Lazy(lambda: None)) == True


# Generated at 2022-06-26 00:21:43.556750
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy = Validation.to_lazy(validation_0)
    assert lazy.thunk() == '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '


# Generated at 2022-06-26 00:21:50.161457
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(Box(2)).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(Try(2)).to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-26 00:21:56.866830
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.value()
    assert str_1 == str_0
    validation_1 = Validation.success()
    lazy_1 = validation_1.to_lazy()
    str_2 = lazy_1.value()
    assert str_2 is None


# Generated at 2022-06-26 00:22:03.020372
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    def test_case_0():
        str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
        validation_0 = Validation(str_0, str_0)
        lazy_0 = validation_0.to_lazy()
        lazy_1 = Lazy(lambda: str_0)
        assert lazy_0 == lazy_1

    test_case_0()


# Generated at 2022-06-26 00:22:08.521686
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_1 = Validation(str_0, str_1)
    validation_0 = validation_0.to_lazy()
    validation_0.value == validation_1.value



# Generated at 2022-06-26 00:22:12.101612
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    assert validation_0 == validation_0.to_lazy().get()


# Generated at 2022-06-26 00:22:20.531218
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert str_0 == lazy_0.value()
    int_0 = 2
    validation_1 = Validation(int_0, int_0)
    lazy_1 = validation_1.to_lazy()
    assert int_0 == lazy_1.value()
    box_0 = validation_0.to_box()
    assert str_0 == box_0.value
    either_0 = validation_1.to_either()
    assert int_0 == either_0.value()
    maybe_0 = validation_1.to_maybe()
    assert int

# Generated at 2022-06-26 00:22:24.087312
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:28.816194
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = lazy_1 = Lazy(lambda: lambda: None)
    validation_1 = validation_0.to_lazy()
    assert lazy_0 == lazy_1
    assert validation_0 != validation_1


# Generated at 2022-06-26 00:22:36.564554
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Some tests
    assert str(Validation.success('foo').to_lazy()) == 'Lazy(function() -> (foo))'
    assert str(Validation.fail([]).to_lazy()) == 'Lazy(function() -> (None))'


# Generated at 2022-06-26 00:22:41.499375
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    print("test_Validation_to_lazy:")
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    lazy_0 = Validation.success(str_0).to_lazy()
    assert lazy_0.value() == str_1

# Generated at 2022-06-26 00:22:45.182427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    pass


# Generated at 2022-06-26 00:22:50.756785
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    assert validation_0.to_lazy() == Lazy(lambda:  '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')

# Generated at 2022-06-26 00:22:53.414018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        test_case_0()
        assert True
    except:
        assert False



# Generated at 2022-06-26 00:22:59.888049
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert str_0 == lazy_0.memoized_value


# Generated at 2022-06-26 00:23:06.823941
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_instance_0 = validation_0.to_lazy()

    assert isinstance(lazy_instance_0, Lazy) and lazy_instance_0() == '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ', \
        "Validation.to_lazy returned incorrect instance"



# Generated at 2022-06-26 00:23:11.557797
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, [])
    if validation_0.to_lazy().get() == str_0:
        print("Test test_Validation_to_lazy ran successfully")
    else:
        print("Test test_Validation_to_lazy failed")


# Generated at 2022-06-26 00:23:16.448689
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    assertion_0 = validation_0.to_lazy()
    assertion_1 = assertion_0.unbox()

    assert assertion_0 is not None
    assert assertion_1 == str_0


# Generated at 2022-06-26 00:23:19.859809
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    assert validation_0.to_lazy().get() == validation_0.value



# Generated at 2022-06-26 00:23:34.960990
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == str_0
    set_0 = set()
    lazy_1 = validation_0.to_lazy()
    assert lazy_1.value() == str_0
    dict_0 = dict()
    lazy_2 = validation_0.to_lazy()
    assert lazy_2.value() == str_0
    str_1 = '<div>\n    <p>Hello world!</p>\n</div>'
    validation_1 = Validation(str_1, str_1)

# Generated at 2022-06-26 00:23:39.103598
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    assert validation_0.to_lazy().get() == str_0


# Generated at 2022-06-26 00:23:42.575463
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation.success('\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')
    assert type(validation_0.to_lazy()) == Lazy


# Generated at 2022-06-26 00:23:46.744990
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    validation_1 = lazy_0.get()
    assert validation_1 == validation_0

# Generated at 2022-06-26 00:23:56.133651
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def mock_func_0(x):
        return x

    validation_0 = Validation.fail('sWF0')
    validation_0 = validation_0.ap(mock_func_0)
    mock_func_1 = mock_func_0
    validation_1 = validation_0.ap(mock_func_1)
    mock_func_2 = mock_func_1
    validation_2 = validation_1.ap(mock_func_2)
    mock_func_3 = mock_func_1
    validation_3 = validation_2.ap(mock_func_3)
    mock_func_4 = mock_func_3
    validation_4 = validation_3.ap(mock_func_4)
    mock_func_5 = mock_func_2

# Generated at 2022-06-26 00:24:00.864770
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    lazy_0 = validation_0.to_lazy()
    value = lazy_0.evaluate()
    assert value == str_0


if __name__ == '__main__':  # pragma: no cover
    test_case_0()

# Generated at 2022-06-26 00:24:03.135173
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation('test', 'test')
    assert validation.to_lazy() == Lazy(lambda: 'test')



# Generated at 2022-06-26 00:24:08.467010
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    lazy = validation_0.to_lazy()

    assert(isinstance(lazy, Lazy))
    assert(validation_0.value == lazy.force())


# Generated at 2022-06-26 00:24:13.216226
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    # Test method Validation.to_lazy
    assert validation_0.to_lazy() == Lazy(lambda: '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')



# Generated at 2022-06-26 00:24:19.849915
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    try:
        str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
        lazy_0 = Validation(str_0, str_0).to_lazy()
        lazy_0.value()
    except Exception:
        raise
    else:
        pass


# Generated at 2022-06-26 00:24:40.142311
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test for method to_lazy of class Validation
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '  # type: str
    validation_0 = Validation(str_0, str_0)  # type: Validation[str, str]
    validation_1 = validation_0.to_lazy()  # type: Lazy[Function() -> (str | None)]



# Generated at 2022-06-26 00:24:42.108491
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    test_case_0()



# Generated at 2022-06-26 00:24:46.643310
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()

    assert lazy_0.is_instance()
    assert lazy_0.value == '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '


# Generated at 2022-06-26 00:24:50.860004
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, [])

    lazy_0 = validation_0.to_lazy()

    assert lazy_0 == Lazy(lambda: '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')


# Generated at 2022-06-26 00:24:55.011505
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == str_0


# Generated at 2022-06-26 00:24:59.268981
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    validation_1 = validation_0.to_lazy()
    assert validation_1.value() == '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '


# Generated at 2022-06-26 00:25:03.604825
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    value_0 = lazy_0.value
    assert value_0 == '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '


# Generated at 2022-06-26 00:25:15.214492
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_try import UnitTestFailureException
    import traceback


# Generated at 2022-06-26 00:25:19.970704
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    try_0 = validation_0.to_lazy()
    try_1 = Try(try_0.value, is_success=try_0.is_success())


# Generated at 2022-06-26 00:25:22.778856
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)

    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1


# Generated at 2022-06-26 00:25:57.120398
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_1 = Validation(str_1, '')

    lazy_1 = validation_1.to_lazy()
    assert not lazy_1.is_forced()
    assert lazy_1.map(lambda v: len(v)).get_force_result() == len(str_1)



# Generated at 2022-06-26 00:26:00.931724
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy = validation_0.to_lazy()
    assert lazy.value() == str_0


# Generated at 2022-06-26 00:26:09.629223
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation('\n                :returns: Copy of self\n                :rtype: Left[A]\n                ', [])
    validation_1 = Validation.success('1')
    validation_2 = Validation.fail([])
    validation_3 = Validation.fail(['InvalidEmail', 'InvalidLogin'])
    assert validation_0.to_lazy() == Lazy('\n                :returns: Copy of self\n                :rtype: Left[A]\n                ')
    assert validation_1.to_lazy() == Lazy('1')
    assert validation_2.to_lazy() == Lazy(None)
    assert validation_3.to_lazy() == Lazy(None)


# Generated at 2022-06-26 00:26:15.436974
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    # assert validation_0.to_lazy() == Lazy(lambda: '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')
    assert validation_0.to_lazy() == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:26:23.559259
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test case 0
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.lazy_value == str_0

    # Test case 1
    tuple_0 = (1, True, 2)
    validation_0 = Validation(tuple_0, True)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.lazy_value == tuple_0

    # Test case 2
    tuple_0 = (1, True, 2)
    validation_0 = Validation(tuple_0, False)
    lazy_0 = validation_0.to_lazy()

# Generated at 2022-06-26 00:26:29.769611
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tests to_lazy function of Validation
    """

    def test_case_lazy(val, val_lazy):
        str_lazy = val_lazy()

        success = str_lazy == val
        return success

    val = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    val_lazy = Validation(val, val).to_lazy()

    # Test case
    success_0 = test_case_lazy(val, val_lazy)
    assert success_0

    return success_0



# Generated at 2022-06-26 00:26:31.160562
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation(None, [])
    lazy = validation.to_lazy()
    assert lazy.get() is validation.value


# Generated at 2022-06-26 00:26:34.404853
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    result = validation_0.to_lazy()

    assert result == Lazy(lambda: str_0)



# Generated at 2022-06-26 00:26:36.629396
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail([2]).to_lazy().value() == None
    assert Validation.success("a").to_lazy().value() == "a"

# Generated at 2022-06-26 00:26:41.206703
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    fn, result = None, None
    for _ in range(100000):
        fn, result = Validation.success(5).to_lazy()
        assert result == 5
        if result != 5:
            print('Test case 0 failed')
            assert False

        fn, result = Validation.fail('Ooops').to_lazy()
        if result != None:
            print('Test case 1 failed')
            assert False
    print('Test case 2 passed')


# Generated at 2022-06-26 00:27:58.788594
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation(1, 1)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == Lazy(lambda: 1)
    assert lazy_0 != Lazy(lambda: 2)


# Generated at 2022-06-26 00:28:02.745766
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    assert validation_0.to_lazy().run() == str_0


# Generated at 2022-06-26 00:28:06.152378
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation('1').to_lazy() == Lazy(lambda: '1')


# Generated at 2022-06-26 00:28:16.219228
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_1 = Validation(str_0, str_0)

    validation_2 = validation_0.to_lazy()
    validation_3 = validation_1.to_lazy()
    validation_4 = validation_2.to_lazy()
    validation_5 = validation_3.to_lazy()
    validation_6 = validation_4.to_lazy()
    validation_7 = validation_5.to_lazy()
    validation_8 = validation_6.to_

# Generated at 2022-06-26 00:28:21.593088
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import inspect
    from pymonet.lazy import Lazy
    validation_0 = Lazy(lambda: '\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')
    validation_1 = Validation.success('\n        :returns: Copy of self\n        :rtype: Left[A]\n        ')
    validation_2 = validation_1.to_lazy()
    assert validation_2 == validation_0


# Generated at 2022-06-26 00:28:24.490605
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        :returns: Copy of self\n        :rtype: Left[A]\n        '
    validation_0 = Validation(str_0, str_0)

    validation_1 = validation_0.to_lazy()
    assert validation_0.value == validation_1.claim()
