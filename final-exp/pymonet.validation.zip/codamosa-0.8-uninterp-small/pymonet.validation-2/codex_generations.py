

# Generated at 2022-06-26 00:18:22.971280
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation_0 = validation_fail_0()
    validation_1 = validation_fail_1()
    assert validation_0 == validation_1
    validation_0 = validation_success_0()
    assert validation_0 == Validation.success([])
    validation_0 = validation_success_1()
    validation_1 = Validation(list_0, [])
    assert validation_0 == validation_1
    assert validation_0 == Validation.success(list_0)


# Generated at 2022-06-26 00:18:26.056821
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try, Failure
    from pymonet.lazy import Lazy

    def test_f():
        return 1 / 0

    try_0 = Try(test_f)
    assert isinstance(try_0, Failure)

    lazy_0 = Lazy(test_f)
    assert isinstance(lazy_0(), Failure)
    assert isinstance(lazy_0.to_try(), Failure)



# Generated at 2022-06-26 00:18:28.461421
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    list_0 = []
    validation_0 = Validation.fail(list_0)
    validation_1 = Validation.fail(list_0)
    assert validation_0 == validation_1


# Generated at 2022-06-26 00:18:33.374203
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    list_0 = []
    list_1 = []
    validation_0 = Validation(list_0, list_0)
    validation_1 = Validation(list_0, list_1)
    validation_2 = Validation(list_1, list_1)
    assert(validation_0 == validation_1)
    assert(validation_0 != validation_2)


# Generated at 2022-06-26 00:18:43.019861
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    assert validation_0 == validation_0
    validation_1 = Validation(list_0, list_0)
    assert validation_0 == validation_1
    validation_0 = Validation(list_0, ['Error'])
    assert validation_0 != validation_1
    validation_1 = Validation(list_0, ['Error'])
    assert validation_0 == validation_1
    validation_0 = Validation('value', ['Error'])
    assert validation_0 != validation_1
    validation_1 = Validation('value', ['Error'])
    assert validation_0 == validation_1
    validation_0 = Validation('value', [])
    assert validation_0 != validation_1

# Generated at 2022-06-26 00:18:46.988803
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_try import Try

    def get_list():
        return list()

    lazy = Validation.success(get_list()).to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.value(), Try)

# Generated at 2022-06-26 00:18:52.205465
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    list_0 = []
    assert Validation(list_0, list_0) == Validation(list_0, list_0)


# Generated at 2022-06-26 00:19:02.487160
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    list_0 = [True, False]
    list_1 = [True, False]
    validation_0 = Validation(list_0, list_1)
    list_2 = []
    list_3 = []
    validation_1 = Validation(list_2, list_3)
    list_4 = []
    list_5 = []
    validation_2 = Validation(list_4, list_5)
    assert validation_0 == validation_1
    assert validation_1 == validation_2


# Generated at 2022-06-26 00:19:10.974073
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests Validation.to_lazy method.
    """
    from pymonet.either import Left
    from pymonet.errors import Errors
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(True).to_lazy() == Lazy(lambda: True)
    assert Validation.fail(Errors.multiple('invalid value')).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-26 00:19:13.850309
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    assert(validation_0 == validation_0)



# Generated at 2022-06-26 00:19:21.187614
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = Validation.success()
    assert var_0.to_lazy() == Lazy(lambda: var_0.value)

test_Validation_to_lazy()


# Generated at 2022-06-26 00:19:28.233039
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    var_0 = Validation.success(1)
    var_1 = Validation.success(1)
    assert var_0 == var_1
    var_2 = Validation.fail(['0'])
    var_3 = Validation.success(1)
    assert var_2 != var_3
    var_4 = Validation.fail(['0'])
    var_5 = Validation.fail(['0'])
    assert var_4 == var_5
    var_6 = Validation.success(1)
    assert var_6 != 'irgendwas'


# Generated at 2022-06-26 00:19:31.627763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_0 = Validation.success("foo")
    var_1 = Validation.fail("foo")
    assert var_0.to_lazy().value() == "foo"
    assert var_1.to_lazy().value() == None


# Generated at 2022-06-26 00:19:44.568161
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    try:
        cmp_0 = Validation.success(1)
        cmp_1 = Validation.success(1)
        cmp_2 = Validation.fail(1)
        cmp_3 = Validation.fail(2)
        cmp_4 = Validation.success()
        cmp_5 = Validation.fail()
        cmp_6 = Validation.fail(1)
        cmp_7 = Validation.success()
        cmp_8 = Validation.fail()
        assert (cmp_0 == cmp_1)
        assert (cmp_2 == cmp_3)
        assert (cmp_4 == cmp_5)
        assert (cmp_6 != cmp_7)
        assert (cmp_7 != cmp_8)
    except AssertionError as e:
        return

# Generated at 2022-06-26 00:19:47.615317
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    var_0 = Validation.success(10)
    var_1 = Lazy(lambda: 10)
    assert(var_0.to_lazy() == var_1)


# Generated at 2022-06-26 00:19:50.134747
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    try:
        Validation.success(1) == Validation.success(1)
        test_case_0()
    except NotImplementedError:
        return False


# Generated at 2022-06-26 00:19:53.308224
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    var_1 = Validation.success()
    var_2 = Validation.fail()
    try:
        var_1.to_lazy()
        assert True
    except Exception:
        assert False


# Generated at 2022-06-26 00:19:56.661633
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert callable(Validation.to_lazy)
    assert isinstance(Validation.success().to_lazy(), Lazy)


# Generated at 2022-06-26 00:20:01.253563
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Name: test_Validation___eq__
    Tag: Validation
    """
    var_1 = Validation.success()
    var_2 = Validation.success()

    assert var_1 == var_2
    assert var_1.__eq__(var_2)


# Generated at 2022-06-26 00:20:02.244673
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    pass


# Generated at 2022-06-26 00:20:10.889635
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def is_lazy(obj):
        return isinstance(obj, Lazy) and obj.func is not None

    assert is_lazy(Validation.success([1, 2, 3]).to_lazy())
    assert is_lazy(Validation.fail(['Error Message']).to_lazy())

    try:
        Validation(None, [1, 2, 3]).to_lazy().get()
        assert False
    except AssertionError:
        pass
    assert Validation.success([]).to_lazy().get() == []


# Generated at 2022-06-26 00:20:15.969914
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().run() == 1
    assert Validation.fail([]).to_lazy().run() == None
    assert Validation.fail([1]).to_lazy().run() == None
    assert Validation.fail([1, 2]).to_lazy().run() == None
    assert Validation.success().to_lazy().run() == None


# Generated at 2022-06-26 00:20:22.151738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # list_0 = []
    # validation_0 = Validation(list_0, list_0)
    # lazy_0 = validation_0.to_lazy()
    # function_0 = lazy_0.value
    # str_0 = str(function_0)
    # assert str_0 == '<function test_case_0.<locals>.<lambda> at 0x7f8973151ea0>'
    assert False

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 00:20:27.671777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # positive test case for method to_lazy
    list_0 = []
    validation_0 = Validation.success(list_0)
    monad_0 = validation_0.to_lazy()
    assert hasattr(monad_0, 'value')
    list_1 = monad_0.value()
    assert list_0 == list_1
    assert len(list_0) == len(list_1)


# Generated at 2022-06-26 00:20:32.601154
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success(0)
    lazy_0 = validation_0.to_lazy()
    value_0 = lazy_0.value()

    assert value_0 == 0, 'values are not equal'
    assert validation_0.value == value_0, 'values are not equal'



# Generated at 2022-06-26 00:20:41.161336
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Create Validation with value and empty errors list
    value_0 = ''
    errors_0 = []
    validation_0 = Validation(value_0, errors_0)

    # Transform Validation to Lazy
    lazy_0 = validation_0.to_lazy()

    # Call Lazy and get value
    actual = lazy_0.get()

    # Call Lazy and get value
    expected = value_0

    assert actual == expected


# Generated at 2022-06-26 00:20:43.199695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = Validation(list_0, list_0).to_lazy()
    assert (not list_0)


# Generated at 2022-06-26 00:20:47.967552
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure, Success

    validation = Validation(1, [])
    try_ = validation.to_try()

    assert isinstance(try_, Success)

    validation = Validation(None, [{}])
    try_ = validation.to_try()

    assert isinstance(try_, Failure)



# Generated at 2022-06-26 00:20:55.968994
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation_0 = Validation(True, True)
    lazy_0 = validation_0.to_lazy()
    boolean_0 = lazy_0.is_lazy()
    assert boolean_0
    with pytest.raises(TypeError) as excinfo:
        lazy_0.is_value()
    assert "'bool' object is not callable" in str(excinfo.value)
    boolean_1 = lazy_0.is_nothing()
    assert boolean_1 == False
    lazy_1 = lazy_0.map(lambda x: x)
    lazy_1 = lazy_0.bind(lambda x: Lazy(lambda: x))


# Generated at 2022-06-26 00:20:58.632849
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)

    try:
        validation_to_lazy_0 = validation_0.to_lazy()
        __logger.info('Test method to_lazy for class Validation: successful')
    except Exception as error:
        __logger.error('Test method to_lazy for class Validation: error - ' + str(error))
        raise error
    return

# Generated at 2022-06-26 00:21:06.530057
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = [1, 2, 3]
    validation_0 = Validation.success(list_0)

    lazy_0 = validation_0.to_lazy()

    assert lazy_0.value == list_0
    assert lazy_0.is_memoized() == False
    assert lazy_0.run() == list_0
    assert lazy_0.is_memoized() == True


# Generated at 2022-06-26 00:21:09.629258
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == list_0


# Generated at 2022-06-26 00:21:13.615208
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v1 = Validation.success(1)
    v2 = Validation.fail([])
    assert v1.to_lazy() == Lazy(lambda: 1)
    assert v2.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:19.418306
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def my_function():
        return 3

    lazy_0 = Validation.success(my_function).to_lazy()
    lazy_1 = Validation.success(my_function).to_lazy()
    try_0 = Validation.success(my_function).to_lazy().value()

    assert lazy_0 == lazy_1
    assert try_0 == Try(3)


# Generated at 2022-06-26 00:21:23.180861
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    simple_value = 1
    validation_0 = Validation.success(simple_value)

    # check for simple value
    assert validation_0.to_lazy().get() == simple_value

    # check internal state
    assert validation_0.value == simple_value
    assert validation_0.errors == []



# Generated at 2022-06-26 00:21:26.565618
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.lazy import Lazy

    assert (Validation.success(5).to_lazy() ==
            Validation.success(5).to_lazy())



# Generated at 2022-06-26 00:21:29.415495
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation.success(list_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.call()


# Generated at 2022-06-26 00:21:32.967334
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = [1, 2, 3]
    validation_0 = Validation.success(list_0)
    lazy = validation_0.to_lazy()
    assert lazy.invoke() == list_0
    assert lazy.invoke() is list_0


# Generated at 2022-06-26 00:21:36.359099
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == validation_0.value


# Generated at 2022-06-26 00:21:46.392542
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    val_0 = Validation.success(1)
    val_1 = Validation.fail([])
    val_2 = Validation.success(2)
    val_3 = Validation.fail(['er'])
    val_4 = Validation.success(3)
    val_5 = Validation.fail(['err', 'errr'])

    assert val_0.to_lazy() == Lazy(1)
    assert val_1.to_lazy() == Lazy(None)
    assert val_2.to_lazy() == Lazy(2)
    assert val_3.to_lazy() == L

# Generated at 2022-06-26 00:21:55.493264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy
    list_0 = []
    success_validation = Validation(list_0, [])
    assert isinstance(success_validation.to_lazy(), Lazy)


# Generated at 2022-06-26 00:21:58.881318
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    print('Test for Validation.to_lazy')

    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success('a').to_lazy() == Lazy(lambda: 'a')



# Generated at 2022-06-26 00:22:02.002877
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    list_0 = []
    validation_0 = Validation(list_0, list_0)
    result_0 = validation_0.to_lazy()

    assert isinstance(result_0, Lazy)


# Generated at 2022-06-26 00:22:05.301782
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_4 = validation_0.to_lazy()
    expected = Lazy(lambda: list_0)
    assert lazy_4 == expected


# Generated at 2022-06-26 00:22:07.045427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()


if __name__ == '__main__':
    test_Validation_to_lazy()

# Generated at 2022-06-26 00:22:15.447937
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests method to_lazy of class Validation. There are three cases.

    1. Validation is success
    2. Validation is failure
    3. Validation contains None value and no errors
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    value = 10
    validation_0 = Validation.success(value)
    lazy = validation_0.to_lazy()
    assert lazy.get() == value
    validation_1 = Validation.fail(['type error'])
    lazy = validation_1.to_lazy()
    assert type(lazy.get()) == Try
    assert lazy.get().is_fail()
    validation_2 = Validation(None, [])
    lazy = validation_2.to_lazy()
    assert lazy

# Generated at 2022-06-26 00:22:18.504876
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy_0 = Validation.success([1, 2, 3]).to_lazy()
    assert(isinstance(lazy_0, Lazy) and lazy_0.f() == [1, 2, 3])



# Generated at 2022-06-26 00:22:21.321101
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()
    assert_equals(lazy_0.value, list_0)


# Generated at 2022-06-26 00:22:26.211802
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.util import assert_equals

    validation_0 = Validation.success(1)
    validation_5 = Validation.fail([1, 2, 3])

    assert_equals(validation_0.to_lazy().get(), 1)
    assert_equals(validation_5.to_lazy().get(), None)



# Generated at 2022-06-26 00:22:33.003283
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get_value() == list_0


# Generated at 2022-06-26 00:22:56.398881
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    list_0.append(validation_0.to_lazy())
    validation_2 = Validation(0, [])
    lazy_1 = validation_0.to_lazy()
    validation_3 = validation_0.to_lazy()
    list_0.append(lazy_1)
    lazy_2 = validation_2.to_lazy()
    list_0.append(validation_0.to_lazy())
    list_0.append(validation_3)
    list_0.append(lazy_2)
    list_0.append(lazy_1)
    list_0.append(validation_0.to_lazy())

# Generated at 2022-06-26 00:23:01.748485
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    # Test with "lazy" = Lazy[Function() -> Any]
    from pymonet.lazy import Lazy
    lazy_0 = Lazy(lambda : list_0)
    validation_1 = validation_0.to_lazy()
    assert validation_1 == lazy_0

# Generated at 2022-06-26 00:23:04.728736
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 2
    validation = Validation.success(f)

    print(validation.to_lazy())


# Generated at 2022-06-26 00:23:12.533167
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Case 1:
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()

    if not isinstance(lazy_0, Lazy):
        print('!! test_Validation_to_lazy failed: (0)')
    elif not lazy_0.value.is_success():
        print('!! test_Validation_to_lazy failed: (1)')
    elif lazy_0.value.value != list_0:
        print('!! test_Validation_to_lazy failed: (2)')
    else:
        print('!! test_Validation_to_lazy correct: (3)')

# Generated at 2022-06-26 00:23:21.236814
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    validation_0 = Validation.success()
    lazy_0 = validation_0.to_lazy()
    try_0 = validation_0.to_lazy().to_try()

    assert lazy_0 == Lazy(lambda: None) and try_0 == Try.success(None)

    validation_1 = Validation.success(2)
    lazy_1 = validation_1.to_lazy()
    try_1 = validation_1.to_lazy().to_try()

    assert lazy_1 == Lazy(lambda: 2) and try_1 == Try.success(2)

    validation_2 = Validation.fail()
    lazy_2 = validation_2

# Generated at 2022-06-26 00:23:23.180477
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    box_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:26.697160
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import partial
    list_0 = [1, 2]
    validation_0 = Validation.success(list_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0 = lazy_0.map(partial(sum))
    assert lazy_0.get() == 3


# Generated at 2022-06-26 00:23:30.242682
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    expected_value = 'lazy'
    validation_instance = Validation(expected_value, [])
    actual_value = validation_instance.to_lazy()
    assert actual_value.value() == expected_value



# Generated at 2022-06-26 00:23:32.708541
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = [1, 2, 3]
    validation_0 = Validation(list_0, 5)
    assert validation_0.to_lazy().value() == list_0


# Generated at 2022-06-26 00:23:41.538776
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    A -> [Number -> A]
    """

    def list_remove_item_by_index(list_, index):
        """
        Remove item from list and returns new value.
        Difference from list.remove is that it returns new value.

        :param list: list of items
        :type list: list | []
        :param index: index of item to remove
        :type index: int
        :returns: list without item at index position
        :rtype: list
        """

        return list_[:index] + list_[index + 1:]

    list_mapper = lambda list_: [list_remove_item_by_index(list_, index) for index in range(len(list_))]


# Generated at 2022-06-26 00:24:11.132885
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Arrange
    validation_0 = Validation(3, [])
    lazy_0 = validation_0.to_lazy()

    # Action
    value_0 = lazy_0.eval()

    # Assert
    assert(value_0 == 3)


# Generated at 2022-06-26 00:24:17.469243
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    list_0 = []
    list_1 = [1]
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == list_0
    validation_1 = Validation(list_1, list_0)
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.get() == list_1
    lazy_2 = Validation.fail(list_1).to_lazy()
    assert lazy_2.get() == None

# Generated at 2022-06-26 00:24:23.436711
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    monad_0 = Validation(True, [])
    Lazy_0 = monad_0.to_lazy()
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool_0
    bool_3 = Lazy_0 == bool_2
    bool_1 = (not bool_3) or bool_1
    bool_2 = bool_0
    bool_3 = monad_0 == bool_2
    bool_1 = (not bool_3) or bool_1
    bool_0 = not bool_1
    assert bool_0


# Generated at 2022-06-26 00:24:27.154712
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(42)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.execute() == 42
    validation_1 = Validation.fail([])
    lazy_1 = validation_1.to_lazy()
    assert lazy_1.execute() is None


# Generated at 2022-06-26 00:24:31.571746
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation('123', '').to_lazy() == Lazy(lambda: '123')
    assert Validation(123, '').to_lazy() == Lazy(lambda: 123)
    assert Validation(True, '').to_lazy() == Lazy(lambda: True)
    assert Validation(None, '').to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:24:39.686096
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []

    validation_0 = Validation(list_0, list_0)

    assert validation_0.to_lazy() == Lazy(lambda: list_0)

    validation_1 = Validation('a', list_0)

    assert validation_1.to_lazy() == Lazy(lambda: 'a')

    validation_2 = Validation(0, list_0)

    assert validation_2.to_lazy() == Lazy(lambda: 0)

    validation_3 = Validation(3.14, list_0)

    assert validation_3.to_lazy() == Lazy(lambda: 3.14)

    validation_4 = Validation(True, list_0)

    assert validation_4.to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-26 00:24:42.554338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.fail()
    assert (validation_0.to_lazy().value() == None)

    validation_0 = Validation.success(1)
    assert (validation_0.to_lazy().value() == 1)


# Generated at 2022-06-26 00:24:47.923117
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # It's tested when:
    # - Validation contains function returning Validation result. Validation is collected.

    from pymonet.lazy import Lazy

    list_0 = []
    validation_0 = Validation(list_0, list_0)
    lazy_0 = validation_0.to_lazy()
    result_0 = lazy_0.collect()
    assert result_0 == validation_0, 'Result should be equals to: {} instead of: {}'.format(validation_0, result_0)
    print('case 0: ok')


# Generated at 2022-06-26 00:24:55.957231
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation.fail(list_0)
    list_1 = []
    validation_1 = Validation.fail(list_1)
    lazy_0 = validation_1.to_lazy()
    list_2 = []
    validation_2 = Validation.fail(list_2)
    lazy_1 = validation_2.to_lazy()
    list_3 = []
    validation_3 = Validation.fail(list_3)
    lazy_2 = validation_3.to_lazy()
    list_4 = []
    validation_4 = Validation.fail(list_4)
    lazy_3 = validation_4.to_lazy()
    list_5 = []
    validation_5 = Validation.fail(list_5)
    lazy_4 = validation_

# Generated at 2022-06-26 00:24:59.378152
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation([]).to_lazy() == Lazy(lambda: []) and \
           Validation([1, 2]).to_lazy() == Lazy(lambda: [1, 2]) and \
           Validation(True).to_lazy() == Lazy(lambda: True)


# Generated at 2022-06-26 00:25:55.576610
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:26:01.247918
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Either

    list_0 = []
    validation_0 = Validation(list_0, list_0)

    assert validation_0.to_lazy() == Lazy(lambda: list_0)
    assert validation_0.to_lazy().value() == validation_0.value


# Generated at 2022-06-26 00:26:03.451501
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    a = Validation.success(10)
    assert a.to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-26 00:26:10.746370
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    list_0 = []
    validation_0 = Validation(list_0, list_0)
    assert validation_0.is_success() == True
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    try_0 = validation_0.to_try()
    assert try_0.is_success() == True
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == list_0
    assert lazy_0.get() == list_0
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)


# Generated at 2022-06-26 00:26:15.334180
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def get():
        return 1

    lazy_1 = Lazy(get)
    validation_1 = Validation(1, [])
    assert validation_1.map(lambda x: x + 10).to_lazy() == Lazy(get) + 10
    assert validation_1.map(lambda x: x + 10).to_lazy() == lazy_1 + 10


# Generated at 2022-06-26 00:26:18.777372
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail([5]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:26:27.897197
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(True, []).to_lazy() == Lazy(lambda: True)
    assert Validation(False, []).to_lazy() == Lazy(lambda: False)
    assert Validation('hello', []).to_lazy() == Lazy(lambda: 'hello')
    assert Validation(None, []).to_lazy() == Lazy(lambda: None)
    assert Validation([], []).to_lazy() == Lazy(lambda: [])
    assert Validation((), []).to_lazy() == Lazy(lambda: ())
    assert Validation({}, []).to_lazy() == Lazy(lambda: {})

# Generated at 2022-06-26 00:26:34.656048
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.identity import Identity
    from pymonet.box import Box

    list_0 = []
    validation_0 = Validation(list_0, list_0)

    # Checking result of Validation.to_lazy
    assert validation_0.to_lazy() == Lazy(lambda: list_0)

    # Checking that Validation.to_lazy is instance of Functor
    assert validation_0.to_lazy() == validation_0.to_lazy().fmap(lambda x: x)

    # Checking that Validation.to_lazy is instance of Applicative
    assert validation_0.to_lazy() == validation_0.to_lazy

# Generated at 2022-06-26 00:26:41.792465
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_validation import Validation

    def test_case_0():
        validation_0 = Validation(3, [])
        lazy_0 = validation_0.to_lazy()
        val_0 = lazy_0.value()
        assert val_0 == validation_0.value, 'to_lazy'

    def test_case_1():
        validation_0 = Validation(3, [])
        lazy_0 = validation_0.to_lazy()
        val_0 = lazy_0.value()
        assert val_0 == validation_0.value, 'to_lazy'

    def test_case_2():
        validation_0 = Validation([], [])
        lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:26:43.664340
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation.success([])
    assert validation.to_lazy() == Lazy(lambda: [])
