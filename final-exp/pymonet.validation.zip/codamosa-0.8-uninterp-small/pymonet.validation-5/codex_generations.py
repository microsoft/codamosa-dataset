

# Generated at 2022-06-26 00:18:31.587867
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_iter import MonadIter
    from pymonet.monad_list import List
    from pymonet.monad_set import Set

    assert Validation.success(MonadIter([1, 2])).to_lazy() == Lazy(MonadIter([1, 2]))
    assert Validation.success(List([1, 2])).to_lazy() == Lazy(List([1, 2]))
    assert Validation.success(Set([1, 2])).to_lazy() == Lazy(Set([1, 2]))



# Generated at 2022-06-26 00:18:35.275538
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    dict_0 = {}
    validation_0 = Validation(bytes_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:38.839427
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    dict_0 = {}
    validation_0 = Validation(bytes_0, dict_0)
    assert validation_0.to_lazy() == validation_0.value


# Generated at 2022-06-26 00:18:43.189744
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    dict_0 = {}
    validation_0 = Validation(bytes_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0 == validation_0.to_lazy()


# Generated at 2022-06-26 00:18:46.818832
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    dict_0 = {}
    validation_0 = Validation(bytes_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == bytes_0



# Generated at 2022-06-26 00:18:54.605072
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method to_lazy of class Validation

    """
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    dict_0 = {}
    validation_0 = Validation(bytes_0, dict_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:58.986035
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    dict_0 = {}
    validation_0 = Validation(bytes_0, dict_0)

    lazy_0 = validation_0.to_lazy()
    assert lazy_0.evaluate() == bytes_0



# Generated at 2022-06-26 00:19:06.459298
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    dict_0 = {}
    validation_0 = Validation(dict_0, dict_0)
    lazy_0 = validation_0.to_lazy()
    int_0 = lazy_0.get_value()
    dict_1 = {}
    dict_2 = {}
    validation_1 = Validation(dict_1, dict_2)
    lazy_1 = validation_1.to_lazy()
    int_1 = lazy_1.get_value()
    dict_3 = {}
    dict_4 = {}
    validation_2 = Validation(dict_3, dict_4)
    lazy_2 = validation_2.to_lazy()
    int_2 = lazy_2.get_value()
    dict_5 = {}
    dict_6 = {}

# Generated at 2022-06-26 00:19:08.335738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    try:
        assert Validation(None, []).to_lazy()
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-26 00:19:14.074653
# Unit test for method to_lazy of class Validation

# Generated at 2022-06-26 00:19:18.868124
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy = validation_0.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value == bytes_0


# Generated at 2022-06-26 00:19:24.671928
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    assert isinstance(validation_0.value, bytes)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value == validation_0.value
    assert validation_0.ap(Lazy.pure(1)).errors == validation_0.errors

# Generated at 2022-06-26 00:19:28.362624
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b"\xea\x1a\xaf\x0d\x97"
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == validation_0.value


# Generated at 2022-06-26 00:19:32.878323
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val_0 = Validation.success(2)
    val_1 = Validation.fail(['Fail'])

    val_2 = val_0.to_lazy()
    val_3 = val_1.to_lazy()

    assert val_2.evaluate() == val_0.value
    assert val_3.evaluate() is None


# Generated at 2022-06-26 00:19:39.082804
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v = Validation.success(1)
    l = v.to_lazy()
    assert l == Lazy(lambda: 1)


# Unit test fot method to_try of class Validation

# Generated at 2022-06-26 00:19:40.465887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation.success(bytes_0)
    assert validation_0.to_lazy().unbox()() == bytes_0

# Generated at 2022-06-26 00:19:48.450147
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation.

    """
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    success_validation = Validation(1, [])
    lazy_success = success_validation.to_lazy()
    assert isinstance(lazy_success, Lazy)

    assert lazy_success() == 1

    fail_validation = Validation(1, [2, 3])
    lazy_fail = fail_validation.to_lazy()
    assert isinstance(lazy_fail, Lazy)

    assert lazy_fail() == None


# Generated at 2022-06-26 00:19:53.126687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation.success(bytes_0)
    lazy_0 = validation_0.to_lazy()

    assert type(lazy_0) == Lazy
    assert lazy_0.eval() == bytes_0


# Generated at 2022-06-26 00:20:03.452689
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try

    bytes_0 = b'\xc2\xfa\x8f\xd8'

    validation_0 = Validation(bytes_0, [])
    lazy_0 = validation_0.to_lazy()

    assert type(lazy_0) == Lazy
    assert lazy_0.value() == bytes_0

    validation_1 = Validation(None, [])
    lazy_1 = validation_1.to_lazy()

    assert type(lazy_1) == Lazy
    assert lazy_1.value() == None 


# Generated at 2022-06-26 00:20:08.968700
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test case where instance has is_success() is True
    test_instance = Validation(1, [])
    result = test_instance.to_lazy()
    assert isinstance(result, Lazy)
    assert result() == 1

    # Test case where instance has is_success() is False
    test_instance = Validation(2, [3])
    result = test_instance.to_lazy()
    assert result().value == 2
    assert result().is_success() is False



# Generated at 2022-06-26 00:20:19.716046
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    v1 = Validation.success(1)
    v2 = Validation.success('abc')
    v3 = Validation.success(None)
    v4 = Validation.fail(None)

    # When
    result1 = v1.to_lazy()
    result2 = v2.to_lazy()
    result3 = v3.to_lazy()
    result4 = v4.to_lazy()

    # Then
    assert result1 == Lazy(lambda: 1)
    assert result2 == Lazy(lambda: 'abc')
    assert result3 == Lazy(lambda: None)
    assert result4 == Lazy(lambda: None)

# Generated at 2022-06-26 00:20:23.285935
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Lazy monad returns function that returns value when it is executes.
    """
    validation = Validation.success(lambda x: x + 1)
    lazy = validation.to_lazy()
    assert lazy.is_success()
    assert lazy.value()(2) == 3


# Generated at 2022-06-26 00:20:28.976256
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test of successful Validation
    assert Validation.success(bytes_0).to_lazy() == Lazy(lambda: bytes_0)
    # Test of failed Validation
    assert Validation.fail('faild').to_lazy() == Lazy(lambda: None)
    # Test of successful Validation with empty value
    assert Validation.success().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:20:36.900919
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    # scenario 1: valid Validation
    input_validation = Validation.success(25)
    actual_result = input_validation.to_lazy()
    expected_result = Lazy(lambda: 25)
    assert actual_result == expected_result
    # scenario 2: invalid Validation
    input_validation = Validation.fail(['a','b','c','d'])
    actual_result = input_validation.to_lazy()
    expected_result = Lazy(lambda: None)
    assert actual_result == expected_result


# Generated at 2022-06-26 00:20:43.479436
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    value = 'text'
    validation = Validation(value, [])

    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-26 00:20:49.070575
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test for has no errors
    validation = Validation(10, [])
    assert validation.to_lazy().value() == 10
    assert validation.to_lazy().is_nothing() == False

    # Test for has errors
    validation = Validation(None, [1, 2, 3])
    assert validation.to_lazy().value() == None
    assert validation.to_lazy().is_nothing() == True


# Generated at 2022-06-26 00:20:53.349829
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test case where Validation is success
    assert Validation.success(lambda: test_case_0()).to_lazy() == Lazy(lambda: test_case_0())
    # Test case where Validation is failure
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:20:54.986153
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:21:00.639823
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_class import MonadClass
    from pymonet.lazy import Lazy
    from pymonet.functor_class import FunctorClass
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    val = Validation(1, [])

    def f():
        return val

    assert f is val.to_lazy().f

    assert isinstance(val.to_lazy(), MonadClass)
    assert isinstance(val.to_lazy(), FunctorClass)
    assert isinstance(val.to_lazy(), Lazy)
    assert isinstance(val.to_lazy(), Try)
    assert isinstance(val.to_lazy(), Success)
    assert not isinstance

# Generated at 2022-06-26 00:21:09.581720
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.validation import Validation

    def test_case_0():
        def get_value():
            nonlocal value_0
            return value_0

        value_0 = b'\xc2\xfa\x8f\xd8'
        validation_0 = Validation.success(value_0)
        lazy_0 = validation_0.to_lazy()
        try_0 = lazy_0.to_try()
        either_0 = try_0.to_either()
        assert either_0.is_right()
        validation_1 = either_0.to_validation()
        assert validation_0 == validation_1


# Generated at 2022-06-26 00:21:16.641017
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    success = Validation.success(1)
    assert success.to_lazy().evaluate() == 1

    fail = Validation.fail(['Error'])
    assert fail.to_lazy().evaluate() is None


# Generated at 2022-06-26 00:21:23.495702
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def _lazy():
        print('lazy evaluation...')
        return "success"
    v = Validation(_lazy, [])
    assert v.to_lazy() == Lazy(_lazy)
    assert v.to_lazy().value() == "success"
    try:
        v = Validation(None, [1,2,3])
        assert v.to_lazy() == Lazy(None)
        v.to_lazy().value()
        assert False
    except Exception as e:
        assert str(e) == 'Invalid Lazy value <none>'


# Generated at 2022-06-26 00:21:26.942765
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-26 00:21:30.650229
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation(lambda: 'A' == 'A', [])
    lazy = validation.to_lazy()
    assert(lazy == Lazy(lambda: 'A' == 'A'))


# Generated at 2022-06-26 00:21:40.290183
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import sys
    import pymonet.either as E
    import pymonet.lazy as L

    assert E.success(1).to_lazy() == L.Lazy(lambda: 1)
    assert E.fail('error').to_lazy() == L.Lazy(lambda: None)

    assert E.success(1).to_lazy().map(lambda x: x + 1) == L.Lazy(lambda: 2)
    assert E.success(1).to_lazy().map(lambda x: x + 1).get() == 2
    assert E.success(1).to_lazy().map(lambda x: x + 1).or_else(5) == 2
    assert E.fail('error').to_lazy().map(lambda x: x + 1).or_else(5) == 5

# Generated at 2022-06-26 00:21:47.417020
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.success('42').to_lazy() == Lazy(lambda: '42')
    assert Validation.success(2.71).to_lazy() == Lazy(lambda: 2.71)
    assert Validation.success(True).to_lazy() == Lazy(lambda: True)
    assert Validation.success(bytes_0).to_lazy() == Lazy(lambda: bytes_0)


# Generated at 2022-06-26 00:21:55.092558
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test that returned lazy is lazy
    validation = Validation.success(1)
    test_case_0.bytes_0 = b'\xc2\xfa\x8f\xd8'
    lazy = validation.to_lazy()
    test_case_0.bytes_0 = b'\xc2\xfa\x8f\xd8'
    if lazy._call.__module__ == "<module 'pymonet.monad_lazy' from 'pymonet/monad_lazy.py'>":
        if "return self._fn()" in str(lazy._call.__code__):
            return True
    return False


# Generated at 2022-06-26 00:21:58.828498
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Monad

    class ValidationM(Validation, Monad):
        pass

    from pymonet.lazy import Lazy

    validation = ValidationM.success(1)
    assert isinstance(validation.to_lazy(), Lazy)


# Generated at 2022-06-26 00:22:03.048772
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # test_with_success_validation
    success = Validation.success(value=10)
    lazy = success.to_lazy()
    assert lazy.eval() == 10
    # test_with_fail_validation
    fail = Validation.fail([10, 20])
    lazy = fail.to_lazy()
    assert lazy.eval() == None


# Generated at 2022-06-26 00:22:07.119086
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Initializing of test data
    validated_0 = Validation.success(b'\xc2\xfa\x8f\xd8')

    # Executing functions
    lazy_0 = validated_0.to_lazy()

    # Asserting result
    assert lazy_0.value == b'\xc2\xfa\x8f\xd8'


# Generated at 2022-06-26 00:22:15.284437
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    monad = ValidationS.success('foo')
    assert monad.to_lazy() == Lazy(lambda: 'foo')

    monad = ValidationS.fail('foo')
    assert monad.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:17.395420
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([1]).to_lazy().get() == None


# Generated at 2022-06-26 00:22:20.492453
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success("a").to_lazy() == Lazy(lambda: "a")
    assert Validation.fail("error").to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:23.400889
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail(['a', 'b']).to_lazy() is None
    assert Validation.success(25).to_lazy() == 25


# Generated at 2022-06-26 00:22:32.711338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Failure, Success
    from pymonet.monad_lazy import Lazy, LazyNothing, LazyJust
    from pymonet.monad_validation import Validation

    lazy_0 = Validation('', []).to_lazy()
    if (lazy_0 != Lazy(lambda: '', [])):
        bytes_0 = b'\xe7\x85\xf3\x9a\x0f\xbcO\x89\x1f\x81\xf1\xef\xd0\x99\x87'
    lazy_0 = Validation(None, ['', '', '']).to_lazy()

# Generated at 2022-06-26 00:22:36.054683
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(42)

    lazy = validation.to_lazy()
    lazy_value = lazy.map(lambda _: _.value)()

    assert lazy_value == 42


# Generated at 2022-06-26 00:22:39.745031
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Counting test coverage.
    """
    test_case_0()


if __name__ == '__main__':
    import doctest
    doctest.testmod()

    def test_case_0():
        bytes_0 = b'some-bytes'


# Generated at 2022-06-26 00:22:49.693171
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test for unsuccessful Validation
    v0 = Validation.fail()
    assert isinstance(v0.to_lazy(), Lazy)
    assert isinstance(v0.to_lazy().value, Exception)
    # Test for successful Validation
    v1 = Validation.success(12345)
    assert isinstance(v1.to_lazy(), Lazy)
    assert isinstance(v1.to_lazy().value, int)
    assert v1.to_lazy().value == 12345


# Generated at 2022-06-26 00:22:55.134827
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    value_0 = b'\xfd\xb7\x8b\x0b\x0b\x11\x92\x0c\xfa\xdc\xcc\xef\x0d\xf4\x1e\x14\xd8\xb4\x98\x84\xdf\x0d\x13\xdb'


# Generated at 2022-06-26 00:22:58.938806
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Validation.success
    test_monad_0 = Validation.success('value_0')
    result_0 = test_monad_0.to_lazy()
    assert result_0.get() == 'value_0'

    # Validation.fail
    test_monad_0 = Validation.fail(['error_0', 'error_1'])
    result_0 = test_monad_0.to_lazy()
    assert result_0.get() == None


# Generated at 2022-06-26 00:23:06.948161
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v1 = Validation.success(5)
    v2 = v1.to_lazy()

    assert v2().value == 5
    assert v2().is_success() == True

    v3 = Validation.fail([])
    v4 = v3.to_lazy()

    assert v4().value == None
    assert v4().is_success() == False


# Generated at 2022-06-26 00:23:11.666870
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.exceptions import PyMonetMonadException
    from pymonet.lazy import Lazy

    # test for successful Validation
    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)

    # test for fail Validation
    with pytest.raises(PyMonetMonadException):
        assert Validation.fail('fail message').to_lazy().value()


# Generated at 2022-06-26 00:23:17.398188
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test case 0
    value0 = b'\xc2\xfa\x8f\xd8'
    validation0 = Validation.success(value0)

    lazy0 = validation0.to_lazy()

    assert validation0.value == lazy0.value()

    # Test case 1
    value1 = None
    validation1 = Validation.fail('noooooooooooo')

    lazy1 = validation1.to_lazy()

    assert validation1.value == lazy1.value()


# Generated at 2022-06-26 00:23:19.312715
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def f():
        return 'foo'

    return Validation(f, []).to_lazy().value()


# Generated at 2022-06-26 00:23:21.946444
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    #call method to_lazy of class Validation and check if result is equal to expected value
    expected = Lazy(lambda: 4)
    result = Validation.success(4).to_lazy()
    assert result == expected


# Generated at 2022-06-26 00:23:29.700369
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def case_0():
        v = Validation.fail()
        l = v.to_lazy()
        assert isinstance(l, Lazy)

    def case_1():
        v = Validation.success()
        l = v.to_lazy()
        assert isinstance(l, Lazy)

    def case_2():
        v = Validation.success(123)
        l = v.to_lazy()
        assert isinstance(l, Lazy)

    def case_3():
        v = Validation.success('abc')
        l = v.to_lazy()
        assert isinstance(l, Lazy)

    def case_4():
        v = Validation.fail([1, 2, 3])
        l = v.to_lazy

# Generated at 2022-06-26 00:23:37.110176
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(2 + 2)
    assert validation.to_lazy() == Lazy(lambda: 4)

    validation = Validation.success('Hello')
    assert validation.to_lazy() == Lazy(lambda: 'Hello')

    validation = Validation.success(data=False)
    assert validation.to_lazy() == Lazy(lambda: False)

    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(lambda: None)

    validation = Validation.fail(errors=['some_error', 'another_error'])
    assert validation.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:23:46.516646
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Create a test entity
    test_entity_0 = Validation(
        value='',
        errors=[
            "error-0"
        ]
    )

    # Create a test entity
    test_entity_1 = Validation(
        value='test entity 1',
        errors=[
            "error-0",
            "error-1",
            "error-2"
        ]
    )

    assert test_entity_0.to_lazy().get() is None
    assert test_entity_1.to_lazy().get() == 'test entity 1'

    # Create a test entity
    test_entity_2 = Validation(
        value='test entity 2',
        errors=[]
    )

    assert test_entity_2.to_lazy().get() == 'test entity 2'

    test_entity_3

# Generated at 2022-06-26 00:23:48.981440
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation(1, [])
    lazy = validation.to_lazy()

    assert lazy == Lazy(lambda: 1)



# Generated at 2022-06-26 00:23:57.712626
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for to_lazy method of Validation class
    """
    simple_function = lambda: 4
    lazy_function   = Lazy(lambda: 4)

    simple_value    = Validation.success(4)
    lazy_value      = Lazy(lambda: Validation.success(4))

    # Test after lazy evaluation
    assert(simple_value.to_lazy().eval() == simple_function())
    assert(lazy_value.to_lazy().eval() == lazy_function.eval())

    # Test before lazy evaluation
    assert(simple_value.to_lazy().value == simple_function)
    assert(lazy_value.to_lazy().value == lazy_function.value)


# Generated at 2022-06-26 00:24:05.800347
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)

    def helper_0():
        return validation_0.value

    lazy_0 = validation_0.to_lazy()
    value_0 = lazy_0.get()
    assert value_0 == helper_0()

test_case_0()
test_Validation_to_lazy()
print('All tests success.')

# Generated at 2022-06-26 00:24:10.369972
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation
    """
    assert Validation.success(1).to_lazy().get() == Lazy(1).get()
    assert Validation.fail([2]).to_lazy().get() == Lazy(None).get()


# Generated at 2022-06-26 00:24:15.555051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 'any'

    assert Validation.success(f).to_lazy() == Lazy(f),\
        'Validation.success().to_lazy() not equal to Lazy(f)'

    assert Validation.fail().to_lazy() == Lazy(lambda: None),\
        'Validation.fail().to_lazy() not equal to Lazy(lambda: None)'


# Generated at 2022-06-26 00:24:19.740545
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)

    assert validation_0.to_lazy().value() == bytes_0
    assert validation_0.to_lazy().value(always=True) == bytes_0

test_Validation_to_lazy()


# Generated at 2022-06-26 00:24:21.506455
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation(1, 2)
    lazy = validation.to_lazy()
    assert lazy.force() == 1


# Generated at 2022-06-26 00:24:27.475920
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test for method to_lazy of class Validation.
    """
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)

    lazy_0 = validation_0.to_lazy()

    bytes_1 = b'\xc2\xfa\x8f\xd8'
    assert_is_instance(lazy_0, Lazy)
    assert_is_instance(lazy_0._thunk, FunctionType)
    assert_equals(lazy_0.value, bytes_1)

# Generated at 2022-06-26 00:24:30.289181
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(bytes([1, 2]))
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value() == bytes([1, 2])


# Generated at 2022-06-26 00:24:38.443325
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import sys
    import io

    saved_stdout = sys.stdout
    try:
        out = io.StringIO()
        sys.stdout = out

        bytes_0 = b'\xaa'
        validation_0 = Validation.success(bytes_0)
        lazy_0 = validation_0.to_lazy()
        assert lazy_0.value() == bytes_0
        out = sys.stdout.getvalue().strip()
        assert out == 'Lazy[Function() -> {}]'.format(bytes_0)
    finally:
        sys.stdout = saved_stdout


if __name__ == "__main__":
    import sys
    import inspect
    import pymonet.test


# Generated at 2022-06-26 00:24:41.957625
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Lazy monad with function returning Validation value.
    """
    validation_0 = Validation.success(b'\xd8\xfa\x8f\xc2')
    lazy_0 = validation_0.to_lazy()
    value = lazy_0()

    assert validation_0.value == value


# Generated at 2022-06-26 00:24:45.927066
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.lazy import Lazy

    def test_fn_0():
        return "test_fn_0_result"

    monad_0 = Validation.success("test_value_0")

    result_0 = monad_0.to_lazy()

    expected_0 = Lazy(lambda: "test_value_0")

    assert result_0 == expected_0



# Generated at 2022-06-26 00:24:57.930257
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation.success(bytes_0)
    lazy_monad_0 = validation_0.to_lazy()
    assert lazy_monad_0.get_value() == bytes_0


# Generated at 2022-06-26 00:25:01.662887
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xe5\xf2'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0_value = lazy_0.force()
    if not bytes_0 is lazy_0_value:
        raise AssertionError("#0")


# Generated at 2022-06-26 00:25:03.122597
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(1, []).to_lazy().eval() == 1


# Generated at 2022-06-26 00:25:07.963378
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy), 'Failed test: Validation_to_lazy_0'


# Generated at 2022-06-26 00:25:12.662543
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)
    return 'test_Validation_to_lazy ok'


# Generated at 2022-06-26 00:25:23.553749
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    validation_0 = Validation(10, [])
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.eval() == 10

    try_0 = validation_0.to_try()
    assert isinstance(try_0, Try)
    assert try_0.is_success()
    assert try_0.value == 10

    lazy_1 = validation_0.to_lazy()
    assert isinstance(lazy_1, Lazy)
    assert lazy_1.eval() == 10

    maybe_0 = validation_0.to_maybe()


# Generated at 2022-06-26 00:25:30.217777
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    # Given
    validation_0 = Validation.success(1)

    # When
    lazy_0 = validation_0.to_lazy()

    # Then
    assert lazy_0 == Lazy(lambda: 1)


# Generated at 2022-06-26 00:25:33.883221
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == bytes_0


# Generated at 2022-06-26 00:25:38.100002
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy

    m_value = "Some value"
    validation_1 = Validation.success(m_value)
    validation_2 = Validation.fail()

    assert validation_1.to_lazy() == Lazy(lambda :m_value)
    assert validation_2.to_lazy() == Lazy(lambda :None)


# Generated at 2022-06-26 00:25:40.036199
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(10).to_lazy().get() == 10
    

# Generated at 2022-06-26 00:26:01.041225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.force() == bytes_0
    assert lazy_0.is_memoized()


# Generated at 2022-06-26 00:26:06.729324
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success(123).to_lazy()
    assert isinstance(result, Lazy), 'result of to_lazy method is not Lazy'
    assert result.get() == 123, 'result is not successful Try'

    result = Validation.fail([123, 345]).to_lazy()
    assert isinstance(result, Lazy), 'result of to_lazy method is not Lazy'
    assert result.get() is None, 'result is not successful Try'


# Generated at 2022-06-26 00:26:09.967973
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\x01\xf4\xde\x82'
    validation_0 = Validation(bytes_0, bytes_0)

    assert validation_0.to_lazy().value() == bytes_0



# Generated at 2022-06-26 00:26:12.956881
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_1 = Lazy(lambda: 'lazy_1')
    validation_1 = Validation.success(lazy_1)

    assert validation_1.to_lazy() == lazy_1


# Generated at 2022-06-26 00:26:15.940940
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    bytes_0 = b'\xc2\xfa\x8f\xd8'

    validation = Validation.success(bytes_0)
    lazy = validation.to_lazy()

    assert validation.value == lazy()


# Generated at 2022-06-26 00:26:23.105935
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = Lazy(lambda: bytes_0)
    validation_1 = validation_0.to_lazy()
    assert lazy_0 == validation_1

if __name__ == '__main__':  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    test_Validation_to_lazy()

    print('Validation tests passed')

# Generated at 2022-06-26 00:26:25.999511
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('Hello').to_lazy().eval() == 'Hello'
    assert Validation.fail(['Error', 'Error']).to_lazy().eval() is None


# Generated at 2022-06-26 00:26:30.328281
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test method to_lazy of class Validation when Validation is successfully.

    It creates Lazy monad with value as a function returning bytes.
    """
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, [])
    lazy_0 = validation_0.to_lazy()
    result_0 = lazy_0.value()
    assert result_0 == bytes_0


# Generated at 2022-06-26 00:26:37.069617
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation(None, []).to_lazy() == Lazy(None)
    assert Validation(1, []).to_lazy() == Lazy(1)
    assert Validation(1, [1]).to_lazy() == Lazy(1)
    assert Validation(1, [1, 2]).to_lazy() == Lazy(1)
    assert Validation(1, [1, 2, 3]).to_lazy() == Lazy(1)
    assert Validation(123, [1, 2, 3]).to_lazy() == Lazy(123)
    assert Validation([None], []).to_lazy() == Lazy([None])
    assert Validation([1], []).to_lazy

# Generated at 2022-06-26 00:26:42.947959
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    for validate_func in [
            Validation.success,
            Validation.fail,
            ]:
        for value in [
                b'\xc2\xfa\x8f\xd8',
                '0xfa8fd888',
                ['a', 'b', 'c'],
                {'a', 'b', 'c'},
                ]:
            validation_0 = validate_func(value)

            lazy_0 = validation_0.to_lazy()

            assert isinstance(lazy_0, Lazy)
            assert lazy_0.value() == value


# Generated at 2022-06-26 00:27:26.532446
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    lazy_0 = Validation(bytes_0, []).to_lazy()
    assert lazy_0().value == bytes_0


# Generated at 2022-06-26 00:27:34.581485
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation(bytes_0, bytes_0)
    byte_0 = bytes_0[0:0:1]
    validation_1 = Validation.success(byte_0)
    lazy_0 = validation_1.to_lazy()
    str_0 = lazy_0.value()



# Generated at 2022-06-26 00:27:40.832705
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    test_string_true = 'test string'
    success_validation = Validation.success(test_string_true)

    # when
    lazy_0 = success_validation.to_lazy()

    # then
    print(lazy_0)
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.is_success() == success_validation.is_success()
    assert lazy_0.value() == success_validation.value


# Generated at 2022-06-26 00:27:45.755982
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test that method to_lazy return successfull Lazy monad with value from Validation when validation is successfull
    validation_0 = Validation.success(b'\xc2\xfa\x8f\xd8')
    lazy_0 = validation_0.to_lazy()  # type: Lazy
    assert lazy_0.call() == b'\xc2\xfa\x8f\xd8'

    # Test that method to_lazy return failed Lazy monad with exception when validation failed
    validation_1 = Validation.fail(b'\xc2\xfa\x8f\xd8')
    lazy_1 = validation_1.to_lazy()  # type: Lazy
    try:
        lazy_1.call()
    except Exception as exception:
        assert exception.exception_type == b

# Generated at 2022-06-26 00:27:48.096751
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xe0\xf7\xb4\xfb'
    lazy_0 = Validation.fail(bytes_0).to_lazy()
    assert lazy_0.result == bytes_0, 'lazy_0.result is bytes_0'


# Generated at 2022-06-26 00:27:50.259786
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xde\xf8\x8e\x90'
    validation_0 = Validation(bytes_0, bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get() == validation_0.value



# Generated at 2022-06-26 00:27:53.239809
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(9191, [])
    try:
        result = validation_0.to_lazy()
        print("Result: " + str(result))
    except Exception:
        print("Error: " + str(Exception))


# Generated at 2022-06-26 00:27:58.090239
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xc2\xfa\x8f\xd8'
    validation_0 = Validation.success(bytes_0)
    lazy_0 = validation_0.to_lazy()
    assert callable(lazy_0.value)
    assert lazy_0() is bytes_0


# Generated at 2022-06-26 00:28:08.536537
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    bytes_0 = b'\xca\xa2\x92To\x8e\xb2\x14\x1a\xf7\xc2\xc0\x9d\x11\xa7\x8e\xe2\x90\xf2\xd2\x0b'
    bytes_1 = b'\x8b\x94\xbb\xe3\x02\xb59\x8f\x1a\x0b\x92\x8c\x1d\x06\x0b\xe3\x9f\x9d\x90\xee\x1c\xb0\x00'

# Generated at 2022-06-26 00:28:14.540710
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def function_0(x):
        return Lazy(x)
    bytes_0 = b'\x80'
    validation_1 = function_0(bytes_0)
    validation_0 = Validation(bytes_0, validation_1)
    validation_2 = validation_0.to_lazy()
    validation_3 = Lazy(bytes_0)
    validation_4 = validation_2.value()
    assert bytes_0 == validation_4
    assert validation_2 == validation_3
