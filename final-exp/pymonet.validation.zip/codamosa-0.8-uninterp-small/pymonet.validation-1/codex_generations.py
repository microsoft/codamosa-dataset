

# Generated at 2022-06-26 00:18:31.161500
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:36.690414
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.to_lazy()

    assert lazy_1 is not None
    assert lazy_1.is_success()
    assert lazy_1.has_value()
    assert lazy_1.get_or_else(False) == set_0



# Generated at 2022-06-26 00:18:39.132741
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:18:44.865703
# Unit test for method to_lazy of class Validation

# Generated at 2022-06-26 00:18:52.275029
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    lazy_0 = validation_0.to_lazy()
    try_0 = lazy_0.eval()
    assert try_0 == set_0


# Generated at 2022-06-26 00:18:58.250977
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # function to test case 0
    def test_case_0():
        set_0 = set()
        validation_0 = Validation(set_0, set_0)
        var_0 = validation_0.to_lazy()

    test_case_0()



# Generated at 2022-06-26 00:19:04.693001
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Create first Lazy instance
    var_0 = Lazy(lambda: [])

    # Create second Lazy instance
    var_1 = Validation.success(var_0)

    # Call to_lazy method
    var_2 = var_1.to_lazy()

    assert var_2 is not None

# Generated at 2022-06-26 00:19:06.963014
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:09.124501
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:22.035293
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Try

    monad_try_0 = Validation.success(1)
    monad_lazy_0 = Validation.success(1)
    monad_lazy_1 = monad_lazy_0.to_lazy()
    monad_lazy_2 = Lazy(lambda : monad_try_0)
    assert monad_lazy_1 == monad_lazy_2
    assert monad_lazy_1.to_try() == monad_try_0

# Generated at 2022-06-26 00:19:27.519571
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Simple test case of Validation to_lazy method"""
    from pymonet.lazy import Lazy

    lazy_monad = Validation.success(5).to_lazy()
    assert lazy_monad.value() == 5



# Generated at 2022-06-26 00:19:30.337380
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:19:34.805203
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Arrange
    validation_0 = Validation.success(0)
    validation_1 = Validation.fail(['error'])

    # Act
    lazy_0 = validation_0.to_lazy()
    lazy_1 = validation_1.to_lazy()

    # Assert
    assert lazy_0.value() == lazy_1.value() == 0


# Generated at 2022-06-26 00:19:41.205198
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation.success(int_0)
    validation_1 = Validation.success(int_0)

    assert validation_0.to_lazy() == validation_1.to_lazy()



# Generated at 2022-06-26 00:19:45.708616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1

    validation_0 = Validation.success(int_0)

    value = validation_0.to_lazy().value()
    error = False

    try:
        assert value == int_0
    except AssertionError:
        error = True

    assert error == False


# Generated at 2022-06-26 00:19:49.849918
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    validation = Validation.success(Box(1))

    assert validation.to_lazy() == Lazy(lambda: Box(1))
    assert validation.to_lazy().force() == Box(1)
    assert validation.to_lazy().force().value == 1

# Generated at 2022-06-26 00:19:59.760008
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.box import Box

    v_lazy_1 = Validation.success(1).to_lazy()
    assert v_lazy_1.value() == 1
    assert v_lazy_1 == Lazy(lambda: 1)

    v_lazy_2 = Validation.fail(None).to_lazy()
    assert v_lazy_2.value() == None
    assert v_lazy_2 == Lazy(lambda: None)

    f_1 = lambda x: Box(x)
    v_lazy_3 = Validation.success(1).to_lazy().bind(f_1)
    assert v_lazy_3.value() == Box(1)
    assert v_

# Generated at 2022-06-26 00:20:03.327592
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 10
    validation = Validation(value, [])
    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-26 00:20:04.925566
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy() == Lazy(lambda: int_0)



# Generated at 2022-06-26 00:20:13.328209
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It takes as a parameter function returning another Validation.
    Function is called with Validation value and returns new Validation with previous value
    and concated new and old errors.

    :param monad: monad contains function
    :type monad: Function(A) -> Validation[Any, List[E]]
    :returns: new validation with stored errors
    :rtype: Validation[A, List[E]]
    """

    value_0 = 1
    errors_0 = []
    value_expected_0 = 1
    value_expected_1 = 1
    validation_0 = Validation(value_0, errors_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.value() == value_expected_0
    errors_1 = ['Error']
    value_1 = 1


# Generated at 2022-06-26 00:20:23.036897
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Monad
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    import pymonet.lazy
    import pymonet.validation

    test_value = 1

    validation = Validation.success(test_value)
    pymonet.lazy.test_Lazy_from_monad(validation, Lazy)
    pymonet.validation.test_case_0()

# Generated at 2022-06-26 00:20:28.297740
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # when
    result = Validation.success(int_0).to_lazy()

    # then
    assert isinstance(result, Lazy)
    assert result.get().value == Try(int_0, True)
    assert result.get().value.is_success()


# Generated at 2022-06-26 00:20:40.550206
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_Validation_to_lazy_0():
        validation = Validation.success(1)
        result = validation.to_lazy().get_result()
        assert result == 1, 'Validation.to_lazy method failed!'

    def test_Validation_to_lazy_1():
        validation = Validation.success('foo')
        result = validation.to_lazy().get_result()
        assert result == 'foo', 'Validation.to_lazy method failed!'

    def test_Validation_to_lazy_2():
        validation = Validation.success([1, 2, 3])
        result = validation.to_lazy().get_result()
        assert result == [1, 2, 3], 'Validation.to_lazy method failed!'


# Generated at 2022-06-26 00:20:43.949550
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    def test_func():
        return int_0
    int_1 = test_func()
    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()
    bool_0 = lazy_0.is_evaluated()
    lazy_0.is_evaluated()
    int_2 = lazy_0.get_value()
    bool_1 = not (bool_0 and (int_0 == int_2))
    test_result_0 = (assert_util_equal(int_0, int_1) and
                     assert_util_equal(bool_1, True))
    return test_result_0


# Generated at 2022-06-26 00:20:47.350361
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation_0 = Validation.success(int_0)
    lazy_0 = Lazy(lambda: int_0)

    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:20:49.835322
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([]).to_lazy().get() is None


# Generated at 2022-06-26 00:20:58.211232
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Left, Right
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_list import List
    from pymonet.box import Box

    # Create monad
    mapper = lambda x: x + 1
    acc = lambda x: x + 10
    int_0 = 0

    # Test Functor Laws
    # Identity
    assert Functor.f_identity_law(Validation.success(int_0), mapper)
    # Composition
    assert Functor.f_composition_law(Validation.success(int_0), mapper, acc)

    # Test Monad Laws
    # Left identity


# Generated at 2022-06-26 00:21:01.454005
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    int_1 = int_0 + 1
    v = Validation.success(int_1)
    assert v.to_lazy() == Lazy(lambda: int_1)


# Generated at 2022-06-26 00:21:04.171923
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_0 = Validation.success(int_0)
    monad_0 = val_0.to_lazy()
    assert monad_0.get() == int_0

test_case_0()

# Generated at 2022-06-26 00:21:08.528569
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    int_0_validation = Validation.success(value=int_0)
    int_0_lazy = int_0_validation.to_lazy()
    # call to get value from Lazy monad
    int_0_result = int_0_lazy.get()
    assert int_0 == int_0_result


# Generated at 2022-06-26 00:21:21.904983
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    int_1 = 2
    int_3 = 3
    int_4 = 4
    lazy_int_1 = Validation.success(int_0).to_lazy()
    assert lazy_int_1.value() is int_0

    lazy_int_2 = Validation.fail([int_1]).to_lazy()
    assert lazy_int_2.value() is None

    lazy_int_3 = Validation.fail([int_1, int_2]).to_lazy()
    assert lazy_int_3.value() is None

    lazy_int_4 = Validation.success(int_3).to_lazy()
    assert lazy_int_4.value() is int_3

    lazy_int_5 = Validation.fail([int_4]).to_lazy()
   

# Generated at 2022-06-26 00:21:24.271236
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test when Validation has no errors
    l = Validation.success(int_0).to_lazy()
    assert l.get() == int_0


# Generated at 2022-06-26 00:21:31.307758
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1

    validation_0 = Validation.success(int_0)
    validation_1 = Validation.fail([])

    def func_0():
        return validation_0

    def func_1():
        return validation_1

    lazy_0 = func_0()
    lazy_1 = func_1()

    maybe_0 = validation_0.to_lazy()
    maybe_1 = validation_1.to_lazy()

    assert maybe_0.get() == lazy_0
    assert maybe_1.get() == lazy_1

# Generated at 2022-06-26 00:21:35.988231
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad import Validation
    from pymonet.lazy import Lazy

    value = 1
    validation = Validation.success(value)
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.callable_value() is not None
    assert lazy.callable_value() == value


# Generated at 2022-06-26 00:21:38.581285
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(int_0)
    lazy_monad = validation.to_lazy()
    assert lazy_monad.get() is int_0


# Generated at 2022-06-26 00:21:45.465939
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    int_1 = 2
    val_0 = Validation.success(int_0)
    val_1 = Validation.fail([])
    assert val_0.to_lazy().value() == int_0
    assert val_1.to_lazy().value() is None
    val_0 = Validation.success(int_0)
    val_1 = Validation.success(int_1)
    assert val_0.to_lazy() is not val_1.to_lazy()


# Generated at 2022-06-26 00:21:54.538234
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.monad_try as MT
    import pymonet.monad_tuple as MT2
    from pymonet.identity import Identity

    # m is Validation[Int, List[String]]
    m = Validation.success(10)

    # m2 is Try[String]
    m2 = m.to_lazy().bind(lambda r: MT.Try(str(r)))

    # m3 is Try[Int]
    m3 = m2.bind(lambda r: MT.Try(int(r)))

    # m4 is Try[Int]
    m4 = m.to_lazy().bind(lambda r: MT.Try(int(r)))

    # Tuple[Try[Int], Try[Int]]
    assert MT2.Tuple(m3, m4) == MT2.Tuple

# Generated at 2022-06-26 00:21:58.584583
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation(\
        Atom(\
            1,\
            FilePath.from_string(\
                "test/test_Validation.py"\
            ),\
            10\
        ).to_lazy().run\
    ).to_lazy()
    assert result == Lazy(lambda: int_0)

# Generated at 2022-06-26 00:22:00.085936
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy().value() == int_0


# Generated at 2022-06-26 00:22:05.958720
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    success_value = Validation.success(42)
    lazy_success_value = success_value.to_lazy()
    assert isinstance(lazy_success_value, Lazy)
    assert lazy_success_value.get() == 42

    fail_value = Validation.fail(['it is a fail'])
    lazy_fail_value = fail_value.to_lazy()
    assert isinstance(lazy_fail_value, Lazy)
    assert lazy_fail_value.get() is None


# Generated at 2022-06-26 00:22:17.782245
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_1 = Validation.success(0).to_lazy()
    assert lazy_1.value == 0

    lazy_2 = Validation.success().to_lazy()
    assert lazy_2.value == None



# Generated at 2022-06-26 00:22:21.517917
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    test_0 = Validation.success(int_0)
    result_0 = test_0.to_lazy()
    assert isinstance(result_0, Lazy)
    assert result_0.unbox() == int_0


# Generated at 2022-06-26 00:22:23.448530
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-26 00:22:29.910084
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val_1 = Validation.success(int_0)
    val_2 = Validation.fail([RuntimeError, 'test_error'])
    val_3 = Validation.fail([RuntimeError, 'test_error_2'])

    assert val_1.to_lazy().value() == int_0
    assert val_1.to_lazy().get() == int_0

    assert val_2.to_lazy().value() == None
    assert val_2.to_lazy().get() == None

    assert val_3.to_lazy().value() == None
    assert val_3.to_lazy().get() == None


# Generated at 2022-06-26 00:22:41.265824
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1

    validation_monad_0 = Validation.success()

    lazy_monad_0 = validation_monad_0.to_lazy()

    #     self.assertEqual(lazy_monad_0.value, None)
    assert lazy_monad_0.value == None

    #     self.assertEqual(lazy_monad_0.is_success(), True)
    assert lazy_monad_0.is_success() == True

    validation_monad_1 = Validation.success(int_0)

    lazy_monad_1 = validation_monad_1.to_lazy()

    #     self.assertEqual(lazy_monad_1.value, int_0)
    assert lazy_monad_1.value == int_0

    #     self

# Generated at 2022-06-26 00:22:46.124967
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(int_0).to_lazy() == Lazy(lambda: int_0)


# Generated at 2022-06-26 00:22:50.754991
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_lazy = Validation.success(1).to_lazy()
    lazy_result = validation_lazy.eval()

    assert lazy_result == 1
    assert validation_lazy.is_success() == True
    assert validation_lazy.is_fail() == False


# Generated at 2022-06-26 00:22:56.107001
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    v_to_lazy_1 = Validation.success(3).to_lazy()
    v_to_lazy_2 = Validation.fail().to_lazy()

    assert v_to_lazy_1 == Lazy(lambda: 3)
    assert v_to_lazy_2 == Lazy(lambda: None)


# Generated at 2022-06-26 00:22:58.977137
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:07.485651
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    int_0 = 0
    int_1 = 1
    bool_0 = False
    bool_1 = True
    empty_list = []
    list_0 = [0, 1]
    empty_dict = {}
    dict_0 = {'key_0': 0, 'key_1': 1}
    empty_set = set()
    set_0 = {0, 1}
    none = None
    fun_0 = lambda: 0
    fun_1 = lambda: 1
    fun_true = lambda: True
    fun_false = lambda: False

    tuple_int_0 = (0, )

# Generated at 2022-06-26 00:23:18.288611
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(1).to_lazy()

    assert lazy.eval() == 1


# Generated at 2022-06-26 00:23:21.496007
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Validation.to_lazy()
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    lazy = validation.to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 1


# Generated at 2022-06-26 00:23:24.913482
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    validation_0 = Validation.success(int_0)
    lazy_0 = validation_0.to_lazy()

    assert isinstance(lazy_0, Lazy)
    assert lazy_0.value() == int_0


# Generated at 2022-06-26 00:23:26.980898
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    input_value = Validation.success(int_0)
    result = input_value.to_lazy()
    assert result.get_result() == int_0


# Generated at 2022-06-26 00:23:29.082573
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def int_0():
        return 1

    lazy = Validation.success(int_0).to_lazy()

    assert lazy.get() == 1


# Generated at 2022-06-26 00:23:32.371590
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = Validation.success(1)
    int_1 = Validation.fail(['a', 'b'])

    assert int_0.to_lazy() == Lazy(lambda: 1)
    assert int_1.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-26 00:23:35.294991
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    lazy = Validation.success(Box(1)).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.get() == Box(1)


# Generated at 2022-06-26 00:23:38.863884
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    v = Validation.success(1)
    assert v.to_lazy().evaluate() == v.value
    v = Validation.fail('error')
    assert v.to_lazy().evaluate() == v.value


# Generated at 2022-06-26 00:23:41.575096
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    validation = Validation(int_0, [])

    result = validation.to_lazy()

    assert not result.is_success()
    assert result.value() == int_0


# Generated at 2022-06-26 00:23:43.955870
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([1, 2]).to_lazy().get() is None


# Generated at 2022-06-26 00:24:04.159848
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    Validation.success(1).to_lazy().value() == 1
    Validation.fail([]).to_lazy().value() is None

# Generated at 2022-06-26 00:24:13.316441
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # Testing Validation.success is going to Lazy
    def case_0():
        val = Validation.success(1)
        assert val.to_lazy().__class__.__name__ == 'Lazy'
        assert val.to_lazy().get() == 1

    # Testing Validation.fail is going to Lazy
    def case_1():
        val = Validation.fail(['ERROR'])
        assert val.to_lazy().__class__.__name__ == 'Lazy'
        assert val.to_lazy().get() is None

    # Testing Validation.success is going to Lazy
    def case_2():
        val = Validation.fail(['ERROR'])
        assert val.to_lazy().__class__.__name__ == 'Lazy'
        assert val.to_lazy

# Generated at 2022-06-26 00:24:15.988801
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    validation = Validation.success(1)

    # when
    lazy = validation.to_lazy()

    # then
    assert lazy.value() == validation.value


# Generated at 2022-06-26 00:24:18.299922
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    val_0 = Validation.success(int_0)
    laz_0 = val_0.to_lazy()
    assert int_0 == laz_0.get()


# Generated at 2022-06-26 00:24:20.393288
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value() == 1
    assert Validation.fail([]).to_lazy().value() is None


# Generated at 2022-06-26 00:24:23.260589
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation(1, [])
    lazy = validation.to_lazy()
    assert(1 == lazy.eval())

    validation = Validation(None, [])
    lazy = validation.to_lazy()
    assert(None == lazy.eval())


# Generated at 2022-06-26 00:24:25.785234
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    int_result = Validation.success(1).to_lazy()
    assert isinstance(int_result, Lazy)
    assert int_result.value() == 1

# Generated at 2022-06-26 00:24:27.478976
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-26 00:24:35.178561
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = 1
    maybe_int_0 = Validation.success(int_0)
    # Validation[A, List[E]] -> Lazy[Function() -> (A | None)]
    lazy_f_0 = maybe_int_0.to_lazy()
    # Lazy[Function() -> (A | None)] -> Lazy[Function() -> (A | None)]
    lazy_f_1 = lazy_f_0.map(lambda x: x+1)
    # Lazy[Function() -> (A | None)] -> Lazy[Function() -> (A | None)]
    lazy_f_2 = lazy_f_1.map(lambda x: x+1)
    # Lazy[Function() -> (A | None)] -> Lazy[Function() -> (A | None)]
    lazy_f_3 = lazy

# Generated at 2022-06-26 00:24:37.377986
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy_0 = Validation.success(int_0).to_lazy()

    assert lazy_0.value() == Validation.success(int_0).value


# Generated at 2022-06-26 00:25:01.661844
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assertValidation(Validation.success('A').to_lazy(), Lazy(lambda: 'A'), 'Validation.fail[]')
    assertValidation(Validation.fail('B').to_lazy(), Lazy(lambda: None), 'Validation.success[A]')


# Generated at 2022-06-26 00:25:04.032687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(5).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-26 00:25:09.154641
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test case 0
    input_0 = Validation(None, [])
    expected_0 = Lazy(lambda: Validation.success(None).value)
    result_0 = input_0.to_lazy()
    try:
        assert result_0 == expected_0
        passed("test_Validation_to_lazy")
    except AssertionError:
        failed("test_Validation_to_lazy")


# Generated at 2022-06-26 00:25:20.526269
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation_0 = Validation(None, [])
    var_0 = validation_0.to_lazy()
    assert var_0 == Lazy(lambda: None)

    validation_1 = Validation(None, [Try(None, is_success=False)])
    var_1 = validation_1.to_lazy()
    assert var_1 == Lazy(lambda: None)

    validation_2 = Validation(1, [Try(None, is_success=False)])
    var_2 = validation_2.to_lazy()
    assert var_2 == Lazy(lambda: 1)


# Generated at 2022-06-26 00:25:23.420879
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    var_0 = validation_0.to_lazy()
    assert var_0.value() == set_0
    test_case_1()


# Generated at 2022-06-26 00:25:30.718861
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    var_0 = Box(10).to_lazy()
    var_1 = Lazy(lambda: Box(10))
    if var_0 == var_1:
        print("SUCCESS")
    else:
        print("FAIL")


# Generated at 2022-06-26 00:25:33.204503
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    validation_0.to_lazy()


# Generated at 2022-06-26 00:25:35.152245
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:25:40.751400
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation_1 = Validation.success(1)
    lazy_1 = validation_1.to_lazy()
    assert isinstance(lazy_1, Lazy) # lazy_1 is instance of Lazy
    assert lazy_1 == Lazy(lambda: 1) # lazy_1 equals to Lazy(lambda: 1)
    assert lazy_1.value() == 1 # lazy_1.value equals to 1

    validation_2 = Validation.fail()
    lazy_2 = validation_2.to_lazy()
    assert isinstance(lazy_2, Lazy) # lazy_2 is instance of Lazy
    assert lazy_2 == Lazy(lambda: None) # lazy_2 equals to Lazy(lambda: None)


# Generated at 2022-06-26 00:25:42.996481
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert(Validation.success(2).to_lazy() == Lazy(lambda: 2))
    assert(Validation.success().to_lazy() == Lazy(lambda: None))



# Generated at 2022-06-26 00:26:27.516127
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)
    assert Validation.success('value') == Validation.success('value').to_lazy().force()



# Generated at 2022-06-26 00:26:31.728031
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    validation_0 = Validation.success("X")
    lazy_0 = validation_0.to_lazy()

    # AssertionError: Expected value to be Nothing but it was: Lazy[Function() -> (Any | None)]

    validation_1 = Validation.fail(["X"])
    lazy_1 = validation_1.to_lazy()

    # AssertionError: Expected value to be Nothing but it was: Lazy[Function() -> (Any | None)]


# Generated at 2022-06-26 00:26:33.970514
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    validation_0.to_lazy()
    validation_0.to_lazy()


# Generated at 2022-06-26 00:26:36.483027
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    var_0 = Validation.success(123)
    var_1 = var_0.to_lazy()
    var_2 = var_1._action()

    assert var_2 == 123
    assert type(var_2) is int



# Generated at 2022-06-26 00:26:43.739898
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Lazy
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    box_0 = Box.pure(1)
    assert box_0 == box_0.to_lazy().fmap(lambda x = Box.pure(1): x)

    maybe_0 = Maybe.just(2)
    assert maybe_0 == maybe_0.to_lazy().fmap(lambda x = Maybe.just(2): x)

    either_0 = Right(3)
    assert either_0 == either_0.to_lazy().fmap(lambda x = Right(3): x)

    validation_0 = Validation.success()
    assert validation_0 == validation_0.to_

# Generated at 2022-06-26 00:26:47.311738
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.value()
    try:
        var_1 = validation_0.value
    except NameError:
        pass


# Generated at 2022-06-26 00:26:51.545030
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation_0 = Validation.fail([1, 4, 6])
    validation_1 = validation_0.to_lazy()
    assert validation_1.value() == validation_0.value

    validation_2 = Validation.success([1, 4, 6])
    validation_3 = validation_2.to_lazy()
    assert validation_3.value() == validation_2.value



# Generated at 2022-06-26 00:26:57.106286
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    assert validation_0.is_fail()
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get().is_fail()
    validation_0 = Validation.success(set_0)
    assert validation_0.is_success()
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.get().is_success()


# Generated at 2022-06-26 00:26:58.717708
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    var_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:27:03.065310
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.monad_either import Either

    set_0 = set()
    validation_0 = Validation(set_0, set_0)
    lazy_0 = validation_0.to_lazy()
    var_0 = lazy_0.__class__.__name__
    lazy_0 = validation_0.to_lazy()
    var_1 = lazy_0.__class__.__name__
