

# Generated at 2022-06-26 00:18:33.776311
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    validation_1 = validation_0.to_lazy()
    int_1 = True if isinstance(validation_1, Lazy) else False
    assert int_1



# Generated at 2022-06-26 00:18:43.360246
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    validation_1 = validation_0.to_lazy()
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '


# Generated at 2022-06-26 00:18:54.222092
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)

    lazy_0 = validation_0.to_lazy()
    assert True == lazy_0.is_called()
    assert str_0 == lazy_0.get_value()


# Generated at 2022-06-26 00:19:05.866826
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    lazy_2 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:13.018394
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_1 = True

# Generated at 2022-06-26 00:19:14.410263
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 00:19:23.916758
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_1 = validation_0.to_lazy()
    # Invoke to get value.
    lazy_1.fn()

# Generated at 2022-06-26 00:19:27.434802
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test with arguments
    # Uncomment these lines
    # arguments = (3)
    # result = validation.to_lazy(*arguments)

    # Asserts
    # Uncomment this line
    # assert result == expected

    raise NotImplementedError



# Generated at 2022-06-26 00:19:32.863933
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)

    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:19:39.070998
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Decorator method
    lazy_0 = Lazy(lambda: str_0)
    assert isinstance(validation_0.to_lazy(), Lazy)
    assert lazy_0 == validation_0.to_lazy()


# Generated at 2022-06-26 00:19:48.699630
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    print(lazy_0)
    return lazy_0


# Generated at 2022-06-26 00:19:58.627493
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_1 = True
    validation_1 = Validation(str_1, int_1)

    lazy_0 = validation_1.to_lazy()

    def feq(a, b, msg=None):
        str_0 = 'Pymonet Error'
        print(str_0)
        print(a)
        print(b)
        assert a == b, msg or '%r != %r' % (a, b)

    bool_0 = lazy_0.is_e

# Generated at 2022-06-26 00:20:05.718770
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    assert validation_0.to_lazy()._value() == str_0


# Generated at 2022-06-26 00:20:11.982896
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    assert isinstance(lazy_0, Lazy)
    assert lazy_0.force() == str_0


# Generated at 2022-06-26 00:20:15.688009
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.str_ import Str
    from pymonet.box import Box
    validation_box = Box(3)
    assert Lazy.unit(3) == validation_box.to_lazy()

# Generated at 2022-06-26 00:20:22.191175
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    lazy_0 = Lazy(lambda: test_case_0())
    lazy_1 = Validation.success(str_0).to_lazy()
    assert lazy_0 == lazy_1


# Generated at 2022-06-26 00:20:32.055562
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    expected = Lazy(lambda: '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        ')
    result = validation_0.to_lazy

# Generated at 2022-06-26 00:20:33.283264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = "Method to_lazy() works wrong"


# Generated at 2022-06-26 00:20:42.364823
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:20:47.434051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Transform Validation to Try.\n\n        :returns: Try with Validation value value. Try is successful when Validation has no errors\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    validation_0.to_lazy()


# Generated at 2022-06-26 00:20:57.343298
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_1 = Validation(str_0, int_0)
    lazy_0 = validation_1.to_lazy()



# Generated at 2022-06-26 00:21:03.752224
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:21:13.210450
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_1 = validation_0.to_lazy()
    lazy_2 = lazy_1.to_lazy()
    str_1 = lazy_2.get()
    int_1 = lazy_2.get()
    str_2 = lazy_2.get()
    str_3 = lazy_2.get()
    str_4 = lazy_2.get()

# Generated at 2022-06-26 00:21:15.305760
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    assert measu

# Generated at 2022-06-26 00:21:23.952843
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Transform Validation to Try.

    :returns: Lazy monad with function returning Validation value
    :rtype: Lazy[Function() -> (A | None)]
    """
    validation_0 = Validation.success()
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_1 = Validation(str_0, int_0)
    validation_0.value = validation_1.value
    validation_0.errors = validation_1.errors
    lazy_0 = validation_0.to_

# Generated at 2022-06-26 00:21:31.344748
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    lazy_0 = Validation(str_0, False).to_lazy()
    failure_0 = Lazy(lambda: str_0)
    assertFailure(failure_0, lazy_0, 'assertEquals(expected, actual, message)')


# Generated at 2022-06-26 00:21:38.485085
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = lazy_0.evaluate()


# Generated at 2022-06-26 00:21:44.396551
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    validation_0.to_lazy()


# Generated at 2022-06-26 00:21:50.673047
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Transform Validation to Try.

    :returns: Lazy monad with function returning Validation value
    :rtype: Lazy[Function() -> (A | None)]
    """
    str_0 = 'abc'
    validation_0 = Validation(str_0, [])
    str_1 = 'abc'
    lazy_0 = validation_0.to_lazy()
    str_2 = lazy_0.value()
    assert str_1 == str_2


# Generated at 2022-06-26 00:21:54.417656
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = 'Success monad'
    validation_0 = Validation.success(str_0)
    lazy_0 = validation_0.to_lazy()
    box_0 = lazy_0.to_box()
    assert str_0 == box_0.val

# Generated at 2022-06-26 00:22:07.347225
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    def lambda_0(value_0): return value_0

    lazy_0 = validation_0.to_lazy()
    d = lazy_0.value()
    value_0 = d
    f = lambda_0(value_0)
    value_1 = f
    return value_1



# Generated at 2022-06-26 00:22:12.688644
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_1 = True
    validation_0 = Validation(str_1, int_1)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:22:21.162143
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    expected_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    validation_0 = Validation(str_0, True)
    actual_0 = validation_0.to_lazy().get()
    assert expected_0 == actual

# Generated at 2022-06-26 00:22:29.792731
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Input parameters
    expected_0 = Lazy(lambda: '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        ')
    validation_0 = Validation('\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        ', [])

    # Execution
    actual_0 = validation_0.to_lazy()

    # Unit test asserts

# Generated at 2022-06-26 00:22:37.423314
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    test_case_0(str_0)


# Generated at 2022-06-26 00:22:45.660677
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    str_1 = '        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    bool

# Generated at 2022-06-26 00:22:54.525628
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    from pymonet.lazy import Lazy

    lazy = validation_0.to_lazy()
    assert lazy == Lazy(lambda: str_0)


# Generated at 2022-06-26 00:22:58.737921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # __init__
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    assert validation_0.to_lazy() == str_0


# Generated at 2022-06-26 00:23:02.156461
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert str(Validation.fail(errors=["No rules"]).to_lazy()) == "<pymonet.lazy.Lazy object at 0x10a88e6d8>"
    return None


# Generated at 2022-06-26 00:23:07.161224
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:26.087116
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_case_0()

# Generated at 2022-06-26 00:23:33.898282
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_1 = True

# Generated at 2022-06-26 00:23:37.567369
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    success_value = 'test'
    validation_0 = Validation(success_value, [])
    validation_1 = validation_0.to_lazy()
    lazy_1 = Lazy(lambda: success_value)
    assert validation_1 == lazy_1


# Generated at 2022-06-26 00:23:43.815167
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    l_0 = validation_0.to_lazy()


# Generated at 2022-06-26 00:23:53.192110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)

# Generated at 2022-06-26 00:24:00.145884
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import itertools

    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_list_0 = validation_0.to_lazy()
    lazy_list_0.memoize()
    assert str_0 == lazy_list_0.value()


# Generated at 2022-06-26 00:24:00.599894
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert True



# Generated at 2022-06-26 00:24:04.584739
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation('\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        ', True)

    validation_0.to_lazy()
    validation_0.to_lazy()


# Generated at 2022-06-26 00:24:14.009237
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    bool_0 = True
    bool_1 = True
    validation_2 = Validation.success(None)
    bool_2 = True
    if validation_0.to_lazy() != validation_2.to_lazy():
        bool_2 = False
    bool_3 = bool_2
    bool_1 = bool_3
    bool_0 = bool_1
    assert bool_0

# Generated at 2022-06-26 00:24:20.158783
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    lazy_1 = lazy_0.get()
    assert lazy_1 == str_0


# Generated at 2022-06-26 00:25:09.410785
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    assert validation_0.to_lazy().value_or(
        None) == str_0 and validation_0.to_lazy().get() == str_0
    int_0 = False
    validation_0 = Validation(str_0, int_0)

# Generated at 2022-06-26 00:25:21.482007
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '

# Generated at 2022-06-26 00:25:29.863283
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = 'x\u0006'
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0.equals(Lazy(lambda: str_0)) == True


# Generated at 2022-06-26 00:25:38.157682
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    assert lazy_0._value() == str_0

# Generated at 2022-06-26 00:25:43.553507
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()



# Generated at 2022-06-26 00:25:54.639975
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    # If true assert will throw exception
    # If false assert will pass

    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()

    assert lazy_0.is_instance_of(Lazy)
    assert lazy_0.is_instance_of(Validation)

# Generated at 2022-06-26 00:25:58.074584
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import lazy

    string = Lazy(lambda: 'Some string')
    string_0 = Lazy(lambda: 'Some string')
    string_1 = Lazy(lambda: 'Some string')

    assert lazy(string_0) == lazy(string_1)

# Generated at 2022-06-26 00:26:05.871068
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """It tests method to_lazy of class Validation"""
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_1 = True
    validation_0 = Validation(str_0, int_1)

    # Unit test for method to_lazy of class Validation
    # It tests the method with parameters conditionally.
    lazy_0 = Lazy(lambda: str_0)
    assert validation_0.to_lazy() == lazy_0


# Generated at 2022-06-26 00:26:14.136110
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_1 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    str_2 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_1 = True
    validation_1 = Validation(str_1, int_1)
    validation_2 = validation_1.to_lazy()


# Generated at 2022-06-26 00:26:15.199514
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation.success('A').to_lazy()


# Generated at 2022-06-26 00:27:56.732461
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    if isinstance(lazy_0, Lazy) and lazy_0.value == str_0:
        return
    raise Exception('assert not reached')


# Generated at 2022-06-26 00:27:58.863785
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(None, [])
    maybe_0 = validation_0.to_maybe()


# Generated at 2022-06-26 00:28:09.000939
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test to_lazy function"""
    # Test result
    test_result_Validation_to_lazy = True

    # Testing ...
    str_0 = '\n        Call success_callback function with monad value when monad is successfully.\n\n        :params success_callback: function to apply with monad value.\n        :type success_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = False
    validation_0 = Validation(str_0, int_0)
    # Test method to_lazy
    validation_0.to_lazy()
    # Test result assignement
    test_result_Validation_to_lazy = True if validation_0.is_success() is not None else False

    # Return test result

# Generated at 2022-06-26 00:28:12.605852
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    int_0 = True
    validation_0 = Validation(None, int_0)
    lazy_0 = validation_0.to_lazy()
    try:
        str_0 = lazy_0.get()
    except:
        str_0 = ""
    assert str_0 is None


# Generated at 2022-06-26 00:28:15.255967
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_0 = Validation(str_0, int_0)
    try:
        assert str_0 == validation_0.to_lazy().value()
    except AssertionError as e: print(e)


# Generated at 2022-06-26 00:28:21.160875
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    assert Lazy(lambda: str_0) == validation_0.to_lazy()


# Generated at 2022-06-26 00:28:25.546907
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    str_0 = '\n        Call success_callback function with monad value when monad is not successfully.\n\n        :params fail_callback: function to apply with monad value.\n        :type fail_callback: Function(A)\n        :returns: self\n        :rtype: Try[A]\n        '
    int_0 = True
    validation_0 = Validation(str_0, int_0)
    lazy_0 = validation_0.to_lazy()
    lazy_0.value()
    lazy_0.value()
