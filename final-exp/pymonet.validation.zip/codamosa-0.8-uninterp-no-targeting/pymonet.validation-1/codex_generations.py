

# Generated at 2022-06-21 19:47:22.094119
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation
    """
    from pymonet.either import Right

    validation = Validation.fail(['24'])
    assert validation.bind(lambda x: Right(x)) == Right(None)
    assert validation.bind(lambda x: Right(x + 'dd')) == Right(None)
    assert validation.bind(lambda x: Right('ld')) == Right(None)


# Generated at 2022-06-21 19:47:26.502023
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()

    assert isinstance(lazy, Lazy), "Should return Lazy monad"
    assert lazy.get_value() == 10, "Should return lazy object with 10"



# Generated at 2022-06-21 19:47:34.011702
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    error = Exception('Some exception')
    v = Validation([], [error])

    assert v.to_try().is_failure, 'Validation.to_try() must return failure for failure Validation'
    assert v.to_try().exception == [error], 'Validation.to_try() must return error from failed Validation'

    v = Validation(1, [])

    assert v.to_try().is_success, 'Validation.to_try() must return success for successful Validation'
    assert v.to_try().value == 1, 'Validation.to_try() must return value from successful Validation'


# Generated at 2022-06-21 19:47:45.069922
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right

    validation = Validation.success()

    # assert Validation.bind is associative
    assert (validation.bind(lambda _: Validation.success('one')).bind(lambda _: Validation.success('two')) ==
            validation.bind(lambda a: Validation.success('one').bind(lambda b: Validation.success('two'))))

    assert validation.bind(lambda _: Validation.success('one')).bind(lambda _: Validation.success('two')) == \
           validation.bind(lambda a: Validation.success('one')).bind(lambda b: Validation.success('two'))

    # assert Validation.bind and Functor.map are compatible

# Generated at 2022-06-21 19:47:53.562789
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right

    assert Validation.success('a').ap(Validation.success(lambda x: x + 'b')) == Validation('ab', [])
    assert Validation.success('a').ap(Validation.fail(['err1'])) == Validation('a', ['err1'])
    assert Validation.fail(['err1']).ap(Validation.success(lambda x: x + 'b')) == Validation(None, ['err1'])
    assert Validation.fail(['err1']).ap(Validation.fail(['err2'])) == Validation(None, ['err1', 'err2'])

    assert Validation.fail(['err2']).to_either() == Left(['err2'])
    assert Validation.success('a').to_either() == Right

# Generated at 2022-06-21 19:48:00.036793
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.success(10)
    assert validation.to_try() == Try(10, True)

    validation = Validation.fail(['Validation Errors'])
    assert validation.to_try() == Try(None, False)


# Generated at 2022-06-21 19:48:02.961831
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(errors=['error']).to_box() == Box(None)



# Generated at 2022-06-21 19:48:11.197283
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_try import FAILURE, SUCCESS
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(0).map(lambda a: a + 1) == Validation(1, [])
    assert Validation.fail([1, 2]).map(lambda a: a + 1) == Validation(None, [1, 2])

    assert Validation.success(0).to_either() == Right(0)
    assert Validation.fail([1,2]).to_either() == Left([1,2])

    assert Validation.success('hello').to_maybe() == Just('hello')
    assert Validation.fail().to_maybe() == Nothing()

   

# Generated at 2022-06-21 19:48:17.233583
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.success(2).is_success() == True

    assert Validation.fail().is_success() == False
    assert Validation.fail(['error']).is_success() == False
    assert Validation.fail(['error1', 'error2']).is_success() == False



# Generated at 2022-06-21 19:48:24.137061
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test function.
    """

    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.fail([1, 2]) != Validation.fail([1])


# Generated at 2022-06-21 19:48:37.110213
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Given
    v0 = Validation.success(3)
    v1 = Validation.success(3)
    v2 = Validation.fail(['error'])

    # Then
    assert v0 is not v1
    assert v0 is not v2
    assert not v0 == v2

    # When
    v0 = Validation.fail(['error'])
    v1 = Validation.fail(['error'])
    v2 = Validation.success(3)

    # Then
    assert v0 is not v1
    assert not v0 == v2

    # When
    v0 = Validation.success(3)
    v1 = Validation.fail(['error'])
    v2 = Validation.success(4)

    # Then
    assert not v0 == v1

# Generated at 2022-06-21 19:48:41.379121
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['some error'])) == 'Validation.fail[None, [\'some error\']]'
    assert str(Validation.success(1)) == 'Validation.success[1]'


# Generated at 2022-06-21 19:48:44.987118
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation.fail(['error'])
    assert str(validation) == 'Validation.fail[[], [\'error\']]'
    validation = Validation.success(2)
    assert str(validation) == 'Validation.success[2]'


# Generated at 2022-06-21 19:48:48.146784
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation
    """
    from pymonet.box import Box

    assert Validation(None, []).to_box() == Box(None)
    assert Validation("abc", []).to_box() == Box("abc")


# Generated at 2022-06-21 19:48:52.095314
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success('abc').to_box() == Box('abc')
    assert Validation.fail([1]).to_box() == Box(None)

# Generated at 2022-06-21 19:49:02.541852
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    from pymonet.validation import Validation

    def to_validation(x):
        if x % 2 == 0:
            return Validation.success(x)
        else:
            return Validation.fail([x])

    assert (Validation.success(2).ap(to_validation(4)).to_maybe() ==
            Validation.success(2).to_maybe())

    assert (Validation.success(2).ap(to_validation(3)).to_maybe() ==
            Validation.fail([3]).to_maybe())

    assert (Validation.fail([1]).ap(to_validation(3)).to_maybe() ==
            Validation.fail([1]).to_maybe())


# Generated at 2022-06-21 19:49:04.502821
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    from pymonet.either import Left, Right

    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail(['a']).to_either() == Left(['a'])



# Generated at 2022-06-21 19:49:07.904901
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('success_value').to_either() == Right('success_value')
    assert Validation.fail(['fail_error']).to_either() == Left(['fail_error'])


# Generated at 2022-06-21 19:49:11.687108
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try, Success, Failure

    assert Validation.success(5).to_try() == Success(5)
    assert Validation.fail([1]).to_try() == Failure([1])


# Generated at 2022-06-21 19:49:14.586543
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('success').is_fail() == False
    assert Validation.fail(['fail']).is_fail() == True


# Generated at 2022-06-21 19:49:28.628339
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Bind is an operation, which, when applied to a monad,
    results in a monad.
    It returns a new monad of the same type, with contents determined
    by the function `folder`.

    Monad m => (a -> m b) -> m a -> m b
    """
    def test_Validation_fail_bind():
        """
        It takes as a parameter folder.
        Function is called with Validation value when validation is successful.
        Function returns new Validation with mapped value.

        :param folder: function (A) -> Validation[B, List[E]]
        :type value: Function(A) -> Validation[B, List[E]]
        """
        def folder(value):
            return Validation.fail(['Error'])

        validation = Validation.fail([])
        result = validation.bind

# Generated at 2022-06-21 19:49:33.025502
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-21 19:49:43.353444
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(Validation.fail([1])) == Validation.success(1)
    assert Validation.success(1).ap(Validation.fail([1, 2, 3])) == Validation.success(1)
    assert Validation.success(1).ap(Validation.success(2)) == Validation.success(1)
    assert Validation.fail([1]).ap(Validation.success(2)) == Validation.fail([1])
    assert Validation.fail([]).ap(Validation.fail([1])) == Validation.fail([1])
    assert Validation.fail([1, 2]).ap(Validation.fail([3, 4])) == Validation.fail([1, 2, 3, 4])



# Generated at 2022-06-21 19:49:53.910193
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """Unit test for Validation to_lazy"""

    # Success case 1
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

    # Success case 2
    assert Validation.success(1).to_lazy().run() == 1

    # Success case 3
    assert Validation.success(1).to_lazy()  != Lazy(lambda: 2)

    # Fail case 1
    assert Validation.fail(['not valid']).to_lazy() == Lazy(lambda: None)

    # Fail case 2
    assert Validation.fail(['not valid']).to_lazy().run() == None


# Generated at 2022-06-21 19:49:56.002149
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)

# Unit tests for method to_try of class Validation

# Generated at 2022-06-21 19:50:03.824051
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Unit test for method to_either of class Validation
    """
    # given
    from pymonet.either import Left, Right

    some_value = 10

    # when
    result_validation_success = Validation.success(some_value).to_either()
    result_validation_fail = Validation.fail(['some error']).to_either()

    # then
    assert result_validation_success == Right(some_value)
    assert result_validation_fail == Left(['some error'])


# Generated at 2022-06-21 19:50:16.610116
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success() == Validation(None, [])
    assert Validation.success(3) == Validation(3, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['foo']) == Validation(None, ['foo'])
    assert Validation.success(3).is_success()
    assert not Validation.success(3).is_fail()
    assert Validation.fail(['foo']).is_fail()
    assert not Validation.fail(['foo']).is_success()
    assert Validation.fail(['foo']).to_maybe() == Validation.fail(['foo']).to_maybe()
    assert Validation.fail(['foo']).to_maybe() != Validation.success(3).to_maybe()
    assert Validation.fail

# Generated at 2022-06-21 19:50:21.742390
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    :returns: None when test is successfully passed, in other case it returns AssertionError
    :rtype: None | AssertionError
    """
    from pymonet.monad_try import SuccessfulTry, FailedTry

    Validation.fail().to_try() == FailedTry(None)
    Validation.success(42).to_try() == SuccessfulTry(42)

# Generated at 2022-06-21 19:50:26.252258
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    # Given
    v1 = Validation.success(2)
    v2 = Validation.fail([])

    # Then
    assert v1.to_box() == Box(2)
    assert v2.to_box() == Box(None)


# Generated at 2022-06-21 19:50:34.772788
# Unit test for method __str__ of class Validation
def test_Validation___str__():

    test_expected = "Validation.success[1]"
    test_value = Validation.success(1)
    test_result = str(test_value)
    assert test_result == test_expected, 'expect {}, but got {}'.format(test_expected, test_result)

    test_expected = "Validation.fail[None, [1, 2]]"
    test_value = Validation.fail([1, 2])
    test_result = str(test_value)
    assert test_result == test_expected, 'expect {}, but got {}'.format(test_expected, test_result)


# Generated at 2022-06-21 19:50:47.643276
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from mock import patch, Mock
    from pymonet.lazy import Lazy

    # patch function to be able to set return value
    fn = patch('pymonet.lazy.Lazy.lazy_value').start()
    fn.return_value = 20

    assert Validation.success(5).to_lazy() == Lazy(fn)
    fn.assert_called_with(5)


# Generated at 2022-06-21 19:50:52.187173
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda val: val + 1) == Validation.success(2)
    assert Validation.fail(['error']).map(lambda val: val + 1) == Validation.fail(['error'])

    try:
        Validation.success().map(lambda val: val + 'add')
        raise AssertionError("Function map has not raised TypeError")
    except TypeError:
        pass


# Generated at 2022-06-21 19:50:56.019675
# Unit test for constructor of class Validation
def test_Validation():
    # Should be success with value and empty errors list
    validation_1 = Validation.success(1)
    assert validation_1.value == 1
    assert validation_1.errors == []
    assert validation_1.is_success() == True
    # Should be fail with value and not empty errors list
    validation_2 = Validation.fail(['error'])
    assert validation_2.value == None
    assert validation_2.errors == ['error']
    assert validation_2.is_success() == False


# Generated at 2022-06-21 19:51:01.299521
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """[Validation] __str__"""
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['a'])) == "Validation.fail[None, ['a']]"



# Generated at 2022-06-21 19:51:08.472263
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Given
    val1 = Validation.success(1)
    val2 = Validation.success(1)
    val3 = Validation.success(2)
    val4 = Validation.fail()
    val5 = Validation.fail('error')

    # Then
    assert(val1 == val2)
    assert(val1 != val3)
    assert(val1 != val4)
    assert(val4 != val5)


# Generated at 2022-06-21 19:51:12.391110
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    """
    Test successful instance of Validation.
    """

    value = "some_value"
    validation = Validation(value, [])

    assert isinstance(validation, Validation)
    assert validation.value == value
    assert validation.errors == []


# Generated at 2022-06-21 19:51:15.037362
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 1
    val = Validation.success(value)

    assert val.to_lazy() == Lazy.pure(value)

# Generated at 2022-06-21 19:51:18.430445
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    l = Validation('foo', []).to_lazy()
    assert isinstance(l, Lazy)
    assert l() == 'foo'


# Generated at 2022-06-21 19:51:24.690071
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation ap should concat errors from Validation returned from function

    :returns: True when test passed
    :rtype: Boolean
    """
    from pymonet.either import Left

    func = lambda a: Left(['error'])
    validation = Validation.fail(['test error']).ap(func)

    return validation.errors == ['test error', 'error']



# Generated at 2022-06-21 19:51:30.782776
# Unit test for method ap of class Validation
def test_Validation_ap():
    def parse_integer(string):
        try:
            return Validation.success(int(string))
        except ValueError:
            return Validation.fail(["Invalid integer"])

    assert Validation.fail(["Invalid float"]).ap(parse_integer("some string")) ==\
           Validation(None, ["Invalid float", "Invalid integer"])
    assert Validation.success("12345").ap(parse_integer("12345")) ==\
           Validation(12345, [])


# Generated at 2022-06-21 19:51:45.056977
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test for Validation.to_maybe method.

    Method should return Maybe with value when Validation is successful or empty Maybe when Validation is failed.
    """
    from pymonet.maybe import Maybe

    # test for successful Validation
    result = Validation.success(5).to_maybe()
    assert result == Maybe.just(5)
    # test for failed Validation
    result = Validation.fail([1, 2]).to_maybe()
    assert result == Maybe.nothing()


# Generated at 2022-06-21 19:51:48.366511
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() == False
    assert Validation.fail(['1', '2']).is_fail() == True


# Generated at 2022-06-21 19:51:58.223403
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('a').to_maybe() == Maybe.just('a')
    assert Validation.success('').to_maybe() == Maybe.just('')
    assert Validation.success(None).to_maybe() == Maybe.just(None)
    assert Validation.success(123).to_maybe() == Maybe.just(123)
    assert Validation.success([]).to_maybe() == Maybe.just([])
    assert Validation.success({}).to_maybe() == Maybe.just({})
    assert Validation.fail('').to_maybe() == Maybe.nothing()
    assert Validation.fail('a').to_maybe() == Maybe.nothing()
    assert Validation.fail(123).to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:52:08.943515
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success('a').is_fail() == False
    assert Validation.success(1).is_fail() == False
    assert Validation.success(True).is_fail() == False
    assert Validation.success(Left('error')).is_fail() == False
    assert Validation.success(Right('a')).is_fail() == False
    assert Validation.success(Maybe.just('a')).is_fail() == False
    assert Validation.success(Maybe.nothing()).is_fail() == False
    assert Validation.success(Box('a')).is_fail()

# Generated at 2022-06-21 19:52:20.974201
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.monad_test_utils import assert_validation_equals

    assert_validation_equals(Validation.success(), Validation.success())
    assert_validation_equals(Validation.success([1]), Validation.success([1]))
    assert not Validation.success() == Validation.fail()
    assert not Validation.success([1]) == Validation.fail()
    assert_validation_equals(Validation.fail(), Validation.fail())
    assert_validation_equals(Validation.fail(['error']), Validation.fail(['error']))
    assert not Validation.fail(['error']) == Validation.success()
    assert not Validation.fail(['error']) == Validation.success(['error'])

# Generated at 2022-06-21 19:52:26.186934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    actual = Validation.success(1).to_lazy()
    assert isinstance(actual, Lazy)
    assert actual == Lazy(lambda: 1)
    actual = Validation.fail([1, 2]).to_lazy()
    assert isinstance(actual, Lazy)
    assert actual == Lazy(lambda: None)


# Generated at 2022-06-21 19:52:29.668951
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(5).map(lambda x: x + 10) == Validation.success(15)
    assert Validation.success(5).map(lambda x: x) == Validation.success(5)
    assert Validation.fail([1, 2, 3]).map(lambda x: x) == Validation.fail([1, 2, 3])


# Generated at 2022-06-21 19:52:33.166713
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail("error").to_either() == Left("error")



# Generated at 2022-06-21 19:52:39.439115
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test Validation ap method. Tests that ap accepts only Validation as
    parameter.
    """
    def to_validation(x):
        return Validation.success(x)

    f = Validation.success(to_validation)
    assert f.ap(Validation.success(1)) == Validation.success(1)
    assert f.ap(Validation.fail(['error'])) == Validation.fail(['error'])

# Generated at 2022-06-21 19:52:48.429197
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Right

    assert Validation(1, [1]) == Validation(1, [1])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.success(1).to_either() == Right(1)

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail().to_maybe() == Nothing()
    assert Validation.fail([1]).to_maybe() == Nothing()

    assert Validation.success(1).to_

# Generated at 2022-06-21 19:53:15.052500
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation
    """
    # When Unit tests Part 1
    # Then
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail(['a']) == Validation.fail(['a'])
    assert Validation.fail(['a', 'b']) == Validation.fail(['a', 'b'])

    assert Validation.success() == Validation.success()
    assert Validation.success(12) == Validation.success(12)
    assert Validation.success('a') == Validation.success('a')
    assert Validation.success(12.2) == Validation.success(12.2)
    assert Validation.success(False) == Validation.success(False)
    assert Validation.success(True) == Validation

# Generated at 2022-06-21 19:53:20.176316
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for method is_success of class Validation
    """

    # test when validation has no errors
    validation = Validation.success(1)
    assert validation.is_success()

    # test when validation has errors
    validation = Validation.fail(["Error"])
    assert not validation.is_success()



# Generated at 2022-06-21 19:53:22.938828
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing
    from pymonet.validation import Validation

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail([1, 2, 3]).to_maybe() == Nothing()


# Generated at 2022-06-21 19:53:28.347812
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.fail(errors=['error'])
    assert validation.is_fail()

    validation = Validation.fail(errors=[])
    assert not validation.is_fail()

    validation = Validation.success(value='value')
    assert not validation.is_fail()


# Generated at 2022-06-21 19:53:31.909438
# Unit test for method is_success of class Validation
def test_Validation_is_success():  # pragma: no cover
    assert Validation.success(True).is_success()
    assert not Validation.fail([]).is_success()
    assert not Validation.fail(['Error']).is_success()


# Generated at 2022-06-21 19:53:36.418093
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(12).to_either() == Right(12)
    assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])


# Generated at 2022-06-21 19:53:41.838290
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Unit test for Validation.bind"""
    from pymonet.validation import Validation

    def folder(value):
        return Validation.success(value)

    assert Validation.success(42).bind(folder) == Validation(42, [])

    assert Validation.fail([1, 2, 3]).bind(folder) == Validation(None, [1, 2, 3])



# Generated at 2022-06-21 19:53:53.681439
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for method ap of class Validation"""

    from pymonet.either import Left
    from pymonet.monad import m_identity
    from pymonet.monad_try import Try

    fn = lambda _: Validation.success('value')

    assert Validation.success('').ap(fn).is_success()
    assert Validation.success('').ap(fn).value == 'value'
    assert Validation.success('').ap(fn).to_either() == m_identity(Try.success('value').to_either())

    fn = lambda _: Validation.fail(['user error 1'])

    assert Validation.success('').ap(fn).is_fail()
    assert Validation.success('').ap(fn).errors == ['user error 1']

# Generated at 2022-06-21 19:53:56.329427
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['test error']).is_fail() == True
    assert Validation.success(1).is_fail() == False


# Generated at 2022-06-21 19:53:59.529477
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    success_validation = Validation.success(1)
    fail_validation = Validation.fail()

    assert success_validation != fail_validation

    success_validation_1 = Validation.success(1)
    assert success_validation_1 == success_validation


# Generated at 2022-06-21 19:54:44.256830
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('x').is_success() is True
    assert Validation.success(None).is_success() is True
    assert Validation.fail([]).is_success() is False
    assert Validation.fail([1]).is_success() is False


# Generated at 2022-06-21 19:54:47.417232
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:54:51.876006
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of Validation.
    """
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:54:54.135276
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail(['error']).to_maybe() == Nothing()



# Generated at 2022-06-21 19:55:00.087576
# Unit test for method map of class Validation
def test_Validation_map():
    """
    test map method.
    """
    success = Validation.success('abc')
    assert success.map(lambda x: len(x)) == Validation.success(3)

    fail = Validation.fail()
    assert fail.map(lambda x: len(x)) == Validation.fail()

# Unit tests for method bind of class Validation

# Generated at 2022-06-21 19:55:02.815950
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'



# Generated at 2022-06-21 19:55:05.361137
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(0).map(lambda x: x + 1) == Validation.success(1)
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation.fail(['error'])


# Generated at 2022-06-21 19:55:08.400612
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([10, 20])) == 'Validation.fail[None, [10, 20]]'


# Generated at 2022-06-21 19:55:12.989445
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    # Success Validation
    assert Validation.success(1).is_success()
    # Fail Validation
    assert not Validation.fail().is_success()
    assert not Validation.fail([1, 2, 3]).is_success()
    assert not Validation.fail(['first', 'second', 'third']).is_success()


# Generated at 2022-06-21 19:55:23.087559
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def f(value):
        if value < 0:
            return Validation.fail(['f: value must be greater or equal 0'])
        return Validation.success(value + 1)

    def g(value):
        if value < 0:
            return Validation.fail(['g: value must be greater or equal 0'])
        return Validation.success(value + 1)

    def h(value):
        if value < 0:
            return Validation.fail(['h: value must be greater or equal 0'])
        return Validation(value + 1, [])


# Generated at 2022-06-21 19:56:17.561367
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    def add1(v):
        return Validation.success(v + 1)

    def add2(v):
        return Validation.success(v + 2)

    def add3(v):
        return Validation.success(v + 3)

    assert Validation.success().ap(add1).to_try() == Try(1, is_success=True)
    assert Validation.success(3).ap(add1).ap(add2).ap(add3).to_try() == Try(9, is_success=True)
    assert Validation.fail(['Error 1', 'Error 2', 'Error 3']).ap(add1).to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:56:22.445066
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def folder(number):
        if number < 5:
            return Try.fail(number)
        return Try.success(number)

    result = Validation.success(2).bind(folder)
    assert result == Try.fail(2)

    result = Validation.success(6).bind(folder)
    assert result == Try.success(6)



# Generated at 2022-06-21 19:56:27.793341
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation('a', []) == Validation.success('a')
    assert Validation('a', []) == Validation('a', [])
    assert Validation.fail(['b']) == Validation(None, ['b'])

    assert Validation.success('a').value == 'a'
    assert Validation.fail(['b']).value is None


# Generated at 2022-06-21 19:56:32.721982
# Unit test for method ap of class Validation
def test_Validation_ap():
    v1 = Validation('foo', ['error', 'error2'])
    v2 = Validation.success('bar')
    v3 = Validation.success('foo')

    assert v1.ap(lambda val: v2) == Validation('foo', ['error', 'error2'])
    assert v3.ap(lambda val: v2) == Validation('foo', [])

    t1 = Validation('foo', ['error', 'error2'])
    t2 = Validation('bar', ['error3', 'error4'])
    t3 = Validation.success('foo')
    t4 = Validation.success('bar')

    assert t1.ap(lambda val: t2) == Validation('foo', ['error', 'error2', 'error3', 'error4'])

# Generated at 2022-06-21 19:56:36.089421
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert (Validation.success(1) == Validation.success(1)) == True
    assert (Validation.success(1) == Validation.fail([1])) == False
    assert (Validation.success(1) == Validation.success(2)) == False
    assert (Validation.fail([1]) == Validation.fail([1])) == True
    assert (Validation.fail([1]) == Validation.fail([2])) == False
    assert (Validation.fail([1, 2]) == Validation.fail([1])) == False


# Generated at 2022-06-21 19:56:43.497042
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test bind method of class Validation
    """
    def mapper(string):
        """
        Mapper function that returns len of string.

        :param string: string to return len
        :type value: String
        :returns: len of string
        :rtype: Int
        """
        return len(string)

    assert Validation('string 123').bind(mapper) == Validation.success(10)


# Generated at 2022-06-21 19:56:46.238090
# Unit test for method map of class Validation
def test_Validation_map():
    def run(mapper):
        return Validation('test', []).map(mapper)

    assert run(lambda x: x + '123') == Validation('test123', [])


# Generated at 2022-06-21 19:56:48.509669
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def f():
        return 12

    assert Validation.success(12).to_lazy() == Lazy(f)

# Generated at 2022-06-21 19:56:56.721697
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test_value = 'str'
    test_errors = ['error_1', 'error_2']

    def test_function():
        return test_value

    validation_success = Validation.success(test_value)
    lazy_success = validation_success.to_lazy()
    assert lazy_success.force() == test_value

    validation_fail = Validation.fail(test_errors)
    lazy_fail = validation_fail.to_lazy()

    try:
        lazy_fail.force()
    except Exception as e:
        assert str(e) == 'None'


# Generated at 2022-06-21 19:56:58.853921
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)
