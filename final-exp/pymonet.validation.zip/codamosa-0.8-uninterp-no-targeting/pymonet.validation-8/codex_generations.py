

# Generated at 2022-06-21 19:47:22.680208
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    box = Validation.success(2).to_box()
    assert isinstance(box, Box)
    assert box.value == 2


# Generated at 2022-06-21 19:47:31.306358
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either, Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])

    val = Validation.success(1)
    assert isinstance(val.to_either(), Either)
    assert val.to_either() == Right(1)

    val = Validation.fail([1, 2])
    assert isinstance(val.to_either(), Either)
    assert val.to_either() == Left([1, 2])



# Generated at 2022-06-21 19:47:34.583219
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    validation = Validation.success(1)
    assert 'Validation.success[1]' == str(validation)

    validation = Validation.fail(['error1', 'error2'])
    assert 'Validation.fail[None, [\'error1\', \'error2\']]' == str(validation)


# Generated at 2022-06-21 19:47:40.516479
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([1, 2]) == Validation.fail([1, 2])

    assert not (Validation.success(1) == Validation.success(2))
    assert not (Validation.fail([]) == Validation.fail([1]))


# Generated at 2022-06-21 19:47:42.623726
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation(None, []).is_success()
    assert not Validation(None, ['']).is_success()


# Generated at 2022-06-21 19:47:54.145909
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left
    from pymonet.utils import validation_fail

    value = Validation.success('success')
    value_fail = Validation.fail(['fail'])

    assert value.ap(lambda x: Validation.success(x)) == Validation.success('success')
    assert value.ap(lambda x: Validation.fail(['fail'])) == Validation.fail(['fail'])
    assert value_fail.ap(lambda x: Validation.success(x)) == Validation.fail(['fail'])
    assert value_fail.ap(lambda x: Validation.fail(['fail'])) == Validation.fail(['fail', 'fail'])
    assert value.ap(validation_fail) == Validation.fail(['fail'])

# Generated at 2022-06-21 19:47:56.982143
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(value='ok')) == "Validation.success['ok']"
    assert str(Validation.fail([1, 2, 3])) == "Validation.fail[None, [1, 2, 3]]"


# Generated at 2022-06-21 19:48:00.562702
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert Validation.success(1).is_success()

    assert not Validation.fail().is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-21 19:48:04.990741
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-21 19:48:07.753361
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert (str(Validation.success('data')) == 'Validation.success[data]')
    assert (str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]')


# Generated at 2022-06-21 19:48:14.682483
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1]).map(lambda x: x + 1) == Validation.fail([1])
    assert Validation.success([1]).map(lambda x: x + [1]) == Validation.success([1, 1])



# Generated at 2022-06-21 19:48:21.567242
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test fuction
    """
    # When
    success = Validation.success(1)
    fail = Validation.fail()

    # Then
    assert success == Validation.success(1)
    assert fail == Validation.fail()
    assert success != fail
    assert success != Validation.success(2)
    assert fail != Validation.fail([1])


# Generated at 2022-06-21 19:48:24.207775
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1) == Validation.success(1).to_maybe()
    assert Maybe.nothing() == Validation.fail().to_maybe()



# Generated at 2022-06-21 19:48:27.988527
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Unit test for method to_either of class Validation"""

    from pymonet.either import Right
    from pymonet.either import Left
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error 1']).to_either() == Left(['error 1'])
    assert Validation.success([1, 2, 3]).to_either() == Right([1, 2, 3])


# Generated at 2022-06-21 19:48:38.152912
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test __eq__ method of class Validation.
    """
    v_first = Validation.success(1)
    v_second = Validation.success(1)
    v_third = Validation.success(2)
    v_fourth = Validation.fail([])
    v_fifth = Validation.fail([])
    v_sixth = Validation.fail([1, 2])
    v_seventh = Validation.success(1)
    v_seventh.errors = [1]
    assert not v_first == v_third
    assert not v_third == v_fourth
    assert not v_third == v_sixth
    assert not v_fourth == v_sixth
    assert not v_fourth == v_second
    assert not v_seventh == v_third
    assert v_first == v

# Generated at 2022-06-21 19:48:45.357894
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.success(1) != Validation.fail()
    assert Validation.fail(['a', 'b']) == Validation.fail(['a', 'b'])
    assert Validation.fail(['a', 'b']) != Validation.fail(['b', 'a'])
    assert Validation.fail(['a', 'b']) != Validation.success()


# Unit tests for method success of class Validation

# Generated at 2022-06-21 19:48:50.942654
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.success(1) != Validation.fail([])
    assert Validation.fail([]) == Validation.fail()
    assert Validation.fail([]) != Validation.success(1)
    assert Validation.fail(['e1']) == Validation.fail(['e1'])
    assert Validation.fail(['e1']) != Validation.fail(['e1', 'e2'])
    assert Validation.fail(['e1']) != Validation.fail(['e2'])


# Generated at 2022-06-21 19:49:00.399216
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    # Success Validation
    assert Validation.success(3).to_box() == Box(3)
    assert Validation.success(3).to_box() != Box(2)
    assert Validation.success(3).to_box() != None

    # Failed Validation
    assert Validation.fail().to_box() == Box(None)
    assert Validation.fail().to_box() != Box(3)
    assert Validation.fail().to_box() != None


# Generated at 2022-06-21 19:49:04.804786
# Unit test for method map of class Validation
def test_Validation_map():
    val = Validation.success(1).map(lambda v: v + 2)
    assert val == Validation(3, [])
    val = Validation.fail(['error']).map(lambda v: v + 2)
    assert val == Validation(None, ['error'])



# Generated at 2022-06-21 19:49:11.931538
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    When two Validations has same value and errors list they are equals.
    """
    assert Validation.success(value=True) == Validation.success(value=True)
    assert Validation.success(value=True) != Validation.success(value=False)
    assert Validation.success(value=False) != Validation.success(value=True)

    assert Validation.fail(errors=['error1', 'error2']) == Validation.fail(errors=['error1', 'error2'])
    assert Validation.fail(errors=['error1', 'error2']) != Validation.fail(errors=['error1'])
    assert Validation.fail(errors=['error1']) != Validation.fail(errors=['error2'])


# Generated at 2022-06-21 19:49:17.942471
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success("hello").is_success()
    assert Validation.success(["hello"]).is_success()
    assert not Validation.fail("oh no").is_success()
    assert not Validation.fail(["oh no"]).is_success()


# Generated at 2022-06-21 19:49:22.204945
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    success = Validation.success(1)
    assert success.to_maybe() == Maybe.just(1)
    fail = Validation.fail(['error'])
    assert fail.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:26.609638
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success()
    assert validation.is_success()

    validation = Validation.success([1, 2])
    assert validation.is_success()

    validation = Validation.fail()
    assert not validation.is_success()

    validation = Validation.fail(['test'])
    assert not validation.is_success()


# Generated at 2022-06-21 19:49:36.699679
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    assert Validation(True, []).to_try() == Try(True, is_success=True)
    assert Validation(False, []).to_try() == Try(False, is_success=True)
    assert Validation(True, [1, 2, 3]).to_try() == Try(True, is_success=False)
    assert Validation(False, [1, 2, 3]).to_try() == Try(False, is_success=False)
    assert Validation(Right(True), []).to_try() == Try(True, is_success=True)
    assert Validation(Right(False), []).to_try() == Try(False, is_success=True)

# Generated at 2022-06-21 19:49:41.989725
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.maybe import Just, Nothing
    from pymonet.box import Box
    from pymonet.try_ import Success, Failure
    from pymonet.lazy import Lazy

    check.equal(type(Validation.success(1).to_either()), Right)
    check.equal(type(Validation.success(1).to_either().value), int)
    check.equal(type(Validation.success(1).to_either().value), int)
    check.equal(type(Validation.success(1).to_either().value), int)
    check.equal(type(Validation.success(1).to_either().value), int)

    check.equal(type(Validation.fail('error').to_either()), Left)
    check.equal

# Generated at 2022-06-21 19:49:45.335312
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation(None, None).is_success() == False
    assert Validation('', []).is_success() == True


# Generated at 2022-06-21 19:49:50.405258
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(5).to_box() == Box(5)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-21 19:49:52.282132
# Unit test for constructor of class Validation
def test_Validation():
    """
    Test for constructor of class Validation
    """
    val = Validation.success('hello')
    assert val == Validation('hello', [])
    val = Validation.fail(['error'])
    assert val == Validation(None, ['error'])



# Generated at 2022-06-21 19:49:58.537705
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    def to_try_test():
        assert Validation.success(10).to_try() == Try(10, is_success=True)
        assert Validation.fail(['wooo']).to_try() == Try(None, is_success=False)
    to_try_test()

# Generated at 2022-06-21 19:50:09.291576
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(value='success', errors=[])
    assert validation.value == 'success'
    assert validation.errors == []
    assert validation.is_success() is True
    assert validation.is_fail() is False
    assert str(validation) == 'Validation.success[success]'

    validation2 = Validation(value='fail', errors=['error1'])
    assert validation2.value == 'fail'
    assert validation2.errors == ['error1']
    assert validation2.is_success() is False
    assert validation2.is_fail() is True
    assert str(validation2) == 'Validation.fail[fail, [\'error1\']]'



# Generated at 2022-06-21 19:50:23.457718
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    import pymonet.exceptions as e
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    successful_validation = Validation.success(1)
    failing_validation = Validation.fail(['error'])

    assert successful_validation.to_try() == Try(1, is_success=True)
    assert failing_validation.to_try() == Try(None, is_success=False)

    class CustomException(Exception):
        pass

    def throws_exception():
        raise CustomException()

    assert successful_validation.to_try() != Try(throws_exception(), is_success=True)

# Generated at 2022-06-21 19:50:35.120702
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for method ap of class Validation"""
    from pymonet.validation import Validation

    def fun(value):
        """
        Function takes parameter and returns Validation without errors.

        :param value: parameter
        :type value: Any
        :return: value wrapped in Validation
        :rtype: Validation[Any, []]
        """
        return Validation.success(value)

    def fun_that_raises(value):
        """
        Function takes parameter and raises exception

        :param value: parameter
        :type value: Any
        :raises: Exception
        """
        raise Exception()


# Generated at 2022-06-21 19:50:36.914384
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.success().is_fail()


# Generated at 2022-06-21 19:50:39.516530
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.success(10).to_lazy()
    assert lazy == Lazy(lambda: 10)

# Generated at 2022-06-21 19:50:51.833994
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(True) == Validation.success(True)
    assert Validation.success(True) != Validation.success(False)

    assert Validation.success(True) != Validation.fail(['test'])
    assert Validation.success(True) != Validation.fail([])

    assert Validation.fail(['test']) == Validation.fail(['test'])
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail(['test', 'test']) == Validation.fail(['test', 'test'])

    assert Validation.fail(['test']) != Validation.fail([])
    assert Validation.fail(['test']) != Validation.fail([1])

# Generated at 2022-06-21 19:50:55.914133
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:51:06.571316
# Unit test for method ap of class Validation
def test_Validation_ap():

    # Create Validation 1 with some errors
    v1 = Validation(
        1,
        [
            Error(1),
            Error(2)
        ]
    )

    # Create Validation 2 with another errors
    v2 = Validation(
        2,
        [
            Error(3),
            Error(4)
        ]
    )

    # ap applied Validation 2 on Validation 1.
    # After applying Validation 1 should has value 1 and concated errors list
    # and errors list should be [Error(1), Error(2), Error(3), Error(4)]
    assert v1.ap(lambda x: v2) == Validation(
        1,
        [
            Error(1),
            Error(2),
            Error(3),
            Error(4)
        ]
    )



# Generated at 2022-06-21 19:51:10.955246
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Unit tests for method Validation.to_maybe"""
    from pymonet.maybe import Maybe

    assert Validation.success('test').to_maybe() == Maybe.just('test')
    assert Validation.fail().to_maybe() == Maybe.nothing()

# Unit tests for method map of class Validation

# Generated at 2022-06-21 19:51:13.429012
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    validation_success = Validation.success(8)
    assert validation_success.to_maybe().get_value() == 8

    validation_fail = Validation.fail([1, 3])
    assert validation_fail.to_maybe().get_value() is None
    assert validation_fail.to_maybe().get_value_or(10) == 10


# Generated at 2022-06-21 19:51:17.597235
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.maybe import Just
    from pymonet.either import Left, Right

    validation = Validation.success(Just(1))
    either = validation.to_either()
    assert isinstance(either, Right)


# Generated at 2022-06-21 19:51:24.371723
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(10).to_try() == Try.success(10)
    assert Validation.fail(['Error']).to_try() == Try.fail(['Error'])


# Generated at 2022-06-21 19:51:30.268706
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(5) == Validation.success(5)
    assert Validation.fail(5) == Validation.fail(5)
    assert Validation.success(5) != Validation.success(6)
    assert Validation.fail(5) != Validation.fail(6)

    assert Validation.success(5) != Validation.fail(5)
    assert Validation.fail(5) != Validation.success(5)


# Generated at 2022-06-21 19:51:34.683353
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-21 19:51:40.413775
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Validation.success(Maybe.just(1)).to_either() == Right(Maybe.just(1))
    assert Validation.success(Maybe.nothing()).to_either() == Right(Maybe.nothing())
    assert Validation.fail(['Error']).to_either() == Left(['Error'])


# Generated at 2022-06-21 19:51:48.303317
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Map method just calls mapper function with Validaion value and returns new Validation with mapped value
    and old Validation errors
    """
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])  # Success validation with mapped value
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation(None, ['error'])  # Fail validation with mapped value

# Generated at 2022-06-21 19:51:52.092601
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box().unbox() == 1
    assert Validation.success(None).to_box().unbox() is None
    assert Validation.fail(None).to_box().unbox() is None



# Generated at 2022-06-21 19:51:56.098632
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(123) == Validation.success(123).to_maybe()
    assert Maybe.nothing() == Validation.fail().to_maybe()
    assert Maybe.nothing() == Validation.fail(['error']).to_maybe()


# Generated at 2022-06-21 19:52:01.539050
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    def f():
        return 'test'

    result = Validation.success('test').to_lazy().value
    assert result == f()
    assert result == 'test'

    result = Validation.fail(['error']).to_lazy().value
    assert not result
    assert result is None



# Generated at 2022-06-21 19:52:06.049921
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Validation.ap(Validation) -> Validation with value and concated error lists.
    """
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.try_ import Try

    assert Validation.success('foo').ap(Validation.success('bar')) == Validation.success('bar')
    assert Validation.success('foo').ap(Validation.fail(['bar'])) == Validation.fail(['bar'])
    assert Validation.fail(['foo']).ap(Validation.success('bar')) == Validation.fail(['foo'])
    assert Validation.fail(['foo']).ap(Validation.fail(['bar'])) == Validation.fail(['foo', 'bar'])

    assert Validation.success('foo').ap(Left('bar'))

# Generated at 2022-06-21 19:52:13.208623
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(5).map(lambda x: x * 2) == Validation.success(10)
    assert Validation.fail([]).map(lambda x: x * 2) == Validation.fail([])

    assert Validation.success("some value").map(lambda x: x + "1").value == "some value1"
    assert Validation.success("some value").map(len).value == 12
    assert Validation.success("some value").map(lambda x: None).value is None
    assert Validation.success("some value").map(lambda x: x * 2).value == "some valuesome value"
    assert Validation.success("some value").map(lambda x: x * 2).value.__len__() == 24


# Generated at 2022-06-21 19:52:27.183171
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(5) == Validation.success(5)
    assert not Validation.fail(['error']) == Validation.fail('error')
    assert not Validation.success(5) == Validation.success(10)
    assert not Validation.success(10) == Validation.fail(['error'])
    assert not Validation.fail(['error']) == Validation.success(5)
    assert not Validation.fail(['error']) == Validation.success(10)



# Generated at 2022-06-21 19:52:30.277433
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet import is_nothing, is_just

    assert is_just(Validation.success(5).to_maybe())
    assert is_nothing(Validation.fail(5).to_maybe())


# Generated at 2022-06-21 19:52:34.867148
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.monad import Just, Nothing

    success = Validation.success('hello')
    assert success.to_maybe() == Just('hello')

    fail = Validation.fail('hello')
    assert fail.to_maybe() == Nothing()



# Generated at 2022-06-21 19:52:39.438930
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.monad_validation import Validation
    assert Validation.success() == Validation.success([])
    assert Validation.success({'key': 'value'}) == Validation.success({'key': 'value'})
    assert Validation.fail() == Validation.fail()


# Generated at 2022-06-21 19:52:48.095301
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
     Success Singleton:

             Success(1)
                /  \
              /      \
            /          \
          /              \
    Success(2)         Success(2)
    """

    ne_success = Validation.success(1)
    ne_success_eq = Validation.success(1)
    ne_success_not_eq_value = Validation.success(2)
    ne_success_not_eq = Validation.success(3)
    ne_success_not_eq.errors.append(1)

    assert ne_success == ne_success_eq
    assert ne_success != ne_success_not_eq_value
    assert ne_success != ne_success_not_eq



# Generated at 2022-06-21 19:52:51.955764
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(['some']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:52:56.338105
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    fail = Validation.fail()
    success = Validation.success()

    assert isinstance(fail, Validation)
    assert isinstance(success, Validation)
    assert fail.is_fail()
    assert not success.is_fail()


# Generated at 2022-06-21 19:53:01.473428
# Unit test for method map of class Validation
def test_Validation_map():
    v1 = Validation.success('value')
    v2 = Validation.fail(['error1', 'error2'])
    assert v1.map(lambda v: v + '1') == Validation('value1', [])
    assert v2.map(lambda _: 'some value') == Validation(None, ['error1', 'error2'])


# Generated at 2022-06-21 19:53:07.988683
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(1).map(lambda a: a - 1).to_either() == Right(0)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])
    assert Validation.fail([1, 2]).map(lambda a: a - 1).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:53:14.901198
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.lazy import Lazy
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.try_ import Success, Failure

    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.success(1).map(lambda x: Lazy(lambda: x + 1)) == Validation(Lazy(lambda: 2), [])
    assert Validation.success(1).map(lambda x: Box(x + 1)) == Validation(Box(2), [])
    assert Validation.success(1).map(lambda x: Right(x + 1)) == Validation(Right(2), [])

# Generated at 2022-06-21 19:53:30.414982
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either, Left, Right

    assert Validation.success() == Validation.success().to_either()
    assert Validation.success(1).to_either() == Either.right(1)

    assert Validation.fail(['error']).to_either() == Either.left(['error'])

    assert Validation.fail(['check', 'errors']).to_either() == Either.left(['check', 'errors'])


# Generated at 2022-06-21 19:53:37.844535
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.
    """
    # Test for equal
    assert Validation.success(5) == Validation.success(5)

    # Test for not equal
    assert not Validation.success(5) == Validation.success('5')
    assert not Validation.success(5) == Validation.fail(['no value'])
    assert not Validation.fail(['no value']) == Validation.fail(['no value 1'])


# Generated at 2022-06-21 19:53:44.795689
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    from pymonet.monad import Validation

    empty_validation = Validation.fail()
    assert empty_validation.value is None
    assert empty_validation.errors == []

    filled_validation = Validation.fail([1, 2])
    assert filled_validation.value is None
    assert filled_validation.errors == [1, 2]

    empty_validation = Validation.success()
    assert empty_validation.value is None
    assert empty_validation.errors == []

    filled_validation = Validation.success([1, 2])
    assert filled_validation.value == [1, 2]
    assert filled_validation.errors == []


# Generated at 2022-06-21 19:53:50.779911
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.success(1).to_try().is_success()
    assert Validation.fail().to_try() == Try(None)
    assert Validation.fail().to_try().is_fail()

# Generated at 2022-06-21 19:53:59.710560
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Given
    def should_return_1(value):
        return Validation.success(1)

    def should_return_empty_list(value):
        return Validation.success()

    def should_return_empty_list_and_error(value):
        return Validation.fail([1])

    # When & Then
    assert Validation.success(1).ap(should_return_empty_list) == Validation.success(1)
    assert Validation.success(1).ap(should_return_1) == Validation.success(1)
    assert Validation.success(1).ap(should_return_empty_list_and_error) == Validation.fail([1])
    assert Validation.fail([1]).ap(should_return_empty_list_and_error) == Validation.fail([1, 1])

# Generated at 2022-06-21 19:54:10.355999
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """Unit test for method __eq__ of class Validation"""

    from pymonet.either import Left, Right

    def mapper(value):
        return value

    def folder(value):
        if value > 4:
            return Validation.success(value + 1)
        return Validation.fail([value])

    # testing simple Validation
    validation1 = Validation(4,  [4])
    validation2 = Validation(4,  [4])
    validation3 = Validation(5,  [5])
    validation4 = Validation(5,  [5, 10])
    validation5 = Validation(10, [10])

    assert validation1 == validation2
    assert validation2 != validation3
    assert validation3 != validation4
    assert validation4 != validation5

    # testing Validation after mapping
    validation6 = validation1

# Generated at 2022-06-21 19:54:13.268990
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    value = 'value'
    validation = Validation.success(value)

    assert validation.is_success()


# Generated at 2022-06-21 19:54:17.149325
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.success import Success

    assert Validation.success(5).to_box() == Box(5)


# Generated at 2022-06-21 19:54:21.096482
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:54:23.253512
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    s = Validation.success()
    f = Validation.fail()

    assert s.is_success()
    assert not f.is_success()


# Generated at 2022-06-21 19:54:43.170790
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation(None, [])
    assert(str(validation) == 'Validation.fail[None, []]')

    validation = Validation(2, [])
    assert(str(validation) == 'Validation.success[2]')

    validation = Validation(None, ['Some Error'])
    assert(str(validation) == 'Validation.fail[None, [\'Some Error\']]')

    # unit test for __eq__ method
    validation_a = Validation(2, [])
    validation_b = Validation(2, [])
    assert(validation_a == validation_b)

    validation_a = Validation(['value'], [])
    validation_b = Validation(['value'], [])
    assert(validation_a == validation_b)

    validation_a = Val

# Generated at 2022-06-21 19:54:47.384810
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation.
    """
    from pymonet.maybe import Maybe
    from pymonet.function import identity

    validation = Validation.fail(['some error'])
    assert validation.is_fail()

    validation = Validation.success("Value")
    assert not validation.is_fail()


# Generated at 2022-06-21 19:54:49.107358
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-21 19:54:52.513220
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(None, [1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'
    assert str(Validation(1, [])) == 'Validation.success[1]'


# Generated at 2022-06-21 19:54:56.931976
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:55:06.006323
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.success(1).map(lambda x: Right(x + 1)) == Validation(Right(2), [])
    assert Validation.success(1).map(lambda x: Left(x + 1)) == Validation(Left(2), [])
    assert Validation.success(1).map(lambda x: Maybe.just(x + 1)) == Validation(Maybe.just(2), [])

# Generated at 2022-06-21 19:55:10.450022
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Test for method ap"""
    case1 = Validation.fail([1,2,3])
    case2 = Validation.success(5)
    case3 = Validation.fail([4,5,6])
    case4 = Validation.success(2)
    assert Validation.fail([1,2,3,4,5,6]) == case1.ap(lambda _: case3)
    assert Validation.success(5) == case2.ap(lambda x: Validation.success(x * 2))
    assert Validation.success(10) == case2.ap(lambda x: case4.map(lambda y: x * y))
    assert Validation.fail([1,2,3]) == case1.ap(lambda _: case2.to_either())

# Generated at 2022-06-21 19:55:14.153269
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert(str(Validation.success('foo')) == 'Validation.success[foo]')
    assert(str(Validation.fail(['bar'])) == 'Validation.fail[None, [\'bar\']]')


# Generated at 2022-06-21 19:55:19.444532
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation(1, []).map(lambda x: x + 1) == Validation(2, [])
    assert Validation(1, []).map(lambda x: () if x == 1 else []) == Validation((), [])
    assert Validation(None, []).map(lambda x: []) == Validation([], [])
    assert Validation(None, []).map(lambda x: None) == Validation(None, [])


# Generated at 2022-06-21 19:55:24.221600
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v1 = Validation.success(1)
    v2 = Validation.success(2)
    v3 = Validation.fail()
    v4 = Validation.fail([1, 2])
    assert v1 == Validation.success(1)
    assert v1 != v2
    assert v3 != v4


# Generated at 2022-06-21 19:55:46.579367
# Unit test for method ap of class Validation
def test_Validation_ap():
    def assert_equal(validation, expected_value, expected_errors):
        assert validation.value == expected_value
        assert validation.errors == expected_errors

    def error_fn(value):
        return Validation(value, ['error'])

    assert_equal(Validation.success('initial value').ap(error_fn), 'initial value', [])
    assert_equal(Validation.fail(['initial error']).ap(error_fn), None, ['initial error'])


# Generated at 2022-06-21 19:55:50.597397
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:55:57.755506
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success('a').ap(Validation.success(lambda a: a + 'b')) == Validation.success('ab')
    assert Validation.success('a').ap(Validation.fail(['Something wrong'])) == Validation.success('a')
    assert Validation.fail(['Something wrong']).ap(Validation.success(lambda a: a + 'b')) == Validation.fail(['Something wrong'])
    assert Validation.fail(['Something wrong']).ap(Validation.fail(['Something wrong'])) == Validation.fail(['Something wrong', 'Something wrong'])


# Generated at 2022-06-21 19:55:59.457127
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() == False
    assert Validation.fail().is_fail() == True


# Generated at 2022-06-21 19:56:07.239534
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error 1', 'error 2'])) == 'Validation.fail[None, [\'error 1\', \'error 2\']]'
    assert str(Validation.success(1)) == 'Validation.success[1]'



# Generated at 2022-06-21 19:56:11.178114
# Unit test for method to_box of class Validation
def test_Validation_to_box():

    # Test when errors list are empty
    assert Validation(1, []).to_box() == Box(1)

    # Test when errors list are empty
    assert Validation(None, [1, 2]).to_box() == Box(None)


# Generated at 2022-06-21 19:56:14.388325
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(4).to_box().value == 4
    assert Validation.fail(['x']).to_box().value is None



# Generated at 2022-06-21 19:56:18.589217
# Unit test for method ap of class Validation
def test_Validation_ap():
    def test_function():
        return Validation.fail([1, 2, 3])

    validation = Validation.success(None).ap(test_function)

    assert validation.is_fail()
    assert validation.errors == [1, 2, 3]
    assert validation.value is None


# Generated at 2022-06-21 19:56:22.480566
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    validation = Validation(None, ['error'])

    assert validation.to_try() == Failure(None, ['error'])

    validation = Validation(4, [])

    assert validation.to_try() == Success(4, [])

# Generated at 2022-06-21 19:56:26.400374
# Unit test for method map of class Validation
def test_Validation_map():
    fn = lambda x: x*2
    assert Validation.success(5).map(fn) == Validation(10, [])
    assert Validation.fail([1,2,3]).map(fn) == Validation(None, [1,2,3])


# Generated at 2022-06-21 19:57:05.654447
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe(): # pragma: no cover
    from pymonet.maybe import Maybe

    assert Validation.success('a').to_maybe() == Maybe.just('a')
    assert Validation.fail('a').to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:57:12.606019
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Tests to_maybe method of class Validation."""
    from pymonet.monad import Monad
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert Monad.get('success').to_maybe() == Maybe.just(Monad.get('success').value)
    assert Monad.get('success').to_maybe() == Maybe.just(Monad.get('success').value)
    assert Monad.get('fail').to_maybe() == Maybe.nothing()
    assert Monad.get('success').to_maybe() == Maybe.just(Monad.get('success').value)

    assert Validation.fail().to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:57:17.931596
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 1) == Validation.fail([1, 2, 3])

