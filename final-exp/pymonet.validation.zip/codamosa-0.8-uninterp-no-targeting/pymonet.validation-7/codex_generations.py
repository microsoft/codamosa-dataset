

# Generated at 2022-06-21 19:47:24.198346
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    c = Validation.success('a')
    assert c.__str__() == 'Validation.success[a]'

    c = Validation.fail(['a', 'b'])
    assert c.__str__() == 'Validation.fail[None, [\'a\', \'b\']]'


# Generated at 2022-06-21 19:47:31.516199
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.functors.functor_either import FunctorEither

    functor = FunctorEither()

    validation = Validation(1, [])
    assert functor.fmap(validation.to_either(), lambda a: a + 1) == Right(2), "Test for successful monad"

    validation = Validation(None, [1, 2, 3])
    assert validation.to_either() == Left([1, 2, 3]), "Test for failed monad"


# Generated at 2022-06-21 19:47:33.797469
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.success()
    assert validation.is_fail() == False

    validation = Validation.fail(['Error'])
    assert validation.is_fail() == True


# Generated at 2022-06-21 19:47:39.209878
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(2)) == 'Validation.success[2]'
    assert str(Validation.fail(['error1'])) == 'Validation.fail[None, [\'error1\']]'


# Generated at 2022-06-21 19:47:42.853942
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:47:47.471754
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(value=1).to_box() == Box(1)
    assert Validation.fail(errors=[1, 2]).to_box() == Box(None)


# Generated at 2022-06-21 19:47:56.324024
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Test method bind of class Validation."""
    fn = lambda a: (a > 10 and Validation.success(str(a))) or Validation.fail(['Value is not greater than 10'])
    assert Validation.success(5).bind(fn) == Validation.fail(['Value is not greater than 10'])
    assert Validation.success(15).bind(fn) == Validation.success('15')


# Generated at 2022-06-21 19:48:00.612155
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    succ = Validation.success(42)
    assert succ.to_maybe() == Just(42)

    fail = Validation.fail(['error'])
    assert fail.to_maybe() == Nothing()


# Generated at 2022-06-21 19:48:03.553182
# Unit test for method is_success of class Validation
def test_Validation_is_success():
  def test():
    assert Validation.success().is_success()
    assert not Validation.success(1).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail(1).is_success()
    assert not Validation.fail([]).is_success()

  test()
  # Lazy test
  Lazy(test)()


# Generated at 2022-06-21 19:48:05.944255
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    test = Validation.success(0)
    assert test.to_lazy() == Lazy(lambda: 0)



# Generated at 2022-06-21 19:48:16.192104
# Unit test for constructor of class Validation
def test_Validation():

    # test constructor with value and errors
    test_validation = Validation(1, [])
    assert test_validation.value == 1
    assert test_validation.errors == []

    # test constructor with None and empty errors
    test_validation = Validation(None, [])
    assert test_validation.value == None
    assert test_validation.errors == []

    # test constructor with None and empty errors
    # test constructor with value and empty errors
    test_validation = Validation('123', ['error1', 'error2'])
    assert test_validation.value == '123'
    assert test_validation.errors == ['error1', 'error2']



# Generated at 2022-06-21 19:48:21.215758
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation

    :returns: None
    """
    from pymonet.box import Box
    assert Box(None) == Validation.fail().to_box()
    assert Box(1) == Validation.success(1).to_box()



# Generated at 2022-06-21 19:48:23.916051
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left
    result = Validation.success('hello').bind(lambda x: Left('world'))
    assert result.value == 'hello' and result.errors == 'world'

# Generated at 2022-06-21 19:48:28.813488
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    test_success = Validation.success()
    test_fail = Validation.fail()
    assert(str(test_success) == 'Validation.success[None]')
    assert(str(test_fail) == 'Validation.fail[None, []]')


# Generated at 2022-06-21 19:48:31.508195
# Unit test for constructor of class Validation
def test_Validation():
    # default constructor
    assert_that(Validation(42, []), equal_to(Validation.success(42)))

    # constructor with only value
    assert_that(Validation(42), equal_to(Validation.success(42)))

    # constructor with value and empty list
    assert_that(Validation(42, []), equal_to(Validation.success(42)))

    # constructor with value and empty list
    assert_that(Validation(None, [42]), equal_to(Validation.fail([42])))


# Generated at 2022-06-21 19:48:35.814073
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation('test value', []).map(lambda t: 'new' + t) == Validation('new' + 'test value', [])
    assert Validation('test value', []).map(lambda t: t + ' new') == Validation('test value' + ' new', [])


# Generated at 2022-06-21 19:48:45.831135
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import is_right

    def inc(x):
        return x + 1

    def to_right(x):
        return Validation.success(x)

    assert Validation.success(None).bind(to_right).bind(inc) == Validation.success(1)
    assert Validation.fail().bind(to_right).bind(inc) == Validation.fail()

    from pymonet.monad_try import Try

    def inc_try(x):
        return Try.success(x + 1)

    assert Validation.success(None).bind(to_right).bind(inc_try).bind(to_right) == Validation.success(1)
    assert Validation.fail().bind(to_right).bind(inc_try).bind(to_right) == Validation.fail()

# Generated at 2022-06-21 19:48:50.979624
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)

# Generated at 2022-06-21 19:48:56.952305
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation.success(1)
    assert Validation(None, ['error1', 'error2']) == Validation.fail(['error1', 'error2'])

# Test for method is_success() of class Validation

# Generated at 2022-06-21 19:49:02.410856
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success('foo') == Validation.success('foo')
    assert Validation.success(None) != Validation.success('foo')
    assert Validation.success() != Validation.success(None)
    assert Validation.success('foo') != Validation.fail(['bar'])
    assert Validation.fail(['bar']) != Validation.fail(['foo'])


# Generated at 2022-06-21 19:49:08.173758
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:49:13.990958
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad import bind

    f = lambda x: Validation.success(x + 1)
    g = lambda x: Validation.success(x * 2)

    assert bind(f, g)(1) == Validation.success(4)
    assert bind(f, g)(2) == Validation.success(6)



# Generated at 2022-06-21 19:49:18.231800
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    validation_1 = Validation.success(1)
    assert validation_1.to_either() == Right(1)

    validation_2 = Validation.fail([1, 2, 3])
    assert validation_2.to_either() == Left([1, 2, 3])


# Generated at 2022-06-21 19:49:23.218470
# Unit test for method to_box of class Validation
def test_Validation_to_box():

    validation_1 = Validation.success(3)
    assert validation_1.to_box() == Box(3)

    validation_2 = Validation.fail([1, 2])
    assert validation_2.to_box() == Box(None)


# Generated at 2022-06-21 19:49:26.394641
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success([1, 2, 3]).to_try() == Try([1, 2, 3], is_success=True)
    assert Validation.fail(errors=[1, 2, 3]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:49:33.596248
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Maybe

    def folder(value):
        return Maybe.just(value + 1)

    validation = Validation.success(1)
    assert validation.bind(folder) == Maybe.just(2)

    validation = Validation.fail([1, 2])
    assert validation.bind(folder) == Maybe.nothing()


# Generated at 2022-06-21 19:49:38.033127
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    v = Validation.success('VALUE')
    assert v.to_either().is_right()
    assert v.to_either().right == 'VALUE'
    assert str(v.to_either()) == 'Either.right[VALUE]'
    v = Validation.fail(['ERROR 1', 'ERROR 2'])
    assert v.to_either().is_left()
    assert v.to_either().left == ['ERROR 1', 'ERROR 2']
    assert str(v.to_either()) == 'Either.left[ERROR 1, ERROR 2]'


# Generated at 2022-06-21 19:49:45.739581
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either

    def validation_to_either_with_success_function(validation):
        def success_function():
            return validation.to_either()
        return success_function

    def validation_to_either_with_fail_function(validation):
        def fail_function():
            return validation.to_either()
        return fail_function

    validation_to_either_with_success_function = given.that(_value_is_equal_to(
        Validation.success(5).to_either()
    )).can_be_verified_by(
        validation_to_either_with_success_function(Validation.success(5))
    ).for_all().verify()


# Generated at 2022-06-21 19:49:49.956039
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    from pymonet.either import Left, Right

    assert Validation.success('value').to_either() == Right('value')
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-21 19:49:51.665150
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[100]' == str(Validation.success(100))


# Generated at 2022-06-21 19:50:03.963106
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test of Validation.to_try() method.
    """
    from pymonet.monad_try import Try

    assert Validation.success().to_try() == Try(None, is_success=True)
    assert Validation.success(42).to_try() == Try(42, is_success=True)
    assert Validation.fail().to_try() == Try(None, is_success=False)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:50:09.239902
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('test').value == 'test'
    assert Validation.success().value == None
    assert Validation.fail(['error']).errors == ['error']
    assert Validation.fail().errors == []


# Generated at 2022-06-21 19:50:13.884201
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['1', '2']).to_either() == Left(['1', '2'])


# Generated at 2022-06-21 19:50:23.927287
# Unit test for method ap of class Validation
def test_Validation_ap():
    v = Validation.success(1)
    f = Validation.success(lambda x: x + 1)
    assert v.ap(f).value == 2
    assert v.ap(f).errors == []

    v = Validation.success(1)
    f = Validation.fail(errors=[1])
    assert v.ap(f).value == 1
    assert v.ap(f).errors == [1]

    v = Validation.success(1)
    f = Validation.fail(errors=[1, 2])
    assert v.ap(f).value == 1
    assert v.ap(f).errors == [1, 2]

    v = Validation.fail(errors=[1])
    f = Validation.success(lambda x: x + 1)
    assert v.ap(f).value == 1
    assert v

# Generated at 2022-06-21 19:50:34.820692
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.fail(['file not created']).ap(
        lambda value: Validation.fail(['file not found'])
    ) == Validation(None, ['file not created', 'file not found'])
    assert Validation.success(123).ap(
        lambda value: Validation.fail(['file not found'])
    ) == Validation(123, ['file not found'])
    assert Validation.fail(['file not created']).ap(
        lambda value: Validation.success(123)
    ) == Validation(None, ['file not created'])
    assert Validation.success(123).ap(
        lambda value: Validation.success(123)
    ) == Validation(123, [])


# Generated at 2022-06-21 19:50:42.646614
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(0).bind(lambda v: Validation.success(v + 1)) == \
           Validation.success(1)
    assert Validation.success(0).bind(lambda v: Validation.fail(['error'])) == \
           Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda v: Validation.success(v + 1)) == \
           Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda v: Validation.fail(['error', 'error2'])) == \
           Validation.fail(['error', 'error2'])


# Generated at 2022-06-21 19:50:46.202781
# Unit test for method ap of class Validation
def test_Validation_ap():
    v = Validation.fail([1, 2])
    m = Validation.fail([3, 4])

    assert v.ap(lambda _: m) == Validation(None, [1, 2, 3, 4])

# Generated at 2022-06-21 19:50:50.240391
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.monad_try import Try

    validation = Validation(1, [])

    assert validation.is_success()
    assert validation.value == 1

    try:
        validation_fail = Validation(1, ['error'])
        validation_fail.value
        assert False
    except Exception:
        assert True


# Generated at 2022-06-21 19:50:57.892700
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(Box(1)).to_box() == Box(Box(1))
    assert Validation.success(Box(1)).to_box().unbox() == Box(1)
    assert Validation.success(1).to_box().unbox() == 1
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail(["error"]).to_box() == Box(None)

# Generated at 2022-06-21 19:51:05.804397
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    def f(x):
        return Try(x+1, is_success=True)

    assert Validation.success(2).ap(f) == Validation.success(2)
    assert Validation.fail(Left(2)).ap(f) == Validation.fail(Left(2))
    assert Validation.fail(Maybe.nothing()).ap(f) == Validation.fail(Maybe.nothing())


# Generated at 2022-06-21 19:51:12.750326
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Two Validations are equals when values and errors lists are equal.
    """
    assert Validation(None, []) == Validation(None, [])
    assert not Validation(None, []) == Validation(None, ['error'])
    assert not Validation(None, []) == Validation('value', [])
    assert not Validation(None, []) == Validation('value', ['error'])


# Generated at 2022-06-21 19:51:19.491800
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    f_success = lambda x: x
    success = Validation.success(1)
    fail = Validation.fail()

    assert success.to_lazy().eval() == 1
    assert fail.to_lazy().eval() == None

    f_fail = lambda x: None
    assert f_fail(success.to_lazy().eval()) == 1

    assert f_success(success.to_lazy().eval()) == f_success(1)
    assert f_fail(fail.to_lazy().eval()) == None


# Generated at 2022-06-21 19:51:29.272091
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    test_value = 42
    test_errors = ['error 1', 'error 2']
    test_value2 = 24

    validation = Validation(test_value, test_errors)
    either = validation.to_either()
    assert isinstance(either, Left)
    assert either.value == test_errors
    assert either != Right(validation.value)

    validation = Validation(test_value2, [])
    either = validation.to_either()
    assert isinstance(either, Right)
    assert either.value == test_value2
    assert either != Left(validation.errors)



# Generated at 2022-06-21 19:51:33.701768
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.tools import assert_equal_strings
    from .test_tools import test_failed

    # Validation.success
    result = Validation.success()
    assert_equal_strings(result, 'Validation.success[None]')

    # Validation.success for value
    result = Validation.success(10)
    assert_equal_strings(result, 'Validation.success[10]')

    # Validation.fail
    result = Validation.fail()
    assert_equal_strings(result, 'Validation.fail[None, []]')

    # Validation.fail for value
    result = Validation.fail([])
    assert_equal_strings(result, 'Validation.fail[None, []]')

    # Validation.fail for value and errors
    result = Validation.fail(['error'])

# Generated at 2022-06-21 19:51:37.885802
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Validation works according to laws
    """
    from pymonet.box import Box

    a = Validation.success(1)
    b = a.to_box()

    assert isinstance(b, Box)
    assert b == Box(1)


# Generated at 2022-06-21 19:51:43.305862
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success() == Validation(None, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation(value=None, errors=['error']) == Validation(None, ['error'])


# Generated at 2022-06-21 19:51:47.736442
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]'


# Generated at 2022-06-21 19:51:51.833650
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(10).map(lambda x: x+10) == Validation.success(20)
    assert Validation.fail([1, 2]).map(lambda x: x+10) == Validation.fail([1, 2])


# Generated at 2022-06-21 19:51:57.737817
# Unit test for method bind of class Validation
def test_Validation_bind():

    # GIVEN
    a = Validation.success(1)
    b = Validation.success(2)
    c = Validation.fail(['error_1'])
    d = Validation.fail(['error_1', 'error_2'])

    # WHEN -> THEN
    assert a.bind(lambda v: b) == b
    assert a.bind(lambda v: c) == c
    assert a.bind(lambda v: d) == d


# Generated at 2022-06-21 19:52:04.133426
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    valid = Validation.success(1)
    box_valid = valid.to_box()
    assert box_valid.value == 1
    assert isinstance(box_valid, Box)

    invalid = Validation.fail([])
    box_invalid = invalid.to_box()
    assert box_invalid.value == None
    assert isinstance(box_invalid, Box)


# Generated at 2022-06-21 19:52:13.208890
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([2])) == 'Validation.fail[None, [2]]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'



# Generated at 2022-06-21 19:52:19.684858
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Validation.
    """
    assert str(Validation('val', [])) == "Validation.success['val']"
    assert str(Validation('val', [1, 2])) == "Validation.fail['val', [1, 2]]"


# Generated at 2022-06-21 19:52:22.805792
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """Unit test for method to_box of class Validation"""
    assert Validation.success('hi').to_box().value == 'hi'
    assert Validation.fail(['There is an error']).to_box().value == None

# Generated at 2022-06-21 19:52:26.145814
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-21 19:52:28.094307
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation('something', []).is_fail() == False
    assert Validation(None, [1]).is_fail() == True


# Generated at 2022-06-21 19:52:31.838149
# Unit test for method bind of class Validation
def test_Validation_bind():
    def folder(value):
        if int(value) < 100:
            return Validation.success(int(value))
        return Validation.fail(["value is greater than 100"])

    assert Validation.success(5).bind(folder) == Validation.success(5)
    assert Validation.success(1000).bind(folder) == Validation.fail(["value is greater than 100"])


# Generated at 2022-06-21 19:52:36.864272
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert "Validation.success[1]" == str(Validation.success(1))
    assert "Validation.fail[None, [1, 2, 3]]" == str(Validation.fail([1, 2, 3]))


# Generated at 2022-06-21 19:52:44.073974
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.monad_try as mt

    # Test successful Validation to Try
    result = Validation.success(5).to_try()
    assert isinstance(result, mt.Try)
    assert result.is_success()
    assert result.unbox() == 5

    # Test failed Validation to Try
    result = Validation.fail(['Failed']).to_try()
    assert isinstance(result, mt.Try)
    assert result.is_fail()
    assert result.unbox() == None


# Generated at 2022-06-21 19:52:50.586660
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # There are two same successful Validations
    valid_monad_1 = Validation((1, 2), [])
    valid_monad_2 = Validation((1, 2), [])
    assert valid_monad_1 == valid_monad_2

    # There are two same fail Validations
    valid_monad_1 = Validation(None, [1, 2, 3])
    valid_monad_2 = Validation(None, [1, 2, 3])
    assert valid_monad_1 == valid_monad_2

    # Successful Validation not equals failed
    valid_monad_1 = Validation((1, 2), [])
    valid_monad_2 = Validation(None, [1, 2, 3])
    assert not valid_monad_1 == valid_monad_2


# Unit

# Generated at 2022-06-21 19:53:01.596015
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1]).to_either() == Left([1])

    assert Validation.success(1).to_either().map(lambda x: x + 1) == Right(2)
    assert Validation.fail([]).to_either().map(lambda x: x + 1) == Left([])
    assert Validation.fail([1]).to_either().map(lambda x: x + 1) == Left([1])


# Generated at 2022-06-21 19:53:10.907610
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    assert Validation.fail().to_try() == Try(None)
    assert Validation.success(1).to_try() == Try(1)

# Generated at 2022-06-21 19:53:21.897193
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for Validation.

    :returns: True when unit test is successful
    :rtype: Boolean
    """

    from pymonet.monad_try import Try

    # Create a function that returns success False
    def check_even(arg):
        return Try(not arg % 2 == 0, is_success=arg % 2 == 0)

    # Create Success Validation
    validation = Validation(3, [])

    # Apply function to Success Validation
    even_result = validation.ap(check_even)

    # Check that validation errors is not empty
    assert even_result.errors == [False]

    # Check that validation value is 3
    assert even_result.value == 3

    # Create Fail validation
    validation = Validation.fail(['error 1', 'error 2'])

    # Apply function to Fail

# Generated at 2022-06-21 19:53:30.002191
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Given
    v1 = Validation.fail(['error1'])
    v2 = Validation.fail(['error1'])
    v3 = Validation.fail(['error1', 'error2'])

    # When
    v_eq = v1 == v2
    v_neq = v1 == v3

    # Then
    assert v_eq is True
    assert v_neq is False



# Generated at 2022-06-21 19:53:34.839743
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Try(1).to_validation().to_box() == Try(1).to_maybe().to_box()
    assert Validation.success(1).to_box() == Box(1)


# Generated at 2022-06-21 19:53:40.919347
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test that __str__ method always return correct value

    >>> from pymonet.monad import Validation
    >>> from datetime import date

    >>> a = Validation.success(date(year=1986, month=6, day=23))
    >>> print(a)
    Validation.success[1986-06-23]

    >>> a = Validation.fail(['a', 'b', 'c'])
    >>> print(a)
    Validation.fail[None, ['a', 'b', 'c']]
    """



# Generated at 2022-06-21 19:53:44.885063
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(None, [])) == 'Validation.success[None]'
    assert str(Validation([], [1, 2])) == 'Validation.fail[[], [1, 2]]'



# Generated at 2022-06-21 19:53:56.178341
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    """Unit test for method bind of class Validation"""

    # test 1
    validation = Validation(1, [])
    result = validation.bind(lambda x: Validation(x * 2, []))
    assert result == Validation(2, [])

    # test 2
    validation = Validation(1, [])
    result = validation.bind(lambda x: Validation(x * 2, []))
    assert result == Validation(2, [])

    # test 3
    validation = Validation(1, [])
    result = validation.bind(lambda x: Validation(x * 2, [])).bind(lambda x: Validation(x / 2, []))
    assert result == Validation(1, [])

    # test 4
    validation = Validation(1, [1])

# Generated at 2022-06-21 19:54:02.255613
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    def folder(value):
        return Right(value)

    assert Validation.success(42).bind(folder) == Right(42)
    assert Validation.fail([1, 2, 3]).bind(folder) == Right(None)

    def folder(value):
        return Left(value)

    assert Validation.success(42).bind(folder) == Left(42)
    assert Validation.fail([1, 2, 3]).bind(folder) == Left(None)

    def folder(value):
        return Try(value)

    assert Validation.success(42).bind(folder) == Try(42)
    assert Validation.fail([1, 2, 3]).bind(folder) == Try(None)

# Generated at 2022-06-21 19:54:06.370654
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation.success() == Validation(None, [])
    assert Validation.success('value') == Validation('value', [])


# Generated at 2022-06-21 19:54:09.961719
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success().is_success()
    assert Validation.success(5).value == 5
    assert Validation.fail().is_fail()
    assert Validation.fail([1, 'error']).errors == [1, 'error']


# Generated at 2022-06-21 19:54:23.252301
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation(Try(2, True), []).to_maybe() == Maybe.just(2)
    assert Validation(Box(2), []).to_maybe() == Maybe.just(2)
    assert Validation(Try(None, False), []).to_maybe() == Maybe.nothing()
test_Validation_to_maybe()

# Generated at 2022-06-21 19:54:26.775591
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(20).to_lazy() == Lazy(lambda: 20)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy() == Lazy(None)


# Generated at 2022-06-21 19:54:30.498343
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-21 19:54:33.093533
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation('value').to_maybe() == Maybe.just('value')
    assert Validation.fail(['error1']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:54:36.530019
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)

# Generated at 2022-06-21 19:54:39.889680
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation(None, ['error'])



# Generated at 2022-06-21 19:54:50.439719
# Unit test for constructor of class Validation
def test_Validation(): # pragma: no cover
    """Unit test for constructor of class Validation"""
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    value = 42
    errors = [1, 2, 3]

    assert Validation(value, errors).value == value, 'value of Validation is wrong'
    assert Validation(value, errors).errors == errors, 'errors of Validation is wrong'
    assert Validation(None, errors).value is None, 'value of Validation is wrong if None'
    assert Validation(value, []).errors == [], 'errors of Validation is wrong if empty list'


# Generated at 2022-06-21 19:55:00.088324
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.validation import fail
    from pymonet.validation import success

    result = success().to_box()
    assert isinstance(result, Box) and result.get_value(None) is None

    result = success(1).to_box()
    assert isinstance(result, Box) and result.get_value(None) == 1

    result = fail().to_box()
    assert isinstance(result, Box) and result.get_value(None) is None

    result = fail([1, 2]).to_box()
    assert isinstance(result, Box) and result.get_value(None) is None


# Generated at 2022-06-21 19:55:04.851748
# Unit test for method map of class Validation
def test_Validation_map():
    expected_success = Validation(4, [])
    expected_fail = Validation(None, [2, 3])

    assert Validation(2, []).map(lambda x: x + 2) == expected_success
    assert Validation.success(2).map(lambda x: x + 2) == expected_success
    assert Validation.fail([2, 3]).map(lambda x: x + 2) == expected_fail



# Generated at 2022-06-21 19:55:15.472503
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Either

    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail('error') == Validation(None, ['error'])

    assert Validation.success(1).is_success()
    assert not Validation.success(1).is_fail()
    assert not Validation.success(1).to_either().is_right()
    assert Validation.success(1).to_either().is_left()
    assert not Validation.success(1).to_try().is_success()
    assert Validation.success(1).to_try().is_failure()

    assert Validation.fail('error').is_fail()
    assert not Validation.fail('error').is_success()
    assert not Validation.fail('error').to_either().is_left()

# Generated at 2022-06-21 19:55:37.194881
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    monad = Validation.success(2)
    assert monad.is_success() == True

    monad = Validation.success("text")
    assert monad.is_success() == True

    monad = Validation.fail(["error_1", "error_2"])
    assert monad.is_success() == False



# Generated at 2022-06-21 19:55:41.814689
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    v = Validation(1, [1, 2, 3])
    assert str(v) == 'Validation.fail[1, [1, 2, 3]]'
    v = Validation(1)
    assert str(v) == 'Validation.success[1]'


# Generated at 2022-06-21 19:55:43.414254
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('a').is_success() == True
    assert Validation.fail(['a']).is_success() == False



# Generated at 2022-06-21 19:55:46.336318
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    def test(result):
        assert result.is_success() == True
        assert result.fold(
            lambda error: None,
            lambda value: value
        ) == value

    value = 5
    errors = ['error']

    result = Validation(value, []).to_try()
    test(result)

    result = Validation(value, errors).to_try()
    test(result)


# Generated at 2022-06-21 19:55:50.515611
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.fail([]).map(lambda x: x + 1) == Validation(None, [])


# Generated at 2022-06-21 19:55:54.278449
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    val = Validation.success('123')
    assert val.to_maybe() == Maybe.just('123')
    val = Validation.fail('123')
    assert val.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:55:58.802212
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation

    validation1 = Validation.success(10).bind(lambda x: Validation.fail([1, 2, 3]))
    validation2 = Validation.success(10).bind(lambda x: Validation.success(20))

    assert validation1 == Validation(None, [1, 2, 3])
    assert validation2 == Validation(20, [])


# Generated at 2022-06-21 19:56:03.075162
# Unit test for constructor of class Validation
def test_Validation():
    v = Validation(1, [])
    assert v == Validation(1, [])
    assert isinstance(v, Validation)



# Generated at 2022-06-21 19:56:07.781181
# Unit test for method map of class Validation
def test_Validation_map():
    f = lambda x: x * 2
    assert Validation.success(2).map(f) == Validation.success(4)
    assert Validation.fail([1]).map(f) == Validation.fail([1])


# Generated at 2022-06-21 19:56:12.028384
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    # given
    validation = Validation.success(value='success')

    # when
    result = validation.bind(lambda value: Validation.fail(errors=['fail']))

    assert result == Validation.fail(errors=['fail'])


# Generated at 2022-06-21 19:56:29.037491
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # given
    validation = Validation(None, ["error"])

    # when
    result = validation.is_fail()

    # then
    assert result is True


# Generated at 2022-06-21 19:56:33.715405
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.monad_try import Try

    assert Validation.fail().is_fail() == True
    assert Validation.success(7).is_fail() == False

    assert Try.success(3).is_fail() == False
    assert Try.fail(ValueError("foo")).is_fail() == True


# Generated at 2022-06-21 19:56:39.481655
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.validation import Validation

    validation_success = Validation.success(10)
    validation_fail = Validation.fail(['error'])
    either_success = validation_success.to_either()
    either_fail = validation_fail.to_either()

    assert either_success == Right(10)
    assert either_fail == Left(['error'])
    assert isinstance(either_success, Functor)
    assert isinstance(either_fail, Functor)
    assert isinstance(either_success, Monad)
    assert isinstance(either_fail, Monad)


# Generated at 2022-06-21 19:56:44.968488
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.fail(1).to_box() == Box(None)
    assert Validation.fail(1).to_box().is_nothing() == True

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1).to_box().is_nothing() == False



# Generated at 2022-06-21 19:56:54.955546
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda v: v + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda v: v + 1).map(lambda v: v + 1) == Validation.success(3)
    assert Validation.fail([1]).map(lambda v: v + 1) == Validation.fail([1])
    assert Validation.fail([1]).map(lambda v: v + 1).map(lambda v: v + 1) == Validation.fail([1])
    assert Validation.fail([1, 2]).map(lambda v: v + 1) == Validation.fail([1, 2])
    assert Validation.fail([1, 2]).map(lambda v: v + 1).map(lambda v: v + 1) == Validation.fail([1, 2])

#

# Generated at 2022-06-21 19:57:02.096989
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Either
    from pymonet.monad_try import Try
    from pymonet.monad_try import NoneException
    from pymonet.monad_try import OSError

    assert Validation.fail([1, 2]).map(lambda x: x + 1) == Validation(None, [1, 2])
    assert Validation.fail([1, 2]).map(lambda x: None) == Validation(None, [1, 2])
    assert Validation.success(5).map(lambda x: x + 1) == Validation(6, [])
    assert Validation.success(5).map(lambda x: None) == Validation(None, [])

    assert Validation.fail([1, 2]).map(lambda x: None).to_maybe() == Either.left(NoneException())
   

# Generated at 2022-06-21 19:57:09.829411
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    >>> assert Validation.fail([1, 2]).ap(lambda x: Validation.success()) == Validation.fail([1, 2])
    >>> assert Validation.fail([1, 2]).ap(lambda x: Validation.fail([3, 4])) == Validation.fail([1, 2, 3, 4])
    >>> assert Validation.success(1).ap(lambda x: Validation.fail([3, 4])) == Validation.fail([3, 4])
    >>> assert Validation.success(1).ap(lambda x: Validation.success(x * 2)) == Validation.success(2)
    """
    pass


# Generated at 2022-06-21 19:57:15.682188
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test that to_try() transforms Validation to Try.
    """
    assert Validation.success(1).to_try() == Try(1, True)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, False)


# Generated at 2022-06-21 19:57:22.718519
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.functors import functor_of

    functor = functor_of(Validation.fail([1, 2])).ap(Validation.fail([10, 20, 30]))
    assert isinstance(functor, Validation)
    assert functor == Validation(None, [1, 2, 10, 20, 30])

    functor = functor_of(Validation.fail([1, 2])).ap(Validation.success(10))
    assert isinstance(functor, Validation)
    assert functor == Validation(None, [1, 2])

    functor = functor_of(Validation.success(10)).ap(Validation.fail([1, 2]))
    assert isinstance(functor, Validation)
    assert functor == Validation(10, [1, 2])

    functor