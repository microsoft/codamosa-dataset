

# Generated at 2022-06-21 19:47:24.970079
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success()
    assert validation.is_success() is True


# Generated at 2022-06-21 19:47:31.472940
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.success(42)
    assert validation.to_try() == Try.success(42)
    assert validation.to_try().is_success()

    validation = Validation.fail(['error 1', 'error 2'])
    assert validation.to_try() == Try.fail(['error 1', 'error 2'])
    assert not validation.to_try().is_success()



# Generated at 2022-06-21 19:47:36.713605
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test Validation.ap method.

    :return: empty list when all tests was succeed
    """
    success = Validation.success(1)
    fail = Validation.fail([1])
    plus_one = lambda x: Validation.success(x + 1)
    bad_plus_one = lambda x: fail
    plus_two = lambda x: Validation.success(x + 2)
    plus_three = lambda x: Validation.success(x + 3)
    assert(success.ap(plus_one) == Validation.success(2))
    assert(success.ap(bad_plus_one) == (fail | Validation.success(1)))
    assert(fail.ap(plus_one) == fail)

# Generated at 2022-06-21 19:47:46.861399
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(0).to_either() == Right(0)
    assert Validation.success("a").to_either() == Right("a")
    assert Validation.fail("a").to_either() == Left("a")

    assert Validation.success(0).to_either() == Right(0)
    assert Validation.success("a").to_either() == Right("a")
    assert Validation.fail("a").to_either() == Left("a")

    assert Validation(0, "a").to_either() == Right(0)
    assert Validation("a", "b").to_either() == Right("a")
    assert Validation("a", ["b"]).to_either() == Left(["b"])

# Generated at 2022-06-21 19:47:50.474295
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('Hello, world!').is_fail() is False
    assert Validation.fail(['some error']).is_fail() is True


# Generated at 2022-06-21 19:47:55.530816
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])


# Generated at 2022-06-21 19:48:05.864442
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try

    validation = Validation.success([42])
    assert validation == validation.ap(lambda m: Try(m, is_success=type(m) == list))
    assert Validation.success([42, None]) == validation.ap(lambda m: Try(m + [None], is_success=type(m) == list))
    assert validation == validation.ap(lambda m: Try(None, is_success=type(m) == list))
    assert Validation.success([42, None]) == validation.ap(lambda m: Try(m + [None], is_success=type(m) == dict))
    assert validation == validation.ap(lambda m: Try(None, is_success=type(m) == dict))

# Generated at 2022-06-21 19:48:07.404132
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    v = Validation.success(1)
    assert v.to_maybe() == Maybe.just(1)


# Generated at 2022-06-21 19:48:12.053136
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Method that tests to_lazy method of class Validation. It tests if function embedded to Lazy monad
    returns Validation value.

    :returns: None
    :rtype: None
    """
    from pymonet.lazy import Lazy
    from nose.tools import assert_equal
    from random import randint

    x = randint(1, 100)
    lazy_validation = Validation.success(x).to_lazy()

    assert_equal(Lazy(lambda: x), lazy_validation)


# Generated at 2022-06-21 19:48:17.393622
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # fail Validation without errors
    assert(Validation.fail().is_fail())

    # fail Validation with errors
    assert(Validation.fail(['wrong']).is_fail())

    # success Validation
    assert(not Validation.success('value').is_fail())



# Generated at 2022-06-21 19:48:23.800033
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(100) == Validation.success(100)
    assert Validation.fail([1]) != Validation.fail([1, 2])
    assert Validation.success(100) != Validation.success(10)
    assert Validation.fail([1]) != Validation.success([1])


# Generated at 2022-06-21 19:48:28.813755
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Maybe.just(1) == Validation.success(1).to_maybe()
    assert Maybe.nothing() == Validation.fail().to_maybe()


# Generated at 2022-06-21 19:48:36.631326
# Unit test for constructor of class Validation
def test_Validation():
    validation_success = Validation.success([1, 2, 3])
    validation_fail = Validation.fail(['error'])
    assert validation_success.value == [1, 2, 3]
    assert validation_success.errors == []
    assert validation_success.is_success() is True
    assert validation_success.is_fail() is False
    assert validation_fail.value is None
    assert validation_fail.errors == ['error']
    assert validation_fail.is_success() is False
    assert validation_fail.is_fail() is True



# Generated at 2022-06-21 19:48:39.184924
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    success = Validation.success(1)
    assert Validation.fail().is_fail() is True
    assert success.is_fail() is False


# Generated at 2022-06-21 19:48:46.440268
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success([1]).ap(lambda x: Validation.success(x + [1])) == Validation.success([1, 1])
    assert Validation.success([1]).ap(lambda x: Validation.fail([2])) == Validation.success([1])
    assert Validation.fail([2]).ap(lambda x: Validation.success(x + [1])) == Validation.fail([2])
    assert Validation.fail([2]).ap(lambda x: Validation.fail([1])) == Validation.fail([2, 1])

# Unit tests for Validation class

# Generated at 2022-06-21 19:48:52.831443
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.success(42)
    assert validation.to_try() == Try(42)

    validation = Validation.fail([])
    assert validation.to_try() != Try(None)

    validation = Validation.fail(['error'])
    assert validation.to_try() == (Try(None) and Try(None, is_success=False))

# Generated at 2022-06-21 19:48:58.047047
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([2]).to_either() == Left([2])


# Generated at 2022-06-21 19:49:04.831701
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1, 2]) == Validation.fail([1, 2])
    assert not Validation.success(1) == Validation.success(2)
    assert not Validation.fail([1]) == Validation.fail([2])
    assert not Validation.fail([]) == Validation.success()
    assert not Validation.fail([1]) == Validation.success()

    assert Validation.fail([]) == Validation.fail([])
    assert not Validation.success(1) == Validation.fail([])


# Generated at 2022-06-21 19:49:11.375411
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1,2,3])) == 'Validation.fail[None, [1, 2, 3]]'



# Generated at 2022-06-21 19:49:23.933488
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.list import List
    from pymonet.maybe import Maybe

    # bind with fold function that returns Maybe
    assert Validation.fail(["error"]).bind(lambda value: Maybe.just(value)) == Validation.fail(["error"])
    assert Validation.success(10).bind(lambda value: Maybe.just(value)) == Validation.success(10)

    # bind with fold function that returns Validation
    assert Validation.fail(["error"]).bind(lambda value: Validation.fail(["error2"])) == Validation.fail(["error2"])
    assert Validation.success(10).bind(lambda value: Validation.fail(["error2"])) == Validation.fail(["error2"])

# Generated at 2022-06-21 19:49:35.124197
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success()
    assert str(success) == 'Validation.success[None]'

    success_with_value = Validation.success(123)
    assert str(success_with_value) == 'Validation.success[123]'

    fail = Validation.fail()
    assert str(fail) == 'Validation.fail[None, []]'

    fail_with_value = Validation.fail([1, 2, 3])
    assert str(fail_with_value) == 'Validation.fail[None, [1, 2, 3]]'

# Generated at 2022-06-21 19:49:38.898645
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Validation('test', []).to_box() == Box('test')
    assert Validation(None, ['test error']).to_box() == Box(None)



# Generated at 2022-06-21 19:49:42.572967
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation1 = Validation.success([1, 2, 3])
    validation2 = Validation.success([4, 5, 6])
    validation3 = Validation.success([7, 8, 9])

    def concat(xs, ys):
        return Validation.success(xs + ys)

    assert validation1.ap(concat(validation2, validation3)).to_either() == \
           Validation(None, [1, 2, 3]).to_either()

if __name__ == '__main__':
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 19:49:46.894884
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(Just(1)) == Validation.success(Just(1))
    assert Validation.fail(Just(2)) == Validation.fail(Just(2))



# Generated at 2022-06-21 19:49:56.498131
# Unit test for method ap of class Validation
def test_Validation_ap():
    import unittest

    # pymonet.monad_try.Try

    class TestValidation(unittest.TestCase):
        def test_ap(self):
            def is_valid(x):
                if not isinstance(x, (int, float)):
                    return Validation.fail('It must be a number')
                elif x < 0:
                    return Validation.fail('It must be greater than 0')
                elif x >= 10:
                    return Validation.fail('It must be less than 10')
                else:
                    return Validation.success()

            self.assertEqual(
                Validation.success(10).ap(is_valid),
                Validation.fail(['It must be less than 10'])
            )


# Generated at 2022-06-21 19:50:00.829288
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation(42, []).to_try() == Try(42, True)
    assert Validation(42, [27]).to_try() == Try(42, False)

# Generated at 2022-06-21 19:50:03.346568
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    success = Validation.success()
    assert success.is_fail() == False

    fail = Validation.fail()
    assert fail.is_fail() == True


# Generated at 2022-06-21 19:50:08.524114
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.fail(['error']).map(lambda v: v + 1) == Validation(None, ['error'])
    assert Validation.success(1).map(lambda v: v + 1) == Validation(2, [])


# Generated at 2022-06-21 19:50:15.580070
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """Unit test for method Validation.to_box"""

    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(None, []).to_box() == Box(None)
    assert Validation(None, [1, 2]).to_box() == Box(None)
    assert Validation(1, ['a', 'b']).to_box() == Box(1)


# Generated at 2022-06-21 19:50:19.051668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(value=1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 1


# Generated at 2022-06-21 19:50:33.372602
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation(123, []).to_either() == Right(123)
    assert Validation(None, [1, 2, 3]).to_either() == Left([1, 2, 3])
    assert Validation(123, [1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-21 19:50:38.978005
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail(1)) == 'Validation.fail[None, [1]]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'



# Generated at 2022-06-21 19:50:44.170083
# Unit test for method bind of class Validation
def test_Validation_bind(): # pragma: no cover
    def folder(x):
        if x >= 0:
            return Validation.success(x + 1)
        return Validation.fail(['error'])
    assert Validation.success(5).bind(folder) == Validation.success(6)
    assert Validation.success(5).bind(folder).value == 6
    assert Validation.success(-1).bind(folder) == Validation.fail(['error'])
    assert Validation.success(-1).bind(folder).errors == ['error']



# Generated at 2022-06-21 19:50:47.089718
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(42).to_try() == Try(42)
    assert Validation.fail().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:50:54.526595
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation.
    """
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    dbl_2 = lambda value: value * 2
    dbl_3 = lambda value: value * 3

    validation_success_1 = Validation.success(1)
    validation_success_2 = Validation.success(2)
    validation_failure_3 = Validation.fail([3])
    empty_list = List.empty()

    assert validation_success_1.ap(
        validation_success_2.map(lambda _: dbl_2)) == Validation.success(2)

# Generated at 2022-06-21 19:50:59.357509
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda a: a + 2) == Validation(3, [])
    assert Validation.fail(errors=['Error 1']).map(lambda a: a + 2) == Validation(None, ['Error 1'])
    assert Validation.fail(errors=['Error 1']).map(lambda a: a + 2).value is None


# Generated at 2022-06-21 19:51:06.423154
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation.success(42).to_box() == Box(42)
    assert Validation.fail([]).to_box() == Box(None)

    try:
        assert Validation.fail([1, 2]).to_box() == Box(None)
    except TypeError:
        assert True


# Generated at 2022-06-21 19:51:12.241053
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Unit test for method bind of class Validation."""
    assert Validation.success().bind(lambda x: Validation.success(x)) == Validation.success()
    assert Validation.success('test').bind(lambda x: Validation.success(x)) == Validation.success('test')
    assert Validation.success('test').bind(lambda x: Validation.fail([])) == Validation.fail([])


# Generated at 2022-06-21 19:51:18.155452
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # GIVEN
    validation_inputs = [
        Validation.fail(['first', 'second']),
        Validation.fail(['third']),
        Validation.fail()
    ]

    # WHEN
    results = list(map(lambda validation_input: validation_input.is_fail(), validation_inputs))

    # THEN
    assert results == [True, True, True]


# Generated at 2022-06-21 19:51:23.522102
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])
    assert Validation.fail('error').map(lambda x: x + 1) == Validation.fail('error')


# Generated at 2022-06-21 19:51:44.885666
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Validation.success(1).to_lazy().map(lambda x: x + 1)



# Generated at 2022-06-21 19:51:49.251873
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test Validation for is_success method
    """
    # Given
    validation = Validation.fail([42])

    # When
    result = validation.is_success()

    # Then
    assert not result


# Generated at 2022-06-21 19:51:53.391976
# Unit test for method __str__ of class Validation
def test_Validation___str__():

    success = Validation.success(2)
    assert str(success) == 'Validation.success[2]'

    fail = Validation.fail([1, 2])
    assert str(fail) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-21 19:52:02.131708
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.

    :returns: True when tests pass
    :rtype: Boolean
    """
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.fail([])
    assert Validation.fail(['error']) != Validation.success()
    assert Validation.success('value') != Validation.fail([])
    assert Validation.success('value') == Validation.success('value')
    return True


# Generated at 2022-06-21 19:52:05.527610
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_success()
    assert not Validation.success('a').is_success()
    assert Validation.fail().is_fail()
    assert Validation.fail([1]).is_fail()


# Generated at 2022-06-21 19:52:11.699021
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1, 2, 3]) != Validation.success(1)
    assert Validation.fail([1, 2, 3]) != Validation.fail([1, 2, 4])
    assert Validation.fail([1, 2, 3]) != Validation.fail([1, 3, 3])


# Generated at 2022-06-21 19:52:20.671787
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    valid_monad = Validation.success()
    assert valid_monad.is_success() is True

    valid_monad = Validation.success(10)
    assert valid_monad.is_success() is True

    valid_monad = Validation.fail()
    assert valid_monad.is_success() is False

    valid_monad = Validation.fail([1])
    assert valid_monad.is_success() is False

    valid_monad = Validation.fail(['error'])
    assert valid_monad.is_success() is False


# Generated at 2022-06-21 19:52:29.860741
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.functor import Do

    user = {'name': 'John', 'age': 30}
    val_user = validation_of_user(user)

    result = Do(val_user)\
             .bind(name_validation)\
             .bind(age_validation)\
             .done()

    assert result.value == 'John'
    assert result.errors == []

    expected = 'Validation.success[John]'
    assert str(result) == expected

    result = Do(val_user)\
             .bind(name_validation)\
             .bind(age_fail_validation)\
             .done()

    assert result.value == 'John'
    assert result.errors == ['Invalid age']

    expected = 'Validation.fail[John, [\'Invalid age\']]'

# Generated at 2022-06-21 19:52:34.293844
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test to_lazy method of class Validation"""
    from pymonet.lazy import Lazy

    lazy = Validation.success(5).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.value() == 5


# Generated at 2022-06-21 19:52:45.418203
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():

    # test for failure
    def run_test_fail(errors):

        # run test
        x = Validation(None, errors)
        from pymonet.maybe import Maybe

        # assert Maybe is empty
        assert x.to_maybe() == Maybe.nothing()

    # test for success
    def run_test_success(value):

        # run test
        x = Validation(value)
        from pymonet.maybe import Maybe

        # assert Maybe contains value
        assert x.to_maybe() == Maybe.just(value)

    # run tests
    run_test_success(None)
    run_test_success('abc')
    run_test_success(True)
    run_test_success([1, 2, 3])
    run_test_fail(None)
    run_test_fail('abc')
    run

# Generated at 2022-06-21 19:53:27.080167
# Unit test for method bind of class Validation
def test_Validation_bind():
    validation = Validation.success('Test')
    assert True == validation.bind(lambda x: Validation.success(x)).is_success()

    validation = Validation.fail(['Error'])
    assert True == validation.bind(lambda x: Validation.success(x)).is_fail()

# Generated at 2022-06-21 19:53:34.095788
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Right, Left

    def add_one(a):
        return a + 1

    assert Validation.success(1) == Right(1)
    assert Validation.success(1) == Validation.success(1).map(add_one) == Validation(2, [])
    assert Validation.fail([]) == Left([])
    assert Validation.fail([]) == Validation.fail([]).map(add_one) == Validation(None, [])


# Generated at 2022-06-21 19:53:42.682499
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation.
    """
    def add_1(x):
        return x + 1
    def add2(x):
        return x + 2
    # bind do not support partial application
    def bind1(x):
        return Validation.success(x).bind(add_1)
    def bind2(x):
        return Validation.success(x).bind(add2)
    assert Validation.success(1).bind(add_1) == Validation.success(2)
    assert Validation.success(1).bind(add_1).bind(add2) == Validation.success(3)
    assert Validation.success(1).bind(add2).bind(add_1) == Validation.success(3)
    assert Validation.success(1).bind(bind1)

# Generated at 2022-06-21 19:53:50.953712
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    args = [
        {'value': None, 'errors': [], 'expected': True},
        {'value': None, 'errors': [1, 2], 'expected': False},
        {'value': 'success', 'errors': [1, 2], 'expected': False},
        {'value': 'success', 'errors': [], 'expected': True},
    ]

    for arg in args:
        actual = Validation(arg['value'], arg['errors']).is_success()
        assert actual == arg['expected']


# Generated at 2022-06-21 19:53:59.830230
# Unit test for method ap of class Validation
def test_Validation_ap():
    # GIVEN
    validation = Validation.success(1)
    # WHEN
    v_0 = validation.ap(lambda val: Validation.success())
    v_1 = validation.ap(lambda val: Validation.fail())
    v_2 = validation.ap(lambda val: Validation.fail([2]))
    v_3 = validation.ap(lambda val: Validation.fail([3, 'a']))
    v_4 = validation.ap(lambda val: Validation.fail([4, 'b', 1]))
    # THEN
    assert_that(v_0.value, equal_to(1))
    assert_that(v_0.errors, equal_to([]))
    assert_that(v_1.value, equal_to(None))

# Generated at 2022-06-21 19:54:03.111511
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()

    assert not Validation.fail([1]).is_success()


# Generated at 2022-06-21 19:54:04.824989
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])


# Generated at 2022-06-21 19:54:07.631076
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success('value').to_box() == Box('value')
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-21 19:54:09.141538
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]'


# Generated at 2022-06-21 19:54:10.567199
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success('foo').map(lambda x: x * 2) == Validation('foofoo', [])
    assert Validation.fail('foo').map(lambda x: x * 2) == Validation(None, ['foo'])


# Generated at 2022-06-21 19:55:32.188981
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail(['Error 1']).to_box() == Box(None)


# Generated at 2022-06-21 19:55:36.994893
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test map for Validation.
    """
    assert Validation(4, []) == Validation(4, []).map(lambda x: x + 1)
    assert Validation(5, []) == Validation(4, []).map(lambda x: x * 2).map(lambda x: x + 1)



# Generated at 2022-06-21 19:55:39.257951
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    success = Validation.success()
    assert Box(success) == success.to_box()

# Generated at 2022-06-21 19:55:46.622321
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation. It checks if Validation returns success with stored value
    and concated errors when ap is called with success Validation.
    """
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    def mapper(arg):
        return Validation.success(10)

    def fn(arg):
        return Validation.success(5)

    def folder(arg):
        return Validation.fail(['Error'])

    # Success Validation
    validation = Validation.success(5)
    assert validation.ap(fn) == Validation.success(5)
    assert validation.ap(fn) == validation.bind(mapper).ap(fn)
    assert validation.ap(fn) == validation.map(fn)

    # Fail validation
    validation

# Generated at 2022-06-21 19:55:55.497171
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    success_validation_a = Validation.success(1)
    success_validation_b = Validation.success(1)
    assert success_validation_a == success_validation_b

    fail_validation_a = Validation.fail()
    fail_validation_b = Validation.fail()
    assert fail_validation_a == fail_validation_b

    fail_validation_a = Validation.fail(['error 1'])
    fail_validation_b = Validation.fail(['error 1'])
    assert fail_validation_a == fail_validation_b

    assert success_validation_a != fail_validation_a



# Generated at 2022-06-21 19:56:02.480589
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(None).is_success() is True
    assert Validation.success(True).is_success() is True
    assert Validation.success(False).is_success() is True
    assert Validation.success(1).is_success() is True
    assert Validation.success(1.1).is_success() is True
    assert Validation.success('str').is_success() is True
    assert Validation.success([]).is_success() is True
    assert Validation.success(()).is_success() is True
    assert Validation.success({}).is_success() is True
    assert Validation.success(set()).is_success() is True

    assert Validation.fail().is_success() is False
    assert Validation.fail([1]).is_success() is False
    assert Validation.fail

# Generated at 2022-06-21 19:56:12.751222
# Unit test for method map of class Validation
def test_Validation_map():
    # Check successful validation
    assert Validation('value', []) == Validation.success('value')
    assert Validation(True, []) == Validation.success(False).map(lambda x: x)
    assert Validation(42, []) == Validation.success(41).map(lambda x: x + 1)
    assert Validation(9.999, []) == Validation.success(3.333).map(lambda x: 3 * x)

    # Check failed validation
    assert Validation(None, ['error1', 'error2']) == Validation.fail(['error1', 'error2'])
    assert Validation(None, ['error1', 'error2']) == Validation.fail(['error1']).map(lambda x: x)
    assert Validation(None, ['error1', 'error2']) == Validation

# Generated at 2022-06-21 19:56:14.505220
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)

# Generated at 2022-06-21 19:56:19.426939
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func(num):
        if num % 2 == 0:
            return Validation.success(num)
        return Validation.fail([num])

    actual = func(4).to_lazy()
    expected = Lazy(lambda: 4)

    assert actual == expected
    assert actual.get() == 4


# Generated at 2022-06-21 19:56:22.335946
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([4, 5]).to_either() == Left([4, 5])
