

# Generated at 2022-06-21 19:47:12.255097
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success(1)
    fail = Validation.fail([])

    assert str(success) == 'Validation.success[1]'
    assert str(fail) == 'Validation.fail[None, []]'


# Generated at 2022-06-21 19:47:25.487404
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    def test_eq_result(v1, v2):
        assert v1 == v2, '{} == {}'.format(v1, v2)

    def test_not_eq_result(v1, v2):
        assert v1 != v2, '{} != {}'.format(v1, v2)

    validation = Validation(value=1, errors=['error1', 'error2'])
    other = Validation(value=1, errors=['error1', 'error2'])
    test_eq_result(validation, other)

    other = Validation(value=1, errors=['error2', 'error1'])
    test_eq_result(validation, other)

    other = Validation(value=1, errors=['error1'])

# Generated at 2022-06-21 19:47:32.581828
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    result = Lazy(lambda: 3)
    assert Validation.success(3).to_lazy() == result
    assert Validation.success(3).to_lazy().to_maybe() == result.to_maybe()
    assert Validation.success(3).to_lazy().to_either() == result.to_either()
    assert Validation.success(3).to_lazy().to_try() == result.to_try()


# Generated at 2022-06-21 19:47:40.038760
# Unit test for method ap of class Validation
def test_Validation_ap():
    def fn(x):
        return Validation.success(x)

    validation_fail = Validation.fail(['1', '2', '3'])
    validation_success = Validation.success(1)

    assert validation_fail.ap(fn) == Validation.fail(['1', '2', '3'])
    assert validation_success.ap(fn) == Validation.success(1)


# Generated at 2022-06-21 19:47:43.708635
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ that returns readable representation of Validation
    """
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]'


# Generated at 2022-06-21 19:47:49.241755
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    try:
        assert Validation.success(1).to_try() == Try(1, is_success=True)
        assert Validation.fail(['Error']).to_try() == Try(None, is_success=False)

    except AssertionError:
        print('test_Validation_to_try has been failed')
        return False
    else:
        print('test_Validation_to_try has been passed')
        return True


# Generated at 2022-06-21 19:48:00.417559
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe import Just

    assert Validation.success('Test').to_maybe() == Maybe.just('Test')
    assert Validation.success().to_maybe() == Maybe.just(None)
    assert Validation.fail(['Error']).to_maybe() == Maybe.nothing()
    assert isinstance(Validation.success('Test').to_maybe(), Maybe)
    assert isinstance(Validation.success().to_maybe(), Maybe)
    assert isinstance(Validation.fail(['Error']).to_maybe(), Maybe)
    assert isinstance(Validation.success('Test').to_maybe(), Just)
    assert isinstance(Validation.success().to_maybe(), Just)



# Generated at 2022-06-21 19:48:09.832831
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.list import List

    assert Validation.fail(['a']).ap(lambda x: Validation.fail(['b'])) == Validation.fail(['a', 'b'])
    assert Validation.success(2).ap(lambda x: Validation.fail(['b'])) == Validation.fail(['b'])
    assert Validation.fail(['a']).ap(lambda x: Validation.success(2)) == Validation.fail(['a'])
    assert Validation.success(2).ap(lambda x: Validation.success(x)) == Validation.success(2)
    assert Validation.success(List('a', 'b', 'c')).ap(lambda x: Validation.success(x.fold_left(lambda x, y: x + y))) == Validation.success('abc')


# Generated at 2022-06-21 19:48:15.595099
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    validation = Validation(1, [])
    other_validation = Validation(1, [])
    different_validation = Validation(2, None)
    not_validation = Left(1)

    assert validation == other_validation
    assert validation != different_validation
    assert validation != not_validation



# Generated at 2022-06-21 19:48:19.149667
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, [1, 2, 3])) == 'Validation.fail[1, [1, 2, 3]]'


# Generated at 2022-06-21 19:48:24.491282
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(10).to_either() == Right(10)
    assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])


# Generated at 2022-06-21 19:48:26.559411
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:48:34.666767
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success, Failure

    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.success(10).to_try().unwrap() == Success(10)
    assert Validation.fail(["error 1", "error 2"]).to_try() == Try(None, is_success=False)
    assert Validation.fail(["error 1", "error 2"]).to_try().unwrap() == Failure("error 1")


# Generated at 2022-06-21 19:48:37.936908
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(42).map(lambda x: x + 1) == Validation.success(43)
    assert Validation.fail(["Failed!"]).map(lambda x: x + 1) == Validation.fail(["Failed!"])



# Generated at 2022-06-21 19:48:46.824779
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(10).bind(lambda x: Validation.success(x*2)) == Validation.success(10*2)
    assert Validation.success(10).bind(lambda x: Validation.fail([x*2])) == Validation.fail([10*2])
    assert Validation.success(10).bind(lambda x: Validation.fail([x, x*2])) == Validation.fail([10, 10*2])
    assert Validation.fail([]).bind(lambda x: Validation.success(x*2)) == Validation.fail([])
    assert Validation.fail([1]).bind(lambda x: Validation.success(x*2)) == Validation.fail([1])


# Generated at 2022-06-21 19:48:56.703861
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    val1 = Validation.success()
    val2 = Validation.success(5)
    val3 = Validation.fail()
    val4 = Validation.fail(['error1', 'error2'])
    assert val1.is_success() and val1.to_maybe() == Maybe.just(None)
    assert val2.is_success() and val2.to_maybe() == Maybe.just(5)
    assert val3.is_fail() and val3.to_either() == Either.left([])
    assert val4.is_fail() and val4.to_either() == Either.left(['error1', 'error2'])

# Unit tests for method is_success of class Validation

# Generated at 2022-06-21 19:49:00.113335
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    t = Validation.success(1)
    assert t.to_box() == Box(1)

    t = Validation.fail([0, 0])
    assert t.to_box() == Box(None)



# Generated at 2022-06-21 19:49:03.719610
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.

    :return: True in case of successful unit test
    :rtype: boolean
    """

    return Validation(1, []) == Validation(1, [])


# Generated at 2022-06-21 19:49:08.887713
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([1]) == Validation.fail([1])

    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.success(1) != Validation.success(2)

    assert Validation.success(1) != Left(1)


# Generated at 2022-06-21 19:49:17.892454
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    success_validation = Validation.success(1 + 1)
    fail_validation = Validation.fail([TypeError('Hello World!')])
    another_success_validation = Validation.success(2)
    another_fail_validation = Validation.fail([ValueError('World Hello!')])
    assert success_validation == success_validation
    assert fail_validation == fail_validation
    assert success_validation != fail_validation
    assert success_validation != another_success_validation
    assert fail_validation != another_fail_validation


# Generated at 2022-06-21 19:49:27.791164
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error1'])) == 'Validation.fail[None, [\'error1\']]'
    assert str(Validation.fail(['error1', 'error2'])) == 'Validation.fail[None, [\'error1\', \'error2\']]'


# Generated at 2022-06-21 19:49:33.737055
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_do import binding

    def test_function(value):
        return Validation.success(value * 2)

    assert binding(function=test_function, monad=Validation.success(10)) == Validation(20, [])
    assert binding(function=test_function, monad=Validation.fail([1, 2])) == Validation(None, [1, 2])


# Generated at 2022-06-21 19:49:38.741578
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    """
    Testing Validation constructor
    """

    assert Validation(1, []) == Validation.success(1)
    assert Validation(None, [1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation(None, []) == Validation.success()
    assert Validation(0, []) == Validation.success(0)

    with pytest.raises(ValueError) as value_error:
        Validation([1], [1, 2])
    assert str(value_error.value) == "value should not be a list"


# Generated at 2022-06-21 19:49:42.125666
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation(None, []).to_maybe() == Maybe.just(None)
    assert Validation(0, [0]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:48.692992
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert_that(Validation.success(True), equal_to(Validation.success(True)))
    assert_that(Validation.success(False), not_(equal_to(Validation.success(True))))
    assert_that(Validation.success(True), not_(equal_to(Validation.fail([]))))


# Generated at 2022-06-21 19:49:51.824842
# Unit test for constructor of class Validation
def test_Validation():

    # Correct variables for constructor of class Validation
    assert Validation(1, [2]).value == 1
    assert Validation(1, [2]).errors == [2]
    assert Validation(1, [2]).is_success() is False
    assert Validation(1, [2]).is_fail() is True

    # Incorrect variables for constructor of class Validation
    try:
        Validation(1, 2)
        raise Exception('Validation test failed!')
    except TypeError as e:
        pass



# Generated at 2022-06-21 19:49:57.664150
# Unit test for method to_try of class Validation
def test_Validation_to_try(): # pragma: no cover
    from pymonet.monad_try import Failure

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1]).to_try() == Try.fail(1)
    assert Validation.success(None).to_try() == Try(None)
    assert Validation.fail([None]).to_try() == Try.fail(None)
    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([Failure(1)]).to_try() == Try.fail(Failure(1))


# Generated at 2022-06-21 19:50:02.272440
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(3).to_box() == Box(3)
    assert Validation.success(4).to_box() == Box(4)

    assert Validation.fail([1, 2, 3]).to_box() == Box(None)



# Generated at 2022-06-21 19:50:08.178251
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(4).to_lazy() == Lazy(lambda: 4)
    assert Validation.success(4).to_lazy() != Lazy(lambda: 8)


# Unit tests for method to_maybe of class Validation

# Generated at 2022-06-21 19:50:11.490971
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([2]).to_box() == Box(None)

# Generated at 2022-06-21 19:50:25.561346
# Unit test for method ap of class Validation
def test_Validation_ap():
    def add(n):
        def inner_add(v):
            return Validation.success(v + n)
        return inner_add

    assert(Validation.success(1).ap(add(2)) == Validation.success(3))
    assert(Validation.fail([1]).ap(add(2)) == Validation.fail([1]))


# Generated at 2022-06-21 19:50:30.532872
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success('1').map(int) == Validation.success(1)
    assert Validation.fail(['error']).map(int) == Validation.fail(['error'])
    assert Validation.success('1').map(lambda x: x + '-1') == Validation.success('1-1')


# Generated at 2022-06-21 19:50:36.688641
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation_without_errors = Validation.success(2)
    assert validation_without_errors.to_try() == Try(2, is_success=True)
    validation_with_errors = Validation.fail(['e1', 'e2'])
    assert validation_with_errors.to_try() == Try(None, is_success=False)

Validation.success(1).to_try()

# Generated at 2022-06-21 19:50:39.296195
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(["error"]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:50:45.993804
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(1, []) == Validation(1, [])
    assert False == (Validation(1, []) == Validation(1, [1]))
    assert False == (Validation(1, [1]) == Validation(2, [1]))


# Generated at 2022-06-21 19:50:53.947132
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.list import List
    from pymonet.utils import compose

    validate = Validation('2', ['Validation error'])
    validate_mapped = validate.bind(lambda x: Validation(int(x), []))

    assert validate_mapped == Validation(2, [])

    validate2 = Validation('2', ['Validation error 1', 'Validation error 2'])
    validate_folded = validate2.bind(
        lambda x: Validation(int(x), [])
        .bind(lambda y: Validation(y + 1, [])))

    assert validate_folded == Validation(3, ['Validation error 1', 'Validation error 2'])

    result1 = Validation.success(7)
    result2 = Validation.success(9)

# Generated at 2022-06-21 19:50:55.865845
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    validation = Validation(1, [])
    assert isinstance(validation.to_lazy(), Lazy)
    assert validation.to_lazy().force() == 1


# Generated at 2022-06-21 19:50:59.885947
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success().to_lazy() == Lazy(lambda: None)
    assert Validation.success(15).to_lazy() == Lazy(lambda: 15)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:51:12.076275
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    assert Validation.success() == Validation.success()
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.success() != Validation.fail([])
    assert Validation.success(4) == Validation.success(4)
    assert Validation.fail([4, 5]) == Validation.fail([4, 5])
    assert Validation.success(4) != Validation.success(5)
    assert Validation.fail([4, 5]) != Validation.fail([4, 6])
    assert Validation.success(4) != Validation.fail([4, 5])
    assert Validation.success(4) != Right(4)
    assert Validation.fail([4, 5]) != Left([4, 5])

# Generated at 2022-06-21 19:51:19.299991
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert_that(str(Validation.success()), equal_to('Validation.success[None]'))
    assert_that(str(Validation.success(1)), equal_to('Validation.success[1]'))
    assert_that(str(Validation.fail(errors=['error'])), equal_to('Validation.fail[None, [\'error\']]'))
    assert_that(str(Validation.fail(errors=['error', 'error2'])), equal_to('Validation.fail[None, [\'error\', \'error2\']]'))


# Generated at 2022-06-21 19:51:44.593831
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Validation.fail(errors=[1, 2]) == Validation.fail(errors=[1, 2])
    assert Validation.success(value=5) == Validation.success(value=5)
    assert Validation.fail(errors=[1, 2]) != Validation.success(value=5)
    assert Validation.success(value=5) != Validation.fail(errors=[1, 2])
    assert Validation.fail(errors=[1, 2]).value == None
    assert Validation.success(value=5).value == 5
    assert Validation.fail(errors=[1, 2]).errors == [1, 2]
    assert Validation.success(value=5).errors == []
    assert Val

# Generated at 2022-06-21 19:51:56.120459
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test function to_try of class Validation.
    """
    from pymonet.monad_try import Try
    def _test_to_try(validation, exp_try):
        """
        Test to_try function.

        :param validation: validation instance to use
        :type validation: Validation[A, E]
        :param exp_try: expected result Try
        :type exp_try: Try[A]
        """
        act_try = validation.to_try()
        assert act_try == exp_try

    # Test to_try for successful Validation
    _test_to_try(Validation.success(1), Try(1))

    # Test to_try for failed Validation
    _test_to_try(Validation.fail('a'), Try(None, is_success=False))




# Generated at 2022-06-21 19:52:02.783112
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test Validation.map function.

    :returns: None
    :rtype: None
    """
    from pymonet.monad_maybe import Maybe

    assert Validation.success(2).map(lambda value: value + 2) == Validation.success(4)
    assert Validation.fail([2]).map(lambda value: value + 2) == Validation.fail([2])


# Generated at 2022-06-21 19:52:04.666273
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success('a').map(lambda x: x + 'b') == Validation.success('ab')
    assert Validation.fail(['a']).map(lambda x: x + 'b') == Validation.fail(['a'])


# Generated at 2022-06-21 19:52:08.476890
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Unit test for Validation monad to_either method.
    """
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-21 19:52:13.210080
# Unit test for method __str__ of class Validation
def test_Validation___str__():              # pragma: no cover
    assert str(Validation([1, 2, 3], [])) == 'Validation.success[[1, 2, 3]]'
    assert str(Validation([1, 2, 3], ['a', 'b'])) == 'Validation.fail[[1, 2, 3], [\'a\', \'b\']]'
    assert str(Validation(None, ['a', 'b'])) == 'Validation.fail[None, [\'a\', \'b\']]'


# Generated at 2022-06-21 19:52:24.897685
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    # Validation.success().to_maybe() == Maybe.nothing()
    actual = Validation.success().to_maybe()
    expected = Maybe.nothing()
    assert actual == expected

    # Validation.fail().to_maybe() == Maybe.nothing()
    actual = Validation.fail().to_maybe()
    expected = Maybe.nothing()
    assert actual == expected

    # Validation.success(123).to_maybe() == Maybe.just(123)
    actual = Validation.success(123).to_maybe()
    expected = Maybe.just(123)
    assert actual == expected

    # Validation.success(Try.success(123)).to_maybe() == Maybe.just(123)

# Generated at 2022-06-21 19:52:27.597952
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:52:31.555685
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Failure, Success
    assert Validation.success(10).to_try() == Success(10)
    assert Validation.fail([]).to_try() == Failure(None)
    assert Validation.fail([1, 2, 3]).to_try() == Failure(None)
    assert Validation.fail([1]).to_try() == Failure(None)


# Generated at 2022-06-21 19:52:35.934423
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(12)) == 'Validation.success[12]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-21 19:53:17.577960
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    def f(v):
        return Validation.success(10)

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.fail([]).to_either() == Left(())
    assert Validation.fail([1, 2, 3]).to_either() == Left(1)
    assert Validation.fail([1, 2, 3]).ap(f).to_either() == Left([1, 2, 3])


# Generated at 2022-06-21 19:53:20.534171
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Testing Validation.map() method
    """
    assert Validation.success(5).map(lambda val: val * 3) == Validation.success(15)
    assert Validation.fail(['error']).map(lambda val: val * 3) == Validation.fail(['error'])


# Generated at 2022-06-21 19:53:26.032400
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('success').to_maybe() == Maybe.just('success')
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:53:32.651186
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(errors=['abc'])) == 'Validation.fail[None, abc]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success('test')) == 'Validation.success[test]'



# Generated at 2022-06-21 19:53:34.441854
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() is True
    assert Validation.success(5).is_fail() is False



# Generated at 2022-06-21 19:53:36.868119
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success().to_maybe() == Maybe.nothing()
    assert Validation.success(100).to_maybe() == Maybe.just(100)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:53:38.659468
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    print(Validation.success(10))
    print(Validation.fail(['Error!']))


# Generated at 2022-06-21 19:53:41.804538
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.fail(['error']).to_try() == Failure(['error'])

# Generated at 2022-06-21 19:53:46.050755
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert (Validation.success(0).to_maybe() == Maybe.just(0))
    assert (Validation.fail('error').to_maybe() == Maybe.nothing())


# Generated at 2022-06-21 19:53:54.837220
# Unit test for constructor of class Validation
def test_Validation():

    # Creating success and fail Validations
    success_validation = Validation.success(1)
    fail_validation = Validation.fail([])
    assert success_validation.value == 1
    assert fail_validation.value == None
    assert success_validation is Validation(1, [])

    # Creating success and fail Validations
    success_validation = Validation.success(1)
    fail_validation = Validation.fail([])
    assert success_validation.value == 1
    assert fail_validation.value == None
    assert success_validation is Validation(1, [])


# Generated at 2022-06-21 19:55:10.137675
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.utils import test_eq

    test_eq("when no errors", Validation(2, []).map(lambda x: x * 2), Validation.success(4))
    test_eq("with errors", Validation(2, ["some error"]).map(lambda x: x * 2), Validation.fail(["some error"]))


# Generated at 2022-06-21 19:55:14.503441
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation_success = Validation.success(10)
    validation_fail = Validation.fail('error')

    assert validation_success.to_box() == Box(10)
    assert validation_fail.to_box() == Box(None)



# Generated at 2022-06-21 19:55:20.483218
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.try_ import Try

    assert Validation.success("value") == Validation.success("value").to_try()
    assert Try("value") == Validation.success("value").to_try()
    assert Validation.fail(["error"]) == Validation.fail(["error"]).to_try()
    assert Try("value", is_success=False) == Validation.fail(["error"]).to_try()



# Generated at 2022-06-21 19:55:25.130470
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    nil_validation = Validation.fail()
    assert nil_validation.to_try() == Try(None, is_success=False)

    value_validation = Validation.success(1)
    assert value_validation.to_try() == Try(1, is_success=True)


# Generated at 2022-06-21 19:55:29.170044
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:55:31.532425
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.fail([1, 2, 3])
    assert validation.is_fail()


# Generated at 2022-06-21 19:55:35.036001
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation('value', [])
    assert validation.is_fail() is False

    validation = Validation.fail(['error'])
    assert validation.is_fail()

    validation = Validation.fail([])
    assert validation.is_fail() is False


# Generated at 2022-06-21 19:55:37.218268
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.success(1).to_either() == Right(1)


# Generated at 2022-06-21 19:55:43.532031
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    def add_one(x):
        if x == 5:
            return Validation.fail('X equal 5 for add_one')
        return Validation.success(x + 1)
    ## Success
    assert Validation.success(1) \
        .bind(add_one) \
        .value == 2
    ## Fail
    assert Validation.success(5) \
        .bind(add_one) \
        .errors == ['X equal 5 for add_one']


# Generated at 2022-06-21 19:55:53.875632
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success().__eq__(Validation.success())
    assert not Validation.success().__eq__(Validation.fail())
    assert not Validation.success(2).__eq__(Validation.success())
    assert not Validation.success(2).__eq__(Validation.fail())
    assert Validation.fail([1, 2]).__eq__(Validation.fail([1, 2]))
    assert not Validation.fail([1, 2]).__eq__(Validation.success())
    assert not Validation.fail([1, 2]).__eq__(Validation.fail())
    assert not Validation.fail().__eq__(Validation.fail([1, 2]))
