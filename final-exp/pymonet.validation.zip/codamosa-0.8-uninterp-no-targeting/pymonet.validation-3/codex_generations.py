

# Generated at 2022-06-21 19:47:14.626675
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.maybe import Maybe

    def fn(a):
        return Maybe.just(a)

    val = Validation.success(5)
    res = val.ap(fn)

    assert val is not res
    assert val.value == res.value
    assert val.errors == res.errors



# Generated at 2022-06-21 19:47:26.002915
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation_1 = Validation.success("a")
    validation_2 = Validation.success("b")

    def mapper_1(a):
        return Validation.fail(["1", "2"])

    validation_3 = validation_1.ap(mapper_1)
    assert Validation('a', ['1', '2']) == validation_3

    def mapper_2(a):
        return Validation.success("b")

    validation_4 = validation_1.ap(mapper_2)
    assert Validation('a', []) == validation_4

    def mapper_3(a):
        return Validation.fail(["4", "5"])

    validation_5 = validation_1.ap(mapper_3).ap(mapper_2)

# Generated at 2022-06-21 19:47:33.218089
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet import Box, Either, Maybe, Validation, Lazy
    from pymonet.monad_try import Try

    # If errors list is empty then validation is successful
    value = 0
    errors = []
    validation = Validation(value, errors)
    lazy = validation.to_lazy()
    assert lazy.get() == value

    # If errors list is not empty then validation is failed
    value = None
    errors = [1]
    validation = Validation(value, errors)
    lazy = validation.to_lazy()
    assert lazy.get() is None



# Generated at 2022-06-21 19:47:40.728264
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation(1, [])

    assert isinstance(val.to_lazy(), Lazy)
    assert val.to_lazy().thunk() == 1

    val = Validation(None, [])

    assert isinstance(val.to_lazy(), Lazy)
    assert val.to_lazy().thunk() is None


# Generated at 2022-06-21 19:47:44.673681
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    m_errors = [TypeError(100)]
    s_errors = []
    assert Validation.fail(m_errors).is_fail()
    assert Validation.success().is_fail() == False
    assert Validation.success(2).is_fail() == False
    assert Validation.fail(s_errors).is_fail()


# Generated at 2022-06-21 19:47:50.181345
# Unit test for constructor of class Validation
def test_Validation():
    """Unit test constructor Validation."""
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success('str') == Validation('str', [])

    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation.fail([1, 2]) == Validation(None, [1, 2])


# Generated at 2022-06-21 19:47:51.977189
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # GIVEN
    validation = Validation(1, [])
    other = Validation(1, [])

    # THEN
    assert validation == other


# Generated at 2022-06-21 19:47:58.358773
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([]) == Validation.fail([])

    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) != Validation.success(1)
    assert Validation.fail([1, 2]) != Validation.fail([1])



# Generated at 2022-06-21 19:48:04.949538
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.monad_try import Try

    assert Validation.fail([1]).is_fail() is True
    assert Validation.fail().is_fail() is False

    assert Validation.success(1).is_fail() is False
    assert Validation.success(Try.success(1)).is_fail() is False
    assert Validation.success(Try.fail(1)).is_fail() is True


# Generated at 2022-06-21 19:48:07.085127
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    result = Validation(10, []).to_lazy()
    assert isinstance(result, Monad)
    assert result.value() == 10


# Generated at 2022-06-21 19:48:15.701962
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Unit test for method to_either of class Validation"""

    assert Validation.success(1).to_either() == Either.right(1)
    assert Validation.fail.to_either() == Either.left(None)
    assert Validation.fail([1, 2]).to_either() == Either.left([1, 2])
    assert Validation.success(1).to_either() != Either.left(None)
    assert Validation.fail.to_either() != Either.right(None)


# Generated at 2022-06-21 19:48:20.782789
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_validation import Validation

    assert Validation.succes(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:48:25.259100
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from pymonet.validation import Validation

    validation = Validation.success(10)
    assert 'Validation.success[10]' == str(validation)
    validation = Validation.fail(['error1', 'error2'])
    assert 'Validation.fail[None, [\'error1\', \'error2\']]' == str(validation)


# Generated at 2022-06-21 19:48:28.975207
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test that Validation successfully transform to Lazy monad.
    """
    lz = Validation.success('one').to_lazy()

    assert lz.force() == 'one'



# Generated at 2022-06-21 19:48:32.918475
# Unit test for method map of class Validation
def test_Validation_map():
    assert (Validation.success(2).map(lambda x: x + 2) == Validation.success(4))
    assert (Validation.fail(['ERROR']).map(lambda x: x + 2) ==
            Validation.fail(['ERROR']))


# Generated at 2022-06-21 19:48:36.631580
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    result = Validation.success('value')
    assert str(result) == 'Validation.success[value]'

    result = Validation.fail('errors')
    assert str(result) == 'Validation.fail[None, errors]'


# Generated at 2022-06-21 19:48:43.885759
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test ap method of class Validation.
    Function `ap` takes as a parameter function returning another Validation.
    Function is called with Validation value and returns new Validation with previous value
    and concated new and old errors.
    """
    def func(value):
        """
        Simple function that returns validation that contains errors and given value.
        """
        return Validation(value, ['error'])

    validation = Validation('value', ['previous error'])
    assert validation.ap(func) == Validation('value', ['previous error', 'error'])

# Generated at 2022-06-21 19:48:51.865426
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    # Success test
    validation = Validation.success(1)
    assert(validation.to_box() == Box(1))

    # Fail test
    validation = Validation.fail()
    assert(validation.to_box() == Box(None))



# Generated at 2022-06-21 19:48:57.295577
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-21 19:49:00.198786
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    val = Validation.success()

    assert val.is_fail() == False

    val = Validation.fail(['Error'])

    assert val.is_fail() == True


# Generated at 2022-06-21 19:49:10.331579
# Unit test for method ap of class Validation
def test_Validation_ap():
    from unittest import TestCase
    from pymonet.monad_maybe import Maybe

    def test_function(value):
        return Validation(Maybe.just(value), [])

    success_value_validation = Validation.success('success')
    success_ap_validation = success_value_validation.ap(test_function)
    assert success_ap_validation.is_success()

    fail_value_validation = Validation.fail([('error', 'Error message')])
    fail_ap_validation = fail_value_validation.ap(test_function)
    assert fail_ap_validation.is_fail()


# Generated at 2022-06-21 19:49:16.587470
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Tests for Validation.is_success method.
    """
    # When Validation has not errors, then is_success returns True
    res = Validation.success(10).is_success()
    assert res is True

    # When Validation has errors, then is_success returns False
    res = Validation.fail(['error']).is_success()
    assert res is False


# Generated at 2022-06-21 19:49:22.410954
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    errors = ['Some error']

    test_success = Validation.success()
    test_fail = Validation.fail(errors)

    assert test_success.to_maybe() == Maybe.just(test_success.value)
    assert test_fail.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:29.571556
# Unit test for method ap of class Validation
def test_Validation_ap():
    def error_fn(value):
        return Validation.fail(['Error from error_fn'])
    assert Validation.success(['Success']).ap(error_fn) == Validation.fail(['Error from error_fn'])

    def error_fn(value):
        return Validation.success(['Success from error_fn'])
    assert Validation.success(['Success 1']).ap(error_fn) == Validation.fail(['Error from error_fn'])

    def error_fn(value):
        return Validation.success(['Success from error_fn'])
    assert Validation.success(['Success 1']).ap(error_fn) == Validation.fail(['Error from error_fn'])


# Generated at 2022-06-21 19:49:35.530794
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.monad_try import Try

    assert isinstance(Validation.success(Try.success(1)).__str__(), str)
    assert str(Validation.success(Try.success(1))) == "Validation.success[Try.success[1]]"

    assert isinstance(Validation.fail([1,2,3]).__str__(), str)
    assert str(Validation.fail([1,2,3])) == "Validation.fail[None, [1, 2, 3]]"


# Generated at 2022-06-21 19:49:39.671787
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation.success(10)
    assert validation1 == Validation.success(10)

    validation2 = Validation.fail([1, 2, 3])
    assert validation2 == Validation.fail([1, 2, 3])

    assert validation1 != validation2


# Generated at 2022-06-21 19:49:41.652362
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.fail([1, 2]).is_success()



# Generated at 2022-06-21 19:49:49.435842
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.utils import identity

    assert Validation.success(10).to_maybe() == Maybe.just(10)
    assert Validation.success(None).to_maybe() == Maybe.just(None)

    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:51.141481
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    validation = Validation.success(10)
    assert validation.to_maybe() == Maybe.just(10)

    validation = Validation.fail([])
    assert validation.to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:49:54.700332
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(
        lambda v: Validation.success(v + 1)) == Validation.success(2)
    assert Validation.success(1).ap(
        lambda v: Validation.fail([v + 1])) == Validation.fail(2)

# Generated at 2022-06-21 19:50:04.345443
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    f = Validation.fail()
    assert f.to_either() == Left([])

    s = Validation.success(10)
    assert s.to_either() == Right(10)


# Generated at 2022-06-21 19:50:08.012244
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.fail('abc').to_either() == Left('abc')
    assert Validation.fail(list()).to_either() == Left(list())
    assert Validation.fail(['a', 'b', 'c']).to_either() == Left(['a', 'b', 'c'])



# Generated at 2022-06-21 19:50:09.413526
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(1, [1]).to_box() == Box(1)


# Generated at 2022-06-21 19:50:13.931690
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert Validation.success(2).is_success()
    assert Validation.fail([]).is_success() == False
    assert Validation.fail([1, 2]).is_success() == False


# Generated at 2022-06-21 19:50:23.978662
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.monad import container

    add = lambda x: x + 1
    inc = lambda x: x + 1
    dec = lambda x: x - 1

    # Validation.success[1]
    val = Validation(1, [])
    monad = container(val)
    assert monad.map(add) == Validation(2, [])
    assert monad.map(inc) == Validation(2, [])
    assert monad.map(dec) == Validation(0, [])

    # Validation.success[2]
    val = Validation(2, [])
    monad = container(val)
    assert monad.map(add) == Validation(3, [])
    assert monad.map(inc) == Validation(3, [])

# Generated at 2022-06-21 19:50:31.817308
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for Validation.ap function.
    """
    assert Validation.success().ap(lambda x: Validation.fail(['error'])) == Validation.success()
    assert Validation.fail(['error']).ap(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])

    assert Validation.success(10).ap(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])



# Generated at 2022-06-21 19:50:40.772091
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    from pymonet.either import Left

    # Given
    val1 = Validation.success(1)
    val2 = Validation.fail([Left(5), Left(10)])
    val3 = Validation.success(10)
    val4 = Validation.fail([Left(20), Left(40)])

    # When
    val12 = val1.ap(lambda x: val2)
    val34 = val3.ap(lambda x: val4)

    # Then
    assert val12 == Validation(1, [Left(5), Left(10)])
    assert val34 == Validation(10, [Left(20), Left(40)])


# Generated at 2022-06-21 19:50:42.809956
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.fail([1, 2, 3])
    assert validation.is_success() == False, "Validation with errors should return False in is_success method"


# Generated at 2022-06-21 19:50:44.994762
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    v = Validation.fail([1, 2, 3])
    assert v.is_fail()


# Generated at 2022-06-21 19:50:53.434797
# Unit test for method ap of class Validation
def test_Validation_ap():
    val = Validation.success(10)
    val2 = Validation.fail([StandardError('my error')])
    val3 = Validation.fail([StandardError('my error3')])

    def f(x): return Validation.success(x + 5)
    def f2(x): return Validation.fail([StandardError('my error2')])

    assert f(10) == Validation.success(15)
    assert f(10).ap(f) == Validation.success(20)
    assert f2(10).ap(f) == Validation.fail([StandardError('my error2')])
    assert f(10).ap(f2) == Validation.fail([StandardError('my error2')])

# Generated at 2022-06-21 19:51:09.243265
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.lazy

    # When
    lazy = Validation.success(1).to_lazy()

    # Then
    assert isinstance(lazy, pymonet.lazy.Lazy)
    assert lazy.get_value() == 1

# Generated at 2022-06-21 19:51:12.432248
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1).value == 1
    assert Validation.success(1).error == []
    assert Validation.fail(['a']).value == None
    assert Validation.fail(['a']).errors == ['a']


# Generated at 2022-06-21 19:51:19.710535
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # Successful validation with value and no errors
    v1 = Validation.success()
    assert str(v1) == 'Validation.success[None]'
    v1 = Validation.success(1)
    assert str(v1) == 'Validation.success[1]'
    # Failed validation with no value and errors list
    v1 = Validation.fail()
    assert str(v1) == 'Validation.fail[None, []]'
    v1 = Validation.fail([1])
    assert str(v1) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:51:30.423836
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.maybe import Maybe
    from pymonet.either import Right

    def folder(x):
        if x > 0:
            return Maybe.just(x)
        return Maybe.nothing()

    assert Validation.success(1).bind(folder) == Maybe.just(1)
    assert Validation.success(-1).bind(folder) == Maybe.nothing()

    assert Validation.success(1).bind(lambda x: Validation.success(x)) == Validation.success(1)
    assert Validation.success(1).bind(lambda x: Validation.fail([1, 2])) == Validation.fail([1, 2])
    assert Validation.fail([1, 2]).bind(lambda x: Validation.success(1)) == Validation.fail([1, 2])

    assert Validation.success(1).bind

# Generated at 2022-06-21 19:51:34.738505
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Method Validation.is_fail should return True when Validation has errors.
    """
    validation = Validation.fail(['error #1', 'error #2'])
    assert validation.is_fail() is True



# Generated at 2022-06-21 19:51:40.512689
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    a = Validation(1, [])
    b = Validation(2, [])
    assert a != b

    a = Validation(1, [])
    b = Validation(1, ['error1'])
    assert a != b

    a = Validation(1, ['error1'])
    b = Validation(1, ['error1'])
    assert a == b


# Generated at 2022-06-21 19:51:42.838765
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:51:50.911697
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.maybe import Just

    assert Validation.fail().to_try() == Try()
    assert Validation.fail(['error']).to_try() == Try()
    assert Validation.success(None).to_try() == Try(None)
    assert Validation.success(Just(12)).to_try() == Try(Just(12))


# Generated at 2022-06-21 19:51:57.086775
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation.success(10)
    assert Validation.success(10) != Validation.success(20)
    assert Validation.fail([10]) == Validation.fail([10])
    assert Validation.fail([10]) != Validation.success(10)
    assert Validation.success('t') == Validation.success('t')
    assert Validation.fail(['x']) != Validation.fail([])


# Generated at 2022-06-21 19:52:01.493772
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('value')) == 'Validation.success[value]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-21 19:52:19.218153
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    v1 = Validation.success(1)
    assert v1.is_success()
    assert not v1.is_fail()
    assert v1.value == 1
    assert v1.errors == []

    v2 = Validation.success('a')
    assert v2.is_success()
    assert not v2.is_fail()
    assert v2.value == 'a'
    assert v2.errors == []

    v3 = Validation.success([])
    assert v3.is_success()
    assert not v3.is_fail()
    assert v3.value == []
    assert v3.errors == []

    v4 = Validation.fail([1, 2, 3])
    assert not v4.is_success()
    assert v4.is_fail()
   

# Generated at 2022-06-21 19:52:22.806177
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(11)) == 'Validation.success[11]'
    assert str(Validation.fail(['fail1', 'fail2'])) == 'Validation.fail[None, [\'fail1\', \'fail2\']]'


# Generated at 2022-06-21 19:52:28.208518
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1]) != Validation.success([1])
    assert Validation.success([1]) == Validation.success([1])



# Generated at 2022-06-21 19:52:32.961088
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(2).ap(
        Validation.fail([1, 2])) == Validation(2, [1, 2])
    assert Validation.fail([1, 2]).ap(
        Validation.success(2)) == Validation(None, [1, 2])
    assert Validation.fail([1, 2]).ap(
        Validation.fail([3, 4])) == Validation(None, [1, 2, 3, 4])
    assert Validation.success(2).ap(
        Validation.success(2)) == Validation(2, [])



# Generated at 2022-06-21 19:52:39.903925
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'


# Generated at 2022-06-21 19:52:43.723293
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation.success(5)
    assert validation.to_box() == Box(5)
    assert validation.to_box().map(lambda x: x + 5) == Box(10)


# Generated at 2022-06-21 19:52:50.487218
# Unit test for constructor of class Validation
def test_Validation():
    """Unit tests for constructor of Validation."""
    from pymonet.list import List

    success = Validation.success(1)
    fail = Validation.fail([1, 2])

    assert(success.value == 1)
    assert(success.errors == [])
    assert(fail.value == None)
    assert(fail.errors == [1, 2])
    assert(str(success) == 'Validation.success[1]')
    assert(str(fail) == 'Validation.fail[None, [1, 2]]')
    # Equality check
    assert(success == Validation.success(1))
    assert(fail == Validation.fail([1, 2]))
    assert(success != Validation.fail([1, 2]))
    assert(fail != Validation.success(1))

# Generated at 2022-06-21 19:52:53.870729
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = random.random()
    assert Validation(value, [1]).to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-21 19:53:01.012760
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    import unittest
    from pymonet.maybe import Maybe

    class TestValidationToMaybe(unittest.TestCase):
        def test_Validation_to_maybe(self):
            self.assertEqual(Validation.success('A').to_maybe(), Maybe('A'))
            self.assertEqual(Validation.fail([]).to_maybe(), Maybe.nothing())

    unittest.main(argv=[''], verbosity=2, exit=False)


# Generated at 2022-06-21 19:53:03.886726
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success(123).is_success() == True
    assert Validation.success([1, 2, 3]).is_success() == True


# Generated at 2022-06-21 19:53:31.481662
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success("test").is_success()

    assert not Validation.fail("test").is_success()


# Generated at 2022-06-21 19:53:36.640830
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: x * 2) == Validation.success(4)

    assert Validation.fail(['error1']).map(lambda x: x * 2) == Validation.fail(['error1'])


# Generated at 2022-06-21 19:53:47.741959
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Asserts that bind method of Validation return new Validation according to function passed to bind"""
    from pymonet.validation import Validation
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    double = lambda v: Validation.success(v * 2)
    none = lambda v: Maybe.nothing()
    fail = lambda v: Validation.fail(["error"])
    fail2 = lambda v: Left("error")

    assert Validation.success(10).bind(double) == Validation.success(20)
    assert Validation.fail(["error"]).bind(double) == Validation.fail(["error"])

    assert Validation.success(10).bind(fail) == Validation.fail(["error"])
    assert Validation.success(10).bind(fail2) == Validation

# Generated at 2022-06-21 19:53:51.593274
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(10, []).to_box().contains(10)
    assert not Validation(10, [1]).to_box().contains(10)


# Generated at 2022-06-21 19:53:54.530991
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Validation.success(1).value
    assert Validation.fail([1]).to_box() == Validation.fail([1]).value


# Generated at 2022-06-21 19:53:56.200489
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-21 19:54:06.181356
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().call() == 1
    assert Try(1, is_success=True) == Lazy(lambda: 1).to_try()

    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy().call() is None
    assert Try(None, is_success=False) == Lazy(lambda: None).to_try()


# Generated at 2022-06-21 19:54:11.727271
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    import pytest

    validation = Validation.success(5)
    assert validation.to_try() == Try(5, is_success=True)

    validation = Validation.fail([5])
    assert validation.to_try() == Try(5, is_success=False)

    with pytest.raises(Exception):
        validation = Validation.fail([5, 5])
        validation.to_try()

# Generated at 2022-06-21 19:54:23.815669
# Unit test for method bind of class Validation
def test_Validation_bind():
    """ Test for method bind of class Validation """
    from pymonet.monad_try import Try


# Generated at 2022-06-21 19:54:25.863941
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(1).to_box() == Box(None)



# Generated at 2022-06-21 19:55:01.808501
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    validation = Validation.success(1)
    assert validation.to_box() == Box(1)

    validation = Validation.fail([1, 2, 3])
    assert validation.to_box() == Box(None)


# Generated at 2022-06-21 19:55:08.222559
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_identity import Identity

    def __fn(x):
        if x % 2 == 0:
            return Validation.success(x/2)
        return Validation.fail(['Expected even number'])

    assert Validation.success(4).ap(Validation.success(__fn)).value == 2
    assert Validation.success(4).ap(Validation.fail(['Error'])).errors == ['Error']
    assert Validation.fail(['Expected even number']).ap(Validation.success(__fn)).errors == ['Expected even number']
    assert Identity(Validation.fail(['Error 1'])).ap(Identity(__fn)).value.errors == ['Error 1']



# Generated at 2022-06-21 19:55:18.017247
# Unit test for method map of class Validation
def test_Validation_map():
    def add_2(value):
        return value + 2

    def add_2_with_validation(value):
        return add_2(value)

    assert Validation.success(1).map(add_2_with_validation) == Validation.success(3)
    assert Validation.success(1).map(lambda value: value + 2) == Validation.success(3)

    assert Validation.fail(['test error']).map(add_2_with_validation) == Validation.fail(['test error'])
    assert Validation.fail(['test error']).map(lambda value: value + 2) == Validation.fail(['test error'])

    assert Validation.success(1).map(add_2) == Validation.success(3)

# Generated at 2022-06-21 19:55:26.636495
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation

    :returns: Nothing
    :rtype: None
    """
    from pymonet.validation import Validation

    def f(x):
        return Validation.success(x)

    def g(x):
        return Validation.fail(['g'])

    def h(x):
        return Validation.fail(['h'])

    def i(x):
        return Validation.success(x)

    assert Validation.success('hello').ap(f) == Validation.success('hello')
    assert Validation.success('hello').ap(g) == Validation.fail(['g'])
    assert Validation.fail(['h']).ap(f) == Validation.fail(['h'])

# Generated at 2022-06-21 19:55:29.532117
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    result = Validation(1, []).is_success()
    assert_that(result, is_(True))
    result = Validation(1, ['error']).is_success()
    assert_that(result, is_(False))


# Generated at 2022-06-21 19:55:36.872597
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    assert Validation.success().to_box().is_empty()
    assert Validation.success(1).to_box().is_present()
    assert Validation.fail().to_box().is_empty()
    assert Validation.fail(1).to_box().is_present()
    assert Validation.success([1, 2]).to_box().is_present()
    assert Validation.fail([1, 2]).to_box().is_present()


# Generated at 2022-06-21 19:55:43.950977
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from unittest import TestCase

    class Test(TestCase):
        def test_Validation___str__1(self):
            res = Validation.success(2)
            assert str(res) == 'Validation.success[2]'

        def test_Validation___str__2(self):
            res = Validation.fail(['error 1', 'error 2'])
            assert str(res) == 'Validation.fail[None, [\'error 1\', \'error 2\']]'

    Test().test_Validation___str__1()
    Test().test_Validation___str__2()

# Generated at 2022-06-21 19:55:45.829906
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 2) == Validation.success(3)
    assert Validation.fail(['testing']).map(lambda x: x + 2) == Validation.fail(['testing'])


# Generated at 2022-06-21 19:55:50.141526
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    result = Validation.success(1).to_try()
    assert result.get() == 1

    result = Validation.fail(['test']).to_try()
    assert result.is_failure()

# Generated at 2022-06-21 19:55:53.264444
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    validation = Validation.success('Ala')
    assert validation.to_box() == Box('Ala')


# Generated at 2022-06-21 19:56:33.145622
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure
    from pymonet.monad_try import is_success
    from pymonet.monad_try import is_failure
    from pymonet.validation import Validation

    assert is_success(Validation.success(1).to_try())
    assert is_failure(Validation.fail([]).to_try())
    assert is_success(Success(1).to_try())
    assert is_failure(Failure(ValueError()).to_try())
    assert is_success(Try(1).to_try())
    assert is_failure(Try(1, is_success=False).to_try())


# Generated at 2022-06-21 19:56:35.913683
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation.success(42).to_maybe() == Maybe.just(42)

    assert Validation.fail(['error 1']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:56:44.012816
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Successful Validation should return 'Validation.success[value]' string.
    Failed Validation should return 'Validation.fail[value, errors]' string.
    """
    value = 42
    errors = ['error1', 'error2']
    assert str(Validation.success(value)) == 'Validation.success[{}]'.format(value)
    assert str(Validation.fail(errors)) == 'Validation.fail[{}, {}]'.format(None, errors)


# Generated at 2022-06-21 19:56:50.556401
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    import unittest

    class ValidationToEitherTest(unittest.TestCase):
        def test_to_either(self):
            self.assertEqual(Validation.success(2).to_either(), Right(2))
            self.assertEqual(Validation.fail([1]).to_either(), Left([1]))
    return unittest.main()


# Generated at 2022-06-21 19:56:53.514484
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('foo').to_box() == Box('foo')
    assert Validation.fail(['error 1', 'error 2']).to_box() == Box(None)


# Generated at 2022-06-21 19:56:56.843865
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test for Validation.is_success method
    """
    assert Validation.success(1).is_success()
    assert not Validation.fail(1).is_success()



# Generated at 2022-06-21 19:57:02.799245
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.try_ import Try

    class A:
        pass

    assert Validation.success(2) == Validation(2, [])
    assert Validation.success(None) == Validation(None, [])
    assert Validation.fail(['error1']) == Validation(None, ['error1'])

    # When value parameter is not an instance of type Validation
    try:
        Validation(2, 'error1')
        assert False
    except AssertionError:
        pass

    # When errors parameter is not an instance of type List
    try:
        Validation(2, 'error1')
        assert False
    except AssertionError:
        pass

    # When value parameter is not an instance of type A

# Generated at 2022-06-21 19:57:09.456901
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(None).is_success()
    assert Validation.success(False).is_success()
    assert Validation.success(True).is_success()
    assert Validation.success(1).is_success()
    assert Validation.success('string').is_success()
    assert Validation.success(1.1).is_success()
    assert Validation.success([1, 2, 3]).is_success()
    assert Validation.success({'K1': 1}).is_success()


# Generated at 2022-06-21 19:57:17.769447
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    f = lambda a: Try(a + 1)
    validation = Validation.success(1).bind(f)
    assert validation == Validation.success(2)

    f = lambda a: Try(a + 1).map_err(lambda: 'error')
    validation = Validation.success(1).bind(f)
    assert validation == Validation.success(2)
