

# Generated at 2022-06-21 19:47:25.070275
# Unit test for constructor of class Validation
def test_Validation():
    """
    Unit test for Validation constructor.
    """
    validation = Validation(1, ['error'])  # 1.a
    assert validation == Validation.fail(['error'])  # 1.b
    assert validation.value == 1  # 1.c
    assert validation.errors == ['error']  # 1.d


# Generated at 2022-06-21 19:47:28.884452
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    testing_class = Validation

    assert testing_class.success(1).to_try() == Try(1, is_success=True)
    assert testing_class.fail(['error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:47:32.702028
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test that to_either method is working fine.
    """
    failure = Validation.fail(['failure'])
    assert failure.to_either() == Left(['failure'])

    success = Validation.success('success')
    assert success.to_either() == Right('success')


# Generated at 2022-06-21 19:47:38.487607
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success([1, 2, 3])) == 'Validation.success[[1, 2, 3]]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-21 19:47:43.505134
# Unit test for method bind of class Validation
def test_Validation_bind():

    def folder(v):
        if v == 'hi':
            return Validation.fail(['value is not hi'])
        return Validation.success(v + v)

    assert Validation('hi', []).bind(folder).value == 'hihi'
    assert Validation('hi', []).bind(folder).errors == ['value is not hi']
    assert Validation('2', []).bind(folder).value == '22'
    assert Validation('2', []).bind(folder).errors == []


# Generated at 2022-06-21 19:47:48.715538
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    # Testing Validation.success
    v = Validation.success(5)
    assert v.to_either() == Right(5)

    v = Validation.success()
    assert v.to_either() == Right(None)

    # Testing Validation.fail
    v = Validation.fail([1, 2, 3])
    assert v.to_either() == Left([1, 2, 3])



# Generated at 2022-06-21 19:47:54.326353
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []) == Validation.success(1)
    assert Box(1) == Validation.success(1).to_box()
    assert Box(None) == Validation.fail([]).to_box()



# Generated at 2022-06-21 19:47:59.982786
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Unit test for method to_maybe of class Validation"""
    assert Validation.success(1).to_maybe() == Maybe(1)
    assert Validation.success().to_maybe() == Maybe(None)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe(None)

# Generated at 2022-06-21 19:48:03.399758
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.monad_try import Try

    try_ = Try.success('ok')
    validation = Validation.success().ap(try_)

    assert validation.is_fail() is False
    assert validation.is_success()

    try_ = Try.fail()
    validation = Validation.success().ap(try_)

    assert validation.is_fail()
    assert validation.is_success() is False


# Generated at 2022-06-21 19:48:09.179537
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # Given
    model_errors = {
        'field': 'is required'
    }
    valid_model = Validation(value=None, errors=[])
    valid_model.errors = []

    invalid_model = Validation(value=None, errors=[])
    invalid_model.errors = model_errors

    # When & Then
    assert valid_model.to_either() == Right(None)
    assert invalid_model.to_either() == Left(model_errors)

# Generated at 2022-06-21 19:48:14.473472
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(None, []).success() == Validation.success(None)
    assert Validation(None, [1]).fail() == Validation.fail([1])



# Generated at 2022-06-21 19:48:18.327239
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success().to_box() == Box(None)
    assert Validation.fail().to_box() == Box(None)


# Generated at 2022-06-21 19:48:26.901631
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(5).value == 5 and Validation.success(5).errors == []
    assert Validation.fail(5).value is None and Validation.fail(5).errors == 5
    assert Validation.success(5).is_success() is True
    assert Validation.success(5).is_fail() is False
    assert Validation.fail(5).is_success() is False
    assert Validation.fail(5).is_fail() is True
    assert Validation.success(5).to_either() == Right(5)
    assert Validation.fail(5).to_

# Generated at 2022-06-21 19:48:31.686080
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.fail(['1', '2']).to_try() == Try.failure(['1', '2'])
    assert Validation.success('ABC').to_try() == Try.success('ABC')


# Generated at 2022-06-21 19:48:34.812482
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False
    assert Validation.fail([]).is_fail() == True
    assert Validation.fail([1, 2]).is_fail() == True


# Generated at 2022-06-21 19:48:35.771415
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.succes

# Generated at 2022-06-21 19:48:42.156166
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test for bind method of Validation monad.
    """
    from pymonet.functor import Functor
    from pymonet.monad import Monad

    assert Validation.success(3).bind(lambda c: Validation.fail([c + 4])).errors == [7]
    assert Validation.success(3).bind(lambda c: Validation.success(c + 1)).value == 4

    assert Functor.of(Validation).is_functor_law_hold(Validation.success(3), lambda c: c + 1, lambda c: c + 1)
    assert Monad.of(Validation).is_monad_law_hold(Validation.success(3))
    assert Monad.of(Validation).is_monad_law_hold(Validation.fail([3]))

    assert Validation

# Generated at 2022-06-21 19:48:45.947204
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    # Check failure to failure
    assert Validation.fail([1,2,3]).to_try() == Failure([1,2,3])
    # Check success to success
    assert Validation.success(100).to_try() == Success(100)

# Generated at 2022-06-21 19:48:51.676140
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('Value').is_success()
    assert not Validation.fail(['Error']).is_success()
    assert not Validation.success(1).is_success()
    # Ensure that value is not None
    assert not Validation.success(None).is_success()


# Generated at 2022-06-21 19:48:54.406724
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() is False
    assert Validation.success().is_fail() is False
    assert Validation.fail([1]).is_fail() is True


# Generated at 2022-06-21 19:49:04.992697
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    # Arrange
    valid = Validation.success(2)
    valid2 = Validation.success(4)
    valid3 = Validation.success(6)
    valid4 = Validation.fail(['valid4'])

    # Act
    result = valid.ap(lambda a: valid2.ap(lambda b: valid3.map(lambda c: a * b * c)))
    result2 = valid.ap(lambda a: valid2.ap(lambda b: valid3.ap(lambda c: valid4.map(lambda d: a * b * c * d))))

    # Assert
    assert result == Validation.success(48)
    assert result2 == Validation.fail(['valid4'])


# Generated at 2022-06-21 19:49:07.306321
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    test = Validation.success('value')
    assert test.is_success()

    test = Validation.fail()
    assert not test.is_success()


# Generated at 2022-06-21 19:49:09.693359
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:15.208307
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Lazy(lambda: 5) == Validation.success(5).to_lazy()
    assert Lazy(lambda: Try(5, is_success=True)) == Validation.fail(['error']).to_lazy()


# Generated at 2022-06-21 19:49:18.195287
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # given
    validation = Validation.success(1)

    # when
    result = validation.is_fail()

    # then
    assert result is False


# Generated at 2022-06-21 19:49:21.284601
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box().unwrap() == 1
    assert Validation.success('x').to_box().unwrap() == 'x'


# Generated at 2022-06-21 19:49:25.890889
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(1, ['error']).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:49:29.331377
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-21 19:49:33.225123
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def as_string(v):
        return str(v)

    assert Validation.success(12).to_lazy().map(as_string).value() == '12'
    assert Validation.fail([1, 2, 3]).to_lazy().value() is None



# Generated at 2022-06-21 19:49:41.376923
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.fail([])
    assert Validation.success(True) == Validation.success(True)
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.success() != Validation.fail([1])
    assert Validation.success("False") != Validation.fail([1])
    assert Validation.success("False") != Validation.success("True")
    assert Validation.fail([1]) != Validation.fail([2])


# Generated at 2022-06-21 19:49:49.037911
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail()
    assert not Validation.success(['error']).is_fail()


# Generated at 2022-06-21 19:49:53.496069
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    value = 10
    validation = Validation.success(value)
    assert validation.to_maybe() == Maybe(value)

    validation = Validation.fail()
    assert validation.to_maybe() == Maybe(None)



# Generated at 2022-06-21 19:50:03.915365
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from pymonet.functor import map_

    success_validation_string = str(Validation.success('value'))
    assert success_validation_string == 'Validation.success[value]'

    fail_validation_string = str(Validation.fail([{'error': 'message'}]))
    assert fail_validation_string == 'Validation.fail[None, [{\'error\': \'message\'}]]'
    fail_validation_string = str(Validation.fail([]))
    assert fail_validation_string == 'Validation.fail[None, []]'



# Generated at 2022-06-21 19:50:16.345100
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation.success(10)
    def add(x):
        return x + 1
    def add_err(x):
        return Validation.fail(['err_' + str(x)])

    assert isinstance(validation.ap(add), Validation)
    assert validation.ap(add).value == 11
    assert validation.ap(add).errors == []

    assert isinstance(validation.ap(add_err), Validation)
    assert validation.ap(add_err).value == 10
    assert validation.ap(add_err).errors == ['err_10']

    assert validation.ap(None) == None
    assert validation.ap('') == ''
    assert validation.ap(0) == 0
    assert validation.ap(add)("") == "10"

# Generated at 2022-06-21 19:50:18.291160
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(42).to_maybe() == Maybe.just(42)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:50:22.768308
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    val1 = Validation.success(15)
    val2 = Validation.fail(['error1', 'error2'])

    assert val1.to_maybe() == Maybe.just(15)
    assert val2.errors == ['error1', 'error2']


# Generated at 2022-06-21 19:50:30.581242
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(2).bind(lambda x: Validation.success(x * 2)) == Validation.success(4)
    assert Validation.fail().bind(lambda x: Validation.success(x * 2)) == Validation.fail()
    assert Validation.success(2).bind(lambda x: Validation.fail()) == Validation.fail()
    assert Validation.fail().bind(lambda x: Validation.fail()) == Validation.fail()

# Unit tests for method map of class Validation

# Generated at 2022-06-21 19:50:40.772967
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.tuple import Tuple

    def add_one(value):
        return Validation.success(value + 1)

    def add_two(value):
        return Validation.success(value + 2)

    assert Validation.success(1).bind(add_one) == Validation.success(2)
    assert Validation.success(1).bind(add_one).bind(add_two) == Validation.success(3)

    def to_either(value):
        return Right(value)

    def to_maybe(value):
        return Maybe.just(value)

    def to_tuple(value):
        return Tuple(value, 0)

    assert Validation.success(1).bind(to_either)

# Generated at 2022-06-21 19:50:43.738890
# Unit test for method map of class Validation
def test_Validation_map():
    """
    >>> test_Validation_map()
    Validation.success[1]
    Validation.fail[[1, 2], [3]]
    """
    print(Validation.success(1).map(lambda x: x + 2))
    print(Validation.fail([1, 2]).map(lambda x: x + 2))


# Generated at 2022-06-21 19:50:48.888890
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]', 'Failed test_Validation___str__'
    assert str(Validation.fail(["warn1", "warn2"])) == 'Validation.fail[None, [\'warn1\', \'warn2\']]', 'Failed test_Validation___str__'


# Generated at 2022-06-21 19:51:08.736431
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # Equality with the same Validation
    success_value = Validation(10, [])
    assert success_value == success_value
    assert success_value.__eq__(success_value)

    # Equality with the same successful Validation
    success_value = Validation(10, [])
    success_value_same = Validation(10, [])
    assert success_value == success_value_same
    assert success_value.__eq__(success_value_same)

    # Equality with the same failed Validation
    failed_value = Validation(10, [10, 20])
    failed_value_same = Validation(10, [10, 20])

# Generated at 2022-06-21 19:51:10.866059
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False
    assert Validation.fail().is_fail() == True


# Generated at 2022-06-21 19:51:13.997485
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert repr(Validation.success(1)) == 'Validation.success[1]'
    assert repr(Validation.fail(['Failed'])) == 'Validation.fail[None, [\'Failed\']]'


# Generated at 2022-06-21 19:51:21.890109
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """Unit test for method __eq__ of class Validation."""
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    # When values are equal and errors list are empty
    assert Validation.success(3) == Validation.success(3)
    assert Validation.fail(None) == Validation.fail(None)

    # When values are equal but errors not
    assert Validation.success(3) == Validation.success(3)
    assert Validation.fail(None) == Validation.fail(None)

    # When values are not equal and errors list are empty
    assert Validation.success(3) != Validation.success(4)
    assert Validation.fail(None) != Validation.fail(None)

    # When values are not equal but errors not
    assert Validation

# Generated at 2022-06-21 19:51:27.439696
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('hello').is_fail() == False
    assert Validation.success(None).is_fail() == False
    assert Validation.fail(['error 1', 'error 2']).is_fail() == True
    # Should raise an error, because boolean value is not instance of Validation class
    try:
        Validation.fail(True)
    except:
        pass



# Generated at 2022-06-21 19:51:30.606691
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation(1, [])
    assert validation.to_lazy() == Lazy(lambda: 1)
    assert validation.to_try() == Try(1, True)
    
    validation = Validation(None, [])
    assert validation.to_lazy() == Lazy(lambda: None)
    assert validation.to_try() == Try(None, False)


# Generated at 2022-06-21 19:51:37.839750
# Unit test for method bind of class Validation
def test_Validation_bind():
    from operator import add
    from pymonet.list import List
    from pymonet.list import cons

    # Test bind of success Validation
    assert Validation.success(2).bind(lambda v: Validation.fail(cons(v, List()))) == Validation(2, [2])
    # Test bind of failed Validation
    assert Validation.fail(List()).bind(lambda v: Validation.success(v + 2)) == Validation(None, [])



# Generated at 2022-06-21 19:51:42.343375
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    try_success = Validation(1, []).to_try()
    try_fail = Validation(None, [1]).to_try()
    assert try_success.is_success()
    assert try_success.get() == 1
    assert not try_fail.is_success()
    assert try_fail.get() is None

# Generated at 2022-06-21 19:51:51.176565
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.fail().map(lambda x: x) == \
           Validation.fail()
    assert Validation.success(1).map(lambda x: x) == \
           Validation.success(1)
    assert Validation.success(1).map(lambda x: x + 1) == \
           Validation.success(2)
    assert Validation.success(2).map(lambda x: x * x) == \
           Validation.success(4)


# Generated at 2022-06-21 19:51:54.770679
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Validation has method to_box that return Box with stored value.
    """
    from pymonet.box import Box

    value = 'a'
    assert Validation.success(value).to_box() == Box(value)


# Generated at 2022-06-21 19:52:24.414289
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    success_validation = Validation(3, [])
    assert success_validation.value == 3
    assert success_validation.errors == []
    assert success_validation.is_success() == True
    assert success_validation.is_fail() == False
    assert success_validation.to_maybe() == Maybe(3)
    assert success_validation.to_either() == Right(3)
    assert success_validation.to_box() == Box(3)
    assert success_validation.to_try() == Try(3, is_success=True)
    assert success_

# Generated at 2022-06-21 19:52:32.004066
# Unit test for constructor of class Validation
def test_Validation():
    # Constructor without params
    assert Validation(None, []) == Validation.success(None)
    assert Validation(None, []) == Validation.fail()

    # Constructor with value
    assert Validation(10, []) == Validation.success(10)
    assert Validation(10, []) == Validation.fail(10)

    # Constructor with errors
    assert Validation(None, [10]) == Validation.success([10])
    assert Validation(None, [10]) == Validation.fail([10])

    # Constructor with value and errors
    assert Validation(1, [10]) == Validation.success(1, [10])
    assert Validation(1, [10]) == Validation.fail(1, [10])



# Generated at 2022-06-21 19:52:38.754095
# Unit test for method map of class Validation
def test_Validation_map():
    validation_success = Validation.success(1)
    validation_fail = Validation.fail(['error'])

    increment = lambda x: x + 1

    # test map function with success Validation
    assert validation_success.map(increment) == Validation.success(2)

    # test map function with fail Validation
    assert validation_fail.map(increment) == Validation.fail(['error'])


# Generated at 2022-06-21 19:52:45.506111
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(42) == Validation.success(42)
    assert Validation.success(42) != Validation.success(43)
    assert Validation.fail([42]) == Validation.fail([42])
    assert Validation.fail([42]) != Validation.fail([43])
    assert Validation.fail([42]) != Validation.success(42)
    assert Validation.success(42) != Validation.fail(42)



# Generated at 2022-06-21 19:52:48.860833
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('A').is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-21 19:52:53.722610
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for method is_success of class Validation.
    """
    # Success case
    success = Validation.success(None)
    assertValidationSuccess(success, True)

    # Fail case
    fail = Validation.fail(None)
    assertValidationSuccess(success, False)


# Generated at 2022-06-21 19:52:58.185831
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail(2).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:53:02.805277
# Unit test for method map of class Validation
def test_Validation_map():
    valid = Validation.success(10)
    result = valid.map(lambda x: x*2)
    assert(result == Validation(20, []))

    invalid = Validation.fail([1, 2, 3])
    result = invalid.map(lambda x: x * 2)
    assert (result == Validation(None, [1, 2, 3]))


# Generated at 2022-06-21 19:53:11.259285
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Method map of Validation should for successful Validation return new Validation with mapped value and previous
    errors. For failed Validation method should return Validation with previous errors.

    :return: None
    """
    import pymonet.monad as monad

    def test_success():
        def mapper(data):
            return data + 1

        assert monad.Validation.success(1).map(mapper) == monad.Validation(2, [])

    def test_fail():
        def mapper(data):
            return data + 1

        assert monad.Validation.fail(['error']).map(mapper) == monad.Validation(None, ['error'])

    test_success()
    test_fail()
    return


# Generated at 2022-06-21 19:53:17.780276
# Unit test for method ap of class Validation
def test_Validation_ap():
    def add1(x):
        return Validation.success(x + 1)

    def add2(x):
        return Validation.success(x + 2)

    assert Validation.success(1).ap(add1).ap(add2) == Validation.success(4)
    assert Validation.success(1).ap(add1) == Validation.success(2)

# Generated at 2022-06-21 19:53:58.176465
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('Success').to_either() == Right('Success')
    assert Validation.fail(errors=['Fail']).to_either() == Left(['Fail'])


# Generated at 2022-06-21 19:54:00.973787
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['ERROR']).is_fail()  # Fail Validation is fail
    assert not Validation.success('OK').is_fail() # Success Validation is not fail


# Generated at 2022-06-21 19:54:08.081406
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation([1, 2, 3], []).__eq__(Validation([1, 2, 3], []))
    assert not Validation([1, 2, 3], []).__eq__(Validation([], []))
    assert not Validation([], [1, 2, 3]).__eq__(Validation([], []))
    assert not Validation.fail().__eq__(Validation.success())
    assert not Validation([], []).__eq__([])


# Generated at 2022-06-21 19:54:11.652550
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    assert Validation.fail([]).to_try() == Try(None, is_success=False)
    assert Validation.success(5.5).to_try() == Try(5.5, is_success=True)


# Generated at 2022-06-21 19:54:12.939696
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success().is_fail()
    assert Validation.fail().is_fail()


# Generated at 2022-06-21 19:54:23.312019
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test to_maybe method of Validation class.
    """
    from pymonet.either import Right
    from pymonet.maybe import Just, Nothing
    from pymonet.validation import Validation

    assert Validation.success(100).to_maybe() == Just(100)
    assert Validation.fail(['some_error']).to_maybe() == Nothing()

    # Unit test of method to_maybe of class Validation when value is Monad
    assert Validation.success(Right(100)).to_maybe() == Just(Right(100))
    assert Validation.fail(['some_error']).to_maybe() == Nothing()

# Unit tests for method to_try of class Validation

# Generated at 2022-06-21 19:54:27.100038
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import try_ as Try

    assert Validation.success('Hello world').to_try() == Try('Hello world')
    assert Validation.success(None).to_try() == Try(None, is_success=True)
    assert Validation.fail(['Error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:54:32.962385
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(1, []) == Validation(1, [])
    assert Validation(None, [1,2]) == Validation(None, [1,2])
    assert Validation(1, [1,2]) != Validation(None, [1,2])
    assert Validation(1, [1,2,3]) != Validation(1, [1,2])


# Generated at 2022-06-21 19:54:36.375295
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def calculation_function():
        return (1 + 2 + 3 + 4) / 2

    lazy_value = Validation.success(calculation_function).to_lazy()
    assert lazy_value.get() == 5



# Generated at 2022-06-21 19:54:42.899097
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation(1, []).to_try() == Try(1, True)
    assert Validation(1, [2]).to_try() == Try(1, False)
    assert Validation.success(2).to_try() == Try(2, True)
    assert Validation.fail([3]).to_try() == Try(None, False)

# Generated at 2022-06-21 19:56:10.429093
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success = Validation.success()
    assert success.is_success() == True

    fail = Validation.fail(errors=[1, 2, 3])
    assert fail.is_success() == False


# Generated at 2022-06-21 19:56:15.875579
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.success(None).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail(['error']).is_success()
    assert not Validation.fail([1, 2, 3]).is_success()


# Generated at 2022-06-21 19:56:17.813172
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(2).bind(lambda x: Validation.success(x + 1)) == Validation.success(3)


# Generated at 2022-06-21 19:56:19.928565
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.fail(['error']).is_success() == False
    assert Validation.success(1).is_success() == True


# Generated at 2022-06-21 19:56:23.357690
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def succ():
        return Validation.success().to_lazy()

    assert succ() == Lazy(lambda: None)

    def fail():
        return Validation.fail().to_lazy()

    assert fail() == Lazy(lambda: None)



# Generated at 2022-06-21 19:56:27.252424
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    success_validation = Validation.success(1)
    assert not success_validation.is_fail()

    fail_validation = Validation.fail([1])
    assert fail_validation.is_fail()



# Generated at 2022-06-21 19:56:31.360362
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1).__eq__('Something') == False
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]).__eq__('Something') == False



# Generated at 2022-06-21 19:56:35.319092
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # GIVEN validation with value and list of errors
    validation = Validation('value', ['error1', 'error2'])
    # WHEN __str__ is called
    # THEN Validation is printed in correct form
    assert 'Validation.fail[value, [error1, error2]]' == str(validation)


# Generated at 2022-06-21 19:56:40.046706
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # empty error list
    validation = Validation.success(10)

    assert validation.is_success() == True

    # non empty error list
    validation = Validation.fail([1, 2, 3])

    assert validation.is_fail() == True


# Generated at 2022-06-21 19:56:46.523957
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    It tests method bind for class Validation
    """

    # prepare expected result
    expected_result = Validation.success(['d'])

    # prepare data


    # call tested method
    actual_result = Validation.success(['a', 'b', 'c']).bind(
        lambda ls: Validation.success(ls[-1]))

    # compare expected result and actual result
    assert expected_result == actual_result
