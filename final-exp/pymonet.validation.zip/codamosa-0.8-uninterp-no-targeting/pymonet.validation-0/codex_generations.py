

# Generated at 2022-06-21 19:47:22.941361
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == 1
    assert Validation.fail().to_box() is None


# Generated at 2022-06-21 19:47:29.222033
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_value = Validation.success(10).to_lazy()
    assert isinstance(lazy_value, Lazy)
    assert lazy_value.value() == 10

    lazy_value = Validation.fail(['error']).to_lazy()
    assert isinstance(lazy_value, Lazy)
    assert lazy_value.value() is None


# Generated at 2022-06-21 19:47:32.050909
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:47:36.066835
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    def foo_test():
        return 100

    def bar_test():
        raise Exception('Bar Exception')

    foo_val = Validation.success(foo_test())
    res_foo = foo_val.to_try()
    bar_val = Validation.fail(bar_test())
    res_bar = bar_val.to_try()
    assert res_foo == Try(100)
    assert type(res_foo) == Try
    assert res_bar != Try(100)
    assert type(res_bar) == Try


# Generated at 2022-06-21 19:47:45.748381
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Test equality of two succeed validations with the same values
    assert (Validation.success(1) ==
            Validation.success(1))

    # Test equality of two succeed validations with the diffrent values
    assert (Validation.success(1) !=
            Validation.success(2))

    # Test equality of two failed validations with the same errors
    assert (Validation.fail(['error 1']) ==
            Validation.fail(['error 1']))

    # Test equality of two failed validations with the diffrent errors
    assert (Validation.fail(['error 1']) !=
            Validation.fail(['error 2']))

    # Test equality of failed and succeeded validations
    assert (Validation.success(1) !=
            Validation.fail())



# Generated at 2022-06-21 19:47:50.665957
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Unit test for method to_either of class  Validation.
    """
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail((1, 2, 3)).to_either() == Left((1, 2, 3))


# Generated at 2022-06-21 19:47:54.896331
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(4).map(lambda x: x + 1) == Validation.success(5)
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])
    assert Validation.fail(['x']).map(lambda x: x + 1) == Validation.fail(['x'])
    assert Validation.fail(['x']).map(lambda x: x + 1) != Validation.fail(['y'])
    assert Validation.success(4).map(lambda x: x + 1) != Validation.fail(['x'])


# Generated at 2022-06-21 19:47:56.369016
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(True).to_box() is Box(True)


# Generated at 2022-06-21 19:48:02.909842
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy_validation = Validation.success(1).to_lazy()
    assert isinstance(lazy_validation, Lazy)
    assert lazy_validation() == 1

    lazy_validation = Validation.fail([1, 2]).to_lazy()
    assert isinstance(lazy_validation, Lazy)
    assert lazy_validation() is None


# Generated at 2022-06-21 19:48:07.601625
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    def test_func(v):
        return v

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)
    assert Validation.success(1).to_box().map(test_func) == Validation.success(1).to_box()


# Generated at 2022-06-21 19:48:14.048255
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(None, [1]).is_fail() is True
    assert Validation(None, [1,2,3,4]).is_fail() is True
    assert Validation(None, []).is_fail() is False
    assert Validation(1, []).is_fail() is False


# Generated at 2022-06-21 19:48:24.806645
# Unit test for method ap of class Validation
def test_Validation_ap():
    # case 1. Validation.fail()
    validation = Validation.fail()
    assert validation == validation.ap(lambda x: Validation.success())

    # case 2. Validation.success()
    validation = Validation.success()
    assert validation == validation.ap(lambda x: Validation.success())

    # case 3. Validation.success()
    validation = Validation.success(1)
    assert validation != validation.ap(lambda x: Validation.fail('error'))

    # case 3. Validation.fail()
    validation = Validation.fail('error')
    assert isinstance(validation.ap(lambda x: Validation.success(1)), Validation)
    assert validation != validation.ap(lambda x: Validation.success(1))


# Generated at 2022-06-21 19:48:35.901285
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    test_Validation_is_fail test method is_fail() of class Validation.
    """
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    # Test for failed validation
    validation = Validation(None, [Left(1), Left('test2')])
    assert validation.is_fail() is True

    # Test for failed validation with successful monads
    validation = Validation(Box(1), [Maybe.just(2), Try(1)])
    assert validation.is_fail() is True

    # Test for successful validation
    validation = Validation(Try('Test', is_success=True), [])
    assert validation.is_fail() is False

    # Test for successful validation with failed mon

# Generated at 2022-06-21 19:48:42.248592
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.tuple import Tuple

    assert Validation.success(True) == Validation.success(True)
    assert Validation.fail(['some error']) == Validation.fail(['some error'])
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.success(True) != Validation.success(False)
    assert Validation.fail(['some error']) != Validation.fail([])
    assert Validation.success(True) != Validation.fail(['some error'])
    assert Validation.fail([]) != Validation.fail(['some error'])
    assert Validation.success(True) != ((1,), [])

# Generated at 2022-06-21 19:48:45.358156
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    v = Validation.success()

    assert v.is_success()
    assert not v.is_fail()

    v = Validation.fail()

    assert not v.is_success()
    assert v.is_fail()


# Generated at 2022-06-21 19:48:50.212792
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert Validation.success(1).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail([1,2,3]).is_success()


# Generated at 2022-06-21 19:48:52.687481
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)


# Generated at 2022-06-21 19:48:57.482452
# Unit test for constructor of class Validation
def test_Validation():
    _success = Validation.success(1)
    assert _success.value == 1
    assert _success.errors == []
    assert _success.is_success()

    _fail = Validation.fail([4, '2'])
    assert _fail.value is None
    assert _fail.errors == [4, '2']
    assert _fail.is_fail()
test_Validation()


# Generated at 2022-06-21 19:49:04.202774
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    value = 'abc'
    validation = Validation.success(value)
    assert validation.is_success()
    assert validation.value == value

    lazy = validation.to_lazy()
    assert lazy is not None
    assert isinstance(lazy, Lazy)
    assert lazy.is_success()
    assert lazy.value() == value


# Generated at 2022-06-21 19:49:07.673538
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation(3, [])) == str(Validation.success(3))
    assert str(Validation(3, ['a', 'b'])) == str(Validation.fail(['a', 'b']))


# Generated at 2022-06-21 19:49:14.489426
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(value=10).to_either() == Right(value=10)
    assert Validation.fail(errors=['error']).to_either() == Left(value=['error'])


# Generated at 2022-06-21 19:49:19.284158
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Checks method is_success of class Validation returns True when errors list is empty.
    """
    assert Validation.success().is_success()
    assert not Validation.fail([]).is_success()
    assert not Validation.fail(['e1']).is_success()


# Generated at 2022-06-21 19:49:24.725569
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    """
    Unit test for method __str__ of class Validation.
    """
    assert str(Validation.success("test")) == "Validation.success[test]"
    assert str(Validation.fail(errors=["test error"])) == "Validation.fail[None, ['test error']]"



# Generated at 2022-06-21 19:49:31.468647
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Assert that Validation.to_either returns Right with value when Validation is successful and
    Left with errors when Validation is failed
    """
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(["ERROR"]).to_either() == Left(["ERROR"])



# Generated at 2022-06-21 19:49:42.399944
# Unit test for method bind of class Validation
def test_Validation_bind():
    def even(x):
        if x % 2 == 0:
            return Validation.success(x)
        else:
            return Validation.fail(['{} is odd'.format(x)])

    def mult_2(x):
        return x * 2

    assert Validation.success(2).bind(even).bind(lambda x: Validation.success(mult_2(x))) == Validation.success(4)
    assert Validation.success(5).bind(even).bind(lambda x: Validation.success(mult_2(x))) == Validation.fail()
    assert Validation.success(5).bind(even).bind(lambda x: Validation.fail(['{} is not multiple of 4'.format(x)])) == \
           Validation.fail()


# Generated at 2022-06-21 19:49:52.717682
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test that checks that method is_success returns True when there is no errors.

    :returns: nothing
    :raises: AssertionError
    """
    from pymonet.validation import Validation

    validation = Validation.success()
    assert validation.is_success() == True, 'Validation without errors is successful'

    validation = Validation.success(['Some value', 'Other value'])
    assert validation.is_success() == True, 'Validation without errors is successful'

    validation = Validation.fail(['Error message'])
    assert validation.is_success() == False, 'Validation with errors is not successful'


# Generated at 2022-06-21 19:49:54.652209
# Unit test for constructor of class Validation
def test_Validation():
    with pytest.raises(RuntimeError):
        Validation(None, ['Error 1'])


# Generated at 2022-06-21 19:49:58.685470
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert Validation.success(None).is_success()
    assert not Validation.fail([1]).is_success()


# Generated at 2022-06-21 19:50:01.756169
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(5).to_box() == Box(5)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-21 19:50:03.213145
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Should return Maybe with value when Validation is success"""
    v = Validation('Success', [])
    assert v.to_maybe() == Maybe.just('Success')


# Generated at 2022-06-21 19:50:13.550972
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success([]).ap(Validation.fail([1, 2])) == Validation.fail([1, 2])
    assert Validation.success([1, 2]).ap(Validation.success([])) == Validation.success([1, 2])
    assert Validation.success([1, 2]).ap(Validation.fail([3])) == Validation.fail([3])

# Generated at 2022-06-21 19:50:22.011603
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.list import List
    from pymonet.monad_try import Try

    fn = lambda x: Try(x)
    try_val = Validation.success(Try(10))
    try_val_2 = Validation.success(Try(20))

    try_val.ap(fn) == Validation.success(10)
    try_val.ap(fn) == try_val_2
    try_val_2.ap(fn) == Validation.success(20)

    fn = lambda x: Try(x, is_success=False)
    try_val = Validation.success(10)
    try_val_2 = Validation.success(20)

    try_val.ap(fn) == Validation.fail([])
    try_val.ap(fn) == try_val_2
   

# Generated at 2022-06-21 19:50:27.687333
# Unit test for method bind of class Validation
def test_Validation_bind():
    def f(x):
        """
        :param x: integer
        :returns: new Validation
        """
        return Validation.success(x * 2)
    validation = Validation.success(2)
    result = validation.bind(f)
    equal = result == Validation.success(4)
    assert equal, 'Should be True'


# Generated at 2022-06-21 19:50:36.734777
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Unit test for method to_maybe of class Validation.

    :returns: Nothing when test failed
    :rtype: Nothing | Exception
    """
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    validation = Validation(5, [])
    assert validation.to_maybe() == Maybe.just(5)

    validation = Validation(None, ['error 1'])
    assert validation.to_maybe() == Maybe.nothing()

    validation = Validation(False, ['error 1'])
    assert validation.to_maybe() == Maybe.just(False)

    return Maybe.Nothing


# Generated at 2022-06-21 19:50:40.366249
# Unit test for method map of class Validation
def test_Validation_map():
    def mapper(x):
        return x + 100

    assert Validation.success(100).map(mapper) == Validation(200, [])
    assert Validation.fail([1, 2]).map(mapper) == Validation(None, [1, 2])



# Generated at 2022-06-21 19:50:46.558743
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """It tests to_lazy method of class Validation"""
    from pymonet.lazy import Lazy

    def validation_fn():
        return Validation.success(1)

    assert Validation.success(1).to_lazy() == Lazy(validation_fn)


# Generated at 2022-06-21 19:50:49.816200
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(9).is_fail() is True
    assert Validation.fail().is_fail() is True
    assert Validation.success(1).is_fail() is False
    assert Validation.success().is_fail() is False



# Generated at 2022-06-21 19:50:53.675144
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 19:51:02.303985
# Unit test for method to_either of class Validation
def test_Validation_to_either(): # pragma: no cover
    from pymonet.maybe import Just
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.box import Box

    # a = 1
    # validation = Validation(a)
    # is_success = validation.is_success()
    # either = validation.to_either()
    # maybe = validation.to_maybe()
    # lazy = validation.to_lazy()
    # box = validation.to_box()
    # try_ = validation.to_try()

    a = None
    validation = Validation([])
    is_success = validation.is_success()
    either = validation.to_either()
    maybe = validation.to_maybe()
    lazy = validation.to_lazy()
    box = validation.to

# Generated at 2022-06-21 19:51:09.002311
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_identity import Identity

    def add_error_info(x):
        return Validation(x, ['error info'])

    def add_error_info_to_id(x):
        return Identity(x).ap(add_error_info)

    assert Validation.success(1).ap(add_error_info) == Validation(1, ['error info'])
    assert Validation.success(1).ap(add_error_info_to_id) == Validation(1, ['error info'])
    assert Validation.success(1).map(add_error_info).ap(add_error_info_to_id) == Validation(None, ['error info', 'error info'])

# Generated at 2022-06-21 19:51:18.661906
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success()

    assert validation.is_success()



# Generated at 2022-06-21 19:51:29.556443
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    def add_1(try_):
        return try_.map(lambda a: a + 1)

    assert (Validation.success(1).bind(add_1) ==
            Validation.success(2))

    assert (Validation.fail([1, 2]).bind(add_1) ==
            Validation.fail([1, 2]))

    def add_maybe(validation):
        from pymonet.maybe import Maybe

        return validation.map(lambda a: a + 1).to_maybe()

    assert (Validation.success(1).bind(add_maybe) ==
            Validation.success(2))


# Generated at 2022-06-21 19:51:36.629537
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
  from pymonet.maybe import Maybe
  from pymonet.monad_try import Try
  from pymonet.monad_list import List
  from pymonet.monad_set import Set

  test_data = [
      (Validation.success(1), Maybe.just(1)),
      (Validation.fail(), Maybe.nothing()),
  ]

  for data, expected in test_data:
      assert expected == data.to_maybe()


# Generated at 2022-06-21 19:51:38.030187
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail()



# Generated at 2022-06-21 19:51:42.130511
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation_success = Validation.success(1)
    assert validation_success.is_success()

    validation_fail = Validation.fail([])
    assert not validation_fail.is_fail()

    validation_fail = Validation.fail(['error'])
    assert validation_fail.is_fail()


# Generated at 2022-06-21 19:51:44.363901
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    def f():
        return 1
    assert Lazy(f).fmap(lambda x: x * 2) == 2

# Generated at 2022-06-21 19:51:48.252987
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(123).to_try() == Try(123)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:51:52.037714
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy().eval() == 2
    assert Validation.success(None).to_lazy().eval() is None
    assert Validation.success(2).to_lazy().eval() == 2


# Generated at 2022-06-21 19:51:58.277653
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    >>> success = Validation.success(42)
    >>> success1 = Validation.success(42)
    >>> assert success == success1
    >>> assert not success == Validation.success(43)
    >>> assert not success == Validation.fail([Exception('aaa')])
    >>> assert not Validation.fail([Exception('aaa')]) == Validation.fail([Exception('bbb')])
    >>> assert Validation.fail([Exception('aaa')]) == Validation.fail([Exception('aaa')])
    """
    pass



# Generated at 2022-06-21 19:52:08.984219
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success()                == Validation.success()
    assert Validation.success('TEST')          == Validation.success('TEST')
    assert Validation.success('TEST', 'XYZ')   == Validation.success('TEST', 'XYZ')
    assert Validation.fail()                   == Validation.fail()
    assert Validation.fail(['TEST'])           == Validation.fail(['TEST'])
    assert Validation.fail(['TEST', 'XYZ'])    == Validation.fail(['TEST', 'XYZ'])

    assert Validation.success()                != Validation.success('TEST')
    assert Validation.success()                != Validation.fail()
    assert Validation.success('TEST')          != Validation.success()
    assert Validation.success('TEST')

# Generated at 2022-06-21 19:52:26.004690
# Unit test for method bind of class Validation
def test_Validation_bind():
    validation = Validation.success(2)
    assert (validation.bind(lambda x: Validation.fail([('a', 1)]))
            == Validation(None, [('a', 1)]))
    assert (validation.bind(lambda x: Validation.success(3))
            == Validation(3, []))

    validation = Validation.fail([('a', 1)])
    assert (validation.bind(lambda x: Validation.success(2))
            == Validation(None, [('a', 1)]))
    assert (validation.bind(lambda x: Validation.fail([('b', 2)]))
            == Validation(None, [('a', 1)]))


# Generated at 2022-06-21 19:52:31.840045
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left

    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 1) == Validation(None, [1, 2, 3])

    assert Validation.success(1).bind(lambda x: Validation.success(x + 1)) == Validation(2, [])
    assert Validation.success(1).bind(lambda x: Validation.fail([x + 1])) == Validation(None, [2])



# Generated at 2022-06-21 19:52:37.983632
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # Given
    value = Validation(1, [])
    errors = Validation(1, [1])

    # When
    is_success_value = value.is_fail()
    is_success_errors = errors.is_fail()

    # Then
    assert is_success_value == False
    assert is_success_errors == True


# Generated at 2022-06-21 19:52:41.174277
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    lazy = Lazy(lambda: Validation(Value, Errors))

    assert Validation(Value, Errors).to_lazy() == lazy


# Generated at 2022-06-21 19:52:45.741860
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:52:51.246757
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    case_1 = 'Validation.success[None]'
    case_2 = "Validation.fail[None, ['field is required']]"
    assert (str(Validation.success()) == case_1)
    assert (str(Validation.fail(['field is required'])) == case_2)


# Generated at 2022-06-21 19:52:58.365339
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test method map of class Validation. Check, that mapper is not called when Validation is fail.
    """
    zero = Validation.fail(['Zero division error'])
    zero = zero.map(lambda x: x / 0)
    assert zero == Validation.fail(['Zero division error'])

    two = Validation.success(2)
    two = two.map(lambda x: x * 2)
    assert two == Validation.success(4)


# Generated at 2022-06-21 19:53:01.975615
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(15).bind(lambda x: Validation.success(x + 1)) == Validation.success(16)
    assert Validation.success(15).bind(lambda x: Validation.success([])) == Validation.success([])


# Generated at 2022-06-21 19:53:08.425383
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.success(Maybe.just(1)).to_either() == Right(Maybe.just(1))
    assert Validation.fail(Try.pure(1)).to_either() == Left(Try.pure(1))


# Generated at 2022-06-21 19:53:11.034236
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.fail(['err1', 'err2']).to_either() == \
           Left(['err1', 'err2'])

    assert Validation.success(42).to_either() == \
           Right(42)


# Generated at 2022-06-21 19:53:32.855397
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success_validation = Validation.success('value')
    fail_validation = Validation.fail(['error1', 'error2'])
    assert str(success_validation) == 'Validation.success[value]'
    assert str(fail_validation) == 'Validation.fail[None, [\'error1\', \'error2\']]'


# Generated at 2022-06-21 19:53:41.925645
# Unit test for method ap of class Validation
def test_Validation_ap():
    f = lambda x: Validation.success(x)
    g = lambda y: Validation.fail(['B'])
    v1 = Validation.success(3)
    v2 = Validation.fail(['A'])
    v3 = Validation.success(2)

    assert v1.ap(f) == Validation.success(3)
    assert v1.ap(g) == Validation.fail(['B'])
    assert v2.ap(f) == Validation.fail(['A'])
    assert v2.ap(g) == Validation.fail(['A', 'B'])
    assert v3.ap(f) == Validation.success(2)
    assert v3.ap(g) == Validation.fail(['B'])


# Generated at 2022-06-21 19:53:49.155900
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test is_fail method of class Validation.

    :returns: True when test is successfull
    :rtype: Boolean
    """
    assert Validation.fail([]).is_fail() == True
    assert Validation.fail([1, 2, 3]).is_fail() == True
    assert Validation.success(1).is_fail() == False
    assert Validation.success(None).is_fail() == False
    return True


# Generated at 2022-06-21 19:53:56.589816
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try().is_success()
    assert Validation.fail([]).to_try().is_fail()
    assert Validation.fail([1, 2]).to_try().is_fail()
    assert Validation.success(1).to_try().get_value() == 1
    assert Validation.fail([1, 2]).to_try().get_value() == None
    assert Validation.fail([1, 2]).to_try().get_errors() == [1, 2]



# Generated at 2022-06-21 19:54:00.844697
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Tests Validation.to_lazy method.
    """
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:54:07.014769
# Unit test for method map of class Validation
def test_Validation_map():
    success_validation = Validation.success(2)

    assert success_validation.map(lambda x: x ** 2) == Validation.success(4)

    fail_validation = Validation.fail(['The value should be greater than zero'])

    assert fail_validation.map(lambda x: x ** 2) == Validation.fail(['The value should be greater than zero'])


# Generated at 2022-06-21 19:54:14.974407
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either
    from pymonet.monad_try import Try

    # given
    v = Validation.fail(['error1', 'error2'])

    # when
    result = v.to_either()

    # then
    assert isinstance(result, Either)
    assert result.is_left()

    # given
    v = Validation.success('x')

    # when
    result = v.to_either()

    # then
    assert isinstance(result, Either)
    assert result.is_right()
    assert result.value == 'x'

    # given
    v = Validation.success(1)

    # when
    result = v.to_try()

    # then
    assert isinstance(result, Try)
    assert result.is_success()
    assert result

# Generated at 2022-06-21 19:54:22.131703
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    It test method __str__ of class Validation.
    """
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'


# Generated at 2022-06-21 19:54:24.712024
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """it should return a Lazy to value"""
    from pymonet.lazy import Lazy
    assert Validation.success('value').to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-21 19:54:30.504159
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Unit test for Validation.bind method"""
    from pymonet.either import Left
    from pymonet.monad_try import Try

    is_fail = lambda x: Validation.fail([str(x)])
    is_success = lambda x: Validation.success(x + 1)

    assert Validation.fail(['1']).bind(is_fail) == Validation.fail(['1'])
    assert Validation.fail(['1']).bind(is_success) == Validation.fail(['1'])
    assert Validation.success(1).bind(is_success) == Validation.success(2)
    assert Validation.success(1).bind(is_fail) == Validation.fail(['1'])


# Generated at 2022-06-21 19:55:18.069791
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation.success(123).to_maybe() == Maybe.just(123)
    assert Validation.fail(['error1']).to_maybe() == Maybe.nothing()
    assert Validation.success(Try(123)).to_maybe() == Maybe.just(Try(123))
    assert Validation.fail([Try(None, is_success=False)]).to_maybe() == Maybe.nothing()
    assert Validation.success(Try(123) \
                              .bind(lambda i: Try(i + 123)) \
                              .bind(lambda i: Try(i - 123))) \
                              .to_maybe() == Maybe.just(Try(123))
    assert Validation.fail

# Generated at 2022-06-21 19:55:23.299047
# Unit test for method map of class Validation
def test_Validation_map():
    def f(x):
        return x * 2

    assert Validation.success(2).map(f).value == 4
    assert Validation.success(2).map(lambda x: x * 2) == Validation.success(4)
    assert Validation.fail(['error']).map(f) == Validation.fail(['error'])


# Generated at 2022-06-21 19:55:25.919489
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    validation = Validation.success(5)
    assert validation.to_maybe() == Maybe.just(5)
    validation = Validation.fail(['error'])
    assert validation.to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:55:29.570636
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success(123) == Validation(123, [])
    assert Validation.fail(['abc', 123, ['aa']]) == Validation(None, ['abc', 123, ['aa']])


# Generated at 2022-06-21 19:55:33.050582
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(2, []).to_maybe() == Maybe.just(2)
    assert Validation(None, [1, 2]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:55:43.294344
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation_test_data import ValidationTestData
    from pymonet.validation_test_cases import ValidationTestCases

    mapping_function = lambda a: Validation.success(a * 2)
    data = ValidationTestData(Validation.fail([2, 3]), Validation.fail([4, 5]), Validation.success(1), \
                              Validation.success(2))
    test_cases = ValidationTestCases(lambda expected, actual: expected.value == actual.value and \
                                                               expected.errors == actual.errors)
    test_cases.add_test_case(data.fail_result, data.fail_result)
    test_cases.add_test_case(data.fail_other_result, data.fail_other_result)
    test_cases.add_test

# Generated at 2022-06-21 19:55:47.339117
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'

# Generated at 2022-06-21 19:55:54.350517
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.fail([1]).__eq__(Validation.fail([1]))
    assert Validation.success(1).__eq__(Validation.success(1))
    assert Validation.fail([1, 2]).__eq__(Validation.fail())
    assert not Validation.success(None).__eq__(Validation.success(1))
    assert Validation.fail().__eq__(Validation.fail())
    assert Validation.success(None).__eq__(Validation.success())


# Generated at 2022-06-21 19:56:04.082652
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Either, Left, Right
    from pymonet.maybe import Maybe

    def mapper_left(value):
        return Left([])

    def mapper_just(value):
        return Maybe.just([])

    def mapper_nothing(value):
        return Maybe.nothing()

    def folder(value):
        return Validation.fail([value])

    def mapper(value):
        return value

    def mapper_reverse(value):
        return '{}1'.format(value[::-1])

    assert Validation.success('10').bind(folder) == Validation.fail(['10'])
    assert Validation.fail('10').bind(folder) == Validation.fail(['10'])
    assert Validation.success('10').map(mapper_reverse) == Validation.success

# Generated at 2022-06-21 19:56:08.074877
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test method is_fail of class Validation.

    """
    assert(Validation.fail(['foo']).is_fail())
