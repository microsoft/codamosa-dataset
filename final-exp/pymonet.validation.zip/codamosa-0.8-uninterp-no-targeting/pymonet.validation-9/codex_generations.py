

# Generated at 2022-06-21 19:47:23.940368
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation('1', ['error 1', 'error 2'])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert isinstance(lazy.evaluate(), Try)
    assert lazy.evaluate().is_fail()
    assert lazy.evaluate().error == 'error 1'


# Generated at 2022-06-21 19:47:30.231531
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    # GIVEN
    from pymonet.monad_try import Try

    # WHEN
    try_success = Validation.success(10).to_try()
    try_fail = Validation.fail(['error1', 'error2']).to_try()

    # THEN
    assert try_success == Try(10, is_success=True)
    assert try_fail == Try(None, is_success=False)


# Generated at 2022-06-21 19:47:35.390953
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    UNIT test for method to_box of class Validation
    """
    from pymonet.box import Box

    assert Validation(123, None).to_box() == Box(123)
    assert Validation('abc', None).to_box() == Box('abc')
    assert Validation([], None).to_box() == Box([])
    assert Validation(None, None).to_box() == Box(None)
    assert Validation({'a': 'A'}, None).to_box() == Box({'a': 'A'})


# Generated at 2022-06-21 19:47:38.532107
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success(1).is_fail()
    assert Validation.fail([1]).is_fail()


# Generated at 2022-06-21 19:47:43.510281
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:47:45.773993
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.monad_maybe import Nothing
    from pymonet.monad_maybe import Just

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail([1]).to_maybe() == Nothing()


# Generated at 2022-06-21 19:47:52.691316
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    assert Validation(1, ['error']) == Validation(1, ['error'])

    assert Validation(1, ['error']) != Validation(2, ['error'])
    assert Validation(2, ['error']) != Validation(1, ['error'])
    assert Validation(1, ['error']) != Validation(1, [])

    assert Validation(1, ['error']) != Left(['error'])
    assert Validation(1, ['error']) != Right(1)


# Unit tests for method __str__ of class Validation

# Generated at 2022-06-21 19:48:03.120599
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    assert Validation.success().__eq__(Validation.success())
    assert Validation.success(1).__eq__(Validation.success(1))
    assert Validation.success(1).__eq__(Validation.success())

    assert Validation.fail().__eq__(Validation.fail())
    assert Validation.fail(['error']).__eq__(Validation.fail(['error']))
    assert Validation.fail(['error1', 'error2']).__eq__(Validation.fail(['error1', 'error2']))
    assert Validation.fail(['error', 'error2']).__eq__(Validation.fail(['error', 'error']))


# Generated at 2022-06-21 19:48:06.229631
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['Error'])) == "Validation.fail[None, ['Error']]"


# Generated at 2022-06-21 19:48:09.475840
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    right = Validation.success('hello').to_either()
    assert right == Right('hello')

    left = Validation.fail(['error1', 'error2']).to_either()
    assert left == Left(['error1', 'error2'])


# Generated at 2022-06-21 19:48:14.730474
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'


# Generated at 2022-06-21 19:48:23.061299
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from random import choice
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1]).to_box() == Box(None)
    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.success(randint(1, 5)).to_box() == Box(choice([1, 2, 3, 4, 5]))


# Generated at 2022-06-21 19:48:27.068665
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().evaluate() == 1

    assert Validation.fail([1]).to_lazy().evaluate() == None



# Generated at 2022-06-21 19:48:31.029414
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(2).to_maybe() == Maybe.just(2)
    assert Validation.fail([1, 2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:48:34.570070
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success('a').ap(Validation.success(lambda x: x.upper())) == Validation.success('A')
    assert Validation.success('a').ap(Validation.fail(['err1'])) == Validation.success('a')

# Generated at 2022-06-21 19:48:41.580799
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map of class Validation
    """
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # map with Maybe
    def maybe_map(value):
        """
        Function to test Maybe map
        """
        def mapper(value):
            return Maybe.just(value * 4)
        return value.map(mapper).value

    assert maybe_map(Validation.success(10)) == 40
    assert maybe_map(Validation.fail([1, 2, 3])) == 20

    # map with Either
    def either_map(value):
        """
        Function to test Either map
        """

# Generated at 2022-06-21 19:48:49.580367
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    val1 = Validation.fail(['error'])
    val2 = Validation.success(None)
    val3 = Validation.success(1)
    val4 = Validation.success('c')
    val5 = Validation.success(0.2)
    val6 = Validation.success(True)
    val7 = Validation.success(5)
    val8 = Validation.success([])
    val9 = Validation.success((1,))
    val10 = Validation.success((1, [2, 3]))
    val11 = Validation.success({1: 2, 3: 4})

# Generated at 2022-06-21 19:48:59.236899
# Unit test for method ap of class Validation
def test_Validation_ap():
    def make_success(m):
        v = Validation.success(m)
        return v

    def make_fail(m):
        v = Validation.fail([m])
        return v

    assert Validation.fail([]).ap(make_success).errors == []
    assert Validation.fail(["e"]).ap(make_success).errors == ["e"]

    assert Validation.fail([]).ap(make_fail).errors == ["e"]
    assert Validation.fail(["e"]).ap(make_fail).errors == ["e"]

    assert Validation.success(12).ap(make_success).errors == []
    assert Validation.success(12).ap(make_fail).errors == ["e"]

# Generated at 2022-06-21 19:49:03.428352
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(10).is_fail() is False
    assert Validation.success(None).is_fail() is False
    assert Validation.success([1, 2, 3]).is_fail() is False

    assert Validation.fail([1, 2, 3]).is_fail() is True


# Generated at 2022-06-21 19:49:08.963627
# Unit test for constructor of class Validation
def test_Validation():
    """

    >>> test_Validation()
    True
    """
    val = Validation.success(1)
    assert val.value == 1
    assert val.errors == []
    assert val.is_success()

    val = Validation.fail([1,2])
    assert val.value is None
    assert val.errors == [1,2]
    assert val.is_fail()
    return True


# Generated at 2022-06-21 19:49:18.729211
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.box import Box
    from pymonet.iterable import Iterable

    validation1 = Validation.fail(errors=[1, 2, 3])
    assert str(validation1) == 'Validation.fail[None, [1, 2, 3]]'
    validation2 = Validation.success(value=Box.just(1))
    assert str(validation2) == 'Validation.success[[Just] 1]'
    validation3 = Validation.success(value=Iterable([1, 2, 3]))
    assert str(validation3) == 'Validation.success[<Iterable [1, 2, 3]>]'


# Generated at 2022-06-21 19:49:28.411511
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # GIVEN
    class CustomError(Exception):
        """Custom error class"""

    validation1 = Validation.fail(['a', 'b'])
    validation2 = Validation.fail(['a', 'b'])
    validation3 = Validation.fail([1, 2])
    validation4 = Validation.fail()
    validation5 = Validation.fail([1, 2, CustomError()])
    validation6 = Validation.fail([CustomError(), 2, 1])
    validation7 = Validation.success('a')
    validation8 = Validation.success(1)

    # THEN
    assert validation1 == validation2
    assert validation1 != validation3
    assert validation3 != validation4
    assert validation4 != validation5
    assert validation5 != validation6
    assert validation5 != validation7
    assert validation7 != validation8

# Generated at 2022-06-21 19:49:36.832442
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test for method __eq__ of class Validation.

    Runs:
        >>> test_Validation___eq__()
        Test Validation.__eq__: ok
    """
    validation_1 = Validation.success(value=1)
    validation_2 = Validation.success(value=1)
    validation_3 = Validation.success(value=2)
    validation_4 = Validation.fail(errors=[1, 2, 3])
    validation_5 = Validation.fail(errors=[1, 2, 3])
    validation_6 = Validation.fail(errors=[4, 5, 6])
    validation_7 = Validation.fail(errors=[1, 2, 3])
    validation_8 = Validation.success(value=2)
    validation_9 = Validation.success(value=1)

    assert validation

# Generated at 2022-06-21 19:49:39.991896
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    validation_success = Validation.success(1)
    validation_fail = Validation.fail([1, 2])

    # when
    lazy_success = validation_success.to_lazy()
    lazy_fail = validation_fail.to_lazy()

    # then
    assert lazy_success.value() == 1
    assert lazy_fail.value() is None


# Generated at 2022-06-21 19:49:42.552677
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().eval() == 1
    assert Validation.fail(["error"]).to_lazy().eval() == None


# Generated at 2022-06-21 19:49:54.274471
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation(None, []).to_maybe() == Maybe.nothing()
    assert Validation(123, []).to_maybe() == Maybe.just(123)
    assert Validation('key', [1, 2]).to_maybe() == Maybe.nothing()

    assert Validation(None, []).to_either() == Left([])
    assert Validation(123, []).to_either() == Right(123)
    assert Validation('key', [1, 2]).to_either() == Left([1, 2])

    assert Validation(None, []).to_box() == Box(None)


# Generated at 2022-06-21 19:50:05.240208
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.list import List
    from pymonet.either import Right

    success = Validation.success([1, 2, 3])
    fail = Validation.fail([
        E.error(message='Failed value', name='failed', code=404),
        E.error(message='Failed value', name='failed', code=404),
    ])

    assert success.to_either() == Right([1, 2, 3])
    assert fail.to_either() == List([
        E.error(message='Failed value', name='failed', code=404),
        E.error(message='Failed value', name='failed', code=404),
    ])


# Generated at 2022-06-21 19:50:10.809011
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert Validation.fail(['a']).is_fail()
    assert not (Validation.success()).is_fail()
    assert not (Validation.success('a')).is_fail()


# Generated at 2022-06-21 19:50:14.922478
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test method 'is_fail' of class Validation.
    """
    assert Validation(1, []).is_fail() == False
    assert Validation(None, [1]).is_fail() == True


# Generated at 2022-06-21 19:50:16.952933
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(None).is_success() == True
    assert Validation.fail().is_success() == False


# Generated at 2022-06-21 19:50:21.985657
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('a').to_box() == Box('a')


# Generated at 2022-06-21 19:50:26.892558
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(errors=(["Error!"])) == Validation(value=None, errors=["Error!"])
    assert Validation.fail(errors=(["Error!"])) is not Validation.fail()
    assert Validation.fail(errors=(["Error!"])).is_fail() is True


# Generated at 2022-06-21 19:50:32.877950
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right

    assert Validation.success(1).map(lambda x: x + 2) == Validation(3, [])
    assert Validation.success(1).map(lambda x: x + 2).to_either() == Right(3)

    assert Validation.fail(['error']).map(lambda x: x + 2) == Validation(None, ['error'])


# Generated at 2022-06-21 19:50:42.497000
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.monad_maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Test successful Validation
    v = Validation.success(3)
    assert(v.to_maybe() == Maybe.just(3))
    assert(v.to_either() == Right(3))
    assert(v.to_box() == Box(3))
    assert(v.to_lazy()() == Lazy(lambda: 3)())
    assert(v.to_try() == Try(3, is_success=True))

    # Test failed Validation
    v = Validation.fail(['an error'])

# Generated at 2022-06-21 19:50:51.142464
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 2) == Validation.success(3)
    assert Validation.success(1).map(lambda x: x + 2).value == 3
    assert Validation.success(1).map(lambda x: x + 2).errors == []
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 2) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 2).value is None
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 2).errors == [1, 2, 3]


# Generated at 2022-06-21 19:50:56.593837
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'



# Generated at 2022-06-21 19:51:04.212012
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda x: 2) == Validation.success(2)
    assert Validation.success(2).map(lambda x: x + 1) == Validation.success(3)
    assert Validation.success(2).map(lambda x: 2) == Validation.success(2)
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation.fail(['error'])

# Generated at 2022-06-21 19:51:14.554640
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test for method __eq__ of class Validation.
    """
    from pymonet.monad_maybe import Maybe

    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, []) != Validation(2, [])
    assert Validation(1, []) != Validation(1, [1])
    assert Validation(1, []) != Validation(2, [1])
    assert Validation(None, ['error']) == Validation(None, ['error'])
    assert Validation(None, ['error1']) != Validation(None, ['error2'])
    assert Validation(None, ['error1']) != Validation(None, [])
    assert Validation.success(1) == Validation.success(1)

# Generated at 2022-06-21 19:51:18.694652
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    def to_maybe(validation):
        return validation.to_maybe()

    assert to_maybe(Validation.success("a")) == Maybe.just("a")
    assert to_maybe(Validation.fail("error")) == Maybe.nothing()


# Generated at 2022-06-21 19:51:26.618981
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])
    assert Validation.success(1).map(lambda x: x + 1).map(lambda x: x + 2) == Validation.success(4)
    assert Validation.fail([]).map(lambda x: x + 1).map(lambda x: x + 2) == Validation.fail([])



# Generated at 2022-06-21 19:51:35.115612
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    validation = Validation.success(1)
    assert validation.to_either() == Right(1)
    validation.errors.append(2)
    assert validation.to_either() == Left([2])


# Generated at 2022-06-21 19:51:44.593833
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation(1, []) == Validation.success(1)
    assert Validation(None, [1]) == Validation.fail([1])
    assert Validation.success(1).is_success()
    assert Validation.fail([1]).is_fail()
    assert not Validation.success(1).is_fail()
    assert not Validation.fail([1]).is_success()
    assert Validation(1, [1, 2]).ap(lambda a: Validation(None, [3])) == Validation(1, [1, 2, 3])
    assert Validation(1, [1, 2]).map(lambda a: a + 1) == Validation(2, [1, 2])

# Generated at 2022-06-21 19:51:48.019575
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    validate = Validation.success(5)
    assert validate.to_box() == Box(5)



# Generated at 2022-06-21 19:51:52.250891
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([]).is_fail()
    assert Validation.fail(['Error message']).is_fail()
    assert Validation.success([]).is_fail() == False
    assert Validation.success(['Error message']).is_fail() == False


# Generated at 2022-06-21 19:51:57.411426
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(2).map(lambda x: x + 1) == Validation.success(3)
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation.fail(['error'])


# Generated at 2022-06-21 19:52:02.229310
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['Error 1', 'Error 2'])) == 'Validation.fail[None, [\'Error 1\', \'Error 2\']]'


# Generated at 2022-06-21 19:52:11.327616
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test method to_lazy of class Validation.
    """

    def _test(value, expected_result):
        """
        It takes value and expected_result and tests method to_lazy.

        :param value: value to send to method
        :type value: A
        :param expected_result: expected value
        :type expected_result: A
        :returns: True when test is successful
        :rtype: Boolean
        """
        from pymonet.lazy import Lazy

        actual_result = Validation.success(value).to_lazy()

        return isinstance(actual_result, Lazy) and callable(actual_result.value) and actual_result.value() == expected_result

    assert _test('value', 'value')
    assert _test(2, 3)
    assert _test

# Generated at 2022-06-21 19:52:16.515756
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success('success')
    assert str(success) == "Validation.success['success']"

    fail = Validation.fail(['error'])
    assert str(fail) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-21 19:52:21.338364
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])

    assert Validation.success(Maybe.just(1)).to_either() == Right(Maybe.just(1))
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])



# Generated at 2022-06-21 19:52:26.532758
# Unit test for method map of class Validation
def test_Validation_map():
    # given
    validation_with_value = Validation(1, []).map(lambda x: x + 1)
    validation_with_failure = Validation(None, ['error message 1']).map(lambda x: x + 1)

    # expect
    assert validation_with_value == Validation(2, [])
    assert validation_with_failure == Validation(None, ['error message 1'])


# Generated at 2022-06-21 19:52:41.911177
# Unit test for method ap of class Validation
def test_Validation_ap():

    # it should concat errors list when Validation is success with errors
    assert Validation(10, []).ap(
        lambda v: Validation(v * 2, [10, 11])) == Validation(20, [10, 11])

    # it should return Validation with concated error lists when Validation is fail
    assert Validation(10, [1, 2]).ap(
        lambda v: Validation(v * 2, [10, 11])) == Validation(20, [1, 2, 10, 11])

    # it should return Validation with concated error lists when Validation is fail
    assert Validation(None, [1, 2]).ap(
        lambda v: Validation(v * 2, [10, 11])) == Validation(None, [1, 2, 10, 11])


# Generated at 2022-06-21 19:52:47.818054
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Check if `is_fail` is correct for Validation.
    """

    test_is_fail_cases = (
        (Validation.success(1), False),
        (Validation.fail([1]), True),
        (Validation.fail([1, 2, 3]), True)
    )

    for validation, expected in test_is_fail_cases:
        result = validation.is_fail()
        assert result == expected, 'Error with input "{}"'.format(validation)



# Generated at 2022-06-21 19:52:56.879831
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(None, [])) == 'Validation.success[]'
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, ['error'])) == "Validation.fail[1, ['error']]"
    assert str(Validation.success()) == 'Validation.success[]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['error'])) == "Validation.fail[None, ['error']]"


# Unit tests for method success of class Validation

# Generated at 2022-06-21 19:53:05.249947
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(123)) == 'Validation.success[123]'


# Generated at 2022-06-21 19:53:09.522217
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation.success(Maybe.just(1)).to_either() == Right(Maybe.just(1))
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])



# Generated at 2022-06-21 19:53:11.547423
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.fail().to_maybe() == Maybe.nothing()
    assert Validation.success(12).to_maybe() == Maybe.just(12)



# Generated at 2022-06-21 19:53:14.921378
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    v1 = Validation.success(1)
    v2 = Validation.success(2)
    v3 = Validation.fail(['Failed!', 'Failed again!'])

    assert v1.to_try() == Try(1)
    assert v2.to_try() == Try(2)
    assert v3.to_try() == Try(None, success=False)


# Generated at 2022-06-21 19:53:20.094261
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == "Validation.success[1]"
    assert str(Validation.fail([])) == "Validation.fail[None, []]"
    assert str(Validation.fail([1,2])) == "Validation.fail[None, [1, 2]]"


# Generated at 2022-06-21 19:53:24.971262
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.maybe_test import test_Maybe_just
    from pymonet.maybe_test import test_Maybe_nothing

    validation = Validation.success('success')
    maybe = validation.to_maybe()

    assert isinstance(maybe, Maybe) and maybe.is_just() and maybe.get() == validation.value

    validation = Validation.fail('error')
    maybe = validation.to_maybe()

    assert isinstance(maybe, Maybe) and maybe.is_nothing()

    try:
        maybe.get()
        assert False # pragma: no cover
    except:
        pass


# Generated at 2022-06-21 19:53:35.389073
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    x = Validation.success(42).ap(lambda x: Validation.success(x))
    assert x.value == 42
    assert len(x.errors) == 0

    x = Validation.success(42).ap(lambda x: Validation.fail(['ups']))
    assert x.value == 42
    assert x.errors == ['ups']

    x = Validation.fail(['ups']).ap(lambda x: Validation.success(42))
    assert x.value == 42
    assert x.errors == ['ups']

    x = Validation.fail(['ups']).ap(lambda x: Validation.fail(['ups, ups']))
    assert x.value == 42
    assert x.errors == ['ups', 'ups, ups']

# Generated at 2022-06-21 19:53:45.307629
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:53:50.482107
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    validation_true = Validation.success(3)
    validation_false = Validation.fail([1])
    assert validation_false.to_maybe().is_nothing()
    assert validation_true.to_maybe().is_just()
    assert validation_true.to_maybe().from_just() == 3


# Generated at 2022-06-21 19:53:55.124643
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v1 = Validation(None, ['error', 'error2'])
    v2 = Validation(None, ['error', 'error2'])
    v3 = Validation(None, ['error'])
    assert v1.__eq__(v2)
    assert not v1.__eq__(v3)


# Generated at 2022-06-21 19:53:59.707627
# Unit test for method bind of class Validation
def test_Validation_bind():
    def f(value):
        if value < 10:
            return Validation.success(value + 1)
        else:
            return Validation.fail([value])

    assert Validation.success(1).bind(f) == Validation.success(2)
    assert Validation.success(10).bind(f) == Validation.fail([10])
    assert Validation.success(None).bind(f) == Validation.fail([None])



# Generated at 2022-06-21 19:54:02.963960
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():  # pragma: no cover
    assert Validation.fail().is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-21 19:54:06.841833
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) != Validation.success(2)
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1]) == Validation.fail([1])


# Generated at 2022-06-21 19:54:13.067387
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(Validation(_map_to_Validation, [])) == Validation.success(2)
    assert Validation.success(1).ap(Validation(_map_to_Validation, [1])) == Validation.fail([1])
    assert Validation.fail([1]).ap(Validation(_map_to_Validation, [2])) == Validation.fail([1,2])
    assert Validation.fail([]).ap(Validation(_map_to_Validation, [1])) == Validation.fail([1])


# Generated at 2022-06-21 19:54:20.688241
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import TrySuccess, TryFailure

    success = Validation.success(2)
    fail = Validation.fail([])

    assert success.to_try().is_success() is True
    assert fail.to_try().is_failure() is True
    assert isinstance(success.to_try(), TrySuccess)
    assert isinstance(fail.to_try(), TryFailure)


# Functional programming style

# Generated at 2022-06-21 19:54:28.677544
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Just some validation functions
    def validate_age(age):
        return Validation.success(age + 1) if age > 18 else Validation.fail(['Age must be > 18'])

    def validate_u18(age):
        return Validation.success(age) if age < 18 else Validation.fail(['Age must be < 18'])

    def validate_u50(age):
        return Validation.success(age) if age < 50 else Validation.fail(['Age must be < 50'])

    # None is used as a value
    assert Validation.success(None).ap(validate_age) == Validation.fail(['Age must be > 18'])
    assert Validation.success(19).ap(validate_age) == Validation.success(20)


# Generated at 2022-06-21 19:54:32.186727
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.fail().is_success()
    assert not Validation.success(42).is_fail()
    assert Validation.success().is_success()



# Generated at 2022-06-21 19:54:42.620466
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, [1, 2]) == Validation(1, [1, 2])
    assert Validation(1, [1, 2]) != Validation(1, [1])
    assert Validation(None, []) == Validation(None, [])
    assert Validation(1, []) != Validation(None, [])


# Generated at 2022-06-21 19:54:46.515501
# Unit test for method bind of class Validation
def test_Validation_bind():
    def folder(value):
        if value == 1:
            return Validation.success(None)
        return Validation.fail(['fail'])

    assert Validation.success(1).bind(folder) == Validation.success(None)
    assert Validation.success(2).bind(folder) == Validation.fail(['fail'])


# Generated at 2022-06-21 19:54:50.652231
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Validation.success(4).to_either() == Right(4)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:54:52.901137
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.fail([ValueError('error')]).is_success() == False


# Generated at 2022-06-21 19:54:58.211806
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(4) == Validation.success(4)
    assert Validation.fail([1]) == Validation.fail([1])
    assert repr(Validation.success(4)) == 'Validation.success[4]'
    assert repr(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:55:04.703053
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def folder(value):
        def inner_function(parameter):
            return Lazy(lambda: parameter * value)

        inner_function = Lazy(inner_function)
        return Try(parameter=2, is_success=True).map(inner_function)

    assert Validation.success(2).bind(folder) == Validation(value=4, errors=[])



# Generated at 2022-06-21 19:55:08.314814
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Create simple validation with value and no errors
    result = Validation.success(1)

    # Transform Validation to Try
    lazy_result = result.to_lazy()

    # assert that result is Try
    assert isinstance(lazy_result, Lazy)
    # assert Try is successful
    assert lazy_result.is_success()
    # assert Try value is 1
    assert lazy_result.get() == 1


# Generated at 2022-06-21 19:55:12.242304
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Failure, Success

    assert Validation.fail(["error"]).to_try() == Failure(None, ["error"])
    assert Validation.success(7).to_try() == Success(7)



# Generated at 2022-06-21 19:55:17.367042
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Equivalent of this code:

    .. code-block:: python

        assert Validation.success(1).to_either() == Right(1)
        assert Validation.fail(None).to_either() == Left(None)
    """
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(None).to_either() == Left(None)


# Generated at 2022-06-21 19:55:24.721867
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.maybe import Maybe

    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success('a')) == 'Validation.success[a]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [error]]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail([Maybe.just('maybe'), Maybe.nothing()])) == 'Validation.fail[None, [Just(maybe), Nothing]]'



# Generated at 2022-06-21 19:55:33.798775
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation([], []).to_try() == Try([], is_success=True)
    assert Validation([], [1]).to_try() == Try([], is_success=False)


# Generated at 2022-06-21 19:55:38.151253
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail('error') == Validation.fail('error')
    assert Validation.fail('error') != Validation.fail('other error')



# Generated at 2022-06-21 19:55:43.443043
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(42).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 42

    lazy = Validation.fail([]).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get() is None


# Generated at 2022-06-21 19:55:44.930081
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(2).to_box() == Box(2)
    assert Validation.fail(['a']).to_box() == Box(None)


# Generated at 2022-06-21 19:55:46.369107
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success('success').to_try().get() == 'success'
    assert Validation.fail(['error']).to_try().is_success() is False


# Generated at 2022-06-21 19:55:56.925261
# Unit test for method ap of class Validation
def test_Validation_ap():
    def validate_name(name):
        if len(name) < 3:
            return Validation(name, ['name is too short'])
        return Validation(name, [])

    def validate_surname(surname):
        if len(surname) > 50:
            return Validation(surname, ['surname is too long'])
        return Validation(surname, [])

    def fullname(name, surname):
        return "{} {}".format(name, surname)

    name_validation = validate_name('Jane')
    surname_validation = validate_surname('Doe')

    fullname_validation = surname_validation.ap(lambda surname: name_validation.map(lambda name: fullname(name, surname)))


# Generated at 2022-06-21 19:56:03.234810
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success()
    assert str(success) == 'Validation.success[None]'
    success = Validation.success(10)
    assert str(success) == 'Validation.success[10]'
    fail = Validation.fail([{'class': 'String', 'field': 'password', 'message': 'Password should be more then 10 chars'},
                            {'class': 'String', 'field': 'email', 'message': 'Email should be present'}])
    assert str(fail) == 'Validation.fail[None, [{\'class\': \'String\', \'message\': \'Password should be more then 10 chars\', \'field\': \'password\'}, {\'class\': \'String\', \'message\': \'Email should be present\', \'field\': \'email\'}]]'


# Generated at 2022-06-21 19:56:08.075081
# Unit test for constructor of class Validation
def test_Validation():
    """"Unit test for constructor of class Validation"""
    assert Validation(1, []).value == 1
    assert Validation('Error', []).errors == []
    assert Validation(1, ['error 1']).errors == ['error 1']


# Generated at 2022-06-21 19:56:12.377723
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test cases for Validation __str__ method.
    """
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:56:16.192727
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(5, []).to_box() == Box(5)
    assert Validation(5, ['error']).to_box() == Box(5)
    assert Validation(None, ['error']).to_box() == Box(None)


# Generated at 2022-06-21 19:56:31.838030
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1).to_box().map(lambda x: x + 1) == Box(2)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box().map(lambda x: x) == Box(None)


# Generated at 2022-06-21 19:56:34.598197
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    It tests to_box() method of Validation class
    """
    from pymonet.box import Box

    assert Validation('x', ['error']).to_box() == Box('x')

# Generated at 2022-06-21 19:56:39.138087
# Unit test for constructor of class Validation
def test_Validation():
    """
    Test Validation constructor.
    """
    validation_success = Validation(1, [])
    assert validation_success.value == 1
    assert validation_success.errors == []
    assert validation_success.is_success() is True
    assert validation_success.is_fail() is False

    validation_fail = Validation(1, [1, 2, 3])
    assert validation_fail.value == 1
    assert validation_fail.errors == [1, 2, 3]
    assert validation_fail.is_success() is False
    assert validation_fail.is_fail() is True



# Generated at 2022-06-21 19:56:49.106861
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    import operator
    import pytest

    validation = Validation.success('value')
    assert Functor.map(validation, str.upper) == 'VALUE'

    validation = Validation.fail(errors=['error'])
    with pytest.raises(UnboundLocalError, match=r'local variable \'errors\' referenced before assignment'):
        Functor.map(validation, str.upper)

    validation = Validation.success('value')
    assert Monad.bind(validation, str.upper) == 'VALUE'

    validation = Validation.fail(errors=['error'])
    assert Monad.bind(validation, str.upper) == None


# Generated at 2022-06-21 19:56:52.747037
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    # Given
    from pymonet.monad_try import Success

    validation = Validation(None, [1, 2]).to_try()

    # When
    success = validation.is_success()

    # Then
    assert not success


# Generated at 2022-06-21 19:56:56.396559
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    value_err = Validation.fail(errors=['error'])
    value_success = Validation.success(value=123)
    assert value_err.is_success() == False
    assert value_success.is_success() == True


# Generated at 2022-06-21 19:56:58.273536
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)


# Generated at 2022-06-21 19:57:00.785440
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Validation(1, []).to_maybe() == Maybe.just(1)
    assert Validation(1, [1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:57:08.511496
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    val_1 = Validation.success('hello')
    val_2 = Validation.success('hello')
    val_3 = Validation.fail([])
    val_4 = Validation.fail([])
    val_5 = Validation.success('hello1')
    assert val_1 == val_2
    assert val_3 == val_4
    assert val_1 != val_3
    assert val_1 != val_4
    assert val_2 != val_3
    assert val_2 != val_4
    assert val_1 != val_5


# Generated at 2022-06-21 19:57:12.876392
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.fail([]).is_success()
    assert not Validation.fail([1]).is_success()
