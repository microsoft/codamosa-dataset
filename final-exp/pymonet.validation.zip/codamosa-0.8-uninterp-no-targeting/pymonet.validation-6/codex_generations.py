

# Generated at 2022-06-21 19:47:21.109606
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-21 19:47:23.201206
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(42).to_box() == Box(42)


# Generated at 2022-06-21 19:47:26.811090
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(3).to_try() == Try(3, True)
    assert Validation.fail(['foo']).to_try() == Try(None, False)



# Generated at 2022-06-21 19:47:31.926369
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for method is_success of class Validation.
    """
    assert Validation.success(1).is_success() == True, \
        "Validation(1, None) must be success"

    assert Validation.fail(['a']).is_success() == False, \
        "Validation(1, ['a']) must be fail"


# Generated at 2022-06-21 19:47:35.762185
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test for Validation class
    """
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]'
    assert str(Validation.fail(['Error'], 10)) == 'Validation.fail[10, [\'Error\']]'


# Generated at 2022-06-21 19:47:40.209290
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # When: Using function to_lazy
    result = Validation.success(1).to_lazy()
    # Then: Function should return Lazy[Function() -> 1]
    assert result == Lazy(lambda: 1)


# Generated at 2022-06-21 19:47:42.322420
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.fail([Exception('Exception')]).is_success()


# Generated at 2022-06-21 19:47:49.790440
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation
    """

    res_fail = Validation.fail(['error1', 'error2'])
    assert str(res_fail) == 'Validation.fail[None, [\'error1\', \'error2\']]'

    res_success = Validation.success('Success value')
    assert str(res_success) == 'Validation.success[Success value]'


# Generated at 2022-06-21 19:47:54.876018
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    success = Validation.success(10)
    assert success.to_maybe() == Maybe.just(10)

    fail = Validation.fail([1, 2, 3])
    assert fail.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:47:57.456814
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.val import Validation

    success_validation = Validation(1, [])
    assert success_validation.to_maybe() == Maybe.just(1)

    fail_validation = Validation(None, [1, 2, 3])
    assert fail_validation.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:48:02.288856
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([]) == Validation(None, [])


# Generated at 2022-06-21 19:48:06.843981
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(42, []) == Validation(42, [])
    assert Validation('42', []) != Validation(42, [])
    assert Validation(42, [1]) != Validation(42, [])
    assert Validation(42, [1, 2]) != Validation(42, [1])


# Generated at 2022-06-21 19:48:16.300776
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    def test_validation_to_try_with_success(value):
        validation = Validation.success(value)
        actual = validation.to_try()
        assert isinstance(actual, Try)
        assert actual.is_success()
        assert actual.value == value

    def test_validation_to_try_with_fail(value):
        validation = Validation.fail(value)
        actual = validation.to_try()
        assert isinstance(actual, Try)
        assert not actual.is_success()
        assert actual.value is None

    test_validation_to_try_with_success(1)
    test_validation_to_try_with_success('abc')
    test_validation_to_try_with_success(lambda: 1)


# Generated at 2022-06-21 19:48:24.951166
# Unit test for method ap of class Validation
def test_Validation_ap():
    def test_fn(val):
        return Validation(val, [])

    # Given
    val = Validation.success(1).ap(test_fn)

    # Then
    assert val == Validation(1, [])

    # Given
    val = Validation.success(1).ap(lambda val: Validation(val, [2, 3]))

    # Then
    assert val == Validation(1, [2, 3])

    # Given
    val = Validation.fail([2, 3]).ap(lambda val: Validation(val, [2, 3]))

    # Then
    assert val == Validation(None, [2, 3, 2, 3])

# Generated at 2022-06-21 19:48:30.768918
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 4)

    val = Validation.success(lazy)

    assert val.to_lazy().value == 4
    assert val.to_lazy().value is lazy.value

    val = Validation.fail()
    assert val.to_lazy().value is None



# Generated at 2022-06-21 19:48:39.598969
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation(1, []).map(lambda n: n+1) == Validation(2, [])
    assert Validation(1, []).map(lambda n: n+1).map(lambda n: n+1) == Validation(3, [])

    assert Validation(1, [1, 2]).map(lambda n: n+1) == Validation(2, [1, 2])
    assert Validation(1, [1, 2]).map(lambda n: n+1).map(lambda n: n+1) == \
           Validation(3, [1, 2])

    assert Validation(None, [1, 2]).map(lambda n: n+1) == Validation(None, [1, 2])

# Generated at 2022-06-21 19:48:41.499897
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(4).to_try() == Success(4)
    assert Validation.fail([4, 5]).to_try() == Failure([4, 5])



# Generated at 2022-06-21 19:48:48.318344
# Unit test for method ap of class Validation
def test_Validation_ap():
    def f1(v):
        return Validation.success(v)

    def f2(v):
        return Validation.fail([f'{v} is even'])

    assert Validation.success(2).ap(f1) == Validation.success(2)
    assert Validation.success(2).ap(f2) == Validation.fail(['2 is even'])
    assert Validation.fail([5, 6]).ap(f1) == Validation.fail([5, 6])
    assert Validation.fail([5, 6]).ap(f2) == Validation.fail([5, 6])


# Generated at 2022-06-21 19:48:51.865532
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['1', '2']).is_fail()
    assert not Validation.fail().is_fail()
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-21 19:48:55.115173
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    pass_validation = Validation.success([1,2,3])
    assert pass_validation.is_fail() == False
    fail_validation = Validation.fail([1,2,3])
    assert fail_validation.is_fail() == True


# Generated at 2022-06-21 19:49:03.526844
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(lambda x: x + 1).map(lambda x: x(1)) == Validation.success(2)
    assert Validation.fail('Error').map(lambda x: x + 1) == Validation.fail('Error')
    assert Validation.success(None).map(lambda x: x + 1) == Validation.success(None)


# Generated at 2022-06-21 19:49:08.775988
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation.success(1).to_box() == Box(1)
    assert Validation(1, [1]).to_box() == Box(1)
    assert Validation.fail([1]).to_box() == Box(None)

# Generated at 2022-06-21 19:49:14.248735
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.success() == Validation(None, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation.fail() == Validation(None, [])


# Generated at 2022-06-21 19:49:16.490056
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() == True
    assert Validation.success().is_fail() == False


# Generated at 2022-06-21 19:49:23.415928
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.errors import ValidationError

    # Test successful Validation
    assert Validation.success().is_success() == True
    assert Validation.success('').is_success() == True

    # Test failed Validation
    assert Validation.fail(['']).is_success() == False
    assert Validation.fail([ValidationError('', '')]).is_success() == False



# Generated at 2022-06-21 19:49:26.973388
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    def add(value):
        return Validation(value+1, [])

    assert Validation.success(1).bind(add) == Validation.success(2)
    assert Validation.fail([1]).bind(add) == Validation.fail([1])


# Generated at 2022-06-21 19:49:35.738907
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from pymonet.monad_try import Try

    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'
    assert str(Validation.success([1, 2, 3])) == 'Validation.success[[1, 2, 3]]'
    assert str(Validation.success(True)) == 'Validation.success[True]'
    assert str(Validation.success(0)) == 'Validation.success[0]'
    assert str(Validation.success(Try.fail(1))) == 'Validation.success[Try.fail[1]]'


# Generated at 2022-06-21 19:49:37.826636
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    expected = 10
    validation = Validation.success(expected)
    assert validation.to_lazy().value() == expected

    validation = Validation.fail()
    assert validation.to_lazy().value() is None


# Generated at 2022-06-21 19:49:39.621989
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    v = Validation("hello", [])
    assert v.is_success() == True


# Generated at 2022-06-21 19:49:43.146590
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.success(10).to_try() == Try.success(10)
    assert Validation.fail([10, 20]).to_try() == Try.fail(10, 20)


# Generated at 2022-06-21 19:49:53.227075
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(1, [])
    assert validation.value == 1
    assert validation.errors == []
    assert validation.is_success() is True
    assert validation.to_either().is_right() is True
    assert validation.to_maybe().is_just() is True
    assert validation.to_try().is_success() is True
    assert validation.to_box().value == 1
    assert validation.to_lazy().value() == 1


# Generated at 2022-06-21 19:49:56.751773
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(1).to_either().map(lambda x: x + 1) == Right(2)
    assert Validation.fail(['errors']).to_either() == Left(['errors'])


# Generated at 2022-06-21 19:50:08.363213
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test Validation.bind(folder) method.
    """
    assert Validation.success(1).bind(lambda v: Validation.success(v + 1)) == Validation.success(2)
    assert Validation.success(1).bind(lambda v: Validation.fail(['some error'])) == Validation.fail(['some error'])
    assert Validation.fail(['some error']).bind(lambda v: Validation.fail(['some error'])) == \
        Validation.fail(['some error'])
    assert Validation.fail(['some error']).bind(lambda v: Validation.success(v + 1)) == Validation.fail(['some error'])


# Generated at 2022-06-21 19:50:12.506463
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.fail(['foo']).to_try() == Try(None, is_success=False)
    assert Validation.success(True).to_try() == Try(True, is_success=True)


# Generated at 2022-06-21 19:50:19.600087
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(5).map(lambda x: x + 1) == Validation.success(6)
    assert Validation.success('abc').map(lambda x: x + 'def') == Validation.success('abcdef')
    assert Validation.fail(['error1', 'error2']).map(lambda x: x + 1) == Validation.fail(['error1', 'error2'])
    assert Validation.fail([1, 2]).map(lambda x: x + 1) == Validation.fail([1, 2])


# Generated at 2022-06-21 19:50:23.739615
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    """
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:50:28.808578
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    result = Validation.success('bar').to_maybe()
    assert result == Maybe.just('bar')

    result = Validation.fail([
        'Something went wrong'
    ]).to_maybe()
    assert result == Maybe.nothing()


# Generated at 2022-06-21 19:50:34.869778
# Unit test for method map of class Validation
def test_Validation_map():
    validation = Validation.success(42)
    assert validation.map(lambda x: x * 2) == Validation(84, [])

    validation = Validation.success(None)
    assert validation.map(lambda x: x * 2) == Validation(None, [])

    validation = Validation.fail(['error'])
    assert validation.map(lambda x: x * 2) == validation


# Generated at 2022-06-21 19:50:38.261114
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('test').to_either() == Right('test')
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-21 19:50:44.578339
# Unit test for constructor of class Validation
def test_Validation():
    success = Validation(12, [])
    fail = Validation(1, ['error'])
    assert success == Validation.success(12)
    assert fail == Validation.fail(['error'])


# Generated at 2022-06-21 19:50:57.345791
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    # Arrange
    from pymonet.maybe import Maybe

    # Act
    result_fail = Validation.fail(['some error']).to_maybe()
    result_success = Validation.success(1).to_maybe()

    # Assert
    assert result_fail == Maybe.nothing()
    assert result_success == Maybe.just(1)


# Generated at 2022-06-21 19:50:59.603541
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation(42, ['error1'])
    assert str(validation) == "Validation.fail[42, ['error1']]"



# Generated at 2022-06-21 19:51:01.023454
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(1, [])
    assert validation.value == 1



# Generated at 2022-06-21 19:51:04.789656
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.validation import Validation

    assert Validation.success('a').map(lambda letter: letter + 'b') == Validation.success('ab')
    assert Validation.success(None).map(lambda letter: letter + 'b') == Validation.success(None)
    assert Validation.fail(['not found']).map(lambda letter: letter + 'b') == Validation.fail(['not found'])



# Generated at 2022-06-21 19:51:11.549659
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.maybe import Maybe

    x = Validation.success(1).__str__()
    y = 'Validation.success[1]'
    assert x == y, 'Expected "{}", but got "{}"'.format(y, x)

    x = Validation.fail([1]).__str__()
    y = 'Validation.fail[None, [1]]'
    assert x == y, 'Expected "{}", but got "{}"'.format(y, x)


# Generated at 2022-06-21 19:51:20.447143
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Right, Left
    from pymonet.maybe import Just, Nothing
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def foo(x):
        return Right(x)

    def bar(x):
        return Left(x)

    assert foo(1).to_maybe() == Just(1)
    assert bar(1).to_maybe() == Nothing()
    assert foo(1).to_lazy() == Lazy(lambda: 1)
    assert foo(1).to_try() == Try(1, is_success=True)
    assert bar(1).to_try() == Try(1, is_success=False)
    assert Validation.success(1).to_maybe() == Just(1)

# Generated at 2022-06-21 19:51:23.300672
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    assert Validation(1, []).is_success() == True
    assert Validation(1, [1]).is_success() == False


# Generated at 2022-06-21 19:51:29.063071
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(10).to_either() == Right(10)
    assert Validation.success(10).to_either() != Left([10])

    assert Validation.fail(errors=[10, 20, 30]).to_either() == Left([10, 20, 30])
    assert Validation.fail(errors=[10, 20, 30]).to_either() != Right(None)


# Generated at 2022-06-21 19:51:31.713398
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    _is_success = Validation('test', [0, 1]).is_success()
    assert _is_success == False

    _is_success = Validation('test', []).is_success()
    assert _is_success == True



# Generated at 2022-06-21 19:51:37.041361
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover

    from pymonet.maybe import Maybe, Just, Nothing

    assert Validation.success('foo').to_maybe() == Just('foo')
    assert Validation.success(None).to_maybe() == Just(None)
    assert Validation.fail('bar').to_maybe() == Nothing()


# Generated at 2022-06-21 19:51:54.654016
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success(1).to_lazy()
    assert lazy.get() == 1
    assert lazy.eval() == 1
    assert lazy.get() == 1


# Generated at 2022-06-21 19:51:59.759822
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test successful call of method to_lazy of class Validation"""
    value = 10
    expected_value = value
    validation = Validation.success(value)
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value == expected_value


# Generated at 2022-06-21 19:52:01.831255
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(1, []).to_box() == Box(1)


# Generated at 2022-06-21 19:52:04.805901
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.success(None).is_success() == True
    assert Validation.fail([1, 2]).is_success() == False


# Generated at 2022-06-21 19:52:08.496711
# Unit test for method ap of class Validation
def test_Validation_ap():
    def folder(value):
        if value:
            return Validation.success("OK")
        return Validation.fail("Fail")

    assert Validation.success("OK").ap(folder) == Validation.success("OK")

    assert Validation.fail("Fail").ap(folder) == Validation.fail("Fail")


# Generated at 2022-06-21 19:52:11.854557
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    try_ = Try(1, is_success=True)
    validation = Validation.success(1)

    assert validation.to_try() == try_

# Generated at 2022-06-21 19:52:19.803947
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation.ap must append new errors list.
    """
    assert Validation.success(1) \
        .ap(lambda x: Validation.success(2)) == Validation.success(2)

    assert Validation.success(1) \
        .ap(lambda x: Validation.fail(['error'])) \
        .ap(lambda x: Validation.fail(['error2'])) == Validation.fail(['error', 'error2'])



# Generated at 2022-06-21 19:52:29.079718
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    def function(value):
        if value:
            return Validation.success()
        return Validation.fail(['test'])

    assert Validation.fail(['test1']).bind(function) == Validation.fail(['test1'])
    assert Validation.success().bind(function) == Validation.success()
    assert Validation.fail(['test']).bind(function) == Validation.fail(['test'])

    def function(value):
        return Validation.success(value)

    assert Validation.success(0).bind(function) == Validation.success(0)
    assert Validation.success(1).bind(function) == Validation.success(1)
    assert Validation.fail(['test']).bind(function) == Validation.fail(['test'])



# Generated at 2022-06-21 19:52:32.779854
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    # GIVEN
    from pymonet.box import Box
    validation = Validation(100, [])

    # WHEN
    result = validation.to_box()

    # THEN
    assert result == Box(100)


# Generated at 2022-06-21 19:52:36.169463
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test Validation to Try when Validation is success.
    """
    assert Validation.success("value").to_try() == Try("value", is_success=True)



# Generated at 2022-06-21 19:52:55.665425
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    assert Validation.success(10).to_either() == Right(10)
    assert Validation.fail(['Error']).to_either() == Left(['Error'])


# Generated at 2022-06-21 19:52:59.407052
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, [2, 3])) == 'Validation.fail[1, [2, 3]]'



# Generated at 2022-06-21 19:53:04.425919
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Testing method map of class Validation
    """
    # Success map
    assert Validation.success(21).map(lambda x: x * 2) == Validation(42, [])

    # Fail map
    assert Validation.fail([1, 2]).map(lambda x: x * 2) == Validation(None, [1, 2])



# Generated at 2022-06-21 19:53:06.996991
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2]).to_box() == Box(None)

# Generated at 2022-06-21 19:53:10.343409
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.fail(["error1", "error2"]).to_try() == Try(None, is_success=False)
    assert Validation.success(123).to_try() == Try(123, is_success=True)



# Generated at 2022-06-21 19:53:14.814247
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.monad_try import Failure, Success
    from pymonet.optional import NoneOption, SomeOption
    from pymonet.lazy import Lazy
    from pymonet.maybe import Nothing, Just

    assert (Validation.success(4).to_box() ==
            Box(4))
    assert (Validation.fail([1, 2, 4]).to_box() ==
            Box(None))


# Generated at 2022-06-21 19:53:18.932619
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:53:22.239213
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1).is_success()
    assert not Validation.success(1).is_fail()
    assert not Validation.fail(1).is_success()
    assert Validation.fail(1).is_fail()


# Unit tests for map

# Generated at 2022-06-21 19:53:33.946721
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    # Case 1: successful Validation
    validation = Validation.success(1)
    assert validation.is_success() is True, 'Expected Validation.success(1) to be successful'
    assert validation.is_fail() is False, 'Expected Validation.success(1) to not be fail'
    assert validation.value is 1, 'Expected value to be 1 but got ' + str(validation.value)
    assert len(validation.errors) == 0, 'Expected errors list length to be 0 but got ' + str(len(validation.errors))

    # Case 2: failed Validation
    errors = [1]
    validation = Validation.fail(errors)
    assert validation.is_success() is False, 'Expected Validation.fail(...) to not be successful'

# Generated at 2022-06-21 19:53:39.394749
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test Validation.to_box.

    :return: None
    """
    # WHEN
    val_fail = Validation.fail()
    val_succ = Validation.success(1)

    # THEN
    assert val_fail.to_box().is_fail
    assert val_succ.to_box().is_success
    assert val_succ.to_box().unbox() == 1



# Generated at 2022-06-21 19:54:13.689641
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert (str(Validation(3, [])) == 'Validation.success[3]')
    assert (str(Validation(2, [1])) == 'Validation.fail[2, [1]]')
    assert (str(Validation(None, [1])) == 'Validation.fail[None, [1]]')


# Generated at 2022-06-21 19:54:18.949285
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('value').to_either() == Right('value')
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])



# Generated at 2022-06-21 19:54:22.900557
# Unit test for constructor of class Validation
def test_Validation():
    assert(Validation(10, []) == Validation.success(10))
    assert(str(Validation.success(10)) == 'Validation.success[10]')
    assert(Validation(None, []) == Validation.fail())
    assert(str(Validation.fail()) == 'Validation.fail[None, []]')


# Generated at 2022-06-21 19:54:29.613763
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([2]).to_maybe() == Maybe.nothing()

    assert Either.of(1).to_maybe() == Maybe.just(1)
    assert Either.of(None).to_maybe() == Maybe.nothing()

    assert Maybe.of(1).to_maybe() == Maybe.just(1)
    assert Maybe.of(None).to_maybe() == Maybe.nothing()

    assert Box.of(1).to_maybe() == Maybe.just(1)
    assert Try.of(None, is_success=True).to_maybe() == Maybe

# Generated at 2022-06-21 19:54:38.328107
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.either import Left, Right

    validation = Validation.success(Right(4))
    assert str(validation) == 'Validation.success[Right(4)]'

    validation = Validation.success()
    assert str(validation) == 'Validation.success[None]'

    validation = Validation.fail([Left('foo'), Left('bar')])
    assert str(validation) == 'Validation.fail[None, [Left(foo), Left(bar)]]'

    validation = Validation.fail([Left('foo')])
    assert str(validation) == 'Validation.fail[None, [Left(foo)]]'



# Generated at 2022-06-21 19:54:45.528364
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """ test for method __eq__ of class Validation """
    success_val = Validation.success('value')
    eq_(success_val, Validation('value', []))

    fail_val = Validation.fail(['error 1', 'error 2'])
    eq_(fail_val, Validation(None, ['error 1', 'error 2']))

    is_true(success_val == Validation.success('value'))
    is_true(fail_val == Validation.fail(['error 1', 'error 2']))


# Generated at 2022-06-21 19:54:55.649112
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.functions import always
    assert Lazy(always(5)).map(lambda x: x + 1) == Lazy(always(6))
    assert Lazy(always(5)).bind(lambda x: Lazy(always(x + 1))) == Lazy(always(6))
    assert Validation.success(5).to_lazy().map(lambda x: x + 1) == Lazy(always(6))
    assert Validation.success(5).to_lazy().bind(lambda x: Lazy(always(x + 1))) == Lazy(always(6))
    assert Validation.fail().to_lazy().map(lambda x: x + 1) == Lazy(always(None))

# Generated at 2022-06-21 19:55:01.128456
# Unit test for method to_try of class Validation
def test_Validation_to_try():

    from pymonet.monad_try import Try

    assert Validation(2, []).to_try() == Try(2, is_success=Validation(2, []).is_success())
    assert Validation(None, [1]).to_try() == Try(None, is_success=Validation(None, [1]).is_success())


# Generated at 2022-06-21 19:55:04.220939
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([2, 3]).to_either() == Left([2, 3])


# Generated at 2022-06-21 19:55:07.808116
# Unit test for method bind of class Validation
def test_Validation_bind():
    def list_length(list):
        if len(list) == 0:
            return Validation.fail(list)
        return Validation.success(len(list))

    # empty list return failed validation
    assert Validation.success([]).bind(list_length).is_fail()

    # one element list will return successful validation
    assert Validation.success(['one']).bind(list_length).is_success()


# Generated at 2022-06-21 19:56:22.830012
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert (Validation.success().is_success() and
            Validation.success(None).is_success() and
            Validation.success(1).is_success() and
            not Validation.fail().is_success() and
            not Validation.fail([]).is_success() and
            not Validation.fail([1]).is_success()
    )


# Generated at 2022-06-21 19:56:28.748645
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation(30, [])
    new_validation = validation.ap(lambda x: Validation.success(x + 1))
    assert new_validation == Validation(30, [])

    validation = Validation(30, [])
    new_validation = validation.ap(lambda x: Validation.fail([11, 2]))
    assert new_validation == Validation(30, [11, 2])


# Generated at 2022-06-21 19:56:36.040936
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    It tests bind method of class Validation.
    """

    def add2(value):
        return Validation.success(value + 2)

    def double(value):
        return Validation.success(value * 2)

    def multiple(value):
        """Good"""
        return Validation.success(value * 3)

    # Valid Validation
    assert Validation.success(1).bind(add2).bind(double).bind(multiple) == Validation.success(12)

    # Valid Validation
    assert Validation.success(4).bind(add2).bind(double).bind(multiple) == Validation.success(24)


# Generated at 2022-06-21 19:56:38.855096
# Unit test for constructor of class Validation
def test_Validation():
    print('Test for constructor of class Validation')
    validation_success = Validation(1, [])
    assert validation_success.is_success(), 'Constructor for Validation should return successfully validation'
    validation_fail = Validation(None, ['test'])
    assert validation_fail.is_fail(), 'Constructor for Validation should return failed validation'


# Generated at 2022-06-21 19:56:41.512723
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('value').is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-21 19:56:48.462164
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.try_ import Try

    # Given
    value = 1
    validation = Validation.success(value)
    expected = Box(value)

    # When
    box = validation.to_box()

    # Then
    assert box == expected

    # Given
    value = None
    validation = Validation.fail(None)
    expected = Try.fail()

    # When
    box = validation.to_box()

    # Then
    assert box == expected



# Generated at 2022-06-21 19:56:56.681364
# Unit test for method bind of class Validation
def test_Validation_bind():
    def f(x):
        if x % 2 == 0:
            return Validation.success(x)
        return Validation.fail([x])

    assert Validation.success(4).bind(f).value == 4
    assert Validation.success(4).bind(f).errors == []

    assert Validation.success(5).bind(f).value == None
    assert Validation.success(5).bind(f).errors == [5]

    assert Validation.fail([1, 2, 3]).bind(f).value == None
    assert Validation.fail([]).bind(f).errors == []


# Generated at 2022-06-21 19:57:01.213853
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    validation = Validation.success(1)
    maybe = validation.to_maybe()
    assert isinstance(maybe, Maybe)
    assert maybe == Maybe.just(1)
    assert maybe is not Maybe.nothing()

    validation = Validation.fail([])
    maybe = validation.to_maybe()
    assert isinstance(maybe, Maybe)
    assert maybe == Maybe.nothing()
    assert maybe is Maybe.nothing()



# Generated at 2022-06-21 19:57:05.699105
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success('A').to_box() == Box('A')
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.success([]).to_box() == Box([])


# Generated at 2022-06-21 19:57:11.610103
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left
    from pymonet.validation import Validation

    def to_validation(value):
        return Validation.success(value)

    def to_left(value):
        return Left(value)

    assert Validation.success(2).ap(to_validation) == Validation.success(2)
    assert Validation.success(2).ap(to_validation).ap(to_validation) == Validation.success(2)
    assert Validation.success(2).ap(to_validation).ap(to_left) == Validation.fail(['error'])
