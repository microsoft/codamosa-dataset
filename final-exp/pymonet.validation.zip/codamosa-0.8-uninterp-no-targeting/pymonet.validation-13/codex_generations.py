

# Generated at 2022-06-21 19:47:20.428083
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation(1, []).to_either() == Right(1)
    assert Validation(1, [1]).to_either() == Left([1])
    assert Validation(None, [1]).to_either() == Left([1])
    assert Validation(None, [1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:47:23.357318
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.fail([3, 4]) == Validation(None, [3, 4])


# Generated at 2022-06-21 19:47:25.681947
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(10).map(lambda x: x + 1) == Validation.success(101)



# Generated at 2022-06-21 19:47:32.340477
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(1).to_either().map(lambda a: a + 2) == Right(3)


# Generated at 2022-06-21 19:47:37.452673
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.fail(['error1']).ap(
        lambda x: Validation.fail(['error2'])) == Validation.fail(['error1', 'error2'])

# Generated at 2022-06-21 19:47:46.860922
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    f = lambda x: x + 1

    assert Validation.success(1).map(f) == Validation.success(2)
    assert Validation.fail([2, 3]).map(f) == Validation.fail([2, 3])

    assert Validation.success(1).map(f) == Validation.success(2)
    assert Validation.fail([2, 3]).map(f) == Validation.fail([2, 3])

    assert Validation.success(1).map(f).to_either() == Right(2)

# Generated at 2022-06-21 19:47:52.666311
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    validation1 = Validation.success(1).ap(lambda x: Validation.fail([0]))
    assert validation1 == Validation.success(1)

    validation2 = Validation.success(1).ap(lambda x: Validation.success(2))
    assert validation2 == Validation.success(2)

    validation3 = Validation.fail([0]).ap(lambda x: Validation.fail([1]))
    assert validation3 == Validation.fail([0, 1])

    validation4 = Validation.fail([0]).ap(lambda x: Validation.success(2))
    assert validation4 == Validation.fail([0])


# Generated at 2022-06-21 19:47:57.528085
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 5) == Validation.success(5).to_lazy()

    v = Validation.fail(["a"])
    assert Lazy(lambda: v.value) == Validation.fail(["a"]).to_lazy()



# Generated at 2022-06-21 19:48:05.863340
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1).__eq__(object()) is False
    assert Validation.success(1).__eq__(1) is False
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']).__eq__(object()) is False
    assert Validation.fail(['error']).__eq__(['error']) is False
    assert Validation.success(1).__eq__(Validation.fail(['error'])) is False


# Generated at 2022-06-21 19:48:12.593802
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Check Validation string representation.
    """
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    # Success is represented as "Validation.success[<Value>]"
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(12)) == 'Validation.success[12]'
    assert str(Validation.success('12')) == "Validation.success['12']"
    assert str(Validation.success([1, 2, 3])) == 'Validation.success[[1, 2, 3]]'
    assert str(Validation.success({'a': 12})) == "Validation.success[{'a': 12}]"

# Generated at 2022-06-21 19:48:25.217218
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from nose.tools import istest, assert_equal

    @istest
    def should_print_success_value():
        from pymonet.validation import Validation

        assert_equal(
            str(Validation.success(1)),
            'Validation.success[1]'
        )

    @istest
    def should_print_fail_value():
        from pymonet.validation import Validation

        assert_equal(
            str(Validation.fail([1, 2])),
            'Validation.fail[None, [1, 2]]'
        )


# Generated at 2022-06-21 19:48:31.439543
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.success(1).to_maybe() != Maybe.nothing()
    assert Validation.fail([]).to_maybe() != Maybe.just(1)



# Generated at 2022-06-21 19:48:34.189247
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation('value', ['error'])
    assert str(validation) == 'Validation.fail[value, [\'error\']]'



# Generated at 2022-06-21 19:48:42.218486
# Unit test for method bind of class Validation
def test_Validation_bind():
    # arrange
    from pymonet.monad_list import List
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    def mapper(value):
        return List(value)

    def mapper2(value):
        return Left(value)

    def mapper3(value):
        return Try(value, is_success=True)

    validation = Validation.success(123)

    assert validation.bind(mapper) == List(123)
    assert validation.bind(mapper2) == Left(123)
    assert validation.bind(mapper3) == Try(123, is_success=True)


# Generated at 2022-06-21 19:48:45.647629
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    success_validation = Validation.success("foo")
    failure_validation = Validation.fail("bar")

    assert success_validation.to_either() == \
        Right("foo")
    assert failure_validation.to_either() == \
        Left("bar")

# Generated at 2022-06-21 19:48:50.025580
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success_validation = Validation.success()
    assert success_validation.is_success()

    fail_validation = Validation.fail()
    assert not fail_validation.is_success()


# Generated at 2022-06-21 19:48:54.035776
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert Validation.success(None).is_success()
    assert not Validation.fail([1, 2]).is_success()
    assert not Validation.fail([]).is_success()


# Generated at 2022-06-21 19:49:00.359524
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # GIVEN list of errors
    errors = ['a', 'b', 'c']

    # AND Validation with errors
    validation = Validation.fail(errors)

    # WHEN is_fail method on Validation with errors is called
    is_fail = validation.is_fail()

    # THEN is_fail should be True
    assert is_fail is True



# Generated at 2022-06-21 19:49:05.140876
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    # Validations to test
    valid = Validation.success(42)
    invalid = Validation.fail(['error'])

    # Check conversion to Try
    assert valid.to_try() == Try(42)
    assert invalid.to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:49:08.460679
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success('test').to_try() == Try('test')
    assert Validation.fail(['test']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:49:19.284951
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert isinstance(Validation.success(None), Validation)
    assert not isinstance(Validation.success(None), Validation)
    assert Validation.success().is_success()
    assert not Validation.success().is_fail()
    assert not Validation.fail().is_success()
    assert Validation.fail().is_fail()



# Generated at 2022-06-21 19:49:23.217992
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # Given
    v = Validation.success('value')

    # When
    result = str(v)

    # Then
    assert(result == 'Validation.success[value]')


# Generated at 2022-06-21 19:49:25.802270
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(123).to_either() == Right(123)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-21 19:49:30.931137
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-21 19:49:35.799782
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    # Success case:
    print('succes case')
    assert Validation.success(2) == Validation(2, [])
    print('success case done')
    print('fail case')
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['1']) == Validation(None, ['1'])
    print('fail case done')
    print('all test done')


# Generated at 2022-06-21 19:49:39.467632
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:49:41.418490
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('foo').is_success()
    assert not Validation.fail().is_success()



# Generated at 2022-06-21 19:49:46.157288
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(["my_error"]) == Validation(None, ["my_error"])


# Generated at 2022-06-21 19:49:50.359912
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success("foo").ap(Validation.success("bar")) == Validation.success("foo")
    assert Validation.fail("foo").ap(Validation.success("bar")) == Validation.fail("foo")


# Generated at 2022-06-21 19:49:53.688519
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    # GIVEN
    success = Validation.success(5)

    # WHEN
    maybe = success.to_maybe()

    # THEN
    assert maybe == Maybe.just(5)


# Generated at 2022-06-21 19:50:10.485809
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    assert Validation(1, []).to_try() == Try(1, is_success=True)
    assert Validation(1, [1, 2, 3]).to_try() == Try(1, is_success=False)

# Generated at 2022-06-21 19:50:15.661460
# Unit test for method ap of class Validation
def test_Validation_ap():
    def int_to_str(i):
        if i == 1:
            return Validation(str(i), [])
        return Validation(None, ['Int is invalid'])
    v = Validation.success(1).ap(int_to_str)
    assert v.value == '1'
    assert v.errors == []


# Generated at 2022-06-21 19:50:18.384968
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation_1 = Validation.fail(["error"])
    validation_2 = Validation.success("success")

    assert validation_1.is_fail()
    assert not validation_2.is_fail()

# Generated at 2022-06-21 19:50:25.689436
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    success_validation = Validation.success(1)
    assert success_validation.to_maybe() == Maybe.just(1)
    assert Maybe.just(1) == success_validation.to_maybe()

    fail_validation = Validation.fail()
    assert fail_validation.to_maybe().is_nothing()
    assert Maybe.nothing() == fail_validation.to_maybe()


# Generated at 2022-06-21 19:50:27.733226
# Unit test for method bind of class Validation
def test_Validation_bind():
    add = lambda a: a + 10
    assert Validation.success(10).bind(add) == Validation.success(20)


# Generated at 2022-06-21 19:50:38.800451
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():

    # Given
    v1 = Validation.success(1)
    v2 = Validation.success(1)
    v3 = Validation.fail([ValueError()])
    v4 = Validation.fail([ValueError()])
    v5 = Validation.success(2)
    v6 = Validation.success()
    v7 = Validation.fail([KeyError()])
    v8 = Validation.fail()

    # Then
    assert v1 == v1
    assert v1 == v2
    assert v3 == v3
    assert v3 == v4
    assert v1 != v3
    assert v2 != v3
    assert v1 != v5
    assert v1 != v6
    assert v2 != v6
    assert v4 != v5
    assert v4 != v6

# Generated at 2022-06-21 19:50:43.120438
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(1, [2]).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, []).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:50:52.120564
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    def add_1(x):
        return Validation.success(x + 1)

    def add_2(x):
        return Validation.success(x + 2)

    def validation_error():
        return Validation.fail(["Validation error"])

    assert Validation.success(1).ap(add_1) == Validation.success(2)
    assert Validation.success(1).ap(validation_error) == Validation.fail(["Validation error"])
    assert Validation.success(1).ap(add_1).ap(add_2) == Validation.success(4)
    assert Validation.fail(["Validation error"]).ap(add_1) == Validation.fail(["Validation error"])

# Generated at 2022-06-21 19:50:56.773889
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    __eq__ test

    :return: no return
    """
    assert Validation.success().__eq__(Validation.success())
    assert not Validation.success().__eq__(Validation.fail())
    assert not Validation.fail().__eq__(Validation.success())



# Generated at 2022-06-21 19:51:00.957373
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()

    assert Validation.success(5).is_success()
    assert not Validation.fail([1, 2, 3]).is_success()

    assert Validation.success([]).is_success()
    assert not Validation.fail(['test']).is_success()



# Generated at 2022-06-21 19:51:30.269965
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.monad_try import Try

    assert Validation(None, []) == Validation.fail()
    assert Validation(None, "test error") == Validation.fail("test error")
    assert Validation(1, []) == Validation.success(1)
    assert Validation(2, "test error") == Validation.success(2).ap(lambda x: Validation.fail([x]))
    assert Validation.success(1).ap(lambda x: Try(lambda: x+2)).to_maybe().get() == 3
    assert Validation.fail(1).ap(lambda x: Try(lambda: x+2)).to_maybe().is_nothing()


# Generated at 2022-06-21 19:51:41.753977
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left

    def divide(x):
        return Validation.success(x/3)

    def validate(y):
        from pymonet.either import Right, Left

        return Right(Try.failure(ZeroDivisionError())) if y == 0 else Right(Try.success(y))

    def validate_divide(x):
        return Validate(x).bind(divide).bind(validate)

    assert Validate(9).bind(divide) == Validation(3, [])
    assert Validate(0).bind(divide) == Validation(None, [ZeroDivisionError()])
    assert Validate(6).bind(validate_divide) == Validation(None, [ZeroDivisionError()])
    assert Val

# Generated at 2022-06-21 19:51:44.964636
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left

    assert Validation.success(Right(1)).bind(lambda x: Validation(x, [])) == Validation.success(Right(1))
    assert Validation.fail([1]).bind(lambda x: Validation(x, [])) == Validation.fail([1])



# Generated at 2022-06-21 19:51:56.332608
# Unit test for constructor of class Validation
def test_Validation():
    # Validation.success()
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(None) == Validation(None, [])
    assert Validation.success(None).get_value() == None

    # Validation.fail()
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])

    # is_success()
    assert Validation.success(1).is_success()
    assert not Validation.fail().is_success()

    #

# Generated at 2022-06-21 19:52:03.354043
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(41) == Validation.success(41)
    assert Validation.success(42) != Validation.success(41)
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]) != Validation.fail([1, 2])
    assert Validation.success(42) != Validation.fail([])


# Generated at 2022-06-21 19:52:11.544312
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    test_cases = [
        {'name': 'Validation.success has no errors',
         'input': Validation.success('success'),
         'expected': True},
        {'name': 'Validation.fail has errors',
         'input': Validation.fail(['error']),
         'expected': False},
    ]

    for i, test_case in enumerate(test_cases):
        test_message = 'Test nr: {nr} {name} input: {input}'.format(nr=i,
                                                                    name=test_case['name'],
                                                                    input=test_case['input'])
        assert test_case['input'].is_success() == test_case['expected'], test_message


# Generated at 2022-06-21 19:52:18.296296
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation(10, [])
    assert Validation.success(10) != Validation(11, [])
    assert Validation.fail([11]) != Validation(10, [])
    assert Validation.fail([11]) == Validation(None, [11])
    assert Validation.fail([11]) != Validation.fail([10])


# Generated at 2022-06-21 19:52:21.412647
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(2).to_try() == Success(2)
    assert Validation.fail([2]).to_try() == Failure([2])

# Generated at 2022-06-21 19:52:26.582443
# Unit test for constructor of class Validation
def test_Validation():
    """Test Validation constructor"""
    l = Validation.success(42)
    assert l.value == 42
    assert l.errors is not None
    assert l.errors == []

    l = Validation.fail(['err1', 'err2'])
    assert l.value == None
    assert l.errors is not None
    assert l.errors == ['err1', 'err2']



# Generated at 2022-06-21 19:52:29.135599
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.either import Left

    assert Validation.success('abc').is_success() == True
    assert Validation.success('abc').is_success() == True
    assert Validation.fail([456]).is_fail() == True


# Generated at 2022-06-21 19:53:20.610553
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.success(False).to_lazy() == Lazy(lambda: False)
    assert Validation.success(True).to_lazy() == Lazy(lambda: True)
    assert Validation.success('1').to_lazy() == Lazy(lambda: '1')


# Generated at 2022-06-21 19:53:33.783831
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    It tests methods:

    - Validation.bind
    """

    from pymonet.functor import Functor

    # Test for function that returns successful Validation
    def bind_function(value):
        return Validation.success(value * 2)

    validation = Validation.success(5)
    # Check that returned Validation is successful
    assert validation.bind(bind_function).value == 10

    # Test for function that returns failed Validation
    def bind_function(value):
        return Validation.fail([Functor('error')])

    validation = Validation.success(5)
    # Check that returned Validation has failed
    assert validation.bind(bind_function).errors[0] == Functor('error')

    # Test for function that returns empty failed Validation
    def bind_function(value):
        return Validation

# Generated at 2022-06-21 19:53:37.101555
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(123).is_success()
    assert Validation.fail().is_success() is False
    assert Validation.fail(['error']).is_success() is False


# Generated at 2022-06-21 19:53:48.901663
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Right, Left

    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([]) == Validation.fail([])

    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1, '1']) != Validation.fail([])

    assert Validation.success(1) != Validation.fail([])
    assert Validation.success(1) != Validation.fail([1, '1'])

    assert Validation.fail([]) != Validation.success(1)
    assert Validation.fail([1, '1']) != Validation.success(1)

    assert Validation.success(1) != Right(1)
    assert Validation.fail([1, '1']) != Right(1)

# Generated at 2022-06-21 19:53:56.794304
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Successful bind method test
    """
    def folder(value):
        """
        Unit test folder function that returns successful Validation with not None value
        """
        return Validation(value, [])

    valid_value = "test"
    assert Validation.success(valid_value).bind(folder).value == valid_value

    valid_value = 1
    assert Validation.success(valid_value).bind(folder).value == valid_value

    valid_value = {}
    assert Validation.success(valid_value).bind(folder).value == valid_value


# Generated at 2022-06-21 19:54:01.621023
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either
    from pymonet.maybe import Maybe

    validation = Validation.success()
    assert validation.to_either() == Either.right(None)

    validation = Validation.success(1)
    assert validation.to_either() == Either.right(1)

    validation = Validation.fail(['err1'])
    assert validation.to_either() == Either.left(['err1'])

    validation = Validation.fail(['err1', 'err2'])
    assert validation.to_either() == Either.left(['err1', 'err2'])


# Generated at 2022-06-21 19:54:05.158098
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.fail().map(lambda x: x) == Validation(None, [])



# Generated at 2022-06-21 19:54:08.825117
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map of class Validation.

    :returns: Nothing
    :rtype: None
    """
    assert Validation.success('x').map(lambda x: x + x) == Validation.success('xx')
    assert Validation.success('x').map(lambda _: None) == Validation.success(None)
    assert Validation.fail([1]).map(lambda x: x + x) == Validation.fail([1])
    assert Validation.success('x').map(lambda x: x + x).map(lambda x: x + x) == Validation.success('xxxx')


# Generated at 2022-06-21 19:54:12.271698
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.success(1) != Validation.fail([])


# Generated at 2022-06-21 19:54:24.049051
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """Unit test for method __eq__ of class Validation"""
    from pymonet.validation import Validation

    assert Validation.success() == Validation.success()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(2) != Validation.success(1)
    assert Validation.success() != Validation.success(2)

    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.fail(['err'])

    assert Validation.fail(['err']) != Validation.success()
    assert Validation.success() != Validation.fail(['err'])

    assert Validation.success(1) != None
    assert Validation.fail(['err']) != None



# Generated at 2022-06-21 19:56:07.699233
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([]).to_lazy()

# Generated at 2022-06-21 19:56:10.948078
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([2, 3]).to_either() == Left([2, 3])


# Generated at 2022-06-21 19:56:13.434666
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()



# Generated at 2022-06-21 19:56:17.476980
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success([1, 2, 3]).to_box() == Box([1, 2, 3])
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.fail(['error1', 'error2']).to_box() == Box(None)


# Generated at 2022-06-21 19:56:22.654466
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Success Validation calling bind returns Success Validation
    def f(x):
        return Validation.success(x + 1)
    assert Validation.success(1).bind(f) == Validation.success(2)

    # Fail Validation calling bind returns Fail Validation
    def f(x):
        return Validation.success(x + 1)
    assert Validation.fail([1]).bind(f) == Validation.fail([1])


# Generated at 2022-06-21 19:56:32.517013
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    failure_monad = Validation.fail(['Err'])

    def mapper(x):
        return Validation.success()

    assert Validation.success(None).ap(mapper) == Validation.success()
    assert Validation.fail([]).ap(mapper) == Validation.fail([])
    assert Validation.success(None).ap(failure_monad) == Validation.fail(['Err'])
    assert Validation.fail(['Err']).ap(failure_monad) == Validation.fail(['Err', 'Err'])
    assert Validation.fail([]).ap(failure_monad) == Validation.fail(['Err'])

# Generated at 2022-06-21 19:56:34.877755
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test to_either method.
    """
    from pymonet.either import Left, Right

    assert Validation.success(10).to_either() == Right(10)
    assert Validation.success().to_either() == Right(None)
    assert Validation.fail([10]).to_either() == Left([10])


# Generated at 2022-06-21 19:56:46.347230
# Unit test for method ap of class Validation
def test_Validation_ap():
    '''
    Test monad Validation. Function Validation.ap is tested.
    '''

    def folder(x):
        '''
        Function takes value and returns Validation
        '''
        if x == 1:
            return Validation(1, ['1'])
        elif x == 2:
            return Validation.success()
        else:
            return Validation(x, [])

    val = Validation(1, ['1'])
    assert val.ap(folder) == Validation(1, ['1'])

    val = Validation(2, ['1'])
    assert val.ap(folder) == Validation(2, [])

    val = Validation(2, ['2'])
    assert val.ap(folder) == Validation(2, ['2'])


# Generated at 2022-06-21 19:56:48.267433
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() is False
    assert Validation.fail().is_fail() is True


# Generated at 2022-06-21 19:56:56.478937
# Unit test for method ap of class Validation
def test_Validation_ap():
    def fn(value):
        return Validation('', ['error'])

    assert(Validation.success('').ap(fn)) == Validation('', ['error'])
    assert(Validation.success('value').ap(fn)) == Validation('value', ['error'])
    assert(Validation.fail(['error1']).ap(fn)) == Validation(None, ['error1', 'error'])
    assert(Validation.fail(['error1', 'error2']).ap(fn)) == Validation(None, ['error1', 'error2', 'error'])
