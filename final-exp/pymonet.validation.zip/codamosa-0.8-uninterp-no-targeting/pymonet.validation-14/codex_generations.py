

# Generated at 2022-06-21 19:47:15.418222
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right

    assert Validation.fail().to_either() == Left([])
    assert Validation.fail('error').to_either() == Left(['error'])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])
    assert Validation.success().to_either() == Right(None)
    assert Validation.success(2).to_either() == Right(2)
    assert Validation.success([1, 2]).to_either() == Right([1, 2])


# Generated at 2022-06-21 19:47:19.032039
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Maybe.just(1).to_validation().to_maybe() == Maybe.just(1)
    assert Maybe.nothing().to_validation().to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:47:24.043222
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test function to_box of class Validation
    """
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-21 19:47:30.357052
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    # Success validation
    validation = Validation.success("test")
    assert validation.to_try().is_success()
    assert validation.to_try().monad_value() == "test"

    # Failed validation
    validation = Validation.fail(["error"])
    assert not validation.to_try().is_success()
    assert validation.to_try().monad_value("default") == "default"


# Generated at 2022-06-21 19:47:35.827761
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    # When Error is list with errors
    assert Validation.fail(["error1", "error2"]).to_try() == Try(["error1", "error2"], is_success=False)

    # When Error is empty list
    assert Validation.fail().to_try() == Try(is_success=False)

    # When Value is None
    assert Validation.success().to_try() == Try(is_success=True)

    # When Value is not None
    assert Validation.success(123).to_try() == Try(123, is_success=True)


# Generated at 2022-06-21 19:47:42.149412
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either

    assert Validation(1, []).to_either() == Either.right(1)
    assert Validation(1, [1]).to_either() == Either.left([1])
    assert Validation.fail([1]).to_either() == Either.left([1])
    assert Validation.success(1).to_either() == Either.right(1)


# Generated at 2022-06-21 19:47:47.204228
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(42).to_either() == Right(42)
    assert Validation.fail('error').to_either() == Left('error')


# Generated at 2022-06-21 19:47:54.706650
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    v = Validation.success(10)
    m = v.to_maybe()
    assert m == Maybe.just(10)
    v = Validation.fail([])
    m = v.to_maybe()
    assert m == Maybe.nothing()


# Generated at 2022-06-21 19:47:57.314054
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.success() == Validation(None, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['Parse error']) == Validation(None, ['Parse error'])


# Generated at 2022-06-21 19:48:02.210947
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation('abc', [1, 2, 3, 4])
    assert validation.__str__() == 'Validation.fail[abc, [1, 2, 3, 4]]'

    validation = Validation('abc', [])
    assert validation.__str__() == 'Validation.success[abc]'


# Generated at 2022-06-21 19:48:06.699618
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[123]' == str(Validation.success(123))
    assert 'Validation.fail[None, [1, 2]]' == str(Validation.fail([1, 2]))


# Generated at 2022-06-21 19:48:09.935440
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success().to_either() == Right(None)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-21 19:48:14.095970
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Preparation
    from pymonet.list import List

    def folder(value):
        return Validation.success(List(value * 2))

    # Test
    assert Validation.success(5).bind(folder) == Validation.success(List([5 * 2]))


# Generated at 2022-06-21 19:48:18.039226
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation.success(1)
    assert Validation(None, ['error1', 'error2']) == Validation.fail(['error1', 'error2'])


# Generated at 2022-06-21 19:48:22.092903
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    instance = Validation(1, [])
    assert Lazy(lambda: 1) == instance.to_lazy()


# Generated at 2022-06-21 19:48:24.913382
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    assert Validation.success([1, 2]).to_lazy().run().call() == [1, 2]
    assert Validation.fail([1, 2]).to_lazy().run().call() is None


# Generated at 2022-06-21 19:48:27.831769
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2]).to_box() == Box(None)


# Generated at 2022-06-21 19:48:30.510266
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert not Validation.fail(['error']).is_success()
    assert Validation.success().is_success()


# Generated at 2022-06-21 19:48:34.858773
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.fail([]).to_try() == Failure(None)
    assert Validation.fail([1]).to_try() == Failure(None)

# Generated at 2022-06-21 19:48:36.980974
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(10).is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-21 19:48:43.655907
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['Invalid']).to_either() == Left(['Invalid'])


# Generated at 2022-06-21 19:48:49.163352
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    def fn_success(value):
        return Validation(value, [])

    def fn_fail(value):
        return Validation(value, ['test error'])

    assert Validation.success('test value').ap(fn_success).value == 'test value'
    assert Validation.fail(['test error']).ap(fn_fail).value is None
    assert Validation.success('test value').ap(fn_success).errors == []
    assert Validation.fail(['test error']).ap(fn_fail).errors == ['test error']

# Generated at 2022-06-21 19:48:52.187410
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])


# Generated at 2022-06-21 19:48:55.611626
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(2) == Validation.success(2)
    assert Validation.success(2) != Validation.success(3)
    assert Validation.fail([]) != Validation.fail([1])
    assert Validation.fail([1]) == Validation.fail([1])


# Generated at 2022-06-21 19:48:58.650722
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    assert validation.to_lazy() == Lazy(lambda: 2)

# Generated at 2022-06-21 19:49:08.226950
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left
    from pymonet.monad_maybe import Just

    assert isinstance(Validation.success(), Validation)
    assert isinstance(Validation.success(5), Validation)
    assert Validation.success(5) == Validation(5, [])
    assert Validation.success(None) == Validation(None, [])
    assert Validation.success(Just(10)) == Validation(Just(10), [])
    assert Validation.success(Left(10)) == Validation(Left(10), [])

    assert isinstance(Validation.fail(), Validation)
    assert isinstance(Validation.fail([1]), Validation)
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])

   

# Generated at 2022-06-21 19:49:16.047631
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['Error']) == Validation(None, ['Error'])
    assert Validation.success(1).is_success()
    assert not Validation.fail([]).is_success()
    assert Validation.fail([]).is_fail()
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-21 19:49:21.477826
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation.
    """

    # Test is_fail of class Validation with error
    assert Validation.fail(['Error']).is_fail()

    # Test is_fail of class Validation without error
    assert not Validation.success('value').is_fail()


# Generated at 2022-06-21 19:49:26.336358
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.success(1).is_success() is True
    assert Validation.success(None).is_success() is True
    assert Validation.fail().is_success() is False
    assert Validation.fail('test').is_success() is False


# Generated at 2022-06-21 19:49:30.890566
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-21 19:49:42.552734
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:49:47.734372
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test function for Validation.map method
    """
    assert Validation.success(1).map(inc) == Validation.success(2)
    assert Validation.fail(['error']).map(inc) == Validation.fail(['error'])



# Generated at 2022-06-21 19:49:52.209383
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    validation = Validation.success('1')
    assert validation.to_box() == Box('1')

    validation = Validation.fail([1, 2, 3])
    assert validation.to_box() == Box(None)


# Generated at 2022-06-21 19:49:57.071399
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    success_validation = Validation.success("value")
    assert isinstance(success_validation.to_maybe(), Maybe)
    assert success_validation.to_maybe().get() == "value"

    fail_validation = Validation.fail(["error"])
    assert isinstance(fail_validation.to_maybe(), Maybe)
    assert not fail_validation.to_maybe().is_just()


# Unit tests for methods to_either and to_try of class Validation

# Generated at 2022-06-21 19:50:01.221755
# Unit test for method map of class Validation
def test_Validation_map():
    validation = Validation.success(1)

    assert validation.map(add_one) == Validation.success(2)

    validation = Validation.fail([])

    assert validation.map(add_one) == Validation.fail([])


# Generated at 2022-06-21 19:50:02.842704
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for method ap"""

    result = Validation.fail(['error']).ap(lambda _: Validation(10, []))

    assert result == Validation(None, ['error'])

# Generated at 2022-06-21 19:50:07.436322
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False
    assert Validation.fail().is_fail() == True
    assert Validation.fail([1]).is_fail() == True


# Generated at 2022-06-21 19:50:12.163763
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(10).to_lazy() == Lazy(lambda: 10)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:50:15.988348
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(20).to_box() == Box(20)
    assert Validation.fail([10, 20, 30]).to_box() == Box(None)


# Generated at 2022-06-21 19:50:20.586548
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(32) == Validation.success(32)
    assert Validation.fail(['A']) == Validation.fail(['A'])
    assert Validation.success(32) != Validation.success(17)
    assert Validation.fail(['A']) != Validation.fail(['B'])



# Generated at 2022-06-21 19:50:40.652222
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(None, []).to_maybe() == Maybe.just(None)
    assert Validation(1, []).to_maybe() == Maybe.just(1)
    assert Validation(None, [1]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-21 19:50:44.361953
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    box = Validation.fail(['error-1', 'error-2']).to_box()
    assert isinstance(box, Box)
    assert box.value is None
    box = Validation.success(lambda x: x + 1).to_box()
    assert isinstance(box, Box)
    assert box.value == (lambda x: x + 1)


# Generated at 2022-06-21 19:50:47.987711
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success, Failure

    assert Validation.success(1).to_try() == Try(1, True)
    assert Validation.fail().to_try() == Try(None, False)


# Generated at 2022-06-21 19:50:57.757437
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    def _eq_a(a_1, a_2):
        return a_1 + a_2

    def _eq_b(a_1, a_2):
        return a_1 + a_2

    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) == Validation.fail([])
    assert Validation.success(1) == Validation.success(_eq_a(1, 0))
    assert Validation.success(1) != Validation.success(_eq_b(1, 0))
    assert Validation.success(1) != Validation.fail(_eq_b(1, 0))


# Generated at 2022-06-21 19:51:01.821688
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for to_lazy method of class Validation implementation.
    """
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:51:05.500050
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() == True
    assert Validation.fail(["error"]).is_fail() == True
    assert Validation.success("value").is_fail() == False


# Generated at 2022-06-21 19:51:12.115341
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.either import Either

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1]).to_try() != Try(1)

    assert Validation.success(1).to_either() == Either.right(1)
    assert Validation.fail([1]).to_either() == Either.left([1])



# Generated at 2022-06-21 19:51:17.273511
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right
    from pymonet.validations import Validation
    from pymonet.validations import Validation

    assert Validation.success(5).to_either() == Right(5)
    assert Validation.fail([1, 2, 3]).to_either().is_left()


# Generated at 2022-06-21 19:51:28.281418
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation1 = Validation.success('foo')
    validation2 = validation1.ap(lambda v: Validation.success(v * 2))
    assert validation2 == Validation.success('foofoo'), 'Ap of successful validation gives wrong result'

    validation1 = Validation.fail(['foo'])
    validation2 = validation1.ap(lambda v: Validation.success(v * 2))
    assert validation2 == Validation.fail(['foo']), 'Ap of failed validation gives wrong result'

    validation1 = Validation.success('foo')
    validation2 = validation1.ap(lambda v: Validation.fail(['bar']))
    assert validation2 == Validation.fail(['bar']), 'Ap of successful validation with failed validation gives wrong result'

    validation1 = Validation.fail(['foo'])
    validation2 = validation1

# Generated at 2022-06-21 19:51:34.868591
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test for method __eq__

    Test it with: nose2 -v tests.monads.test_validation
    """
    from nose2.tools import such

    with such.A('Validation __eq__ method') as it:
        @it.has_test_setup
        def setup():
            it.validation = Validation
            it.right = Validation.success(0)
            it.left = Validation.fail([1])
            it.right2 = Validation.success(0)
            it.left2 = Validation.fail([1])

        with it.having('__eq__ method'):

            @it.should('be equal to right monad')
            def test_eq_right():
                it.assertEqual(it.right, it.right2)


# Generated at 2022-06-21 19:52:11.464980
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]', 'Validation.success[1] should be string representation'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]', 'Validation.fail[None, [1, 2]] should be string representation'


# Generated at 2022-06-21 19:52:22.987159
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test method map of class Validation.
    """
    def validate_name(name):
        if name.find('a') != -1:
            return Validation.success(name)
        return Validation.fail(['name must contains a'])

    assert validate_name('aa').is_success() == True  # Validation should be successful
    assert validate_name('aa').values() == ['aa']

    assert validate_name('bb').is_fail() == True  # Validation should be fail
    assert validate_name('bb').errors() == ['name must contains a']

    assert validate_name('bb').map(lambda name: 'name: {}'.format(name)) == Validation('name: bb', ['name must contains a'])

# Generated at 2022-06-21 19:52:24.313666
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:52:27.816477
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(3).map(lambda x: x + 1) == Validation.success(4)
    assert Validation.fail(['error 1']).map(lambda x: x + 1) == Validation.fail(['error 1'])


# Generated at 2022-06-21 19:52:31.660038
# Unit test for method map of class Validation
def test_Validation_map():
    val_success = Validation.success("data")
    valmap_success = val_success.map(str)
    assert valmap_success == Validation("data", [])

    val_fail = Validation.fail(["foo", "bar"])
    valmap_fail = val_fail.map(str)
    assert valmap_fail == Validation(None, ["foo", "bar"])


# Generated at 2022-06-21 19:52:41.518995
# Unit test for constructor of class Validation
def test_Validation():
    """
    >>> test_Validation()
    Validation.success[2]
    Validation.fail[None, ['my_error']]
    # doctest: +IGNORE_EXCEPTION_DETAIL
    Traceback (most recent call last):
    ...
    ValueError: errors should be list, Error: <type 'exceptions.TypeError'>
    """

# Generated at 2022-06-21 19:52:45.660623
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success("Hello")) == "Validation.success[Hello]"
    assert str(Validation.fail(["error 1", "error 2"])) == "Validation.fail[None, ['error 1', 'error 2']]"


# Generated at 2022-06-21 19:52:48.861977
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert Validation.fail(['error1', 'error2']).is_fail()


# Generated at 2022-06-21 19:53:00.345055
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success([1, 2, 3]) == Validation([1, 2, 3], [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail(['abc', 23]) == Validation(None, ['abc', 23])
    assert Validation.fail() == Validation(None, [])

    assert Validation.success().is_success() is True

# Generated at 2022-06-21 19:53:03.881589
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    errors = ['error 1', 'error 2']
    validation1 = Validation(None, errors)
    assert(validation1.is_fail() == True)

    validation2 = Validation(None, [])
    assert(validation2.is_fail() == False)


# Generated at 2022-06-21 19:53:40.575999
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success = Validation.success('foo')
    assert success.is_success()

    fail = Validation.fail(['foo', 'bar'])
    assert not fail.is_success()


# Generated at 2022-06-21 19:53:45.585859
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    value = 'value'
    with_value = Validation(value, [])
    assert with_value.to_try() == Try(value)
    assert with_value.to_try().is_success()

    errors = ['error 1', 'error 2']
    with_errors = Validation(None, errors)
    assert with_errors.to_try() == Try(None)
    assert not with_errors.to_try().is_success()
    assert with_errors.to_try().exception == errors



# Generated at 2022-06-21 19:53:51.725153
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation(1, []).to_maybe() == Maybe.just(1)
    assert Validation(None, []).to_maybe() == Maybe.just(None)
    assert Validation(None, ['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:53:54.665732
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Lazy(lambda: 1)
    success = Validation.success(1)

    assert success.to_lazy() == lazy


# Generated at 2022-06-21 19:53:58.302433
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test if to_box method of Validation class works correctly.
    """
    from pymonet.box import Box

    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.success('foo').to_box() == Box('foo')


# Generated at 2022-06-21 19:54:06.323855
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])

    assert Validation.success(1).to_either().is_right()
    assert Validation.fail(['error']).to_either().is_left() is False

    assert Validation.success(1).to_either().value == 1
    assert Validation.fail(['error']).to_either().value == ['error']


# Generated at 2022-06-21 19:54:13.660677
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test for method map of class Validation.

    It compares two Validations which value equal to mapped by lambda of Validation.
    """
    from pymonet.validation import Validation
    from pymonet.validation import Validation as Validation

    result = Validation.fail().map(lambda x: x * 2)
    expected = Validation(None, [])
    assert result == expected, 'should be {}, but got {}'.format(expected, result)

    result = Validation.success(3).map(lambda x: x * 2)
    expected = Validation(6, [])
    assert result == expected, 'should be {}, but got {}'.format(expected, result)


# Generated at 2022-06-21 19:54:22.514986
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation(1, []).ap(lambda x: Validation(1, [])) == Validation(1, [])
    assert Validation(1, []).ap(lambda x: Validation(2, [2])) == Validation(1, [2])
    assert Validation(1, [1]).ap(lambda x: Validation(2, [2])) == Validation(1, [1, 2])
    assert Validation(1, [1]).ap(lambda x: Validation(2, [])) == Validation(1, [1])


# Generated at 2022-06-21 19:54:25.040074
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success = Validation.success("success")
    assert success.is_success() is True

    fail = Validation.fail(["fail"])
    assert fail.is_fail() is True


# Generated at 2022-06-21 19:54:30.671836
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Right
    validation_success_right = Validation.success(Right('Success'))
    validation_success_left = Validation.success(Right('Fail'))
    validation_fail_list = Validation.fail([])
    validation_fail_list_value = Validation.fail(['Fail'])

    def success_val(val):
        if val == 'Success':
            return Validation.success('Super')
        else:
            return Validation.fail([val])

    def fail_val(val):
        return Validation.fail(['Fail'])

    assert validation_success_right.ap(success_val) == Validation.success('Super')
    assert validation_success_right.ap(fail_val) == Validation.fail(['Fail'])

# Generated at 2022-06-21 19:55:55.765872
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    def transform_value(value):
        return Validation(value + 1, [])

    def transform_value_with_error(value):
        return Validation(value + 1, ['error'])

    assert Validation.success(5).ap(transform_value) == Validation(5, [])
    assert Validation.success(5).ap(transform_value_with_error) == Validation(5, ['error'])



# Generated at 2022-06-21 19:55:59.259505
# Unit test for constructor of class Validation
def test_Validation():
    # Test successful Validation
    assert Validation.success(2).value == 2
    assert Validation.success(2).errors == []

    # Test failed Validation
    assert Validation.fail(['error']).value is None
    assert Validation.fail(['error']).errors == ['error']


# Generated at 2022-06-21 19:56:10.741518
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Successful validation
    result = Validation.success(1).to_lazy()
    assert(isinstance(result, Lazy))
    assert(isinstance(result.value(), Try))
    assert(result.value().is_success())
    assert(result.value().value == 1)

    # Failed validation
    result = Validation.fail(['error']).to_lazy()
    assert(isinstance(result.value(), Try))
    assert(result.value().is_fail())
    assert(result.value().error() == ['error'])


# Generated at 2022-06-21 19:56:21.151601
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.monad_maybe import Maybe
    from pymonet.either import Left, Right

    valA = Validation.success(1).to_maybe().to_either().bind(lambda x: Right(x - 1))
    assert valA == Right(0)
    assert valA == Validation.success(0)

    valB = Maybe.just(1).bind(lambda x: Left.left(x - 1))
    assert valB != Validation.fail([1])
    assert valB == Validation.success(1)

    valC = Maybe.just(1).bind(lambda x: Left.left(x - 1))
    assert valC != Validation.success(1)
    assert valC == Validation.fail([1])

    valD = Validation.fail([1]).to_try()
    assert valD

# Generated at 2022-06-21 19:56:27.342676
# Unit test for method to_box of class Validation
def test_Validation_to_box():

    assert Validation.success(True).to_box() == Box(True)
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-21 19:56:31.121837
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation1 = Validation.success(5)
    assert validation1.to_box() == Box(5)

    validation2 = Validation.fail(5)
    assert validation2.to_box() == Box(None)


# Generated at 2022-06-21 19:56:38.408131
# Unit test for method bind of class Validation
def test_Validation_bind():
    def users_than_are_active(user):
        return Validation.success(user['active']) if 'active' in user else Validation.fail(['user not active'])

    def get_user_interests(user):
        if 'interest' in user:
            return Validation.success(user['interest'])
        return Validation.fail(['no interests'])

    def make_recommendations(interests):
        if len(interests) == 0:
            return Validation.fail(['nothings for you'])
        return Validation.success(interests)

    user = {
        'name': 'Adam',
        'active': True,
        'interest': ['sport', 'movies'],
    }


# Generated at 2022-06-21 19:56:43.578210
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation(2, []).to_try() == Try(2)
    assert Validation('error', ['error']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:56:45.637151
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(5).map(lambda x: x + 2) == Validation(7, [])


# Generated at 2022-06-21 19:56:49.040658
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    case_1 = Validation.success('hello')
    case_2 = Validation.fail(['hello'])

    assert case_1.to_box() == Box('hello')
    assert case_2.to_box() == Box(None)
