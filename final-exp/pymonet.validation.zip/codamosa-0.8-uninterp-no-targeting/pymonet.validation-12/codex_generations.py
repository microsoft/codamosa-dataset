

# Generated at 2022-06-21 19:47:29.407524
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation
    """
    assert Validation.fail(["Error 1"]) == Validation.fail(["Error 1"])
    assert Validation.success(["Value 1"]) == Validation.success(["Value 1"])
    assert Validation.fail(["Error 1"]) != Validation.fail(["Error 2"])
    assert Validation.success(["Value 1"]) != Validation.success(["Value 2"])

    assert Validation.fail(["Error 1"]) != Validation.success(["Value 1"])


# Generated at 2022-06-21 19:47:32.134367
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(123).to_either() == Right(123)
    assert Validation.fail(1).to_either() == Left(1)


# Generated at 2022-06-21 19:47:36.269290
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    try:
        raise Exception('Test')
        v = Validation.success(1)
    except:
        v = Validation.fail([Exception('Test')])

    u = Validation.success(2)

    assert not v.is_success()
    assert v.is_fail()
    assert v.to_try().is_success() == False
    assert v.to_try().errors == [Exception('Test')]

    assert u.is_success()
    assert not u.is_fail()
    assert u.to_try().is_success() == True
    assert u.to_try().value == 2


# Generated at 2022-06-21 19:47:41.625281
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(2, [1]).to_box() == Box(2)
    assert Validation.success(2).to_box() == Box(2)
    assert Validation.fail([1]).to_box() == Box(None)

# Generated at 2022-06-21 19:47:47.471751
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: x + 1) == Validation.success(3)
    assert Validation.fail(["Error"]).map(lambda x: x + 1) == Validation.fail(["Error"])


# Generated at 2022-06-21 19:47:53.582506
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Validation is success if error list are empty
    """
    assert Validation(None, []).is_success()
    assert not Validation(['1'], ['2']).is_success()


# Generated at 2022-06-21 19:48:06.301884
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # Success case
    val = Validation.success(1)
    assert val.bind(lambda x: Validation.success(x + 1).to_either()) == Right(2)
    assert val.bind(lambda x: Validation.success(x + 1).to_maybe()) == Maybe.just(2)
    assert val.bind(lambda x: Validation.success(x + 1).to_box()) == Box(2)
    assert val.bind(lambda x: Validation.success(x + 1).to_lazy()) == Lazy(lambda: 2)

# Generated at 2022-06-21 19:48:12.146905
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(42).to_either().is_right
    assert Validation.success(42).to_either().value == 42

    assert Validation.fail([CannotDivideByZero(), CannotDivideByNine()]).to_either().is_left
    assert Validation.fail([CannotDivideByZero(), CannotDivideByNine()]).to_either().value == [CannotDivideByZero(), CannotDivideByNine()]

    assert Validation.success(12).to_either() == Right(12)
    assert Validation.fail([42]).to_either() == Left([42])



# Generated at 2022-06-21 19:48:15.757739
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('value').value == 'value'
    assert Validation.fail(['error1', 'error2']).errors == ['error1', 'error2']


# Generated at 2022-06-21 19:48:19.285604
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1]).map(lambda x: x + 1) == Validation.fail([1])



# Generated at 2022-06-21 19:48:25.779815
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation.success(1)
    validation2 = Validation.success(2)
    validation3 = Validation.fail([3])
    validation4 = Validation.fail([4])
    validation5 = Validation.success(1)
    assert validation1 != validation2
    assert validation1 != validation3
    assert validation3 != validation4
    assert validation1 == validation5


# Generated at 2022-06-21 19:48:36.657721
# Unit test for method ap of class Validation
def test_Validation_ap():

    def t1(value):
        return Validation.success(value).ap(
            Validation.success(lambda x: x + 1)
        )

    assert t1(1) == Validation(2, [])
    assert t1(1).is_success()

    def t2(value):
        return Validation.success(value).ap(
            Validation.fail([1])
        )

    assert t2(1) == Validation(1, [1])
    assert t2(1).is_success()

    def t3(value):
        return Validation.fail([1]).ap(
            Validation.success(lambda x: x + 1)
        )

    assert t3(1) == Validation(None, [1])
    assert t3(1).is_fail()


# Generated at 2022-06-21 19:48:39.377212
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(9).to_try() == Try.success(9), "Should be the same"
    assert Validation.fail().to_try() == Try.fail(), "Should be the same"



# Generated at 2022-06-21 19:48:45.276484
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('value').is_fail() == False
    assert Validation.success(['value', 'value2']).is_fail() == False
    assert Validation.success({'key': 'value'}).is_fail() == False
    assert Validation.fail().is_fail() == True
    assert Validation.fail(['error']).is_fail() == True
    assert Validation.fail(['error', 'error']).is_fail() == True


# Generated at 2022-06-21 19:48:50.005039
# Unit test for method ap of class Validation
def test_Validation_ap():

    assert Validation(8, []).ap((lambda x: Validation(x + 1, ['x']))).value == 8
    assert Validation(9, ['x']).ap((lambda x: Validation(x + 1, ['x']))).value == 9
    assert Validation(9, ['x']).ap((lambda x: Validation(x + 1, ['x']))).errors == ['x', 'x']
    assert Validation(8, []).ap((lambda x: Validation(x + 1, ['x']))).errors == ['x']

# Generated at 2022-06-21 19:48:51.820849
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1]).is_fail()


# Generated at 2022-06-21 19:48:56.614785
# Unit test for method ap of class Validation
def test_Validation_ap():
    success = Validation.success('foo')
    fail = Validation.fail(['error1'])
    verify_fn = lambda value: Validation.fail(['error2'])

    assert success.ap(verify_fn) == Validation('foo', ['error2'])
    assert fail.ap(verify_fn) == Validation(None, ['error1', 'error2'])

# Generated at 2022-06-21 19:49:00.716739
# Unit test for method map of class Validation
def test_Validation_map():
    val = Validation.success(1)
    val2 = Validation.fail([2])
    assert val.map(lambda x: x * 2) == Validation.success(2)
    assert val2.map(lambda x: x * 2) == Validation.fail([2])


# Generated at 2022-06-21 19:49:03.884812
# Unit test for method map of class Validation
def test_Validation_map():
    def double(number):
        return number * 2

    validation = Validation.success(10)
    assert validation.map(double).value == 20

    # Nothing is done when Validation has errors
    validation = Validation.fail(['error'])
    assert validation.map(double).value is None



# Generated at 2022-06-21 19:49:07.861617
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success(True)) == 'Validation.success[True]'
    assert str(Validation.fail(['Something went wrong'])) == 'Validation.fail[None, [\'Something went wrong\']]'


# Generated at 2022-06-21 19:49:15.310134
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success([1, 2, 3, 4])) == 'Validation.success[[1, 2, 3, 4]]'
    assert str(Validation.fail(['First', 'Second'])) == 'Validation.fail[None, [\'First\', \'Second\']]'


# Generated at 2022-06-21 19:49:22.936776
# Unit test for method to_try of class Validation
def test_Validation_to_try():
   from pymonet.monad_try import Try
   from pymonet.validation import Validation
   from pymonet.utils import is_success

   assert Try(None, is_success=True) == Validation.success().to_try()
   assert Try(None, is_success=False) == Validation.fail().to_try()

   assert is_success(Validation.success().to_try())
   assert not is_success(Validation.fail().to_try())

# Generated at 2022-06-21 19:49:25.695204
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    # given
    val = Validation(1, [])

    # when
    maybe = val.to_maybe()

    # then
    assert maybe == Maybe.just(1)


# Generated at 2022-06-21 19:49:32.505516
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.success([])) == 'Validation.success[[]]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:49:37.158464
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:49:40.077094
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('foo').to_maybe() == Maybe.just('foo')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:44.244592
# Unit test for method map of class Validation
def test_Validation_map():
    # mapper return value when Validation is success
    def mapper(value):
        return '{} is success'.format(value)

    result = Validation.success('test').map(mapper)

    assert result == Validation(mapper('test'), [])


# Generated at 2022-06-21 19:49:54.233349
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1).to_box() != Box(2)
    assert Validation.success(1).to_box() == Validation.success(1).to_box()
    assert Validation.success(1).to_box() != Validation.success(2).to_box()
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1]).to_box() == Box(None)
    assert Validation.fail([]).to_box() == Validation.fail([2]).to_box()


# Generated at 2022-06-21 19:49:57.816126
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('foo').is_success() == True
    assert Validation.fail(['foo']).is_success() == False


# Generated at 2022-06-21 19:50:10.388593
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # Successful validation
    validation1 = Validation.success('Hello world!')
    validation2 = Validation.success('Hello world!')
    validation3 = Validation.fail(['error'])
    validation4 = Validation.fail(['error'])

    assert validation1 == validation2
    assert validation3 == validation4

    assert validation1 == 'Hello world!'
    assert validation1 != 'User input is not valid'

    assert validation1 == Right('Hello world!')
    assert validation1 != Right('User input is not valid')

    assert validation1 == Maybe.just('Hello world!')
    assert validation

# Generated at 2022-06-21 19:50:18.154687
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 4) == Validation.fail([]).to_lazy()
    assert Lazy(lambda: 4) == Validation.success(4).to_lazy()



# Generated at 2022-06-21 19:50:22.622731
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.fail(['err1', 'err2'])) == 'Validation.fail[None, [\'err1\', \'err2\']]'
    assert str(Validation.success('data')) == 'Validation.success[data]'


# Generated at 2022-06-21 19:50:27.909514
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error1'])) == 'Validation.fail[None, [\'error1\']]'
    assert str(Validation.success(1)) == 'Validation.success[1]'


# Generated at 2022-06-21 19:50:31.934259
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success().to_try() == Try.success(None)
    assert Validation.fail([1, 2]).to_try() == Try.fail([1, 2])


# Generated at 2022-06-21 19:50:33.182682
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail(["error"]).to_maybe() == Nothing()


# Generated at 2022-06-21 19:50:36.822752
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success(1)) == "Validation.success[1]"
    assert str(Validation.fail([1])) == "Validation.fail[None, [1]]"


# Generated at 2022-06-21 19:50:42.355853
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation_1 = Validation(1, [])
    validation_2 = Validation(2, [])
    validation_3 = Validation(1, ['error'])

    assert validation_1 == validation_1
    assert not (validation_1 != validation_1)

    assert validation_1 != validation_2
    assert not (validation_1 == validation_2)

    assert validation_1 != validation_3
    assert not (validation_1 == validation_3)


# Generated at 2022-06-21 19:50:48.050633
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    It tests method __eq__ of class Validation.

    ::
    """
    assert Validation(1, 2) == Validation(1, 2)
    assert Validation(1, 2) != Validation(1, 1)
    assert Validation(1, 2) != Validation(2, 2)
    assert Validation(1, 2) != 1


# Generated at 2022-06-21 19:50:57.849948
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.fail([1, 2, 3]).ap(lambda _: Validation.fail([3, 4])).to_try().get_errors() == [1, 2, 3, 3, 4]
    assert Validation.success(1).ap(lambda _: Validation.fail([3, 4])).to_try().get_errors() == [3, 4]
    assert Validation.fail([1, 2]).ap(lambda _: Validation.success(3)).to_try().get_errors() == [1, 2]
    assert Validation.success(2).ap(lambda _: Validation.success(3)).to_try().get() == 3


# Generated at 2022-06-21 19:51:00.361472
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation.success(1)
    assert Validation(None, ['error1', 'error2']) == Validation.fail(['error1', 'error2'])


# Generated at 2022-06-21 19:51:13.106428
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(10, []).to_maybe() == Maybe.just(10)
    assert Validation(None, [11, 22]).to_maybe() == Maybe.nothing()
    assert Validation(None, []).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:51:18.009588
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail(1) == Validation.fail(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail(1) != Validation.fail(2)


# Generated at 2022-06-21 19:51:24.558100
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test Validation.to_box() method.
    """
    assert Validation(None, []).to_box() == Box(None)
    assert Validation(7, []).to_box() == Box(7)
    assert Validation(3, [1, 2, 3]).to_box() == Box(3)
    assert Validation(None, [1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-21 19:51:31.286956
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    obj1 = Validation.fail(['error'])
    obj2 = Validation.fail(['another error'])
    obj3 = Validation.fail(['error'])

    assert obj1 == obj1
    assert obj1 == obj3
    assert obj2 != obj1

    obj1 = Validation.success('Haha')
    obj2 = Validation.success()
    obj3 = Validation.success('Haha')

    assert obj1 == obj1
    assert obj1 == obj3
    assert obj2 != obj1

    assert obj2 != 'a'


# Generated at 2022-06-21 19:51:34.610017
# Unit test for method map of class Validation
def test_Validation_map():
    """Unit test for map method of class Validation"""

    # Test for successful Validation
    add_ten = lambda x: x + 10
    validation = Validation.success(10)

    assert validation.map(add_ten) == Validation.success(20)

    # Test for faled validation
    validation = Validation.fail(['failed'])

    assert validation.map(add_ten) == Validation.fail(['failed'])


# Generated at 2022-06-21 19:51:38.406805
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    success_validation = Validation.success()
    assert success_validation.is_fail() is False

    fail_validation = Validation.fail()
    assert fail_validation.is_fail() is True


# Generated at 2022-06-21 19:51:42.131656
# Unit test for method map of class Validation
def test_Validation_map():
    assert (Validation.success(1).map(lambda x: x + 1) == Validation.success(2))
    assert (Validation.fail(['error1']).map(lambda x: x + 1) ==
            Validation.fail(['error1']))


# Generated at 2022-06-21 19:51:52.148206
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation monad unit test
    """
    from pymonet.validation import Validation

    def fail_fn(x):
        return Validation.fail([x])

    assert Validation.success(1).ap(fail_fn).errors == [1]
    assert Validation.success(1).ap(fail_fn).value == 1

    def success_fn(x):
        return Validation.success(x)

    assert Validation.success(1).ap(success_fn).errors == []
    assert Validation.success(1).ap(success_fn).value == 1

# Generated at 2022-06-21 19:51:55.665470
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('test')) == 'Validation.success[test]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-21 19:52:05.711098
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.maybe import Maybe
    from pymonet.either import Either

    success_validation = Validation.success(Maybe.just(2))
    assert success_validation == Validation(Maybe.just(2), [])
    assert success_validation.is_success() == True
    assert success_validation.to_either() == Either.right(Maybe.just(2))

    fail_validation = Validation.fail(['FAIL'])
    assert fail_validation == Validation(None, ['FAIL'])
    assert fail_validation.is_fail() == True
    assert fail_validation.to_either() == Either.left(['FAIL'])


# Generated at 2022-06-21 19:52:26.446144
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(42).to_box() == Box(42)
    assert Validation.fail('error').to_box() == Box(None)


# Generated at 2022-06-21 19:52:33.105996
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map of class Validation.
    """
    # pylint: disable=R0914
    def test_map(value, input_num, expected_result, expected_errors):
        """
        Unit test for map function.

        :param value: value to test
        :type value: A
        :param input_num: input number
        :type input_num: int
        :param expected_result: expected result
        :type expected_result: B
        :param expected_errors: expected errors
        :type expected_errors: List[E]
        """
        # Initialize validation
        validation = Validation(value, expected_errors)

        # Test map function
        result = validation.map(lambda v: v * 2)
        assert result == Validation(expected_result, expected_errors)

    test

# Generated at 2022-06-21 19:52:41.173435
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert_equal(Validation.success().bind(lambda x: Validation.fail('a')), Validation.fail('a'))
    assert_equal(Validation.fail().bind(lambda x: Validation.fail('b')), Validation.fail('b'))
    assert_equal(Validation.success('x').bind(lambda x: Validation.success('y')), Validation.success('y'))
    assert_equal(Validation.fail('x').bind(lambda x: Validation.success('y')), Validation.success('y'))


# Generated at 2022-06-21 19:52:46.874009
# Unit test for constructor of class Validation
def test_Validation():
    p = Validation(3, [])
    q = Validation(3, [])
    assert p == q
    assert Validation.success(3) == Validation(3, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.success(3) != Validation.fail([])
    assert Validation.success(3) != Validation.fail(["error"])


# Generated at 2022-06-21 19:52:50.009294
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(4).to_maybe() == Maybe.just(4)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:52:58.551170
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    def run(description, v, expected):
        assert expected == v.__str__(), description

    # Success case
    run('Should return Validation.success[value]', Validation('value', []),
        'Validation.success[value]')
    run('Should return Validation.success[None]', Validation(None, []),
        'Validation.success[None]')
    # Fail case
    run('Should return Validation.fail[value, errors]', Validation(None, ['error']),
        'Validation.fail[None, [\'error\']]')


# Generated at 2022-06-21 19:53:01.418669
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['fail1']).is_fail()
    assert not Validation.fail([]).is_fail()
    assert not Validation.success(123).is_fail()


# Generated at 2022-06-21 19:53:05.131073
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert(Validation.success(ValueError()).to_try() == Try.success(ValueError()))
    assert(Validation.fail([ValueError()]).to_try() == Try.failure(ValueError()))


# Generated at 2022-06-21 19:53:07.534481
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert_that(Validation.success(1).to_either(), is_(right(1)))
    assert_that(Validation.fail(errors=[1]).to_either(), is_(left([1])))



# Generated at 2022-06-21 19:53:10.302327
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.try_ import Success, Failure

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.fail([1]).to_try() == Failure([1])



# Generated at 2022-06-21 19:53:48.319153
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('').is_success() == True
    assert Validation.success(None).is_success() == True


# Generated at 2022-06-21 19:53:57.232783
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation(1, []) >> \
           (lambda val: Validation(2, [])) == Validation(2, [])
    assert Validation(1, []) >> \
           (lambda val: Validation(2, [1])) == Validation(2, [1])
    assert Validation(1, [1]) >> \
           (lambda val: Validation(2, [1])) == Validation(2, [1, 1])
    assert Validation(1, [1, 2]) >> \
           (lambda val: Validation(2, [1, 2])) == Validation(2, [1, 2, 1, 2])


# Generated at 2022-06-21 19:54:00.476021
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    is_instance = Validation.success('foo').to_lazy() == Lazy(lambda: 'foo')
    assert is_instance is True


# Generated at 2022-06-21 19:54:05.542762
# Unit test for method bind of class Validation
def test_Validation_bind():
    def folder(value):
        return Validation.success(value + 1)

    assert Validation.success(1).bind(folder) == Validation.success(2)
    assert Validation.fail(['error 1']).bind(folder) == Validation.fail(['error 1'])



# Generated at 2022-06-21 19:54:13.601736
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    def validate_data(data):
        if data is None:
            return Validation.fail(['Data must be set', 'Data is not set'])
        if data == 0:
            return Validation.fail(['Data must be larger than 0'])
        if data < 0:
            return Validation.fail(['Data must be positive'])

        return Validation.success(data)

    assert validate_data(None).to_try() == Failure(['Data must be set', 'Data is not set'])
    assert validate_data(0).to_try() == Failure(['Data must be larger than 0'])
    assert validate_data(1).to_try() == Success(1)


# Generated at 2022-06-21 19:54:18.851455
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    monad = Validation.success(2)
    assert monad.to_try().is_success()

    monad = Validation.fail([ValidationError('message')])
    assert monad.to_try().is_failure()


# Generated at 2022-06-21 19:54:21.995183
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assertValidationToMaybe(Validation.success(2),  Just(2))
    assertValidationToMaybe(Validation.fail([]), Just(None))


# Unit test helper for method to_maybe of class Validation

# Generated at 2022-06-21 19:54:26.326295
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test method to_maybe of class Validation.
    """
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success().to_maybe() == Maybe.just(None)
    assert Validation.fail(['error 1', 'error 2']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:54:29.145445
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(5).to_try() == Try(5, is_success=True)
    assert Validation.fail(5).to_try() == Try(5, is_success=False)


# Generated at 2022-06-21 19:54:34.044466
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test for method Validation.__str__()

    :returns: Nothing
    :rtype: None
    """
    assert str(Validation(42, [])) == 'Validation.success[42]'
    assert str(Validation(42, ['error'])) == 'Validation.fail[42, [\'error\']]'


# Generated at 2022-06-21 19:56:07.589074
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # Successful validation -> Right monad
    success_validation = Validation.success(1)
    assert success_validation.to_either() == Right(1)

    # Failed validation -> Left monad
    failed_validation = Validation.fail(['Error'])
    assert failed_validation.to_either() == Left(['Error'])



# Generated at 2022-06-21 19:56:16.409798
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda a: a + 2) != Validation(4, [])
    assert Validation.success(2).map(lambda a: a + 2) == Validation.success(4)
    assert Validation.success(2).map(lambda a: a - 2) == Validation.success(0)
    assert Validation.fail([1, 2, 3]).map(lambda a: a + 2) == Validation(None, [1, 2, 3])
    assert Validation.fail([1, 2, 3]).map(lambda a: a - 2) == Validation(None, [1, 2, 3])


# Generated at 2022-06-21 19:56:24.539342
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def f1(x):
        return Validation.success(lambda x: x + 1)

    def f2(x):
        return Validation.success(lambda x: x + 2)

    def f3(x):
        return Validation.fail([1, 2, 3])

    def f(x):
        return Validation.fail([3])

    def g(x):
        return Try(lambda y: x + y)

    # Validation.success.bind(f).bind(g)
    assert Validation.success(1).bind(f1).bind(g)(5) == Try(6)
    # Validation.success.bind(f).bind(f).bind(g)
    assert Validation.success(1).bind(f1).bind(f2).bind

# Generated at 2022-06-21 19:56:27.755626
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-21 19:56:36.679757
# Unit test for method bind of class Validation
def test_Validation_bind():
    print("Test for Validation.bind")
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Just, Nothing
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    def half(n):
        return Validation.success(n / 2)

    def lazy_half_value(n):
        return Lazy(lambda: n / 2)

    def lazy_half_function(n):
        return Lazy(lambda: half(n))

    def try_half(n):
        return Try(n / 2)

    def either_half(n):
        return Right(n / 2)

    def lazy_half(n):
        return Lazy(lambda: n / 2)


# Generated at 2022-06-21 19:56:39.378034
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    @lazy(return_type=Validation)
    def lazy_function(a):
        return Validation.success(a)

    assert lazy_function(5).to_lazy().force() == Validation.success(5)
    assert lazy_function(5).to_lazy().to_lazy().force() == Validation.success(5)


# Generated at 2022-06-21 19:56:42.338216
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    assert Validation.success('success').to_either() == Right('success')
    assert Validation.fail('error').to_either() == Left('error')


# Generated at 2022-06-21 19:56:52.711553
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    def test_success():
        from pymonet.monad_try import Try
        from pymonet.monad_type import Unit
        from pymonet.monad_try import Failure

        for value, is_success in zip([0, 1, 2, 3], [True, True, True, True]):
            assert Validation.success(value).to_try() == Try(value, is_success=is_success)
            assert Validation.success(value).to_try().is_success() == True

        assert Validation.success(Unit()).to_try() == Try(Unit(), is_success=True)
        assert Validation.success(Unit()).to_try().is_success() == True

    def test_fail():
        from pymonet.monad_try import Try

# Generated at 2022-06-21 19:56:58.047232
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[]' == str(Validation.success())
    assert 'Validation.success[42]' == str(Validation.success(42))
    assert 'Validation.fail[None, []]' == str(Validation.fail())
    assert 'Validation.fail[abc, [lorem, ipsum]]' == str(Validation.fail(['lorem', 'ipsum']))



# Generated at 2022-06-21 19:57:07.180841
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.functions import match
    from pymonet.lazy import Lazy
    from pymonet.either import Left
    from pymonet.box import Box

    def _mapper(value):
        return 2 * value

    assert Validation.success(2).map(_mapper).value == 4
    assert Validation.success(2).map(Lazy(_mapper)).value == 4
    assert Validation.success(2).map(Left(2)).to_either().value == 2
    assert Validation.success(2).map(Box(2)).to_box().value == 2

