

# Generated at 2022-06-21 19:47:17.041578
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False
    assert Validation.fail([1, 2, 3]).is_fail() == True


# Generated at 2022-06-21 19:47:25.023164
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def func():
        return 7

    lazy = Validation.success(7).to_lazy()
    assert lazy.to_string() == 'Lazy(function)'
    assert callable(lazy.value)
    assert lazy.value() == 7

    lazy = Validation.fail(['error']).to_lazy()
    assert lazy.to_string() == str(Lazy.nothing())
    assert not callable(lazy.value)
    assert lazy.value is None


# Generated at 2022-06-21 19:47:32.818114
# Unit test for method map of class Validation
def test_Validation_map():
    # GIVEN 2 Validations with success and fail value
    v1 = Validation.success('success')
    v2 = Validation.fail(['fail'])

    def rm_s(s):
        return s[1:]

    # WHEN map function that removes first letter is applied
    v1 = v1.map(rm_s)
    v2 = v2.map(rm_s)

    # THEN value of Validation is changed and errors did not
    assert v1 == Validation.success('uccess')
    assert v2 == Validation.fail(['fail'])



# Generated at 2022-06-21 19:47:44.468878
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    success_val = Validation.success()
    lazy_success_val = success_val.to_lazy()

    assert lazy_success_val.value() == success_val.value
    assert lazy_success_val.to_try() == Try(success_val.value)
    assert lazy_success_val.to_either() == success_val.to_either()

    fail_val = Validation.fail()
    lazy_fail_val = fail_val.to_lazy()

    assert lazy_fail_val.value() == fail_val.value
    assert Try(fail_val.value) == lazy_fail_val.to_try()
    assert fail_val.to_either() == lazy_fail_val.to_either()


# Generated at 2022-06-21 19:47:46.117292
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success('kappa')
    assert lazy.to_lazy() == Lazy(lambda: 'kappa')


# Generated at 2022-06-21 19:47:48.568320
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test when Validation is successful.
    """
    assert Validation.success(2).to_box() == Box(2)
    assert Validation.success(None).to_box() == Box(None)


# Generated at 2022-06-21 19:47:50.218206
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(None).is_success() and Validation.fail(None).is_fail()



# Generated at 2022-06-21 19:47:52.690358
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)



# Generated at 2022-06-21 19:47:55.939381
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-21 19:48:02.065413
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success(1)
    lazy_validation = validation.to_lazy()
    assert lazy_validation == Lazy(lambda: validation.value)
    assert lazy_validation.value() == Try(validation.value, is_success=validation.is_success())


# Generated at 2022-06-21 19:48:07.084047
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert Validation.fail([1]).is_fail()
    assert not Validation.success().is_fail()
    assert not Validation.success(1).is_fail()



# Generated at 2022-06-21 19:48:09.376549
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    actual_validation = Validation.success('data')
    actual_try = actual_validation.to_try()
    expected_try = Try.unit('data')

    assert actual_try == expected_try


# Generated at 2022-06-21 19:48:14.190487
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.utils import assert_equal

    lazy = Validation.success(1).to_lazy()
    assert isinstance(lazy, Lazy)
    assert_equal(lazy.evaluate(), 1)
    assert_equal(lazy.evaluate(), 1)


# Generated at 2022-06-21 19:48:18.136263
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(1, ['error1']).to_box() == Box(1)

# Generated at 2022-06-21 19:48:26.833839
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'

    assert Validation.success(10) == Validation.success(10)
    assert Validation.success(10) != Validation.fail([1, 2, 3])
    assert Validation.success(10) != Validation.success(20)

    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]) != Validation.fail([1, 2, 3, 4])


# Generated at 2022-06-21 19:48:32.845972
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(1) != Validation(0, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail([1]) != Validation(None, [42])
    assert Validation.success(42) == Validation(42, [])


# Generated at 2022-06-21 19:48:38.927413
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation.success(1)
    assert Validation(2, []) != Validation.success(1)
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, [1]) != Validation.fail([1])
    assert Validation(None, [2]) != Validation.fail([1])
    assert Validation([], []) == Validation([], [])
    assert Validation(None, []) != Validation(None, [1])


# Generated at 2022-06-21 19:48:44.240613
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    v1 = Validation.success(1)
    v2 = Validation.success(None)
    v3 = Validation.fail([])

    assert v1.to_maybe() == Maybe.just(1)
    assert v2.to_maybe() == Maybe.just(None)
    assert v3.to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:48:48.591829
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    success = Validation.success()
    assert success.to_maybe() == Maybe.just(None)

    fail = Validation.fail()
    assert fail.to_maybe() == Maybe.nothing()

    success = Validation(10, [])
    assert success.to_maybe() == Maybe.just(10)

    fail = Validation(10, ['error'])
    assert fail.to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:48:54.332620
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['1'])) == 'Validation.fail[None, [\'1\']]'


# Generated at 2022-06-21 19:49:01.520299
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.success().to_try() == Try(None)
    assert Validation.fail().to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:49:05.043597
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Define expected and actual
    expected = Validation(3, [])
    actual = Validation(3, []).ap(Validation(lambda x: x, []))

    # Assert expected and actual are equals
    assert expected == actual


# Generated at 2022-06-21 19:49:09.652693
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    val = Validation.success('value')
    assert val.to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-21 19:49:14.334118
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    success_case = Validation('success_value', [])
    assert success_case.to_box() == Box('success_value')

    fail_case = Validation(None, ['fail'])
    assert fail_case.to_box() == Box(None)

# Generated at 2022-06-21 19:49:25.108447
# Unit test for method ap of class Validation
def test_Validation_ap():
    def always_true(v):
        return Validation.success(v)

    def always_fail(v):
        return Validation.fail(["Error"])

    success = Validation.success()
    assert success.ap(always_true(1)) == Validation(1, [])
    assert success.ap(always_fail(1)) == Validation(None, ['Error'])

    fail = Validation.fail(["Error"])
    assert fail.ap(always_fail(1)) == Validation(None, ['Error', 'Error'])
    assert fail.ap(always_true(1)) == Validation(None, ['Error'])


if __name__ == '__main__':  # pragma: no cover
    test_Validation_ap()

# Generated at 2022-06-21 19:49:33.780350
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Right

    validation = Validation.success(Right(5))
    result = validation.map(lambda m: m.value ** 2)
    assert result == Validation(25, [])

    validation = Validation.fail(Right(5))
    result = validation.map(lambda m: m.value ** 2)
    assert result == Validation(None, [Right(5)])

    validation = Validation.success(None)
    result = validation.map(lambda m: m.value ** 2)
    assert result == Validation(None, [])


# Generated at 2022-06-21 19:49:36.779179
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(42)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: 42)

    validation = Validation.fail()
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: None)


# Generated at 2022-06-21 19:49:42.069869
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    from pymonet.list import List
    from pymonet.list import List
    from pymonet.list import Nil
    from pymonet.list import Cons

    with_errors = List.of(1, 2, 3)
    no_errors = List.of()

    with_errors_ap = Validation.fail(with_errors).ap(Validation.fail)
    assert with_errors_ap.is_fail()
    assert with_errors_ap.errors == [Nil, Cons(1, Cons(2, Cons(3, Nil)))]
    assert with_errors_ap.value is None

    no_errors_ap = Validation.fail(no_errors).ap(Validation.fail)
    assert no_errors_ap.is_fail()

# Generated at 2022-06-21 19:49:50.222595
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.value_objects import Validation
    from pymonet import curry

    @curry
    def add_one(a):
        return a + 1

    v1 = Validation.success(1)
    v2 = Validation.fail(["Error"])

    assert v1.map(add_one) == Validation(2, [])
    assert v2.map(add_one) == Validation(None, ["Error"])


# Generated at 2022-06-21 19:49:54.234893
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.success(1).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail([]).is_success()
    assert not Validation.fail(['test']).is_success()


# Generated at 2022-06-21 19:50:10.141314
# Unit test for constructor of class Validation
def test_Validation():
    def test_success_constructor():
        """Unit test for constructor of class Validation"""
        # Given
        value = 'Test'

        # When
        validation = Validation(value, [])

        # Then
        assert validation.is_success()
        assert validation.value == value

    def test_fail_constructor():
        """Unit test for constructor of class Validation"""
        # Given
        value = None
        errors = ['error']

        # When
        validation = Validation(value, errors)

        # Then
        assert validation.is_fail()
        assert validation.errors == errors

    test_success_constructor()
    test_fail_constructor()


# Generated at 2022-06-21 19:50:17.499243
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    v = Validation(5, [])
    e = v.to_either()

    assert e == Right(5), 'Validation.to_either() should return either monad with value'

    v = Validation(None, ['error0', 'error1'])
    e = v.to_either()

    assert e == Left(['error0', 'error1']), 'Validation.to_either() should return either monad with errors'


# Generated at 2022-06-21 19:50:22.304473
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.success(2) != Validation(4, [])
    assert Validation.success(2) != Validation(2, [3])
    assert Validation.fail([1, 2]) != Validation(2, [])



# Generated at 2022-06-21 19:50:27.587988
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.fail() == Validation(None, [])
    assert Validation.success() == Validation(None, [])
    assert Validation.fail(['error 1', 'error 2']) == Validation(None, ['error 1', 'error 2'])
    assert Validation.success(10) == Validation(10, [])


# Generated at 2022-06-21 19:50:38.216922
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation
    from pymonet.monad_try import Try

    def function_returning_success(a):
        return Validation.success(a)

    def function_returning_failed(a):
        return Validation.fail([1])

    assert Validation.success(1).ap(function_returning_success) == Validation.success(1)
    assert Validation.success(1).ap(function_returning_failed) == \
        Validation(value=1, errors=[1])

    assert Try(1).ap(function_returning_success).to_validation().errors[0].value is None
    assert len(Try(1).ap(function_returning_failed).to_validation().errors) == 0

# Generated at 2022-06-21 19:50:43.517952
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(2).is_success()
    assert not Validation.fail(['Error']).is_success()


# Generated at 2022-06-21 19:50:48.457525
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False
    assert Validation.success(None).is_fail() == False
    assert Validation.fail().is_fail() == True
    assert Validation.fail([1, 2]).is_fail() == True
    assert Validation.fail(["test"]).is_fail() == True


# Generated at 2022-06-21 19:50:53.865796
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    result = Try.success(10)
    assert Validation.success(10).to_try() == result

    result = Try.fail(None, [10])
    assert Validation.fail([10]).to_try() == result


# Generated at 2022-06-21 19:50:59.805804
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure as TryFailure

    validation = Validation(Try(4), [])

    assert validation.to_lazy().run() == Try(4)

    validation = Validation(TryFailure('err4'), [])

    assert validation.to_lazy().run() == TryFailure('err4')


# Generated at 2022-06-21 19:51:11.992994
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.fail([1, 2, 3]).to_either().is_left()
    assert Validation.fail([1, 2, 3]).to_either().is_not_left() is False
    assert Validation.fail([1, 2, 3]).to_either().is_right() is False
    assert Validation.fail([1, 2, 3]).to_either().is_not_right()
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])
    assert Validation.fail([1, 2, 3]).to_either() != Right([1, 2, 3])

    assert Validation.success(3).to_either().is_left() is False
    assert Validation.success(3).to_either().is_not_

# Generated at 2022-06-21 19:51:29.022251
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    success = Validation.success(1)
    assert success.to_try() == Try(1, is_success=success.is_success())
    assert Try(1, is_success=success.is_success()) == success.to_try()

    fail = Validation.fail([1, 2, 3])
    assert fail.to_try() == Try(None, is_success=fail.is_success())
    assert Try(None, is_success=fail.is_success()) == fail.to_try()


# Generated at 2022-06-21 19:51:30.914645
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    It tests method to_maybe of class Validation
    """

    from pymonet.maybe import Just, Nothing

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail([]).to_maybe() == Nothing()


# Generated at 2022-06-21 19:51:36.064213
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Validation.bind(Function(A) -> Validation[B, E]) -> Validation[B, E]
    """

    def f(x):
        """
        Function returns Validation.success(2)
        :rtype Validation[Int, List[String]]
        """
        return Validation.success(x * 2)

    success_value = Validation.success(1)
    assert success_value.bind(f) == Validation.success(2)

    def g(x):
        """
        Function returns Validation.fail(['error'])
        :rtype Validation[Int, List[String]]
        """
        return Validation.fail(['error'])

    fail_value = Validation.fail(['fail'])

# Generated at 2022-06-21 19:51:40.314764
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # no errors
    assert Validation(1, None).to_either() == Right(1)

    # with errors
    assert Validation(None, [1, 2, 3]).to_either() == Left([1, 2, 3])



# Generated at 2022-06-21 19:51:42.416802
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    assert Validation.success().is_success() == True
    assert Validation.fail().is_success() == False


# Generated at 2022-06-21 19:51:48.128896
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    # should return Box monad with value
    assert Validation.success(1).to_box() == Box(1)

# Unit tests for method to_lazy of class Validation

# Generated at 2022-06-21 19:51:55.265179
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right

    assert Validation.success(1).map(lambda x: x + 33) == Validation(34, [])
    assert Validation.success(1).map(Left([])) == Validation(Left([]), [])

    assert Validation.fail([]).map(lambda x: x + 33) == Validation(None, [])
    assert Validation.fail([]).map(Left([])) == Validation(Left([]), [])


# Generated at 2022-06-21 19:51:58.312002
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(3).to_box() == Box(3)
    assert Validation.fail('Foo').to_box() == Box(None)


# Generated at 2022-06-21 19:52:02.788617
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda a: a + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda a: a) == Validation.success(1)


# Generated at 2022-06-21 19:52:11.698314
# Unit test for method bind of class Validation
def test_Validation_bind():

    def add_three(value):
        return 3 + value

    def return_five(value):
        return Validation.success(5)

    def return_failure(value):
        return Validation.fail([1, 2, 3])

    assert Validation.success(10).bind(add_three) == Validation.success(13)
    assert Validation.success(10).bind(return_five) == Validation.success(5)
    assert Validation.success(10).bind(return_failure) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]).bind(add_three) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]).bind(return_five) == Validation.fail([1, 2, 3])


# Generated at 2022-06-21 19:52:38.091111
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    def test_success():
        value = Maybe(5)
        validation = Validation.success(value)
        assert(Box(value) == validation.to_box())

    def test_failure():
        value = Maybe.nothing()
        validation = Validation.fail(value)
        assert(Box(value) == validation.to_box())


# Generated at 2022-06-21 19:52:41.615112
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success(1).is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail([]).is_success() == False

    # Unit test for method is_fail of class Validation

# Generated at 2022-06-21 19:52:47.848824
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """ Unit test for method to_lazy of Validation

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    def _():
        """
        Returns True

        :returns: True
        :rtype: Boolean
        """
        return True

    _lazy = Validation.success().to_lazy()

    assert _lazy == Lazy(lambda: None), 'Validation.to_lazy() should return Lazy(lambda: None) when Validation is success'

# Generated at 2022-06-21 19:52:59.407032
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left
    from pymonet.fluent import Fluent
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.validation import Validation

    # Bind function is identity
    validate = Validation.fail(['first error', 'second error'])
    assert validate.bind(lambda _: validate) == validate

    # Bind function returns successful validation
    def map_function(value):
        return Validation.success('new_value')

    value = 'value'
    other_value = 'new_value'
    validate = Validation.success(value)
    assert validate.bind(map_function) == Validation.success(other_value)

    # Fluent map

# Generated at 2022-06-21 19:53:06.507958
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.fail()
    assert validation.to_try() == Try(None, is_success=False)
    assert validation.to_try().is_success() is False
    assert validation.to_try().is_fail() is True

    validation = Validation.success('pymonet')
    assert validation.to_try() == Try('pymonet', is_success=True)
    assert validation.to_try().is_success() is True
    assert validation.to_try().is_fail() is False

# Generated at 2022-06-21 19:53:12.081500
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test for method bind of class Validation.
    """

    def folder(v):
        from pymonet.monad_list import MonadList
        return MonadList.unit(v + v)

    success_validation = Validation.success(2)
    failed_validation = Validation.fail(['err1', 'err2'])

    assert MonadList(['4']) == success_validation.bind(folder)
    assert MonadList(['err1', 'err2']) == failed_validation.bind(folder)


# Generated at 2022-06-21 19:53:23.035341
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def function_that_returns_success():
        return 'success'

    def function_that_returns_fail():
        return 'fail'

    assert Validation.success('success').to_lazy().get_value() == 'success'
    assert Validation.fail().to_lazy().get_value() == None

    assert Validation.success(function_that_returns_success()).to_lazy().get_value() == 'success'
    assert Validation.success(function_that_returns_fail()).to_lazy().get_value() == 'fail'

    assert Validation.fail(function_that_returns_success()).to_lazy().get_value() == None
    assert Validation.fail(function_that_returns_fail()).to_lazy().get_value() == None



# Generated at 2022-06-21 19:53:26.790475
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True, "is_success method of Validation class works incorrectly"
    assert Validation.fail([1, 2]).is_success() is False, "is_success method of Validation class works incorrectly"


# Generated at 2022-06-21 19:53:36.208068
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    from pymonet.monad_try import Try

    success_validation = Validation(None, [])
    success_validation2 = Validation('some value', [])
    success_validation3 = Validation(None, ['some error'])
    fail_validation = Validation(None, ['some error'])
    fail_validation2 = Validation('some value', ['some error'])
    fail_validation3 = Validation(None, ['some error 1'])
    monad = Try(1)
    success_validation4 = Validation([], [])
    fail_validation4 = Validation([], ['some error 1', 'some error 2'])

    assert success_validation != fail_validation
    assert success_validation != monad

# Generated at 2022-06-21 19:53:38.659328
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-21 19:54:01.065001
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation
    validation = Validation(10, [])

    assert validation.to_lazy() == Lazy(lambda: 10)



# Generated at 2022-06-21 19:54:04.649175
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('Hey').is_fail() is False
    assert Validation.fail(['It is fail']).is_fail() is True


# Generated at 2022-06-21 19:54:09.376415
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation.
    """
    validation = Validation(1, [])
    assert validation.__str__() == 'Validation.success[1]'

    validation = Validation(2, [1, '22'])
    assert validation.__str__() == 'Validation.fail[2, [1, \'22\']]'

# Generated at 2022-06-21 19:54:10.543079
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try.success(1)

# Generated at 2022-06-21 19:54:15.262140
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(['Not Valid']).to_box() == Box(None)



# Generated at 2022-06-21 19:54:16.455160
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    return assert_equals(Validation(1, []).to_box(), Box(1))


# Generated at 2022-06-21 19:54:19.911829
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try[int](1)
    assert Validation.fail([1]).to_try() == Try[int](None)


# Generated at 2022-06-21 19:54:22.774037
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation_success = Validation(1, [])
    assert validation_success.is_success()

    validation_failure = Validation(1, [1])
    assert not validation_failure.is_success()


# Generated at 2022-06-21 19:54:29.545685
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    minus_one = lambda x: Validation.success(-1 if x == 0 else x)
    minus_two = lambda x: Validation.success(-2 if x == 0 else x)
    minus_three = lambda x: Validation.success(-3 if x == 0 else x)
    is_none = lambda x: Maybe.nothing() if x == 0 else Maybe.just(x)
    is_minus_one = lambda x: Right(-1 if x == 0 else x)
    is_minus_two = lambda x: Right(-2 if x == 0 else x)
    is_minus_three = lambda x: Right(-3 if x == 0 else x)

    assert Validation.success() == Validation.success()

# Generated at 2022-06-21 19:54:33.443169
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:55:18.609656
# Unit test for method map of class Validation
def test_Validation_map():
    def test_mapper(value):
        return value

    validation = Validation.success('value')
    mapped = validation.map(test_mapper)

    assert mapped == Validation('value', [])


# Generated at 2022-06-21 19:55:22.625067
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(3).to_lazy().value() == 3
    assert Validation.success(3).to_lazy().value() == 3
    assert Validation.fail([]).to_lazy().is_empty()


# Generated at 2022-06-21 19:55:26.539176
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    try:
        assert not Validation.success(1).is_fail()
        assert Validation.fail([1, 2, 3]).is_fail()
    except Exception as e:
        print('Test for method is_fail() of class Validation is fail.', e)
        return False

    print('Test for method is_fail() of class Validation is successful.')
    return True


# Generated at 2022-06-21 19:55:29.452845
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    success = Validation.success('A')
    assert Maybe.just('A') == success.to_maybe()

    fail = Validation.fail(['error'])
    assert Maybe.nothing() == fail.to_maybe()


# Generated at 2022-06-21 19:55:32.188735
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('test').is_success()
    assert False == Validation.fail('test').is_success()


# Generated at 2022-06-21 19:55:34.615865
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-21 19:55:42.851204
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test to_either method of Validation.

    :returns: nothing
    :rtype: None
    """
    valid_value = Validation.success(1)
    assert valid_value.to_either() == Right(1)
    assert valid_value.to_either().get_value() == 1
    invalid_value = Validation.fail(['error'])
    assert invalid_value.to_either() == Left(['error'])
    assert invalid_value.to_either().get_value() == ['error']
    assert not invalid_value.to_either().is_success()


# Generated at 2022-06-21 19:55:49.498885
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['fail']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:55:52.847338
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def get_lazy():
        return Validation.fail([1, 2]).to_lazy()

    assert get_lazy().value() == None
    assert isinstance(get_lazy(), Lazy)


# Generated at 2022-06-21 19:55:58.513395
# Unit test for method map of class Validation
def test_Validation_map():
    validation = Validation.success(42)
    mapped = validation.map(lambda x: x * 2)
    assert mapped == Validation(84, [])

    validation = Validation.fail(['error'])
    mapped = validation.map(lambda x: x * 2)
    assert mapped == Validation(None, ['error'])

    validation = Validation.fail(['error'])
    mapped = validation.map(lambda x: x * 2)
    assert mapped == Validation(None, ['error'])


# Generated at 2022-06-21 19:56:43.357320
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test Validation to_maybe method.
    """
    assert Validation.success(10).to_maybe() == Maybe.just(10)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:56:46.113911
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-21 19:56:53.314178
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(2).bind(lambda x: Validation.success(x * 2)) == Validation.success(4)
    assert Validation.success(3).bind(lambda x: Validation.fail(['Error'])) == Validation.fail(['Error'])
    assert Validation.fail(['Error']).bind(lambda x: Validation.success(x * 2)) == Validation.fail(['Error'])
    assert Validation.fail(['Error']).bind(lambda x: Validation.fail(['Error'])) == Validation.fail(['Error'])


# Generated at 2022-06-21 19:56:56.964868
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(5).to_either() == Right(5)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-21 19:56:59.400303
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # GIVEN
    validation = Validation.fail([1, 2, 3])

    # WHEN
    result = validation.is_fail()

    # THEN
    assert result is True



# Generated at 2022-06-21 19:57:01.817967
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    result = Validation.success(True).to_box()
    assert result == Box(True)



# Generated at 2022-06-21 19:57:06.435451
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test simple mapping success and fail Validation.
    """

    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation.fail(['error'])

# Generated at 2022-06-21 19:57:09.326280
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:57:13.547429
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    val_fail = Validation.fail([1, 2, 3])
    val_success = Validation.success()

    assert val_fail.is_fail() == True
    assert val_success.is_fail() == False