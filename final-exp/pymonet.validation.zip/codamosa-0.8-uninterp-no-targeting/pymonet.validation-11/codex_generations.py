

# Generated at 2022-06-21 19:47:23.625757
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation('value', [])) == 'Validation.success[value]'
    assert str(Validation('value', ['error_1', 'error_2'])) == 'Validation.fail[value, [\'error_1\', \'error_2\']]'



# Generated at 2022-06-21 19:47:27.375856
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() is True
    assert Validation.success(12).is_fail() is False
    assert Validation.fail(['err1', 'err2']).is_fail() is True


# Generated at 2022-06-21 19:47:30.129475
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_maybe import Maybe

    assert Validation.success([1, 2, 3]).ap(Maybe.just(lambda x: len(x))).value == 3

# Generated at 2022-06-21 19:47:32.145943
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-21 19:47:39.252570
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success('1').map(int) == Validation.success(1)
    assert Validation.success('1').map(lambda value: int(value) + 1) == Validation.success(2)
    assert Validation.fail(['error1', 'error2']).map(int) == Validation.fail(['error1', 'error2'])


# Generated at 2022-06-21 19:47:42.584033
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail('error').to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:47:46.861569
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:47:55.933658
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation.
    """
    # WHEN
    validation = Validation.success('value')

    # THEN
    assert str(validation) == 'Validation.success[value]'

    # WHEN
    validation = Validation.fail(['error'])

    # THEN
    assert str(validation) == 'Validation.fail[None, [\'error\']]'

# Generated at 2022-06-21 19:48:04.863040
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(3).bind(lambda x: Validation.success(x + 4)) == Validation.success(7)
    assert Validation.success(3).bind(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda x: Validation.success(x + 4)) == Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda x: Validation.fail(['error2'])) == Validation.fail(['error', 'error2'])


# Generated at 2022-06-21 19:48:07.939333
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Validation.success('value').to_maybe() == Maybe.just('value')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:48:12.047631
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    box = Validation.success('success').to_box()
    assert isinstance(box, Box)
    assert box.value == 'success'


# Generated at 2022-06-21 19:48:17.395229
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.identity import Identity
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:48:20.181731
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(5).is_fail() == False
    assert Validation.fail([5]).is_fail() == True


# Generated at 2022-06-21 19:48:24.920041
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    successful_validation = Validation.success(value=123)
    assert 'Validation.success[123]' == str(successful_validation)

    failed_validation = Validation.fail(errors=['error-1', 'error-2'])
    assert 'Validation.fail[None, [\'error-1\', \'error-2\']]' == str(failed_validation)



# Generated at 2022-06-21 19:48:31.536107
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Transformations to Maybe From Validation should return Maybe with stored value when Validation is successful
    and empty Maybe when Validation is unsuccessful.
    """
    from pymonet.maybe import Maybe

    assert Validation.success(3).to_maybe() == Maybe.just(3)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.fail([2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:48:39.572773
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Two Validations are equals when values and errors lists are equal.
    """
    # Test when two Validation instances with equal values and errors lists
    assert Validation.success(1) == Validation.success(1)

    # Test when two Validation instances with not equal values and errors lists
    assert Validation.success(1) != Validation.success(2)

    # Test when two Validation instances with equal values and not equal errors lists
    assert Validation.fail([1, 2, 3]) != Validation.fail([1, 2, 3, 4])

    # Test when two Validation instances with not equal values and errors lists
    assert Validation.success(1) != Validation.fail([1, 2, 3])



# Generated at 2022-06-21 19:48:44.441894
# Unit test for method map of class Validation
def test_Validation_map():
    validation = Validation.success('Hello world!')
    mapper_function = lambda string: len(string)
    new_validation = validation.map(mapper_function)
    assert mapper_function(validation.value) == new_validation.value
    assert validation.errors == new_validation.errors
    assert validation != new_validation


# Generated at 2022-06-21 19:48:50.985502
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left

    validation = Validation.fail([])
    assert validation.map(lambda x: x).is_fail()

    validation = Validation.success(True)
    assert validation.map(lambda x: x).is_success()

    validation = Validation.fail([])
    assert validation.map(lambda x: x).to_either() == Right(None)

    validation = Validation.success('value')
    assert validation.map(lambda x: x).to_either() == Right('value')

    validation = Validation.fail([])
    assert validation.map(lambda x: x).to_try().is_success()

    validation = Validation.success('value')
    assert validation.map(lambda x: x).to_try() == Try

# Generated at 2022-06-21 19:49:01.781625
# Unit test for method map of class Validation
def test_Validation_map():
    def add_one(a):
        return a + 1

    def add_two(a):
        return a + 2

    assert Validation.fail().map(add_one) == Validation(None, [])
    assert Validation.success(1).map(add_one) == Validation(2, [])
    assert Validation.success(1).map(add_two) == Validation(3, [])
    assert Validation.fail([1]).map(add_one) == Validation(None, [1])
    assert Validation.fail([1]).map(add_two) == Validation(None, [1])



# Generated at 2022-06-21 19:49:04.992603
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    # For successful Validation returned Box must contain Validation value
    val = Validation.success(10)
    assert val.to_box() == Box(val.value)

    # For failed Validation returned Box must contain Validation value
    val = Validation.fail('errors')
    assert val.to_box() == Box(val.value)


# Generated at 2022-06-21 19:49:18.477359
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for bind method of Validation.
    """
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.monad_list import List
    from pymonet.monad_dict import Dict
    from pymonet.monad_set import Set
    from pymonet.monad_tuple import Tuple


# Generated at 2022-06-21 19:49:22.980076
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():

    assert Validation.fail([]).is_fail()
    assert Validation.fail([1]).is_fail()
    assert not Validation.success([]).is_fail()
    assert not Validation.success([1]).is_fail()


# Generated at 2022-06-21 19:49:33.904928
# Unit test for method bind of class Validation
def test_Validation_bind():

    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    # Test functions
    def fn(value):
        return Try(value)

    def fn1(value):
        return List([value])

    def fn2(value):
        return Right(value)

    def fn3(value):
        return Left(value)

    # Tests
    assert Validation.success('a').bind(fn).value == Try.success('a').value
    assert Validation.success(1).bind(fn).value == Try.success(1).value
    assert Validation.success(1).bind(fn1).value == List.unit(1).value
    assert Validation.success([]).bind(fn1).value == List.unit([]).value

# Generated at 2022-06-21 19:49:43.317912
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    def run_test(value, is_success, either_fail, either_success):
        validation = Validation(value, []) if is_success else Validation(value, [1])
        result = validation.to_either()
        assert result.is_fail() == either_fail
        assert result.is_success() == either_success
        assert result.value == value

    run_test(None, False, True, False)
    run_test(1, False, True, False)
    run_test('', False, True, False)
    run_test(None, True, False, True)
    run_test(1, True, False, True)
    run_test('', True, False, True)


# Generated at 2022-06-21 19:49:51.167431
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test for method `__str__` of class Validation.
    """
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(123)) == 'Validation.success[123]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-21 19:49:53.929804
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success().to_either() == Right(None)
    assert Validation.success(12).to_either() == Right(12)
    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])


# Generated at 2022-06-21 19:50:00.989212
# Unit test for constructor of class Validation
def test_Validation():
    def monad_success(value):
        return Validation.success(value)
    def monad_fail(value):
        return Validation.fail(value)

    # Test successful constructor
    monad_success(1) == Validation(1, [])
    # Test failed constructor
    monad_fail(1) == Validation(None, [1])



# Generated at 2022-06-21 19:50:09.883605
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation((), [])) == 'Validation.success[None]'
    assert str(Validation((1, 2), [])) == 'Validation.success[(1, 2)]'
    assert str(Validation([1, 2], [])) == 'Validation.success[[1, 2]]'
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(None, [1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-21 19:50:13.611791
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Test method is_fail of class Validation"""
    assert bool(Validation.fail().is_fail()) is True
    assert bool(Validation.success().is_fail()) is False



# Generated at 2022-06-21 19:50:16.820726
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-21 19:50:21.525854
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.success(1).to_box() == Box(1)


# Generated at 2022-06-21 19:50:27.113878
# Unit test for method ap of class Validation
def test_Validation_ap():
    def add_error(value):
        return Validation('new_value', ['error'])

    assert(Validation.success('value').ap(add_error) == Validation('new_value', ['error']))
    assert(Validation.fail(['error1']).ap(add_error) == Validation(None, ['error1']))


# Generated at 2022-06-21 19:50:30.580748
# Unit test for method map of class Validation
def test_Validation_map():
    input_ = Validation.success(1)
    actual = input_.map(lambda x: x + 1)
    expected = Validation.success(2)
    Assert(actual == expected)


# Generated at 2022-06-21 19:50:39.778600
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for Validation.ap method"""
    assert Validation.success(3).ap(lambda x: Validation.success(x + 1)) == Validation.success(4)
    assert Validation.success(3).ap(lambda x: Validation.fail([])) == Validation.success(3)
    assert Validation.fail([1, 2, 3]).ap(lambda x: Validation.success(x + 1)) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]).ap(lambda x: Validation.fail([4, 5, 6])) == Validation.fail([1, 2, 3, 4, 5, 6])


# Generated at 2022-06-21 19:50:46.871787
# Unit test for method map of class Validation
def test_Validation_map():
    """
    map method of Validation class.
    """
    def inc(x):
        return x + 1

    assert Validation.success(3).map(inc) == Validation.success(4)
    assert Validation.fail('Error 1').map(inc) == Validation.fail(['Error 1'])


# Generated at 2022-06-21 19:50:50.969739
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success(None).to_maybe() == Maybe.nothing()
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:50:56.594704
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.fail().bind(lambda x: Validation.fail()).is_fail()
    assert Validation.fail().bind(lambda x: Validation.success()).is_fail()
    assert Validation.success().bind(lambda x: Validation.fail()).is_fail()


# Generated at 2022-06-21 19:51:01.889894
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    def test(value, errors):
        actual = Validation(value, errors).to_maybe()
        expected = Maybe.unit(value) if len(errors) == 0 else Maybe.nothing()

        assert actual == expected

    # Success
    yield test, "a", []
    yield test, None, []

    # Fail
    yield test, "a", ["error"]



# Generated at 2022-06-21 19:51:04.537211
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test Validation.is_success method.

    :return: nothing
    """
    validation = Validation.fail()
    assert validation.is_success() == False

    validation = Validation.success()
    assert validation.is_success() == True


# Generated at 2022-06-21 19:51:09.366834
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation('a', 1)) == 'Validation.fail[a, 1]'
    assert str(Validation('a', None)) == 'Validation.fail[a, None]'
    assert str(Validation('a', [])) == 'Validation.success[a]'

    assert str(Validation(None, 1)) == 'Validation.fail[None, 1]'
    assert str(Validation(None, None)) == 'Validation.fail[None, None]'
    assert str(Validation(None, [])) == 'Validation.success[None]'

# Unit tests for method success of class Validation

# Generated at 2022-06-21 19:51:13.132494
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation.success([1, 2, 3]).to_box() == Box([1, 2, 3])


# Generated at 2022-06-21 19:51:18.326456
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])


# Generated at 2022-06-21 19:51:27.821496
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation

    It should: return 'Validation.success[value]' when Validation is successful
    """
    value = 'value'
    val = Validation.success(value)
    assert str(val) == 'Validation.success[value]'

    """
    It should: return 'Validation.fail[value, errors]' when Validation is failed
    """
    value = 'value'
    errors = ['error_1', 'error_2']
    val = Validation.fail(errors)
    assert str(val) == 'Validation.fail[None, [\'error_1\', \'error_2\']]'



# Generated at 2022-06-21 19:51:34.656254
# Unit test for method bind of class Validation
def test_Validation_bind():

    def multiply_by_two(value) -> int:
        return value * 2
    
    def add_two(value) -> int:
        return value + 2
    
    def round_half_up(value) -> int:
        """
        Round number to the nearest integral value.
        """
        return math.floor(value) + 0.5
    
    def pow_two(value) -> int:
        return value**2

    # test for Validation.success(2).bind(multiply_by_two).bind(add_two)
    assert Validation(2, []).bind(lambda value: Validation.success(multiply_by_two(value))).bind(lambda value: Validation.success(add_two(value))) == Validation(6, [])

    # test for Validation.fail([1]).

# Generated at 2022-06-21 19:51:38.809336
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success('value')) == "Validation.success['value']"
    assert str(Validation.fail([1,2,3])) == "Validation.fail[None, [1, 2, 3]]"


# Generated at 2022-06-21 19:51:45.215312
# Unit test for method ap of class Validation
def test_Validation_ap():
    def f(x): return Validation.fail(['err'])
    assert Validation.success(2).ap(f) == Validation.fail(['err'])
    assert Validation.success(2).ap(lambda x: Validation.success(x)) == Validation.success(2)

    def f(x): return Validation.fail(['err'])
    assert Validation.fail(['err']).ap(f) == Validation.fail(['err', 'err'])
    assert Validation.fail(['err']).ap(lambda x: Validation.success(x)) == Validation.fail(['err'])



# Generated at 2022-06-21 19:51:50.252136
# Unit test for method map of class Validation
def test_Validation_map():
    v1 = Validation.success(5)
    assert v1.map(add_one) == Validation(6, [])

    v2 = Validation.fail(['error'])
    assert v2.map(add_one) == Validation(None, ['error'])



# Generated at 2022-06-21 19:51:56.595686
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Validation.to_try() should transform Validation to Try
    """
    from pymonet.monad_try import Try

    success_validation = Validation.success(2)
    assert success_validation.to_try() == Try(2, is_success=True)

    fail_validation = Validation.fail([1, 2, 3])
    assert fail_validation.to_try() == Try(None, is_success=False)


# Generated at 2022-06-21 19:52:01.157814
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v = Validation.success('abc')
    v2 = Validation.success('abc')
    v3 = Validation.success('cde')
    assert v == v2
    assert v != v3
    assert v != 'abc'



# Generated at 2022-06-21 19:52:05.365005
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.fail(["error1", "error2"]).map(lambda v: v + 1) == Validation(None, ["error1", "error2"])
    assert Validation.success(5).map(lambda v: v + 1) == Validation(6, [])



# Generated at 2022-06-21 19:52:13.647553
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation([], []).is_fail() == False
    assert Validation(None, ['']).is_fail() == True
    assert Validation('', ['']).is_fail() == True
    assert Validation(1, ['']).is_fail() == True
    assert Validation(False, ['']).is_fail() == True



# Generated at 2022-06-21 19:52:21.765741
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    from pymonet.validation_test_helper import ValidationTestHelpers

    # When Validation contains no errors
    ValidationTestHelpers.assert_values_equal(Validation.success(1).to_maybe(), Maybe(1))

    # When Validation contains some errors
    ValidationTestHelpers.assert_values_equal(Validation.fail(['error']).to_maybe(), Maybe(None))


# Generated at 2022-06-21 19:52:28.927417
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.test.test_box import make_test_case, make_test_case_data
    from nose.tools import assert_true, assert_false

    test_cases = [
        make_test_case([Validation.success(5), Box(5)])
    ]

    test_case_data = make_test_case_data(test_cases)

    for actual_result, expected_result in test_case_data:
        yield assert_true, actual_result == expected_result


# Generated at 2022-06-21 19:52:30.243968
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-21 19:52:41.766868
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try

    validation_instance = Validation(1, []).ap(lambda x: Validation(x + 2, []))
    assert validation_instance.value == 3
    assert validation_instance.errors == []

    validation_instance = Validation(1, [1]).ap(lambda x: Validation(x + 2, [2]))
    assert validation_instance.value == 3
    assert validation_instance.errors == [1, 2]

    validation_instance = Validation(1, [1]).ap(lambda x: Try(x + 2))
    assert validation_instance.value == 3
    assert validation_instance.errors == [1]

    validation_instance = Validation(1, [1]).ap(lambda x: Try(x / 0))
    assert validation_instance.value == None
    assert validation

# Generated at 2022-06-21 19:52:46.183071
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation.success('Hello')
    assert validation.value == 'Hello'
    assert len(validation.errors) == 0

    validation = Validation.fail(['bad', 'errors'])
    assert validation.value is None
    assert validation.errors == ['bad', 'errors']


# Generated at 2022-06-21 19:52:55.080576
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    def f(value):
        if value == 'fail':
            return Validation.fail(value)
        return Validation.success(value)

    assert f('success').bind(f) == Validation.success('success')
    assert f('fail').bind(f) == Validation.fail('fail')
    assert f('fail').bind(f).to_either() == Left('fail')
    assert f('success').bind(f).to_maybe() == Maybe.just('success')



# Generated at 2022-06-21 19:53:05.557450
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.maybe import Maybe
    from operator import add

    validation = Validation.fail(['Fault']) \
        .bind(lambda _: Validation(3, [])
              .bind(lambda _: Validation(4, [])))

    assert validation == Validation(4, ['Fault'])

    validation = Validation.success(1) \
        .bind(lambda _: Validation(2, [])) \
        .bind(lambda _: Validation(3, []))

    assert validation == Validation(3, [])

    validation = Validation.success(1) \
        .bind(lambda _: Validation(2, [])) \
        .bind(lambda _: Validation.fail(['Fault'])) \
        .bind(lambda _: Validation(3, []))

    assert validation == Validation

# Generated at 2022-06-21 19:53:12.054135
# Unit test for method map of class Validation
def test_Validation_map():
    # given
    def mapper(x):
        return x + x

    validation = Validation.success(1)
    expected = Validation(2, [])

    # when
    result = validation.map(mapper)

    # then
    assert expected == result, 'Validation.map() should return Validation with stored value and no errors'

    # given
    validation = Validation.fail([1, 2, 3])
    expected = Validation(None, [1, 2, 3])

    # when
    result = validation.map(mapper)

    # then
    assert expected == result, 'Validation.map() should return Validation with stored errors and no value'


# Generated at 2022-06-21 19:53:23.034440
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    def inc(value):
        return Validation.success(value + 1)

    def to_str(value):
        return Validation.success(str(value))

    def sqr(value):
        return Validation.success(value * value)

    result = Validation.success(10)\
        .bind(inc)\
        .bind(inc)\
        .bind(to_str)\
        .bind(sqr)\
        .bind(inc)

    assert result == Validation.success(12100)

    result = Validation.success(10) \
        .bind(inc) \
        .bind(inc) \
        .bind(lambda x: Validation.fail([2])) \
        .bind(to_str) \
        .bind(sqr) \
        .bind(inc)

# Generated at 2022-06-21 19:53:36.091910
# Unit test for method bind of class Validation
def test_Validation_bind():
    def return_success(value):
        return Validation.success(value)

    def return_fail(value):
        return Validation.fail([value])

    assert Validation.success(3).bind(return_success) == Validation.success(3)
    assert Validation.fail(['value']).bind(return_success) == Validation.fail(['value'])
    assert Validation.success(3).bind(return_fail) == Validation.fail(['3'])
    assert Validation.fail(['value']).bind(return_fail) == Validation.fail(['value', 'value'])


# Generated at 2022-06-21 19:53:38.863482
# Unit test for constructor of class Validation
def test_Validation():
    validate = Validation(5, [])
    assert validate.value is 5
    assert validate.errors == []
    assert validate.is_success() is True
    assert validate.is_fail() is False


# Generated at 2022-06-21 19:53:42.038224
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('value').to_maybe() == Maybe.just('value')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()



# Generated at 2022-06-21 19:53:48.860678
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def test():
        return Validation('a', [])

    lazy = test().to_lazy()

    assert isinstance(lazy, Lazy), 'Expected Lazy, but get {}'.format(lazy)
    assert lazy.value() == 'a', 'Expected "a", but get {}'.format(lazy.value())

# Generated at 2022-06-21 19:53:53.296269
# Unit test for method map of class Validation
def test_Validation_map():
    # Test map on success Validation
    success_validation = Validation.success(1)
    success_validation_mapped = success_validation.map(lambda x: x * x)
    assert success_validation_mapped == Validation.success(1)


# Generated at 2022-06-21 19:53:55.950484
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    res = Validation.fail([])
    assert res.is_fail() == True

    res = Validation.success()
    assert res.is_fail() == False


# Generated at 2022-06-21 19:54:00.997055
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for method ap of class Validation"""
    def test_fn(value):
        return Validation.fail(['test_Validation_ap_error'])

    value = 'val'
    actual = Validation.success(value).ap(test_fn)

    assert Validation('val', ['test_Validation_ap_error']) == actual, \
        'Validation.success({}).ap(test_fn) should be equal to Validation({}, [test_Validation_ap_error])'.format(
            value, value)



# Generated at 2022-06-21 19:54:07.545484
# Unit test for method to_try of class Validation
def test_Validation_to_try():

    # Input: Validation.success('Hello')
    # Expected output: Try.success('Hello')
    assert Validation.success('Hello').to_try() == Try.success('Hello')

    # Input: Validation.fail(['Error'])
    # Expected output: Try.fail(['Error'])
    assert Validation.fail(['Error']).to_try() == Try.fail(['Error'])


# Generated at 2022-06-21 19:54:13.513555
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for method is_success of class Validation.
    """
    assert Validation.success().is_success() == True
    assert Validation.success(42).is_success() == True
    assert Validation.success('test').is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail([1]).is_success() == False
    assert Validation.fail(['2']).is_success() == False
    assert Validation.fail([1, '2', 3]).is_success() == False


# Generated at 2022-06-21 19:54:22.063271
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.functor import Mapper

    def add_one(value):
        return value + 1

    def folder(value):
        return Validation.success(value + 1)

    assert Validation.success(1).bind(folder) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail(["error1"])).errors == ["error1"]

    assert Validation.success(1).bind(Mapper(add_one).fmap) == Validation.success(2)


# Generated at 2022-06-21 19:54:45.190948
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    #
    # Test is_fail when Validation is fail
    #
    assert Validation.fail([100, 200]).is_fail() is True
    assert Validation.fail([True]).is_fail() is True
    #
    # Test is_fail when Validation is success
    #
    assert Validation.success(100).is_fail() is False
    assert Validation.success("string").is_fail() is False
    assert Validation.success([]).is_fail() is False
    assert Validation.success(("1", "2")).is_fail() is False


# Generated at 2022-06-21 19:54:47.980994
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Given
    validation = Validation.success('success')
    lazy = validation.to_lazy()

    # Then
    assert isinstance(lazy, Lazy)
    assert lazy.get() == 'success'


# Generated at 2022-06-21 19:54:50.488500
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.fail([1, 2, 3])
    assert validation.is_fail() == True


# Generated at 2022-06-21 19:55:00.954133
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    It tests to_try method of Validation monad. to_try returns Try monad.
    It tests returning Try from Validation when Validation is failed and successful.
    """
    def method(x):
        return x

    assert Validation.success(10).to_try().is_success()
    assert Validation.success(10).to_try().or_else(20) == 10
    assert Validation.success(10).to_try().map(method).is_success()
    assert Validation.success(10).to_try().map(method).or_else(20) == 10
    assert Validation.success(10).to_try().bind(lambda x: Try(x + 10)).is_success()
    assert Validation.success(10).to_try().bind(lambda x: Try(x + 10)).or_

# Generated at 2022-06-21 19:55:07.780685
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # unit test for successful validation
    validation = Validation(1, [])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.call() == 1

    # unit test for failed validation
    validation = Validation(None, [])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.call() is None

    # unit test for failed validation
    validation = Validation(None, ['validation error'])
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.call() is None


# Generated at 2022-06-21 19:55:15.425644
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    def test_success_case():
        v_success = Validation.success('test')
        v_either = v_success.to_either()
        assert isinstance(v_either, Right) and v_either.value == v_success.value

    def test_fail_case():
        v_fail = Validation.fail(['Error'])
        v_either = v_fail.to_either()
        assert isinstance(v_either, Left) and v_either.value == v_fail.errors

    test_success_case()
    test_fail_case()


# Generated at 2022-06-21 19:55:24.964286
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Test for case when Validation is successful and bind function returns an error
    v1 = Validation.success('1')
    v2 = Validation.fail('2')
    assert v1.bind(lambda x: v2) == v2

    # Test for case when Validation is failure and bind function returns an error
    v1 = Validation.fail('1')
    v2 = Validation.fail('2')
    assert v1.bind(lambda x: v2) == v2

    # Test for case when Validation is successful and bind function returns success
    v1 = Validation.success('1')
    v2 = Validation.success('2')
    assert v1.bind(lambda x: v2) == v2

    # Test for case when Validation is failure and bind function returns success

# Generated at 2022-06-21 19:55:29.168969
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """Test for method is_success of class Validation"""
    from pymonet.validation import Validation

    assert Validation.success(5).is_success() == True, 'Failed test for method is_success of class Validation'



# Generated at 2022-06-21 19:55:38.191579
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for bind method of Validation.
    """
    from pymonet.functor import Functor

    def bad_f(value):
        return Functor.fail([ERROR_MESSAGE])

    def good_f(value):
        return Functor.success(value)

    validation = Validation.success(VALUE)
    validation_bad = validation.bind(bad_f)
    validation_good = validation.bind(good_f)

    assert validation_bad.value is None
    assert validation_bad.errors == [ERROR_MESSAGE]
    assert validation_good.value == VALUE
    assert validation_good.errors == []


# Generated at 2022-06-21 19:55:40.957943
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success("First validation").is_fail() == False
    assert Validation.fail("First validation").is_fail() == True


# Generated at 2022-06-21 19:56:12.114175
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([]) == Validation(None, [])


# Generated at 2022-06-21 19:56:15.965925
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('success-value').to_either() == Right('success-value')
    assert Validation.fail(['fail-errors']).to_either() == Left(['fail-errors'])


# Generated at 2022-06-21 19:56:21.866392
# Unit test for constructor of class Validation
def test_Validation():
    assert str(Validation('A', [])) == 'Validation.success[A]'
    assert str(Validation('A', [1, 2, 3])) == 'Validation.fail[A, [1, 2, 3]]'
    assert str(Validation(None, [])) == 'Validation.success[None]'
    assert str(Validation(None, [1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-21 19:56:24.420725
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(value='value') == Validation.success(value='value')
    assert not Validation.success(value='value') == Validation.success(value='another value')

    assert Validation.fail([]) == Validation.fail([])
    assert not Validation.fail(errors=['Error']) == Validation.fail(errors=['Another Error'])


# Generated at 2022-06-21 19:56:30.083091
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy().get() == None


# Generated at 2022-06-21 19:56:34.910343
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for method is_success of class Validation.

    """
    assert (Validation.success(1).is_success() == True)
    assert (Validation.success(None).is_success() == True)
    assert (Validation.fail([]).is_success() == False)
    assert (Validation.fail([1]).is_success() == False)



# Generated at 2022-06-21 19:56:41.325878
# Unit test for constructor of class Validation
def test_Validation():
    try:
        assert Validation.success(3) == Validation(3, [])
        assert Validation.fail(['3']) == Validation(None, ['3'])
        assert Validation(3, ['3']) == Validation(3, ['3'])
        print('test_Validation: passed')
    except AssertionError:
        print('test_Validation: failed')


# Generated at 2022-06-21 19:56:45.833102
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation(1, []).to_try() == Try(1, is_success=True)
    assert Validation(1, [2]).to_try() == Try(1, is_success=False)


# Generated at 2022-06-21 19:56:48.510763
# Unit test for constructor of class Validation
def test_Validation():
    validate = Validation(None, [])

    assert validate.is_fail()

    validate = Validation(1, [])

    assert validate.is_success()
    assert validate.value == 1




# Generated at 2022-06-21 19:56:58.086555
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success_validation = Validation.success(1)
    assert success_validation.is_success()
    assert not success_validation.is_fail()

    fail_validation = Validation.fail(['fail'])
    assert not fail_validation.is_success()
    assert fail_validation.is_fail()

    success_fail_validation = Validation.fail([]).success()
    assert success_fail_validation.is_success()
    assert not success_fail_validation.is_fail()

    fail_success_validation = Validation.success(1).fail()
    assert not fail_success_validation.is_success()
    assert fail_success_validation.is_fail()
