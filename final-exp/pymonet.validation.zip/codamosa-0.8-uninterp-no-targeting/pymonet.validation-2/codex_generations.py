

# Generated at 2022-06-21 19:47:21.949572
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    # Setup
    from pymonet.either import Right, Left
    right_value = Right(123)
    left_value = Left(456)

    # Exercise
    validation_to_either_success = Validation.success(right_value).to_either()
    validation_to_either_fail = Validation.success(left_value).to_either()

    # Verify
    assert validation_to_either_success == right_value
    assert validation_to_either_fail == left_value


# Generated at 2022-06-21 19:47:30.751939
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test method is_fail of class Validation.

    :returns: True for test passed
    :rtype: Boolean
    """
    failed_monad = Validation.fail(['error1'])
    assert failed_monad.is_fail()

    failed_monad = Validation.fail(['error1', 'error2'])
    assert failed_monad.is_fail()

    failed_monad = Validation.fail([])
    assert not failed_monad.is_fail()

    success_monad = Validation.success('test')
    assert not success_monad.is_fail()

    return True


# Generated at 2022-06-21 19:47:32.621429
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    expected = Box(5)
    assert Validation.success(5).to_box() == expected

# Generated at 2022-06-21 19:47:42.964893
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation to ensure that method
    returns correct result.

    :returns: True if test was successful.
    :rtype: Boolean
    """
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def _test(value, errors):
        test_case = Validation(value, errors)
        result = test_case.to_lazy()
        expected = Lazy(lambda: value)
        return result == expected

    return all([
        _test(1, []),
        _test(None, [1, 2, 3]),
    ])


# Generated at 2022-06-21 19:47:48.178040
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Test for method is_fail of class Validation"""
    validation = Validation.fail(['error'])
    assert validation.is_fail()

    validation = Validation.fail([])
    assert not validation.is_fail()

    validation = Validation.success(10)
    assert not validation.is_fail()


# Generated at 2022-06-21 19:47:54.327260
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success('some value').is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail([1, 2, 3]).is_success() == False


# Generated at 2022-06-21 19:47:56.702316
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.fail().is_fail()
    assert Validation.success().is_fail()
    assert not Validation.success(42).is_fail()
    assert Validation.fail([42]).is_fail()

# Generated at 2022-06-21 19:48:07.259464
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Tests of mapping function for Validation class.
    """
    # Success
    assert Validation.success('success').map(lambda x: x.upper()) == Validation.success('SUCCESS')
    assert Validation.success('success').map(lambda x: x.lower()) == Validation.success('success')
    assert Validation.success('success').map(lambda x: [1, 2, 3]) == Validation.success([1, 2, 3])

    # Fail
    assert Validation.fail(['error1', 'error2']).map(lambda x: x.upper()) == Validation.fail(['error1', 'error2'])
    assert Validation.fail(['error1', 'error2']).map(lambda x: x.lower()) == Validation.fail(['error1', 'error2'])

# Generated at 2022-06-21 19:48:14.191076
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)

    assert Validation.fail(['error1', 'error2']) == Validation.fail(['error1', 'error2'])
    assert Validation.fail(['error1', 'error2']) != Validation.fail(['error1', 'error3'])

    assert Validation.success(None) != Validation.fail(['error1', 'error3'])
    assert Validation.success(1) != Validation.fail(['error1', 'error2'])


# Generated at 2022-06-21 19:48:17.745648
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(42)
    assert validation.to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-21 19:48:26.344076
# Unit test for method map of class Validation
def test_Validation_map():
    """Test map method of the class Validation"""

    assert Validation.success(2).map(lambda x: x + 2) == Validation.success(4)
    assert Validation.success(2).map(lambda x: x * 2) == Validation.success(4)
    assert Validation.success(2).map(lambda x: x - 2) == Validation.success(0)


# Generated at 2022-06-21 19:48:35.632441
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import cata

    def sum(x, y):
        return x + y

    sum_f = lambda x: sum(x, 1)

    def div(x, y):  # pragma: no cover
        return x / y

    div_f = lambda x: div(x, 0)  # pragma: no cover

    sum_f_try = lambda x: Try(sum(x, 1), is_success=True)

    assert Validation.success(3).to_try() == sum_f_try(2)
    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-21 19:48:38.893636
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-21 19:48:40.808452
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    assert validation.to_lazy().get() == 1

# Generated at 2022-06-21 19:48:45.438556
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad
    assert Functor.verify_implementation(Validation)
    assert Applicative.verify_implementation(Validation)
    assert Monad.verify_implementation(Validation)

# Generated at 2022-06-21 19:48:48.738123
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(None, []).is_fail() == False
    assert Validation('is_success', []).is_fail() == False
    assert Validation(None, ['is_fail']).is_fail() == True
    assert Validation('is_success', ['is_fail']).is_fail() == True


# Generated at 2022-06-21 19:48:57.042709
# Unit test for method map of class Validation
def test_Validation_map():
    success_value = 'success'
    fail_value = 'fail'
    fail_error = 'error'
    success_length = len(success_value)
    fail_length = len(fail_value)
    success_errors = []
    fail_errors = [fail_error]

    success_validation = Validation.success(success_value)
    fail_validation = Validation.fail(fail_errors)

    assert success_validation.map(lambda x: len(x)) == Validation(success_length, success_errors)
    assert fail_validation.map(lambda x: len(x)) == fail_validation


# Generated at 2022-06-21 19:49:02.944290
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.monad_tests.utils import Func, add_one
    assert Func(Validation.success(0)).map(add_one).is_success()
    assert Func(Validation.fail([])).map(add_one).is_fail()
    assert Func(Validation.success(0)).map(add_one).value == 1
    assert Func(Validation.fail([])).map(add_one).value is None



# Generated at 2022-06-21 19:49:10.046265
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    def method_to_try_of_class_Validation_when_fail():
        validation = Validation.fail()
        try_ = validation.to_try()
        assert try_.is_fail()

    def method_to_try_of_class_Validation_when_success():
        validation = Validation.success(1)
        try_ = validation.to_try()
        assert try_ == Try(1)

    method_to_try_of_class_Validation_when_success()
    method_to_try_of_class_Validation_when_fail()


# Generated at 2022-06-21 19:49:13.167701
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('value').is_success()
    assert not Validation.fail('error').is_success()


# Generated at 2022-06-21 19:49:21.427861
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    val = Validation(None, [])
    assert val.is_success()

    val = Validation(1, [])
    assert val.is_success()

    val = Validation(1, [1])
    assert not val.is_success()

    val = Validation(1, [None, 1, 2])
    assert not val.is_success()



# Generated at 2022-06-21 19:49:26.011126
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation(2, []).to_either() == Right(2)
    assert Validation(2, ['2 is even, please provide odd number']).to_either() == Left(['2 is even, please provide odd number'])


# Generated at 2022-06-21 19:49:31.664653
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1, 2]).is_fail()
    assert Validation.fail(['1', '2']).is_fail()
    assert Validation.fail(['1']).is_fail()
    assert Validation.fail([]).is_fail()


# Generated at 2022-06-21 19:49:42.854907
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.
    """
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Validation.success(False) == Validation.success(False)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.success('test') != Validation.success(123)
    assert Validation.success('test') != Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.fail(['another error'])

    assert Validation.success(2) != Validation.success(2.0)
    assert Validation.success(True) != Validation.success(False)

# Generated at 2022-06-21 19:49:50.088328
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-21 19:49:52.668287
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:49:54.621350
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(True).is_success()
    assert Validation.fail(['err1']).is_success() == False


# Generated at 2022-06-21 19:50:00.689184
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    for el in [Validation.success(1),
               Validation.success(Try.success(2)),
               Validation.success(Box(Try.success(3)))]:
        assert el.to_box() == Box(el.value)


# Generated at 2022-06-21 19:50:10.860096
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test to_maybe method of Validation
    """
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    # Successful case
    assert Validation.success(1).to_maybe() == Maybe.just(1)

    # Fail case
    assert Validation.fail([]).to_maybe() == Maybe.nothing()

    # Fail case with errors
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()

    # Fail case with value passed
    assert Validation.fail([1, 2, 3], 99).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:50:15.317627
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad import Monad

    def _ap(value):
        return Validation.success(value).ap(Monad.pure)

    assert _ap(1).is_success()
    assert _ap(1).value == 1



# Generated at 2022-06-21 19:50:26.893109
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(2) != Validation.success(1)
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1]) != Validation.fail([1, 2])
    assert Validation.fail() != Validation.success()
    assert Validation.fail([1]) != Validation.success(1)


# Generated at 2022-06-21 19:50:35.481497
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for method to_try of class Validation."""
    from pymonet.monad_try import Try

    v = Validation.success(1)
    t = v.to_try()
    assert isinstance(t, Try)
    assert t.get() == 1
    assert t.is_success() is True
    assert t.is_fail() is False

    v = Validation.fail(1)
    t = v.to_try()
    assert isinstance(t, Try)
    assert t.is_success() is False
    assert t.is_fail() is True



# Generated at 2022-06-21 19:50:38.520395
# Unit test for method map of class Validation
def test_Validation_map():
    validation = Validation.success(5)
    assert validation == Validation.success(5)
    assert validation.map(lambda x: x + 1) == Validation.success(6)


# Generated at 2022-06-21 19:50:40.117030
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-21 19:50:44.421873
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([]).is_fail() == True
    assert Validation.success().is_fail() == False


# Generated at 2022-06-21 19:50:46.524472
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('foo').to_box().value == 'foo'
    assert Validation.fail([1]).to_box().value is None


# Generated at 2022-06-21 19:50:54.235096
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe, Nothing
    from pymonet import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try, Failure

    assert Validation.success(10).map(lambda v: v * 5) == Validation.success(50)
    assert Validation.success(10).map(lambda v: v ** 2) == Validation.success(100)
    assert Validation.fail(['error']).map(lambda v: v * 5) == Validation.fail(['error'])
    assert Validation.fail(['error']).map(lambda v: v ** 2) == Validation.fail(['error'])

    assert Validation.success(10).to_either() == Right(10)

# Generated at 2022-06-21 19:51:01.689479
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1]) != Validation.success(1)
    assert Validation.success(1) != Validation.fail([1])
    assert Validation.success(1) == Try.success(1)
    assert Validation.fail([1]) == Try.fail([1])


# Generated at 2022-06-21 19:51:09.724266
# Unit test for method map of class Validation
def test_Validation_map():
    err_msg = "Validation.map method is not working."
    assert Validation.success(5).map(lambda x: x * x) == \
           Validation.success(25), err_msg

    assert Validation.fail([]).map(lambda x: x * x) == \
           Validation.fail([]), err_msg

    assert Validation.fail(['error 1', 'error 2']).map(lambda x: x * x) == \
           Validation.fail(['error 1', 'error 2']), err_msg


# Generated at 2022-06-21 19:51:11.765026
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet import Validation as V

    assert V.success().is_success()
    assert not V.fail().is_success()


# Generated at 2022-06-21 19:51:21.487612
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_function():
        return 1
    validation = Validation.success(1)
    assert validation.to_lazy().map(lambda x: x()).to_either() == Either.success(test_function())
    assert validation.to_lazy().map(lambda x: x()).to_maybe() == Maybe.success(test_function())
    assert validation.to_lazy().map(lambda x: x()).to_box() == Box.success(test_function())
    assert validation.to_lazy().map(lambda x: x()).to_try() == Try.success(test_function())


# Generated at 2022-06-21 19:51:25.773307
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test if method is_fail returns the expected result.
    """
    validation = Validation(0, [])
    assert validation.is_fail() == False
    validation = Validation(None, ['UPPER', 'DIGIT'])
    assert validation.is_fail() == True


# Generated at 2022-06-21 19:51:31.574488
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    def check_validation_to_try(value):
        assert Validation.success(value).to_try() == Try.succeed(value)
        assert Validation.fail(value).to_try() == Try.fail(value)

    check_validation_to_try(None)
    check_validation_to_try(1)
    check_validation_to_try([])
    check_validation_to_try("a")

# Unit tests for method to_lazy of class Validation

# Generated at 2022-06-21 19:51:36.383523
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.monad_try import Try

    try_value = Try(2, is_success=True)
    try_error = Try(ValueError('Test message'), is_success=False)

    validation = Validation.success(2)
    assert validation.is_success()
    assert validation.value == 2
    assert validation.errors == []

    validation = Validation.fail([ValueError('Test message')])
    assert validation.is_fail()
    assert validation.value is None
    assert validation.errors == [ValueError('Test message')]

    assert validation == Validation.fail([ValueError('Test message')])

    validation = Validation.success(2)
    assert validation == Validation.success(2)

    assert try_value.to_validation().value == 2

# Generated at 2022-06-21 19:51:38.607154
# Unit test for method map of class Validation
def test_Validation_map():
    val = Validation.success(2)
    assert val.map(lambda x: x + 2) == Validation(4, [])


# Generated at 2022-06-21 19:51:47.542642
# Unit test for method bind of class Validation
def test_Validation_bind():

    def folder(value):
        if value < 10:
            return Validation.fail(['error'])
        return Validation.success(value + 10)

    # Validation.bind is called with positive value and folder returns Validation.success
    validation = Validation.success(5).bind(folder)
    assert validation == Validation(15, [])

    # Validation.bind is called with positive value and folder returns Validation.fail
    validation = Validation.success(5).bind(folder)
    assert validation == Validation(None, ['error'])

    # Validation.bind is called with None and folder returns Validation.fail
    validation = Validation.success().bind(folder)
    assert validation == Validation(None, ['error'])

    # Validation.bind is called with None and folder returns Validation.success
    validation = Val

# Generated at 2022-06-21 19:51:50.965268
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(4).to_box() == Box(4)
    assert Validation.fail([1, 2]).to_box() == Box(None)


# Generated at 2022-06-21 19:51:52.479309
# Unit test for method ap of class Validation
def test_Validation_ap():
    def mapper(x):
        return Validation.success(x+1)
    assert Validation.success(1).ap(mapper) == Validation.success(2)
    assert Validation.success(1).ap(mapper).errors == []

# Generated at 2022-06-21 19:51:56.241602
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success(10)
    assert str(success) == "Validation.success[10]"

    fail = Validation.fail([1, 2])
    assert str(fail) == "Validation.fail[None, [1, 2]]"


# Generated at 2022-06-21 19:52:00.130245
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(4)) == 'Validation.success[4]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-21 19:52:16.655998
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert isinstance(Validation.success(1).to_maybe(), Maybe)
    assert Validation.success(1).to_maybe().value == 1
    assert Validation.success(1).to_maybe().is_nothing() is False
    assert Validation.fail().to_maybe().value is None
    assert Validation.fail().to_maybe().is_nothing() is True


# Generated at 2022-06-21 19:52:19.691509
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation.fail([])
    assert validation.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-21 19:52:22.576057
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.success(5).to_try() == Try(5)
    assert Validation.fail([1]).to_try() == Try(None, False)

# Generated at 2022-06-21 19:52:31.228528
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Test case for Validation.bind method."""
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def test_monad_value(fn, value):
        return fn(value)

    v = Validation.success(1)
    assert test_monad_value(v.bind, lambda x: x + 1) == 2
    assert test_monad_value(v.bind, lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert test_monad_value(v.bind, lambda x: Validation.fail(['error'])) == Validation.fail(['error'])
    assert test_

# Generated at 2022-06-21 19:52:36.061898
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    result = Validation.success("passed").to_either()
    assert result == Right("passed")

    result = Validation.fail("spam").to_either()
    assert result == Left("spam")


# Generated at 2022-06-21 19:52:41.837967
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation
    """
    # Test with successful Validation with value 10
    assert Validation.success(10).is_fail() is False
    # Test with failed Validation with empty errors list
    assert Validation.fail([]).is_fail() is True
    # Test with failed Validation with not empty errors list
    assert Validation.fail([1, 2, 3]).is_fail() is True


# Generated at 2022-06-21 19:52:47.033340
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def value_mapper(value):
        return value

    def errors_mapper(errors):
        return errors

    value = Validation.success([1,2,3])
    assert value.to_lazy().value() == [1,2,3]

    value = Validation.fail(['Error 1'])
    assert value.to_lazy().value() is None


# Generated at 2022-06-21 19:52:50.161391
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    value = Validation.success().to_box().value
    assert value == None
    value = Validation.success('test').to_box().value
    assert value == 'test'



# Generated at 2022-06-21 19:52:54.067715
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(3).map(lambda v: v + 1) == Validation(4, [])
    assert Validation.fail(['error']).map(lambda v: v + 1) == Validation(None, ['error'])


# Generated at 2022-06-21 19:52:59.359916
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: x + 1) == Validation.success(3)
    assert Validation.success(2).map(lambda x: x + 1).value == 3
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])


# Generated at 2022-06-21 19:53:10.881166
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()


# Generated at 2022-06-21 19:53:21.289881
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit testing Validation bind method.

    :return: True if test is successful, otherwise False
    :rtype: Boolean
    """
    from pymonet.validation import Validation

    def f(n):
        if n < 10:
            return Validation.fail('Too low!')
        if n > 20:
            return Validation.fail('Too high!')
        return Validation.success()

    assert Validation(5, []).bind(f) == Validation(None, ['Too low!'])
    assert Validation(25, []).bind(f) == Validation(None, ['Too high!'])
    assert Validation(15, []).bind(f) == Validation(None, [])

    return True


# Generated at 2022-06-21 19:53:28.496242
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    It tests to box method of Validation.
    """
    from pymonet.box import Box

    # Box created from successful Validation
    assert Validation.success(5).to_box() == Box(5)

    # Box from failed Validation
    assert Validation.fail().to_box() == Box(None)


# Generated at 2022-06-21 19:53:38.473583
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.monad_try import Try

    # Test for Success Validation
    assert str(Validation.success('Success')) == 'Validation.success[Success]'

    # Test for Failed Validation
    assert str(Validation.fail(['Fail'])) == 'Validation.fail[None, [\'Fail\']]'

    # Test for Failed Validation with list of errors
    assert str(Validation.fail(['Fail1', 'Fail2'])) == 'Validation.fail[None, [\'Fail1\', \'Fail2\']]'

    # Test for Validation with multiple errors
    assert str(Validation.fail([Try.fail('Error1'), Try.fail('Error2')])) == \
        'Validation.fail[None, [Try.fail[\'Error1\'], Try.fail[\'Error2\']]]'

# Generated at 2022-06-21 19:53:45.607740
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Tests if constructor and methods of class Validation works correctly.
    """
    assert Validation.success().bind(lambda _: Validation.fail()) == Validation.fail()
    assert Validation.success('test').bind(lambda _: Validation.fail()) == Validation.fail()
    assert Validation.success('test').bind(lambda _: Validation.success()) == Validation.success()
    assert Validation.success('test').bind(lambda v: Validation.success(v)) == Validation.success('test')
    assert Validation.fail(['error 1']).bind(lambda _: Validation.success()) == Validation.fail(['error 1'])
    assert Validation.fail(['error 1']).bind(lambda _: Validation.fail()) == Validation.fail(['error 1'])

# Generated at 2022-06-21 19:53:49.864802
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    a_validation = Validation.fail(['error1', 'error2'])
    b_validation = Validation.fail(['error1', 'error2'])
    assert a_validation == b_validation



# Generated at 2022-06-21 19:53:55.762302
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.try_ import Try
    from pymonet.lazy import Lazy

    value = Validation.success(20)
    result = value.to_lazy()
    assert result.value() == 20

    value = Validation.fail([20])
    result = value.to_lazy()
    assert result.value() is None


# Generated at 2022-06-21 19:53:59.370636
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert not Validation.success(1) == Validation.success()
    assert Validation.fail() == Validation.fail()
    assert Validation.fail([1]) == Validation.fail([1])
    assert not Validation.success(1) == Validation.fail()



# Generated at 2022-06-21 19:54:04.649185
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    actual = Validation.fail([]).to_box()
    expected = Box(None)
    assert actual == expected

    actual = Validation.success(0).to_box()
    expected = Box(0)
    assert actual == expected



# Generated at 2022-06-21 19:54:06.065702
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(None, [1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-21 19:54:31.734982
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail(['error'])) == "Validation.fail[None, ['error']]"
    assert str(Validation.fail()) == "Validation.fail[None, []]"


# Generated at 2022-06-21 19:54:38.426105
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left
    from pymonet.validation import Validation
    from pymonet.monad_maybe import Maybe

    valid = Validation.success('something')
    assert(valid.to_either() == valid.to_box().to_either())
    assert(valid.to_either() == valid.to_maybe().to_either())

    invalid = Validation.fail(['error'])
    assert(invalid.to_either() == Left(['error']))



# Generated at 2022-06-21 19:54:45.607485
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Create successful Validation without errors and check if to_str returns proper string.
    """
    from pymonet.monad_try import Try

    validation = Validation.success(Try(lambda: 3 / 0))
    assert str(validation) == 'Validation.success[Try[Exception]]'

    validation = Validation.fail([TypeError('exception message'), TypeError('exception message')])
    assert str(validation) == 'Validation.fail[None, [TypeError, TypeError]]'


# Generated at 2022-06-21 19:54:55.688464
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to_lazy method of class Validation
    """
    from pymonet.monad_try import Try

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy().unwrap() == None
    assert Validation.success(3).to_lazy().unwrap() == 3
    assert Validation.fail([1]).to_lazy().to_try().is_success() is False
    assert Validation.success(3).to_lazy().to_try().is_success() is True
    assert Validation.success(3).to_lazy().unwrap_or(5) == 3

# Generated at 2022-06-21 19:55:01.449008
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    valid = Validation(1, [])
    invalid = Validation(None, [1, 2])
    assert valid.__eq__(Validation(1, [])) == True
    assert valid.__eq__(Validation(2, [])) == False
    assert valid.__eq__(invalid) == False
    assert valid.__eq__(None) == False


# Generated at 2022-06-21 19:55:03.611843
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:55:05.976565
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Just, Nothing

    assert Validation.success(42).to_maybe() == Just(42)
    assert Validation.fail([]).to_maybe() == Nothing()



# Generated at 2022-06-21 19:55:08.802646
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(['']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-21 19:55:13.783981
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right
    from pymonet.either import Left

    assert Validation.success(7).to_either() == Right(7)
    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.fail(['Some error']).to_either() == Left(['Some error'])


# Generated at 2022-06-21 19:55:18.805940
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # Successful Validation:
    v1 = Validation.success(True)
    assert v1.to_either() == Right(True)

    # Failed validation:
    v2 = Validation.fail(['error-1', 'error-2'])
    assert v2.to_either() == Left(['error-1', 'error-2'])


# Generated at 2022-06-21 19:56:11.227591
# Unit test for method map of class Validation
def test_Validation_map():
    """
    It tests method map for two cases:
    * Validation has value and empty errors list,
    * Validation has value and not empty errors list.
    """
    def mapper(value):
        return value + 2

    assert Validation.success(2).map(mapper) == Validation.success(4)
    assert Validation.fail([1]).map(mapper) == Validation.fail([1])


# Generated at 2022-06-21 19:56:19.134253
# Unit test for constructor of class Validation
def test_Validation():
    valSuccess = Validation.success(5)
    valFail = Validation.fail()

    assert valSuccess.value == 5
    assert valSuccess.errors == []
    assert valSuccess.is_success() is True
    assert valSuccess.is_fail() is False
    assert valSuccess.to_maybe().is_just() is True

    assert valFail.value is None
    assert valFail.errors == []
    assert valFail.is_success() is False
    assert valFail.is_fail() is True
    assert valFail.to_maybe().is_nothing() is True


# Generated at 2022-06-21 19:56:24.568363
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Validation.map takes function (A) -> B and Validation[A, List[E]] and returns Validation[B, List[E]]
    """
    def succ(x):
        return x * 10

    def err(x):
        return x

    v0 = Validation.success(5)
    v1 = Validation.success(5).map(succ)
    v2 = Validation.success(5).map(err)
    assert v0 == v2
    assert v1 != v2
    assert Validation.success(50) == v1

# Generated at 2022-06-21 19:56:34.909750
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation
    """
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # Two Successful Validation are equals when values are equal. Errors are not tested.
    assert Validation.success('value') == Validation.success('value')
    assert Validation.success('value') == Validation.success(123)
    assert Validation.success('value') == Validation.success(True)
    assert Validation.success('value') == Validation.success([1, 2, 3])
    assert Validation.success('value') == Validation.success((1, 2, 3))

# Generated at 2022-06-21 19:56:36.806413
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.validation import Validation

    assert not Validation.success('success').is_fail()
    assert Validation.fail(['error']).is_fail()


# Generated at 2022-06-21 19:56:41.138765
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try(1, True)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, False)

# Generated at 2022-06-21 19:56:44.634921
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == "Validation.success[1]"
    assert str(Validation.fail(['error'])) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-21 19:56:50.254418
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.functoolsempty import empty

    def to_try(validation):
        return validation.to_try()

    # Success
    assert to_try(Validation.success('a')) == Try('a')
    assert to_try(Validation.success(1)) == Try(1)
    assert to_try(Validation.success({'a': 'b'})) == Try({'a': 'b'})

    # Fail
    assert to_try(Validation.fail(['a'])).is_fail()
    assert to_try(Validation.fail(1)).is_fail()
    assert to_try(Validation.fail({'a': 'b'})).is_fail()

# Generated at 2022-06-21 19:56:54.724426
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    assert Validation(1, Left(2)) == Validation(1, Left(2))
    assert Validation(1, Left(2)) != Left(1)
    assert Validation(1, Left(2)) != Validation(1, Right(2))


# Generated at 2022-06-21 19:56:57.314834
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(10).to_box() == Box(10)
    assert Validation.success(10).to_box().is_instance_of(Box)