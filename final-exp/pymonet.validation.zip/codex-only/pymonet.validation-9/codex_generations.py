

# Generated at 2022-06-24 00:44:19.521924
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test that Validation to Either transformation works properly.
    """
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad import Failable, Monad

    failable = Failable()

    assert failable.success(1).to_either() == Right(1)
    assert failable.success(None).to_either() == Right(None)
    assert failable.fail(['foo']).to_either() == Left(['foo'])
    assert failable.fail(['foo', 'bar']).to_either() == Left(['foo', 'bar'])

    assert failable.box(1).to_either() == Right(1)
    assert failable

# Generated at 2022-06-24 00:44:26.491484
# Unit test for method ap of class Validation
def test_Validation_ap():

    def add_one(number):
        from pymonet.validation import Validation

        return Validation.success(number + 1)

    def add_two(number):
        from pymonet.validation import Validation

        return Validation.success(number + 2)

    def add_three(number):
        from pymonet.validation import Validation

        return Validation.success(number + 3)

    assert Validation.success(2).ap(add_one).ap(add_two).ap(add_three).value == 8
    assert Validation.success(2).ap(add_one).ap(add_two).ap(add_three).errors == []

    def add_one_with_error(number):
        from pymonet.validation import Validation


# Generated at 2022-06-24 00:44:27.688804
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation([], []).is_success() == True
    assert Validation([1], [1]).is_success() == False


# Generated at 2022-06-24 00:44:35.616312
# Unit test for method bind of class Validation
def test_Validation_bind():
    """ Unit test for method bind of class Validation.
    """

    def add(x):
        def add_x(y):
            return x + y

        return add_x

    def add_3(y):
        return add(3)(y)

    def add_5(y):
        return add(5)(y)

    assert Validation.success(add_5).bind(add_3) == Validation.success(8)

# Generated at 2022-06-24 00:44:39.757536
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # When Validation is failed should return True
    assert Validation.fail([1, 2, 3]).is_fail()

    # When Validation is successful should return False
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-24 00:44:42.650997
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success(1)
    assert str(success) == 'Validation.success[1]'

    fail = Validation.fail([1, 2, 3])
    assert str(fail) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:44:45.225911
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation.success('value')
    def monad(val): return Validation.success('result').ap(lambda res: Validation.fail([1]))
    assert validation.ap(monad) == Validation('value', [1])

# Generated at 2022-06-24 00:44:51.191619
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    x = Validation.success(2)
    assert x.is_success() == True

    y = Validation.fail()
    assert y.is_success() == False


# Generated at 2022-06-24 00:44:59.008702
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(1) == Validation.success(1).to_try()
    assert Failure(None, [1, 2]) == Validation.fail([1, 2]).to_try()

# Unit tests for method ap of class Validation

# Generated at 2022-06-24 00:45:01.326212
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    v = Validation.success(4)
    assert v.is_success()

    v = Validation.fail([4])
    assert not v.is_success()


# Generated at 2022-06-24 00:45:04.496002
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    def fun(val):
        return Validation.success('ololo')

    valid = Validation.success(20)
    new = valid.ap(fun)
    assert new.value == 20
    assert new.is_success() is True



# Generated at 2022-06-24 00:45:12.212675
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe, Nothing, Just

    def test_transform_success_validation_to_maybe():
        assert Validation.success(2).to_maybe() == Just(2)

    def test_transform_fail_validation_to_maybe():
        assert Validation.fail([1, 2, 5]).to_maybe() == Nothing()

    # Run all test
    test_transform_success_validation_to_maybe()
    test_transform_fail_validation_to_maybe()



# Generated at 2022-06-24 00:45:17.685842
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:45:24.835998
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # Arrange
    val1 = Validation.fail([1,2])
    val2 = Validation.fail()
    val3 = Validation.success()

    # Act
    is_fail1 = val1.is_fail() 
    is_fail2 = val2.is_fail()
    is_fail3 = val3.is_fail()

    # Assert
    assert(is_fail1)
    assert(is_fail2)
    assert(not is_fail3)


# Generated at 2022-06-24 00:45:31.722434
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test function.

    :return: Nothing
    """

    # pylint: disable=C0103
    # unit test must have names in form test_*

    # Test successful Validation with map function
    assert Validation.success('foo').map(lambda x: x + 'bar') == Validation.success('foobar')

    # Test failed Validation with map function
    assert Validation.fail(['bar']) \
        .map(lambda x: x + 'bar') == Validation.fail(['bar']), \
        'Failure Validation must be not transformed by map'

    print('All tests for method map of class Validation has passed successfully')


# Generated at 2022-06-24 00:45:37.210132
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    # create new Validation
    validation = Validation(1, [])
    # run method
    result = validation.to_box()
    # assert result
    assert isinstance(result, Box) and result.value == 1


# Generated at 2022-06-24 00:45:41.658915
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    result = Validation.success(10).to_lazy()
    assert result == Lazy(lambda: 10), 'Check that Validation value is updated in Lazy'


# Generated at 2022-06-24 00:45:46.951964
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(10)) == 'Validation.success[10]', "Validation.success != 'Validation.success[10]'"
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]',\
        "Validation.fail != 'Validation.fail[None, ['error']]'"


# Generated at 2022-06-24 00:45:55.955204
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    unit test for ap method of class Validation.
    Test creates successful Validation monad and two Validation monads with errors:
    - failedValidation1 contains error1
    - failedValidation2 contains error2 and error3

    ap method is applied to successfulValidation monad with function 'check_function'.
    Check_function create new Validation monad with two errors:
    - error1 and error2.

    Function 'check_function' has signature (A) -> Validation[Any, List[E]]
    So ap method returns new Validation monad with previous value and concated errors list.

    :returns: None
    :rtype: None
    """
    error1 = 1
    error2 = 2
    error3 = 3

    success_value = 'success'


# Generated at 2022-06-24 00:45:58.891280
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation(None, [])
    assert validation.is_success() == True

    validation = Validation(None, [])
    assert validation.is_success() == True


# Generated at 2022-06-24 00:46:07.918860
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(None) == Validation.success(None)
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success('a') == Validation.success('a')
    assert Validation.success([1, 2, 3]) == Validation.success([1, 2, 3])
    assert Validation.success({'a': 1}) == Validation.success({'a': 1})
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail(['a']) == Validation.fail(['a'])
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3])

# Generated at 2022-06-24 00:46:13.829774
# Unit test for constructor of class Validation
def test_Validation():
    # Test constructor with success
    assert Validation.success(value=1) == Validation(1, [])
    assert Validation.fail(errors=[1]) == Validation(None, [1])

    # Test constructor with fail
    assert Validation(value=1, errors=[]) == Validation(1, [])
    assert Validation(value=None, errors=[1]) == Validation(None, [1])


# Generated at 2022-06-24 00:46:15.747781
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: 4 * x) == Validation(8, [])

# Generated at 2022-06-24 00:46:21.006719
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail(['a']) == Validation.fail(['a'])
    assert Validation.fail(['a']) != Validation.fail(['b'])


# Generated at 2022-06-24 00:46:23.147530
# Unit test for method bind of class Validation
def test_Validation_bind():
    value = 'test'
    validation = Validation.success(value)
    new_validation = validation.bind(lambda x: Validation.fail())

    assert new_validation.value == value
    assert new_validation.errors == []
    assert new_validation.is_success() == False



# Generated at 2022-06-24 00:46:27.907856
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    def get_number():
        return Validation.success(10)

    assert Try(10).to_lazy() == Validation.success(10).to_lazy()
    assert Lazy(get_number()) == Validation.success(10).to_lazy()


# Generated at 2022-06-24 00:46:31.221625
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing
    from pymonet.validation import Validation

    success_validation = Validation.success(100)
    failure_validation = Validation.fail([1, 2, 3])

    assert success_validation.to_maybe() == Just(100)
    assert failure_validation.to_maybe() == Nothing()


# Generated at 2022-06-24 00:46:37.500411
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success('validation').to_either().is_right()
    assert Validation.success('validation').to_either().get_or_else(None) == 'validation'

    assert Validation.fail(['error']).to_either().is_left()
    assert Validation.fail(['error']).to_either().get_or_else(None) == ['error']


# Generated at 2022-06-24 00:46:41.947514
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    errors = [1, 2, 3]
    validation = Validation.fail(errors)

    assert validation.is_fail() is True
    assert validation.is_success() is False
    assert validation.errors == errors
    assert validation.value is None


# Generated at 2022-06-24 00:46:46.829003
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    validation = Validation.success(10)

    try_monad = validation.to_try()
    assert try_monad == Success(10)

    validation = Validation.fail(['error 1', 'error 2'])

    try_monad = validation.to_try()
    assert try_monad == Failure(['error 1', 'error 2'])

# Generated at 2022-06-24 00:46:51.050606
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    successful_validation = Validation.success(5)
    failing_validation = Validation.fail([])

    assert isinstance(successful_validation.to_maybe(), Maybe)
    assert successful_validation.to_maybe().is_nothing() is False
    assert successful_validation.to_maybe().is_just() is True

    assert isinstance(failing_validation.to_maybe(), Maybe)
    assert failing_validation.to_maybe().is_nothing() is True
    assert failing_validation.to_maybe().is_just() is False

test_Validation_to_maybe()


# Generated at 2022-06-24 00:46:57.026679
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.fail()) == "Validation.fail[None, []]"
    assert str(Validation.fail(["error1", "error2"])) == "Validation.fail[None, ['error1', 'error2']]"
    assert str(Validation.success(1)) == "Validation.success[1]"



# Generated at 2022-06-24 00:47:02.744717
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    validation_success = Validation.success(1)
    assert validation_success.is_success()

    validation_fail = Validation.fail()
    assert not validation_fail.is_success()


# Generated at 2022-06-24 00:47:08.188067
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:47:13.394953
# Unit test for method map of class Validation
def test_Validation_map():
    result = Validation.success(1).map(lambda v: v + 1)
    assert result == Validation(2, [])

    result = Validation.success(1).map(None)
    assert result == Validation(None, [])

    result = Validation.fail([1, 2]).map(None)
    assert result == Validation(None, [])


# Generated at 2022-06-24 00:47:18.502760
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    # input data
    validation_success = Validation.success(1)
    validation_fail = Validation.fail([1,2,3])

    # expected data
    expected_success = Validation.success(1)
    expected_fail = Validation.fail([1,2,3])

    # assert
    assert validation_success.to_try() == expected_success
    assert validation_fail.to_try() == expected_fail

# Generated at 2022-06-24 00:47:21.644600
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    # default
    assert Validation(None, []).is_success()

    # success
    assert Validation.success('value') == Validation('value', [])

    # fail
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:47:25.189093
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    def get_lazy_box(fn, *args):
        return fn(*args).to_lazy()

    assert get_lazy_box(Validation.success, Box('Monad')) == Lazy(lambda: Box('Monad'))
    assert get_lazy_box(Validation.fail, None) == Lazy(lambda: None)

# Generated at 2022-06-24 00:47:26.596269
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.fail([1]).is_fail()



# Generated at 2022-06-24 00:47:31.812282
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    # when validation has no errors
    assert Validation(1, []).to_maybe() == Maybe.just(1)
    # when validation has some errors
    assert Validation(1, [1, 2, 3]).to_maybe() == Maybe.nothing()

    # isSuccessful validation
    assert Validation(Try(1), []).to_maybe() == Maybe.just(Try(1))
    # isFailed validation
    assert Validation(Try(1), [1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:47:35.314211
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success("abc").ap(lambda i: Validation.success("abc" + i)) == Validation.success("abcabc")
    assert Validation.success("abc").ap(lambda i: Validation.fail("error" + i)) == Validation.fail("errorabc")


# Generated at 2022-06-24 00:47:37.929155
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation([], [])) == 'Validation.success[[]]'
    assert str(Validation(None, ['fail'])) == 'Validation.fail[None, [\'fail\']]'


# Generated at 2022-06-24 00:47:43.195813
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either

    assert Validation.success(5).to_either() == Either.right(5)
    assert Validation.fail([1]).to_either() == Either.left([1])
    assert Validation.fail([]).to_either() == Either.left([])


# Generated at 2022-06-24 00:47:45.950962
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Mapping function on Validation monad should return new monad with mapped value.

    :returns: Assertion Error when test fails
    """
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-24 00:47:49.377994
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation
    from pymonet.validation import Success, Fail

    assert Success(1).to_maybe() == Maybe.just(1)
    assert Success(None).to_maybe() == Maybe.just(None)
    assert Success(True).to_maybe() == Maybe.just(True)
    assert Success(False).to_maybe() == Maybe.just(False)

    assert Fail([]).to_maybe() == Maybe.nothing()
    assert Fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:47:54.770122
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Unit test that confirms that to_try method works correctly.
    """
    assert Validation.success('foo').to_try().is_success
    assert Validation.fail(['foo', 'bar']).to_try().is_success == False


# Generated at 2022-06-24 00:47:57.796338
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('ok').is_success()
    assert isinstance(Validation.success('ok').is_success(), bool)
    assert Validation.fail(['error 1']).is_success() is False


# Generated at 2022-06-24 00:48:03.726757
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.success(1).is_success() is True
    assert Validation.success('s').is_success() is True
    assert Validation.success([]).is_success() is True
    assert Validation.success({}).is_success() is True
    assert Validation.success(None).is_success() is True

    assert Validation.fail([1]).is_success() is False
    assert Validation.fail([1, 2]).is_success() is False
    assert Validation.fail(['a']).is_success() is False
    assert Validation.fail('a').is_success() is False


# Generated at 2022-06-24 00:48:13.857618
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_validation import Validation

    validation_f = Validation.fail(['error1', 'error2'])
    result = validation_f.ap(lambda x: Validation.fail(['error3']))
    assert result == Validation.fail(['error1', 'error2', 'error3'])

    validation_s = Validation.success(2)
    result = validation_s.ap(lambda x: Validation.fail(['error1']))
    assert result == Validation.fail(['error1'])

    validation_s_2 = Validation.success(2)
    result = validation_s_2.ap(lambda x: Validation.success(x))
    assert result == Validation.success(2)

    validation_f_2 = Validation.fail(['error1'])


# Generated at 2022-06-24 00:48:15.944848
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(2) == Validation(2, [])
    assert Validation.fail(['2']) == Validation(None, ['2'])


# Generated at 2022-06-24 00:48:18.417428
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation_box = Validation(Box(2), []).to_box()

    print(validation_box)
    print(validation_box.get_monad())


# Generated at 2022-06-24 00:48:21.934899
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.success(10)
    obj = validation.to_try()
    assert isinstance(obj, Try)

    assert obj.is_success
    assert obj.get() == 10

    validation = Validation.fail([10])
    obj = validation.to_try()
    assert isinstance(obj, Try)

    assert not obj.is_success
    assert obj.get() is None

# Generated at 2022-06-24 00:48:27.381772
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    # bind
    >>> test_Validation_bind()
    Validation.success[54]
    """
    def folder(value):
        return Validation.success(value * 2)

    validation = Validation.success(27).bind(folder).bind(folder)
    print(validation)


# Generated at 2022-06-24 00:48:29.861664
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(10, []) == Validation.success(10)
    assert Validation(None, ['A']) == Validation.fail(['A'])



# Generated at 2022-06-24 00:48:38.068664
# Unit test for method is_success of class Validation
def test_Validation_is_success():  # pragma: no cover
    """
    Unit test for method is_success of class Validation
    """
    assert Validation.success().is_success() == True
    assert Validation.success([1, 2, 3]).is_success() == True
    assert Validation.success(1).is_success() == True
    assert Validation.success(1.1).is_success() == True
    assert Validation.success(None).is_success() == True
    assert Validation.success('1').is_success() == True
    assert Validation.success({'a':1, 'b': 2, 'c':3}).is_success() == True

    assert Validation.fail().is_success() == False
    assert Validation.fail([1, 2, 3]).is_success() == False

# Generated at 2022-06-24 00:48:39.996438
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)


# Generated at 2022-06-24 00:48:49.755811
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    test_success_1 = Validation.success('test')
    test_success_2 = Validation.success('test')
    test_fail_1 = Validation.fail(['fail'])
    test_fail_2 = Validation.fail(['fail'])
    test_fail_3 = Validation.fail(['fail_1', 'fail_2'])

    assert test_success_1 == test_success_2
    assert test_fail_1 == test_fail_2
    assert test_fail_1 != test_fail_3

    assert test_success_1 != test_fail_1


# Generated at 2022-06-24 00:48:51.741373
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-24 00:48:59.451838
# Unit test for method ap of class Validation
def test_Validation_ap():
    def validation_fn_that_returns_empty_list(x):
        return Validation.success(x)

    def validation_fn_that_returns_1_in_list(x):
        return Validation.fail([1])

    def validation_fn_that_returns_1_in_list_and_returns_2_in_list(x):
        return Validation.fail([1, 2])

    assert Validation.success(10).ap(validation_fn_that_returns_empty_list) == Validation.success(10)
    assert Validation.success(10).ap(validation_fn_that_returns_1_in_list) == Validation.fail([1])

# Generated at 2022-06-24 00:49:01.567698
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.fail(["error"]).to_maybe() == Maybe.nothing()
    assert Validation.success(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:49:06.771956
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation\
        .success(48)\
        .to_lazy()\
        .eval() == 48

# Generated at 2022-06-24 00:49:17.247126
# Unit test for constructor of class Validation
def test_Validation():
    # Test for constructor of Successful Validation
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success([1, 2]) == Validation([1, 2], [])
    assert Validation.success('a') == Validation('a', [])
    assert Validation.success({'a': 1}) == Validation({'a': 1}, [])
    assert Validation.success(None) == Validation(None, [])

    # Test for constructor of Failed Validation
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail([1, 2]) == Validation(None, [1, 2])
    assert Validation

# Generated at 2022-06-24 00:49:23.083296
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:49:30.006271
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Either
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # type: Validation[A, List[E]]
    validation_success = Validation.success(1)
    validation_fail = Validation.fail([])

    assert validation_success.to_maybe() == Maybe.just(1)
    assert validation_fail.to_maybe() == Maybe.nothing()

    # type: Validation[Either[A, List[E]], List[E]]
    validation_success = Validation.success(Either.right(1))
    validation_fail = Validation.success(Either.left([]))


# Generated at 2022-06-24 00:49:40.708707
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy

    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda x: Right(1)) == Validation.success(Right(1))

    assert Validation.success(1).map(lambda _: Lazy(lambda: 1)).value() == Validation.success(1).value

    assert Validation.fail(["error"]).map(lambda x: x + 1) == Validation.fail(["error"])
    assert Validation.fail(["error"]).map(lambda x: Right(1)) == Validation.fail(["error"])



# Generated at 2022-06-24 00:49:42.095697
# Unit test for method bind of class Validation
def test_Validation_bind():
    test_bind(asList(1, None), Validation.success(1))

# Generated at 2022-06-24 00:49:52.162328
# Unit test for constructor of class Validation
def test_Validation():
    """Checks Validation class constructor"""
    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, []) != Validation(2, [])
    assert Validation(1, [1]) != Validation(1, [])
    assert Validation(None, []) != Validation(1, [])
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert repr(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, [1])) == 'Validation.fail[1, [1]]'
    assert repr(Validation(1, [1])) == 'Validation.fail[1, [1]]'


# Generated at 2022-06-24 00:49:53.950194
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # GIVEN successful Validation
    validation = Validation.success('John')

    # WHEN is_fail method is called
    result = validation.is_fail()

    # THEN False is returned
    assert result == False


# Generated at 2022-06-24 00:49:58.167614
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:49:59.899167
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    sut = Validation.success()
    assert sut.is_success()


# Generated at 2022-06-24 00:50:03.513742
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success().to_try() == Try.success()
    assert Validation.success('test').to_try() == Try.success('test')

    assert Validation.fail().to_try() == Try.failure()



# Generated at 2022-06-24 00:50:06.572500
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == 'Validation.success[1]'

    assert str(Validation(None, [1, 2])) == 'Validation.fail[None, [1, 2]]'



# Generated at 2022-06-24 00:50:14.921792
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    # should return Right with value 1
    assert Validation.success(1).to_either() == Right(1)

    # should return Left with value 'x'
    assert Validation.fail(['x']).to_either() == Left(['x'])

    # should return Left with value 'y'
    assert Validation.fail(['x', 'y']).to_either() == Left(['x', 'y'])


# Generated at 2022-06-24 00:50:17.585082
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.fail([1]).is_success() == False


# Generated at 2022-06-24 00:50:20.791562
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:50:25.145520
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.validation import Validation

    assert Validation.success().is_success()
    assert Validation.success(2).is_success()
    assert Validation.success([]).is_success()
    assert Validation.success(None).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail(['error']).is_success()
    assert not Validation.fail([[]]).is_success()
    assert not Validation.fail(None).is_success()


# Generated at 2022-06-24 00:50:27.363187
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.monoid import Sum
    from pymonet.maybe import Just, Nothing

    validation = Validation.success(123)
    assert validation.to_maybe() == Just(123)

    validation = Validation.fail([Sum(123)])
    assert validation.to_maybe() == Nothing()


# Generated at 2022-06-24 00:50:35.437230
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.lazy import Lazy

    def f(value):
        return Lazy(lambda: value)

    def g(value):
        return Lazy(lambda: value + 2)

    def h(value):
        return Lazy(lambda: value * 3)

    validation = Validation.success(10)
    assert validation == validation.bind(f).bind(g).bind(h)

    validation = Validation.fail(['Error 1', 'Error 2'])
    assert validation == validation.bind(f).bind(g).bind(h)

# Generated at 2022-06-24 00:50:41.597069
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    It tests method to_try of class Validation.
    """
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    assert Validation.success('test').to_try() == Success('test')
    assert Validation.fail(['error1']).to_try() == Failure(['error1'])


# Generated at 2022-06-24 00:50:47.009404
# Unit test for constructor of class Validation
def test_Validation():
    success = Validation.success("value")
    assert isinstance(success, Validation)
    assert success.value == "value"
    assert success.errors == []
    assert success.is_success()

    fail = Validation.fail([1, 2, 3])
    assert isinstance(fail, Validation)
    assert fail.value is None
    assert fail.errors == [1, 2, 3]
    assert fail.is_fail()


# Generated at 2022-06-24 00:50:54.339879
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    fun = lambda x: x + 1
    expect = Left([])
    actual = Validation.fail().to_either().left_map(fun)

    assert expect == actual

    expect = Right(2)
    actual = Validation.success(1).to_either().right_map(fun)

    assert expect == actual


# Generated at 2022-06-24 00:51:00.641492
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    succ = Validation.success(1)
    res = succ.to_lazy()
    assert(res == Lazy(lambda: 1))

    fail = Validation.fail(errors=['a', 'b'])
    res = fail.to_lazy()
    assert(res == Lazy(lambda: None))


# Generated at 2022-06-24 00:51:06.168430
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    empty_list = Validation.fail()
    empty_list_either = empty_list.to_either()
    assert empty_list_either.is_left() == True
    assert empty_list_either.is_right() == False
    assert empty_list_either.value == []
    empty_list_either_errors = empty_list_either.left()
    assert empty_list_either_errors.is_just() == True
    assert empty_list_either_errors.is_nothing() == False
    assert empty_list_either_errors.value == []

    single_error = Validation.fail(['error'])
    single_error_either = single_error.to_either()
    assert single_error_either.is_left() == True
    assert single_error_either.is_right() == False
    single_

# Generated at 2022-06-24 00:51:08.030512
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_box import test_Validation_to_box
    test_Validation_to_box(Validation)


# Generated at 2022-06-24 00:51:12.338563
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def side_effect_function():
        side_effect_variable = 1
        return 3

    validation = Validation.success(side_effect_function)
    lazy_value = validation.to_lazy().value()
    assert lazy_value() == 3

# Generated at 2022-06-24 00:51:21.320961
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Define test cases
    test_cases = [
        # (expected, test_id, e, a)
        (True, 'null-null', Validation.fail([]), Validation.fail([])),
        (True, 'value-value', Validation.success(1), Validation.success(1)),
        (False, 'null-value', Validation.fail([]), Validation.success(None)),
        (False, 'not-equal-value', Validation.success(1), Validation.success(2)),
        (False, 'not-equal-errors', Validation.success(None, [1]), Validation.success(None, [2]))
    ]

    # Execute test cases

# Generated at 2022-06-24 00:51:28.439072
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Validation.success(1).to_box()
    assert Validation.success(2).to_box() != Validation.fail([3, 4]).to_box()
    assert Validation.fail([1, 2]).to_box() == Validation.fail([1, 2]).to_box()
    assert Validation.fail([3, 4]).to_box() != Validation.success(5).to_box()
    assert Validation.success(1).to_box() != Validation.success(2).to_box()
    assert Validation.fail([1, 2]).to_box() != Validation.fail([3, 4]).to_box()


# Generated at 2022-06-24 00:51:33.486244
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    It tests first method of class Validation.
    """
    assert str(Validation.success(23)) == 'Validation.success[23]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:51:35.042626
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    pass
# -------------------------------------------------------


# -------------------------------------------------------

# Generated at 2022-06-24 00:51:40.005434
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    def fn(value):
        return Validation.success()

    assert Validation.success(1).ap(fn) == Validation.success(1)

    def fn(value):
        return Validation.fail(['error'])

    assert Validation.success(1).ap(fn) == Validation.fail(['error'])


# Generated at 2022-06-24 00:51:46.184743
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for method ap of class Validation"""
    from pymonet.validation import Validation
    from pymonet.functor import Functor

    assert Validation.success(5).ap(Functor.just(lambda x: x + 2)) == Validation.success(7)
    assert Validation.success(5).ap(Functor.just(lambda x: x / 2)) == Validation.success(2.5)
    assert Validation.fail(['x']).ap(Functor.just(lambda x: x + 2)) == Validation.fail(['x'])
    assert Validation.success(5).ap(Functor.fail(lambda x: x / 0)) == Validation.fail(['x'])


# Generated at 2022-06-24 00:51:49.542660
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(99).is_success() is True
    assert Validation.fail(errors=["error1"]).is_success() is False



# Generated at 2022-06-24 00:51:55.286606
# Unit test for constructor of class Validation
def test_Validation():
    eq_(Validation.success(5), Validation(5, []))
    eq_(Validation.fail(['err']), Validation(None, ['err']))
    assert Validation.fail(['err']).is_fail()
    assert Validation.success(5).is_success()


# Generated at 2022-06-24 00:52:00.424297
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-24 00:52:04.084821
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for is_success method of class Validation.
    """
    assert Validation.success().is_success()
    assert Validation.success([1, 2, 3]).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail([1, 2, 3]).is_success()


# Generated at 2022-06-24 00:52:06.818659
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    assert Validation.success("test").to_try() == Try("test", is_success=True)
    assert Validation.fail(["fail"]).to_try() == Try("fail", is_success=False)



# Generated at 2022-06-24 00:52:10.639269
# Unit test for method bind of class Validation
def test_Validation_bind():
    def test_function_that_returns_Validation(value):
        if value == 2:
            return Validation.success(value * 2)
        else:
            return Validation.fail(["Value have to be equal 2, '{}' given".format(value)])
    assert Validation.success(2).bind(test_function_that_returns_Validation) == Validation.success(4)


# Generated at 2022-06-24 00:52:12.921444
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:22.693532
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    assert Validation.success('123').bind(lambda x: Validation.success(int(x))) == Validation.success(123)
    assert Validation.success('123').bind(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda x: Validation.success(int(x))) == Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])



# Generated at 2022-06-24 00:52:26.768107
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    success = Validation.success('test')
    assert success.to_maybe() == Maybe.just('test')

    fail = Validation.fail(['test'])
    assert fail.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:34.055734
# Unit test for method ap of class Validation
def test_Validation_ap():
    m = Validation.success(lambda x: x + 3)
    v = Validation.success(2)
    assert v.ap(m) == Validation.success(5)
    assert v.ap(m).to_maybe() == Maybe.just(5)

    m_2 = Validation.fail(['some error'])
    v_2 = Validation.success(2)
    assert v_2.ap(m_2) == Validation.success(None)
    assert v_2.ap(m_2).to_maybe() == Maybe.nothing()

    m_3 = Validation.fail(['some error'])
    v_3 = Validation.fail(['some error 2'])
    assert v_3.ap(m_3) == Validation.fail(['some error 2', 'some error'])

   

# Generated at 2022-06-24 00:52:41.958169
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.functor import Functor

    validations = [
        # Success, Success
        Validation.success(1).bind(lambda x: Validation.success(x + 1)),
        # Success, Failure
        Validation.success(2).bind(lambda x: Validation.fail(['error'])),
        # Failure, Success
        Validation.fail(['error']).bind(lambda x: Validation.success(42)),
        # Failure, Failure
        Validation.fail(['error1']).bind(lambda x: Validation.fail(['error2']))]
    expected_validations = [
        Validation.success(2),
        Validation.fail(['error']),
        Validation.fail(['error']),
        Validation.fail(['error1', 'error2'])]


# Generated at 2022-06-24 00:52:45.794342
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Box(1) == Validation(1, []).to_box()



# Generated at 2022-06-24 00:52:52.316561
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    # Successful Validation
    assert Validation.success(1).to_either() == Right(1)
    # Error Validation
    assert Validation.fail(['foo']).to_either() == Left(['foo'])



# Generated at 2022-06-24 00:52:54.505765
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(['a']) == Validation(None, ['a'])


# Generated at 2022-06-24 00:52:58.558533
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Failure

    assert Validation.success(True).to_lazy() == Lazy(lambda: True)
    assert Validation.fail([True]).to_lazy() == Lazy(lambda: None)


# Unit tests for methods ap and bind of class Validation

# Generated at 2022-06-24 00:53:07.090968
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet import spy, assert_that
    from pymonet.monad_try import Success, Failure

    spy_tests = spy(test_Validation_to_try)
    spy_tests.spy_method(Validation.__init__, returns=Validation.success(1))

    Validation.success(1).to_try() == Success(1)
    Validation.fail([1]).to_try() == Failure([1])

    assert_that(spy_tests.spied_methods_calls_count).is_equal_to(2)


# Generated at 2022-06-24 00:53:09.788846
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail(['error1']).to_try() == Try(None)


# Generated at 2022-06-24 00:53:14.868710
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success(42).is_fail()
    assert Validation.fail([42]).is_fail()


# Generated at 2022-06-24 00:53:21.825706
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    import unittest

    class TestValidationIsFail(unittest.TestCase):
        def test_is_fail(self):
            self.assertTrue(Validation.fail(['One', 'Two']).is_fail())
            self.assertFalse(Validation.success(1).is_fail())

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestValidationIsFail))
    unittest.TextTestRunner().run(suite)

# Generated at 2022-06-24 00:53:25.417667
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(1)) == 'Validation.fail[None, 1]'


# Generated at 2022-06-24 00:53:31.094915
# Unit test for constructor of class Validation
def test_Validation():
    validation_successful = Validation.success(value=1)
    validation_failed = Validation.fail(errors=[1, 2, 3])

    assert validation_successful == Validation(value=1, errors=[])
    assert validation_failed == Validation(value=None, errors=[1, 2, 3])


# Generated at 2022-06-24 00:53:35.265079
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() == True
    assert Validation.success(1).is_fail() == False


# Generated at 2022-06-24 00:53:46.259782
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation

    """
    simple_validation = Validation.success(10)
    assert simple_validation.ap(lambda x: Validation.success(x + 10)) == Validation.success(20)

    validation_with_errors = Validation.fail(['error1', 'error2', 'error3'])
    assert validation_with_errors.ap(lambda x: Validation.success(x + 10)) == validation_with_errors

    complex_validation_with_errors = Validation.fail(['error1', 'error2', 'error3']).ap(
        lambda x: Validation.success(x + 10)).ap(lambda x: Validation.fail(['error4', 'error5', 'error6']))
    assert complex_validation_with_errors == Validation.fail

# Generated at 2022-06-24 00:53:48.733678
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success('mapped').map(lambda x: x[::-1]) == Validation.success('depmam')
    assert Validation.fail(['error1', 'error2']).map(lambda x: x[::-1]) == Validation.fail(
        ['error1', 'error2'])


# Generated at 2022-06-24 00:53:50.402470
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[10]' == str(Validation.success(10))
    assert 'Validation.fail[None, [1, 2, 3]]' == str(Validation.fail([1, 2, 3]))



# Generated at 2022-06-24 00:53:58.312013
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    with Lazy(lambda: Try(lambda: 1/0).to_lazy()) as lazy:
        assert lazy.to_lazy() == Lazy.wrap(Try(lambda: 1/0).to_maybe().to_lazy())

        with Try(lazy.evaluate) as result:
            assert result == Try(1/0).to_lazy().evaluate()


# Generated at 2022-06-24 00:54:04.245766
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success().to_try() == Success(None)
    assert Validation.success(1).to_try() == Success(1)
    assert Validation.fail().to_try() == Failure(None)
    assert Validation.fail([1, 2]).to_try() == Failure([1, 2])


# Generated at 2022-06-24 00:54:10.721090
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(42).is_success()
    assert Validation.fail(['first error']).is_success() == False

    assert Validation.success(Try.fail('something went wrong')).is_success()
    assert Validation.success(Box.from_value(42)).is_success()
    assert Validation.success(Maybe.just(42)).is_success()
