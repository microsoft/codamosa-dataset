

# Generated at 2022-06-24 00:44:17.150147
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    lazy = Validation.success(5).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.to_value() == 5


# Generated at 2022-06-24 00:44:21.058445
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(5).to_either() == Right(5)
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail(errors=['error 1']).to_either() == Left(['error 1'])


# Generated at 2022-06-24 00:44:26.614027
# Unit test for method bind of class Validation
def test_Validation_bind():
    def divide(x, y):
        if y == 0:
            return Validation.fail([ValueError()])
        return Validation.success(x / float(y))

    res1 = Validation.success(10) \
        .bind(lambda x: divide(x, 0)) \
        .bind(lambda x: divide(x, 0))
    assert res1 == Validation(None, [ValueError(), ValueError()])

    res2 = Validation.success(10) \
        .bind(lambda x: divide(x, 2)) \
        .bind(lambda x: divide(x, 0))
    assert res2 == Validation(None, [ValueError()])


# Generated at 2022-06-24 00:44:30.730937
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation("Monad", []).ap(lambda x: Validation(x, [])) == Validation("Monad", [])
    assert Validation("Monad", ["Error1", "Error2"]).ap(lambda x: Validation(x, [])) == Validation("Monad", ["Error1", "Error2"])
    assert Validation("Monad", []).ap(lambda x: Validation(x, ["Error1", "Error2"])) == Validation("Monad", ["Error1", "Error2"])
    assert Validation("Monad", ["Error1"]).ap(lambda x: Validation(x, ["Error2"])) == Validation("Monad", ["Error1", "Error2"])


# Generated at 2022-06-24 00:44:36.438369
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(3).map(lambda x: x + 1) == Validation(4, [])
    assert Validation.success(3).map(lambda x: x + 1).value == 4
    assert Validation.success(3).map(lambda x: x + 1).errors == []
    assert Validation.fail(['error1']).map(lambda x: x + 1) == Validation(None, ['error1'])
    assert Validation.fail(['error1']).map(lambda x: x + 1).value == None
    assert Validation.fail(['error1']).map(lambda x: x + 1).errors == ['error1']


# Generated at 2022-06-24 00:44:43.350871
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Failure

    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.success(None).to_maybe() == Maybe.just(None)
    assert Validation.fail([Failure(Exception())]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:44:47.551756
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert not Validation.success(1) == Validation.success(2)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) == Validation.fail([1])
    assert not Validation.fail([2]) == Validation.fail([1])
    assert not Validation.success(1) == Validation.fail([])


# Generated at 2022-06-24 00:44:52.481529
# Unit test for method map of class Validation
def test_Validation_map():
    """Test various possible outcomes for Validation.map function."""

    assert Validation.success(1).map(lambda x: x * 2) == Validation.success(2)
    assert Validation.fail(['error']).map(lambda x: x * 2) == Validation.fail(['error'])



# Generated at 2022-06-24 00:44:58.678765
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """ Unit test for method is_fail of class Validation """
    assert Validation.success().is_fail() == False
    assert Validation.fail().is_fail() == True
    assert Validation.fail(['err']).is_fail() == True


# Generated at 2022-06-24 00:45:06.274619
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover

    def fn(a):
        return Validation.success(a)

    # When Validation object is successful and has value [1,2,3]
    # and function is successful
    # then result is successful Validation with previous value and empty errors list
    assert Validation.success([1, 2, 3]).ap(fn) == Validation.success([1, 2, 3])

    # When Validation object is successful and has value [1,2,3]
    # and function is not successful
    # then result is successful Validation with previous value and empty errors list
    def fn1(a):
        return Validation.fail(['this is error'])

    assert Validation.success([1, 2, 3]).ap(fn1) == Validation.success([1, 2, 3])

    # When Validation object is

# Generated at 2022-06-24 00:45:12.056625
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test for Validation.ap method.
    """
    from pymonet.validation import Validation
    from pymonet.either import Left

    assert(
        Validation.success(['A']).ap(lambda x: Validation.success(x)) ==
        Validation.success(['A'])
    )
    assert(
        Validation.success(['A']).ap(lambda x: Validation.fail(['B'])) ==
        Validation.fail(['B'])
    )

# Generated at 2022-06-24 00:45:20.472143
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Create sample Validation and Test to_maybe method.

    :return: None
    """
    # Create sample valid and invalid Validations
    successfull_v = Validation.success(5)
    failed_v = Validation.fail([1, 2])

    # You can use to_maybe method to return Maybe with value from Validation
    # When Validation is successfull
    successfull_m = successfull_v.to_maybe()
    # When Validation is not successfull
    failed_m = failed_v.to_maybe()


# Generated at 2022-06-24 00:45:23.873719
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('').is_success()
    assert not Validation.fail([]).is_success()



# Generated at 2022-06-24 00:45:25.132953
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(3).is_success()

# Generated at 2022-06-24 00:45:32.583263
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation.to_lazy() method
    """
    def test():
        """
        Test function
        """
        return 7
    lazy = Validation.success().to_lazy()
    assert lazy.eval() is None

    lazy = Validation.success(1).to_lazy()
    assert lazy.eval() == 1

    to_lazy = Validation.success(1).bind(lambda x: Validation.success(test)).to_lazy()
    assert to_lazy.bind(lambda x: Lazy(lambda: x())).eval() == 7

    to_lazy = Validation.fail().bind(lambda x: Validation.success(test)).to_lazy()
    assert to_lazy.bind(lambda x: Lazy(lambda: x())).eval() is None

    to_l

# Generated at 2022-06-24 00:45:34.002918
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Simple test for is_fail method"""
    assert Validation.fail(['error']).is_fail()
    assert not Validation.fail().is_fail()
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-24 00:45:37.866638
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    validation = Validation.success(1)
    assert validation.to_either() == Right(1)

    validation = Validation.fail([1, 2])
    assert validation.to_either() == Left([1, 2])



# Generated at 2022-06-24 00:45:49.667386
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success().is_success() == True
    assert Validation.success(0).is_success() == True
    assert Validation.success('').is_success() == True
    assert Validation.success('42').is_success() == True
    assert Validation.success(42).is_success() == True
    assert Validation.success(42.0).is_success() == True
    assert Validation.success([]).is_success() == True
    assert Validation.success({}).is_success() == True
    assert Validation.success([1, 2, 3]).is_success() == True
    assert Validation.success({'a': 1}).is_success() == True
    assert Validation.success(True).is_success() == True
    assert Validation.success(False).is_success() == True

# Generated at 2022-06-24 00:45:52.699523
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing
    from pymonet.either import Right, Left

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail([1]).to_maybe() == Nothing()

# Generated at 2022-06-24 00:45:56.455075
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success(1)
    assert str(success) == 'Validation.success[1]'

    fail = Validation.fail([1, 2, 3])
    assert str(fail) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:46:00.990286
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(3, []).to_maybe() == Maybe.just(3)
    assert Validation(None, []).to_maybe() == Maybe.just(None)
    assert Validation(None, [1, 2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:46:07.398063
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It tests to_lazy method of Validation monad.
    """
    from pymonet.lazy import Lazy

    def use_lazy(avalue):
        """
        Placholder for possible monad's value usage.

        :params avalue: value to use.
        :type avalue: (A)
        """
        pass

    validation = Validation.success('value')
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.get_value() == 'value'

    use_lazy(lazy.get_value())

# Generated at 2022-06-24 00:46:12.410047
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([]).to_try() == Try(None, is_success=False)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:46:23.818639
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    # 'Unit test' for method ap of class Validation
    #
    # method ap for Validation monad takes as a parameter function returning another Validation.
    # Function is called with Validation value and returns new Validation with previous value
    # and concated new and old errors.
    #
    # def ap(self, fn):
    #     return Validation(self.value, self.errors + fn(self.value).errors)

    def add_errors(value):
        return Validation(value, [value])

    assert Validation('test', ['validation']).ap(add_errors) == Validation('test', ['validation', 'test'])
    assert Validation('test', []).ap(add_errors) == Validation('test', ['test'])

# Generated at 2022-06-24 00:46:26.550531
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test that validation can be converted to box.
    """
    assert Validation.fail([1, 2, 3]).to_box().is_empty()
    assert Validation.success(10).to_box().is_present()
    assert Validation.success(10).to_box().get() == 10


# Generated at 2022-06-24 00:46:28.169196
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Method is_fail should return True when errors are empty.
    """
    assert Validation.success().is_fail() is False
    assert Validation.fail().is_fail() is True


# Generated at 2022-06-24 00:46:30.338027
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)


# Generated at 2022-06-24 00:46:37.090804
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.tests import assert_equal

    assert_equal(Validation.success(1), Validation.success(1))
    assert_equal(Validation.fail([]), Validation.fail([]))
    assert_equal(Validation.success(1), Validation(1, []))
    assert_equal(Validation.fail([1]), Validation(None, [1]))


# Generated at 2022-06-24 00:46:46.662965
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right, Either
    from pymonet.monad_try import Try

    # map function
    def double(x):
        return x * 2

    # Validation.success(Value)
    validation = Validation.success(1)
    # Validation.success(Value)
    r = Validation.success(2)

    # test map Validation.success(Value)
    assert validation.map(double) == r

    # test map Either.Right(Value)
    assert validation.map(double) == r

    # test map Try.Success(Value)
    assert validation.map(double) == r

    # Validation.fail(Errors)
    validation = Validation.success([])
    # Validation.fail(Value)
    r = Validation.fail([])

    # test map

# Generated at 2022-06-24 00:46:54.453136
# Unit test for method map of class Validation
def test_Validation_map():
    def f(x): return x * 2

    assert Validation(2, []).map(f) == Validation(4, []), \
        "Validation map method failed"
    assert Validation(2, [1, 2]).map(f) == Validation(4, [1, 2]), \
        "Validation map method failed"
    assert Validation(None, [1, 2]).map(f) == Validation(None, [1, 2]), \
        "Validation map method failed"


# Generated at 2022-06-24 00:46:56.552019
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_success():
        assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    test_success()

    def test_fail():
        assert Validation.fail().to_lazy() == Lazy(lambda: None)
    test_fail()


# Generated at 2022-06-24 00:46:58.749709
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation(1, []).to_box() == Box(1)

# Generated at 2022-06-24 00:47:01.165959
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()


# Generated at 2022-06-24 00:47:03.243082
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success('success').to_either() == Right('success')
    assert Validation.fail(['fail']).to_either() == Left(['fail'])


# Generated at 2022-06-24 00:47:10.356304
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """Unit test for to_box method of class Validation."""
    from pymonet.box import Box

    assert Validation.success(5).to_box() == Box(5)
    assert Validation.success().to_box() == Box(None)
    assert Validation.fail(1).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:47:16.790316
# Unit test for method map of class Validation
def test_Validation_map():
    assert(Validation.success(1).map(lambda a: a + 1) == Validation(2, []))
    assert(Validation.success(2).map(lambda a: a * 3) == Validation(6, []))

    assert(Validation.fail([1, 2]).map(lambda a: a * 3) == Validation(None, [1, 2]))
    assert(Validation.fail([1]).map(lambda a: a * 3) == Validation(None, [1]))


# Generated at 2022-06-24 00:47:24.534402
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation.ap
    """
    assert Validation.success(None).ap(lambda _: Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.success(True).ap(lambda v: Validation.fail(['error']) if v else Validation.success(None)) == Validation.success(None)
    assert Validation.fail(['error']).ap(lambda _: Validation.success(None)) == Validation.fail(['error'])
    assert Validation.fail(['error']).ap(lambda _: Validation.fail(['error'])) == Validation.fail(['error', 'error'])

# Generated at 2022-06-24 00:47:26.677174
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['some error']).is_fail()
    assert not Validation.success(123).is_fail()


# Generated at 2022-06-24 00:47:30.483834
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.fail(['error']).map(lambda x: x**2) == Validation(None, ['error'])
    assert Validation.success(100).map(lambda x: x**2) == Validation(10000, [])
    assert Validation.fail(['error']).map(lambda x: x**3).map(lambda x: x**2) == Validation(None, ['error'])


# Generated at 2022-06-24 00:47:35.337700
# Unit test for method to_try of class Validation
def test_Validation_to_try():

    from pymonet.monad_try import Try

    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)
    assert Validation.success(['value']).to_try() == Try(['value'], is_success=True)


# Generated at 2022-06-24 00:47:42.783463
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    assert Validation.success(1).to_try().get_or_else(None) == 1
    assert Validation.success(1).to_try().is_success() is True
    assert Validation.fail([1]).to_try().get_or_else([1]) == [1]
    assert Validation.fail([1]).to_try().is_success() is False


# Generated at 2022-06-24 00:47:48.635264
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(6) == Validation.success(6)
    assert Validation.success(6) != Validation.success(7)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail(['error']) != Validation.fail([])
    assert Validation.fail([]) != Validation.fail(['error'])
    assert Validation.fail(['error1']) != Validation.fail(['error2'])
    assert Validation.success(6) != Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.success(6)


# Generated at 2022-06-24 00:48:00.248130
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    @test
    def test_to_maybe_for_success_validation():
        @test
        def test_to_maybe_for_success_validation_called_with_string():
            @test
            def test_to_maybe_for_success_validation_called_with_string_returns_just_for_string():
                assert Validation.success("test").to_maybe() == Maybe.just("test")

        @test
        def test_to_maybe_for_success_validation_called_with_integer():
            @test
            def test_to_maybe_for_success_validation_called_with_integer_returns_just_for_integer():
                assert Validation.success(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:48:02.136275
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    assert Validation.success(5).is_success() is True
    assert Validation.fail([1]).is_success() is False
    assert Validation.fail([]).is_success() is False



# Generated at 2022-06-24 00:48:11.915748
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert Validation.success().to_box() == Validation.success().to_box()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1).to_box() == Validation.success(1).to_box()
    assert Validation.success(1).to_box() == Validation.success(1)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']).to_box() == Validation.fail(['error']).to_box()
    assert Validation.fail(['error']).to_box() == Validation.fail(['error'])
    assert Validation.success(1) != Validation.success(2)
   

# Generated at 2022-06-24 00:48:15.010268
# Unit test for method map of class Validation
def test_Validation_map():
    assert_that(Validation.success(1).map(lambda x: x * 2), equal_to(Validation.success(2)))
    assert_that(Validation.fail().map(lambda x: x * 2), equal_to(Validation.fail()))


# Generated at 2022-06-24 00:48:17.902285
# Unit test for method __str__ of class Validation
def test_Validation___str__():

    assert str(Validation.success(2)) == 'Validation.success[2]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:48:20.096293
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(1, []).is_fail() == False
    assert Validation(None, ['error 1']).is_fail() == True


# Generated at 2022-06-24 00:48:23.775397
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(Try(1)).to_either() == Left(Try(1))

# Unit tests for method to_maybe of class Validation

# Generated at 2022-06-24 00:48:30.441535
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('first')) == 'Validation.success[first]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['failure'])) == "Validation.fail[None, ['failure']]"


# Generated at 2022-06-24 00:48:33.038374
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:48:38.353946
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    # Unit test for method to_either of class Validation
    validation1 = Validation(1, ['error1'])
    assert validation1.to_either() == Left(['error1'])
    validation2 = Validation(1, [])
    assert validation2.to_either() == Right(1)


# Generated at 2022-06-24 00:48:40.726588
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    # Setup
    validation = Validation.success()

    # Exercise

    # Verify
    assert validation.to_box() == Box(None)

    # Cleanup - none necessary

# Generated at 2022-06-24 00:48:48.115322
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.function import compose

    assert compose(
        lambda x: x + 1,
        Validation.success)\
        .bind(lambda x: Validation.fail(['error1', 'error2'])) == Validation.fail(['error1', 'error2'])
    assert compose(
        lambda x: x + 1,
        Validation.success(1))\
        .bind(lambda x: Validation.success(x + 1)) == Validation.success(3)
    assert compose(
        lambda x: x + 1,
        Validation.fail(['error1', 'error2']))\
        .bind(lambda x: Validation.success(x + 1)) == Validation.fail(['error1', 'error2'])

# Generated at 2022-06-24 00:48:49.706287
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from copy import copy

    valid = Validation(1, [])
    x = valid.to_box()

    assert x == Box(1)
    assert x.value == 1

    assert valid == Validation(1, [])


# Generated at 2022-06-24 00:48:52.884725
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation('value', []).is_fail() == False
    assert Validation('value', ['error']).is_fail() == True


# Generated at 2022-06-24 00:48:59.631774
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(2).is_success()
    assert not Validation.success(None).is_success()
    assert not Validation.success([]).is_success()
    assert not Validation.success({}).is_success()
    assert not Validation.success(1.2).is_success()
    assert not Validation.success(False).is_success()

    assert not Validation.fail([1, 2, 3]).is_success()
    assert not Validation.fail({}).is_success()
    assert not Validation.fail(1.2).is_success()
    assert not Validation.fail(None).is_success()
    assert not Validation.fail(False).is_success()


# Generated at 2022-06-24 00:49:09.322202
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation.success(1)
    validation2 = Validation.success(1)

    assert validate(validation1 == validation2, True)
    assert validate(validation1 == Validation.success(2), False)
    assert validate(validation1 == Validation.fail([1]), False)

    assert validate(Validation.fail([1]) == Validation.fail([1]), True)
    assert validate(Validation.fail([1]) == Validation.fail([2]), False)
    assert validate(Validation.fail([1]) == Validation.success(1), False)


# Generated at 2022-06-24 00:49:12.964450
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test Validation.to_box() method.
    """

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(1, [1]).to_box() == Box(1)


# Generated at 2022-06-24 00:49:20.666438
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Successful validation equals to successful validation
    assert Validation(1, []) == Validation(1, [])
    # Successful validation don't equal to failed validation
    assert Validation(1, []) != Validation(1, ['error'])
    # Successful validation don't equal to failed validation with empty list
    assert Validation(1, []) != Validation(1, [])
    # Validation don't equal to None
    assert Validation(1, []) != None
    # Failed validation don't equal to failed validation with other errors list
    assert Validation(1, ['error']) != Validation(1, ['error', 'other error'])
    # Failed validation don't equal to failed validation with other errors list
    assert Validation(1, ['other error']) != Validation(1, ['error'])


# Generated at 2022-06-24 00:49:22.960409
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert Validation.fail().is_success() is False


# Generated at 2022-06-24 00:49:26.561664
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # Success Validation transform to Right
    assert Validation.success("successValue").to_either() == Right("successValue")

    # Fail Validation transform to Left
    assert Validation.fail(['failValue']).to_either() == Left(['failValue'])


# Generated at 2022-06-24 00:49:31.299192
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.success(1).ap(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.fail(['error']).ap(lambda x: Validation.success(x + 1)) == Validation.fail(['error'])
    assert Validation.fail(['error']).ap(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])

# Generated at 2022-06-24 00:49:42.327047
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Validation.__eq__(other)
    """

    # When Validation is success and second Validation is success then result should be True
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success('a') == Validation.success('a')

    # When Validation is fail and second Validation is fail and errors list are equal then result should be True
    assert Validation.fail(['A']) == Validation.fail(['A'])
    assert Validation.fail([1]) == Validation.fail([1])

    # When Validation is success and second Validation is success and values are different then result should be False
    assert Validation.success(1) != Validation.success('a')

    # When Validation is success and second Validation is fail then result should be False
    assert Val

# Generated at 2022-06-24 00:49:49.875231
# Unit test for method ap of class Validation
def test_Validation_ap():
    success_validation = Validation.success('value')
    fail_validation = Validation.fail([])

    def fn(value):
        if len(value) == 0:
            return Validation.fail(['error'])
        return Validation.success(value.upper())

    assert success_validation.ap(fn) == Validation('VALUE', [])
    assert fail_validation.ap(fn) == Validation(None, ['error'])


# Generated at 2022-06-24 00:49:55.920243
# Unit test for method map of class Validation
def test_Validation_map():
    assert_equal(Validation.success(1).map(lambda value: value + 2), Validation.success(3))
    assert_equal(Validation.fail([]).map(lambda value: value + 2), Validation.fail([]))
    assert_equal(Validation.fail([1, 2, 3]).map(lambda value: value + 2), Validation.fail([1, 2, 3]))


# Generated at 2022-06-24 00:50:05.198540
# Unit test for method bind of class Validation
def test_Validation_bind():
    '''
    Test map method of class Maybe.
    '''
    assert Validation.success(1).bind(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail([1, 2, 3])) == Validation.fail([1, 2, 3])
    assert Validation.success(1).bind(lambda x: Validation.fail([1, 2, 3])).bind(lambda x: Validation.success(x)) == Validation.fail([1, 2, 3])

# Generated at 2022-06-24 00:50:10.149338
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():

    from pymonet.result import Success, Failure

    assert Success(None) != Failure([])
    assert Success(None) == Success(None)
    assert Success(10) == Success(10)
    assert Success(None) != Success(10)
    assert Success(10) != Success(None)
    assert Success(10) != Failure([])
    assert Success(None) != Failure([])
    assert Failure([]) != Success(10)
    assert Failure([]) != Success(None)
    assert Success(None) == Success(None)
    assert Success(10) == Success(10)
    assert Success(None) != Success(10)
    assert Success(10) != Success(None)
    assert Success(10) != Failure([])
    assert Success(None) != Failure([])
    assert Failure([]) != Success(10)
    assert Failure

# Generated at 2022-06-24 00:50:14.545142
# Unit test for method map of class Validation
def test_Validation_map():
    mapper = lambda x: x + 'a'
    value = 'b'
    validation = Validation.success(value)
    assert validation.map(mapper) == Validation('ba', [])
    assert validation.errors == []


# Generated at 2022-06-24 00:50:23.691285
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Successful validation
    validation = Validation.success(1)
    # Apply function on Validation value
    result = validation.bind(lambda x: Validation.success(x + 1))

    # Validation should be successful
    assert result.is_success()
    # Validation value should be 2
    assert result.value == 2

    # Failed validation
    validation = Validation.fail(['a'])
    # Apply function on failed Validation
    result = validation.bind(lambda x: Validation.success(x + 1))

    # Validation should not be successful
    assert not result.is_success()
    # Validation value should be None
    assert result.value is None
    # Validation errors should be ['a']
    assert result.errors == ['a']


# Generated at 2022-06-24 00:50:30.275974
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    val = Validation.success('success')
    assert val.to_lazy() == Lazy(lambda: 'success')

    val = Validation.fail()
    assert val.to_lazy().call() is None


# Generated at 2022-06-24 00:50:32.767105
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:50:35.438034
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.success(1).map(lambda x: None) == Validation(None, [])
    assert Validation.fail(1).map(lambda x: x + 1) == Validation(None, 1)


# Generated at 2022-06-24 00:50:47.139960
# Unit test for constructor of class Validation
def test_Validation():
    """Unit test for Validation"""
    def _test_Validation_eq():
        validation1 = Validation(1, [1])
        validation2 = Validation(1, [1])
        assert validation1 == validation2
        assert not validation1 is validation2

    def _test_Validation_success():
        validation = Validation.success(1)
        assert validation.value == 1
        assert validation.errors == []
        assert validation.is_success()

    def _test_Validation_fail():
        validation = Validation.fail([1, 2, 3])
        assert validation.value is None
        assert validation.errors == [1, 2, 3]
        assert validation.is_fail()

    def _test_Validation_map():
        validation1 = Validation.success(1)

# Generated at 2022-06-24 00:50:53.672217
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    def test_success():
        validation = Validation.success('success')
        assert validation.to_box() == Box('success')

    def test_fail():
        validation = Validation.fail()
        assert validation.to_box() == Box(None)

    test_success()
    test_fail()


# Generated at 2022-06-24 00:50:57.664605
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Try(None, is_success=True) == Validation.success().to_try()
    assert Try(None, is_success=False) == Validation.fail().to_try()



# Generated at 2022-06-24 00:51:02.269772
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.
    """
    def run_eq_test(val1, val2, expected_result):
        """
        Runs test for two values equality.

        :param val1: input value
        :type val1: Validation[A, []]
        :param val2: input value
        :type val2: Validation[A, []]
        :param expected_result: expected result
        :type expected_result: Boolean
        """
        actual_result = val1 == val2
        assert expected_result == actual_result, "Equality check for {} and {} failed. Expected {}, actual {}"\
            .format(val1, val2, expected_result, actual_result)

    run_eq_test(Validation.success(), Validation.success(), True)
   

# Generated at 2022-06-24 00:51:06.485908
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Given
    def fn(v):
        return Validation.fail(['wrong' + str(v)])

    validation = Validation.success(5)

    # When
    actual = validation.ap(fn)

    # Then
    assert actual == Validation(5, ['wrong5'])


# Generated at 2022-06-24 00:51:13.756112
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """__eq__(self, other)"""
    assert Validation.fail(errors=[1, 2]) == Validation.fail(errors=[1, 2])
    assert Validation.fail(errors=[1, 2]) != Validation.fail(errors=[])
    assert Validation.success(value=1) == Validation.success(value=1)
    assert Validation.success(value=1) != Validation.success(value=2)
    assert Validation.fail(errors=[1, 3]) != object()


# Generated at 2022-06-24 00:51:22.149903
# Unit test for method bind of class Validation
def test_Validation_bind():
    from functools import partial
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    def divide(numerator, denominator):
        if denominator == 0:
            return Left('Division by zero!')
        return Right(numerator / denominator)

    validate_is_positive = partial(Validation.fail, errors=['Value should be positive'])
    validate_denominator = partial(Validation.fail, errors=['Denominator should be positive'])

    def validate(numerator, denominator):
        if numerator < 0:
            return validate_is_positive()
        if denominator < 0:
            return validate_denominator()
        return Validation.success()


# Generated at 2022-06-24 00:51:26.054149
# Unit test for method bind of class Validation
def test_Validation_bind():
    def divide(i, j):
        if j == 0:
            return Validation.fail([])
        return Validation.success(i / j)

    foo = Validation.success(2)
    res = foo.bind(lambda x: divide(10, x))
    assert res == Validation.fail([])

    res = foo.bind(lambda x: divide(10, x))
    assert res == Validation.fail([])

    res = foo.bind(lambda x: divide(3, x))
    assert res == Validation.success(1.5)


# Generated at 2022-06-24 00:51:37.663919
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.either import Right, Left

    assert Validation.success(5).to_either() == Right(5)
    assert Validation.success(Maybe.just(Box(Lazy(lambda: Try(5))))).to_either() == Right(Maybe.just(Box(Lazy(lambda: Try(5)))))
    assert Validation.fail(['a', Maybe.nothing(), Box(Lazy(lambda: Try(5, is_success=False)))]).to_either() == Left(['a', Maybe.nothing(), Box(Lazy(lambda: Try(5, is_success=False)))])


# Generated at 2022-06-24 00:51:41.742254
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Test for method bind of class Validation."""
    def fn(i):
        return Validation.success(i + 1)

    val = Validation.success(1)
    assert val.bind(fn) == Validation(2, [])

    err = Validation.fail([1])
    assert err.bind(fn) == Validation(None, [1])


# Generated at 2022-06-24 00:51:52.498988
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.maybe import maybe, Maybe
    from pymonet.lazy import Lazy

    try_success = Try(lambda: 5/2)
    try_fail = Try(lambda: 1/0)

    assert(Validation.fail([5, 7]).to_maybe() == Maybe.nothing())
    assert(Validation.success(5).to_maybe() == Maybe.just(5))
    assert(Validation.success(try_success).to_maybe() == Maybe.just(try_success))
    assert(Validation.success(try_fail).to_maybe() == Maybe.nothing())
    assert(Validation.success(Lazy(lambda: 5)).to_maybe() == Maybe.just(Lazy(lambda: 5)))

    # transform to Maybe and apply function to Maybe

# Generated at 2022-06-24 00:51:56.667157
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(value=None).is_success() == True
    assert Validation.success(value=1).is_success() == True
    assert Validation.fail(errors=[1, 2, 3]).is_success() == False


# Generated at 2022-06-24 00:52:01.906820
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(2, []) == Validation(2, [])
    assert Validation(2, ['error1']) == Validation(2, ['error1'])
    assert Validation(3, ['error1']) != Validation(2, ['error1'])
    assert Validation(2, ['error1', 'error2']) != Validation(2, ['error1'])



# Generated at 2022-06-24 00:52:05.320848
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right

    assert Validation.fail(['error']).to_either()           == Left(['error'])
    assert Validation.success(42).to_either()               == Right(42)


# Generated at 2022-06-24 00:52:10.371632
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('a').to_maybe() == Maybe.just('a')
    assert Validation.fail([]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:13.306628
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(True, [])
    assert validation.value == True
    assert validation.errors == []

    validation2 = Validation(False, ['Error'])
    assert validation2.value == False
    assert validation2.errors == ['Error']


# Generated at 2022-06-24 00:52:22.935844
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success

    result = Validation(1, []).to_try()
    assert result == Success(1)

    failure = Failure(errors=[1, 2, 3])
    result = Validation(None, [1, 2, 3]).to_try()
    assert result.errors == failure.errors
    assert result.is_failure == failure.is_failure
    assert result.is_success == failure.is_success

# Generated at 2022-06-24 00:52:28.284713
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(100).to_either() == Right(100)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([100]).to_either() == Left([100])
    assert Validation.fail([100, 200]).to_either() == Left([100, 200])


# Generated at 2022-06-24 00:52:33.102089
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    def to_try_success():
        """Transform successful validation to successful Try"""
        return Validation.success(100).to_try()

    def to_try_fail():
        """Transform fail validation to fail Try"""
        return Validation.fail([1, 2, 3]).to_try()

    assert to_try_success() == Try(100, is_success=True)
    assert to_try_fail() == Try(None, is_success=False)



# Generated at 2022-06-24 00:52:35.473167
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(42).is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:52:41.984290
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit testing of method Validation.to_lazy
    """
    from pymonet.lazy import Lazy

    value = 'value'
    validation = Validation.success(value)

    lazy = validation.to_lazy()

    assert lazy == Lazy(lambda: value)


# Generated at 2022-06-24 00:52:47.620409
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation
    from pymonet.validation import fail, success

    assert Validation.success('hello').ap(success('world')) == success('hello')
    assert Validation.success('hello').ap(fail('world')) == fail(['world'])



# Generated at 2022-06-24 00:52:56.759018
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation(3, []).to_lazy() == Lazy(lambda: 3)
    assert Validation(None, [1, 2]).to_lazy() == Lazy(lambda: None)

    assert Validation(Try(1), []).to_lazy() == Lazy(lambda: Try(1))
    assert Validation(Try(None, is_success=False), [1, 2]).to_lazy() == Lazy(lambda: Try(None, is_success=False))



# Generated at 2022-06-24 00:52:59.916630
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success(3)
    assert validation.is_success() == True

    validation = Validation.fail(['error 1', 'error 2'])
    assert validation.is_success() == False


# Generated at 2022-06-24 00:53:07.167840
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, ['error']) == Validation.fail(['error'])
    assert Validation('foo', []) == Validation.success('foo')
    assert Validation('foo', ['error']).is_fail()
    assert Validation(None, []).is_success()
    assert Validation('foo', []).is_success()


# Generated at 2022-06-24 00:53:09.248728
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    v = Validation.success(value=1)
    assert v.is_success() == True
    assert v.is_fail() == False


# Generated at 2022-06-24 00:53:10.531602
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation([1, 2, 3]).to_box() == Box([1, 2, 3])



# Generated at 2022-06-24 00:53:17.599118
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test function to_lazy of Validation class.
    """
    from pymonet.lazy import Lazy

    value = 'value'
    validation = Validation.success(value)
    lazy = validation.to_lazy()
    assert lazy == Lazy(lambda: value)

# Generated at 2022-06-24 00:53:29.658369
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():

    from pymonet.functor import List

    def test_is_fail_when_errors_not_empty():
        assert Validation.fail([1, 2, 3]).is_fail()

    def test_is_fail_when_errors_empty():
        assert not Validation.fail([]).is_fail()

    def test_is_fail_when_errors_None():
        assert Validation.fail(None).is_fail()

    def test_is_fail_when_errors_List():
        assert Validation.fail(List([1])).is_fail()

    def test_is_fail_when_errors_other_objects():
        assert Validation.fail({}).is_fail()
        assert Validation.fail(1).is_fail()


# Generated at 2022-06-24 00:53:34.570622
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # Test for successful validation
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(1).to_either() != Right(2)
    assert Validation.success(1).to_either() != Left(1)

    # Test for failed validation
    assert Validation.fail(['error1']).to_either() == Left(['error1'])
    assert Validation.fail(['error1']).to_either() != Left(['error2'])
    assert Validation.fail(['error1']).to_either() != Right(1)

# Generated at 2022-06-24 00:53:40.073886
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for Validation.is_success method.
    """

    # Empty list of errors is success
    assert Validation.success().is_success() is True
    # List with elements should be success
    assert Validation.success(['a']).is_success() is True

    # None is failure
    assert Validation.fail().is_success() is False
    # List with elements should be false
    assert Validation.fail([1]).is_success() is False


# Generated at 2022-06-24 00:53:42.453182
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(2).to_lazy()() == 2
    assert Validation.fail([1, 2, 3]).to_lazy()() == None


# Generated at 2022-06-24 00:53:48.522547
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Unit test for method is_success of class Validation.
    """
    from pymonet.monad_try import Try

    # Just value
    assert Validation.success().is_success() == True
    # Just value
    assert Validation.success(1).is_success() == True
    # Just value
    assert Validation.success('test').is_success() == True
    # Just value
    assert Validation.success(Try.success('test')).is_success() == True
    # Just value
    assert Validation.success(Try.fail('test')).is_success() == True
    # Just value
    assert Validation.success([]).is_success() == True
    # Just value
    assert Validation.success([1, 2, 3]).is_success() == True
    # Just value

# Generated at 2022-06-24 00:53:55.776694
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.maybe import Maybe

    def double_or_zero(num):
        if num == 0:
            return Maybe.nothing()
        return Maybe.just(num * num)

    assert Validation.success(2).bind(double_or_zero) == Validation.success(4)
    assert Validation.success(0).bind(double_or_zero) == Validation.success(None)

# Generated at 2022-06-24 00:54:02.629161
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation
    """
    from pymonet.monad_try import Try

    validation_fail = Validation.fail()
    validation_success = Validation.success()

    assert validation_fail.is_fail()
    assert not validation_success.is_fail()

    assert Try.success(1).is_success()
    assert Try.failure(Exception('some exception')).is_fail()


# Generated at 2022-06-24 00:54:11.813072
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.fail(['error', 'error2']).to_either() == Left(['error', 'error2'])
    assert Validation.success(Box(1)).to_either() == Right(1)
    assert Validation.success(Maybe.just(1)).to_either() == Right(1)
    assert Validation.success(Maybe.nothing()).to_either() == Right(None)
    assert Validation.fail(Maybe.just(['error'])).to_either() == Left(['error'])


# Generated at 2022-06-24 00:54:20.807852
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad import Monad
    from pymonet.validator import Validator

    Monad.test_bind(
        bind_action=lambda x: Validator.success({'id': x}),
        bind_expected=Validation({'id': 1}, []),
        monad_type=Validation,
        unit_params=[1]
    )

    Monad.test_bind(
        bind_action=lambda x: Validator.fail(['error 1']),
        bind_expected=Validation(None, ['error 1']),
        monad_type=Validation,
        unit_params=[1]
    )
