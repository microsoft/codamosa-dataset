

# Generated at 2022-06-24 00:44:16.423330
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test for class Box.
    """
    from pymonet.box import Box

    assert Validation.success(None).to_box() == Box(None)
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)

# Generated at 2022-06-24 00:44:19.477608
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(42).to_maybe() == Maybe.just(42)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:44:24.809510
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1]).map(lambda x: x + 1) == Validation.fail([1])


# Generated at 2022-06-24 00:44:31.619124
# Unit test for constructor of class Validation
def test_Validation():
    successful_validation = Validation.success('a')

    assert(successful_validation == Validation('a', []))
    assert(successful_validation.is_success())
    assert(successful_validation == Validation('a', []))

    failed_validation = Validation.fail(['e'])
    assert(failed_validation == Validation(None, ['e']))
    assert(failed_validation.is_fail())


# Generated at 2022-06-24 00:44:33.633462
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])


# Generated at 2022-06-24 00:44:37.357986
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(2).to_lazy() == Lazy(lambda: 2)
    assert Validation.fail([1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:44:40.198535
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation.success(10)
    assert validation == Validation(10, [])

    validation = Validation.fail([1, 2, 3])
    assert validation == Validation(None, [1, 2, 3])


# Generated at 2022-06-24 00:44:44.078965
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Arrange
    validation = Validation.success(1)
    validation2 = Validation.success(2)
    validation_fail = Validation.fail([1, 2])

    # Act
    result = validation.ap(lambda value: validation2)
    result_fail = validation_fail.ap(lambda value: validation2)

    # Assert
    assert result.value == 2
    assert result.is_success()
    assert len(result.errors) == 0

    assert result_fail.value == None
    assert result_fail.is_fail()
    assert len(result_fail.errors) == 3

# Generated at 2022-06-24 00:44:55.646387
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(None).ap(
        Validation.success(lambda x: Validation.fail(['A']))) == Validation.fail(['A'])
    assert Validation.success(None).ap(
        Validation.fail(['A'])) == Validation.fail(['A'])
    assert Validation.success(None).ap(
        Validation.success(lambda x: Validation.success(None))) == Validation.success(None)
    assert Validation.fail(['A']).ap(
        Validation.success(lambda x: Validation.success(None))) == Validation.fail(['A'])
    assert Validation.fail(['A']).ap(
        Validation.fail(['B'])) == Validation.fail(['A', 'B'])

# Generated at 2022-06-24 00:45:05.382103
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Method ap takes as a parameter function returning another Validation.
    Function is called with Validation value and returns new Validation with previous value
    and concated new and old errors.
    """
    def fn(value):
        if value == 1:
            return Validation.success('1')
        return Validation.fail(['error'])

    assert Validation.success(1).ap(fn).value == '1'
    assert Validation.success(1).ap(fn).errors == []

    assert Validation.success(2).ap(fn).value == 2
    assert Validation.success(2).ap(fn).errors == ['error']

    assert Validation.fail(['error']).ap(fn).value == None
    assert Validation.fail(['error']).ap(fn).errors == ['error']

# Generated at 2022-06-24 00:45:10.817350
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 3) == Validation(3, []).to_lazy()
    assert Lazy(lambda: 4) == Validation(4, []).to_lazy()


# Generated at 2022-06-24 00:45:19.749575
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(None) == Validation.fail([1, 2, 3, 4]).to_try()
    assert Failure(AttributeError, None) == Validation.success('test').to_try()


    assert Success(None) == Validation.fail([1, 2, 3, 4]).to_try()
    assert Failure(AttributeError, None) == Validation.success('test').to_try()

# Generated at 2022-06-24 00:45:22.073259
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(2) == Validation.success(2)
    assert Validation.fail() == Validation.fail()


# Generated at 2022-06-24 00:45:28.234589
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success([1, 2, 3]).to_try() == Try([1, 2, 3], True)
    assert Validation.success(1).to_try() == Try(1, True)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, False)
    assert Validation.fail(1).to_try() == Try(None, False)


# Generated at 2022-06-24 00:45:34.631995
# Unit test for method map of class Validation
def test_Validation_map():

    print('Unit test for Validation.map')

    def is_even(x):
        return (x % 2) == 0

    def add_one(x):
        return x + 1

    def incr(x):
        return Validation.success(x + 1)

    def double(x):
        return Validation.success(x * 2)

    def half(x):
        return Validation.success(x / 2)

    def square(x):
        return Validation.success(x ** 2)

    def add_two(x):
        return Validation.success(x + 2)

    def add(x, y):
        if x + y <= 10:
            return Validation.success(x + y)

# Generated at 2022-06-24 00:45:37.998996
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    value = 10
    errors = ['error1', 'error2']
    validation = Validation(value, errors)

    assert validation.value == value
    assert validation.errors == errors
    assert validation.is_fail()
    assert not validation.is_success()



# Generated at 2022-06-24 00:45:43.732260
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation.success('value')
    result = validation.ap(lambda value: Validation.fail(['exception']))
    assert result == Validation('value', ['exception'])
    assert result.value == 'value'
    assert result.errors == ['exception']
    assert result.is_fail()


# Generated at 2022-06-24 00:45:47.861461
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success("value").is_success()
    assert not Validation.success([]).is_success()
    assert not Validation.fail("error").is_success()
    assert not Validation.fail([]).is_success()


# Generated at 2022-06-24 00:45:56.429608
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test is_success method of Validation class.
    """
    from pymonet.box import Box
    from pymonet.monad_try import Try

    test_value = None
    test_errors = [1, 2]
    test_success_value = 'success'
    test_success_monad = Validation(test_success_value, [])

    assert test_success_monad.to_box() == Box(test_success_value, is_success=True)

    test_fail_monad = Validation(test_value, test_errors)
    assert test_fail_monad.to_box() == Box(test_value, is_success=False)

    test_none_monad = Validation(None, test_errors)
    assert test_none_monad.to_box() == Box

# Generated at 2022-06-24 00:46:06.139312
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Either
    from pymonet.maybe import Maybe

    fn = lambda x: x + 1

    assert Validation.success(5).map(fn) == Validation(6, [])
    assert Validation.fail([]).map(fn) == Validation(None, [])

    assert Validation.success(5).map(lambda x: Either.just(x + 1)) == Validation(Either.just(6), [])
    assert Validation.fail([]).map(lambda x: Either.just(x + 1)) == Validation(None, [])

    assert Validation.success(5).map(lambda x: Maybe.just(x + 1)) == Validation(Maybe.just(6), [])
    assert Validation.fail([]).map(lambda x: Maybe.just(x + 1)) == Val

# Generated at 2022-06-24 00:46:10.025875
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(
        1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(
        None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(
        [1, 2]).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:46:12.280917
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation_success = Validation.success(1)
    validation_fail = Validation.fail([1])
    assert validation_fail.is_fail()
    assert not validation_success.is_fail()



# Generated at 2022-06-24 00:46:21.933713
# Unit test for constructor of class Validation
def test_Validation():
    """
    >>> test_Validation()
    Validation.success[1]
    Validation.fail[None, [ValueError]]
    """
    from operator import add

    #
    # Use Validation to validate data
    #
    validation = Validation.success(1)

    # validate something
    validation = validation.ap(lambda a: Validation.success(a + 1))
    validation = validation.ap(lambda a: Validation.success(a + 1))

    # try to throw exception
    validation = validation.ap(lambda a: Validation.success(a + occur()))

    # print validation status
    print(validation)

    #
    # Transform Validation to Maybe
    #
    validation_as_maybe = validation.to_maybe()

    # transform Maybe to Validation
    validation_from_maybe = validation_

# Generated at 2022-06-24 00:46:28.167595
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v_1 = Validation.success(1)
    v_2 = Validation.success(2)
    v_3 = Validation.success(1)
    v_4 = Validation.fail()
    v_5 = Validation.fail([])
    v_6 = Validation.fail([1])
    v_7 = Validation.fail([1])

    assert v_1 == v_1
    assert v_2 == v_2
    assert v_3 == v_3
    assert v_4 == v_4
    assert v_5 == v_5
    assert v_6 == v_6
    assert v_7 == v_7

    assert v_1 != v_2
    assert v_1 != v_4
    assert v_1 != v_5
    assert v_1 != v_6
   

# Generated at 2022-06-24 00:46:33.166020
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try

    errors = ['error1', 'error2']

    def fn(value):
        return Try(value, is_success=False)

    assert Validation.success('value').ap(fn) == Validation.success('value')
    assert Validation.fail(errors).ap(fn) == Validation.fail(errors)

# Generated at 2022-06-24 00:46:40.524586
# Unit test for method map of class Validation
def test_Validation_map():
    # given
    validation_success = Validation.success(2)
    validation_fail = Validation.fail([1, 2, 3])

    # when
    result_success = validation_success.map(lambda x: x * 2)
    result_fail = validation_fail.map(lambda x: x * 2)

    # then
    assert result_success == Validation.success(4)
    assert result_fail == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:46:47.129650
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)


# Generated at 2022-06-24 00:46:51.100812
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation(None, []).is_success()
    assert not Validation(None, ['some error']).is_success()


# Generated at 2022-06-24 00:46:58.399532
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(5) == Validation.fail([5])
    assert Validation.success(5) == Validation.success()
    assert Validation.success(5) != Validation.success(6)
    assert Validation.success(5) != Validation.fail([])
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.fail([])


# Generated at 2022-06-24 00:47:06.428028
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert (Validation.success(10).to_maybe() == Maybe.just(10))
    assert (Validation.success(Box(10)).to_maybe() == Maybe.just(Box(10)))
    assert (Validation.success(Box(10)).to_maybe().map(lambda x: x + 1) == Maybe.just(Box(11)))
    assert (Validation.success(Box(10)).to_maybe().map(lambda x: x.value + 1) == Maybe.just(11))
    assert (Validation.success(Lazy(lambda: 10)).to_maybe() == Maybe.just(10))

# Generated at 2022-06-24 00:47:12.208715
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.utils import equals

    equals(True, Validation.success().is_success())
    equals(True, Validation.success(None).is_success())
    equals(False, Validation.success(1).is_success())
    equals(False, Validation.fail().is_success())
    equals(False, Validation.fail([]).is_success())
    equals(False, Validation.fail([1]).is_success())


# Generated at 2022-06-24 00:47:15.085005
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right
    from pymonet.box import Box

    def folder(x):
        return Right(Box(x))

    validation = Validation.success(1)

    result = validation.bind(folder)

    assert result == Right(Box(1))



# Generated at 2022-06-24 00:47:19.543113
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of Validation class."""
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def lazy_f():
        """Function for to test lazy evaluation."""
        return Validation.success(1)

    assert Validation.success(1).to_lazy() == Lazy(lazy_f)


# Generated at 2022-06-24 00:47:21.512463
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation.fail()

    assert not validation1 == Validation.success(1)
    assert validation1 == Validation.fail()


# Generated at 2022-06-24 00:47:24.488669
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Box(1) == Validation.success(1).to_box()
    assert Box(2) == Validation.success(2).to_box()
    assert Box(None) == Validation.fail([1, 2, 3]).to_box()


# Generated at 2022-06-24 00:47:30.310677
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda x: x) == Validation.success(1)
    assert Validation.success(None).map(lambda x: x + 1) == Validation.success(None)
    assert Validation.fail(['Error']).map(lambda x: x + 1) == Validation.fail(['Error'])
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])


# Generated at 2022-06-24 00:47:33.777164
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail(errors=['error']).is_success()


# Generated at 2022-06-24 00:47:37.243837
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for method to_try of class Validation"""
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:47:38.941525
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail('error').is_success()



# Generated at 2022-06-24 00:47:41.714655
# Unit test for method map of class Validation
def test_Validation_map():

    def mapper(x):
        return x + 3

    validation = Validation.success(9)
    map_result = validation.map(mapper)

    assert Validation.success(12) == map_result

    validation = Validation.fail()
    map_result = validation.map(mapper)

    assert Validation.fail() == map_result


# Generated at 2022-06-24 00:47:46.251037
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():

    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, ['error']) == Validation(1, ['error'])
    assert Validation(2, []) == Validation(2, [])
    assert Validation(1, ['error']) != Validation(2, ['error'])
    assert Validation(1, ['error 2']) != Validation(1, ['error'])
    assert Validation(1, []) != Validation(2, [])
    assert Validation(1, []) != Validation(1, ['error'])


# Generated at 2022-06-24 00:47:50.680012
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Tests __eq__ to compare two Validations for equality.
    """
    assert Validation.success('x') == Validation('x', [])
    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation.fail(['error']) != Validation(None, ['error2'])
    assert Validation.success(1) != Validation.fail([])
    assert Validation.success(1) != Validation(1, [])



# Generated at 2022-06-24 00:47:56.067095
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    # Test successful Validation to Box conversion
    assert Validation.success(3).to_box() == Box(3)

    # Test failed Validation to Box conversion
    assert Validation.fail([3, 5]).to_box() == Box(None)


# Generated at 2022-06-24 00:48:00.173291
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('Crocodile')) == 'Validation.success[Crocodile]'
    assert str(Validation.fail(['Error 1', 'Error 2'])) == 'Validation.fail[None, [\'Error 1\', \'Error 2\']]'


# Generated at 2022-06-24 00:48:02.940489
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('test') == Validation('test', [])
    assert Validation.fail('test') == Validation(None, 'test')
    assert Validation.fail() == Validation(None, [])
    assert Validation.success() == Validation(None, [])


# Generated at 2022-06-24 00:48:05.066205
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    # Given
    validation = Validation.success(1)
    # When
    result = validation.to_maybe()
    # Then
    assert result == Maybe.just(1)


# Generated at 2022-06-24 00:48:15.312425
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def f(x):
        return Validation.success(x ** 2)

    def g(x):
        return Validation.success(x * 3)

    def h(x):
        return Try.success(x * 2)

    assert(Validation.success(2).bind(f) == Validation.success(4))
    assert(Validation.success(2).bind(f).bind(g) == Validation.success(12))
    assert(Validation.success(2).bind(f).bind(g).bind(h) == Validation.success(24))
    assert(Validation.fail('a').bind(f) == Validation.fail('a'))

# Generated at 2022-06-24 00:48:24.229982
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation of ap checks.
    """
    # Validation.success(3).ap(Validation.success(lambda x: x * 2)) == Validation.success(6)
    assert Validation.success(3).ap(Validation.success(lambda x: x * 2)) == Validation.success(6)

    # Validation.success(3).ap(Validation.success(lambda x: x + 'aaa')) == Validation.success(6)
    assert Validation.success(3).ap(Validation.success(lambda x: x + 'aaa')) == Validation.fail(['aaa'])

    # Validation.success(3).ap(Validation.fail(['Error 1', 'Error 2'])) == Validation.fail(['Error 1', 'Error 2'])
    assert Validation.success(3).ap

# Generated at 2022-06-24 00:48:31.538971
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert (Validation.success(4) == \
            Validation.success({'test': [1, 2, 3], 'test2': ['a', 'b', 'c']}))
    assert (Validation.fail(['test', 'test2']) == \
            Validation.fail(['test', 'test2']))
    assert (Validation.success([1, 2, 3, 4]) == \
            Validation.fail(['test', 'test2'])) == False


# Generated at 2022-06-24 00:48:33.949551
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:48:45.413475
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.success(Try.success(1)).to_either() == Right(Try.success(1))
    assert Validation.success(Try.fail('message')).to_either() == Right(Try.fail('message'))
    assert Validation.fail(['something goes wrong']).to_either() == Left(['something goes wrong'])
    assert Validation.fail(None).to_either() == Left(None)
    assert Validation.success().to_either() == Right(None)


# Generated at 2022-06-24 00:48:48.152991
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(1).to_validation() == Validation.success(1)
    assert Failure(1).to_validation() == Validation.fail([1])


# Generated at 2022-06-24 00:48:52.774104
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.monad_try import Try

    # Validation.success
    assert Validation(None, []) == Validation.success()
    assert Validation(None, []) == Validation.success(None)
    assert Validation(1, []) == Validation.success(1)

    # Validation.fail
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, ['error']) == Validation.fail(['error'])


# Generated at 2022-06-24 00:48:58.083597
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Checks if Validation can be transformed to Box.
    """
    from pymonet.box import Box

    assert Validation.success('example').to_box() == Box('example')
    assert Validation.success(42).to_box() == Box(42)


# Generated at 2022-06-24 00:49:06.177500
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation_1 = Validation.success(1)
    assert str(validation_1) == 'Validation.success[1]'
    validation_2 = Validation.success('smth')
    assert str(validation_2) == 'Validation.success[smth]'
    validation_3 = Validation.fail([1, 2, 3])
    assert str(validation_3) == 'Validation.fail[None, [1, 2, 3]]'
    validation_4 = Validation.fail(['my_error'])
    assert str(validation_4) == 'Validation.fail[None, [\'my_error\']]'


# Generated at 2022-06-24 00:49:11.745214
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    def is_not_negative(value):
        return Validation.success(value) if value >= 0 else Validation.fail(['Value must be positive'])

    def double(value):
        return Validation.success(value * 2)

    assert is_not_negative(1).bind(double) == Validation.success(2)
    assert is_not_negative(-1).bind(double) == Validation.fail(['Value must be positive'])

# Generated at 2022-06-24 00:49:14.065383
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(42).to_box() == Box(42)
    assert Validation.fail([42]).to_box() == Box(None)


# Generated at 2022-06-24 00:49:21.033964
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    """Test __str__ method of Validation."""
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation(5, [])) == 'Validation.success[5]'
    assert str(Validation(5, [1, 2, 3])) == 'Validation.fail[5, [1, 2, 3]]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:49:23.806908
# Unit test for constructor of class Validation
def test_Validation():
    """
    Unit test for constructor of class Validation.
    """
    validation = Validation(4, [])
    assert validation == Validation(4, [])
    assert validation.value == 4
    assert validation.errors == []


# Generated at 2022-06-24 00:49:28.153486
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(None).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)

if __name__ == '__main__':  # pragma: no cover
    # import doctest
    # doctest.testmod()

    # Unit test for method to_lazy of class Validation
    test_Validation_to_lazy()

# Generated at 2022-06-24 00:49:32.055120
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Test for method is_fail of class Validation."""
    Validation.fail(['error']).is_fail() == True
    Validation.fail().is_fail() == False



# Generated at 2022-06-24 00:49:40.668635
# Unit test for method bind of class Validation
def test_Validation_bind():
    with pytest.raises(TypeError) as e_info:
        Validation.success(1).bind(1)

    fn = lambda num: Validation.fail(['Number {} is not odd'.format(num)]) if num % 2 == 0 else Validation.success(num)

    assert Validation.success(1).bind(fn).value == 1
    assert Validation.success(2).bind(fn).value is None
    assert Validation.success(2).bind(fn).errors == ['Number 2 is not odd']
    assert Validation.success(2).bind(fn).is_fail() is True


# Generated at 2022-06-24 00:49:43.377561
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    It tests that method is_fail returns true
    when values errors list is not empty.
    """
    assert Validation(1, [2]).is_fail() == True


# Generated at 2022-06-24 00:49:47.538584
# Unit test for method bind of class Validation
def test_Validation_bind():
    def folder(value):
        if value == 5:
            return Validation.success("five")
        return Validation.fail([])
    assert Validation.success(5).bind(folder) == Validation.success("five")
    assert Validation.success(13).bind(folder) == Validation.fail([])
    assert Validation.fail(["error"]).bind(folder) == Validation.fail([])



# Generated at 2022-06-24 00:49:55.153182
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success('1').ap(lambda x: Validation.success(str(int(x) + 1))).value == '2'
    assert Validation.success('1').ap(lambda x: Validation.fail()).is_fail()
    assert Validation.fail().ap(lambda x: Validation.fail()).is_fail()
    assert Validation.fail().ap(lambda x: Validation.success(str(int(x) + 1))).is_fail()


# Generated at 2022-06-24 00:49:59.278360
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Validation.success(10).to_lazy()
    assert Lazy(lambda: None) == Validation.fail(['something wrong']).to_lazy()


# Generated at 2022-06-24 00:50:07.273847
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    def add_one(e):
        return Validation.success(e + 1)

    def add_fail(a):
        return Validation.fail([a])

    def add_non_validation(a):
        return a + 1

    def throw(value):
        raise Exception('error')

    valid = Validation.success(1)
    assert valid.bind(add_one) == Validation.success(2)
    assert valid.bind(add_fail) == Validation.fail([1])

    with pytest.raises(Exception) as e:
        assert valid.bind(throw)

# Generated at 2022-06-24 00:50:13.428382
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]) != Validation.success(1)



# Generated at 2022-06-24 00:50:15.532981
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(None, [])
    assert validation.value == None
    assert validation.errors == []


# Generated at 2022-06-24 00:50:20.354949
# Unit test for method ap of class Validation
def test_Validation_ap():
    # given
    def fn(x):
        return Validation.success(x + 2)
    val1 = Validation.success(5)
    new_val = Validation.success(5).ap(fn)
    # then
    assert new_val.value == 5
    assert new_val.errors == []


# Generated at 2022-06-24 00:50:23.438282
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.success(None).to_try() == Success(None)
    assert Validation.fail([1]).to_try() == Failure([1])
    assert Validation.fail(['Error']).to_try() == Failure(['Error'])



# Generated at 2022-06-24 00:50:27.659846
# Unit test for method is_fail of class Validation
def test_Validation_is_fail(): # pragma: no cover
    assert Validation.success(1).is_fail() == False
    assert Validation.fail([1]).is_fail() == True


# Generated at 2022-06-24 00:50:34.488794
# Unit test for method bind of class Validation
def test_Validation_bind():
    def f(value):
        if value > 5:
            return Validation.success(value + 1)
        return Validation.fail(['Error'])

    assert Validation.success(8).bind(f) == Validation.success(9), 'Simple bind test'
    assert Validation.success(4).bind(f) == Validation.fail(['Error']), 'Simple bind test'



# Generated at 2022-06-24 00:50:39.739230
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success
    from pymonet.monad_try import Fail

    # When Validation is successful
    assert Validation.success(1).to_box() == Box(1)
    # When Validation is failed
    assert Validation.fail([1]).to_box() == Box(None)
    # When Try is successful
    assert Try(1).to_validation().to_box() == Box(1)
    assert Try(1, is_success=True).to_validation().to_box() == Box(1)
    assert Try(1, is_success=False).to_validation().to_box() == Box(None)

# Generated at 2022-06-24 00:50:43.062666
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.functions import Function
    from pymonet.functions import Function1
    from pymonet.functions import Function2
    from pymonet.validation import Validation
    from pymonet.box import Box

    def test_function(val):
        def inner_function(b):
            return Validation.success(b)
        return Box.pure(Function1.curry(inner_function, val)).to_function()

    assert Validation.success(123).ap(test_function(456)) == Validation.success(123)
    assert Validation.success(123).ap(test_function(None)) == Validation.success(123)


# Generated at 2022-06-24 00:50:49.066660
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test is_fail method of Validation class. It should return true when errors list is not empty.
    """
    assert Validation.fail([1]).is_fail()
    assert Validation.fail().is_fail()
    assert Validation.fail([1, 2, 3]).is_fail()
    assert Validation.success(1).is_fail() == False
    assert Validation.success().is_fail() == False


# Generated at 2022-06-24 00:50:52.759878
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([]).is_fail() == False
    assert Validation.fail([1]).is_fail() == True
    assert Validation.fail([1, 2]).is_fail() == True


# Generated at 2022-06-24 00:50:57.971727
# Unit test for method map of class Validation
def test_Validation_map():
    """
    assert_equal test_Validation_map
    """
    assert_equal(Validation.success(3).map(lambda x: x * 2), Validation.success(6))
    assert_equal(Validation.fail([1, 2, 3]).map(lambda x: x * 2), Validation.fail([1, 2, 3]))


# Generated at 2022-06-24 00:51:05.141142
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    # Tests for to_box method
    assert Validation.success(3).to_box() == Box(3), 'Validation.success(3).to_box() == Box(3)'
    assert Validation.fail([0]).to_box() == Box(None), 'Validation.fail([0]).to_box() == Box(None)'
    assert Validation.success(3).to_box().is_success() is True, 'Validation.success(3).to_box().is_success() is True'

# Generated at 2022-06-24 00:51:11.427600
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Left, Right

    # testing monad try
    assert Validation.success(34).ap(Try(lambda x: x + 1)) == Validation.success(34).bind(lambda x: Try(lambda: x + 1))
    assert Validation.success(34).ap(Try(lambda x: x / 0)) == \
           Validation('ZeroDivisionError: division by zero', ['ZeroDivisionError: division by zero'])


# Generated at 2022-06-24 00:51:15.703175
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    success_validation = Validation.success(1)
    fail_validation = Validation.fail([1])

    assert success_validation.to_either() == Right(1)
    assert fail_validation.to_either() == Left([1])

# Generated at 2022-06-24 00:51:23.124938
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.success(True).to_either() == Right(True)
    assert Validation.success(3.1415926).to_either() == Right(3.1415926)
    assert Validation.success('foo').to_either() == Right('foo')
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:51:27.110686
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test for method to_try of class Validation.
    """
    from pymonet.monad_try import Try
    test_value = 1
    test_error = [1]
    assert Validation.success(test_value).to_try() == Try(test_value)
    assert Validation.fail(test_error).to_try() == Try(None, is_success=False, errors=test_error)

# Generated at 2022-06-24 00:51:38.290241
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.
    """

    # Test success Validation == success Validation
    assert Validation.success('test') == Validation.success('test'), \
        'test == test for Validation of class Validation raised AssertionError'

    # Test success Validation != fail Validation
    assert Validation.success('test') != Validation.fail('test'), \
        'test != test for Validation of class Validation raised AssertionError'

    # Test failed Validation != success Validation
    assert Validation.fail('test') != Validation.success('test'), \
        'test != test for Validation of class Validation raised AssertionError'

    # Test failed Validation == failed Validation

# Generated at 2022-06-24 00:51:40.821150
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    sval = Validation.success(1)
    fval = Validation.fail(['error'])
    assert sval.is_success()
    assert fval.is_success() is False


# Generated at 2022-06-24 00:51:47.052334
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Successful Validation contains as value list and no errors.

    :returns: Successful Validation contains error
    :rtype: Validation[List[int], List[Exception]]
    """
    print('Unit test for method ap of class Validation')

    def adder(addend):
        return lambda x: x + addend

    def add_map(value):
        return Validation.success(adder(value))

    def divider(divisor):
        return lambda x: x / divisor

    def divide_map(value):
        if value != 0:
            return Validation.success(divider(value))
        else:
            return Validation.fail([ZeroDivisionError('Division by zero')])


# Generated at 2022-06-24 00:51:53.774918
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left
    from pymonet.either import Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:51:55.329147
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test __str__ method of Validation class.
    """



# Generated at 2022-06-24 00:51:58.857108
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # Given
    value = 'test_value'
    error = 'test_error'
    success_validation = Validation.success(value)
    fail_validation = Validation.fail([error])

    # Then
    assert (str(success_validation) == 'Validation.success[{}]'.format(value))
    assert (str(fail_validation) == 'Validation.fail[None, [{}]]'.format(error))



# Generated at 2022-06-24 00:52:06.564347
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    val_success_0 = Validation.success()
    assert str(val_success_0) == 'Validation.success[None]'
    val_success_1 = Validation.success(1)
    assert str(val_success_1) == 'Validation.success[1]'
    val_fail_0 = Validation.fail()
    assert str(val_fail_0) == 'Validation.fail[None, []]'
    val_fail_1 = Validation.fail(['error'])
    assert str(val_fail_1) == "Validation.fail[None, ['error']]"
    val_fail_2 = Validation.fail(['error 1', 'error 2'])
    assert str(val_fail_2) == "Validation.fail[None, ['error 1', 'error 2']]"



# Generated at 2022-06-24 00:52:13.675760
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    """
    Unit test for method to_lazy of class Validation
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(Try(1), []).to_lazy() == Lazy(lambda: Try(1))
    assert Validation('a', ['e1', 'e2']).to_lazy() == Lazy(lambda: 'a')
    assert Validation(Try('a'), ['e1', 'e2']).to_lazy() == Lazy(lambda: Try('a'))


# Generated at 2022-06-24 00:52:16.839868
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1]).is_fail()
    assert not Validation.success([1]).is_fail()


# Generated at 2022-06-24 00:52:22.369576
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    nel_a = Validation.fail(['a'])
    nel_b = Validation.fail(['b'])
    nel_ab = nel_a.ap(lambda _: nel_b)

    assert nel_ab.errors == ['a', 'b']



# Generated at 2022-06-24 00:52:27.238106
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for Validation class. It test method ap."""
    # Given
    validation = Validation.success('value')
    fn = lambda x: Validation.fail(['error'])

    # When
    result = validation.ap(fn)

    # Then
    assert result == Validation('value', ['error'])



# Generated at 2022-06-24 00:52:33.398471
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]', 'Validation.success[None] is expected'
    assert str(Validation.success(3)) == 'Validation.success[3]', 'Validation.success[3] is expected'
    assert str(Validation.fail()) == 'Validation.fail[None, []]', 'Validation.fail[None, []] is expected'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]', 'Validation.fail[None, [1, 2, 3]] is expected'


# Generated at 2022-06-24 00:52:36.801120
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(True)) == 'Validation.success[True]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'



# Generated at 2022-06-24 00:52:46.984444
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    result = Validation(10, []) == Validation(10, [])
    assert result, 'Validation should be equal to the same one'

    result = Validation(10, []) == Validation(20, [])
    assert not result, 'Validation should not be equal to the same one'

    result = Validation(20, ['error']) == Validation(20, ['error'])
    assert result, 'Validation should be equal to the same one'

    result = Validation(20, ['error']) == Validation(10, ['error'])
    assert not result, 'Validation should not be equal to the same one'

    result = Validation(10, ['error']) == Validation(10, [])
    assert not result, 'Validation should not be equal to the same one'


# Generated at 2022-06-24 00:52:57.068751
# Unit test for constructor of class Validation
def test_Validation():
    "test_Validation"
    assert Validation(10, []) == Validation(10, [])
    assert Validation(10, []) != Validation(11, [])
    assert Validation(10, []) != Validation(10, [1])
    assert Validation(10, []) != Validation(10, None)
    assert Validation(10, [1]) != Validation(10, None)
    assert Validation(10, []) != Validation(11, [1])
    assert Validation(10, [1, 2, 3]) != Validation(10, [1, 2, 3])
    assert Validation(10, [1, 2, 3]) != Validation(10, [1, 2, 3, 4])


# Generated at 2022-06-24 00:53:02.352830
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""

    from pymonet.lazy import Lazy

    validation = Validation.success(42)
    assert validation.to_lazy() == Lazy(lambda: validation.value)


# Generated at 2022-06-24 00:53:04.828596
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None)

# Generated at 2022-06-24 00:53:09.478259
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    >>> from pymonet.validation import Validation
    >>> def fn(x):
    ...     return Validation.success(x)
    >>> Validation.success([1, 2, 3]).bind(fn)
    Validation.success[[1, 2, 3]]
    >>> Validation.success([4, 5, 6]).bind(fn).value
    [4, 5, 6]
    """
    pass


# Generated at 2022-06-24 00:53:14.345183
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Success, Failure

    def multiply_2(number):
        return Validation(number * 2, [])

    def multiply_3(number):
        return Validation(number * 3, [])

    assert Validation.success(3).bind(multiply_2).bind(multiply_3) == Validation.success(18)
    assert Validation.success(3).bind(multiply_2).bind(multiply_3).value == 18
    assert Validation.success(3).bind(multiply_2).bind(multiply_3).is_success()

# Generated at 2022-06-24 00:53:18.315363
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail([]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:24.375847
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success([1, 2, 3])) == 'Validation.success[[1, 2, 3]]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['er1', 'er2', 'er3'])) == 'Validation.fail[None, [\'er1\', \'er2\', \'er3\']]'


# Generated at 2022-06-24 00:53:30.021452
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
    assert Validation.fail(["error"]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:53:33.596478
# Unit test for method __str__ of class Validation
def test_Validation___str__(): # type (...) -> None
    """
    Test __str__ method of Validation class.

    :returns: None
    :rtype: None
    """
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:53:37.144126
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    maybe = Validation.success(1).to_maybe()
    assert Maybe.just(1) == maybe
    maybe = Validation.fail().to_maybe()
    assert Maybe() == maybe


# Generated at 2022-06-24 00:53:41.589147
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('success')) == 'Validation.success[success]'
    assert str(Validation.fail(['fail'])) == 'Validation.fail[None, [\'fail\']]'



# Generated at 2022-06-24 00:53:44.105702
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    # Given
    valid = Validation.success(3)
    invalid = Validation.success(3)

    # Then
    assert valid.is_success() == True
    assert invalid.is_success() == False



# Generated at 2022-06-24 00:53:54.127953
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.monads import unit_test, TestFailed

    def test():
        return unit_test(
            [
                Validation.success(5) == Validation.success(5),
                Validation.success(5) == Validation.fail(['err']),
                Validation.fail(['err']) == Validation.success(5),
                Validation.fail(['err']) == Validation.fail(['err']),
            ],
            [
                True,
                False,
                False,
                True,
            ]
        )

    try:
        test()
    except TestFailed as e:
        print(e)
        return
    else:
        print('pass')


# Generated at 2022-06-24 00:54:03.840105
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(None) == Validation.success(None)
    assert Validation.success(None) != Validation.fail([])
    assert Validation.success(10) != Validation.fail([1])
    assert Validation.success(10) != Validation.fail([2])
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.fail([1]) != Validation.fail([2])



# Generated at 2022-06-24 00:54:06.217861
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.success()
    assert validation.is_fail() is False
    validation = Validation.fail()
    assert validation.is_fail() is True



# Generated at 2022-06-24 00:54:09.572878
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    >>> test_Validation_is_success()
    Test success
    """
    assert Validation.success(1).is_success()
    assert Validation.fail().is_success() is False
    print('Test success')



# Generated at 2022-06-24 00:54:12.788581
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Failure, Success
    assert (Validation.success(1).to_try() == Success(1))
    assert (Validation.fail([1, 2, 3]).to_try() == Failure(None, errors=[1, 2, 3]))
