

# Generated at 2022-06-24 00:44:16.679901
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(2)) == 'Validation.success[2]'
    assert str(Validation.fail(['a', 'b'])) == 'Validation.fail[None, [\'a\', \'b\']]'


# Generated at 2022-06-24 00:44:24.999314
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right, Either
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    # Validation[int, str]
    v1 = Validation.success(10)

    # function (int) -> Either[str, int]
    f1 = lambda x: Right(x)
    # function (int) -> Validation[str, int]
    f2 = lambda x: Validation.success(x)
    # function (int) -> Try[int]
    f3 = lambda x: Try(x)
    # function (int) -> Lazy[int]
    f4 = lambda x: Lazy(lambda: x)

    # v1.bind(f1) == Right(10)

# Generated at 2022-06-24 00:44:31.010941
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Test Validation.ap function
    """
    from pymonet.either import Left, Right

    valid_success = Validation.success('Success')
    valid_fail = Validation.fail(['Error'])
    either_success = valid_success.to_either()
    either_fail = valid_fail.to_either()

    assert valid_success.ap(lambda x: Right(x + ' ap')) == Validation.success('Success ap')
    assert valid_success.ap(lambda x: Left(['Error ap'])) == Validation.success('Success')
    assert valid_success.ap(valid_success) == Validation.success('Success')
    assert valid_success.ap(valid_fail) == Validation.fail(['Error'])


# Generated at 2022-06-24 00:44:33.603085
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail([1, 2]).to_maybe() == Nothing()


# Generated at 2022-06-24 00:44:35.939035
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1, 2, 3]).is_fail()
    assert Validation.success(1).is_fail() is False


# Generated at 2022-06-24 00:44:42.653695
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail(errors=['Error']).map(lambda x: x + 1) == Validation.fail(errors=['Error'])



# Generated at 2022-06-24 00:44:46.591473
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success().to_either() == Right(None)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])
    assert Validation.fail([]).to_either() == Left([])


# Generated at 2022-06-24 00:44:53.071998
# Unit test for constructor of class Validation
def test_Validation():
    v = Validation.success(1)

    assert v.value == 1
    assert len(v.errors) == 0

    v = Validation.fail([])

    assert v.value == None
    assert len(v.errors) == 0

    v = Validation.fail(['error'])

    assert v.value == None
    assert v.errors == ['error']


# Generated at 2022-06-24 00:44:54.982089
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()



# Generated at 2022-06-24 00:44:59.735379
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-24 00:45:05.452134
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():

    # when
    validate = Validation.fail(["failed"])

    # then
    assert validate.is_fail()

    # and
    assert not validate.is_success()


# Generated at 2022-06-24 00:45:11.026064
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left
    from pymonet.monad_try import Try

    # test Validation.success
    assert Validation.success(5) == Validation(5, [])
    assert Validation.success(5).is_success() == True
    assert Validation.success(5).is_fail() == False
    assert Validation.success() == Validation(None, [])
    assert Validation.success().is_success() == True
    assert Validation.success().is_fail() == False

    # test Validation.fail
    assert Validation.fail([1,2,3]) == Validation(None, [1,2,3])
    assert Validation.fail([1,2,3]).is_success() == False
    assert Validation.fail([1,2,3]).is_fail() == True

# Generated at 2022-06-24 00:45:12.672175
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)


# Generated at 2022-06-24 00:45:17.662362
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success(None).is_fail()
    assert Validation.fail().is_fail()
    assert Validation.fail([1, 2, 3]).is_fail()


# Generated at 2022-06-24 00:45:21.305112
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation('test', [1,2,3]).to_either() == Right('test')
    assert Validation(None, [1,2,3]).to_either() == Left([1,2,3])

# Generated at 2022-06-24 00:45:29.162871
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    validation = Validation(5, [])
    lazy_monad = validation.to_lazy()
    assert lazy_monad.value == 5
    assert lazy_monad.get() == 5
    assert isinstance(lazy_monad, Lazy)
    validation = Validation(None, [])
    lazy_monad = validation.to_lazy()
    assert lazy_monad.get() is None
    assert isinstance(lazy_monad, Lazy)


# Generated at 2022-06-24 00:45:32.554557
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('success_value') == Validation('success_value', [])
    assert Validation.fail(['message']) == Validation(None, ['message'])
    assert Validation(1, []) == Validation(1, [])
    assert Validation(None, ['message']) == Validation(None, ['message'])


# Generated at 2022-06-24 00:45:34.294832
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    val_case_1 = Validation.success('success')
    val_case_2 = Validation.success('success')
    return val_case_1 == val_case_2


# Generated at 2022-06-24 00:45:36.757339
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'

# Generated at 2022-06-24 00:45:42.862125
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:45.120585
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success('value').is_fail()
    assert Validation.fail().is_fail()


# Generated at 2022-06-24 00:45:48.883082
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    f = lambda: 1
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:45:53.609738
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:45:57.973415
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():  # pragma: no cover
    from pymonet.maybe import Maybe
    
    m_just_fail = Validation(Maybe.just, m_fail.errors)
    assert m_just_fail.is_fail() is True
    m_just_success = Validation(Maybe.just, [])
    assert m_just_success.is_fail() is False



# Generated at 2022-06-24 00:46:07.164248
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation.
    Tested methods:
        * Validation.success: returns successful Validation
        * Validation.fail: returns failed Validation
        * Validation.is_success: returns True when Validation is successful
        * Validation.is_fail: returns True when Validation is failed
        * Validation.map: maps new value
        * Validation.bind: maps new value
        * Validation.ap: apply function
        * Validation.to_maybe: transforms Validation to Maybe
        * Validation.to_either: transforms Validation to Either
        * Validation.to_box: transforms Validation to Box
        * Validation.to_lazy: transforms Validation to Lazy
        * Validation.to_try: transforms Validation to Try
    """
    raise Exception('Not implemented!')

# Generated at 2022-06-24 00:46:10.134643
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    valid_with_value = Validation.fail(errors='Errors')
    valid_with_errors = Validation.success(value=None)

    assert(valid_with_value.is_fail())
    assert(valid_with_errors.is_fail() is False)


# Generated at 2022-06-24 00:46:16.093841
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Method called in the test of pymonet.monad_validation.Validation
    """
    from pymonet import jit

    @jit
    def greater_than_zero(value):
        from pymonet.monad_validation import Validation

        return Validation.fail(errors=['Value should be greater than zero']) if value < 0 \
            else Validation.success(value)
    assert Validation.success(3).ap(lambda x: greater_than_zero(x * 2)) == Validation.fail(
        errors=['Value should be greater than zero'])
    assert Validation.success(-1).ap(lambda x: greater_than_zero(x * 2)) == Validation.fail(
        errors=['Value should be greater than zero'])

# Generated at 2022-06-24 00:46:20.635343
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(10, []) == Validation.success(10)
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, [1]) == Validation.fail([1])


# Generated at 2022-06-24 00:46:27.905659
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert(Validation.fail().to_either() == Left([]))
    assert(Validation.fail(['a']).to_either() == Left(['a']))
    assert(Validation.fail(['a', 'b']).to_either() == Left(['a', 'b']))
    assert(Validation.success().to_either() == Right(None))
    assert(Validation.success(0).to_either() == Right(0))
    assert(Validation.success('a').to_either() == Right('a'))


# Generated at 2022-06-24 00:46:33.113740
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Map method must return a new Validation with mapped current Validation value.
    """
    from pymonet.validation import Validation
    assert Validation.success(1) == Validation.success(1).map(lambda x: x + 1)
    assert Validation.fail([1, 2]) == Validation.fail([1, 2]).map(lambda x: x + 1)


# Generated at 2022-06-24 00:46:37.451308
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 2) == Validation.success(2).to_lazy()
    assert Lazy(lambda: None) == Validation.fail(["error"]).to_lazy()


# Generated at 2022-06-24 00:46:42.599616
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation.success(1)
    assert Validation(2, []) == Validation.success(2)
    assert Validation(None, [1, 2]) == Validation.fail([1, 2])
    assert Validation(None, [3, 4]) == Validation.fail([3, 4])


# Generated at 2022-06-24 00:46:48.527046
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert_that(Validation.success(5).to_try(), equal_to(Try.success(5)))
    assert_that(Validation.success(None).to_try(), equal_to(Try.success(None)))
    assert_that(Validation.fail(['Err']).to_try(), equal_to(Try.fail('Err')))
    assert_that(Validation.fail([]).to_try(), equal_to(Try.fail('No errors')))
    assert_that(Validation.fail(['Err', 'Err2']).to_try(), equal_to(Try.fail('Err')))


# Generated at 2022-06-24 00:46:54.644093
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.fail(['error 1'])
    assert False == validation.is_success()

    validation = Validation.fail(['error 1', 'error 2'])
    assert False == validation.is_success()

    validation = Validation.success('value')
    assert True == validation.is_success()


# Generated at 2022-06-24 00:47:00.380454
# Unit test for method ap of class Validation
def test_Validation_ap():
    def unit(x):
        return Validation.success(x)

    def unit2(x):
        return Validation.fail([x])

    assert Validation.success(1).ap(unit).value is 1
    assert Validation.success(2).ap(unit2).value is None
    assert Validation.fail(['a']).ap(unit).value is None
    assert Validation.fail(['a']).ap(unit2).value is None


# Generated at 2022-06-24 00:47:05.405010
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Unit test for method to_either of class Validation"""

    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.success(42).to_either() == Right(42)
    assert Validation.success(Try(42)).to_either() == Right(Try(42))


# Generated at 2022-06-24 00:47:12.076151
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def mapper(value):
        if value % 2 == 0:
            return Try.success(value)
        return Try.failure(value)

    val_success = Validation.success(10)
    result = val_success.bind(mapper)
    assert result.is_success()
    assert result.value == 10

    val_fail = Validation.success(11)
    result = val_fail.bind(mapper)
    assert result.is_fail()
    assert result.value is None


# Generated at 2022-06-24 00:47:14.399511
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.fail().to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:47:17.072023
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation.success('value')
    expected = Box('value')
    actual = validation.to_box()

    assert actual == expected



# Generated at 2022-06-24 00:47:23.869403
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda x: x - 1) == Validation.success(0)
    assert Validation.fail([1]).map(lambda x: x - 1) == Validation.fail([1])
    assert Validation.fail([1]).map(lambda x: x + 1) == Validation.fail([1])
    assert Validation.success(None).map(lambda x: x + 1) == Validation.success(None)
    assert Validation.success(None).map(lambda x: x - 1) == Validation.success(None)


# Generated at 2022-06-24 00:47:31.397956
# Unit test for method map of class Validation

# Generated at 2022-06-24 00:47:35.520604
# Unit test for constructor of class Validation
def test_Validation(): # pragma: no cover
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([]) == Validation(None, [])


# Generated at 2022-06-24 00:47:37.493607
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    def f():
        return 1
    assert Validation.success(1).to_lazy() == Lazy(f)


# Generated at 2022-06-24 00:47:38.870495
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:47:41.517711
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    errors = ['error 1', 'error 2']
    success = '123'
    assert Validation.success(success).is_success() is True
    assert Validation.success().is_success() is True
    assert Validation.fail(errors).is_success() is False


# Generated at 2022-06-24 00:47:49.851486
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert repr(Validation.success(2).to_lazy()) == 'Lazy(<function Validation.success.<locals>.<lambda> at 0x{}>)'.format(hex(id(Validation.success(2).to_lazy().f))[2:])
    assert repr(Validation.fail().to_lazy()) == 'Lazy(<function Validation.fail.<locals>.<lambda> at 0x{}>)'.format(hex(id(Validation.fail().to_lazy().f))[2:])


# Generated at 2022-06-24 00:47:53.960705
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(123)) == 'Validation.success[123]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-24 00:47:56.109601
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():

    # Given
    validation = Validation([], [])

    # Then
    assert validation.is_fail() == False


# Generated at 2022-06-24 00:48:00.721113
# Unit test for method ap of class Validation
def test_Validation_ap():
    def to_upper(v):
        return Validation.success(v.upper())

    def to_lower(v):
        return Validation.success(v.lower())

    validation = Validation.success('Validation')
    assert validation.ap(to_upper) == Validation.success('VALIDATION')
    assert validation.ap(to_lower) == Validation.success('validation')


# Generated at 2022-06-24 00:48:05.791809
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-24 00:48:16.150954
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert (Validation.success(1) == Validation.success(1))
    assert (Validation.success(1) == Validation(1, []))
    assert (Validation.fail([]) == Validation.fail([]))
    assert (Validation.fail([]) == Validation(None, []))
    assert (Validation.fail([1]) == Validation.fail([1]))
    assert (Validation.fail([1]) == Validation(None, [1]))
    assert (not Validation.success(1) == Validation(2, []))
    assert (not Validation.success(1) == Validation(1, [1]))
    assert (not Validation.fail([1]) == Validation(None, [2]))
    assert (not Validation.fail([1]) == Validation.success())

# Generated at 2022-06-24 00:48:19.468701
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation(1, []).to_either() == Right(1)
    assert Validation(1, [1]).to_either() == Left([1])


# Generated at 2022-06-24 00:48:22.750591
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success(2).is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail(['e1', 'e2']).is_success() == False


# Generated at 2022-06-24 00:48:28.397961
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(2) != Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail([2]) != Validation(None, [1])


# Generated at 2022-06-24 00:48:33.788909
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    Test.equal(Validation.success(1).to_try(), Try.success(1))
    Test.equal(Validation.fail([]).to_try(), Try.fail(None, errors=True))


# Generated at 2022-06-24 00:48:38.494136
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    >>> from pymonet.validation import Validation

    >>> validation = Validation.success(2)
    >>> validation.to_either()
    Right(2)

    >>> validation = Validation.fail(['Error message'])
    >>> validation.to_either()
    Left(['Error message'])
    """
    pass


# Generated at 2022-06-24 00:48:47.170587
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test for method __eq__ for class Validation.
    """
    from pymonet.decorators import raises
    from pymonet.errors import UncomparableTypesException

    assert Validation(1, []) == Validation(1, [])
    assert Validation.fail() == Validation.fail()
    assert Validation.fail(["a"]) == Validation.fail(["a"])
    assert Validation(1, []) != Validation.fail()
    assert Validation.fail() != Validation.fail(["a"])
    assert Validation.fail(["a"]) != Validation.fail(["b"])
    assert Validation(1, []) != Validation(2, [])
    assert Validation.fail(["a"]) != Validation.fail(["a", "b"])

   

# Generated at 2022-06-24 00:48:53.379399
# Unit test for method ap of class Validation
def test_Validation_ap():
    def _f(x):
        nonlocal _errors
        return Validation(x + 1, _errors)
    _errors = [True, False]
    assert Validation(1, [True]).ap(_f).errors == [True, True, False]



# Generated at 2022-06-24 00:49:00.998197
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success([1]) == Validation.success([1])
    assert Validation.fail() == Validation.fail()
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1,2]) == Validation.fail([1,2])
    assert Validation.success(1) != Validation.fail()
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) != Validation.success(1)
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1,2]) != Validation.fail([1,])

# Unit test

# Generated at 2022-06-24 00:49:08.255273
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(5)) == "Validation.success[5]"
    assert str(Validation.fail()) == "Validation.fail[None, []]"
    assert str(Validation.fail([1,2,3])) == "Validation.fail[None, [1, 2, 3]]"


# Generated at 2022-06-24 00:49:11.474881
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation
    """
    from pymonet.box import Box

    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail('errors list').to_box() == Box(None)


# Generated at 2022-06-24 00:49:13.309038
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.validation import Validation

    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:49:15.662633
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.monad_try import Failure

    assert Validation.success().is_success()
    assert not Validation.fail().is_success()



# Generated at 2022-06-24 00:49:21.829178
# Unit test for method ap of class Validation
def test_Validation_ap():
    v = Validation.success(123)
    def fn(x):
        return Validation.fail(['error1', 'error2'])
    assert v.ap(fn) == Validation.success(123)
    assert v.ap(fn).errors == ['error1', 'error2']
    v = Validation.fail(['error1'])
    assert v.ap(fn) == Validation.fail(['error1'])
    assert v.ap(fn).errors == ['error1']
    assert v.ap(fn).value is None
    v = Validation.success()
    assert v.ap(fn).value is None
    assert v.ap(fn) == Validation.success(None)


# Generated at 2022-06-24 00:49:28.547533
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map for Validation
    """
    # Validation with success
    assert Validation.success('test').map(lambda x: x + 'test2') == Validation.success('testtest2')
    assert Validation.success('test').map(lambda x: x.upper()) == Validation.success('TEST')
    assert Validation.success(None).map(lambda x: 'test2').value == 'test2'

    # Validation with error
    assert Validation.fail('error').map(lambda x: 'test2') == Validation.fail('error')
    assert Validation.fail('error').map(lambda x: x + 'test2') == Validation.fail('error')


# Generated at 2022-06-24 00:49:40.524961
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for method to_try of class Validation"""

    # Check if function returns successfully Try with correct value
    def test_success_validation_to_try_without_errors():
        """
        Unit test for method to_try of class Validation
        when it is naturally successful, with value and no errors
        """
        from pymonet.monad_try import Try
        assert Validation(3, []).to_try() == Try(3, is_success=True)

    # Check if function returns successfully Try with correct value
    def test_success_validation_to_try_with_errors():
        """
        Unit test for method to_try of class Validation
        when it is successful, with value and errors
        """
        from pymonet.monad_try import Try

# Generated at 2022-06-24 00:49:46.182412
# Unit test for method bind of class Validation
def test_Validation_bind():
    def folder(value):
        if value % 2 == 0:
            return Validation.success(value / 2)
        return Validation.fail(['Not even'])

    assert Validation.success(2).bind(folder) == Validation.success(1)
    assert Validation.success(3).bind(folder) == Validation.fail(['Not even'])
    assert Validation.fail(['Something bad']).bind(folder) == Validation.fail(['Something bad'])

# Generated at 2022-06-24 00:49:52.963119
# Unit test for method ap of class Validation
def test_Validation_ap():
    fn = lambda a: Validation.success(a * 2)
    res = Validation.success(1).ap(fn)
    assert res == Validation(2, [])

    fn = lambda a: Validation.fail([a])
    res = Validation.success(1).ap(fn)
    assert res == Validation(1, [1])

    fn = lambda a: Validation.success(a * 2)
    res = Validation.fail([1]).ap(fn)
    assert res == Validation(None, [1])

    fn = lambda a: Validation.fail([a])
    res = Validation.fail([1]).ap(fn)
    assert res == Validation(None, [1, 1])



# Generated at 2022-06-24 00:49:57.973523
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.success(1)
    assert validation.to_try() == Try(1)

    validation = Validation.fail([1, 2, 3])
    assert validation.to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:50:00.751927
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success('a').to_box() == Box('a')
    assert Validation.fail(['error']).to_box() == Box(None)

# Generated at 2022-06-24 00:50:03.318853
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation(1, []).value == 1
    assert Validation('', []).value == ''
    assert Validation(None, ['']).errors == ['']


# Generated at 2022-06-24 00:50:05.350243
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation(1, []).to_try() == Try(1)
    assert Validation(None, [1]).to_try() == Try(None)


# Generated at 2022-06-24 00:50:13.531105
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    assert Validation.success('abc') == Validation.success('abc')
    assert Validation.success('abc') != Validation.success('xyz')
    assert Validation.success('abc') != Left(['abc'])

    assert Validation.fail(['abc']) == Validation.fail(['abc'])
    assert Validation.fail(['abc']) != Validation.fail(['xyz'])
    assert Validation.fail(['abc']) != Right('xyz')


# Generated at 2022-06-24 00:50:20.030847
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() == False
    assert Validation.success(1).is_fail() == False
    assert Validation.success(1).map(lambda x: x*2).is_fail() == False
    assert Validation.fail().is_fail() == True
    assert Validation.fail('error').is_fail() == True
    assert Validation.fail('error').map(lambda x: x*2).is_fail() == True


# Generated at 2022-06-24 00:50:21.851897
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(42) == Validation.success(42).to_try().get_or_else(0)
    assert 0 == Validation.fail(['error']).to_try().get_or_raise()

# Generated at 2022-06-24 00:50:26.182453
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test the method to_either of class Validation.

    :return: none
    """
    from pymonet.either import Left, Right
    Validation.success(1).to_either() == Right(1)
    Validation.fail(['a']).to_either() == Left(['a'])


# Generated at 2022-06-24 00:50:33.140755
# Unit test for method bind of class Validation
def test_Validation_bind():
    def inc(x):
        return x + 1

    def double(x):
        return x * 2

    assert Validation.success(2).bind(inc).map(double) == Validation.success(6)
    assert Validation.fail([1, 2]).bind(inc) == Validation.fail([1, 2])
    assert Validation.fail([2]).map(double) == Validation.fail([2])


# Generated at 2022-06-24 00:50:37.157762
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.val import Validation

    assert Validation.success('hello') == Validation.success('hello')
    assert Validation.success(1) != Validation.success(2)

    assert Validation.fail(['hello']) == Validation.fail(['hello'])
    assert Validation.fail(['hello']) != Validation.fail([1])


# Generated at 2022-06-24 00:50:42.790543
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left
    from pymonet.validation import Validation
    from pymonet.box import Box

    def fn(x):
        return Validation.success(Box(x))

    validation = Validation.fail(['Invalid name'])
    assert (validation.ap(fn).to_either() ==
            Left(['Invalid name']))


# Generated at 2022-06-24 00:50:49.260296
# Unit test for method bind of class Validation
def test_Validation_bind():
    def return_validation_success(value):
        return Validation.success(value + value)

    def return_validation_fail(value):
        return Validation.fail(['error'])

    assert Validation.success(5).bind(return_validation_success).value == 10
    assert Validation.success(5).bind(return_validation_fail).is_fail()
    assert Validation.fail(['error']).bind(return_validation_success).is_fail()
    assert Validation.fail(['error']).bind(return_validation_fail).is_fail()



# Generated at 2022-06-24 00:50:58.673675
# Unit test for constructor of class Validation
def test_Validation():
    assert str(Validation.success('hello')) == 'Validation.success[hello]'
    assert str(Validation.fail(['error1'])) == 'Validation.fail[None, [error1]]'
    assert str(Validation.fail(['error1', 'error2'])) == 'Validation.fail[None, [error1, error2]]'
    assert Validation.success('hello') == Validation('hello', [])
    assert Validation.fail(['error1']) == Validation(None, ['error1'])
    assert Validation.fail(['error1', 'error2']) == Validation(None, ['error1', 'error2'])


# Generated at 2022-06-24 00:51:04.507919
# Unit test for constructor of class Validation
def test_Validation():
    unit_success = Validation.success(value=1)
    unit_fail = Validation.fail(errors=[])
    assert unit_success == unit_success
    assert unit_fail == unit_fail
    assert unit_success != unit_fail


# Generated at 2022-06-24 00:51:07.635068
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda a: a + 1) == Validation.success(2)
    assert Validation.fail(['error']).map(lambda a: a + 1) == Validation.fail(['error'])


# Generated at 2022-06-24 00:51:15.898692
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()
    assert Validation.fail(['a']).to_maybe() == Maybe.nothing()
    assert Validation.fail([1, 'a']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:51:20.437684
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.either import Right
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(2).to_box() == Box(2)

    assert Validation.fail([1]).to_box() == Box(None)
    assert Validation.fail([1, 2]).to_box() == Box(None)


# Generated at 2022-06-24 00:51:27.859050
# Unit test for method map of class Validation
def test_Validation_map():
    success = Validation.success(10)
    assert success.map(lambda x: x / 2) == Validation.success(5), 'It should be 10 / 2 = 5'
    assert success.map(lambda x: x + 10) == Validation.success(20), 'It should be 10 + 10 = 20'

    error = Validation.fail([])
    assert error.map(lambda x: x / 2) == Validation.fail([]), 'It should not change errors'
    assert error.map(lambda x: x + 10) == Validation.fail([]), 'It should be 10 + 10 = 20'

# Generated at 2022-06-24 00:51:32.903012
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation.
    """
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(None, [1]).to_box() == Box(None)


# Generated at 2022-06-24 00:51:42.028801
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert (
        Validation(
            1,
            [
                1,
                2
            ]
        ) == Validation(
            1,
            [
                1,
                2
            ]
        ))
    assert (
        Validation(
            2,
            [
                1,
                2
            ]
        ) != Validation(
            2,
            [
                1,
                2,
                3
            ]
        ))
    assert (
        Validation(
            3,
            []
        ) == Validation(
            3,
            []
        ))
    assert (
        Validation(
            4,
            []
        ) != Validation(
            5,
            []
        ))

# Generated at 2022-06-24 00:51:43.790683
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for method to_try of class Validation"""

    assert Validation.success("Hello").to_try() == Try("Hello")
    assert Validation.fail("Hello").to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:51:51.439625
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(5, [])) == 'Validation.success[5]'
    assert str(Validation(None, [5, 6, 7])) == 'Validation.fail[None, [5, 6, 7]]'

    assert repr(Validation(5, [])) == 'Validation.success[5]'
    assert repr(Validation(None, [5, 6, 7])) == 'Validation.fail[None, [5, 6, 7]]'


# Generated at 2022-06-24 00:51:56.283204
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    test_cases = [
        {
            'input': {
                'value': 1,
                'errors': [],
            },
            'expected': 'Validation.success[1]',
        },
        {
            'input': {
                'value': 1,
                'errors': ['error'],
            },
            'expected': 'Validation.fail[1, [\'error\']]',
        },
    ]

    for test_case in test_cases:
        value = test_case['input']['value']
        errors = test_case['input']['errors']
        validation = Validation(value, errors)
        assert str(validation) == test_case['expected']


# Generated at 2022-06-24 00:52:04.335136
# Unit test for method ap of class Validation
def test_Validation_ap():
    from functools import partial

    def validate_name_must_not_be_empty(name):
        return Validation.fail([name]) if len(name) == 0 else Validation.success(name)

    def validate_name_must_be_equal_to_expected(expected_name):
        return partial(
            lambda name: Validation.fail(['error']) if name != expected_name else Validation.success(name))

    validation = Validation.success('ivan')
    validation = validation.ap(validate_name_must_not_be_empty)
    validation = validation.ap(validate_name_must_be_equal_to_expected('ivan'))
    assert validation == Validation('ivan', [])

# Generated at 2022-06-24 00:52:12.100784
# Unit test for constructor of class Validation
def test_Validation():
    """
    >>> test_Validation()
    'OK'
    """
    def eq(x, y):
        return x == y

    # Validation.success
    actual = Validation.success(1)
    assert actual == Validation(1, [])

    # Validation.fail
    actual = Validation.fail([1, 2, 3])
    assert actual == Validation(None, [1, 2, 3])

    return 'OK'


# Generated at 2022-06-24 00:52:18.032310
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:52:24.759469
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test Validation map method.
    """

    # success: (A) -> B
    assert Validation.success(3).map(lambda x: x + 1) == Validation.success(4)
    # fail: (A) -> B
    assert Validation.fail(["Error"]).map(lambda x: x + 1) == Validation.fail(["Error"])



# Generated at 2022-06-24 00:52:31.550480
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """Unit test for method is_success of class Validation"""
    assert Validation.success().is_success() is True
    assert Validation.success(1).is_success() is True
    assert Validation.success([1, 2]).is_success() is True
    assert Validation.success('test').is_success() is True
    assert Validation.success((1, 2)).is_success() is True

    assert Validation.fail().is_success() is False
    assert Validation.fail([1, 2]).is_success() is False
    assert Validation.fail('test').is_success() is False
    assert Validation.fail((1, 2)).is_success() is False


# Generated at 2022-06-24 00:52:39.096603
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test to_lazy method of class Validation"""
    from pymonet.lazy import Lazy

    validation_with_value = Validation.success(100)
    assert validation_with_value.to_lazy() == Lazy(lambda: 100)

    validation_with_no_value = Validation.fail([])
    assert callable(validation_with_no_value.to_lazy().value) is False
    assert validation_with_no_value.to_lazy().value is None


# Generated at 2022-06-24 00:52:45.952049
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    from pymonet.either import Right
    from pymonet.validation import Validation


# Generated at 2022-06-24 00:52:52.001756
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # when
    success = Validation.success('value')
    fail = Validation.fail(['error'])

    # then
    assert str(success) == 'Validation.success[value]'
    assert str(fail) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-24 00:52:54.811735
# Unit test for constructor of class Validation
def test_Validation():

    assert Validation.success(5) == Validation(5, [])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])


# Generated at 2022-06-24 00:53:00.763047
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(['Error 1', 'Error 2']).to_box() == Box(None)



# Generated at 2022-06-24 00:53:05.093481
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    assert Validation(10, []).to_box() == Box(10)


# Generated at 2022-06-24 00:53:07.838303
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1).value == 1
    assert not Validation.success(1).errors
    assert Validation.fail('a').value is None
    assert Validation.fail('a').errors == ['a']


# Generated at 2022-06-24 00:53:11.915722
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.list import List
    from pymonet.maybe import Just, Nothing
    from pymonet.validation import Validation

    assert Validation.success().to_maybe() == Nothing
    assert Validation.success(10).to_maybe() == Just(10)
    assert Validation.fail([1, 2, 3]).to_maybe() == Nothing
    assert Validation.fail([1, 2, 3]).to_maybe() == Nothing


# Generated at 2022-06-24 00:53:20.660653
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation.
    Two tests are created. First test checks that validation bind to folder returns correct Validation object.
    Second test checks that exception is raised when incorrect types are used.
    """
    validation = Validation.success(1)
    assert validation.bind(lambda x: Validation.success(x + 1)) == Validation.success(2), \
        'Failed to validate Validation.bind method.'

    try:
        Validation.success(1).bind(lambda x: Validation.success(x + 1)) != Validation.success(2)
        assert False, 'Failed to validate Validation.bind method for incorrect types.'
    except AssertionError:
        pass

# Generated at 2022-06-24 00:53:25.413222
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Just, Nothing

    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.success(None).to_maybe() == Just(None)
    assert Validation.fail().to_maybe() == Nothing


# Generated at 2022-06-24 00:53:34.539514
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation has method `ap` that can accept another monad as a parameter and
    returned monad is merged with current monad. If other monad is Try monad
    and return failed monad, than current monad also failed with errors from
    Try monad

    This function test ap method
    """
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    # Successful Try[Int] + Successful Validation[String, List[Error]] = Successful Validation[String, List[Error]]
    assert Validation.success('test').ap(Try.success(1)) == Validation.success('test')

    # Failed Try[Int] + Successful Validation[String, List[Error]] = Failed Validation[String, List[Error]]

# Generated at 2022-06-24 00:53:36.538910
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(42)) == "Validation.success[42]"
    assert str(Validation.fail(["error", "other error"])) == "Validation.fail[None, ['error', 'other error']]"


# Generated at 2022-06-24 00:53:40.296027
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() is True
    assert Validation.success().is_fail() is False


# Generated at 2022-06-24 00:53:47.287178
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.success(10).is_success() is True
    assert Validation.success('Hello').is_success() is True
    assert Validation.success(['a', 'b']).is_success() is True
    assert Validation.success({'a': 10, 'b': 20}).is_success() is True
    assert Validation.success(A).is_success() is True
    assert Validation.success(A()).is_success() is True

    assert Validation.fail().is_success() is False
    assert Validation.fail([10]).is_success() is False
    assert Validation.fail(['Hello']).is_success() is False
    assert Validation.fail([['a', 'b']]).is_success() is False
    assert Validation

# Generated at 2022-06-24 00:53:55.429776
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation.success().to_box() == Box(None)
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(2).to_box() == Box(2)
    assert Validation.fail(1).to_box() == Box(None)
    assert Validation.fail(2).to_box() == Box(None)


# Generated at 2022-06-24 00:53:57.711221
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(42).to_box() == Box(42)


# Generated at 2022-06-24 00:54:00.469454
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test for to_box method.
    """
    assert Validation('value', []).to_box() == Box('value')


# Generated at 2022-06-24 00:54:03.089740
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    res = Validation.fail(['error']).to_box()
    expected = Box(None)

    assert res == expected


# Generated at 2022-06-24 00:54:06.217862
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:54:12.068819
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_maybe import Maybe

    assert Validation.success(99).to_either() == Right(99)
    assert Validation.fail().to_either() == Left(())
    assert Validation.fail(['Error 1']).to_either() == Left(['Error 1'])
    assert Validation.fail(['Error 1', 'Error 2']).to_either() == Left(['Error 1', 'Error 2'])
