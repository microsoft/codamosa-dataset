

# Generated at 2022-06-24 00:44:18.029824
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.fail(['f1']).ap(lambda x: Validation.fail(['f2'])) == Validation.fail(['f1', 'f2'])
    assert Validation.success(2).ap(lambda x: Validation.fail(['f3'])) == Validation.fail(['f3'])
    assert Validation.fail(['f4']).ap(lambda x: Validation.success(2)) == Validation.fail(['f4'])
    assert Validation.success(2).ap(lambda x: Validation.success(4)) == Validation.success(4)

# Generated at 2022-06-24 00:44:21.494194
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert_that(str(Validation.success(10)),
                is_('Validation.success[10]'))
    assert_that(str(Validation.fail(['error'])),
                is_('Validation.fail[None, [\'error\']]'))

# Generated at 2022-06-24 00:44:22.979502
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()



# Generated at 2022-06-24 00:44:25.225695
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation.success(1)
    assert validation.value == 1
    assert validation.errors == []

    validation = Validation.fail(['an error'])
    assert validation.value is None
    assert validation.errors == ['an error']

# Generated at 2022-06-24 00:44:26.851306
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1, 2]).is_fail() is True
    assert Validation.success(1).is_fail() is False


# Generated at 2022-06-24 00:44:30.176248
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Validation(1, []).to_either() == Right(1)
    assert Validation.success(1).to_either() == Right(1)
    assert Validation(None, ['error']).to_either() == Left(['error'])
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:44:35.761022
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(4).is_success()
    assert not Validation.success(4).is_fail()

    assert not Validation.fail(['error']).is_success()
    assert Validation.fail(['error']).is_fail()


# Generated at 2022-06-24 00:44:40.297200
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(1).bind(lambda n: Validation.success(n + 10)) == Validation.success(11) \
        and Validation.success(2).bind(lambda n: Validation.fail(['error'])) == Validation.fail(['error'])


# Generated at 2022-06-24 00:44:47.026527
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    assert Maybe.just(10).to_validation().to_maybe() == Maybe.just(10)
    assert Maybe.nothing().to_validation().to_maybe() == Maybe.nothing()
    assert Lazy(lambda: None).to_validation().to_maybe() == Maybe.nothing()
    assert Try(10).to_validation().to_maybe() == Maybe.just(10)
    assert Try(10).fail([]).to_validation().to_maybe() == Maybe.nothing()
    assert Left(10).to_validation().to_maybe() == Maybe.nothing()
    assert Right(10).to_validation().to_maybe()

# Generated at 2022-06-24 00:44:54.058819
# Unit test for method bind of class Validation
def test_Validation_bind():
    def _folder(value):
        '''
        Function for testing bind method of Validation Class
        '''
        return Validation.success(value + 1)

    assert Validation.success(1).bind(_folder) == Validation.success(2)
    assert Validation.fail([ValueError]).bind(_folder) == Validation.fail([ValueError])
    assert Validation.success(1).bind(lambda _: Validation.fail([ValueError])) == Validation.fail([ValueError])


# Generated at 2022-06-24 00:44:59.185171
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('value').to_either() == Right('value')
    assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])


# Generated at 2022-06-24 00:45:01.430733
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Unit test for method to_lazy of class Validation"""
    assert Validation.success('value') == Validation.success('value').to_lazy().solve()


# Generated at 2022-06-24 00:45:03.744894
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test to check Validation.is_fail method.
    """

    assert Validation.fail(['No errors']).is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-24 00:45:06.217734
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1), 'Successful Validation to Box conversion'
    assert Validation.fail([1]).to_box() == Box(None), 'Failed Validation to Box conversion'



# Generated at 2022-06-24 00:45:09.599285
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.maybe import Maybe

    assert Validation.success('Test').to_maybe() == Maybe.just('Test')
    assert Validation.fail().to_maybe() == Maybe.nothing()
    assert Validation('Test', []).to_maybe() == Maybe.just('Test')
    assert Validation(None, ['Error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:14.157520
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.validation import Validation

    def is_fail(errors, expected):
        validation = Validation(None, errors)
        assert validation.is_fail() == expected, 'It should return {} for {}'.format(expected, errors)

    print('test_Validation_is_fail... ', end='')
    is_fail([], False)
    is_fail([1], True)
    is_fail([1, 2, 3], True)
    print('OK')


# Generated at 2022-06-24 00:45:16.230783
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(10).to_try() == Try.pure(10)
    assert Validation.fail([Error('error')]).to_try() == Try.raise_(Error('error'))

# Generated at 2022-06-24 00:45:18.417542
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail().to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:45:26.713219
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.validation import Validation
    from pymonet.validation import Validation as V
    from pymonet.validation import ValidationError

    assert V.success(12).is_success() == True
    assert V.fail(errors=[0, 1]).is_success() == False
    assert V.success(None).is_success() == True
    assert V.fail(errors=[]).is_success() == False
    assert V.fail(errors=[ValidationError("error")]).is_success() == False
    assert V.success(0).is_success() == True


# Generated at 2022-06-24 00:45:32.785955
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.success(42).is_success() is True
    assert Validation.fail(['error']).is_success() is False
    assert Validation.fail().is_success() is False


# Generated at 2022-06-24 00:45:36.028214
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success([1]).to_box() == Box([1])
    assert Validation.success(None).to_box() == Box(None)


# Generated at 2022-06-24 00:45:38.499704
# Unit test for constructor of class Validation
def test_Validation():
    # Test Success
    assert Validation.success(5) == Validation(5, []), 'Test Validation.success'

    # Test Fail
    assert Validation.fail() == Validation(None, []), 'Test Validation.fail'


# Generated at 2022-06-24 00:45:44.352621
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert (
        str(Validation.success('success value'))
        ==
        "Validation.success['success value']"
    )

    assert (
        str(Validation.fail(['error 1', 'error 2']))
        ==
        "Validation.fail[None, ['error 1', 'error 2']]"
    )


# Generated at 2022-06-24 00:45:48.194626
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(123)) == 'Validation.success[123]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:45:56.595342
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right

    assert Validation.success(10).bind(lambda a: Right(a)).value == Validation.success(10).value
    assert Validation.success(10).bind(lambda a: Right(a)).errors == Validation.success(10).errors
    assert Validation.success(10).bind(lambda a: Left('Error!')).value == Validation.success(10).value
    assert Validation.success(10).bind(lambda a: Left('Error!')).errors == Validation.success(10).errors
    assert Validation.fail([10, 20]).bind(lambda a: Left('Error!')).value == Validation.fail([10, 20]).value

# Generated at 2022-06-24 00:46:02.060839
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    a = Validation.success(1)
    b = Validation.fail([1, 2])

    assert a.to_either() == Right(1)
    assert b.to_either() == Left([1, 2])


# Generated at 2022-06-24 00:46:05.871989
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(None) == Validation.success(1)
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 1) == Validation.fail([1, 2, 3])

# Generated at 2022-06-24 00:46:09.755285
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation.

    :returns: True
    :rtype: Boolean
    """
    assert Validation.fail().is_fail() == True
    assert Validation.success(42).is_fail() == False


# Generated at 2022-06-24 00:46:15.892908
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    from pymonet.validation import Validation

    def minus(x):
        return -x

    def double(x):
        return x * 2

    def inc(x):
        return x + 1

    result = Validation.success(1).bind(minus).bind(double).bind(inc)

    assert result.value == -1, 'Should return -1'
    assert len(result.errors) == 0, 'Should return no errors'

    def fail(x):
        return Validation.fail([x])

    result = Validation.success(1).bind(fail).bind(minus).bind(double).bind(inc)

    assert result.value is None, 'Should return None'

# Generated at 2022-06-24 00:46:23.524846
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(-1.4).to_box() == Box(-1.4)
    assert Validation.success([1, 2, 3]).to_box() == Box([1, 2, 3])
    assert Validation.success({1, 2, 3}).to_box() == Box({1, 2, 3})
    assert Validation.success({'a': 1, 'b': 2}).to_box() == Box({'a': 1, 'b': 2})


# Generated at 2022-06-24 00:46:27.722460
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    # GIVEN empty Validation
    validation = Validation.fail()

    # WHEN to_maybe is called
    maybe = validation.to_maybe()

    # THEN maybe is empty
    assert maybe == Maybe.nothing()

    # GIVEN value Validation
    validation = Validation.success('value')

    # WHEN to_maybe is called
    maybe = validation.to_maybe()

    # THEN maybe is some
    assert maybe == Maybe.just(validation.value)


# Generated at 2022-06-24 00:46:37.245181
# Unit test for method ap of class Validation
def test_Validation_ap():
    v1 = Validation.fail([1, 2, 3])
    v2 = Validation.fail([4, 5, 6])
    v3 = Validation.fail([7, 8, 9])

    assert v1.ap(lambda: v2) == Validation(None, [1, 2, 3, 4, 5, 6])
    assert v2.ap(lambda: v3) == Validation(None, [4, 5, 6, 7, 8, 9])
    assert v1.ap(lambda: v3) == Validation(None, [1, 2, 3, 7, 8, 9])
    assert Validation.fail([]).ap(lambda: v1) == Validation(None, [1, 2, 3])


# Generated at 2022-06-24 00:46:44.411252
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    def run_test(expected, value, errors=[]):
        # act
        validation = Validation(value, errors)

        # assert
        assert expected == validation.is_success()

    # arrange
    run_test(True, 10)
    run_test(True, 'str')
    run_test(True, [1, 2, 3])

    run_test(False, None, [1])
    run_test(False, None, ['error'])
    run_test(False, None, [1, 2, 3])


# Generated at 2022-06-24 00:46:52.098233
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.validation import Validation

    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([]) != Validation.fail(['error'])
    assert Validation.fail([]) != Validation.success()


# Generated at 2022-06-24 00:47:03.057643
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Validation.success('test').to_box() == Box('test')
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')
    assert Validation.success('test').to_maybe() == Maybe.just('test')
    assert Validation.success('test').to_try() == Try('test')
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.fail([]).to

# Generated at 2022-06-24 00:47:09.873927
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success
    from pymonet.monad_try import Failure

    assert Validation.success(4).to_try() == Success(4)
    assert Validation.fail([]).to_try() == Failure(None, [])
    assert Validation.fail(['1']).to_try() == Failure(None, ['1'])

# Generated at 2022-06-24 00:47:12.668018
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.fail(None).is_success()
    assert not Validation.fail([1, 2, 3]).is_success()


# Generated at 2022-06-24 00:47:16.503296
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert isinstance(Validation.success(1).to_try(), Try)
    assert isinstance(Validation.fail([]).to_try(), Try)
    assert isinstance(Validation.fail(['error']).to_try(), Try)



# Generated at 2022-06-24 00:47:21.576143
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert Validation.success(1).is_success()

    assert not Validation.fail().is_success()
    assert not Validation.fail(1).is_success()
    assert not Validation.fail([1]).is_success()


# Generated at 2022-06-24 00:47:23.594616
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:47:29.148423
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(25) == Validation.success(25)
    assert Validation.success(25) != Validation.success(26)
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.fail([1, 2, 3]) != Validation.fail([1, 2, 4])
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([]) != Validation.fail([1])

# Generated at 2022-06-24 00:47:35.462899
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success().to_either() == Right(None)
    assert Validation.success(123).to_either() == Right(123)

    assert Validation.fail().to_either() == Left([])
    assert Validation.fail(['a', 'b']).to_either() == Left(['a', 'b'])


# Generated at 2022-06-24 00:47:38.445170
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(2).to_try() == Success(2)
    assert Validation.fail(['error']).to_try() == Failure(['error'])

# Generated at 2022-06-24 00:47:41.123712
# Unit test for constructor of class Validation
def test_Validation():
    # Test Validation constructor: Validation.success
    validation_success = Validation.success()
    assert validation_success.value is None
    assert len(validation_success.errors) == 0

    # Test Validation constructor: Validation.fail
    validation_fail = Validation.fail()
    assert validation_fail.value is None
    assert len(validation_fail.errors) == 0



# Generated at 2022-06-24 00:47:46.465383
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(2).bind(lambda value: Validation.success(value * 2)) == Validation.success(4)


# Generated at 2022-06-24 00:47:52.226974
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success_validation1 = Validation.success()
    assert success_validation1.is_success() == True

    success_validation2 = Validation.success(1)
    assert success_validation2.is_success() == True

    success_validation3 = Validation.success([])
    assert success_validation3.is_success() == True

    fail_validation1 = Validation.fail()
    assert fail_validation1.is_success() == False

    fail_validation2 = Validation.fail([])
    assert fail_validation2.is_success() == False

    fail_validation3 = Validation.fail(['error'])
    assert fail_validation3.is_success() == False


# Generated at 2022-06-24 00:47:59.115034
# Unit test for method map of class Validation
def test_Validation_map():
    return (Validation.fail(['first error', 'second error']) ==
            Validation(None, []).map(lambda x: x).ap(lambda x: Validation.fail(['first error', 'second error']))) & \
           (Validation(5, []) == Validation(1, []).map(lambda x: x + 4))

# Generated at 2022-06-24 00:48:03.615389
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map of class Validation.
    """
    # Successful Validation
    validate = Validation.success(10)

    # Applying mapper function
    unit_test.test_value(validate.map(lambda x: x * 2), Validation.success(20))

    # Failed Validation
    validate = Validation.fail(['error1', 'error2'])

    # Applying mapper function
    result = validate.map(lambda x: x * 2)
    unit_test.test_value(result, Validation.fail(['error1', 'error2']))
    unit_test.test_true(result.is_fail())

    unit_test.test_true(result.to_either().is_left())

# Generated at 2022-06-24 00:48:05.748393
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])


# Generated at 2022-06-24 00:48:13.735933
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    It tests to_either method functionality.
    """
    from pymonet.either import Right

    assert Validation.success(10).to_either() == Right(10)
    assert Validation.success(20).to_either() == Right(20)

    assert Validation.fail([]).to_either() == Right(None)
    assert Validation.fail([1]).to_either() == Right(None)



# Generated at 2022-06-24 00:48:18.655799
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.validation import error

    validation = Validation.fail([error(u'something went wrong')])
    fn = lambda x: Try.fail(u'another error').to_validation()
    result = validation.ap(fn)
    assert result.is_fail()
    assert result.errors == [error(u'something went wrong'), error(u'another error')]


# Generated at 2022-06-24 00:48:25.688656
# Unit test for method ap of class Validation
def test_Validation_ap():
    valid_val = Validation.success(3)
    invalid_val = Validation.fail(['Error 1'])

    def inc(value):
        return Validation.success(value + 1)

    def dec(value):
        return Validation.success(value - 1)

    assert valid_val.ap(inc) == Validation.success(4)
    assert invalid_val.ap(inc) == Validation.fail(['Error 1'])
    assert valid_val.ap(dec) == Validation.success(3)
    assert invalid_val.ap(dec) == Validation.fail(['Error 1'])

    def fail_with_error(value):
        return Validation.fail(['Error 2'])

    assert valid_val.ap(fail_with_error) == Validation.fail(['Error 2'])


# Generated at 2022-06-24 00:48:28.400709
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left

    assert Validation.success(1).bind(lambda x: Left(x + 2)) == Left(3)

# Generated at 2022-06-24 00:48:35.000249
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test for method is_fail of class Validation
    """
    from pymonet.either import Left

    validation = Validation.fail(['aa.bb', 'cc.bb'])
    assert validation.is_fail() == True

    validation = Validation.fail()
    assert validation.is_fail() == False

    validation = Validation.success(Left(['aa.bb', 'cc.bb']))
    try:
        validation.is_fail()
        assert False
    except:
        assert True


# Generated at 2022-06-24 00:48:39.295190
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2]).to_box() == Box(None)



# Generated at 2022-06-24 00:48:49.066559
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Testing for method bind of class Validation.
    """
    from pymonet.either import Left, Right

    def monad_function(x):
        return Right(3 * x)

    success_validation = Validation.success(2)
    failed_validation = Validation.fail(['failed validation'])

    assert success_validation.bind(monad_function) == Right(6)
    assert failed_validation.bind(monad_function) == Left(['failed validation'])



# Generated at 2022-06-24 00:48:50.292256
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)


# Generated at 2022-06-24 00:48:57.446546
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation

    :return: None
    :rtype: NoneType
    """

    # Test for successful validation
    value = 10
    validation = Validation.success(value)
    assert validation.to_box() == Box(value)

    # Test for failed validation
    validation = Validation.fail(value)
    assert validation.to_box() == Box(None)



# Generated at 2022-06-24 00:49:02.203217
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success(123).to_lazy() == Lazy(lambda: 123)


# Generated at 2022-06-24 00:49:09.419763
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    def _test(value, errors, expected):
        result = Validation(value, errors).to_either()
        assert result == expected

    _test(None, [], Left([]))
    _test(10, [], Right(10))
    _test(10, [1, 2], Left([1, 2]))


# Generated at 2022-06-24 00:49:11.438592
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:49:16.211586
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert(str(Validation.success()) == 'Validation.success[None]')
    assert(str(Validation.success(2)) == 'Validation.success[2]')
    assert(str(Validation.fail([1])) == 'Validation.fail[None, [1]]')
    assert(str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]')



# Generated at 2022-06-24 00:49:18.400037
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(5, []).to_box() == Box(5)
    assert Validation(None, [1]).to_box() == Box(None)


# Generated at 2022-06-24 00:49:24.361572
# Unit test for method ap of class Validation
def test_Validation_ap():
    Validation.success(1).ap(Validation.success(lambda x: x * 3)) == Validation.success(3)
    Validation.success(1).ap(Validation.fail(['error'])) == Validation.fail(['error'])
    Validation.fail(['error']).ap(Validation.success(lambda x: x * 3)) == Validation.fail(['error'])
    Validation.fail(['error 1']).ap(Validation.fail(['error 2'])) == Validation.fail(['error 1', 'error 2'])


if __name__ == '__main__':
    print('Validation.success().is_success()')
    print(Validation.success().is_success())
    print('Validation.fail().is_success()')

# Generated at 2022-06-24 00:49:29.256413
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right

    def fn(x):
        if x < 0:
            return Left("x is less than 0")
        return Right(x)

    r1 = Validation.success(3).ap(fn)
    assert r1.value == 3
    assert r1.is_success()

    r2 = Validation.success(-1).ap(fn)
    assert r2.value == None
    assert r2.is_fail()
    assert r2.errors == ['x is less than 0']


# Generated at 2022-06-24 00:49:34.468821
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    value = 'value'
    errors = 'error'
    assert str(Validation.success(value)) == 'Validation.success[{}]'.format(value)
    assert str(Validation.fail(errors)) == 'Validation.fail[None, {}]'.format(errors)


# Generated at 2022-06-24 00:49:38.284118
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box
    assert Validation(1, []).to_box() == Box(1)
    assert Validation(1, [1]).to_box() == Box(1)


# Generated at 2022-06-24 00:49:43.743161
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():

    success_a = Validation.success(1)
    success_b = Validation.success(1)

    assert success_a == success_b

    fail_a = Validation.fail(['a'])
    fail_b = Validation.fail(['a'])

    assert fail_a == fail_b

    success = Validation.success(1)
    fail = Validation.fail(['a'])

    assert success != fail


# Generated at 2022-06-24 00:49:46.838401
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail().to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:49:55.202630
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import either

    assert(either(
        lambda x: 'Left: ' + ', '.join(x),
        lambda x: 'Right: ' + str(x),
        Validation.fail(['error1', 'error2']).to_either()
    ) == 'Left: error1, error2')

    assert(either(
        lambda x: 'Left: ' + ', '.join(x),
        lambda x: 'Right: ' + str(x),
        Validation.success(42).to_either()
    ) == 'Right: 42')


# Generated at 2022-06-24 00:50:01.146139
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(lambda x: x + 1).ap(Validation.success(1)) == Validation.success(2)
    assert Validation.success(lambda x: x + 2).ap(Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.fail(['error']).ap(Validation.success(lambda x: x + 1)) == Validation.fail(['error'])


# Generated at 2022-06-24 00:50:05.471751
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    def test_success_to_either():
        assert Validation.success('hello').to_either() == Right('hello')

    def test_fail_to_either():
        assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])

    test_success_to_either()
    test_fail_to_either()


# Generated at 2022-06-24 00:50:08.925798
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Validation.to_lazy() unittest.
    """
    assert Validation.success(23).to_lazy() == Lazy(lambda: 23)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:50:12.366677
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(1, []).is_fail() == False
    assert Validation(1, [1]).is_fail() == True


# Generated at 2022-06-24 00:50:20.236753
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    Validation.success(1).to_lazy() == Lazy(lambda: 1)
    Validation.success(1).to_lazy().force() == 1
    Validation.success(1).to_lazy().force_unsafe() == 1
    Validation.fail('fail').to_lazy() == Lazy(lambda: None)
    Validation.fail('fail').to_lazy().force() == None
    Validation.fail('fail').to_lazy().force_unsafe() == None


# Generated at 2022-06-24 00:50:25.660754
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # Given
    validation = Validation.success('John Doe')
    expected = Lazy(lambda: 'John Doe')

    # When
    result = validation.to_lazy()

    # Then
    assert expected == result


# Generated at 2022-06-24 00:50:28.789191
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(42).to_either() == Right(42)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:50:34.577667
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test for method to_box of class Validation
    """
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-24 00:50:41.354389
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.try_ import Try
    from pymonet.either import Right, Left
    from pymonet.maybe import Nothing, Just
    from pymonet.monad_try import Option
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    # When empty errors
    assert(Validation.success() == Validation.success().to_maybe().to_validation())
    assert(Validation.fail() == Validation.fail().to_maybe().to_validation())
    assert(Validation.success(1) == Validation.success(1).to_maybe().to_validation())
    assert(Validation.fail([1]) == Validation.fail([1]).to_maybe().to_validation())

    # When value is None

# Generated at 2022-06-24 00:50:45.136182
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    assert Validation.success('test').to_either() == Right('test')
    assert Validation.fail(['test']).to_either() == Left(['test'])


# Generated at 2022-06-24 00:50:50.714767
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.success(1).map(lambda x: x + 1).value == 2
    assert Validation.success(1).map(lambda x: x + 1).errors == []
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation(None, ['error'])
    assert Validation.fail(['error']).map(lambda x: x + 1).value is None
    assert Validation.fail(['error']).map(lambda x: x + 1).errors == ['error']


# Generated at 2022-06-24 00:50:54.475800
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['Error']).to_either() == Left(['Error'])


# Generated at 2022-06-24 00:50:58.833218
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation.fail(['Error 1', 'Error 2']).to_box()
    assert isinstance(validation, Box)
    try:
        validation.get()
    except IndexError:
        pass
    else:
        fail("fail should raise IndexError")

# Generated at 2022-06-24 00:51:09.020869
# Unit test for method map of class Validation
def test_Validation_map():
    f = lambda x: x
    g = lambda x: x + 1
    h = lambda x: x + 2

    me = Validation.success(1)
    mo = Validation.fail(['error'])

    def add(x, y): return x + y

    def sub(x, y): return x - y

    add_fn = lambda x: x + 1
    sub_fn = lambda x: x - 1

    # Identity: map(x -> x) == x
    assert Validation.success(1).map(f) == Validation.success(1)
    assert Validation.fail(['error']).map(f) == Validation.fail(['error'])

    # Composition: map(x -> g(f(x))) == map(g) . map(f)

# Generated at 2022-06-24 00:51:14.814095
# Unit test for method ap of class Validation
def test_Validation_ap():
    def unit(x):
        def unit_body(v):
            return Validation.success(v)

        return unit_body(x)

    assert Validation.success(2).ap(unit(10)) == Validation(10, [])
    assert Validation.fail(['10']).ap(unit(13)) == Validation(13, ['10'])


# Generated at 2022-06-24 00:51:19.845144
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation.
    """
    assert Validation.success().is_fail() == False
    assert Validation.fail().is_fail() == True


# Generated at 2022-06-24 00:51:25.791790
# Unit test for constructor of class Validation
def test_Validation():
    errors1 = ['error1', 'error2', 'error3']
    errors2 = ['error4', 'error5', 'error6']
    errors_merge = ['error1', 'error2', 'error3', 'error4', 'error5', 'error6']
    value1 = 'value1'
    value2 = 'value2'
    value3 = 'value3'
    fn = lambda v: Validation(value2, errors2)
    fn2 = lambda v: Validation(value3, errors_merge)
    validation_success = Validation(value1, [])
    validation_fail = Validation(value1, errors1)
    validation_success2 = Validation(value2, errors2)
    validation_success_merge_errors = Validation(value3, errors_merge)


# Generated at 2022-06-24 00:51:30.087218
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    value = 'value'
    assert Validation.success(value).to_maybe() == Maybe.just(value)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:51:36.571261
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Unit test for method to_maybe of class Validation"""
    from pymonet.maybe import Maybe

    success = Validation.success(1)
    assert success.to_maybe() == Maybe.just(1)
    assert success.to_maybe().is_just() is True

    fail = Validation.fail([])
    assert fail.to_maybe() == Maybe.nothing()
    assert fail.to_maybe().is_nothing() is True


# Generated at 2022-06-24 00:51:42.901755
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success(1).is_success() == True
    assert Validation.success(2).is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail([1]).is_success() == False
    assert Validation.fail([1, 2, 3]).is_success() == False


# Generated at 2022-06-24 00:51:44.972534
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation
    from pymonet.box import Box

    assert Validation.success(Box(1)).to_try() == Try(Box(1))
    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:51:51.335785
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    success_validation = Validation.success()
    failure_validation = Validation.fail()
    assert success_validation.to_try() == Try(None, is_success=True)
    assert failure_validation.to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:52:00.872414
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.validation import Validation

    assert Validation.success().is_success() == True
    assert Validation.success('foo').is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail(['foo']).is_success() == False
    assert Validation.success().is_fail() == False
    assert Validation.success('foo').is_fail() == False
    assert Validation.fail().is_fail() == True
    assert Validation.fail(['foo']).is_fail() == True
    assert Validation.fail(['foo', 'bar']).is_fail() == True


# Generated at 2022-06-24 00:52:04.747355
# Unit test for method map of class Validation
def test_Validation_map():
    """Test map"""

    assert Validation.success(2).map(lambda value: value + 1) == Validation.success(3)
    assert Validation.success().map(lambda value: value + 1) == Validation.success()
    assert Validation.fail(['error']).map(lambda value: value + 1) == Validation.fail(['error'])


# Generated at 2022-06-24 00:52:06.894234
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success('test').to_either() == Right('test')
    assert Validation.fail(['first', 'second']).to_either() == Left(['first', 'second'])


# Generated at 2022-06-24 00:52:09.461162
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])



# Generated at 2022-06-24 00:52:12.445626
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    FunctionUnit test for method to_lazy of class Validation
    """
    from pymonet.monad_try import Try

    assert Validation.success('test').to_lazy().eval() == 'test'
    assert Validation.fail(['test']).to_lazy().eval() == None


# Generated at 2022-06-24 00:52:16.784357
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:52:20.010172
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail() is True
    assert Validation.fail().is_fail() is True
    assert Validation.success(1).is_fail() is False


# Generated at 2022-06-24 00:52:24.069290
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])


# Generated at 2022-06-24 00:52:31.952675
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(42) == Validation.success(42)
    assert Validation.success(42) == Validation.success(42)
    assert Validation.fail([42]) == Validation.fail([42])
    assert not Validation.fail([42]) == Validation.fail([42, 43])
    assert not Validation.fail([42]) == Validation.fail()
    assert not Validation.success(42) == Validation.success(43)
    assert not Validation.success(42) == Validation.fail()
    assert not Validation.success(42) == Validation.fail([42])



# Generated at 2022-06-24 00:52:41.274549
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert(Validation(1, []) == Validation(1, []))
    assert(Validation(2, []) != Validation(1, []))
    assert(Validation(1, [1]) == Validation(1, [1]))
    assert(Validation(1, [1, 2]) == Validation(1, [1, 2]))
    assert(Validation(1, [1, 2]) != Validation(1, [2, 1]))
    assert(Validation(1, [1, 2]) != Validation(1, [1, 2, 3]))
    assert(Validation(1, [1, 2]) != Validation(1, []))
    assert(Validation(1, []) != Validation(1, [1, 2]))


# Generated at 2022-06-24 00:52:49.196451
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(value=1) == Validation.success(value=1)
    assert Validation.fail(errors=[1]) == Validation.fail(errors=[1])

    assert Validation.success(value=1) != Validation.success(value=2)
    assert Validation.fail(errors=[1, 2]) != Validation.fail(errors=[2, 3])

    assert Validation.success(value=1) != Validation.fail([1])


# Generated at 2022-06-24 00:52:51.220853
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation.fail(['error 1', 'error 2'])
    assert str(validation) == 'Validation.fail[None, [\'error 1\', \'error 2\']]'
    validation = Validation.success('value')
    assert str(validation) == 'Validation.success[value]'


# Generated at 2022-06-24 00:52:55.930465
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert(Validation.fail().to_either() == Left([]))
    assert(Validation.fail(['error 1']).to_either() == Left(['error 1']))
    assert(Validation.success(1).to_either() == Right(1))


# Generated at 2022-06-24 00:53:04.251911
# Unit test for method map of class Validation
def test_Validation_map():
    v1 = Validation.success('a')
    assert v1.map(lambda x: x.upper()).value == 'A'

    v2 = Validation.success('b')
    assert v2.map(lambda x: x+'a').value == 'ba'

    v3 = Validation.fail(['c', 'd'])
    assert v3.map(lambda x: x+'a').value == None
    assert v3.map(lambda x: x+'a').errors == ['c', 'd']


# Generated at 2022-06-24 00:53:08.625216
# Unit test for method ap of class Validation
def test_Validation_ap():
    def f(n):
        if n < 0:
            return Validation.fail(['n is less than zero'])
        return Validation.success(n + 1)

    assert Validation.success(1).ap(f) == Validation.success(1)
    assert Validation.success(-1).ap(f) == Validation.fail(['n is less than zero'])


# Generated at 2022-06-24 00:53:17.248602
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.list import List

    assert Validation.success(1).bind(lambda x: Validation.fail([2, 3])) == Validation(None, [2, 3])
    assert Validation.success([1, 2, 3]).bind(List.wrap) == List.wrap([1, 2, 3])
    assert Validation.success([1, 2, 3]).bind(List.fail) == Validation(None, [1, 2, 3])



# Generated at 2022-06-24 00:53:19.211480
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test for method map when errors list is empty.
    """
    assert Validation.success(value=1).map(lambda x: x + 1) == Validation(2, [])


# Generated at 2022-06-24 00:53:30.157199
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    pytest for method ap of class Validation.
    """
    def concat_errors(a):
        """
        Function that returns Validation with collected errors from passed argument.

        :param a: value to check for errors
        :type a: Any
        :returns: Validation with value and copied errors
        :rtype: Validation[Any, List[Any]]
        """
        errors = a.errors
        return Validation(a.value, errors)

    assert Validation.success('string').ap(concat_errors) == Validation.success('string')
    assert Validation.fail(['error1']).ap(concat_errors) == Validation.fail(['error1'])
    assert Validation.success('string').ap(concat_errors) != Validation.fail([])
    assert Validation.success

# Generated at 2022-06-24 00:53:34.352152
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    result1 = str(Validation.fail(['Err1', 'Err2']))
    result2 = str(Validation.fail([]))
    result3 = str(Validation.success('Hey'))
    result4 = str(Validation.success())

    assert result1 == 'Validation.fail[None, [\'Err1\', \'Err2\']]'
    assert result2 == 'Validation.fail[None, []]'
    assert result3 == 'Validation.success[Hey]'
    assert result4 == 'Validation.success[None]'


# Generated at 2022-06-24 00:53:39.907837
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation.success(0).to_box() == Box(0)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:46.164422
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success('123').map(lambda x: len(x)) == Validation(3, [])
    assert Validation.success(True).map(lambda x: x) == Validation(True, [])
    assert Validation.success([1, 2, 3]).map(lambda x: len(x)) == Validation.success(3)
    assert Validation.fail([ValueError('exception')]).map(lambda x: len(x)) == Validation.fail([ValueError('exception')])
    assert Validation.fail([ValueError('exception')]).map(lambda x: x) == Validation.fail([ValueError('exception')])


# Generated at 2022-06-24 00:53:49.631943
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation

    assert Validation.success(2).bind(lambda x: Validation.success(x * 2)) == Validation.success(4)
    assert Validation.success(2).bind(lambda x: Validation.fail(['ERROR'])) == Validation.fail(['ERROR'])
    assert Validation.fail(['ERROR']).bind(lambda x: Validation.success(x * 2)) == Validation.fail(['ERROR'])
    assert Validation.fail(['ERROR']).bind(lambda x: Validation.fail(['ERROR'])) == Validation.fail(['ERROR'])

# Generated at 2022-06-24 00:53:59.906867
# Unit test for method ap of class Validation
def test_Validation_ap():
    valid_fail = Validation(None, ['1'])
    valid_success = Validation(1, [])
    fn = lambda x: Validation(None, [])
    expected = Validation(None, ['1'])
    assert valid_fail.ap(fn) == expected

    fn = lambda x: Validation(None, ['2'])
    expected = Validation(None, ['1', '2'])
    assert valid_fail.ap(fn) == expected

    valid_fail = Validation(1, ['1'])
    fn = lambda x: Validation(x, [])
    expected = Validation(1, ['1'])
    assert valid_fail.ap(fn) == expected

    valid_success = Validation(2, [])
    fn = lambda x: Validation(x + 1, [])
    expected

# Generated at 2022-06-24 00:54:05.358797
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation

    It asserts:
        - String representation for successful Validation
        - String representation for unsucceful Validation

    :return: Nothing
    """
    assert 'Validation.success[None]' == str(Validation.success())
    assert 'Validation.fail[None, []]' == str(Validation.fail())


# Generated at 2022-06-24 00:54:10.207426
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1) \
        .ap(lambda x: Validation.success(2)) \
        == Validation.success(1)
    assert Validation.success(1) \
        .ap(lambda x: Validation.fail()) \
        == Validation.fail()
    assert Validation.fail() \
        .ap(lambda x: Validation.success(2)) \
        == Validation.fail()
    assert Validation.fail() \
        .ap(lambda x: Validation.fail()) \
        == Validation.fail()
