

# Generated at 2022-06-24 00:44:14.605110
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.success('Test').is_fail()


# Generated at 2022-06-24 00:44:19.735246
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    assert Validation.success(5).is_success()
    assert not Validation.success(5).is_fail()
    assert not Validation.fail().is_success()
    assert Validation.fail().is_fail()
    #assert not Validation.fail(5).is_success()
    #assert Validation.fail(5).is_fail()


# Generated at 2022-06-24 00:44:24.259696
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(value=1).to_box().value == 1
    assert Validation.fail(errors=[1, 2]).to_box().value == None



# Generated at 2022-06-24 00:44:30.557914
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.monad_dict import monad_dict
    from pymonet.maybe import Maybe
    from pymonet.functor_dict import functor_dict
    from pymonet.applicative_dict import applicative_dict
    from pymonet.monad_dict import monad_dict

    assert monad_dict['Validation'] == Validation
    assert functor_dict[Validation] == Validation.map
    assert applicative_dict[Validation] == Validation.ap
    assert monad_dict[Validation] == Validation.bind

    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail([1, 2]) == Validation(None, [1, 2])

# Generated at 2022-06-24 00:44:37.076526
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    # test for success validation
    valid1 = Validation.success(42)
    valid1_binded = valid1.bind(lambda x: Left([x]))
    assert valid1_binded == Left([42])
    valid1_binded = valid1.bind(lambda x: Maybe.just(x))
    assert valid1_binded == Maybe.just(42)
    valid1_binded = valid1.bind(lambda x: Validation.success(x))
    assert valid1_binded == Validation.success(42)

    # test for fail validation
    valid2 = Validation.fail(['error1', 'error2'])
    valid2_binded = valid2.bind(lambda x: Left([x]))
    assert valid

# Generated at 2022-06-24 00:44:46.917111
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.validation import Validation

    assert Validation.success('test').map(lambda x: x.upper()) == Validation.success('TEST')
    assert Validation.success(2).map(lambda x: x * 3) == Validation.success(6)
    assert Validation.success(5).map(lambda x: x + 1).map(lambda x: x * x) == Validation.success(36)
    assert Validation.fail(['test1']).map(lambda x: x.upper()) == Validation.fail(['test1'])
    assert Validation.fail(['test1']).map(lambda x: x * 3) == Validation.fail(['test1'])
    assert Validation.fail(['test1']).map(lambda x: x + 1).map(lambda x: x * x)

# Generated at 2022-06-24 00:44:54.037706
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail([1, 2]) == Validation(None, [1, 2])

    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(None) == Validation(None, [])
    assert Validation.success(None) != Validation(None, [1])


# Generated at 2022-06-24 00:45:04.188393
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test for method bind of class Validation.
    """
    from pymonet.either import Left
    from pymonet.monad_try import Try
    from pymonet.result import Result
    from pymonet.reader import Reader

    # Test with other monads
    assert Validation.success('success').bind(lambda value: Reader(lambda: value)).run_reader == 'success'
    assert Validation.success('success').bind(lambda value: Try(value)).is_success()
    assert Validation.success('success').bind(lambda value: Result(value)).is_success()
    assert Validation.success('success').bind(lambda value: Left('fail')).is_left()

    # Test with not Validation monad
    assert Validation.success('success').bind(lambda value: value) == 'success'

# Generated at 2022-06-24 00:45:07.037575
# Unit test for method map of class Validation
def test_Validation_map():
    """
    :returns: Nothing
    :rtype: None
    """
    assert Validation.success(1).map(lambda v: v + 2) == Validation.success(3)
    assert Validation.fail(errors=[1, 2]).map(lambda v: v + 2) == Validation.fail(errors=[1, 2])


# Generated at 2022-06-24 00:45:10.269790
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    assert Validation.fail() == Validation.fail()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail([1, 2]) != Validation.fail([1])


# Generated at 2022-06-24 00:45:12.384294
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(10, []).to_lazy() == Lazy(lambda: 10)
    assert Validation(10, ['error']).to_lazy() == Lazy(lambda: 10)

# Generated at 2022-06-24 00:45:15.371507
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    validation = Validation.fail(['one'])
    try_ = validation.to_try()
    assert try_.is_success() is False

    validation = Validation.success(1)
    try_ = validation.to_try()
    assert try_.is_success() is True



# Generated at 2022-06-24 00:45:22.340785
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    # Test for successful Try with value
    assert Validation.success(Try.success('A')).to_box() == Box(Try.success('A'))

    # Test for failed Try with value
    assert Validation.success(Try.failed(Exception)).to_box() == Box(Try.failed(Exception))

    # Test for successful Try with exception
    assert Validation.success(Try.failed('A')).to_box() == Box(Try.failed('A'))

    # Test for failed Try with exception
    assert Validation.success(Try.success(Exception)).to_box() == Box(Try.success(Exception))


# Generated at 2022-06-24 00:45:26.929530
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    success_validation = Validation.success(2)
    assert success_validation.to_box() == Box(2)
    fail_validation = Validation.fail(['error 1', 'error 2'])
    assert fail_validation.to_box() == Box(None)


# Generated at 2022-06-24 00:45:33.064589
# Unit test for method map of class Validation
def test_Validation_map():  # pragma: no cover
    assert Validation.success(1).map(lambda a: a + 1) == Validation.success(2)
    assert Validation.fail(['error while parsing']).map(lambda a: a + 1) == Validation.fail(['error while parsing'])


# Generated at 2022-06-24 00:45:39.318199
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(1).bind(lambda x: Validation.success(x+1)) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail([1])) == Validation.fail([1])
    assert Validation.fail([1]).bind(lambda x: Validation.success(1)) == Validation.fail([1])
    assert Validation.fail([1]).bind(lambda x: Validation.fail([2])) == Validation.fail([1, 2])


# Generated at 2022-06-24 00:45:46.415815
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Either

    assert Validation.success(Maybe.just(10)).to_maybe() == Maybe.just(Maybe.just(10))
    assert Validation.success(Maybe.nothing()).to_maybe() == Maybe.just(Maybe.nothing())
    assert Validation.success(10).to_maybe() == Maybe.just(10)
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:53.179631
# Unit test for method bind of class Validation
def test_Validation_bind():
    valid_to_int = Validation.success(10)
    invalid_to_int = Validation.fail(['Invalid integer'])

    def not_int(value):
        return int(value)

    result = invalid_to_int.bind(not_int)

    assert(result == Validation.fail(['Invalid integer']))
    assert(result.value == None)

    result = valid_to_int.bind(not_int)

    assert(result == Validation.success(10))
    assert(result.value == 10)


# Generated at 2022-06-24 00:45:57.886491
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test for method to_either of class Validation
    """
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:46:04.015528
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1]) != Validation.success(1)
    assert Validation.success(1) != Validation.fail([1])


# Generated at 2022-06-24 00:46:08.233339
# Unit test for method map of class Validation
def test_Validation_map():
    def mapper(x):
        return x * 2

    assert Validation.success(1).map(mapper) == Validation(2, [])
    assert Validation.fail(['error']).map(mapper) == Validation(None, ['error'])


# Generated at 2022-06-24 00:46:16.298155
# Unit test for method ap of class Validation
def test_Validation_ap():
    from unittest import TestCase, main

    class TestValidationAp(TestCase):
        def test_ap_function_returning_success_Validation(self):
            validation = Validation.success('any')

            self.assertEqual(validation.ap(lambda _: Validation.fail()), validation)


        def test_ap_function_returning_fail_Validation(self):
            validation = Validation.success('any')

            self.assertEqual(validation.ap(lambda _: Validation.fail(['errors'])), Validation('any', ['errors']))

    main()



# Generated at 2022-06-24 00:46:24.512368
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """It should compare two Validations"""
    # Given
    val1 = Validation.success(1)
    val2 = Validation.success(1)
    val3 = Validation.success(2)
    val4 = Validation.fail([1])
    val5 = Validation.fail([1])
    val6 = Validation.fail([2])

    # Then
    assert val1 == val2
    assert val4 == val5
    assert val1 != val3
    assert val1 != val4
    assert val4 != val6


# Generated at 2022-06-24 00:46:28.674430
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x * 2) == Validation.success(2)
    assert Validation.fail([]).map(lambda x: x * 2) == Validation.fail([])

    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1, 2]).map(lambda x: x + 1) == Validation.fail([1, 2])


# Generated at 2022-06-24 00:46:31.992249
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    v1 = Validation('lorem', ['error 1'])
    assert v1.to_either() == Left(['error 1'])
    assert (v1.to_either()) == Left(['error 1'])
    v2 = Validation('ipsum')
    assert v2.to_either() == Right('ipsum')


# Generated at 2022-06-24 00:46:40.870068
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    lazy = Validation.success(100).to_lazy()

    assert lazy.value() == 100
    assert lazy.value() == 100
    assert lazy.value() == 100
    assert lazy.value() == 100
    assert lazy.value() == 100

    assert lazy == Validation.success(100).to_lazy()
    assert lazy != Validation.success(200).to_lazy()
    assert lazy != Validation.fail().to_lazy()



# Generated at 2022-06-24 00:46:43.189594
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    success_validation = Validation.success(1)
    fail_validation = Validation.fail(['error'])
    assert success_validation != fail_validation


# Generated at 2022-06-24 00:46:46.254236
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert (Validation.success(10).to_either() ==
            Right(10))
    assert (Validation.fail([1, 'string']).to_either() ==
            Left([1, 'string']))


# Generated at 2022-06-24 00:46:51.501572
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success(123)) == "Validation.success[123]"
    assert str(Validation.fail(["error"])) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-24 00:47:02.538646
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([2]).to_either() == Left([2])

    assert Validation.success(1).to_either() != Right(2)
    assert Validation.fail([2]).to_either() != Left([1])

    assert Validation.success(1).to_either() != Left(1)
    assert Validation.fail([2]).to_either() != Right([2])

    assert Validation.success(1).to_either() != Left(2)

# Generated at 2022-06-24 00:47:05.372797
# Unit test for method map of class Validation
def test_Validation_map():
    assert (Validation.success(1).map(lambda v: v + 1) == Validation.success(2))
    assert (Validation.fail(['error1']).map(lambda v: v + 1) == Validation.fail(['error1']))


# Generated at 2022-06-24 00:47:11.671021
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Success case
    v = Validation.success(1).bind(lambda v: Validation.success(v * 3))
    assert v == Validation.success(3)
    # Fail case
    v = Validation.success(1).bind(lambda v: Validation.fail(v * 3))
    assert v == Validation.fail(3)
    # Success case
    v = Validation.fail(1).bind(lambda v: Validation.success(v * 3))
    assert v == Validation.fail(1)


# Generated at 2022-06-24 00:47:20.615838
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe

    fn_ok = lambda x: x + 1

    Validation.success(5).bind(fn_ok) == Validation.success(6)
    Validation.fail(['a']).bind(fn_ok) == Validation.fail(['a'])
    Validation.fail(['a']).bind(lambda x: Validation.success(10)) == Validation.fail(['a'])
    Validation.fail(['a']).bind(lambda x: Validation.fail(['b'])) == Validation.fail(['a', 'b'])

# Generated at 2022-06-24 00:47:27.651574
# Unit test for method map of class Validation
def test_Validation_map():
    # Arrange
    succ = Validation.success(5)
    fail = Validation.fail(['errors'])

    # Action
    succ = succ.map(lambda x: x + 1)
    fail = fail.map(lambda x: x + 1)

    # Assertion
    assert succ == Validation.success(6)
    assert fail == Validation.fail(['errors'])

# Generated at 2022-06-24 00:47:34.350574
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(42).map(lambda v: v * 2) == Validation.success(84)
    assert Validation.fail(['error']).map(lambda v: v * 2) \
        == Validation.fail(['error'])


# Generated at 2022-06-24 00:47:44.960866
# Unit test for method ap of class Validation
def test_Validation_ap():
    """:see: Validation.ap"""
    from pymonet.either import Either

    def body():
        def fn1(value):
            return Either.success(value)

        def fn2(value):
            return Either.fail([value])

        def fn3(value):
            return Either.fail([2 * value])

        def fn4(value):
            return Either.fail([3 * value])

        assert Validation.success(1).ap(fn1) == Validation.success(1)
        assert Validation.success(1).ap(fn2) == Validation.fail([1])
        assert Validation.success(1).ap(fn3) == Validation.fail([2])
        assert Validation.success(1).ap(fn4) == Validation.fail([3])

# Generated at 2022-06-24 00:47:47.206680
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation.success(5)
    assert(validation == Validation(5, []))
    assert(validation.value == 5)
    assert(validation.errors == [])


# Generated at 2022-06-24 00:47:54.541690
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success('foo').to_try() == Try('foo')
    assert Validation.fail(['err']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:47:59.086497
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test Validation.to_maybe.

    :return: nothing, test is passed
    :rtype: None
    """
    assert Validation.success(1).to_maybe() == Just(1)

    assert Validation.success('abc').to_maybe() == Just('abc')

    assert type(Validation.fail(['error']).to_maybe()) == Nothing


# Generated at 2022-06-24 00:48:01.432377
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success([])) == 'Validation.success[[]]'
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.success([])) == 'Validation.success[[]]'
    assert str(Validation.fail(10)) == 'Validation.fail[None, 10]'


# Generated at 2022-06-24 00:48:07.028936
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation(2, []).to_box() == Box(2)
    assert Validation(Lazy(lambda: 2), []).to_box() == Box(Lazy(lambda: 2))



# Generated at 2022-06-24 00:48:14.737871
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation(Box(10), [])
    actual_result = validation.to_box()
    expected_result = Box(Box(10))
    assert actual_result == expected_result
    assert actual_result.value == Box(10)

    validation = Validation(Box(10), ['error'])
    actual_result = validation.to_box()
    expected_result = Box(Box(10))
    assert actual_result == expected_result
    assert actual_result.value == Box(10)



# Generated at 2022-06-24 00:48:20.945789
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(3)) == 'Validation.success[3]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['Error1', 'Error2'])) == 'Validation.fail[None, [\'Error1\', \'Error2\']]'


# Generated at 2022-06-24 00:48:31.576470
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.task import Task

    def identity(x): # -> Task
        return Task.of(lambda: x)

    success_task = identity(123) # -> Task
    failure_task = Task.of(lambda: Validation.fail(['error'])) # -> Task

    def invalid_task(x): # -> Task
        return Task.of(lambda: Validation.fail(['error'])) # -> Task

    assert success_task.ap(identity(123)) == Task.of(lambda: Validation.success(246))
    assert invalid_task(123).ap(identity(123)) == Task.of(lambda: Validation.fail(['error']))
    assert success_task.ap(invalid_task(123)) == Task.of(lambda: Validation.fail(['error']))

# Generated at 2022-06-24 00:48:39.018876
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(None, []).__eq__(Validation(None, []))
    assert not Validation(None, []).__eq__(Validation(None, [1]))
    assert not Validation(None, [1]).__eq__(Validation(None, []))
    assert not Validation(1, []).__eq__(Validation(None, []))
    assert not Validation(1, []).__eq__(Validation(None, []))
    assert not Validation(1, []).__eq__(None)
    assert not Validation(1, []).__eq__(1)


# Generated at 2022-06-24 00:48:42.955615
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test to_try method of class Validation
    """
    from pymonet.monad_try import Try

    assert Validation(None, [1, 2, 3]).to_try() == Try(None, False)
    assert Validation(1, []).to_try() == Try(1, True)


# Generated at 2022-06-24 00:48:51.197081
# Unit test for constructor of class Validation
def test_Validation():
    from collections import Counter

    a_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    # a_list = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10]
    # a_list = []

    def avg(a_list):
        """Returns avg of numbers in list"""
        return sum(a_list) / len(a_list) if len(a_list) > 0 else None

    def is_empty(a_list):
        """Returns None when list is empty"""
        return Validation.fail(['List is empty']) if len(a_list) == 0 else Validation.success(a_list)

    def has_doubles(a_list):
        """Returns None when list has doubles"""
       

# Generated at 2022-06-24 00:48:54.772559
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    with it('returns True when errors list are empty'):
        expect(Validation.fail().is_fail()).to(be_true)

    with it('returns False otherwise'):
        expect(Validation.fail(errors=[1]).is_fail()).to(be_true)


# Generated at 2022-06-24 00:48:57.619696
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1, 2]) == Validation(None, [1, 2])


# Generated at 2022-06-24 00:49:04.660151
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation('foo', []).bind(lambda x: Validation('bar', [])) == Validation('bar', [])
    assert Validation(None, ['error']).bind(lambda x: Validation('bar', [])) == Validation('bar', [])
    assert Validation('foo', ['error']).bind(lambda x: Validation('bar', ['error'])) == \
           Validation('bar', ['error', 'error'])


# Generated at 2022-06-24 00:49:07.161097
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(Box(1)).to_box() == Box(Box(1))
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-24 00:49:12.584219
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def _lazy_return_3():
        return 3
    lazy = _lazy_return_3
    expected_result = Validation.success(3)
    result = expected_result.to_lazy().evaluate()

    assert result == expected_result


# Generated at 2022-06-24 00:49:15.243639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert(Validation.success(Box.just(4)).to_lazy().value() == Box.just(4))
    assert(Validation.success(None).to_lazy().value() is None)
    assert(Validation.success(Maybe.just(4)).to_lazy().value() == Maybe.just(4))

# Generated at 2022-06-24 00:49:17.504719
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(3).map(lambda v: v + 1) == Validation.success(4)
    assert Validation.success(3).map(lambda v: v + 1).value == 4


# Generated at 2022-06-24 00:49:28.284037
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """Unit test for method __eq__ of class Validation"""
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation(None, []) == Validation.success()
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, []) != Validation.success(1)
    assert Validation(None, []) != Validation.fail(['Error'])

    assert Validation(1, []) == Validation.success(1)
    assert Validation(1, []) != Validation.fail(['Error'])

    assert Validation(None, ['Error']) == Validation.fail(['Error'])
    assert Validation(None, ['Error']) != Validation.success(1)


# Generated at 2022-06-24 00:49:36.837320
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])

    assert Validation.success(1).is_success()
    assert not Validation.success(1).is_fail()

    assert not Validation.fail([1]).is_success()
    assert Validation.fail([1]).is_fail()


# Generated at 2022-06-24 00:49:43.624488
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(1).bind(lambda x: Validation.success(x+1)).value == 2
    assert Validation.success(1).bind(lambda x: Validation.fail(['Should not be called'])).value == 1
    assert Validation.fail(['Should not be called']).bind(lambda x: Validation.fail(['Should not be called'])).value is None
    assert Validation.fail(['Should not be called']).bind(lambda x: Validation.success(1)).value is None


# Generated at 2022-06-24 00:49:46.749317
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.fail(errors=['error']).to_box() == Box(None)


# Generated at 2022-06-24 00:49:53.087530
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(2).ap(lambda x: Validation.fail(['a', 'b'])) == Validation.fail(['a', 'b'])
    assert Validation.fail(['a', 'b']).ap(lambda x: Validation.success(x + 1)) == Validation.fail(['a', 'b'])
    assert Validation.fail(['a', 'b']).ap(lambda x: Validation.fail(['c', 'd'])) == Validation.fail(['a', 'b', 'c', 'd'])


# Generated at 2022-06-24 00:50:02.751914
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation(None, [])
    validation2 = Validation(None, [])
    assert validation1 == validation1
    assert validation1 == validation2

    validation1 = Validation(None, [1])
    validation2 = Validation(None, [1])
    assert validation1 == validation1
    assert validation1 == validation2

    validation1 = Validation('some_value', [])
    validation2 = Validation('some_value', [])
    assert validation1 == validation1
    assert validation1 == validation2

    validation1 = Validation('some_value', [1])
    validation2 = Validation('some_value', [1])
    assert validation1 == validation1
    assert validation1 == validation2



# Generated at 2022-06-24 00:50:08.497971
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test_bind__Validation
    """
    assert Validation.success(1).bind(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail(['foo'])) == Validation.fail(['foo'])
    assert Validation.fail(['foo']).bind(lambda x: Validation.success(x + 1)) == Validation.fail(['foo'])
    assert Validation.fail(['foo']).bind(lambda x: Validation.fail(['bar'])) == Validation.fail(['foo', 'bar'])

# Generated at 2022-06-24 00:50:12.312669
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    v = Validation.success(Box(2))
    assert Box(Box(2)) == v.to_box()



# Generated at 2022-06-24 00:50:22.396171
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda _: None) == Validation.success(None)
    assert Validation.success(1).map(lambda _: True) == Validation.success(True)
    assert Validation.success(1).map(lambda _: False) == Validation.success(False)
    assert Validation.success(1).map(lambda _: Validation.success(1)) == Validation.success(Validation.success(1))
    assert Validation.success(1).map(lambda _: Validation.fail([1])) == Validation.fail([1])
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])

# Generated at 2022-06-24 00:50:32.801816
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    from pymonet.either import Left, Right

    def _throw(x):
        raise Exception("Test throw Exception")

    def _right(x):
        return Right(x)

    def _left(x):
        return Left(x)

    def _validation(x):
        return Validation.success(x)

    assert Validation.success("Hello").bind(_throw) == Validation.fail("Hello")
    assert Validation.success("Hello").bind(_validation) == Validation.success("Hello")
    assert Validation.success("Hello").bind(_right) == Validation.success("Hello")
    assert Validation.success("Hello").bind(_left) == Validation.fail("Hello")

    assert Validation.fail("Hello").bind(_throw) == Validation.fail("Hello")
    assert Val

# Generated at 2022-06-24 00:50:39.643119
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    from pymonet.lazy import Lazy
    from pymonet.maybe import Just
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.either import Right

    validation = Validation.fail(['Failed']).to_lazy()
    assert isinstance(validation, Lazy)
    assert validation.force() == None

    validation = Validation.success(['Success']).to_lazy()
    assert isinstance(validation, Lazy)
    assert validation.force() == ['Success']


# Generated at 2022-06-24 00:50:44.950107
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def mapper(v):
        return Try(lambda: v + 1)

    result = Validation.success(10).bind(mapper).to_maybe()
    assert(result == Maybe.just(11))


# Generated at 2022-06-24 00:50:48.649756
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail() == True
    assert Validation.fail([]).is_fail() == False
    assert Validation.success().is_fail() == False
    assert Validation.success(42).is_fail() == False


# Generated at 2022-06-24 00:50:59.834048
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation(4, []).bind(lambda x: Validation(x + 1, [])).value == 5
    assert Validation(4, []).bind(lambda x: Validation(x + 1, [])).is_success()
    assert Validation(4, []).bind(lambda x: Validation(x + 1, [])).errors == []
    assert Validation([4], []).bind(lambda x: Validation(x[0] + 1, [])).value == 5
    assert Validation([4], []).bind(lambda x: Validation(x[0] + 1, [])).is_success()
    assert Validation([4], []).bind(lambda x: Validation(x[0] + 1, [])).errors == []


# Generated at 2022-06-24 00:51:07.278274
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()
    assert not Validation.success(None).is_success()
    assert not Validation.success(123).is_success()
    assert Validation.success([]).is_success()
    assert Validation.success(['123']).is_success()
    assert not Validation.fail([]).is_success()
    assert not Validation.fail(['123']).is_success()


# Generated at 2022-06-24 00:51:11.039539
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():

    success = Validation.success(2)
    fail = Validation.fail(['error'])

    assert success == Validation.success(2)
    assert fail == Validation.fail(['error'])


# Generated at 2022-06-24 00:51:14.680633
# Unit test for method bind of class Validation
def test_Validation_bind():
    validation = Validation.fail(['error 1', 'error 2'])
    fn = lambda _: Validation.success('success')

    assert validation.bind(fn) == Validation.fail(['error 1', 'error 2'])


# Generated at 2022-06-24 00:51:21.138701
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert(Validation.success() == Validation.success())
    assert(Validation.success(42) == Validation.success(42))
    assert(Validation.fail([]) == Validation.fail([]))
    assert(Validation.fail([42]) == Validation.fail([42]))

    assert(Validation.success() != Validation.success(42))
    assert(Validation.success() != Validation.fail())
    assert(Validation.success(42) != Validation.fail())
    assert(Validation.fail() != Validation.fail([42]))


# Generated at 2022-06-24 00:51:24.846123
# Unit test for constructor of class Validation
def test_Validation():
    validation1 = Validation.success()
    assert validation1.value is None
    assert len(validation1.errors) == 0

    validation2 = Validation.success(18)
    assert validation2.value == 18
    assert len(validation2.errors) == 0

    validation3 = Validation.fail(["Missing value"])
    assert validation3.value is None
    assert validation3.errors == ["Missing value"]

# Unit tests for public methods of class Validation

# Generated at 2022-06-24 00:51:27.599235
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation(1, []).is_success() == True
    assert Validation(1, [1]).is_success() == False


# Generated at 2022-06-24 00:51:38.444885
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for method ap of class Validation"""

    assert Validation.success().ap(lambda _: Validation.success()) == Validation.success()
    assert Validation.success(1).ap(lambda _: Validation.success()) == Validation.success(1)
    assert Validation.success(1).ap(lambda _: Validation.success('a')) == Validation.success(1)
    assert Validation.success(1).ap(lambda _: Validation.success()) == Validation.success(1)

    assert Validation.success(1).ap(lambda _: Validation.fail(['a'])) == Validation.fail(['a'])
    assert Validation.fail(['a']).ap(lambda _: Validation.success()) == Validation.fail(['a'])

# Generated at 2022-06-24 00:51:41.560703
# Unit test for constructor of class Validation
def test_Validation():
    validation_success = Validation(10, [])
    validation_fail = Validation(None, [])
    assert validation_success.value == 10 and validation_success.errors == []
    assert validation_fail.value == None and validation_fail.errors == []



# Generated at 2022-06-24 00:51:49.129706
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert(str(Validation(None, [])) == 'Validation.success[None]')
    assert(str(Validation(None, [1, 2])) == 'Validation.fail[None, [1, 2]]')
    assert(str(Validation(1, [])) == 'Validation.success[1]')
    assert(str(Validation(1, [1, 2])) == 'Validation.fail[1, [1, 2]]')


# Generated at 2022-06-24 00:51:51.344729
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    result = Validation.success('value')

    assert result.is_success()


# Generated at 2022-06-24 00:52:00.546880
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    import pymonet.validation

    def get_something():
        return 'something'

    def get_another_thing():
        return 'another thing'

    def get_number():
        return 1

    def get_another_number():
        return 2

    something = pymonet.Validation.success(get_something())
    another_thing = pymonet.Validation.success(get_another_thing())

    assert something.to_lazy() == pymonet.Lazy(get_something)
    assert another_thing.to_lazy() == pymonet.Lazy(get_another_thing)


# Generated at 2022-06-24 00:52:05.256181
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert Validation.fail([1]) == Validation.fail([1])
    assert not Validation.success(1) == Validation.success(2)
    assert not Validation.success([]) == Validation.fail([])
    assert not Validation.fail([1]) == Validation.fail([])
    assert not Validation.fail([1]) == Validation.fail([1, 2])



# Generated at 2022-06-24 00:52:13.779988
# Unit test for method ap of class Validation
def test_Validation_ap():
    fail = Validation.fail(['abc', 'def'])
    fail2 = Validation.fail(['1', '2'])
    pass_ = Validation.success(['1'])

    assert fail.ap(lambda x: fail2) == Validation(None, ['abc', 'def', '1', '2'])
    assert (
        fail.ap(lambda x: pass_) ==
        Validation(None, ['abc', 'def'])
    )
    assert (
        pass_.ap(lambda x: fail2) ==
        Validation(['1'], ['1', '2'])
    )
    assert (
        pass_.ap(lambda x: pass_) ==
        Validation(['1'], [])
    )

# Generated at 2022-06-24 00:52:19.904937
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    successValue = 'successValue'
    failValue = 'failValue'
    assert Validation.success(successValue).value == Validation.success(successValue).to_lazy().evaluate()
    assert Validation.fail([failValue]).value is None
    assert Validation.fail([failValue]).value == Validation.fail([failValue]).to_lazy().evaluate()

# Generated at 2022-06-24 00:52:24.408016
# Unit test for constructor of class Validation
def test_Validation():
    validation_success = (Validation.success('value'), 'validation_success')
    validation_fail = (Validation.fail(['errors']), 'validation_fail')
    return [validation_success, validation_fail]


# Generated at 2022-06-24 00:52:30.837124
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.success(None).to_try() == Try(None, is_success=True)
    assert Validation.success(None).to_try() == Try(None, is_success=True)
    assert Validation.fail(['Error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:52:35.317879
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Check that method is_fail return true when errors list is not empty
    """

    # Given
    monad = Validation.fail([1, 2])

    # When
    result = monad.is_fail()

    # Then
    assert result is True


# Generated at 2022-06-24 00:52:40.371484
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Validation.success(100).to_maybe() == Just(100)
    assert Validation.fail().to_maybe() == Nothing()

# Generated at 2022-06-24 00:52:46.595367
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    lazy = Validation.success("test").to_lazy()

    try:
        assert lazy.eval() == "test"
    except:
        assert False, "Validation.to_lazy failed"


# Generated at 2022-06-24 00:52:51.073970
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['a', 'b', 'c']).is_fail() is True
    assert Validation.fail([]).is_fail() is False
    assert Validation.success(True).is_fail() is False



# Generated at 2022-06-24 00:52:56.009884
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def id_function(value):
        return value

    lazy_identity = Validation.success(id_function).to_lazy()
    assert lazy_identity(1) == 1

# Unit test function for method to_try of class Validation

# Generated at 2022-06-24 00:53:03.791033
# Unit test for method map of class Validation
def test_Validation_map():
    # Test for success
    assert Validation.success(50).map(lambda v: v * 2) == Validation.success(100)
    assert Validation.success(50).map(lambda v: v / 0) == Validation.fail()

    # Test for fail
    assert Validation.fail().map(lambda v: v * 2) == Validation.fail()
    assert Validation.fail().map(lambda v: v / 0) == Validation.fail()


# Generated at 2022-06-24 00:53:05.686675
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.fail().is_success() is False


# Generated at 2022-06-24 00:53:12.239340
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.base_monad import is_monad

    def is_maybe(value):
        from pymonet.maybe import Maybe

        return isinstance(value, Maybe)

    assert is_monad(Validation.success(0).to_maybe(), is_maybe_function=is_maybe)
    assert is_monad(Validation.fail(['error']).to_maybe(), is_maybe_function=is_maybe)


# Generated at 2022-06-24 00:53:14.755137
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # GIVEN
    validation = Validation('value', ['error one', 'error two'])

    # WHEN
    result = validation.is_fail()

    # THEN
    assert result is True


# Generated at 2022-06-24 00:53:24.102611
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right

    validation1 = Validation.success(1)
    validation2 = Validation.fail([1, 2])

    to_either = lambda x: Left(x)
    to_validation = lambda x: Validation.success(x * 2)
    assert validation1.bind(to_validation).bind(to_either) == Left(2)
    assert validation1.bind(to_validation) != Left(2)
    assert validation2.bind(to_validation).bind(to_either) == Left(2)
    assert validation2.bind(to_validation) != Left(2)


# Generated at 2022-06-24 00:53:31.677642
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail(['error']) != Validation.fail(['error1', 'error2'])
    assert Validation.fail(['error']) != Validation.success()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']) == Validation.fail([])


# Generated at 2022-06-24 00:53:40.441723
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation.
    """

    # The case of successful Validation
    validation = Validation.success('value')
    assert 'value' == validation.value
    assert '[]' == str(validation.errors)
    assert 'Validation.success[value]' == str(validation)

    # The case of failure Validation
    validation = Validation.fail(['error'])
    assert 'value' == validation.value
    assert '["error"]' == str(validation.errors)
    assert 'Validation.fail[value, ["error"]]' == str(validation)


# Generated at 2022-06-24 00:53:47.881612
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda value: value + 1) == Validation.success(2)
    assert Validation.success(A(0, 1)).map(lambda value: value.a + value.b) == Validation.success(1)
    assert Validation.fail(["bad"]).map(lambda value: value + 1) == Validation.fail(["bad"])
    assert Validation.fail(["bad"]).map(lambda value: A(value, 0).a + A(value, 0).b) == Validation.fail(["bad"])


# Generated at 2022-06-24 00:53:49.993134
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(2) == Validation.success(2)
    assert Validation.fail(['Error']) == Validation.fail(['Error'])


# Generated at 2022-06-24 00:53:53.228681
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(123).to_either() == Right(123)
    assert Validation.fail(['a', 'b']).to_either() == Left(['a', 'b'])


# Generated at 2022-06-24 00:53:57.857201
# Unit test for method ap of class Validation
def test_Validation_ap():
    def f(value):
        return Validation.success(value)

    first = Validation.success('123')
    second = Validation.fail(['error'])

    assert first.ap(f) == Validation('123', [])
    assert second.ap(f) == Validation(None, ['error'])



# Generated at 2022-06-24 00:54:05.624851
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.success(1) != Validation.fail()
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail() == Validation.fail()
    assert Validation.fail([]) != Validation.success()


# Generated at 2022-06-24 00:54:09.311819
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail().to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:54:14.998821
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success(2).is_fail()
    assert Validation.fail().is_fail()
    assert Validation.fail(['error']).is_fail()
    assert Validation.fail(['error1', 'error2']).is_fail()
