

# Generated at 2022-06-24 00:44:21.178935
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.maybe import Maybe

    def f(x):
        return Try(x, is_success=False)

    def g(x):
        return Box(x + 1)

    def h(x):
        return Maybe.just(x + 1)

    assert Validation.success(1).ap(f).is_fail() is True
    assert Validation.success(1).ap(g) == Validation.success(2)
    assert Validation.success(1).ap(h) == Validation.success(2)



# Generated at 2022-06-24 00:44:24.510533
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    >>> def to_int(s):
    ...     try:
    ...         return Validation.success(int(s))
    ...     except ValueError:
    ...         return Validation.fail(['Value is not a string'])

    >>> Validation.success('42').bind(to_int)
    Validation.success[42]
    >>> Validation.fail(['Value is not a string']).bind(to_int)
    Validation.fail[None, ['Value is not a string']]
    """


# Generated at 2022-06-24 00:44:26.994652
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(None, []) == Validation.fail()
    assert Validation(1, []) == Validation.success(1)
    assert Validation.fail(None) == Validation(None, None)


# Generated at 2022-06-24 00:44:28.535366
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, True)
    assert Validation.fail(['err1']).to_try() == Try(None, False)



# Generated at 2022-06-24 00:44:35.428066
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    # Expected: maybe with value
    assert Validation.success('A').to_maybe() == Maybe.just('A')
    # Expected: maybe with no value
    assert Validation.fail('A').to_maybe() == Maybe.nothing()
    # Expected: maybe with no value
    assert Validation.fail(['A']).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:44:39.720407
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(5).to_box() == Box(5)
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.fail('some error').to_box() == Box(None)


# Generated at 2022-06-24 00:44:42.712133
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()


# Generated at 2022-06-24 00:44:43.774291
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(None, [])

    assert validation.value == None
    assert validation.errors == []


# Generated at 2022-06-24 00:44:50.506314
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1).to_box().is_instance_of(Box)
    assert Validation.success(1).to_box().is_instance_of(Validation)



# Generated at 2022-06-24 00:44:53.531532
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    # Successful validation is success
    assert Validation.success().is_success()

    # Failed validation is not success
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-24 00:44:59.545058
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Validation.success(42).to_maybe() == Maybe.just(42)
    assert Validation.fail(['Fail']).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:45:05.452801
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:45:07.899302
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1]).to_try() == Try(1, is_success=False)



# Generated at 2022-06-24 00:45:13.688290
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
        >>> from pymonet.monad_validation import Validation
        >>> from pymonet.either import Right, Left
        >>> false_validation = Validation.fail([])
        >>> true_validation = Validation.success(2)
        >>> assert(false_validation.to_either() == Left([]))
        >>> assert(true_validation.to_either() == Right(2))
    """
    pass


# Generated at 2022-06-24 00:45:22.206872
# Unit test for method ap of class Validation

# Generated at 2022-06-24 00:45:26.468487
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right
    fn = lambda x: Right(x * 10)
    assert Validation.success(10).bind(fn) == Right(100)
    assert Validation.success(10).bind(lambda x: Left(x)).is_success() == True

# Generated at 2022-06-24 00:45:30.802664
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.list import List
    from pymonet.box import Box

    assert Validation(42, []).to_box() == Box(42)
    assert Validation(None, []).to_box() == Box(None)
    assert List(Validation(42, []), Validation(None, [])).map(lambda x: x.to_box()) == List(Box(42), Box(None))



# Generated at 2022-06-24 00:45:33.921470
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail().to_box().is_nothing() == False
    assert Validation.fail([1, 2, 3, 4]).to_box() == Box(None)



# Generated at 2022-06-24 00:45:37.207542
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success('success')
    assert str(success) == 'Validation.success[success]'
    fail = Validation.fail(['fail'])
    assert str(fail) == 'Validation.fail[None, [\'fail\']]'


# Generated at 2022-06-24 00:45:42.070951
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail(['error1']).map(lambda x: x + 1) == Validation.fail(['error1'])


# Generated at 2022-06-24 00:45:49.606084
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(None, [])) == "Validation.success[None]"
    assert str(Validation(123, [])) == "Validation.success[123]"
    assert str(Validation(None, [1, 2, 3])) == "Validation.fail[None, [1, 2, 3]]"
    assert str(Validation(123, [1, 2, 3])) == "Validation.fail[123, [1, 2, 3]]"


# Generated at 2022-06-24 00:45:56.455149
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success(1).is_success() == True
    assert Validation.success(None).is_success() == True
    assert Validation.success([1, 2, 3]).is_success() == True
    assert Validation.success('foo').is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail(['abc']).is_success() == False
    assert Validation.success({'foo': 'bar'}).is_success() == True


# Generated at 2022-06-24 00:46:00.928844
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Validation(1, []).to_either() == Right(1)
    assert Validation(1, [1, 2, 3]).to_either() == Try(1, is_success=False)

# Generated at 2022-06-24 00:46:03.048580
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left
    from pymonet.validation import Validation

    assert Validation.success(3).to_either() == Right(3)
    assert Validation.fail(['error']).to_either() == Left(['error'])



# Generated at 2022-06-24 00:46:08.285647
# Unit test for method map of class Validation
def test_Validation_map():  # pragma: no cover
    actual = Validation.success(1).map(lambda v: v + 1)
    assert actual == Validation(2, [])

    actual = Validation.fail(['error']).map(lambda v: v + 1)
    assert actual == Validation(None, ['error'])


# Generated at 2022-06-24 00:46:15.481891
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Function that implements unit test for method map of class Validation.
    """
    success = Validation.success(value=1)
    result = success.map(partial(lambda x, y: x * y, 2))
    assert result == Validation.success(value=2)

    fail = Validation.fail(errors=['1', '2', '3'])
    result = fail.map(lambda x: x * 2)
    assert result == Validation.fail(errors=['1', '2', '3'])



# Generated at 2022-06-24 00:46:19.696063
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, []) != Validation(2, [])
    assert Validation(1, []) != Validation(1, ['error'])



# Generated at 2022-06-24 00:46:27.090847
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    # Initializing successful validation
    value = 'value'
    input_data = Validation(value, [])
    # Validating constructor
    assert input_data.value == value
    assert input_data.errors == []

    # Initializing failed validation
    value = None
    input_data = Validation(value, ['test_error'])
    # Validating constructor
    assert input_data.value is None
    assert input_data.errors == ['test_error']



# Generated at 2022-06-24 00:46:29.944663
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    from pymonet.either import Right, Left

    assert Validation.success(10).to_either() == Right(10)
    assert Validation.fail([10, 20]).to_either() == Left([10, 20])


# Generated at 2022-06-24 00:46:35.554963
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    def Validation_str(value, errors):
        return Validation(value, errors).__str__()

    assert Validation_str(1, []) == 'Validation.success[1]'
    assert Validation_str(None, [1, 2]) == 'Validation.fail[None, [1, 2]]'



# Generated at 2022-06-24 00:46:41.259676
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.monad_maybe import Just, Nothing

    maybe = Validation.success('Success')
    assert maybe.to_either() == Right('Success')
    maybe = Validation.fail(['Fail'])
    assert maybe.to_either() == Left(['Fail'])


# Generated at 2022-06-24 00:46:46.876786
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validate = Validation.success(2)
    assert validate.to_box() == Box(2)

    validate = Validation.fail([1, 2, 3, 4])
    assert validate.to_box() == Box(None)


# Generated at 2022-06-24 00:46:49.234192
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    validation = Validation.success(10)
    assert validation.to_box() == Box(10)

    validation = Validation.fail([])
    assert validation.to_box() == Box(None)


# Generated at 2022-06-24 00:46:52.740807
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Validation.map tests
    """
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail(['Error']).map(lambda x: x + 1) == Validation.fail(['Error'])


# Generated at 2022-06-24 00:46:58.710128
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(42)) == "Validation.success[42]"
    assert str(Validation.success("abc")) == "Validation.success[abc]"
    assert str(Validation.fail(['error 1', 'error 2'])) == "Validation.fail[None, ['error 1', 'error 2']]"



# Generated at 2022-06-24 00:47:06.637367
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    success = Validation.success('value')
    fail = Validation.fail(['error'])

    assert success == Validation.success('value')
    assert fail == Validation.fail(['error'])

    assert Validation.success('value') != Validation.success('another_value')
    assert Validation.fail(['error']) != Validation.fail(['another_error'])

    assert Validation.success('value') != Validation.fail(['another_error'])
    assert Validation.fail(['error']) != Validation.success('another_value')

    assert Validation.success('value') != 'value'
    assert Validation.fail(['error']) != 'error'

    assert Validation.success('value') != Left('value')
    assert Validation

# Generated at 2022-06-24 00:47:12.417830
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success().is_success()
    assert Validation.success(10).value == 10
    assert Validation.fail().is_fail()

# Generated at 2022-06-24 00:47:17.267682
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    import pytest
    from pymonet.monad_try import Try, Success, Failure

    assert Validation.success(20).to_try() == Success(20)
    assert Validation.fail(['error 1']).to_try() == Failure(None)
    assert Validation.fail(['error 1', 'error 2']).to_try() == Failure(None)


# Generated at 2022-06-24 00:47:21.283570
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def test_function():
        return "test_value"

    lazy = Validation.success(test_function).to_lazy()

    assert isinstance(lazy, Lazy)
    assert lazy.get()() == "test_value"


# Generated at 2022-06-24 00:47:25.818575
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(100)
    assert Lazy(lambda: 100) == validation.to_lazy()


# Generated at 2022-06-24 00:47:28.513200
# Unit test for constructor of class Validation
def test_Validation():
    # need to catch AssertionError to check if constructor works as expected
    try:
        Validation(None, None)
        raise AssertionError("Should raise AssertionError")
    except AssertionError:
        pass



# Generated at 2022-06-24 00:47:38.119507
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Run unit test for method bind of class Validation.
    """
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy

    fn = lambda x: Right(x)
    v = Validation.success("success")
    v1 = v.bind(fn)
    assert v1 == Right("success")

    v2 = Validation.fail().bind(fn)
    assert v2 == Left([])

    assert v2.to_try() == Try(None, is_success=False)
    assert v1.to_try() == Try("success", is_success=True)
    assert v2.to_lazy() == Lazy(lambda: None)
    assert v1.to_lazy() == Lazy(lambda: "success")

# Generated at 2022-06-24 00:47:41.063375
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():

    validate = Validation(None, [])
    assert validate.is_fail() is True

    validate = Validation(None, ['Error1', 'Error2'])
    assert validate.is_fail() is True

    validate = Validation(None, [])
    assert validate.is_fail() is True


# Generated at 2022-06-24 00:47:43.532301
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success("value") == Validation.success("value")
    assert Validation.fail(["error1"]) == Validation.fail(["error1"])
    assert Validation.fail(["error1", "error2"]) == Validation.fail(["error1", "error2"])


# Generated at 2022-06-24 00:47:45.109101
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 10) == Validation.success(11)


# Generated at 2022-06-24 00:47:47.389126
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert (Validation.success(1).to_box() == Box(1))
    assert (Validation.fail([]).to_box() == Box(None))


# Generated at 2022-06-24 00:47:57.417772
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Just, Nothing

    # Given: Validation with success value
    validation = Validation(value=1, errors=[])

    # When: transform validation to maybe
    result = validation.to_maybe()

    # Then: result is Just with previous value
    assert result == Just(1)

    # Given: Validation with fail value
    validation = Validation(value=1, errors=[1])

    # Then: result is Nothing
    assert validation.to_maybe() == Nothing()



# Generated at 2022-06-24 00:47:59.632358
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Validation.success(42).map(lambda x: x + 1) == Validation.success(43)
    """
    assert Validation.success(42).map(lambda x: x + 1) == \
        Validation.success(43)


# Generated at 2022-06-24 00:48:07.256750
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Right

    assert Validation(None, []) == Validation(None, [])

    assert Validation(Right('left'), ['error_1']) != Validation(Right('left'), ['error_2'])

    assert Validation(Right('left'), ['error_1']) != Validation(Right('right'), ['error_1'])


# Generated at 2022-06-24 00:48:16.235018
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left
    from pymonet.functions import flip
    from pymonet.validation import Validation

    assert Validation.success(1).bind(lambda x: x * 2) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail([x])) == Validation.fail([1])

    # bind(Validation, Function) test
    def bind_validation_function(value):
        def inner(x):
            return x * 2
        return bind(value, inner)

    assert bind_validation_function(Validation.success(1)) == Validation.success(2)

    # bind is alias for flat_map
    def flat_map_validation_function(value):
        def inner(x):
            return x * 2
       

# Generated at 2022-06-24 00:48:23.519775
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    fail_validation = Validation.fail([])
    assert fail_validation.is_fail() == True

    fail_validation = Validation.fail(['some error'])
    assert fail_validation.is_fail() == True

    success_validation = Validation.success()
    assert success_validation.is_fail() == False

    success_validation = Validation.success('some value')
    assert success_validation.is_fail() == False


# Generated at 2022-06-24 00:48:34.852433
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Given
    v1 = Validation.success('foo')
    v2 = Validation.fail([3, 2, 1])
    v3 = Validation.fail([8, 7, 6])

    fn1 = lambda v: Validation.success(v + 'bar')
    fn2 = lambda v: Validation.fail([4, 5])

    # When
    u1 = v1.ap(fn1)
    u2 = v2.ap(fn2)
    u3 = v2.ap(fn1)
    u4 = v3.ap(fn2)

    # Then
    assert u1 == Validation('foobar', [])
    assert u2 == Validation(None, [3, 2, 1, 4, 5])

# Generated at 2022-06-24 00:48:41.686453
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.monad_maybe import Maybe

    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail(1).map(lambda x: x + 1) == Validation.fail(1)
    assert Validation.fail(Maybe.just(1)).map(lambda x: x + 1) == Validation.fail(Maybe.just(1))


# Generated at 2022-06-24 00:48:43.940889
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['Error']) == Validation(None, ['Error'])
    assert Validation.success(1) != Validation(1, ['Error'])
    assert Validation.success(1) != Validation(2, [])


# Generated at 2022-06-24 00:48:49.125695
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    val = Validation.success(2)
    assert val.to_lazy().is_success()
    assert val.to_lazy().get_value()() == 2

    val = Validation.fail(['Error'])
    assert val.to_lazy().is_fail()
    assert val.to_lazy().get_error() == ['Error']


# Generated at 2022-06-24 00:48:50.757137
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation(1, [])

    ok_(not validation.is_fail())

    validation = Validation(1, [1, 2, 3])

    ok_(validation.is_fail())


# Generated at 2022-06-24 00:49:00.295015
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.maybe import Maybe
    from pymonet.list import List
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def mapper(i):
        return List([i, i * 2, i * 3])

    def mapper1(i):
        return Maybe.just(i)

    def mapper2(i):
        return Box(i)

    def mapper3(i):
        return Lazy(lambda: i)

    def mapper4(i):
        return Try(i)

    val = Validation.success(3)
    assert val.ap(mapper) == Validation.success([3, 6, 9])

# Generated at 2022-06-24 00:49:07.405280
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)

    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])

    assert Validation.fail([1]) != Validation.fail([1, 2])
    assert Validation.fail([1, 2]) != Validation.fail([1])

    assert Validation.fail(1) != Validation.fail(2)
    assert Validation.success(1) != Validation.success(2)

    assert Validation.fail(1) != Validation.success(1)
    assert Validation.success(1) != Validation.fail(1)


# Generated at 2022-06-24 00:49:13.206215
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    """ Unit test for method to_box of class Validation"""
    from pymonet.box import Box

    assert(Validation.success(1).to_box() == Box(1))
    assert(Validation.fail([1]).to_box() == Box(None))


# Generated at 2022-06-24 00:49:18.754028
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Case: Validation is failed.
    Expected: result of is_fail is True
    """
    assert Validation.success(1).is_fail() == False
    assert Validation.fail('error').is_fail() == True


# Generated at 2022-06-24 00:49:21.765548
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.success(1).to_lazy().get() == 1
    assert Validation.fail().to_lazy() == Lazy(lambda: None)
    assert Validation.fail().to_lazy().get() is None


# Generated at 2022-06-24 00:49:26.827422
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation(1, []).to_either() == Try(1, is_success=True)
    assert Validation(1, ['error']).to_either() == Try(['error'], is_success=False)


# Generated at 2022-06-24 00:49:31.456987
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Given
    validation = Validation.success(5)

    # When
    result = validation.bind(lambda value: Validation.success(value))

    # Then
    assert isinstance(result, Validation)
    assert result == Validation.success(5)



# Generated at 2022-06-24 00:49:36.836108
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    validation = Validation(1, [])
    t = validation.to_try()
    assert t.is_success() is True
    assert t.value() == 1

    validation = Validation(None, [])
    t = validation.to_try()
    assert t.is_success() is False
    assert t.value() is None


# Generated at 2022-06-24 00:49:42.999537
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success().to_try() == Try(None)
    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail().to_try() == Try(None, is_success=False)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:49:49.946443
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.fail([TypeError('I am error')])) \
        == 'Validation.fail[None, [{0}({1})]]'.format(TypeError.__name__, 'I am error')
    assert str(Validation.success([TypeError('I am error')])) \
        == 'Validation.success[[{0}({1})]]'.format(TypeError.__name__, 'I am error')


# Generated at 2022-06-24 00:50:00.971549
# Unit test for method bind of class Validation
def test_Validation_bind():
    v1 = Validation.success(1)
    v2 = Validation.fail(['e1', 'e2'])

    # Validation<int, str>.bind(Function(int) -> Validation[int, str])
    assert v1.bind(lambda v: Validation.success(v + 10)) == Validation.success(11)
    assert v2.bind(lambda v: Validation.success(v + 10)) == Validation.fail(['e1', 'e2'])
    assert v1.bind(lambda v: Validation.fail([v + 5])) == Validation.fail([6])
    assert v2.bind(lambda v: Validation.fail([v + 5])) == Validation.fail(['e1', 'e2'])

    # Validation<int, str>.bind(Function(int) ->

# Generated at 2022-06-24 00:50:04.833202
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Method to_lazy of class Validation"""

    from pymonet.lazy import Lazy

    # Test on Validation.success
    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()

    # Test on Validation.fail
    assert Lazy(lambda: None) == Validation.fail(['error']).to_lazy()


# Generated at 2022-06-24 00:50:06.810305
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation('try', []).to_box() == Validation('try', []).value


# Generated at 2022-06-24 00:50:08.923054
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('a').is_fail() == False
    assert Validation.fail(['b']).is_fail() == True


# Generated at 2022-06-24 00:50:13.382628
# Unit test for constructor of class Validation
def test_Validation():
    """
    Unit test for Validation constructor.
    """
    validation = Validation("foo", ["error"])
    assert validation.value == "foo"
    assert validation.errors == ["error"]


# Generated at 2022-06-24 00:50:17.176105
# Unit test for method __str__ of class Validation
def test_Validation___str__(): # pragma: no cover
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['err'])) == 'Validation.fail[None, [\'err\']]'


# Generated at 2022-06-24 00:50:25.454261
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test method ap of Validation.

    :returns: Nothing
    :rtype: None
    """

    def run_test(function, errors, expected_result):
        """
        Function to run one test.

        :param function: function to validate
        :type function: Function(Any) -> Validation[A, List[E]]
        :param errors: list of errors
        :type errors: List[E]
        :param expected_result: expected result
        :type expected_result: String
        :returns: Nothing
        :rtype: None
        """
        validation = Validation.success(5)
        result = validation.ap(function)
        assert result == Validation(5, errors), 'Expected {}'.format(expected_result)

    # Test cases
    # function, errors, expected result
    test

# Generated at 2022-06-24 00:50:28.427103
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:50:33.430046
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert __str__(Validation.success('yeah')) == 'Validation.success[yeah]'
    assert __str__(Validation.fail(['error1', 'error2'])) == 'Validation.fail[None, [\'error1\', \'error2\']]'


# Generated at 2022-06-24 00:50:41.304345
# Unit test for method bind of class Validation
def test_Validation_bind():
    v1 = Validation.success(10)
    v2 = Validation.fail([])
    v3 = Validation.fail(['Bad request'])
    v4 = Validation.success(10).bind(lambda num: Validation.success(num * 2))
    v5 = Validation.fail(['Bad request']).bind(lambda num: Validation.success(num * 2))
    v6 = Validation.success(10).bind(lambda num: Validation.fail(['Bad request']))
    v7 = Validation.fail(['Bad request']).bind(lambda num: Validation.fail(['Bad request']))
    assert v1 == Validation(10, [])
    assert v2 == Validation(None, [])
    assert v3 == Validation(None, ['Bad request'])
    assert v4 == Validation

# Generated at 2022-06-24 00:50:43.837531
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(0).is_fail() == False
    assert Validation.fail([1]).is_fail() == True


# Generated at 2022-06-24 00:50:46.494089
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:50:48.927284
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert (Validation.success(2).bind(lambda x: Validation.success(x + 2)) ==
            Validation.success(4))



# Generated at 2022-06-24 00:50:58.174860
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    if Validation.fail(['a']) == Validation.fail(['b']):
        raise Exception(('__eq__ method for class Validation failed. '
                         'Two failed Validations are equals'))
    if Validation.fail(['a']) == Validation.fail(['a', 'b']):
        raise Exception(('__eq__ method for class Validation failed. '
                         'Two failed Validations are equals'))

    if not Validation.success('a') == Validation.success('a'):
        raise Exception(('__eq__ method for class Validation failed. '
                         'Two successful Validations are not equals'))


# Generated at 2022-06-24 00:51:02.884870
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Unit test for method is_fail of class Validation."""

    def run_test(value, errors, is_fail):
        """Helper function for running tests."""
        validation = Validation(value, errors)
        if is_fail != validation.is_fail():
            raise ValueError('Validation is fail: {}'.format(validation))

    run_test(None, [], False)
    run_test(None, ['error 1', 'error 2'], True)
    run_test('value', [], False)
    run_test('value', ['error 1', 'error 2'], True)



# Generated at 2022-06-24 00:51:05.975453
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success('test').to_try() == Try.success('test')
    assert Validation.fail(['test']).to_try() == Try.fail(['test'])


# Generated at 2022-06-24 00:51:11.038981
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, []) != Validation(1, [1])
    assert Validation(1, []) != Validation(2, [])
    assert Validation(1, [1, 2]) != Validation(1, [1])

# Generated at 2022-06-24 00:51:14.626404
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.fail([1])
    assert validation.is_fail(), 'Validation is fail'
    validation = Validation.success(1)
    assert not validation.is_fail(), 'Validation is not fail'


# Generated at 2022-06-24 00:51:22.671798
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    monad_try = Try(1)
    monad_maybe = Maybe.nothing()
    monad_lazy = Lazy(lambda: 1)
    monad_either = Left(1)

    def monad_validation_fn(x):
        if x == 1:
            return Validation.success(2)
        return Validation.fail(2)

    assert Validation.success(1).ap(monad_validation_fn) == Validation.success(1)
    assert Validation.success(1).ap(monad_try) == Validation.success(1)

# Generated at 2022-06-24 00:51:24.972130
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test Validation.to_box method.
    """
    assert ((Validation.success('value').to_box()).value == 'value')
    assert ((Validation.fail([1, 2, 3]).to_box()).value is None)


# Generated at 2022-06-24 00:51:28.227431
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation('123', []).to_either() == Right('123')
    assert Validation(None, ['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:51:32.517345
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.fail(['invalid value']).to_box() == Box(None)
    assert Validation.success('test').to_box() == Box('test')


# Generated at 2022-06-24 00:51:36.015952
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    # Positive cases
    assert Validation.success('data').to_maybe() == Maybe.just('data')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:51:38.090856
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.fail(['error']).is_success() == False


# Generated at 2022-06-24 00:51:49.724789
# Unit test for method ap of class Validation
def test_Validation_ap():
    Validation.success(1).ap(lambda x: Validation.success(2)).value == 2
    Validation.success(1).ap(lambda x: Validation.fail([])).value == 1
    Validation.success(1).ap(lambda x: Validation.fail(['Some error'])).value == 1
    Validation.fail([]).ap(lambda x: Validation.success(2)).value == None
    Validation.fail([1, 2]).ap(lambda x: Validation.success(2)).value == None
    Validation.fail([1, 2]).ap(lambda x: Validation.fail([])).value == None
    Validation.fail([1, 2]).ap(lambda x: Validation.fail(['Some error'])).value == None

# Generated at 2022-06-24 00:52:00.078428
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    It tests equality of Validation instances.

    Two Validations are equals when values and errors lists are equal.
    """
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(1) != Validation(2, [])
    assert Validation.success(1) != Validation(1, ['error1'])
    assert Validation.fail(['error1']) == Validation(None, ['error1'])
    assert Validation.fail(['error1']) != Validation.fail(['error2'])
    assert Validation.fail(['error1']) != Validation(1, ['error1'])


# Generated at 2022-06-24 00:52:02.025177
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    # Successful validation
    value = Validation.success(1).to_box()
    assert value.value == 1
    assert isinstance(value, Validation)

    # Failed validation
    value = Validation.fail([1, 2, 3]).to_box()
    assert value.value is None
    assert isinstance(value, Validation)


# Generated at 2022-06-24 00:52:09.862169
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(None).is_success()
    assert Validation.success(1).is_success()
    assert Validation.success(1) != Validation.success(2)
    assert not Validation.fail([1]).is_success()
    assert not Validation.fail([1, 2]).is_success()
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.fail([1, 2]) != Validation.fail([1])


# Generated at 2022-06-24 00:52:13.425902
# Unit test for method map of class Validation
def test_Validation_map():
    v = Validation.success(3)
    assert v.map(lambda x: x + 1) == Validation(4, [])

    v = Validation.success(3)
    assert v.map(lambda x: x + 'monad') == Validation('3monad', [])


# Generated at 2022-06-24 00:52:22.369668
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    success = Validation.success()
    assert success.value is None and len(success.errors) == 0

    fail = Validation.fail()
    assert fail.value is None and len(fail.errors) == 0

    success = Validation.success('success')
    assert success.value == 'success' and len(success.errors) == 0

    fail = Validation.fail([1, 2, 3])
    assert fail.value is None and fail.errors == [1, 2, 3]


# Generated at 2022-06-24 00:52:27.223026
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['Error', 'Error 2'])) == 'Validation.fail[None, [\'Error\', \'Error 2\']]'


# Generated at 2022-06-24 00:52:30.073910
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(10)
    lazy = validation.to_lazy()

    assert lazy.value() == 10
    assert lazy == Lazy(lambda: 10)


# Generated at 2022-06-24 00:52:33.290739
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    val1 = Validation.success(42)
    val2 = Validation.fail(['error1', 'error2'])

    assert str(val1) == 'Validation.success[42]'
    assert str(val2) == "Validation.fail[None, ['error1', 'error2']]"


# Generated at 2022-06-24 00:52:40.353958
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Failure

    # Returns Successful Try monad when Validation is successful
    assert Validation(5, []).to_try() == Try(5, is_success=True)
    assert Validation(None, []).to_try() == Try(None, is_success=True)

    # Returns OK Try monad when Validation is failure
    assert Validation(5, [1, 2]).to_try() == Try(5, is_success=False)
    assert Validation(5, []).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:52:44.543689
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('value').is_fail() == False
    assert Validation.fail('error').is_fail() == True


# Generated at 2022-06-24 00:52:52.048955
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.success(1) != Validation.fail([1])
    assert Validation.fail([1]) != Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) != Validation.fail([2])

if __name__ == '__main__':  # pragma: no cover
    test_Validation___eq__()

# Generated at 2022-06-24 00:52:57.822496
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit tests for method __eq__ of class Validation
    """
    try:
        from nose.tools import assert_equal
    except ImportError:
        def assert_equal(a, b):
            assert a == b

    success_validation = Validation.success(42)
    fail_validation = Validation.fail([42])

    assert_equal(success_validation, Validation.success(42))
    assert_equal(fail_validation, Validation.fail([42]))



# Generated at 2022-06-24 00:53:00.573175
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box
    assert Validation.fail(['test']).to_box() == Box(None)
    assert Validation.success(5).to_box() == Box(5)


# Generated at 2022-06-24 00:53:05.603755
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(123).to_box() == Box(123)
    assert Validation.fail().to_box() == Box(None)


# Generated at 2022-06-24 00:53:10.733504
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail(errors=[1, 2]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:53:18.366807
# Unit test for method to_box of class Validation
def test_Validation_to_box(): # pragma: no cover
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success().to_box() == Box(None)
    assert Validation.fail().to_box() == Box(None)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:21.088841
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test.

    Python convention is use underscore '_' as a name of unit test methods.
    """
    v = Validation.success()
    assert v.is_fail() == False


# Generated at 2022-06-24 00:53:29.197336
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.funcs import curry

    def add_validation(a, b):
        def add(x):
            return Validation.success(x + x)
        return add(a)

    def concat(a, b):
        return Validation.success(a + b)

    add = curry(concat)

    v = Validation.success(1)

    assert v.ap(add) == Validation.success(2)
    assert v.ap(add_validation) == Validation.success(2)



# Generated at 2022-06-24 00:53:32.020329
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    validation = Validation.success(1)
    assert validation == Validation.success(1)
    assert validation != Validation.success(2)
    assert validation != Validation.fail([1, 2])
    assert validation != Validation.fail([3, 4])


# Generated at 2022-06-24 00:53:39.441046
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test for method to_try of class Validation.

    It should return Try with value from Validation
    """
    from pymonet.monad_try import Try

    assert Try(1).map(lambda x: x + 1) == Validation(1, []).to_try().map(lambda x: x + 1)
    assert Try(None, is_success=False) == Validation(None, ['error']).to_try().map(lambda x: x + 1)


# Generated at 2022-06-24 00:53:42.206614
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():

    # Validation to Maybe
    assert Validation(3, []).to_maybe() == Maybe.just(3)
    assert Validation(None, [1, 2]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:53:43.867767
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for Validation.is_fail method
    """
    assert Validation.success(1).is_fail() == False


# Generated at 2022-06-24 00:53:50.146124
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    GIVEN Validation with value and empty errors list
    WHEN call to_lazy method
    THEN Lazy monad is returned that returns this value
    """
    test_value = 'TEST'
    validation = Validation(test_value, [])
    assert validation.to_lazy().value() == test_value



# Generated at 2022-06-24 00:53:54.518772
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Converts current Success and Failure to Lazy monad"""
    from pymonet.lazy import Lazy

    assert Validation.success(2) == Lazy(2).to_validation()
    assert Validation.success(None) == Lazy(None).to_validation()
    assert Validation.success(None) == Lazy(lambda: None).to_validation()



# Generated at 2022-06-24 00:54:03.973252
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.either import Left
    from pymonet.monad_try import Try

    assert Validation.success(1).is_fail() is False
    assert Validation.fail([1, 2, 3]).is_fail() is True

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)
    assert Validation.success(1).to_either() == Left(None)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:54:07.691982
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(2).to_try() == Try(2)
    assert Validation.fail(list(range(4))).to_try() == Try(None, is_success=False)



# Generated at 2022-06-24 00:54:14.176430
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    >>> Validation.success(1).ap(Validation.success(lambda x: x + 1)).is_success()
    True

    >>> Validation.success(1).ap(Validation.fail(['error'])).is_fail()
    True

    >>> Validation.fail(['first error']).ap(Validation.success(lambda x: x + 1)).is_fail()
    True

    >>> Validation.fail(['first error']).ap(Validation.fail(['second error'])).is_fail()
    True

    >>> Validation.success(1).ap(Validation.success(lambda x: x + 1)).value
    2
    """
    pass
