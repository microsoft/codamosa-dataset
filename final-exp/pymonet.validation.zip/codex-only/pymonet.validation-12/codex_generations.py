

# Generated at 2022-06-24 00:44:16.783889
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation(1, []).to_maybe() == Maybe.just(1)
    assert Validation(1, [1]).to_maybe() == Maybe.nothing()

    assert (Try(1, is_success=True)
            .to_validation()
            .to_maybe() == Maybe.just(1))
    assert (Try(1, is_success=False)
            .to_validation()
            .to_maybe() == Maybe.nothing())


# Generated at 2022-06-24 00:44:18.859398
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    val_s = Validation.success(1)
    assert(val_s.to_box() == Box(1))
    val_f = Validation.fail([2, 3])
    assert(val_f.to_box() == Box(None))


# Generated at 2022-06-24 00:44:23.692156
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    # Validation with None value
    validation = Validation(None, [InvalidArgument('error')])
    # Method returns successfully Try
    assert validation.to_try() == Try(None, is_success=False)

    # Validation with value
    validation = Validation(444, [])
    # Method returns successfully Try
    assert validation.to_try() == Try(444)

# Generated at 2022-06-24 00:44:25.365366
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    x = Validation.fail()
    y = Validation.fail([1, 2])
    assert x.is_fail()
    assert y.is_fail()


# Generated at 2022-06-24 00:44:31.253133
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left
    from pymonet.box import Box
    from pymonet.maybe import Maybe
    from pymonet.lazy import Lazy

    test_value = 10

    # test for success Validation
    success_validation = Validation.success(test_value)

    assert success_validation.bind(Right) == Right(test_value)
    assert success_validation.bind(Box) == Box(test_value)
    assert success_validation.bind(Maybe.just) == Maybe.just(test_value)
    assert success_validation.bind(lambda _: Maybe.nothing()) == Maybe.nothing()
    assert success_validation.bind(Lazy) == Lazy(lambda: test_value)

# Generated at 2022-06-24 00:44:34.041428
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left
    from pymonet.validation import Validation

    fn = lambda x: Validation.success(x + 2)

    assert Validation.success(2).ap(fn) == Validation.success(4)
    assert Validation.success(2).ap(Left(3)) == Validation.success(2)
    assert Validation.fail([1, 2]).ap(fn) == Validation.fail([1, 2])



# Generated at 2022-06-24 00:44:42.812474
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test that Validation can be transform to Try.

    Return successful Try when Validation is success, otherwise failed Try.
    """
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    actual = Validation.success(3).to_try()
    expected = Try(3, is_success=True)

    assert actual == expected, "Wrong transform to Try for Validation"

    actual = Validation.fail(3).to_try()
    expected = Try(None, is_success=False)

    assert actual == expected, "Wrong transform to Try for Validation"

# Generated at 2022-06-24 00:44:49.028508
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Left, Right

    def extract_value(x):
        return Maybe.just(x)

    def extract_second_value(x):
        return Maybe.just(x + "!")

    def extract_value_from_either(x):
        return Right(x)

    def extract_second_value_from_either(x):
        return Right(x + "!")

    def extract_value_from_either_error(x):
        return Left(x)

    def extract_second_value_from_either_error(x):
        return Left(x + "!")

    def extract_value_from_validation(x):
        return Validation.success(x)


# Generated at 2022-06-24 00:44:51.118883
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)


# Generated at 2022-06-24 00:45:02.307800
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(1).bind(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda x: Validation.success(x + 1)) == Validation.fail(['error'])
    assert Validation.fail(['error']).bind(lambda x: Validation.fail(['error1'])) == Validation.fail(['error', 'error1'])

# Unit tests for map of class Validation

# Generated at 2022-06-24 00:45:08.575236
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test case for method to_lazy of class Validation"""

    def success_mapper(obj):
        return obj

    def fail_mapper(obj):
        return obj

    ret = Validation.success(True).to_lazy().get()
    assert ret(success_mapper), "Validation success transformations to Lazy must be successful"

    ret = Validation.fail([]).to_lazy().get()
    assert ret(fail_mapper), "Validation fail transformations to Lazy must be successful"


# Generated at 2022-06-24 00:45:12.673342
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.exception import Error

    assert Validation.fail().is_fail() is True
    assert Validation.fail([Error('Error')]).is_fail() is True

    assert Validation.success().is_fail() is False
    assert Validation.success(1).is_fail() is False


# Generated at 2022-06-24 00:45:20.327775
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    # Successful Validation
    assert Validation(2, []) == Validation.success(2)
    assert Validation(2, []) != Validation.success(3)

    # Failed Validation
    assert Validation(None, ['error']) == Validation.fail(['error'])
    assert Validation(None, ['error']) != Validation.fail(['error 2'])
    assert Validation(None, ['error']) != Validation.fail([])



# Generated at 2022-06-24 00:45:29.237336
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.box import Box

    def test_success():
        Validation(Try(1), []).is_success() is True
        Validation(Box(1), []).is_success() is True
        Validation(Left(1), []).is_success() is True

    def test_fail():
        Validation(Try(1, is_success=False), [1]).is_success() is False
        Validation(Box(1), [1]).is_success() is False
        Validation(Left(1), [1]).is_success() is False

    test_success()
    test_fail()


# Generated at 2022-06-24 00:45:34.677503
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    validation = Validation.fail([1, 2, 3])
    assert validation.to_maybe() == Maybe.nothing()

    validation = Validation.success(2)
    assert validation.to_maybe() == Maybe.just(2)


# Generated at 2022-06-24 00:45:37.761201
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.success(123).to_box() == Box(123)


# Generated at 2022-06-24 00:45:43.127571
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.success().to_maybe() == Maybe.just(None)
    assert Validation.fail([5]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:49.758563
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left, Right

    assert Left(5).map(lambda x: x + 2) == Left(5)
    assert Right(5).map(lambda x: x + 2) == Right(7)

    assert Validation.success(5).map(lambda x: x + 2) == Validation(7, [])
    assert Validation.fail(['error']).map(lambda x: x + 2) == Validation(None, ['error'])



# Generated at 2022-06-24 00:45:59.401170
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation
    from pymonet.functor import Functor, Container

    @Functor
    class Test(Container):
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            return self.value == other.value

        def map(self, mapper):
            return Test(mapper(self.value))

        def __str__(self):  # pragma: no cover
            return 'Test[{}]'.format(self.value)

    # Simple test
    value = Test(1)
    validation_1 = Validation(2, [])

    def mapper(x):
        return validation_1

    assert Validation(1, validation_1.errors) == value.ap(mapper)

    # Some fails
   

# Generated at 2022-06-24 00:46:05.433849
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(1.0).to_either() == Right(1.0)
    assert Validation.success("hello").to_either() == Right("hello")
    assert Validation.fail(["error"]).to_either() == Left(["error"])
    assert Validation.fail(["error1", "error2"]).to_either() == Left(["error1", "error2"])



# Generated at 2022-06-24 00:46:11.232191
# Unit test for method ap of class Validation
def test_Validation_ap():
    def f(x):
        return Validation.success(x)

    def g(x):
        return Validation.fail(['Error'])

    assert Validation.fail(['Error1']).ap(f) == Validation.fail(['Error1'])
    assert Validation.fail(['Error1']).ap(g) == Validation.fail(['Error1', 'Error'])
    assert Validation.success(8).ap(f) == Validation.success(8)
    assert Validation.success(8).ap(g) == Validation.success(8)

# Generated at 2022-06-24 00:46:14.688560
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1).value == 1
    assert Validation.success(1).is_fail() == False
    assert Validation.success(1).is_success() == True

    assert Validation.fail(['error']).value == None
    assert Validation.fail(['error']).is_fail() == True
    assert Validation.fail(['error']).is_success() == False


# Generated at 2022-06-24 00:46:18.817503
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    input = Validation.success('Hello')
    expected = Validation.success(Try('Hello', is_success=True))

    assert input.to_try().map(lambda t: t.is_success()) == expected.map(lambda t: t.value.is_success())



# Generated at 2022-06-24 00:46:25.037496
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(55)) == 'Validation.success[55]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error1'])) == "Validation.fail[None, ['error1']]"


# Generated at 2022-06-24 00:46:31.592289
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test that to_maybe method of Validation class return Maybe of value.
    """
    from pymonet.maybe import Maybe

    # Test that to_maybe method of class Validation return Maybe of value
    assert Validation.success("value").to_maybe() == Maybe("value"), "Error in Validation.to_maybe()"
    assert Validation.fail([]).to_maybe() == Maybe.nothing(), "Error in Validation.to_maybe()"


# Generated at 2022-06-24 00:46:35.798313
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['error1', 'error2'])) == 'Validation.fail[None, [\'error1\', \'error2\']]'


# Generated at 2022-06-24 00:46:41.448298
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_maybe import Maybe
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    val = Validation.success(5)

    assert val.to_lazy() == Lazy(lambda: 5)
    assert lazy(val) == Lazy(lambda: 5)

# Generated at 2022-06-24 00:46:45.534024
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(10, [1, 2]).to_box() == Box(10)


# Generated at 2022-06-24 00:46:47.844465
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1, 2]).is_fail()


# Generated at 2022-06-24 00:46:52.086756
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:46:57.763744
# Unit test for method bind of class Validation
def test_Validation_bind():
    add_5 = lambda x: Validation.success(5 + x)
    assert Validation.success(1).bind(add_5) == Validation.success(6)
    assert Validation.fail([1, 2, 3]).bind(add_5) == Validation.fail([1, 2, 3])



# Generated at 2022-06-24 00:47:04.230005
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.lazy import Lazy


# Generated at 2022-06-24 00:47:06.825762
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(2).to_try() == Try(2, is_success=True)
    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:47:11.575589
# Unit test for method bind of class Validation
def test_Validation_bind():
    success = Validation.success(1)
    fail = Validation.fail()
    assert success.bind(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert success.bind(lambda x: Validation.fail()) == Validation.fail()
    assert fail.bind(lambda x: Validation.fail()) == Validation.fail()


# Generated at 2022-06-24 00:47:14.719885
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(123)) == 'Validation.success[123]'
    assert str(Validation.fail('Error')) == 'Validation.fail[None, Error]'


# Generated at 2022-06-24 00:47:16.373035
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    assert Validation.success(1) == Validation.success(1)


# Generated at 2022-06-24 00:47:20.933514
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    successful_validation = Validation.success(0)
    assert successful_validation.is_success() == True

    failed_validation = Validation.fail('error')
    assert failed_validation.is_success() == False


# Generated at 2022-06-24 00:47:27.034014
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 10) == Validation.success(10).to_lazy()
    assert Lazy(lambda: 20) == Validation.fail([10]).to_lazy()


# Generated at 2022-06-24 00:47:32.605042
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Should return function result when Validation is success.
    """
    assert Validation.success("success").map(lambda s: s + "!") == Validation.success("success!")



# Generated at 2022-06-24 00:47:35.276707
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.test_util import assert_equals

    validation = Validation.success([1, 2, 3])
    assert_equals(validation.is_success(), True)


# Generated at 2022-06-24 00:47:43.553549
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    assert Validation.fail(['a', 'b']) == Validation.fail(['a', 'b'])
    assert Validation.success() == Validation.success()
    assert Validation.success(Maybe.just(2)) == Validation.success(Maybe.just(2))
    assert Validation.fail([Left(2), Left(3)]) == Validation.fail([Left(2), Left(3)])


# Generated at 2022-06-24 00:47:47.200380
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(ValueClass(1)) == Validation(ValueClass(1), [])
    assert Validation.fail([ValueClass(1)]) == Validation(None, [ValueClass(1)])
    assert Validation.success(ValueClass(1)).is_success() is True
    assert Validation.fail([ValueClass(1)]).is_fail() is True


# Generated at 2022-06-24 00:47:56.327587
# Unit test for method map of class Validation
def test_Validation_map():
    # with no errors
    assert Validation.success(10).map(lambda x: x + 10) == Validation(20, [])
    assert Validation.success(10).map(lambda x: '10') == Validation('10', [])

    # with errors
    assert Validation.fail(['error']).map(lambda x: x + 10) == Validation.fail(['error']) == Validation(None, ['error'])



# Generated at 2022-06-24 00:48:01.689481
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(lambda x: Validation.success(x)) == Validation.success(1)
    assert Validation.success(1).ap(lambda x: Validation.fail([x])) == Validation.fail([1])

    assert Validation.fail([1]).ap(lambda x: Validation.success(x)) == Validation.fail([1])
    assert Validation.fail([1]).ap(lambda x: Validation.fail([x])) == Validation.fail([1])


# Generated at 2022-06-24 00:48:07.282572
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(42).to_try() == Try.success(42)
    assert Validation.success(42).to_try() != Try.failure([])
    assert Validation.fail([]).to_try() == Try.failure([])
    assert Validation.fail([]).to_try() != Try.success(None)

# Generated at 2022-06-24 00:48:15.204197
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Function that tests ap method of class Validation.

    :returns: Nothing
    :rtype: None
    """
    assert Validation.success(3).ap(Validation.fail(['Error'])) == Validation(3, ['Error'])
    assert Validation.success(3).ap(Validation.success(3)) == Validation(3, [])
    assert Validation.fail(['Error']).ap(Validation.success(3)) == Validation(None, ['Error'])
    assert Validation.fail(['Error']).ap(Validation.fail(['Error'])) == Validation(None, ['Error', 'Error'])

# Generated at 2022-06-24 00:48:21.935089
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # when
    result = Validation.fail(['err1', 'err2']).to_maybe()

    # then
    assert result.is_nothing()

    # when
    result = Validation.success(Box(1)).to_maybe()

    # then
    assert result.is_just() and result.value.value == 1

    # when
    result = Validation.fail(['err1', 'err2']).to_maybe()

    # then
    assert result.is_nothing()

    # when
    result = Validation.success(Lazy(lambda: 6)).to_maybe()

    # then

# Generated at 2022-06-24 00:48:24.365318
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    # Given
    validation = Validation.success('Success')
    # Then: Successful Validation to Either returns Right monad with same value
    assert validation.to_either() == Right('Success')

    # Given
    validation = Validation.fail(['Failure'])
    # Then: Failed Validation to Either returns Left monad with errors
    assert validation.to_either() == Left(['Failure'])


# Generated at 2022-06-24 00:48:29.390400
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Validation.success(3).to_maybe() == Maybe(3)
    assert Validation.fail([3, 2]).to_maybe() == Maybe(None)


# Generated at 2022-06-24 00:48:34.286110
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[10]' == str(Validation.success(10))
    assert 'Validation.fail[None, [1, 2]]' == str(Validation.fail([1, 2]))


# Generated at 2022-06-24 00:48:41.610532
# Unit test for method map of class Validation
def test_Validation_map():
    # Given
    v1 = Validation.success([1, 2, 3])
    u1 = Validation.success(3)

    # When
    v2 = v1.map(lambda a: a[2])
    u2 = u1.map(lambda a: a + 5)

    # Then
    assert v2 == Validation.success(3)
    assert u2 == Validation.success(8)



# Generated at 2022-06-24 00:48:51.045024
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(lambda x: Validation.success(x + 1)) == Validation.success(2)

    assert Validation.success(1).ap(lambda x: Validation.fail([])) == Validation.success(1)

    assert Validation.success(1).ap(lambda x: Validation.fail(['error'])) == Validation.success(1)

    assert Validation.fail(['error']).ap(lambda x: Validation.success(x + 1)) == Validation.fail(['error'])

    assert Validation.fail(['error']).ap(lambda x: Validation.fail(['error2'])) == Validation.fail(['error'])


# Generated at 2022-06-24 00:48:53.855182
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert_equals(Validation.fail(['error1']).is_success(), False)
    assert_equals(Validation.success(10).is_success(), True)


# Generated at 2022-06-24 00:49:04.659445
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Validation instance should contains validation errors.

    :returns: None
    :rtype: None
    """
    def validate_number_format(number):
        """
        Validates string number.

        :params number: string number
        :type number: String
        :returns: validation result with value and errors
        :rtype: Validation
        """
        errors = []
        if not isinstance(number, str):
            errors.append('Number is not a String')
        elif len(number) == 0:
            errors.append('Number String is empty')
        elif not number.isdigit():
            errors.append('Number String is not digit')
        if len(errors) > 0:
            return Validation.fail(errors)
        return Validation.success(int(number))


# Generated at 2022-06-24 00:49:07.126183
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation.success(10)
    assert Validation.success(10) != Validation.success(12)
    assert Validation.success(10) != Validation.fail()
    assert Validation.fail() == Validation.fail()


# Generated at 2022-06-24 00:49:10.654754
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success()
    assert validation.is_success() is True


# Generated at 2022-06-24 00:49:12.568685
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    v = Validation.success(1)
    assert v.to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:49:20.885830
# Unit test for method map of class Validation
def test_Validation_map():
    def mapper(value):
        if value == 'pymonet':
            return value + '1'
        return value

    assert Validation.success('pymonet').map(mapper) == Validation.success('pymonet1')
    assert Validation.success(1).map(mapper) == Validation.success(1)

    errors = [
        '1',
        '23',
        '456'
    ]

    assert Validation.fail(errors).map(mapper) == Validation.fail(errors)


# Generated at 2022-06-24 00:49:26.196121
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('1') == Validation('1', [])
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(['1', '2']) == Validation(None, ['1', '2'])
    assert Validation.fail(['1']) == Validation(None, ['1'])
    assert Validation.fail() == Validation(None, [])


# Generated at 2022-06-24 00:49:29.876625
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success([1, 2, 3]).to_try() == Try([1, 2, 3], is_success=True)
    assert Validation.fail([1, 2, 3]).to_try() == Try([1, 2, 3], is_success=False)

# Generated at 2022-06-24 00:49:35.955182
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation.success(10)

    def add_errors(x):
        if x > 5:
            return Validation.fail(['greater than 5'])
        else:
            return Validation.success(x)

    result = validation.ap(add_errors)

    assert len(result.errors) == 1
    assert result.errors == ['greater than 5']

# Generated at 2022-06-24 00:49:39.219822
# Unit test for method is_success of class Validation
def test_Validation_is_success():  # pragma: no cover
    assert Validation.fail().is_success()
    assert not Validation.fail(['error']).is_success()
    assert Validation.success(10).is_success()



# Generated at 2022-06-24 00:49:42.914862
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.monad_maybe import Maybe

    assert(Validation("data", [1, 2, 3]).to_maybe() == Maybe.just("data"))
    assert(Validation(None, [1, 2, 3]).to_maybe() == Maybe.nothing())


# Generated at 2022-06-24 00:49:46.619430
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(5, []).to_box() == Box(5)


# Generated at 2022-06-24 00:49:48.586290
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success('some')
    assert isinstance(validation.to_lazy(), Lazy)


# Generated at 2022-06-24 00:49:59.908475
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert (Validation.success().bind(lambda v: Validation.fail(['Error'])) ==
            Validation.fail(['Error']))

    assert (Validation.success(1).bind(lambda v: Validation.fail(['Error'])) ==
            Validation.fail(['Error']))

    assert (Validation.success().bind(lambda v: Validation.success(2)) ==
            Validation.success(2))

    assert (Validation.success(1).bind(lambda v: Validation.success(v + 2)) ==
            Validation.success(3))

    assert (Validation.fail().bind(lambda v: Validation.fail(['Error'])) ==
            Validation.fail(['Error']))


# Generated at 2022-06-24 00:50:02.828822
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right

    assert Validation.success(1).value == 1
    assert Validation.success(1).errors == []
    assert Validation.success(1).is_success() is True
    assert Validation.success(1).is_fail() is False

    assert Validation.fail([1, 2, 3]).value is None
    assert Validation.fail([1, 2, 3]).errors == [1, 2, 3]
    assert Validation.fail([1, 2, 3]).is_success() is False
    assert Validation.fail([1, 2, 3]).is_fail() is True



# Generated at 2022-06-24 00:50:08.614092
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.functor import Functor

    def f(n):
        if n == 1:
            return Functor.unit(n)
        return Validation.fail(['n not equal to 1'])

    # test for successful validation
    validation1 = Validation.success(1)
    lazy1 = validation1.to_lazy()
    assert lazy1.f() == 1
    assert lazy1.f() == validation1.value

    # test for failed validation
    validation2 = Validation.fail(['n not equal to 1'])
    lazy2 = validation2.to_lazy()
    assert lazy2.f() is None
    assert lazy2.f() is validation2.value

# Generated at 2022-06-24 00:50:12.421152
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test when Validation has not errors.
    """
    validation = Validation.success([])

    assert validation.is_success(), 'It should be success'


# Generated at 2022-06-24 00:50:14.774072
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() is False
    assert Validation.fail(['1']).is_fail()



# Generated at 2022-06-24 00:50:17.398692
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation(1, []).map(lambda x: x + 1) == Validation(2, [])



# Generated at 2022-06-24 00:50:22.512731
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """Test method to_box on class Validation"""

    from pymonet.box import Box

    assert Validation.success(5).to_box() == Box(5)
    assert Validation.success(3).to_box() == Box(3)
    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:50:24.911768
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation(1, []).map(lambda a: a + 1).value == 2
    assert Validation(1, [1, 2]).map(lambda a: a + 1).errors == [1, 2]


# Generated at 2022-06-24 00:50:35.034090
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.monad_either import Left, Right
    from pymonet.box import Box
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1), "Validation success 1 to lazy"
    assert Validation.fail(2).to_lazy() == Lazy(lambda: None), "Validation fail 2 to lazy"

    assert Validation.success(1).to_lazy().to_box() == Box(1), "Validation success 1 to lazy 1 to box"
    assert Validation.fail(2).to_lazy().to_box() == Box(None), "Validation fail 2 to lazy 2 to box"

    assert Validation

# Generated at 2022-06-24 00:50:38.371907
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('test-value').is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:50:49.525697
# Unit test for method map of class Validation
def test_Validation_map():

    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])
    assert Validation.success(1).map(lambda x: x + 1).map(lambda x: x + 1) == Validation(3, [])
    assert Validation.success(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Validation(4, [])
    assert Validation.success(1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1).map(lambda x: x + 1) == Validation(5, [])
    assert Validation.fail().map(lambda x: x + 1) == Validation(None, [])


# Generated at 2022-06-24 00:50:51.491451
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    val = Validation.fail([])
    assert val.is_fail() == True


# Generated at 2022-06-24 00:50:56.894469
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]', \
        'Returned string representation should be "Validation.success[1]"'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]', \
        'Returned string representation should be "Validation.fail[None, [1]]"'


# Generated at 2022-06-24 00:51:02.059708
# Unit test for method map of class Validation
def test_Validation_map():
    """Unit tests for method map of class Validation"""
    from pymonet.validation import Validation

    def _f(a):
        return a + 1

    validation = Validation(1, ['error'])
    assert validation.map(_f) == Validation(2, ['error'])

    validation = Validation.success(1)
    assert validation.map(_f) == Validation(2, [])


# Generated at 2022-06-24 00:51:04.502890
# Unit test for method bind of class Validation
def test_Validation_bind():
    x = Validation.success(2).bind(lambda x: Validation.success(x + 1))
    y = Validation.success(2)

    assert x == y

# Generated at 2022-06-24 00:51:12.434178
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(10).map(lambda x: x + 2) == \
           Validation.success(12)

    assert Validation.fail(['error']).map(lambda x: x + 2) == \
           Validation.fail(['error'])

    assert Validation.success('abc').map(lambda x: x + 'def') == \
           Validation.success('abcdef')

    assert Validation.success([]).map(lambda x: x + [2, 3, 4]) == \
           Validation.success([2, 3, 4])


# Generated at 2022-06-24 00:51:18.614363
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.success(10).to_either() == Right(10)

    # Test for map function
    assert (Validation.success(10)
            .to_either()
            .map(lambda value: value * 2)
            == Right(20))


# Generated at 2022-06-24 00:51:24.123051
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    foo = Validation.success('foo')
    bar = Validation.fail(['bar'])

    success_to_try = foo.to_try()
    fail_to_try = bar.to_try()

    assert(isinstance(success_to_try, Try))
    assert(isinstance(fail_to_try, Try))

    assert(success_to_try.is_success())
    assert(not fail_to_try.is_success())

    assert(success_to_try == Try('foo', is_success=True))
    assert(fail_to_try == Try(['bar'], is_success=False))


# Generated at 2022-06-24 00:51:25.762694
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    def lazy():
        return value

    validate = Validation.success(value)
    assert validate.to_lazy() == Lazy(lazy)

# Generated at 2022-06-24 00:51:27.815993
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('').is_success() == True


# Generated at 2022-06-24 00:51:37.615276
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation

    :returns: assertion errors
    :rtype: List[AssertionError]
    """
    res = Validation.success('value').ap(lambda x: Validation.success(x + 1)).ap(lambda x: Validation.success(x + 2))
    res1 = Validation.fail('error').ap(lambda x: Validation.success(x + 1)).ap(lambda x: Validation.success(x + 2))

    assert res == Validation.success(3), 'Validation.ap should return valid Validation'
    assert res1 == Validation.fail(['error']), 'Validation.ap should return valid Validation'

    return []


# Generated at 2022-06-24 00:51:45.184784
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail() == Validation.fail()
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1, 2]) == Validation.fail([1, 2])
    assert Validation.success() != Validation.fail()
    assert Validation.success(1) != Validation.fail()
    assert Validation.success() != Validation.fail([1])
    assert Validation.success(1) != Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])

# Generated at 2022-06-24 00:51:54.636386
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right
    from pymonet.box import Box

    def optimistic_add(a, b):
        from pymonet.either import Right

        return Right(a + b)

    def pessimistic_add(a, b):
        from pymonet.either import Left

        return Left(('Error in argument {!r} and {!r}', a, b))

    def optimistic_validator(number):
        from pymonet.either import Right

        return Right(number)

    def pessimistic_validator(number):
        from pymonet.either import Left

        if number == 0:
            return Left('Zero is not allowed')
        else:
            return Left('Number is not even')

    # Given arguments and function
    args = [2, 3]

# Generated at 2022-06-24 00:51:58.806668
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try().is_success()
    assert Validation.success().to_try().is_success()
    assert Validation.fail([1]).to_try().is_fail()
    assert Validation.fail().to_try().is_fail()


# Generated at 2022-06-24 00:52:02.993151
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success('success').to_either() == Right('success')
    assert Validation.fail(['1', '2', '3']).to_either() == Left(['1', '2', '3'])


# Generated at 2022-06-24 00:52:05.400154
# Unit test for method map of class Validation
def test_Validation_map():
    # given
    validation = Validation.success('b')

    # when
    result = validation.map(lambda x: x + 'a')

    # then
    assert result == Validation.success('ba')


# Generated at 2022-06-24 00:52:10.080931
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test Validation.__str__ method.
    """
    # test of string representation of success Validation
    assert (str(Validation.success('string')) ==
            'Validation.success[string]')

    # test of string representation of failed Validation
    assert (str(Validation.fail(['error'])) ==
            'Validation.fail[None, [\'error\']]')


# Generated at 2022-06-24 00:52:14.413648
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Unit test for method to_maybe of class Validation"""

    def assert_equal(left, right):
        """Helper function for test equality of two values."""
        if left == right:
            return
        assert False, '{} == {}'.format(left, right)

    assert_equal(Validation.success('test').to_maybe(), Maybe.just('test'))
    assert_equal(Validation.fail(['test']).to_maybe(), Maybe.nothing())


# Generated at 2022-06-24 00:52:26.515043
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    # First argument is success validation, second is failed validation
    validations = [Validation.success(1), Validation.fail('fail_1')]
    second_validations = [Validation.success(2), Validation.fail('fail_2')]

    # Asserting ap method
    # First argument is success validation, second is failed validation
    assert validations[0].ap(lambda x: second_validations[0]) == Validation.success(2), \
        'Validation success ap method has failed!'

# Generated at 2022-06-24 00:52:28.646021
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()


# Generated at 2022-06-24 00:52:40.822493
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation(1, []), 'should be success'
    assert Validation(1, ['error1']) == Validation(1, ['error1']), 'should be success'
    assert Validation(1, ['error1']) != Validation(2, ['error1']), 'should not be same'
    assert Validation(1, ['error1']) != Validation(1, []), 'should not be same'
    assert Validation(1, []) != Validation(2, []), 'should not be same'
    assert Validation(1, []) != Validation(1, ['error1']), 'should not be same'
    assert Validation(1, ['error1']) != Validation(2, ['error2']), 'should not be same'

# Generated at 2022-06-24 00:52:46.967012
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    validation = Validation('someval', ['someerr'])
    result = validation.to_box()
    assert isinstance(result, Validation)
    assert result.value == 'someval'
    assert result.errors == ['someerr']


# Generated at 2022-06-24 00:52:58.014623
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right

    assert Validation.success(10).ap(lambda v: Left([])) == Validation(10, [])
    assert Validation.success(10).ap(lambda v: Right(100)) == Validation(100, [])
    assert Validation.fail([]).ap(lambda v: Left([])) == Validation(None, [])
    assert Validation.fail([]).ap(lambda v: Right(100)) == Validation(100, [])
    assert Validation.success(10).ap(lambda v: Validation.fail(['Error'])) == Validation(10, ['Error'])

    # Unit test for class Validation
    assert Validation.success(10).is_success() is True
    assert Validation.fail([]).is_fail() is True
    assert Validation

# Generated at 2022-06-24 00:53:03.698087
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.monad_try import Failure
    from pymonet.lazy import Lazy

    def fail_function():
        raise Exception('Validation.to_lazy')

    success = Validation.success(1)
    assert Lazy(lambda: 1) == success.to_lazy()
    assert Lazy(fail_function) == Validation.fail([]).to_lazy()


# Generated at 2022-06-24 00:53:07.797131
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    def test():
        success_validation = Validation.success('text')
        assert success_validation.to_maybe() == Maybe.just('text')

        fail_validation = Validation.fail(['error'])
        assert fail_validation.to_maybe() == Maybe.nothing()

    test()


# Generated at 2022-06-24 00:53:12.468740
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation.
    """
    success_value = Validation.success().to_box().unbox()
    assert success_value is None

    fail_value = Validation.fail(['fail']).to_box().unbox()
    assert fail_value is None

    success_value = Validation.success(True).to_box().unbox()
    assert success_value is True

    fail_value = Validation.fail(['fail']).to_box().unbox()
    assert fail_value is None


# Generated at 2022-06-24 00:53:18.186040
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    validation = Validation.success(1)
    maybe = validation.to_maybe()
    assert maybe == Maybe.just(1)

    validation = Validation.fail()
    maybe = validation.to_maybe()
    assert maybe == Maybe.nothing()


# Generated at 2022-06-24 00:53:21.504957
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('ok')) == 'Validation.success[ok]'
    assert str(Validation.fail(['error1', 'error2'])) == 'Validation.fail[None, [\'error1\', \'error2\']]'


# Generated at 2022-06-24 00:53:26.818142
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success('foo').is_success()
    assert not Validation.success().is_fail()

    assert not Validation.fail(['bar']).is_success()
    assert Validation.fail(['bar']).is_fail()



# Generated at 2022-06-24 00:53:30.370759
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(2).is_success() == True
    assert Validation.success(None).is_success() == True
    assert Validation.fail([1, 2]).is_success() == False


# Generated at 2022-06-24 00:53:32.217074
# Unit test for method map of class Validation
def test_Validation_map():
    # Mapping function should return new Validation with mapped value and previous errors
    assert Validation.success(1).map(lambda x: x + 1) == Validation(2, [])


# Generated at 2022-06-24 00:53:38.589672
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Validation.success(3).to_box() == Box(3)
    assert Validation.success('something').to_box() == Box('something')
    assert Validation.fail().to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:43.809802
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    lazy = Validation.success().to_lazy()
    try:
        assert isinstance(lazy, Lazy)
        assert isinstance(lazy(), Try)
        assert lazy().is_success()
        assert lazy().value() is None
    except AssertionError:
        print(lazy)
        print(lazy().value)


# Generated at 2022-06-24 00:53:49.719173
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try().value == 1
    assert Validation.success(1).to_try().is_success() == True

    assert Validation.fail([2]).to_try().value == None
    assert Validation.fail([2]).to_try().is_success() == False


# Generated at 2022-06-24 00:53:51.318990
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1]).map(lambda x: x + 1) == Validation.fail([1])


# Generated at 2022-06-24 00:53:58.533376
# Unit test for method map of class Validation
def test_Validation_map():
    # when
    validation = Validation.success(5)
    # and
    validation2 = validation.map(lambda v: v + 1)
    # then
    assert validation2 == Validation.success(6)
    # when
    validation = Validation.fail([5])
    # and
    validation2 = validation.map(lambda v: v + 1)
    # then
    assert validation2 == Validation.fail([5])


# Generated at 2022-06-24 00:54:03.749871
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    @Validate(lambda x: x > 0, lambda x: x)
    def counter(x):
        return x - 1

    assert counter(0) == Validation.fail([0])
    assert counter(0).to_try() == Try.fail(0)
    assert counter(1).to_try() == Try.success(0)



# Generated at 2022-06-24 00:54:09.616475
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def folder(value):
        return Try(value + 1, value != 0)

    test_cases = [(Validation.success(2), 3), (Validation.fail([1, 2]), None)]
    for test_case, expected in test_cases:
        result = test_case.bind(folder)
        assert result.is_success() == expected[0]
        assert result.value == expected[1]
