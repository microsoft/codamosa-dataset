

# Generated at 2022-06-24 00:44:14.996354
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:44:24.028574
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.either import Either
    from pymonet.monad_list import List
    from pymonet.optional import Optional
    from pymonet.monad_try import Try

    assert Validation.success(1).is_fail() == False
    assert Validation.success([1, 2]).is_fail() == False
    assert Validation.fail([1]).is_fail() == True
    assert Validation.fail([1, 2]).is_fail() == True
    assert Validation.success(Either.success(1)).is_fail() == False
    assert Validation.success(Either.fail(1)).is_fail() == False
    assert Validation.success(List.success([1, 2])).is_fail() == False
    assert Validation.success(List.fail([1])).is_fail() == False
   

# Generated at 2022-06-24 00:44:25.960960
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(2).to_maybe() == Maybe.just(2)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:44:30.713886
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.monad_try import Try

    assert Validation.success(1).is_success()
    assert not Validation.fail([].append(1)).is_success()

    assert not Validation.success(1).ap(lambda f: Validation.fail([f].append(2))).is_success()
    assert not Validation.success(1).ap(lambda f: Validation.fail([f].append(2))).is_success()

    assert not Validation.fail([1]).is_success()
    assert not Validation.fail([1]).ap(lambda f: Validation.fail([f].append(2))).is_success()

    assert not Validation.fail([1]).ap(lambda f: Validation.fail([f].append(2))).is_success()
    assert not Validation.fail([1]).ap

# Generated at 2022-06-24 00:44:35.578433
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Validation.fail(['error1', 'error2']).to_maybe() == Nothing()
    assert Validation.success('ok').to_maybe() == Just('ok')


# Generated at 2022-06-24 00:44:42.673989
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success('2') == Validation.success('2')
    assert Validation.fail('2', ['error']) == Validation.fail('2', ['error'])
    assert Validation.fail(None, ['error']) == Validation.fail(None, ['error'])
    assert Validation.success('1') != Validation.success('2')
    assert Validation.fail('2') != Validation.fail('2', ['error'])
    assert Validation.fail('2', ['error1']) != Validation.fail('2', ['error2'])


# Generated at 2022-06-24 00:44:45.987797
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    - It should return string fmt for success validation.
    - It should return string fmt for fail validation.
    """
    assert str(Validation(30, [])) == 'Validation.success[30]'
    assert str(Validation(30, [30])) == 'Validation.fail[30, [30]]'


# Generated at 2022-06-24 00:44:50.480447
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)

# Generated at 2022-06-24 00:44:53.393920
# Unit test for constructor of class Validation
def test_Validation():
    val = Validation(1, ['a'])

    assert val.value == 1
    assert val.errors == ['a']


# Generated at 2022-06-24 00:44:55.791438
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # Should return Right monad with value
    assert Validation.success(999).to_either() == Right(999)

    # Should return Left monad with errors list
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:45:01.740278
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation_success_value = Validation.success(value=True)
    assert str(validation_success_value) == 'Validation.success[True]'

    validation_fail_value = Validation.fail(errors=[False, True, False])
    assert str(validation_fail_value) == 'Validation.fail[None, [False, True, False]]'


# Generated at 2022-06-24 00:45:06.043186
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation(None, []).to_try() == Success(None)
    assert Validation(1, []).to_try() == Success(1)
    assert Validation(None, ['not valid']).to_try() == Failure('not valid')
    assert Validation(None, ['not valid', 'other error']).to_try() == Failure('not valid', 'other error')



# Generated at 2022-06-24 00:45:08.671437
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Right, Left

    valid = Validation.success(42)
    assert valid.to_either() == Right(42)

    invalid = Validation.fail(['a', 'b'])
    assert invalid.to_either() == Left(['a', 'b'])


# Generated at 2022-06-24 00:45:12.562477
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, ['fail']) == Validation.fail(['fail'])
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(1) != Validation(2, [])


# Generated at 2022-06-24 00:45:15.282477
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(3).to_either() == Right(3)
    assert Validation.fail(['1', '2']).to_either() == Left(['1', '2'])
    

# Generated at 2022-06-24 00:45:19.946944
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """Unit test for method __str__ of class Validation"""
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:45:25.762773
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.monad_try import TryError

    validation = Validation.success(1)
    assert Validation.success(1) == validation.to_try()

    validation = Validation.fail('error')
    assert Validation.fail('error') == validation.to_try().to_validation()

# Generated at 2022-06-24 00:45:27.740104
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.task import Task

    def f(x):
        return Validation.success(x + 1)

    assert Validation.success(1).bind(f).value == 2
    assert Validation.success(1).bind(lambda x: Task.of(Validation.success(x + 1))).value == 2



# Generated at 2022-06-24 00:45:30.831472
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test Validation bind method.

    :returns: True if test passes
    :rtype: Boolean
    """
    # Given
    validation = Validation.success(10)
    def upper_five(value):
        return value >= 5

    # When
    result = validation.bind(upper_five)

    # Then
    assert True == result

    # Given
    validation = Validation.fail([1, 2, 3])
    def upper_five(value):
        return value >= 5

    # When
    result = validation.bind(upper_five)

    # Then
    assert True != result


# Generated at 2022-06-24 00:45:32.223370
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)

# Generated at 2022-06-24 00:45:38.777239
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    assert Validation.success(10).to_either() == Right(10)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.fail(10).to_either() == Left(10)
    assert Validation.fail(None).to_either() == Left(None)
    assert Validation.fail([]).to_either() == Left([])


# Generated at 2022-06-24 00:45:41.927199
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail().to_box() == Box(None)


# Generated at 2022-06-24 00:45:52.303259
# Unit test for method ap of class Validation
def test_Validation_ap():
    # GIVEN
    val1 = Validation.success(5)
    val2 = Validation.fail(['error'])
    val3 = Validation.success([1, 2, 3])
    func1 = lambda x: Validation.success(x + 5)
    func2 = lambda y: Validation.success(y + 2)
    func3 = lambda z: Validation.fail(['error2'])
    # WHEN
    result1 = val1.ap(func1)
    result2 = val2.ap(func2)
    result3 = val3.ap(func3)
    # THEN
    assert result1 == Validation.success(10)
    assert result2 == Validation.fail(['error'])
    assert result3 == Validation.fail([1, 2, 3, 'error2'])


#

# Generated at 2022-06-24 00:45:55.918536
# Unit test for constructor of class Validation
def test_Validation():
    validation_a = Validation.success(1)
    validation_b = Validation.fail([2])

    assert validation_a == validation_a
    assert validation_b == validation_b
    assert validation_a != validation_b


# Generated at 2022-06-24 00:46:02.362617
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for to_try method of Validation class"""
    success_validation = Validation.success(1)
    fail_validation = Validation.fail()

    assert success_validation.to_try().is_success() == True
    assert success_validation.to_try().value == 1

    assert fail_validation.to_try().is_success() == False
    assert fail_validation.to_try().value == None



# Generated at 2022-06-24 00:46:13.416732
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation.
    """
    from pymonet.functor_list import List

    def inc(a):
        return a + 1
    assert Validation.success(5).bind(inc) == Validation.success(6)
    assert Validation.fail(['error 1', 'error 2']).bind(inc) == Validation.fail(['error 1', 'error 2'])

    def f_map(a):
        return Validation.fail(['error 3', 'error 4'])
    assert Validation.success(5).bind(f_map) == Validation.fail(['error 3', 'error 4'])
    assert Validation.fail(['error 1', 'error 2']).bind(f_map) == Validation.fail(['error 1', 'error 2'])


# Generated at 2022-06-24 00:46:19.571721
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    """
    It calls to_box method of Validation class with success and fail Validations.
    """
    print('test_to_box')

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail('err').to_box() == Box(None)

# Generated at 2022-06-24 00:46:26.991610
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success().value is None
    assert Validation.success(10).value == 10
    assert Validation.success(10).is_success()
    assert Validation.fail().is_fail()
    assert Validation.fail().value is None
    assert Validation.fail(['error']).is_fail()
    assert Validation.fail(['error']).value is None
    assert Validation.fail(['error']).errors == ['error']



# Generated at 2022-06-24 00:46:30.702811
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Unit test for method ap of class Validation.

    :returns: None
    :rtype: None
    """
    def test_fn(x):
        if x < 4:
            return Validation.fail([x])
        return Validation.success(x)

    test_fail = Validation.fail([1, 2, 3]).ap(test_fn)
    test_success = Validation.success(4).ap(test_fn)

    assert test_fail == Validation.fail([1, 2, 3, 1, 2, 3])
    assert test_success == Validation.success(4)

# Generated at 2022-06-24 00:46:33.904338
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success('value') == Validation('value', [])
    assert not Validation.fail([]) == Validation.fail(['e1'])


# Generated at 2022-06-24 00:46:42.296040
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    """Unit test for constructor of class Validation"""

    validation = Validation.success()
    assert validation.value is None
    assert validation.errors == []

    validation = Validation.success(1)
    assert validation.value == 1
    assert validation.errors == []

    validation = Validation.fail()
    assert validation.value is None
    assert validation.errors == []

    validation = Validation.fail([1, 2, 3])
    assert validation.value is None
    assert validation.errors == [1, 2, 3]


# Generated at 2022-06-24 00:46:45.313486
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:46:49.565947
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    @Lazy
    def monad_function():
        return Validation(1, [])
    assert monad_function.get() == Validation(1, [])
    assert monad_function() == Validation(1, [])


# Generated at 2022-06-24 00:46:55.320108
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    success_validation = Validation(1, [])
    fail_validation = Validation(1, [1])
    from pymonet.either import Left, Right
    assert success_validation.to_either() == Right(1)
    assert fail_validation.to_either() == Left([1])



# Generated at 2022-06-24 00:47:04.235008
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Validation.success("Success") == Validation("Success", [])
    assert Validation.fail("Fail") == Validation(None, ["Fail"])

    assert Validation("Success", []).is_success() is True
    assert Validation("Fail", ["Fail"]).is_success() is False

    assert Validation("Success", []).is_fail() is False
    assert Validation("Fail", ["Fail"]).is_fail() is True

    assert Validation("Success", []).map(lambda x: x+x) == Validation("SuccessSuccess", [])
    assert Validation("Success", []).bind(lambda x: Validation.success(x+x)) == Validation("SuccessSuccess", [])


# Generated at 2022-06-24 00:47:07.489185
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation(1, ["Error"])
    assert "Validation.fail[1, ['Error']]" == str(validation)

    validation = Validation(1, [])
    assert "Validation.success[1]" == str(validation)


# Generated at 2022-06-24 00:47:11.620020
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(100) == Validation(100, [])
    assert Validation.fail(["some error"]) == Validation(None, ["some error"])

    assert Validation.success(100).value == 100
    assert Validation.fail(["some error"]).errors == ["some error"]



# Generated at 2022-06-24 00:47:20.578115
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    # GIVEN
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe

    # WHEN
    validation = Validation.success(4)
    validation_fail = Validation.fail(['error'])
    validation_with_error_as_error = Validation.fail([ValueError('error')])

    # THEN
    assert validation.to_either() == Right(4)
    assert validation_fail.to_either() == Left(['error'])
    assert validation_with_error_as_error.to_either() == Left([ValueError('error')])
    validation_to_either = validation.to_either().to_try()
    assert isinstance(validation_to_either, Try)
    assert validation_to_either

# Generated at 2022-06-24 00:47:27.305889
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for method __str__ of class Validation
    """
    validation = Validation.success(1)
    assert str(validation) == 'Validation.success[1]'

    validation = Validation.fail(['error'])
    assert str(validation) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-24 00:47:34.842550
# Unit test for method ap of class Validation
def test_Validation_ap():
    n = Validation.fail([1, 2]).ap(lambda x: Validation.success(x + 1))
    m = Validation.success(2).ap(lambda x: Validation.fail([3, 4]))

    assert n == Validation(None, [1, 2])
    assert m == Validation(2, [3, 4])

# Generated at 2022-06-24 00:47:41.095016
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left

    # Test Error handling
    assert Validation.success(2).bind(lambda x: Right(x + 3)) == Right(5)
    assert Validation.success(2).bind(lambda x: Left(x + 3)) == Left(5)

    # Test Integer
    assert Validation.success(2).bind(lambda x: Right(x + 3)) == Right(5)

    # Test String
    assert Validation.success("foo").bind(lambda x: Right(x + "bar")) == Right("foobar")
    assert Validation.success("foo").bind(lambda x: Right(x + "bar")) == Right("foobar")


# Generated at 2022-06-24 00:47:44.719393
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success('value')) == 'Validation.success[value]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-24 00:47:46.404988
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    success_validation = Validation.success('value')
    assert (success_validation.to_maybe() == Maybe.just('value'))

    fail_validation = Validation.fail(['error'])
    assert (fail_validation.to_maybe() == Maybe.nothing())


# Generated at 2022-06-24 00:47:49.917600
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Assert that Validation.to_box() returns Box with validation value.
    """

    from pymonet.box import Box

    # Box with string value
    assert Validation.success('pymonet').to_box() == Box('pymonet')

    # Empty box
    assert Validation.fail().to_box() == Box(None)

# Unit tests for method to_try of class Validation

# Generated at 2022-06-24 00:47:54.418885
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    """
    Unit test for constructor of class Validation
    """
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.success() == Validation(None, [])
    assert Validation.fail() == Validation.fail([])
    assert Validation.success(10) == Validation(10, [])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])


# Generated at 2022-06-24 00:48:02.583321
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Method bind of class Validation
    """
    def validator_fail(value):
        """
        Function that returns failed Validation when value isn't int.
        """
        from pymonet.either import Left, Right

        try:
            int(value)
        except:
            return Validation.fail(['Int error'])
        return Validation.success(value)

    def validator_success(value):
        """
        Function that returns successful Validation when value is int.
        """
        from pymonet.either import Left, Right

        try:
            int(value)
        except:
            return Validation.fail(['Int error'])
        return Validation.success(int(value))

    # bind should return Validation with value from folder function

# Generated at 2022-06-24 00:48:07.673409
# Unit test for constructor of class Validation
def test_Validation():
    """
    :return: None
    """
    assert Validation(1, []).is_success() == True
    assert Validation(1, [1]).is_success() == False
    assert Validation(1, []).is_fail() == False
    assert Validation(1, [1]).is_fail() == True


# Generated at 2022-06-24 00:48:09.561549
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(10).is_fail() is False
    assert Validation.fail([1]).is_fail() is True


# Generated at 2022-06-24 00:48:11.716324
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('value').is_success() is True
    assert Validation.fail(['error']).is_success() is False


# Generated at 2022-06-24 00:48:14.826207
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, ['error1', 'error2'])) == 'Validation.fail[1, [\'error1\', \'error2\']]'

# Generated at 2022-06-24 00:48:19.588422
# Unit test for method bind of class Validation
def test_Validation_bind():
    def fn(value):
        if value == 8:
            return Validation.success(value * 2)
        return Validation.fail(['Not correct value'])

    assert Validation.fail(['a', 'b']).bind(fn) == Validation.fail(['a', 'b'])
    assert Validation.success(8).bind(fn) == Validation.success(16)
    assert Validation.success(9).bind(fn) == Validation.fail(['Not correct value'])


# Generated at 2022-06-24 00:48:24.059554
# Unit test for constructor of class Validation
def test_Validation():
    """
    Unit test for validation constructor.
    """
    assert Validation(1, []) == Validation(1, [])


# Generated at 2022-06-24 00:48:30.321488
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation.success(Box(1))
    assert validation.to_box() == Box(Box(1))

    validation = Validation.success(1)
    assert validation.to_box() == Box(1)

    validation = Validation.fail([1])
    assert validation.to_box() == Box(None)



# Generated at 2022-06-24 00:48:37.314240
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Unit test for Validation.ap method."""
    assert Validation.success(1).ap(Validation.success(lambda x: x + 1)) == Validation.success(2)
    assert Validation.fail('failed').ap(Validation.success(lambda x: x + 1)) == Validation.fail('failed')
    assert Validation.fail(['input is not number']).ap(Validation.fail(['authorization failed'])) == Validation.fail(['input is not number', 'authorization failed'])

# Generated at 2022-06-24 00:48:40.189611
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation('test', []).to_either() == Right('test')
    assert Validation(None, ['fail']).to_either() == Left(['fail'])


# Generated at 2022-06-24 00:48:50.590546
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(None) == Validation.success(None)
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.success(1) != Validation.success(None)
    assert Validation.fail([]) != Validation.success(None)
    assert Validation.fail([1, 2]) != Validation.fail([])
    assert Validation.success(1) != Validation.fail([])


# Generated at 2022-06-24 00:48:54.862928
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(0, []) == Validation.success(0)
    assert Validation(None, [1]) == Validation.fail([1])



# Generated at 2022-06-24 00:49:05.417129
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation(None, []) == Validation(None, [])
    assert Validation('A', []) == Validation('A', [])
    assert Validation(False, []) == Validation(False, [])

    assert Validation(None, ['Some error']) != Validation(None, [])
    assert Validation(None, ['Some error']) != Validation(None, ['Some error'])
    assert Validation('A', ['Some error']) != Validation('A', [])
    assert Validation('A', ['Some error']) != Validation('A', ['Some error'])
    assert Validation(False, ['Some error']) != Validation(False, [])
    assert Validation(False, ['Some error']) != Validation(False, ['Some error'])


# Unit

# Generated at 2022-06-24 00:49:12.698408
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right

    assert Validation.success(42).bind(lambda v: Left(v)) == Left(42)
    assert Validation.success(42).bind(lambda v: Right(v)) == Right(42)
    assert Validation.fail(['err1', 'err2']).bind(lambda v: Left(v)) == Left(None)
    assert Validation.fail(['err1', 'err2']).bind(lambda v: Right(v)) == Right(None)


# Generated at 2022-06-24 00:49:14.451999
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.try_ import Success, Failure

    assert Validation.success(4).to_try() == Success(4)
    assert Validation.fail([]).to_try() == Failure(None, True)


# Generated at 2022-06-24 00:49:16.218335
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:49:20.631830
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success("abc").map(lambda x: x + "def") == Validation.success("abcdef")
    assert Validation.success("abc").map(lambda x: x + "def").value == "abcdef"
    assert Validation.fail(['error']).map(lambda x: x + "def") == Validation.fail(['error'])
    assert Validation.fail(['error']).map(lambda x: x + "def").value is None


# Generated at 2022-06-24 00:49:23.313415
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == "Validation.success[1]"
    assert str(Validation.fail(["error"])) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-24 00:49:28.056964
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left
    from pymonet.monad_try import Try

    assert Validation.success(10) == Validation(10, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail(['error 1']) == Validation(None, ['error 1'])
    assert Validation.fail(['error 1', 'error 2']) == Validation(None, ['error 1', 'error 2'])
    assert Validation.fail(['error 3', 'error 1', 'error 2']) == Validation(None, ['error 3', 'error 1', 'error 2'])


# Generated at 2022-06-24 00:49:38.751255
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(1, []) == Validation(1, [])
    assert Validation(1, [1]) == Validation(1, [1])
    assert Validation(1, [1, 2]) == Validation(1, [1, 2])
    assert Validation(None, [1, 2]) == Validation(None, [1, 2])
    assert Validation(1, []) != Validation(2, [])
    assert Validation(1, [1]) != Validation(1, [])
    assert Validation(1, [1, 2]) != Validation(1, [2, 1])
    assert Validation(None, [1, 2]) != Validation(None, [1])


# Generated at 2022-06-24 00:49:42.829753
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation_success = Validation.success()
    assert validation_success.is_success() and validation_success.is_fail() is False
    validation_fail = Validation.fail(["error"])
    assert validation_fail.is_success() is False and validation_fail.is_fail()



# Generated at 2022-06-24 00:49:48.342010
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test of method to_maybe of class Validation
    """
    from pymonet.maybe import Maybe

    assert Validation.success(value='A').to_maybe() == Maybe.just('A')
    assert Validation.fail(['a']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:49:54.140586
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success().is_fail()
    assert not Validation.success(1).is_fail()
    assert not Validation.success('a').is_fail()
    assert Validation.fail().is_fail()
    assert Validation.fail([1]).is_fail()
    assert Validation.fail(['a']).is_fail()


# Generated at 2022-06-24 00:49:59.853524
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    """Unit test for method __str__ of class Validation."""
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['foo'])) == 'Validation.fail[None, [\'foo\']]'


# Generated at 2022-06-24 00:50:02.834612
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    assert Validation.success(10).to_try() == Success(10)
    assert Validation.fail([10, 20]).to_try() == Failure([10, 20])


# Generated at 2022-06-24 00:50:05.205456
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, ['error'])) == 'Validation.fail[1, [\'error\']]'


# Generated at 2022-06-24 00:50:09.847095
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    validations_values = Validation.success(5).to_box()
    validations_errors = Validation.fail([5]).to_box()

    assert validations_values == Box(5)
    assert validations_errors == Box(None)


# Generated at 2022-06-24 00:50:15.151932
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    value = 'hola'
    assert Validation.success(value).to_try() == Try(value, is_success=True)
    assert Validation.fail(['error']).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:50:22.976722
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1).to_lazy()

    assert validation.get() == 1

    from pymonet import Lazy
    from pymonet.monad_try import Try

    validation = Validation.fail([1, 2]).to_lazy()

    assert validation == Lazy(lambda: None)

    validation = validation.map(lambda x: Try(x, is_success=False))

    assert validation == Lazy(lambda: None)

    validation = validation.map(lambda x: Try([1, 2], is_success=False))

    assert validation == Lazy(lambda: [1, 2])


# Generated at 2022-06-24 00:50:25.637853
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Check that Validation value transferred to Box
    """
    from pymonet.box import Box

    validation = Validation.success(1)
    assert validation.to_box() == Box(1)



# Generated at 2022-06-24 00:50:29.233865
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1).to_box() != Box(2)
    assert Validation.fail().to_box() == Box(None)


# Generated at 2022-06-24 00:50:35.291715
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    print(Validation.success(22))
    print(Validation.fail([1, 2]))

    assert str(Validation.success(22)) == 'Validation.success[22]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:50:41.545845
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    def to_maybe_success(): return Validation.success('Success').to_maybe()
    def to_maybe_fail(): return Validation.fail(['Error']).to_maybe()

    assert isinstance(to_maybe_success(), Maybe)
    assert to_maybe_success() == Maybe.just('Success')
    assert to_maybe_fail().is_nothing()


# Generated at 2022-06-24 00:50:49.386354
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    success_case = Validation.success(1)
    fail_case = Validation.fail(['fail'])

    assert success_case.to_lazy() == Lazy(lambda: 1), 'Validation to Lazy for success case failed'
    assert fail_case.to_lazy() == Lazy(lambda: None), 'Validation to Lazy for fail case failed'


# Generated at 2022-06-24 00:50:56.213254
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    validation = Validation.success(1)
    assert isinstance(validation.to_maybe(), Maybe)
    assert validation.to_maybe().is_just()
    assert validation.to_maybe().get() == 1

    validation = Validation.fail([])
    assert isinstance(validation.to_maybe(), Maybe)
    assert validation.to_maybe().is_nothing()



# Generated at 2022-06-24 00:51:03.609138
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():

    def test_is_fail_returns_true_for_errors():
        assert_that(Validation.fail(errors=[1, 2]).is_fail(), is_(True))

    def test_is_fail_returns_false_for_empty_errors():
        assert_that(Validation.success().is_fail(), is_(False))

    def test_is_fail_returns_false_for_false():
        assert_that(Validation.success(False).is_fail(), is_(False))

    def test_is_fail_returns_false_for_true():
        assert_that(Validation.success(True).is_fail(), is_(False))

    test_is_fail_returns_true_for_errors()
    test_is_fail_returns_false_for_empty_errors()
    test_

# Generated at 2022-06-24 00:51:06.882169
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 'value'
    validation = Validation.success(value)
    assert validation.to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-24 00:51:15.450784
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from pymonet import Validation

    validation = Validation.success('value')
    assert str(validation) == 'Validation.success[value]'

    validation = Validation.fail()
    assert str(validation) == 'Validation.fail[None, []]'

    validation = Validation.fail([1, 2, 3])
    assert str(validation) == 'Validation.fail[None, [1, 2, 3]]'

    validation = Validation.fail([])
    assert str(validation) == 'Validation.fail[None, []]'


# Generated at 2022-06-24 00:51:20.040119
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation_success = Validation.success(1)

    assert validation_success.to_lazy().get() == 1

    validation_fail = Validation.fail(['error1', 'error2'])

    assert validation_fail.to_lazy().get() == None

    validation_without_value = Validation(None, ['error1'])

    assert validation_without_value.to_lazy().get() == None

# Generated at 2022-06-24 00:51:24.275156
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert (Validation(42, []) == Validation.success(42).to_lazy().get().to_validation())

# Generated at 2022-06-24 00:51:27.708621
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])



# Generated at 2022-06-24 00:51:31.361899
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:51:35.729685
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.fail([]).is_success() == False
    assert Validation.fail(['BAD']).is_success() == False
    assert Validation.success(None).is_success() == True
    assert Validation.success('OK').is_success() == True


# Generated at 2022-06-24 00:51:42.323549
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation([], [])) == 'Validation.success[[]]'
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(None, ['error'])) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-24 00:51:43.391431
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    def get_result():
        return Validation.success(1) != Validation.success(2)

    assert True == get_result()



# Generated at 2022-06-24 00:51:53.619360
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    from pymonet.monad_try import Try

    success = Validation.success(1)
    assert success == Validation(1, [])

    fail = Validation.fail(['something'])
    assert fail == Validation(None, ['something'])

    try_success = Try(1)
    success = success.ap(try_success.to_validation)
    assert success == Validation(1, [])

    try_fail = Try.fail(['something'])
    fail = fail.ap(try_fail.to_validation)
    assert fail == Validation(None, ['something'])

    success = success.map(lambda x: x + 1)
    assert success == Validation(2, [])

    fail = fail.map(lambda x: x + 1)
    assert fail

# Generated at 2022-06-24 00:51:56.020436
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(["error"]).is_fail()
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-24 00:52:02.334705
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():

    from pymonet.either import Left, Right
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_lazy import Lazy

    # test for successful validation
    validation = Validation('value', [])
    assert validation.to_lazy() == Lazy(lambda: 'value')

    # test for failed validation
    validation = Validation('value', [1,2,3])
    assert validation.to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-24 00:52:04.237913
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(5).to_box() == Box(5)

# Generated at 2022-06-24 00:52:05.679891
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('value').is_success() is True, 'Validation.success().is_success() must be True'



# Generated at 2022-06-24 00:52:10.042186
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('foo') == Validation('foo', [])
    assert Validation.fail(['foo']) == Validation(None, ['foo'])



# Generated at 2022-06-24 00:52:13.452237
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Method __eq__ should return True when two Validation instances has same value and errors.
    """
    assert Validation.success(value=1) == Validation.success(value=1)
    assert Validation.fail(errors=[1, 2]) == Validation.fail(errors=[1, 2])


# Generated at 2022-06-24 00:52:16.532571
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.fail(['a']).is_fail()
    assert Validation.fail(['e1']).is_fail()



# Generated at 2022-06-24 00:52:22.138242
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    v1 = Validation.success('foo')
    assert str(v1) == "Validation.success['foo']"

    v2 = Validation.fail(['error_1', 'error_2'])
    assert str(v2) == "Validation.fail[None, ['error_1', 'error_2']]"


# Generated at 2022-06-24 00:52:31.061518
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try

    def validate_username(username):
        """
        It takes username as a parameter and returns Validation with failure errors
        when username has less than 4 symbols.

        :param username: username
        :type username: str
        :returns: Validation with username or failure errors
        :rtype: Validation[str, str]
        """
        if len(username) < 4:
            return Validation.fail(['username is too short'])
        return Validation.success(username)


# Generated at 2022-06-24 00:52:41.040335
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.box import Box
    from pymonet.either import Right
    assert Validation(42, []).to_lazy() == Lazy(lambda: 42)
    assert Validation('hello', []).to_lazy() == Lazy(lambda: 'hello')
    assert Validation(Try(42), []).to_lazy() == Lazy(lambda: Try(42))
    assert Validation(Maybe.just(42), []).to_lazy() == Lazy(lambda: Maybe.just(42))
    assert Validation(Box(42), []).to_lazy() == Lazy(lambda: Box(42))

# Generated at 2022-06-24 00:52:50.598885
# Unit test for method map of class Validation
def test_Validation_map():
    # Given
    test_data = [
        {
            'value': {
                'mapper': lambda x: x + 1,
                'v': Validation.success(1),
                'exp': Validation.success(2)
            }
        },
        {
            'value': {
                'mapper': lambda x: x + 1,
                'v': Validation.fail(['first']),
                'exp': Validation.fail(['first'])
            }
        }
    ]

    for test in test_data:
        yield check_Validation_map, test['value']['mapper'], test['value']['v'], test['value']['exp']


# Generated at 2022-06-24 00:52:56.680843
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert str(Validation(123, [1, 2, 3])) == 'Validation.fail[123, [1, 2, 3]]'
    assert str(Validation(False, [])) == 'Validation.success[False]'
    assert str(Validation(None, [1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'
    assert str(Validation(123, [])) == 'Validation.success[123]'


# Generated at 2022-06-24 00:53:02.319022
# Unit test for constructor of class Validation
def test_Validation():
    success = Validation.success(55)
    assert success.value == 55
    assert success.errors == []

    fail = Validation.fail([1, 2])
    assert fail.value is None
    assert fail.errors == [1, 2]


# Generated at 2022-06-24 00:53:09.683918
# Unit test for constructor of class Validation
def test_Validation():

    def test_success_constructor():
        success = Validation.success(1)
        assert success == Validation(1, [])

    def test_fail_constructor():
        fail = Validation.fail([1, 'error'])
        assert fail == Validation(None, [1, 'error'])

    test_success_constructor()
    test_fail_constructor()


# Generated at 2022-06-24 00:53:16.087626
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    value = 1
    validation = Validation(value, [])

    assert validation.to_maybe() == Just(value)

    validation = Validation(None, [1, 2, 3])
    assert validation.to_maybe() == Nothing()

# Generated at 2022-06-24 00:53:21.729731
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(5) == Validation(5, [])
    assert Validation.success(5) == Validation(5, [])
    assert Validation.success(5) == Validation(5, [])
    assert Validation.fail([1, 2, 3]) == Validation(None, [1, 2, 3])


# Unit tests for bind methods of class Validation

# Generated at 2022-06-24 00:53:30.021018
# Unit test for method __str__ of class Validation
def test_Validation___str__():
  # Arrange
  expected_result = 'Validation.success[success]'
  test_val = Validation.success('success')

  # Act
  result = str(test_val)

  # Assert
  assert result == expected_result

  # Arrange
  expected_result = 'Validation.fail[None, [\'error1\', \'error2\']]'
  test_val = Validation.fail(['error1', 'error2'])

  # Act
  result = str(test_val)

  # Assert
  assert result == expected_result


# Generated at 2022-06-24 00:53:33.273950
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    validation = Validation.success(1)
    assert isinstance(validation.to_either(), Right)
    assert validation.to_either().value == 1

    validation = Validation.fail([1, 2, 3])
    assert isinstance(validation.to_either(), Left)
    assert validation.to_either().value == [1, 2, 3]



# Generated at 2022-06-24 00:53:37.102329
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('foo') == Validation('foo', [])
    assert Validation.fail(['foo']) == Validation(None, ['foo'])
    assert Validation.fail() == Validation(None, [])


# Generated at 2022-06-24 00:53:40.335005
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success("test").map(lambda value: value.upper()) == Validation("TEST", [])


# Generated at 2022-06-24 00:53:43.540862
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail(['test']).to_either() == Left(['test'])


# Generated at 2022-06-24 00:53:49.019414
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Validation.success(9).to_either() == Right(9)
    assert Validation.fail(['name is required']).to_either() == Left(['name is required'])

# Generated at 2022-06-24 00:53:52.551997
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map of class Validation.
    """
    f = lambda x: x + 2
    assert Validation.success(1).map(f) == Validation.success(3)
    assert Validation.fail([1]).map(f) == Validation.fail([1])


# Generated at 2022-06-24 00:53:58.577720
# Unit test for method to_box of class Validation
def test_Validation_to_box():

    from pymonet.box import Box
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_box() == Box(5)
    assert Validation.fail([1, 2, 3, 4]).to_box() == Box(None)

    assert Validation.success(Maybe.just(5)).to_box() == Box(Maybe.just(5))
    assert Validation.fail([1, 2, 3, 4]).to_box() == Box(None)


# Generated at 2022-06-24 00:54:08.032005
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.validation import Validation
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.success('').to_maybe() == Maybe.just('')
    assert Validation.success(None).to_maybe() == Maybe.just(None)

    assert Validation.fail([5]).to_maybe() == Maybe.nothing()
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()
    assert Validation.fail([None]).to_maybe() == Maybe.nothing()
    assert Validation.fail(['']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:54:13.973679
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from unittest.mock import MagicMock
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    # Handle Successful Validation
    mock_maybe = MagicMock(spec=Maybe)
    validation = Validation.success(mock_maybe)
    returned_maybe = validation.to_maybe()
    assert mock_maybe == returned_maybe

    # Handle Failed Validation
    mock_try = MagicMock(spec=Try)
    validation = Validation.fail([mock_try])
    returned_maybe = validation.to_maybe()
    assert Maybe.nothing() == returned_maybe
