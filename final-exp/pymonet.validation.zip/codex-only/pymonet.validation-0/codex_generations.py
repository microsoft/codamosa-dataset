

# Generated at 2022-06-24 00:44:22.554518
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure
    from pymonet.monad_try import Success

    assert Validation.success(10).to_try() == Try.success(10)
    assert Validation.fail().to_try() == Try.failure()
    assert Validation.fail(['error1', 'error2']).to_try() == Try.failure(['error1', 'error2'])

    assert Validation.success(10).to_try().is_success() == True
    assert Validation.fail().to_try().is_success() == False
    assert Validation.fail(['error1', 'error2']).to_try().is_success() == False

    assert Validation.success(10).to_try().is_failure() == False

# Generated at 2022-06-24 00:44:28.336603
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from functools import partial

    assert Validation(1, []) == Validation.success(1)
    assert Validation(None, [1]) == Validation.fail([1])
    assert Validation(None, [1, 2]) != Validation.fail([1])
    assert Validation(1, []) == Validation.success(1)
    assert Validation(1, []) != Validation.success(2)
    assert Validation.success(2).value == 2
    assert Validation.fail([1]).errors == [1]
    assert Validation.fail([1]).value is None

# Generated at 2022-06-24 00:44:34.081342
# Unit test for method map of class Validation
def test_Validation_map():
    def add_one(num):
        return num + 1

    validation = Validation.success(1)
    assert validation.map(add_one) == Validation(2, [])

    validation = Validation.fail()
    assert validation.map(add_one) == Validation(None, [])



# Generated at 2022-06-24 00:44:39.314555
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(['File not exists']) == Validation(None, ['File not exists'])


# Generated at 2022-06-24 00:44:45.083211
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.monad_try import Try
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    try_value = Try(1, is_success=True)
    try_with_error = Try(1, is_success=False)

    either_value = Right(1)
    either_with_error = Left(1)

    maybe_value = Maybe.just(1)
    maybe_with_error = Maybe.nothing()

    box_value = Box(1)

    lazy = Lazy(lambda: 1)

    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])

    assert Validation

# Generated at 2022-06-24 00:44:48.084260
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Testing Validation.ap method.
    """

    # given
    val1 = Validation.fail(['error1', 'error2'])
    val2 = Validation.fail(['error3', 'error4'])

    # when
    val3 = val1.ap(lambda _: val2)

    # then
    assert val3 == Validation.fail(['error1', 'error2', 'error3', 'error4'])

# Generated at 2022-06-24 00:44:52.595574
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:03.848662
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Unit test for Validation.bind"""
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    assert Validation.success(3).bind(lambda x: x * 2) == Validation.success(6)
    assert Validation.success(3).bind(lambda x: Validation.fail(['error'])) == Validation.fail(['error'])
    assert Validation.success(3).bind(lambda x: Try(x * 2)) == Validation.success(6)
    assert Validation.success(3).bind(lambda x: Try(x * 2, is_success=False)) == Validation.fail([])
    assert Validation.success(3).bind(lambda x: Right(x * 2)) == Validation.success(6)
    assert Validation.success(3).bind

# Generated at 2022-06-24 00:45:05.835588
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.to_maybe(Validation.fail(['error'])) == Maybe.nothing()
    assert Validation.to_maybe(Validation.success(True)) == Maybe.just(True)


# Generated at 2022-06-24 00:45:07.586702
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-24 00:45:12.851429
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test for Validation.ap method.
    Method ap must take as a parameter function returning another Validation.
    Function is called with Validation value and returns new Validation with previous value
    and concated new and old errors.
    """
    from pymonet.tuple import Tuple

    # Case when Validation is successful and function returns successful Validation
    def fn(x):
        return Validation.success(3)

    validation = Validation.success(1)
    result = validation.ap(fn)

    assert result == Tuple(Validation.success(3), Validation.success(3))

    # Case when Validation is successful and function returns failed Validation
    def fn(x):
        return Validation.fail([2])

    validation = Validation.success(1)
    result = validation.ap(fn)

   

# Generated at 2022-06-24 00:45:20.352457
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success().to_either() == Right(None)
    assert Validation.success('test').to_either() == Right('test')
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.fail(['err1', 'err2']).to_either() == Left(['err1', 'err2'])


# Generated at 2022-06-24 00:45:28.984541
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Tests for method is_success of class Validation.
    """
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative
    from pymonet.monad import Monad

    assert isinstance(Validation.success(5).is_success(), bool)

    assert Validation.fail([]).is_success() == False
    assert Validation.fail([1, 2]).is_success() == False

    assert Validation.success(5).is_success() == True
    assert Validation.success([]).is_success() == True
    assert Validation.success(None).is_success() == True


# Generated at 2022-06-24 00:45:31.415148
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.fail(['error1'])) == 'Validation.fail[None, [\'error1\']]'
    assert str(Validation.success('value')) == 'Validation.success[value]'


# Generated at 2022-06-24 00:45:33.660389
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[val]' == str(Validation.success('val'))
    assert 'Validation.fail[None, [1, 2]]' == str(Validation.fail([1, 2]))



# Generated at 2022-06-24 00:45:38.216537
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(10).to_maybe() == Maybe.just(10)
    assert Validation.success(None).to_maybe() == Maybe.just(None)
    assert Validation.fail([1, 2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:42.651902
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])



# Generated at 2022-06-24 00:45:52.862776
# Unit test for constructor of class Validation
def test_Validation():
    """ Test for constructor of class Validation """
    from nose.tools import assert_raises
    from pymonet.error import InvalidType, ValidationError

    # Should raise exception for wrong types
    assert_raises(InvalidType, Validation, None, None)
    assert_raises(InvalidType, Validation, None, None)

    # Should raise exception for not boolean success parameter
    assert_raises(ValidationError, Validation, None, [])

    # Should create successful Validation
    assert Validation(True, []) == Validation.success(True)
    assert Validation(True, None) == Validation.success(True)
    assert Validation(True, {}) == Validation.success(True)
    assert Validation(True, [1, 2, 3]) == Validation.success(True)

# Generated at 2022-06-24 00:46:03.129005
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Right, Left

    # Simple application
    f = lambda x: Validation.success(x)
    v = Validation.fail('Bad').ap(f)
    assert v == Validation.fail('Bad')

    # Take a value from right monad and adding it to accumulator
    def add_to_list(list_, item):
        list_.append(item)
        return Validation.success(list_)

    r = Validation.success('a').ap(lambda x: Right(add_to_list([], x)))
    assert r == Validation.success(['a'])

    # Take a value from left monad and adding it to accumulator
    def add_to_list(list_, item):
        list_.append(item)
        return Validation.success(list_)

    l

# Generated at 2022-06-24 00:46:13.985328
# Unit test for constructor of class Validation
def test_Validation():
    # pylint: disable=no-member
    assert Validation.success('foo').value == 'foo'
    assert Validation.success(['foo']).value == ['foo']
    assert Validation.success(('foo',)).value == ('foo',)
    assert Validation.success(['foo']).value == ['foo']
    assert Validation.success({'foo': 1}).value == {'foo': 1}
    assert Validation.success(set(['foo'])).value == set(['foo'])
    assert Validation.success(bytearray([1, 2, 3])).value == bytearray([1, 2, 3])

    assert Validation.fail().errors == []
    assert Validation.fail('foo').errors == ['foo']
    assert Validation.fail(['foo']).errors == ['foo']

# Generated at 2022-06-24 00:46:17.273541
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(Box(42)).to_box() == Box(42)
    assert Validation.fail([]).to_box() == Box(None)


# Generated at 2022-06-24 00:46:18.342353
# Unit test for method ap of class Validation
def test_Validation_ap():
    pass


# Generated at 2022-06-24 00:46:21.519230
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1,2,3]).is_fail() == True
    assert Validation.success(1).is_fail() == False


# Generated at 2022-06-24 00:46:24.214219
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Tests to_try validation method.
    """
    assert Validation.success(1).to_try().is_success() == True
    assert Validation.success(1).to_try().value == 1
    assert Validation.fail([1]).to_try().is_success() == False
    assert Validation.fail([1]).to_try().value is None


# Generated at 2022-06-24 00:46:28.685897
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try

    def failed(value):
        return Validation.fail([value])

    def div(value):
        def div_inner(value_inner):
            return value / value_inner
        return Try(div_inner(value)).to_validation()

    assert Validation.fail(['error']).bind(failed) == Validation.fail(['error'])
    assert Validation.success(5).bind(div) == Validation.success(5)


# Generated at 2022-06-24 00:46:40.037849
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert Validation.success(3) == Validation.success(3)
    assert Validation.success(3) != Validation.success(5)

    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail(['error1']) == Validation.fail(['error1'])
    assert Validation.fail(['error1', 'error2']) == Validation.fail(['error1', 'error2'])
    assert Validation.fail(['error1', 'error2']) != Validation.fail(['error1'])
    assert Validation.fail(['error1', 'error2']) != Validation.fail(['error2', 'error3'])


# Generated at 2022-06-24 00:46:47.087526
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test to lazy convert.
    """
    from pymonet.lazy import Lazy

    assert Validation.success('aaa').to_lazy() == Lazy(lambda: 'aaa')
    assert Validation.fail(['error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:46:53.405023
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success([1,2,3]) == Validation.success([1,2,3])
    assert Validation.fail([1,2,3]) == Validation.fail([1,2,3])
    assert Validation.fail([1,2,3]) != Validation.fail([1,2])


# Generated at 2022-06-24 00:46:56.252564
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    validation = Validation.success(10)
    assert validation.to_maybe() == Maybe.just(10)

    validation = Validation.success()
    assert validation.to_maybe() == Maybe.nothing()

    validation = Validation.fail([1])
    assert validation.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:47:00.477863
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.either import Left, Right

    assert Validation.success(1) == Validation(1, [])
    assert Validation.success().value == None
    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation.fail().errors == []
    assert Validation.fail(1).errors == [1]


# Generated at 2022-06-24 00:47:04.948374
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('value').to_box() == Box('value')
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1.1).to_box() == Box(1.1)
    assert Validation.success(1.0).to_box() == Box(1.0)



# Generated at 2022-06-24 00:47:08.519896
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    validation = Validation.fail([1, 2])
    assert validation.to_try() == Failure([1, 2])

    validation = Validation.success(1)
    assert validation.to_try() == Success(1)


# Generated at 2022-06-24 00:47:10.858844
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.fail([1]).is_success()


# Generated at 2022-06-24 00:47:14.429387
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(42).is_fail() == False
    assert Validation.success([1, 2, 3]).is_fail() == False
    assert Validation.success(True).is_fail() == False

    assert Validation.fail().is_fail() == True
    assert Validation.fail([1, 2, 3]).is_fail() == True



# Generated at 2022-06-24 00:47:18.699262
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Test Validation.to_lazy method.
    """
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert Validation.success(100).to_lazy() == Lazy(lambda: 100)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:47:21.873770
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    assert (Validation.success(12).to_lazy() == Lazy(lambda: 12))
    assert (Validation.fail(12).to_lazy() == Lazy(lambda: None))


# Generated at 2022-06-24 00:47:27.970668
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.functions import always

    assert Lazy(always(Validation.success('data'))
                .ap(lambda _: Validation.success(None))
                .to_lazy()
                .value) == Try.success('data')

    assert Lazy(always(Validation.success('data'))
                .ap(lambda _: Validation.fail(['err']))
                .to_lazy()
                .value) == Try.fail(Validation.fail(['err']).value)

    assert Lazy(Validation.success(Validation.success('data'))
                .to_lazy()
                .value) == Try.success(Validation.success('data'))


# Generated at 2022-06-24 00:47:38.231792
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Test method __eq__ of class Validation
    """
    from pymonet.either import Left, Right

    assert(Validation.success() == Validation.success())
    assert(Validation.success(4) == Validation.success(4))
    assert(Validation.fail() == Validation.fail())
    assert(Validation.fail([1, 2]) == Validation.fail([1, 2]))
    assert(Validation.success() != Validation.fail([1, 2]))
    assert(Validation.success() != Validation.success(4))
    assert(Validation.fail([1, 2]) != Validation.fail())
    assert(Validation.success(4) != Validation.success())
    assert(Validation.success(4) != Validation.fail())

# Generated at 2022-06-24 00:47:39.628794
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # Given
    v = Validation.success()

    # When
    is_fail = v.is_fail()

    # Then
    assert is_fail is False


# Generated at 2022-06-24 00:47:41.454368
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation
    """
    from pymonet.box import Box

    box = Validation.success('value').to_box()
    assert isinstance(box, Box)
    assert box.value == 'value'


# Generated at 2022-06-24 00:47:48.189433
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:47:54.135496
# Unit test for constructor of class Validation
def test_Validation():
    no_errors = Validation.success(1)
    errors = Validation.fail([1, 2, 3])
    assert no_errors == Validation.success(1)
    assert errors == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:47:55.581419
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation(1, [])
    assert Box(1) == validation.to_box()



# Generated at 2022-06-24 00:48:00.150406
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []) == Validation(1, [])
    assert Validation(None, []) == Validation(None, [])
    assert Validation(1, [1, 2]) == Validation(1, [1, 2])


# Generated at 2022-06-24 00:48:04.420311
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test for Validation.ap method.
    """
    from pymonet.either import Left

    # errors is empty
    assert Validation.success(123).ap(lambda x: Validation.success(3 * x)) == Validation.success(369)
    assert Validation.success('abc').ap(lambda x: Validation.success(x.upper())) == Validation.success('ABC')

    # errors is not empty
    assert Validation.fail(['a', 'b']).ap(lambda x: Validation.success(x.upper())) == Validation.fail(['a', 'b'])
    assert Validation.success('abc').ap(lambda x: Validation.fail(['x', 'y', 'z'])) == Validation.fail(['x', 'y', 'z'])
    assert Validation.fail

# Generated at 2022-06-24 00:48:08.722966
# Unit test for method __str__ of class Validation
def test_Validation___str__(): # pragma: no cover
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:48:12.830906
# Unit test for method to_box of class Validation
def test_Validation_to_box():

    from pymonet.box import Box
    from pymonet.validation import Validation

    # when validation is successful
    assert Validation.success(2).to_box() == Box(2)
    # when validation is failed
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-24 00:48:16.203518
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success_validation = Validation.success(2)
    assert str(success_validation) == 'Validation.success[2]'

    fail_validation = Validation.fail(['error'])
    assert str(fail_validation) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-24 00:48:19.458328
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success('foo')) == 'Validation.success[foo]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'



# Generated at 2022-06-24 00:48:21.207762
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """Unit test for method to_box of class Validation."""
    assert Validation.success("test string").to_box() == Box("test string")


# Generated at 2022-06-24 00:48:22.790103
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:48:33.585252
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation.
    """
    import unittest

    from pymonet.maybe import Maybe

    class TestValidationBind(unittest.TestCase):
        """
        Unit test for method bind of class Validation.
        """
        def test_Validation_bind_success(self):
            """
            Unit test for method bind of class Validation.
            """
            def f(value):
                """
                Success function.
                """
                return [value]

            validation = Validation.success(1)
            result = validation.bind(f)

            self.assertEqual(result, Validation([1], []))

        def test_Validation_bind_fail(self):
            """
            Unit test for method bind of class Validation.
            """

# Generated at 2022-06-24 00:48:40.099967
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    """
    It tests Validation.ap method.

    Case:
     - ap should return failed Validation with concated errors
    """
    from pymonet.validation import Validation

    def mapper(value):
        return Validation(None, ['first', 'second'])

    # given
    left = Validation(1, ['first'])

    # when
    actual = left.ap(mapper)

    # then
    expected = Validation(None, ['first', 'second'])
    assert actual == expected



# Generated at 2022-06-24 00:48:46.557528
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(lambda x: x + 1).ap(Validation.success(1)) == Validation.success(2)
    assert Validation.fail('error').ap(Validation.success(1)) == Validation.fail('error')
    assert Validation.success(lambda x: x + 1).ap(Validation.fail('error')) == Validation.fail('error')
    assert Validation.fail('first error').ap(Validation.fail('second error')) == Validation.fail(['first error', 'second error'])


# Generated at 2022-06-24 00:48:54.933448
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    def inc(x): return x + 1
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(1).map(inc).to_box() == Box(2)
    assert Validation.success(1).ap(Box(inc)).to_box() == Box(2)
    assert Validation.success(1).bind(Box).to_box() == Box(1)
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-24 00:48:57.252699
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() is True
    assert Validation.fail(['error']).is_success() is False


# Generated at 2022-06-24 00:49:01.705715
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Unit test for method to_either of class Validation
    """
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-24 00:49:08.737697
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success(10)
    assert validation.is_success(), 'Validation should be successful'

    validation = Validation.fail([1, 2, 3])
    assert not validation.is_success(), 'Validation should be failed'

# Unit tests for method map of class Validation

# Generated at 2022-06-24 00:49:12.498106
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation(None, []).to_box() == Box(None)
    assert Validation(Try(2), []).to_box() == Box(Try(2))
    assert Validation(Box(3), []).to_box() == Box(Box(3))


# Generated at 2022-06-24 00:49:21.166550
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.box import Box

    def f(value):
        if value is None:
            return Validation.fail([1])
        if len(value) > 10:
            return Validation.fail([2])
        return Validation.success(Box(value))


    assert Validation.success('1234') == Validation.success('1234').ap(f)
    assert Validation.fail([2]) == Validation.success('12345678901').ap(f)
    assert Validation.fail([1]) == Validation.success(None).ap(f)

# Generated at 2022-06-24 00:49:23.665399
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail(['error'])) == "Validation.fail[None, ['error']]"


# Generated at 2022-06-24 00:49:29.175203
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.maybe import Maybe

    def folder(x):
        if x == 1:
            return Maybe.just(x + 1)
        return Maybe.nothing()

    assert Validation.success(1).bind(folder) == Maybe.just(2)
    assert Validation.success(2).bind(folder) == Maybe.nothing()
    assert Validation.success(1).bind(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(2).bind(lambda x: Validation.success(x + 1)) == Validation.success(3)


# Generated at 2022-06-24 00:49:33.564367
# Unit test for constructor of class Validation
def test_Validation():
    # Given
    value = 'Some value'
    errors = ['Error']

    # When
    validation = Validation(value, errors)

    # Then
    assert validation.value == value
    assert validation.errors == errors



# Generated at 2022-06-24 00:49:40.314059
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == "Validation.success[1]"
    assert str(Validation.success("test")) == "Validation.success[test]"
    assert str(Validation.fail([1, 2])) == "Validation.fail[None, [1, 2]]"
    assert str(Validation.fail(["test1", "test2"])) == "Validation.fail[None, ['test1', 'test2']]"


# Generated at 2022-06-24 00:49:46.286565
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    # Validation is successful, to_maybe should return just with Validation value
    assert isinstance(Validation.success(10).to_maybe(), Maybe)
    assert Validation.success(10).to_maybe().get_value() == 10

    # Validation is failed, to_maybe should return nothing
    assert isinstance(Validation.fail([1, 2]).to_maybe(), Maybe)
    assert Validation.fail([1, 2]).to_maybe().get_value() is None


# Generated at 2022-06-24 00:49:53.208826
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation
    from pymonet.utils import identity

    # Validation failure
    v1 = Validation.fail(['foo'])
    assert v1.bind(identity) == Validation.fail(['foo'])

    # Validation failure with mapper function
    v2 = Validation.fail(['foo'])
    f2 = lambda x: Validation.success(x)
    assert v2.bind(f2) == Validation.fail(['foo'])

    # Validation success
    v3 = Validation.success('foo')
    f3 = lambda x: Validation.success('{} {}'.format(x, 'bar'))
    assert v3.bind(f3) == Validation.success('foo bar')


# Generated at 2022-06-24 00:49:58.543500
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    """Unit test for method __str__ of class Validation."""
    validation = Validation('some value', [])
    assert str(validation) == 'Validation.success[some value]'
    validation = Validation(None, ['error'])
    assert str(validation) == 'Validation.fail[None, [error]]'

# Generated at 2022-06-24 00:50:00.028329
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()


# Generated at 2022-06-24 00:50:07.123273
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation
    def returns_fail(param):
        return Validation.fail(['ERROR'])

    def returns_success(param):
        return Validation.success('VALUE')

    result = Validation.fail(['TEST_ERROR']).ap(returns_fail)

    assert result == Validation.fail(['TEST_ERROR', 'ERROR'])

    result = Validation.fail(['TEST_ERROR']).ap(returns_success)

    assert result == Validation.fail(['TEST_ERROR'])

    result = Validation.success('TEST_VALUE').ap(returns_fail)

    assert result == Validation.fail(['ERROR'])

    result = Validation.success('TEST_VALUE').ap(returns_success)

    assert result == Validation.success

# Generated at 2022-06-24 00:50:09.052249
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == 1
    assert Validation.fail().to_maybe() == None


# Generated at 2022-06-24 00:50:12.845379
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe().get_value() == 1
    assert Validation.fail([2, 3]).to_maybe().is_nothing()


# Generated at 2022-06-24 00:50:21.992312
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.success(1).map(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(1).map(lambda x: Validation.fail([])) == Validation.success(1)
    assert Validation.success(1).map(lambda x: Validation.fail([1])) == Validation.success(1)
    assert Validation.fail([]).map(lambda x: x + 1) == Validation.fail([])
    assert Validation.fail([]).map(lambda x: Validation.success(x + 1)) == Validation.fail([])

# Generated at 2022-06-24 00:50:24.982715
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(3).bind(lambda x: Validation(x, [])) == Validation.success(3)
    assert Validation(3, []).bind(lambda x: Validation.fail(["This is wrong"])) == Validation(-1, ["This is wrong"])


# Generated at 2022-06-24 00:50:31.770212
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    # Create successful Validation and convert it to Box
    validation = Validation.success(4)
    assert Box(4) == validation.to_box()

    # Create failed Validation and convert it to Box
    validation = Validation.fail(['error'])
    assert Box(None) == validation.to_box()


# Generated at 2022-06-24 00:50:35.550368
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation(1, [])
    validation2 = Validation(2, [])
    validation3 = Validation(1, [1])
    validation4 = Validation(1, [])

    assert_equals(validation1, validation1)
    assert_equals(validation1, validation4)
    assert_not_equals(validation1, validation2)
    assert_not_equals(validation1, validation3)


# Generated at 2022-06-24 00:50:40.838695
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.list import List

    # test for is_fail when it is true
    assert Validation.fail(List.of(1, 2, 3)).is_fail()

    # test for is_fail when it is false
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-24 00:50:51.389344
# Unit test for method ap of class Validation
def test_Validation_ap():

    def function(value):
        return Validation(None, [Errors.ERROR_1])

    unit = Validation(2, [Errors.ERROR_1])
    assert unit.ap(function()) == Validation(2, [Errors.ERROR_1, Errors.ERROR_1])

    unit = Validation(2, [])
    assert unit.ap(function()) == Validation(2, [Errors.ERROR_1])

    unit = Validation(1, [])
    assert unit.ap(lambda value: Validation.success(value)) == Validation(1, [])

    unit = Validation(1, [])
    assert unit.ap(lambda value: Validation.fail([Errors.ERROR_1])) == Validation(1, [Errors.ERROR_1])

# Generated at 2022-06-24 00:51:01.898681
# Unit test for method map of class Validation
def test_Validation_map():
    v1 = Validation.success(1)
    v2 = Validation.success(2)
    v3 = Validation.success("c")
    v4 = Validation.success("d")
    v5 = Validation.fail([])
    v6 = Validation.fail(["e"])
    v7 = Validation.fail(["f", "g"])

    # success
    assert v1.map(lambda x: x + 1) == Validation.success(2)
    assert v2.map(lambda x: x + 1) == Validation.success(3)
    assert v3.map(lambda x: x * 2) == Validation.success("cc")
    assert v4.map(lambda x: x * 2) == Validation.success("dd")

    # fail (on fail map doesn't do anything)


# Generated at 2022-06-24 00:51:05.470393
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success('test').to_try() == Try('test', is_success=True)
    assert Validation.fail(['test']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:51:11.645385
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    def function(value):
        return Validation.success(value)
    assert Validation.success(1).ap(function) == Validation.success(1)
    assert Validation.success(1).ap(function).errors == []

    def function(value):
        return Validation.fail(['error'])
    assert Validation.success(1).ap(function) == Validation.fail(['error'])
    assert Validation.success(1).ap(function).errors == ['error']

    def function(value):
        return Validation.fail(['error1', 'error2'])
    assert Validation.success(1).ap(function) == Validation.fail(['error1', 'error2'])

# Generated at 2022-06-24 00:51:14.362228
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('lazy').to_lazy() == Lazy(lambda: 'lazy')


# Generated at 2022-06-24 00:51:19.811957
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(3).to_maybe() == Maybe.just(3)
    assert Validation.fail().to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:51:21.886878
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Test for Validation.is_fail()
    """
    assert not Validation.success(42).is_fail()
    assert Validation.fail([Exception("Error")]).is_fail()


# Generated at 2022-06-24 00:51:24.539958
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad import identity_test
    from pymonet.monad_try import Try

    success_validation = Validation.success("value")
    identity_test(success_validation, Try("value", is_success=True))
    fail_validation = Validation.fail(["error"])
    identity_test(fail_validation, Try(None, is_success=False))

# Generated at 2022-06-24 00:51:29.095368
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.fail(["error message"]).ap(lambda _: Validation.fail(['new error message'])) == Validation.fail(["error message", "new error message"])
    assert Validation.fail(["error message"]).ap(lambda _: Validation.success(['new value'])) == Validation.success(["new value"])
    assert Validation.success(["value"]).ap(lambda _: Validation.fail(['new error message'])) == Validation.fail(["new error message"])
    assert Validation.success(["value"]).ap(lambda _: Validation.success(['new value'])) == Validation.success(["new value"])

# Generated at 2022-06-24 00:51:33.145243
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(value=123).to_box() == Box(123)
    assert Validation.fail(errors=['error1']).to_box() == Box(None)



# Generated at 2022-06-24 00:51:39.848667
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    assert 'success' in str(Validation.success(100))
    assert '100' in str(Validation.success(100))
    assert 'fail' in str(Validation.fail([1, 2, 3]))
    assert '1' in str(Validation.fail([1, 2, 3]))
    assert '2' in str(Validation.fail([1, 2, 3]))
    assert '3' in str(Validation.fail([1, 2, 3]))


# Generated at 2022-06-24 00:51:43.509657
# Unit test for method bind of class Validation
def test_Validation_bind():
    def f(x):
        return Validation.success(x)

    assert Validation.fail(errors=[1]).bind(f) == Validation.fail(errors=[1])
    assert Validation.success(1).bind(f) == Validation.success(1)


# # Unit test for method ap of class Validation

# Generated at 2022-06-24 00:51:45.237360
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():  # pragma: no cover
    assert Validation.success().is_fail() == False
    assert Validation.fail().is_fail() == True


# Generated at 2022-06-24 00:51:51.618935
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test for to_maybe method

    :returns: None
    :rtype: None
    """
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Validation.success('value').to_maybe() == Maybe.just('value')
    assert Validation.fail('error').to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:51:56.216483
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 1) == Validation.fail([1, 2, 3])
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)


# Generated at 2022-06-24 00:52:02.136057
# Unit test for method ap of class Validation
def test_Validation_ap():
    def fn(param):
        if param == 'success':
            return Validation.success('success')
        return Validation.fail(['fail', param])
    assert Validation.success('start').ap(fn) == Validation.success('start')
    assert Validation.success('fail').ap(fn) == Validation.fail(['fail', 'fail'])
    assert Validation.fail(['fail']).ap(fn) == Validation.fail(['fail'])


# Generated at 2022-06-24 00:52:04.714690
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:52:05.624022
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail() == True


# Generated at 2022-06-24 00:52:08.012609
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['Error']).is_fail() is True
    assert Validation.success('foo').is_fail() is False


# Generated at 2022-06-24 00:52:09.469277
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(2).to_try() == Try(2)
    assert Validation.fail().to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:52:13.213004
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Tests map method of Validation monad.
    """
    assert Validation(1, []).map(lambda x: x + 1) == Validation(2, [])
    assert Validation(None, [1, 2]).map(lambda x: x + 1) == Validation(None, [1, 2])


# Generated at 2022-06-24 00:52:21.755542
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success(None)) == 'Validation.success[None]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'
    assert str(Validation.fail(['error'])) == "Validation.fail[None, ['error']]"
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:52:25.187891
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    successful = Validation.success(10)
    assert not successful.is_fail()

    failed = Validation.fail(['error'])
    assert failed.is_fail()


# Generated at 2022-06-24 00:52:30.983353
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    validation1 = Validation.success(11)
    assert validation1.to_maybe() == Maybe.just(11)

    validation2 = Validation.success(None)
    assert validation2.to_maybe() == Maybe.just(None)

    validation3 = Validation.fail([])
    assert validation3.to_maybe() == Maybe.nothing()

    validation4 = Validation.fail(['ee'])
    assert validation4.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:35.195028
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test for Validation to Either transformation.

    :returns: None
    :rtype: None
    """
    from pymonet.either import Left, Right

    assert Validation.success(5).to_either() == Right(5)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-24 00:52:44.336814
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    # Validation is success and should returns Maybe just value
    maybe_val = Validation.success('some value').to_maybe()
    assert maybe_val == Maybe.just('some value')
    assert maybe_val.is_just()
    assert maybe_val.value == 'some value'

    # Validation is failed and should returns nothing
    maybe_val = Validation.fail(['error']).to_maybe()
    assert maybe_val == Maybe.nothing()
    assert maybe_val.is_nothing()


# Generated at 2022-06-24 00:52:49.408520
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try

    assert Validation.fail(['Error']).to_lazy().unwrap() == None
    assert Validation.success(1).to_lazy().unwrap() == 1

    result = Validation.fail(['Error']).to_lazy().bind(lambda x: Validation.success(x ** 2))
    assert result.to_try() == Try(None, is_success=False)

    result = Validation.success(1).to_lazy().bind(lambda x: Validation.success(x ** 2))
    assert result.to_try() == Try(1, is_success=True)


# Generated at 2022-06-24 00:52:55.109406
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    add_method_test(Validation(1, []).is_success, True)
    add_method_test(Validation(1, [1]).is_success, False)
    run_all_tests()

# Unit test method is_fail of class Validation

# Generated at 2022-06-24 00:53:04.878241
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    # Return Maybe with Validation value
    assert Validation.fail().to_maybe() == Maybe.nothing()
    assert Validation.success().to_maybe() == Maybe.just(None)
    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.fail([1, 2]).to_maybe() == Maybe.nothing()
    assert Validation.success([1, 2]).to_maybe() == Maybe.just([1, 2])



# Generated at 2022-06-24 00:53:08.585502
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()

    success_validation = Validation(42, [])
    assert success_validation.is_success()

    failed_validation = Validation(None, ['Error'])
    assert not failed_validation.is_success()


# Generated at 2022-06-24 00:53:10.979838
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:53:19.797714
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe

    # success
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.success(None).to_either() == Right(None)
    assert Validation.success(Maybe.just(1)).to_either() == Right(Maybe.just(1))

    # fail
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail([]).to_either() == Left([])


# Generated at 2022-06-24 00:53:23.821429
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """Test Validation.to_lazy()."""
    from pymonet.lazy import Lazy

    value = 'value'
    assert Validation.success(value).to_lazy() == Lazy(lambda: value)


# Generated at 2022-06-24 00:53:25.575009
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:53:30.223044
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation(None, [1, 2]).to_either() == Left([1, 2])
    assert Validation(None, []).to_either() == Right(None)
    assert Validation('string', [1, 2]).to_either() == Right('string')




# Generated at 2022-06-24 00:53:32.190572
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:34.693047
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation(None, []) == Validation(None, [])


# Generated at 2022-06-24 00:53:37.517477
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('value').to_box() == Box('value')
    assert Validation.fail(['error']).to_box() == Box(None)


# Generated at 2022-06-24 00:53:45.756443
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Test to_either method of class Validation"""
    from pymonet.either import Left, Right
    from pymonet.list import List
    from pymonet.tuple import Tuple

    assert Validation.success("b").to_either() == Right("b")
    assert Validation.fail(["a", "b", "c"]).to_either() == Left(List("a", "b", "c"))
    assert Validation.fail(Tuple(1, 2, 3)).to_either() == Left(Tuple(1, 2, 3))


# Generated at 2022-06-24 00:53:55.268775
# Unit test for method map of class Validation
def test_Validation_map():  # pragma: no cover
    def increment(value):
        return value + 1

    validation = Validation.success(10)
    assert(validation.map(increment) == Validation(11, []))

    validation = Validation.fail([])
    assert(validation.map(increment) == Validation(None, []))

    validation = Validation.fail(['error'])
    assert(validation.map(increment) == Validation(None, ['error']))



# Generated at 2022-06-24 00:53:58.962091
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(100).is_fail() == False
    assert Validation.success(None).is_fail() == False
    assert Validation.fail(errors=['Error']).is_fail() == True
    assert Validation.fail().is_fail() == True


# Generated at 2022-06-24 00:54:05.965983
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation
    from pymonet.validation import Validation as V

    def f(x):
        return V.success(x + 1)

    def g(x):
        return V.fail(['error'])

    # Test for successful validation
    assert Validation.success(5).bind(f) == Validation.success(6)

    # Test for failed validation
    assert Validation.success(5).bind(g) == Validation.fail(['error'])


# Generated at 2022-06-24 00:54:09.660869
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # test success Validation
    validation = Validation.success(1)
    assert validation.to_lazy().run() == 1

    # test failure Validation
    validation = Validation.fail([2])
    assert validation.to_lazy().run() == None



# Generated at 2022-06-24 00:54:15.238286
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # method to_either when Validation is success
    assert Validation.success(42).to_either() == Right(42)

    # method to_either when Validation is failure
    assert Validation.fail('failed').to_either() == Left('failed')
