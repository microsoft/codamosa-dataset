

# Generated at 2022-06-24 00:44:16.110697
# Unit test for method ap of class Validation
def test_Validation_ap():
    def mapper(value):
        return Validation.success(10)

    val1 = Validation.success(5)
    val2 = Validation.fail(['error'])

    assert val1.ap(mapper).value == 10
    assert not val1.ap(mapper).errors
    assert val2.ap(mapper).value is None
    assert val2.ap(mapper).errors

# Generated at 2022-06-24 00:44:19.911679
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.fail([]).is_success() == False
    assert Validation.fail(['error']).is_success() == False
    assert Validation.success(None).is_success() == True


# Generated at 2022-06-24 00:44:24.545521
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(100).to_either() == Right(100)
    assert Validation.fail([100]).to_either() == Left([100])


# Generated at 2022-06-24 00:44:26.439234
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success('a').to_maybe().to_either() == Either.Right('a')
    assert Validation.fail(['a']).to_maybe().to_either() == Either.Left(None)


# Generated at 2022-06-24 00:44:29.932869
# Unit test for constructor of class Validation
def test_Validation():
    """
    Run tests for class Validation
    """
    print(' - Run tests for class Validation')

    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])

    validation = Validation.success(1)
    assert validation.value == 1
    assert validation.errors == []

    validation = Validation.fail([1])
    assert validation.value is None
    assert validation.errors == [1]

    print(' - Tests for class Validation are OK')


# Generated at 2022-06-24 00:44:35.868828
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Success, Failure

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.fail(['Failed']).to_try() == Failure(None, 'Validation.fail', ['Failed'])


# Generated at 2022-06-24 00:44:41.270203
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    fn = lambda x: Validation.success(x*x)
    assert Validation.success(3).ap(fn) == Validation.success(9)
    assert Validation.success(3).ap(fn).is_success()
    assert Validation.fail().ap(fn) == Validation.fail()
    assert Validation.fail().ap(fn).is_fail()

# Generated at 2022-06-24 00:44:43.833342
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(42).to_box() == Box(42)
    assert Validation.fail(['error1']).to_box() == Box(None)


# Generated at 2022-06-24 00:44:54.217135
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Given
    successful_validation = Validation.success('Success!')
    failed_validation = Validation.fail(['Error 1', 'Error 2'])

    failed_validation_2 = Validation.fail(['Error 1', 'Error 2'])

    # Then
    assert successful_validation == Validation.success('Success!')
    assert failed_validation == Validation.fail(['Error 1', 'Error 2'])
    assert failed_validation == failed_validation_2
    assert True



# Generated at 2022-06-24 00:45:01.400695
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(None, []) == Validation.fail()
    assert Validation(None, [1]) == Validation.fail([1])
    assert Validation(1, []) == Validation.success(1)
    assert Validation(1, [1]) != Validation.fail()
    assert Validation(1, [1]) != Validation.success(1)
    assert Validation(1, [1]) != Validation.success(2)


# Generated at 2022-06-24 00:45:04.013592
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('val')) == 'Validation.success[val]'
    assert str(Validation.fail(['fail'])) == 'Validation.fail[None, [\'fail\']]'


# Generated at 2022-06-24 00:45:07.780038
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for method to_lazy of class Validation.
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    lazy = validation.to_lazy()

    assert lazy.__eq__(Lazy(lambda: 2))
    
    validation = Validation.fail(['fail'])
    lazy = validation.to_lazy()

    assert lazy.__eq__(Lazy(lambda: None))


# Generated at 2022-06-24 00:45:12.202548
# Unit test for method map of class Validation
def test_Validation_map():
    # Given
    v = Validation(1, [1, 2, 3])

    # When
    mv = v.map(lambda x: x + 1)

    # Then
    assert isinstance(mv, Validation) is True
    assert mv == Validation(2, [1, 2, 3])



# Generated at 2022-06-24 00:45:17.954319
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy(): # pragma: no cover
    """
    Unit test for method to_lazy of class Validation
    """
    value = 'value'
    validation = Validation.success(value)
    lazy = validation.to_lazy()
    assert lazy.get() == value


# Generated at 2022-06-24 00:45:24.839198
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    validation = Validation.success(1)
    try_monad = validation.to_try()
    assert try_monad.is_success() == True
    assert try_monad.get_or_else(lambda x: False) == 1

    validation = Validation.fail(['error'])
    try_monad = validation.to_try()
    assert try_monad.is_success() == False
    assert try_monad.is_failure() == True


# Generated at 2022-06-24 00:45:28.560448
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    test_value = 5

    def test_mapper(value):
        if value == 5:
            return Validation(value * 2, ['error'])
        return Validation(value * 2, [])

    assert Validation.ap(Validation.success(test_value), test_mapper) == \
           Validation.fail(['error'])
    assert Validation.ap(Validation.fail(['error']), test_mapper) == \
           Validation.fail(['error'])
    assert Validation.ap(Validation.success(test_value), test_mapper).value == 10


# Generated at 2022-06-24 00:45:31.705953
# Unit test for constructor of class Validation
def test_Validation():
    """
    Test for constructor of class Validation
    """
    # Success case
    assert Validation.success(3) == Validation(3, [])
    # Fail case
    assert Validation.fail(['error']) == Validation(None, ['error'])



# Generated at 2022-06-24 00:45:33.241015
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validation = Validation.success(42)
    assert validation.to_lazy() == Lazy(lambda: 42)


# Generated at 2022-06-24 00:45:36.337638
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() is False
    assert Validation.success(4).is_fail() is False
    assert Validation.fail([]).is_fail() is True
    assert Validation.fail([1, 2, 3]).is_fail() is True

# Generated at 2022-06-24 00:45:40.729372
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet import monad_just
    from .validation_test_case import ValidationTestCase

    monad = Validation.success('2')
    fn = lambda i: Validation.success(int(i) * 2)

    assert monad_just(monad.ap(fn), '4') == ValidationTestCase.success_4()
    assert monad_just(monad.ap(lambda i: Validation.fail(['error'])), '4') == ValidationTestCase.fail_4()



# Generated at 2022-06-24 00:45:46.110389
# Unit test for method map of class Validation
def test_Validation_map():
    # Test success Validation map
    success = Validation.success(3)
    assert success.map(lambda x: x + 2) == Validation.success(5)

    # Test failed Validation map
    failed = Validation.fail([1, 2, 3])
    assert failed.map(lambda x: x + 2) == Validation.fail([1, 2, 3])



# Generated at 2022-06-24 00:45:49.805283
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Just, Nothing

    assert Validation.success(5).to_maybe() == Just(5)
    assert Validation.fail([1, 2, 3]).to_maybe() == Nothing()


# Generated at 2022-06-24 00:45:56.696702
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert(Validation.fail([1]).ap(lambda x: Validation.fail([1, 2])) == Validation.fail([1, 2]))
    assert(Validation.fail([1]).ap(lambda x: Validation.fail([])) == Validation.fail([]))
    assert(Validation.success(1).ap(lambda x: Validation.fail([1, 2])) == Validation.fail([1, 2]))
    assert(Validation.success(1).ap(lambda x: Validation.success(2)) == Validation.success(2))



# Generated at 2022-06-24 00:46:06.366510
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    success_validation = Validation.success(1)
    assert success_validation == success_validation

    success_validation_with_same_value = Validation.success(1)
    assert success_validation == success_validation_with_same_value

    success_validation_with_another_value = Validation.success(2)
    assert success_validation != success_validation_with_another_value

    fail_validation = Validation.fail([1, 2, 3])
    assert fail_validation == fail_validation


# Generated at 2022-06-24 00:46:16.461944
# Unit test for method to_try of class Validation
def test_Validation_to_try():

    def fn():
        return 1

    def fn_error():
        raise Exception('error')

    maybe = Validation.success(fn())
    try_ = maybe.to_try()
    assert try_ == Try(fn(), is_success=True)

    maybe = Validation.fail(['error'])
    try_ = maybe.to_try()
    assert try_ == Try(None, is_success=False)

    maybe = Validation.fail(['error'])
    try_ = maybe.to_try()
    assert try_ == Try(None, is_success=False)

    maybe = Validation.success(fn_error())
    try_ = maybe.to_try()
    assert try_ == Try(None, is_success=False)


# Generated at 2022-06-24 00:46:22.359980
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success() == Validation(None, []).is_success()
    assert Validation.success(12345) == Validation(12345, []).is_success()
    assert Validation.success('12345') == Validation('12345', []).is_success()
    assert Validation.success(12345).is_success()
    assert Validation.success('12345').is_success()


# Generated at 2022-06-24 00:46:26.421103
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Unit test for method to_either of class Validation"""
    from pymonet.either import Right, Left

    assert Validation.success().to_either() == Right(None)
    assert Validation.success('value').to_either() == Right('value')
    assert Validation.fail().to_either() == Left([])
    assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])


# Generated at 2022-06-24 00:46:29.601519
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation(1, []).to_try() == Try(1, True)
    assert Validation(1, [1]).to_try() == Try(1, False)


# Generated at 2022-06-24 00:46:36.941527
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success(Box(1)).to_maybe() == Maybe.just(Box(1))

    assert Validation.fail().to_maybe() == Maybe.nothing()
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:46:46.607298
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.functor import Functor
    from pymonet import io
    from pymonet.stream import Stream

    val_1 = Validation.success('map me')
    val_2 = Validation.fail(['map me'])

    # Functor test
    functor_test = Functor(val_1, val_1.map)
    functor_test.test_identity()
    functor_test.test_composition(lambda x: x.upper(), lambda x: len(x))

    # Functor IO test
    io_test = Functor(io.IO(lambda: val_1), lambda monad: monad.map(lambda x: x.upper()))
    io_test.test_identity()

# Generated at 2022-06-24 00:46:51.503333
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail().to_box() == Box(None)



# Generated at 2022-06-24 00:46:54.290584
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Unit test for method is_fail of class Validation
    """
    assert Validation(None, []).is_fail() is False
    assert Validation(None, ['error']).is_fail() is True


# Generated at 2022-06-24 00:46:55.904348
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success('a') == Validation.success('a')
    assert Validation.fail(['error']) == Validation.fail(['error'])


# Generated at 2022-06-24 00:46:58.632538
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')
    assert Validation.fail(['fail']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:47:02.630471
# Unit test for constructor of class Validation
def test_Validation():
    """
    >>> v = Validation.success(3)
    >>> w = Validation.fail([1, 2])
    >>> v == Validation(3, [])
    True
    >>> w == Validation(None, [1, 2])
    True
    """



# Generated at 2022-06-24 00:47:10.001871
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.either import Left, Right

    success_validation = Validation.success(Maybe.just(2))
    assert success_validation.to_either() == Right(Maybe.just(2))

    fail_validation = Validation.fail(['error'])
    assert fail_validation.to_either() == Left(['error'])


# Generated at 2022-06-24 00:47:11.391133
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail()


# Generated at 2022-06-24 00:47:13.343010
# Unit test for constructor of class Validation
def test_Validation():
    result = Validation(10, [])
    assert result == Validation(10, [])



# Generated at 2022-06-24 00:47:20.241128
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # Test when Validation is success
    validation_success = Validation.success(True)
    try:
        assert validation_success.to_lazy().get()
    except:
        assert False

    # Test when Validation is fail
    validation_fail = Validation.fail(['error'])
    try:
        assert validation_fail.to_lazy().get()
    except:
        assert True



# Generated at 2022-06-24 00:47:25.699970
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success('success').to_lazy() == Lazy(lambda: 'success')
    assert Validation.fail() == Validation(None, [])


# Generated at 2022-06-24 00:47:27.151296
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(5).to_lazy().call() == 5


# Generated at 2022-06-24 00:47:32.687451
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:47:40.298826
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    from pymonet.monad_try import Try
    from pymonet.either import Right

    # Unit test for method __str__ of class Validation
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'
    assert str(Validation.success(Try.success('42'))) == 'Validation.success[42]'
    assert str(Validation.fail([Try.fail('fail 1'),
                                Right(2),
                                Try.success(Try.success(3)),
                                Try.success(3)])) == 'Validation.fail[None, [fail 1, 2, 3]]'


# Generated at 2022-06-24 00:47:43.159827
# Unit test for method __str__ of class Validation
def test_Validation___str__(): # pragma: no cover
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([2])) == 'Validation.fail[None, [2]]'


# Generated at 2022-06-24 00:47:50.237151
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Unit test for method bind of class Validation"""
    def fn_1(x):
        if x >= 0:
            return Validation.success()
        return Validation.fail(['Value {} must be greater ore equals 0'.format(x)])

    def fn_2(x):
        if x < 10:
            return Validation.success()
        return Validation.fail(['Value {} must be less than 10'.format(x)])

    # when value is successful
    val = Validation.success(5).bind(fn_1).bind(fn_2)
    assert val.is_success()

    # when first value is failure
    val = Validation.success(-5).bind(fn_1).bind(fn_2)
    assert val.is_fail()

    # when second value is failure

# Generated at 2022-06-24 00:47:54.458353
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.either import Left, Right

    x = Right(None).to_validation()
    # case: Return True if both Validations have equal values, but different types
    assert x == Validation.success(None)

    x = Right(None).to_validation()
    # case: Return True if both Validations have equal values and equal types
    assert x == x

    x = Right(None).to_validation()
    # case: Return False if one of Validations has errors
    assert x != Left([])

    x = Right('test').to_validation()
    # case: Return False if both Validations have different values
    assert x != Left('test')



# Generated at 2022-06-24 00:47:56.894488
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-24 00:47:58.611424
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.fail([1,2]).is_success() is False


# Generated at 2022-06-24 00:48:03.124346
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation = Validation(True, [])
    another_validation = Validation(True, [])
    assert validation == another_validation

    validation = Validation(True, [])
    another_validation = Validation(True, [1, 2, 3])
    assert validation != another_validation

    validation = Validation(True, [])
    another_validation = Validation(False, [])
    assert validation != another_validation


# Generated at 2022-06-24 00:48:07.475983
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(2).is_success()
    assert not Validation.success('xxx').is_success()
    assert not Validation.fail(['Some error']).is_success()
    assert not Validation.fail([]).is_success()


# Generated at 2022-06-24 00:48:11.680016
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('validation') == Validation('validation', [])
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:48:14.492284
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    # Check that is_success returns True for empty errors list
    assert Validation.success().is_success()

    # Check that is_success returns False for not empty errors list
    assert not Validation.fail([1]).is_success()


# Generated at 2022-06-24 00:48:17.085805
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)


# Generated at 2022-06-24 00:48:21.376628
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    b = Validation(10, []).to_box()
    assert b == Box(10)

    b = Validation(None, []).to_box()
    assert b == Box(None)

    b = Validation(10, ['err1', 'err2']).to_box()
    assert b == Box(10)

    b = Validation(None, ['err1', 'err2']).to_box()
    assert b == Box(None)


# Generated at 2022-06-24 00:48:31.866026
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe, Just, Nothing

    val = Validation.success(1).ap(lambda i: Try(i))
    assert val == Try(1)

    val = Validation.fail([1, 2]).ap(lambda i: Try(i))
    assert val == Try(None, is_success=False)

    val = Validation.success(1).ap(lambda i: Just(i))
    assert val == Just(1)

    val = Validation.fail([1, 2]).ap(lambda i: Just(i))
    assert val == Nothing()

    val = Validation.success(1).ap(lambda i: Right(i))
    assert val == Right(1)

    val = Validation.fail

# Generated at 2022-06-24 00:48:37.041179
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([2])
    assert Validation.success(1) != Validation.fail([])


# Generated at 2022-06-24 00:48:39.295925
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success('value').to_maybe() == Maybe.just('value')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:48:50.928596
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(3).map(lambda x: x * 2) == Validation.success(6)
    assert Validation.success('r').map(lambda x: x + 'y') == Validation.success('ry')
    assert Validation.success('r').map(lambda x: x + 'y').map(lambda x: x + 't') == Validation.success('ryt')

    assert Validation.fail(['error1']).map(lambda x: x * 2) == Validation.fail(['error1'])
    assert Validation.fail(['error1']).map(lambda x: x + 'y') == Validation.fail(['error1'])

# Generated at 2022-06-24 00:48:53.457206
# Unit test for method to_try of class Validation
def test_Validation_to_try():

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([1, 2]).to_try() == Try(None)



# Generated at 2022-06-24 00:49:00.476422
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    from pymonet.list_ import List
    from pymonet.validation import Validation

    validation = Validation.success('First')
    result = validation.ap(List.unit(lambda x: Validation.success(x)).prepend('First').prepend('Second'))
    assert Validation.fail(['Second']) == result

    validation = Validation.success('First')
    result = validation.ap(List.unit(lambda x: Validation.success(x)).prepend('First').prepend('Second').prepend('Third'))
    assert Validation.fail(['Third', 'Second']) == result

    validation = Validation.fail(['First'])

# Generated at 2022-06-24 00:49:10.737504
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test that transforms Validation to Try and checks to_try result.
    """

    # check that we get either right or left
    assert Validation.success(2).to_try().is_success()
    assert Validation.fail([]).to_try().is_fail()

    # check that value is same
    assert Validation.success(2).to_try().value == 2
    assert Validation.fail([]).to_try().value is None

    # check that failures are same
    assert Validation.success(2).to_try().failures is None
    assert Validation.fail([1]).to_try().failures == [1]



# Generated at 2022-06-24 00:49:13.592912
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(2).to_maybe() == Maybe.just(2)
    assert Validation.success().to_maybe() == Maybe.just(None)
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:49:19.647293
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left
    from pymonet.maybe import Just, Nothing

    assert Validation.success().to_maybe() == Nothing()
    assert Validation.success(1).to_maybe() == Just(1)
    assert Validation.fail().to_maybe() == Nothing()
    assert Validation.fail(1).to_maybe() == Nothing()


# Generated at 2022-06-24 00:49:21.597094
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Try

    assert Validation.success(Try(Box(1))).to_box() == Box(Box(1))



# Generated at 2022-06-24 00:49:23.267373
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([])) == 'Validation.fail[None, []]'


# Generated at 2022-06-24 00:49:24.982985
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(1, []).is_fail() is False
    assert Validation(1, [2]).is_fail() is True


# Generated at 2022-06-24 00:49:26.668182
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation(19, [])
    result = validation.ap(Validation(19, ['1', '2']))
    assert result == Validation(19, ['1', '2'])
    result = validation.ap(Validation(19, []))
    assert result == validation


# Generated at 2022-06-24 00:49:28.771681
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert Validation.fail([]).is_success() is False


# Generated at 2022-06-24 00:49:35.514195
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # Create new LittleValidation with error
    lit = Validation.fail(['error1', 'error2'])
    assert(lit.to_either() == Left(['error1', 'error2']))

    # Create new LittleValidation without error
    lit = Validation.success(5)
    assert(lit.to_either() == Right(5))


# Generated at 2022-06-24 00:49:42.326362
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert 'Validation.success[]' == str(Validation.success())
    assert 'Validation.success[2]' == str(Validation.success(2))
    assert 'Validation.fail[None, []]' == str(Validation.fail())
    assert 'Validation.fail[None, [1]]' == str(Validation.fail(1))
    assert 'Validation.fail[None, [1, 2]]' == str(Validation.fail([1, 2]))


# Generated at 2022-06-24 00:49:52.392938
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    :params: first
    :params: second
    :returns: sum of first and second
    """

    def add(first, second):  # pragma: no cover
        return first + second

    def add_error(first, second):  # pragma: no cover
        return Validation.fail(errors=['{} {} {}'.format('Error for numbers', str(first), str(second))])

    assert Validation.success(5).bind(lambda a: Validation.success(a + 1)) == Validation.success(6)
    assert Validation.success(5).bind(add, 4) == Validation.success(9)
    assert Validation.fail().bind(add, 4) == Validation.fail()
    assert Validation.fail().bind(lambda a: add_error(a, 4)) == Validation

# Generated at 2022-06-24 00:49:57.032555
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    result = Validation.fail().to_try()
    assert result == Try(None, is_success=False)

    result = Validation.success(10).to_try()
    assert result == Try(10, is_success=True)

# Generated at 2022-06-24 00:50:05.705846
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.either import Right, Left
    from pymonet.lazy import Lazy

    assert Validation(1, []).bind(lambda v: Validation(v * 2, [])).value == 2
    assert Validation(1, [1]).bind(lambda v: Validation(v * 2, [])).value == 2
    assert Validation(1, ['err']).bind(lambda v: Validation(v * 2, ['err'])).errors == ['err']

    assert Validation(1, []).bind(lambda v: Validation(v * 2, [])).bind(lambda v: Validation(v * 3, [])).value == 6

# Generated at 2022-06-24 00:50:11.004509
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    def test_case_success():
        assert Validation.success(True).to_maybe() == Maybe.just(True)

    def test_case_fail():
        assert Validation.fail('error').to_maybe() == Maybe.nothing()

    test_case_success()
    test_case_fail()


# Generated at 2022-06-24 00:50:19.000209
# Unit test for method to_either of class Validation
def test_Validation_to_either():
# Given
    from pymonet.either import Right, Left

    validation = Validation.success('test')
    right_expected = Right('test')
# When
    right_result = validation.to_either()
# Then
    assert right_expected == right_result

    left_expected = Left(['error'])
    validation = Validation.fail(['error'])
# When
    left_result = validation.to_either()
# Then
    assert left_expected == left_result


# Generated at 2022-06-24 00:50:21.495955
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1]).to_box() == Box(None)



# Generated at 2022-06-24 00:50:27.039320
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert (Validation.fail([1])
            .ap(lambda x: Validation.success(x + 1)) ==
            Validation.fail([1]))
    assert (Validation.success(1)
            .ap(lambda x: Validation.fail([x + 1])) ==
            Validation.fail([2]))
    assert (Validation.success(1)
            .ap(lambda x: Validation.success(x + 1)) ==
            Validation.success(2))


# Generated at 2022-06-24 00:50:35.748131
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(2) == Validation.success(2)

    assert Validation.fail(['error 1', 'error 2']) == Validation.fail(['error 1', 'error 2'])

    assert Validation.success(4) != Validation.fail(['error 1', 'error 2'])

    assert Validation.fail(['error 1', 'error 2']) != Validation.success(4)

    assert Validation.success(8) != Validation.success(5)

    assert Validation.fail(['error 1', 'error 2']) != Validation.fail(['error 1'])


# Generated at 2022-06-24 00:50:40.082091
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation(1, 2).bind(lambda x: Validation.success(x)) == Validation(1, 2)
    assert Validation.success(1).bind(lambda x: Validation.fail([2])) == Validation(None, [2])

# Generated at 2022-06-24 00:50:42.291381
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert \
        Validation.success('test').to_box() == Box('test')



# Generated at 2022-06-24 00:50:48.380175
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Function that tests map method of Validation class.

    :returns: True when test succeeded, otherwise raises AssertionError
    :rtype: Boolean
    """
    assert Validation.success(1).map(lambda c: c + 1) == Validation.success(2)
    assert Validation.fail(['invalid']).map(lambda c: c + 1) == Validation.fail(['invalid'])
    return True


# Generated at 2022-06-24 00:50:53.912303
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Test method __str__ of class Validation.
    """
    assert(str(Validation.success(42)) == 'Validation.success[42]')
    assert(str(Validation.fail([42, 'error'])) == 'Validation.fail[None, [42, \'error\']]')


# Generated at 2022-06-24 00:51:03.384678
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Right
    from pymonet.maybe import Maybe
    from test.test_helpers import identity, f

    assert Validation.success(2).map(identity) == Validation.success(2)
    assert Validation.fail(['Error 1']).map(identity) == Validation.fail(['Error 1'])

    assert Validation.success(2).map(f) == Validation.success(3)
    assert Validation.fail(['Error 1']).map(f) == Validation.fail(['Error 1'])

    # Monad transformer
    assert Validation.success(2).map(Right).map(identity) == Validation.success(Right(2))

# Generated at 2022-06-24 00:51:07.307154
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    success = Validation.success(1)
    assert success.__str__() == 'Validation.success[1]'
    fail = Validation.fail([])
    assert fail.__str__() == 'Validation.fail[None, []]'


# Generated at 2022-06-24 00:51:11.506338
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # Use case 1. Fail Validation
    assert Validation(None, ['er1', 'er2']).is_fail()

    # Use case 2. Successful Validation
    assert not Validation(True, []).is_fail()


# Generated at 2022-06-24 00:51:14.213092
# Unit test for method to_box of class Validation
def test_Validation_to_box():

    assert(Validation.success(1).to_box() == Box(1))
    assert(Validation.fail().to_box() == Box(None))



# Generated at 2022-06-24 00:51:22.049539
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    # when: validation is successful
    val = Validation.success(1)

    # then: lazy should be successful
    assert Lazy(lambda: val.value) == val.to_lazy()

    # when: validation is failure
    val = Validation.fail()

    # then: lazy should be failure
    assert Try(None, is_success=False) == val.to_lazy()

# Generated at 2022-06-24 00:51:26.784738
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.maybe import Maybe

    assert Validation(2, []).bind(Maybe.just) == Maybe.just(2)
    assert Validation(2, [1]).bind(Maybe.just) == Maybe.nothing()

    fn = lambda x: Maybe.just(x * 3)
    assert Validation(2, []).bind(fn) == Maybe.just(6)


# Generated at 2022-06-24 00:51:37.318652
# Unit test for method ap of class Validation
def test_Validation_ap():

    a = Validation.success(None)

    b = a.ap(lambda x: Validation.success('b'))
    assert b == Validation.success('b')

    c = b.ap(lambda x: Validation.fail(['error']))
    assert c == Validation.fail(['error'])

    d = Validation.success(None)
    e = d.ap(lambda x: Validation.fail(['error']))
    assert e == Validation.fail(['error'])

    f = Validation.success(None)
    g = f.ap(lambda x: Validation.fail(['error1', 'error2']))
    assert g == Validation.fail(['error1', 'error2'])

# Generated at 2022-06-24 00:51:40.299564
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:51:44.934853
# Unit test for constructor of class Validation
def test_Validation():
    # Success constructor
    validate = Validation(10, [])
    assert validate.value == 10
    assert validate.errors == []
    assert validate.is_success() == True
    assert validate.is_fail() == False

    # Fail constructor
    validate = Validation(None, [1, 2])
    assert validate.value == None
    assert validate.errors == [1, 2]
    assert validate.is_success() == False
    assert validate.is_fail() == True


# Generated at 2022-06-24 00:51:52.946129
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(None) == Validation.success(None)
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success('abc') == Validation.success('abc')

    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail(['error']) == Validation.fail(['error'])

    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail(['error']) != Validation.fail(['error1'])


# Generated at 2022-06-24 00:51:56.316101
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(3, []).to_box() == Box(3)
    assert Validation(3, ['oops']).to_box() == Box(3)


# Generated at 2022-06-24 00:51:57.609523
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(100).is_fail() == False
    assert Validation.fail([1, 2, 3]).is_fail() == True


# Generated at 2022-06-24 00:52:06.067876
# Unit test for constructor of class Validation
def test_Validation():
    # success
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail('test error') == Validation(None, ['test error'])
    assert Validation.fail(['test error']) == Validation(None, ['test error'])

    # fail
    assert Validation.success() == Validation(None, [])
    assert Validation.success('test value') == Validation('test value', [])
    assert Validation.success(['test value']) == Validation(['test value'], [])



# Generated at 2022-06-24 00:52:14.106067
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    from random import randint
    from pymonet.list import List
    from pymonet.either import Right

    for _ in range(100):
        assert str(Validation.success()) == 'Validation.success[None]'
        assert str(Validation.success(randint(0, 100))) == 'Validation.success[{}]'.format(randint(0, 100))
        assert str(Validation.fail()) == 'Validation.fail[None, []'
        assert str(Validation.fail([randint(0, 100)])) == 'Validation.fail[None, [{}]'.format(randint(0, 100))
        assert str(Validation.fail(List.of(1, 2, 3))) == 'Validation.fail[None, [1, 2, 3]'

# Generated at 2022-06-24 00:52:22.917753
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Check to_box method of Validation class.
    """
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.fail().to_box() == Box(None)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:52:25.906160
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error1', 'error2']).is_fail()
    assert not Validation.success('success').is_fail()


# Generated at 2022-06-24 00:52:28.750684
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1, 2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:35.720200
# Unit test for method map of class Validation
def test_Validation_map():
    test_success_val = Validation.success(1)
    assert test_success_val.map(lambda v: v + 1) == Validation.success(2)
    test_failure_val = Validation.fail([])
    assert test_failure_val.map(lambda v: v + 1) == test_failure_val


# Generated at 2022-06-24 00:52:41.693788
# Unit test for method map of class Validation
def test_Validation_map():
    """
    |GIVEN| function that transforms string to integer
    |WHEN| perform method map on any Validation
    |THEN| returned Validation should contain transformed value
    """
    from pymonet.either import Left, Right

    def mapper(val):
        return int(val)

    validation = Validation.success('1')
    left_validation = Validation.fail()

    assert validation.map(mapper) == Validation(1, [])
    assert left_validation.map(mapper) == Validation(None, [])


# Generated at 2022-06-24 00:52:50.268974
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad import Monad

    assert Monad.to_lazy(Validation.success('test')).value() == Lazy(lambda: 'test').value()
    assert Monad.to_lazy(Validation.success(None)).value() == Lazy(lambda: None).value()

    assert Monad.to_lazy(Validation.fail([])).value() == Lazy(lambda: None).value()
    assert Monad.to_lazy(Validation.fail([1, 2, 3])).value() == Lazy(lambda: None).value()


# Generated at 2022-06-24 00:52:54.777218
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() is False
    assert Validation.fail().is_fail() is True


# Generated at 2022-06-24 00:53:00.763203
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(5).bind(lambda n: n + 1) == Validation.success(6)
    assert Validation(None, ['error']).bind(lambda _: 1) == Validation(None, ['error'])


# Generated at 2022-06-24 00:53:11.065779
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation

    def get_user(id):
        if id not in [1, 2, 3]:
            return Validation.fail(['User with id: {} doesn\'t exist'.format(id)])
        return Validation.success({'id': id, 'name': 'name{}'.format(id)})

    def get_group(user):
        if user['id'] < 3:
            return Validation.fail(['User with id: {} can\'t be in group'.format(user['id'])])
        return Validation.success(['group{}'.format(user['id'])])

    assert Validation.success(1).bind(get_user).bind(get_group) == Validation(None, ['User with id: 1 can\'t be in group'])
    assert Validation

# Generated at 2022-06-24 00:53:17.482972
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(3).to_lazy() == Lazy(lambda: 3)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:53:23.384606
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    validation = Validation.success('abc')
    assert validation.to_maybe() == Maybe.just('abc')

    validation = Validation.fail([])
    assert validation.to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:53:26.398834
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(None, []).is_fail() == False
    assert Validation(None, [1, 2, 3]).is_fail() == True


# Generated at 2022-06-24 00:53:30.045802
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(42).to_maybe() == Maybe.just(42)
    assert Validation.fail('a').to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:53:32.592579
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    success = Validation.success(5)
    fail = Validation.fail([Exception(), AttributeError()])

    assert success.to_either() == Right(5)
    assert fail.to_either() == Left([Exception(), AttributeError()])


# Generated at 2022-06-24 00:53:37.017883
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    assert Validation.success(10).to_maybe() == Maybe.just(10)
    assert Validation.fail(["error1", "error2"]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:53:44.719170
# Unit test for method to_box of class Validation
def test_Validation_to_box():  # pragma: no cover
    from pymonet.box import Box

    validation = Validation.success(42)
    assert validation.to_box() == Box(42)
    assert validation.to_box().maybe().to_maybe().unsafe_get() == 42
    assert validation.to_box().boxed() == 42

    validation = Validation.fail([1, 2, 3])
    assert validation.to_box() == Box(None)
    assert validation.to_box().maybe().to_maybe().unsafe_get() == None
    assert validation.to_box().boxed() == None



# Generated at 2022-06-24 00:53:49.333783
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validate = Validation.success()
    assert validate.is_success() is True

    validate = Validation.fail([1, 2])
    assert validate.is_success() is False


# Generated at 2022-06-24 00:53:55.571201
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation('value', [])) == 'Validation.success[value]'
    assert str(Validation('value', ['error1', 'error2'])) == 'Validation.fail[value, [\'error1\', \'error2\']]'


# Generated at 2022-06-24 00:54:01.999055
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation = Validation(None, []).success()
    assert validation == Validation.success()

    validation = Validation(123, []).success()
    assert validation == Validation(123, [])

    validation = Validation(123, []).success()
    assert validation == Validation.success(123)

    validation = Validation(123, ['ERROR']).fail()
    assert validation == Validation.fail(['ERROR'])


# Generated at 2022-06-24 00:54:08.657240
# Unit test for method map of class Validation
def test_Validation_map():
    import pytest

    assert Validation.success(2).map(lambda x: x ** 2) == Validation(4, [])
    assert Validation.success('bob').map(lambda x: x * 10) == Validation('bobbobbobbob', [])
    assert Validation.fail(['ERROR']).map(lambda x: x ** 2) == Validation(None, ['ERROR'])
    assert Validation.fail(['ERROR']).map(lambda x: x * 10) == Validation(None, ['ERROR'])


# Generated at 2022-06-24 00:54:12.346028
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    validation = Validation.success(1)
    assert validation.to_lazy() == Lazy(lambda: 1)

    validation = Validation.fail()
    assert validation.to_lazy() == Lazy(lambda: None)

