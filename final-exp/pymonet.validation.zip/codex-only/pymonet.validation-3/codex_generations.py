

# Generated at 2022-06-24 00:44:18.897281
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """It that can hold either a success value or a failure value and has methods for accumulating errors"""
    from pymonet.monad import Validation

    success_value = Validation.success(42).__str__()
    assert success_value == 'Validation.success[42]', 'Validation.success[42] is expected for successful value'

    fail_value = Validation.fail(['First error', 'Second error']).__str__()
    assert fail_value == 'Validation.fail[None, [\'First error\', \'Second error\']]', \
        'Validation.fail[None, [\'First error\', \'Second error\']] is expected for failed value'


# Generated at 2022-06-24 00:44:29.199482
# Unit test for method bind of class Validation
def test_Validation_bind():  # pragma: no cover
    """
    Validation.bind must check that it returned expected result.
    """
    from pymonet.either import Right, Left
    from pymonet.validation import Validation

    def both_right(left_value, right_value):
        """
        Function that takes two values, if both values are Right returns 100.

        :param left_value: left value
        :type left_value: Either[A | B]
        :param right_value: right value
        :type right_value: Either[A | B]
        :returns: 100 if left and right values are Right, otherwise error with both Left values
        :rtype: Validation[Any, List[Either[A | B]]]
        """

# Generated at 2022-06-24 00:44:34.956449
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(3)) == "Validation.success[3]"
    assert str(Validation.fail(["error1", "error2"])) == "Validation.fail[None, ['error1', 'error2']]"


# Generated at 2022-06-24 00:44:39.972018
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:44:44.780508
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation
    from pymonet.result import Result

    validation = Validation.success(42)
    result = validation.ap(lambda x: Validation.success(x * x)).to_either()
    assert result.is_right() and result.value == 1764


# Generated at 2022-06-24 00:44:51.192058
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail().to_box() == Box(None)


# Generated at 2022-06-24 00:45:02.005755
# Unit test for method map of class Validation
def test_Validation_map():
    def mapper(v):
        return v + 1

    def try_mapper(v):
        return v + '1'

    val = Validation(1, [])
    assert val.map(mapper) == Validation(2, [])

    val2 = Validation('1', [])
    assert val2.map(try_mapper) == Validation('11', [])

    def invalid_mapper(v):
        return v + '1'

    val3 = Validation(1, [])
    assert val3.map(invalid_mapper) == Validation(None, [])


# Generated at 2022-06-24 00:45:04.256196
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation(1, [])
    assert validation.is_fail() is False
    validation = Validation(None, [1])
    assert validation.is_fail() is True


# Generated at 2022-06-24 00:45:06.440093
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(3).to_box() == Box(3)
    assert Validation.fail([1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:45:10.448930
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    validation_right_without_errors = Validation.success(42)
    assert validation_right_without_errors.to_either() == Right(42)

    validation_right_with_errors = Validation.success(42)
    assert validation_right_with_errors.ap(lambda i: Validation.fail(['Some error'])).to_either() == Left(['Some error'])


# Generated at 2022-06-24 00:45:17.504785
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success('test').to_either() == Right('test')
    assert Validation.fail(['test_error']).to_either() == Left(['test_error'])



# Generated at 2022-06-24 00:45:19.204193
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(42).to_box() == Box(42)



# Generated at 2022-06-24 00:45:22.174814
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]'


# Generated at 2022-06-24 00:45:25.086270
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['err']).is_fail() is True
    assert Validation.success('success').is_fail() is False


# Generated at 2022-06-24 00:45:30.997942
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right

    def validate_age(age):
        if age >= 18:
            return Validation.success()
        return Validation.fail(['age is not valid'])

    def validate_sex(sex):
        if sex == 'male':
            return Validation.success()
        return Validation.fail(['sex is not valid'])

    def validate_name(name):
        if name != '':
            return Validation.success()
        return Validation.fail(['name is not valid'])

    def validate_person(age, sex, name):
        return validate_age(age) \
            .bind(lambda _: validate_sex(sex)) \
            .bind(lambda _: validate_name(name)) \
            .to_either()



# Generated at 2022-06-24 00:45:38.756911
# Unit test for constructor of class Validation
def test_Validation():
    # Success Validation
    Validation.success(value = 1)
    # Fail Validation with one value in errors list
    Validation.fail(errors = [1])
    # Fail Validation with two values in errors list
    Validation.fail(errors = [1, 2])
    # Validation initialized with empty errors list
    Validation(1, [])
    # Validation initialized with one value in errors list
    Validation(1, [1])
    # Validation initialized with two values in errors list
    Validation(1, [1, 2])


# Generated at 2022-06-24 00:45:41.445510
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(3).to_box() == Box(3)


# Generated at 2022-06-24 00:45:50.543374
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert(Validation.success(5).to_maybe() == Maybe.just(5))
    assert(Validation.fail(Left([{'username': 'Login is to short'}])).to_maybe() == Maybe.nothing())
    assert(Validation.fail(Left([{'username': 'Login is to short'}, {'password': 'Password can not be empty'}])).to_maybe() == Maybe.nothing())
    assert(Validation.fail(Try(5, is_success=False)).to_maybe() == Maybe.nothing())

# Generated at 2022-06-24 00:45:52.466392
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(5).map(lambda x: x + 1) == Validation.success(6)


# Generated at 2022-06-24 00:45:57.625787
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    assert Validation.success('value').to_either() == Right('value')
    assert Validation.success().to_either() == Right(None)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:46:00.684646
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1])) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:46:03.620140
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(1).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:46:08.774329
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation('a', []) == Validation('a', [])
    assert Validation('b', [1]) != Validation('b', [])
    assert Validation('a', [1, 2]) != Validation('a', [1])
    assert Validation('b', [1, 2]) != Validation('a', [1])


# Generated at 2022-06-24 00:46:12.172401
# Unit test for method map of class Validation
def test_Validation_map():
    value = Validation(1, [])

    test_result = value.map(lambda x: x + 1)
    expected_result = Validation(2, [])

    assert test_result == expected_result


# Generated at 2022-06-24 00:46:15.806257
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation(7, []).to_box() == Box(7)
    assert Validation(None, [1, 2, 3]).to_box() == Box(None)


# Generated at 2022-06-24 00:46:19.540224
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe, Just, Nothing

    assert Validation(1, []).to_maybe() == Just(1)
    assert Validation(None, [1]).to_maybe() == Nothing()


# Generated at 2022-06-24 00:46:25.301481
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    Unit test for Validation.to_lazy method.

    :return: None
    """
    from pymonet.lazy import Lazy

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [1, 2, 3]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:46:32.849991
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation(None, []).bind(lambda val: Validation.success(val + 1)) == Validation(1, [])
    assert Validation(None, ['error']).bind(lambda val: Validation.success(val)) == Validation(None, ['error'])
    assert Validation(1, ['error']).bind(lambda val: Validation.success(val + 1)) == Validation(2, ['error'])
    assert Validation(1, ['error']).bind(lambda val: Validation.fail(['error'])) == Validation(1, ['error'])
    assert Validation(None, ['error']).bind(lambda val: Validation.fail(['error'])) == Validation(None, ['error'])


# Generated at 2022-06-24 00:46:41.021549
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation.success(10)
    assert Validation.success(10) != Validation.success(20)
    assert Validation.success(10) != Validation.fail(['first', 'second'])

    assert Validation.fail(['first']) == Validation.fail(['first'])
    assert Validation.fail(['first']) != Validation.fail(['first', 'second'])
    assert Validation.fail(['first']) != Validation.success(20)



# Generated at 2022-06-24 00:46:45.172323
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation(1, []).to_lazy() == Lazy(lambda: 1)
    assert Validation(None, [Try.FAIL, Try.FAIL]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:46:48.429900
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(123) == Validation(123, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:46:55.108294
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:46:58.277566
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])



# Generated at 2022-06-24 00:47:02.602047
# Unit test for constructor of class Validation
def test_Validation(): # pragma: no cover
    assert Validation.fail(errors=[1, 2, 3]) == \
        Validation(None, [1, 2, 3])

    assert Validation.success(value=2) == \
        Validation(value=2, errors=[])


# Generated at 2022-06-24 00:47:08.703103
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.box import Box

    assert Validation.success(Box.just(10)) == Validation(Box.just(10), [])
    assert Validation.fail([10, 20, 30]) == Validation(None, [10, 20, 30])

# Generated at 2022-06-24 00:47:15.121134
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(123) == Validation.success(123)
    assert Validation.fail('A') == Validation.fail('A')
    assert Validation.success(123) != Validation.success(456)
    assert Validation.fail('A') != Validation.fail('B')
    assert Validation.success(123) != Validation.fail('A')
    assert Validation.fail('A') != Validation.success(123)


# Generated at 2022-06-24 00:47:22.937661
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Create two successful Validations with equals values and errors lists
    validation_1 = Validation.success({"name": "John", "age": 30})
    validation_2 = Validation.success({"name": "John", "age": 30})
    validation_3 = Validation.success({"name": "Jane", "age": 40})

    assert validation_1 == validation_2, "Expected validations are equals"
    assert validation_1 != validation_3, "Expected validations are not equals"

    # Create two failed Validations with equals errors lists
    validation_1 = Validation.fail(["message 1", "message 2"])
    validation_2 = Validation.fail(["message 1", "message 2"])
    validation_3 = Validation.fail(["message 3", "message 4"])

    assert validation_1 == validation_

# Generated at 2022-06-24 00:47:25.189503
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Nothing, Just
    from pymonet.monad_try import Failure

    assert Validation.fail(['Error 1', 'Error 2']).to_maybe() == Nothing()
    assert Validation.success(7).to_maybe() == Just(7)
    assert isinstance(Validation.success(Failure('Error', TypeError)), Validation)



# Generated at 2022-06-24 00:47:27.730504
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('1').is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-24 00:47:34.390499
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    res = Validation(1, [])
    assert res == Validation(1, [])
    assert not res == Validation(2, [])
    assert not res == Validation(1, [1])
    assert not res == Validation(2, [1])


# Generated at 2022-06-24 00:47:45.021019
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import TryError, Try

    assert Validation.fail([]).to_try() == Try(None, is_success=False)
    assert Validation.fail([1, 2]).to_try() == Try(None, is_success=False)
    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.success(1).to_try().or_else(0) == 1
    assert Validation.fail([]).to_try().or_else(0) == 0
    assert Validation.fail([1, 2]).to_try().or_else(0) == 0
    assert Validation.fail([TryError(), TryError()]).to_try().or_else(0) == 0

# Generated at 2022-06-24 00:47:51.037008
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad import Monad
    from pymonet.monad_list import List

    def f(value):
        return List([1, 2, 3]) if value % 2 == 0 else List([4, 5, 6])

    validation = Validation.success(2)
    result = validation.ap(f)
    assert result == Validation(2, [1, 2, 3])

    validation = Validation.success(3)
    result = validation.ap(f)
    assert result == Validation(3, [4, 5, 6])

    validation = Validation.fail(['Test'])
    result = validation.ap(f)
    assert result == Validation(None, ['Test'])

# Generated at 2022-06-24 00:47:53.732273
# Unit test for method bind of class Validation
def test_Validation_bind():
    def invoke(value):
        return Validation(value, [])

    assert Validation.success(20).bind(invoke).value == 20


# Generated at 2022-06-24 00:47:57.017107
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation(10, []).to_try() == Try(10)
    assert Validation(None, [10]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:48:02.382847
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.list_ import List

    # Successful Validation with same type
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    # Successful Validation with different type
    assert Validation.success([1, 2, 3]).map(List) == Validation.success(List([1, 2, 3]))
    # Failed Validation
    assert Validation.fail([]).map(List) == Validation.fail([])

# Unit tests for method bind of class Validation

# Generated at 2022-06-24 00:48:05.936076
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])



# Generated at 2022-06-24 00:48:13.502522
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.functors import List, map

    a = Validation.success([1, 2, 3])
    b = Validation.success([6, 5, 4])
    result = a.ap(List(b))
    assert len(result.errors) == 3
    assert result.value is None
    assert map(lambda x: x*x, a).ap(b).value == [36, 25, 16]

# Generated at 2022-06-24 00:48:18.694235
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(["first error", "second error"]).is_fail()
    assert Validation(None, []).is_fail() is False



# Generated at 2022-06-24 00:48:20.534793
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    validation = Validation.success(1)
    box = validation.to_box()
    assert box == Box(1)

# Generated at 2022-06-24 00:48:23.685888
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    from nose.tools import assert_equal

    assert_equal(Validation.success('value'), Validation('value', []))
    assert_equal(Validation.fail(['error']), Validation(None, ['error']))


# Generated at 2022-06-24 00:48:27.482293
# Unit test for method map of class Validation
def test_Validation_map():
    f = lambda x: x + 1
    assert Validation.success(0).map(f).value == 1


# Generated at 2022-06-24 00:48:31.751896
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left
    from pymonet.either import Right

    assert Validation.success().to_either() == Right()
    assert Validation.success(10).to_either() == Right(10)
    assert Validation.fail().to_either() == Left(None)
    assert Validation.fail([16]).to_either() == Left([16])


# Generated at 2022-06-24 00:48:35.141262
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail(1).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:48:40.339090
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Unit test for method to_maybe of class Validation
    """
    from pymonet.maybe import Maybe

    val = Validation.success(1)
    assert val.to_maybe() == Maybe.just(1)
    assert val.to_maybe().get_or_default(0) == 1
    val = Validation.fail([])
    assert val.to_maybe() == Maybe.nothing()
    assert val.to_maybe().get_or_default(0) == 0


# Generated at 2022-06-24 00:48:42.155214
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(0).to_maybe() == Maybe.just(0)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:48:46.165063
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail().map(lambda x: x + 1) == Validation.fail()


# Generated at 2022-06-24 00:48:53.704035
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success().to_either() == Right(None)
    assert Validation.success(123).to_either() == Right(123)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])

# Generated at 2022-06-24 00:49:00.476434
# Unit test for method ap of class Validation
def test_Validation_ap(): # pragma: no cover
    def fn(x):
        return Validation.fail([x + 1])

    assert Validation(1, [1]).ap(fn) == Validation(1, [1, 2])
    assert Validation(1, [1]).ap(lambda x: Validation.success(x + 2)) == Validation(3, [1])


# Generated at 2022-06-24 00:49:06.779954
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation.fail(errors=['Something is wrong', 'Another wrong'])
    assert str(validation) == 'Validation.fail[None, [\'Something is wrong\', \'Another wrong\']]'


# Generated at 2022-06-24 00:49:12.164856
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    input = Validation.fail(['error']).to_either()
    assert input == Left(['error'])

    input = Validation.success(True).to_either()
    assert input == Right(True)


# Generated at 2022-06-24 00:49:14.424657
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success(2).is_fail()
    assert Validation.fail([]).is_fail()
    assert Validation.fail([1, 2]).is_fail()


# Generated at 2022-06-24 00:49:26.287224
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for method to_try of class Validation"""

    from hypothesis import given, assume
    from hypothesis.strategies import tuples
    import unittest

    try:
        from pymonet.monad_try import Try
    except ImportError:  # pragma: no cover
        class Try:  # pylint: disable=too-few-public-methods
            """
            Dummy class for Try monad
            """

            def __init__(self, value, is_success):
                pass
            def __eq__(self, other):  # pylint: disable=no-self-use
                """
                Dummy method for eq
                """
                return True

    class TestValidationToTry(unittest.TestCase):
        """
        Unit test for method to_try of class Validation
        """

# Generated at 2022-06-24 00:49:34.585520
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test map method of Successful Validation class.
    When A is None and B is List, result Validation value is []
    """
    assert str(Validation.success(None).map(lambda a: a is None)) == 'True'

    """
    Test map method of Failed Validation class.
    When A is None and B is List, result Validation value is None and errors list is not empty
    """
    assert str(Validation.fail([1]).map(lambda a: a is None)) == 'Validation.fail[None, [1]]'


# Generated at 2022-06-24 00:49:38.382177
# Unit test for method bind of class Validation
def test_Validation_bind():
    # pylint: disable=missing-docstring
    from pymonet.monad_list import List

    assert Validation.success(2).bind(lambda x: List([x])) == List([2])


# Generated at 2022-06-24 00:49:41.079452
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    validation = Validation('hello', ['error'])
    box = validation.to_box()

    assert Box('hello') == box



# Generated at 2022-06-24 00:49:49.458078
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    _validation_try = Validation.success(42).to_try()
    assert _validation_try == Try(42, is_success=True)

    _validation_try = Validation.fail(['error']).to_try()
    assert _validation_try == Try(None, is_success=False)



# Generated at 2022-06-24 00:49:54.745842
# Unit test for constructor of class Validation
def test_Validation():
    result = Validation.success(1)
    assert result.value == 1 and result.errors == []
    result = Validation.fail()
    assert result.value is None and result.errors == []
    result = Validation.fail(['ERR'])
    assert result.value is None and result.errors == ['ERR']


# Generated at 2022-06-24 00:50:02.426070
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Unit test for method bind of class Validation."""
    def add_two(x):
        return x + 2

    def sub_two(x):
        return x - 2

    def add_result(x):
        return Validation.success(add_two(x))

    def sub_result(x):
        return Validation.success(sub_two(x))

    assert Validation.success(2).bind(add_result) == Validation.success(4)
    assert Validation.success(2).bind(add_result).bind(sub_result) == Validation.success(2)


# Generated at 2022-06-24 00:50:06.221823
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:50:08.735548
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)



# Generated at 2022-06-24 00:50:18.527676
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation.success()

    assert str(validation) == 'Validation.success[None]'

    validation = Validation.success('str')

    assert str(validation) == 'Validation.success[str]'

    validation = Validation.fail(['err1'])

    assert str(validation) == 'Validation.fail[None, [\'err1\']]'

    validation = Validation.fail(['err1', 'err2'])

    assert str(validation) == 'Validation.fail[None, [\'err1\', \'err2\']]'


# Generated at 2022-06-24 00:50:20.752749
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(None, []) == Validation.fail().to_box()
    assert Validation(1, []) == Validation.success(1).to_box()


# Generated at 2022-06-24 00:50:24.045813
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # Test for successful Validation
    assert(str(Validation.success(10)) == 'Validation.success[10]')

    # Test for failed Validation
    assert(str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]')


# Generated at 2022-06-24 00:50:29.994090
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """Test Validation.__str__ implementation."""
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'



# Generated at 2022-06-24 00:50:36.851466
# Unit test for method map of class Validation
def test_Validation_map():
    success_value = Validation.success('value').map(lambda x: x + '_mapped')
    success_value_mapped = Validation.success('value_mapped')

    fail_value = Validation.fail().map(lambda x: x + '_mapped')
    fail_value_mapped = Validation.fail()

    assert success_value == success_value_mapped
    assert fail_value == fail_value_mapped


# Generated at 2022-06-24 00:50:39.414799
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test for success Validation
    """
    validation = Validation.success()
    assert validation.is_success() is True



# Generated at 2022-06-24 00:50:50.693886
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.functor import Functor

    # Given
    validation_1 = Validation('test', [])
    validation_2 = Validation('test', ['error'])

    # When
    validation_1_mapped = validation_1.map(lambda i: i + '_mapped')
    validation_2_mapped = validation_2.map(lambda i: i + '_mapped')

    # Then

# Generated at 2022-06-24 00:51:01.253459
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe

    assert Validation.success().is_success()

    assert not Validation.success(None).is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail(None).is_success()
    assert not Validation.fail({}).is_success()
    assert not Validation.fail([0]).is_success()

    assert Validation.success(0).is_success()
    assert Validation.success([]).is_success()
    assert Validation.success({}).is_success()

    assert not Validation.fail([0]).is_success()
    assert not Validation.fail([Try.fail(ValueError())]).is_success()

# Generated at 2022-06-24 00:51:04.217057
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test "to_try" method of Validation class.
    """
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)

    assert Validation.fail(['error']).to_try() == Try.fail('error')


# Generated at 2022-06-24 00:51:08.605519
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    validation = Validation(2, [])
    success = Success(2)
    failure = Failure(None)

    assert validation.to_try() == success
    assert validation.then_fail([1, 2, 3]).to_try() == failure

# Generated at 2022-06-24 00:51:12.663566
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 'value') == Validation.success('value').to_lazy()
    assert Lazy(lambda: None) == Validation.fail().to_lazy()


# Generated at 2022-06-24 00:51:18.318542
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    def test_function():
        return 5

    validation = Validation.success(test_function())
    assert validation.to_lazy().resolve() == test_function()

    lazy = Lazy(test_function)
    assert validation.to_lazy() == lazy


# Generated at 2022-06-24 00:51:24.305579
# Unit test for method ap of class Validation
def test_Validation_ap():
    from test.tools import assert_that

    v1 = Validation.fail(['error1']).ap(lambda x: Validation.success('success'))
    v2 = Validation.fail(['error1', 'error2']).ap(lambda x: Validation.fail(['error2']))
    v3 = Validation.success('success').ap(lambda x: Validation.fail(['error1']))

    assert_that(v1, is_(Validation.fail(['error1'])))
    assert_that(v2, is_(Validation.fail(['error1', 'error2', 'error2'])))
    assert_that(v3, is_(Validation.fail(['error1'])))

# Generated at 2022-06-24 00:51:29.993164
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe(): # pragma: no cover
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    validation_success = Validation.success('success')
    validation_failure = Validation.fail('failure')

    assert validation_success.to_maybe() == Maybe.just('success')
    assert validation_failure.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:51:33.632456
# Unit test for method ap of class Validation
def test_Validation_ap():
    def get_monad(value):
        return Validation.fail([value])
    val = Validation.success(1).ap(get_monad)
    assert val == Validation(1, [1])

# Generated at 2022-06-24 00:51:35.970188
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(True).is_success()
    assert not Validation.fail([True]).is_success()


# Generated at 2022-06-24 00:51:41.304407
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail() == Validation.fail()
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1, 2]) == Validation.fail([1, 2])
    assert Validation.fail([1]) != Validation.fail([1, 2])



# Generated at 2022-06-24 00:51:45.944292
# Unit test for constructor of class Validation
def test_Validation():
    success = Validation.success()
    assert success.value == None
    assert success.is_success()
    assert not success.is_fail()

    fail = Validation.fail()
    assert fail.value == None
    assert fail.is_fail()
    assert not fail.is_success()


# Generated at 2022-06-24 00:51:50.541909
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    lazy = Validation.fail([1, 2, 3]).to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy.value == None


# Generated at 2022-06-24 00:51:55.476210
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail(['a', 'b'])) == 'Validation.fail[None, [\'a\', \'b\']]'


# Generated at 2022-06-24 00:51:59.900753
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Test Validation to Either works as expected"""
    from pymonet.either import Either

    assert Validation.success('success').to_either() == Either.Right('success')
    assert Validation.fail(['error']).to_either() == Either.Left(['error'])


# Generated at 2022-06-24 00:52:08.511152
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation.

    :return: Nothing
    """
    from random import randint, choice
    from pymonet.list import List
    from pymonet.maybe import Maybe

    def f(x):
        return x * 3

    def g(x):
        return x + 5

    def h(x):
        if x < 0:
            return Maybe.nothing()
        return Maybe.just(x)

    def i(x):
        lst = List(x).fold_l(lambda x, y: x + [y], [])
        return Maybe.from_list(lst)


# Generated at 2022-06-24 00:52:10.544901
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('test').to_lazy() == Lazy(lambda: 'test')


# Generated at 2022-06-24 00:52:11.866933
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    result = Validation.success(True)
    assert result.is_success()
    assert result.value


# Generated at 2022-06-24 00:52:14.015305
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() is False
    assert Validation.fail().is_fail() is True


# Generated at 2022-06-24 00:52:17.931809
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation(1, []).to_maybe() == Maybe.just(1)
    assert Validation(None, [2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:24.999543
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'
    assert str(Validation.fail(['a', 'b'])) == "Validation.fail[None, ['a', 'b']]"


# Generated at 2022-06-24 00:52:30.168426
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.fail(['error1']).to_box() == Box(None)
    assert Validation.success(5).to_box() == Box(5)


# Generated at 2022-06-24 00:52:32.105013
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success().to_maybe() == Maybe.just(None)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:39.704032
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    def given_validation_fail_when_is_fail_then_true():
        validation = Validation.fail(['Wrong key name'])
        assert validation.is_fail()

    def given_validation_success_when_is_fail_then_false():
        validation = Validation.success('Value')
        assert validation.is_fail() is False

    given_validation_fail_when_is_fail_then_true()
    given_validation_success_when_is_fail_then_false()


# Generated at 2022-06-24 00:52:45.003992
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """
    Validation is_fail method should return False when errors list are empty.

    :return: True when test passed
    """

    assert Validation.success(value='Hello').is_fail() == False

    assert Validation.success().is_fail() == False

    assert Validation.fail().is_fail() == True

    assert Validation.fail(errors=[1, 2, 3]).is_fail() == True


# Generated at 2022-06-24 00:52:56.795910
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(None).to_either() == Right(None)
    assert Validation.success(False).to_either() == Right(False)
    assert Validation.success(True).to_either() == Right(True)
    assert Validation.success(123).to_either() == Right(123)
    assert Validation.success('abc').to_either() == Right('abc')
    assert Validation.success([1, 2, 3]).to_either() == Right([1, 2, 3])
    assert Validation.success({'a': 123, 'b': 321}).to_either() == Right({'a': 123, 'b': 321})

    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([None]).to_

# Generated at 2022-06-24 00:52:59.917304
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert(str(Validation.success(5)) == 'Validation.success[5]')
    assert(str(Validation.fail(['5'])) == 'Validation.fail[None, [\'5\']]')


# Generated at 2022-06-24 00:53:10.491994
# Unit test for constructor of class Validation
def test_Validation():
    # Test equal of two Validations
    assert Validation(1, []) == Validation(1, [])
    assert not Validation(1, ['error']) == Validation(1, [])
    assert not Validation(1, []) == Validation(2, [])
    assert not Validation(1, ['error']) == Validation(1, ['error2'])

    # Test equal of two Validations
    assert Validation(1, []) == Validation(1, [])
    assert not Validation(1, ['error']) == Validation(1, [])
    assert not Validation(1, []) == Validation(2, [])
    assert not Validation(1, ['error']) == Validation(1, ['error2'])

    # Test if Validation is successful or not

# Generated at 2022-06-24 00:53:17.288148
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    v1 = Validation(1, ['error1'])
    v2 = Validation(2, ['error2'])
    assert v1.ap(lambda x: v2) == Validation(1, ['error1', 'error2'])


# Generated at 2022-06-24 00:53:18.366580
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail([1, 2, 3]).is_fail()

# Generated at 2022-06-24 00:53:23.864419
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    # Success
    assert str(Validation.success(123)) == "Validation.success[123]"

    # Fail
    assert str(Validation.fail(['error1', 'error2'])) == "Validation.fail[None, ['error1', 'error2']]"


# Generated at 2022-06-24 00:53:33.839024
# Unit test for method map of class Validation
def test_Validation_map():
    """Unit test for method map of class Validation."""
    from .maybe import Maybe
    from .monad_try import Try

    f = lambda x: x + 1
    g = lambda x: Try(x + 1)
    h = lambda x: Maybe.just(x + 1)

    success_validation_integer = Validation.success(1)
    fail_validation_integer = Validation.fail(errors=[1])

    assert success_validation_integer.map(f) == Validation(2, [])
    assert success_validation_integer.map(g).value.value == 2
    assert success_validation_integer.map(h).value.value == 2

    assert fail_validation_integer.map(f) == Validation(None, [1])

# Generated at 2022-06-24 00:53:37.355338
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    validation = Validation.success(10)
    assert validation.to_try().is_success() == True

    validation = Validation.fail([1, 2, 3])
    assert validation.to_try().is_fail() == True


# Generated at 2022-06-24 00:53:42.819745
# Unit test for method map of class Validation
def test_Validation_map():  # pragma: no cover
    assert Validation.success(2).map(lambda x: x + 1) == Validation.success(3)
    assert Validation.fail(['error']).map(lambda x: x + 1) == Validation.fail(['error'])
    assert Validation.success(2).map(lambda _: None) == Validation.success(None)


# Generated at 2022-06-24 00:53:47.583912
# Unit test for method ap of class Validation
def test_Validation_ap():

    # create Validation
    validation = Validation(1, [])

    # assert Validation is successful
    assert validation.is_success() is True

    # take function and returns new Validation with previous value and concated new and old errors
    def my_function(x):
        return Validation(x * 2, ['error 1'])

    # take Function(A) -> Validation[B, E] and returns new Validation with previous value
    image = validation.ap(my_function)
    assert image.value == 2
    assert image.errors == ['error 1']
    assert not image.is_success()

# Generated at 2022-06-24 00:53:50.031425
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    try_success = Try(1).to_validation()
    try_fail = Try(None, is_success=False).to_validation()

    assert try_success.to_try() == Try.success(1)
    assert try_fail.to_try() == Try.fail(ValueError('None Value'))


# Generated at 2022-06-24 00:53:51.882078
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    valid = Validation.success(1)
    assert valid.to_maybe() == Maybe.just(1)

    invalid = Validation.fail([Left("error")])
    assert valid.to_maybe() == Maybe.just(1)

# Generated at 2022-06-24 00:54:01.848005
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.monad_try import Try
    from pymonet.either import Right
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    assert Validation.success().is_success()
    assert not Validation.fail(['error one']).is_success()
    assert Validation.success().to_maybe().is_success()
    assert not Validation.success().to_maybe().to_either().is_success()
    assert not Validation.success().to_try().is_success()
    assert Validation.success().to_box().is_success()
    assert Validation.success().to_lazy().is_success()
    assert Validation.success().to_either().is_success()
    assert not Validation.fail(['error two']).to_either().is_success()

# Generated at 2022-06-24 00:54:06.939018
# Unit test for constructor of class Validation
def test_Validation():
    """
    Run tests on Validation constructor.

    :returns: AssertionError exception when tests are failed
    """
    try:
        assert Validation.success(1) == Validation(1, [])
        assert Validation.fail([1, 2]) == Validation(None, [1, 2])
    except AssertionError:
        print('Validation constructor failed!')
        raise


# Generated at 2022-06-24 00:54:14.610167
# Unit test for method ap of class Validation
def test_Validation_ap(): # pragma: no cover
    from pymonet.validation import Validation
    from pymonet.functor import Functor
    from typing import Union

    class Format(Functor):
        def __init__(self, value):
            self.value = value

        def map(self, mapper):
            return Format(mapper(self.value))

        def to_validation(self):
            if not isinstance(self.value, str):
                return Validation(self.value, ['Not String'])
            return Validation(self.value, [])

    def ap(format: Format) -> Validation:
        return format.to_validation()

    def addr_validation(address: Union[str, None]) -> Validation:
        if not address:
            return Validation(address, ['Address is empty'])