

# Generated at 2022-06-24 00:44:15.951105
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(errors=['My Error']).is_fail() == True
    assert Validation.fail().is_fail() == True
    assert Validation.success().is_fail() == False
    assert Validation.success(1).is_fail() == False


# Generated at 2022-06-24 00:44:17.800741
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(1).to_lazy().value == Validation.success(1).value


# Generated at 2022-06-24 00:44:21.921154
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(True).is_success()
    assert not Validation.success(False).is_success()

    assert not Validation.fail([]).is_success()
    assert not Validation.fail([1]).is_success()
    assert not Validation.fail([1, 2]).is_success()


# Generated at 2022-06-24 00:44:27.981462
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.validation import Validation

    def test(v1, v2, expected):
        actual = v1 == v2
        actual = actual == expected
        return actual

    success_v1 = Validation.success(1)
    success_v2 = Validation.success(1)
    success_v3 = Validation.success(2)
    fail_v1 = Validation.fail([1])
    fail_v2 = Validation.fail([1])
    fail_v3 = Validation.fail([2])

    assert test(success_v1, success_v1, True)
    assert test(success_v1, success_v2, True)
    assert test(success_v1, success_v3, False)
    assert test(success_v1, fail_v1, False)


# Generated at 2022-06-24 00:44:33.853368
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    test_Validation_to_try tests method to_try of class Validation
    """
    from pymonet.monad_try import Try

    VALIDATION = Validation(None, ['a']).to_try()

    assert VALIDATION == Try(None, is_success=False)


# Generated at 2022-06-24 00:44:36.141453
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(1, []).is_success()
    assert Validation(None, [2]).is_fail()


# Generated at 2022-06-24 00:44:43.378375
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    assert (Validation.success('ok').to_lazy() ==
            Lazy(lambda: 'ok') ==
            Try('ok')
            )
    assert (Validation.fail().to_lazy() ==
            Lazy(lambda: None)
            )

# Generated at 2022-06-24 00:44:53.305311
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Test for method is_success returns True when errors empty.
    """
    from pymonet.monad_try import Try
    from pymonet.either import Left, Right

    assert Validation.success(1).is_success() == True
    assert Validation.fail([]).is_success() == False
    assert Validation.fail([Left(1)]).is_success() == False
    assert Validation.fail([Right(1)]).is_success() == False
    assert Validation.fail([Try(1)]).is_success() == False
    assert Validation.fail([Try(1, is_success=False)]).is_success() == False
    assert Validation.fail([Try(1, is_success=True)]).is_success() == False



# Generated at 2022-06-24 00:44:58.773230
# Unit test for method map of class Validation
def test_Validation_map():
    def mapper(value):
        return value + 1

    assert Validation(2, ["Some error"]).map(mapper) == Validation(3, ["Some error"])
    assert Validation(2, []).map(mapper) == Validation(3, [])


# Generated at 2022-06-24 00:45:01.393333
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Checks if Validation converted to box contains same value.
    """
    from pymonet.box import Box

    assert Validation(2, []).to_box() == Box(2)


# Generated at 2022-06-24 00:45:07.703665
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    def unit_test(input_var, output_var):
        validation = Validation(input_var, [])
        assert validation.to_box() == output_var

    unit_test(1, Box(1))
    unit_test("Hello", Box("Hello"))
    unit_test([1, 2, 3], Box([1, 2, 3]))
    unit_test((1, 2, 3), Box((1, 2, 3)))


# Generated at 2022-06-24 00:45:16.862122
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    from pymonet.monad_list import List

    fn = lambda i: Validation.success(i + 1)

    assert Validation.success(1).ap(fn).errors == []
    assert Validation.fail().ap(fn).value is None
    assert Validation.fail().ap(fn).errors == []

    assert Validation.success(1).ap(lambda i: Validation.fail()).errors == []
    assert Validation.fail().ap(lambda i: Validation.success(i + 1)).errors == []

    assert Validation.success(1).ap(lambda i: Validation.fail([i, i + 1])).errors == [1, 2]

# Generated at 2022-06-24 00:45:19.023734
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail(['a', 'b']) == Validation(None, ['a', 'b'])



# Generated at 2022-06-24 00:45:28.578805
# Unit test for constructor of class Validation
def test_Validation():
    """
    Unit test for constructor of class Validation.
    """

    # Case 1: Successful validation.
    value = Validation.success("Test")
    assert value.value == "Test"
    assert len(value.errors) == 0
    assert value.is_success() is True
    assert value.is_fail() is False
    assert value == Validation("Test", [])

    # Case 2: Failed Validation.
    value = Validation.fail(["test"])
    assert value.value is None
    assert len(value.errors) == 1 and value.errors[0] == "test"
    assert value.is_success() is False
    assert value.is_fail() is True
    assert value == Validation(None, ["test"])


# Generated at 2022-06-24 00:45:31.106001
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    result = Validation.fail([1, 100])
    assert result.is_fail(), 'Validation is failed'
    assert not result.is_success(), 'Validation is not failed'


# Generated at 2022-06-24 00:45:37.189411
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """
    It specifies Validation to Try transformation correctness.

    :returns: Nothing
    :rtype: None
    """
    from pymonet.lazy import Lazy

    validation = Validation.success(2)
    assert validation.to_lazy() == Lazy(lambda: 2)


# Generated at 2022-06-24 00:45:41.601927
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(2).to_maybe().value == Maybe.just(2).value
    assert Validation.fail(2).to_maybe().value == Maybe.nothing().value


# Generated at 2022-06-24 00:45:46.058894
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([2]).to_either() == Left([2])
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])

# Generated at 2022-06-24 00:45:54.134795
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.utils import to_list

    success = Validation.success(lambda x: x + 1)
    assert Validation.success(2) == success.bind(lambda fn: Validation.success(fn(1)))

    success = Validation.success(lambda x: x + 1)
    assert Validation.success([2, 4, 6]) == success.bind(
        lambda fn: Validation.success([1, 2, 3]).map(to_list(fn))
    )

    failure = Validation.fail([1])
    assert Validation.fail([1]) == failure.bind(lambda fn: Validation.success(fn(1)))


# Generated at 2022-06-24 00:45:57.184496
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.maybe import Maybe

    def mapper(x):
        return Maybe.just(x).map(lambda x: x ** 2)

    validation = Validation.success(1)
    assert(validation.ap(mapper).to_maybe() == Maybe.just(1))


# Generated at 2022-06-24 00:45:59.109062
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.validation import Validation
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()


# Generated at 2022-06-24 00:46:02.872215
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(42).to_lazy() == Lazy(lambda: 42)
    assert Validation.fail('error').to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:46:05.955567
# Unit test for method bind of class Validation
def test_Validation_bind():
    # Test successful Validation
    assert Validation.success(3)\
        .bind(lambda x: Validation.success(x + 1)) == Validation.success(4)



# Generated at 2022-06-24 00:46:11.304289
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    validate = Validation.success(1)
    print('validate = {}'.format(validate))
    result = validate.to_maybe()
    print('result = {}'.format(result))
    assert result.is_just()
    assert 1 == result.value()
    validate = Validation.fail([Exception('Unit test')])
    print('validate = {}'.format(validate))
    result = validate.to_maybe()
    print('result = {}'.format(result))
    assert result.is_nothing()



# Generated at 2022-06-24 00:46:12.917077
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.fail([1]).is_success() == False


# Generated at 2022-06-24 00:46:16.180787
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(2).to_box() == Box(2)
    assert Validation.fail(1).to_box() == Box(None)


# Generated at 2022-06-24 00:46:18.909566
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(10).value == 10
    assert Validation.fail(['error']).value == None


# Generated at 2022-06-24 00:46:21.564029
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: x * x) == Validation(4, [])


# Generated at 2022-06-24 00:46:24.680934
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Validation.success(1).to_lazy()

    assert(lazy == Lazy(lambda: 1))
    assert(lazy.get() == 1)

    lazy = Validation.fail([]).to_lazy()

    assert(lazy == Lazy(lambda: None))
    assert(lazy.get() is None)


# Generated at 2022-06-24 00:46:29.410883
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    validation1 = Validation.success(1)
    validation2 = Validation.success(1)
    assert validation1 == validation2

    validation1 = Validation.fail(['error1', 'error2'])
    validation2 = Validation.fail(['error2', 'error1'])
    assert validation1 == validation2

    validation1 = Validation.success(1)
    assert validation1 != Validation.success(2)

    validation1 = Validation.fail(['error1'])
    assert validation1 != Validation.fail(['error1', 'error2'])



# Generated at 2022-06-24 00:46:31.655042
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    validation = Validation.success(True)

    assert validation.to_try() == Try.success(True)


# Generated at 2022-06-24 00:46:37.446092
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Right
    from pymonet.validation import Validation

    val_success = Validation.success(43)
    val_fail = Validation.fail()

    assert val_success.to_maybe().equals(Right(43).to_maybe()) == True
    assert val_fail.to_maybe().is_empty() == True


# Generated at 2022-06-24 00:46:41.497870
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.success().is_fail()
    assert not Validation(42, []).is_fail()
    assert Validation(None, ["error"]).is_fail()


# Generated at 2022-06-24 00:46:47.864775
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    validate_success = Validation.success(123)
    assert validate_success.to_lazy() == Lazy(lambda: 123)

    validate_with_error = Validation.fail(['error'])
    assert validate_with_error.to_lazy() == Lazy(lambda: None)



# Generated at 2022-06-24 00:46:55.601771
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Unit test for method to_maybe of class Validation"""
    from pymonet.maybe import Maybe

    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()
    assert Validation.success(None).to_maybe() == Maybe.just(None)
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success('1').to_maybe() == Maybe.just('1')


# Generated at 2022-06-24 00:46:58.632999
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['Error']) == Validation(None, ['Error'])


# Generated at 2022-06-24 00:47:01.875507
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(7).to_either() == Right(7)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:47:08.232574
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_validation import Validation

    assert Validation.success().ap(lambda _: Validation.success()) == Validation(None, [])
    assert Validation.success(1).ap(lambda x: Validation.success(2)) == Validation(2, [])
    assert Validation.success(1).ap(lambda x: Validation.success(2, [3])) == Validation(2, [3])
    assert Validation.success(1).ap(lambda x: Validation.fail([2])).errors == [2]
    assert Validation.success(1, [2]).ap(lambda x: Validation.fail([3])).errors == [2, 3]

# Generated at 2022-06-24 00:47:12.071966
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(5).to_try() == Try(5, is_success=True)
    assert Validation.fail(['error1']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:47:13.924569
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():  # pragma: no cover
    assert Validation.fail().is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-24 00:47:22.075543
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success(1).is_success() == True
    assert Validation.success('').is_success() == True
    assert Validation.success(True).is_success() == True

    assert Validation.fail().is_success() == False
    assert Validation.fail(['Error']).is_success() == False
    assert Validation.fail([1]).is_success() == False
    assert Validation.fail(['']).is_success() == False
    assert Validation.fail([True]).is_success() == False

    assert Validation.success(1).is_success() == True
    assert Validation.success('A').is_success() == True
    assert Validation.success(True).is_success() == True

# Generated at 2022-06-24 00:47:27.152418
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    validation = Validation.success(value=1)
    assert validation.to_try() == Try(1, is_success=True)

    validation = Validation.fail(errors=[])
    assert validation.to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:47:34.843223
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success(None).to_maybe() == Maybe.just(None)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:47:39.672361
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail([1,2]).to_box() == Box(None)


# Generated at 2022-06-24 00:47:40.672946
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert Validation.fail().is_success() is False


# Generated at 2022-06-24 00:47:48.275444
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Failure, Success
    from pymonet.validation import Validation

    res = Validation(5, []).to_try()
    assert isinstance(res, Success)
    assert res.value == 5


    res = Validation(5, ['error']).to_try()
    assert isinstance(res, Failure)
    assert res.value == 5



# Generated at 2022-06-24 00:47:54.133877
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    value = False
    assert Validation.fail([]).is_fail() == value
    assert Validation.fail(['a']).is_fail() == value
    assert Validation.success('success').is_fail() != value



# Generated at 2022-06-24 00:47:57.054789
# Unit test for constructor of class Validation
def test_Validation():
    val = Validation('value', ['error1', 'error2'])
    assert val.value == 'value'
    assert val.errors == ['error1', 'error2']



# Generated at 2022-06-24 00:48:03.466031
# Unit test for constructor of class Validation
def test_Validation():
    init = Validation.fail()
    assert init == Validation(None, [])
    assert init.is_fail()
    assert init.is_success() is False
    assert init.to_either() == Left([])
    assert init.to_maybe() == Maybe.nothing()
    assert init.to_box() == Box(None)

    init = Validation.success('value')
    assert init == Validation('value', [])
    assert init.is_success()
    assert init.is_fail() is False
    assert init.to_either() == Right('value')
    assert init.to_maybe() == Maybe.just('value')
    assert init.to_box() == Box('value')


# Generated at 2022-06-24 00:48:10.924279
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Unit test for method to_box of class Validation.

    :returns: True, if test passed
    :rtype: Boolean
    """
    from pymonet.box import Box
    from pymonet.validation import Validation
    from pymonet.monad_identity import identity

    if not identity(Validation.success(2)).to_box() == Box(2):
        return False

    if not Validation.success(2).to_box() == Box(2):
        return False

    return True


# Generated at 2022-06-24 00:48:12.701842
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert (Validation.fail(['fail']).is_fail())
    assert (not Validation.success().is_fail())


# Generated at 2022-06-24 00:48:14.568653
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation(None, []).is_success()
    assert not Validation(None, ['test']).is_success()


# Generated at 2022-06-24 00:48:17.720800
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    v1 = Validation.success(42)
    assert v1.to_try() == Try(42)
    v2 = Validation.fail(["error"])
    assert v2.to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:48:23.529131
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.maybe import Maybe

    assert (Validation.success(2)
            .ap(Maybe.just(lambda x: x * 2))
            .value == 4)

    assert (Validation.success(2)
            .ap(Maybe.nothing())
            .value == 2)

    assert (Validation.success(2)
            .ap(Maybe.nothing())
            .is_success())

    assert (Validation.fail([1, 2])
            .ap(Maybe.just(lambda x: x * 2))
            .value == None)

    assert (Validation.fail([1, 2])
            .ap(Maybe.just(lambda x: x * 2))
            .errors == [1, 2])


# Generated at 2022-06-24 00:48:33.289388
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(1).ap(Validation.fail(['errors'])) == Validation(1, ['errors'])
    assert Validation.fail(['errors1']).ap(Validation.fail(['errors2'])) == Validation(None, ['errors1', 'errors2'])
    assert Validation.fail(['errors']).ap(Validation.success(2)) == Validation(None, ['errors'])
    assert Validation.success(1).ap(Validation.success(2)) == Validation(1, [])
    assert Validation.success(1).ap(Validation.success(2).ap(Validation.fail(['error']))) == Validation(1, ['error'])


# Generated at 2022-06-24 00:48:40.961571
# Unit test for method bind of class Validation
def test_Validation_bind():
    v = Validation.fail(['error'])
    v1 = v.bind(lambda: Validation.fail(['error2']))
    assert v1.errors == ['error2']
    v2 = v.bind(lambda: Validation.success(123))
    assert v2.errors == ['error']
    v3 = Validation.success(123).bind(lambda x: Validation.fail(['error2']))
    assert v3.errors == ['error2']


# Generated at 2022-06-24 00:48:46.033051
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    def test_func():
        return 10

    assert Validation.success(10).to_lazy() == Lazy(test_func)


# Generated at 2022-06-24 00:48:49.317763
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation.success(10)
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.success(10) != Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:48:55.808704
# Unit test for method bind of class Validation
def test_Validation_bind():
    def is_pos(x):
        if x > 0:
            return Validation.success(True)
        return Validation.fail(['Number is negative'])

    assert Validation.success(2).bind(is_pos) == Validation(True, [])
    assert Validation.success(-5).bind(is_pos) == Validation(None, ['Number is negative'])
    assert Validation.fail(['Invalid number']).bind(is_pos) == Validation(None, ['Invalid number'])


# Generated at 2022-06-24 00:49:03.043616
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success('value')) == 'Validation.success[value]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:49:04.549396
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    expected = Validation.success(3)
    actual = Validation.success(3).to_lazy().flat_map(lambda x: x()).to_validation()
    assert(actual == expected)


# Generated at 2022-06-24 00:49:06.788561
# Unit test for constructor of class Validation
def test_Validation():
    # it tests empty errors
    assert Validation.success(1) == Validation(1, [])
    # it tests with errors
    assert Validation.fail(['something went wrong']) == Validation(None, ['something went wrong'])


# Generated at 2022-06-24 00:49:11.849503
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(1, [])) == "Validation.success[1]"
    assert str(Validation(None, [1, 2, 3])) == "Validation.fail[None, [1, 2, 3]]"



# Generated at 2022-06-24 00:49:18.462655
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation(123, []).to_try() == Success(123)
    assert Validation(None, []).to_try() == Try(None, True)
    assert Validation(None, [1, 2]).to_try() == Failure([1, 2])

# Generated at 2022-06-24 00:49:28.093744
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    success = Validation.success(5)
    fail = Validation.fail(['Fail to validate'])

    assert success.ap(lambda x: Try(0, is_success=True)) == Validation(5, [])
    assert success.ap(lambda x: Try(0, is_success=False)) == Validation(5, [])
    assert fail.ap(lambda x: Try(0, is_success=True)) == Validation(None, ['Fail to validate'])
    assert fail.ap(lambda x: Try(0, is_success=False)) == Validation(None, ['Fail to validate'])

    assert success.ap(lambda x: Box(0)) == Validation(5, [])

# Generated at 2022-06-24 00:49:32.053398
# Unit test for method is_success of class Validation
def test_Validation_is_success():

    assert Validation.success(2).is_success() == True
    assert Validation.success().is_success() == True
    assert Validation.fail(['error']).is_success() == False


# Generated at 2022-06-24 00:49:40.753200
# Unit test for constructor of class Validation
def test_Validation():
    # positive case
    assert Validation.fail(['error']) == Validation(None, ['error'])
    assert Validation.success('value') == Validation('value', [])

    # negative cases
    assert Validation.fail(['error']) != 'Validation[None, []]'
    assert Validation.success('value') != 'Validation[value, []]'
    assert Validation.success('value') != Validation(None, ['error'])
    assert Validation.fail(['error']) != Validation('value', [])

    # test repr
    assert repr(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'
    assert repr(Validation.success('value')) == 'Validation.success[value]'

    # test success
    assert Validation.success

# Generated at 2022-06-24 00:49:43.209283
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(1, []).to_box() == (Box(1))
    assert Validation(None, [None]).to_box() == (Box(None))


# Generated at 2022-06-24 00:49:47.699671
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """Validation is success if errors list is empty"""
    validation = Validation.success(1)
    assert validation.is_success()
    validation = Validation.fail([1])
    assert not validation.is_success()



# Generated at 2022-06-24 00:49:51.727624
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(Validation.success) == Validation.success(Validation.success(2))
    assert Validation.fail([]).map(Validation.success) == Validation.fail([])


# Generated at 2022-06-24 00:50:02.303285
# Unit test for method ap of class Validation
def test_Validation_ap():
    """Test ap method implementation."""
    assert Validation.fail(['first', 'second']).ap(
        lambda x: Validation.fail(['additional'])).errors == ['first',
                                                              'second', 'additional']
    assert Validation.success(42).ap(lambda x: Validation.fail(['additional'])).errors == ['additional']
    assert Validation.success(42).ap(
        lambda x: Validation.fail(['additional'])).ap(lambda x: Validation.fail(['more'])).errors == [
            'additional', 'more']
    assert Validation.fail(['first', 'second']).ap(lambda x: Validation.success()).errors == [
        'first', 'second']

# Generated at 2022-06-24 00:50:08.737292
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Empty errors list
    errors_empty = []
    # Not empty errors list
    errors_not_empty = ['error']

    # Validation value
    value = 'value'

    # Function that takes any and returns not empty list
    fn = lambda _: Validation(None, errors_not_empty)

    # Validation that has errors
    validation_fail = Validation(value, errors_not_empty)
    # Validation that has no errors
    validation_success = Validation(value, errors_empty)

    # Call ap method on successful Validation and take result
    result = validation_success.ap(fn)
    # Create Validation with errors concated
    expected = Validation(value, errors_not_empty + errors_empty)
    # Validate
    assert result == expected

    # Call ap method on failed Validation and take

# Generated at 2022-06-24 00:50:19.226376
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    """Unit test for Validation.ap method"""
    from pymonet.either import Left
    from pymonet.monad_try import Try

    assert (Validation.fail([1, 2]).ap(lambda v: Validation.fail([3])).errors == [1, 2, 3])
    assert (Validation.fail([1]).ap(lambda v: Validation.success(v)).errors == [1])
    assert (Validation.success(1).ap(lambda v: Validation.fail([2])).errors == [2])
    assert (Validation.success(1).ap(lambda v: Validation.success(v)).value == 1)

# Generated at 2022-06-24 00:50:20.732363
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(0).is_success()
    assert not Validation.fail([]).is_success()


# Generated at 2022-06-24 00:50:23.133213
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == from_just(Right(1))
    assert Validation.fail(['']).to_either() == from_just(Left(['']))


# Generated at 2022-06-24 00:50:33.694131
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test bind method of class Validation.
    """
    # Validation can transform itself to other monad class
    # like Try, Either, Maybe and Box.
    def test_bind_with_other_monad():
        """
        Validation can transform itself to other monad class
        like Try, Either, Maybe and Box.
        """
        assert Validation.success(10).bind(lambda x: Validation.success(x / 2)) == Validation.success(5)
        assert Validation.success(10).bind(lambda x: Validation.fail(2)) == Validation.fail(2)
        assert Validation.fail(2).bind(lambda x: Validation.success(x)) == Validation.fail(2)
        assert Validation.fail(2).bind(lambda x: Validation.fail(x)) == Val

# Generated at 2022-06-24 00:50:39.023133
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v1 = Validation.success([{'id': 1, 'name': 'one'}])
    v2 = Validation.success([{'id': 1, 'name': 'one'}])
    v3 = Validation.success([{'id': 1, 'name': 'one'}])
    assert v1 == v2
    assert v2 == v3

# Generated at 2022-06-24 00:50:45.193784
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(5, []).to_maybe() == Maybe.just(5)
    assert Validation(None, []).to_maybe() == Maybe.just(None)
    assert Validation(5, [1, 2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:50:50.595828
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    value = "I'm Validation value"
    errors = ["I'm validation error"]
    validation = Validation(value, errors)

    assert Left(errors) == validation.to_either()

    validation = Validation(value, [])
    assert Right(value) == validation.to_either()



# Generated at 2022-06-24 00:50:57.256682
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('a')) == 'Validation.success[a]'
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail(['first error'])) == 'Validation.fail[None, [\'first error\']]'
    assert str(Validation.fail(['first error', 'second error'])) == 'Validation.fail[None, [\'first error\', \'second error\']]'


# Generated at 2022-06-24 00:51:01.339099
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    success = Validation.success(Box(5))
    fail = Validation.fail()

    assert success.to_box().value == Box(5)
    assert fail.to_box().value is Box(None)


# Generated at 2022-06-24 00:51:05.439054
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(2).ap(Validation.success(lambda x: x + 1)) == Validation.success(3)
    assert Validation.success(2).ap(Validation.success(lambda x: x / 0)) == Validation.success(2)
    assert Validation.success(2).ap(Validation.fail('error')) == Validation.fail('error')
    assert Validation.success(2).ap(Validation.fail(['error1', 'error2'])) == Validation.fail(['error1', 'error2'])


# Generated at 2022-06-24 00:51:11.308338
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation.success('good')
    assert validation.value == 'good'
    assert validation.errors == []
    assert validation.is_success()
    assert not validation.is_fail()

    validation = Validation.fail(['bad'])
    assert validation.value == None
    assert validation.errors == ['bad']
    assert not validation.is_success()
    assert validation.is_fail()


# Generated at 2022-06-24 00:51:18.434501
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    fn_success = Validation.success(lambda x: x + 3)
    fn_fail = Validation.fail(['SHOULD FAIL'])

    failed_validation = Validation.fail(['SHOULD FAIL'])
    succed_validation = Validation.success(3)
    assert failed_validation.ap(fn_success) == Validation(None, ['SHOULD FAIL', 3])
    assert succed_validation.ap(fn_fail) == Validation(3, ['SHOULD FAIL'])


# Generated at 2022-06-24 00:51:20.408520
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success(1)
    assert validation.is_success() == True

    validation = Validation.fail()
    assert validation.is_success() == False


# Generated at 2022-06-24 00:51:25.712622
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error 1', 'error 2']).is_fail()
    assert not Validation.fail().is_fail()
    assert not Validation.success(1).is_fail()
    assert not Validation.success('string').is_fail()


# Generated at 2022-06-24 00:51:32.615809
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation
    from pymonet.either import Left, Right

    fold = lambda v: Left(v + 1) if v < 0 else Right(v + 1)

    assert Validation.success(10).bind(fold) == Validation.success(11)
    assert Validation.success(-10).bind(fold) == Validation.fail([-11])



# Generated at 2022-06-24 00:51:41.813659
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    assert Validation.success(5).to_either() == Right(5)
    assert Validation.success(5).to_either().unwrap() == 5
    assert Validation.success(5).to_either().unwrap_or(10) == 5
    assert Validation.success(5).to_either().unwrap_or_default() == 5

    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.fail(['error']).to_either().unwrap_or('default') == 'default'
    assert Val

# Generated at 2022-06-24 00:51:49.124201
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test to_box method of Validation class.
    """
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(2).to_box() == Box(2)
    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.fail(['error1', 'error2']).to_box() == Box(None)


# Generated at 2022-06-24 00:51:56.762182
# Unit test for method map of class Validation
def test_Validation_map():
    v1 = Validation.success(10)
    v1_mapped = v1.map(lambda x: x + 10)
    v2 = Validation.fail(['error1', 'error2'])
    v2_mapped = v2.map(lambda x: x + 10)

    assert (Validation.success(20), Validation.fail(['error1', 'error2'])) == (v1_mapped, v2_mapped)


# Generated at 2022-06-24 00:52:00.296107
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(False).to_either() == Right(False)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:52:05.183406
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Unit test for method Validation.is_fail"""

    success = Validation.success()
    assert success.is_fail() == False

    fail = Validation.fail()
    assert fail.is_fail() == True



# Generated at 2022-06-24 00:52:08.614691
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    success = Validation.success(10)
    fail = Validation.fail([TypeError('Error 1')])

    assert success.is_fail() == False
    assert fail.is_fail() == True


# Generated at 2022-06-24 00:52:12.697321
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation

    val1 = Validation(1, [1])
    val2 = Validation(3, [3])

    # Testing Validation.ap
    val3 = val1.ap(lambda x: Validation(x, [2]))
    assert val1.errors == [1]
    assert val2.errors == [3]
    assert val3.value == 1
    assert val3.errors == [1, 2]

# Generated at 2022-06-24 00:52:16.723774
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe, MaybeMonad

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:52:21.899514
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    assert Validation.success(5).to_box() == Box(5)
    assert Validation.fail(['err1', 'err2']).to_box() == Box(None)


# Generated at 2022-06-24 00:52:30.928591
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    # unit test for Validation.success(value).to_try()
    assert Validation.success().to_try() == Try(None, is_success=True)
    expected = Try('foo', is_success=True)
    assert Validation.success('foo').to_try() == expected
    assert Validation.success('foo').to_try() == Try('foo', is_success=True)
    # unit test for Validation.fail(errors).to_try()
    expected = Try(None, is_success=False)
    assert Validation.fail().to_try() == expected
    assert Validation.fail('foo').to_try() == expected
    assert Validation.fail('foo', 'bar').to_try() == expected


# Generated at 2022-06-24 00:52:35.648255
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([Try.exception_cls('error')]).to_box() == Box(None)


# Generated at 2022-06-24 00:52:44.305654
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    def bad_func():
        raise Exception('Boom!')

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.success().to_try() == Success(None)

    assert Validation.fail(['Error 1']).to_try() == Failure(['Error 1'])
    assert Validation.success(bad_func).to_try() == Failure(['Boom!'])



# Generated at 2022-06-24 00:52:46.730157
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(1).map(lambda x: x + 1) == Validation.success(2)
    assert Validation.fail([1]).map(lambda x: x + 1) == Validation.fail([1])


# Generated at 2022-06-24 00:52:52.564907
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([]).to_try() == Try(None, is_success=False)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:52:59.287399
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    #given
    from pymonet.monad_try import Try

    #when
    try_success = Validation.success('value').to_try()
    try_fail = Validation.fail(['error']).to_try()

    #then
    assert isinstance(try_success, Try) and try_success.is_success() and try_success.value == 'value'
    assert isinstance(try_fail, Try) and try_fail.is_fail() and try_fail.value is None
    assert Try.fuzzy_equals(try_success, try_fail) is False


# Generated at 2022-06-24 00:53:07.129739
# Unit test for method bind of class Validation
def test_Validation_bind():
    """It should return list of Validations"""
    def f(count):
        """It that return list of lists of numbers"""
        return [range(count), range(count)]

    assert Validation.success([1, 2]).bind(f) == Validation.success([[0, 1], [0, 1]])
    assert Validation.success([1, 2]).bind(lambda count: Validation.success(f(count))) == \
           Validation.success([[0, 1], [0, 1]])


# Generated at 2022-06-24 00:53:09.827304
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success(5).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail(['Error']).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:53:16.248373
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail(('error',)).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:53:20.257526
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    # given
    value = 1
    validation = Validation.success(value)
    expected = Right(value)

    # when
    result = validation.to_either()

    # then
    assert expected == result



# Generated at 2022-06-24 00:53:24.310849
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Tests that Validation.success(value) returns Validation with given value.
    """
    # Given
    validation = Validation.success(10)
    # Then
    assert str(validation) == 'Validation.success[10]'


# Generated at 2022-06-24 00:53:31.558789
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    validation = Validation.success()
    try_monad = validation.to_try()
    assert isinstance(try_monad, Success)
    assert try_monad.is_success()

    validation = Validation.fail()
    try_monad = validation.to_try()
    assert isinstance(try_monad, Failure)
    assert not try_monad.is_success()


# Generated at 2022-06-24 00:53:37.886615
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.success(None) == Validation(None, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:53:42.563666
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success('1') == Validation.success('1')
    assert Validation.success([1]) == Validation.success([1])
    assert Validation.success({'1': 2}) == Validation.success({'1': 2})
    assert Validation.success(None) == Validation.success(None)
    assert Validation.success(Validation(1, [])) == Validation.success(Validation(1, []))
    assert Validation.success({Validation(1, []): 2}) == Validation.success({Validation(1, []): 2})
    assert Validation.success([Validation(1, [])]) == Validation.success([Validation(1, [])])


# Generated at 2022-06-24 00:53:46.229460
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success().is_fail() is False
    assert Validation.success('test').is_fail() is False
    assert Validation.fail().is_fail() is True
    assert Validation.fail(['error']).is_fail() is True


# Generated at 2022-06-24 00:53:51.228617
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Test for bind method of Validation class."""
    from pymonet.either import Left
    from pymonet.maybe import Just, Nothing
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    first_name = Validation.success('John')
    last_name = Validation.success('Smith')
    age = Validation.fail(['age should be number', 'age should be greater than 0'])

    def get_full_name(first_name, last_name):
        """Concatenate first and last name."""
        return first_name + ' ' + last_name


# Generated at 2022-06-24 00:53:58.256457
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation.success(10)
    assert Validation.success(10) != Validation.success('abc')
    assert Validation.fail() != Validation.fail(['error'])
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.fail(['error']) != Validation.fail()


# Generated at 2022-06-24 00:54:04.202370
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success() == Validation(None, [])
    assert Validation.success(42) == Validation(42, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])



# Generated at 2022-06-24 00:54:07.547770
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:54:12.067849
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    a = Validation(1, [2])
    b = Validation(1, [2])
    assert a == b

    a = Validation.success([1])
    b = Validation.success([1])
    assert a == b

    a = Validation.fail(['a', 'b'])
    b = Validation.fail(['a', 'b'])
    assert a == b

