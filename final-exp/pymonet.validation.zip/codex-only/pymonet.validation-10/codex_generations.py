

# Generated at 2022-06-24 00:44:19.520209
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation1 = Validation.success(1)
    validation2 = Validation.fail([1])
    validation3 = Validation.fail([1])

    assert (validation1.ap(lambda i: Validation.success(2)) == Validation.success(1))
    assert (validation2.ap(lambda i: Validation.fail([2])) == Validation.fail([1, 2]))
    assert (validation3.ap(lambda i: Validation.fail([1])) == Validation.fail([1, 1]))


# Generated at 2022-06-24 00:44:25.092146
# Unit test for method ap of class Validation
def test_Validation_ap():
    def plus(x): return Validation.success(x + 100)

    assert Validation.success(10).ap(plus).value == 110
    assert Validation.fail(['is not digit']).ap(plus).value == None

    # Unit test for method to_either of class Validation

# Generated at 2022-06-24 00:44:29.931235
# Unit test for method to_box of class Validation
def test_Validation_to_box(): # pragma: no cover
    from pymonet.box import Box

    validation = Validation.success('aaa').to_box()
    assert validation == Box('aaa')


# Generated at 2022-06-24 00:44:37.058794
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Test case 1. Two Validation are equal
    t1 = Validation([1, 2, 3], [])
    t2 = Validation([1, 2, 3], [])

    assert t1 == t2

    # Test case 2. Two Validation are not equal
    t1 = Validation([1, 2, 3], [])
    t2 = Validation([3, 1, 2], [])

    assert t1 != t2
test_Validation___eq__()


# Generated at 2022-06-24 00:44:38.648337
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('ok').is_fail() == False
    assert Validation.fail(['error']).is_fail() == True



# Generated at 2022-06-24 00:44:45.000298
# Unit test for method map of class Validation
def test_Validation_map():
    val_success = Validation(2, [])
    val_fail = Validation(1, [])

    assert val_success.map(lambda x: x * 2) == \
        Validation(4, [])

    assert val_fail.map(lambda x: x * 2) == \
        Validation(1, [])

# Generated at 2022-06-24 00:44:55.690097
# Unit test for method map of class Validation
def test_Validation_map():
    """Unit test for method map of class Validation"""
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import TryException, Try

    validation = Validation.fail(['error1', 'error2'])
    assert validation.map(lambda x: x) == Validation(None, ['error1', 'error2'])

    validation = Validation.success(2)
    assert validation.map(lambda x: x) == Validation(2, [])
    assert validation.map(lambda x: x + 2) == Validation(4, [])
    assert validation.map(lambda x: Validation.fail(['error'])) == Validation(None, ['error'])

   

# Generated at 2022-06-24 00:45:00.421408
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert repr(Validation(1, [])) == "Validation.success[1]"
    assert repr(Validation(2, [1, 2])) == "Validation.fail[2, [1, 2]]"



# Generated at 2022-06-24 00:45:09.468353
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Given
    success = Validation.success('success')
    fail1 = Validation.fail(['Error 1'])
    fail2 = Validation.fail(['Error 2'])
    fail3 = Validation.fail(['Error 3'])

    # When
    success_ap1 = success.ap(lambda value: fail1)
    success_ap2 = success_ap1.ap(lambda value: fail2)
    success_ap3 = success_ap2.ap(lambda value: fail3)

    # Then
    assert success_ap3.value == 'success'
    assert success_ap3.errors == ['Error 1', 'Error 2', 'Error 3']

# Generated at 2022-06-24 00:45:12.080129
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    validation = Validation.success()
    assert validation.is_success()
    validation = Validation.success(10)
    assert validation.is_success()
    validation = Validation.fail([1, 2])
    assert not validation.is_success()


# Generated at 2022-06-24 00:45:20.654011
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.success(55)) == 'Validation.success[55]'
    assert str(Validation.success('hello')) == 'Validation.success[hello]'
    assert str(Validation.fail(5)) == 'Validation.fail[None, 5]'
    assert str(Validation.fail(55)) == 'Validation.fail[None, 55]'
    assert str(Validation.fail('hello')) == 'Validation.fail[None, hello]'


# Generated at 2022-06-24 00:45:25.638140
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Either

    def _func(val):
        return Either.success(val)

    assert(Validation.success(10).to_either() == _func(10))
    assert(Validation.fail(["Error"]).to_either() != _func(10))



# Generated at 2022-06-24 00:45:29.552653
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation([], []).to_either() == Right([]), "Validation.to_either should return Right with value"
    assert Validation(None, [1, 'a']).to_either() == Left([1, 'a']), \
        "Validation.to_either should return Left with errors list"


# Generated at 2022-06-24 00:45:32.145829
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])



# Generated at 2022-06-24 00:45:38.374091
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert repr(Validation.success('value')) == 'Validation.success[value]'
    assert str(Validation.success('value')) == 'Validation.success[value]'
    assert repr(Validation.fail(['error1', 'error2'])) == 'Validation.fail[None, [\'error1\', \'error2\']]'


# Generated at 2022-06-24 00:45:42.290705
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation('test', []).to_box() == Box('test')
    assert Validation('test', ['test']).to_box() == Box('test')


# Generated at 2022-06-24 00:45:48.605005
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 1
    validation = Validation.success(value)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == value

    errors = [ValueError('some error')]
    validation = Validation.fail(errors)
    lazy = validation.to_lazy()
    assert isinstance(lazy, Lazy)
    assert lazy() == None

# Generated at 2022-06-24 00:45:54.021739
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    assert Validation(Maybe.just(1), []).to_maybe() == Maybe.just(1)
    assert Validation(Try.success(1), []).to_maybe() == Maybe.just(1)
    assert Validation(Try.failure(TypeError()), []).to_maybe() == Maybe.nothing()
    assert Validation(None, []).to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:45:56.832744
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success('test').to_try() == Try.pure('test')
    assert Validation.fail(['test']).to_try() == Try.raise_error(RuntimeError('test'))



# Generated at 2022-06-24 00:46:02.308465
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test Validation to_try method.
    """
    from pymonet.try_ import Success, Failure, Try
    from pymonet.monad_try import Try

    assert Validation.fail().to_try() == Try(None, is_success=False)
    assert Validation.success(5).to_try() == Try(5, is_success=True)



# Generated at 2022-06-24 00:46:12.026445
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v1 = Validation.success(1)
    v2 = Validation.success(1)
    v3 = Validation.success(2)
    v4 = Validation.fail([])
    v5 = Validation.fail([1])
    v6 = Validation.fail([1])
    v7 = Validation.fail([2])

    assert v1 == v2
    assert v2 == v1

    assert v1 != v3
    assert v3 != v1

    assert v4 != v5
    assert v5 != v4

    assert v5 == v6
    assert v6 == v5

    assert v6 != v7
    assert v7 != v6



# Generated at 2022-06-24 00:46:18.657075
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    val = Validation.success(0)
    assert val.to_maybe() == Maybe.just(0)
    val = Validation.fail([0])
    assert val.to_maybe() == Maybe.nothing()
    f = lambda: Try(1).get()
    val = Validation.fail([f])
    assert val.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:46:20.383821
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    import pytest

    assert Validation.success(10).is_success() == True
    assert Validation.fail().is_success() == False


# Generated at 2022-06-24 00:46:28.975418
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Tests Validation.ap method.
    """
    from pymonet.box import Box
    from pymonet.validation import validation_to_box

    def test_fn(value):
        """
        Test function that returns successful Box.

        :param value: function argument
        :type value: A
        :returns: successful Box with value
        :rtype: Box[A]
        """
        return Box(value)

    result = Validation.success(1).ap(test_fn)

    assert result == Validation.success(1)

    assert result.value == 1
    assert result.errors == []

    result = Validation.fail(errors=['test error']).ap(test_fn)

    assert result == Validation.fail(errors=['test error'])

    assert result.value is None
   

# Generated at 2022-06-24 00:46:37.760556
# Unit test for method bind of class Validation
def test_Validation_bind():

    def successful_Validation(number):
        return Validation.success(number)

    def failed_Validation(number):
        return Validation.fail([number, number])

    assert Validation.success(1).bind(successful_Validation).value == 1
    assert Validation.success(1).bind(failed_Validation).errors == [1, 1]
    assert Validation.fail([5]).bind(successful_Validation).errors == [5]
    assert Validation.fail([5]).bind(failed_Validation).errors == [5, 5]

    print('Test successfull')


# Generated at 2022-06-24 00:46:42.513619
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert(str(Validation(1, ['error1', 'error2'])) == "Validation.fail[1, ['error1', 'error2']]")
    assert(str(Validation(1, [])) == "Validation.success[1]")

# Unit tests for method is_success

# Generated at 2022-06-24 00:46:49.535818
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_either import Left, Right
    from pymonet.box import Box

    def uc(thing):
        return str(thing).upper()

    assert Validation.success('Value').to_box() == Box('Value')
    assert Validation.success('Value').map(uc).to_box() == Box('VALUE')

    assert Validation.fail(['error']).to_box() == Box(None)
    assert Validation.fail(['error']).map(uc).to_box() == Box(None)

    assert Validation.success('Value').to_box().to_maybe() == Maybe.just('Value')
    assert Validation.success('Value').map(uc).to_box().to

# Generated at 2022-06-24 00:46:55.685268
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation(True, [])) == 'Validation.success[True]'
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(None, ['err'])) == 'Validation.fail[None, [\'err\']]'
    assert str(Validation(None, ['err1', 'err2'])) == 'Validation.fail[None, [\'err1\', \'err2\']]'


# Generated at 2022-06-24 00:46:58.709756
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.fail([]).to_try() == Try(None)
    assert Validation.success(1).to_try() == Try(1)



# Generated at 2022-06-24 00:47:06.637833
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.curry import curry
    from pymonet.lazy import Lazy
    from pymonet.functor import Functor
    from pymonet.applicative import Applicative

    # success of equals success
    assert Validation.success() == Validation.success()

    # success of not equals fail
    assert Validation.success() != Validation.fail()

    # fail of equals fail
    assert Validation.fail() == Validation.fail()

    # fail with different values not equals
    assert Validation.fail([1]) != Validation.fail([2])

    # success with different values not equals
    assert Validation.success(1) != Validation.success(2)

    # right with different values not equals
    assert Validation.success([1]) != Validation.success([2])

    # success with different values

# Generated at 2022-06-24 00:47:16.417313
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """Test for method Validation.is_fail."""
    from pymonet.either import Left, Right
    from pymonet.monad_list import List
    from pymonet.monad_maybe import Maybe
    from pymonet.monad_set import Set

    #  Create sample monads
    monad = Validation.fail(['error'])
    assert monad.is_fail() is True
    assert monad.is_success() is False
    monad = Validation.success()
    assert monad.is_fail() is False
    assert monad.is_success() is True

    #  Wrap some monad in new monad and test it
    monad = monad.to_box()
    assert monad.unbox().is_fail() is False
    assert monad.unbox().is_success()

# Generated at 2022-06-24 00:47:20.686405
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(123, []) == Validation.success(123).to_lazy().value()
    assert Validation(123, ['error']).to_lazy().value().is_fail()

# Generated at 2022-06-24 00:47:25.076742
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    v = Validation.fail()
    assert v.to_box() == Box(None)

# Generated at 2022-06-24 00:47:31.276274
# Unit test for constructor of class Validation
def test_Validation():
    f1 = Validation.fail(['fail 1'])
    f2 = Validation.fail(['fail 1', 'fail 2'])
    s1 = Validation.success(None)
    s2 = Validation.success(1)
    unittest.TestCase().assertEqual(f1, Validation(None, ['fail 1']))
    unittest.TestCase().assertEqual(f2, Validation(None, ['fail 1', 'fail 2']))
    unittest.TestCase().assertEqual(s1, Validation(None, []))
    unittest.TestCase().assertEqual(s2, Validation(1, []))


# Generated at 2022-06-24 00:47:36.271560
# Unit test for method bind of class Validation
def test_Validation_bind():
    success = Validation.success(2)
    fail = Validation.fail(["Error"])

    assert success.bind(lambda value: Validation.success(value * 2)).value == 4
    assert success.bind(lambda value: Validation.fail(["Error"])).errors == ["Error"]

    assert fail.bind(lambda value: Validation.success(value * 2)).value is None
    assert fail.bind(lambda value: Validation.fail(["Error"])).errors == ["Error"]

# Generated at 2022-06-24 00:47:43.713307
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    assert Validation.success(1).to_lazy() == Lazy(lambda: 1)
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)
    assert Validation.fail([1]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:47:45.846505
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(None) == Validation.success(None).to_try()
    assert Failure(['error1']) == Validation.fail(['error1']).to_try()


# Generated at 2022-06-24 00:47:47.815869
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([1, 2]).to_box() == Box(None)


# Generated at 2022-06-24 00:47:53.565322
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.functor import Functor
    from pymonet.monad import Monad
    from pymonet.applicative import Applicative
    from pymonet.maybe import Maybe

    def test_functor(monad):
        return Functor.test_functor(monad)

    def test_functor_laws(monad):
        return Functor.test_functor_laws(monad)

    def test_monad(monad):
        return Monad.test_monad(monad)

    def test_monad_laws(monad):
        return Monad.test_monad_laws(monad)

    def test_applicative(monad):
        return Applicative.test_applicative(monad)


# Generated at 2022-06-24 00:48:02.122494
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    from pymonet.data_structures import List

    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy

    def test_case_success():
        # GIVEN
        input = Validation.success(List.of(1, 2, 3))

        # WHEN
        output = input.to_either()

        # THEN
        assert output == Right(List.of(1, 2, 3))

    def test_case_fail():
        # GIVEN
        input = Validation.fail(List.of(1, 2, 3))

        # WHEN
        output = input.to_either()

        # THEN

# Generated at 2022-06-24 00:48:04.780056
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation(True, []) == Validation.success(True)
    assert Validation(None, []) == Validation.success()
    assert Validation(None, [1, 2, 3]) == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:48:10.521763
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    Unit test for method __eq__ of class Validation.
    """
    assert Validation.success([1,2,3]) == Validation.success([1,2,3])
    assert Validation.success().__eq__('test') is False
    assert Validation.success(1) == Validation.fail([1]) is False


# Generated at 2022-06-24 00:48:16.163214
# Unit test for method bind of class Validation
def test_Validation_bind():
    valid = Validation.success(2)
    assert valid.bind(lambda x: Validation.success(x * 2)) == Validation.success(4)

    invalid = Validation.fail(['error'])
    assert invalid.bind(lambda x: Validation.success(x * 2)) == Validation.fail(['error'])

    # Validation should be success and not fail
    # hlint complains about useless lambda function usage
    assert valid.bind(lambda x: Validation.fail(['error'])) == Validation.success(2)


# Generated at 2022-06-24 00:48:18.788186
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(None, []).is_fail() is False
    assert Validation(None, ['error']).is_fail() is True
    assert Validation('value', []).is_fail() is False
    assert Validation('value', ['error']).is_fail() is True


# Generated at 2022-06-24 00:48:25.800914
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad import Monad
    from pymonet.validation import Validation
    from pymonet.either import Right, Left

    def is_correct(x):
        return Validation.success(x)

    def is_correct_any(x):
        return Validation.success(x + " - any")

    def is_fail(x):
        return Validation.fail(['error'])

    # Validation bind test
    assert Monad.bind(Validation.success(1), is_correct) == Validation.success(1)
    assert Monad.bind(Validation.success(1), is_correct_any) == Validation.success(1)
    assert Monad.bind(Validation.fail(['error']), is_correct_any) == Validation.fail(['error'])

# Generated at 2022-06-24 00:48:29.378384
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Tests method to_maybe of class Validation.
    """
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.success(None).to_maybe() == Maybe.just(None)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:48:33.003224
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(True) == Validation.success(True)


# Generated at 2022-06-24 00:48:36.397692
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(1).to_try() == Success(1)
    assert Validation.fail(2).to_try() == Failure(2)


# Generated at 2022-06-24 00:48:38.798478
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('value').is_fail() == False
    assert Validation.fail(['do not have errors']).is_fail() == True


# Generated at 2022-06-24 00:48:40.796040
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success('succ').is_success()
    assert Validation.fail(['first', 'second']).is_fail()


# Generated at 2022-06-24 00:48:44.345051
# Unit test for method bind of class Validation
def test_Validation_bind():

    def fail_folder(value):
        return Validation.success(value + 1)

    def error_folder(value):
        return Validation.fail([value + 1])

    assert Validation.success(1).bind(fail_folder) == Validation(2, [])
    assert Validation.success(1).bind(error_folder) == Validation(None, [2])
    assert Validation.fail([1]).bind(fail_folder) == Validation(None, [1])
    assert Validation.fail([1]).bind(error_folder) == Validation(None, [1, 2])

# Generated at 2022-06-24 00:48:48.939206
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(42).to_box() == Box(42)
    assert not (Validation.fail(["Value can't be less than zero", "Value can't be greater than 100"]).
        to_box() == Box(42))



# Generated at 2022-06-24 00:48:52.384055
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    # Test to_either with success validation
    def test_Success_to_Either():
        value = 5
        validation = Validation.success(value)
        assert(validation.to_either() == Right(value))

    test_Success_to_Either()

    # Test to_either with fail validation
    def test_Fail_to_Either():
        errors = [1, 2, 3]
        validation = Validation.fail(errors)
        assert(validation.to_either() == Left(errors))

    test_Fail_to_Either()


# Generated at 2022-06-24 00:49:03.012820
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Test method map of class Validation.
    """

    # Test for corrupted method map for failed Validation

    val = Validation.fail(['list', 'of', 'errors'])

    def func(value):
        return value * 3

    result = val.map(func)

    assert not result.is_success()

    # Test for corrupted method map for success Validation

    val = Validation.success(42)

    result = val.map(func)

    assert not result.is_fail()

    # Test for success method map for success Validation

    val = Validation.success(42)

    result = val.map(lambda x: x + 1)

    assert result.is_success() and result.value == 43


# Generated at 2022-06-24 00:49:04.526482
# Unit test for method __str__ of class Validation
def test_Validation___str__():  # pragma: no cover
    print(Validation.fail(['error']))
    print(Validation.fail())
    print(Validation.success(12))
    print(Validation.success())


# Generated at 2022-06-24 00:49:05.797292
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    val = Validation.success('foo')
    assert val.to_lazy() == Lazy(lambda: 'foo')


# Generated at 2022-06-24 00:49:07.328893
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    errors = ['error']
    assert Validation.fail(errors).is_fail()

    assert not Validation.success().is_fail()


# Generated at 2022-06-24 00:49:17.850699
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test method bind of class Validation.

    :returns: Nothing
    :rtype: Nothing
    """

    equals = lambda x: lambda y: x == y

    # Success Validation
    assert Validation.success(4).bind(lambda x: Validation(x + 2, [])).value == 6
    assert Validation.success(4).bind(lambda x: Validation(x + 2, [])).errors == []
    assert Validation.success(5).bind(lambda x: Validation(x + 2, [])).value == 7

    # Fail Validation
    assert Validation.fail([1, 2]).bind(lambda x: Validation(x + 2, [])).value == None

# Generated at 2022-06-24 00:49:19.982876
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    validation = Validation("Value", ["Error"])
    box = validation.to_box()

    assert isinstance(box, Box)
    assert box.value == "Value"


# Generated at 2022-06-24 00:49:22.954360
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert_that(Validation.success("val").is_success(), is_(True))
    assert_that(Validation.fail("error").is_success(), is_(False))


# Generated at 2022-06-24 00:49:25.683063
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(123).to_try() == Try(123)
    assert Validation.fail(['error']).to_try() == Try(None)


# Generated at 2022-06-24 00:49:28.176046
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('hello').to_maybe() == Maybe.just('hello')
    assert Validation.fail(['error message']).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:49:40.125374
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert ((Validation.success(2) == Validation.success(2)) == True)
    assert ((Validation.success(None) == Validation.success(None)) == True)
    assert ((Validation.success(False) == Validation.success(False)) == True)
    assert ((Validation.success(True) == Validation.success(True)) == True)
    assert ((Validation.fail() == Validation.fail()) == True)
    assert ((Validation.fail(['a', 'b']) == Validation.fail(['a', 'b'])) == True)
    assert ((Validation.fail([]) == Validation.fail([])) == True)
    assert ((Validation.success(2) != Validation.success(2.2)) == True)

# Generated at 2022-06-24 00:49:41.497242
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(5).is_success() == True



# Generated at 2022-06-24 00:49:47.159933
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(2)) == 'Validation.success[2]'
    assert str(Validation.fail(['error'])) == 'Validation.fail[None, [\'error\']]'


# Generated at 2022-06-24 00:49:49.979812
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.fail(['error']).to_either() == Left(['error'])
    assert Validation.success(3).to_either() == Right(3)


# Generated at 2022-06-24 00:49:59.898853
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.lazy import Lazy

    assert Validation.success(2).bind(Lazy(lambda x: Validation.success(x * 2))) == Validation.success(4)
    assert Validation.success(2).bind(Lazy(lambda x: Validation.fail([x, "invalid"]))) == Validation.fail([2, "invalid"])
    assert Validation.fail(["error"]).bind(Lazy(lambda x: Validation.success(x * 2))) == Validation.fail(["error"])
    assert Validation.fail(["error"]).bind(Lazy(lambda x: Validation.fail(["error2"]))) == Validation.fail(["error"])


# Generated at 2022-06-24 00:50:02.219184
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success('succes').to_maybe() == Maybe.just('succes')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:50:06.011044
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert (
        Validation.success(1)
        .bind(lambda x: Validation.success(x + 1)) ==
        Validation.success(2)
    )

    assert (
        Validation.fail([1])
        .bind(lambda x: Validation.success(x)) ==
        Validation.fail([1])
    )


# Generated at 2022-06-24 00:50:09.858145
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    v = Validation.success(3)
    assert str(v) == "Validation.success[3]"

    v = Validation.fail(["err"])
    assert str(v) == "Validation.fail[None, ['err']]"


# Generated at 2022-06-24 00:50:14.774429
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() == True
    assert Validation.success('success').is_success() == True

    assert Validation.fail().is_success() == False
    assert Validation.fail(['fail']).is_success() == False


# Generated at 2022-06-24 00:50:20.112803
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    If errors list is empty, validation should print successful message
    If errors list is not empty, validation should print fail message
    """
    assert str(Validation(1, [])) == 'Validation.success[1]'
    assert str(Validation(1, [1, 2])) == 'Validation.fail[1, [1, 2]]'


# Generated at 2022-06-24 00:50:24.532135
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Validation.success().is_success() == True
    Validation.fail().is_success() == False

    :returns: True
    :rtype: Boolean
    """
    validation1 = Validation.fail(errors=[1, 2, 3])
    validation2 = Validation.success(value=2)

    return validation1.is_success() == False and validation2.is_success() == True



# Generated at 2022-06-24 00:50:32.776760
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """Unit test for method to_try of class Validation"""
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1)
    assert Validation.fail([]).to_try() == Try(None, is_success=False)
    assert Validation.fail([1]).to_try() == Try(None, is_success=False)
    assert Validation.fail([1, 2]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:50:37.904397
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.monad_try import Try

    def validator(x):
        if x is None:
            return Validation.fail(errors=['Do not try to divide by 0'])
        return Validation.success(value=100 / x)

    assert Validation.success(100).bind(validator) == Validation.success(100 / 100)
    assert Validation.fail(errors=['Do not try to divide by 0']).bind(validator) == Validation.fail(errors=['Do not try to divide by 0'])


# Generated at 2022-06-24 00:50:49.496717
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe

    class A:
        pass

    v1 = Validation.success(A())
    v2 = Validation.success(A())
    v3 = Validation.fail([])
    v4 = Validation.fail([])
    v5 = Validation.success(1)
    v6 = Validation.fail([])

    def folder(value):
        return v2

    def folder1(value):
        return Validation.fail([])

    def folder2(value):
        return Validation.success('1')

    assert v1.bind(folder) == v2
    assert v3.bind(folder) == v4
    assert v1.bind(folder1) == v4
    assert v1.bind(folder2) == Validation

# Generated at 2022-06-24 00:50:54.949347
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    # given
    validation_success = Validation.success(1)
    validation_fail = Validation.fail(['error'])

    # then
    assert validation_success.to_lazy() == Lazy(lambda: 1)
    assert validation_fail.to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:50:57.665397
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """Test for method is_success of class Validation"""

    validation = Validation.success()

    assert validation.is_success()
    assert not validation.is_fail()

# Generated at 2022-06-24 00:51:00.056579
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('sucess').to_lazy() == Lazy(lambda: 'sucess')


# Generated at 2022-06-24 00:51:07.075887
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():  # pragma: no cover
    on_validation_equality.expect(Validation.fail(['error1']), Validation.fail(['error1']), to_be=True)
    on_validation_equality.expect(Validation.success(3), Validation.success(3), to_be=True)

    on_validation_equality.expect(Validation.success(3), Validation.success(42), to_be=False)
    on_validation_equality.expect(Validation.success(3), Validation.fail(['error1']), to_be=False)
    on_validation_equality.expect(Validation.fail(['error1']), Validation.fail(['error2']), to_be=False)


# Generated at 2022-06-24 00:51:09.813865
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False  # noqa
    assert Validation.fail([1, 2]).is_fail() == True  # noqa



# Generated at 2022-06-24 00:51:19.892934
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.maybe import Maybe

    assert Validation.success(Maybe.just(1)).ap(lambda i: Validation.success(Maybe.just(i + 1))) == \
           Validation.success(Maybe.just(2))

    assert Validation.success(Maybe.just(1)).ap(lambda i: Validation.fail([i])) == \
           Validation.fail([1])

    assert Validation.fail([]).ap(lambda i: Validation.success(Maybe.just(i + 1))) == \
           Validation.fail([])

    assert Validation.fail([1, 2]).ap(lambda i: Validation.fail([i + 1])) == \
           Validation.fail([1, 2])


# Generated at 2022-06-24 00:51:22.638203
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    from pymonet.either import Left, Right

    assert Validation.fail([1]).is_fail()
    assert Validation.fail([1, 2]).is_fail()
    assert Validation.fail([]).is_fail()
    assert Validation.success(1).is_fail() == False


# Generated at 2022-06-24 00:51:26.487006
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    success = Validation.success(1)
    assert success

    fail = Validation.fail([1, 2, 3])
    assert fail

    assert Validation.fail() == Validation.fail()
    assert Validation.success() == Validation.success()
    assert Validation.fail([]) == Validation.fail()
    assert Validation.fail([1]) != Validation.success()
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.success([1]) == Validation.success([1])
    assert Validation.success([1]) != Validation.success([])


# Generated at 2022-06-24 00:51:28.716932
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():  # pragma: no cover
    assert Validation(None, [0, 1, 2]).is_fail()


# Generated at 2022-06-24 00:51:35.481356
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    >>> validate = Validation.success()
    >>> validate1 = Validation.success()
    >>> validate2 = Validation.success(2)
    >>> validate3 = Validation.fail()
    >>> validate4 = Validation.fail([1, 2])
    >>> assert validate == validate1
    >>> assert validate != validate2
    >>> assert validate != validate3
    >>> assert validate != validate4
    """
    pass


# Generated at 2022-06-24 00:51:41.760706
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error1', 'error2']).to_either() == Left(['error1', 'error2'])


# Generated at 2022-06-24 00:51:43.244632
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    v = Validation.success(10)
    assert v.to_maybe() == Maybe.just(10)

    v = Validation.fail([1, 2, 3])
    assert v.to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:51:53.489820
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.lazy import Lazy
    from pymonet.box import Box

    assert Validation.success().is_success()
    assert Validation.success(1).is_success()
    assert Validation.success('abc').is_success()
    assert Validation.success([]).is_success()
    assert Validation.success(['a']).is_success()
    assert Validation.success({}).is_success()
    assert Validation.success({'k': 'v'}).is_success()
    assert Validation.success(Left('err')).is_success()
    assert Validation.success(Right('value')).is_success()
    assert Validation

# Generated at 2022-06-24 00:51:57.582028
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail([1, 2]).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:52:01.285760
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success('foo')) == 'Validation.success[foo]'
    assert str(Validation.fail(['bar', 'baz'])) == 'Validation.fail[None, [\'bar\', \'baz\']]'



# Generated at 2022-06-24 00:52:04.538173
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Nothing, Maybe

    test_case = [
                  (Validation.success(10), Maybe.just(10)),
                  (Validation.fail(), Maybe.nothing())
                ]

    for input, result in test_case:
        assert input.to_maybe() == result


# Generated at 2022-06-24 00:52:10.300249
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.fail().to_maybe() == Maybe.nothing()
    assert Validation.success(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:52:18.587536
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    result_is_nothing = Validation.fail().to_maybe()
    assert result_is_nothing == Maybe.nothing()

    result_is_just = Validation.success(42).to_maybe()
    assert result_is_just == Maybe.just(42)

    result_is_just = Validation.success(Maybe.nothing()).to_maybe().flat_map(lambda x: x)
    assert result_is_just == Maybe.nothing()

# Generated at 2022-06-24 00:52:24.558709
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail([1, 1]) == Validation.fail([1, 1])
    assert Validation.fail([1, 1]) != Validation.fail([1])


# Generated at 2022-06-24 00:52:28.645919
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(5).to_box() == Box(5)
    assert Validation.fail(["foo"]).to_box() == Box(None)


# Generated at 2022-06-24 00:52:35.685263
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.list import List
    from pymonet.validation import Validation

    # Parameters and expected result
    validation = Validation.success(List(1, 2, 3, 4))
    assert validation.ap(lambda x: Validation.success(x.map(lambda x: x * 3))) == Validation.success(List(3, 6, 9, 12))
    assert validation.ap(lambda x: Validation.fail(['fail'])) == Validation.fail(['fail'])

    validation = Validation.fail(['fail'])
    assert validation.ap(lambda x: Validation.success(List(1, 2, 3, 4))) == Validation.fail(['fail'])

# Generated at 2022-06-24 00:52:37.514536
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left

    assert Validation.success('A').to_either() == Right('A')
    assert Validation.fail(['Error']).to_either() == Left(['Error'])


# Generated at 2022-06-24 00:52:46.758405
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """
    It tests method __eq__ of class Validation.

    :return: None
    :rtype: None
    """
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy
    from pymonet.either import Either

    assert(
        Validation.success(Maybe.just('A')) ==
        Validation.success(Maybe.just('A'))
    )
    assert(
        Validation.success(Maybe.just('A')) !=
        Validation.success(Maybe.just('B'))
    )

    assert(
        Validation.success(Box('A')) ==
        Validation.success(Box('A'))
    )

# Generated at 2022-06-24 00:52:51.622657
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1, 2, 3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:52:58.519911
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.success(12).is_success() is True
    assert Validation.success(12).is_fail() is False
    assert Validation.fail().is_success() is False
    assert Validation.fail([]).is_success() is False
    assert Validation.fail([1, 2]).is_success() is False
    assert Validation.fail([1, 2]).is_fail() is True
    assert Validation.success({}).is_success() is True
    assert Validation.success({}).is_fail() is False



# Generated at 2022-06-24 00:53:03.560711
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])

# Generated at 2022-06-24 00:53:09.303388
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1, 2]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:53:20.078890
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: x * 2) == Validation.success(4)
    assert Validation.success(2).map(lambda x: None) == Validation.success(None)
    assert Validation.success(2).map(lambda x: x * 2) != Validation.success(2)

    assert Validation.fail([]).map(lambda x: x * 2) == Validation.fail([])
    assert Validation.fail([]).map(lambda x: None) == Validation.fail([])
    assert Validation.fail([]).map(lambda x: x * 2) != Validation.success(2)

    assert Validation.fail([1, 2, 3]).map(lambda x: x * 2) == Validation.fail([1, 2, 3])

# Generated at 2022-06-24 00:53:26.896262
# Unit test for constructor of class Validation
def test_Validation():
    # Successful validation
    value = Validation.success(10)
    assert value.value == 10
    assert len(value.errors) == 0

    # Failed validation
    value = Validation.fail(['error1', 'error2'])
    assert value.value is None
    assert len(value.errors) == 2
    assert value.errors[0] == 'error1'
    assert value.errors[1] == 'error2'

# Generated at 2022-06-24 00:53:29.806923
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert (
        Validation.success('success').to_box() ==
        Validation.success('success').to_lazy().to_box() ==
        Box('success')
    )


# Generated at 2022-06-24 00:53:32.736787
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.success(2)
    assert Validation.fail(1) == Validation.fail(1)
    assert Validation.fail(1) != Validation.fail(2)
    assert Validation.success(1) != Validation.fail(1)


# Generated at 2022-06-24 00:53:36.090832
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success('foo') == Validation.success('foo')
    assert Validation.success('foo') != Validation.success('bar')

    assert Validation.fail(['foo']) == Validation.fail(['foo'])
    assert Validation.fail(['foo']) != Validation.fail(['bar'])
    assert Validation.fail(['foo']) != Validation.fail([])


# Generated at 2022-06-24 00:53:41.815296
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success()
    assert not Validation.fail().is_success()
    assert not Validation.fail(['expected foo, got None']).is_success()
    assert not Validation.success(None).is_success()



# Generated at 2022-06-24 00:53:46.377488
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    # Value should be stored in Validation
    assert str(Validation(1)) == 'Validation.success[1]'
    assert Validation(1).value == 1
    assert Validation(1).errors == []

    # Value and errors should be stored in Validation
    assert str(Validation(1, [1])) == 'Validation.fail[1, [1]]'
    assert Validation(1, [1]).value == 1
    assert Validation(1, [1]).errors == [1]


# Generated at 2022-06-24 00:53:48.651428
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(10).is_success() is True
    assert Validation.fail().is_success() is False



# Generated at 2022-06-24 00:53:52.841768
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.success(None).to_box() == Box(None)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1, 2]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:55.547876
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail().to_either() == Left([])



# Generated at 2022-06-24 00:53:58.910857
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():  # pragma: no cover
    from pymonet.lazy import Lazy

    lazy = Validation(10, []).to_lazy()
    assert lazy == Lazy(lambda: 10)
    assert lazy.value() == 10


# Generated at 2022-06-24 00:54:04.465580
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    try:
        from asserts import assert_true, assert_false

        assert_true(Validation.fail(['error']).is_fail())
        assert_false(Validation.success().is_fail())
        print('Unit test for method is_fail of class Validation ok')
    except:
        print('Unit test for method is_fail of class Validation failed')


# Generated at 2022-06-24 00:54:06.938831
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('hello there').is_fail() is False
    assert Validation.fail([1, 2, 3]).is_fail() is True


# Generated at 2022-06-24 00:54:09.829014
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:54:13.604347
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    errors = [1, 2, 3]
    v = Validation(None, errors)
    assert v.is_fail()

    v = Validation(errors, None)
    assert v.is_fail()

    v = Validation(None, [])
    assert not v.is_fail()

    v = Validation([], None)
    assert not v.is_fail()
