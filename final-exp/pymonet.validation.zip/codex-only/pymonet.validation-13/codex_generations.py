

# Generated at 2022-06-24 00:44:16.993009
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(1).is_fail() == False
    assert Validation.success().is_fail() == False
    assert Validation.fail([]).is_fail() == True
    assert Validation.fail(["a"]).is_fail() == True


# Generated at 2022-06-24 00:44:20.288342
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation(1, []).to_either() == Right(1)
    assert Validation(1, [1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-24 00:44:24.355963
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation('value', []).to_either() == Right('value')
    assert Validation('value', ['error']).to_either() == Left(['error'])
    assert Validation.success('value').to_either() == Right('value')
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:44:27.416372
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    value, error = 'value', 'error'

    assert (
        Validation.success(value).to_either() ==
        Right(value)
    )

    assert (
        Validation.fail(error).to_either() ==
        Left(error)
    )

# Generated at 2022-06-24 00:44:38.058575
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Right, Left
    from pymonet.maybe import Maybe, Just

    def square(number):
        return number * number

    def inc(number):
        return number + 1

    def twice(number):
        return number + number

    assert Validation.success(10).map(square) == Validation.success(100)
    assert Validation.success(10).map(inc).map(twice) == Validation.success(22)
    assert Validation.success(10).map(inc).map(inc).map(inc) == Validation.success(13)
    assert Validation.fail([1, 2, 3]).map(square) == Validation.fail([1, 2, 3])
    assert Validation.success(10).map(square).to_either() == Right(100)
    assert Validation

# Generated at 2022-06-24 00:44:43.194618
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([]) == Validation(None, [])
    assert Validation.fail(['error1', 'error2']) == Validation(None, ['error1', 'error2'])
    assert Validation.success(5) == Validation(5, [])
    assert Validation.success() == Validation(None, [])
    assert not Validation.success(5) == Validation(None, [])



# Generated at 2022-06-24 00:44:44.958761
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation.success(1).bind(lambda x: Validation.success(x + 1)) == Validation.success(2)
    assert Validation.success(1).bind(lambda x: Validation.fail([x + 1])) == Validation.fail([2])

# Generated at 2022-06-24 00:44:49.724557
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(100).to_either() == Right(100)
    assert Validation.fail([100]).to_either() == Left([100])



# Generated at 2022-06-24 00:44:53.152826
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error']).is_fail()
    assert not Validation.success(1).is_fail()


# Generated at 2022-06-24 00:44:55.657308
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-24 00:45:01.969020
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    is_fail = Validation.fail(['error1', 'error2']).is_fail()

    assert is_fail is True
    assert isinstance(is_fail, bool)

    is_fail = Validation.success(12).is_fail()

    assert is_fail is False

    is_fail = Validation.success().is_fail()

    assert is_fail is False



# Generated at 2022-06-24 00:45:08.008013
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test for method ap of class Validation

    :returns: Nothing
    :rtype: Nothing
    """
    assert Validation.success(1).ap(lambda x: Validation.success(x + 10)) == Validation.success(11)
    assert Validation.success(1).ap(lambda x: Validation.fail([AssertionError('some error')])) \
        == Validation.fail([AssertionError('some error')])


# Generated at 2022-06-24 00:45:17.126957
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.either import Left, Right
    from pymonet.lazy import Lazy
    from pymonet.maybe import Just, Nothing
    from pymonet.val import Val
    from pymonet.validation import Validation

    def add_5(num):
        return num + 5

    # Validation with success flag
    test_val_1 = Validation.success(5)
    test_val_2 = Validation.success(None)
    test_val_3 = Validation.success('5')
    test_val_4 = Validation.success([5])
    test_val_5 = Validation.success(['5'])
    test_val_6 = Validation.success(Lazy(lambda: 5))
    test_val_7 = Validation.success(Just(5))
    test_val

# Generated at 2022-06-24 00:45:24.393411
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    v = Validation.success()
    assert v.is_fail() == False
    v = Validation.success(True)
    assert v.is_fail() == False
    v = Validation.success('Hello')
    assert v.is_fail() == False
    v = Validation.success(None)
    assert v.is_fail() == False

    v = Validation.fail()
    assert v.is_fail() == True
    v = Validation.fail(['Error'])
    assert v.is_fail() == True


# Generated at 2022-06-24 00:45:32.115208
# Unit test for method bind of class Validation
def test_Validation_bind():
    assert Validation(2, []).bind(lambda v: Validation(v + 1, [])) == Validation(3, [])
    assert Validation(2, []).bind(lambda v: Validation.success(v + 1)) == Validation(3, [])
    assert Validation.success(2).bind(lambda x: Validation.fail([])) == Validation(None, [])
    assert Validation.fail([1]).bind(lambda x: Validation.fail([])) == Validation(None, [1])
    assert Validation.fail([1]).bind(lambda x: Validation(1, [])) == Validation(None, [1])
    assert Validation.fail([1]).bind(lambda x: Validation.success(1)) == Validation(None, [1])
    assert Validation.fail([1, 2]).bind

# Generated at 2022-06-24 00:45:36.793304
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('value').is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-24 00:45:41.093029
# Unit test for method map of class Validation
def test_Validation_map():
    validation = Validation.success(2)
    mapped_validation = validation.map(lambda x: x + 1)
    assert mapped_validation == Validation(3, [])


# Generated at 2022-06-24 00:45:51.729054
# Unit test for method bind of class Validation
def test_Validation_bind():
    def f(x: int) -> Validation:
        if x > 2:
            return Validation.success(x)
        return Validation.fail([x])

    # success bind
    assert Validation.success(5).bind(f) == Validation.success(5)
    # fail bind
    assert Validation.fail([5]).bind(f) == Validation.fail([5])
    # fail with errors bind
    assert Validation.fail([1, 2]).bind(f) == Validation.fail([1, 2])
    # bind with function returns empty Validation
    assert Validation.success(3).bind(lambda x: Validation.success()) == Validation.success(3)
    # bind with function returns failed Validation
    assert Validation.success(2).bind(lambda x: Validation.fail([x])) == Val

# Generated at 2022-06-24 00:45:59.928690
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.validation import Validation
    # Given
    valid_validations = [
        Validation.success(1),
        Validation.fail([1, 2]),
        Validation.fail([1, 2, 3]),
        Validation.success('A'),
        Validation.fail(['A', 'B', 'C'])
    ]
    result_validations = [
        Validation.success(2),
        Validation.fail([1, 2]),
        Validation.fail([1, 2, 3]),
        Validation.success('A'),
        Validation.fail(['A', 'B', 'C'])
    ]
    for x, y in zip(valid_validations, result_validations):
        # When
        z = x.ap(lambda _: Validation.success(2))
        #

# Generated at 2022-06-24 00:46:03.045749
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail(['Error'])) == 'Validation.fail[None, [\'Error\']]'



# Generated at 2022-06-24 00:46:06.573427
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])


# Generated at 2022-06-24 00:46:11.010940
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    v1 = Validation.success(10)
    v2 = Validation.success(10)
    v3 = Validation.fail([1, 2])
    v4 = Validation.fail([1, 2])
    v5 = Validation.success(None)
    assert v1 == v2
    assert v3 == v4
    assert v1 != "10"
    assert v1 != v3
    assert v1 != v5

# Generated at 2022-06-24 00:46:13.813091
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail() == Validation(None, [])
    assert Validation.fail([1]) == Validation(None, [1])



# Generated at 2022-06-24 00:46:17.112553
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail(10).to_box() == Box(None)


# Generated at 2022-06-24 00:46:21.511040
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    success_validation = Validation.success(1)
    assert success_validation == Validation.success(1)

    fail_validation = Validation.fail(["Error"])
    assert fail_validation == Validation.fail(["Error"])



# Generated at 2022-06-24 00:46:26.115620
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right, Left

    assert Validation.success('Ivan').bind(lambda x: Right(x + ' Ivanov')) == Right('Ivan Ivanov')
    assert Validation.fail(1).bind(lambda x: Right(x + ' Ivanov')) == Left(1)


# Generated at 2022-06-24 00:46:30.250597
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(10)) == 'Validation.success[10]'
    assert str(Validation.fail([1, 2, 3])) == 'Validation.fail[None, [1, 2, 3]]'


# Generated at 2022-06-24 00:46:35.506041
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    import pymonet.monad_try as monad_try
    assert Validation.success(4).to_try() == monad_try.Try(4)
    assert Validation.fail(['error1', 'error2']).to_try() == monad_try.Try(None)


# Generated at 2022-06-24 00:46:38.160319
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success(123).is_fail() is False
    assert Validation.fail([1]).is_fail() is True


# Generated at 2022-06-24 00:46:47.412620
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Left, Right

    assert Validation.success(1).bind(lambda a: Validation.success(Left(a))) == Validation.success(Left(1))
    assert Validation.success(1).bind(lambda a: Validation.success(Right(a))) == Validation.success(Right(1))

    assert Validation.fail([1]).bind(lambda a: Validation.success(Left(a))) == Validation.fail([1])
    assert Validation.fail([2]).bind(lambda a: Validation.success(Right(a))) == Validation.fail([2])

    assert Validation.fail([1]).bind(lambda a: Validation.fail([3])) == Validation.fail([1, 3])
    assert Validation.success(1).bind(lambda a: Validation.fail([3]))

# Generated at 2022-06-24 00:46:48.967327
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Box(1) == Validation.success(1).to_box() == Validation.fail([1]).to_box()


# Generated at 2022-06-24 00:46:52.741569
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success(1) != Validation.fail([])
    assert Validation.fail([]) != Validation.fail([])
    assert Validation.fail(['a']) != Validation.fail(['b'])


# Generated at 2022-06-24 00:46:54.979279
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.success('OK').is_fail() == False
    assert Validation.fail(['Error']).is_fail() == True


# Generated at 2022-06-24 00:46:58.062841
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(5).map(lambda x: x + 2) == Validation.success(7)
    assert Validation.fail(["Error"]).map(lambda x: x + 2) == Validation.fail(["Error"])


# Generated at 2022-06-24 00:47:03.006419
# Unit test for method map of class Validation
def test_Validation_map():  # pragma: no cover
    def add_3(x):
        return x + 3

    assert Validation.success(6).map(add_3) == Validation.success(9)
    assert Validation.fail([1, 2, 3]).map(add_3) == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:47:11.020843
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Test to_either method of class Validation.

    :returns: None
    :rtype: NoneType
    """
    from pymonet.either import Left, Right

    assert Validation.success().to_either() == Right(None)
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.fail([1, 2]).to_either() == Left([1, 2])


# Generated at 2022-06-24 00:47:13.783021
# Unit test for method map of class Validation
def test_Validation_map():
    v = Validation.success(5)
    v1 = v.map(lambda x: x + 1)
    assert v1 == Validation(6, [])

# Generated at 2022-06-24 00:47:18.778057
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.monad_try import Try
    from pymonet.functor import Functor
    from pymonet.functor_result import FunctorResult

    def add_one(x):
        return FunctorResult(Try.successful(x + 1))

    assert Functor(1).bind(add_one).value == 2
    assert Functor(1).bind(add_one).bind(add_one).value == 3


# Generated at 2022-06-24 00:47:21.872837
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right
    from pymonet.validation import Validation

    assert Validation.success('value').to_either() == Right('value')
    assert Validation.fail(['error_1']).to_either() == Left(['error_1'])



# Generated at 2022-06-24 00:47:26.483944
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right, Left
    from pymonet.monad_try import Try

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.fail([1]).to_either() == Left([1])
    assert Validation.success(1).to_either().bind(lambda x: x ** 4) == Right(1) ** 4
    assert Validation.fail(1).to_either().bind(lambda x: x ** 4) == Left(1)
    assert Validation.fail([1, 2]).to_either().bind(lambda x: x ** 4) == Left([1, 2])

    def test_fn(value):
        if value < 5:
            return Validation.success(value)
        return

# Generated at 2022-06-24 00:47:28.548334
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:47:32.972509
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail() == True
    assert Validation.success().is_fail() == False
    assert Validation.fail(['some_error']).is_fail() == True


# Generated at 2022-06-24 00:47:37.423670
# Unit test for constructor of class Validation
def test_Validation():
    from pymonet.utils import assert_equals
    assert_equals(Validation.success(), Validation(None, []))
    assert_equals(Validation.success(1), Validation(1, []))

    assert_equals(Validation.fail(), Validation(None, []))
    assert_equals(Validation.fail([1]), Validation(None, [1]))


# Generated at 2022-06-24 00:47:39.396188
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('x').to_box() == Box('x')
    assert Validation.fail(['y']).to_box() == Box(None)


# Generated at 2022-06-24 00:47:46.283322
# Unit test for method ap of class Validation
def test_Validation_ap():
    errors_list = ["Something went wrong"]
    validation = Validation.success("email")

    validation = validation.ap(lambda v: Validation.fail(errors_list))
    assert validation == Validation("email", ["Something went wrong"])

    validation = Validation.success("email")
    validation = validation.ap(lambda v: Validation.success("address"))
    assert validation == Validation("address", [])


# Generated at 2022-06-24 00:47:49.015580
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test for method to_box.
    """
    # Success condition
    assert Validation.success(10).to_box() == Box(10)

    # Fail condition
    assert Validation.fail(['Error']).to_box() == Box(None)


# Generated at 2022-06-24 00:47:58.168165
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.fail(["error"]).ap(lambda x: Validation.success(x)) == Validation.fail(["error"])
    assert Validation.fail(["error"]).ap(lambda x: Validation.fail(["another error"])) == Validation.fail(
        ["error", "another error"])
    assert Validation.success(1).ap(lambda x: Validation.success(x)) == Validation.success(1)
    assert Validation.success(1).ap(lambda x: Validation.fail(["error"])) == Validation.fail(["error"])



# Generated at 2022-06-24 00:47:59.825930
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail(['error']).to_either() == Left(['error'])


# Generated at 2022-06-24 00:48:06.885653
# Unit test for method to_try of class Validation
def test_Validation_to_try():  # pragma: no cover
    from pymonet.monad_try import Try

    assert Validation.fail(['fail']).to_try() == Try(None, is_success=False)
    assert Validation.success(None).to_try() == Try(None, is_success=True)


# Generated at 2022-06-24 00:48:09.492781
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation('success', []) == Validation.success('success')


# Unit test on method Validation.is_success()

# Generated at 2022-06-24 00:48:16.151431
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map
    """
    def mapper(a):
        return a + '123'

    assert Validation.success('').map(mapper) == Validation.success('123')
    assert Validation.success('abc').map(mapper) == Validation.success('abc123')
    assert Validation.fail(['error1']).map(mapper) == Validation.fail(['error1'])
    assert Validation.fail(['error1', 'error2']).map(mapper) == Validation.fail(['error1', 'error2'])


# Generated at 2022-06-24 00:48:20.857599
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(123) == Validation.success(123)
    assert Validation.fail([1, 2, 3]) == Validation.fail([1, 2, 3])
    assert Validation.success(123) != Validation.fail([])
    assert Validation.success(123) != Validation.success(666)
    assert Validation.fail([1, 2, 3]) != Validation.success(None)
    assert Validation.fail([1, 2, 3]) != Validation.fail([3, 2, 1])


# Generated at 2022-06-24 00:48:23.440378
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert True == Validation.success(1).is_success()
    assert False == Validation.fail([]).is_success()
    assert False == Validation.fail(['error']).is_success()


# Generated at 2022-06-24 00:48:30.443323
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    val = Validation('Success value', ['err1', 'err2'])
    val.errors.append('err3')
    box = val.to_box()
    assert 'Success value' == box.get()
    assert ['err1', 'err2', 'err3'] == val.errors
    val = Validation.success('success')
    box = val.to_box()
    assert 'success' == box.get()



# Generated at 2022-06-24 00:48:34.073728
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation(1, []) == Validation.success(1)
    assert Validation(1, [1]) != Validation.success(1)
    assert Validation(2, [2]) != Validation.success(2)
    assert Validation(1, [1]) == Validation.fail([1])
    assert Validation(2, [2]) == Validation.fail([2])


# Generated at 2022-06-24 00:48:39.864718
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation(None, []).is_fail() == False
    assert Validation("some value", [1, 2, 3]).is_fail() == True
    assert Validation([1, 2, 3], ['err']).is_fail() == True


# Generated at 2022-06-24 00:48:47.759415
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success() == Validation(None, [])
    assert Validation.success(2) == Validation(2, [])
    assert Validation.fail('error') == Validation(None, ['error'])
    assert Validation.fail(['error1', 'error2']) == Validation(None, ['error1', 'error2'])

#Unit test for function is_success from class Validation

# Generated at 2022-06-24 00:48:53.890944
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['errors']).is_fail() is True
    assert Validation.fail(['errors']).is_success() is False
    assert Validation.success().is_fail() is False
    assert Validation.success().is_success() is True


# Generated at 2022-06-24 00:49:01.102863
# Unit test for method to_either of class Validation
def test_Validation_to_either():

    from pymonet.either import Right, Left

    assert isinstance(Validation.success(1).to_either(), Right)
    assert Validation.success(1).to_either() == Right(1)

    assert isinstance(Validation.fail(['err']).to_either(), Left)
    assert Validation.fail(['err']).to_either() == Left(['err'])


# Generated at 2022-06-24 00:49:12.569921
# Unit test for method bind of class Validation
def test_Validation_bind():
    import unittest


    class Validation_bind_Test(unittest.TestCase):
        """
        Unit test for Validation bind method.
        """

        def test_Validation_bind_returns_Validation_when_value_is_not_empty_list_and_mapper_function_returns_validation(self):
            """
            Returns Validation when value is not empty list and mapper function returns Validation.
            """

            def mapper(value):
                return Validation(value * 2, [])

            validation = Validation(5, [])

            self.assertEqual(validation.bind(mapper), Validation(10, []))


# Generated at 2022-06-24 00:49:20.322771
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """Unit test for method __str__ of class Validation
    """
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(5)) == 'Validation.success[5]'
    assert str(Validation.success("python")) == 'Validation.success[python]'
    assert str(Validation.success([])) == 'Validation.success[[]]'
    assert str(Validation.success([[1, 2, 3], [4, 5, 6]])) == 'Validation.success[[[1, 2, 3], [4, 5, 6]]]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([5])) == 'Validation.fail[None, [5]]'

# Generated at 2022-06-24 00:49:25.383126
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:49:28.711279
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    from pymonet.validation import Validation

    @Lazy
    def lazy_value():
        return 'value'

    validation_value = Validation.success(lazy_value)
    assert validation_value.to_lazy() == Lazy(lambda: 'value')


# Generated at 2022-06-24 00:49:34.585252
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(10) == Validation.success(10)
    assert Validation.success(10) != Validation.success(11)
    assert Validation.fail(errors=[10]) == Validation.fail(errors=[10])
    assert Validation.fail(errors=[10]) != Validation.fail(errors=[11])



# Generated at 2022-06-24 00:49:44.155585
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Test to_maybe method
    """
    from pymonet.either import Left, Right, Either
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Validation.success(Either.unit("hello")).to_maybe() == Maybe.just("hello")
    assert Validation.fail(Either.unit("hello")).to_maybe() == Maybe.nothing()
    assert Validation.success(Maybe.just("hello")).to_maybe() == Maybe.just("hello")
    assert Validation.fail(Maybe.just("hello")).to_maybe() == Maybe.nothing()
    assert Validation.success(Maybe.nothing()).to_maybe() == Maybe.nothing()
    assert Validation.fail(Maybe.nothing()).to_maybe() == Maybe.nothing()
    assert Validation.success

# Generated at 2022-06-24 00:49:49.493622
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """
    Unit test for method to_either of class Validation
    """
    from pymonet.either import Either
    from pymonet.monad_try import Try

    #Tests of success validation with to_either method that returns Right with value
    success_validations_list = [
        Validation.success(5),
        Validation.success('abc'),
        Validation.success(None)
    ]
    for validation in success_validations_list:
        result = validation.to_either()
        assert result == Either.right(validation.value)

    #Tests of fail validation with to_either method that returns Left with errors

# Generated at 2022-06-24 00:50:00.575848
# Unit test for method map of class Validation

# Generated at 2022-06-24 00:50:05.095239
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """
    Case when Validation is successful.
    """
    validation = Validation.success('value')
    maybe = validation.to_maybe()
    assert (maybe.value, maybe.is_just) == ('value', True)

    """
    Case when Validation is failed.
    """
    validation = Validation.fail(['error'])
    maybe = validation.to_maybe()
    assert (maybe.value, maybe.is_just) == (None, False)


# Generated at 2022-06-24 00:50:07.741385
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Unit test for method to_try of class Validation.
    """

    # given
    val = Validation.success(42)

    # when
    try_ = val.to_try()

    # then
    assert try_.is_success == True
    assert try_.value == 42


# Generated at 2022-06-24 00:50:12.637779
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():  # pragma: no cover
    from pymonet.maybe import Maybe

    assert Validation.success('value').to_maybe() == Maybe.just('value')
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:50:14.686553
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy
    assert Validation.success('lazy').to_lazy() == Lazy(lambda: 'lazy')
    assert Validation.fail([]).to_lazy() == Lazy(lambda: None)


# Generated at 2022-06-24 00:50:17.355193
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    value = 'value'
    result = Validation.success(value).to_box()
    assert result == Box(value)


# Generated at 2022-06-24 00:50:21.076609
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success('test').is_success() is True
    assert Validation.success().is_success() is True
    assert Validation.fail('test').is_success() is False
    assert Validation.fail(['test', 'test']).is_success() is False


# Generated at 2022-06-24 00:50:26.328929
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    # Arrange
    validation1 = Validation(1, [])
    validation2 = Validation(1, [])
    validation3 = Validation(1, None)
    validation4 = Validation(2, [])

    # Act

    # Assert
    assert validation1 == validation2
    assert validation1 != validation3
    assert validation1 != validation4



# Generated at 2022-06-24 00:50:36.939741
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Test method ap of class Validation.
    """
    def _fn1(x):
        return Validation(x * 2, [])

    def _fn2(x):
        return Validation(x + 2, ['error1'])

    def _fn3(x):
        return Validation(x + 2, ['error1'])

    def _fn4(x):
        return Validation(x + 2, ['error1', 'error2'])

    val1 = Validation.success(2)
    val2 = Validation.fail(['error1'])
    val3 = val1.ap(_fn1)
    val4 = val2.ap(_fn2)
    val5 = val1.ap(_fn2)
    val6 = val2.ap(_fn3)

# Generated at 2022-06-24 00:50:43.145466
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right

    def impure_fn(x):
        return Left([])

    def pure_fn(x):
        return Right(1)

    assert Validation.success(1).ap(impure_fn).to_either() == Left([])
    assert Validation.fail(['']).ap(pure_fn).to_either() == Left(['', 1])



# Generated at 2022-06-24 00:50:54.424081
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Unit test for method bind of class Validation.
    """
    from pymonet.op import mul
    from pymonet.monad_try import Try

    def mul_two2(x):
        """
        Try to multiply value with 2 and returns result.

        :params x: value to multiply
        :type x: int
        :returns: result of multiplication
        :rtype: int
        """
        return Try(mul(x, 2), True)

    result = Validation.success(1)
    assert result.bind(mul_two2) == Validation.success(2)
    assert result.bind(lambda x: mul_two2(mul(x, 2))) == Validation.success(8)
    result = Validation.fail(['error1'])

# Generated at 2022-06-24 00:50:57.153065
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    assert Validation.success('value').to_try() == Try.success('value')
    assert Validation.fail(['error']).to_try() == Try.fail()



# Generated at 2022-06-24 00:51:01.371792
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    st = str(Validation('foo', []))
    assert st == 'Validation.success[foo]', 'test fail'

    st = str(Validation('foo', [5]))
    assert st == 'Validation.fail[foo, [5]]', 'test fail'


# Generated at 2022-06-24 00:51:09.545472
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert(
        Validation.success([1, 2, 3])
            .ap(lambda x: Validation.success(list(map(lambda y: y + 1, x))))
        == Validation.success([2, 3, 4]))
    assert(
        Validation.fail(['error 1'])
            .ap(lambda x: Validation.success(list(map(lambda y: y + 1, x))))
        == Validation.fail(['error 1']))
    assert(
        Validation.fail(['error 1'])
            .ap(lambda x: Validation.fail(['error 2']))
        == Validation.fail(['error 1', 'error 2']))

# Generated at 2022-06-24 00:51:11.689718
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)
    assert Validation.fail([]).to_box() == Box(None)
    assert Validation.fail([1]).to_box() == Box(None)


# Generated at 2022-06-24 00:51:15.579073
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from .applicative import Applicative

    assert Validation(1, []).is_success() is True
    assert Validation(1, [1]).is_success() is False

    # Applicative interface
    assert isinstance(Validation(1, []), Applicative)


# Generated at 2022-06-24 00:51:21.785588
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assertValidation = lambda value: Validation.success(value)
    assertValidation.assertValidation = assertValidation
    assertValidation.assertValidation(2).to_box() == Box(2)

    assertValidation = lambda value: Validation.fail([value, value])
    assertValidation.assertValidation = assertValidation
    assertValidation.assertValidation(2).to_box() == Box(None)


# Generated at 2022-06-24 00:51:22.966033
# Unit test for constructor of class Validation
def test_Validation():
    validation = Validation(value=1, errors=['error'])
    assert 1 == validation.value
    assert ['error'] == validation.errors


# Generated at 2022-06-24 00:51:25.101639
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Validation.success('lazy').to_lazy() == Lazy(lambda: 'lazy')


# Generated at 2022-06-24 00:51:36.112149
# Unit test for method ap of class Validation
def test_Validation_ap():
    validation = Validation.success({'age': 30})

    assert validation.ap(lambda d: Validation.success(
        d['age'])) == Validation.success(30)
    assert validation.ap(lambda d: Validation.fail([
          'age is not set'])) == Validation.fail([
          'age is not set'])

    validation = Validation.fail(['age is not set'])

    assert validation.ap(lambda d: Validation.success(
        d['age'])) == Validation.fail(['age is not set', 'age is not set'])
    assert validation.ap(lambda d: Validation.fail([
          'age is not set'])) == Validation.fail(['age is not set', 'age is not set'])

# Generated at 2022-06-24 00:51:40.219875
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation.success() == Validation(None, [])
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail([1]) == Validation(None, [1])
    assert Validation.fail(['Error']) == Validation(None, ['Error'])



# Generated at 2022-06-24 00:51:42.208219
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(10).to_box() == Box(10)
    assert Validation.fail([ValueError]).to_box() == Box(None)



# Generated at 2022-06-24 00:51:45.240933
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    actual = str(Validation.fail())
    expected = "Validation.fail[None, []]"
    assert actual == expected

    actual = str(Validation.fail(["first", "second"]))
    expected = "Validation.fail[None, ['first', 'second']]"
    assert actual == expected

    actual = str(Validation.success())
    expected = "Validation.success[None]"
    assert actual == expected

    actual = str(Validation.success("value"))
    expected = "Validation.success[value]"
    assert actual == expected



# Generated at 2022-06-24 00:51:51.216161
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Either
    from pymonet.validation import Validation

    assert Validation.success(1).to_either() == Either.right(1)
    assert Validation.fail(['error']).to_either() == Either.left(['error'])


# Generated at 2022-06-24 00:52:01.863347
# Unit test for method bind of class Validation
def test_Validation_bind():
    """Tests that bind returns correct monad."""
    from pymonet.monad_try import Success, Failure
    from pymonet.validation import Validation

    assert Validation.fail().bind(lambda x: Success(x)) == Validation.fail()
    assert Validation.success().bind(lambda x: Success(x)) == Success(None)
    assert Validation.success(1).bind(lambda x: Success(x)) == Success(1)
    assert Validation.fail().bind(lambda x: Failure(x)) == Validation.fail()
    assert Validation.success().bind(lambda x: Failure(x)) == Validation.fail()
    assert Validation.success(1).bind(lambda x: Failure(x)) == Validation.fail()



# Generated at 2022-06-24 00:52:10.558683
# Unit test for method ap of class Validation
def test_Validation_ap():
    valid = Validation.success({"name": "Anton"})
    invalid = Validation.fail(["Name is required"])

    def validate_name(name):
        if not name:
            return Validation.fail(["Name is required."])
        return Validation.success(name)

    assert valid.ap(lambda value: validate_name(value["name"])) == Validation.success({"name": "Anton"})
    assert invalid.ap(lambda value: validate_name(value["name"])) == Validation.fail(["Name is required", "Name is required."])


# Generated at 2022-06-24 00:52:18.265193
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    """Unit test for method __eq__ of class Validation"""
    v1 = Validation.success(1)
    v2 = Validation.success(1)
    v3 = Validation.fail([1, 2, 3])
    v4 = Validation.fail([1, 2, 3])

    assert v1 == v1
    assert v1 == v2
    assert v3 == v3
    assert v3 == v4
    assert v3 != v1
    assert v3 != 42
    assert v3 != [1, 2, 3]


# Generated at 2022-06-24 00:52:27.621425
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success() == Validation.success()
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success([1]) == Validation.success([1])
    assert Validation.success('1') == Validation.success('1')

    assert Validation.fail() != Validation.success()
    assert Validation.fail() != Validation.fail()
    assert Validation.fail(Exception()) != Validation.fail()
    assert Validation.fail([1,2,3]) != Validation.fail()
    assert Validation.fail('1') != Validation.success('1')



# Generated at 2022-06-24 00:52:31.833466
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try, Failure, Success

    validate_success = Validation.success('success')
    validate_failure = Validation.fail(['error_msg'])

    assert validate_success.to_try() == Try(Success('success'))
    assert validate_failure.to_try() == Try(Failure(['error_msg']))


# Generated at 2022-06-24 00:52:37.099489
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:52:42.099925
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    # test of valid Validation
    assert Validation.success('good').to_either() == Right('good')

    # test of invalid Validation
    assert Validation.fail('bad').to_either() == Left('bad')



# Generated at 2022-06-24 00:52:47.656663
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation(None, ['test error']).to_maybe() == Maybe.nothing()
    assert Validation(None, []).to_maybe() == Maybe.just(None)
    assert Validation(1, []).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:52:52.048143
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    print_test_separator()
    method = 'is_fail'
    print_test_method_name(method)

    from pymonet.validation import Validation

    val = Validation.fail(['error1'])
    expected = True
    result = val.is_fail()
    assert_result(method, val, expected, result)

    val = Validation.success('value')
    expected = False
    result = val.is_fail()
    assert_result(method, val, expected, result)


# Generated at 2022-06-24 00:52:59.143225
# Unit test for method ap of class Validation
def test_Validation_ap():
    f = lambda x: Validation.success(x + 1)
    m = Validation.success(1)
    v = m.ap(f)
    assert v.value == 2

    f = lambda x: Validation.fail(x + 1)
    m = Validation.success(1)
    v = m.ap(f)
    assert v.value == 1
    assert v.errors == [2]

    f = lambda x: Validation.fail(x + 1)
    m = Validation.fail(1)
    v = m.ap(f)
    assert v.value == None
    assert v.errors == [1, 2]

# Generated at 2022-06-24 00:53:04.907471
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    """
    Test ``to_try`` method of Validation.
    """
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success, Failure

    assert Validation.success().to_try() == Try(None, is_success=True)
    assert Validation.success(1).to_try() == Try(1, is_success=True)
    assert Validation.fail().to_try() == Try(None, is_success=False)
    assert Validation.fail([1, 2, 3]).to_try() == Try(None, is_success=False)

# Generated at 2022-06-24 00:53:07.682042
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(10).map(lambda x: x + 1) == Validation(11, [])
    assert Validation.success(10).map(lambda x: x - 1) == Validation(9, [])


# Generated at 2022-06-24 00:53:11.625131
# Unit test for method bind of class Validation
def test_Validation_bind():
    """
    Test method bind of class Either.
    """

    def folder(x):
        return Validation.success(x + 10)

    success_validation = Validation.success(2)
    assert success_validation.bind(folder) == Validation.success(12)

    fail_validation = Validation.fail(['fail'])
    assert fail_validation.bind(folder) == Validation.fail(['fail'])


# Generated at 2022-06-24 00:53:20.258926
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    error_list = ['error1']
    assert Validation(1, []).__eq__(Validation(1, []))

    assert not Validation(1, []).__eq__(Validation(2, []))
    assert not Validation(1, []).__eq__(Validation(1, error_list))

    assert not Validation(None, error_list).__eq__(Validation(None, []))
    assert not Validation(None, error_list).__eq__(Validation(1, error_list))
    assert not Validation(None, error_list).__eq__(Validation(None, ['other error']))


# Generated at 2022-06-24 00:53:26.348868
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success([]).map(lambda x: x + [1]) == Validation.success([1])
    assert Validation.success([]).map(lambda x: None) == Validation.success(None)
    assert Validation.success('A').map(lambda x: '{}{}'.format(x, 'B')) == Validation.success('AB')


# Generated at 2022-06-24 00:53:30.630323
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(100).to_maybe() == Maybe.just(100)
    assert Validation.fail(['Error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:53:38.119262
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    """It tests Validation.is_fail method."""
    validation = Validation(None, ['errors'])
    assert validation.is_fail() == True
    assert Validation.fail(['errors']).is_fail() == True
    assert Validation.fail([]).is_fail() == False
    assert Validation.success(None).is_fail() == False


# Generated at 2022-06-24 00:53:42.004163
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.validation import Validation

    assert Validation.success(10).to_maybe() == Maybe.just(10)
    assert Validation.fail().to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:53:43.936452
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(1, []).to_box() == Box(1)
    assert Validation(None, [1]).to_box() == Box(None)


# Generated at 2022-06-24 00:53:50.810786
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    assert Validation.fail().to_try() == Try.fail([])
    assert Validation.fail([1, 2, 3]).to_try() == Try.fail([1, 2, 3])
    assert Validation.success('hello').to_try() == Try.success('hello')



# Generated at 2022-06-24 00:53:54.057645
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Unit test for method map of class Validation.
    """

    validation = Validation.success(10)
    new_validation = validation.map(lambda x: x + 1)

    assert new_validation == Validation(value=11, errors=[])


# Generated at 2022-06-24 00:53:58.047925
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.monad_lazy import Lazy
    from pymonet.validation import Validation

    def fun():
        return 100

    assert Validation.success(100).to_lazy() == Lazy(fun)



# Generated at 2022-06-24 00:54:01.694259
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    log_call(test_Validation_to_lazy.__name__)
    assert repr(Validation.success('value').to_lazy()) == repr(Lazy(lambda: 'value'))


# Generated at 2022-06-24 00:54:06.748081
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    from pymonet.either import Either

    validation = Validation.success()
    assert validation.is_success()

    validation = Validation.success(None)
    assert validation.is_success()

    validation = Validation.success(123)
    assert validation.is_success()

    validation = Validation.fail(['error'])
    assert not validation.is_success()


# Generated at 2022-06-24 00:54:14.508795
# Unit test for method ap of class Validation
def test_Validation_ap():

    def f(x):
        return Validation(x, [])

    assert Validation(0, []).ap(f) == Validation(0, [])
    assert Validation(1, []).ap(f) == Validation(1, [])
    assert Validation('', []).ap(f) == Validation('', [])
    assert Validation(None, []).ap(f) == Validation(None, [])

    def f(x):
        return Validation(x, [1])

    assert Validation(0, []).ap(f) == Validation(0, [1])
    assert Validation(1, []).ap(f) == Validation(1, [1])
    assert Validation('', []).ap(f) == Validation('', [1])