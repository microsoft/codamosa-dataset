

# Generated at 2022-06-24 00:44:15.076935
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    res = Validation.fail(['a', 'b']).is_fail()
    assert res
    res = Validation.success('success').is_fail()
    assert not res


# Generated at 2022-06-24 00:44:17.845734
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    validation = Validation.success(1)
    lazy_result = validation.to_lazy()
    assert lazy_result.get() is 1


# Generated at 2022-06-24 00:44:21.340001
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(42)) == 'Validation.success[42]'
    assert str(Validation.fail(['error 1', 'error 2'])) == 'Validation.fail[None, [\'error 1\', \'error 2\']]'


# Generated at 2022-06-24 00:44:29.346998
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.validation import Validation
    from pymonet.monad_list import List
    from pymonet.monad_try import Try

    assert Validation.success(1).bind(Try) == Try(1)

    assert Validation.fail(['Error']).bind(Try) == Try(None,
        is_success=False)

    def map_value_to_maybe_with_value(value):
        from pymonet.maybe import Maybe
        return Maybe.just(value)

    assert Validation.success(1).bind(map_value_to_maybe_with_value) == Maybe.just(1)

    assert Validation \
        .fail(['Error']) \
        .bind(map_value_to_maybe_with_value) == Maybe.nothing()



# Generated at 2022-06-24 00:44:37.771285
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.validation import Validation

    # success Validation with string value
    val = Validation.success(None)

    assert val.to_try() == Try(None, is_success=True)
    val.map(lambda v: "value")
    assert val.to_try() == Try("value", is_success=True)

    # unsuccessful Validation
    val = Validation.fail(["error"])

    assert val.to_try() == Try(None, is_success=False)
    assert val.to_try().to_validation() == val



# Generated at 2022-06-24 00:44:40.967361
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(42).is_success()
    assert Validation.success(42).is_success()
    assert not Validation.fail(['error']).is_success()
    assert not Validation.fail(['error']).is_success()


# Generated at 2022-06-24 00:44:44.651663
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.validation import Validation

    def test_success():
        assert Validation.success(5).to_box() == Box(5)

    def test_fail():
        assert Validation.fail(['error']).to_box() == Box(None)

    test_success()
    test_fail()



# Generated at 2022-06-24 00:44:52.760370
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(42) == Validation.success(42)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.success(42) != Validation.success(43)
    assert Validation.fail(['error']) == Validation.fail(['error'])
    assert Validation.success(42) != Validation.fail(['error'])



# Generated at 2022-06-24 00:45:03.881934
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    Check function ap for Validation.
    """
    from pymonet.either import Left, Right
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # Success ap list
    assert Validation.success(1).ap(Validation.success([1])) == Validation.success([1])

    # Success ap Maybe
    assert Validation.success(1).ap(Maybe.just([1])) == Validation.success([1])

    # Success ap Either
    assert Validation.success(1).ap(Right([1])) == Validation.success([1])

    # Success ap Try

# Generated at 2022-06-24 00:45:06.102241
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_maybe() == Maybe.just(1)
    assert Validation.fail(['error 1']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:45:14.314199
# Unit test for method ap of class Validation
def test_Validation_ap():
    # This test should be True
    with raises(TypeError):
        Validation.success(1).ap(2)

    # This test should be True
    assert Validation.success(1).ap(lambda x: Validation.fail([1, 2])) == Validation.fail([1, 2])

    # This test should be True
    assert Validation.success(1).ap(lambda x: Validation.success(x + 1)).value == 2

    # This test should be True
    assert Validation.fail([1, 2]).ap(lambda x: Validation.success(x + 1)) == Validation.fail([1, 2])

    # This test should be True
    assert Validation.fail([1, 2]).ap(lambda x: Validation.fail([3, 4])) == Validation.fail([1, 2, 3, 4])

# Generated at 2022-06-24 00:45:15.964559
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    value = 'value'
    errors = 'errors'
    assert Validation(value, errors) == Validation(value, errors)


# Generated at 2022-06-24 00:45:18.088869
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success(4)) == 'Validation.success[4]'
    assert str(Validation.fail([4])) == 'Validation.fail[None, [4]]'


# Generated at 2022-06-24 00:45:24.266034
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try

    assert Validation.success().to_box() == Try.success(None).to_box()
    assert Validation.success(1).to_box() == Try.success(1).to_box()
    assert Validation.fail([1, 2, 3]).to_box() == Try.failure([1, 2, 3]).to_box()


# Generated at 2022-06-24 00:45:30.425742
# Unit test for method bind of class Validation
def test_Validation_bind():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    def f(x):
        return Try(lambda: int(x))

    def g(x):
        return Try(lambda: x**2)

    def h(x):
        return Try(lambda: x + x)

    assert Validation.success(2).bind(f).bind(g).bind(h) == Try(8)
    assert Validation.success(2).bind(f).bind(g).bind(h).to_monad().bind(lambda x: Right(x)) == Right(8)


# Generated at 2022-06-24 00:45:33.253761
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    # given
    validation = Validation.success(2)

    # when
    lazy = validation.to_lazy()

    # then
    assert lazy().to_maybe().is_just()    # value is set
    assert lazy().to_maybe().value() == 2 # value is 2


# Generated at 2022-06-24 00:45:36.028658
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert (Validation.success(1).to_either() == Right(1))
    assert (Validation.fail([1, 2]).to_either() == Left([1, 2]))


# Generated at 2022-06-24 00:45:47.248557
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    assert Validation(1, []).to_maybe() == Maybe.just(1)
    assert Validation(1, []).to_maybe().map(lambda x: x + 1) == Maybe.just(2)
    assert Validation(1, []).to_maybe().fmap(lambda x: x + 1) == Maybe.just(2)
    assert Validation(1, []).to_maybe().fmap(lambda x: x + 1).fmap(lambda x: x + 2) == Maybe.just(3)
    assert Validation(1, []).to_maybe().fmap(lambda x: x + 1).fmap(lambda x: x + 2).fmap(lambda x: x + 3) == Maybe.just(4)

# Generated at 2022-06-24 00:45:50.124535
# Unit test for constructor of class Validation
def test_Validation():
    assert Validation.success(value=1) == Validation(1, [])
    assert Validation.fail(errors=[1]) == Validation(None, [1])



# Generated at 2022-06-24 00:45:55.546082
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail([2, 3]).to_either() == Left([2, 3])
    assert Validation.fail([]).to_either() == Left([])
    assert Validation.success(None).to_either() == Right(None)


# Generated at 2022-06-24 00:45:59.092357
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == 'Validation.success[None]'
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'


# Generated at 2022-06-24 00:46:07.809731
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Failure

    # Given
    validation_success = Validation.success('foo')
    validation_failure = Validation.fail(['error'])

    # When
    try_success = validation_success.to_try()
    try_failure = validation_failure.to_try()

    # Then
    assert isinstance(try_success, Try)
    assert isinstance(try_failure, Try)
    assert try_success.is_success() == True
    assert try_failure.is_success() == False
    assert try_success.get_or_else(None) == 'foo'
    assert try_failure.get_or_else(Failure) == Failure


# Generated at 2022-06-24 00:46:12.881207
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    assert Validation(None, []) == Validation(None, [])
    assert Validation(1, []) == Validation(1, [])
    assert Validation(None, [1]) == Validation(None, [1])
    assert Validation(1, [1]) == Validation(1, [1])


# Generated at 2022-06-24 00:46:14.765623
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation(1, []).to_box() == Box(1)


# Generated at 2022-06-24 00:46:26.188162
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Property based test for Validation.to_box method.
    """
    import hypothesis.strategies as st
    from hypothesis import given
    from pymonet.box import Box
    from pymonet.monad import i_compose

    @i_compose(Validation, Box)
    @given(st.integers())
    def should_return_box_of_validation_value(value):
        """
        It takes as an argument an integer value and returns Box of Validation.
        New box should contains value that was in validation.

        :param value: int value
        :type value: int
        :returns: Box of Validation
        :rtype: Box
        """
        return Validation.success(value)

    should_return_box_of_validation_value()


# Generated at 2022-06-24 00:46:32.261993
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(None).is_success() == True
    assert Validation.success().is_success() == True
    assert Validation.success(1).is_success() == True
    assert Validation.success("abc").is_success() == True
    assert Validation.success("").is_success() == True
    assert Validation.success("True").is_success() == True
    assert Validation.success("False").is_success() == True
    assert Validation.success(True).is_success() == True
    assert Validation.success(False).is_success() == True
    assert Validation.success([]).is_success() == True
    assert Validation.success([1, 2, 3]).is_success() == True
    assert Validation.success([None]).is_success() == True
    assert Validation.success

# Generated at 2022-06-24 00:46:42.387117
# Unit test for method map of class Validation
def test_Validation_map():
    test_case_data = [
        {
            'name': 'Successfully validation',
            'input': Validation.fail(['error1', 'error2']).map(lambda x: x + 2),
            'output': Validation(None, ['error1', 'error2'])
        },
        {
            'name': 'Fail validation',
            'input': Validation.success(2).map(lambda x: x + 2),
            'output': Validation(4, [])
        }
    ]

    for test_case in test_case_data:
        assert test_case['input'] == test_case['output'], 'test fail for case: {}'.format(test_case['name'])



# Generated at 2022-06-24 00:46:45.923078
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    """Unit test for method to_either of class Validation"""
    from pymonet.either import Left, Right

    assert Validation.success(1).to_either() == Right(1)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:46:49.095782
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success_validation = Validation.success('success!')
    fail_validation = Validation.fail(['fail!'])

    assert success_validation.is_success()
    assert not fail_validation.is_success()


# Generated at 2022-06-24 00:46:51.418751
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(2).to_maybe() == Just(2)
    assert Validation.fail(['error']).to_maybe() == Nothing()


# Generated at 2022-06-24 00:46:56.769680
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success().is_success() is True
    assert Validation.fail().is_success() is False
    assert Validation.success(0).is_success() is True
    assert Validation.fail([0]).is_success() is False


# Generated at 2022-06-24 00:47:02.007906
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    assert Validation.success(1).is_success() == True
    assert Validation.fail().is_success() == False
    assert Validation.fail([1, 2, 3]).is_success() == False


# Generated at 2022-06-24 00:47:03.175089
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success('value').to_box().value == 'value'

# Generated at 2022-06-24 00:47:13.444314
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    validation = Validation.success(2).ap(lambda x: Validation.success(x + 2))
    assert validation.value == 4
    assert validation.is_success()

    validation = Validation.fail(['error']).ap(lambda x: Validation.success(x + 2))
    assert validation.value == None
    assert validation.errors == ['error']
    assert validation.is_fail()

    validation = Validation.fail(['error']).ap(lambda x: Validation.fail(['error2']))
    assert validation.value == None
    assert validation.errors == ['error', 'error2']
    assert validation.is_fail()

    validation = Validation.success(2).ap(lambda x: Validation.fail(['error2']))
    assert validation.value == 2
    assert validation

# Generated at 2022-06-24 00:47:20.684136
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from pymonet.validation import Validation

    assert Validation.success(1) == Validation.success(1)
    assert Validation.fail([]) == Validation.fail([])
    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1, 2]) == Validation.fail([1, 2])
    assert Validation.fail([1]) != Validation.fail([1, 2])
    assert Validation.fail([1]) != Validation.fail([])
    assert Validation.success(1) != Validation.success(2)
    assert Validation.success(1) != Validation.fail([])


# Generated at 2022-06-24 00:47:30.568966
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    Unit test for function:
        Validation.__str__
    """
    success_validation = Validation.success(True)
    assert success_validation.__str__() == 'Validation.success[True]'
    fail_validation = Validation.fail([1, 2])
    assert fail_validation.__str__() == 'Validation.fail[None, [1, 2]]'
    success_validation = Validation.success('haha')
    assert success_validation.__str__() == 'Validation.success[haha]'
    fail_validation = Validation.fail([])
    assert fail_validation.__str__() == 'Validation.fail[None, []]'


# Generated at 2022-06-24 00:47:36.773575
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.box import Box

    # Arrange
    validation_success = Validation.success(Box('box'))
    validation_failure = Validation.fail([Try('Error 1'), Try('Error 2')])

    # Act
    result_success = validation_success.to_box()
    result_failure = validation_failure.to_box()

    # Assert
    assert result_success.value == Box('box')
    assert result_failure.value is None



# Generated at 2022-06-24 00:47:47.388766
# Unit test for constructor of class Validation
def test_Validation():  # pragma: no cover
    from pymonet.either import Right
    from pymonet.maybe import Maybe

    assert Validation(1, []).value == 1
    assert Validation(1, []).errors == []
    assert Validation(1, None).errors == []
    assert Validation(1, []).map(lambda x: x + 1).value == 2
    assert Validation(1, []).map(lambda x: x + 1).errors == []

    assert Validation(1, []).bind(lambda x: Validation(x + 1, [])).value == 2
    assert Validation(1, []).bind(lambda x: Validation(x + 1, [])).errors == []
    assert Validation(1, []).bind(lambda x: Validation(x + 1, [])).is_success()

    assert Validation

# Generated at 2022-06-24 00:47:58.611725
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    test_data = {
        'with_value': {
            'fn': lambda: Validation.success('Test'),
            'expected': lambda: Maybe.just('Test')
        },
        'with_empty': {
            'fn': lambda: Validation.fail(errors=['Test']),
            'expected': lambda: Maybe.nothing()
        },
    }
    for case, data in test_data.items():
        result = data['fn']().to_maybe()
        expected = data['expected']()

        assert result == expected, '{0}: {1} != {2}'.format(case, result, expected)


# Generated at 2022-06-24 00:48:01.455762
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    value = 1
    lazy = Validation.success(value).to_lazy()

    assert type(lazy) is Lazy
    assert lazy.force() == value


# Generated at 2022-06-24 00:48:03.625446
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Left, Right

    assert Validation.success(2).to_either() == Right(2)
    assert Validation.fail([1, 2, 3]).to_either() == Left([1, 2, 3])


# Generated at 2022-06-24 00:48:13.740553
# Unit test for method ap of class Validation
def test_Validation_ap():
    # Unit: when validation success, return success with concatenated list of errors
    def test_success():
        val_success = Validation(1, [])
        val_expected = Validation(1, [1, 2, 3])
        def f(val):
            return Validation(None, [1, 2, 3])

        val_actual = val_success.ap(f)
        assert val_expected == val_actual

    # Unit: when validation fail, return fail with concatenated list of errors
    def test_fail():
        val_fail = Validation(None, [1, 2, 3])
        val_expected = Validation(None, [1, 2, 3, 1, 2, 3])
        def f(val):
            return Validation(None, [1, 2, 3])

        val_actual = val_fail

# Generated at 2022-06-24 00:48:15.501397
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    def testing_code():
        validation = Validation.success(42)
        return validation.to_box()

    assert testing_code() == Box(42)



# Generated at 2022-06-24 00:48:19.430474
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    # case when errors list is empty
    assert Validation.success(1).is_fail() is False
    # case when errors list are not empty
    assert Validation.fail([1, 2, 3]).is_fail() is True


# Generated at 2022-06-24 00:48:26.495949
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try

    # Given
    v1 = Validation.success(2)
    v2 = Validation.success(Try.success(lambda x: x + 2))

    # When
    result = v1.ap(v2)

    # Then
    assert(result == Validation.success(4))

    # Given
    v1 = Validation.success(2)
    v2 = Validation.fail([RuntimeError('test')])

    # When
    result = v1.ap(v2)

    # Then
    assert(result == Validation.fail([RuntimeError('test')]))

    # Given
    v1 = Validation.fail([RuntimeError('test1')])
    v2 = Validation.success(Try.success(lambda x: x + 2))

    # When


# Generated at 2022-06-24 00:48:28.839940
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    """Test method to_maybe of class Validation"""
    from pymonet.maybe import Just, Nothing
    from pymonet.validation import Validation

    assert Validation.success(2).to_maybe() == Just(2)
    assert Validation.fail().to_maybe() == Nothing()


# Generated at 2022-06-24 00:48:38.010722
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.either import Left, Right
    from pymonet.monad_try import Try

    def my_function(value):
        if value is None:
            return Try(value, is_success=False)
        return Try(value + 1, is_success=True)

    assert Validation.success(1).ap(my_function) == Validation(2, [])
    assert Validation.success(None).ap(my_function).value is None
    assert Validation.success(None).ap(my_function).is_fail() is True
    assert Validation.success(None).ap(my_function).errors == [None]
    assert Validation.fail([1, 2, 3]).ap(my_function).value is None
    assert Validation.fail([1, 2, 3]).ap(my_function).is_

# Generated at 2022-06-24 00:48:39.590316
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation.success(value=1).to_lazy().value() == 1



# Generated at 2022-06-24 00:48:41.702361
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box

    assert Validation.success(1).to_box() == Box(1)


# Generated at 2022-06-24 00:48:45.789463
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    validation = Validation.success(1)
    assert validation.to_maybe() == Maybe.just(1)

    validation = Validation.fail()
    assert validation.to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:48:48.902434
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(42).to_maybe() == Maybe.just(42)
    assert Validation.fail(['error']).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:48:53.456548
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    """It tests to_lazy method of class Validation."""
    monad = Validation.success("Hello World")
    assert monad.to_lazy().eval() == monad.value


# Generated at 2022-06-24 00:49:01.187136
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.validation import Validation
    from pymonet.lazy import Lazy

    lazy_number = Validation.success(10).to_lazy()
    assert(lazy_number == Lazy(lambda: 10))

    lazy_none = Validation.fail([ValueError('Error message'), TypeError('Error message')]).to_lazy()
    assert(lazy_none == Lazy(lambda: None))



# Generated at 2022-06-24 00:49:08.474566
# Unit test for method bind of class Validation
def test_Validation_bind():

    def folder(value):
        return Validation.fail(['error']) if value == 6 else Validation.success(value)

    assert Validation.success(5).bind(folder) == Validation.success(5)
    assert Validation.success(6).bind(folder) == Validation.fail(['error'])



# Generated at 2022-06-24 00:49:15.301985
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success().map(lambda x: x + 3) == Validation.success(3)
    assert Validation.fail().map(lambda x: x + 3) == Validation.fail()
    assert Validation.success(1).map(lambda x: x + 3) == Validation.success(4)
    assert Validation.fail([1, 2, 3]).map(lambda x: x + 3) == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:49:21.314770
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():

    assert Validation.success(2) == Validation.success(2)
    assert Validation.success(2) != Validation.success(3)
    assert Validation.success(2) != Validation.fail([1])
    assert Validation.success(2) != {'value': 2, 'errors': []}

    assert Validation.fail([1]) == Validation.fail([1])
    assert Validation.fail([1]) != Validation.fail([1, 2])
    assert Validation.fail([1]) != Validation.success(2)
    assert Validation.fail([1]) != {'value': None, 'errors': [1]}


# Generated at 2022-06-24 00:49:24.345092
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    validation = Validation("value", [])
    assert validation.__str__() == "Validation.success[value]"

    validation = Validation("value", ["error"])
    assert validation.__str__() == "Validation.fail[value, ['error']]"


# Generated at 2022-06-24 00:49:26.605323
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right
    from pymonet.monad_try import Try

    assert Validation.success(10).to_either() == Right(10)
    assert Validation.fail(['Error']).to_either() == Try(None, False, ['Error'])


# Generated at 2022-06-24 00:49:28.850953
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Success(42).to_validation() == Validation(42, [])
    assert Failure('Error').to_validation() == Validation(None, ['Error'])


# Generated at 2022-06-24 00:49:37.299540
# Unit test for constructor of class Validation
def test_Validation():
    """
    Unit test for constructor of class Validation.
    """
    from pymonet.either import Left, Right

    # When
    validation = Validation(None, [])

    # Then
    assert validation
    assert validation.value is None
    assert validation.errors == []
    assert validation == Validation.success()
    assert validation == Validation.success(None)
    assert validation.is_success()
    assert not validation.is_fail()
    assert validation.to_either() == Right(None)


# Generated at 2022-06-24 00:49:40.318783
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['required']).is_fail()
    assert not Validation.fail([]).is_fail()



# Generated at 2022-06-24 00:49:45.620827
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.fail(['error1']) == Validation.fail(['error1'])
    assert Validation.success(1) == Validation.success(1)
    assert Validation.success('Monet') != Validation.success('monet')
    assert Validation.success(1) != Validation.fail(1)
    assert Validation.success(1) != None


# Generated at 2022-06-24 00:49:47.924297
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    import pymonet.monad_try

    assert Validation.success(1).to_try() == pymonet.monad_try.Try.success(1)


# Generated at 2022-06-24 00:49:53.869283
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet import Validation
    from pymonet.either import Left, Right

    # Success validation
    success = Validation.success(1)
    assert success.to_either() == Right(1)

    # Fail validation
    fail = Validation.fail(['test'])
    assert fail.to_either() == Left(['test'])


# Generated at 2022-06-24 00:49:56.694038
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    assert Validation.success(1) == Validation(1, [])
    assert Validation.fail(['error']) == Validation(None, ['error'])


# Generated at 2022-06-24 00:49:59.801721
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Checks if method to_box returns Box with Validation value.
    """
    from pymonet.box import Box

    assert Validation.fail([1, 2, 3]).to_box() == Box(None)
    assert Validation.success(1).to_box() == Box(1)


# Generated at 2022-06-24 00:50:02.114109
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    assert Validation.success(1).to_box() == Box(1)

    assert Validation.fail().to_box() == Box(None)



# Generated at 2022-06-24 00:50:04.679624
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(True).to_maybe() == Maybe.just(True)
    assert Validation.success(False).to_maybe() == Maybe.just(False)
    assert Validation.fail().to_maybe() == Maybe.nothing()

# Generated at 2022-06-24 00:50:08.716219
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """Unit test for method is_success of class Validation"""
    print('Unit test for method is_success of class Validation')

    assert Validation.success("Success").is_success()
    assert Validation.success(1).is_success()
    assert Validation.success(1.1).is_success()

    result = Validation.fail(["Fail"])
    assert result.is_success() is False
    result = Validation.fail(["Fail", "Second", "Third"])
    assert result.is_success() is False


# Generated at 2022-06-24 00:50:12.943529
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    assert Validation(5, []).to_lazy() == Lazy(lambda: 5)
    assert Validation.fail([1, 2]).to_lazy() == Lazy(lambda: None)

# Generated at 2022-06-24 00:50:16.954377
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation(1, []).to_try() == Try(1)
    assert Validation(1, [1]).to_try() == Try(1, is_success=False)


# Generated at 2022-06-24 00:50:19.494467
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail() == Validation(None, [1,2,3])


# Generated at 2022-06-24 00:50:22.279459
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(10).map(lambda x: x * 2) == Validation(20, [])
    assert Validation.fail().map(lambda x: x * 2) == Validation(None, [])


# Generated at 2022-06-24 00:50:26.752027
# Unit test for method to_either of class Validation
def test_Validation_to_either():  # pragma: no cover
    from pymonet.either import Left
    from pymonet.maybe import Maybe

    assert Validation.success(1).to_either() == Validation.success(1).to_maybe().to_either()
    assert Validation.fail([1]).to_either() == Validation.fail([1]).to_maybe().to_either()
    assert Validation.success(1).to_either() != Left(1)


# Generated at 2022-06-24 00:50:37.211165
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.monad_try import Try

    # Given Validation[A, List[E]]
    validation = Validation.success(5)

    # When operation map is called
    # Then Validation[B, List[E]] must be returned
    assert validation.map(lambda a: a + 5) == Validation(10, [])

    # Given monad Validation[A, List[E]]
    validation = Validation.fail(['error'])

    # When operation map is called
    # Then same monad is returned
    assert validation.map(lambda a: a + 5) == Validation(None, ['error'])

    # Given monad Validation[A, List[E]]
    monad = Validation.success(5)



# Generated at 2022-06-24 00:50:42.882367
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.fail([1,2,3]).to_maybe() == Maybe.nothing()


# Generated at 2022-06-24 00:50:48.510534
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    """
    It should return string representation of class Validation.
    """
    assert str(Validation.success(1)) == 'Validation.success[1]'
    assert str(Validation.fail([1, 2])) == 'Validation.fail[None, [1, 2]]'
    assert str(Validation.fail()) == 'Validation.fail[None, []]'


# Generated at 2022-06-24 00:50:53.574512
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.box import Box
    from pymonet.monad_try import Failure, Success

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(1, [Failure(1)]).to_box() == Box(1)

# Generated at 2022-06-24 00:50:59.221730
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.fail(['first error', 'second error'])
    assert validation.is_fail()

    validation = Validation.success('test')
    assert not validation.is_fail()



# Generated at 2022-06-24 00:51:09.212168
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    import pytest
    from pymonet.either import Left
    from pymonet.box import Box
    from pymonet.try_ import Try

    def validate_value_less_then(monad, compare_value, field_name='field'):
        """
        For example:
        (monad == Box(8))
        validate_value_less_then(monad, 9, 'age')
        """
        def mapper(value):
            errors = []
            if value > compare_value:
                errors.append('{} is not less then {}'.format(field_name, compare_value))
            return Validation(value, errors)
        return monad.ap(mapper)

    assert validate_value_less_then(Box(8), 8) == Validation(8, [])


# Generated at 2022-06-24 00:51:13.356289
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.fail(['time']).map(lambda v: v + 1) == Validation(None, ['time'])
    assert Validation.success(1).map(lambda v: v + 1) == Validation(2, [])


# Generated at 2022-06-24 00:51:21.716649
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    def test_Validation_to_try_when_Validation_is_fail():
        assert Validation.fail(1).to_try() == Try(None, is_success=False)

    def test_Validation_to_try_when_Validation_is_success():
        assert Validation.success(1).to_try() == Try(1, is_success=True)

    test_Validation_to_try_when_Validation_is_fail()
    test_Validation_to_try_when_Validation_is_success()


# Generated at 2022-06-24 00:51:24.595411
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail(['error1']).is_fail() == True
    assert Validation.fail(['error1', 'error2']).is_fail() == True
    assert Validation.fail([]).is_fail() == False
    assert Validation.success(None).is_fail() == False
    assert Validation.success(1).is_fail() == False
    assert Validation.success('value').is_fail() == False


# Generated at 2022-06-24 00:51:29.652368
# Unit test for method __eq__ of class Validation
def test_Validation___eq__():
    from asserts import assert_true, assert_false, assert_equals
    from pymonet.monad_try import Try
    from pymonet.either import Left
    from pymonet.maybe import Maybe
    from pymonet.box import Box
    from pymonet.lazy import Lazy

    # When
    result = Validation(None, []) == Validation(None, [])

    # Then
    assert_true(result)
    assert_equals(Validation(None, []) == None, False)
    assert_false(Validation(None, []) == Try(None))
    assert_false(Validation(None, []) == Left(None))
    assert_false(Validation(None, []) == Maybe(None))
    assert_false(Validation(None, []) == Box(None))
   

# Generated at 2022-06-24 00:51:34.064454
# Unit test for method to_lazy of class Validation
def test_Validation_to_lazy():
    from pymonet.lazy import Lazy

    assert Lazy(lambda: 1) == Validation.success(1).to_lazy()
    assert Lazy(lambda: None) == Validation.fail([1, 2]).to_lazy()


# Generated at 2022-06-24 00:51:37.062664
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    assert Validation.success(1).to_either() == Either.right(1)
    assert Validation.fail([1, 2]).to_either() == Either.left([1, 2])


# Generated at 2022-06-24 00:51:41.375701
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe

    assert Validation.fail().to_maybe() == Maybe.nothing()
    assert Validation.success(1).to_maybe() == Maybe.just(1)


# Generated at 2022-06-24 00:51:44.991964
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    from pymonet.maybe import Maybe, Either
    from pymonet.validation import Validation, Left, Right

    assert Validation.fail([]).to_maybe() == Maybe.nothing()
    assert Validation.success(10).to_maybe() == Maybe.just(10)


# Generated at 2022-06-24 00:51:54.336533
# Unit test for method map of class Validation
def test_Validation_map():
    """
    Validation is functional data structure that can hold either a success value or a failure value
    and has methods for accumulating errors.
    """
    def add_number(number):
        """
        Add number to value stored in Validation.

        :param number: number to add
        :type number: float
        :returns: new Validation
        :rtype: Validation[A, []]
        """
        return lambda value: Validation(value + number, [])

    # Successful Validation
    assert Validation.success(3).map(add_number(1)) == Validation.success(4)

    # Failed Validation
    assert Validation.fail([1, 2, 3]).map(add_number(1)) == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:51:57.778732
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Success, Failure

    assert Validation.success(10).to_try() == Success(10)
    assert Validation.fail([1, 2, 3]).to_try() == Failure(None)



# Generated at 2022-06-24 00:52:03.069506
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    # when success
    assert Validation.success(1).is_success()
    assert Validation.success(True).is_success()
    assert Validation.success(None).is_success()
    # when fail
    assert not Validation.fail([]).is_success()
    assert not Validation.fail([1]).is_success()
    assert not Validation.fail([1, 'test']).is_success()


# Generated at 2022-06-24 00:52:12.944781
# Unit test for method ap of class Validation
def test_Validation_ap():
    """
    we can take a function of type A -> Validation[B, List[E]] and apply it on Validation[A, List[E]]
    This operation returns Validation with original value and concated errors produced by applied function.
    """
    def add(num):
        return Validation(num + 100, [])

    def add_with_error(num):
        return Validation(num + 100, ['add_with_error'])

    assert Validation(10, []).ap(add) == Validation(10, [])
    assert Validation(10, []).ap(add_with_error) == Validation(10, ['add_with_error'])
    assert Validation(10, ['v1']).ap(add_with_error) == Validation(10, ['v1', 'add_with_error'])


# Generated at 2022-06-24 00:52:18.637632
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    validation = Validation.success(1)
    assert validation.is_fail() == False, 'Validation.is_fail() should return False for successful Validation'

    validation = Validation.fail()
    assert validation.is_fail() == True, 'Validation.is_fail() should return False for successful Validation'


# Generated at 2022-06-24 00:52:24.608014
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    """
    Test Method to_box of class Validation.

    :return: None
    :rtype: None
    """
    from pymonet.box import Box

    assert Validation(1, []).to_box() == Box(1)
    assert Validation(None, [1]).to_box() == Box(None)


# Generated at 2022-06-24 00:52:27.706068
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert Validation.fail().is_fail()
    assert not Validation.fail([]).is_fail()
    assert Validation.success(10).is_fail()
    assert not Validation.success().is_fail()


# Generated at 2022-06-24 00:52:32.218739
# Unit test for method ap of class Validation
def test_Validation_ap():
    from pymonet.monad_try import Try
    from pymonet.monad_list import List

    assert_that(
        Validation.success(1)
            .ap(lambda x: List([Try.success(x)])),
        equal_to(
        Validation.success(1)
            .map(lambda x: List([Try.success(x)]))))


# Generated at 2022-06-24 00:52:41.565318
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    # Given
    add_two = lambda x: x + 2
    add_three = lambda x: x + 3
    validations = [
        Validation.success(1),
        Validation.success(2),
        Validation.fail(['a', 'b']),
        Validation.fail(['a', 'b', 'c', 'd']),
    ]
    expected_values = [
        3,
        4,
        None,
        None,
    ]
    expected_errors_len = [
        0,
        0,
        2,
        4,
    ]


# Generated at 2022-06-24 00:52:46.399578
# Unit test for method to_maybe of class Validation
def test_Validation_to_maybe():
    assert Validation.success(5).to_maybe() == Maybe.just(5)
    assert Validation.fail([1]).to_maybe() == Maybe.nothing()



# Generated at 2022-06-24 00:52:48.169976
# Unit test for method is_fail of class Validation
def test_Validation_is_fail():
    assert not Validation.success().is_fail()
    assert Validation.fail().is_fail()


# Generated at 2022-06-24 00:52:52.608858
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert(str(Validation.success(1)) == 'Validation.success[1]')
    assert(str(Validation.fail()) == 'Validation.fail[None, []]')


# Generated at 2022-06-24 00:52:57.707440
# Unit test for method map of class Validation
def test_Validation_map():
    from pymonet.either import Left
    from pymonet.list import List

    def mapper(value):
        return value.reverse()

    assert Validation.success(List([1, 2, 3])).map(mapper) == Validation.success(List([3, 2, 1]))
    assert Validation.fail([1, 2, 3]).map(mapper) == Validation.fail([1, 2, 3])


# Generated at 2022-06-24 00:53:04.272461
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try

    assert Validation.success(10).to_try() == Try(10, is_success=True)
    assert Validation.success().to_try() == Try(None, is_success=True)
    assert Validation.fail(['less than 18']).to_try() == Try(None, is_success=False)


# Generated at 2022-06-24 00:53:11.997845
# Unit test for method bind of class Validation
def test_Validation_bind():
    def transform(number):
        if number < 0:
            return Validation.fail([number, 'must be non negative'])
        else:
            return Validation.success(number / 2)

    assert Validation.success(2).bind(transform) == Validation.success(1)

    assert Validation.fail(['must be integer']).bind(transform) == Validation.fail(['must be integer'])

    assert Validation.success(-1).bind(transform) == Validation.fail([-1, 'must be non negative'])

# Generated at 2022-06-24 00:53:14.516327
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    success = Validation.success()
    assert success.is_success() is True

    failure = Validation.fail(['err1', 'err2'])
    assert failure.is_success() is False



# Generated at 2022-06-24 00:53:20.225359
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    from pymonet.monad_try import Try, Failure

    validation = Validation.success(1)
    assert validation.to_try() == Try.success(1)

    validation = Validation.fail(['First error', 'Second error'])
    assert validation.to_try() == Try.failure(Failure(['First error', 'Second error']))


# Generated at 2022-06-24 00:53:29.731306
# Unit test for method to_either of class Validation
def test_Validation_to_either():
    from pymonet.either import Right
    from pymonet.either import Left

    validation = Validation.success(5)

    assert validation.to_either() == Right(5)
    assert validation.to_either() != Right(4)
    assert validation.to_either() != Left(5)
    assert validation.to_either() == validation.to_either()

    validation = Validation.fail(['error'])

    assert validation.to_either() == Left(['error'])
    assert validation.to_either() != Left(5)
    assert validation.to_either() != Right(5)
    assert validation.to_either() == validation.to_either()


# Generated at 2022-06-24 00:53:34.711083
# Unit test for method to_box of class Validation
def test_Validation_to_box():
    from pymonet.monad_try import Try
    from pymonet.monad_try import Success, Failure
    from pymonet.maybe import Maybe
    from pymonet.box import Box

    result = Validation.success(42).to_box()
    assert isinstance(result, Box)
    assert result.unbox() == 42

    result = Validation.fail().to_box()
    assert isinstance(result, Box)
    assert result.unbox() is None

    result = Validation.fail(['error']).to_box()
    assert isinstance(result, Box)
    assert result.unbox() is None


# Generated at 2022-06-24 00:53:37.402887
# Unit test for method __str__ of class Validation
def test_Validation___str__():
    assert str(Validation.success()) == "Validation.success[None]"
    assert str(Validation.success(1)) == "Validation.success[1]"
    assert str(Validation.fail()) == "Validation.fail[None, []]"
    assert str(Validation.fail([3])) == "Validation.fail[None, [3]]"


# Generated at 2022-06-24 00:53:47.204112
# Unit test for method ap of class Validation
def test_Validation_ap():  # pragma: no cover
    assert Validation.success().ap(lambda r: Validation.fail(['Failed'])) == Validation.fail(['Failed'])
    assert Validation.success(2).ap(lambda r: Validation.fail(['Failed'])) == Validation.fail(['Failed'])
    assert Validation.success(2).ap(lambda r: Validation.success(4)) == Validation.success(2)
    assert Validation.fail([]).ap(lambda r: Validation.success(4)) == Validation.fail([])
    assert Validation.fail(['Failed']).ap(lambda r: Validation.success(4)) == Validation.fail(['Failed'])

# Generated at 2022-06-24 00:53:55.912789
# Unit test for method ap of class Validation
def test_Validation_ap():
    assert Validation.success(2).ap(Validation.success(lambda x: x + 2)) == Validation.success(4)
    assert Validation.success(2).ap(Validation.fail(['Something went wrong'])) == Validation.fail(['Something went wrong'])
    assert Validation.fail(['Something went wrong']).ap(Validation.success(lambda x: x + 2)) == Validation.fail(['Something went wrong'])
    assert Validation.fail(['Something went wrong']).ap(Validation.fail(['Something went wrong'])) == Validation.fail(['Something went wrong', 'Something went wrong'])

# Generated at 2022-06-24 00:54:01.644961
# Unit test for method is_success of class Validation
def test_Validation_is_success():
    """
    Validation is success if it has empty error list.

    :returns: True for successful test
    :rtype: Boolean
    """
    success = Validation.success(2)
    assert success.is_success() is True

    fail = Validation.fail(['a', 'b'])
    assert fail.is_success() is False


# Generated at 2022-06-24 00:54:04.823385
# Unit test for method ap of class Validation
def test_Validation_ap():
    apVal = Validation.success(lambda str: str + "Monet")
    mapVal = Validation.success("Py")
    val = Validation.success("Py")

    assert val.ap(apVal).value == "PyMonet"

# Generated at 2022-06-24 00:54:08.913694
# Unit test for method map of class Validation
def test_Validation_map():
    assert Validation.success(2).map(lambda x: x + 2) == Validation.success(4)
    assert Validation.fail(['Error 1']).map(lambda x: x + 2) == Validation.fail(['Error 1'])


# Generated at 2022-06-24 00:54:13.875586
# Unit test for method to_try of class Validation
def test_Validation_to_try():
    import pymonet.monad_try as monad_try

    def _should_return_successful_try(value):
        return monad_try.Try.success(value)

    def _should_return_failed_try(value):
        return monad_try.Try.fail(value)

    assert _should_return_successful_try(1) == Validation.success(1).to_try()
    assert _should_return_failed_try([1]) == Validation.fail([1]).to_try()
