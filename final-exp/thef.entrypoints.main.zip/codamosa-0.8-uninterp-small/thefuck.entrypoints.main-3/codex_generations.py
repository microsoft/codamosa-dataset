

# Generated at 2022-06-26 04:51:08.957999
# Unit test for function main
def test_main():
    import os  # noqa: E402

    try:
        os.environ.pop('TF_HISTORY', None)
    except Exception as exc_0:
        print('Exception in {}'.format(exc_0))

    # Test with parameters
    main()

    # Test with 1 argument
    sys.argv = ['thefuck_test_function.py', '--version']
    main()

    # Test with 2 arguments
    sys.argv = ['thefuck_test_function.py', '--version', 'fuck']
    main()

    # Test with 3 arguments
    sys.argv = ['thefuck_test_function.py', '--version', 'fuck', '--help']
    main()

test_case_0()
test_main()

# Generated at 2022-06-26 04:51:12.890647
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-26 04:51:14.975284
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 04:51:18.094203
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import sys
        print("In test case 0 Exception: ", sys.exc_info()[1])

main()

# Generated at 2022-06-26 04:51:24.072743
# Unit test for function main
def test_main():

    try:
        # Unit test for function main
        test_case_0()
    except:
        print('Error while testing for main')
        sys.exit(1)

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:51:30.266325
# Unit test for function main
def test_main():
    # Import the module for testing.
    from . import cli

    # Initialize output before invoking the thefuck.cli.main function.
    init_output()

    # Initialize argument parser.
    parser = Parser()

    # Set arguments.
    args = parser.parse(['--command', 'echo', '--alias'])

    # Invoke `main` function.
    var_0 = cli.main(args, parser)

    return var_0



# Generated at 2022-06-26 04:51:36.676810
# Unit test for function main
def test_main():
    exc = None

    try:
        test_case_0()
    except Exception as err:
        exc = err

    assert exc is None

if __name__ == '__main__':
    os.environ['TF_SHELL'] = 'bash'
    main()

# Generated at 2022-06-26 04:51:37.647579
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 04:51:38.685830
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:51:40.789313
# Unit test for function main
def test_main():
    var_0 = test_case_0()

test_main()

# Generated at 2022-06-26 04:52:03.507259
# Unit test for function main
def test_main():
    # Switch to test directory
    from pathlib import Path
    from os import chdir
    test_path = Path(__file__).parent
    chdir(test_path)

    # Rename files
    from os import rename
    rename("test_main.py", "main.py")
    rename("data/source_code/test_main.py", "data/source_code/main.py")

    # Run test
    test_case_0()

    # Restore files
    rename("main.py", "test_main.py")
    rename("data/source_code/main.py", "data/source_code/test_main.py")

    # Switch back to original directory
    chdir(test_path.parent)


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:52:06.616866
# Unit test for function main
def test_main():
    test_case_0()

# vim: set ai et ts=4 sw=4 tw=80:

# Generated at 2022-06-26 04:52:08.547413
# Unit test for function main
def test_main():
    var_1 = main()
    assert (var_1 is None)


# Generated at 2022-06-26 04:52:10.867444
# Unit test for function main
def test_main():
    assert test_case_0() == None

# Generated at 2022-06-26 04:52:13.557203
# Unit test for function main
def test_main():
    res = main()
    assert(res is None)

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 04:52:18.803437
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        var_0 = None
    else:
        var_0 = True
    return var_0

# Generated at 2022-06-26 04:52:19.770216
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-26 04:52:23.197348
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0


# Generated at 2022-06-26 04:52:24.683767
# Unit test for function main

# Generated at 2022-06-26 04:52:25.382424
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-26 04:52:44.517690
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error while testing the function main")

# Generated at 2022-06-26 04:52:54.102691
# Unit test for function main
def test_main():
    this_dir = os.path.dirname(os.path.realpath(__file__))
    pkg_dir = os.path.realpath(os.path.join(this_dir, '..'))
    # Note: The value of `sys.path` before this `print` statement is:
    #       ['', '<pkg_dir>/thefuck', '<pkg_dir>/thefuck.egg-info', '<pkg_dir>', '/home/nb/.virtualenvs/py3.6/lib/python36.zip', '/home/nb/.virtualenvs/py3.6/lib/python3.6', '/home/nb/.virtualenvs/py3.6/lib/python3.6/lib-dynload', '/usr/lib/python36.zip', '/usr/lib/python3.6', '/

# Generated at 2022-06-26 04:52:59.280315
# Unit test for function main
def test_main():
    var_0 = Parser()
    var_1 = var_0.parse([
        "thefuck"
    ])
    var_0.print_usage()

if __name__ == '__main__':
    # test_main()
    main()

# Generated at 2022-06-26 04:53:03.648588
# Unit test for function main
def test_main():
    assert main()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 04:53:06.822188
# Unit test for function main
def test_main():
    # test case 0
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:53:10.802319
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-26 04:53:12.529409
# Unit test for function main
def test_main():
    print("Test main()")
    test_case_0()

# Generated at 2022-06-26 04:53:15.544136
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == None


# Generated at 2022-06-26 04:53:16.912182
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:53:19.374952
# Unit test for function main
def test_main():
    test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:53:54.902737
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':

    main()
    test_main()

# Generated at 2022-06-26 04:54:00.137355
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0
    except:
        raise AssertionError("Unexpected exception was raised" )


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:54:01.660761
# Unit test for function main
def test_main():
    test_case_0()


# Generated at 2022-06-26 04:54:09.545695
# Unit test for function main
def test_main():
    assert not os.path.exists('/tmp/utest_main/test_case_0')
    try:
        _create_directory('/tmp/utest_main/test_case_0')
        test_case_0()
    finally:
        _delete_directory('/tmp/utest_main/test_case_0')


# Generated at 2022-06-26 04:54:13.753364
# Unit test for function main
def test_main():
  try:
    main()
  except SystemExit as inst:
    if inst.args[0] == 0:
      return True
    else:
      return False
  return False

# Generated at 2022-06-26 04:54:18.869885
# Unit test for function main
def test_main():
    # Exception handling undefined
    # There is no error test case for main()
    try:
        test_case_0()
    except Exception:
        pass


# Generated at 2022-06-26 04:54:21.909855
# Unit test for function main
def test_main():
    var_0 = main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-26 04:54:28.085326
# Unit test for function main
def test_main():
    # TF_HISTORY set to 1 should run the alias command and return 0
    os.environ['TF_HISTORY'] = '1'
    exit_code = main()
    assert exit_code == 0
    assert sys.stdout.getvalue() == 'fuck = fasd -e vim\n'

# Generated at 2022-06-26 04:54:31.214461
# Unit test for function main
def test_main():
    path = os.getcwd()
    os.chdir(os.path.dirname(os.path.realpath(__file__)))
    try:
        os.environ['TF_HISTORY'] = '1'
        test_case_0()
    finally:
        del os.environ['TF_HISTORY']
        os.chdir(path)

# Generated at 2022-06-26 04:54:33.556724
# Unit test for function main
def test_main():
    from .test_main import test_main
    test_main()


# Generated at 2022-06-26 04:55:52.710984
# Unit test for function main
def test_main():
    var_0 = "-------------------------------------------------------------------------------"
    var_1 = "Failed to load any rules: No module named 'rules'"
    var_2 = "-------------------------------------------------------------------------------"
    try:
        var_3 = os.environ
    except Exception:
        var_3 = None
    finally:
        try:
            var_4 = os.environ
        except Exception:
            var_4 = None
        finally:
            try:
                var_5 = os.environ
            except Exception:
                var_5 = None
            finally:
                try:
                    var_6 = os.environ
                except Exception:
                    var_6 = None
                finally:
                    try:
                        var_7 = os.environ
                    except Exception:
                        var_7 = None

# Generated at 2022-06-26 04:55:54.077679
# Unit test for function main
def test_main():
    assert test_case_0() == None

# Generated at 2022-06-26 04:55:55.630130
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-26 04:55:56.441166
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-26 04:55:58.318481
# Unit test for function main
def test_main():
    assert test_case_0() == None

# Generated at 2022-06-26 04:56:01.799006
# Unit test for function main
def test_main():
    # Capture console output
    from io import StringIO
    capturedOutput = StringIO()
    sys.stdout = capturedOutput
    test_case_0()
    sys.stdout = sys.__stdout__
    # Check results
    assert capturedOutput.getvalue() == 'Help?\n'

# Generated at 2022-06-26 04:56:03.407611
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        return 0
    return 1

# Generated at 2022-06-26 04:56:05.627294
# Unit test for function main
def test_main():
    check_if_equal(test_case_0, None)

# Generated at 2022-06-26 04:56:07.336457
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:56:09.741611
# Unit test for function main
def test_main():
    main()
    main()
    main()
    main()
    main()
    main()

# Check that main() runs OK

# Generated at 2022-06-26 04:58:57.416038
# Unit test for function main
def test_main():
    try:
        from ... import main
    except SystemExit:
        var_0 = None
    else:
        var_0 = main()
    assert var_0 == None

# Utility functions


# Generated at 2022-06-26 04:59:02.562574
# Unit test for function main
def test_main():
    # Arrange
    argv = ['thefuck']

    # Act
    with patch('sys.argv', argv):
        main()


# Generated at 2022-06-26 04:59:06.117230
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None, \
        'Unexpected output (%s)' % var_0

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:59:07.132159
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-26 04:59:08.595738
# Unit test for function main
def test_main():
    var_0 = main()
    assert(var_0 == None)


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:59:10.512959
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 04:59:14.171843
# Unit test for function main
def test_main():
    # Running main
    test_case_0()

#if __name__ == '__main__':
#    main(sys.argv)

# Generated at 2022-06-26 04:59:17.439886
# Unit test for function main
def test_main():
    var_1 = os.path.abspath(__file__)
    test_case_0()

# Testing
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:59:19.476736
# Unit test for function main
def test_main():
  assert callable(main)
  

# Validate test case 0
test_case_0()

# Generated at 2022-06-26 04:59:20.246292
# Unit test for function main
def test_main():
    var_0 = main()
    assert not var_0