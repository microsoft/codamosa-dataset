

# Generated at 2022-06-26 04:50:59.719859
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-26 04:51:00.208293
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-26 04:51:02.002887
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-26 04:51:03.520934
# Unit test for function main
def test_main():
    # test case 0
    test_case_0()
    print('Test Success!')


# Generated at 2022-06-26 04:51:04.001844
# Unit test for function main
def test_main():
    assert 1==main()

# Generated at 2022-06-26 04:51:06.447175
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception:
        import traceback
        logs.error(traceback.format_exc())

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:51:08.364731
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    except:
        raise Exception("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-26 04:51:10.907051
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-26 04:51:21.169079
# Unit test for function main
def test_main():
    from .mock_args import set_args
    import argparse

    argv = ['thefuck', '--alias', 'fuck']
    set_args(argparse, argv)
    var_0 = main()
    assert var_0 is None

    argv = ['thefuck', '--alias', 'fuck', '--command', 'cp']
    set_args(argparse, argv)
    var_0 = main()
    assert var_0 is None

    argv = ['thefuck', '--alias', 'fuck', '--command', 'cp', '--def', 'def']
    set_args(argparse, argv)
    var_0 = main()
    assert var_0 is None


# Generated at 2022-06-26 04:51:22.654979
# Unit test for function main
def test_main():
    assert callable ( main)

# Generated at 2022-06-26 04:51:39.458443
# Unit test for function main
def test_main():
    list_0 = ['python3', 'thefuck', '--version']
    list_1 = ['thefuck', '--version']
    list_2 = ['thefuck', '--help']

    sys.argv = list_0
    test_case_0()

    sys.argv = list_1
    test_case_0()

    sys.argv = list_2
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:51:44.589296
# Unit test for function main
def test_main():
    try:
        var_1 = main()
    except SystemExit:
        pass
    except:
        halt("ERROR: Unexpected exception")
    else:
        halt("ERROR: Expected exception")

# Generated at 2022-06-26 04:51:50.203137
# Unit test for function main
def test_main():
    try:
        # Unit test for function called main
        test_case_0()
    except SystemExit:
        pass
    except:
        import traceback
        logs.error(traceback.format_exc())
        return False

    return True


if __name__ == '__main__':
    logs.halt(main())

# Generated at 2022-06-26 04:51:54.548200
# Unit test for function main
def test_main():
    test_cases = [
        {
            "name": "test_case_0",
            "test_case_0": test_case_0
        }
    ]
    for test_case in test_cases:
        for key, value in test_case.items():
            if key == "name":
                print("Running test {}".format(value))
            else:
                value()

if __name__ == "__main__":
    main()

# Generated at 2022-06-26 04:51:59.115478
# Unit test for function main
def test_main():
    subprocess.call(["py.test", "-sv", "tests/unit/test_main.py"])

# Generated at 2022-06-26 04:52:01.775799
# Unit test for function main
def test_main():
    """Tests the functionality of the main"""
    pass

# Generated at 2022-06-26 04:52:06.566426
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        assert True
    except:
        assert False



# Generated at 2022-06-26 04:52:11.776799
# Unit test for function main
def test_main():
    import os
    import tempfile
    import shutil

    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    #assert var_0 == None

# Test that the 'python setup.py test' command works.
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:52:13.208020
# Unit test for function main
def test_main():
    assert True
#test_main()

# Generated at 2022-06-26 04:52:14.569018
# Unit test for function main
def test_main():
    pass


# Generated at 2022-06-26 04:52:33.756888
# Unit test for function main
def test_main():
    try:
        sys.argv = ['thefuck']
        test_case_0()
    except SystemExit:
        pass

# Generated at 2022-06-26 04:52:46.658070
# Unit test for function main
def test_main():
    with patch('thefuck.main.main.Parser') as mock_Parser:
        with patch.object(builtins, '__import__') as mock_importer:
            mock_importer.side_effect = Exception('Error')
            mock_Parser.return_value.parse.return_value = Mock()
            with patch.object(builtins, 'print') as mock_print:
                mock_Parser.return_value.print_help.return_value = Mock()
                test_case_0()
                mock_Parser.return_value.print_help.assert_called_once()
                mock_print.assert_called_once()

            with patch.object(builtins, 'print') as mock_print:
                mock_Parser.return_value.parse.return_value = Mock(help=True)
                test_case_0()


# Generated at 2022-06-26 04:52:53.775279
# Unit test for function main
def test_main():
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None
    assert main() == None


# Generated at 2022-06-26 04:52:57.249316
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        return False

    return True

print(test_main())

# Generated at 2022-06-26 04:52:58.617078
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-26 04:53:00.687076
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:53:03.292229
# Unit test for function main
def test_main():
    assert 1 == 1


# Generated at 2022-06-26 04:53:07.151637
# Unit test for function main

# Generated at 2022-06-26 04:53:10.801625
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-26 04:53:18.337837
# Unit test for function main
def test_main():
# Test https://github.com/nvbn/thefuck/issues/921
    global var_0
    var_0 = {'env': None, 'script': '', 'alias': None}
    var_0 = main()

if __name__ == '__main__':
    test_case_0()
    test_main()

# Generated at 2022-06-26 04:54:02.838532
# Unit test for function main
def test_main():
    mocker.patch('thefuck.shells.shell.get_command')
    mocker.patch('thefuck.shells.shell.get_history')
    mocker.patch('thefuck.shells.shell.to_script')
    mocker.patch('thefuck.main.Parser')
    mocker.patch('thefuck.main.print_alias')
    mocker.patch('thefuck.main.fix_command')
    mocker.patch('thefuck.main.logs')
    mocker.patch('thefuck.main.get_installation_info')
    mocker.patch('thefuck.main.os')
    mocker.patch('thefuck.main.sys')
    mocker.patch('thefuck.main.logs.version')
    mocker.patch('thefuck.main.shell')
    mocker

# Generated at 2022-06-26 04:54:09.612143
# Unit test for function main
def test_main():
    sys.argv.append("--help")

# Generated at 2022-06-26 04:54:10.645948
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:54:14.234981
# Unit test for function main
def test_main():
    import __main__ as main
    import sys
    sys.argv[0] = 'main.py'
    sys.argv[1] = '--version'
    main.main()


# Generated at 2022-06-26 04:54:19.974463
# Unit test for function main
def test_main():
    var_0 = True
    var_1 = False
    try:
        test_case_0()
    except Exception:
        var_1 = True
    finally:
        assert var_0 == var_1

# Generated at 2022-06-26 04:54:26.387832
# Unit test for function main
def test_main():
    try:
        main_test = main()
    except NameError:
        main_test = None

    assert main_test == None
    return main_test

test_main()

# if __name__ == '__main__':
#     main()

# Generated at 2022-06-26 04:54:29.550862
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import traceback
        logs.error(traceback.format_exc())


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:54:31.416200
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-26 04:54:33.123354
# Unit test for function main
def test_main():
    test_case_0()

main()

# Generated at 2022-06-26 04:54:35.895517
# Unit test for function main
def test_main():
    expected = None
    actual = main()

    assert expected == actual

test_case_0()

# Generated at 2022-06-26 04:55:49.820191
# Unit test for function main
def test_main():
    var_1 = main()


# Generated at 2022-06-26 04:55:50.686653
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 04:55:54.627844
# Unit test for function main
def test_main():
    assert main() is None
    assert main() is None
    assert main() is None
    assert main() is None
    assert main() is None


# Generated at 2022-06-26 04:56:03.091666
# Unit test for function main
def test_main():
    argv_org = sys.argv
    sys.argv = ['thefuck', '--alias']
    var_0 = main()
    sys.argv = ['thefuck', '--help']
    var_1 = main()
    sys.argv = ['thefuck', '--version']
    var_2 = main()
    sys.argv = ['thefuck', 'pwd']
    var_3 = main()
    sys.argv = ['thefuck', '--shell', 'bash', '--shell-logger']
    var_4 = main()
    sys.argv = argv_org

# Generated at 2022-06-26 04:56:03.896251
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-26 04:56:10.383168
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except:
        print('Function main does not exist.')
        sys.exit(1)
    else:
        try:
            main()
        except:
            print('Failed to call main.')
            sys.exit(1)
        else:
            print('\nUnit test for function main, passed.')
            test_case_0()

# Generated at 2022-06-26 04:56:14.160946
# Unit test for function main
def test_main():
    try:
        assert callable (main) == True
    except AssertionError as e:
        raise(e)


# Generated at 2022-06-26 04:56:23.660633
# Unit test for function main
def test_main():
    # We define a trace to log the calls done by main
    @patch('builtins.print')
    @patch('os.environ')
    @patch('sys.argv', ['test_case_0'])
    @patch('sys.version_info', version_info(major=3, minor=8))
    def var_0():
        try:
            main()
        except:
            pass

    var_0()

    # We check that main calls the expected functions

# Generated at 2022-06-26 04:56:24.389451
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-26 04:56:28.342943
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch

    with patch('sys.stdout', new=StringIO()) as fakeOutput:
        test_case_0()
    assert fakeOutput.getvalue() == '''\
Usage: thefuck [--version] [-h | --help] [--alias ALIAS]
               [--shell-logger] [--no-execute] [--clear-log]
               [--no-colors] [--debug] [--settings SETTINGS]
               [command]
'''

# Unit tests for function main

# Generated at 2022-06-26 04:59:17.440315
# Unit test for function main
def test_main():
    print("\nTesting main\n")
    test_case_0()


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:59:19.795623
# Unit test for function main
def test_main():
    # Call function main
    var_0 = main()

    # Check variable type
    assert type(var_0) == NoneType


# Generated at 2022-06-26 04:59:22.076137
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None



# Generated at 2022-06-26 04:59:26.647590
# Unit test for function main
def test_main():
    # Call function main
    try:
        assert callable(main)
    except AssertionError:
        logs.error("Function 'main' is not callable")
    else:
        main()

# Generated at 2022-06-26 04:59:29.697938
# Unit test for function main
def test_main():
    try:
        from .thefuck.shells.shell import init
    except ImportError:
        pass
    else:
        # Set the value of environment variable TF_SHELL
        os.environ['TF_SHELL'] = 'sh'
        test_case_0()

# Generated at 2022-06-26 04:59:30.756430
# Unit test for function main
def test_main():
    os.system("python {}".format(__file__.replace('.py', '.example.py')))

# Generated at 2022-06-26 04:59:35.725738
# Unit test for function main
def test_main():
    current_file_path = os.path.realpath(__file__)
    cli_path = os.path.join(os.path.dirname(__file__), '..', '..', '..', '..', '..', 'thefuck', 'cli.py')
    if current_file_path == cli_path:
        # Remove if condition when running unit test
        if True:
            test_case_0()

# Generated at 2022-06-26 04:59:36.389134
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:59:37.550164
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-26 04:59:40.181091
# Unit test for function main
def test_main():
    sys.argv = ["/usr/local/bin/thefuck","fuck"]
    main()