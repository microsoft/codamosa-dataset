

# Generated at 2022-06-26 04:51:02.584227
# Unit test for function main
def test_main():
    assert main() == None
    pass

# Generated at 2022-06-26 04:51:05.276757
# Unit test for function main
def test_main():
    print("Test case: Expected false")
    test_case_0()
    assert not True, "Expected false"
    return None


if __name__ == '__main__':
    test_main()
else:
    main()

# Generated at 2022-06-26 04:51:16.274374
# Unit test for function main
def test_main():
    # Assign
    test_file = os.path.splitext(os.path.basename(__file__))[0]
    tests_dir = os.path.dirname(__file__)
    repo_dir = os.path.dirname(tests_dir)
    test_data_dir = os.path.join(tests_dir, "data", test_file)
    test_case_dir = os.getcwd()
    if os.path.isdir(test_case_dir):
        shutil.rmtree(test_case_dir)
    shutil.copytree(test_data_dir, test_case_dir)
    output_file = os.path.join(test_case_dir, "output.txt")

# Generated at 2022-06-26 04:51:19.637568
# Unit test for function main
def test_main():
    # Call function main
    var_0 = main()

    # Do assertion
    assert not var_0 or var_0

    # Print var_0
    print(var_0)


# Main
if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:51:30.787340
# Unit test for function main
def test_main():
    from subprocess import call
    from os import kill
    from signal import SIGTERM
    import os
    import tempfile
    from pathlib import Path
    
    
    fd, temp_file_path = tempfile.mkstemp()
    
    
    
    # If temp_file_path exists, make sure it is empty
    if Path(temp_file_path).exists():
        with open(temp_file_path, "w") as f:
            f.seek(0)
            f.truncate()
    
    
    
    
    
    
    
    
    
    
    
    
    
    # Change the permissions of the temp file to make this file executable
    os.chmod(temp_file_path, 0o744)
    # The default mode for the temp file is "w

# Generated at 2022-06-26 04:51:36.597357
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except SystemExit as exception:
        if exception.code == 0:
            print('test case 0 passed')
        else:
            print('test case 0 failed')


# Generated at 2022-06-26 04:51:38.521224
# Unit test for function main
def test_main():
    input_0 = None


# Generated at 2022-06-26 04:51:51.224604
# Unit test for function main
def test_main():
    old_stdin = sys.stdin
    old_stdout = sys.stdout
    old_stderr = sys.stderr

    from io import StringIO

    try:
        inp = StringIO('inp')
        out = StringIO('out')
        err = StringIO('err')

        sys.stdin = inp
        sys.stdout = out
        sys.stderr = err

        test_case_0()

        assert sys.stdin == inp
        assert sys.stdout == out
        assert sys.stderr == err

    finally:
        sys.stdin = old_stdin
        sys.stdout = old_stdout
        sys.stderr = old_stderr

# Generated at 2022-06-26 04:51:52.370966
# Unit test for function main
def test_main():
    test_case_0()
    # Test case where stdin is empty
    # test_case_1()

# Generated at 2022-06-26 04:51:54.261475
# Unit test for function main
def test_main():
    # Arrange
    # Act
    test_case_0()
    # Assert

# Generated at 2022-06-26 04:52:11.956168
# Unit test for function main
def test_main():
    var_0 = main()

# Generated at 2022-06-26 04:52:12.736169
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-26 04:52:13.558603
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-26 04:52:19.932619
# Unit test for function main
def test_main():
    ####
    # Variables for param values
    ####
    global var_0


# Generated at 2022-06-26 04:52:24.467141
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        return 1


if __name__ == '__main__':
    sys.exit(main() or 0)

# Generated at 2022-06-26 04:52:26.242476
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None

# Generated at 2022-06-26 04:52:33.778821
# Unit test for function main
def test_main():
    # Set up test inputs
    test_inputs = ['fuck']

    # Call function
    main()

    # Check function output
    # Check logging output
    # Also compare to other fixtures to make sure log output is not changing unintentionally
    fixture_file = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'fixtures/tf_log.txt')
    expected_output = open(fixture_file, 'r').read()
    assert(expected_output == logs._log_output)


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:52:36.883808
# Unit test for function main
def test_main():
    main()

# Testing if the main is working
if __name__ == "__main__":
    main()

# Generated at 2022-06-26 04:52:38.774895
# Unit test for function main
def test_main():
    assert callable(main), "Expected callable."


# Generated at 2022-06-26 04:52:44.290272
# Unit test for function main
def test_main():
    # Test if function runs without error
    try:
        test_case_0()
    except:
        return False
    return True

# Generated at 2022-06-26 04:53:04.510389
# Unit test for function main
def test_main():
    # Assert if the function raises a SystemExit exception
    with pytest.raises(SystemExit):
        # Call the function
        main()

# Generated at 2022-06-26 04:53:10.991898
# Unit test for function main
def test_main():
    try:
        main.__code__ = compile('def main():\n    logs.version("The Fuck {}".format(get_installation_info().version),\n                 sys.version.split()[0],\n                 shell.info())', '', 'exec')
        var_0 = main()
    except Exception as e:
        logs.exception(e)
        assert False
    else:
        print(var_0)
        assert True


# Generated at 2022-06-26 04:53:16.431570
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False


if __name__ == '__main__':
    try:
        test_main()
    except:
        pass

# Generated at 2022-06-26 04:53:20.806856
# Unit test for function main
def test_main():
    assert func_0(param_0, param_1) == expected_0
    assert func_0(param_0, param_1) == expected_1
    assert func_0(param_0, param_1) == expected_2


# Generated at 2022-06-26 04:53:24.036279
# Unit test for function main
def test_main():
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:53:29.601820
# Unit test for function main
def test_main():
    print("test_main")
    test_case_0()

# Generated at 2022-06-26 04:53:31.967683
# Unit test for function main
def test_main():
    sys.argv[1] = 'fuck'
    var_0 = main()
    assert(var_0 == None)
    var_1 = main()
    assert(var_1 == None)

# Generated at 2022-06-26 04:53:42.830053
# Unit test for function main
def test_main():
    from thefuck.main import main # Thefuck.main.main
    from thefuck.main import test_case_0 # Thefuck.main.test_case_0
    from thefuck.main import test_main # Thefuck.main.test_main
    from thefuck.main import print_alias # Thefuck.main.print_alias
    from thefuck.main import fix_command # Thefuck.main.fix_command

    import sys, os # sys and os
    import traceback # traceback

    # Set unit testing varibles
    main.thefuck_settings__dir = "~/.thefuck" # main.thefuck_settings__dir
    main.display_fuck_command = False # main.display_fuck_command
    main.wait_command = 3 # main.wait_command
    main.no_colors = False # main.no

# Generated at 2022-06-26 04:53:44.863595
# Unit test for function main
def test_main():
    var_0 = main()
    return var_0


# Generated at 2022-06-26 04:53:54.187470
# Unit test for function main

# Generated at 2022-06-26 04:54:34.956109
# Unit test for function main
def test_main():
    # Testing case 0
    try:
        var_0 = main()
    except SystemExit:
        logs.error('Caught SystemExit exception')
    else:
        assert var_0 is None, 'test_case_0:  Failed'
        logs.info('test_case_0:  Success')
    # Testing case 1
    try:
        var_0 = main()
    except SystemExit:
        logs.error('Caught SystemExit exception')
    else:
        assert var_0 is None, 'test_case_1:  Failed'
        logs.info('test_case_1:  Success')

# Generated at 2022-06-26 04:54:37.386052
# Unit test for function main
def test_main():
    print('Testing main...')
    assert test_case_0() == None

test_main()

# Generated at 2022-06-26 04:54:40.505948
# Unit test for function main
def test_main():
    with pytest.raises(Exception) as e_0:
        test_case_0()
    assert e_0.type == SystemExit
    assert e_0.value.code == 0

if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-26 04:54:42.395504
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-26 04:54:44.652655
# Unit test for function main
def test_main():
    var_0 = main()


# Generated at 2022-06-26 04:54:49.549465
# Unit test for function main
def test_main():
    import mock
    with mock.patch('sys.argv', ['thefuck', 'command', 'arg1', 'arg2']):
        test_case_0()


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:54:51.338353
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:54:55.255347
# Unit test for function main
def test_main():
    var_0 = main()

    # Test if the main function runs without error
    assert var_0 == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:54:57.169220
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-26 04:55:00.198511
# Unit test for function main
def test_main():
    var_0 = main()

print('\n', 'Test Results', '\n', '='*30)

test_case_0()
test_main()

# Generated at 2022-06-26 04:56:10.785087
# Unit test for function main
def test_main():
    assert callable(main)

    # Call function main
    main()

# Generated at 2022-06-26 04:56:16.840826
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except Exception as err:
        print("Test case 0 failed")
        print(err)
        assert False
    else:
        assert True


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:56:18.877781
# Unit test for function main
def test_main():
    main()
    assert True



# Generated at 2022-06-26 04:56:23.855167
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-26 04:56:26.110109
# Unit test for function main

# Generated at 2022-06-26 04:56:28.915019
# Unit test for function main
def test_main():
    capture_output = io.StringIO()              # Create IO object
    sys.stdout = capture_output                 #  and redirect stdout.
    main()
    sys.stdout = sys.__stdout__                 # Reset redirect.
    output = capture_output.getvalue().strip()
    return output


# Generated at 2022-06-26 04:56:34.084348
# Unit test for function main
def test_main():
    # tests: 3

    # from types import ModuleType
    
    # test_case_0()
    var_0 = main()
    assert var_0 == None

    
    
    
    


# Generated at 2022-06-26 04:56:37.685684
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-26 04:56:38.587179
# Unit test for function main
def test_main():
    assert test_case_0() == None

main()

# Generated at 2022-06-26 04:56:46.412074
# Unit test for function main
def test_main():
    # Check if main() invoke the function
    # Command: thefuck
    # Command: thefuck --help
    # Command: thefuck --version
    # Command: thefuck --alias
    # Command: thefuck --shell-logger
    test_case_0()


if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:59:33.832798
# Unit test for function main
def test_main():
    logs.set_log(True)
    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:59:34.733685
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-26 04:59:35.784069
# Unit test for function main
def test_main():
    var_3 = main()
    assert var_3 == None


# Generated at 2022-06-26 04:59:43.168132
# Unit test for function main
def test_main():
    try:
        from unittest.mock import Mock
        from unittest.mock import patch
    except ImportError:
        from mock import Mock
        from mock import patch
    with patch('thefuck.main.main', Mock(name='main')) as mock_main:
        # Call the function under test with mocked out input
        main()
        # Check the function was called
        assert mock_main.called


# Generated at 2022-06-26 04:59:47.194374
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 is None, var_0


# Test main()
test_case_0()
test_main()

# Generated at 2022-06-26 04:59:50.275892
# Unit test for function main
def test_main():
    test_case_0()

__all__ = [
    "test_case_0",
    "test_main"
]

# Generated at 2022-06-26 04:59:56.249025
# Unit test for function main
def test_main():
    # Assign function parameters as strings.
    # Function parameters as strings.
    function_parameter_0 = 'Hello world'
    function_parameter_1 = 'This is a test'

    # Call function
    var_0 = main(function_parameter_0, function_parameter_1)

# Generated at 2022-06-26 04:59:59.139460
# Unit test for function main
def test_main():
    var_1 = main()

# vim: set tabstop=4 shiftwidth=4 softtabstop=4 expandtab :

# Generated at 2022-06-26 05:00:00.975536
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 05:00:03.490114
# Unit test for function main
def test_main():
    test_case_0()
    test_case_1()