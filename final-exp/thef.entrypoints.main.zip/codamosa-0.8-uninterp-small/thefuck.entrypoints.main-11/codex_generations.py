

# Generated at 2022-06-26 04:50:59.914580
# Unit test for function main
def test_main():
    var_1 = main()
    assert var_1 == None

# Generated at 2022-06-26 04:51:09.264057
# Unit test for function main
def test_main():
    var_0 = Parser()
    var_1 = var_0.parse(sys.argv)

    if var_1.help:
        var_0.print_help()
    else:
        if var_1.version:
            var_2 = get_installation_info()
            var_3 = sys.version.split()
            logs.version(var_2.version, var_3[0], shell.info())
        else:
            if var_1.alias:
                print_alias(var_1)
            else:
                if var_1.command or 'TF_HISTORY' in os.environ:
                    fix_command(var_1)

# Generated at 2022-06-26 04:51:20.714933
# Unit test for function main
def test_main():
    try:
        import mock
        from os import environ
    except ImportError:
        mock = None

    if mock is None:
        try:
            from unittest.mock import patch
        except ImportError:
            from mock import patch
    else:
        from mock import patch
    import re

    # Setting up mock
    mocked_main = mock.Mock(side_effect=main)
    mocked_print_alias = mock.Mock(side_effect=print_alias)
    mocked_fix_command = mock.Mock(side_effect=fix_command)
    mocked_shell_logger = mock.Mock(side_effect=shell_logger)

# Generated at 2022-06-26 04:51:21.557117
# Unit test for function main
def test_main():

    # Call function main
    main()

    # Assert
    assert True

# Generated at 2022-06-26 04:51:30.592586
# Unit test for function main
def test_main():
  
    # Setup the call to main
    def side_effect(argv):
      return Parser().parse(argv)

    with patch('thefuck.main.Parser') as mock_Parser:

      mock_instance = mock_Parser.return_value
      mock_instance.parse.side_effect = side_effect

      # Call the function
      result = main()

    # Assert the result
    assert result is None, 'function returns'
  
    # Assert the side effects
    assert mock_instance.parse.call_count == 1, 'function calls'
    assert mock_instance.parse.call_args_list[0][0][0] == sys.argv, 'function calls'

# Generated at 2022-06-26 04:51:41.967000
# Unit test for function main
def test_main():
    # Arrange
    argv_0 = "thefuck"
    argv_1 = "--help"
    argv_2 = "--version"
    argv_3 = "--alias"
    argv_4 = """rm -rf """.split()
    argv_5 = "--shell-logger"
    argv_6 = "--pdb"
    argv_7 = "--no-colors"
    argv_8 = "--spawn-wait"
    argv_9 = "--wait"
    argv_10 = "--count"
    argv_11 = "--auto-sudo"
    argv_12 = "--conf"
    argv_13 = "--eval-file"
    argv_14 = "--no-wait"

# Generated at 2022-06-26 04:51:42.766457
# Unit test for function main
def test_main():
    assert True == True

# Generated at 2022-06-26 04:51:45.336200
# Unit test for function main
def test_main():
    logs.init_logging()
    test_case_0()

# Generated at 2022-06-26 04:51:49.747000
# Unit test for function main
def test_main():
    # Do not change this test
    command_line_args = [sys.argv[0], ""]
    with mock.patch.object(sys, 'argv', command_line_args):
        test_case_0()

main()

# Generated at 2022-06-26 04:51:54.703044
# Unit test for function main
def test_main():
    # Create mock object
    mock_0 = MagicMock()
    mock_1 = MagicMock()
    var_0 = test_case_0(mock_0,mock_1)
    assert var_0 == 0

# Generated at 2022-06-26 04:52:08.705074
# Unit test for function main
def test_main():
    var_1 = 'thefuck'
    from sys import argv as argv
    argv[:] = [var_1, '--version']
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:52:15.624459
# Unit test for function main
def test_main():
    # Mock function call
    main()
    try:
        main_mock
    except NameError:
        main_mock = Mock()
        main_mock.side_effect = main
    assert main_mock.called
    assert main_mock.call_count == 1

# Generated at 2022-06-26 04:52:18.071058
# Unit test for function main
def test_main():
    log_0 = None
    obj_0 = call_main(log_0)
    return None


# Generated at 2022-06-26 04:52:19.890855
# Unit test for function main
def test_main():
    var_0 = main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:52:29.792560
# Unit test for function main
def test_main():
    sys.argv[1:] = ["-h"]
    test_case_0()
    sys.argv[1:] = ["--version"]
    test_case_0()
    sys.argv[1:] = ["--alias", "alias", "ps"]
    test_case_0()
    sys.argv[1:] = ["--command", "ps"]
    test_case_0()
    sys.argv[1:] = ["--shell-logger", "--log-file", "test.txt"]
    test_case_0()

# Generated at 2022-06-26 04:52:30.524434
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-26 04:52:32.655096
# Unit test for function main
def test_main():
  # We don't have mocking in place so we'll just run this.
  main()

# Generated at 2022-06-26 04:52:46.255976
# Unit test for function main
def test_main():
    var_1 = True
    var_2 = False
    

# Generated at 2022-06-26 04:52:47.968570
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:52:48.812494
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-26 04:53:05.721535
# Unit test for function main
def test_main(): 
    test_case_0()

test_main()

# Generated at 2022-06-26 04:53:15.530550
# Unit test for function main

# Generated at 2022-06-26 04:53:21.902878
# Unit test for function main
def test_main():
    var_1 = False
    if (os.path.isfile('<setup.py>')):
        var_1 = True

    var_2 = False
    if (os.path.isfile('<test_main.py>')):
        var_2 = True

    var_3 = False
    if (var_1 and var_2):
        var_3 = True

    if (var_3):
        test_case_0()

# Generated at 2022-06-26 04:53:25.213606
# Unit test for function main
def test_main():
    os.environ["TF_HISTORY"] = "1"
    main()


# Generated at 2022-06-26 04:53:29.185018
# Unit test for function main
def test_main():

    test_case_0()

# Generated at 2022-06-26 04:53:30.721825
# Unit test for function main
def test_main():
    print('Testing function main')
    test_case_0()


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:53:38.800526
# Unit test for function main
def test_main():
    args = ['thefuck', 'ls', '.']
    parse_main(args)
    args = ['thefuck', 'ls', '.', '-v']
    parse_main(args)
    args = ['thefuck', 'ls', '.', '--version']
    parse_main(args)
    args = ['thefuck', 'ls', '.', '--help']
    parse_main(args)

# Generated at 2022-06-26 04:53:39.874765
# Unit test for function main
def test_main():
    test_case_0()

# Generated at 2022-06-26 04:53:43.594882
# Unit test for function main
def test_main():
    assert main() == None, 'Test Failed'
    return 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:53:46.598265
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    sys.exit(test_main())

# Generated at 2022-06-26 04:54:21.878659
# Unit test for function main
def test_main():
    try:
        os.unlink(".tfcmd")
    except BaseException:
        pass

    test_case_0()

if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:54:26.721895
# Unit test for function main
def test_main():
    # Test that main executes properly
    assert test_case_0() == None, "Failure, main is not working in The Fuck."

########## Test Cases End ##########

# If running tests, exit now
if __name__ == '__main__':
    exit()

main()

# Generated at 2022-06-26 04:54:29.698060
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        print("Error raised in function main, check the inputs")

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:54:32.082795
# Unit test for function main
def test_main():
    test_case_0()

main()

# Generated at 2022-06-26 04:54:41.850410
# Unit test for function main
def test_main():
    var_0 = os.environ
    var_0['TF_HISTORY'] = 'echo OK'
    var_1 = sys.argv
    var_1.append('--help')
    var_0 = main()
    var_1 = sys.argv
    del var_1[-1]
    var_0 = main()
    var_1 = sys.argv
    var_1.append('--alias')
    var_0 = main()
    var_1 = sys.argv
    del var_1[-1]
    var_0 = main()
    var_1 = sys.argv
    var_1.append('--version')
    var_0 = main()
    var_1 = sys.argv
    del var_1[-1]
    var_0 = main()

# Generated at 2022-06-26 04:54:44.143151
# Unit test for function main
def test_main():
    assert (main() == None)


# Generated at 2022-06-26 04:54:45.632301
# Unit test for function main
def test_main():
    assert callable(main)


# Generated at 2022-06-26 04:54:49.255831
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        import sys
        print("In test case 0 for the function main:", file=sys.stderr)
        raise

# Generated at 2022-06-26 04:54:50.339813
# Unit test for function main
def test_main():
    # replace command with function you want to test
    assert callable(main)

# Generated at 2022-06-26 04:55:02.219278
# Unit test for function main
def test_main():
    import mock
    from ..utils import get_installation_info
    from ..system import init_output
    from ..shells import shell
    from ..argument_parser import Parser
    from .alias import print_alias
    from .fix_command import fix_command
    from .. import logs
    from ..argument_parser import Namespace

    with mock.patch('sys.argv', ['thefuck', '--help']):
        with mock.patch('thefuck.argument_parser.Parser.parse') as mock_parse:
            mock_parse.return_value = Namespace(help=True)
            with mock.patch('thefuck.argument_parser.Parser.print_help') as mock_print_help:
                test_case_0()
                assert mock_print_help.called


# Generated at 2022-06-26 04:56:10.828337
# Unit test for function main
def test_main():
    main()
    main()
    main()


# Generated at 2022-06-26 04:56:16.293992
# Unit test for function main
def test_main():
    case_0 = {
        'expected': \
"""--help            Show this message

--version         Show the version

--alias=ALIAS     Set a custom alias for The Fuck

""",
        }


# Generated at 2022-06-26 04:56:24.253134
# Unit test for function main
def test_main():
    # Test a function was called
    with patch('thefuck.main.print_alias') as mock_print_alias:
        args = argparse.Namespace(alias=None)
        main(args)
        mock_print_alias.assert_called()

    # Test a function was called
    with patch('thefuck.main.fix_command') as mock_fix_command:
        args = argparse.Namespace(command=None, env=None)
        main(args)
        mock_fix_command.assert_called()

    # Test a function was called
    with patch('thefuck.main.shell_logger') as mock_shell_logger:
        args = argparse.Namespace(shell_logger='bash')
        main(args)
        mock_shell_logger.assert_called()

    # Test a function was

# Generated at 2022-06-26 04:56:25.347576
# Unit test for function main
def test_main():
    assert True == test_case_0()

# Generated at 2022-06-26 04:56:26.668939
# Unit test for function main
def test_main():
    f_0 = main()
    assert f_0 == None


# Generated at 2022-06-26 04:56:29.675257
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:56:31.597441
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:56:33.006941
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-26 04:56:38.036193
# Unit test for function main
def test_main():
    # Test case 0
    test_case_0()
    # Test case 1
    # test_case_1()
    # Test case 2
    # test_case_2()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:56:42.210625
# Unit test for function main
def test_main():
    print("Unit test for function main")
    test_case_0()

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:59:24.846551
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-26 04:59:27.789606
# Unit test for function main
def test_main():
    try:
        assert callable(main)
    except AssertionError:
        return False
    
    return main() is None


# Generated at 2022-06-26 04:59:35.409746
# Unit test for function main
def test_main():
    with open('test_main.txt', 'w') as fp:
        with redirect_stdout(fp):
            test_case_0()
    with open('test_main.txt', 'r') as fp:
        output = ''.join(fp.readlines())

# Generated at 2022-06-26 04:59:37.549527
# Unit test for function main
def test_main():
    var_0 = main()
    # Check if function returns None
    assert var_0 is None
    # Check if function doesn't raise any exceptions


# Generated at 2022-06-26 04:59:46.714217
# Unit test for function main
def test_main():
    # Stub
    import __builtin__ as builtins
    builtins.logs = logs.logs
    builtins.get_installation_info = get_installation_info
    builtins.os = os
    builtins.print_alias = print_alias
    builtins.print_help = Parser().print_help
    builtins.print_usage = Parser().print_usage
    builtins.print_version = logs.print_version
    builtins.shell = shell
    builtins.sys = sys

    from thefuck.main import main
    main()

# Generated at 2022-06-26 04:59:57.941099
# Unit test for function main
def test_main():
    from .main import main as main_test
    from .main import fix_command as fix_command_test

    from .alias import print_alias as print_alias_test
    from .main import shell_logger as shell_logger_test
    # os.environ['TF_HISTORY'] = 'pwd'
    # os.environ['TF_ALIAS'] = 'echo it is an alias'
    # os.environ['TF_SHELL'] = 'false'
    # os.environ['TF_SHELL_LOGGER'] = 'false'
    # os.environ['TF_COMMAND'] = 'echo this is a command'
    # os.environ['TF_VARIABLE_0'] = '7'
    # os.environ['TF_VARIABLE_1'] = '10'
   

# Generated at 2022-06-26 04:59:59.138332
# Unit test for function main
def test_main():
    assert True == True


# Generated at 2022-06-26 05:00:09.924169
# Unit test for function main
def test_main():
    from .. import __version__, __shell__


    init_output()

    from . import alias
    from . import fix_command
    from . import shell_logger
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from .. import logs
    from ..argument_parser import Parser
    from ..shells import shell
    Parser_obj_0 = Parser()

    import sys
    var_0 = Parser_obj_0.parse(sys.argv)

    var_1 = var_0.help
    var_2 = var_0.version
    var_3 = var_0.alias
    var_4 = var_0.command
    var_5 = var_4
    var_6 = var_0.shell_

# Generated at 2022-06-26 05:00:17.933681
# Unit test for function main
def test_main():
    try:
        execfile('main.py', {'__name__': '__main__'})
    except SystemExit as var_0:
        assert var_0.code == 0
        return
    except:
        print('Uncaught exception')
        raise
    else:
        print('Test failed')

# Generated at 2022-06-26 05:00:21.817502
# Unit test for function main
def test_main():
    assert True
