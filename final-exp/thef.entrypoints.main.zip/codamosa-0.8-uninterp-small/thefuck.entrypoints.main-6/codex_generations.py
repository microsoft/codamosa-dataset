

# Generated at 2022-06-26 04:51:02.884493
# Unit test for function main
def test_main():
    # Test for case
    test_case_0()

# Generated at 2022-06-26 04:51:05.527507
# Unit test for function main
def test_main():
    command = 'TF_HISTORY=1 python -c "from thefuck import main; main()"'
    exit_status = os.system(" ".join([command, "echo The Fuck 0.0.0"]))
    assert exit_status == 0


# Generated at 2022-06-26 04:51:07.861841
# Unit test for function main
def test_main():
    from unittest import TestCase
    from . import main_orig

    class test_main(TestCase):
        def test_case_0(self):
            main_orig.main()



# Generated at 2022-06-26 04:51:20.500105
# Unit test for function main
def test_main():
    import sys  # noqa: E402
    import os  # noqa: E402

# Generated at 2022-06-26 04:51:21.945949
# Unit test for function main
def test_main():
    assert test_case_0()

# Generated at 2022-06-26 04:51:24.529554
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-26 04:51:26.997552
# Unit test for function main
def test_main():
    assert callable(main)
    var_0 = test_case_0()
    assert var_0 == None

# Generated at 2022-06-26 04:51:29.797502
# Unit test for function main
def test_main():
    try:
        test_case_0()
    except:
        assert True == False


if __name__ == '__main__':
    test_main()

# Generated at 2022-06-26 04:51:33.342717
# Unit test for function main
def test_main():
    # call the function
    test_case_0()


# Execute the unit tests
if __name__ == "__main__":
    test_main()

# Generated at 2022-06-26 04:51:34.846275
# Unit test for function main
def test_main():
    assert main() == None

test_case_0()

# Generated at 2022-06-26 04:51:45.408948
# Unit test for function main
def test_main():
    var_0 = main()
    assert var_0 == None

# Generated at 2022-06-26 04:51:48.684438
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-26 04:51:51.053932
# Unit test for function main
def test_main():
    try:
        var = main()
        assert var == 0
    except Exception as e:
        pytest.fail('Could not call function main \nError: {}'.format(e))



# Generated at 2022-06-26 04:51:56.340285
# Unit test for function main
def test_main():
    TestCase_0 = unittest.TestCase()
    with TestCase_0.assertRaises(ImportError):
        test_case_0()

# Generated at 2022-06-26 04:52:03.232509
# Unit test for function main
def test_main():
    # Caution: if you alter the test, it may be confusing to read
    # the source code.
    patch_args = FakeArgv(['-h', '--version', '--alias', 'python'])
    patch_args.__enter__()

# Generated at 2022-06-26 04:52:12.978654
# Unit test for function main
def test_main():
    try:
        assert os.path.exists('./tests/resources/sample_history')
    except AssertionError as e:
        raise(e)
    # Open file for read/write access
    f = open("./tests/resources/sample_history", "r+")
    lines = f.readlines()
    f.seek(0)
    for line in lines:
        if not line.startswith("pip"):
            f.write(line)
    f.truncate()
    f.close()

    sa = open("./tests/resources/sample_alias", "r")
    sa_lines = sa.readlines()
    sa.close()

    for line in sa_lines:
        key, value = line.split('=', 1)
        os.environ[key] = value

# Generated at 2022-06-26 04:52:19.481343
# Unit test for function main
def test_main():
    mocker.patch('sys.argv', [""])
    mocker.patch('main.fix_command', return_value=(None))
    mocker.patch('main.print_alias', return_value=(None))
    mocker.patch('main.shell_logger', return_value=(None))
    assert var_0 == "Error"
    var_1 = main()


# Generated at 2022-06-26 04:52:30.957244
# Unit test for function main
def test_main():
    os.environ['TF_REQUIRE_INTERACTIVE'] = '0'
    os.environ['TF_SHELL'] = 'bash'
    test_case_0()
    os.environ['TF_SHELL'] = 'sh'
    test_case_0()
    os.environ['TF_SHELL'] = 'dash'
    test_case_0()
    os.environ['TF_SHELL'] = 'zsh'
    test_case_0()
    os.environ['TF_SHELL'] = 'tcsh'
    test_case_0()
    os.environ['TF_SHELL'] = 'csh'
    test_case_0()

# Generated at 2022-06-26 04:52:39.063094
# Unit test for function main
def test_main(): 
    try: 
        assert callable(main)
    except: 
        print("Function `main` is not callable")
        return
    else: 
        pass

    import types
    from .fix_command import fix_command
    from .alias import print_alias

    # Empty
    params = {}
    returned = main(**params)
    returned = bool(returned)
    assert type(returned) == bool
    assert returned == False

    # Argument `help`
    params = {
        "help": True
    }
    returned = main(**params)
    returned = bool(returned)
    assert type(returned) == bool
    assert returned == False

    # Argument `version`
    params = {
        "version": True
    }
    returned = main(**params)
    returned = bool