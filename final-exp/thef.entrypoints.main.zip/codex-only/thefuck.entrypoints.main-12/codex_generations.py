

# Generated at 2022-06-24 05:21:15.653745
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:21:17.088041
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = "test"
    main()

# Generated at 2022-06-24 05:21:17.938383
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:21:19.587749
# Unit test for function main
def test_main():
    parser = Parser()
    sys.argv = ['fuck', '--alias', 'fuck']
    known_args = parser.parse(sys.argv)
    assert known_args.alias == 'fuck'

# Generated at 2022-06-24 05:21:30.348762
# Unit test for function main
def test_main():
    from mock import patch
    from sys import argv
    from .alias import test_print_alias
    from .fix_command import test_fix_command

    argv = ['thefuck']
    with patch('thefuck.main.Parser.parse') as mock_parse, \
            patch('thefuck.main.get_installation_info') as mock_version, \
            patch('thefuck.main.print_alias') as mock_alias:
        mock_parse.return_value = {'help': True, 'version': False,
                                   'alias': None, 'shell_logger': False,
                                   'command': None}
        main()
        mock_parse.assert_called_once_with(argv)
        mock_alias.assert_not_called()

    argv = ['thefuck', '--version']

# Generated at 2022-06-24 05:21:32.357243
# Unit test for function main
def test_main():
    with patch('sys.argv', ['thefuck']):
        assert main() == None


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:21:35.426676
# Unit test for function main
def test_main():
    try:
        from .shell_logger import shell_logger  # noqa: E402
    except ImportError:
        logs.warn('Shell logger supports only Linux and macOS')
        #return False
    else:
        shell_logger("no_arg.log")
    return True

# Generated at 2022-06-24 05:21:46.994632
# Unit test for function main
def test_main():
    import os  # noqa: E402
    import sys  # noqa: E402
    import tempfile  # noqa: E402
    from .. import logs  # noqa: E402

    logs.loggers.clear()
    logs.debug = lambda *args, **kwargs: None

    from ..argument_parser import Parser  # noqa: E402
    from ..utils import get_installation_info  # noqa: E402
    from ..shells import shell  # noqa: E402
    from .alias import print_alias  # noqa: E402
    from .fix_command import fix_command  # noqa: E402

    def mock_print_alias(args):
        print("mock alias")
    print_alias = mock_print_alias

    def mock_fix_command(args):
        print

# Generated at 2022-06-24 05:21:47.546462
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:21:56.276438
# Unit test for function main
def test_main():
    import os
    import sys
    import unittest
    import unittest.mock
    from thefuck.argument_parser import Parser


# Generated at 2022-06-24 05:22:03.308109
# Unit test for function main
def test_main():
    # test for help
    sys.argv = ['-h']
    main()

    # test for version
    sys.argv = ['--version']
    main()

    # test for alias
    sys.argv = ['--alias']
    main()

    # test for shell_logger
    sys.argv = ['--shell-logger']
    main()

    # test for everything else
    sys.argv = []
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:04.286119
# Unit test for function main
def test_main():
    assert(main() == None)

# Generated at 2022-06-24 05:22:06.529286
# Unit test for function main
def test_main():
    with patch('sys.argv', ['thefuck']):
        assert sys.argv == ['thefuck']

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:16.621032
# Unit test for function main
def test_main():
    from mock import patch, call, mock_open
    from .alias import write_alias  # noqa: E402
    from .fix_command import FixCommand  # noqa: E402

    with patch('sys.argv', ['thefuck', '--help']):
        with patch('builtins.print') as print_mock:
            with patch('thefuck.argument_parser.Parser.print_help') as print_help_mock:
                main()
                print_help_mock.assert_called_once()
                assert not print_mock.called

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('builtins.print') as print_mock:
            with patch('thefuck.logs.version') as version_mock:
                from ..utils import get_installation_

# Generated at 2022-06-24 05:22:18.193249
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:23.824530
# Unit test for function main
def test_main():
    from . import __main__
    from unittest import mock
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from .argument_parser import Parser
    mock_print_help = mock.Mock()
    mock_version = mock.Mock()
    mock_print_alias = mock.Mock()
    mock_fix_command = mock.Mock()
    mock_shell_logger = mock.Mock()
    mock_print_usage = mock.Mock()
    mock_parser = mock.Mock()
    mock_parser.return_value = mock_parser

# Generated at 2022-06-24 05:22:32.520819
# Unit test for function main
def test_main():
    # "With" function, when inserted in front of an expression, evaluates the expression, and binds any variables to it
    with patch('thefuck.main.sys') as sys, \
            patch('thefuck.main.Parser') as Parser, \
            patch('thefuck.main.logs.version'), \
            patch('thefuck.main.print_alias'), \
            patch('thefuck.main.fix_command'), \
            patch('thefuck.main.shell_logger') as shell_logger:

        # Mock the content of the sys argument for the function to work
        sys.argv = ['thefuck', '--version']

        # Mock the parser's attributes
        parser = Parser.return_value
        parser.parse.return_value = parser

        # Mock the parser's methods

# Generated at 2022-06-24 05:22:33.548906
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-24 05:22:41.699375
# Unit test for function main
def test_main():
    import os  # noqa: E402
    from ..utils import get_installation_info  # noqa: E402
    from ..system import get_shell_command  # noqa: E402
    from .alias import print_alias  # noqa: E402
    from .fix_command import fix_command  # noqa: E402

    mock_parser = Mock()
    mock_parser.parse = Mock(return_value=Mock(help=False, version=False, alias=False, shell_logger=None))
    mock_parser.print_help = Mock()

    monkeypatch.setattr(thefuck.main, 'Parser', Mock(return_value=mock_parser))
    monkeypatch.setattr(thefuck.logs, 'version', Mock())

# Generated at 2022-06-24 05:22:43.190706
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:44.665458
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:45.658803
# Unit test for function main
def test_main():
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-24 05:22:49.046646
# Unit test for function main
def test_main():
    func = main
    # call function
    try:
        func()
    except SystemExit as e:
        if e.code == 2:
            pass
        else:
            raise e
    else:
        raise Exception('SystemExit not raised')

# Generated at 2022-06-24 05:22:49.594530
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:22:59.241046
# Unit test for function main
def test_main():
    # Test help option
    with patch('sys.argv', ['fuck', '--help']):
        assert main() == print(Parser().format_help())
    # Test version option
    with patch('sys.argv', ['fuck', '--version']):
        assert main() == logs.version()
    # Test alias option
    with patch('sys.argv', ['fuck', '--alias']):
        assert main() == print_alias()
    # No options
    with patch('sys.argv', ['fuck']):
        assert main() == print('usage: fuck [-h] [--version] [--alias] [-d] [--shell-logger SHELL_LOGGER] [--help] command')


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:59.848941
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-24 05:23:01.022536
# Unit test for function main
def test_main():
    assert_raises(SystemExit, main)

# Generated at 2022-06-24 05:23:09.955414
# Unit test for function main
def test_main():
    arrs = [
        ["thefuck", "--help"],
        ["thefuck", "--version"],
        ["thefuck", "notatestcommand", "--history-size", "-5"],
        ["thefuck", "notatestcommand", "--no-colors", "--no-interactive"],
        ["thefuck", "notatestcommand", "--spawn-command", "cd", "./tests"],
        ["thefuck", "notatestcommand", "--priority", "cd"],

        ["thefuck", "--alias"],
        ["thefuck", "--alias", "fuck"],
        ["thefuck", "--alias", "fuck", "--shell=bash"],

    ]

    for arr in arrs:
        main()

# Generated at 2022-06-24 05:23:11.354338
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:23:12.128930
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:23:12.740045
# Unit test for function main
def test_main():
    assert main()==None

# Generated at 2022-06-24 05:23:13.371877
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:23:15.075245
# Unit test for function main
def test_main():
    assert main == main

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:23:15.698897
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:23:26.070025
# Unit test for function main
def test_main():
    from io import StringIO

    import sys
    from unittest.mock import patch

    from .fix_command import FixCommand  # noqa: E402
    from ..utils import TestCase  # noqa: E402

    class MainTest(TestCase):
        @patch('sys.exit', lambda *args: None)
        def test_prints_help_if_help_is_requested(self):
            main(['--help'])
            self.assertEqual(self.output, self.read_fixture('help.out'))

        @patch('sys.exit', lambda *args: None)
        def test_prints_usage_if_no_command(self):
            main([])
            self.assertEqual(self.output, self.read_fixture('usage.out'))


# Generated at 2022-06-24 05:23:27.160700
# Unit test for function main
def test_main():
    main()


###############################################################################


# Generated at 2022-06-24 05:23:35.818661
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse([])
    assert(known_args.help == False)
    assert(known_args.version == False)
    known_args = parser.parse(["--help"])
    assert(known_args.help == True)
    known_args = parser.parse(["--version"])
    assert(known_args.version == True)
    known_args = parser.parse(["--alias"])
    assert(known_args.alias == True)
    known_args = parser.parse(["--command"])
    assert(known_args.command == True)


# Generated at 2022-06-24 05:23:41.137113
# Unit test for function main
def test_main():
    # Test whether it prints help
    with logs.capture_output() as (out, err):
        main()
    assert out.getvalue().startswith('usage')
    assert err.getvalue() == ''

    # Test whether it prints version
    with logs.capture_output() as (out, err):
        main(['--version'])
    assert out.getvalue().startswith('The Fuck')
    assert err.getvalue() == ''

# Generated at 2022-06-24 05:23:42.727477
# Unit test for function main
def test_main():
    assert main() is None, "The function should return None"

# Generated at 2022-06-24 05:23:52.616325
# Unit test for function main
def test_main():
    import os
    import sys
    import subprocess
    from ..utils import get_installation_info
    from ..argument_parser import Parser
    from ..system import init_output

    init_output()
    current_directory = os.getcwd()
    installation_info = get_installation_info()

    def f():
        try:
            main()
        except SystemExit:
            return sys.exc_info()[1].code
        else:
            return 0

    # main
    assert f() == 0

    # --help
    assert f() == 0
    assert sys.argv == ['thefuck', '--help']

    # --version
    assert f() == 0
    assert sys.argv == ['thefuck', '--version']

    # --alias

# Generated at 2022-06-24 05:23:53.728423
# Unit test for function main
def test_main(): # noqa: D102
    assert main()


# Generated at 2022-06-24 05:23:54.292895
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:24:00.608585
# Unit test for function main
def test_main():
    # Test when help is requested
    with mock.patch('thefuck.main.parser') as parser_mock:
        main()
        parser_mock.parse.assert_called_with(sys.argv)
        parser_mock.print_help.assert_called()

    # Test when version is requested
    with mock.patch('thefuck.main.parser') as parser_mock:
        parser_mock.parse.return_value.version = True
        main()
        parser_mock.print_usage.assert_not_called()

    # Test when alias is requested
    with mock.patch('thefuck.main.parser') as parser_mock:
        parser_mock.parse.return_value.alias = True

# Generated at 2022-06-24 05:24:01.809949
# Unit test for function main
def test_main():
    assert(main() is None)

# Generated at 2022-06-24 05:24:05.923155
# Unit test for function main
def test_main():
    import subprocess
    import sys

    proc = subprocess.Popen([sys.executable, "-m", "thefuck"], stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    stdout, _ = proc.communicate()
    assert b'Usage: thefuck [OPTIONS] COMMAND' in stdout
    assert proc.returncode == 0

# Generated at 2022-06-24 05:24:07.501089
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = 'ls -l'
    main()

# Generated at 2022-06-24 05:24:17.959175
# Unit test for function main
def test_main():
    sys.argv = ['doesnt_matter', '-V']
    main()
    assert(sys.stdout.getvalue() == '3.27\npython 3.7.3\n\n')
    sys.stdout = io.StringIO()
    sys.argv = ['doesnt_matter', '--help']
    main()
    help_string = sys.stdout.getvalue()
    assert(help_string == usage)
    sys.argv = ['doesnt_matter', 'git', 'remote', '-v']
    # TODO: figure out how to properly mock this function in order to properly
    # test the case when a command is passed
    # main()
    # assert(sys.stdout.getvalue() == 'Changes pushed\n')


# Generated at 2022-06-24 05:24:19.538057
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:24:30.796435
# Unit test for function main
def test_main():
    # Test for help
    with mock.patch('thefuck.argument_parser.Parser.parse') as parse_mock:
        parse_mock.return_value = argparse.Namespace(help=True)
        with mock.patch('builtins.print') as print_mock:
            main()

# Generated at 2022-06-24 05:24:31.103709
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:24:31.397662
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:24:32.563483
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:24:41.699635
# Unit test for function main
def test_main():
    from unittest.mock import patch, MagicMock
    from argparse import Namespace
    from ..utils import get_installation_info
    from ..shells import shell
    import sys
    known_args = Namespace(
        exclude_rules=False,
        help=False,
        history_limit=None,
        match_path='',
        no_colors=False,
        rules=None,
        slow_commands_mode='always',
        use_notify_osd=False,
        wait=None,
        versions=False,
        alias=False,
        command=None,
        shell_logger=None,
        version=False,
        settings_path=None,
    )

# Generated at 2022-06-24 05:24:52.301646
# Unit test for function main
def test_main():
    from thefuck.conf import Settings
    from thefuck.rules.git import match, get_new_command
    try:
        import mock
    except ImportError:
        from unittest import mock
    import sys

    mock_popen = mock.Mock()
    sys.modules['subprocess'] = mock_popen

    mock_popen.Popen = mock.Mock()
    mock_popen.Popen.communicate = mock.Mock(return_value=("", ""))
    mock_popen.Popen.returncode = 0

    settings = Settings({'rules': ['thefuck.rules.git'],
                         'git_shortcut': False,
                         'wait_command': 0})
    

# Generated at 2022-06-24 05:25:01.992168
# Unit test for function main
def test_main():
    from .. import utils
    from ..config import Config
    from thefuck import settings
    import contextlib
    import os
    import sys

    @contextlib.contextmanager
    def _fake_user_config(user_config):
        with utils.temp_dir() as temp_path:
            config_file = os.path.join(temp_path, '.config', 'thefuck', 'settings.py')
            os.makedirs(os.path.dirname(config_file))
            with open(config_file, 'w') as config:
                config.write(user_config)
            with utils.temp_environ():
                os.environ['XDG_CONFIG_HOME'] = temp_path
                yield

    config = Config(settings, load_system_config=False)
    config.clear()



# Generated at 2022-06-24 05:25:04.747127
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 2

# Generated at 2022-06-24 05:25:12.643273
# Unit test for function main
def test_main():
    # Testing for 'help' argument
    main(['-h'])
    assert 'Usage' in logs.output
    assert 'TF_SHELL' in logs.output
    assert 'TF_ALIAS' in logs.output

    # Testing for 'version' argument
    main(['-v'])
    assert 'thefuck' in logs.output

    # Testing for 'shell_logger' argument
    # TODO: Need to implement try and except
    # main(['-s', 'bash'])
    # assert 'The Fuck {} shell logger is initialized'.format('bash') in logs.output

    # Testing for empty arguments
    main([])
    assert 'Usage' in logs.output
    assert 'TF_SHELL' in logs.output
    assert 'TF_ALIAS' in logs.output

# Generated at 2022-06-24 05:25:13.205028
# Unit test for function main
def test_main():
    logging.basicConfig = lambda **kwargs: None
    assert main() == 0

# Generated at 2022-06-24 05:25:13.508501
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:25:14.110983
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:25:21.235783
# Unit test for function main
def test_main():
    # Unit test for argument parser

    # Test for help argument
    try:
        sys.argv = ['thefuck', '--help']
        main()
    except SystemExit:
        assert True

    # Test for version argument
    try:
        sys.argv = ['thefuck', '--version']
        main()
    except SystemExit:
        assert True

    # Test for alias argument
    try:
        sys.argv = ['thefuck', '--alias']
        main()
    except SystemExit:
        assert True

    # Test for command argument
    sys.argv = ['thefuck', 'echo']
    main()

    # Test for no command argument
    try:
        sys.argv = ['thefuck']
        main()
    except SystemExit:
        assert True



# Generated at 2022-06-24 05:25:27.383617
# Unit test for function main
def test_main():
    # check for help option
    fake_argv = ['tf', '--help']
    sys.argv = fake_argv
    main()

    # check for version option
    fake_argv = ['tf', '--version']
    sys.argv = fake_argv
    main()

    # check for alias option
    fake_argv = ['tf', '--alias', 'fuck=thefuck']
    sys.argv = fake_argv
    main()

    # check for command
    fake_argv = ['tf', '--command=54321']
    sys.argv = fake_argv
    main()

    # check for shell_logger
    fake_argv = ['tf', '--shell_logger']
    sys.argv = fake_argv
    main()

# Generated at 2022-06-24 05:25:28.270555
# Unit test for function main
def test_main():
    res = main()
    assert res is None

# Generated at 2022-06-24 05:25:29.391549
# Unit test for function main
def test_main():
    from . import main1
    main1.main()

# Generated at 2022-06-24 05:25:29.949387
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:25:31.886739
# Unit test for function main
def test_main():
    sys.argv = ['thefuck']
    assert main() == None


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:25:32.413513
# Unit test for function main
def test_main():
    assert main is not None

# Generated at 2022-06-24 05:25:32.938792
# Unit test for function main
def test_main():
    assert main()==1

# Generated at 2022-06-24 05:25:33.452087
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:25:33.939908
# Unit test for function main
def test_main():
	main()

# Generated at 2022-06-24 05:25:34.736435
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:25:43.325389
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert (get_installation_info().version == logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info()) == '3.32.0')
    assert (logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info()) == 'The Fuck 3.32.0 using Python 3.6.5')
    assert get_installation_info().version == '3.32.0'  # noqa: E711

# Generated at 2022-06-24 05:25:44.361940
# Unit test for function main
def test_main():
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-24 05:25:51.957018
# Unit test for function main
def test_main():
    sys.argv.append('--version')
    assert main() == 'The Fuck 3.13 using Python 3.7.3'
    sys.argv.remove('--version')
    sys.argv.append('--alias')
    assert main() == 'eval $(thefuck --alias)'
    sys.argv.remove('--alias')
    sys.argv.append('--shell-logger')
    assert main() == 'Logging shell... Press Enter or Esc to exit'
    sys.argv.remove('--shell-logger')
    sys.argv.append('--help')
    assert main() == 'usage: thefuck [-h] [--version] [--alias] [--shell-logger]'
    sys.argv.remove('--help')

# Generated at 2022-06-24 05:25:58.850488
# Unit test for function main
def test_main():
    import argparse
    from contextlib import contextmanager

    from .argument_parser import help_message
    from .argument_parser import version_message
    from .argument_parser import usage_message

    @contextmanager
    def replace(module, name, value):
        original = getattr(module, name)
        setattr(module, name, value)
        yield
        setattr(module, name, original)

    @contextmanager
    def replace_argv(argv):
        original_argv = sys.argv
        sys.argv = argv
        yield
        sys.argv = original_argv

    @contextmanager
    def capture_output():
        from io import StringIO
        output = None

# Generated at 2022-06-24 05:25:59.852444
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-24 05:26:01.995248
# Unit test for function main
def test_main():
    args = ['thefuck', '--version']
    assert main() == Parser().parse(args)

# Generated at 2022-06-24 05:26:03.007157
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-24 05:26:05.252540
# Unit test for function main
def test_main():
    args = 'thefuck --version'
    main(args.split())



if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:06.365852
# Unit test for function main
def test_main():
    assert main


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:07.611274
# Unit test for function main
def test_main():
    logs.init(lambda x: None)
    main()
#


# Generated at 2022-06-24 05:26:09.162629
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:16.779676
# Unit test for function main
def test_main():
    from unittest import mock
    import argparse
    from .. import argument_parser
    from .. import system
    with mock.patch('sys.argv', ['thefuck']):
        assert(main()==None)
    with mock.patch('sys.argv', ['thefuck', '--version']):
        assert(main()==None)
    with mock.patch('sys.argv', ['thefuck', '--help']):
        assert(main()==None)
    with mock.patch('sys.argv', ['thefuck', '--alias', 'tf']):
        assert(main()==None)
    with mock.patch('sys.argv', ['thefuck', 'fuck']):
        assert(main()==None)

# Generated at 2022-06-24 05:26:17.392389
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:26:18.096903
# Unit test for function main
def test_main():
    main()
    assert main() == None

# Generated at 2022-06-24 05:26:18.556107
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:26:19.061725
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:26:20.720508
# Unit test for function main
def test_main():
    sys.argv = ['mock', '--alias', 'howdy', 'alias',
                'cd', '/home/mock', 'cd', '~']
    main()

# Generated at 2022-06-24 05:26:24.292439
# Unit test for function main
def test_main():
    try:
        if main() is None:
            print("Main function has no return statement.")
        else:
            print("Main function does have a return statement.")
    except Exception:
        print("Main function does have an Exception")

test_main()

# Generated at 2022-06-24 05:26:27.630912
# Unit test for function main
def test_main():
    # Arrange
    test_argv = ['fuck']

    # Act
    main()
    # print_alias(test_argv)
    # fix_command(test_argv)

    # Assert

# Generated at 2022-06-24 05:26:28.230866
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-24 05:26:29.912439
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        assert True

# Generated at 2022-06-24 05:26:38.876063
# Unit test for function main
def test_main():

    #test for branch with known_args.help.
    class fake_known_args:
        help = True
        version = False
        alias = False
        command = False
        shell_logger = False

    main()
    main(fake_known_args)

# test for branch with known_args.version.
    class fake_known_args:
        help = False
        version = True
        alias = False
        command = False
        shell_logger = False

    main()
    main(fake_known_args)

# test for branch with known_args.alias
    class fake_known_args:
        help = False
        version = False
        alias = True
        command = False
        shell_logger = False

    main()
    main(fake_known_args)

# test for branch with known_

# Generated at 2022-06-24 05:26:39.548913
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:26:41.383083
# Unit test for function main
def test_main():
#    args = []
#    parser = Parser()
#    known_args = parser.parse(args)
    pass

# Generated at 2022-06-24 05:26:49.399169
# Unit test for function main
def test_main():
    import sys
    import io
    # setup
    new_argv = ['./thefuck.py','--version']
    original_stdout = sys.stdout
    original_argv = sys.argv
    sys.argv = new_argv
    captured_output = io.StringIO()
    sys.stdout = captured_output
    # test
    try:
        main()
    except SystemExit as e:
        if e.code != 0:
            raise e
    # teardown
    sys.stdout = original_stdout
    sys.argv = original_argv
    assert 'thefuck' in captured_output.getvalue()

# Generated at 2022-06-24 05:26:56.629858
# Unit test for function main
def test_main():
    import unittest.mock # noqa: E402

    with unittest.mock.patch('sys.argv', ['thefuck','--version']):
        with unittest.mock.patch('thefuck.main.logs.version') as logs_version:
            with unittest.mock.patch('thefuck.main.init_output') as init_output:
                main()
                assert logs_version.call_count == 1
                assert init_output.call_count == 1

# Generated at 2022-06-24 05:27:03.519089
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from unittest.mock import call
    from unittest.mock import MagicMock

    from .alias import print_alias
    from .shell_logger import shell_logger

    with patch.object(Parser, 'parse') as mock_parse, \
         patch.object(Parser, 'print_help'), \
         patch.object(Parser, 'print_usage'):
        mock_parse.return_value = MagicMock(
            help=False,
            version=False,
            alias=False,
            command=False,
            shell_logger=False
        )
        main()
        mock_parse.assert_called_once_with(sys.argv)
        Parser.print_usage.assert_called_once_with()


# Generated at 2022-06-24 05:27:05.155150
# Unit test for function main
def test_main():
    import thefuck
    assert thefuck.__main__.main() == None

# Generated at 2022-06-24 05:27:06.859206
# Unit test for function main
def test_main():
    os.environ["TF_HISTORY"] = "fdgfdgfdgfdgfdgfdg"
    main()

# Generated at 2022-06-24 05:27:08.082108
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False

# Generated at 2022-06-24 05:27:08.659469
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:27:19.210484
# Unit test for function main
def test_main():
    import sys
    import io
    import subprocess
    from unittest.mock import patch

    from .alias import print_alias as _print_alias
    from .fix_command import fix_command as _fix_command
    from ..shells import shell

    def _shell_info():
        return shell.Shell(
            os.path.join(os.path.dirname(os.path.dirname(
                os.path.dirname(os.path.abspath(__file__))))),
            'bash')

    def _log_version(version, python_version, shell_info):
        return None

    def _parser_print_usage():
        return None

    def _parser_print_help():
        return None

    def _log_warning(message):
        return None


# Generated at 2022-06-24 05:27:20.886126
# Unit test for function main
def test_main():
    from . import command_from_history, get_aliases
    from .check import get_closest_match
    from ..utils import get_all_executables

    assert main() == 'finish'

# Generated at 2022-06-24 05:27:22.139064
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:27:32.736342
# Unit test for function main
def test_main():
    from unittest.mock import patch, MagicMock
    from .alias import print_alias
    from .fix_command import fix_command
    test_argv = ['thefuck', '-v']
    # test parser.parse()
    with patch('sys.argv', test_argv):
        with patch('thefuck.argument_parser.Parser') as mock_parser:
            mock_parser.return_value.parse.return_value = "mock_known_args"
            known_args = main()
            mock_parser.parse.assert_called_once_with(test_argv)
            assert known_args == mock_parser.parse.return_value

    # test logs.version()

# Generated at 2022-06-24 05:27:34.590846
# Unit test for function main
def test_main():
    import sys
    
    main()
    assert sys.argv == ['fuck.py']

# Generated at 2022-06-24 05:27:35.200356
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:27:37.164215
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:27:39.162619
# Unit test for function main
def test_main():
    sys.argv = ["thefuck", "echo", "hello", "world"]
    main()

# Generated at 2022-06-24 05:27:45.993523
# Unit test for function main
def test_main():
    # pylint: disable=protected-access
    from .test_app import TFApp
    from .test_argument_parser import TFArgumentParser

    def MockParser():
        return TFArgumentParser()

    def MockApp():
        return TFApp()

    sys.argv = ['./thefuck']
    import thefuck.app as app
    app.ArgumentParser = MockParser
    app.App = MockApp
    app.main()
    assert main() == None  # To check if the code reaches the end of the function

# Generated at 2022-06-24 05:27:51.979268
# Unit test for function main
def test_main():
    # Check if the help message is printed
    from unittest.mock import patch  # noqa: E402
    with patch('sys.stdout') as stdout_mock:
        from . import main as main_fn
        main_fn()
        stdout_mock.assert_called_with(
            'usage: thefuck [-h] [-v] [-a SHELL] [-l] [-r] [-f]\n')


# Generated at 2022-06-24 05:27:52.477279
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:27:54.127575
# Unit test for function main
def test_main():
    try:
        main()
    except:
        raise

# Generated at 2022-06-24 05:27:54.689364
# Unit test for function main
def test_main():
  assert main()==0

# Generated at 2022-06-24 05:27:55.406119
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:28:01.186444
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(['--alias','echo','hello'])
    assert known_args.alias
    assert not known_args.help
    assert not known_args.version
    assert known_args.command == 'echo'
    assert known_args.command_args == 'hello'
    assert not known_args.shell_logger


# Generated at 2022-06-24 05:28:01.769090
# Unit test for function main
def test_main():
    assert False

# Generated at 2022-06-24 05:28:06.930640
# Unit test for function main
def test_main():
    global sys
    import argparse

    # Mock argv
    sys.argv = ['thefuck','--alias','ls','git','--dryrun','--safe','--no-enable-vcs-staging','--no-create-dirs',
    '--exclude-standard','.','--quiet']
    # Mock parser to avoid printing
    parser = argparse.ArgumentParser()
    parser.version = '3.6.0'
    parser.add_argument = lambda *args, **kwargs: None
    parser.parse_args = lambda self, args=None, namespace=None: None
    parser.exit = lambda self, status=0, message=None: None
    # The code below is the same from main
    if known_args.help:
        parser.print_help()

# Generated at 2022-06-24 05:28:12.209585
# Unit test for function main
def test_main():

    # Check if the help option works
    sys.argv = ['thefuck', '-h']
    main()
    assert True

    # Check if the alias option works
    sys.argv = ['thefuck', '--alias']
    main()
    assert True

    # Check if the version option works
    sys.argv = ['thefuck', '--version']
    main()

# Generated at 2022-06-24 05:28:13.659912
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--version']
    assert main() == None

# Generated at 2022-06-24 05:28:14.977013
# Unit test for function main
def test_main():
    assert main() is None
    #assert main(["blahblah"]) is None

# Generated at 2022-06-24 05:28:16.420649
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:28:17.004216
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-24 05:28:17.546672
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:28:18.569392
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:28:19.648936
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-24 05:28:30.275354
# Unit test for function main
def test_main():
    import re
    import io
    import pytest
    import sys
    import os
    import shutil
    from contextlib import redirect_stdout
    from mock import patch

    import thefuck.main
    import thefuck.utils
    import thefuck.argument_parser
    import thefuck.shells

    sys.argv = ['thefuck', '--alias', 'fish']
    args = thefuck.main.main()
    assert args.shell == 'fish'

    sys.argv = ['thefuck', '--version']
    f = io.StringIO()
    with redirect_stdout(f):
        thefuck.main.main()
    version_output = re.findall(r"^thefuck \d+\.\d+\.\d+", f.getvalue(), re.MULTILINE)
    assert version_

# Generated at 2022-06-24 05:28:40.757558
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch
    from unittest import TestCase
    class TFTests(TestCase):
        
        @patch('sys.argv', ["script.py","-v"])
        @patch('builtins.print')
        def test_version_main(self, mock_print):
            main()
            assert mock_print.call_args[0][0] == "The Fuck 3.22 using Python 3.6.5"


        @patch('sys.argv', ["script.py","--alias"])
        @patch('builtins.print')
        def test_alias_main(self, mock_print):
            main()
            assert mock_print.call_args[0][0] == "alias fuck='eval $(thefuck $(fc -ln -1))'"

       

# Generated at 2022-06-24 05:28:42.755999
# Unit test for function main
def test_main():
    assert main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:28:46.729883
# Unit test for function main
def test_main():
    import unittest
    class test_main(unittest.TestCase):
        def test_main(self):
            pass
            #main()
    unittest.main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:28:56.105681
# Unit test for function main
def test_main():
    from unittest import mock

    m = mock.Mock()
    with mock.patch.dict(sys.modules, {'thefuck.argument_parser': m}):
        main()

    m.Parser.assert_called_once_with()
    m.Parser().parse.assert_called_once_with(sys.argv)
    args = m.Parser().parse()
    assert args in m.Parser().parse.return_value

    def parse_side_effect(arg):
        arg.help = True
        return arg

    m.Parser().parse.side_effect = parse_side_effect
    with mock.patch.dict(sys.modules, {'thefuck.argument_parser': m}):
        main()
    m.Parser().print_help.assert_called_once()


# Generated at 2022-06-24 05:28:56.913645
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:28:57.477132
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:29:08.574231
# Unit test for function main
def test_main():
    from .mock_utils import get_mock_args
    from .test_commandline import mock_parser
    from os import environ

    def mock_parse(*args, **kwargs):
        return get_mock_args(args[0])

    mock_parser.parse = mock_parse
    original_sys_argv = sys.argv
    original_os_environ = os.environ
    sys.argv = ['thefuck', '-h']
    try:
        main()
    finally:
        sys.argv = original_sys_argv
    sys.argv = ['thefuck', '--version']
    try:
        main()
    finally:
        sys.argv = original_sys_argv
    sys.argv = ['thefuck', '--alias']

# Generated at 2022-06-24 05:29:13.007700
# Unit test for function main
def test_main():
    import StringIO

    parser = Parser()
    version = ""
    def version(version_, _, __):
        version_ = version_

    logs.version = version
    sys.argv = [__file__, "--help"]
    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    main()
    out = sys.stdout.getvalue().strip()
    sys.stdout.close()
    sys.stdout = stdout
    assert out == parser.format_usage()

    sys.argv = [__file__, "--version"]
    stdout = sys.stdout
    sys.stdout = StringIO.StringIO()
    main()
    out = sys.stdout.getvalue().strip()
    sys.stdout.close()

# Generated at 2022-06-24 05:29:16.468655
# Unit test for function main
def test_main():
  from .test_main import test_main as main
  main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:29:25.867983
# Unit test for function main
def test_main():
    from ..system import init_settings, which
    from .alias import print_alias
    from .fix_command import fix_command
    from ..utils import get_installation_info
    import sys

    # Disable logger to test output
    def log(msg):
        pass
    logs.log = log

    # Monkey patch Parser to return expected arguments
    class ParserClass(object):
        def parse(self, argv):
            return argv
    parser = ParserClass()

    # Set expected arguments
    sys.argv = 'thefuck --help'.split()
    known_args = parser.parse(sys.argv)

    # Monkey patch Print functions to not print, but return expected output
    def print_help():
        return 'Print help'
    parser.print_help = print_help


# Generated at 2022-06-24 05:29:27.537574
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:29:27.930378
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:29:30.489412
# Unit test for function main
def test_main():
    import sys  # noqa: E402
    import os  # noqa: E402
    sys.argv = ['thefuck']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:29:31.322245
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:29:31.864847
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:29:33.599492
# Unit test for function main
def test_main():
    sys.argv = [sys.argv[0], 'test']
    assert main() != None

# Generated at 2022-06-24 05:29:41.617003
# Unit test for function main
def test_main():
    # Test the parser
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument("-v", "--version", help="Show thefuck version",
                    action="store_true")
    Parser.add_alias(parser)
    Parser.add_history(parser)
    Parser.export_history(parser)
    Parser.train(parser)
    Parser.priority(parser)
    Parser.no_colors(parser)
    Parser.settings_path(parser)
    Parser.confirm_apps(parser)
    Parser.wait(parser)
    Parser.repeat(parser)
    Parser.require_long_running_command(parser)
    Parser.show_command(parser)
    Parser.find_command_logs(parser)
    Parser

# Generated at 2022-06-24 05:29:42.840532
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    main()

# Generated at 2022-06-24 05:29:43.520743
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:29:52.985940
# Unit test for function main
def test_main():
    import subprocess
    import unittest

    class TestMain(unittest.TestCase):

        def test_main_exit_status_0(self):
            self.assertEqual(
                subprocess.call(['python', '-m', 'thefuck', '--version']), 0)

        def test_main_exit_status_1(self):
            self.assertEqual(
                subprocess.call(['python', '-m', 'thefuck', '--wrong_flag']), 1)
    unittest.main(argv=[''], verbosity=0, exit=False)


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:29:53.993672
# Unit test for function main
def test_main():
    global main
    main()

# Generated at 2022-06-24 05:29:54.706902
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:29:55.678172
# Unit test for function main
def test_main():
    sys.argv = ["-h"]
    main()

# Generated at 2022-06-24 05:29:56.104206
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:30:02.147522
# Unit test for function main
def test_main():
    from unittest import mock  # noqa: E402
    from ..utils import get_installation_info  # noqa: E402
    from ..logs import version, warning  # noqa: E402
    from ..argument_parser import Parser  # noqa: E402

    with mock.patch('sys.argv', ['thefuck', '-h']):
        main()
        assert Parser().parse.called

    with mock.patch('sys.argv', ['thefuck', '--version']):
        main()
        assert version.called

    with mock.patch('sys.argv', ['thefuck', '--shell-logger']), \
            mock.patch('os.environ', {}):
        with mock.patch('thefuck.main.shell_logger') as shell_logger:
            main()
           

# Generated at 2022-06-24 05:30:03.225748
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:30:03.914638
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:30:10.971529
# Unit test for function main
def test_main():
    #Test possible inputs
    #Test the output help
    command = "thefuck --help"
    assert main() == known_args.help
    #Test the output version
    command = "thefuck --version"
    assert main() == known_args.version
    #Test the output alias
    command = "thefuck --alias"
    assert main() == known_args.alias
    #Test the output command
    command = "thefuck --command"
    assert main() == known_args.command
    #Test the output shell_logger
    command = "thefuck --shell-logger"
    assert main() == known_args.shell_logger

# Generated at 2022-06-24 05:30:18.752497
# Unit test for function main
def test_main():
    assert parser.print_help()
    assert parser.print_usage()
    assert logs.version(get_installation_info().version,sys.version.split()[0], shell.info())
    # It's important to check if an alias is being requested before checking if
    # `TF_HISTORY` is in `os.environ`, otherwise it might mess with subshells.
    # Check https://github.com/nvbn/thefuck/issues/921 for reference
    assert print_alias(known_args)
    assert fix_command(known_args)
    assert logs.warn('Shell logger supports only Linux and macOS')
    assert shell_logger(known_args.shell_logger)

# Generated at 2022-06-24 05:30:24.220960
# Unit test for function main
def test_main():
    import sys
    from . import logs

    sys.argv = ["thefuck", "--version"]
    main()

    sys.argv = ["thefuck", "git commnad", "--alias", "fuck"]
    main()

    sys.argv = ["thefuck", "--help"]
    main()

    sys.argv = ["thefuck", "git commnad"]
    main()

    sys.argv = ["thefuck", "--shell-logger", "zsh"]
    main()

# Generated at 2022-06-24 05:30:31.113394
# Unit test for function main
def test_main():
    parser = Parser()
    parser.parse(['--help'])
    parser.parse(['--version'])
    parser.parse(['--bash-logger'])
    parser.parse(['--zsh-logger'])
    parser.parse(['--shell-logger'])
    parser.parse(['--wait'])
    parser.parse(['--alias'])


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:30:31.894954
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-24 05:30:41.902989
# Unit test for function main
def test_main():
    # GIVEN
    import argparse
    argv = ['thefuck', '--alias', 'fish']
    # WHEN
    with patch.object(sys, 'argv', argv):
        # THEN
        assert print_alias(argparse.Namespace(alias='fish')) == 'function thefuck\n  command fish thefuck $argv\nend'

    argv = ['thefuck', '--help']
    with patch.object(sys, 'argv', argv):
        assert main() == parser.print_help()

    argv = ['thefuck', '--version']
    with patch.object(sys, 'argv', argv):
        assert logs.version() == version(get_installation_info().version,
                     sys.version.split()[0], shell.info())


# Generated at 2022-06-24 05:30:47.837297
# Unit test for function main
def test_main():
    parser = Parser()
    argument_parser = parser.parse(['sudo', 'apt-get', 'update', '-m'])
    assert argument_parser.num == 2
    assert argument_parser.force_command is True
    assert argument_parser.wait is True

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:30:48.456199
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:30:49.896246
# Unit test for function main
def test_main():
    sys.argv = ["thefuck"]
    main()
    assert True

# Generated at 2022-06-24 05:30:52.407293
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = '0'
    parser = Parser()
    main()
    main()
    main()
    main()
    main()

# Generated at 2022-06-24 05:30:54.890671
# Unit test for function main
def test_main():
    try:
        main()
    except ImportError:
        logs.warn('Test main support only Linux and macOS')


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:31:03.058235
# Unit test for function main
def test_main():
    parser = Parser()

    liste = ["thefuck"]
    args = parser.parse(liste)
    assert args.help == False
    assert args.version == False
    assert args.command == False

    liste = ["thefuck", "--help"]
    args = parser.parse(liste)
    assert args.help == True
    assert args.version == False
    assert args.command == False

    liste = ["thefuck", "--version"]
    args = parser.parse(liste)
    assert args.help == False
    assert args.version == True
    assert args.command == False

    liste = ["thefuck","-A","alias"]
    args = parser.parse(liste)
    assert args.help == False
    assert args.version == False
    assert args.command == False
    assert args

# Generated at 2022-06-24 05:31:14.069460
# Unit test for function main
def test_main():
    # test help
    logs.debug = MagicMock()
    sys.argv = ['thefuck', '-h']
    main()
    assert logs.debug.call_args[0][0] == 'Running with args [-h]'
    assert logs.debug.call_count == 1
    # test version
    logs.version = MagicMock()
    sys.argv = ['thefuck', '--version']
    main()
    assert logs.version.call_count == 1
    # test alias
    from ..argument_parser import _get_parser
    logs.debug = MagicMock()
    _print_alias = MagicMock()
    sys.argv = ['thefuck', '--alias']
    with patch('thefuck.main.print_alias', _print_alias, create=True):
        main()

# Generated at 2022-06-24 05:31:23.539730
# Unit test for function main
def test_main():
    class mock_Parser:
        def parse(self, argv):
            return argv
        def print_help(self):
            pass
        def print_usage(self):
            pass
    class known_args:
        def __init__(self, help, version, alias, command, shell_logger):
            self.help = help
            self.version = version
            self.alias = alias
            self.command = command
            self.shell_logger = shell_logger
    try:
        from .fix_command import fix_command as fix_command_mocked
    except ImportError:
        pass
    try:
        from .shell_logger import shell_logger as shell_logger_mocked
    except ImportError:
        pass