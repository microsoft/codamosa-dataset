

# Generated at 2022-06-24 05:21:20.633472
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-24 05:21:24.345859
# Unit test for function main
def test_main():
    from . import main
    import sys
    import os
    history_file = os.path.join(os.path.expanduser('~'), '.bash_history')
    os.environ["TF_HISTORY"] = history_file
    main()

# Generated at 2022-06-24 05:21:27.796336
# Unit test for function main
def test_main():
    # GIVEN
    class ArgGen():
        def __getitem__(self, key):
            return None
    arg_list = [ArgGen()]
    # THEN
    assert main() == None

# Generated at 2022-06-24 05:21:36.259475
# Unit test for function main
def test_main():
    import os
    import sys

    sys.argv = ['thefuck']

    main()

# Generated at 2022-06-24 05:21:37.218409
# Unit test for function main
def test_main():
    # Postcondition: The function throws no error
    main()

# Generated at 2022-06-24 05:21:48.264899
# Unit test for function main
def test_main():
    import os
    import sys
    def get_stderr():
        sys.stderr.flush()
        return sys.__stderr__.getvalue()
    sys.argv = sys.argv[:1]
    os.environ['TF_HISTORY'] = "1"
    main()
    assert 'Usage' in get_stderr()
    sys.argv = sys.argv[:1] + ['help']
    main()
    assert 'Usage' in get_stderr()
    sys.argv = sys.argv[:1] + ['--help']
    main()
    assert 'Usage' in get_stderr()
    sys.argv = sys.argv[:1] + ['alias']
    main()
    assert 'Usage' in get_stderr()
   

# Generated at 2022-06-24 05:21:49.255721
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-24 05:21:52.537287
# Unit test for function main
def test_main():
    import unittest
    class TestMain(unittest.TestCase):
        def test_main(self):
            self.assertEqual(main(), None)
    unittest.main()

# Generated at 2022-06-24 05:21:53.130704
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:22:01.092775
# Unit test for function main
def test_main():
    initial_env = os.environ.get('TF_HISTORY')
    initial_argv = sys.argv
    initial_stdout = sys.stdout

    # Test alias
    sys.argv = ['thefuck','--alias']
    sys.argv += ['--version']
    sys.stdout = open('testlog.txt', 'w')
    main()
    sys.stdout.close()
    tmp = open('testlog.txt', 'r')
    assert tmp.readline().strip() == 'alias tf=\'python3 -c "from thefuck.main import main; main()"\''
    tmp.close()
    os.remove('testlog.txt')
    os.remove('testlog.txt.bak')

    # Test with TF_HISTORY

# Generated at 2022-06-24 05:22:01.705336
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:22:02.454485
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:22:03.072185
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:22:10.568519
# Unit test for function main
def test_main():
    # Mock out sys.argv to simulate user input:
    # thefuck --alias
    sys.argv = ['thefuck', '--alias']
    try:
        from unittest.mock import patch  # noqa: F401
    except ImportError:
        from mock import patch  # noqa: F401

    with patch('thefuck.main.print_alias') as print_alias_mock:
        main()
    # print_alias was called with exactly one argument,
    # the result of the command-line parsing
    assert print_alias_mock.call_count == 1

# Generated at 2022-06-24 05:22:12.578756
# Unit test for function main
def test_main():
    from ..main import main
    from ..system import init_output
    init_output()
    main()

# Generated at 2022-06-24 05:22:19.245475
# Unit test for function main
def test_main():  # noqa: D103
    parser = Parser()
    sys.argv = ['thefuck', '--help']
    main()
    assert parser.help == True
    sys.argv = ['thefuck', '--version']
    main()
    assert parser.version == True
    sys.argv = ['thefuck', '--alias']
    main()
    assert parser.alias == True
    sys.argv = ['thefuck', '--command']
    main()
    assert parser.command == True
    sys.argv = ['thefuck', '--shell-logger']
    main()
    assert parser.shell_logger == True

# Generated at 2022-06-24 05:22:19.797482
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:22:30.604978
# Unit test for function main
def test_main():
    # Function main() should call print_help() when it's being called with --help
    # It should call logs.version() when it's being called with --version
    # It should call print_alias() when it's being called with --alias
    # It should call fix_command() when it's being called with --command or
    # TF_HISTORY is in os.environ
    # It should call logs.warn() when it's being called with --shell-logger
    # when it's not supported by the platform
    # Otherwise it should call parser.print_usage()
    # Mock args to represent input arguments
    # Mock function print_help()
    def print_help():
        return True
    # Mock function print_usage()
    def print_usage():
        return True
    # Mock function version()
    def version():
        return True
   

# Generated at 2022-06-24 05:22:35.691460
# Unit test for function main
def test_main():
    class KnownArgs:
        pass
    known_args = KnownArgs()
    known_args.command = 'echo 123'
    known_args.alias = None
    known_args.help = None
    known_args.version = None
    known_args.alias = None
    known_args.shell_logger = None
    main()

# Generated at 2022-06-24 05:22:37.128122
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = '0'
    main()
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:22:37.625145
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:22:44.468862
# Unit test for function main
def test_main():
    # Test for print_help
    old_stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    main()
    main([])
    main(['-h'])
    main(['--help'])

    # Test for alias
    main(['--alias'])
    main(['--alias', 'rm'])
    main(['--alias', 'rm', '--exclude', 'rm'])
    main(['--alias', 'rm', '--exclude', 'rm', '--reverse'])
    main(['--alias', 'rm', '--exclude', 'rm', '--reverse', '--force-alias'])
    main(['--alias', 'rm', '--exclude', 'rm', '--reverse', '--force-alias', '--shell=bash'])

# Generated at 2022-06-24 05:22:48.239167
# Unit test for function main
def test_main():
    import unittest

    class MainTest(unittest.TestCase):
        def test_it_runs_without_errors(self):
            try:
                main()
            except SystemExit:
                # Exit is expected in case of --help or --version
                pass

# Generated at 2022-06-24 05:22:58.614282
# Unit test for function main
def test_main():
    from .shell_logger import shell_logger  # noqa: E402
    from ..shells import bash, zsh, fish  # noqa: E402

# Generated at 2022-06-24 05:23:00.212383
# Unit test for function main
def test_main():
    assert main() == None

# Unit test to check return value of main function

# Generated at 2022-06-24 05:23:06.754834
# Unit test for function main
def test_main():
    with patch('thefuck.main.Parser') as parser_mock:
        argparse.ArgumentParser.parse_args = MagicMock(return_value=argparse.Namespace())
        with patch('thefuck.main.fix_command') as fix_mock:
            with patch('thefuck.main.print_alias') as alias_mock:
                main()
                assert fix_mock.called
                assert not alias_mock.called

# Generated at 2022-06-24 05:23:12.387540
# Unit test for function main
def test_main():
    parser = Parser()
    assert parser.parse(["thefuck", "--help"]).help == True
    assert parser.parse(["thefuck", "--version"]).version == True
    assert parser.parse(["thefuck", "--shell-logger"]).shell_logger == True
    assert parser.parse(["thefuck", "--alias"]).alias == True
    assert parser.parse(["thefuck", "--debug"]).debug == True
    assert parser.parse(["thefuck", "--exclude-rules"]).exclude_rules == True
    assert parser.parse(["thefuck"]).help == True

# Generated at 2022-06-24 05:23:13.002901
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:23:14.272778
# Unit test for function main
def test_main():
    main()
    logs.main()

# Generated at 2022-06-24 05:23:14.876740
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:23:15.493966
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:23:17.385880
# Unit test for function main
def test_main():
    print("test main result")

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:23:18.713886
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-24 05:23:19.052231
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:23:19.704745
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:23:20.877349
# Unit test for function main
def test_main():
    import os
    from ..system import xdg_data_home

    os.environ["TF_HISTORY"] = 'True'
    assert os.path.isdir(xdg_data_home + "/thefuck")

# Generated at 2022-06-24 05:23:21.523829
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()

# Generated at 2022-06-24 05:23:22.293594
# Unit test for function main
def test_main():
   main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:23:23.629332
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:23:24.198586
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:23:27.032144
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck']
    from . import main
    try:
        sys.stdout.getvalue()
    except:
        from io import StringIO
        sys.stdout = StringIO()


# Generated at 2022-06-24 05:23:27.652000
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:23:33.698524
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .. import argument_parser
    from .. import shells


# Generated at 2022-06-24 05:23:34.336299
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:23:37.256068
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = ' '
    os.environ['TF_SHELL'] = 'zsh'
    sys.argv = ['thefuck', '--alias']
    main()

# Generated at 2022-06-24 05:23:38.495199
# Unit test for function main
def test_main():
    #def __main__():
    main()


# Generated at 2022-06-24 05:23:48.979364
# Unit test for function main
def test_main():
    from unittest import mock  # noqa: E402
    from .test_alias import test_print_alias, test_print_alias_with_no_args
    from .test_parser import test_parser_with_command, test_parser_with_alias, \
        test_parser_with_alias_no_args, test_parser_with_shell_logger

    def _test(parser_mock, module, args):
        parser_mock.return_value = module.known_args

        main()

        parser_mock.assert_called_with(sys.argv)

        module.mock_main.assert_called()


# Generated at 2022-06-24 05:23:49.551185
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:23:50.510380
# Unit test for function main
def test_main():
    result = main()
    assert result == None

# Generated at 2022-06-24 05:23:51.081899
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:23:51.646167
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:23:52.249237
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:23:53.274743
# Unit test for function main
def test_main():
    main()
    return(known_args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:23:56.137628
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--version']
    assert main() == None
    sys.argv = ['thefuck', 'rm', '--help']
    assert main() == None
    sys.argv = ['thefuck', '--alias', 'fuck']
    assert main() == None
    sys.argv = ['thefuck', '--shell-logger']
    assert main() == None

# Generated at 2022-06-24 05:23:57.050672
# Unit test for function main
def test_main():
    assert main() is not 0

# Generated at 2022-06-24 05:24:03.681180
# Unit test for function main
def test_main():
    cmd = 'fuck'
    from unittest.mock import patch
    import io
    import sys

    # Patching stdout to check logs
    stdout = io.StringIO()
    with patch('sys.stdout', stdout):
        main()
    assert stdout.getvalue().strip().split('\n')[-1] == cmd + ': Command not found'


# Generated at 2022-06-24 05:24:10.365430
# Unit test for function main
def test_main():
    assert main(sys.argv[1])==parser.print_usage()
    assert main(sys.argv[2])==parser.print_usage()
    assert main(sys.argv[3])==parser.print_usage()
    assert main(sys.argv[4])==parser.print_usage()
    assert main(sys.argv[5])==parser.print_usage()
    assert main(sys.argv[6])==parser.print_usage()

# Generated at 2022-06-24 05:24:10.754647
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:24:11.347272
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:24:12.133398
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:24:13.174882
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:24:13.971084
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:24:16.826183
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = '1'
    arguments = sys.argv
    sys.argv = ['thefuck']
    main()
    sys.argv = arguments

# Generated at 2022-06-24 05:24:18.574881
# Unit test for function main
def test_main():
    #Testing the main function
    main()



# Generated at 2022-06-24 05:24:23.227027
# Unit test for function main
def test_main():
    old_sys_argv = sys.argv
    sys.argv = ['--help']
    assert main() == None
    sys.argv = ['--version']
    assert main() == None
    sys.argv = ['--alias']
    assert main() == None
    sys.argv = ['--command', 'ls']
    assert main() == None
    sys.argv = ['--shell-logger', 'zsh']
    assert main() == None
    sys.argv = old_sys_argv

# Generated at 2022-06-24 05:24:23.868678
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:24:25.384538
# Unit test for function main
def test_main():
    from .test_parser import test_parser
    test_parser(main)

# Generated at 2022-06-24 05:24:35.718209
# Unit test for function main
def test_main():
    test_args = Parser()
    # test help command
    test_known_args = test_args.parse(['-h'])
    assert test_known_args.help == True
    # test version command
    test_known_args = test_args.parse(['--version'])
    assert test_known_args.version == True
    # test alias command
    test_known_args = test_args.parse(['--alias'])
    assert test_known_args.alias == True
    # test shell_logger
    test_known_args = test_args.parse(['--shell-logger'])
    assert test_known_args.shell_logger == True
    # test command
    test_known_args = test_args.parse(['--command'])

# Generated at 2022-06-24 05:24:36.931706
# Unit test for function main
def test_main():
    assert main() is None


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:24:38.415280
# Unit test for function main
def test_main():
    assert main()


if __name__ == '__main__':
    # Unit test for function main
    test_main()
    main()

# Generated at 2022-06-24 05:24:38.955005
# Unit test for function main
def test_main():
  assert main() == None

# Generated at 2022-06-24 05:24:42.234984
# Unit test for function main
def test_main():
    sys.argv = [
        "thefuck", "--alias"
    ]
    main()
    sys.argv = [
        "thefuck", "--command"
    ]
    main()
    sys.argv = [
        "thefuck"
    ]
    main()

# Generated at 2022-06-24 05:24:44.197794
# Unit test for function main
def test_main():
    print('Unit test for function main')

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:24:52.734373
# Unit test for function main
def test_main():
    import sys
    import filecmp
    sys.argv.append('--version')
    sys.stdout = open("test_version", "w")
    main()
    sys.stdout.close()
    assert filecmp.cmp("test_version", "test_version_expected")
    sys.argv.pop()
    sys.argv.append('--shell_logger')
    sys.stdout = open("test_logger", "w")
    main()
    sys.stdout.close()
    assert filecmp.cmp("test_logger", "test_logger_expected")
    os.remove("test_version")
    os.remove("test_logger")

# Generated at 2022-06-24 05:24:53.310969
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:25:02.772914
# Unit test for function main
def test_main():
    from unittest.mock import (
        patch,
        call
    )
    from unittest import mock
    from ..utils import get_installation_info
    from ..system import init_output
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    init_output()


# Generated at 2022-06-24 05:25:12.129963
# Unit test for function main
def test_main():
    assert known_args.help == False
    assert known_args.version == False
    assert known_args.alias == False
    assert known_args.command == False
    assert 'TF_HISTORY' in os.environ == False
    assert known_args.shell_logger == False

    sys.argv = ['command', '--alias']
    assert known_args.help == False
    assert known_args.version == False
    assert known_args.alias == True
    assert known_args.command == False
    assert 'TF_HISTORY' in os.environ == False
    assert known_args.shell_logger == False

    sys.argv = ['command', '--version']
    assert known_args.help == False
    assert known_args.version == True
    assert known_args.alias == False
    assert known

# Generated at 2022-06-24 05:25:18.208437
# Unit test for function main
def test_main():
    from unittest.mock import patch  # noqa: E402
    from multiprocessing import Process  # noqa: E402
    import sys  # noqa: E402

    def other_process():
        main()
        sys.exit(0)

    with patch.object(sys, 'argv', [__file__, '--version']):
        with patch('sys.exit') as exit:
            with patch('os._exit') as _exit:
                other_process()
                assert exit.call_args == _exit.call_args

# Generated at 2022-06-24 05:25:28.218724
# Unit test for function main
def test_main():
    from unittest import mock
    from .. import settings
    from .alias import print_alias
    from .fix_command import fix_command
    from ..shells import shell

    settings.enabled = True
    settings.wait_command = 0
    settings.confirm_exit = False
    settings.require_confirmation = False
    settings.wait_slow_command = 5
    settings.history_limit = None
    settings.slow_commands = ()
    settings.exclude_rules = ()
    settings.priority = {}
    settings.no_colors = True
    settings.alter_history = False
    os.environ.pop('TF_HISTORY', None)


# Generated at 2022-06-24 05:25:33.017828
# Unit test for function main
def test_main():
    from unittest.mock import MagicMock, patch

    os.environ = {}
    sys.argv = MagicMock(return_value = ["python3", "/Users/apple/Desktop/TheFuck/tests/test_main.py"])

    with patch("builtins.print") as mock_print:
        main()
        mock_print.assert_called_once_with(sys.exit())

# Generated at 2022-06-24 05:25:43.869645
# Unit test for function main
def test_main():
    from .mocks import parser, known_args
    from ..system import init_output
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from .mocks import parser, known_args
    from .mocks import parser, known_args
    from .mocks import parser, known_args
    from .mocks import parser, known_args

    print_alias.cache_clear()
    fix_command.cache_clear()
    init_output.cache_clear()
    get_installation_info.cache_clear()
    shell.info.cache_clear()
    print_alias.cache_clear()
    print_alias.cache_clear()
    print_alias

# Generated at 2022-06-24 05:25:47.506128
# Unit test for function main
def test_main():
    cmd = "python thefuck/main.py"
    # set the value of stdin
    sys.argv = ["python thefuck/main.py", "-h"]
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:25:48.014374
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:25:56.020778
# Unit test for function main
def test_main():
    argv = []
    parser = Parser()
    known_args = parser.parse(argv)
    if known_args.help:
        parser.print_help()
    elif known_args.version:
        logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info())
    # It's important to check if an alias is being requested before checking if
    # `TF_HISTORY` is in `os.environ`, otherwise it might mess with subshells.
    # Check https://github.com/nvbn/thefuck/issues/921 for reference
    elif known_args.alias:
        print_alias(known_args)
    elif known_args.command or 'TF_HISTORY' in os.environ:
        fix_command(known_args)

# Generated at 2022-06-24 05:25:56.531508
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:25:57.153973
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:25:57.981020
# Unit test for function main
def test_main():
    from .__main__ import main   

    main()

# Generated at 2022-06-24 05:26:08.490008
# Unit test for function main
def test_main():
    import sys

    def fake_parse(args):
        class FakeArgs:
            def __init__(self):
                self.help = False
                self.version = False
                self.alias = False
                self.command = False
                self.shell_logger = False

        return FakeArgs()

    def fake_print(s):
        pass

    def fake_warn(s):
        pass

    def fake_get_installation_info():
        class FakeInfo:
            def __init__(self):
                self.version = "1.0.0"
        return FakeInfo()

    def fake_shell_info():
        return "shell info"

    setattr(sys, "argv", ["thefuck", "--help"])

    class FakeParser:
        def __init__(self):
            self.parse = fake

# Generated at 2022-06-24 05:26:09.067683
# Unit test for function main
def test_main():
    assert m

# Generated at 2022-06-24 05:26:17.535432
# Unit test for function main
def test_main():
    from .fix_command import main as fix_command_main # noqa: E402
    from .alias import main as alias_main # noqa: E402
    from .shell_logger import main as shell_logger_main # noqa: E402
    from unittest.mock import patch
    import tempfile # noqa: E402

    class FakeArgs:
        pass

    args_all_true = FakeArgs()
    args_all_true.command = True
    args_all_true.shell_logger = "shell_logger_all_true"
    args_all_true.help = True
    args_all_true.version = True
    args_all_true.alias = True

    args_command = FakeArgs()
    args_command.command = True

    args_shell_logger = FakeArgs()

# Generated at 2022-06-24 05:26:18.029678
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-24 05:26:20.589724
# Unit test for function main
def test_main():
    import unittest  # noqa: E402

    class MainTest(unittest.TestCase):
        def test_print_usage(self):
            with self.assertRaises(SystemExit) as ex:
                main()
                self.assertEquals(ex.code, 0)

    unittest.main()

# Generated at 2022-06-24 05:26:31.714512
# Unit test for function main
def test_main():
    import os, re
    import thefuck.main

    class Args:
        def __init__(self, help, version, alias, command, shell_logger):
            self.help = help
            self.version = version
            self.alias = alias
            self.command = command
            self.shell_logger = shell_logger
            self.debug = False
            self.no_colors = False

    assert re.match(
        r'The Fuck \d+\.\d+\.\d+ using Python \d+\.\d+\.\d+ on .*',
        thefuck.main.main(Args(False, True, False, None, None)))

    thefuck.main.main(Args(True, False, False, None, None))
    assert "usage:" in sys.stdout.getvalue()


# Generated at 2022-06-24 05:26:39.913747
# Unit test for function main
def test_main():
    test_help = False
    test_version = False
    test_alias = False
    test_command = False
    test_shell_logger = False

    sys.argv = ['test', '-h']
    main()
    assert test_help

    sys.argv = ['test', '--version']
    main()
    assert test_version

    sys.argv = ['test', '--alias']
    main()
    assert test_alias

    sys.argv = ['test', '--command', 'cd a', '--enable-shell-logger']
    main()
    assert test_command

    sys.argv = ['test', '--enable-shell-logger']
    main()
    assert test_shell_logger


########### End of function test_main ###########

# Generated at 2022-06-24 05:26:40.560457
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:26:41.178427
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:26:43.051447
# Unit test for function main
def test_main():
    assert (main() == None)
    return True

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:43.660664
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:26:44.254071
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:26:44.890965
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:26:46.318939
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:53.760113
# Unit test for function main
def test_main():
    import io
    from contextlib import redirect_stdout

    if sys.version_info[0] > 2:
        from unittest.mock import patch
    else:
        from mock import patch
    from ..argument_parser import argument_parser

    with patch('sys.argv', ['thefuck', '--help']):
        with redirect_stdout(io.StringIO()) as stream:
            main()
        assert stream.getvalue().splitlines() == argument_parser().format_help().splitlines()[
                                                1:-1]

    with patch('sys.argv', ['thefuck', '--version']):
        with redirect_stdout(io.StringIO()) as stream:
            main()

# Generated at 2022-06-24 05:26:54.104056
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:26:57.681030
# Unit test for function main
def test_main():
    from .alias import print_alias
    from .fix_command import fix_command
    parser = Parser()
    known_args = parser.parse(['--help'])
    main()
    known_args = parser.parse(['--version'])
    main()
    known_args = parser.parse(['--alias'])
    main()
    known_args = parser.parse(['--shell', 'tcsh'])
    main()
    known_args = parser.parse(['--shell-logger', 'tcsh'])
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:58.436160
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:26:59.098289
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-24 05:27:09.566457
# Unit test for function main
def test_main():
    from .test_utils import patch, patch_input, CLEAR_CACHE

    known_args = Parser().parse(['sudo', 'echo', 'test'])
    known_args.wait_command = 0.1

    with patch('sys.argv', ['sudo', 'echo', 'test']):
        with patch('subprocess.Popen'):
            assert not main()
            assert main() != 0

    with patch('sys.argv', ['sudo', '-h']):
        with patch('subprocess.Popen'):
            assert main() == 0

    with patch('sys.argv', ['sudo', '--version']):
        with patch('subprocess.Popen'):
            assert main() == 0


# Generated at 2022-06-24 05:27:10.572177
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-24 05:27:11.419109
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-24 05:27:11.981116
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:27:12.585371
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:27:21.822131
# Unit test for function main
def test_main():
    from .test_arguments import test_input_set
    from .test_parser import test_parser_set
    from .test_output import test_output_set
    from .test_logs import test_logs_set
    from .test_version import test_version_set
    from .test_utils import test_utils_set
    from .test_alias import test_alias_set
    from .test_history import test_history_set
    from .test_shell import test_shell_set
    from .test_shell_logger import test_shell_logger_set

    test_input_set()
    test_parser_set()
    test_logs_set()
    test_version_set()
    test_utils_set()
    test_alias_set()
    test_history_set()
    test_

# Generated at 2022-06-24 05:27:32.457179
# Unit test for function main
def test_main():
    import subprocess
    import sys

    test_env = os.environ.copy()
    test_env['TF_ALIAS'] = 'alias fuck="eval $(thefuck $(fc -ln -1));"'

    def run(args):
        return subprocess.check_output(
            [sys.executable, '-m', 'thefuck', '--'] + args,
            stderr=subprocess.STDOUT, env=test_env,
        ).decode('utf-8').strip()

    assert run(['--alias', 'zsh']) == 'eval $(thefuck $(fc -ln -1 | tail -n 1));'
    assert run(['--alias', 'fish']) == 'function fuck; eval (thefuck (commandline -opc)); end;'

# Generated at 2022-06-24 05:27:37.355615
# Unit test for function main
def test_main():
    exec_command = ''

    try:
        main()
    except SystemExit as exit_exception:
        exec_command = exit_exception.args[0]

    assert(exec_command == '')


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:27:38.863979
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-24 05:27:39.471711
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:27:40.107822
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:27:49.489666
# Unit test for function main
def test_main():  # noqa: F811
    fh = open("test_main.txt", "w")
    logs.stderr = fh
    main()
    fh.close()
    fh = open("test_main.txt", "r")
    for line in fh:
        if line == "Usage: thefuck [OPTIONS] [COMMAND]...\n" or \
           line == "  --help                 Show this message and exit.\n":
            assert True
        else:
            assert False
    fh.close()
    fh = open("test_main.txt", "w")
    main()
    fh.close()
    fh = open("test_main.txt", "r")

# Generated at 2022-06-24 05:27:50.070851
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:27:50.650666
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-24 05:27:51.892737
# Unit test for function main
def test_main():
    main()
    assert 1 == 1

# Generated at 2022-06-24 05:27:52.373480
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:27:56.237532
# Unit test for function main
def test_main():
    # python3 -m thefuck.main
    sys.argv = ['thefuck']
    main()

    # python3 -m thefuck.main --alias
    sys.argv = ['thefuck', '--alias']
    main()

# Generated at 2022-06-24 05:28:02.083269
# Unit test for function main
def test_main():
    from thefuck import main
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from .argument_parser import Parser
    from .utils import get_installation_info
    from .system import init_output
    from .shells import shell
    from .logs import version
    
    main()

# Generated at 2022-06-24 05:28:13.378080
# Unit test for function main
def test_main():
    import subprocess
    import os
    import sys

    def check_python_version(x):
        # this is equivalent to python3.6 and above
        if sys.version_info[0] == 3 and sys.version_info[1] > 5:
            assert x == 'Python 3'
        # 2.7 and 2.6 should both be 'Python 2'
        elif sys.version_info[0] == 2:
            assert x == 'Python 2'

    def check_tf_alias(x):
        assert x.startswith('alias fuck=')

    def check_tf_version(x):
        assert x.startswith('The Fuck')

    def check_tf_help(x):
        assert x.startswith('usage: thefuck')


# Generated at 2022-06-24 05:28:13.942633
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-24 05:28:15.344142
# Unit test for function main
def test_main():
    assert main() == None


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:28:25.998402
# Unit test for function main
def test_main():
    from unittest.mock import patch

    from ..utils import get_installation_info

    from .logs import version
    from .argument_parser import Parser

    install_info = get_installation_info()

    main_patch = patch('thefuck.main.fix_command')
    version_patch = patch('thefuck.main.logs.version')
    get_installation_info_patch = patch.object(get_installation_info, '__call__', return_value=install_info)

# Generated at 2022-06-24 05:28:26.634465
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:28:33.771368
# Unit test for function main
def test_main():
    # 1. testing --help option
    # assert the exit code is zero
    assert main() == 0

    # 2. testing --version option
    # assert the exit code is zero
    assert main() == 0
    
    # 3. testing --alias option
    # assert the exit code is zero
    assert main() == 0

    # 4. testing --command option
    # assert the exit code is zero
    assert main() == 0
    
    # 5. testing --shell-logger option
    # assert the exit code is zero
    assert main() == 0

    # 6. testing --no-logging option
    # assert the exit code is zero
    assert main() == 0

# Generated at 2022-06-24 05:28:34.775109
# Unit test for function main
def test_main():
    main()
    return 0

# Generated at 2022-06-24 05:28:35.337197
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:28:35.936373
# Unit test for function main
def test_main():
	assert main() == None

# Generated at 2022-06-24 05:28:36.613316
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:28:40.982782
# Unit test for function main
def test_main():
    from click.testing import CliRunner
    from . import cli, argument_parser

    runner = CliRunner()
    result = runner.invoke(cli.main, ['--version'])
    assert get_installation_info().version in result.output



# Generated at 2022-06-24 05:28:45.906506
# Unit test for function main
def test_main():
    import unittest
    class Test(unittest.TestCase):
        def test_help(self):
            with self.assertRaises(SystemExit):
                main(['--help'])

        def test_version(self):
            with self.assertRaises(SystemExit):
                main(['--version'])

        def test_shell_logger(self):
            main(['--shell-logger'])

        def test_unknown(self):
            with self.assertRaises(SystemExit):
                main([])

    unittest.main()

# Generated at 2022-06-24 05:28:48.551531
# Unit test for function main
def test_main():
    try:
        main()
    except AttributeError:
        pass
    sys.argv.append('--version')
    main()
    sys.argv.append('--help')
    main()
    sys.argv.append('fuck')
    main()

# Generated at 2022-06-24 05:28:57.485213
# Unit test for function main
def test_main():
    from unittest import mock
    from thefuck import parser

    with mock.patch('thefuck.parser.parse', return_value=mock.Mock(help=False,
                                                                    version=False,
                                                                    command="ls -l",
                                                                    alias=None,
                                                                    shell_logger=None)):
        with mock.patch('thefuck.fix_command') as mock_fix_command:
            main()
            assert mock_fix_command.called


# Generated at 2022-06-24 05:28:58.990241
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:28:59.595064
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:29:00.573593
# Unit test for function main
def test_main():
    args = ['fuck']
    main(args)

# Generated at 2022-06-24 05:29:01.319042
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:29:01.952590
# Unit test for function main
def test_main():
    assert main==main

# Generated at 2022-06-24 05:29:03.690458
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:29:08.677835
# Unit test for function main
def test_main():
    # True cases
    assert main() != 1
    assert main() != log_to_file()
    assert main() != get_installation_info()
    assert main() != init_output()
    assert main() != fix_command()
    assert main() != print_alias()
    assert main() != get_watch_file_path()

# Generated at 2022-06-24 05:29:09.650215
# Unit test for function main
def test_main():
    # assert main() == None
    assert main() == None

# Generated at 2022-06-24 05:29:11.822838
# Unit test for function main
def test_main():
    old_argv = sys.argv
    sys.argv = "thefuck --help".split()
    main()
    sys.argv = old_argv


# Generated at 2022-06-24 05:29:23.296137
# Unit test for function main
def test_main():
    import sys
    import io
    sys.stdout = io.StringIO()
    sys.argv = ['thefuck', '-h']
    main()
    assert sys.stdout.getvalue() == 'usage: thefuck [-h] [--version] [--alias] [--shell-logger] [--] [commands [commands ...]]\n\nCorrect your previous console command.\n\npositional arguments:\n  commands          Commands to correct\n\noptional arguments:\n  -h, --help        show this help message and exit\n  --version         show version and exit\n  --alias, -a       Show shell alias for The Fuck\n  --shell-logger, -l\n                    Show shell logger command to test The Fuck\n\nFor more information see https://github.com/nvbn/thefuck\n'

# Generated at 2022-06-24 05:29:33.515555
# Unit test for function main
def test_main():
    import textwrap
    import mock

    with mock.patch('sys.argv', ['thefuck', '--help']):
        main()

# Generated at 2022-06-24 05:29:34.063683
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:29:34.937386
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-24 05:29:44.413801
# Unit test for function main
def test_main():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    _print_alias = print_alias
    _print_usage = parser.print_usage
    _print_help = parser.print_help
    _fix_command = fix_command
    _shell_logger = shell_logger

# Generated at 2022-06-24 05:29:45.020139
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-24 05:29:55.996859
# Unit test for function main
def test_main():
    ## Test help output
    class Parser:
        def __init__(self, parser):
            pass
        def parse(self, argv):
            pass
        def print_help(self):
            return 'help'
        def print_usage(self):
            return 'usage'
    class KnownArgs:
        def __init__(self, args):
            self.help = True
        def __init__(self, args):
            self.version = True
        def __init__(self, args):
            self.shell_logger = True
        def __init__(self, args):
            self.alias = True


# Generated at 2022-06-24 05:30:02.236616
# Unit test for function main
def test_main():
    global sys
    global os
    sys.argv[1:] = [
        "--alias", "fuck = thefuck"]
    assert main() == None
    assert sys.argv[1:] == [
        "--alias", "fuck = thefuck"]
    sys.argv[1:] = [
        "--alias", "fuck = thefuck", "--help"]
    assert main() == None
    assert sys.argv[1:] == [
        "--alias", "fuck = thefuck", "--help"]
    sys.argv[1:] = [
        "--alias", "fuck = thefuck", "--version"]
    assert main() == None
    assert sys.argv[1:] == [
        "--alias", "fuck = thefuck", "--version"]

# Generated at 2022-06-24 05:30:09.394196
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--alias', 'fuck']
    main()
    sys.argv = ['thefuck', '--shell_logger', 'bash']
    main()
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    os.environ['TF_HISTORY'] = 'test_env'
    main()

# Generated at 2022-06-24 05:30:12.963893
# Unit test for function main
def test_main():
    #TEST 1 
    main()
    #TEST 2
    pass
    #TEST 3
    pass
    #TEST 4
    pass
    #TEST 5
    pass
if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:30:13.392948
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-24 05:30:13.770934
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-24 05:30:16.903709
# Unit test for function main
def test_main():
    with patch('sys.argv', ['thefuck', '--help']):
        main()
    assert sys.argv == ['thefuck', '--help']

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:30:17.521798
# Unit test for function main
def test_main():
    assert main == main

# Generated at 2022-06-24 05:30:25.416979
# Unit test for function main
def test_main():
    Parser.main = main
    from unittest import mock
    from ..argument_parser import Parser
    from .alias import AliasLogger

    version_mock = mock.Mock()
    version_mock.return_value = 'version'

    shell_mock = mock.Mock()
    shell_mock.info.return_value = 'shell info'

    log_mock = mock.Mock()
    log_mock.version = version_mock
    log_mock.warn = mock.Mock()

    info_mock = mock.Mock()
    info_mock.version = 'thefuck version'

    alias_logger_mock = mock.Mock()
    alias_logger_mock.print_alias = mock.Mock()

# Generated at 2022-06-24 05:30:36.694853
# Unit test for function main
def test_main():
    if not os.path.isdir(os.path.expanduser("~")+"/.thefuck"):
        os.mkdir(os.path.expanduser("~")+"/.thefuck")
    if not os.path.isfile(os.path.expanduser("~")+"/.thefuck/fuck.txt"):
        f = open(os.path.expanduser("~")+"/.thefuck/fuck.txt","w+")
        f.write("echo hello")
        f.close()
# Now import the config files
    import os
    os.environ['TF_SHELL_CONFIG'] = os.path.expanduser("~")+"/.thefuck/fuck.txt"
    sys.argv[1] = "echo"
    sys.argv[2] = "hello"

# Generated at 2022-06-24 05:30:38.791782
# Unit test for function main
def test_main():
    assert isinstance(main(),type(None))
    # TODO:
    # assert main() == ???
    # assert main(sys.argv) == ???

# Generated at 2022-06-24 05:30:45.860383
# Unit test for function main
def test_main():
    import sys
    import io
    import os

    class fake_file:
        def __init__(self, contents):
            self.contents = contents

        def read(self):
            return self.contents

    old_stdout = sys.stdout
    old_stderr = sys.stderr
    old_stdin = sys.stdin
    old_argv = sys.argv
    old_os_env = os.environ.get('TF_HISTORY')
    old_os_alias = os.environ.get('TF_ALIAS')

    stdout = fake_file('')
    stderr = fake_file('')
    stdin = fake_file('')

    def cleanup():
        sys.stdout = old_stdout
        sys.stderr = old_stder

# Generated at 2022-06-24 05:30:46.503183
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-24 05:30:49.150970
# Unit test for function main
def test_main():
    # Case one:
    test_case_01_args = ['fuck', 'python', '--version']
    logs.is_debug = False
    main()
    # Case two:
    test_case_02_args = ['fuck', 'sudo']
    logs.is_debug = True
    main()

# Generated at 2022-06-24 05:30:56.773779
# Unit test for function main
def test_main():
    # simulate user input as if executing from command line
    sys.argv = ['thefuck', 'cd /tmp&&git add .', '&&', 'git commit -m "test_commit"']

    # make sure no output is printed to stdout
    saved_stdout = sys.stdout
    out = sys.stdout = StringIO()

    # call main
    main()

    # restore stdout
    output = out.getvalue().strip()
    sys.stdout = saved_stdout

    # there should be no output to stdout
    assert output == ''
    assert 'thefuck' in sys.modules

# Generated at 2022-06-24 05:30:57.916677
# Unit test for function main
def test_main():
    known_args = Parser().parse(['ls'])
    known_args.help = True
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-24 05:31:02.262647
# Unit test for function main
def test_main():
    os.environ["TF_HISTORY"] = 'test'
    test_command = ['fuck', 'cd', 'ls']
    main(test_command)
    os.environ.pop("TF_HISTORY")
    test_command_alias = 'test_alias'
    main(['--alias', test_command_alias])
    main(['--version'])
    main(['--shell-logger', 'yes'])

# Generated at 2022-06-24 05:31:13.482047
# Unit test for function main
def test_main():
    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.main.print_alias') as mock_print_alias:
            main()
            assert not mock_print_alias.called

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.main.version') as mock_version:
            main()
            assert mock_version.called

    with patch('sys.argv', ['thefuck', '--alias', 'fuck']):
        with patch('thefuck.main.print_alias') as mock_print_alias:
            main()
            assert mock_print_alias.called


# Generated at 2022-06-24 05:31:21.092648
# Unit test for function main
def test_main():
    sys.argv = ['./thefuck']

    logs.version = Mock(side_effect=Exception('exit'))
    fixes.print_alias = Mock(side_effect=Exception('exit'))
    fixes.fix_command = Mock(side_effect=Exception('exit'))
    parser.print_usage = Mock(side_effect=Exception('exit'))

    try:
        main()
    except Exception:
        pass

    logs.version.assert_called_with(get_installation_info().version,
                       sys.version.split()[0], shell.info())

    sys.argv = ['./thefuck', '-v']

    try:
        main()
    except Exception:
        pass
