

# Generated at 2022-06-22 00:27:24.023634
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:27:24.671776
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-22 00:27:25.368912
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:27:36.541504
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)

    if known_args.help:
        parser.print_help()
    elif known_args.version:
        logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info())
    # It's important to check if an alias is being requested before checking if
    # `TF_HISTORY` is in `os.environ`, otherwise it might mess with subshells.
    # Check https://github.com/nvbn/thefuck/issues/921 for reference
    elif known_args.alias:
        print_alias(known_args)
    elif known_args.command or 'TF_HISTORY' in os.environ:
        fix_command(known_args)

# Generated at 2022-06-22 00:27:37.196674
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:27:38.043259
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:27:39.326441
# Unit test for function main
def test_main():
	main()

# Generated at 2022-06-22 00:27:48.134391
# Unit test for function main
def test_main():
    from unittest.mock import patch, mock_open
    from .fix_command import FixCommand
    from .shells import shell

    def _make_mock_open(content):
        return mock_open(read_data=content)

    def _make_mock_open_fnc(mock_open):
        return lambda filename, **kwargs: mock_open(filename, **kwargs)


# Generated at 2022-06-22 00:27:49.736639
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:27:51.257942
# Unit test for function main
def test_main():
    # Returns True if main imports the following modules
    assert main() is None


# Generated at 2022-06-22 00:28:01.428274
# Unit test for function main
def test_main():
    main()
    return True

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:28:09.991729
# Unit test for function main
def test_main():
    from unittest import mock

    with mock.patch('sys.argv', ['thefuck', '--version']):
        main()
    with mock.patch('thefuck.shells.shell.info') as info_mock:
        info_mock.return_value = 'Shell: /bin/bash, Python: 3.4.3'
        assert logs.version(get_installation_info().version,
                            sys.version.split()[0], info_mock.return_value) == \
            'Correcting shit since 2015-04-27 (Python 3.4.3, Shell: /bin/bash)'

# Generated at 2022-06-22 00:28:12.655951
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = '1'
    main()
    assert True

# Generated at 2022-06-22 00:28:15.175878
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
if __name__ == '__main__':
    test_main()
    main()

# Generated at 2022-06-22 00:28:15.766137
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:28:16.341824
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:28:18.622978
# Unit test for function main
def test_main():
    with pytest.raises(SystemExit) as exit_code:
        main()
    assert exit_code.value.code == 0

# Generated at 2022-06-22 00:28:29.657368
# Unit test for function main
def test_main():
    from mock import patch, call, MagicMock

    class FakeKnownArgs(object):
        def __init__(self, **kwargs):
            for k,v in kwargs.items():
                setattr(self, k, v)

    def fake_print_alias(known_args):
        pass

    def fake_fix_command(known_args):
        pass

    def fake_shell_logger(known_args):
        pass


# Generated at 2022-06-22 00:28:30.262243
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:42.027487
# Unit test for function main
def test_main():
    # check help
    sys.argv = [sys.argv[0], '--help']
    main()

# Generated at 2022-06-22 00:29:04.512254
# Unit test for function main
def test_main():
    import argparse
    argv = sys.argv[:]
    sys.argv = [argv[0]]

    main()
    assert sys.argv[1:] == ['-h']
    sys.argv = argv
    main()
    assert sys.argv[1:] == []
    sys.argv.append('--help')
    main()
    assert sys.argv[1:] == ['-h']
    sys.argv = argv
    main()

# Generated at 2022-06-22 00:29:06.595426
# Unit test for function main
def test_main():
    """ Test Main.
    Test Test_Main
    """
    result = main()
    assert result == 0

# Generated at 2022-06-22 00:29:11.592453
# Unit test for function main
def test_main():
    """
    test version, help and show alias.        
    """
    # version
    sys.argv = ['thefuck', '--version']
    main()
    # help
    sys.argv = ['thefuck', '--help']
    main()
    # show alias
    sys.argv = ['thefuck', '--alias']
    main()

# Generated at 2022-06-22 00:29:15.960470
# Unit test for function main
def test_main():
	import mock
	import os
	from unittest.mock import patch
	from unittest.mock import mock_open
	from thefuck import config
	from thefuck import argument_parser
	from thefuck import utils
	from thefuck import system
	from thefuck import alias
	from thefuck import fix_command
	from thefuck import shells
	from thefuck import logs

	# check whether argument_parser.parser.print_help() is called
	patcher1 = patch('thefuck.argument_parser.Parser.parse')
	patcher1.return_value = argparse.Namespace(help=True)
	patcher2 = patch('thefuck.argument_parser.Parser.print_help')
	patcher1.start()
	patcher2.start()
	main()
	assert patcher2.called == 1

# Generated at 2022-06-22 00:29:16.500671
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:25.446011
# Unit test for function main
def test_main():
    from contextlib import contextmanager
    from types import SimpleNamespace
    from ..system import Popen

    class PopenMock(Popen):
        def __init__(self, *args, **kwargs):
            self.args = args


    @contextmanager
    def mock_args(**kwargs):
        # Mock args to be SimpleNamespace
        args = SimpleNamespace()
        for arg in kwargs:
            setattr(args, arg, kwargs[arg])

        # Backup globals
        backup_args = sys.argv
        backup_popen = Popen

        # Mock globals
        sys.argv = []
        Popen = PopenMock

        yield args

        # Restore globals
        sys.argv = backup_args
        Popen = backup_popen



# Generated at 2022-06-22 00:29:27.920119
# Unit test for function main
def test_main():
    args = sys.argv[:1] + ["-h"]
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:39.794739
# Unit test for function main
def test_main():
    import os
    import pytest
    from ..argument_parser import Parser
    from ..system import init_output
    from ..utils import get_installation_info
    from ..shells import shell
    from ..logs import version
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger

    class MockParser(Parser):
        def __init__(self):
            self.help = False
            self.version = False
            self.alias = False
            self.command = False
            self.shell_logger = False

        def print_help(self):
            self.help = True

        def print_usage(self):
            self.help = True

    class MockInitOutput:
        def __init__(self):
            pass


# Generated at 2022-06-22 00:29:41.200352
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:46.289724
# Unit test for function main
def test_main():
    _, sys.modules = sys.modules, {}
    from . import commands  # noqa: E402


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:30:17.399600
# Unit test for function main
def test_main():
    print('yes')

# Generated at 2022-06-22 00:30:20.686624
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from thefuck.shells import Shell
    from .shells import shell
    
    # The format is the same as that in .travis.yml
    shell.name = 'gogole'
    shell.version = '8.8.8'
    
    with patch('thefuck.main.fix_command') as mock_fix_command, \
         patch('thefuck.main.print_alias', return_value=None) as mock_print_alias, \
         patch('thefuck.main.shell_logger') as mock_shell_logger:
        main('--help')
        assert not mock_fix_command.called
        assert not mock_print_alias.called
        assert not mock_shell_logger.called
        
        main('--version')
        assert not mock

# Generated at 2022-06-22 00:30:28.400311
# Unit test for function main
def test_main():
    import pytest
    import os
    import sys
    output = 'Usage: thefuck [OPTIONS] COMMAND [ARGS]...\n\n'
    output += 'Try to match and execute fixed command'
    output += '\n\nOptions:\n  --version        Show the version and exit.\n'
    output += '  --alias [shell]  Print alias for shell.\n'
    output += '  --shell-logger   Log shell commands to stderr.\n'
    output += '  --no-colors      Turn off colors.\n'
    output += '  --no-warn        Turn off warnings.\n'
    output += '  --debug          Turn on debug mode.\n'
    output += '  --help           Show this message and exit.\n'

# Generated at 2022-06-22 00:30:40.253504
# Unit test for function main
def test_main():
    """
    test cases:
    1. when the known_args is empty, it will print the usage of thefuck
    2. when the known_args has some values:
        2.1 if help is true, print the help
        2.2 if version is true, print the version
        2.3 if alias is true, print the alias
        2.4 if command is true, run fix_command
        2.5 if shell_logger is true, run shell_logger
    """

    #case1:
    known_args = {}
    main(known_args)

    #case2:
    known_args = {'help': True}
    main(known_args)

    known_args = {'version': True}
    main(known_args)

    known_args = {'alias': True}

# Generated at 2022-06-22 00:30:41.286369
# Unit test for function main
def test_main():
    global main
    main()

# Generated at 2022-06-22 00:30:50.840890
# Unit test for function main
def test_main():
    sys.argv = ['', '--alias']
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.alias == True
    sys.argv = ['', '--version']
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.version == True
    sys.argv = ['', '--help']
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help == True
    sys.argv = ['', '--shell-logger']
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.shell_logger == True

# Generated at 2022-06-22 00:31:03.246255
# Unit test for function main
def test_main():
    from .alias import print_alias
    from .fix_command import fix_command

    from unittest.mock import patch
    from types import SimpleNamespace

    class MockParser:
        def __init__(self):
            self.known_args = SimpleNamespace()

        def parse(self, argv):
            self.known_args.help = False
            return self.known_args

        def print_help(self):
            pass

        def print_usage(self):
            pass

    class MockParserWithAlias:
        def __init__(self):
            self.known_args = SimpleNamespace()

        def parse(self, argv):
            self.known_args.help = False
            self.known_args.alias = True
            return self.known_args

        def print_help(self):
            pass

# Generated at 2022-06-22 00:31:03.965117
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:31:08.376150
# Unit test for function main
def test_main():
    # Init sys.argv
    sys.argv = ["python3", "thefuck", "command", "--alias", "alias"]

    global print_alias
    print_alias = lambda _: False

    main()


# Generated at 2022-06-22 00:31:18.321238
# Unit test for function main
def test_main():
    import unittest
    import subprocess
    import sys
    from ..system import fix_command
    from ..utils import get_all_executables
    from ..utils import get_all_scripts
    from .alias import print_alias
    from .shell_logger import shell_logger
    from .fix_command import fix_command
    from ..argument_parser import Parser

    class TestMain(unittest.TestCase):

        def run_main(self, argv):
            if argv:
                self.main_argv = sys.argv
                sys.argv = argv
            main()
            if argv:
                sys.argv = self.main_argv


# Generated at 2022-06-22 00:32:30.892303
# Unit test for function main
def test_main():
    old_argv = sys.argv
    sys.argv = ['thefuck', '--version']
    main()
    assert sys.argv == old_argv

# Generated at 2022-06-22 00:32:42.178401
# Unit test for function main
def test_main():
    from argparse import Namespace
    from .shells.bash import is_correct
    from .alias import is_correct as is_correct_alias

    assert main() == None

    sys.argv = ['thefuck', '--help']
    assert main() == None

    sys.argv = ['thefuck', '--version']
    assert main() == None

    sys.argv = ['thefuck', '--alias']
    assert main() == None

    sys.argv = ['thefuck', 'ls', '-a']
    assert main() == None

    sys.argv = ['thefuck', '--shell-logger']
    assert main() == None

    parser = Parser()
    sys.argv = ['thefuck', '--alias', 'git']
    known_args = parser.parse(sys.argv)
   

# Generated at 2022-06-22 00:32:42.755366
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:43.909963
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:54.305274
# Unit test for function main
def test_main():
    import mock
    import sys
    import os
    from ..system import get_shell

    shell_name = get_shell().name

    args = mock.Mock()
    args.help = None
    args.version = None
    args.alias = None
    args.command = None
    args.shell_logger = None

    with mock.patch.dict(os.environ):
        with mock.patch.object(sys, 'argv', ['thefuck']):
            with mock.patch('thefuck.argument_parser.Parser.print_help') as mocked_print_help:
                main()
                mocked_print_help.assert_called_once_with()


# Generated at 2022-06-22 00:33:06.371697
# Unit test for function main
def test_main():
    import unittest.mock


# Generated at 2022-06-22 00:33:07.000551
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:33:12.778082
# Unit test for function main
def test_main():
    # Arrange
    import unittest
    from unittest.mock import patch
    test_args = ['thefuck']
    with patch.object(sys, 'argv', test_args):
        # Act
        from .main import main
        # Assert
        assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:33:13.787272
# Unit test for function main
def test_main():
    assert isinstance(main(), None)

# Generated at 2022-06-22 00:33:14.412517
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:36:08.683585
# Unit test for function main
def test_main():
    # simulate proper commandline args and environment variable
    sys.argv = ['programname', '--alias', '--debug']
    os.environ['TF_HISTORY'] = 'some_file'
    old_stdout = sys.stdout

    # Suppress stdout in unit test
    with io.StringIO() as buf, contextlib.redirect_stdout(buf):
        main()
        output = buf.getvalue()

        assert 'alias' in output
        assert 'debug' in output
        assert 'some_file' in output

# To test unittest please run: python3 -m unittest -v tests/unit_tests/unit_tests_main.py
if __name__ == '__main__':
    test_main()

# Generated at 2022-06-22 00:36:11.688138
# Unit test for function main
def test_main():
    os.environ["TF_HISTORY"]="./tests/shell_history"
    main()

# Generated at 2022-06-22 00:36:18.392204
# Unit test for function main
def test_main():
    # Arrange
    import io # noqa: E402
    import sys # noqa: E402

    old_stderr = sys.stderr
    stderr = io.StringIO()
    sys.stderr = stderr

    # Act
    main()

    # Assert
    stderr.seek(0)
    assert "usage: thefuck" in stderr.read()


# Generated at 2022-06-22 00:36:19.258996
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:36:20.255718
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:36:20.885754
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:36:22.797502
# Unit test for function main
def test_main():
    parser = Parser()
    args = ["--no-log", "--help"]
    known_args = parser.parse(args)
    main()

# Generated at 2022-06-22 00:36:23.278202
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:36:25.885997
# Unit test for function main
def test_main():
    '''
    Test the main function of the program
    '''
    # Running the main
    main()

# Generated at 2022-06-22 00:36:28.017776
# Unit test for function main
def test_main():
    #Uncomment next line to test shell_logger
    pass
    # main(["-l", "bash"])