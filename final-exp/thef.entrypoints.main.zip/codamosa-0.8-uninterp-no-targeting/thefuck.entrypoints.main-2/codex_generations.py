

# Generated at 2022-06-22 00:27:27.396464
# Unit test for function main
def test_main():
    assert main()==None
    # assert main()==shell_logger
    assert main()==fix_command
    assert main()==print_alias

# Generated at 2022-06-22 00:27:28.046200
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:27:40.035539
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .alias import print_alias
    from .fix_command import fix_command
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .shell_logger import shell_logger

    with patch.object(sys, 'argv', ['thefuck']):
        with patch.object(Parser, 'parse', return_value=Namespace(help=True)):
            with patch.object(Parser, 'print_help') as print_help:
                with patch.object(logs, 'version'):
                    main()
                    assert print_help.called


# Generated at 2022-06-22 00:27:48.537862
# Unit test for function main
def test_main():
    import mock  # noqa
    with mock.patch('thefuck.main.fix_command') as fix_command_:
        with mock.patch('thefuck.main.print_alias') as print_alias_:
            with mock.patch('thefuck.main.Parser') as Parser_:
                help_ = mock.Mock()
                help_.help = True
                print_help_ = mock.Mock()
                usage_ = mock.Mock()
                version_ = mock.Mock()
                version_.version = True
                shell_logger_ = mock.Mock()
                shell_logger_.shell_logger = True
                shell_logger_.command = True
                alias_ = mock.Mock()
                alias_.alias = True
                alias_.command = True

                Parser = mock.Mock()
                Pars

# Generated at 2022-06-22 00:27:58.439049
# Unit test for function main
def test_main():
    from mock import patch, call
    from contextlib import nested
    from ..system import init_output
    init_output()

    with nested(
        patch('sys.argv', ['thefuck']),
        patch('thefuck.argument_parser.Parser.parse',
              return_value=argparse.Namespace(help=True)),
        patch('thefuck.argument_parser.Parser.print_help')
    ) as (argv, parse, print_help):
        main()
        assert parse.call_args_list == [call(argv)]
        assert print_help.call_args_list == [call()]


# Generated at 2022-06-22 00:28:01.171288
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--alias']
    main()
    assert sys.argv[1] == '--alias'

# Generated at 2022-06-22 00:28:06.883289
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--alias', 'git']
    main()
    sys.argv = ['thefuck', '--shell-logger', 'bash']
    main()
    sys.argv = ['thefuck', 'git']
    main()

# Generated at 2022-06-22 00:28:18.345948
# Unit test for function main
def test_main():
    with patch('sys.argv', ['tf', '--version']):
        main()
        
    with patch('sys.argv', ['tf']):
        main()
        
    with patch('sys.argv', ['tf', '--shell', 'zsh', '--print-alias']):
        alis =  main()
        
    with patch('sys.argv', ['tf', '--shell', 'bash', '--print-alias']):
        alis =  main()
        
    with patch('sys.argv', ['tf', 'asd']):
        alis =  main()
        
    with patch('sys.argv', ['tf', '--shell', 'zsh', '--shell-logger']):
        alis =  main()

# Generated at 2022-06-22 00:28:18.853810
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:19.366946
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:42.871237
# Unit test for function main
def test_main():
    import os  # noqa: E402
    from unittest.mock import patch  # noqa: E402
    from . import logs  # noqa: E402
    from . import main  # noqa: E402
    from . import argument_parser  # noqa: E402

    class Args:
        def __init__(self):
            self.version = None
            self.help = None
            self.command = None
            self.alias = None
            self.shell_logger = None

    # No args

# Generated at 2022-06-22 00:28:50.280637
# Unit test for function main
def test_main():
    sys.argv = ['thefuck']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '-v']
    main()
    sys.argv = ['thefuck', '--shell', 'zsh']
    main()
    sys.argv = ['thefuck', '--shell-logger', 'zsh']
    main()
    sys.argv = ['thefuck', '--version']
    main()

# Generated at 2022-06-22 00:28:51.316630
# Unit test for function main
def test_main():
    main()

# Functional test for function main

# Generated at 2022-06-22 00:28:52.352210
# Unit test for function main
def test_main():
    # TODO: Add tests for main function
    pass

# Generated at 2022-06-22 00:29:04.322471
# Unit test for function main
def test_main():
    import io
    import sys
    import os
    import traceback
    import subprocess

    def run_main():
        old_stdout = sys.stdout
        sys.stdout = io.StringIO()
        try:
            main()
        except Exception:
            traceback.print_exc()
        finally:
            output = sys.stdout.getvalue()
            sys.stdout.close()
            sys.stdout = old_stdout
        return output

    assert run_main() == ''

    os.environ['TF_HISTORY'] = 'tfgit'
    assert run_main() == 'Sorry, I can\'t fix "tfgit"\n'

    os.environ['TF_HISTORY'] = 'git pull origin master'
    del os.environ['TF_HISTORY']
    assert run_

# Generated at 2022-06-22 00:29:04.895063
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:07.770234
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        if e.code == 2:
            assert True
        else:
            assert False
    else:
        assert False

# Generated at 2022-06-22 00:29:20.250742
# Unit test for function main
def test_main():
    from contextlib import contextmanager
    from unittest.mock import patch

    @contextmanager
    def env(**env_vars):
        original_env = dict(os.environ)
        os.environ.update(env_vars)
        try:
            yield
        finally:
            os.environ.clear()
            os.environ.update(original_env)

    # test if function help is called
    with env(TF_HISTORY=""):
        with patch('thefuck.__main__.Parser.help') as mock_help:
            with patch('thefuck.__main__.sys') as mock_sys:
                mock_sys.argv = ['thefuck', '-h']
                main()
                mock_help.assert_called_with()

    # test if function print_usage is called


# Generated at 2022-06-22 00:29:21.816701
# Unit test for function main
def test_main():
    assert main == main

# Generated at 2022-06-22 00:29:23.700963
# Unit test for function main
def test_main():
    args = ['fuck', 'apt-get']
    main()
    assert sys.exit()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:42.063172
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:52.553513
# Unit test for function main
def test_main():
    class MockParser(object):
        def __init__(self):
            self.help = True
            self.version = False

        def parse(self, argv):
            return self

        def print_help(self):
            assert 1

        def print_usage(self):
            assert 1

    main_parser = Parser
    main_help = main_parser.print_help
    main_usage = main_parser.print_usage
    main_version = logs.version
    main_get_installation_info = get_installation_info

    main_init_output = init_output
    main_fix_command = fix_command
    main_print_alias = print_alias

    try:
        init_output.mock = True
    except AttributeError:
        pass
    else:
        init_output()

   

# Generated at 2022-06-22 00:29:53.903431
# Unit test for function main
def test_main():
    assert True
    assert type(main()) is None

# Generated at 2022-06-22 00:29:54.438318
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:55.100547
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:29:55.725177
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-22 00:29:56.333259
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:30:08.591036
# Unit test for function main
def test_main():
    import mock
    import os
    from thefuck.argument_parser import Parser
    from thefuck.shells import shell
    from thefuck.types import Settings
    from thefuck.utils import wrap_settings

    class DummyParser(Parser):
        def __init__(self):
            super(DummyParser, self).__init__()

        def parse(self, argv):
            return type(
                '', (object,), {'help': False, 'version': False, 'alias': None,
                                'command': None, 'shell_logger': False,
                                'settings': wrap_settings(Settings())})()


# Generated at 2022-06-22 00:30:09.940580
# Unit test for function main
def test_main():
    assert main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:30:21.286493
# Unit test for function main
def test_main():
    import unittest
    import sys
    import os
    import subprocess
    class MyTest(unittest.TestCase):
        def test_help_functionality(self):
            try:
                out = subprocess.check_output(['tf_main', '-h'], stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as exc:
                pass
            else:
                logs.error("Substring not found")

        def test_version_functionality(self):
            try:
                out = subprocess.check_output(['tf_main', '-V'], stderr=subprocess.STDOUT)
            except subprocess.CalledProcessError as exc:
                logs.error("Substring not found")

# Generated at 2022-06-22 00:31:08.376474
# Unit test for function main
def test_main():
    import builtins
    from ..shells import bash, zsh
    from .alias import Alias

    known_args = Parser().parse([])

    def test_shell_logger(mocker):
        try:
            from .shell_logger import shell_logger  # noqa: E402
        except ImportError:
            logs.warn('Shell logger supports only Linux and macOS')
        else:
            shell_logger(known_args.shell_logger)

    def test_print_usage(mocker):
        parser = mocker.Mock()
        parser.print_usage()
        builtins.print = mocker.Mock()

    def test_fix_command(mocker):
        fix_command(known_args)

    def test_print_alias(mocker):
        print_alias(known_args)

# Generated at 2022-06-22 00:31:09.743045
# Unit test for function main
def test_main():
    global main
    main=main()
    assert main!=None

# Generated at 2022-06-22 00:31:19.379271
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from thefuck.utils import get_installation_info


# Generated at 2022-06-22 00:31:30.743213
# Unit test for function main
def test_main():
    # Initialize output
    from ..system import init_output
    init_output()

    # Ensure print alias works
    from .alias import print_alias
    import os
    import sys
    import unittest
    from unittest.mock import patch

    class MockParser:

        def parse(self, args):
            return known_args

    class MockPrintAlias:

        def print_alias(self, args):
            return args.alias

    class TestMainPrint(unittest.TestCase):

        def setUp(self):
            self.known_args = known_args
            self.known_args.alias = True
            self.known_args.shell = 'shell'
            self.known_args.history_limit = '-1'
            self.sys_argv = sys.argv
            self.os_en

# Generated at 2022-06-22 00:31:31.935141
# Unit test for function main
def test_main():
    assert(main())

# Generated at 2022-06-22 00:31:40.270653
# Unit test for function main
def test_main():
    from unittest.mock import MagicMock
    from .argument_parser import Parser

    mocked_parser = MagicMock(spec=Parser)
    mocked_parser.parse.return_value = MagicMock(
        help=True, alias=False, command=None, shell_logger=None, version=False
    )

    main(parser=mocked_parser)
    mocked_parser.parse.assert_called_once()
    mocked_parser.print_help.assert_called_once()

# Generated at 2022-06-22 00:31:40.886304
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:31:41.528548
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:31:42.754755
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:31:46.967520
# Unit test for function main
def test_main():
    class MockArgs:
        pass

    known_args = MockArgs()
    known_args.help = False
    known_args.version = False
    known_args.alias = False
    known_args.command = False
    known_args.shell_logger = False
    main()



# Generated at 2022-06-22 00:33:08.282116
# Unit test for function main
def test_main():

    # Test the help case
    def test_help():
        _locals = {'known_args': lambda : ['-h']}

        from unittest.mock import Mock, patch # noqa: E402
        from . import main # noqa: E402
        from ..utils import sysexit # noqa: E402

        # We cannot call main function, so we patch it
        with patch.object(main, "main") as _main:
            # Import the module again
            from . import main # noqa: E402

            # We want to know that exit code was 0
            with patch.object(sys, "excepthook", Mock()) as _excepthook:
                # Execute the code
                main.main()

                # Check that exit code is 0
                _excepthook.assert_called_

# Generated at 2022-06-22 00:33:20.327451
# Unit test for function main
def test_main():
    from io import StringIO
    import sys
    from unittest.mock import patch

    from .argument_parser import Parser
    from .alias import print_alias
    from .fix_command import fix_command

    # Test for known_args.help
    with patch('sys.argv', ['thefuck', '-h']):
        with patch.object(sys, 'stdout', new=StringIO()) as fake_out:
            main()
            assert fake_out.getvalue() == Parser().print_help()

    # Test for known_args.version
    with patch('sys.argv', ['thefuck', '--version']):
        with patch.object(sys, 'stdout', new=StringIO()) as fake_out:
            main()

# Generated at 2022-06-22 00:33:31.141317
# Unit test for function main
def test_main():
    import argparse
    from unittest.mock import patch  # noqa: E402
    # Initialize output before importing any module, that can use colorama.
    from ..system import init_output
    init_output()
    # Make sure that test_main() will return None, instead of main()
    main_patch = patch('thefuck.main.main', return_value=None)
    # Make sure that test_main() will use temp_parser()
    temp_parser_patch = patch('thefuck.main.Parser', return_value=argparse.ArgumentParser(add_help=False))
    parser_patch = patch('thefuck.main.Parser', lambda: argparse.ArgumentParser(add_help=False))

# Generated at 2022-06-22 00:33:31.755442
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:33:32.344688
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:33:32.970305
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:33:33.594385
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:33:34.908357
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:33:42.651966
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck', '--version']
    try:
        assert main() is None
    except SystemExit:  # pragma: no cover
        pass

    sys.argv = ['thefuck', '--help']
    try:
        assert main() is None
    except SystemExit:  # pragma: no cover
        pass

    sys.argv = ['thefuck', '--alias', 'fuck']
    try:
        assert main() is None
    except SystemExit:  # pragma: no cover
        pass

# Generated at 2022-06-22 00:33:54.759991
# Unit test for function main
def test_main():
    import os
    import sys
    import tempfile
    import unittest.mock
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    sys.argv = ['/usr/bin/thefuck']
    parser = Parser()
    known_args = parser.parse(sys.argv)
    if known_args.help:
        parser.print_help()
    elif known_args.version:
        logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info())
    # It's important to check if an alias is being requested before checking if
    # `TF_HISTORY` is in `os.environ

# Generated at 2022-06-22 00:36:56.205639
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:37:02.842116
# Unit test for function main
def test_main():
    from . import test_parse_settings as config  # noqa: E402
    from . import test_settings as settings  # noqa: E402
    from . import test_aliases as aliases  # noqa: E402
    import builtins  # noqa: E402
    import logging  # noqa: E402
    import io  # noqa: E402
    tests = io.StringIO()
    handler = logging.StreamHandler(tests)
    handler.setLevel(logging.INFO)
    builtins.logs.addHandler(handler)

    main()
    assert tests.getvalue() == ''

    main(['-h'])

# Generated at 2022-06-22 00:37:05.728453
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = '1'
    try:
        main()
    finally:
        del os.environ['TF_HISTORY']

# Generated at 2022-06-22 00:37:06.341118
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:37:13.037358
# Unit test for function main
def test_main():
    # 1. Testing print_help()
    # mock sys.argv
    sys.argv = ["thefuck.py","-h"]
    main()

    # 2. Testing version()
    sys.argv = ["thefuck.py", "-v"]
    main()
    # 3. Testing alias
    sys.argv = ["thefuck.py","--alias","fuck"]
    main()
    # 4. Testing fix_command()
    sys.argv = ["thefuck.py", "fuck"]
    main()

# Generated at 2022-06-22 00:37:19.002636
# Unit test for function main
def test_main():
    import mock
    mock_argv = ['--version']
    mock_sys = mock.MagicMock()
    mock_sys.argv = mock_argv
    mock_sys.version = 'python 2.6.6'
    with mock.patch('sys.argv', mock_argv):
        with mock.patch('sys.version', 'python 2.6.6'):
            import thefuck
         