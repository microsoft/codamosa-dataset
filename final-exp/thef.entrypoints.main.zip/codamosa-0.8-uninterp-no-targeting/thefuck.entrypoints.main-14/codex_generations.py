

# Generated at 2022-06-22 00:27:25.753102
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-22 00:27:26.402330
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:27:37.555065
# Unit test for function main
def test_main():
    def system(x):
        return x

    try:
        sys.argv = ['thefuck']
        main()
    except SystemExit:
        pass
    else:
        raise AssertionError('The else part should never run')
    try:
        sys.argv = ['thefuck', '--version']
        main()
    except SystemExit:
        pass
    else:
        raise AssertionError('The else part should never run')
    try:
        sys.argv = ['thefuck', '--shell', 'bash']
        main()
    except SystemExit:
        pass
    else:
        raise AssertionError('The else part should never run')
    try:
        sys.argv = ['thefuck', '--shell-logger']
        main()
    except SystemExit:
        pass
   

# Generated at 2022-06-22 00:27:44.679352
# Unit test for function main
def test_main():
    class testargs:
        def __init__(self, version = False, command = False, alias = False,
                                 help = False, shell_logger = False):
            self.version = version
            self.command = command
            self.alias = alias
            self.help = help
            self.shell_logger = shell_logger
    main(testargs(version = True, alias = True, command = True,
                         help = True, shell_logger = True))

# Generated at 2022-06-22 00:27:55.356483
# Unit test for function main
def test_main():
    from .arguments import main_parser
    from shell_logger_linux import shell_logger_linux
    from shell_logger_osx import shell_logger_osx
    from mock import patch, MagicMock
    _main = main
    mock_parser = MagicMock(main_parser)
    mock_shell_logger = MagicMock(shell_logger_linux)
    mock_osx_shell_logger = MagicMock(shell_logger_osx)

    def main():
        _main()
        assert mock_parser.parse_args.called
        assert mock_shell_logger.called
        assert mock_osx_shell_logger.called


# Generated at 2022-06-22 00:27:58.065690
# Unit test for function main
def test_main():
    test_argv = ['main.py', '-alias']
    sys.argv = test_argv
    if __name__ == '__main__':
        main()

# Generated at 2022-06-22 00:28:08.311447
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', new=['thefuck', '--version']):
        main()
    with mock.patch('sys.argv', new=['thefuck', '--help']):
        main()
    with mock.patch('sys.argv', new=['thefuck', '--alias', 'fuck']):
        main()
    with mock.patch('sys.argv', new=['thefuck', 'command']):
        main()
    with mock.patch('sys.argv', new=['thefuck', '--shell_logger', 'zsh']):
        main()
    with mock.patch('sys.argv', new=['thefuck']):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:28:08.972121
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-22 00:28:09.993463
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:20.644670
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from thefuck import alias
    from thefuck.utils import get_installation_info

    # Test for alias
    with patch('thefuck.main.print_alias') as mock_print_alias, \
            patch('thefuck.main.fix_command') as mock_fix_command, \
            patch('thefuck.main.sys.version_info', (3, 5, 0)), \
            patch('thefuck.main.sys.platform', 'linux'), \
            patch('thefuck.main.shell', 'gnome-terminal'), \
            patch('thefuck.main.sys.argv', ['thefuck', '-a']):
        main()

# Generated at 2022-06-22 00:28:29.804557
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:41.505705
# Unit test for function main
def test_main():
    import sys
    import os
    import shutil
    from ..hint import Hint
    from ..utils import temp_files
    from ..rules import Function
    from ..command import Command
    from .alias import print_alias
    os.environ["TF_CONFIG_PATH"] = os.path.expanduser(".")
    try:
        os.makedirs("~/.config/thefuck")
    except FileExistsError:
        pass;
    shutil.copy("/usr/share/thefuck/rules/git.py", "~/.config/thefuck")
    shutil.copy("/usr/share/thefuck/rules/suggest.py", "~/.config/thefuck")
    os.environ["TF_ALIAS"] = "alias fuck='eval $(thefuck \\$(fc -ln -1))'"
   

# Generated at 2022-06-22 00:28:42.669792
# Unit test for function main
def test_main():
    assert main() is not None

# Generated at 2022-06-22 00:28:44.075086
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-22 00:28:55.676792
# Unit test for function main
def test_main():
    # Unit tests for help, version and alias
    test_help = ['--help']
    test_version = ['--version']
    test_alias = ['--alias', 'tf']
    # Unit test for command input
    test_command = ['It\'s hight time to get to work!']
    # Unit test for shell_logger
    test_shell_logger = ['--shell-logger']
    # Unit test for Main
    test_main = []

    savedin = sys.argv

# Generated at 2022-06-22 00:28:56.534686
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-22 00:28:58.034708
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-22 00:28:58.750591
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:03.342214
# Unit test for function main
def test_main():
    stdout = sys.stdout
    sys.stdout = open(os.devnull, 'w')
    main()
    sys.stdout.close()
    sys.stdout = stdout

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:12.685528
# Unit test for function main
def test_main():
	known_args = Parser().parse(sys.argv)	# Parses the arguments from the command-line
	parser = Parser()	# Creates the ArgumentParser object
	# known_args.help is set to False by default, hence this if statement is skipped
	# known_args.version is set to False by default, hence this if statement is skipped
	# known_args.alias is set to False by default, hence this if statement is skipped
	# known_args.command is set to False by default, hence this if statement is skipped
	# known_args.shell_logger is set to 'bash' by default, hence this if statement is skipped
	# hence, this final else statement is executed
	parser.print_usage()	# Prints the usage message of the script
		
# Run the main() function

# Generated at 2022-06-22 00:29:38.174572
# Unit test for function main
def test_main():
    # Test helper function
    def _main(args):
        """Helper to perform main() with args."""
        with patch('sys.argv', ['tf'] + args):
            main()
    # Test that main() exits correctly on help
    with patch('sys.exit') as sys_exit:
        _main(['--help'])
        assert sys_exit.call_count == 1
    # Test that main() exits correctly on version
    with patch('sys.exit') as sys_exit:
        _main(['--version'])
        assert sys_exit.call_count == 1

# Generated at 2022-06-22 00:29:38.800933
# Unit test for function main
def test_main():
    assert main() != None

# Generated at 2022-06-22 00:29:40.108631
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()


# Generated at 2022-06-22 00:29:41.617341
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:29:43.796239
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:46.086529
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        assert True
    else:
        assert False

# Generated at 2022-06-22 00:29:53.876015
# Unit test for function main
def test_main():
    # Test the case when only -h is given
    argv = ['fuck', '-h']
    assert main() == parser.print_usage()

    # Test the case when only --version is given
    argv = ['fuck', '--version']
    assert main() == logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info())
    # Test the case when only --alias is given
    argv = ['fuck', '--alias']
    assert main() == print_alias(known_args)
    # Test the case when only --shell_logger is given
    argv = ['fuck', '--shell_logger']
    assert main() == shell_logger(known_args.shell_logger)
    # Test the case when only commands is given

# Generated at 2022-06-22 00:29:55.464617
# Unit test for function main
def test_main():
	main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:57.341016
# Unit test for function main
def test_main():
    from ..system import init_output, reset_output
    init_output()
    main()
    reset_output()

# Generated at 2022-06-22 00:29:58.726983
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:30:39.371432
# Unit test for function main
def test_main():
    from unittest.mock import patch, mock_open, MagicMock
    from ..utils import get_installation_info
    from ..argument_parser import ArgumentParser
    from ..log import logger
    from ..system import shell_execute
    import sys
    import os

    installation_info = get_installation_info()
    with patch('thefuck.main.init_output'):
        with patch('thefuck.main.Parser', return_value=ArgumentParser()):
            parser = ArgumentParser()
            with patch('thefuck.main.Parser.parse', return_value=parser.parse_args([])) as _:
                with patch('thefuck.main.get_installation_info', return_value=installation_info):
                    with patch('thefuck.main.print_alias'):
                        main()
                        parser.print

# Generated at 2022-06-22 00:30:42.454432
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)

    if known_args.help:
        parser.print_help()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:30:43.046417
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:30:43.705038
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:30:44.294531
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:30:44.889342
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:30:45.933769
# Unit test for function main
def test_main():
    # Calling main() should not throw any exception
    main()

# Generated at 2022-06-22 00:30:46.577009
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:30:47.168983
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:30:47.812769
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:04.883150
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help
    assert known_args.version
    assert known_args.alias
    assert known_args.command
    assert known_args.shell_logger
    assert known_args.help == False
    assert known_args.version == True
    assert known_args.alias == True
    assert known_args.command == True
    assert known_args.shell_logger == True

# Generated at 2022-06-22 00:32:16.534109
# Unit test for function main
def test_main():
    import os  # noqa: E402
    from unittest.mock import patch  # noqa: E402
    from . import print_alias  # noqa: E402
    from . import fix_command  # noqa: E402
    from ..system import init_output  # noqa: E402
    from .shell_logger import shell_logger  # noqa: E402

    with patch('sys.argv', ['tf']):
        main()

    with patch('sys.argv', ['tf', '--help']):
        main()

    with patch('sys.argv', ['tf', '--version']):
        main()

    with patch('sys.argv', ['tf', '--alias']):
        with patch('builtins.print') as mock_print:
            main()


# Generated at 2022-06-22 00:32:17.189916
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:32:20.233377
# Unit test for function main
def test_main():
    import sys  # noqa: E402
    sys.argv = ['thefuck']

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:32:21.652078
# Unit test for function main
def test_main():
    assert main

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:32:33.657376
# Unit test for function main
def test_main():
    import unittest
    from unittest.mock import patch
    from ..argument_parser import Parser
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger

    class MainTestCase(unittest.TestCase):
        @patch('sys.argv', ['.', '--help'])
        @patch.object(Parser, 'print_help')
        def test_help(self, print_help_mock):
            main()
            self.assertTrue(print_help_mock.called)


# Generated at 2022-06-22 00:32:44.615050
# Unit test for function main
def test_main():
    def test_parser():
        class mock_Parser():
            def __init__(self):
                self.help = False
                self.alias = ''
                self.shell_logger = ''
                self.command = ''
                self.version = False
            def parse(self, a):
                return self
            def print_help(self):
                None
            def print_usage(self):
                None

        return mock_Parser()

    def test_logs():
        class mock_logs():
            def __init__(self):
                None
            def version(v, v2, s):
                None
            def warn(s):
                None
            def shell_logger(s):
                None
            def shell_logger_active(s):
                None

        return mock_logs()


# Generated at 2022-06-22 00:32:49.129845
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    expected ='usage: tf [-h] [-p] [-q] [-d] [-l] [-v] [--alias]\n              [script]\n'
    assert(parser.print_usage() == expected)

# Generated at 2022-06-22 00:32:50.561626
# Unit test for function main
def test_main():
    import sys
    sys.argv = ["thefuck", "--alias"]
    main()

# Generated at 2022-06-22 00:32:58.688951
# Unit test for function main
def test_main():
    # Test case 1:
    # Test if input of main() is ['fuck', 'help']
    # Test if it can print the expected help
    class Obj:
        def __init__(self):
            self.help = True
    try:
        main(args=['fuck', 'help'])
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise e
    except:
        raise
    else:
        pass
    # Test case 2:
    # Test if input of main() is ['fuck', 'version']
    # Test if it can print the expected version
    try:
        main(args=['fuck', 'version'])
    except SystemExit as e:
        if e.code == 0:
            pass
        else:
            raise e
    except:
        raise

# Generated at 2022-06-22 00:35:49.925567
# Unit test for function main
def test_main():
    sys.argv = ["thefuck"]


# Generated at 2022-06-22 00:35:51.389379
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-22 00:36:03.762466
# Unit test for function main
def test_main():
    """
        Function to test function main
        :return:
        """
    from unittest import mock
    from . import logger

# Generated at 2022-06-22 00:36:04.389128
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:36:05.384004
# Unit test for function main
def test_main():
    assert main() is None


# Generated at 2022-06-22 00:36:06.012241
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:36:06.824546
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:36:18.194505
# Unit test for function main
def test_main():
    sourcetree = 'source /Users/michaelvanderheide/Library/Application Support/SourceTree/stree_bash_completion.sh'
    alias = 'alias fuck="eval $(thefuck $(fc -ln -1))"'

    known_args = Parser().parse([sourcetree, alias])

    assert known_args.command is None
    assert known_args.help is False
    assert known_args.shell_logger == 'bash'
    assert known_args.version is False
    assert known_args.wait is None
    assert known_args.repeat == 1
    assert known_args.alias == 'fuck'
    assert known_args.no_wait is False
    assert known_args.require_confirmation is False

# Generated at 2022-06-22 00:36:26.704049
# Unit test for function main
def test_main():
    # Unit test for function main
    import argparse
    import os
    import mock
    import io
    import sys

    # Mock print and input
    sys.stdout = io.StringIO()
    sys.stdin = io.StringIO()

    from thefuck.utils import get_installation_info
    from thefuck.shells import shell

    with mock.patch('thefuck.main.Parser') as mocked_parser:
        with mock.patch('sys.argv', ['thefuck']):
            with mock.patch('sys.stdout.write') as mocked_write:
                mocked_parser().parse.return_value = argparse.Namespace(help=False, version=False,
                                                                        alias=False)
                get_installation_info().version.return_value = '3.3.3'

# Generated at 2022-06-22 00:36:38.346103
# Unit test for function main
def test_main():
    # import mock
    import os
    import sys

    # patch stdout
    # real_stdout = sys.stdout
    # real_print = print
    # stdout_mock = mock.MagicMock(spec=sys.stdout)
    # @mock.patch('sys.stdout', new=stdout_mock)
    # def print_test():
    #     real_print('test')
    #     real_stdout.write('test')

    # CURRENT_DIR = os.getcwd()
    # os.chdir('tests')

    # parser = Parser()
    # known_args = parser.parse(['-h'])
    # main(known_args)
    # out, err = capsys.readouterr()
    # assert out == Parser().format_help()

   