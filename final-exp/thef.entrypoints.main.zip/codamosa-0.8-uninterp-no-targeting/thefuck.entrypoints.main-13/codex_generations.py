

# Generated at 2022-06-22 00:27:27.664874
# Unit test for function main
def test_main():
    assert main() == 'None'

# Generated at 2022-06-22 00:27:28.750297
# Unit test for function main
def test_main():
    assert fix_command() == "FUCK"

# Generated at 2022-06-22 00:27:29.402879
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:27:33.751931
# Unit test for function main
def test_main():
    from click.testing import CliRunner
    from .argument_parser import VERSION, SHELL_LOGGERS, shell_supported
    from .shell_logger import shell_logger

    runner = CliRunner()
    resultHelp = runner.invoke(main, ['--help'])
    resultVersion = runner.invoke(main, ['--version'])
    resultDefault = runner.invoke(main, ['fuck'])
    resultShellLogger = runner.invoke(main, ['--shell-logger', SHELL_LOGGERS[0]])
    resultInvalidAlias = runner.invoke(main, ['--alias', 'invalid'])
    if not shell_supported():
        resultAlias = runner.invoke(main, ['--alias', SHELL_LOGGERS[0]])

# Generated at 2022-06-22 00:27:35.576510
# Unit test for function main
def test_main():
    # return
    assert 1 == 1

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:27:42.971595
# Unit test for function main
def test_main():
    parser = Parser()
    assert parser.parse(['fuck']) == parser.parse(['--help'])
    assert parser.parse(['fuck', '--version']) != parser.parse(['--help'])
    assert parser.parse(['fuck', '--alias', 'fuck']) != parser.parse(['--help'])
    assert parser.parse(['fuck', '--shell-logger']) != parser.parse(['--help'])

# Generated at 2022-06-22 00:27:43.848270
# Unit test for function main
def test_main():
    # TODO: test
    pass

# Generated at 2022-06-22 00:27:55.132646
# Unit test for function main
def test_main():
    import sys
    import os
    import fcntl

    def _mock_alias_print(alias):
        return alias

    def _mock_fix_command(known_args):
        return known_args

    def _mock_shell_logger(logger):
        return logger

    _mock_system_argv = sys.argv
    _mock_system_stdout = sys.stdout
    _mock_system_stderr = sys.stderr
    _mock_system_stdin = sys.stdin

    class _test_class:
        def __init__(self, argv):
            self.argv = argv
            self.known_args = []
            self.help = False
            self.version = False
            self.alias = ''
            self.shell_log

# Generated at 2022-06-22 00:27:56.365312
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:27:56.974533
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:28:05.772990
# Unit test for function main
def test_main():
    return

# Generated at 2022-06-22 00:28:06.381640
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:28:07.373393
# Unit test for function main
def test_main():
    print("it should print help")
    main()

# Generated at 2022-06-22 00:28:07.778340
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:08.580395
# Unit test for function main
def test_main():
	assert main() == None

if __name__ == '__main__':
	main()

# Generated at 2022-06-22 00:28:20.196792
# Unit test for function main
def test_main():
    test_parser = Parser()
    test_args = test_parser.parse(sys.argv)
    if "--help" in sys.argv:
        test_parser.print_help()
    elif "--version" in sys.argv:
        logs.error(get_installation_info().version,
                     sys.version.split()[0], shell.info())
    elif "--alias" in sys.argv:
        print_alias(test_args)
    elif "--shell-logger" in sys.argv:
        try:
            from .shell_logger import shell_logger  # noqa: E402
        except ImportError:
            logs.error('Shell logger supports only Linux and macOS')
        else:
            shell_logger(test_args.shell_logger)
   

# Generated at 2022-06-22 00:28:24.016277
# Unit test for function main
def test_main():
    os.environ["TF_HISTORY"] = "1"
    main()
    os.environ.pop("TF_HISTORY", None)


# Generated at 2022-06-22 00:28:24.595695
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:28:35.500869
# Unit test for function main
def test_main():
    import sys
    import unittest
    from unittest.mock import patch
    from io import StringIO
    from ..log import logs
    from ..argument_parser import Parser

    class TestMain(unittest.TestCase):
        def test_main1(self):
            capturedOutput = StringIO()
            sys.stdout = capturedOutput

# Generated at 2022-06-22 00:28:36.062795
# Unit test for function main
def test_main():
	main()

# Generated at 2022-06-22 00:28:52.455851
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:04.416602
# Unit test for function main
def test_main():
    import argparse
    argparse.ArgumentParser = FakeArgumentParser
    with mock.patch('sys.argv', ['-h']):
        main()
    with mock.patch('sys.argv', ['--help']):
        main()
    with mock.patch('sys.argv', ['-v']):
        main()
    with mock.patch('sys.argv', ['--version']):
        main()
    with mock.patch('sys.argv', ['--alias']):
        main()
    with mock.patch('sys.argv', ['--shell-logger']):
        main()
    with mock.patch('sys.argv', ['-c', 'false']):
        main()

# Generated at 2022-06-22 00:29:05.812805
# Unit test for function main
def test_main():
    main()
if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:06.675425
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:29:07.282449
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:29:19.797672
# Unit test for function main
def test_main():
    import mock
    import thefuck

    assert main() == None

    # mock sys.argv
    import sys

    # clean sys.argv
    sys.argv = [sys.argv[0]]
    # test case 1: no argument
    with mock, mock.patch('sys.argv', [sys.argv[0]]):
        assert main() == None

    # test case 2: version
    with mock.patch('sys.stdout') as mock_stdout:
        with mock.patch('sys.argv', [sys.argv[0], '--version']):
            main()
            assert mock_stdout.write.call_count == 2

    # test case 3: help

# Generated at 2022-06-22 00:29:28.502845
# Unit test for function main
def test_main():
    unknown_arg = '--unknown'
    sys.argv = [sys.argv[0]] + [unknown_arg]
    main()
    assert unknown_arg in sys.stderr.getvalue()
    sys.stderr.truncate(0)
    sys.stderr.seek(0)
    sys.argv = [sys.argv[0]] + ['--help']
    main()
    assert len(sys.stderr.getvalue()) == 0
    sys.stderr.truncate(0)
    sys.stderr.seek(0)
    sys.argv = [sys.argv[0]] + ['--version']
    main()
    assert len(sys.stderr.getvalue()) == 0
    sys.stderr.truncate(0)
    sys

# Generated at 2022-06-22 00:29:29.610319
# Unit test for function main
def test_main():
    sys.argv = ['thefuck']

# Generated at 2022-06-22 00:29:40.750366
# Unit test for function main
def test_main():
    argv = ["thefuck", "thefuck"]
    with mock.patch('thefuck.main.Parser.parse',
                    return_value = argparse.Namespace(confirm = False, command = None, debug = False, env = False,
                                                      history = True, help = False, interactive = True, no_colors = False,
                                                      repeat = True, rules = [], settings = None, shell_logger = False,
                                                      sudo_command = None, wait = 3, alias = None, version = None)):
        with mock.patch('builtins.print') as print_mock:
            with mock.patch.dict('os.environ', {'TF_NO_COLOR': '1'}):
                main()
                assert print_mock.called

# Generated at 2022-06-22 00:29:52.045810
# Unit test for function main
def test_main():
    import subprocess  # noqa: E402

    def invoke(*args, **kwargs):
        _in = kwargs.get('stdin', None)
        _in = open(_in) if _in and os.path.isfile(_in) else None
        return subprocess.check_output(['python', __file__, *args],
                                       stdin=_in).decode()

    assert invoke('--help')
    assert invoke('--version')
    assert invoke('--aliases')
    assert invoke('--shell-logger', stdin='test_shell_logger.py')

    with open('test_file.txt', 'w') as file:
        file.write('test command')
    assert invoke('test command', stdin='test_file.txt')



# Generated at 2022-06-22 00:30:25.115947
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-22 00:30:26.001389
# Unit test for function main
def test_main():
    init_output()

    main()

# Generated at 2022-06-22 00:30:26.553666
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:30:27.547182
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-22 00:30:28.136965
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:30:40.005176
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args != parser.parse(['--shell', 'bash', '--version'])
    assert known_args != parser.parse(['--shell', 'bash', 'fix', 'whoami'])
    assert known_args != parser.parse(['--shell', 'bash', 'fix', 'whoami'])
    assert known_args != parser.parse(['--shell', 'bash', 'fix', 'whoami'])
    assert known_args != parser.parse(['--shell', 'bash', 'fix', 'whoami'])
    assert known_args != parser.parse(['--shell', 'bash', 'fix', 'whoami'])

# Generated at 2022-06-22 00:30:41.849428
# Unit test for function main
def test_main():
    test_args=['thefuck', '--help']
    main()
    assert  sys.argv == test_args

# Generated at 2022-06-22 00:30:42.511807
# Unit test for function main
def test_main():
  pass

# Generated at 2022-06-22 00:30:51.644126
# Unit test for function main
def test_main():
    # Test help arg
    with patch('sys.argv', ['thefuck', '--help']):
        try:
            main()
        except:
            assert True
        else:
            assert False

    # Test version arg
    with patch('sys.argv', ['thefuck', '--version']):
        try:
            main()
        except:
            assert True
        else:
            assert False

    # Test alias arg
    with patch('sys.argv', ['thefuck', '--alias']):
        try:
            main()
        except:
            assert True
        else:
            assert False

    # Test no arg
    with patch('sys.argv', ['thefuck']):
        try:
            main()
        except:
            assert True
        else:
            assert False

# Generated at 2022-06-22 00:30:52.856381
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:32:03.339010
# Unit test for function main
def test_main():
    os.system('clear')
    main()

# Generated at 2022-06-22 00:32:03.950064
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:10.421165
# Unit test for function main
def test_main():
    _sys = __import__("sys")
    _os = __import__("os")
    _os.environ['TF_HISTORY'] = "ls && exit\ntest\nexit\n"
    _sys.argv = ['/usr/local/bin/thefuck', 'jr']
    try:
        main()
    except SystemExit:
        pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:32:18.927748
# Unit test for function main
def test_main():
	test_parser = Parser()
	test_known_args = test_parser.parse(["--help"])
	test_known_args = test_parser.parse(["--version"])
	test_known_args = test_parser.parse(["--alias"])
	test_known_args = test_parser.parse(["--shell-logger"])
	test_known_args = test_parser.parse([""])
	test_known_args = test_parser.parse(["gcc: error: could not fork"])

# Generated at 2022-06-22 00:32:21.302756
# Unit test for function main
def test_main():
    main()
    test_command = ['thefuck', 'how did you konw what i do']
    assert sys.argv == test_command

# Generated at 2022-06-22 00:32:21.900746
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:32:33.940033
# Unit test for function main
def test_main():
    import mock
    from .test_shell_logger import test_shell_logger
    from .test_alias import test_print_alias
    from .test_fix_command import test_fix_command
    from .test_argument_parser import test_help, test_version

    mock_parser = mock.Mock()
    argv = ['thefuck']
    known_args = mock.Mock()
    mock_parser.parse.return_value = known_args

    with mock.patch('thefuck.main.Parser', return_value=mock_parser):
        main()
        mock_parser.parse.assert_called_once_with(argv)
    known_args.help = True
    with mock.patch('thefuck.main.Parser', return_value=mock_parser):
        main()

# Generated at 2022-06-22 00:32:35.946030
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False
    else:
        assert True

# Generated at 2022-06-22 00:32:36.632767
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:37.206744
# Unit test for function main
def test_main():
   assert False

# Generated at 2022-06-22 00:35:20.483787
# Unit test for function main
def test_main():
    from mock import MagicMock
    sys = MagicMock()
    sys.argv = ['-v']

    def assert_called(called):
        assert called

    logs = MagicMock()
    logs.version = lambda x, y, z: assert_called(True)

    from .. import logs as logs_real
    logs_real.logs = logs
    main()



# Generated at 2022-06-22 00:35:22.270797
# Unit test for function main
def test_main():
    # check help
    sys.argv = ['thefuck']
    assert main() == None


# Generated at 2022-06-22 00:35:29.591856
# Unit test for function main
def test_main():
    import os
    import sys

    sys.argv = ["thefuck", "--help"]
    main()

    sys.argv = ["thefuck", "--version"]
    main()

    os.environ['TF_HISTORY'] = "aaaaa"
    sys.argv = ["thefuck", "haha"]
    main()

    sys.argv = ["thefuck", "--shell-logger=bash"]
    main()

# Generated at 2022-06-22 00:35:30.210330
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:35:30.852065
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:35:39.252356
# Unit test for function main
def test_main():
    from .config import Config  # noqa: E402
    from .alias import print_alias  # noqa: E402
    from .fix_command import fix_command  # noqa: E402

    # make a copy of the sys.argv to be used for restore after the test
    actual_sys_argv = sys.argv[:]

    # Setup mocks
    os.environ['TF_HISTORY'] = 'True'
    parser = Parser()
    parser.print_usage = mock.Mock()
    parser.print_help = mock.Mock()
    logs.version = mock.Mock()
    print_alias = mock.Mock()
    fix_command = mock.Mock()
    get_installation_info = mock.Mock()

# Generated at 2022-06-22 00:35:40.545275
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:35:41.145296
# Unit test for function main
def test_main():
    return main()

# Generated at 2022-06-22 00:35:51.072831
# Unit test for function main
def test_main():
    import io
    import os
    import sys

    from pytest import raises

    # load old env
    env = os.environ.copy()
    # Create a new environment
    os.environ = {"TF_HISTORY": "1"}

    # Store stdout
    stdout = sys.stdout
    # Capture stdout
    sys.stdout = io.StringIO()

    main()
    assert sys.stdout.getvalue() == ''

    with raises(SystemExit) as ex:
        sys.argv = ['-T', '-T']
        main()
    assert ex.value.code == 2

    sys.argv = ['-h']
    main()
    assert sys.stdout.getvalue() != ''

    # Close old stdout
    sys.stdout.close()
    # Load old stdout

# Generated at 2022-06-22 00:35:53.699127
# Unit test for function main
def test_main():
    try:
        sys.argv.append('--help')
        main()

    except SystemExit:
        assert True
    sys.argv.remove('--help')
