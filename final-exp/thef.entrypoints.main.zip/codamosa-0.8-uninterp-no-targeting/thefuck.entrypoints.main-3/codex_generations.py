

# Generated at 2022-06-22 00:27:24.942014
# Unit test for function main
def test_main():
    assert main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:27:29.569451
# Unit test for function main
def test_main():
    # If main function run with no parameter, print version and exit
    #sys.argv = [sys.argv[0]]
    pass

# Make main function behave like main function
main.__name__ = "__main__"

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:27:33.798346
# Unit test for function main
def test_main():
    import random

    # Create a dummy sys.argv
    random.seed(0)
    num = random.randrange(100)
    help_ = random.randrange(num) > num/2
    ver_ = random.randrange(num) > num/3
    alias_ = random.randrange(num) > 2*num/3
    shell_log_ = random.randrange(num) <= num/6
    sys.argv = [str(random.randrange(num))]
    if help_:
        sys.argv.append('--help')
        assert help_
    if ver_:
        sys.argv.append('--version')
        assert ver_
    if alias_:
        sys.argv.append('--alias')
        assert alias_

# Generated at 2022-06-22 00:27:35.236152
# Unit test for function main
def test_main():
    import sys
    sys.argv = ["","aa"]
    assert main() == None

# Generated at 2022-06-22 00:27:38.321389
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    except Exception:
        print('error')


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:27:41.806051
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    try:
        assert known_args.help
        assert known_args.version
        #assert known_args.alias
        #assert known_args.shell_logger
        assert known_args.command
    except:
        raise Exception
    finally:
        pass

# Generated at 2022-06-22 00:27:53.960403
# Unit test for function main
def test_main():
    # Test 1:
    # Case -> The requested command is to print help
    # Input -> sys.argv = ['thefuck', '--help']
    # Expected output -> Print help message
    sys.argv = ['thefuck', '--help']
    test_help_output = str(main())
    print("Expected output")
    print("usage: thefuck [-h] [--version] [--alias [SHELL]] [--no-color]")
    print("               [--shell-logger [SHELL]] [--use CMD [CMD ...]]")
    print("               [--rules [RULES [RULES ...]]] [--require [REQUIRE [REQUIRE ...]]]")
    print("               [--running-as-script]")
    print("               [command]")

# Generated at 2022-06-22 00:28:06.180255
# Unit test for function main
def test_main():
    with patch.object(sys, 'argv', ['thefuck', '-h']):
        main()
        mock_print_help.assert_called_once_with()

    with patch.object(sys, 'argv', ['thefuck', '--version']):
        main()
        mock_logs.version.assert_called_once_with(mock_installation_info.version, \
                mock_version, mock_shell.info())

    with patch.object(sys, 'argv', ['thefuck', '--alias']):
        main()
        mock_print_alias.assert_called_once_with(known_args)

    os.environ['TF_HISTORY'] = 'history'

# Generated at 2022-06-22 00:28:15.959148
# Unit test for function main
def test_main():
    # test case 1: help command
    test_args = ['--help']
    sys.argv = test_args
    try:
        main()
    except SystemExit:
        pass
    assert True

    # test case 2: version command
    test_args = ['--version']
    sys.argv = test_args
    try:
        main()
    except SystemExit:
        pass
    assert True

    # test case 3: shell_logger command
    test_args = ['--shell-logger']
    sys.argv = test_args
    try:
        main()
    except SystemExit:
        pass
    assert True

# Generated at 2022-06-22 00:28:16.603596
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:35.542010
# Unit test for function main
def test_main():
    from unittest import mock
    from . import alias
    from . import fix_command
    from . import shell_logger
    from . import test_shell_logger
    from ..shells import bash, fish, zsh

    # No arguments
    with mock.patch.object(sys, 'argv', ['thefuck']):
        with mock.patch('thefuck.main.Parser.parse') as mock_parse:
            mock_parse.return_value = mock.Mock(**{
                'help': False,
                'version': False,
                'alias': False,
                'command': False,
                'shell_logger': False})
        with mock.patch('thefuck.main.Parser.print_usage'):
            main()
            assert mock_parse.called

    # Argument --help

# Generated at 2022-06-22 00:28:37.610670
# Unit test for function main
def test_main():
    assert 1 == 1


if __name__ == "__main__":
    main()

# Generated at 2022-06-22 00:28:48.641504
# Unit test for function main
def test_main():
    from unittest.mock import patch

    def mock_import_module():
        pass

    def mock_alias(arg):
        pass

    def mock_fix_command(arg):
        pass

    def mock_shell_logger(arg):
        pass

    with patch.object(sys, 'argv', ['thefuck']):
        with patch.object(Parser, 'parse',
                          return_value=argparse.Namespace(help=True)) as mock_parse:
            with patch.object(Parser, 'print_help') as mock_print_help:
                main()
                mock_parse.assert_called_once()
                mock_print_help.assert_called_once()

# Generated at 2022-06-22 00:29:00.533102
# Unit test for function main
def test_main():
    from unittest.mock import Mock, patch
    from io import StringIO
    import sys
    sys.argv = ["thefuck", "--alias", "fuck"]
    f = StringIO()
    with patch.object(sys, 'stdout', f):
        with patch('thefuck.main.print_alias') as m:
            main()
            m.called == True
    with patch.object(sys, 'stdout', f):
        with patch('thefuck.main.fix_command') as m:
            sys.argv = ["thefuck", "ls"]
            main()
            m.called == True
    with patch.object(sys, 'stdout', f):
        with patch('thefuck.main.print_help') as m:
            sys.argv = ["thefuck", "--help"]
            main()

# Generated at 2022-06-22 00:29:01.109788
# Unit test for function main
def test_main():
    print("Test Main")

# Generated at 2022-06-22 00:29:03.156863
# Unit test for function main
def test_main():
    assert fix_command.__name__ == 'fix_command'

# Generated at 2022-06-22 00:29:03.756278
# Unit test for function main
def test_main():
    assert main()==None

# Generated at 2022-06-22 00:29:12.855344
# Unit test for function main
def test_main():
    try:
        from unittest.mock import patch  # noqa: F401
    except ImportError:
        from mock import patch  # noqa: F401
    from thefuck.shells import _get_aliases  # noqa: F401

    class args:
        pass

    # Running `thefuck --help`
    args.help = True
    with patch('thefuck.main.Parser') as Parser,\
            patch('thefuck.main.parser.parse') as parse:

        parse.return_value = args
        main()

    Parser.assert_called_once()
    parse.assert_called_once()
    Parser.return_value.print_help.assert_called_once()

    # Running `thefuck --version`
    args.help = False
    args.version = True

# Generated at 2022-06-22 00:29:16.987301
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help == False
    assert known_args.version ==False
    assert known_args.alias == False
    assert known_args.shell_logger == False
    #assert known_args.explain == False
    #assert known_args.settings == False
    #assert known_args.no_colors == False 
    #assert known_args.wait == False 
    #assert known_args.dry_run == False
    #assert known_args.n == False
    #assert known_args.require_confirmation == False
    #assert known_args.repeat == False
    #assert known_args.eval == False
    #assert known_args.fuck 
    #assert known_args.with_hook == None



# Generated at 2022-06-22 00:29:17.633379
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:34.010692
# Unit test for function main
def test_main():
    assert Parser()

# Generated at 2022-06-22 00:29:36.494150
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:45.454876
# Unit test for function main
def test_main():
    from . import main
    from . import test_fix_command
    from thefuck.shells.bash import Bash
    from thefuck.shells.common import Shell
    from thefuck.utils import wrap_settings
    from thefuck.shells.zsh import Zsh
    from thefuck.shells.powershell import Powershell
    from thefuck.shells.fish import Fish
    from thefuck.shells.cmd import Cmd
    from thefuck.shells.xonsh import Xonsh
    argv = ['thefuck', '--help']

# Generated at 2022-06-22 00:29:53.664990
# Unit test for function main
def test_main():
    sys.argv = ['thefuck']
    logs.clear()
    main()

# Generated at 2022-06-22 00:29:55.670537
# Unit test for function main
def test_main():
    parser = Parser()
    args = parser.parse(['fuck', 'ls'])
    main()

# Generated at 2022-06-22 00:29:56.280688
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:30:08.590815
# Unit test for function main
def test_main():
    import sys
    import os
    import mock
    import textwrap

    from argparse import ArgumentParser

    from ..argument_parser import CommandParser
    from .. import config
    from .. import logs
    from .. import utils
    from ..config import get_version

    main_help = 'thefuck [OPTIONS] [COMMAND]'

    @mock.patch.object(ArgumentParser, "exit")
    def test_help(exit):
        """
        Checks that `thefuck --help` outputs expected text
        """
        sys.argv = ['thefuck', '--help']
        main()

# Generated at 2022-06-22 00:30:09.311003
# Unit test for function main
def test_main():
    # If a fix is found, return True
    assert True

# Generated at 2022-06-22 00:30:10.617623
# Unit test for function main
def test_main():
    import pytest
    with pytest.raises(SystemExit):
        main()

# Generated at 2022-06-22 00:30:12.582895
# Unit test for function main
def test_main():
    class fake_args:
        alias = None
        command = None
        help = None
        version = None
        shell_logger = None
    assert main(fake_args) is None

# Generated at 2022-06-22 00:30:46.623766
# Unit test for function main
def test_main():
    # Line below will check whether the function is working properly
    assert main() == None

# Generated at 2022-06-22 00:30:50.090055
# Unit test for function main
def test_main():
    class MockKnownArgs:
        help = False
        version = False
        alias = ""
        command = ""
        shell_logger = False

    known_args = MockKnownArgs()
    main(known_args)


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:30:50.701432
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:31:03.196814
# Unit test for function main
def test_main():
    from io import StringIO
    from unittest.mock import patch
    from ..argument_parser import parse_known_args
    from ..logs import debug
    from ..utils import get_installation_info
    from ..shell_logger import shell_logger

    from .shells import COMMAND_ERRORS

    @patch('argparse.ArgumentParser.print_usage')
    @patch('sys.argv', ['thefuck'])
    @patch('sys.stdout', new_callable=StringIO)
    def print_usage(mocked_stdout):
        main()
        assert 'Usage: thefuck' in mocked_stdout.getvalue()


# Generated at 2022-06-22 00:31:03.669807
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:31:04.270893
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:31:15.794816
# Unit test for function main
def test_main():
    try:
        import mock  # noqa: E402
    except ImportError:
        import builtins  # noqa: E402

        def mock(*args, **kwargs):  # noqa: E402
            class _mock:
                def __init__(self, *args, **kwargs):
                    pass

                def __call__(self, *args, **kwargs):
                    return _mock()

                @classmethod
                def __getattr__(cls, name):
                    if name in ('__file__', '__path__'):
                        return '/dev/null'
                    elif name[0] == name[0].upper():
                        mockType = type(name, (), {})
                        mockType.__module__ = __name__
                        return mockType
                    else:
                        return _mock()
            return

# Generated at 2022-06-22 00:31:16.303418
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:31:16.867406
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:31:19.315747
# Unit test for function main
def test_main():
    #running the function main
    main()

# Generated at 2022-06-22 00:32:27.194607
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-22 00:32:29.071102
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--version']
    main()
    assert 1

# Generated at 2022-06-22 00:32:40.535972
# Unit test for function main
def test_main():
    # Test 1
    args_1 = Parser().parse(['thefuck'])
    assert type(args_1) == argparse.Namespace
    assert args_1.init == False
    assert args_1.alias == None
    assert args_1.command == None
    assert args_1.shell_logger == None
    assert args_1.version == False
    assert args_1.help == False

    # Test 2
    args_2 = Parser().parse(['thefuck', 'syntaxerror', 'saying', 'goodbye'])
    assert type(args_2) == argparse.Namespace
    assert args_2.init == False
    assert args_2.alias == None
    assert args_2.command == 'syntaxerror saying goodbye'
    assert args_2.shell_logger == None

# Generated at 2022-06-22 00:32:41.143083
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-22 00:32:41.938035
# Unit test for function main
def test_main():
     main()

# Generated at 2022-06-22 00:32:42.491832
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:32:53.463799
# Unit test for function main
def test_main():
    class  Mock():
        def __init__(self, args):
            self.args = args
        def parse(self, args):
            known_args = Mock()
            known_args.help = False
            known_args.version = False
            known_args.alias = False
            known_args.command = False
            known_args.shell_logger = False
            return known_args
        def print_help(self):
            assert True
        def print_usage(self):
            assert True
    class Logs():
        def version(self, version, version_py, version_shell):
            assert True
        def warn(self, args):
            assert True

# Generated at 2022-06-22 00:32:54.141878
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:32:55.324483
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-22 00:32:56.817517
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:35:40.941149
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-22 00:35:50.938119
# Unit test for function main
def test_main():
    g = globals()
    del g['__builtins__']
    import sys
    import os
    import time
    import re

    with open('test_main.py', 'w') as f:
        f.write(
'''
if __name__ == '__main__':
    print('__main__')
'''
        )

    sys.argv = ['./thefuck', 'python test_main.py']
    with open('test.log', 'w') as f:
        g['logs']._print = lambda x, **kw: f.write(x + '\n')
        g['init_output']()
        g['Parser'].parse = lambda x: lambda x, y: (lambda x: x)(x)
        g['print_alias'] = lambda x: None

# Generated at 2022-06-22 00:35:51.503755
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:35:52.849610
# Unit test for function main
def test_main():
    assert main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:36:05.334883
# Unit test for function main
def test_main():
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from ..utils import get_installation_info
    from unittest.mock import patch
    import thefuck
    import io

    known_args = Parser().parse(['-v'])
    logs_version = thefuck.logs.version

    with patch('sys.stdout', new=io.StringIO()) as mock_stdout:
        main()
    assert mock_stdout.getvalue().strip() == logs_version(get_installation_info().version, 'Python 3.6.7', 'zsh')

    with patch('thefuck.logs.version', return_value=None) as mock_logs_version:
        main()

# Generated at 2022-06-22 00:36:07.294329
# Unit test for function main
def test_main():
    return os.system("./tests/func_tests/test_main.sh")

# Generated at 2022-06-22 00:36:08.682595
# Unit test for function main
def test_main():
    assert main()==None

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:36:17.030478
# Unit test for function main
def test_main():
    logs.version = lambda v, p, s: True
    parser = Parser()
    command_arg = 'thefuck --version'
    os.system(command_arg)
    os.system(command_arg)
    os.system(command_arg)
    os.system(command_arg)
    os.system(command_arg)
    os.system(command_arg)
    
    known_args = parser.parse(sys.argv)
    return known_args

# Generated at 2022-06-22 00:36:17.616470
# Unit test for function main
def test_main():
    assert main

# Generated at 2022-06-22 00:36:18.753515
# Unit test for function main
def test_main():
    main()
    assert(True)