

# Generated at 2022-06-22 00:27:25.908654
# Unit test for function main
def test_main():
    # TODO: Add a unit test for this function
    pass

# Generated at 2022-06-22 00:27:37.096728
# Unit test for function main
def test_main():
    from ..exceptions import FailedCommand
    from .alias import print_alias
    from .shell_logger import shell_logger
    from thefuck.exceptions import FixFailed

    main_stub = StubSource(main, returns=0)
    sys.argv = ['./thefuck']

    assert main_stub().exception is None
    assert main_stub().return_value == 0

    sys.argv = ['./thefuck', '--alias']
    print_alias_stub = StubSource(print_alias, returns=0)

    assert main_stub().exception is None
    assert main_stub().return_value == 0
    print_alias_stub.assert_called(known_args=print_alias_stub.args[0])


# Generated at 2022-06-22 00:27:47.278151
# Unit test for function main
def test_main():
    import sys
    import os

    _original = sys.argv

    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = _original

    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = _original

    sys.argv = ['thefuck', 'echo']
    main()
    sys.argv = _original

    os.environ['TF_HISTORY'] = 'echo'
    sys.argv = ['thefuck']
    main()
    sys.argv = _original

    sys.argv = ['thefuck', '--alias']
    main()
    sys.argv = _original

    sys.argv = ['thefuck', '--shell-logger']
    main()
    sys.argv = _original



# Generated at 2022-06-22 00:27:47.902929
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:27:58.037772
# Unit test for function main
def test_main():
    from .logs import Logs
    from .argument_parser.parser import Parser
    from ..utils import get_installation_info
    from ..shells import ShellInfo
    from .alias import alias
    from .fix_command import fix
    from random import random

    def mock_print_help():
        pass

    def mock_print_usage():
        pass

    def reset_functions(mock_logs, mock_parser, mock_get_installation_info, mock_shell_info, mock_alias, mock_fix):
        logs.version = mock_logs.version
        parser.parse = mock_parser.parse
        get_installation_info.info = mock_get_installation_info.info
        shell.info = mock_shell_info.info
        print_alias = mock_alias.print_alias


# Generated at 2022-06-22 00:27:58.679564
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:28:00.414219
# Unit test for function main
def test_main():
    from . import __main__ as main
    main.main()

# Generated at 2022-06-22 00:28:12.346820
# Unit test for function main
def test_main():
    global sys
    sys = Mock()
    tf = thefuck()
    tf.init_output()
    tf.init_logs()
    tf.init_sentry()
    tf.init_memory_checker()
    tf.init_monorepo_checker()
    tf.init_shelve()
    tf.main()
    assert tf.shell.logs_to_stdout == tf.settings.log_to_console
    assert tf.shell.logs_to_stdout is True
    assert tf.shell.priority_aliases == []
    assert tf.shell.name == "bash"
    assert tf.settings.history_limit == 1000
    assert tf.settings.wait_command == 1
    tf.logs.version("3.23.1", "3.7.2", "bash")
    tf

# Generated at 2022-06-22 00:28:12.935731
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:28:13.586025
# Unit test for function main
def test_main():
    assert main

# Generated at 2022-06-22 00:28:22.743925
# Unit test for function main
def test_main():
    assert main

# Generated at 2022-06-22 00:28:24.956667
# Unit test for function main
def test_main():
    import pytest
    args = ['-v']
    main(args)
    #version = ['-V']
    #main(version)



# Generated at 2022-06-22 00:28:25.601259
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:28:36.295877
# Unit test for function main
def test_main():
    # Testing with no arguments passed
    parser = Parser()
    assert parser.parse(sys.argv) == parser.parse(['thefuck'])
    # Testing with '-h' passed
    assert parser.parse(['thefuck', '-h']) == parser.parse(['thefuck'])
    # Testing with '--help' passed
    assert parser.parse(['thefuck', '--help']) == parser.parse(['thefuck'])
    # Testing with '-v' passed
    assert parser.parse(['thefuck', '-v']) == parser.parse(['thefuck', '--version'])
    # Testing with '--version' passed
    assert parser.parse(['thefuck', '--version']) == parser.parse(['thefuck', '--version'])
    # Testing with '-s' passed


# Generated at 2022-06-22 00:28:44.137256
# Unit test for function main
def test_main():
    parser = Parser()
    test_args = parser.parse(["python", "-c", "ls --l"])

    stderr = sys.stderr
    stdout = sys.stdout
    sys.stderr = logs.silenced
    sys.stdout = logs.silenced

    try:
        main()
    except SystemExit:
        pass

    sys.stderr = stderr
    sys.stdout = stdout

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:28:46.217890
# Unit test for function main
def test_main():
    log_str = "" 
    print(log_str)
    assert log_str == ""

# Generated at 2022-06-22 00:28:47.689332
# Unit test for function main
def test_main():
    assert(main())


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:28:59.622474
# Unit test for function main
def test_main():
    capture = logs.capture()
    main()
    assert capture.getvalue().strip() == 'usage: thefuck [-h] [--version]\n              ' \
                                         '[--alias [ALIAS]] [--quiet | --no-colors]\n              ' \
                                         '[--require-confirmation | --no-require-confirmation]\n              ' \
                                         '[--rules RULES] [--shell SHELL] ' \
                                         '[--shell-logger] [--pyeval PYEVAL | --not-pyeval]\n              ' \
                                         '[--history-size HISTORY_SIZE] [--separate-stderr]\n              ' \
                                         '[--wait WAIT] [--fuck [COMMAND [ARGS [ARGS ...]]]]\n' \
                                         '\n'

# Generated at 2022-06-22 00:29:01.016157
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        main()

# Generated at 2022-06-22 00:29:02.097896
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:29.860501
# Unit test for function main
def test_main():
    from ..system import is_exists
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    main_test = main
    mock_parser = Parser(FakeNamespace(help=False, version=False, command=False, alias=[],
                                       shell_logger=None, no_colors=False, use_colors=False,
                                       iterm2_integration=False))
    mock_parser.parse = lambda args: mock_parser.add_argument('fake_command')
    main_test._parser = mock_parser
    main_test()
    mock_parser.parse = lambda args: mock_parser.add_argument('-v')
    main_test._parser = mock_parser
    main_test()
    mock_parser.parse

# Generated at 2022-06-22 00:29:31.042070
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-22 00:29:32.493716
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:33.170881
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:29:43.814830
# Unit test for function main
def test_main():
    from unittest import mock
    from . import tests
    from .tests import parser
    from .tests import run
    from .tests import print_alias
    sys.argv = ['thefuck', '--version']
    with mock.patch('sys.argv', sys.argv):
        with mock.patch('thefuck.main.get_installation_info') as get_installation_info:
            with mock.patch('thefuck.main.logs.version') as version:
                with mock.patch('thefuck.main.shell.info') as info:
                    main()
    assert get_installation_info.called
    assert version.called
    assert info.called
    sys.argv = ['thefuck', '--help']

# Generated at 2022-06-22 00:29:44.617696
# Unit test for function main
def test_main():
	pass

# Generated at 2022-06-22 00:29:45.938136
# Unit test for function main
def test_main():
    # TODO fix this test
    assert main() == None

# Generated at 2022-06-22 00:29:47.568166
# Unit test for function main
def test_main():
    # Usage:
    assert main() is None


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:48.717693
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:50.964486
# Unit test for function main
def test_main():
    args = Parser().parse(['fuck'])
    main(args)

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:30:25.156511
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:30:25.708467
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:30:26.296930
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:30:27.004427
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:30:29.616791
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--help']
    assert main()
    sys.argv = ['thefuck', '--version']
    assert main()

# Generated at 2022-06-22 00:30:30.206242
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:30:30.787557
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:30:34.573191
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-22 00:30:38.732948
# Unit test for function main
def test_main():
    assert main( ) == None

if __name__ == '__main__':
    main()
    '''
    def test_main():
        assert main( ) == None
    '''

# Generated at 2022-06-22 00:30:47.819113
# Unit test for function main
def test_main():
    parser = Parser()
    sys.argv.append("--help")
    parser.parse(sys.argv)
    sys.argv.append("--version")
    parser.parse(sys.argv)
    sys.argv.append("--debug")
    parser.parse(sys.argv)
    sys.argv.append("--alias")
    parser.parse(sys.argv)
    sys.argv.append("--command")
    parser.parse(sys.argv)
    sys.argv.append("--shell-logger")
    parser.parse(sys.argv)
    parser.print_usage()

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:31:59.025161
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:32:00.477457
# Unit test for function main
def test_main():
    assert main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:32:02.191450
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:13.541374
# Unit test for function main
def test_main():
    import sys
    import unittest
    import unittest.mock
    from .fix_command import fix_command
    from .alias import print_alias
    from .shell_logger import shell_logger
    from io import StringIO
    from ..system import init_output
    init_output()

    class MainTestCase(unittest.TestCase):
        def tearDown(self):
            unittest.mock.patch(target='sys.stdout', new=sys.__stdout__).stop()
            unittest.mock.patch(target='sys.argv', new=sys.argv).stop()


# Generated at 2022-06-22 00:32:20.748913
# Unit test for function main
def test_main():
    test_args = ['--alias', '--version', '--help', '--shell-logger=bash']
    for arg in test_args:
        arg_list = arg.split('=')
        main_args = ['thefuck'] + arg_list
        with logs.capture_output() as captured:
            sys.argv = main_args
            main()
            captured_text = captured.getvalue()
            assert arg in captured_text


# Generated at 2022-06-22 00:32:21.354395
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:32:32.903588
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help == parser.print_help()
    assert known_args.version == logs.version(get_installation_info().version,
                                              sys.version.split()[0], shell.info())
    assert known_args.alias == print_alias(known_args)
    assert known_args.command or 'TF_HISTORY' in os.environ == fix_command(known_args)
    assert known_args.shell_logger == shell_logger(known_args.shell_logger)
    assert known_args.verbose == None
    assert known_args.rules == None
    assert known_args.script == None
    assert known_args.exclude == None

# Generated at 2022-06-22 00:32:37.874447
# Unit test for function main
def test_main():

    # Test 1
    sys.argv[1:] = ['fuck']
    main()
    assert True

    # Test 2
    sys.argv[1:] = ['-v']
    main()
    assert True

    # Test 3
    sys.argv[1:] = ['--version']
    main()
    assert True

# Generated at 2022-06-22 00:32:38.445652
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-22 00:32:45.910963
# Unit test for function main
def test_main():
    with patch('sys.argv', ['thefuck', '--alias', 'fuck']):
        with patch('thefuck.main.print_alias') as print_aliases:
            main()
            print_aliases.assert_called_once()

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.main.sys.version.split', return_value=['11.0.0']) as version_split:
            with patch('thefuck.main.shell.info', return_value=['fish']) as shell_info:
                with patch('thefuck.main.os.environ.get', return_value='1.5.5') as installation_info:
                    with patch('thefuck.main.logs.version') as version:
                        main()
                        version_split.assert_

# Generated at 2022-06-22 00:35:35.349449
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-22 00:35:40.645068
# Unit test for function main
def test_main():
    # This object is used with pytest fixture
    e = Exception()
    e.output = "pytest"
    assert known_args.command or 'TF_HISTORY' in os.environ

# Generated at 2022-06-22 00:35:50.694233
# Unit test for function main
def test_main():

    import sys

    # Test for command with posix shell
    sys.argv = ['thefuck', 'command','--shell=posix']
    with mock.patch('sys.stdout') as mock_out:
        main()
        assert mock_out.write.call_count == 2
        assert mock_out.write.call_args[0][0] == 'thefuck'

    # Test for shell logger with zsh shell
    sys.argv = ['thefuck', '--shell-logger=zsh']
    with mock.patch('sys.stdout') as mock_out:
        main()
        assert mock_out.write.call_count == 2
        assert mock_out.write.call_args[0][0] == 'thefuck'

    # Test for alias with zsh shell

# Generated at 2022-06-22 00:36:02.923528
# Unit test for function main
def test_main():
    known_args = namedtuple('NoValue', [])
    with patch('{}.Parser.parse'.format(__name__), return_value=known_args,
               autospec=True) as parse_mock, \
         patch('{}.print_alias'.format(__name__)) as print_alias_mock, \
         patch('{}.fix_command'.format(__name__)) as fix_command_mock, \
         patch('{}.shell_logger'.format(__name__)) as shell_logger_mock, \
         patch('{}.os.environ.get'.format(__name__), return_value=None):
        main()
        parse_mock.assert_has_calls([call(sys.argv)])
        print_alias_mock.assert_not_called()
        fix

# Generated at 2022-06-22 00:36:03.281093
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:36:03.690883
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:36:04.653676
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-22 00:36:07.017344
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = 'history'
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:36:07.623113
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:36:12.600586
# Unit test for function main
def test_main():
    from ..utils import is_on_mac_os as test_is_on_mac_os

    assert callable(main) is True
    assert main() is None

    if test_is_on_mac_os():
        assert main('--shell-logger=bash') is None