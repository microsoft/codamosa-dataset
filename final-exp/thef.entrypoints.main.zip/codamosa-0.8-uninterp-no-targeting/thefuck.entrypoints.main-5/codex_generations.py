

# Generated at 2022-06-22 00:27:25.535125
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:27:35.382719
# Unit test for function main
def test_main():
    # create a file with history in it
    command_history_file = open('test_command_history', 'w')
    command_history_file.write('sudo apt-get install blah blah\n')
    command_history_file.close()
    sys.argv = ['thefuck', '--hist-file=test_command_history']
    main()
    command_history_file = open('test_command_history', 'r')
    file_contents = command_history_file.readlines()
    assert file_contents[0] == 'sudo apt-get install blah blah\n'
    # if this is correct, then main() worked correctly
    os.remove('test_command_history')

# Generated at 2022-06-22 00:27:35.964619
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:27:46.633422
# Unit test for function main
def test_main():
    from .test_history import HistoryMock

    history = HistoryMock()
    history.add_command('echo test')

    parser = Parser()
    known_args = parser.parse(['fuck'])
    assert known_args.help == False
    assert known_args.version == False
    assert known_args.alias == False
    assert known_args.command == False
    assert known_args.shell_logger == False

    known_args = parser.parse(['fuck', '--help'])
    assert known_args.help == True
    assert known_args.version == False
    assert known_args.alias == False
    assert known_args.command == False
    assert known_args.shell_logger == False

    known_args = parser.parse(['fuck', '--version'])

# Generated at 2022-06-22 00:27:57.111857
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from pathlib import Path
    from .fix_command import FixCommand  # noqa: E402
    from .alias import print_alias  # noqa: E402
    from .shell_logger import shell_logger  # noqa: E402

    with patch('sys.argv', ['thefuck']):
        main()

    with patch('sys.argv', ['thefuck', '--help']):
        main()

    with patch('sys.argv', ['thefuck', '-v']):
        main()

    alias = 'alias fuck=\'eval $(thefuck $(fc -ln -1))\''

# Generated at 2022-06-22 00:27:57.596736
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:28:00.151784
# Unit test for function main
def test_main():  # noqa: D103,W0212
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:28:12.140918
# Unit test for function main
def test_main():
    from unittest import mock
    from thefuck.utils import get_installation_info


# Generated at 2022-06-22 00:28:13.635715
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:28:14.390424
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:28:33.155706
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    if known_args.help:
        return True
    elif known_args.version:
        return get_installation_info().version
    elif known_args.alias:
        return print_alias(known_args)
    elif known_args.command or 'TF_HISTORY' in os.environ:
        return fix_command(known_args)
    elif known_args.shell_logger:
        try:
            from .shell_logger import shell_logger  # noqa: E402
        except ImportError:
            return False
        else:
            return shell_logger(known_args.shell_logger)
    else:
        return False

# Generated at 2022-06-22 00:28:38.200203
# Unit test for function main
def test_main():
    import sys
    import pytest # noqa: E402

    with pytest.raises(SystemExit) as e:
        sys.argv = ["thefuck"]
        main()

    assert e.value.code is None

    with pytest.raises(SystemExit) as e:
        sys.argv = ["thefuck", "--version"]
        main()

    assert e.value.code is None

    with pytest.raises(SystemExit) as e:
        sys.argv = ["thefuck", "--alias", "fuck"]
        main()

    assert e.value.code is None

    with pytest.raises(SystemExit) as e:
        sys.argv = ["thefuck", "--shell-logger", "fish"]
        main()

    assert e.value.code is None



# Generated at 2022-06-22 00:28:49.590572
# Unit test for function main
def test_main():
    from .argument_parser import Parser
    from .fix_command import fix_command as mock_fix_command, Command
    from .alias import print_alias as mock_print_alias
    for action, args in [
        (None, sys.argv),
        ('--help', sys.argv),
        ('--version', sys.argv),
        ('--alias', sys.argv),
        ('', ['fuck']),
        ('--shell-logger', ['fuck', '--shell-logger'])]:
        known_args = Parser().parse(args)

# Generated at 2022-06-22 00:29:01.063038
# Unit test for function main
def test_main():
    import shutil

# Generated at 2022-06-22 00:29:03.110456
# Unit test for function main
def test_main():
    sys.argv = ['thefuck','--alias','fuck']
    main()

# Generated at 2022-06-22 00:29:03.757687
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:29:05.131842
# Unit test for function main
def test_main():
    assert main() == ("a.argv : %s", sys.argv)

# Generated at 2022-06-22 00:29:05.760184
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:29:07.017109
# Unit test for function main
def test_main():
    assert main() == 0
    assert main() == -1

# Generated at 2022-06-22 00:29:08.021909
# Unit test for function main
def test_main():
    main()
    main(command = "fuck")

# Generated at 2022-06-22 00:29:25.912527
# Unit test for function main
def test_main():
    main_func = main()
    assert main_func == None

# Generated at 2022-06-22 00:29:29.051440
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = ''
    main()
    assert (str(main.__doc__) in open("README.md").read())

# Generated at 2022-06-22 00:29:29.725613
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-22 00:29:30.532992
# Unit test for function main
def test_main():
	main()

# Generated at 2022-06-22 00:29:31.166557
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:32.591151
# Unit test for function main
def test_main():
    sys.argv = ["fuck", "hello"]
    main()

# Generated at 2022-06-22 00:29:37.660322
# Unit test for function main
def test_main():
    args = 'fuck --help'
    parser = Parser()
    known_args = parser.parse(args.split())
    assert known_args.help
    logs.debug("Test PASSED")

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:29:38.114832
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:29:50.249238
# Unit test for function main
def test_main():
    from .shells import bash, get_shell as fake_get_shell
    from .shells.generic import get_history as fake_get_history
    from .shells.generic import And, Or, pip_install
    from .types import NewCommand, Command

    from .alias import print_alias
    from .fix_command import print_result, print_results, print_history

    command = 'ls'

    # If no command is given, prints just usage
    def fake_parser_print_usage():
        assert True

    parser = Parser()
    parser.print_usage = fake_parser_print_usage
    parser.parse(['thefuck', 'some_random_arg'])

    # If alias is requested, prints alias
    print_alias_calls = []

    def fake_print_alias(known_args):
        print

# Generated at 2022-06-22 00:30:01.616543
# Unit test for function main
def test_main():
    def replace_argv(args):
        sys.argv = [sys.argv[0]] + args

    def restore_argv():
        sys.argv = sys.argv[:1]

    import subprocess

    try:
        replace_argv([])
        main()
        assert True
    except SystemExit as e:
        print(e.code)
        assert e.code == 2
    finally:
        restore_argv()

    try:
        replace_argv(['--version'])
        main()
        assert True
    except SystemExit as e:
        print(e.code)
        assert e.code == 0
    finally:
        restore_argv()


# Generated at 2022-06-22 00:30:34.977586
# Unit test for function main
def test_main():
  assert main() is None

# Generated at 2022-06-22 00:30:45.786317
# Unit test for function main
def test_main():
    import unittest.mock as mock  # noqa: E402
    main()
    assert '--help\n' in sys.stdout.getvalue()
    parser = Parser()
    known_args = parser.parse(['--version'])
    main()
    assert '--help\n' in sys.stdout.getvalue()
    known_args = parser.parse(['--alias'])
    main()
    assert '--help\n' in sys.stdout.getvalue()
    os.environ['TF_HISTORY'] = 'true'
    main()
    assert '--help\n' in sys.stdout.getvalue()
    assert mock.call in logs.warn.mock_calls

# Generated at 2022-06-22 00:30:53.622864
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .shell_logger import shell_logger
    from .fix_command import fix_command
    cli_parser = Parser()
    cli_parser.add_argument('--version', action='store_true')
    cli_parser.add_argument('--alias', action='store_true')
    cli_parser.add_argument('--shell-logger', action='store_true')
    cli_parser.add_argument('--debug', action='store_true')
    cli_parser.add_argument('-e', '--no-execute', action='store_true')
    cli_parser.add_argument('-l', '--list', action='store_true')

# Generated at 2022-06-22 00:31:05.075596
# Unit test for function main
def test_main():
    from .shell_logger import execution_logger
    from .shell_logger import restore_logger
    from unittest import TestCase
    from mock import patch
    from time import strptime
    from time import mktime
    class Test_Main(TestCase):
        def setUp(self):
            self.execute = execution_logger('history.log')
            self.restore = restore_logger('history.log')
        def test_logger(self):
            self.execute.export_env()
            self.assertEqual(self.execute.log_file_name, "history.log")
        def test_restore_logger(self):
            self.restore.restore_env()
            self.assertEqual(os.environ.get("TF_HISTORY"), None)

# Generated at 2022-06-22 00:31:06.460466
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:31:16.951275
# Unit test for function main
def test_main():
    import os

    if 'TF_HISTORY' in os.environ:
        del os.environ['TF_HISTORY']

    class KnownArgs(object):
        pass

    known_args = KnownArgs()
    known_args.version = True
    main()
    known_args.version = False
    main()
    known_args.alias = True
    main()
    known_args.alias = False
    main()
    known_args.help = True
    main()
    known_args.help = False
    known_args.shell_logger = "zsh"
    main()
    known_args.shell_logger = False
    main()
    import sys
    sys.argv.append("echo test")
    main()

# Generated at 2022-06-22 00:31:18.087892
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-22 00:31:29.717720
# Unit test for function main
def test_main():
    # test for print_help()
    sys.argv = ['thefuck', '--help']

# Generated at 2022-06-22 00:31:31.044668
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:31:32.711492
# Unit test for function main
def test_main():
    main()
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:32:52.788313
# Unit test for function main
def test_main():
    class known_args:
        def __init__(self):
            self.alias = False
            self.help = False
            self.version = False
            self.command = False
            self.shell_logger = False
    known_args = known_args()
    main()

    sys.argv[1] = "--help"
    main()

    sys.argv[1] = "--version"
    main()

    sys.argv[1] = "--alias"
    main()

    sys.argv[1] = "--shell-logger"
    main()
    sys.argv[2] = "zsh"
    main()

    # Check with known command
    sys.argv = ['thefuck','fetch']
    os.environ['TF_HISTORY'] = "1"
   

# Generated at 2022-06-22 00:32:54.140736
# Unit test for function main
def test_main():
    assert main() == 'print_usage'

# Generated at 2022-06-22 00:32:54.678177
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:32:56.464009
# Unit test for function main
def test_main(): 
    assert main() == None

# Generated at 2022-06-22 00:32:58.548551
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()

# Generated at 2022-06-22 00:33:09.557933
# Unit test for function main
def test_main():
    """Initiate main function test"""
    from .mock_subprocess import mock_subprocess  # noqa: E402
    from .mock_subprocess import MockSubprocess  # noqa: E402
    from .mock_subprocess import subprocess_output  # noqa: E402
    from thefuck.const import VERSION  # noqa: E402
    import tempfile  # noqa: E402
    import argparse  # noqa: E402
    import subprocess  # noqa: E402
    import shutil  # noqa: E402
    import textwrap  # noqa: E402
    import contextlib  # noqa: E402


# Generated at 2022-06-22 00:33:10.180571
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:33:12.070589
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-22 00:33:12.715696
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:33:14.886577
# Unit test for function main
def test_main():
  try:
    from .utils import get_installation_info  # noqa: E402
  except ImportError:
    print(True)
  return True

# Generated at 2022-06-22 00:36:02.124464
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:36:02.697585
# Unit test for function main
def test_main():
    main()
    assert True

# Generated at 2022-06-22 00:36:03.762247
# Unit test for function main
def test_main():
    assert main() == None


# Generated at 2022-06-22 00:36:04.333354
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-22 00:36:04.962327
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-22 00:36:07.564958
# Unit test for function main
def test_main():
    """
    This test is to test if the main function can return the right message.
    """
    sys.argv = ['thefuck', '--version']
    try:
        main()
    except SystemExit as exception:
        assert exception.code == 0

# Generated at 2022-06-22 00:36:08.148970
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:36:08.724743
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-22 00:36:11.740531
# Unit test for function main
def test_main():
    #main()
    pass

if __name__ == '__main__':
    test_main()

# Generated at 2022-06-22 00:36:12.790197
# Unit test for function main
def test_main():
    assert True
