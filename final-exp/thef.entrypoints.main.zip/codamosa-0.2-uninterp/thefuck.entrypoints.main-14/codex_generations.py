

# Generated at 2022-06-18 06:57:10.475472
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:10.892696
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:11.306145
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:11.724020
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.181233
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.595095
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.144097
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.631343
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.108618
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.573724
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:40.149239
# Unit test for function main
def test_main():
    import sys
    from unittest.mock import patch
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .. import logs
    from ..system import init_output
    init_output()
    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.argument_parser.Parser.print_help') as mock_print_help:
            main()
            assert mock_print_help.called
    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.logs.version') as mock_version:
            main()
           

# Generated at 2022-06-18 06:57:40.616399
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:41.070754
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:41.520324
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:48.000521
# Unit test for function main
def test_main():
    import sys
    import os
    import subprocess
    import tempfile
    import shutil
    import unittest
    import unittest.mock

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.temp_dir = tempfile.mkdtemp()
            self.temp_file = os.path.join(self.temp_dir, 'temp_file')
            self.temp_file_content = 'temp_file_content'
            with open(self.temp_file, 'w') as f:
                f.write(self.temp_file_content)

        def tearDown(self):
            shutil.rmtree(self.temp_dir)


# Generated at 2022-06-18 06:57:48.373793
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:48.753281
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:49.187532
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:49.575820
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:50.309975
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:08.257447
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:08.721776
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:09.187478
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:09.611876
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:10.008832
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:11.000747
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:11.635323
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:12.234979
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:12.716672
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:13.287736
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:50.707655
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:51.248134
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:51.710778
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:52.387366
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:52.792023
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:53.274273
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:59.361303
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--alias', 'fuck']
    main()
    sys.argv = ['thefuck', '--shell-logger', 'bash']
    main()
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    os.environ['TF_HISTORY'] = 'ls'
    main()

# Generated at 2022-06-18 06:58:59.779517
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:03.859411
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for usage
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:59:04.269705
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:18.214350
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:18.684981
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:19.122420
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:19.546960
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:20.319972
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:20.723230
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:27.848596
# Unit test for function main
def test_main():
    import sys
    import os
    import io
    from unittest.mock import patch
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from ..system import init_output
    from .. import logs

    init_output()

    # Test for help
    with patch.object(sys, 'argv', ['thefuck', '--help']):
        with patch.object(Parser, 'print_help') as mock_print_help:
            main()
            mock_print_help.assert_called_once()

    # Test for version

# Generated at 2022-06-18 07:00:28.285247
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:28.712368
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:29.126015
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:01.943140
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:02.372249
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:02.889017
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:03.346074
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:03.797429
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:04.197615
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:04.667803
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:05.884056
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:06.351504
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:06.816523
# Unit test for function main
def test_main():
    assert main() == None