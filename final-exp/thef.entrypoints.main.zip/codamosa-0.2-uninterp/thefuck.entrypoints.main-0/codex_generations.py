

# Generated at 2022-06-18 06:57:18.050080
# Unit test for function main
def test_main():
    import os
    import sys
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import Mock
    from unittest.mock import call
    from unittest.mock import ANY
    from unittest.mock import DEFAULT
    from unittest.mock import create_autospec
    from unittest.mock import PropertyMock
    from unittest.mock import sentinel

    parser = Parser()

# Generated at 2022-06-18 06:57:18.525212
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:18.953533
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.094955
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()

    # Test for version
    sys.argv = ['thefuck', '--version']
    main()

    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()

    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()

    # Test for command
    sys.argv = ['thefuck', 'command']
    main()

# Generated at 2022-06-18 06:57:24.575073
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.080879
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.590061
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.145872
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.621511
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:27.134099
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.373971
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.855617
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:38.164541
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:38.632351
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:39.229120
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:39.704486
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:40.150077
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:40.615685
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:41.071367
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:41.520872
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:59.900961
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:00.264004
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:00.632795
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:01.006139
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.004569
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.437504
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:03.395991
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:04.141860
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:04.608787
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:05.065729
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:41.607299
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:42.059737
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:42.803904
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:43.320560
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:43.774700
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:44.420566
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:44.890087
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:45.352338
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:45.952951
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:52.858807
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for no argument
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 07:00:07.287273
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:07.981125
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:08.852081
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:09.417142
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:09.829453
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:10.333815
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:00:10.762103
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:11.182771
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:11.577250
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:12.058779
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:46.744340
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:47.229748
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:48.002737
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:48.507032
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:48.991904
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:56.724888
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command


# Generated at 2022-06-18 07:02:57.101852
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:57.509688
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:57.911874
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:02:58.326107
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:33.821638
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:34.337358
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:05:34.798210
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:35.238852
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:35.718286
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:36.544623
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:37.028156
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:05:37.575750
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:05:43.669050
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    with patch('thefuck.main.Parser') as mock_parser:
        mock_parser.return_value.parse.return_value = \
            mock_parser.return_value.parse.return_value = \
            mock_parser.return_value.parse.return_value = \
            mock_parser.return_value.parse.return_value = \
            mock_parser.return_value.parse.return_value = \
            mock_parser.return_value.parse.return_value = \
            mock_parser.return_value.parse.return_value = \
            mock

# Generated at 2022-06-18 07:05:44.041640
# Unit test for function main
def test_main():
    assert main() == None