

# Generated at 2022-06-18 06:56:59.310351
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:59.666337
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:00.132642
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:01.134949
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:01.532645
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:01.961239
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:02.312622
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:02.680985
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:03.033733
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:03.434473
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.342186
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.814704
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:21.328423
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:21.787514
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:22.185491
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:22.778019
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:23.548864
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.068280
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.540523
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.041531
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:59.266641
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:59.898846
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:00.264259
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:00.720850
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:01.120076
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.034113
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.467830
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:03.455344
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:04.145428
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:04.676813
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:15.580046
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:15.959427
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:23.876036
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger

    with patch('sys.argv', ['thefuck']):
        with patch('thefuck.argument_parser.Parser.parse') as parse:
            parse.return_value = Parser().parse(['thefuck'])
            with patch('thefuck.argument_parser.Parser.print_usage') as print_usage:
                main()
                assert print_usage.called


# Generated at 2022-06-18 06:59:24.279772
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:24.774395
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:25.180354
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:25.616888
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:59:26.190661
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:26.585344
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:27.024223
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:52.457500
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:53.649191
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:54.750702
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:55.233372
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:55.661964
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:56.122351
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:56.618747
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:57.092999
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:57.504187
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:58.169495
# Unit test for function main
def test_main():
    assert main() == None