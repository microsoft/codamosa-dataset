

# Generated at 2022-06-18 06:57:10.504429
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:10.919944
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:11.334474
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:11.751679
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.177403
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.595473
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.144481
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.629760
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.106093
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.574601
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:31.786962
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:32.168657
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.125620
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:33.554140
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.941713
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.308432
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:43.137265
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.logs.version') as version:
            main()
            version.assert_called_once_with(get_installation_info().version,
                                            '3.6.1', shell.info())

    with patch('sys.argv', ['thefuck', '--alias']):
        with patch('thefuck.print_alias') as print_alias_:
            main()

# Generated at 2022-06-18 06:57:43.546844
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:43.975156
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:44.365350
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:20.380177
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:20.818552
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:21.216740
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:21.686256
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:22.211589
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:22.684193
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:23.073298
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:23.800863
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:24.489047
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:24.908675
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:39.138315
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:39.930240
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:40.856561
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:59:41.260294
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:41.694195
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:42.093209
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:42.558047
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.017084
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.490459
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.889284
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:16.363865
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:16.846233
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:17.866135
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.281803
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.637355
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:19.360631
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:19.774480
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.165723
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.567968
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:21.110125
# Unit test for function main
def test_main():
    assert main() == None