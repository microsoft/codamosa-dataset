

# Generated at 2022-06-18 06:57:11.605006
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:12.027003
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:12.445223
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.856946
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.405741
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.893271
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:14.373535
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.845572
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.269901
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.743146
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.126716
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.554144
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.942495
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.308185
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.680830
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:35.067609
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.336516
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.820466
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:38.090577
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:38.536291
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:13.522924
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:13.992110
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:14.459146
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:14.917393
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.470475
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.863099
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.247571
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.750713
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:17.155607
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:17.541432
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:31.545453
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:31.954982
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:32.366682
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:32.733230
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:33.120450
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:33.462515
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:59:33.858423
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:34.263764
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:34.628054
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:35.000925
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:03.880702
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:04.321061
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:04.741608
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:05.132219
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:05.507976
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:05.849314
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:06.246696
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:06.621893
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:07.023549
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:07.398374
# Unit test for function main
def test_main():
    assert main() == None