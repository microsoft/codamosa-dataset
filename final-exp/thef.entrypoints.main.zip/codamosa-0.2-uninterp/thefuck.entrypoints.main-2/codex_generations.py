

# Generated at 2022-06-18 06:56:59.573245
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:59.966414
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:00.399368
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:01.264223
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:01.700681
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:02.082182
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:02.443004
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:02.824112
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:03.202741
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:03.587171
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:21.504988
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:21.956100
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:22.579566
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:23.137989
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:23.868613
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:24.348145
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.924412
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.429990
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.951362
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:26.453561
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.038660
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.467355
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:08.457593
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--alias', 'fuck']
    main()
    sys.argv = ['thefuck', '--shell-logger', 'bash']
    main()
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:58:09.178642
# Unit test for function main
def test_main():
    # TODO: fix this test
    pass

# Generated at 2022-06-18 06:58:09.611470
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:10.007902
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:10.834739
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:11.477278
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:12.131417
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:12.665245
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:49.427457
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:49.856191
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:50.893982
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:51.441216
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:51.914534
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:52.551592
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:52.988665
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:53.468793
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:54.029271
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:54.992213
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:08.640912
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:09.234915
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:09.692154
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:10.185583
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:10.608787
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:00:11.036011
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:11.439104
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:00:11.852033
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:12.254850
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:12.653845
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:44.611972
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:53.788031
# Unit test for function main
def test_main():
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()
            self.known_args = self.parser.parse(sys.argv)

        @patch('thefuck.main.print_alias')
        @patch('thefuck.main.fix_command')
        def test_main(self, fix_command, print_alias):
            self.known_args.alias = True
            main()

# Generated at 2022-06-18 07:02:54.160633
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:54.541760
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:54.922651
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:55.958193
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:02:56.424695
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:56.861429
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:57.276093
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:57.690092
# Unit test for function main
def test_main():
    assert main() == None