

# Generated at 2022-06-18 06:56:55.505153
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:56.003463
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:56.337364
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:56.674519
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:57.017146
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:56:57.435680
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:57.855803
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:58.231159
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:56:58.590664
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:58.945815
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:17.605092
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:18.116021
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:18.555992
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-18 06:57:18.983972
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:19.412382
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:19.804371
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.197986
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.604354
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:21.084971
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:21.540825
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.241518
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.612958
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.956610
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:59.089211
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:59.482986
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-18 06:57:59.996384
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:00.387102
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:00.758867
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:01.579695
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:02.063738
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:19.392515
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:19.782092
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:20.251660
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:20.696773
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:21.085311
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:21.505275
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:21.930918
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:23.577690
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:28.742300
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for no argument
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:59:34.723362
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from . import alias
    from . import fix_command
    from . import shell_logger
    from .. import logs
    from .. import argument_parser
    from .. import utils
    from .. import system
    from .. import __version__
    from .. import shells

    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.argument_parser.Parser.parse') as parse:
            with patch('thefuck.argument_parser.Parser.print_help') as print_help:
                main()
                parse.assert_called_once_with(['thefuck', '--help'])
                print_help.assert_called_once_with()


# Generated at 2022-06-18 07:02:13.576845
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:14.346223
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:14.789899
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:15.195768
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:15.825611
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:16.208019
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:16.741230
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:17.764314
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.194707
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.572644
# Unit test for function main
def test_main():
    assert main() == None