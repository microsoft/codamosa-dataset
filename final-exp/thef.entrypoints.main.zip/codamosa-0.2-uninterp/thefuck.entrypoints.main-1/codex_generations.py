

# Generated at 2022-06-18 06:57:19.497323
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger

    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.argument_parser.Parser.parse') as parse:
            parse.return_value = Parser().parse(['thefuck', '--help'])
            with patch('thefuck.argument_parser.Parser.print_help') as print_help:
                main()
                assert print_help.called


# Generated at 2022-06-18 06:57:19.915593
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.312418
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:20.785716
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:21.292517
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:30.107914
# Unit test for function main
def test_main():
    import sys
    import os
    import unittest
    from unittest.mock import patch
    from . import alias
    from . import fix_command
    from . import shell_logger
    from . import logs
    from . import Parser
    from . import get_installation_info
    from . import shell
    from . import init_output

    class TestMain(unittest.TestCase):
        @patch('sys.argv', ['thefuck', '--help'])
        @patch('thefuck.argument_parser.Parser.parse')
        @patch('thefuck.argument_parser.Parser.print_help')
        def test_help(self, print_help, parse):
            main()
            parse.assert_called_once_with(['thefuck', '--help'])
            print_help.assert_

# Generated at 2022-06-18 06:57:30.462647
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:30.849058
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:31.304701
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:31.682732
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:49.265589
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:49.654217
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:50.391250
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:50.769409
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:51.282462
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:51.687842
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:52.103840
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:52.523362
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:52.947561
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.708700
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command']
    main()
    # Test for shell logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for no argument
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:58:33.290427
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:33.727391
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:34.222190
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:34.694524
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:35.103341
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:35.483587
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:35.841593
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:36.250807
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:43.827550
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.logs.version') as mock_version:
            main()
            mock_version.assert_called_once_with(get_installation_info().version,
                                                 sys.version.split()[0], shell.info())

    with patch('sys.argv', ['thefuck', '--alias']):
        with patch('thefuck.logs.version') as mock_alias:
            main()

# Generated at 2022-06-18 06:58:44.453607
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:59.505726
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:59.945947
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:00.372547
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:00.780682
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:01.171274
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:01.575010
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:02.174655
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:02.696881
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:03.183387
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:00:03.630966
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:44.089184
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from .alias import print_alias
    from .fix_command import fix_command

    with patch('sys.argv', ['thefuck']):
        with patch.object(Parser, 'parse', return_value=Parser().parse(['thefuck'])):
            with patch.object(Parser, 'print_usage') as mock_print_usage:
                main()
                mock_print_usage.assert_called_once()

    with patch('sys.argv', ['thefuck', '--help']):
        with patch.object(Parser, 'parse', return_value=Parser().parse(['thefuck', '--help'])):
            with patch.object(Parser, 'print_help') as mock_print_help:
                main()
                mock_print

# Generated at 2022-06-18 07:02:44.444399
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:45.016289
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:46.058340
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:46.811303
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:53.636998
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for no argument
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 07:02:54.012076
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:54.397867
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:54.772639
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:55.171279
# Unit test for function main
def test_main():
    assert main() == None