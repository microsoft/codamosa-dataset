

# Generated at 2022-06-18 06:57:05.349552
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:05.691345
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:06.035597
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:06.372406
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:06.816005
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:07.201542
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:07.605361
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:08.079514
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:08.449378
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:09.295702
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.623198
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:27.135177
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:28.575904
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.071691
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.505312
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.911463
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:30.262444
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:30.602561
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:31.015189
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:31.436267
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:06.393967
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:07.517253
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:14.697710
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from . import argument_parser
    from . import alias
    from . import fix_command
    from . import shell_logger
    from . import logs
    from . import utils
    from . import shells


# Generated at 2022-06-18 06:58:15.187278
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.612309
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.007336
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.526475
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.991259
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:21.619543
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--alias']
    main()
    sys.argv = ['thefuck', '--shell-logger']
    main()
    sys.argv = ['thefuck', '--command', 'ls']
    main()

# Generated at 2022-06-18 06:58:22.144591
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:59.155348
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:59.610010
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:00.053105
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:59:01.093961
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:01.564272
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:01.913491
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:02.409247
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:02.823132
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:59:03.210827
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:03.635915
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:15.789114
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:16.268060
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:16.727616
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:17.096162
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:23.447928
# Unit test for function main
def test_main():
    import sys
    import os
    import unittest
    import unittest.mock
    from ..utils import get_installation_info
    from ..argument_parser import Parser
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()
            self.known_args = self.parser.parse(sys.argv)

        def test_help(self):
            with unittest.mock.patch('sys.argv', ['thefuck', '--help']):
                with unittest.mock.patch('thefuck.argument_parser.Parser.print_help') as mock_print_help:
                    main()
                    mock_print_help

# Generated at 2022-06-18 07:00:23.896970
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:25.371245
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:25.823775
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:26.229445
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:26.661917
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:57.472352
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:57.883422
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:58.300225
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:58.656198
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:58.989101
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:59.675502
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:00.582756
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:01.331807
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:01.821407
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:02.256718
# Unit test for function main
def test_main():
    assert main() is None