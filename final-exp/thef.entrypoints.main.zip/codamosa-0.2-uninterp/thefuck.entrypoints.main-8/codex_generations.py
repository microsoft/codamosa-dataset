

# Generated at 2022-06-18 06:57:07.506626
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:08.051060
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:08.422209
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:09.295782
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:09.678960
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:10.052523
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.543245
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for else
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:57:16.000303
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:16.430196
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:16.898623
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.706655
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:35.096499
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.330210
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:36.820176
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:38.164298
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:38.635404
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:39.228823
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:39.692079
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:40.150861
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:40.615507
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.009885
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.526804
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:16.990543
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:17.402676
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:18.898874
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:19.304265
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:19.783628
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:20.232651
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:20.681087
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:21.110903
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:36.881989
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:37.336086
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:37.706221
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:44.429158
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .alias import print_alias
    from .fix_command import fix_command
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from ..system import init_output
    from .. import logs
    import os
    import sys

    init_output()

    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.argument_parser.Parser.print_help') as mock_print_help:
            main()
            mock_print_help.assert_called_once()

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.logs.version') as mock_version:
            main()

# Generated at 2022-06-18 06:59:45.546230
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:45.996619
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:51.805332
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger


# Generated at 2022-06-18 06:59:56.129870
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--alias', 'fuck']
    main()
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    sys.argv = ['thefuck', '--shell-logger', 'bash']
    main()
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:59:56.531591
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:57.139686
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:14.114862
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:14.671094
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:15.465558
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:15.949062
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:16.452248
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:16.933460
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:17.804672
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:18.276545
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:18.713845
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:01:19.137442
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:51.920084
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:52.351380
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:52.774214
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:57.709900
# Unit test for function main
def test_main():
    # Test help
    sys.argv = ['thefuck', '--help']
    main()
    # Test version
    sys.argv = ['thefuck', '--version']
    main()
    # Test alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test command
    sys.argv = ['thefuck', 'echo', 'hello']
    main()
    # Test shell logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test no args
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 07:03:58.420671
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:03:58.916765
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:59.342039
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:03:59.780670
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:04:00.212914
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:04:00.572775
# Unit test for function main
def test_main():
    main()