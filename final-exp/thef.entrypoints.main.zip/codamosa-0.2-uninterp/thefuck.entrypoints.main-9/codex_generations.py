

# Generated at 2022-06-18 06:57:02.847792
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:03.228340
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:03.587849
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:03.938339
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:04.295291
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:04.646061
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:04.987347
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:05.331286
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:05.713920
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:06.058357
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.348809
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.924293
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.431407
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.950106
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.454403
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.966970
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:28.413797
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:28.929646
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.411174
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.838350
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:11.567285
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for no argument
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 06:58:12.177830
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:12.664653
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:13.211469
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:13.725723
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:14.148984
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:14.630258
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.058064
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.556372
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.949585
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:36.068261
# Unit test for function main
def test_main():
    import sys
    sys.argv = ['thefuck', '--version']
    main()
    sys.argv = ['thefuck', '--help']
    main()
    sys.argv = ['thefuck', '--alias', 'fuck']
    main()
    sys.argv = ['thefuck', '--shell-logger', 'bash']
    main()
    sys.argv = ['thefuck', '--command', 'ls']
    main()
    os.environ['TF_HISTORY'] = 'ls'
    main()

# Generated at 2022-06-18 06:59:36.799764
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:37.273389
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:37.661405
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:38.101442
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:38.869828
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-18 06:59:39.238683
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:40.120435
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:41.001987
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:41.428230
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:19.677596
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.081735
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.485984
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.887712
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:21.356975
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:22.167342
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:23.229486
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:23.733436
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:24.201132
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:24.663041
# Unit test for function main
def test_main():
    assert main() == None