

# Generated at 2022-06-18 06:57:05.538614
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:05.884326
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:06.228044
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.710311
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import ANY
    from unittest.mock import DEFAULT
    from unittest.mock import sentinel
    from unittest.mock import PropertyMock
    from unittest.mock import create_autospec
    from unittest.mock import Mock
    from unittest.mock import mock_open
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import call
    from unittest.mock import mock_open
    from unittest.mock import ANY

# Generated at 2022-06-18 06:57:13.294726
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.780356
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.297668
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.778088
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.211707
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.746759
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:24.766272
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.278542
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.779829
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:26.301999
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:33.966086
# Unit test for function main
def test_main():
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()
            self.known_args = self.parser.parse(sys.argv)

        @patch('thefuck.main.print_alias')
        @patch('thefuck.main.fix_command')
        def test_main_with_alias(self, fix_command, print_alias):
            self.known_args.alias = True
            main()
            print_alias.assert_called_once_

# Generated at 2022-06-18 06:57:34.334121
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.735815
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:35.125793
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.333877
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.819837
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:54.973045
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:55.360103
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:55.758791
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:56.156705
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:56.552225
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:56.935860
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.315850
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.710064
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:05.865013
# Unit test for function main
def test_main():
    from unittest.mock import patch, Mock
    from .. import argument_parser
    from .. import utils
    from .. import logs
    from .. import shells
    from . import alias
    from . import fix_command

    with patch('sys.argv', ['thefuck', '--version']):
        with patch.object(logs, 'version') as mock_version:
            with patch.object(utils, 'get_installation_info') as mock_get_installation_info:
                with patch.object(shells, 'shell') as mock_shell:
                    main()
                    mock_version.assert_called_once_with(mock_get_installation_info().version,
                                                         '3.6.1', mock_shell.info())


# Generated at 2022-06-18 06:58:06.284847
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:41.547292
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:41.995917
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:42.736633
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:43.198562
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:43.647073
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:44.244009
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:44.711379
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:45.190478
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:45.620202
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:46.327556
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:58.535138
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:59.090594
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:59.739870
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:00.257732
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:00.674265
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:01.066035
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:01.491729
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:02.066571
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:00:02.622777
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:11.064700
# Unit test for function main
def test_main():
    # Test for help
    sys.argv = ['thefuck', '--help']
    main()
    # Test for version
    sys.argv = ['thefuck', '--version']
    main()
    # Test for alias
    sys.argv = ['thefuck', '--alias']
    main()
    # Test for shell_logger
    sys.argv = ['thefuck', '--shell-logger']
    main()
    # Test for command
    sys.argv = ['thefuck', '--command']
    main()
    # Test for no argument
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-18 07:02:39.358198
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:40.035227
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:40.422877
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:40.812414
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:41.723272
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:42.134097
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:42.533626
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:42.884221
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:43.323207
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:43.749528
# Unit test for function main
def test_main():
    assert main() == None