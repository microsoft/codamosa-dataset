

# Generated at 2022-06-18 06:56:56.901338
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:56:57.289430
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:56:57.627520
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:58.009081
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:58.366554
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:58.722680
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:59.081045
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:59.438882
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:56:59.792835
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:00.264609
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:18.837824
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:19.297448
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:19.690152
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.082904
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.478880
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:20.927105
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:21.400367
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:21.892728
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:30.509684
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger


# Generated at 2022-06-18 06:57:30.902612
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:54.794791
# Unit test for function main
def test_main():
    import os
    import sys
    import unittest
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    class TestMain(unittest.TestCase):
        def setUp(self):
            self.parser = Parser()
            self.known_args = self.parser.parse(sys.argv)

        def test_help(self):
            with patch('sys.argv', ['thefuck', '--help']):
                with patch('thefuck.argument_parser.Parser.print_help') as mock_print_help:
                    main()
                    mock_print_help.assert_called_once()


# Generated at 2022-06-18 06:57:55.201731
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:55.599050
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:55.995760
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:56.396902
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:56.783551
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.163166
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.539817
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:57.909731
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:58.267074
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:35.580902
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:35.972502
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:36.353102
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:36.731663
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:44.617699
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..shells import shell
    from ..utils import get_installation_info
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger


# Generated at 2022-06-18 06:58:45.088575
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:45.536190
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:46.328704
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:46.793548
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:47.430392
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:02.423045
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:02.921289
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:03.396470
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:00:04.597130
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:00:05.028576
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:06.469434
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:07.350075
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:08.034185
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:08.890317
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:00:09.408843
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:46.690357
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:47.190604
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:47.502224
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:48.248197
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:48.736343
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:49.209345
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:49.721652
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:50.186721
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:50.647530
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:51.873475
# Unit test for function main
def test_main():
    main()