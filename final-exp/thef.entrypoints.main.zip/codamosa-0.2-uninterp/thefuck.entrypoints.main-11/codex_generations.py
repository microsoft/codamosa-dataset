

# Generated at 2022-06-18 06:57:13.405795
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.893620
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.367993
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.811800
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.240591
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.743405
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:16.184704
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:16.667374
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:17.120766
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:17.550918
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:35.124984
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:36.331551
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:44.282093
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from .alias import print_alias
    from .fix_command import fix_command

    with patch('thefuck.main.Parser') as mock_parser:
        mock_parser.return_value.parse.return_value = 'known_args'

# Generated at 2022-06-18 06:57:45.108176
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-18 06:57:45.884659
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:46.299226
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:46.704535
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:47.101380
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:47.500382
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:47.877978
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:24.027300
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:24.581320
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:25.000662
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:25.424824
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:25.940868
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:26.487222
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:26.885988
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:27.312844
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:27.720405
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:28.328038
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.121872
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.549292
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.944252
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:44.327031
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:45.441097
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:45.903484
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:59:46.264035
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:46.636951
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:52.474911
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from unittest.mock import MagicMock
    from unittest.mock import call

    # Test help
    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.argument_parser.Parser.print_help') as mock_print_help:
            main()
            assert mock_print_help.call_count == 1

    # Test version
    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.logs.version') as mock_version:
            main()
            assert mock_version.call_count == 1

    # Test alias

# Generated at 2022-06-18 06:59:53.125348
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:02:26.881209
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:27.380150
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:02:27.804482
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:28.220657
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:28.640886
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:29.054997
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:29.494394
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:29.867399
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:30.505232
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-18 07:02:30.889882
# Unit test for function main
def test_main():
    assert main() == None