

# Generated at 2022-06-18 06:57:11.636463
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.089251
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:12.505377
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:12.977864
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.479786
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:13.967251
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.438723
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:14.944341
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.470794
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:15.905426
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.339104
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:33.752787
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.133838
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:34.502795
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:34.883571
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:36.178420
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:44.171151
# Unit test for function main
def test_main():
    from unittest.mock import patch, mock_open
    from io import StringIO
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from ..argument_parser import Parser
    from ..utils import get_installation_info
    from ..shells import shell
    from ..system import init_output
    from .. import logs
    import os
    import sys

    init_output()
    parser = Parser()
    known_args = parser.parse(sys.argv)

    with patch('sys.stdout', new=StringIO()) as fake_out:
        parser.print_help()

# Generated at 2022-06-18 06:57:44.588708
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:45.000947
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:45.406587
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:21.654238
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:22.178847
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:22.621486
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:23.000599
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:23.355866
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:24.303159
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:24.726658
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:25.132787
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:25.489917
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:25.943450
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:40.766310
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:59:41.173505
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:41.563195
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:41.959321
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:42.410985
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:42.873810
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.343423
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:43.733801
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:44.123759
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:44.506856
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.253704
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.638265
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:19.388488
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:19.801954
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 07:02:20.255227
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.648222
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:21.193236
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:21.568658
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:22.991357
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:23.461386
# Unit test for function main
def test_main():
    assert main() == None