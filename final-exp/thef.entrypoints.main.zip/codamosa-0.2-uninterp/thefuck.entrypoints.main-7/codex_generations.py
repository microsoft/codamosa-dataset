

# Generated at 2022-06-18 06:57:04.391103
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:04.754934
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:05.085937
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:05.435708
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:57:05.782272
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:06.124300
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:06.458729
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:07.007872
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:07.416152
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:07.998848
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:25.780339
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.301530
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:26.785716
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:27.281097
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:28.655243
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.138075
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.570184
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:57:29.959558
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:57:38.017038
# Unit test for function main

# Generated at 2022-06-18 06:57:38.470604
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:13.798765
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:14.238274
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:14.699774
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:15.188279
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:15.612721
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-18 06:58:16.035104
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 06:58:16.565346
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:17.020086
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:17.458788
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:58:18.930184
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:36.125986
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:36.882424
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:37.326200
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:37.706702
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:38.100786
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:38.456792
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:38.822275
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:39.189208
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:40.090628
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 06:59:41.002455
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:16.048833
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:16.670174
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:17.708181
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.163034
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:18.520548
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-18 07:02:19.268699
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:19.663468
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.081317
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.485629
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-18 07:02:20.887869
# Unit test for function main
def test_main():
    assert main() == None