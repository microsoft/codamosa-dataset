

# Generated at 2022-06-12 10:21:56.462697
# Unit test for function main
def test_main():
    try:
        main()
    except:
        assert False
    

# Generated at 2022-06-12 10:22:05.090404
# Unit test for function main
def test_main():
    import mock
    import imp
    import thefuck.main
    main=imp.reload(thefuck.main)
    print_alias=mock.MagicMock()
    main.print_alias=print_alias
    fix_command=mock.MagicMock()
    main.fix_command=fix_command
    parser=mock.MagicMock()
    parser.parse=mock.MagicMock()
    parser.parse.return_value.help=False
    parser.parse.return_value.version=False
    parser.parse.return_value.alias=False
    parser.parse.return_value.command=False
    parser.parse.return_value.shell_logger=False
    parser.print_usage=print_alias
    main.Parser=mock.MagicMock()

# Generated at 2022-06-12 10:22:12.897734
# Unit test for function main
def test_main():
    logs.version = lambda version, python, shell: (version, python, shell)
    from unittest.mock import patch, PropertyMock
    parser = Parser()
    try:
        del os.environ['TF_HISTORY']
    except KeyError:
        pass

    # test help option
    with patch.object(parser, 'parse', return_value=argparse.Namespace(
            help=True)):
        with patch.object(parser, 'print_help') as mock_print_help:
            main()
            assert mock_print_help.called

    # test version option
    with patch.object(parser, 'parse', return_value=argparse.Namespace(version=True)):
        with patch.object(logs, 'version') as mock_version:
            main()

# Generated at 2022-06-12 10:22:13.944720
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:14.577375
# Unit test for function main
def test_main():
    assert main() == 0

# Generated at 2022-06-12 10:22:15.254364
# Unit test for function main
def test_main():
  main()

# Generated at 2022-06-12 10:22:15.737694
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:19.523617
# Unit test for function main
def test_main():
    test_sys_args=["thefuck"]
    main()
    test_known_args=parse(test_sys_args)

    assert test_known_args.help == True
    assert test_known_args.version == False
    assert test_known_args.alias == False
    assert test_known_args.command == False
    assert test_known_args.shell_logger == False

test_main()

# Generated at 2022-06-12 10:22:20.420315
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:23.254353
# Unit test for function main
def test_main():
    '''To test the function main()'''
    from .pytest_thefuck.thefuck_logger import TheFuckLogger
    parser = Parser()
    logs.LOGGER = TheFuckLogger(logs.LOGGER.level, logs.LOGGER.log_file)

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:39.893381
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:22:41.619757
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help

# Generated at 2022-06-12 10:22:42.120790
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:42.631909
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:50.450606
# Unit test for function main
def test_main():
    from unittest import mock
    from . import command_names
    from . import __main__
    from .main import parser
    from .main import print_alias
    from .main import fix_command
    from .main import shell_logger

    with mock.patch.object(__main__, 'parser', spec_set=parser):
        with mock.patch.object(__main__, 'print_alias', spec_set=print_alias):
            with mock.patch.object(__main__, 'fix_command', spec_set=fix_command):
                with mock.patch.object(__main__, 'shell_logger', spec_set=shell_logger):
                    with mock.patch('sys.argv', [command_names.MAIN_COMMANDS['main']['help']]):
                        main()

# Generated at 2022-06-12 10:22:51.752772
# Unit test for function main
def test_main():
    assert main() == None

# UNIT TEST FIXTURES

# unit test config

# Generated at 2022-06-12 10:22:52.779368
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:58.407903
# Unit test for function main
def test_main():
    # Test help message
    logs.do_enable_rewrite = False
    sys.argv = ['thefuck', '--help']
    main()
    assert logs.do_enable_rewrite  # noqa: S101

    # Test version
    logs.do_enable_rewrite = False
    sys.argv = ['thefuck', '--version']
    main()
    assert logs.do_enable_rewrite  # noqa: S101

    # Test alias
    logs.do_enable_rewrite = False
    sys.argv = ['thefuck', 'alias', 'test', 'echo test']
    main()
    assert logs.do_enable_rewrite  # noqa: S101

    # Test alias
    logs.do_enable_rewrite = False

# Generated at 2022-06-12 10:22:59.000335
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:22:59.586071
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:23:19.639820
# Unit test for function main

# Generated at 2022-06-12 10:23:20.091302
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:23:21.539956
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:22.380416
# Unit test for function main
def test_main():
    assert (main() == None)
# End of unit test

# Generated at 2022-06-12 10:23:27.114684
# Unit test for function main
def test_main():
    # Importing thefuck.main will modify `sys.argv`.
    # Thus, we need to make a copy to restore it later.
    sys_argv = sys.argv[:]
    try:
        sys.argv = ['thefuck', '--help']
        main()
        sys.argv = ['thefuck', '--version']
        main()
        sys.argv = ['thefuck', '--alias']
        main()
    finally:
        sys.argv = sys_argv

# Generated at 2022-06-12 10:23:28.778381
# Unit test for function main
def test_main():
    try:
        main()
        status = 0
    except SystemExit as e:
        status = e.code

    assert status == 0

# Generated at 2022-06-12 10:23:32.979596
# Unit test for function main
def test_main():
    import sys
    import os
    from .system import init_output
    from ..utils import get_all_executables
    from .shells import get_shell
    from .shells import init_aliases
    sys.argv = ["thefuck"]
    init_output()
    import logging
    logging.basicConfig(level=logging.DEBUG)
    init_aliases()
    main()

# Generated at 2022-06-12 10:23:34.090570
# Unit test for function main
def test_main():
    sys.argv = ["thefuck", "--alias", "--version"]
    main()

# Generated at 2022-06-12 10:23:34.868316
# Unit test for function main
def test_main():
    parser = Parser()
    assert parser is not None

# Generated at 2022-06-12 10:23:35.438327
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:24:09.246821
# Unit test for function main
def test_main():
    # Exercise
    main()

    # Verify


# Generated at 2022-06-12 10:24:13.960229
# Unit test for function main
def test_main():
    test_parser = Parser()
    assert test_parser.parse(['fuck'])
    assert test_parser.parse(['fuck', '-t'])
    assert test_parser.parse(['fuck', '--version'])
    assert test_parser.parse(['fuck', '--alias'])
    assert test_parser.parse(['fuck', '--alias', 'zsh'])



if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:24:20.892551
# Unit test for function main
def test_main():
    with patch('sys.argv', ['/usr/local/bin/thefuck', '--help']):
        with patch.object(Parser, 'print_help') as print_help:
            with patch('thefuck.__main__.fix_command') as fix_command:
                main()
                assert not print_help.called
                assert not fix_command.called

    with patch('sys.argv', ['/usr/local/bin/thefuck', '--version']):
        with patch('thefuck.__main__.logs.version') as version:
            with patch('thefuck.__main__.get_installation_info') as get_installation_info:
                with patch('thefuck.__main__.shell') as shell:
                    main()
                    assert not version.called

# Generated at 2022-06-12 10:24:25.641217
# Unit test for function main
def test_main():
    os.environ["PATH"] = "/home/test"
    os.environ["TF_HISTORY"] = "/home/test"
    sys.argv = ['/home/test/thefuck']
    logs.mock()
    main()
    logs.reset()

# Generated at 2022-06-12 10:24:26.074033
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:24:29.199700
# Unit test for function main
def test_main():
    from unittest import mock

    argv = ['thefuck']
    # Mock "Arguments" object
    with mock.patch('thefuck.types.KnownArgs') as known_args:
        main()
    known_args.print_usage.assert_called_once_with(argv)

# Generated at 2022-06-12 10:24:29.672206
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:24:30.695504
# Unit test for function main
def test_main():
    args = ['thefuck', '--version']
    main(args)

# Generated at 2022-06-12 10:24:34.598033
# Unit test for function main
def test_main():
    args = []
    # help before version
    args.append(['-h'])
    args.append(['--help'])
    # version before help
    args.append(['-v'])
    args.append(['--version'])
    # shell_logger output
    args.append(['--shell-logger'])
    # no args
    args.append([])
    # unknown args
    args.append(['--unknown'])

    return args

# Generated at 2022-06-12 10:24:35.612109
# Unit test for function main
def test_main():
    assert main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:25:48.418548
# Unit test for function main
def test_main():
    from . import test_alias, test_args, test_command, test_version, test_help
    test_alias()
    test_command()
    test_version()
    test_help()
    test_args()

# Generated at 2022-06-12 10:25:48.969298
# Unit test for function main
def test_main():
    assert main

# Generated at 2022-06-12 10:25:57.163465
# Unit test for function main
def test_main():
    from ..utils import is_exception, wrap_retry
    from ..shells import get_aliases
    from unittest import TestCase, mock
    from unittest.mock import patch
    import io

    class TestMain(TestCase):
        @patch('sys.argv', ['thefuck'])
        @patch('sys.stdout', new_callable=io.StringIO)
        def test_default(self, mock_stdout):
            main()
            self.assertEqual(mock_stdout.getvalue(), 'Usage: thefuck [OPTIONS] COMMAND\n\n')


# Generated at 2022-06-12 10:25:57.569837
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:26:05.721182
# Unit test for function main
def test_main():
    import sys
    from mock import patch, Mock
    from .alias import alias
    from .alias import print_alias
    from .fix_command import fix_command
    from .shell_logger import shell_logger
    from ..argument_parser import Parser

    sys.argv = ['thefuck', '--alias', 'mv']
    main()
    assert (print_alias.called)

    sys.argv = ['thefuck', '--help']
    main()
    assert (Parser.print_help.called)

    sys.argv = ['thefuck', '--shell-logger']
    main()
    assert (Parser.print_usage.called)

    sys.argv = ['thefuck', '--version']
    main()
    assert (Parser.print_version.called)


# Generated at 2022-06-12 10:26:15.463215
# Unit test for function main
def test_main():
    # конструкция try...except вынесена в отдельную функцию
    def _test(args, expected_output, expected_return_code):

        # Make a copy of sys.argv
        old_argv = sys.argv

        # Make a copy of sys.stdout
        old_stdout = sys.stdout

        # Make a copy of sys.stderr
        old_stderr = sys.stderr

        # Make a copy of os.environ
        old_env = None
        if 'TF_HISTORY' in os.environ:
            old_env = os.environ.copy()

        # Suppress stdout and stderr

# Generated at 2022-06-12 10:26:19.887859
# Unit test for function main
def test_main():
    environ = os.environ
    sys.argv = ['thefuck']
    os.environ = {'TF_ALIAS': 'fuck = echo test'}
    main()
    with open('test.txt', 'r') as file:
        test_line = file.readline()
        assert(test_line == 'alias fuck = echo test')
    os.remove('test.txt')
    os.environ = environ

# Generated at 2022-06-12 10:26:20.700209
# Unit test for function main
def test_main():
    assert main() == None

main()

# Generated at 2022-06-12 10:26:21.144622
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:26:21.566885
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:28:51.241379
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser

    with patch('thefuck.argument_parser.sys') as mock_sys:
        mock_sys.args = ["arg1", "arg2"]
        mock_sys.argv = ["arg1", "arg2"]
        mock_sys.stdout = "test"

        with patch('thefuck.utils.get_installation_info') as mock_get_installation_info:
            with patch('thefuck.shells.shell') as mock_shell:
                mock_get_installation_info.version = "test"
                mock_get_installation_info.return_value = None
                mock_shell.info = "test"
                mock_shell.return_value = None


# Generated at 2022-06-12 10:28:55.069230
# Unit test for function main
def test_main():
    testargs = ["test_main.py", "fuck", "file_name:line_no:error_message", "--no-ansi", "--version", "--shell_logger", "bash"]
    saved_argv = sys.argv
    sys.argv = testargs
    main()
    sys.argv = saved_argv

# Generated at 2022-06-12 10:28:55.977289
# Unit test for function main
def test_main():
    assert hasattr(main, '__call__')

# Generated at 2022-06-12 10:28:56.536627
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:28:57.159582
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:28:58.004680
# Unit test for function main
def test_main():
    assert True

# Generated at 2022-06-12 10:29:04.449966
# Unit test for function main
def test_main():
    from unittest import mock
    from . import argument_parser
    import pkg_resources
    from . import alias

    os.environ['TF_HISTORY'] = 'sdsdsdsd'

    known_args = {
        'help': False,
        'version': False,
        'alias': False,
        'command': False,
        'shell_logger': None,
        'settings': None,
        'no_color': False,
        'no_fuck': False,
        'extras': []
    }


# Generated at 2022-06-12 10:29:11.376790
# Unit test for function main
def test_main():
    from .mock_subprocess import MockSubprocess

    with open('/tmp/history.txt', 'w') as f:
        f.write("uptime")

    parser = Parser()
    known_args = parser.parse(['--quiet', '--no-color'])

    def mock_fix_command(known_args):
        assert known_args.command == 'uptime'
        assert known_args.trim_in_thread is True
        assert known_args.quiet is True
        assert known_args.no_color is True
        assert known_args.extend_env == {}
        assert known_args.python_shell

    with MockSubprocess():
        fix_command.funcs[:] = [mock_fix_command]
        known_args.command = 'uptime'
        main()
        known_

# Generated at 2022-06-12 10:29:12.318336
# Unit test for function main
def test_main():
    pass


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:29:13.052415
# Unit test for function main
def test_main():
    assert True
