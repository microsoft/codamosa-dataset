

# Generated at 2022-06-12 10:21:47.031165
# Unit test for function main
def test_main():
    assert main() == None, "main() failed"

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:21:47.435254
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:21:50.746442
# Unit test for function main
def test_main():
    _main()
    assert 'print_usage' in sys.modules['thefuck.main']
    assert 'shell_logger' in sys.modules['thefuck.main']
    assert 'logs' in sys.modules['thefuck.main']
    assert 'fix_command' in sys.modules['thefuck.main']

# Generated at 2022-06-12 10:21:51.219230
# Unit test for function main
def test_main():
    assert main()==None

# Generated at 2022-06-12 10:21:52.255083
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:01.361616
# Unit test for function main
def test_main():
    import sys
    import os
    import pytest
    from ..utils import get_installation_info  # noqa: E402
    from ..shells import shell  # noqa: E402
    from .alias import main as alias_main  # noqa: E402
    from .fix_command import main as fix_command_main  # noqa: E402
    # Mock all the external functions
    import mock
    mock.patch('thefuck.argument_parser.Parser.parse').start()
    mock.patch('thefuck.argument_parser.Parser.print_help').start()
    mock.patch('thefuck.logs.version').start()
    mock.patch('thefuck.argument_parser.Parser.print_usage').start()
    mock.patch('thefuck.alias.print_alias').start()

# Generated at 2022-06-12 10:22:01.873779
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:02.384146
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:10.164224
# Unit test for function main
def test_main(): # noqa: F811
    import io # noqa: F811
    from .alias import main as alias_main # noqa: F811
    from .fix_command import main as fix_command_main # noqa: F811
    from .shell_logger import main as shell_logger_main # noqa: F811

    help_message = io.StringIO()
    version_message = io.StringIO()
    alias_message = io.StringIO()
    fix_command_message = io.StringIO()
    shell_logger_message = io.StringIO()

    class FakeParser(object):
        def parse(self, args):
            return namespace(help=True,
                            version=False,
                            alias=False,
                            command=False,
                            shell_logger=False)


# Generated at 2022-06-12 10:22:18.027817
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = '1'
    
    # test 1
    sys.argv = ['thefuck', 'ls -la', '1']
    from .fix_command import Script
    from .rules import manager
    manager.enable_lazy()
    from .rules.shells import zsh, bash, fish
    assert main() is None
    
    # test 2
    sys.argv = ['thefuck','--debug']
    assert main() is None
    
    # test 3
    sys.argv = ['thefuck','--quiet']
    assert main() is None
    
    # test 4
    sys.argv = ['thefuck','--version']
    assert main() is None
    
    # test 5
    sys.argv = ['thefuck','--help']

# Generated at 2022-06-12 10:22:26.483496
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:26.932659
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:35.443628
# Unit test for function main
def test_main():
    import unittest
    import sys
    import os
    import random
    import string

    class TestMain(unittest.TestCase):

        def test_main_should_return_help_if_called_with_no_arguments(self):
            # Need to capture the output, this is the only way I've found to do it
            # Tested on StackOverflow, it looks like it's the best solution
            import io
            from contextlib import redirect_stdout
            f = io.StringIO()
            with redirect_stdout(f):
                main()
            output = f.getvalue()
            # Check if output contains the word usage, if so, that means the help message came up
            self.assertIn('usage', output)


# Generated at 2022-06-12 10:22:37.751248
# Unit test for function main
def test_main():
    #Test with no argument
    assert main() == None
    #Test with invalid argument
    with pytest.raises(SystemExit):
        assert main("--invalid") == SystemExit

# Generated at 2022-06-12 10:22:38.801471
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:46.974322
# Unit test for function main
def test_main():
    # test help functionality for the main function
    with captured_output() as (out1, err1):
        sys.argv = ['thefuck', '--help']
        main()
        output1 = out1.getvalue().strip()

# Generated at 2022-06-12 10:22:54.080389
# Unit test for function main
def test_main():
    from os import environ
    from sys import version_info, version
    from thefuck import utils

    environ['TF_HISTORY']='git statsu'
    try:
        known_args = Parser().parse('')
    except SystemExit:
        pass
    else:
        assert known_args.versions_info == (version_info.major, version_info.minor)
        assert known_args.versions == (version.split(' ')[0], '0.0.0')
        assert known_args.installed_version == (utils.get_installation_info().version, '0.0.0')
        assert known_args.python_version == (version.split(' ')[0], '0.0.0')
        assert known_args.config == (None, None)

# Generated at 2022-06-12 10:23:03.066818
# Unit test for function main
def test_main():
    # Test for help
    class FakeArgv:
        def __init__(self, args):
            self.args = args

        def __iter__(self):
            return iter(self.args)

        def __getitem__(self, idx):
            return self.args[idx]

        def __len__(self):
            return len(self.args)

    with mock.patch('sys.argv', FakeArgv(['', '--help'])):
        with mock.patch('thefuck.main.Parser') as mock_parser:
            assert main()
            mock_parser.return_value.parse.assert_called_once_with(
                ['', '--help'])
            mock_parser.return_value.print_help.assert_called_once_with()

    # Test for version

# Generated at 2022-06-12 10:23:03.922880
# Unit test for function main
def test_main():
    assert callable(main)

# Generated at 2022-06-12 10:23:11.735479
# Unit test for function main
def test_main():
    from .alias import print_alias
    from .fix_command import fix_command

    import sys
    import os

    # Test for help
    sys.argv = ["thefuck", "--help"]
    main()

    # Test for alias
    sys.argv = ["thefuck", "-a"]
    with mock.patch('thefuck.main.print_alias', return_value=None) as mocked:
        main()
        mocked.assert_called_once()

    # Test for command
    sys.argv = ["thefuck", "--command", "test"]
    with mock.patch('thefuck.main.fix_command', return_value=None) as mocked:
        main()
        mocked.assert_called_once()

    # Test for shell_logger

# Generated at 2022-06-12 10:23:28.488230
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = "Hello "
    main()

# Generated at 2022-06-12 10:23:31.344034
# Unit test for function main
def test_main():
    from .logs import reset_log_settings

    reset_log_settings()
    main()
    assert logs.get_log_level() != 'DEBUG'
    assert not logs.disable_colors()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:31.838635
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:23:33.007352
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:40.613164
# Unit test for function main
def test_main():
    parser = Parser()
    # known_args = parser.parse(sys.argv)

    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # something = parser.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something
    # known_args.something


# Generated at 2022-06-12 10:23:41.080769
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:23:41.544873
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-12 10:23:45.055597
# Unit test for function main
def test_main():
    import os  # noqa: E402
    os.environ['TF_HISTORY'] = 'True'
    with open('/tmp/testfile', 'w') as f:
        f.write('pwd')
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:47.122071
# Unit test for function main
def test_main():
    script_name = "HISTORY_FILE"
    sys.argv = [script_name]

    main()


test_main()

# Generated at 2022-06-12 10:23:47.575858
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:24:24.612833
# Unit test for function main
def test_main():
    try:
        from .shell_logger import shell_logger  # noqa: E402

        assert callable(shell_logger)
    except ImportError:
        assert True
    except ModuleNotFoundError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 10:24:31.913087
# Unit test for function main
def test_main():
    import subprocess as sp
    from subprocess import call as sbc

    # it should execute the help properly
    sbc(["thefuck", "--help"])

    # it should execute the version command properly
    sbc(["thefuck", "--version"])

    # it should execute the alias command properly (doesn't have any
    # kind of validation)
    sbc(["thefuck", "--alias"])

    # it should execute the shell logger command properly (doesn't have any
    # kind of validation)
    sbc(["thefuck", "--shell-logger"])

    # it should execute the fix command properly
    # - it should execute the fix command when there is a previous commands
    #   stored in the environment variable TF_HISTORY
    env = os.environ.copy()

# Generated at 2022-06-12 10:24:32.407415
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:24:37.070122
# Unit test for function main
def test_main():
    pass
    # Setting up parameters for the main function.
    # Mock up parameters.
    '''
    parser = Parser()
    known_args = parser.parse(sys.argv)
    sys.argv = ['fuck', '--help']
    main()

    sys.argv = ['fuck', '--version']
    main()

    sys.argv = ['fuck', '--alias']
    main()

    os.environ['TF_HISTORY'] = True
    sys.argv = ['fuck']
    main()
    '''

# Generated at 2022-06-12 10:24:37.492236
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-12 10:24:37.938920
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:24:39.109822
# Unit test for function main
def test_main():
    # Test command
    logs.set_log_level(logs.logging.INFO)
    main()
    assert True

# Generated at 2022-06-12 10:24:43.803887
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(['-a'])
    main()
    assert known_args.alias == True
    known_args = parser.parse(['--version'])
    main()
    assert known_args.version == True
    known_args = parser.parse(['-h'])
    main()
    assert known_args.help == True
    known_args = parser.parse(['-l'])
    main()
    assert known_args.shell_logger == 'en'

# Generated at 2022-06-12 10:24:44.316278
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:24:45.833700
# Unit test for function main
def test_main():
    from .shells import get_shell

    assert main() == None

# Generated at 2022-06-12 10:26:00.569365
# Unit test for function main
def test_main():
    testargs = ["thefuck", "--help", "--version", "--alias", "python3", "--shell-logger"]
    with patch.object(sys, 'argv', testargs):
        assert main() is None

test_main()

# Generated at 2022-06-12 10:26:07.557743
# Unit test for function main
def test_main():
    from .shells import bash, zsh  # noqa: E402
    import pytest  # noqa: E402
    import subprocess  # noqa: E402

    pytest.main(['--capture=no', 'tests'])
    assert subprocess.check_call(
        [bash.bash, '-c', 'thefuck --alias']) == 0
    assert subprocess.check_call(
        [zsh.zsh, '-c', 'thefuck --alias']) == 0

    assert subprocess.check_call([bash.bash, '-c', 'thefuck --version']) == 0
    assert subprocess.check_call([zsh.zsh, '-c', 'thefuck --version']) == 0


# Generated at 2022-06-12 10:26:08.227420
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:26:15.227063
# Unit test for function main
def test_main():
    from .test_utils import mock
    from .test_utils import make_args
    from .test_utils import arguments_without_command
    from .test_utils import arguments_with_no_config
    from .test_utils import arguments_with_config
    with mock.patch('sys.argv', make_args(arguments_without_command)):
        main()
    with mock.patch('sys.argv', make_args(arguments_with_no_config)):
        main()
    with mock.patch('sys.argv', make_args(arguments_with_config)):
        main()

# Generated at 2022-06-12 10:26:15.710588
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:26:16.913565
# Unit test for function main
def test_main():
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:26:20.521868
# Unit test for function main
def test_main():
    import sys # noqa: E402
    import mock # noqa: E402

    sys.argv = [
        'thefuck',
        '-e'
        ]

    # Mock exit - to not exit the program
    with mock.patch('sys.exit', lambda *_, **__: None):
        main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:26:21.903662
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', '--version']
    main()
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:26:23.412491
# Unit test for function main
def test_main():
    try:
        import pytest
    except ImportError:
        pass
    else:
        pytest.main(args = [__file__])

# Generated at 2022-06-12 10:26:31.121974
# Unit test for function main
def test_main(): # noqa: D103
    with patch('thefuck.main.fix_command', return_value=None), \
            patch('thefuck.main.print_alias', return_value=None), \
            patch('thefuck.main.shell_logger', return_value=None), \
            patch('thefuck.main.parser.print_help', return_value=None), \
            patch('thefuck.main.parser.print_usage', return_value=None), \
            patch('thefuck.main.logs.version') as logs_version:
        main()
        assert not logs_version.called
    

# Generated at 2022-06-12 10:28:56.493456
# Unit test for function main
def test_main():
    sys.argv = ['/usr/bin/fuck', 'fuck']
    main()

test_main()

# Generated at 2022-06-12 10:29:03.802272
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help == False
    known_args = parser.parse(['--help'])
    assert known_args.help == True
    known_args = parser.parse(['--version'])
    assert known_args.version == True
    assert known_args.help == False
    known_args = parser.parse(['--alias'])
    assert known_args.alias == True
    assert known_args.version == False
    assert known_args.help == False
    known_args = parser.parse(['--shell-logger'])
    assert known_args.shell_logger == True
    assert known_args.alias == False
    assert known_args.version == False
    assert known_args.help == False
   

# Generated at 2022-06-12 10:29:05.971497
# Unit test for function main
def test_main():
    args = ['thefuck', '--help']
    try:
        sys.argv = args
        main()
    except SystemExit as e:
        assert e.code == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:29:12.815221
# Unit test for function main
def test_main():
    import mock
    from argparse import Namespace
    from argument_parser import Parser

    # Test help
    with mock.patch('argparse._sys.argv', ["thefuck"]):
        assert main()

    # Test version
    with mock.patch('argparse._sys.argv', ["thefuck", "--version"]):
        assert main()

    # Test alias
    with mock.patch('argparse._sys.argv', ["thefuck", "--alias"]):
        assert main()
    known_args = Parser().parse(["thefuck", "--alias"])
    assert known_args.alias

    # Test alias for a python2 shell
    with mock.patch('argparse._sys.argv', ["thefuck", "--alias=python2"]):
        assert main()

# Generated at 2022-06-12 10:29:13.707152
# Unit test for function main
def test_main():
    assert main == 'main'

# Generated at 2022-06-12 10:29:14.305577
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:29:15.091762
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:29:19.016342
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .shell_logger import shell_logger

    with patch("thefuck.main.shell_logger") as mocke_shell_logger:
        main()
        mocke_shell_logger.assert_called_with(False)

# Generated at 2022-06-12 10:29:28.833265
# Unit test for function main
def test_main():
    from .fix_command import main as fix_command_main
    from .shells import shell
    from .alias import main as alias_main
    import sys
    import os

    def assert_exit(argv, expected_stdout):
        try:
            main(argv)
        except SystemExit as e:
            assert e.code == 0
            assert sys.stdout.getvalue() == expected_stdout
        else:
            assert False, 'SystemExit expected'

    for argv in [['thefuck'],
                 ['thefuck', '--help'],
                 ['thefuck', '--version']]:
        assert_exit(argv, '')

    monkeypatch.setattr(shell, 'info',
                        lambda: {'name': 'bash', 'version': '3.2.57'})

# Generated at 2022-06-12 10:29:29.366345
# Unit test for function main
def test_main():
    return main()
