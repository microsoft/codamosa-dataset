

# Generated at 2022-06-12 10:21:52.622815
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:21:54.095311
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass

# Generated at 2022-06-12 10:21:54.981050
# Unit test for function main
def test_main():
    assert main() is None or True

# Generated at 2022-06-12 10:22:03.626105
# Unit test for function main
def test_main():
    import unittest

    class HelpTest(unittest.TestCase):

        def test_main(self):
            with self.assertRaises(SystemExit) as cm:
                main()
            the_exception = cm.exception
            self.assertEqual(the_exception.code, 0)

    class VersionTest(unittest.TestCase):

        def test_main(self):
            with self.assertRaises(SystemExit) as cm:
                main()
            the_exception = cm.exception
            self.assertEqual(the_exception.code, 0)

    class AliasTest(unittest.TestCase):

        def test_main(self):
            with self.assertRaises(SystemExit) as cm:
                main()
            the_exception = cm.exception
            self

# Generated at 2022-06-12 10:22:04.107956
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:04.587918
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:22:11.390588
# Unit test for function main
def test_main():
    logs.log = lambda *x, **y: None

    def run_main():
        from .app import main
        return main()

    def run_fix_command(arguments=''):
        from .fix_command import fix_command
        fix_command(Parser().parse(arguments.split()))

    def run_print_alias(arguments='-l'):
        from .alias import print_alias
        print_alias(Parser().parse(arguments.split()))

    class ArgParse:
        class Namespace:
            pass

        def __init__(self, alias=False):
            self._alias = alias

        def parse(self, arguments):
            result = ArgParse.Namespace()
            result.alias = self._alias
            return result

    assert run_main() is None
    assert run_fix_

# Generated at 2022-06-12 10:22:12.148128
# Unit test for function main
def test_main():
    return(_main=="main")

# Generated at 2022-06-12 10:22:15.438313
# Unit test for function main
def test_main():
    known_args = Parser().parse(['fuck', 'df'])
    from .fix_command import test_fix_command
    assert test_fix_command(known_args) == 1
    assert main() == 0

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:19.294144
# Unit test for function main
def test_main():
    # f = open('a.txt', 'w+')
    # f.write('aaa')
    # f.close()
    # os.system('rm a.txt -f')
    # os.system('touch a.txt')
    os.system('rm a.txt -f')
    os.system('touch a.txt')
    os.system('echo "aaa">> a.txt')
    os.system('python3 main.py')

# Generated at 2022-06-12 10:22:35.946522
# Unit test for function main
def test_main():
    sys.argv = ['tf']
    main()

# Generated at 2022-06-12 10:22:37.124584
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:38.473299
# Unit test for function main
def test_main():
    assert(len(main()) == 0)

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:46.657021
# Unit test for function main
def test_main():
    import subprocess
    import sys
    p = subprocess.Popen(['thefuck', '--alias'], stdout=subprocess.PIPE)
    out, err = p.communicate()
    assert p.returncode == 0
    assert out.decode().split("\n")[0] == '# Add this to your "~/.bashrc" config'
    assert 'eval $(thefuck --alias thefuck)' in out.decode()
    assert out.decode().split("\n")[2] == '# Now, running `fuck` will execute `thefuck`'
    p = subprocess.Popen(['thefuck', '--alias', 'fk'], stdout=subprocess.PIPE)
    out, err = p.communicate()
    assert p.returncode == 0
    assert out.decode

# Generated at 2022-06-12 10:22:47.707394
# Unit test for function main
def test_main():
    pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:48.860389
# Unit test for function main
def test_main():
    # thefuck.app.main()
    assert main == main

# Generated at 2022-06-12 10:22:49.452268
# Unit test for function main
def test_main():
    assert 'main'

# Generated at 2022-06-12 10:22:50.553086
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:51.482079
# Unit test for function main
def test_main():
    from .. import main as m
    m.main()
    assert 1

# Generated at 2022-06-12 10:22:51.882012
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:23:08.307100
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        return 1
    return 0

# Generated at 2022-06-12 10:23:09.992148
# Unit test for function main
def test_main():
    import os

    os.environ['TF_HISTORY'] = '1'
    sys.argv[1:] = ['--debug']

    main()

# Generated at 2022-06-12 10:23:16.288118
# Unit test for function main
def test_main():
    known_args = {
        'alias': False,
        'command': False,
        'debug': True,
        'env': {},
        'exclude_rules': None,
        'extend_env': False,
        'interactive': False,
        'no_colors': False,
        'no_wait': False,
        'priority': 'normal',
        'require_confirmation': False,
        'rules': None,
        'script': False,
        'settings': None,
        'shell_logger': None,
        'version': False,
        'wait': True,
        'wait_command': None,
        'help': False,
        '_func': 'tf'
    }
    exit_code = main(known_args)
    assert exit_code == 0
    return True

# Generated at 2022-06-12 10:23:19.401735
# Unit test for function main
def test_main():
    from .test_its import its
    its('print_help') \
        .asserts(main).returns(None) \
        .by_executing('--help')
    its('print_version') \
        .asserts(main).returns(None) \
        .by_executing('--version')

# Generated at 2022-06-12 10:23:25.695024
# Unit test for function main
def test_main():
    for i in range(0, len(sys.argv)):
        del sys.argv[i]
    sys.argv = sys.argv + ['--help']
    assert main() == None
    sys.argv = sys.argv + ['--version']
    assert main() == None
    sys.argv = sys.argv + ['--alias', 'fuck']
    assert main() == None
    sys.argv = sys.argv + ['--shell-logger', 'bash']
    assert main() == None
    sys.argv = sys.argv + ['echo', 'a', 'b']
    assert main() == None

# Generated at 2022-06-12 10:23:26.978047
# Unit test for function main
def test_main():
    assert(callable(main))

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:34.761356
# Unit test for function main
def test_main():
    import tempfile
    import shlex
    import argparse
    from subprocess import Popen, PIPE

    with tempfile.TemporaryDirectory() as directory:
        history = os.path.join(directory, 'history')
    
        def env(env, command):
            env = dict(os.environ, **env)
            return Popen(shlex.split(command),
                         stdout=PIPE, stderr=PIPE, env=env)

        assert env({'TF_HISTORY': history},
                   'thefuck --explain') == 0
        assert env({'TF_HISTORY': history},
                   'thefuck --version') == 0
        assert env({},
                   'thefuck --version') == 0
        assert env({'TF_HISTORY': history},
                   'thefuck --alias') == 0

# Generated at 2022-06-12 10:23:35.637480
# Unit test for function main
def test_main():
    main()


# Generated at 2022-06-12 10:23:35.968932
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:23:43.698209
# Unit test for function main
def test_main():
    from unittest.mock import patch, call  # noqa: E402

    with patch.object(sys, 'argv', ['thefuck']):
        with patch('thefuck.shells.get_shell') as get_shell:
            get_shell.return_value.support_alias = True
            main()
            assert get_shell.mock_calls == [call()]

    with patch.object(sys, 'argv', ['thefuck', '--help']):
        with patch('thefuck.shells.get_shell') as get_shell:
            get_shell.return_value.support_alias = True
            main()
            assert get_shell.mock_calls == []


# Generated at 2022-06-12 10:24:18.775904
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from ..argument_parser import Parser

    with patch.object(Parser, 'parse', return_value=None):
        with patch.object(Parser, 'print_help'):
            with patch.object(Parser, 'print_usage'):
                main()

# Generated at 2022-06-12 10:24:19.239476
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:24:20.025349
# Unit test for function main
def test_main():
    assert main() == 'Error'

# Generated at 2022-06-12 10:24:20.821845
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:24:24.154396
# Unit test for function main
def test_main():
    known_args = Parser().parse(sys.argv)
    assert main() == fix_command(known_args)

# Generated at 2022-06-12 10:24:24.560306
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:24:26.526993
# Unit test for function main
def test_main():
    try:
        parser = Parser()
        known_args = parser.parse([])
        fix_command(known_args)
    except:
        pass

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:24:33.686503
# Unit test for function main
def test_main():
    from argparse import Namespace
    logger = logs.Logger(True)
    sys_args = sys.argv
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-12 10:24:34.566499
# Unit test for function main
def test_main():
    assert(main())

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:24:36.276466
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code == 0


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:25:55.610442
# Unit test for function main
def test_main():
    init_output()

    # Test the alias option
    sys.argv = ['thefuck', '--alias']
    # Test the command option
    sys.argv = ['thefuck', '--command', 'vim']
    # Test the command line mode
    sys.argv = ['thefuck', 'vim', 'abc.txt']
    # Test the shell logger
    sys.argv = ['thefuck', '--shell-logger']
    # Test the version option
    sys.argv = ['thefuck', '--version']
    # Test the help option
    sys.argv = ['thefuck', '--help']
    # Test the error case
    sys.argv = ['thefuck']

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:25:58.046398
# Unit test for function main
def test_main():
    from unittest.mock import patch

    with patch('sys.argv', ['thefuck', '-h']):
        main()
        assert sys.argv[1] == '-h'

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:25:59.863635
# Unit test for function main
def test_main():
    from unittest.mock import patch

    with patch('thefuck.main.fix_command', return_value=None):
        main()

# Generated at 2022-06-12 10:26:00.345543
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:26:00.897980
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:26:03.000675
# Unit test for function main
def test_main():
    sys.argv = ['', 'fuck', 'dap']
    exitCodes = main()
    assert exitCodes == 0 or exitCodes == 1

# Generated at 2022-06-12 10:26:04.554992
# Unit test for function main
def test_main():
    sys.argv = ['']
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:26:04.949733
# Unit test for function main
def test_main():
    assert main

# Generated at 2022-06-12 10:26:10.123381
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)

    assert known_args.help == False
    assert known_args.version == False
    assert known_args.alias == False
    assert known_args.command == False
    assert known_args.shell_logger == False
    assert known_args.no_colors == False

# Generated at 2022-06-12 10:26:10.696522
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:28:43.561341
# Unit test for function main
def test_main():
    print_alias_called = 0
    fix_command_called = 0

    class MockParser:
        def parse(self, args):
            return MockArgs()

        def print_usage(self):
            pass

        def print_help(self):
            pass

    class MockArgs:
        help = False
        version = False
        alias = False
        command = False
        shell_logger = False

    class MockLogs:
        @staticmethod
        def version(*args):
            pass

        @staticmethod
        def warn(*args):
            pass

    class MockShell:
        @staticmethod
        def info():
            return 'a shell'

    class MockPrintAlias:
        def __init__(self):
            nonlocal print_alias_called
            print_alias_called += 1


# Generated at 2022-06-12 10:28:43.954385
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:28:44.819125
# Unit test for function main
def test_main():
    print("Running test_main function!\n\n")
    main()

# Generated at 2022-06-12 10:28:50.030668
# Unit test for function main
def test_main():
    l = []
    def mock_fix_command(arg):
        l.append(len(arg.command))
    parser = Parser()
    parser.parse = lambda arg: arg
    parser.print_help = lambda: l.append(1)
    parser.print_usage = lambda: l.append(2)
    logs.version = lambda a,b,c: l.append((a,b,c))
    try:
        from .shell_logger import shell_logger  # noqa: E402
    except ImportError:
        pass
    else:
        shell_logger = lambda x: x
    print_alias = lambda x: x
    main = lambda: l.append(3)
    main()
    assert l == [3], "Main function is not working"

# Generated at 2022-06-12 10:28:50.464338
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:28:51.866802
# Unit test for function main
def test_main():
    logged_data = [l for l in logs.get_logger().debug_data if 'fucked' in l]
    assert(len(logged_data) > 0)
    return logged_data

# Generated at 2022-06-12 10:29:00.418722
# Unit test for function main
def test_main():
    import sys
    from random import randint
    from io import StringIO
    from unittest import TestCase
    from unittest.mock import patch, MagicMock

    from .utils import get_installation_info

    class TestParser(Parser):
        def __init__(self):
            super().__init__()
            self.known_args = self.parse(sys.argv)

    class TestFunc(TestCase):
        def test_help_option(self):
            with patch('sys.argv', ['thefuck', '-h']):
                with patch('thefuck.main.Parser') as mock_parser:
                    mock_parser.return_value = TestParser()

# Generated at 2022-06-12 10:29:01.100631
# Unit test for function main
def test_main():
    unittest.main()

# Generated at 2022-06-12 10:29:07.823339
# Unit test for function main
def test_main():
    logs.version = MagicMock()
    logs.warn = MagicMock()
    get_installation_info = MagicMock()
    get_installation_info.version = 1
    parser = MagicMock()
    known_args = MagicMock()
    known_args.version = False
    known_args.help = False
    known_args.alias = False
    known_args.shell_logger = False
    known_args.command = False
    os.environ['TF_HISTORY'] = "False"
    with patch('sys.argv', ["thefuck"]):
        main()
        logs.version.assert_called_once()
    with patch('sys.argv', ["thefuck", "-v"]):
        main()
        logs.version.assert_called_once()

# Generated at 2022-06-12 10:29:09.640927
# Unit test for function main
def test_main():
    log = logs.get_log()
    log.getChild('version').setLevel(logging.CRITICAL)
    log.setLevel(logging.CRITICAL)
    main()