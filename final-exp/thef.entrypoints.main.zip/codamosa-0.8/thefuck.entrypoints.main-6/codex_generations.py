

# Generated at 2022-06-12 10:22:00.005935
# Unit test for function main
def test_main():
    with mock.patch('sys.argv', ['thefuck', '--version']):
        with mock.patch('thefuck.logs.version') as version:
            main()
            assert version.call_count == 1

    with mock.patch('sys.argv', ['thefuck', '--help']):
        with mock.patch('thefuck.argument_parser.Parser.print_help') as \
                print_help:
            main()
            assert print_help.call_count == 1
            assert print_help.call_args == mock.call()

    with mock.patch('sys.argv', ['thefuck', '--alias']):
        with mock.patch('thefuck.alias.print_alias') as print_alias:
            main()
            assert print_alias.call_count == 1
            assert print_alias.call_

# Generated at 2022-06-12 10:22:04.586499
# Unit test for function main
def test_main():
    # Testing to check whether the version information is printed.
    import io
    import sys
    import contextlib
    sys.argv.append("--version")
    sys.argv.append("--quiet")
    f = io.StringIO()
    fix_command({})
    with contextlib.redirect_stdout(f):
        main()
    output = f.getvalue().strip()
    assert output == '3.3.0'

# Generated at 2022-06-12 10:22:05.400210
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:22:06.424615
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:08.052578
# Unit test for function main
def test_main():
    sys.argv = ["thefuck", "--version"]
    assert main() == None


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:08.579555
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:09.049516
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:09.484215
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:12.507820
# Unit test for function main
def test_main():
    class arg(object):
        pass
    obj = arg()
    obj.help = True
    obj.version = False
    obj.alias = False
    obj.command = False
    obj.shell_logger = None
    sys.argv = ['thefuck']
    main()

# Generated at 2022-06-12 10:22:14.335274
# Unit test for function main
def test_main():
    if __name__ == "__main__":
        main()
    if __name__ == "__main__":
        main()

# Generated at 2022-06-12 10:22:28.354283
# Unit test for function main
def test_main():
    test_parser = Parser()
    known_args = test_parser.parse(sys.argv)
    # test to help arg
    try:
        test_parser.print_help()
    except:
        assert True
    else:
        assert False
    # test version arg
    try:
        logs.version(get_installation_info().version,
                     sys.version.split()[0], shell.info())
    except:
        assert True
    else:
        assert False
    # test alias arg
    try:
        print_alias(known_args)
    except:
        assert True
    else:
        assert False
    # test fix arg
    try:
        fix_command(known_args)
    except:
        assert True
    else:
        assert False
    # test usage

# Generated at 2022-06-12 10:22:36.740069
# Unit test for function main
def test_main():
    from unittest import mock
    from .. import settings
    from ..parser import get_parser
    from ..system import init_shell

    shell_info = init_shell()
    _, parser = get_parser(os.path.basename(sys.argv[0]), shell_info)

    with mock.patch('sys.argv',
                    [os.path.basename(sys.argv[0]), "--version"]):
        main()

    with mock.patch('sys.argv',
                    [os.path.basename(sys.argv[0]), "--help"]):
        main()

    with mock.patch('sys.argv',
                    [os.path.basename(sys.argv[0]), "--alias", "thefuck"]):
        main()


# Generated at 2022-06-12 10:22:37.821244
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:38.914450
# Unit test for function main
def test_main():
    assert main() is None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:47.104819
# Unit test for function main
def test_main():
    import sys
    import unittest
    import unittest.mock
    from ..stats import main_for_stats

    class testMain(unittest.TestCase):

        @unittest.mock.patch('sys.argv', ['thefuck', '--alias'])
        def test_main_alias(self):
            assert not main()

        @unittest.mock.patch('sys.argv', ['thefuck', '--shell_logger'])
        def test_main_shell_logger(self):
            assert not main()

        def test_main_no_args(self):
            assert not main()

        @unittest.mock.patch('sys.argv', ['thefuck', '--version'])
        def test_main_version(self):
            assert not main()


# Generated at 2022-06-12 10:22:54.438392
# Unit test for function main
def test_main():
    from types import MethodType
    import unittest.mock
    # pylint: disable=global-statement
    global sys
    global os
    sys = unittest.mock.MagicMock()
    sys.argv = []
    os = unittest.mock.MagicMock()
    os.environ = {}
    os.environ['TF_HISTORY'] = 'a'
    main()
    # os.environ
    # os.environ['TF_HISTORY'] = 'a'
    # os.environ = {'TF_HISTORY':'a'}
    sys.argv = ['t','--alias','zsh','--','command','--with','args']
    main()
    assert isinstance(sys.exit, MethodType)

# Generated at 2022-06-12 10:22:56.675321
# Unit test for function main
def test_main():
    os.environ["TF_SHELL"] = "fish"
    os.environ["TF_HISTORY"] = "0"
    try:
        main()
        assert True
    except SystemExit:
        assert True
    except:
        assert False

# Generated at 2022-06-12 10:22:59.675037
# Unit test for function main
def test_main():
    sys.argv = ['thefuck', 'cf', 'start']
    logs.disabled = True
    # Rewrite is not needed, so parser should print_usage()
    main()

# Generated at 2022-06-12 10:23:00.248317
# Unit test for function main
def test_main():
   main()

# Generated at 2022-06-12 10:23:03.270202
# Unit test for function main
def test_main():
    # Check if the same format before and after main
    parser = Parser()
    old_args = parser.parse(sys.argv)
    main()
    new_args = parser.parse(sys.argv)
    assert old_args == new_args

# Generated at 2022-06-12 10:23:26.168296
# Unit test for function main
def test_main():
    import thefuck  # noqa: F401
    import imp  # noqa: F401
    imp.reload(thefuck.main)
    import os  # noqa: F401
    import sys  # noqa: F401
    from thefuck.argument_parser import Parser  # noqa: F401
    # Test of help
    sys.argv = ['thefuck', '--help']
    thefuck.main.main()
    sys.argv = ['thefuck', '-h']
    thefuck.main.main()
    # Test of version
    sys.argv = ['thefuck', '--version']
    thefuck.main.main()
    sys.argv = ['thefuck', '-V']
    thefuck.main.main()
    # Te

# Generated at 2022-06-12 10:23:26.640326
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:23:27.390432
# Unit test for function main
def test_main():
    main()
    assert True

# Generated at 2022-06-12 10:23:28.523903
# Unit test for function main
def test_main():
    os.environ['TF_HISTORY'] = 'TEST'
    s = main()

# Generated at 2022-06-12 10:23:32.197592
# Unit test for function main
def test_main():
    test_args = ['-h','-v','--alias','--command','--shell-logger']
    parser = Parser()
    for test_arg in test_args:
        known_args = parser.parse([test_arg])
        main()
    
    
if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:32.917824
# Unit test for function main
def test_main():
    args = ["fuck", "--help"]
    main()

# Generated at 2022-06-12 10:23:33.466968
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:23:35.831266
# Unit test for function main
def test_main():
    known_args = Parser().parse(sys.argv)
    assert known_args.command or 'TF_HISTORY' in os.environ


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:23:37.210071
# Unit test for function main
def test_main():
    ok = True

    if __name__ == '__main__':
        ok = False

    assert ok

# Generated at 2022-06-12 10:23:44.916961
# Unit test for function main
def test_main():
    from unittest.mock import patch, call # noqa: E402
    
    with patch('sys.argv', [
            'thefuck', 'command', '--shell', 'zsh'
        ]), \
        patch('thefuck.shells.get_shell') as mock_get_shell, \
        patch('thefuck.utils.get_shared_lib') as mock_get_shared_lib, \
        patch('thefuck.utils.get_closest') as mock_get_closest, \
        patch('thefuck.utils.get_settings') as mock_get_settings, \
        patch('thefuck.settings.load_settings') as mock_load_settings:

        mock_get_shell.return_value = 'zsh'

# Generated at 2022-06-12 10:24:16.162964
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:24:22.385861
# Unit test for function main
def test_main():
    from unittest.mock import Mock, patch
    from .alias import print_alias as _print_alias
    from .fix_command import fix_command as _fix_command
    from ..utils import get_installation_info as _get_installation_info
    sys.argv = ['thefuck']
    with patch('thefuck.argument_parser.Parser.parse',
               Mock(return_value=Mock(help=True))):
        with patch('thefuck.argument_parser.Parser.print_help') as ph:
            assert main() == ph.return_value

# Generated at 2022-06-12 10:24:24.268769
# Unit test for function main
def test_main():
    main()


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:24:25.270264
# Unit test for function main
def test_main():
    main()
    assert True

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:24:29.233987
# Unit test for function main
def test_main():
    import mock
    mock_parser = mock.Mock()
    mock_parser.parse = mock.Mock(return_value=mock.Mock(help=False,version=False, command=False, alias=False, shell_logger=False))
    with mock.patch('thefuck.main.Parser', return_value=mock_parser):
        assert main() == None

# Generated at 2022-06-12 10:24:32.893562
# Unit test for function main
def test_main():
    import unittest.mock
    sys.argv = ["thefuck"]
    with unittest.mock.patch('..argument_parser.Parser.parse'):
        with unittest.mock.patch('..argument_parser.Parser.print_help'):
            with unittest.mock.patch('..logs.version'):
                main()                                         


# Generated at 2022-06-12 10:24:33.362892
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:24:35.971551
# Unit test for function main
def test_main():
    from unittest.mock import MagicMock
    from unittest.mock import patch
    from unittest.mock import mock_open
    #from unittest.mock import mock_open
    sys.argv = ['thefuck', '--version']
    logs.version = MagicMock()
    main()
    #assert False

# Generated at 2022-06-12 10:24:41.906694
# Unit test for function main
def test_main():
    from .alias import main as print_alias
    from .fix_command import main as fix_command
    from .shell_logger import main as shell_logger
    from sys import argv, platform

    main_test_cases = [
        ("--help", "print_help"),
        ("--version", "logs.version"),
        ("--alias", "print_alias"),
        ("--command", "fix_command"),
        ("--shell-logger", "shell_logger")
    ]

    def test(input, output):
        args = ["thefuck", input]
        with patch.object(Parser, "parse", lambda *args: args[1][1]):
            argv = patch.object(__name__, "argv", args)
            with argv:
                main()
                output.assert_called()



# Generated at 2022-06-12 10:24:42.544047
# Unit test for function main
def test_main():
    assert main()


# Generated at 2022-06-12 10:25:54.993161
# Unit test for function main
def test_main():
    """
    args.alias is True
    """
    print('args.alias is True')
    sys.argv = ['thefuck', '--alias']
    try:
        main()
    except SystemExit as e:
        assert e.code == 0
    else:
        assert False


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:25:55.467248
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:25:56.175639
# Unit test for function main
def test_main():
    assert hasattr(main, '__call__')

# Generated at 2022-06-12 10:25:57.163074
# Unit test for function main
def test_main():
  try:
    main()
  except SystemExit:
    return 1
  return 0

# Generated at 2022-06-12 10:26:05.303846
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .alias import test_print_alias
    from .fix_command import test_fix_command
    from .shell_logger import test_shell_logger

    with patch('sys.argv', ['thefuck', '--help']):
        with patch('thefuck.argument_parser.Parser.print_help') as print_help:
            main()
            assert print_help.called

    with patch('sys.argv', ['thefuck', '--version']):
        with patch('thefuck.logs.version') as version:
            main()
            version.assert_called_with('7.0', '3.7.3', 'zsh')


# Generated at 2022-06-12 10:26:14.988633
# Unit test for function main
def test_main():
    # Test help message
    sys.argv = ["thefuck", "-h"]
    with mock.patch('sys.stdout', new=StringIO()) as mock_stdout:
        main()
    assert 'Show this message and exit.' in mock_stdout.getvalue()

    # Test version message
    sys.argv = ["thefuck", "--version"]
    with mock.patch('sys.stdout', new=StringIO()) as mock_stdout:
        main()
    assert 'The Fuck 3' in mock_stdout.getvalue()

    # Test thefuck command
    from ..application import Application
    sys.argv = ["thefuck", "git"]
    mock_app = mock.Mock(spec=Application)
    mock_app.run.return_value = "Good Command"
    

# Generated at 2022-06-12 10:26:19.688858
# Unit test for function main
def test_main():
    """
        This test unit checks the help() and version() methods are printed
        when specified from the command line.
    """
    import sys
    orig_sys_args = sys.argv
    sys_argv = ['thefuck', '--version']
    sys.argv = sys_argv
    main()
    sys_argv = ['thefuck', '--help']
    sys.argv = sys_argv
    main()
    sys.argv = orig_sys_args

# Generated at 2022-06-12 10:26:20.735971
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:26:21.177259
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:26:21.594294
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:28:42.265842
# Unit test for function main
def test_main():
    assert main() == None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:28:45.630903
# Unit test for function main
def test_main():
    import subprocess
    import thefuck
    # Install thefuck with the '--no-alias' flag to prevent it from adding
    # an alias when it is installed
    subprocess.check_call(['pip','install','--no-alias','.'])
    # Load the installed thefuck as a module to run the main function
    # which would normally be run when thefuck is executed in the command line
    thefuck.main()

# Generated at 2022-06-12 10:28:48.110207
# Unit test for function main
def test_main():
    # unit test for main method
    main()
    # output and assert
    out, err = capsys.readouterr()
    assert out == 'usage: thefuck [-h] [-v] [-l] [-p] [-a ALIAS] [-e] [-f] [-s] [-c] [--] [command]\n'


# Generated at 2022-06-12 10:28:48.898669
# Unit test for function main
def test_main():
    sys.argv = sys.argv[:1]
    main()

# Generated at 2022-06-12 10:28:49.312957
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:28:49.672658
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:28:50.105186
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:28:51.050148
# Unit test for function main
def test_main():
    sys.argv[1:] = ['fuck']
    assert main()

# Generated at 2022-06-12 10:28:59.822373
# Unit test for function main
def test_main():
    from .test_utils import Monkey
    from ..argument_parser import Parser
    from .. import logs
    from sys import argv

    monkey = Monkey(Parser, 'parse', lambda _: argparse.Namespace(command=True))
    monkey.patch()
    argv[1:] = ["command"]
    with Monkey(logs, 'warn', lambda _: None):
        main()
    assert argv[1:] == ["command"]
    monkey.revert()
    monkey = Monkey(Parser, 'parse', lambda _: argparse.Namespace(version=True))
    monkey.patch()
    argv[1:] = ["version"]
    with Monkey(logs, 'version', lambda _: None):
        main()
    assert argv[1:] == ["version"]
    monkey.revert()

# Generated at 2022-06-12 10:29:00.630015
# Unit test for function main
def test_main():
	pass


if __name__ == '__main__':
    main()