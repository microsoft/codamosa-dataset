

# Generated at 2022-06-12 10:21:46.516919
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit as e:
        assert e.code==0

# Generated at 2022-06-12 10:21:46.976380
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:21:55.073637
# Unit test for function main
def test_main():
    from .. import __version__ as version
    from ..utils import get_installation_info
    from ..shells import shell
    import sys

    get_installation_info_mock = mock.PropertyMock(return_value=
        mock.Mock(version=version, commit=None)
    )
    with mock.patch.object(get_installation_info, '__class__',
                           get_installation_info_mock):
        with mock.patch.object(logs, 'version', return_value=None):
            with mock.patch.object(sys, 'argv', ['thefuck', '--version']):
                main()
                logs.version.assert_called_once_with(version,
                    sys.version.split()[0], shell.info())


# Generated at 2022-06-12 10:21:56.887925
# Unit test for function main
def test_main():
    foo = ['python', 'fuck.py', '--alias']
    main(foo)


if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:21:57.395467
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:21:58.214486
# Unit test for function main
def test_main():
    assert main() == None
    
test_main()

# Generated at 2022-06-12 10:22:01.152713
# Unit test for function main
def test_main():
    parser = Parser()
    known_args = parser.parse(sys.argv)
    assert known_args.help == False
    assert known_args.version == False
    assert known_args.alias == False

# Generated at 2022-06-12 10:22:01.469550
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:01.734918
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:02.078938
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:22:17.864316
# Unit test for function main
def test_main():
    import os                   # noqa: E402
    from unittest import mock  # noqa: E402

    [mock_version, mock_shell_logger, mock_fix_command] = [mock.MagicMock()
                                                           for i in range(3)]
    known_args = mock.MagicMock()

    with mock.patch('sys.argv', ['thefuck', '--version']):
        with mock.patch('thefuck.main.get_installation_info', mock.Mock(return_value=mock_version)):
            with mock.patch('thefuck.main.logs', mock.Mock()):
                with mock.patch('thefuck.shells.shell.info', mock.Mock(return_value='test shell_info')):
                    main()

# Generated at 2022-06-12 10:22:18.255853
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:18.675097
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-12 10:22:19.128169
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:25.726951
# Unit test for function main
def test_main():
    import os
    import sys

    from textwrap import dedent
    from unittest.mock import MagicMock, patch
    from .fix_command import fix_command

    class Args(object):
        def __init__(self, alias=False, command=False, help=False,
                     shell_logger=False, version=False):
            self.alias = alias
            self.command = command
            self.help = help
            self.shell_logger = shell_logger
            self.version = version

    with patch("sys.stdout", new_callable=MagicMock) as stdout:
        with patch("os.environ", {}):
            main(Args(help=True))
            stdout.assert_not_called()  # noqa: B950


# Generated at 2022-06-12 10:22:26.090112
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:26.538557
# Unit test for function main
def test_main():
    assert main

# Generated at 2022-06-12 10:22:27.994132
# Unit test for function main
def test_main():
    import types
    assert isinstance(main, types.FunctionType), 'main is not a function'

# Generated at 2022-06-12 10:22:31.056317
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    # Ensure error stack is printed
    logs.enable_debug()
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:22:31.536375
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:47.572406
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:22:49.709212
# Unit test for function main
def test_main():
    try:
        main()
    except SystemExit:
        pass
    except OSError:
        pass  # On OSError, exists with code 1 and SystemExit is raised

# Generated at 2022-06-12 10:22:50.243552
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:22:50.750649
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:22:54.390382
# Unit test for function main
def test_main():
    # Test if help flag is True
    main.__code__ = Parser().parse(['fuck']).help

    # Test if version flag is True
    main.__code__ = Parser().parse(['fuck', '--version']).version

    # Test if alias flag is True
    main.__code__ = Parser().parse(['fuck', '--alias']).alias

    # Test if command is not empty
    main.__code__ = Parser().parse(['fuck', 'echo']).command

    # Test if TF_HISTORY is not empty
    os.environ['TF_HISTORY'] = ''
    main.__code__ = 'TF_HISTORY' in os.environ

# Generated at 2022-06-12 10:23:03.272516
# Unit test for function main
def test_main():
    global sys, os
    from .. import argument_parser
    from .. import utils
    from .. import logs
    from .. import shells
    from .. import system

    #sys
    sys_get_argv_return = ['fuck']
    sys_get_stdout_return = ['--version']
    sys_exit_return = 0


    #os
    os_environ = {'TF_HISTORY': 100}

    #argument_parser
    argument_parser_parser_return = ['fuck']

    #logs
    logs_version_return = ['fuck']
    logs_warn_return = 'fuck'

    #utils
    get_installation_info_return = 'fuck'

    #shells.shell.info
    shells.shell.info_return = 'fuck'

    #system.init_output
    init_

# Generated at 2022-06-12 10:23:11.135282
# Unit test for function main
def test_main():
    # Mock the existing args
    parser = Parser()
    known_args = parser.parse(sys.argv)

    # Test help
    old_stdout = sys.stdout
    sys.stdout = open('out', 'w')
    known_args.help = True
    main()
    sys.stdout.close()
    sys.stdout = old_stdout
    outfile = open('out', 'r')
    outtext = outfile.read()
    outfile.close()
    os.remove('out')
    assert 'usage: thefuck' in outtext

    # Test version
    old_stdout = sys.stdout
    sys.stdout = open('out', 'w')
    known_args.version = True
    main()
    sys.stdout.close()

# Generated at 2022-06-12 10:23:11.607111
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:23:12.771765
# Unit test for function main
def test_main():
    pars = Parser()
    known_args = pars.parse(sys.argv)
    main()

# Generated at 2022-06-12 10:23:19.343543
# Unit test for function main
def test_main():
    import io
    import sys
    import unittest.mock as mock
    import pytest
    from ..argument_parser import Parser
    from thefuck import logs
    from thefuck.shells import shell

    def get_info():
        return get_installation_info()

    def get_version():
        return get_installation_info().version

    def get_shell():
        return shell.info()

    def to_bytes(string):
        return bytes(string.encode())

    def py_version():
        return sys.version.split()[0]

    @pytest.fixture
    def mock_parser(request):
        parser = Parser()
        with mock.patch('thefuck.main.Parser') as Parser:
            Parser.return_value = parser
            yield parser


# Generated at 2022-06-12 10:23:51.551891
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:23:52.034604
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:23:54.774436
# Unit test for function main
def test_main():
    from unittest import mock

    import sys
    with mock.patch.object(sys, 'argv', ['thefuck']):
        # Testing if main function runs
        try:
            main()
        except SystemExit:
            pass

# Generated at 2022-06-12 10:23:55.590040
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:23:59.853326
# Unit test for function main
def test_main():
    from unittest.mock import patch
    from .get_alias import get_alias  # noqa: E402

    test_path = 'thefuck.shells.get_aliases'
    with patch(test_path, return_value={'test': 'correct'}):
        assert get_alias(test_path) == {'test': 'correct'}

# Generated at 2022-06-12 10:24:00.604657
# Unit test for function main
def test_main():

    from thefuck import main
    main()

# Generated at 2022-06-12 10:24:01.702924
# Unit test for function main
def test_main():
    assert main() != None

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:24:08.206692
# Unit test for function main
def test_main():
    from mock import patch, Mock, MagicMock
    from .utils import get_parsed_args
    from .alias import print_alias
    from .fix_command import fix_command
    from .argument_parser import  Parser
    from ..system import init_output
    from .. import logs

    init_output()
    parser = Parser()
    # Test help
    with patch.object(Parser, 'parse_args', return_value=get_parsed_args(help=True)):
        with patch.object(parser, 'print_help') as mock_method:
                main()
                assert mock_method.called
    # Test version

# Generated at 2022-06-12 10:24:09.208634
# Unit test for function main
def test_main():
    pass

# Generated at 2022-06-12 10:24:14.835166
# Unit test for function main
def test_main():
    logs = []
    parser = Parser(logs=logs)
    known_args = parser.parse(("-h",))
    assert known_args.help
    assert not known_args.version
    assert not known_args.alias
    assert not known_args.command
    assert not known_args.shell_logger
    main()
    assert logs == ["usage: tf [-h] [-v] [--alias ALIAS] [--shell-logger SHELL]",
                    'tf: error: the following arguments are required: command']


# Generated at 2022-06-12 10:25:24.544802
# Unit test for function main
def test_main():
    main()


# Test whether nvbn is installed

# Generated at 2022-06-12 10:25:25.195103
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:25:25.698557
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:25:26.126303
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:25:27.123332
# Unit test for function main
def test_main():
    if __name__ == '__main__':
        sys.exit(main())

# Generated at 2022-06-12 10:25:28.010537
# Unit test for function main
def test_main():
    my_main = main()
    assert my_main == None

# Generated at 2022-06-12 10:25:28.815151
# Unit test for function main
def test_main():
    assert main() == None

# Generated at 2022-06-12 10:25:29.254802
# Unit test for function main
def test_main():
    main()

# Generated at 2022-06-12 10:25:30.103500
# Unit test for function main
def test_main():
    main()

if __name__ == '__main__':
    main()

# Generated at 2022-06-12 10:25:32.148486
# Unit test for function main
def test_main():
    parser = Parser()
    test_argv = ["thefuck", "ls -al"]
    test_args = parser.parse(test_argv)
    test_args.command = "ls -al"
    fix_command(test_args)

# Generated at 2022-06-12 10:27:56.069422
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:27:57.694968
# Unit test for function main
def test_main():
    import unittest
    class MainTestCase(unittest.TestCase):
        def test_main(self):
            self.assertEqual(main(),None)

    unittest.main()

# Generated at 2022-06-12 10:27:58.181507
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:27:58.574115
# Unit test for function main
def test_main():
    assert main() is None

# Generated at 2022-06-12 10:28:05.635856
# Unit test for function main
def test_main():
    #  Get list of arguments name
    argument_list = list(Parser().parse_args().__dict__.keys())
    assert argument_list.__contains__('help')
    assert argument_list.__contains__('version')
    assert argument_list.__contains__('shell')
    assert argument_list.__contains__('alias')

    # Check if arguments are working
    sys.argv.append('--help')
    main()
    sys.argv.remove('--help')

    sys.argv.append('--version')
    main()
    sys.argv.remove('--version')

    sys.argv.append('--alias')
    main()
    sys.argv.remove('--alias')

# Generated at 2022-06-12 10:28:06.392398
# Unit test for function main
def test_main():
    #main()
    assert True

# Generated at 2022-06-12 10:28:14.075729
# Unit test for function main
def test_main():
    import subprocess
    import os
    import sys
    import shutil
    import inspect

    def run(*args):
        cwd = os.path.dirname(os.path.abspath(__file__))
        path = os.path.join(cwd, '..', '..')
        if path not in os.environ["PYTHONPATH"].split(os.pathsep):
            os.environ["PYTHONPATH"] = os.pathsep.join([path,
                                                        os.environ["PYTHONPATH"]])
            os.execv(sys.executable, [sys.executable] + list(args))

    # Store current directory to go back
    current_dir = os.getcwd()

    # Replace temporary variables

# Generated at 2022-06-12 10:28:14.730502
# Unit test for function main
def test_main():
    assert main()

# Generated at 2022-06-12 10:28:15.971608
# Unit test for function main
def test_main():
    print("Method main - START")
    assert(main())
    print("Method main - END")

# Generated at 2022-06-12 10:28:18.128469
# Unit test for function main
def test_main():
    '''
    Tests to see if the function is handled correctly

    '''
    # Testing to see if an alias is handled correctly
    main(['--alias', 'fuck'])
    
    # Testing to see if the help is handled correctly
    main(['--help'])