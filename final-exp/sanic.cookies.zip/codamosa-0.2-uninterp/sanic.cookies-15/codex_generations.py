

# Generated at 2022-06-18 04:58:41.254826
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 04:58:45.818675
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert "foo" in cookie_jar
    cookie_jar["foo"] = "baz"
    assert "foo" in cookie_jar
    del cookie_jar["foo"]
    assert "foo" not in cookie_jar
    assert headers.getall("Set-Cookie") == []


# Generated at 2022-06-18 04:58:58.303394
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:08.780452
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["path"] = "test"
    assert cookie["path"] == "test"
    cookie["comment"] = "test"
    assert cookie["comment"] == "test"
    cookie["domain"] = "test"
    assert cookie["domain"] == "test"
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["secure"] = "test"
    assert cookie["secure"] == "test"
    cookie["httponly"] = "test"
    assert cookie["httponly"] == "test"
    cookie["version"] = "test"
    assert cookie["version"] == "test"
    cookie["samesite"] = "test"


# Generated at 2022-06-18 04:59:14.029066
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:24.185425
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"

# Generated at 2022-06-18 04:59:36.727148
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True


# Generated at 2022-06-18 04:59:48.828040
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:59.309429
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c["max-age"] = "10"
    assert str(c) == "name=value; Max-Age=10"
    c["expires"] = datetime(2020, 1, 1, 1, 1, 1)
    assert str(c) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 01:01:01 GMT"
    c["secure"] = True
    assert str(c) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 01:01:01 GMT; Secure"
    c["httponly"] = True

# Generated at 2022-06-18 05:00:07.021736
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "test"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "test"



# Generated at 2022-06-18 05:00:22.860117
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:00:28.073105
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:00:38.041593
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "0"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 05:00:48.472318
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"

    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"

    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "test=test; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie["secure"] = True

# Generated at 2022-06-18 05:00:58.429468
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=%s; Secure; HttpOnly; Version=1; SameSite=Strict; Comment=test; Domain=test" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-18 05:01:07.318634
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    cookie['path'] = '/'
    cookie['domain'] = 'example.com'
    cookie['comment'] = 'comment'
    cookie['max-age'] = 'max-age'
    cookie['secure'] = 'secure'
    cookie['httponly'] = 'httponly'
    cookie['version'] = 'version'
    cookie['samesite'] = 'samesite'
    cookie['expires'] = 'expires'
    assert str(cookie) == 'name=value; Path=/; Domain=example.com; Comment=comment; Max-Age=max-age; Secure; HttpOnly; Version=version; SameSite=samesite; Expires=expires'


# Generated at 2022-06-18 05:01:13.277748
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"


# Generated at 2022-06-18 05:01:23.842811
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:01:29.580147
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:01:39.645700
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"
    cookie["max-age"] = "1"
    assert str(cookie) == "key=value; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["secure"] = False

# Generated at 2022-06-18 05:01:54.382483
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:02:05.223457
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test3"] = "test3"

# Generated at 2022-06-18 05:02:16.712007
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"
    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=test; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert (
        str(cookie)
        == "test=test; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    )
    cookie["secure"] = True

# Generated at 2022-06-18 05:02:21.730470
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:02:31.057366
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = "example.com"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "This is a comment"

# Generated at 2022-06-18 05:02:41.007606
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    assert str(cookie) == "key=value; Max-Age=0; Expires=%s; Path=/; Comment=comment; Domain=domain; Secure; HttpOnly; Version=1; SameSite=Lax" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")

# Generated at 2022-06-18 05:02:50.803070
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:02:57.420828
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:03:07.679139
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:03:16.231595
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = "test"
    cookie["httponly"] = "test"
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    assert str(cookie) == "test=test; Path=/; Comment=test; Domain=test; Max-Age=test; Secure; HttpOnly; Version=test; SameSite=test"


# Generated at 2022-06-18 05:03:29.831231
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"

    cookie["max-age"] = "123"
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:03:41.323527
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('key', 'value')
    cookie['expires'] = 'expires'
    cookie['path'] = 'path'
    cookie['comment'] = 'comment'
    cookie['domain'] = 'domain'
    cookie['max-age'] = 'max-age'
    cookie['secure'] = 'secure'
    cookie['httponly'] = 'httponly'
    cookie['version'] = 'version'
    cookie['samesite'] = 'samesite'
    assert cookie['expires'] == 'expires'
    assert cookie['path'] == 'path'
    assert cookie['comment'] == 'comment'
    assert cookie['domain'] == 'domain'
    assert cookie['max-age'] == 'max-age'
    assert cookie['secure'] == 'secure'
    assert cookie['httponly'] == 'httponly'
   

# Generated at 2022-06-18 05:03:49.040928
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    assert cookie_jar["key"].value == "value"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == None
    assert cookie_jar.get("key") == None


# Generated at 2022-06-18 05:03:56.949502
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = "123"
    assert cookie["max-age"] == 123
    cookie["expires"] = datetime.now()
    assert isinstance(cookie["expires"], datetime)
    cookie["secure"] = True
    assert cookie["secure"] is True
    cookie["httponly"] = True
    assert cookie["httponly"] is True
    cookie["version"] = "1"
    assert cookie["version"] == "1"
    cookie["samesite"] = "Strict"
    assert cookie["samesite"] == "Strict"
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["comment"] = "comment"
    assert cookie["comment"] == "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 05:04:05.867419
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:17.484864
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:04:22.256173
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:04:33.251865
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 3600
    assert str(cookie) == "name=value; Path=/; Max-Age=3600"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=3600; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=3600; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True


# Generated at 2022-06-18 05:04:39.667220
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:48.281449
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Max-Age=0"

    cookie["max-age"] = "0"
    assert str(cookie) == "key=value; Max-Age=0"

    cookie["max-age"] = "1"
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie

# Generated at 2022-06-18 05:05:06.704625
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 1
    assert str(cookie) == "name=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:09.725886
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:05:16.039467
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    assert len(cookie_jar) == 3
    assert len(headers) == 1
    assert len(headers["Set-Cookie"]) == 3
    del cookie_jar["key2"]
    assert len(cookie_jar) == 2
    assert len(headers) == 1
    assert len(headers["Set-Cookie"]) == 2
    assert cookie_jar["key1"] == "value1"
    assert cookie_jar["key3"] == "value3"
    del cookie_jar["key1"]
    assert len(cookie_jar) == 1
    assert len(headers) == 1

# Generated at 2022-06-18 05:05:26.190323
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"

# Generated at 2022-06-18 05:05:36.561097
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True


# Generated at 2022-06-18 05:05:43.343516
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:05:53.885424
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"
    cookie["max-age"] = "10"
    assert str(cookie) == "test=value; Path=/; Max-Age=10"
    cookie["max-age"] = 10
    assert str(cookie) == "test=value; Path=/; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True

# Generated at 2022-06-18 05:06:02.891620
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"

# Generated at 2022-06-18 05:06:09.256213
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    cookie["test"] = "test"


# Generated at 2022-06-18 05:06:17.711360
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:06:52.586207
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:06:58.734287
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    del cookie_jar["test"]
    assert cookie_jar.get("test") is None
    assert headers.get("Set-Cookie") is None


# Generated at 2022-06-18 05:07:08.562748
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = "10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "strict"
    assert str(cookie) == "key=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=strict"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"

# Generated at 2022-06-18 05:07:19.584468
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:07:26.032715
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert headers.get("Set-Cookie") == "test_key=test_value; Path=/; Max-Age=0"
    del cookie_jar["test_key"]
    assert headers.get("Set-Cookie") == None


# Generated at 2022-06-18 05:07:29.761701
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:07:34.518972
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar


# Generated at 2022-06-18 05:07:43.825251
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:51.889300
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly, test2=test2; Path=/; HttpOnly"


# Generated at 2022-06-18 05:08:03.368033
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    assert len(cookie_jar) == 3
    assert len(headers) == 1
    assert len(headers.getlist("Set-Cookie")) == 3
    del cookie_jar["key2"]
    assert len(cookie_jar) == 2
    assert len(headers) == 1
    assert len(headers.getlist("Set-Cookie")) == 2
    assert "key2" not in cookie_jar
    assert "key2" not in headers
    assert "key1" in cookie_jar
    assert "key1" in headers
    assert "key3" in cookie_jar