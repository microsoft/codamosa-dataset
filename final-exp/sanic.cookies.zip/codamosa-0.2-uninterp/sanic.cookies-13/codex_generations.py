

# Generated at 2022-06-18 04:58:19.653214
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 04:58:30.393284
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1)
    assert str(cookie) == "test=value; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:58:39.348700
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value2"

# Generated at 2022-06-18 04:58:46.917002
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    cookies["test"] = "test2"
    assert cookies["test"].value == "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly"
    cookies["test2"] = "test"
    assert cookies["test2"].value == "test"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly, test2=test; Path=/; HttpOnly"


# Generated at 2022-06-18 04:58:58.341051
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"

# Generated at 2022-06-18 04:59:04.648795
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    cookie["unknown"] = "Unknown"


# Generated at 2022-06-18 04:59:16.623603
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers.get("Set-Cookie") == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers.get("Set-Cookie") == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers.get("Set-Cookie") == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 04:59:25.762809
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:36.966288
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "lax"

# Generated at 2022-06-18 04:59:48.920512
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:02.626249
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    assert headers.get("Set-Cookie1") == "test2=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]

# Generated at 2022-06-18 05:00:07.912440
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:00:19.959089
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True


# Generated at 2022-06-18 05:00:27.721001
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:00:37.884468
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = "10"
    assert cookie["max-age"] == 10
    cookie["max-age"] = 10
    assert cookie["max-age"] == 10
    cookie["expires"] = datetime.now()
    assert isinstance(cookie["expires"], datetime)
    cookie["secure"] = True
    assert cookie["secure"] is True
    cookie["httponly"] = True
    assert cookie["httponly"] is True
    cookie["version"] = "1"
    assert cookie["version"] == "1"
    cookie["samesite"] = "Strict"
    assert cookie["samesite"] == "Strict"
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["comment"] = "comment"

# Generated at 2022-06-18 05:00:48.370253
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("key=value; Max-Age=0; Expires=")
    cookie["secure"] = True
    assert str(cookie).startswith("key=value; Max-Age=0; Expires=")
    assert str(cookie).endswith("; Secure")
    cookie["httponly"] = True
    assert str(cookie).startswith("key=value; Max-Age=0; Expires=")
    assert str(cookie).endswith("; Secure; HttpOnly")

# Generated at 2022-06-18 05:00:59.027693
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "test=test; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:07.602016
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    assert headers.getall("Set-Cookie") == [
        "foo=bar; Path=/; Max-Age=0",
        "baz=qux; Path=/; Max-Age=0",
    ]
    del cookie_jar["foo"]
    assert headers.getall("Set-Cookie") == ["baz=qux; Path=/; Max-Age=0"]
    del cookie_jar["baz"]
    assert headers.getall("Set-Cookie") == []
    assert cookie_jar == {}


# Generated at 2022-06-18 05:01:12.337288
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:01:15.416700
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:01:36.386855
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

   

# Generated at 2022-06-18 05:01:44.737147
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["unknown"] = "unknown"
    assert cookie["path"] == "/"
    assert cookie["expires"] == datetime.now()
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "comment"


# Generated at 2022-06-18 05:01:56.695316
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value2"

# Generated at 2022-06-18 05:02:06.915620
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:02:18.027672
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = "10"
    assert str(cookie) == "key=value; Path=/; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:22.341459
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:31.454063
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]

# Generated at 2022-06-18 05:02:37.214303
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = datetime(2020, 1, 1)
    assert cookie["expires"] == datetime(2020, 1, 1)
    cookie["max-age"] = 1
    assert cookie["max-age"] == 1
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    cookie["version"] = "1"
    assert cookie["version"] == "1"
    cookie["samesite"] = "Lax"
    assert cookie["samesite"] == "Lax"
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["comment"] = "comment"
    assert cookie["comment"] == "comment"

# Generated at 2022-06-18 05:02:46.001919
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 10
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 10
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"
    assert cookie.key == "test"
    assert cookie.value == "value"

# Generated at 2022-06-18 05:02:55.137713
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:03:17.396202
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0, key2=value2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:03:28.384165
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True


# Generated at 2022-06-18 05:03:39.391850
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:51.538712
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:04:01.657280
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.utcnow()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=Strict; Comment=comment; Domain=domain"

# Generated at 2022-06-18 05:04:10.502700
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["expires"] = datetime.now()
    assert isinstance(cookie["expires"], datetime)
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["max-age"] = "0"
    assert cookie["max-age"] == "0"
    cookie["max-age"] = "1"
    assert cookie["max-age"] == "1"
    cookie["max-age"] = 1
    assert cookie["max-age"] == 1
    cookie["max-age"] = False
    assert cookie["max-age"] == False


# Generated at 2022-06-18 05:04:15.875374
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:26.046923
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.utcnow()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=lax; Comment=test; Domain=test"

# Generated at 2022-06-18 05:04:36.564620
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("name=value; Path=/; Max-Age=0; Expires=")

    cookie = Cookie("name", "value")
    cookie["path"]

# Generated at 2022-06-18 05:04:47.628138
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "qux"
    cookie_jar["foo"] = "quux"
    cookie_jar["foo"] = "corge"
    cookie_jar["foo"] = "grault"
    cookie_jar["foo"] = "garply"
    cookie_jar["foo"] = "waldo"
    cookie_jar["foo"] = "fred"
    cookie_jar["foo"] = "plugh"
    cookie_jar["foo"] = "xyzzy"
    cookie_jar["foo"] = "thud"
    cookie_jar["foo"] = "foo"
    cookie_jar["foo"] = "bar"
    cookie_

# Generated at 2022-06-18 05:05:21.701651
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:05:32.233955
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:43.579804
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:05:54.070147
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Path=/; Comment=comment; Domain=domain; Max-Age=max-age; Secure; HttpOnly; Version=version; SameSite=samesite; Expires=%s" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")

# Generated at 2022-06-18 05:06:03.068203
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:06:13.840479
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    assert len(cookies) == 3
    assert len(cookies.cookie_headers) == 3
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "test=test; Path=/; test2=test2; Path=/; test3=test3; Path=/"
    del cookies["test"]
    assert len(cookies) == 2
    assert len(cookies.cookie_headers) == 2
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "test2=test2; Path=/; test3=test3; Path=/"
    del cookies["test2"]
   

# Generated at 2022-06-18 05:06:22.876103
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:06:29.122756
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert cookie_jar["key"].value == "value"
    assert cookie_jar.headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert cookie_jar.headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"
    assert cookie_jar.headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"
    assert cookie_jar.headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"
    assert cookie_jar.headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"
    assert cookie_

# Generated at 2022-06-18 05:06:37.832449
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"

# Generated at 2022-06-18 05:06:49.542596
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:07:11.442136
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:07:21.143825
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:31.349730
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"

    c = Cookie("name", "value")
    c["path"] = "/"
    assert str(c) == "name=value; Path=/"

    c = Cookie("name", "value")
    c["path"] = "/"
    c["max-age"] = 0
    assert str(c) == "name=value; Path=/; Max-Age=0"

    c = Cookie("name", "value")
    c["path"] = "/"
    c["max-age"] = 0
    c["expires"] = datetime(2020, 1, 1, 0, 0, 0)

# Generated at 2022-06-18 05:07:37.315009
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert cookie_jar["key"] == "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == None


# Generated at 2022-06-18 05:07:47.816755
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "baz"


# Generated at 2022-06-18 05:07:55.459560
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert not cookie_jar.get("test")
    assert not headers.get("Set-Cookie")
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert cookie_jar["test"] == "test2"

# Generated at 2022-06-18 05:08:06.642448
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["foo2"] = "bar2"
    cookie_jar["foo3"] = "bar3"
    cookie_jar["foo4"] = "bar4"
    cookie_jar["foo5"] = "bar5"
    cookie_jar["foo6"] = "bar6"
    cookie_jar["foo7"] = "bar7"
    cookie_jar["foo8"] = "bar8"
    cookie_jar["foo9"] = "bar9"
    cookie_jar["foo10"] = "bar10"
    cookie_jar["foo11"] = "bar11"
    cookie_jar["foo12"] = "bar12"
    cookie_jar["foo13"] = "bar13"
   

# Generated at 2022-06-18 05:08:11.521763
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert headers.get("Set-Cookie") == "foo=bar; Path=/; Max-Age=0"
    del cookie_jar["foo"]
    assert headers.get("Set-Cookie") == "foo=; Path=/; Max-Age=0"
