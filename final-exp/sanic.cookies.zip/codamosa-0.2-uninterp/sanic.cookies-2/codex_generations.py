

# Generated at 2022-06-18 04:58:34.361567
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = "example.com"

# Generated at 2022-06-18 04:58:44.827101
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    cookie_jar["baz"] = "quux"
    cookie_jar["qux"] = "quuz"
    cookie_jar["corge"] = "grault"
    cookie_jar["garply"] = "waldo"
    cookie_jar["fred"] = "plugh"
    cookie_jar["xyzzy"] = "thud"
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    cookie_jar["baz"] = "quux"
    cookie_jar["qux"] = "quuz"
    cookie_jar["corge"] = "grault"
    cookie_jar

# Generated at 2022-06-18 04:58:58.350434
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value")
    cookie["max-age"] = "10"
    assert str(cookie) == "key=value; Max-Age=10"

    cookie = Cookie("key", "value")
    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie = Cookie("key", "value")
    cookie["secure"] = True
    assert str(cookie) == "key=value; Secure"

    cookie = Cookie("key", "value")
    cookie["httponly"] = True
    assert str(cookie)

# Generated at 2022-06-18 04:59:08.781964
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'
    cookie['path'] = '/'
    assert str(cookie) == 'name=value; Path=/'
    cookie['max-age'] = 0
    assert str(cookie) == 'name=value; Path=/; Max-Age=0'
    cookie['expires'] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == 'name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT'
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure'

# Generated at 2022-06-18 04:59:20.204979
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 04:59:25.354006
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "lax"
    cookie["version"] = 1
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["samesite"] = "samesite"
    cookie["version"] = "version"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 04:59:32.428881
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:36.430012
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert cookie_jar["key"].value == "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:48.779873
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:53.246623
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"
    assert "key" not in cookie_jar


# Generated at 2022-06-18 05:00:05.440829
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:00:11.019973
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    del cookie_jar["test"]
    assert cookie_jar.get("test") is None
    assert headers.get("Set-Cookie") is None


# Generated at 2022-06-18 05:00:22.211066
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Secure"

    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:33.925416
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0, test2=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"

# Generated at 2022-06-18 05:00:45.714997
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=%s" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")

    cookie["secure"] = True

# Generated at 2022-06-18 05:00:52.994485
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:01:01.720904
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:01:10.739781
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:23.125433
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:01:33.516658
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["path"] = "test"
    assert cookie["path"] == "test"
    cookie["comment"] = "test"
    assert cookie["comment"] == "test"
    cookie["domain"] = "test"
    assert cookie["domain"] == "test"
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["secure"] = "test"
    assert cookie["secure"] == "test"
    cookie["httponly"] = "test"
    assert cookie["httponly"] == "test"
    cookie["version"] = "test"
    assert cookie["version"] == "test"
    cookie["samesite"] = "test"


# Generated at 2022-06-18 05:01:46.173182
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert "key" in cookie_jar
    assert "key" in cookie_jar.cookie_headers
    assert "Set-Cookie" in headers
    assert "key=value" in headers["Set-Cookie"]
    del cookie_jar["key"]
    assert "key" not in cookie_jar
    assert "key" not in cookie_jar.cookie_headers
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:01:52.055957
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"] == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookies["test"]
    assert "test" not in cookies
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:01:58.755125
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    assert headers["Set-Cookie"] != "test=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:07.426405
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    del cookie_jar["test"]
    assert cookie_jar["test"] == ""
    assert cookie_jar["test2"] == "test2"
    assert cookie_jar["test3"] == "test3"
    assert headers.getall("Set-Cookie") == [
        "test=; Max-Age=0; Path=/",
        "test2=test2; Path=/",
        "test3=test3; Path=/",
    ]


# Generated at 2022-06-18 05:02:18.518350
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:02:28.988588
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["path"] = "test"
    assert cookie["path"] == "test"
    cookie["comment"] = "test"
    assert cookie["comment"] == "test"
    cookie["domain"] = "test"
    assert cookie["domain"] == "test"
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["secure"] = "test"
    assert cookie["secure"] == "test"
    cookie["httponly"] = "test"
    assert cookie["httponly"] == "test"
    cookie["version"] = "test"
    assert cookie["version"] == "test"
    cookie["samesite"] = "test"


# Generated at 2022-06-18 05:02:35.716295
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:02:44.814422
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["max-age"] = 10
    assert str(cookie) == "foo=bar; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "foo=bar; Max-Age=10; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Max-Age=10; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:54.088318
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:06.468042
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = "10"
    assert str(cookie) == "test=value; Path=/; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:03:18.768828
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:03:24.036740
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:03:32.851352
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 100
    assert str(cookie) == "name=value; Max-Age=100"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:41.357571
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:03:52.924735
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:04:04.099918
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("name=value; Path=/; Max-Age=0; Expires=")

    cookie = Cookie("name", "value")
    cookie["path"]

# Generated at 2022-06-18 05:04:15.561565
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:04:26.824109
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"

# Generated at 2022-06-18 05:04:34.767700
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key"] = "value3"
    assert headers["Set-Cookie"] == "key=value3; Path=/; Max-Age=0"



# Generated at 2022-06-18 05:04:46.270804
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:05:01.830217
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 123
    assert str(cookie) == "name=value; Path=/; Max-Age=123"
    cookie["expires"] = datetime(2030, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2030 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2030 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:05:11.547448
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers.get("Set-Cookie") == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"
    assert headers.get("Set-Cookie") == "test=test3; Path=/; Max-Age=0\ntest2=test4; Path=/; Max-Age=0"
    cookie

# Generated at 2022-06-18 05:05:17.937983
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:05:26.825110
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Path=/; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:05:38.179792
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"

# Generated at 2022-06-18 05:05:46.538301
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:05:52.102665
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:05:58.607959
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:06:05.217808
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:15.560675
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:06:29.280036
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:06:33.939906
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    del cookie_jar["test"]
    assert cookie_jar == {}
    assert headers == {}


# Generated at 2022-06-18 05:06:41.258129
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["domain"] = "example.com"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert str(cookie) == (
        "name=value; Path=/; Domain=example.com; "
        "Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0; "
        "Secure; HttpOnly; Version=1; SameSite=Strict"
    )

# Generated at 2022-06-18 05:06:52.110632
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:07:04.205400
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:16.842749
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=%s; Secure; HttpOnly; Version=1; SameSite=Strict; Comment=comment; Domain=domain" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")

# ------------------------------------------------------------ #
#  Tests
# ------------------------------------------------------------ #



# Generated at 2022-06-18 05:07:21.013857
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    cookie_jar["quux"] = "quuz"
    del cookie_jar["baz"]
    assert cookie_jar["foo"] == "bar"
    assert cookie_jar["quux"] == "quuz"
    assert "baz" not in cookie_jar
    assert headers["Set-Cookie"] == "foo=bar; Path=/; baz=qux; Path=/; Max-Age=0; quux=quuz; Path=/"


# Generated at 2022-06-18 05:07:31.352410
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0,test2=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"

# Generated at 2022-06-18 05:07:41.655756
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:51.667481
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:08:04.488206
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:08:13.440220
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:08:23.302250
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   