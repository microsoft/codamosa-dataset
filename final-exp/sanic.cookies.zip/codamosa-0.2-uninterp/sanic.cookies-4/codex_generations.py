

# Generated at 2022-06-18 04:58:22.549664
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:58:33.391208
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 04:58:44.911898
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = "max-age"
    assert str(cookie) == "key=value; Max-Age=max-age"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=max-age; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=max-age; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:58:55.751049
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_value"
    assert "test_cookie" in cookie_jar
    assert "test_value" == cookie_jar["test_cookie"].value
    assert "Set-Cookie" in headers
    assert "test_cookie=test_value" in headers["Set-Cookie"]
    del cookie_jar["test_cookie"]
    assert "test_cookie" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 04:59:02.595096
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = "10"
    cookie["expires"] = datetime.utcnow()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "Lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == "10"
    assert cookie["expires"] == datetime.utcnow()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == "1"
    assert cookie["samesite"] == "Lax"

# Generated at 2022-06-18 04:59:14.732386
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 04:59:24.376524
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 04:59:36.812350
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "value")
    assert str(c) == "test=value"

    c["path"] = "/"
    assert str(c) == "test=value; Path=/"

    c["max-age"] = 0
    assert str(c) == "test=value; Path=/; Max-Age=0"

    c["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(c) == "test=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"

    c["secure"] = True
    assert str(c) == "test=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"


# Generated at 2022-06-18 04:59:48.828555
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 123
    assert str(cookie) == "key=value; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:51.920104
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:00:04.774013
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = "123"
    assert str(cookie) == "key=value; Max-Age=123"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:16.835374
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:00:26.135610
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "value"
    assert headers["Set-Cookie"] == "name=value; Path=/; Max-Age=0"
    cookie_jar["name"] = "new_value"
    assert headers["Set-Cookie"] == "name=new_value; Path=/; Max-Age=0"
    cookie_jar["name"]["max-age"] = 3600
    assert headers["Set-Cookie"] == "name=new_value; Path=/; Max-Age=3600"
    cookie_jar["name"]["max-age"] = 3600
    assert headers["Set-Cookie"] == "name=new_value; Path=/; Max-Age=3600"
    cookie_jar["name"]["max-age"]

# Generated at 2022-06-18 05:00:35.718785
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["httponly"] = True
    cookie["secure"] = True
    cookie["samesite"] = "Lax"
    assert (
        str(cookie)
        == "name=value; Path=/; expires=%s; Max-Age=0; HttpOnly; Secure; SameSite=Lax"
        % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")
    )

# Generated at 2022-06-18 05:00:46.614821
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.utcnow()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=Lax; Comment=comment; Domain=domain"

# Generated at 2022-06-18 05:00:58.724919
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:02.943087
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    del cookie_jar["test"]
    assert cookie_jar.get("test") is None
    assert headers.get("Set-Cookie") is None


# Generated at 2022-06-18 05:01:11.490942
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0; Secure"

# Generated at 2022-06-18 05:01:18.495874
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:01:26.779556
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "lax"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:01:39.946989
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:01:46.914791
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:01:58.535150
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 05:02:07.935794
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    assert headers.get("Set-Cookie", 1) == "test2=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]

# Generated at 2022-06-18 05:02:19.059154
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:02:29.464218
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("name=value; Path=/; Max-Age=0; Expires=")
    cookie["secure"] = True
    assert str(cookie).startswith(
        "name=value; Path=/; Max-Age=0; Expires="
    ) and "Secure" in str(cookie)
    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:36.001497
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie["secure"] = True

# Generated at 2022-06-18 05:02:44.928916
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 05:02:54.151554
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"
    cookie["max-age"] = "123"
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:03:06.540487
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 05:03:19.679336
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:03:30.097866
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:03:41.560581
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:03:52.964804
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:04:04.193866
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:04:12.154365
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:04:20.397307
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar['foo'] = 'bar'
    cookie_jar['baz'] = 'qux'
    cookie_jar['quux'] = 'corge'
    cookie_jar['grault'] = 'garply'
    cookie_jar['waldo'] = 'fred'
    cookie_jar['plugh'] = 'xyzzy'
    cookie_jar['thud'] = 'baz'
    cookie_jar['bar'] = 'foo'
    cookie_jar['qux'] = 'baz'
    cookie_jar['corge'] = 'quux'
    cookie_jar['garply'] = 'grault'
    cookie_jar['fred'] = 'waldo'
    cookie_jar['xyzzy'] = 'plugh'

# Generated at 2022-06-18 05:04:26.379631
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:04:37.643634
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:47.764641
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:05:05.257704
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:13.482289
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"

# Generated at 2022-06-18 05:05:24.157193
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'
    cookie['path'] = '/'
    assert str(cookie) == 'name=value; Path=/'
    cookie['max-age'] = '10'
    assert str(cookie) == 'name=value; Path=/; Max-Age=10'
    cookie['expires'] = datetime(2020, 1, 1)
    assert str(cookie) == 'name=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT'
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure'
    cookie['httponly'] = True

# Generated at 2022-06-18 05:05:31.489126
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    jar["baz"] = "qux"
    assert headers.getall("Set-Cookie") == [
        "foo=bar; Path=/",
        "baz=qux; Path=/",
    ]
    del jar["foo"]
    assert headers.getall("Set-Cookie") == ["baz=qux; Path=/"]
    del jar["baz"]
    assert headers.getall("Set-Cookie") == []

# Generated at 2022-06-18 05:05:35.352596
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"
    assert not cookie_jar


# Generated at 2022-06-18 05:05:47.292833
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:05:52.946133
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = "100"
    assert str(cookie) == "name=value; Path=/; Max-Age=100"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:06:01.800826
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"
    cookie["max-age"] = 100
    assert str(cookie) == "test=value; Max-Age=100; Path=/"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=100; Path=/"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=100; Path=/; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:12.169159
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    assert str(cookie) == "name=value; Max-Age=0; expires=%s; Path=/; Comment=comment; Domain=domain; Secure; HttpOnly; Version=1; SameSite=strict" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-18 05:06:19.219621
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["secure"] = False
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"


# Generated at 2022-06-18 05:06:41.654861
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
   

# Generated at 2022-06-18 05:06:52.445234
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2018, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Mon, 01-Jan-2018 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Mon, 01-Jan-2018 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:07:04.539021
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)

# Generated at 2022-06-18 05:07:17.643278
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    assert headers.get("Set-Cookie", 1) == "test2=test2; Path=/; Max-Age=0"
    del cookie_jar["test2"]

# Generated at 2022-06-18 05:07:29.134250
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True
    assert str(cookie)

# Generated at 2022-06-18 05:07:36.772024
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    assert cookie_jar["test"].value == "test"
    assert cookie_jar["test"]["path"] == "/"
    assert cookie_jar["test"]["max-age"] == 0


# Generated at 2022-06-18 05:07:45.001117
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:54.461453
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["secure"] = False
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"


# Generated at 2022-06-18 05:08:06.317891
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 05:08:14.713437
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True