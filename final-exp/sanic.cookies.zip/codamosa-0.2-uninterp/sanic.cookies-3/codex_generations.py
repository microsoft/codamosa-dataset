

# Generated at 2022-06-18 04:58:34.361590
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"] == "test"
    del cookies["test"]
    assert cookies.get("test") is None
    assert headers.get("Set-Cookie") is None



# Generated at 2022-06-18 04:58:41.835816
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["expires"] = datetime.now()
    assert isinstance(cookie["expires"], datetime)
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    cookie["version"] = 1
    assert cookie["version"] == 1
    cookie["samesite"] = "Lax"
    assert cookie["samesite"] == "Lax"
    cookie["comment"] = "comment"
    assert cookie["comment"] == "comment"
    cookie["domain"] = "domain"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 04:58:49.406841
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:00.410032
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("key=value; Path=/; Max-Age=0; Expires=")


# Generated at 2022-06-18 04:59:11.166158
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True
    assert str(cookie)

# Generated at 2022-06-18 04:59:22.127250
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 04:59:28.894227
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True


# Generated at 2022-06-18 04:59:38.773634
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 04:59:45.935586
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"
    assert not cookie_jar.get("key")


# Generated at 2022-06-18 04:59:54.455773
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:00:06.032551
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Path=/; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:18.138223
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('key', 'value')
    cookie['path'] = '/'
    cookie['expires'] = datetime.now()
    cookie['comment'] = 'comment'
    cookie['domain'] = 'domain'
    cookie['max-age'] = 0
    cookie['secure'] = True
    cookie['httponly'] = True
    cookie['version'] = 1
    cookie['samesite'] = 'Strict'
    cookie['unknown'] = 'unknown'
    assert cookie['path'] == '/'
    assert cookie['expires'] == datetime.now()
    assert cookie['comment'] == 'comment'
    assert cookie['domain'] == 'domain'
    assert cookie['max-age'] == 0
    assert cookie['secure'] == True
    assert cookie['httponly'] == True
    assert cookie['version'] == 1
    assert cookie

# Generated at 2022-06-18 05:00:22.771187
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert headers["Set-Cookie"] == "test_key=test_value; Path=/; Max-Age=0"
    del cookie_jar["test_key"]
    assert headers["Set-Cookie"] == ""


# Generated at 2022-06-18 05:00:34.082803
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:00:44.792574
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["max-age"] = "100"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "strict"
    assert str(cookie) == (
        "test=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; "
        "Max-Age=100; Secure; HttpOnly; Version=1; SameSite=strict"
    )


# ------------------------------------------------------------ #
#  Response
# ------------------------------------------------------------ #



# Generated at 2022-06-18 05:00:57.937076
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:01:08.030157
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:12.042516
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    assert cookie_jar["key"].value == "value"
    assert cookie_jar["key"]["path"] == "/"
    assert cookie_jar["key"]["max-age"] == 0


# Generated at 2022-06-18 05:01:18.182887
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    del cookie_jar["test"]
    assert headers.getall("Set-Cookie") == ["test2=test2; Path=/"]


# Generated at 2022-06-18 05:01:26.568663
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"

    cookie["max-age"] = "123"
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:39.861294
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:01:43.807523
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:01:49.042504
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:02:01.996274
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:08.788070
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"

    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"

# Generated at 2022-06-18 05:02:20.274899
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:30.020127
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:02:36.361308
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:02:45.134948
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["max-age"] = 10
    assert str(cookie) == "test=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["secure"] = False
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

# Generated at 2022-06-18 05:02:54.619282
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 1, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 01:01:01 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 01:01:01 GMT; Secure"


# Generated at 2022-06-18 05:03:07.847596
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 05:03:17.979209
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie["secure"] = True

# Generated at 2022-06-18 05:03:23.303829
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert headers["Set-Cookie"] == "test_key=test_value; Path=/; Max-Age=0"
    del cookie_jar["test_key"]
    assert headers["Set-Cookie"] == ""


# Generated at 2022-06-18 05:03:32.389208
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:03:42.290736
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:03:46.610428
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 123
    assert str(cookie) == "name=value; Max-Age=123"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:50.250053
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:03:58.157921
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert str(cookie) == "key=value; Path=/; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0; Secure; HttpOnly; Version=1; SameSite=Strict"

# Generated at 2022-06-18 05:04:08.281260
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:18.555941
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:35.411896
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:46.796431
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:04:58.446410
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:05:09.049113
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["max-age"] = 10
    assert str(cookie) == "test=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:15.721291
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:05:26.103819
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:05:31.833168
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:05:37.470785
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"

# Generated at 2022-06-18 05:05:46.820852
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["foo"] = "bar"
    cookies["baz"] = "qux"
    cookies["quux"] = "quuz"
    del cookies["baz"]
    assert "baz" not in cookies
    assert "baz" not in cookies.cookie_headers
    assert "baz" not in headers
    assert "foo" in cookies
    assert "foo" in cookies.cookie_headers
    assert "foo" in headers
    assert "quux" in cookies
    assert "quux" in cookies.cookie_headers
    assert "quux" in headers


# Generated at 2022-06-18 05:05:56.144548
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:06:13.531119
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:24.588685
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 100
    assert str(cookie) == "key=value; Path=/; Max-Age=100"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:35.550597
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'

    cookie = Cookie('name', 'value')
    cookie['max-age'] = 1
    assert str(cookie) == 'name=value; Max-Age=1'

    cookie = Cookie('name', 'value')
    cookie['expires'] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == 'name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT'

    cookie = Cookie('name', 'value')
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Secure'

    cookie = Cookie('name', 'value')
    cookie['httponly'] = True
    assert str(cookie) == 'name=value; HttpOnly'



# Generated at 2022-06-18 05:06:49.305420
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Secure"

    cookie = Cookie("name", "value")
    cookie["path"] = "/"

# Generated at 2022-06-18 05:07:00.322150
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    cookie['max-age'] = 1
    cookie['expires'] = datetime.now()
    cookie['secure'] = True
    cookie['httponly'] = True
    cookie['path'] = '/'
    cookie['domain'] = 'example.com'
    cookie['comment'] = 'comment'
    cookie['version'] = '1'
    cookie['samesite'] = 'Lax'
    assert str(cookie) == 'key=value; Max-Age=1; Expires=%s; Secure; HttpOnly; Path=/; Domain=example.com; Comment=comment; Version=1; SameSite=Lax' % datetime.now().strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-18 05:07:09.115511
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=%s; Secure; HttpOnly; Version=1; SameSite=Strict; Comment=comment; Domain=domain" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-18 05:07:19.702846
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = "123"
    assert str(cookie) == "name=value; Max-Age=123"

    cookie["max-age"] = 123
    assert str(cookie) == "name=value; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=123; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=123; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["secure"] = False

# Generated at 2022-06-18 05:07:30.502780
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"

    cookie["max-age"] = "test"
    assert str(cookie) == "test=test; Max-Age=test"

    cookie["max-age"] = 1
    assert str(cookie) == "test=test; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=test; Max-Age=1; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=test; Max-Age=1; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True
    assert str

# Generated at 2022-06-18 05:07:41.156309
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:51.333762
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"

# Generated at 2022-06-18 05:08:11.682685
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = "100"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "Lax"
    assert str(cookie) == "key=value; Path=/; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=Lax"

# Generated at 2022-06-18 05:08:14.287043
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"


# Generated at 2022-06-18 05:08:17.735182
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
