

# Generated at 2022-06-18 04:58:34.795122
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:58:44.912466
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 04:58:51.104671
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    assert cookie["expires"] == "expires"
    assert cookie["path"] == "Path"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"
    assert cookie["max-age"] == "Max-Age"
    assert cookie["secure"] == "Secure"
    assert cookie["httponly"] == "HttpOnly"

# Generated at 2022-06-18 04:58:59.271834
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 04:59:09.526255
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 04:59:20.872520
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 04:59:28.229165
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 04:59:30.510013
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:39.677132
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 04:59:50.907837
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Comment=comment; Domain=domain; Max-Age=max-age; Secure; HttpOnly; Version=version; SameSite=samesite; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

# Generated at 2022-06-18 05:00:05.275489
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie["secure"] = True

# Generated at 2022-06-18 05:00:17.637928
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar['test'] = 'test'
    cookie_jar['test2'] = 'test2'
    cookie_jar['test3'] = 'test3'
    cookie_jar['test4'] = 'test4'
    cookie_jar['test5'] = 'test5'
    cookie_jar['test6'] = 'test6'
    cookie_jar['test7'] = 'test7'
    cookie_jar['test8'] = 'test8'
    cookie_jar['test9'] = 'test9'
    cookie_jar['test10'] = 'test10'
    cookie_jar['test11'] = 'test11'
    cookie_jar['test12'] = 'test12'
    cookie_jar['test13'] = 'test13'
   

# Generated at 2022-06-18 05:00:26.334007
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:37.343745
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0, test2=test4; Path=/; Max-Age=0"

# Generated at 2022-06-18 05:00:47.980033
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert str(c) == "foo=bar"
    c["max-age"] = 10
    assert str(c) == "foo=bar; Max-Age=10"
    c["expires"] = datetime(2020, 1, 1)
    assert str(c) == "foo=bar; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["secure"] = True
    assert str(c) == "foo=bar; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    c["httponly"] = True

# Generated at 2022-06-18 05:00:58.884081
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test the __str__ method of Cookie
    """
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 1
    assert str(cookie) == "name=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:08.528479
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "Lax"
    cookie["version"] = 1
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["samesite"] == "Lax"
    assert cookie["version"] == 1
    assert cookie["comment"] == None
    assert cookie["domain"] == None
    assert cookie["expires"] == datetime.now()

# Generated at 2022-06-18 05:01:20.552049
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"

# Generated at 2022-06-18 05:01:27.990027
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "foo=bar; Max-Age=0; expires=%s" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Max-Age=0; expires=%s; Secure" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")
    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:38.380493
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"

    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0"

    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Secure"

    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"

# Generated at 2022-06-18 05:02:03.170533
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=%s" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")

    cookie["secure"] = True

# Generated at 2022-06-18 05:02:14.931269
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"

# Generated at 2022-06-18 05:02:26.080772
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"

# Generated at 2022-06-18 05:02:33.933774
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = "10"
    assert str(cookie) == "name=value; Max-Age=10"
    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["secure"] = False

# Generated at 2022-06-18 05:02:44.154597
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:02:49.933719
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    assert not cookie_jar


# Generated at 2022-06-18 05:02:55.917771
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('key', 'value')
    c['path'] = '/'
    c['max-age'] = 0
    c['expires'] = datetime.now()
    c['secure'] = True
    c['httponly'] = True
    c['version'] = 1
    c['samesite'] = 'Strict'
    assert c['path'] == '/'
    assert c['max-age'] == 0
    assert c['expires'] == datetime.now()
    assert c['secure'] == True
    assert c['httponly'] == True
    assert c['version'] == 1
    assert c['samesite'] == 'Strict'


# Generated at 2022-06-18 05:03:07.277216
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert isinstance(cookie["expires"], datetime)
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"

# Generated at 2022-06-18 05:03:14.328517
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookiejar = CookieJar(headers)
    cookiejar["key"] = "value"
    assert "key" in cookiejar
    assert "key" in cookiejar.cookie_headers
    assert "key" in headers
    del cookiejar["key"]
    assert "key" not in cookiejar
    assert "key" not in cookiejar.cookie_headers
    assert "key" not in headers


# Generated at 2022-06-18 05:03:25.929295
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:03:38.562202
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:03:46.557199
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["domain"] = "example.com"
    cookie["max-age"] = 3600
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert str(cookie) == "key=value; Path=/; Domain=example.com; Max-Age=3600; Secure; HttpOnly; Version=1; SameSite=Strict"


# Generated at 2022-06-18 05:03:56.043505
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1)
    assert str(cookie) == "key=value; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:07.332690
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    cookie["test"] = "test"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == "test"
    assert cookie["secure"] == True
    assert cookie["httponly"] == True

# Generated at 2022-06-18 05:04:11.024628
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:04:15.952931
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:04:27.064181
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = "example.com"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "This is a comment"

# Generated at 2022-06-18 05:04:35.496027
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:46.866580
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    assert cookie["expires"] == "expires"
    assert cookie["path"] == "Path"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"
    assert cookie["max-age"] == "Max-Age"
    assert cookie["secure"] == "Secure"
    assert cookie["httponly"] == "HttpOnly"

# Generated at 2022-06-18 05:04:57.775167
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test.com"
    cookie["max-age"] = "test"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "Lax"
    assert (
        str(cookie)
        == 'test=value; expires=Wed, 01-Jan-2020 00:00:00 GMT; Path=/; Comment=test; Domain=test.com; Max-Age=test; Secure; HttpOnly; Version=1; SameSite=Lax'
    )

# Generated at 2022-06-18 05:05:12.353238
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["max-age"] = 1
    assert cookie["max-age"] == 1
    cookie["max-age"] = False
    assert cookie["max-age"] == False
    cookie["expires"] = datetime.now()
    assert cookie["expires"] == datetime.now()
    cookie["expires"] = False
    assert cookie["expires"] == False
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["secure"] = False
    assert cookie["secure"] == False
    cookie["httponly"] = True
    assert cookie["httponly"] == True
   

# Generated at 2022-06-18 05:05:18.428847
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert headers["Set-Cookie"] == "test_key=test_value; Path=/; Max-Age=0"
    assert cookie_jar["test_key"].value == "test_value"


# Generated at 2022-06-18 05:05:26.983221
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 0
    cookie["samesite"] = "test"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 0
    assert cookie["samesite"] == "test"



# Generated at 2022-06-18 05:05:38.280449
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"
    cookie["max-age"] = "test"
    assert str(cookie) == "test=test; Max-Age=test"
    cookie["max-age"] = 1
    assert str(cookie) == "test=test; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=test; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=test; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["secure"] = False

# Generated at 2022-06-18 05:05:43.672102
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:05:54.141933
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0"

    cookie["max-age"] = "0"
    assert str(cookie) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0"

    cookie["max-age"] = "1"

# Generated at 2022-06-18 05:05:59.389192
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:06:10.154399
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:06:18.220861
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    assert cookie["path"] == "/"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"
    assert cookie["max-age"] == "max-age"
    assert cookie["secure"] == "secure"
    assert cookie["httponly"] == "httponly"
    assert cookie["version"] == "version"
    assert cookie["samesite"] == "samesite"

# Generated at 2022-06-18 05:06:29.366297
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:06:54.394534
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:05.592502
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Secure"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["httponly"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:07:13.305276
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == None


# Generated at 2022-06-18 05:07:22.179099
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:07:31.895373
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
   

# Generated at 2022-06-18 05:07:41.874660
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"

    del cookie_jar["key1"]
    assert "key1" not in cookie_jar
    assert "key1" not in cookie_jar.cookie_headers
    assert "key1" not in headers
    assert "key2" in cookie_jar
    assert "key2" in cookie_jar.cookie_headers
    assert "key2" in headers
    assert "key3" in cookie_jar
    assert "key3" in cookie_jar.cookie_headers

# Generated at 2022-06-18 05:07:50.595079
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert "Set-Cookie" not in headers
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test2=test2; Path=/; HttpOnly"
    del cookie_jar["test2"]
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:07:53.693122
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"


# Generated at 2022-06-18 05:08:05.539938
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0, test2=test3; Path=/; Max-Age=0"
    cookie_jar["test3"] = "test4"

# Generated at 2022-06-18 05:08:09.130625
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   