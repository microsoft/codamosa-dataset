

# Generated at 2022-06-18 04:58:26.458163
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:58:36.566741
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"
    cookie["max-age"] = 10
    assert str(cookie) == "test=test; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=test; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=test; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:58:45.495334
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("key=value; Max-Age=10; Expires=")

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=; Secure"

    cookie["httponly"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=; Secure; HttpOnly"

    cookie["path"] = "/"

# Generated at 2022-06-18 04:58:51.070244
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 04:59:02.186715
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 04:59:13.609701
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 04:59:20.205379
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"
    assert "test" not in cookie_jar


# Generated at 2022-06-18 04:59:27.868614
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True
   

# Generated at 2022-06-18 04:59:34.575809
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    assert not cookie_jar.get("test")


# Generated at 2022-06-18 04:59:41.571851
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 04:59:48.425163
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:55.566079
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["test"] = "test"
    cookie["test"] = False
    cookie["test"] = 0
    cookie["test"] = ""
    cookie["test"] = None
    cookie["test"] = []
    cookie["test"] = {}
    cookie["test"] = ()
    cookie["test"] = set()
    cookie["test"] = False
    cookie["test"] = True

# Generated at 2022-06-18 05:00:05.063034
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Secure"
    cookie["httponly"] = True
    assert str(cookie) == "key=value; Path=/; Secure; HttpOnly"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Secure; HttpOnly; Max-Age=0"
    cookie["expires"] = datetime.now()

# Generated at 2022-06-18 05:00:17.279186
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c["path"] = "/"
    assert str(c) == "name=value; Path=/"
    c["max-age"] = 0
    assert str(c) == "name=value; Path=/; Max-Age=0"
    c["expires"] = datetime(2020, 1, 1)
    assert str(c) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["secure"] = True
    assert str(c) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    c["httponly"] = True

# Generated at 2022-06-18 05:00:26.128062
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=%s" % (
        cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie["secure"] = True

# Generated at 2022-06-18 05:00:37.291700
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2018, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Mon, 01-Jan-2018 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Mon, 01-Jan-2018 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:00:47.943055
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:00:58.886254
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = "10"
    assert cookie["max-age"] == 10
    cookie["expires"] = datetime.now()
    assert isinstance(cookie["expires"], datetime)
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["comment"] = "comment"
    assert cookie["comment"] == "comment"
    cookie["domain"] = "domain"
    assert cookie["domain"] == "domain"
    cookie["version"] = "version"
    assert cookie["version"] == "version"
    cookie["samesite"] = "samesite"

# Generated at 2022-06-18 05:01:08.528074
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    assert str(c) == "key=value"
    c["path"] = "/"
    assert str(c) == "key=value; Path=/"
    c["expires"] = datetime(2020, 1, 1)
    assert str(c) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["max-age"] = 0
    assert str(c) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0"
    c["secure"] = True
    assert str(c) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0; Secure"

# Generated at 2022-06-18 05:01:20.608497
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["max-age"] = 100
    assert str(cookie) == "name=value; Max-Age=100"

    cookie = Cookie("name", "value")
    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Expires=Tue, 01-Jan-2019 00:00:00 GMT"

    cookie = Cookie("name", "value")
    cookie["secure"] = True
    assert str(cookie) == "name=value; Secure"

    cookie = Cookie("name", "value")
    cookie["httponly"] = True
    assert str(cookie) == "name=value; HttpOnly"



# Generated at 2022-06-18 05:01:34.028565
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:01:42.405673
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "Strict"
    cookie["version"] = 1
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["samesite"] == "Strict"
    assert cookie["version"] == 1
    assert cookie["comment"] == None
    assert cookie["domain"] == None


# Generated at 2022-06-18 05:01:53.240300
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:02:04.815134
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["max-age"] = "1"
    assert cookie["max-age"] == "1"
    cookie["expires"] = datetime.now()
    assert cookie["expires"] == datetime.now()
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    cookie["version"] = "1"
    assert cookie["version"] == "1"
    cookie["samesite"] = "Strict"
    assert cookie["samesite"] == "Strict"
    cookie["samesite"] = "Lax"
    assert cookie["samesite"] == "Lax"

# Generated at 2022-06-18 05:02:16.627493
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:02:27.709095
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:02:37.787845
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    cookie_jar["quux"] = "corge"
    assert len(cookie_jar) == 3
    assert len(headers) == 1
    assert headers.get("Set-Cookie") == "foo=bar; Path=/; baz=qux; Path=/; quux=corge; Path=/"
    del cookie_jar["baz"]
    assert len(cookie_jar) == 2
    assert len(headers) == 1
    assert headers.get("Set-Cookie") == "foo=bar; Path=/; quux=corge; Path=/"
    del cookie_jar["foo"]
    assert len(cookie_jar) == 1

# Generated at 2022-06-18 05:02:46.623002
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"
    cookie["httponly"] = True
    assert str(cookie)

# Generated at 2022-06-18 05:02:55.431503
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    cookie["path"] = "test"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = "test"
    cookie["httponly"] = "test"
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    cookie["test"] = "test"
    assert cookie["expires"] == "test"
    assert cookie["path"] == "test"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == "test"
    assert cookie["secure"] == "test"
    assert cookie["httponly"] == "test"
   

# Generated at 2022-06-18 05:03:07.215289
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Secure"

    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:31.075619
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:03:42.246453
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["max-age"] = 1
    assert str(cookie) == "test=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:53.003305
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:04:04.194569
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    assert cookie["expires"] == "expires"
    assert cookie["path"] == "Path"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"
    assert cookie["max-age"] == "Max-Age"
    assert cookie["secure"] == "Secure"
    assert cookie["httponly"] == "HttpOnly"

# Generated at 2022-06-18 05:04:15.639826
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:22.497301
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    assert not cookie_jar


# Generated at 2022-06-18 05:04:33.305559
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value")
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie = Cookie("key", "value")
    cookie["expires"] = datetime(2020, 2, 2, 2, 2, 2)
    assert str(cookie) == "key=value; Expires=Sun, 02-Feb-2020 02:02:02 GMT"

    cookie = Cookie("key", "value")
    cookie["secure"] = True
    assert str(cookie) == "key=value; Secure"

    cookie = Cookie("key", "value")
    cookie["httponly"] = True
    assert str(cookie) == "key=value; HttpOnly"



# Generated at 2022-06-18 05:04:45.131524
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cj = CookieJar(headers)
    cj["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cj["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cj["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cj["test2"] = "test4"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0, test2=test4; Path=/; Max-Age=0"
    cj["test2"] = "test5"
    assert headers

# Generated at 2022-06-18 05:04:54.856666
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:05:02.311169
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    assert "foo" in jar
    assert "foo" in jar.cookie_headers
    assert "Set-Cookie" in headers
    assert "foo=bar" in headers["Set-Cookie"]
    del jar["foo"]
    assert "foo" not in jar
    assert "foo" not in jar.cookie_headers
    assert "Set-Cookie" not in headers
    assert "foo=bar" not in headers["Set-Cookie"]


# Generated at 2022-06-18 05:05:18.440228
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:22.292929
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["max-age"] = "123"
    assert str(cookie) == "foo=bar; Max-Age=123"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "foo=bar; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:29.437889
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    cookie["path"] = "test"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = "test"
    cookie["httponly"] = "test"
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    cookie["test"] = "test"


# Generated at 2022-06-18 05:05:39.804112
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    cookie_jar["test_key2"] = "test_value2"
    del cookie_jar["test_key"]
    assert cookie_jar["test_key2"] == "test_value2"
    assert headers.getall("Set-Cookie") == [
        "test_key2=test_value2; Path=/",
        "test_key=; Max-Age=0",
    ]
    del cookie_jar["test_key2"]
    assert headers.getall("Set-Cookie") == [
        "test_key2=; Max-Age=0",
        "test_key=; Max-Age=0",
    ]
    assert cookie_jar == {}

#

# Generated at 2022-06-18 05:05:51.568522
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 05:05:58.330096
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"
    cookie["max-age"] = "123"
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:06:02.190734
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:06:13.485787
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; HttpOnly"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; HttpOnly"
    cookie_jar["foo"] = "bar"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; HttpOnly"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; HttpOnly"
    cookie_jar["foo"] = "bar"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; HttpOnly"
    cookie

# Generated at 2022-06-18 05:06:24.441992
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:35.419956
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:06:56.478249
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    assert str(c) == "key=value"
    c["path"] = "/"
    assert str(c) == "key=value; Path=/"
    c["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(c) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["max-age"] = 0
    assert str(c) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0"
    c["secure"] = True
    assert str(c) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0; Secure"

# Generated at 2022-06-18 05:07:07.391782
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:19.324525
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"

    cookie = Cookie("name", "value")
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie = Cookie("name", "value")
    cookie["secure"] = True
    assert str(cookie) == "name=value; Secure"

    cookie = Cookie("name", "value")
    cookie["httponly"] = True
    assert str(cookie) == "name=value; HttpOnly"

   

# Generated at 2022-06-18 05:07:30.412952
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["max-age"] = "0"
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["max-age"] = "1"
    assert str(cookie) == "key=value; Max-Age=1"
    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("key=value; Max-Age=1; Expires=")
    cookie["secure"] = True
    assert str(cookie).startswith

# Generated at 2022-06-18 05:07:35.845203
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:07:44.357800
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:07:50.238851
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:08:01.291911
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["path"] = "test"
    assert cookie["path"] == "test"
    cookie["comment"] = "test"
    assert cookie["comment"] == "test"
    cookie["domain"] = "test"
    assert cookie["domain"] == "test"
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["secure"] = "test"
    assert cookie["secure"] == "test"
    cookie["httponly"] = "test"
    assert cookie["httponly"] == "test"
    cookie["version"] = "test"
    assert cookie["version"] == "test"
    cookie["samesite"] = "test"


# Generated at 2022-06-18 05:08:10.912299
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:08:14.938331
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"
