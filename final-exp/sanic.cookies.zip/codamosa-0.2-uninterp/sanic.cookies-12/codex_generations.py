

# Generated at 2022-06-18 04:58:34.361616
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 04:58:36.473361
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:58:42.011588
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["test"] = "test"


# Generated at 2022-06-18 04:58:51.860232
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["key"] = "value"
    jar["key2"] = "value2"
    jar["key3"] = "value3"
    jar["key4"] = "value4"
    jar["key5"] = "value5"
    jar["key6"] = "value6"
    jar["key7"] = "value7"
    jar["key8"] = "value8"
    jar["key9"] = "value9"
    jar["key10"] = "value10"
    jar["key11"] = "value11"
    jar["key12"] = "value12"
    jar["key13"] = "value13"
    jar["key14"] = "value14"
    jar["key15"] = "value15"

# Generated at 2022-06-18 04:59:02.186982
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie["max-age"] = 123
    assert str(cookie) == "foo=bar; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "foo=bar; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:13.007509
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["max-age"] = 10
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie.__str__() == "test=test; Max-Age=10; expires=%s; Secure; HttpOnly; Version=1; SameSite=strict; Path=/; Comment=test; Domain=test" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-18 04:59:23.688652
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"

# Generated at 2022-06-18 04:59:29.717269
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 04:59:37.402608
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key"] = "value3"
    assert headers["Set-Cookie"] == "key=value3; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:49.319237
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:00:03.544907
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar['test_cookie'] = 'test_value'
    cookie_jar['test_cookie2'] = 'test_value2'
    cookie_jar['test_cookie3'] = 'test_value3'
    cookie_jar['test_cookie4'] = 'test_value4'
    cookie_jar['test_cookie5'] = 'test_value5'
    cookie_jar['test_cookie6'] = 'test_value6'
    cookie_jar['test_cookie7'] = 'test_value7'
    cookie_jar['test_cookie8'] = 'test_value8'
    cookie_jar['test_cookie9'] = 'test_value9'
    cookie_jar['test_cookie10'] = 'test_value10'
    cookie_

# Generated at 2022-06-18 05:00:14.607129
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:00:23.990890
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert headers.get("Set-Cookie") == "foo=bar; Path=/; Max-Age=0"
    del cookie_jar["foo"]
    assert headers.get("Set-Cookie") == "foo=; Path=/; Max-Age=0"
    cookie_jar["foo"] = "bar"
    cookie_jar["foo"]["max-age"] = 10
    assert headers.get("Set-Cookie") == "foo=bar; Path=/; Max-Age=10"
    del cookie_jar["foo"]
    assert headers.get("Set-Cookie") == "foo=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:00:35.274027
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:00:47.157099
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:00:58.767368
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:01:08.407307
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:01:20.369437
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:01:27.859611
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["unknown"] = "unknown"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"
    assert cookie["max-age"] == "max-age"
    assert cookie["secure"] == "secure"

# Generated at 2022-06-18 05:01:38.282662
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2019, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:56.046602
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["key"] = "value"
    assert jar["key"].value == "value"
    assert headers["Set-Cookie"][0] == "key=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:05.368365
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"


# Generated at 2022-06-18 05:02:16.711383
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:02:24.930978
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["domain"] = "example.com"
    cookie["max-age"] = 3600
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert str(cookie) == "name=value; Path=/; Domain=example.com; Max-Age=3600; Secure; HttpOnly; Version=1; SameSite=Strict"


# Generated at 2022-06-18 05:02:30.847199
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key"] = "value3"
    assert headers["Set-Cookie"] == "key=value3; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:36.868649
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:02:44.988780
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "test=test; Path=/; Comment=test; Domain=test; Max-Age=test; Secure; HttpOnly; Version=test; SameSite=test; Expires=%s" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")

# Generated at 2022-06-18 05:02:54.563267
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("mycookie", "myvalue")
    cookie["path"] = "/"
    cookie["max-age"] = "10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "strict"
    cookie["comment"] = "mycomment"
    cookie["domain"] = "mydomain"
    assert str(cookie) == (
        "mycookie=myvalue; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=strict; Comment=mycomment; Domain=mydomain"
    )


# Generated at 2022-06-18 05:03:06.721809
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 05:03:17.161246
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_value"
    cookie_jar["test_cookie2"] = "test_value2"
    cookie_jar["test_cookie3"] = "test_value3"
    cookie_jar["test_cookie4"] = "test_value4"
    cookie_jar["test_cookie5"] = "test_value5"
    cookie_jar["test_cookie6"] = "test_value6"
    cookie_jar["test_cookie7"] = "test_value7"
    cookie_jar["test_cookie8"] = "test_value8"
    cookie_jar["test_cookie9"] = "test_value9"
    cookie_jar["test_cookie10"] = "test_value10"
    cookie_

# Generated at 2022-06-18 05:03:37.161059
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert cookies["test"]["path"] == "/"
    assert headers["Set-Cookie"] == "test=test; Path=/"


# Generated at 2022-06-18 05:03:43.897279
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "1"
    cookie_jar["b"] = "2"
    cookie_jar["c"] = "3"
    cookie_jar["d"] = "4"
    cookie_jar["e"] = "5"
    cookie_jar["f"] = "6"
    cookie_jar["g"] = "7"
    cookie_jar["h"] = "8"
    cookie_jar["i"] = "9"
    cookie_jar["j"] = "10"
    cookie_jar["k"] = "11"
    cookie_jar["l"] = "12"
    cookie_jar["m"] = "13"
    cookie_jar["n"] = "14"
    cookie_jar["o"] = "15"
   

# Generated at 2022-06-18 05:03:54.194767
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"
    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=test; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:04:05.920000
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 3600
    assert str(cookie) == "name=value; Path=/; Max-Age=3600"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=3600; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=3600; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:04:13.570583
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "value"
    assert headers["Set-Cookie"] == "name=value; Path=/; Max-Age=0"
    cookie_jar["name"] = "value2"
    assert headers["Set-Cookie"] == "name=value2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:23.122423
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    assert cookie_jar["test"].value == "test3"


# Generated at 2022-06-18 05:04:33.694219
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('name', 'value')
    c['expires'] = datetime.now()
    c['path'] = '/'
    c['comment'] = 'comment'
    c['domain'] = 'domain'
    c['max-age'] = 0
    c['secure'] = True
    c['httponly'] = True
    c['version'] = 1
    c['samesite'] = 'strict'
    assert c['expires'] == datetime.now()
    assert c['path'] == '/'
    assert c['comment'] == 'comment'
    assert c['domain'] == 'domain'
    assert c['max-age'] == 0
    assert c['secure'] == True
    assert c['httponly'] == True
    assert c['version'] == 1
    assert c['samesite'] == 'strict'

# Generated at 2022-06-18 05:04:38.019632
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"

    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"

    cookie["max-age"] = 10
    assert str(cookie) == "test=test; Path=/; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=test; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=test; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:44.131437
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers["Set-Cookie"] == "key=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:56.345778
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"

    cookie["max-age"] = 1
    assert str(cookie) == "test=test; Max-Age=1"

    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("test=test; Max-Age=1; Expires=")

    cookie["secure"] = True
    assert str(cookie).startswith("test=test; Max-Age=1; Expires=")
    assert str(cookie).endswith("; Secure")

    cookie["httponly"] = True
    assert str(cookie).startswith("test=test; Max-Age=1; Expires=")
    assert str(cookie).endswith("; Secure; HttpOnly")

    cookie["path"] = "/"


# Generated at 2022-06-18 05:05:33.435126
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test3"] = "test3"

# Generated at 2022-06-18 05:05:44.954431
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:05:52.963844
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "localhost"
    cookie["max-age"] = "10"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "Lax"
    assert str(cookie) == "name=value; Path=/; Comment=test; Domain=localhost; Max-Age=10; Secure; HttpOnly; Version=1; SameSite=Lax"


# Generated at 2022-06-18 05:05:55.625076
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:06:00.290597
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Max-Age=0"


# Generated at 2022-06-18 05:06:11.578856
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:16.769207
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["key"] = "value"
    assert jar["key"] == "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; HttpOnly"
    del jar["key"]
    assert headers["Set-Cookie"] == "key=; Path=/; Max-Age=0; HttpOnly"
    assert jar == {}
    assert headers == {}


# Generated at 2022-06-18 05:06:25.513283
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test2" in cookie_jar
    assert "test3" in cookie_jar
    assert headers.get("Set-Cookie") == "test2=test2; Path=/; test3=test3; Path=/"


# Generated at 2022-06-18 05:06:36.146523
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:49.402509
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:20.322591
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert headers["Set-Cookie"] == "test_key=test_value; Path=/; Max-Age=0"
    cookie_jar["test_key"] = "test_value_2"
    assert headers["Set-Cookie"] == "test_key=test_value_2; Path=/; Max-Age=0"
    cookie_jar["test_key"] = "test_value_3"
    assert headers["Set-Cookie"] == "test_key=test_value_3; Path=/; Max-Age=0"
    cookie_jar["test_key"] = "test_value_4"

# Generated at 2022-06-18 05:07:30.833595
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:41.388457
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:51.529296
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:57.606815
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'

    cookie['max-age'] = 10
    assert str(cookie) == 'name=value; Max-Age=10'

    cookie['expires'] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == 'name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT'

    cookie['secure'] = True
    assert str(cookie) == 'name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure'

    cookie['httponly'] = True

# Generated at 2022-06-18 05:08:04.060442
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:08:13.053113
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c["path"] = "/"
    assert str(c) == "name=value; Path=/"
    c["max-age"] = 0
    assert str(c) == "name=value; Path=/; Max-Age=0"
    c["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(c) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["secure"] = True
    assert str(c) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:08:23.132710
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"