

# Generated at 2022-06-18 04:58:19.850474
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"

# Generated at 2022-06-18 04:58:30.673926
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie["secure"] = True

# Generated at 2022-06-18 04:58:39.546648
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 04:58:44.349206
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == None


# Generated at 2022-06-18 04:58:50.807889
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert isinstance(cookie["expires"], datetime)
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 04:58:59.516819
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"] == "test"
    assert headers.get("Set-Cookie") == "test=test"
    del cookies["test"]
    assert headers.get("Set-Cookie") == "test=; Max-Age=0"
    assert cookies.get("test") is None


# Generated at 2022-06-18 04:59:03.407534
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 04:59:09.376511
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:20.737036
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'

    cookie = Cookie('name', 'value')
    cookie['max-age'] = 0
    assert str(cookie) == 'name=value; Max-Age=0'

    cookie = Cookie('name', 'value')
    cookie['expires'] = datetime(2020, 1, 1, 1, 1, 1)
    assert str(cookie) == 'name=value; Expires=Wed, 01-Jan-2020 01:01:01 GMT'

    cookie = Cookie('name', 'value')
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Secure'

    cookie = Cookie('name', 'value')
    cookie['httponly'] = True
    assert str(cookie) == 'name=value; HttpOnly'



# Generated at 2022-06-18 04:59:28.155826
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "lax"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 04:59:49.488054
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    try:
        cookie["key"] = "value"
        assert False
    except KeyError:
        assert True
    try:
        cookie["key"] = "value"
        assert False
    except KeyError:
        assert True
    try:
        cookie["max-age"] = "Max-Age"
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-18 05:00:00.336456
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:07.627806
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 100
    assert str(cookie) == "key=value; Max-Age=100"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:19.676520
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = "123"
    assert str(cookie) == "name=value; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:23.755326
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    del cookie_jar["test"]
    assert cookie_jar.get("test") is None
    assert headers.get("Set-Cookie") is None


# Generated at 2022-06-18 05:00:28.431530
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:00:38.254331
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"

    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"

    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=test; Path=/; Max-Age=0"

    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

   

# Generated at 2022-06-18 05:00:48.599729
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:00:59.134132
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:08.752910
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["max-age"] = 100
    assert str(cookie) == "test=value; Max-Age=100"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:24.517857
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:01:35.332926
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('test', 'test')
    c['expires'] = 'test'
    assert c['expires'] == 'test'
    c['path'] = 'test'
    assert c['path'] == 'test'
    c['comment'] = 'test'
    assert c['comment'] == 'test'
    c['domain'] = 'test'
    assert c['domain'] == 'test'
    c['max-age'] = 'test'
    assert c['max-age'] == 'test'
    c['secure'] = 'test'
    assert c['secure'] == 'test'
    c['httponly'] = 'test'
    assert c['httponly'] == 'test'
    c['version'] = 'test'
    assert c['version'] == 'test'
    c['samesite'] = 'test'


# Generated at 2022-06-18 05:01:40.040442
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:01:43.993764
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"].value == "test"
    del cookie_jar["test"]
    assert cookie_jar.get("test") is None
    assert headers.get("Set-Cookie") is None


# Generated at 2022-06-18 05:01:55.915287
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["max-age"] = "1"
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 1
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "test"
    cookie["test"] = "test"
    assert cookie["max-age"] == 1
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == 1

# Generated at 2022-06-18 05:02:06.403393
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:17.495316
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["foo"] = "baz"
    cookie_jar["baz"] = "foo"
    cookie_jar["baz"] = "bar"
    cookie_jar["baz"] = "baz"
    cookie_jar["baz"] = "foo"
    cookie_jar["baz"] = "bar"
    cookie_jar["baz"] = "baz"
    cookie_jar["baz"] = "foo"
    cookie_jar["baz"] = "bar"
    cookie_jar["baz"] = "baz"
    cookie_jar["baz"] = "foo"
    cookie_jar["baz"] = "bar"

# Generated at 2022-06-18 05:02:28.245825
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:02:38.415033
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:02:47.035225
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:03:24.471154
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:03:33.135843
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:39.561342
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:03:51.412659
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    assert str(cookie) == (
        "name=value; Path=/; Expires=Wed, 01-Jan-2020 00:00:00 GMT; "
        "Max-Age=0; Comment=comment; Domain=domain; Secure; HttpOnly; "
        "Version=1; SameSite=strict"
    )

# Generated at 2022-06-18 05:03:57.665129
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:07.848409
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:04:12.973315
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key"] = "value3"
    assert headers["Set-Cookie"] == "key=value3; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:21.124582
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:04:30.937592
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:43.152594
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c["max-age"] = 0
    assert str(c) == "name=value; Max-Age=0"
    c["max-age"] = "0"
    assert str(c) == "name=value; Max-Age=0"
    c["expires"] = datetime(2020, 1, 1)
    assert str(c) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["secure"] = True
    assert str(c) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    c["httponly"] = True

# Generated at 2022-06-18 05:05:07.429994
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:14.929353
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = "max-age"
    assert str(cookie) == "key=value; Max-Age=max-age"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True
    assert str

# Generated at 2022-06-18 05:05:25.574934
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert headers["Set-Cookie"] == "foo=baz; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"

# Generated at 2022-06-18 05:05:35.769302
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "name=value; Max-Age=0"

    cookie = Cookie("name", "value")
    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )

    cookie = Cookie("name", "value")
    cookie["secure"] = True
    assert str(cookie) == "name=value; Secure"

    cookie = Cookie("name", "value")
    cookie["httponly"] = True
    assert str

# Generated at 2022-06-18 05:05:42.349697
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.getall("Set-Cookie") == ["test=test; Path=/"]
    del cookie_jar["test"]
    assert headers.getall("Set-Cookie") == ["test=; Path=/; Max-Age=0"]


# Generated at 2022-06-18 05:05:53.091820
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True


# Generated at 2022-06-18 05:06:01.944709
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie_1"] = "test_value_1"
    cookie_jar["test_cookie_2"] = "test_value_2"
    cookie_jar["test_cookie_3"] = "test_value_3"
    cookie_jar["test_cookie_4"] = "test_value_4"
    assert len(cookie_jar) == 4
    assert len(cookie_jar.cookie_headers) == 4
    assert len(headers) == 1
    assert len(headers["Set-Cookie"]) == 4
    del cookie_jar["test_cookie_1"]
    assert len(cookie_jar) == 3
    assert len(cookie_jar.cookie_headers) == 3
    assert len(headers) == 1
    assert len

# Generated at 2022-06-18 05:06:06.766581
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:06:16.356568
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:06:27.924507
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"

# Generated at 2022-06-18 05:06:59.742344
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=%s" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")

    cookie["secure"] = True

# Generated at 2022-06-18 05:07:08.756077
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["domain"] = "example.com"
    cookie["expires"] = datetime(2021, 1, 1)
    cookie["max-age"] = "60"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "Strict"
    assert str(cookie) == (
        "test=value; Path=/; Domain=example.com; "
        "Expires=Tue, 01-Jan-2021 00:00:00 GMT; Max-Age=60; "
        "Secure; HttpOnly; Version=1; SameSite=Strict"
    )

# Generated at 2022-06-18 05:07:19.627038
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:07:30.473468
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:07:40.811123
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = "123"
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["path"] = "/"
    cookie["domain"] = "example.com"
    cookie["comment"] = "comment"
    cookie["version"] = "1"
    cookie["samesite"] = "Strict"

    assert str(cookie) == (
        "key=value; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; "
        "Secure; HttpOnly; Path=/; Domain=example.com; Comment=comment; "
        "Version=1; SameSite=Strict"
    )

# Generated at 2022-06-18 05:07:47.168526
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:55.127085
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"
    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=test; Path=/; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=%s" % datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    cookie["secure"] = True

# Generated at 2022-06-18 05:08:01.131741
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:08:10.778762
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = "10"
    assert cookie["max-age"] == "10"
    cookie["max-age"] = 10
    assert cookie["max-age"] == 10
    cookie["max-age"] = 10.0
    assert cookie["max-age"] == 10
    cookie["max-age"] = "10.0"
    assert cookie["max-age"] == "10.0"
    cookie["max-age"] = "ten"
    assert cookie["max-age"] == "ten"
    cookie["max-age"] = False
    assert cookie["max-age"] == False
    cookie["expires"] = datetime.now()
    assert cookie["expires"] == datetime.now()
    cookie["expires"] = "datetime.now()"