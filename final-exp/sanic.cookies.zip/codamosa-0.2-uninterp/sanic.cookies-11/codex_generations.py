

# Generated at 2022-06-18 04:58:39.603853
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; HttpOnly"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; HttpOnly"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 04:58:47.633495
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    assert cookie["expires"] == "expires"
    assert cookie["path"] == "Path"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"
    assert cookie["max-age"] == "Max-Age"
    assert cookie["secure"] == "Secure"
    assert cookie["httponly"] == "HttpOnly"

# Generated at 2022-06-18 04:58:59.481650
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["expires"] = datetime.now()
    assert cookie["expires"] == datetime.now()
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    cookie["version"] = 1
    assert cookie["version"] == 1
    cookie["samesite"] = "strict"
    assert cookie["samesite"] == "strict"
    with pytest.raises(KeyError):
        cookie["unknown"] = "unknown"
    with pytest.raises(ValueError):
        cookie["max-age"]

# Generated at 2022-06-18 04:59:09.870426
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["max-age"] = 10
    assert str(cookie) == "test=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:21.232924
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["test"] = "value"
    assert jar["test"].value == "value"
    assert headers["Set-Cookie"] == "test=value; Path=/; Max-Age=0"
    jar["test"] = "new value"
    assert jar["test"].value == "new value"
    assert headers["Set-Cookie"] == "test=new value; Path=/; Max-Age=0"
    jar["test"]["max-age"] = 3600
    assert jar["test"]["max-age"] == 3600
    assert headers["Set-Cookie"] == "test=new value; Path=/; Max-Age=3600"
    jar["test"]["max-age"] = 0
    assert jar["test"]["max-age"]

# Generated at 2022-06-18 04:59:28.428058
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:33.746814
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == None


# Generated at 2022-06-18 04:59:40.434807
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime.utcnow()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=Lax; Comment=test; Domain=test"

# Generated at 2022-06-18 04:59:51.809579
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:00:02.531104
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:00:15.332684
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:00:24.829896
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:00:29.951549
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:00:36.828262
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert cookie_jar.cookie_headers["test"] == "Set-Cookie"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert cookie_jar.cookie_headers == {}
    assert headers["Set-Cookie"] == ""


# Generated at 2022-06-18 05:00:47.870292
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:00:58.885413
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = "test"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "test"
    cookie["samesite"] = "test"
    cookie["test"] = "test"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"
    assert cookie["max-age"] == "test"
    assert cookie["secure"] == True
    assert cookie["httponly"] == True

# Generated at 2022-06-18 05:01:03.116476
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    assert "test" not in cookie_jar


# Generated at 2022-06-18 05:01:09.130821
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:01:18.338803
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["unknown"] = "unknown"


# Generated at 2022-06-18 05:01:26.660937
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["path"] = "test"
    assert cookie["path"] == "test"
    cookie["comment"] = "test"
    assert cookie["comment"] == "test"
    cookie["domain"] = "test"
    assert cookie["domain"] == "test"
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["secure"] = "test"
    assert cookie["secure"] == "test"
    cookie["httponly"] = "test"
    assert cookie["httponly"] == "test"
    cookie["version"] = "test"
    assert cookie["version"] == "test"
    cookie["samesite"] = "test"


# Generated at 2022-06-18 05:01:40.029388
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"
    cookie["max-age"] = 10
    assert str(cookie) == "test=test; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=test; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=test; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:50.484358
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:02:02.874812
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 05:02:14.337288
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert cookie_jar["test"].value == "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert cookie_jar["test2"].value == "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"



# Generated at 2022-06-18 05:02:23.334996
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:31.889663
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "lax"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:02:36.872389
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 05:02:45.670031
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:02:52.298678
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    assert cookie_jar.get("test") == None


# Generated at 2022-06-18 05:02:58.378851
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["max-age"] = 10
    assert str(cookie) == "name=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:18.668380
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["test"] = "test"
    cookie["test"] = False
    cookie["test"] = 0
    cookie["test"] = datetime.now()
    cookie["test"] = True
    cookie["test"] = "test"
    cookie["test"] = "test"
    cookie["test"] = "test"
    cookie["test"] = "test"
    cookie["test"] = "test"
    cookie

# Generated at 2022-06-18 05:03:29.301276
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:40.662248
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "Lax"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["samesite"] == "Lax"
    assert cookie["version"] == None
    assert cookie["comment"] == None
    assert cookie["domain"] == None
    assert cookie["key"] == "key"
    assert cookie["value"] == "value"
    assert cookie["expires"] == dat

# Generated at 2022-06-18 05:03:52.681368
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("key", "value")
    c["max-age"] = "123"
    assert c["max-age"] == 123
    c["expires"] = datetime.now()
    assert isinstance(c["expires"], datetime)
    c["secure"] = True
    assert c["secure"] == True
    c["secure"] = False
    assert c["secure"] == False
    c["httponly"] = True
    assert c["httponly"] == True
    c["httponly"] = False
    assert c["httponly"] == False
    c["version"] = "1"
    assert c["version"] == "1"
    c["samesite"] = "Strict"
    assert c["samesite"] == "Strict"
    c["path"] = "/"
    assert c["path"] == "/"

# Generated at 2022-06-18 05:03:58.625290
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 05:04:06.004927
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:04:17.485436
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:04:27.255535
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"

# Generated at 2022-06-18 05:04:38.515363
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("key=value; Max-Age=0; Expires=")
    cookie["secure"] = True
    assert str(cookie).startswith("key=value; Max-Age=0; Expires=")
    assert str(cookie).endswith("; Secure")
    cookie["httponly"] = True
    assert str(cookie).startswith("key=value; Max-Age=0; Expires=")
    assert str(cookie).endswith("; Secure; HttpOnly")

# Generated at 2022-06-18 05:04:48.079052
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 05:05:14.828778
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["max-age"] = 100
    assert str(cookie) == "test=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=100"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=100; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:25.504424
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:35.692766
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:05:47.590389
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:05:56.639080
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:58.794031
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:06:05.301498
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"

# Generated at 2022-06-18 05:06:15.627610
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:21.488598
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:06:33.303931
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 05:06:53.623670
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; HttpOnly; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; HttpOnly; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"

# Generated at 2022-06-18 05:07:04.873249
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:18.256808
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )
    cookie["secure"] = True

# Generated at 2022-06-18 05:07:30.130077
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:07:41.078444
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:47.042660
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:07:55.058424
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"

# Generated at 2022-06-18 05:08:06.591246
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:08:10.446366
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in headers


# Generated at 2022-06-18 05:08:17.215042
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"