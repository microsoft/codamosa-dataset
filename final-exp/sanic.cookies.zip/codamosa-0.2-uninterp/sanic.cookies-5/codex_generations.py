

# Generated at 2022-06-18 04:58:24.936564
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 04:58:35.089715
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = "example.com"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "This is a comment"

# Generated at 2022-06-18 04:58:44.950337
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"

# Generated at 2022-06-18 04:58:58.338846
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0, test2=test4; Path=/; Max-Age=0"

# Generated at 2022-06-18 04:59:03.214596
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "test")
    c["path"] = "/"
    c["max-age"] = 100
    c["expires"] = datetime(2020, 1, 1)
    c["secure"] = True
    c["httponly"] = True
    c["version"] = 1
    c["samesite"] = "Strict"
    assert str(c) == "test=test; Path=/; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly; Version=1; SameSite=Strict"

# Generated at 2022-06-18 04:59:15.028479
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["foo"] = "baz"
    cookie_jar["foo"] = "qux"
    cookie_jar["foo"] = "quux"
    cookie_jar["foo"] = "corge"
    cookie_jar["foo"] = "grault"
    cookie_jar["foo"] = "garply"
    cookie_jar["foo"] = "waldo"
    cookie_jar["foo"] = "fred"
    cookie_jar["foo"] = "plugh"
    cookie_jar["foo"] = "xyzzy"
    cookie_jar["foo"] = "thud"
    del cookie_jar["foo"]
    assert headers.getall("Set-Cookie") == []

# Unit

# Generated at 2022-06-18 04:59:24.569922
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('name', 'value')
    assert str(c) == 'name=value'
    c['max-age'] = 10
    assert str(c) == 'name=value; Max-Age=10'
    c['expires'] = datetime(2020, 1, 1)
    assert str(c) == 'name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT'
    c['secure'] = True
    assert str(c) == 'name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure'
    c['httponly'] = True

# Generated at 2022-06-18 04:59:36.849581
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]

# Generated at 2022-06-18 04:59:48.876489
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:55.820233
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["max-age"] = "1"
    assert cookie["max-age"] == 1
    cookie["max-age"] = 1
    assert cookie["max-age"] == 1
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["max-age"] = False
    assert cookie["max-age"] == 0
    cookie["max-age"] = None
    assert cookie["max-age"] == 0
    cookie["max-age"] = ""
    assert cookie["max-age"] == 0
    cookie["max-age"] = "0"
    assert cookie["max-age"] == 0
    cookie["max-age"] = "1"


# Generated at 2022-06-18 05:00:15.165274
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Tue, 01-Jan-2019 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"
    cookie["httponly"] = True


# Generated at 2022-06-18 05:00:24.717442
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    assert cookie["expires"] == datetime.now()
    assert cookie["path"] == "/"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "strict"

# Generated at 2022-06-18 05:00:33.876205
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    cookiejar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookiejar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookiejar["key2"] = "value"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:00:45.712222
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["samesite"] = "Lax"
    assert str(cookie) == (
        "name=value; Path=/; Expires=Wed, 01-Jan-2020 00:00:00 GMT; "
        "Max-Age=0; Secure; HttpOnly; Version=1; Comment=comment; "
        "Domain=domain; SameSite=Lax"
    )


# Generated at 2022-06-18 05:00:52.214669
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert cookie_jar["key"] == "value"
    del cookie_jar["key"]
    assert cookie_jar.get("key") is None
    assert headers.get("Set-Cookie") is None


# Generated at 2022-06-18 05:01:01.276559
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 123
    assert str(cookie) == "key=value; Path=/; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=123; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["secure"] = False

# Generated at 2022-06-18 05:01:05.495379
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    assert cookie_jar["key"].value == "value"


# Generated at 2022-06-18 05:01:15.180513
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:01:25.213484
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"
    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:36.143303
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["max-age"] = 10
    assert str(cookie) == "test=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:01:52.973279
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:02:04.677489
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:16.627536
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    cookies["test2"] = "test2"
    cookies["test3"] = "test3"
    cookies["test4"] = "test4"
    cookies["test5"] = "test5"
    cookies["test6"] = "test6"
    cookies["test7"] = "test7"
    cookies["test8"] = "test8"
    cookies["test9"] = "test9"
    cookies["test10"] = "test10"
    cookies["test11"] = "test11"
    cookies["test12"] = "test12"
    cookies["test13"] = "test13"
    cookies["test14"] = "test14"
    cookies["test15"] = "test15"

# Generated at 2022-06-18 05:02:27.709922
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Path=/; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:02:34.903539
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"
   

# Generated at 2022-06-18 05:02:44.225302
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_value"
    cookie_jar["test_cookie2"] = "test_value2"
    cookie_jar["test_cookie3"] = "test_value3"
    cookie_jar["test_cookie4"] = "test_value4"
    cookie_jar["test_cookie5"] = "test_value5"
    cookie_jar["test_cookie6"] = "test_value6"
    cookie_jar["test_cookie7"] = "test_value7"
    cookie_jar["test_cookie8"] = "test_value8"
    cookie_jar["test_cookie9"] = "test_value9"
    cookie_jar["test_cookie10"] = "test_value10"
    cookie_

# Generated at 2022-06-18 05:02:53.684871
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    assert len(cookie_jar) == 3
    assert len(headers) == 1
    assert len(headers["Set-Cookie"]) == 3
    del cookie_jar["test"]
    assert len(cookie_jar) == 2
    assert len(headers) == 1
    assert len(headers["Set-Cookie"]) == 2
    assert cookie_jar["test2"] == "test2"
    assert cookie_jar["test3"] == "test3"
    del cookie_jar["test2"]
    assert len(cookie_jar) == 1
    assert len(headers) == 1

# Generated at 2022-06-18 05:03:05.944073
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:03:12.149827
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.headers
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.headers


# Generated at 2022-06-18 05:03:19.432258
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:30.264311
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:03:41.712311
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:03:52.965627
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "value")
    assert str(c) == "test=value"
    c["max-age"] = 10
    assert str(c) == "test=value; Max-Age=10"
    c["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(c) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["secure"] = True
    assert str(c) == "test=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    c["httponly"] = True

# Generated at 2022-06-18 05:04:04.149050
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in cookie_jar.cookie_headers
    assert "Set-Cookie" in headers
    assert "test" in headers["Set-Cookie"]
    cookie_jar["test2"] = "test2"
    assert "test2" in cookie_jar
    assert "test2" in cookie_jar.cookie_headers
    assert "Set-Cookie" in headers
    assert "test2" in headers["Set-Cookie"]
    del cookie_jar["test"]
    assert "test" not in cookie_jar
    assert "test" not in cookie_jar.cookie_headers
    assert "Set-Cookie" in headers
    assert "test" not in headers

# Generated at 2022-06-18 05:04:15.561499
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    assert str(cookie) == "test=test"

    cookie["max-age"] = 0
    assert str(cookie) == "test=test; Max-Age=0"

    cookie["max-age"] = "0"
    assert str(cookie) == "test=test; Max-Age=0"

    cookie["max-age"] = "test"
    assert str(cookie) == "test=test; Max-Age=test"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=test; Max-Age=test; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True

# Generated at 2022-06-18 05:04:26.824919
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = "123"
    assert str(cookie) == "name=value; Path=/; Max-Age=123"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=123; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=123; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:04:38.423452
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Secure"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Secure; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:48.003076
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:04:59.381565
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = "10"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "strict"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

    assert cookie["path"] == "/"
    assert cookie["expires"] == datetime.now()
    assert cookie["max-age"] == "10"
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == "1"
    assert cookie["samesite"] == "strict"
    assert cookie["comment"] == "comment"

# Generated at 2022-06-18 05:05:09.811377
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert len(cookie_jar) == 2
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "test=test; Path=/; test2=test2; Path=/"
    del cookie_jar["test"]
    assert len(cookie_jar) == 1
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "test2=test2; Path=/"
    del cookie_jar["test2"]
    assert len(cookie_jar) == 0
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "test2=; Max-Age=0; Path=/"

#

# Generated at 2022-06-18 05:05:26.161383
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"

    assert len(cookie_jar) == 5
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "key1=value1; Path=/; key2=value2; Path=/; key3=value3; Path=/; key4=value4; Path=/; key5=value5; Path=/"

    del cookie_jar["key3"]
    assert len(cookie_jar) == 4
    assert len(headers) == 1

# Generated at 2022-06-18 05:05:36.515509
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:05:48.308584
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:05:56.639421
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "strict"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert str(cookie) == "test=test; Path=/; Max-Age=0; Expires=%s; Secure; HttpOnly; Version=1; SameSite=strict; Comment=test; Domain=test" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-18 05:06:04.616634
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:06:10.354215
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:06:18.355195
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test1"] = "test1"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"

# Generated at 2022-06-18 05:06:29.490222
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=%s" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")

    cookie["secure"] = True

# Generated at 2022-06-18 05:06:39.423855
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:06:50.573305
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:07:07.392072
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    cookie

# Generated at 2022-06-18 05:07:19.323393
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Max-Age=10"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:30.412488
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=0; Secure"

# Generated at 2022-06-18 05:07:36.402423
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 1
    assert str(cookie) == "name=value; Path=/; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Path=/; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:40.099241
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"


# Generated at 2022-06-18 05:07:50.792417
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["expires"] == datetime.now()
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 05:07:57.165383
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:08:07.434258
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    assert len(cookie_jar) == 2
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "foo=bar; Path=/; baz=qux; Path=/"
    del cookie_jar["foo"]
    assert len(cookie_jar) == 1
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "baz=qux; Path=/"
    del cookie_jar["baz"]
    assert len(cookie_jar) == 0
    assert len(headers) == 0
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:08:10.652510
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; HttpOnly"


# Generated at 2022-06-18 05:08:17.347586
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert cookie_jar["test"] == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == ""
    assert cookie_jar == {}
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test2=test2; Path=/; Max-Age=0"