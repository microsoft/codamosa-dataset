

# Generated at 2022-06-18 04:58:40.683344
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Path=/; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 04:58:45.342831
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 04:58:58.339097
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 04:59:03.202231
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 04:59:15.029125
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 04:59:24.571077
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 1
    assert str(cookie) == "name=value; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "name=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 04:59:36.850253
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Lax"
    assert cookie["comment"] == "comment"
    assert cookie["domain"] == "domain"

# Generated at 2022-06-18 04:59:48.828161
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"


# Generated at 2022-06-18 04:59:55.792520
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:05.238384
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers.get("Set-Cookie") == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers.get("Set-Cookie") == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"
    assert headers.get("Set-Cookie") == "test=test3; Path=/; Max-Age=0"

# Generated at 2022-06-18 05:00:19.419747
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    assert str(cookie) == (
        "key=value; Path=/; expires=Wed, 01-Jan-2020 00:00:00 GMT; "
        "Max-Age=0; Secure; HttpOnly; Version=1; SameSite=Strict"
    )

# Generated at 2022-06-18 05:00:27.457741
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 1
    assert str(cookie) == "key=value; Max-Age=1"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=1; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:00:33.429733
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:00:40.667859
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0"
    cookie_jar["test"] = "test5"

# Generated at 2022-06-18 05:00:49.300115
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:00:59.544837
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["expires"] = "expires"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-18 05:01:09.080560
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = "test"
    assert cookie["expires"] == "test"
    cookie["path"] = "test"
    assert cookie["path"] == "test"
    cookie["comment"] = "test"
    assert cookie["comment"] == "test"
    cookie["domain"] = "test"
    assert cookie["domain"] == "test"
    cookie["max-age"] = "test"
    assert cookie["max-age"] == "test"
    cookie["secure"] = "test"
    assert cookie["secure"] == "test"
    cookie["httponly"] = "test"
    assert cookie["httponly"] == "test"
    cookie["version"] = "test"
    assert cookie["version"] == "test"
    cookie["samesite"] = "test"


# Generated at 2022-06-18 05:01:21.335540
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test3"

# Generated at 2022-06-18 05:01:32.443227
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c["max-age"] = 10
    assert str(c) == "name=value; Max-Age=10"
    c["expires"] = datetime(2020, 1, 1)
    assert str(c) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["secure"] = True
    assert str(c) == "name=value; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    c["httponly"] = True

# Generated at 2022-06-18 05:01:42.025132
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert cookie["path"] == "/"
    assert cookie["expires"] == datetime.now()
    assert cookie["max-age"] == 0
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "lax"
    assert cookie["comment"] == "test"
    assert cookie["domain"] == "test"

# Generated at 2022-06-18 05:01:57.196640
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )
    cookie["secure"] = True
    assert str(cookie) == "name=value; Max-Age=0; Expires=%s; Secure" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )
    cookie["secure"] = False

# Generated at 2022-06-18 05:02:07.258666
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    assert headers.get("Set-Cookie1") == "test2=test2; Path=/; Max-Age=0"
    del cookie_jar["test2"]

# Generated at 2022-06-18 05:02:13.196893
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:24.421230
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    cookie["key"] = "value"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = 0
    cookie["max-age"] = "0"
    cookie["max-age"] = "1"
    cookie["max-age"] = 1
    cookie["max-age"] = "a"

# Generated at 2022-06-18 05:02:29.042547
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:32.677260
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert cookie_jar["key"].value == "value"
    del cookie_jar["key"]
    assert "key" not in cookie_jar
    assert headers.get("Set-Cookie") == None


# Generated at 2022-06-18 05:02:37.325891
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Strict"

    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["expires"] == datetime.now()
    assert cookie["secure"] == True
    assert cookie["httponly"] == True
    assert cookie["version"] == 1
    assert cookie["samesite"] == "Strict"

    with pytest.raises(KeyError):
        cookie["unknown"] = "unknown"

    with pytest.raises(ValueError):
        cookie["max-age"]

# Generated at 2022-06-18 05:02:44.501751
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "value2"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0"
    cookie_jar["key2"] = "value"
    assert headers["Set-Cookie"] == "key=value2; Path=/; Max-Age=0\nkey2=value; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:02:53.787763
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"

# Generated at 2022-06-18 05:03:05.445850
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "Lax"
    cookie["version"] = 1
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=%s; Secure; HttpOnly; SameSite=Lax; Version=1; Comment=test; Domain=test" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")

# Generated at 2022-06-18 05:03:22.239770
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Expires=%s" % (
        datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )
    cookie["secure"] = True

# Generated at 2022-06-18 05:03:31.720310
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0; HttpOnly"
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert headers.get("Set-Cookie") == "test=test; Path=/; HttpOnly"
    assert headers.get("Set-Cookie", 1) == "test2=test2; Path=/; HttpOnly"
    del cookie_jar["test"]

# Generated at 2022-06-18 05:03:42.263013
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["max-age"] = "1"
    assert cookie["max-age"] == "1"
    cookie["expires"] = datetime.now()
    assert cookie["expires"] == datetime.now()
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    cookie["version"] = "1"
    assert cookie["version"] == "1"
    cookie["samesite"] = "Strict"
    assert cookie["samesite"] == "Strict"
    try:
        cookie["test"] = "value"
    except KeyError:
        assert True

# Generated at 2022-06-18 05:03:53.003105
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test2; Path=/; Max-Age=0"
    cookie_jar["test3"] = "test3"

# Generated at 2022-06-18 05:04:04.197176
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    assert str(cookie) == "test=value"

    cookie["path"] = "/"
    assert str(cookie) == "test=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "test=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "test=value; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

    cookie["httponly"] = True

# Generated at 2022-06-18 05:04:13.856984
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    assert str(cookie) == "key=value; Path=/; Max-Age=0; Secure; HttpOnly; Comment=comment; Domain=domain; Version=version; SameSite=samesite"


# Generated at 2022-06-18 05:04:25.298694
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 0
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True
    assert str(cookie) == "key=value; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly"

# Generated at 2022-06-18 05:04:35.796418
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"

    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Path=/; Max-Age=0"

    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT"

    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure"


# Generated at 2022-06-18 05:04:47.105052
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = 3600
    assert str(cookie) == "name=value; Path=/; Max-Age=3600"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "name=value; Path=/; Max-Age=3600; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; Max-Age=3600; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:04:58.579980
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["expires"] = "expires"
    cookie["path"] = "Path"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = "Max-Age"
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"
    assert cookie["expires"] == "expires"
    assert cookie["path"] == "Path"
    assert cookie["comment"] == "Comment"
    assert cookie["domain"] == "Domain"
    assert cookie["max-age"] == "Max-Age"
    assert cookie["secure"] == "Secure"
    assert cookie["httponly"] == "HttpOnly"

# Generated at 2022-06-18 05:05:26.554334
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookie_jar["test"] = "test3"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0"
    cookie_jar["test2"] = "test4"
    assert headers["Set-Cookie"] == "test=test3; Path=/; Max-Age=0; test2=test4; Path=/; Max-Age=0"

# Generated at 2022-06-18 05:05:37.814592
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert "test" in cookie_jar
    assert "test" in headers
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    cookie_jar["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly"
    cookie_jar["test2"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly, test2=test2; Path=/; HttpOnly"
    cookie_jar["test3"] = "test3"

# Generated at 2022-06-18 05:05:42.148466
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookie_

# Generated at 2022-06-18 05:05:52.923179
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 05:06:01.763742
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:06:13.462293
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"
    cookie_jar["key13"] = "value13"

# Generated at 2022-06-18 05:06:19.551746
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:06:31.322415
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"
    assert headers["Set-Cookie"] == "key=new_value; Path=/; Max-Age=0"
    cookie_jar["key"] = "new_value"

# Generated at 2022-06-18 05:06:41.743136
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:06:52.515929
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    cookie_jar["test3"] = "test3"
    cookie_jar["test4"] = "test4"
    cookie_jar["test5"] = "test5"
    cookie_jar["test6"] = "test6"
    cookie_jar["test7"] = "test7"
    cookie_jar["test8"] = "test8"
    cookie_jar["test9"] = "test9"
    cookie_jar["test10"] = "test10"
    cookie_jar["test11"] = "test11"
    cookie_jar["test12"] = "test12"
    cookie_jar["test13"] = "test13"
   

# Generated at 2022-06-18 05:07:23.775704
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "test")
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "test"
    cookie["test"] = "test"
    cookie["test"] = False
    cookie["test"] = 0
    cookie["test"] = ""
    cookie["test"] = None
    cookie["test"] = True
    cookie["test"] = 1
    cookie["test"] = "test"
    cookie["test"] = datetime.now()
    cookie["test"] = "/"
    cookie["test"] = "test"


# Generated at 2022-06-18 05:07:29.572292
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert headers.get("Set-Cookie") == "key=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:07:40.971096
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"
    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Path=/; Max-Age=0; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"

# Generated at 2022-06-18 05:07:51.334748
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 100
    assert str(cookie) == "key=value; Max-Age=100"
    cookie["expires"] = datetime(2020, 1, 1)
    assert str(cookie) == "key=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "key=value; Max-Age=100; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure"
    cookie["httponly"] = True

# Generated at 2022-06-18 05:07:57.489915
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    cookies["test"] = "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0"
    cookies["test2"] = "test3"
    assert headers["Set-Cookie"] == "test=test2; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"
    cookies["test"] = "test4"
    assert headers["Set-Cookie"] == "test=test4; Path=/; Max-Age=0\ntest2=test3; Path=/; Max-Age=0"

# Generated at 2022-06-18 05:08:08.302233
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "name=value; Path=/; Max-Age=0"
    cookie["expires"] = datetime.now()
    assert str(cookie) == "name=value; Path=/; Max-Age=0; Expires=%s" % (
        cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")
    )
    cookie["secure"] = True

# Generated at 2022-06-18 05:08:12.933393
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers.get("Set-Cookie") == "test=test; Path=/; Max-Age=0"
    del cookie_jar["test"]
    assert headers.get("Set-Cookie") == "test=; Path=/; Max-Age=0"


# Generated at 2022-06-18 05:08:17.765455
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly"
    del cookie_jar["test"]
    assert headers["Set-Cookie"] == "test=; Path=/; Max-Age=0; HttpOnly"


# Generated at 2022-06-18 05:08:23.462983
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert cookie_jar["key"] == "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"
    del cookie_jar["key"]
    assert "key" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-18 05:08:31.397731
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    cookie_jar["key5"] = "value5"
    cookie_jar["key6"] = "value6"
    cookie_jar["key7"] = "value7"
    cookie_jar["key8"] = "value8"
    cookie_jar["key9"] = "value9"
    cookie_jar["key10"] = "value10"
    cookie_jar["key11"] = "value11"
    cookie_jar["key12"] = "value12"