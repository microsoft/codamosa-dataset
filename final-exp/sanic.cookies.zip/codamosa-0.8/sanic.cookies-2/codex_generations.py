

# Generated at 2022-06-12 08:31:13.462264
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    jar = CookieJar(headers)
    jar["my-key"] = "my-value"
    assert headers.getall("Set-Cookie") == [
        "my-key=my-value; Path=/; Max-Age=0; HttpOnly"
    ]
    del jar["my-key"]
    # The value should be deleted from the headers, but the key should remain
    assert "Set-Cookie" not in headers
    jar["my-key"] = "my-value"
    assert headers.getall("Set-Cookie") == [
        "my-key=my-value; Path=/; Max-Age=0; HttpOnly"
    ]
    del jar["my-key"]
    # Now the key should also be deleted
    assert "Set-Cookie" not in headers

#

# Generated at 2022-06-12 08:31:21.021724
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "value")
    assert c.__str__() == "test=value"
    expiry = datetime(1970, 1, 1, 1, 1, 1)
    c["expires"] = expiry
    assert c.__str__() == "test=value; Expires=Thu, 01-Jan-1970 01:01:01 GMT"
    c["secure"] = True
    assert c.__str__() == "test=value; Expires=Thu, 01-Jan-1970 01:01:01 GMT; Secure"
    c["httponly"] = True
    assert c.__str__() == "test=value; Expires=Thu, 01-Jan-1970 01:01:01 GMT; Secure; HttpOnly"
    c["Secure"] = False

# Generated at 2022-06-12 08:31:31.173374
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('werkzeug', 'awesome')
    assert cookie.__str__() == 'werkzeug=awesome'
    cookie = Cookie('hello', 'world')
    cookie['path'] = '/'
    cookie['domain'] = 'localhost'
    cookie['expires'] = datetime(
        year=2020, month=1, day=1, hour=1, minute=1, second=1)
    assert (
        cookie.__str__()
        == 'hello=world; Path=/; Domain=localhost; Expires=Wed, 01-Jan-2020 01:01:01 GMT'
    )
    cookie = Cookie('hello', 'world')
    cookie['path'] = '/'
    cookie['domain'] = 'localhost'
    cookie['max-age'] = 9999
    cookie['secure'] = True

# Generated at 2022-06-12 08:31:37.418651
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaders()
    jar = CookieJar(headers)
    jar["hello"] = "world!"
    assert headers["Set-Cookie"] == 'hello="world!"; Path=/'
    jar["hello"] = "changed"
    assert headers["Set-Cookie"] == 'hello="changed"; Path=/'
    jar["hello"]["path"] = "/path"
    assert headers["Set-Cookie"] == 'hello="changed"; Path=/path'
    del jar["hello"]
    assert headers["Set-Cookie"] == 'hello=""; Max-Age=0; Path=/path'
    assert jar == {}



# Generated at 2022-06-12 08:31:39.953998
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    assert 1 == 1
    return True


# Generated at 2022-06-12 08:31:50.062982
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test-key", "test-value")
    assert not cookie.get("invalid-key")
    assert not cookie.get("expires")
    assert not cookie.get("max-age")
    assert not cookie.get("secure")
    assert not cookie.get("httponly")
    assert not cookie.get("version")
    assert not cookie.get("samesite")
    assert cookie.get("path") == "/"

    # Provided key is not in the set of available keys
    with pytest.raises(KeyError):
        cookie["invalid-key"] = 1

    # Value for max-age is not a valid integer
    with pytest.raises(ValueError):
        cookie["max-age"] = "not-a-valid-int"

    # Value for expires is not a valid datetime.datetime

# Generated at 2022-06-12 08:31:58.595421
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    raw_input_data = [
        {"input": {"key": "secure", "value": False}, "output": "输入值不是False"},
        {"input": {"key": "expires", "value": False}, "output": "Cookie 'expires' property must be a datetime"},
        {"input": {"key": "max-age", "value": "text"}, "output": "Cookie max-age must be an integer"},
        {"input": {"key": "test", "value": "test"}, "output": "Unknown cookie property"},
    ]

# Generated at 2022-06-12 08:32:06.963610
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Test to make sure that the Cookie object can be made into a string."""
    headers = {}
    new_cookie = Cookie("hello", "world")
    assert new_cookie.__str__() == "hello=world"
    new_cookie["Max-Age"] = "100"
    assert new_cookie.__str__() == "hello=world; Max-Age=100"
    headers["hello"] = "world"
    new_cookie = Cookie("hello", "world")
    new_cookie["Max-Age"] = "100"
    assert new_cookie.__str__() == "hello=world; Max-Age=100"

# Generated at 2022-06-12 08:32:15.936848
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == 'name=value'
    cookie["expires"] = "Sun, 17-Jan-2038 19:14:07 GMT"
    assert str(cookie) == 'name=value; expires=Sun, 17-Jan-2038 19:14:07 GMT'
    cookie.max_age = "36000"
    assert str(cookie) == 'name=value; expires=Sun, 17-Jan-2038 19:14:07 GMT; Max-Age=36000'


# ------------------------------------------------------------ #
#  Helpers
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:32:21.248174
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # test if the method can del item in the headers
    headers = Headers()
    jar = CookieJar(headers)
    jar["a"] = "b"
    assert "a" in jar
    del jar["a"]
    assert "a" not in jar

    # test if the method can del item but not in the headers
    headers = Headers()
    jar = CookieJar(headers)
    del jar["a"]
    assert "a" not in jar


# Generated at 2022-06-12 08:32:27.269118
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("testcookie", "testvalue")
    ret = cookie.__str__()
    assert ret == "testcookie=testvalue"


# Generated at 2022-06-12 08:32:34.402488
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c1 = Cookie("key1", "value1")
    assert c1["path"] == "/"
    assert c1["key1"] == None
    c2 = Cookie("key2", "value2")
    assert c2["key2"] == None
    try:
        c3 = Cookie("expires", "value3")
        assert False
    except KeyError as e:
        assert str(e) == "Cookie name is a reserved word"
    try:
        c4 = Cookie("key4", "value4")
        c4["expires"] = "value4"
        assert False
    except KeyError as e:
        assert str(e) == "Unknown cookie property"
    c5 = Cookie("key5", "value5")

# Generated at 2022-06-12 08:32:42.716883
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    # create a CookieJar object
    cookie_jar = CookieJar(headers)
    # test first use case, key does not exist on the CookieJar object
    test_key = "test"
    cookie_jar.__delitem__(test_key)
    assert test_key not in cookie_jar.headers
    # test second use case, key exists on the CookieJar object
    cookie_jar.headers[test_key] = "value"
    cookie_jar.__delitem__(test_key)
    assert test_key not in cookie_jar.headers


# Generated at 2022-06-12 08:32:53.418654
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    result = str(cookie)
    assert result == "key=value"
    cookie["Expires"] = datetime(2050, 12, 31, 12, 0, 0, tzinfo=None)
    result = str(cookie)
    assert result == "key=value; Expires=Sat, 31-Dec-2050 12:00:00 GMT"
    cookie["max-age"] = 10
    result = str(cookie)
    assert result == ("key=value; Expires=Sat, 31-Dec-2050 12:00:00 GMT; "
                      "Max-Age=10")
    cookie["Domain"] = "localhost"
    result = str(cookie)

# Generated at 2022-06-12 08:33:04.422914
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["path"] = "/"
    assert str(cookie) == "foo=bar; Path=/;"
    cookie["max-age"] = 0
    assert str(cookie) == "foo=bar; Max-Age=0; Path=/;"
    del cookie["max-age"]
    cookie["expires"] = datetime(2040, 1, 1, 1, 1, 1)
    assert str(cookie) == "foo=bar; Expires=Wed, 01-Jan-2040 01:01:01 GMT; Path=/;"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Expires=Wed, 01-Jan-2040 01:01:01 GMT; Path=/; Secure;"

# Generated at 2022-06-12 08:33:14.470967
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c1 = Cookie("c1", "1")
    c1["path"] = "/"
    c1["expires"] = datetime.strptime("Wed, 21 Oct 2015 07:28:00 GMT", "%a, %d %b %Y %H:%M:%S %Z")
    c1["max-age"] = 0
    c1["comment"] = "Test1"
    c1["domain"] = "localhost"
    c1["secure"] = True
    c1["httponly"] = True
    c1["version"] = "1"
    c1["samesite"] = "lax"
    print(c1)
    # Result: c1=1; Path=/; expires=Wed, 21 Oct 2015 07:28:00 GMT; Max-Age=0; Comment=Test1; Domain=localhost; Secure;

# Generated at 2022-06-12 08:33:26.091424
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers({"Content-Type": "text/html; charset=utf-8"})
    cookie = CookieJar(headers)
    cookies = [
        {"key": "Test", "value": "this"},
        {"key": "Test2", "value": "that"}
    ]
    for cookie_ in cookies:
        cookie[cookie_["key"]] = cookie_["value"]
    assert len(list(cookie.items())) == 2
    assert len(list(cookie.keys())) == 2
    assert len(list(cookie.values())) == 2
    assert "Test" in cookie
    assert "Test2" in cookie
    del cookie["Test"]
    assert len(list(cookie.items())) == 1
    assert len(list(cookie.keys())) == 1

# Generated at 2022-06-12 08:33:38.089976
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="key", value="value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 20
    assert str(cookie) == "key=value; Max-Age=20"
    cookie["path"] = "test"
    assert str(cookie) == "key=value; Max-Age=20; Path=test"
    cookie["domain"] = "test"
    assert (
        str(cookie)
        == "key=value; Max-Age=20; Path=test; Domain=test"
    )
    cookie["expires"] = datetime(2020, 5, 19, 22, 24, 28)

# Generated at 2022-06-12 08:33:41.194809
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test Case of program
    headers = MultiHeader()
    headers["Set-Cookie"] = "Key1=Val1"
    headers["Set-Cookie"] = "Key2=Val2"
    headers["Set-Cookie"] = "Key3=Val3"
    cookie_jar = CookieJar(headers)
    del cookie_jar["Key2"]
    assert headers["Set-Cookie"] == "Key1=Val1;Key3=Val3"


# Generated at 2022-06-12 08:33:51.343252
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")

    # Set version property
    cookie["version"] = 1
    assert cookie["version"] == 1

    # Set max-age property
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0

    # Set expires property
    cookie["expires"] = datetime.now()
    assert isinstance(cookie["expires"], datetime)

    # Set domain property
    cookie["domain"] = "127.0.0.1"
    assert cookie["domain"] == "127.0.0.1"

    # Set path property
    cookie["path"] = "/"
    assert cookie["path"] == "/"

    # Set comment property
    cookie["comment"] = "TEST"
    assert cookie["comment"] == "TEST"

    # Set httponly property

# Generated at 2022-06-12 08:33:57.537371
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    expected = "Cookie=cookie; HttpOnly"
    assert str(Cookie("Cookie","cookie")) == expected


# Generated at 2022-06-12 08:34:08.607816
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Ensure that Cookie.__setitem__ raises an exception
    when attempting to set an invalid property
    """
    cookie = Cookie("test", "data")
    try:
        cookie["expires"] = datetime.now()
    except KeyError:
        assert False

    try:
        cookie["path"] = "/"
    except KeyError:
        assert False

    try:
        cookie["comment"] = "test"
    except KeyError:
        assert False

    try:
        cookie["domain"] = "test.com"
    except KeyError:
        assert False

    try:
        cookie["max-age"] = "100"
    except KeyError:
        assert False
    try:
        cookie["secure"] = True
    except KeyError:
        assert False


# Generated at 2022-06-12 08:34:12.967639
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "value"

    del cookie_jar["name"]

    assert headers.getall("Set-Cookie") == ["name=; Max-Age=0"]

# Generated at 2022-06-12 08:34:21.106219
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cookies = CookieJar(headers)
    cookies.add(Cookie('name', 'value'))
    assert 'name' in cookies
    assert cookies['name'].output() == 'Set-Cookie: name="value"; Path=/'
    assert 'name' in cookies.cookie_headers
    del cookies['name']
    assert 'name' not in cookies
    assert 'name' not in cookies.cookie_headers
    assert 'Set-Cookie' not in headers


# Generated at 2022-06-12 08:34:28.221878
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie = CookieJar(headers)
    assert len(headers) == 0
    assert not cookie.cookie_headers.get("hello")
    assert not cookie.headers.get("Set-Cookie")
    cookie["hello"] = "3"
    assert len(headers) == 1
    assert cookie.cookie_headers.get("hello")
    assert cookie.headers.get("Set-Cookie")
    assert cookie["hello"] == "3"


# Generated at 2022-06-12 08:34:32.563457
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cj = CookieJar(headers)
    cookie = Cookie('session', '1234')
    cookie['path'] = "/"
    cj.cookie_headers['session'] = 'Set-Cookie'
    headers.add('Set-Cookie', cookie)
    del cj['session']
    assert cj == {}
    assert cj.cookie_headers == {}
    assert headers == {}


# Generated at 2022-06-12 08:34:40.159714
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('welcome', 'hello')
    cookie['path'] = '/'
    cookie['comment'] = 'automated test'
    cookie['version'] = '1'
    cookie['expires'] = datetime(2021, 12, 12, 12, 12, 12)
    cookie['httponly'] = 'httponly'
    cookie['secure'] = 'secure'
    cookie['max-age'] = '15'
    cookie['domain'] = 'example.com'
    cookie['samesite'] = 'lax'
    assert str(cookie) == 'welcome=hello; Domain=example.com; Path=/; comment=automated test; expires=Mon, 12-Dec-2021 12:12:12 GMT; max-age=15; version=1; HttpOnly; Secure; SameSite=lax'


# Generated at 2022-06-12 08:34:46.212891
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    cookies["a"] = "b"
    del cookies["a"]
    assert not headers.get("Set-Cookie")
    cookies["c"] = "d"
    del cookies["c"]
    assert not headers.get("Set-Cookie")
    cookies["e"] = "f"
    del cookies["e"]
    assert not headers.get("Set-Cookie")

# Generated at 2022-06-12 08:34:56.714595
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import unittest.mock
    from unittest.mock import ANY

    cookie = Cookie("name", "value")
    cookie["expires"] = datetime(2017, 7, 1)
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "localhost"
    cookie["max-age"] = "10"
    cookie["secure"] = True
    cookie["httponly"] = False

    with unittest.mock.patch("werkzeug.datastructures.Cookie.__str__") as mock:
        mock.return_value = "mock"
        assert str(cookie) == "mock"
        mock.assert_called_once_with()


# Generated at 2022-06-12 08:35:05.943134
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test cookie with two pairs
    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"
    expected_str = "foo=bar; Path=/"
    assert str(cookie) == expected_str
    # test equal sign in value
    cookie = Cookie("foo", "bar=1")
    cookie["path"] = "/"
    expected_str = 'foo="bar=1"; Path=/"'
    assert str(cookie) == expected_str
    # test non-ascii chars
    cookie = Cookie("foo", "üäö")
    cookie["path"] = "/"
    expected_str = "foo=üäö; Path=/"
    assert str(cookie) == expected_str
    # test max-age
    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"
    cookie

# Generated at 2022-06-12 08:35:23.405033
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    test_cookie = CookieJar(headers)
    test_cookie["test_key"] = "test_value"
    assert "test_key" in test_cookie.cookie_headers
    del test_cookie["test_key"]
    assert not test_cookie.cookie_headers["test_key"]

# Generated at 2022-06-12 08:35:27.689747
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    This test will check if Cookie class could raise a KeyError when setting a property which is a reserved word
    """
    Cookie._keys = {"test": "test"}
    with pytest.raises(KeyError):
        cookie = Cookie("key", "value")
        cookie["test"] = "test"



# Generated at 2022-06-12 08:35:36.072435
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # simple cookie
    c = Cookie("test", "1234")
    assert str(c) == "test=1234"
    # string with quotes
    c = Cookie("test", '"hello"')
    assert str(c) == 'test="\\"hello\\""'
    # string with spaces
    c = Cookie("test", "hello world")
    assert str(c) == 'test="hello world"'
    # cookie with max-age
    c = Cookie("test", "1234")
    c["max-age"] = 999
    assert str(c) == "test=1234; Max-Age=999"
    # cookie with expires
    c = Cookie("test", "1234")
    c["expires"] = datetime(2030, 1, 1, 1, 1, 1)

# Generated at 2022-06-12 08:35:37.327210
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar({})
    jar["test"] = "test"
    del jar["test"]

# Generated at 2022-06-12 08:35:39.833407
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = CaseInsensitiveDict()
    cookie_jar = CookieJar(headers)
    cookie_jar['A'] = '1'
    assert headers['Set-Cookie'] == 'A=1; Path=/'


# Generated at 2022-06-12 08:35:47.910998
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class MockHeaders:
        def __init__(self):
            self.headers = dict()

        def add(self, key, val):
            if key not in self.headers:
                self.headers[key] = [val]
            else:
                if val not in self.headers[key]:
                    self.headers[key].append(val)

        def popall(self, key):
            res = []
            if key in self.headers:
                res = self.headers[key]
            self.headers[key] = []
            return res

    # Test case 1
    headers = MockHeaders()
    jar = CookieJar(headers)
    jar["key1"] = "val1"
    jar["key2"] = "val2"
    del jar["key1"]

# Generated at 2022-06-12 08:35:50.306296
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert cookie.__str__() == "key=value"


# Generated at 2022-06-12 08:35:53.338152
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    cookies['test'] = 'test'
    assert 'test' in cookies
    assert 'test' in cookies['test']


# Generated at 2022-06-12 08:36:03.285747
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Might want to import Cookie from here
    c = Cookie("name", "value")
    assert c.__str__() == "name=value"

    c["httpsonly"] = True
    assert c.__str__() == "name=value; HttpOnly"

    c["httpsonly"] = False
    c["max-age"] = DEFAULT_MAX_AGE
    assert c.__str__() == "name=value; Max-Age=0"

    c["expires"] = datetime(2020, 1, 1)
    assert c.__str__() == "name=value; Max-Age=0; expires=Wed, 01-Jan-2020 00:00:00 GMT"

# Generated at 2022-06-12 08:36:12.935491
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("asd", "asd")
    cookie["secure"] = False
    assert cookie["secure"] is False
    cookie["secure"] = True
    assert cookie["secure"] is True
    cookie["secure"] = "1"
    assert cookie["secure"] == "1"
    cookie["secure"] = "0"
    assert cookie["secure"] == "0"
    cookie["secure"] = 0
    assert cookie["secure"] == 0
    cookie["secure"] = 1
    assert cookie["secure"] == 1
    cookie["secure"] = None
    assert cookie["secure"] is None
    cookie["secure"] = "ads"
    assert cookie["secure"] == "ads"



# Generated at 2022-06-12 08:36:28.690199
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from multiheader import MultiHeader
    from datetime import datetime
    from httpcookie import Morsel

    # cookie value as string
    cookie = CookieJar(MultiHeader())
    cookie["name"] = "value"
    assert isinstance(cookie["name"], Morsel)
    assert cookie["name"].key == "name"
    assert cookie["name"].value == "value"
    assert cookie["name"]["path"] == "/"
    assert cookie["name"]["max-age"] == 0

    # cookie value as datetime
    expires = datetime(2020, 1, 1, 12)
    cookie["expires"] = expires
    assert cookie["expires"].key == "expires"
    assert cookie["expires"].value == expires

    # cookie value as number
    cookie["max_age"] = 999

# Generated at 2022-06-12 08:36:33.688659
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    cookies["foo"] = "bar"
    assert cookies["foo"].value == "bar"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; Version=0; Max-Age=0"


# Generated at 2022-06-12 08:36:39.567686
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import pytest
    headers = pytest.Mock()
    headers.add = pytest.Mock()
    jar = CookieJar(headers)
    jar['a'] = '1'
    headers.add.assert_called_with('Set-Cookie', jar['a'])



# Generated at 2022-06-12 08:36:47.076642
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Test __str__ method of Cookie class."""
    cookie_obj1 = Cookie("test1", "test1_value")
    cookie_obj1["path"] = "/"
    cookie_obj1["expires"] = "2030-01-01T00:00:00Z"
    cookie_obj1["max-age"] = 1000
    cookie_obj1["domain"] = "localhost"
    cookie_obj1["SameSite"] = "Lax"
    cookie_obj1["secure"] = True
    cookie_obj1["httponly"] = True

# Generated at 2022-06-12 08:36:56.742403
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("redirect", "0")
    assert str(cookie) == "redirect=0"
    cookie["max-age"] = 0
    assert str(cookie) == "redirect=0; Max-Age=0"
    cookie["httponly"] = True
    assert str(cookie) == "redirect=0; Max-Age=0; HttpOnly"
    cookie["expires"] = datetime(2014, 12, 12, 12, 12, 12)
    assert (
        str(cookie)
        == "redirect=0; Max-Age=0; HttpOnly; Expires=Fri, 12-Dec-2014 12:12:12 GMT"
    )


# Generated at 2022-06-12 08:37:05.659619
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    # assert str(cookie) == "key=value"
    cookie["max-age"] = 0
    # assert str(cookie) == "key=value; Max-Age=0"
    cookie["expires"] = datetime.utcnow()
    # assert str(cookie)
    cookie["domain"] = "test.com"
    # assert str(cookie)
    cookie["secure"] = True
    # assert str(cookie)
    cookie["httponly"] = True
    # assert str(cookie)
    cookie["path"] = "/"
    # assert str(cookie)
    cookie = Cookie("key", "value;")
    # assert str(cookie) == 'key="value;"'

# Generated at 2022-06-12 08:37:16.913603
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('test', 'value')
    cookie['comment'] = 'this is a comment'
    assert str(cookie) == 'test=value; Comment=this is a comment'
    cookie = Cookie('test', 'value')
    cookie['secure'] = True
    assert str(cookie) == 'test=value; Secure'
    cookie = Cookie('test', 'value')
    cookie['secure'] = False
    assert str(cookie) == 'test=value'
    cookie = Cookie('test', 'value')
    cookie['samesite'] = 'Lax'
    assert str(cookie) == 'test=value; SameSite=Lax'
    cookie = Cookie('test', 'value')
    cookie['expires'] = datetime(2049, 12, 31, 23, 59, 59)

# Generated at 2022-06-12 08:37:24.762401
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers.add("Set-Cookie", "key=value")
    headers.add("Set-Cookie", "key2=value2")

    cookiejar = CookieJar(headers)

    assert len(cookiejar) == 2

    del cookiejar["key"]

    assert len(cookiejar) == 1

    assert "key=value" not in headers.getlist("Set-Cookie")

    assert "key2=value2" in headers.getlist("Set-Cookie")


# Generated at 2022-06-12 08:37:37.009307
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("a", "b")
    assert str(cookie) == "a=b"
    cookie = Cookie("a", "b")
    cookie["max-age"] = 1
    assert str(cookie) == "a=b; Max-Age=1"
    cookie = Cookie("a", "b")
    cookie["expires"] = datetime(2018, 1, 1, 0, 0)
    assert str(cookie) == "a=b; Expires=Mon, 01-Jan-2018 00:00:00 GMT"
    cookie = Cookie("a", "b")
    cookie["secure"] = True
    assert str(cookie) == "a=b; Secure"
    cookie = Cookie("a", "b")
    cookie["path"] = "/"
    assert str(cookie) == "a=b; Path=/"

# Generated at 2022-06-12 08:37:47.387032
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    cookie = Cookie("test", "value")
    cookies = CookieJar({"Set-Cookie": []})

    cookie["test"] = "test"
    assert cookie["test"] == "test"
    assert "test" in cookie

    cookie["max-age"] = "2"
    assert cookie["max-age"] == "2"
    assert "max-age" in cookie

    cookie["expires"] = "datetime"
    assert cookie["expires"] == "datetime"
    assert "expires" in cookie

    cookies["test"] = "value"
    assert cookies["test"] == "value"

    cookies["test"] = "value2"
    assert cookies["test"] == "value2"


# Generated at 2022-06-12 08:38:10.132327
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('c', 'cookie-value')
    assert str(cookie) == 'c=cookie-value'
    cookie['comment'] = 'a cookie'
    assert str(cookie) == 'c=cookie-value; Comment=a cookie'
    cookie['comment'] = False
    assert str(cookie) == 'c=cookie-value'
    cookie['secure'] = True
    assert str(cookie) == 'c=cookie-value; Secure'
    cookie['secure'] = False
    assert str(cookie) == 'c=cookie-value'
    cookie['httponly'] = True
    assert str(cookie) == 'c=cookie-value; HttpOnly'
    cookie['httponly'] = False
    assert str(cookie) == 'c=cookie-value'
    cookie['version'] = 2

# Generated at 2022-06-12 08:38:20.437240
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cj = CookieJar(headers)
    cj["name"] = "value"
    assert cj == {}
    cj["name"] = "value"
    assert cj != {}
    del cj["name"]
    assert cj == {}
    assert headers["Set-Cookie"] == ""
    assert headers.normalized.get("Set-Cookie", None) == None
    cj["name"] = "value"
    cj["name"]["max-age"] = 0
    assert cj == {}
    assert headers["Set-Cookie"] == ""
    assert headers.normalized.get("Set-Cookie", None) == None
    # print("name already exists in cookie headers")
    cj["name"] = "value"
    assert cj != {}

# Generated at 2022-06-12 08:38:28.403779
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie["max-age"] = 42
    assert str(cookie) == "foo=bar; Max-Age=42"

    cookie["path"] = "/qux"
    assert str(cookie) == "foo=bar; Max-Age=42; Path=/qux"

    cookie["expires"] = datetime(2017, 2, 22, 2, 22, 2)
    assert str(cookie) == \
        "foo=bar; Max-Age=42; Path=/qux; expires=Wed, 22-Feb-2017 02:22:02 GMT"


# Generated at 2022-06-12 08:38:33.507112
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('name', 'value')
    cookie['path'] = '/'
    assert cookie['path'] == '/'
    cookie['comment'] = 'test'
    assert cookie['comment'] == 'test'
    cookie['domain'] = 'localhost'
    assert cookie['domain'] == 'localhost'
    cookie['max-age'] = 100
    assert cookie['max-age'] == 100
    cookie['secure'] = True
    assert cookie['secure']
    cookie['httponly'] = True
    assert cookie['httponly']



# Generated at 2022-06-12 08:38:36.829342
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_name, cookie_value = "fred", "flintstone"
    cookie = Cookie(cookie_name, cookie_value)
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie_string = str(cookie)
    assert cookie_string.startswith("fred=flintstone; Max-Age=0"), cookie_string
    assert (
        cookie_string.count("; ") == 1
    ), f"Cookie string '{cookie_string}' should have exactly 1 semicolon"

# Generated at 2022-06-12 08:38:40.709563
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from .headers import Headers

    cookie_jar = CookieJar(Headers())
    cookie_jar["test_cookie"] = "test_value"

    assert cookie_jar.get("test_cookie")
    assert cookie_jar.get("test_cookie").value == "test_value"



# Generated at 2022-06-12 08:38:49.951681
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("testCookie", "testValue")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["comment"] = "hello world"
    cookie["expires"] = datetime(2003, 9, 2, 3, 4, 5)
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert cookie["secure"] is True
    assert cookie["httponly"] is True
    assert cookie["comment"] == "hello world"
    assert cookie["expires"] == datetime(2003, 9, 2, 3, 4, 5)


# Generated at 2022-06-12 08:38:56.608802
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Case 1: max-age is set
    cookie = Cookie("cookie_key", "cookie_value")
    cookie["max-age"] = 100
    cookie["secure"] = True
    assert str(cookie) == "cookie_key=cookie_value; Max-Age=100; Secure"

    # Case 2: max-age is not set
    cookie = Cookie("cookie_key", "cookie_value")
    cookie["secure"] = True
    assert str(cookie) == "cookie_key=cookie_value; Secure"


# Case 1: None max-age
# Case 2: valid max-age
# Case 3: non-int max-age

# Generated at 2022-06-12 08:39:04.368156
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookieJar = CookieJar(headers)
    cookieJar["user"] = "asdd"
    cookieJar["user"] = "asd"
    cookieJar["user"] = "asd"
    cookieJar["user"] = "asd"
    cookieJar["user"] = "asd"
    result = cookieJar.headers["Set-Cookie"][0].value
    del cookieJar["user"]
    result2 = cookieJar.headers["Set-Cookie"][1].value
    assert result == "user=asd; Path=/"
    assert result2 == "; Max-Age=0"



# Generated at 2022-06-12 08:39:10.753520
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    print(cookie_jar)
    print(headers)
    cookie_jar["key2"] = "value2"
    print(cookie_jar)
    print(headers)
    del cookie_jar["key1"]
    print(cookie_jar)
    print(headers)
    del cookie_jar["key2"]
    print(cookie_jar)
    print(headers)


# Generated at 2022-06-12 08:39:34.878874
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    jar = CookieJar(headers)
    jar['my-cookie'] = "my_value"
    del jar['my-cookie']
    assert headers.getall('Set-Cookie') == []


# Generated at 2022-06-12 08:39:42.434526
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    c["path"] = "/"
    c["domain"] = "example.com"
    c["max-age"] = "12345"
    c["expires"] = datetime(2009, 2, 14, 11, 42, 45)
    c["httponly"] = "True"
    c["secure"] = "False"

    result = c.__str__()
    assert result == 'key=value; Path=/; Domain=example.com; Max-Age=12345; Expires=Sat, 14-Feb-2009 11:42:45 GMT; HttpOnly; Secure'
    c["httponly"] = False

    result = c.__str__()

# Generated at 2022-06-12 08:39:51.490253
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert str(cookie) == 'key=value'

    cookie['path'] = '/'
    cookie['comment'] = 'Comment'
    cookie['domain'] = 'Domain'
    cookie['max-age'] = '123'
    cookie['secure'] = 'Secure'

    expected = 'key=value; Path=/; Comment=Comment; Domain=Domain; Max-Age=123; Secure'
    assert str(cookie) == expected

    cookie = Cookie('key', 'value')
    cookie['expires'] = datetime.fromtimestamp(1576547203)
    assert str(cookie) ==  'key=value; expires=Sat, 08-Feb-2020 01:20:03 GMT'



# Generated at 2022-06-12 08:39:59.794662
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test basic Cookie header formatting logic
    """
    cookie = Cookie("name", "value")
    assert cookie.__str__() == "name=value"
    cookie["path"] = "/"
    assert cookie.__str__() == "name=value; Path=/"
    cookie["domain"] = "example.com"
    assert (
        cookie.__str__()
        == "name=value; Path=/; Domain=example.com"
    )
    cookie["max-age"] = 3600
    assert (
        cookie.__str__()
        == "name=value; Path=/; Domain=example.com; Max-Age=3600"
    )
    cookie["expires"] = datetime(
        year=2020, month=6, day=1, hour=12, minute=0, second=0
    )

# Generated at 2022-06-12 08:40:09.389921
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Testing the following cases:
    # __delitem__(key)
    #     A cookie key is passed into __delitem__ and it deletes it from the
    #     cookieJar correctly
    # __delitem__(key)
    #     A key that does not exist is passed into __delitem__ and it sets
    #     the cookie to an empty string and then it sets the max-age
    #     property to 0. This deletes the cookie from the client's browser

    # Defining the header and creating the cookieJar
    header = {"Set-Cookie": ["key1=value1"]}
    headers = MultiHeader(header)
    cookieJar = CookieJar(headers)

    # Testing case 1:
    assert len(cookieJar.cookie_headers) == 1
    assert "key1" in cookieJar.cookie_headers

# Generated at 2022-06-12 08:40:14.376872
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie(key='one', value='two')
    c['path'] = '/'
    c['expires'] = datetime.now()
    c['domain'] = 'localhost'
    c['max-age'] = 50
    c['httponly'] = True
    c['comment'] = 'this is a comment'
    assert c.encode('utf-8') == str(c).encode('utf-8')

# Generated at 2022-06-12 08:40:16.957840
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    jar = CookieJar(headers)
    jar["name"] = "sky"
    del jar["name"]
    assert jar.headers.getlist("Set-Cookie") == ["name=; Max-Age=0; Path=/"]


# Generated at 2022-06-12 08:40:27.017182
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers.add("Set-Cookie", "my_cookie=123; Expires=Fri, 10-Aug-2028 02:47:11 GMT; Max-Age=315360000; Path=/; HttpOnly; SameSite=Strict")
    headers.add("Set-Cookie", "my_cookie2=123; Expires=Fri, 10-Aug-2028 02:47:11 GMT; Max-Age=315360000; Path=/; HttpOnly; SameSite=Strict")
    cookies = CookieJar(headers)

    del cookies["my_cookie"]
    assert "my_cookie2=123"  in cookies.headers.get_all("Set-Cookie")
    assert "my_cookie" not in cookies.headers.get_all("Set-Cookie")

# Generated at 2022-06-12 08:40:34.798795
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo','bar')
    assert str(cookie) == 'foo=bar'
    cookie['path'] = '/'
    assert str(cookie) == 'foo=bar; Path=/'
    cookie['httponly'] = True
    assert str(cookie) == 'foo=bar; Path=/; HttpOnly'
    assert str(Cookie('foo', 'bar baz')) == 'foo="bar baz"'
    assert str(Cookie('foo', 'bar baz')) == 'foo="bar baz"'
    assert str(Cookie('foo', 'bar baz')) == 'foo="bar baz"'


# Generated at 2022-06-12 08:40:41.845028
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeadersDict({"Set-Cookie": "session_token=123"})
    cookie_jar = CookieJar(headers)
    cookie_jar["new_key"] = "new_value"
    assert cookie_jar["new_key"]["Path"] == "/"
    assert headers["Set-Cookie"][0] == "session_token=123"
    assert len(headers["Set-Cookie"]) == 2
    assert headers["Set-Cookie"][1] == "new_key=new_value; Path=/"
