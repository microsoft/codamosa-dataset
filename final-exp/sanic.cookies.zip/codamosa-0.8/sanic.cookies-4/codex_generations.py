

# Generated at 2022-06-12 08:31:10.181466
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    max_age_int = 100
    test_Cookie_with_max_age_int = Cookie("foo", "bar")
    test_Cookie_with_max_age_int["max-age"] = max_age_int
    assert test_Cookie_with_max_age_int.__str__() == "foo=bar; Max-Age=100"

    max_age_float = 5.5
    test_Cookie_with_max_age_float = Cookie("foo", "bar")
    test_Cookie_with_max_age_float["max-age"] = max_age_float
    assert test_Cookie_with_max_age_float.__str__() == "foo=bar; Max-Age=5.5"

    expires = datetime(2009, 2, 14, 15, 4, 47)


# Generated at 2022-06-12 08:31:19.679716
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # If this cookie doesn't exist, add it to the header keys
    if True:
        cookie = Cookie("name", "value")
        cookie["path"] = "/"
        cookie.value = "value"
        cookie_cookie = ["name=value", "Path=/"]
        cookie_cookie = ["name=value", "Path=/"]
        assert isinstance(cookie_cookie, list)
        assert cookie_cookie == ["name=value", "Path=/"]
        assert isinstance(cookie_cookie, list)
        assert cookie_cookie == ["name=value", "Path=/"]
        return
    # If this cookie doesn't exist, add it to the header keys
    if True:
        cookie = Cookie("name", "value")
        cookie["path"] = "/"
        cookie.value = "value"

# Generated at 2022-06-12 08:31:25.949186
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")

    assert str(cookie) == "foo=bar"

    cookie["path"] = "/"
    cookie["Expires"] = "Wed, 31-Dec-97 23:59:59 GMT"
    cookie["secure"] = True
    cookie["HttpOnly"] = True

    assert (
        str(cookie)
        == "foo=bar; Path=/; Expires=Wed, 31-Dec-97 23:59:59 GMT; Secure; HttpOnly"
    )

# Generated at 2022-06-12 08:31:34.126516
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("name", "value")
    assert c["path"] == "/"
    with pytest.raises(KeyError):
        c["whatever"] = "some value"

    with pytest.raises(ValueError):
        c["max-age"] = "not_an_int"
    with pytest.raises(TypeError):
        c["expires"] = "not_a_datetime"
    with pytest.raises(ValueError):
        c["max-age"] = -1

    with pytest.raises(KeyError):
        c["path"] = "not_an"
    c["expires"] = datetime.utcnow()
    c["max-age"] = 10
    c["comment"] = "comment"
    c["domain"] = "domain"
    c["secure"] = True

# Generated at 2022-06-12 08:31:41.660683
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar["test"] = "test_cookie"
    assert("test" in cookie_jar)
    assert("test" in cookie_jar.headers["Set-Cookie"])
    del cookie_jar["test"]
    assert("test" not in cookie_jar)
    assert("test" not in cookie_jar.headers["Set-Cookie"])


# Generated at 2022-06-12 08:31:48.809664
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('foo', 'bar')
    s = str(c)
    assert s == 'foo=bar'
    c['max-age'] = 12345
    s = str(c)
    assert s == 'foo=bar; Max-Age=12345'
    c['expires'] = datetime(2021, 10, 4, 11, 3, 0, 0)
    s = str(c)
    assert s == 'foo=bar; Max-Age=12345; Expires=Mon, 04-Oct-2021 11:03:00 GMT'
    c['secure'] = True
    s = str(c)
    assert s == 'foo=bar; Max-Age=12345; Expires=Mon, 04-Oct-2021 11:03:00 GMT; Secure'
    c['httponly'] = True

# Generated at 2022-06-12 08:31:56.564436
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('foo', 'bar')
    cookie['max-age'] = max_age = 10
    cookie['expires'] = expires = datetime.now()
    cookie['domain'] = 'baz.com'
    cookie['httponly'] = True
    cookie['secure'] = True
    cookie['samesite'] = 'None'
    assert cookie['max-age'] == max_age
    assert cookie['expires'] == expires
    assert cookie['domain'] == 'baz.com'
    assert cookie['httponly']
    assert cookie['secure']
    assert cookie['samesite'] == 'None'



# Generated at 2022-06-12 08:32:06.797037
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert str(c) == "foo=bar"

    c = Cookie("foo", "bar=baz")
    assert str(c) == "foo=\"bar=baz\""

    c["comment"] = "this is my comment"
    c["domain"] = "test.com"
    c["secure"] = True
    c["httponly"] = True
    c["expires"] = datetime(2018, 1, 1, 12)

    assert str(c) == (
        "foo=bar=baz; Comment=this is my comment; Domain=test.com; "
        "HttpOnly; Secure; expires=Mon, 01-Jan-2018 12:00:00 GMT"
    )


# Generated at 2022-06-12 08:32:09.245375
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["test"] = "test"
    assert jar["test"].value == "test"



# Generated at 2022-06-12 08:32:16.490305
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
  cookie = Cookie('key', 'value')
  assert str(cookie) == 'key=value'

  cookie = Cookie('key', 'value; path=/')
  assert str(cookie) == 'key=value; path=/'

  cookie = Cookie('key', 'value; path=/; HttpOnly; SameSite=Strict')
  assert str(cookie) == 'key=value; path=/; HttpOnly; SameSite=Strict'


# Generated at 2022-06-12 08:32:24.511700
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    request = Request(headers=[])
    request.cookies = CookieJar(request.headers)
    request.cookies["my_key"] = "my_value"
    assert request.cookies["my_key"] == "my_value"



# Generated at 2022-06-12 08:32:29.385829
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["example_key"] = "example_value"
    assert headers.get("Set-Cookie") == "example_key=example_value"
    del jar["example_key"]
    assert headers.get("Set-Cookie") != "example_key=example_value"
    assert headers.get("Set-Cookie") == "example_key=; Max-Age=0"


# Generated at 2022-06-12 08:32:35.921756
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Test __setitem__ of Cookie class
    """
    cookie = Cookie("key","value")
    # Test cases
    # Should raise a KeyError
    try:
        cookie["expires"] = "2015-04-24"
    except KeyError:
        pass
    # Should NOT raise a KeyError
    cookie["expire"] = "2015-04-24"
    # Should raise a ValueError
    try:
        cookie["max-age"] = "asdf"
    except ValueError:
        pass
    # Should set the cookie
    cookie["max-age"] = "1234"
    assert cookie["max-age"] == "1234"
    assert cookie["expire"] == "2015-04-24"
    # Should raise a TypeError

# Generated at 2022-06-12 08:32:43.447684
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    cookiejar = CookieJar(headers)
    cookiejar['test_key'] = 'test_value'
    assert cookiejar['test_key'] == 'test_value'
    assert headers[''] == 'test_key=test_value'
    cookiejar['test_key'] = 'test_value2'
    assert cookiejar['test_key'] == 'test_value2'
    assert headers[''] == 'test_key=test_value2'


# Generated at 2022-06-12 08:32:54.143231
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["max-age"] = 100
    cookie["expires"] = datetime.now()
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["path"] = "/path"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"

    with pytest.raises(KeyError):
        cookie["unknown"] = "unknown"
    with pytest.raises(ValueError):
        cookie["max-age"] = "not_int"
    with pytest.raises(TypeError):
        cookie["expires"] = "not_datetime"
    with pytest.raises(ValueError):
        cookie["max-age"] = -1



# Generated at 2022-06-12 08:33:03.245092
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="key", value="value")
    cookie["path"] = "/"
    cookie["httponly"] = True
    assert str(cookie) == "key=value; Path=/; HttpOnly"
    cookie["max-age"] = 3600
    assert str(cookie) == "key=value; Max-Age=3600; Path=/; HttpOnly"
    cookie["expires"] = "Sat, 06 Oct 2018 00:00:00 GMT"
    assert str(cookie) == "key=value; Expires=Sat, 06 Oct 2018 00:00:00 GMT; Max-Age=3600; Path=/; HttpOnly"



# Generated at 2022-06-12 08:33:10.191539
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    [c, h] = create_cookie_headers()
    c['foo']="b+a+r"
    assert str(c['foo']) == "foo=b%2Ba%2Bar"
    assert c['foo'].encode('utf-8') == b"foo=b%2Ba%2Bar"
    assert c['foo'].encode('ascii') == b"foo=b+a+r"


# Generated at 2022-06-12 08:33:13.837996
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    h = MultiHeader()
    cs = CookieJar(h)
    cs['test'] = 'test'
    cs['test2'] = 'test2'

    assert len(h['Set-Cookie']) == 2


# Generated at 2022-06-12 08:33:25.578214
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="test-key", value="test-value")
    assert str(cookie) == "test-key=test-value"

    cookie["max-age"] = 99999999
    assert str(cookie) == "test-key=test-value; Max-Age=99999999"

    cookie["expires"] = datetime(2021, 3, 8, 15, 11, 5)
    assert str(cookie) == "test-key=test-value; Max-Age=99999999; expires=Tue, 08-Mar-2021 15:11:05 GMT"

    cookie["domain"] = "test.domain"
    assert str(cookie) == "test-key=test-value; Max-Age=99999999; expires=Tue, 08-Mar-2021 15:11:05 GMT; Domain=test.domain"


# Generated at 2022-06-12 08:33:33.338125
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print("CookieJar:{}".format(CookieJar.__delitem__),end=',')
    cookie_jar = CookieJar(Mock())
    # Test case 1: a cookie is added, and then deleted
    cookie_jar["test"] = "test_value"
    assert cookie_jar["test"] == "test_value"
    del cookie_jar["test"]
    assert not "test" in cookie_jar
    # Test case 2: a cookie is not added, and then deleted
    del cookie_jar["test"]
    assert not "test" in cookie_jar


# Generated at 2022-06-12 08:33:42.043372
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar()
    jar["name"] = "value"
    del jar["name"]
    assert jar["name"] == ""
    assert not jar._raw_cookies
    jar["name"] = "value"
    del jar["name"]
    assert not jar._raw_cookies



# Generated at 2022-06-12 08:33:45.825994
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar(Headers())
    assert "name" not in jar.cookie_headers
    jar["name"] = "value"
    assert jar["name"] == "value"
    assert "name" in jar.cookie_headers
    del jar["name"]
    assert "name" not in jar.cookie_headers


# Generated at 2022-06-12 08:33:48.728094
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()

    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert headers.get("Set-Cookie") == "key=value; Path=/"

    del cookie_jar["key"]
    assert len(headers) == 0


# Generated at 2022-06-12 08:33:55.719439
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key1', 'value1')
    assert str(cookie) == 'key1=value1'

    cookie_with_all_fields = Cookie('key2', 'value2')
    cookie_with_all_fields['expires'] = datetime.now()
    cookie_with_all_fields['path'] = '/'
    cookie_with_all_fields['comment'] = 'test comment'
    cookie_with_all_fields['domain'] = 'localhost'
    cookie_with_all_fields['max-age'] = 10
    cookie_with_all_fields['secure'] = True
    cookie_with_all_fields['httponly'] = True
    cookie_with_all_fields['version'] = '1.1'
    cookie_with_all_fields['samesite'] = 'lax'
    assert str

# Generated at 2022-06-12 08:34:05.398433
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    C = Cookie(
        "test",
        "value",
        {"max-age": 12345},
        {"expires": datetime(2017,12,31)},
        {"domain": "example.com"},
        {"path": "/"},
        {"secure": False},
        {"version": 1},
        {"samesite": "lax"},
    )

    assert C.__str__() == "test=value; Max-Age=12345; Expires=Sun, 31-Dec-2017 00:00:00 GMT; Domain=example.com; Path=/; Version=1; SameSite=lax"

# Generated at 2022-06-12 08:34:15.730405
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("key", "value")
    c["expires"] = "expires"
    c["path"] = "path"
    c["comment"] = "comment"
    c["domain"] = "domain"
    c["max-age"] = "max-age"
    c["secure"] = "secure"
    c["httponly"] = "httponly"
    c["version"] = "version"
    c["samesite"] = "samesite"
    c["non_standard"] = "non_standard"
    # check for expected exception if key is not valid
    with pytest.raises(KeyError) as exception_info:
        c["non_standard"] = "non_standard"
    assert exception_info.value.args[0] == "Unknown cookie property"
    # check for expected exception if key is not

# Generated at 2022-06-12 08:34:25.751142
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 1
    assert(cookie["max-age"] == 1)
    cookie["expires"] = datetime.now()
    cookie["comment"] = "Any comment"
    cookie["domain"] = "domain.com"
    cookie["max-age"] = 2
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "strict"
    cookie["path"] = "/"

# Generated at 2022-06-12 08:34:34.067059
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('foo', 'bar')
    assert str(c).startswith('foo=bar')
    c = Cookie('foo', 'bar')
    c['expires'] = datetime.utcnow()
    assert str(c).startswith('foo=bar; Expires=')
    c = Cookie('foo', 'bar')
    c['httponly'] = True
    assert str(c).startswith('foo=bar; HttpOnly')
    c = Cookie('foo', 'bar')
    c['max-age'] = 42
    assert str(c).startswith('foo=bar; Max-Age=42')
    c = Cookie('foo', 'bar')
    c['path'] = '/'
    assert str(c).startswith('foo=bar; Path=/')

# Generated at 2022-06-12 08:34:43.784116
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaders({"Set-Cookie": ["A=B; Path=/", "B=123; Path=/"]})
    cookie_jar = CookieJar(headers)
    assert headers == {"Set-Cookie": ["A=B; Path=/", "B=123; Path=/"]}
    assert cookie_jar["B"].value == "123"
    assert cookie_jar.cookie_headers == {"A": "Set-Cookie", "B": "Set-Cookie"}

    del cookie_jar["B"]

    assert headers == {"Set-Cookie": ["A=B; Path=/", "B=; Max-Age=0; Path=/"]}
    assert cookie_jar == {"A": Cookie("A", "B")}
    assert cookie_jar.cookie_headers == {"A": "Set-Cookie"}


# Generated at 2022-06-12 08:34:48.612402
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {"Set-Cookie": "key=value; Max-Age=60"}
    test_jar = CookieJar(headers)
    test_jar.__delitem__("key")
    expected_output = {}
    assert test_jar.headers == expected_output



# Generated at 2022-06-12 08:34:54.659249
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    #test
    pass
# ------------------------------------------------------------ #
#  CookieJar
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:35:04.800221
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "qux"
    assert len(headers[cookie_jar.header_key]) == 2
    assert cookie_jar["foo"].value == "bar"
    assert cookie_jar["baz"].value == "qux"
    cookie_jar["baz"] = "corge"
    assert len(headers[cookie_jar.header_key]) == 2
    assert cookie_jar["baz"].value == "corge"
    del cookie_jar["foo"] 
    assert len(headers[cookie_jar.header_key]) == 1
    assert cookie_jar.get("foo") == None



# Generated at 2022-06-12 08:35:06.923063
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = headers.Headers({"Content-Type": "application/json"})
    assert headers["Content-Type"] == "application/json"

# Generated at 2022-06-12 08:35:17.277799
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('key', 'value')
    assert cookie['path'] == '/'

    # Add a key that is not in _keys
    with pytest.raises(KeyError):
        cookie['key2'] = 'value2'
    assert cookie.get('key2') is None

    # Add a key that is in _keys
    cookie['path'] = '/test_Cookie'
    assert cookie['path'] == '/test_Cookie'

    # Add a key that is in _flags
    cookie['secure'] = True
    assert cookie.get('secure') is True

    # Add a key that is in _keys, but lower case
    cookie['expires'] = datetime.now()
    assert cookie['expires'] != ""


# Generated at 2022-06-12 08:35:24.582792
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie("test", "value")
    ck["path"] = "/"
    ck["max-age"] = 0
    ck["expires"] = datetime.now()
    ck["domain"] = "example.com"
    ck["secure"] = True
    ck["httponly"] = True
    ck["version"] = 1

    assert str(ck) == (
        "test=value; Path=/; Max-Age=0; "
        "expires=%s; Domain=example.com; Secure; HttpOnly"
    ) % ck["expires"].strftime("%a, %d-%b-%Y %T GMT")

# Generated at 2022-06-12 08:35:33.412725
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test_cookie", "test_value")
    assert str(c) == "test_cookie=test_value"
    c["path"] = "/test_path"
    assert str(c) == "test_cookie=test_value; Path=/test_path"
    c["secure"] = True
    assert str(c) == "test_cookie=test_value; Path=/test_path; Secure"
    c["httponly"] = True
    assert str(c) == "test_cookie=test_value; Path=/test_path; Secure; HttpOnly"
    c["max-age"] = 60
    assert str(c) == "test_cookie=test_value; Path=/test_path; Secure; HttpOnly; Max-Age=60"
    c["domain"] = "test_domain"

# Generated at 2022-06-12 08:35:41.053205
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test the string serialization of Cookie class to the one of
    SimpleCookie
    """
    #
    # Test the output of Cookie class matches the output
    # of SimpleCookie
    #
    # Reference:
    # SimpleCookie is taken from SimpleCookie class of Morsel object
    # in http.cookies
    #
    from http.cookies import SimpleCookie
    sc = SimpleCookie()
    sc["chocolate"] = "chip"
    sc["chocolate"]["expires"] = "Wed, 01-Jan-2020 00:00:00 GMT"
    sc["chocolate"]["max-age"] = 10
    s = str(sc["chocolate"])

# Generated at 2022-06-12 08:35:44.411372
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("Testing Cookie.__setitem__...")
    cookie = Cookie("test_key", "test_value")
    cookie.__setitem__("test_key", "test_value")
    assert cookie["test_key"] == "test_value"
    print("Test passed")


# Generated at 2022-06-12 08:35:47.525611
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["test"] = "test_value"
    assert headers == {"Set-Cookie": ["test=test_value; Path=/"]}



# Generated at 2022-06-12 08:35:56.889300
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test to check the ValueError exception is raised when the max-age property is set to a non-integer value
    result = False
    try:
        cookie = Cookie("key", "value")
        cookie["max-age"] = "value"
    except ValueError:
        result = True
    assert result

    # Test to check the TypeError exception is raised when the expires property is set to a non-datetime value
    result = False
    try:
        cookie = Cookie("key", "value")
        cookie["expires"] = "value"
    except TypeError:
        result = True
    assert result

    # Test to check the KeyError exception is raised when a property which does not exist is set
    result = False

# Generated at 2022-06-12 08:36:06.686292
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = None
    cookie["path"] = "/"
    cookie["comment"] = "hello"
    cookie["domain"] = "test"
    cookie["version"] = 0


test_Cookie___setitem__()

# Generated at 2022-06-12 08:36:15.976012
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_name = "name"
    cookie_value = "value"
    cookie_path = "/path"
    cookie_domain = "domain"
    cookie_comment = "comment"
    cookie_max_age = "100"
    cookie_secure = False
    cookie_httponly = False
    cookie_version = 0

    # Tests with max-age and expires
    dt = datetime.utcnow()
    cookie = Cookie(cookie_name, cookie_value)
    cookie["path"] = cookie_path
    cookie["domain"] = cookie_domain
    cookie["comment"] = cookie_comment
    cookie["max-age"] = cookie_max_age
    cookie["expires"] = dt
    cookie["secure"] = cookie_secure
    cookie["httponly"] = cookie_httponly
    cookie["version"] = cookie_version

# Generated at 2022-06-12 08:36:24.684932
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import http
    from datetime import datetime
    from typing import Dict

    cookie_jar = CookieJar(http.MultiHeader())
    cookie_jar["name"] = "ham"
    assert cookie_jar["name"] == "ham"
    assert cookie_jar.cookie_headers.get("name") == "Set-Cookie"
    assert cookie_jar.headers.getall("Set-Cookie")[0] == "name=ham; Path=/; Max-Age=0"
    cookie_jar["name"] = "turkey"
    assert cookie_jar["name"] == "turkey"
    assert cookie_jar.headers.getall("Set-Cookie")[0] == "name=turkey; Path=/; Max-Age=0"
    cookie_jar["type"] = "lunch"
    assert cookie_jar["type"]

# Generated at 2022-06-12 08:36:36.826971
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {'Content-Type': 'text/html'}
    header = CookieJar(headers)
    header['test1'] = ""
    header['test2'] = ""
    header['test3'] = ""
    header['test1']['max-age'] = 100
    header['test2']['httponly'] = False
    header['test3']['httponly'] = True
    assert headers['Set-Cookie'] == \
        'test1=; Max-Age=100; Path=/; test2=; Path=/; test3=; Path=/; HttpOnly'
    header['test1']['path'] = '/test'
    header['test2']['secure'] = True
    header['test3']['secure'] = True
    header['test4'] = 'text4'

# Generated at 2022-06-12 08:36:46.264069
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    # Case 1: remove an item that is not in the cookiejar
    try:
        cookiejar['hello'] = 'Boop'
        del cookiejar['hello']
        cookiejar['world'] = 'Earth'
        del cookiejar['world']
    except:
        pass
    else:
        assert False
    # Case 2: remove an item that is in the cookiejar
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    cookiejar['hello'] = 'Beep'
    del cookiejar['hello']
    # Case 3: remove an item that is currently empty
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    cookiejar['hello'] = 'Boop'
    cookiejar['hello'] = ''

# Generated at 2022-06-12 08:36:57.077956
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["foo"] = "bar"
    cookies["bar"] = "foo"
    cookies["baz"] = "faz"
    assert "foo" in cookies
    assert "bar" in cookies
    cookies["foo"] = "bar"
    cookies["bar"] = "foo"
    cookies.__delitem__("foo")
    assert "foo" not in cookies
    assert "bar" in cookies
    cookies["foo"] = "bar"
    cookies["bar"] = "foo"
    cookies["baz"] = "faz"
    cookies["foo"] = ""
    cookies.__delitem__("foo")
    assert "foo" not in cookies
    assert "bar" in cookies



# Generated at 2022-06-12 08:37:03.032321
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({})
    cookie_jar["foo"] = "bar"
    assert not cookie_jar.cookie_headers.get("foo")
    assert cookie_jar["foo"].value == "bar"

    cookie_jar["foo"] = "baz"
    assert cookie_jar["foo"].value == "baz"
    assert cookie_jar.cookie_headers["foo"] == "Set-Cookie"


# Generated at 2022-06-12 08:37:07.668555
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie = CookieJar(headers)

    cookie["user_id"] = "1"
    cookie["username"] = "John Doe"
    del cookie["user_id"]

    assert cookie["username"].value == "John Doe"

    with pytest.raises(KeyError):
        cookie["user_id"]

# Generated at 2022-06-12 08:37:16.648344
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie = Cookie("test", "test")
    cookie["path"] = "/"
    headers.add("Set-Cookie", cookie)
    cookie2 = Cookie("test2", "test2")
    cookie2["path"] = "/"
    headers.add("Set-Cookie", cookie)
    cookiejar = CookieJar(headers)
    assert 'test' in cookiejar
    assert 'test2' in cookiejar
    assert 'Set-Cookie' in headers
    del cookiejar['test2']
    assert 'test2' not in cookiejar
    assert 'Set-Cookie' not in headers


# Generated at 2022-06-12 08:37:26.205119
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('test', 'password')
    cookie['max-age'] = 0
    cookie['secure'] = False
    cookie['httponly'] = False
    cookie['comment'] = "test_comment"
    cookie['domain'] = "test_domain"
    cookie['path'] = "test_path"
    cookie['version'] = "test_version"
    cookie['samesite'] = "test_samesite"
    encoding = 'utf-8'
    assert cookie.encode(encoding) == 'test=password; Max-Age=0; comment=test_comment; domain=test_domain; path=test_path; version=test_version; SameSite=test_samesite'

# Generated at 2022-06-12 08:37:42.626106
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_Cookie = Cookie("test", "value")
    assert str(test_Cookie) == "test=value"
    test_Cookie["path"] = "/"
    assert str(test_Cookie) == "test=value; Path=/"
    test_Cookie["domain"] = ".example.com"
    assert str(
        test_Cookie
    ) == "test=value; Path=/; Domain=.example.com"
    test_Cookie["max-age"] = 1800
    assert str(
        test_Cookie
    ) == "test=value; Path=/; Domain=.example.com; Max-Age=1800"
    test_Cookie = Cookie("test", "value")
    assert str(test_Cookie) == "test=value"

# Generated at 2022-06-12 08:37:45.908558
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("cname", "cvalue")
    assert str(cookie) == "cname=cvalue"


# Generated at 2022-06-12 08:37:53.763130
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    with pytest.raises(KeyError) as e_info:
        cookie["foo"] = "bar"
    assert str(e_info.value) == "Unknown cookie property"
    with pytest.raises(ValueError) as e_info:
        cookie["max-age"] = "value"
    assert str(e_info.value) == "Cookie max-age must be an integer"
    with pytest.raises(TypeError) as e_info:
        cookie["expires"] = datetime.now()
    assert str(
        e_info.value
    ) == "Cookie 'expires' property must be a datetime"
    assert "secure" in cookie

# Generated at 2022-06-12 08:38:01.079410
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('name', 'value')
    try:
        cookie['max-age'] = "01234"
    except ValueError:
        raise Exception('Cookie.__setitem__() failed')
    try:
        cookie['expires'] = datetime.now()
    except TypeError:
        raise Exception('Cookie.__setitem__() failed')
    cookie['secure'] = True
    if cookie['secure'] != True:
        raise Exception('Cookie.__setitem__() failed')
    cookie['httponly'] = True
    if cookie['httponly'] != True:
        raise Exception('Cookie.__setitem__() failed')
    try:
        cookie['secure'] = False
    except:
        raise Exception('Cookie.__setitem__() failed')

# Generated at 2022-06-12 08:38:10.132637
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar()

    # Initialize some cookies.
    jar["foo"] = "bar"
    jar["fun"] = "baz"
    jar["fun"]["domain"] = "example.com"
    jar["fun"]["secure"] = True
    jar["other"] = "cookie"
    jar["other"]["domain"] = "example.com"
    jar["other"]["path"] = "/"
    jar["other"]["httponly"] = True

    assert dict(jar.headers) == {
        "Set-Cookie": [
            "foo=bar",
            "fun=baz; Domain=example.com; Secure",
            "other=cookie; Domain=example.com; Path=/; HttpOnly",
        ]
    }

    # Delete a cookie from the jar, and see that the header

# Generated at 2022-06-12 08:38:16.905177
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie("name", "marcus")
    ck["domain"] = "example.com"
    ck["path"] = "/"
    ck["httponly"] = True
    ck["max-age"] = 60
    ck["samesite"] = "lax"
    assert str(ck) == "name=marcus; Path=/; Domain=example.com; Max-Age=60; HttpOnly; SameSite=Lax"



# Generated at 2022-06-12 08:38:26.831548
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_test = Cookie('test_key', 'test_value')
    assert len(cookie_test) == 0
    cookie_test['test_key'] = 'test_value'
    assert len(cookie_test) == 0

    with pytest.raises(KeyError) as error_getitem:
        cookie_test['test_key1'] = '1'
    assert "Cookie name is a reserved word" in str(error_getitem.value)

    with pytest.raises(KeyError) as error_getitem:
        cookie_test['test-key1'] = '1'
    assert "Cookie key contains illegal characters" in str(error_getitem.value)

    with pytest.raises(KeyError) as error_getitem:
        cookie_test['test_key1'] = '1'

# Generated at 2022-06-12 08:38:38.642795
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(name="username", value="John Doe")
    assert "username=John Doe" == str(cookie)
    cookie["path"] = "/"
    cookie["domain"] = "google.com"
    assert (
        "username=John Doe; Path=/; Domain=google.com" == str(cookie)
    )
    cookie["max-age"] = 300
    assert (
        "username=John Doe; Path=/; Domain=google.com; Max-Age=300"
        == str(cookie)
    )
    cookie["expires"] = datetime(year=2030, month=10, day=5, hour=5, minute=5)

# Generated at 2022-06-12 08:38:44.293086
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # When
    ck = Cookie("ck_1", "ck_1_value")
    ck["domain"] = "localhost"
    ck["path"] = "/"
    ck["expires"] = datetime(2019, 12, 25)
    ck["max-age"] = 60
    ck["secure"] = True
    ck["httponly"] = True
    ck["version"] = 1

    # Then
    assert str(ck) == "ck_1=ck_1_value; " \
                      "Domain=localhost; " \
                      "Path=/; " \
                      "Expires=Wed, 25-Dec-2019 00:00:00 GMT; " \
                      "Max-Age=60; " \
                      "Secure; " \
                      "HttpOnly; " \
                      "Version=1"

#

# Generated at 2022-06-12 08:38:54.176069
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
        # Set up a Cookie object for testing
        testCookie = Cookie("Key", "Value")

        # Testing that an exception is raised when attempting to set an item with an illegal key
        raised = False
        try:
                testCookie["%s" % chr(127)] = "foo"
        except KeyError:
                raised = True
        assert raised

        # Testing that an exception is raised when attempting to set an item with a reserved keyword
        raised = False
        try:
                testCookie["expires"] = "foo"
        except KeyError:
                raised = True
        assert raised

        # Testing that a value of False is not actually added to the dictionary
        testCookie["comment"] = False
        assert "comment" not in testCookie

        # Testing an item of the correct type is added to the dictionary for a valid key
        test

# Generated at 2022-06-12 08:39:23.706383
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    expected = "name=value; Path=/; Comment=this is a comment.; Domain=example.com; Max-Age=9999; Secure; HttpOnly; Version=1; SameSite=None"
    c = Cookie("name", "value")
    c["path"] = "/"
    c["comment"] = "this is a comment."
    c["domain"] = "example.com"
    c["max-age"] = 9999
    c["secure"] = True
    c["httponly"] = True
    c["version"] = 1
    c["samesite"] = None
    assert expected == str(c)


# Generated at 2022-06-12 08:39:33.033968
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    cookie.path = '/'

    # standard case
    assert 'name=value; Path=/' == str(cookie)

    # max-age case
    cookie['max-age'] = 60
    assert 'name=value; Path=/; Max-Age=60' == str(cookie)

    # expires case
    import datetime
    expires = datetime.datetime(2021, 1, 1)
    cookie['expires'] = expires
    assert 'name=value; Path=/; Max-Age=60; Expires=Fri, 01-Jan-2021 00:00:00 GMT' == str(cookie)

    # flag case
    cookie.secure = True

# Generated at 2022-06-12 08:39:39.493910
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookies = CookieJar(headers)
    cookies["cookie"] = "chocolate chip"
    cookies["cookie"] = "oatmeal raisin"
    cookies["cookie2"] = "vanilla"
    cookies["cookie2"] = "strawberry"

    assert (
        "Set-Cookie" in headers
        and "Set-Cookie2" in headers
        and "Set-Cookie3" in headers
    )

    # delete cookie values
    del cookies["cookie"]
    assert (
        "Set-Cookie" in headers
        and "Set-Cookie2" in headers
        and "Set-Cookie3" not in headers
    )

    del cookies["cookie2"]
    assert "Set-Cookie" in headers and "Set-Cookie2" not in headers



# Generated at 2022-06-12 08:39:48.203698
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert isinstance(str(cookie), str)
    assert str(cookie) == 'name=value'
    cookie['max-age'] = 10
    assert str(cookie) == 'name=value; Max-Age=10'
    cookie['expires'] = datetime(2017, 1, 1)
    assert str(cookie) == 'name=value; Max-Age=10; Expires=Sun, 01-Jan-2017 00:00:00 GMT'
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Max-Age=10; Expires=Sun, 01-Jan-2017 00:00:00 GMT; Secure'
    cookie['httponly'] = True

# Generated at 2022-06-12 08:39:57.512257
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj["foo"] = "bar"
    assert cj.headers["Set-Cookie"] == "foo=bar; Path=/; HttpOnly"
    del cj["foo"]
    assert cj.headers["Set-Cookie"] == "foo=; Path=/; HttpOnly; Max-Age=0"
    assert len(cj.keys()) == 0
    cj["bar"] = "foo"
    cj["baz"] = "bar"
    assert cj.headers["Set-Cookie"] == \
        "bar=foo; Path=/; HttpOnly; baz=bar; Path=/; HttpOnly"
    del cj["baz"]
    assert cj.headers["Set-Cookie"] == "bar=foo; Path=/; HttpOnly"

# Generated at 2022-06-12 08:40:07.392454
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multidict import CIMultiDict
    from multidict import MultiDictProxy
    cj = CookieJar(CIMultiDict())
    cj["a"] = "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
    cj["b"] = "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb"

# Generated at 2022-06-12 08:40:16.430377
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-12 08:40:19.583393
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {'a': 'b'}
    HTTPHeaders.__setitem__ = MagicMock()
    CookieJar.__setitem__(headers, 'a', 'b')
    HTTPHeaders.__setitem__.assert_called()



# Generated at 2022-06-12 08:40:25.488584
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_value"
    assert "test_cookie=test_value" in headers["Set-Cookie"]
    del cookie_jar["test_cookie"]
    assert "test_cookie=test_value" not in headers["Set-Cookie"]


# Generated at 2022-06-12 08:40:35.043404
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Test deletion of a cookie from a CookieJar with one header
    mock_headers = nectar.helpers.MultiDict()
    mock_headers.add("Set-Cookie", "username=yummycookie")
    cookie_jar = CookieJar(mock_headers)
    assert cookie_jar.headers.getall("Set-Cookie") == [
        "username=yummycookie"
    ]
    assert cookie_jar["username"] == "yummycookie"
    del cookie_jar["username"]
    assert not cookie_jar.headers.getall("Set-Cookie")
    assert cookie_jar.headers.get("Set-Cookie") is None
    del cookie_jar["username"]
    assert not cookie_jar.headers.getall("Set-Cookie")