

# Generated at 2022-06-12 08:31:11.672183
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key"]["max-age"] = 123
    assert len(cookie_jar) == 1
    assert len(headers.values(cookie_jar.header_key)) == 1
    cookie_jar["key"] = "new_value"
    assert len(cookie_jar) == 1
    assert len(headers.values(cookie_jar.header_key)) == 1
    cookie_jar["new_key"] = "new_value"
    assert len(cookie_jar) == 2
    assert len(headers.values(cookie_jar.header_key)) == 2
    del cookie_jar["key"]
    assert len(cookie_jar) == 1

# Generated at 2022-06-12 08:31:20.532904
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import pytest
    from quart.datastructures import Headers, MultiDict

    headers = Headers(MultiDict({}))
    cookie = CookieJar(headers)

    # teardown
    headers.clear()

    # normal case
    assert cookie["test"] == cookie["test"]
    assert cookie["test"] == None
    assert cookie["test"] != 1

    # assertion when key is a reserved word
    with pytest.raises(KeyError):
        cookie["expires"] = "test"
        cookie["path"] = "test"
        cookie["comment"] = "test"
        cookie["domain"] = "test"
        cookie["max-age"] = "test"
        cookie["secure"] = "test"
        cookie["httponly"] = "test"
        cookie["version"] = "test"

# Generated at 2022-06-12 08:31:29.427090
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test 1
    cookie = Cookie("name", "value")
    cookie['expires'] = '2018-01-01'
    assert cookie['expires'] == '2018-01-01'

    # Test 2
    with pytest.raises(KeyError):
        cookie['illegal'] = 'value'

    # Test 3
    with pytest.raises(ValueError):
        cookie['max-age'] = 'illegal'

    # Test 4
    with pytest.raises(TypeError):
        cookie['expires'] = datetime.strptime('2018-01-01', '%Y-%m-%d')


# Generated at 2022-06-12 08:31:33.957088
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    cookie = cookiejar.__setitem__()

    jar["test"] = "value"
    assert jar.header_key in headers.getall()

    cookiejar.__delitem__(jar)
    assert jar.header_key not in headers.getall()

# Generated at 2022-06-12 08:31:45.469930
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from quart.wrappers.request import Request
    from quart.wrappers.response import Response

    headers = []
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_cookie_value"
    # Check if the test_cookie is set in the headers list
    cookie_found = False
    for header in headers:
        if header[0] == "Set-Cookie" and header[1] == 'test_cookie="test_cookie_value"; Path=/':
            cookie_found = True
    if cookie_found:
        print("Test __setitem__ of CookieJar Class: PASS")
    else:
        print("Test __setitem__ of CookieJar Class: FAIL")


# Generated at 2022-06-12 08:31:55.112311
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    ## Uncomment the following line to debug this function
    # import ipdb; ipdb.set_trace()
    headers = OrderedMultiDict()
    cookie_jar = CookieJar(headers)
    cookie_name = "cookie_name"
    cookie_value = "cookie_value"
    cookie_jar[cookie_name] = cookie_value
    assert headers[cookie_name] == cookie_value
    assert cookie_jar[cookie_name].value == cookie_value
    assert headers["Set-Cookie"] == '"cookie_name=cookie_value"; Path=/'


# Generated at 2022-06-12 08:32:01.727111
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test1"] = "test1"
    cookie_jar["test2"] = "test2"
    del cookie_jar["test"]
    del cookie_jar["test1"]
    del cookie_jar["test2"]
    print("test_CookieJar___delitem__:", headers)


# Generated at 2022-06-12 08:32:08.096787
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
        Scenario: CookieJar should be able to delete a cookie
        Given a cookie named: "cookie" with value "42"
        When the cookie is deleted
        Then the cookie should not be in the jar
    """

    h = {"Content-Type": "application/json"}
    c = CookieJar(MultiHeader(h))
    c["cookie"] = "42"

    assert c["cookie"] == "42"

    del c["cookie"]

    assert c.get("cookie") is None



# Generated at 2022-06-12 08:32:13.422782
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    assert(headers["Set-Cookie"] == "test=test; Path=/;")
    del cookie_jar["test"]
    assert("Set-Cookie" not in headers)


# Generated at 2022-06-12 08:32:20.866201
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Testing cookie_headers does not contain key
    # Input
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    key = 'nothing'
    # Expected
    new_cookie_headers = {}
    new_headers = {'Set-Cookie': ""}
    # Actual
    cookie_jar[key] = ""
    cookie_jar[key]["max-age"] = 0
    del cookie_jar[key]
    # Assert
    assert cookie_jar.cookie_headers == new_cookie_headers
    assert cookie_jar.headers == new_headers


# Generated at 2022-06-12 08:32:31.616715
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    from unittest import TestCase, main
    class TestCookie(TestCase):
        def test_set_non_reserved_key(self):
            c = Cookie("foo", "bar")
            c["a"] = "b"
            c["c"] = "d"
            self.assertEqual(c.get("a"), "b")
            self.assertEqual(c.get("c"), "d")

        def test_set_reserved_key(self):
            c = Cookie("foo", "bar")
            try:
                c["expires"] = "oh no"
            except KeyError:
                pass
            else:
                raise AssertionError("Should raise KeyError when setting reserved key")

            try:
                c["expires"] = False
            except KeyError:
                pass

# Generated at 2022-06-12 08:32:33.958920
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    expected_string = "foo=bar"
    assert str(cookie) == expected_string

# Generated at 2022-06-12 08:32:44.500944
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test that cookies are properly formatted.
    import unittest

    class CookieTest(unittest.TestCase):
        def test_get_headers(self):
            c = Cookie("test", "value")
            c["path"] = "/"
            c["expires"] = datetime(2017, 1, 1, 0, 0, 0)
            c["max-age"] = "3600"
            c["secure"] = True
            c["httponly"] = True
            c["version"] = 1
            c["samesite"] = "lax"

# Generated at 2022-06-12 08:32:55.548845
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    delitem = '__delitem__'

    assert hasattr(CookieJar, delitem), \
        f'Expected instance of class `CookieJar` to have a method named `{delitem}`, but there was none.'

    assert callable(getattr(CookieJar, delitem)), \
        f'Method `{delitem}` should be callable, but it wasn\'t.'

    current_dir, _ = os.path.split(__file__)
    test_dir = os.path.join(current_dir, 'examples')
    final_dir = os.path.join(test_dir, 'delcookie')
    os.makedirs(final_dir, exist_ok=True)
    test_file = os.path.join(final_dir, 'delcookie.html')

# Generated at 2022-06-12 08:32:57.767069
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import doctest
    from .cookies import Cookie
    doctest.run_docstring_examples(Cookie.__setitem__, globals(), verbose=False)

# Generated at 2022-06-12 08:32:59.441992
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["hello"] = "world"
    del cookie_jar["hello"]
    assert headers[cookie_jar.header_key] == []


# Generated at 2022-06-12 08:33:10.242071
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("a", "value")
    assert(cookie.__str__() == "a=value")
    cookie["expires"] = datetime(2017, 2, 3, 1, 2, 3)
    assert(cookie.__str__() == "a=value; Expires=Fri, 03-Feb-2017 01:02:03 GMT")
    cookie["path"] = "/"
    assert(cookie.__str__() == "a=value; Expires=Fri, 03-Feb-2017 01:02:03 GMT; Path=/")
    cookie["secure"] = True
    assert(cookie.__str__() == "a=value; Expires=Fri, 03-Feb-2017 01:02:03 GMT; Path=/; Secure")
    cookie["httponly"] = True

# Generated at 2022-06-12 08:33:22.201346
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"

    # Cookie with custom path, comment, domain and HttpOnly flag
    c = Cookie("foo", "bar")
    c["path"] = "/"
    c["comment"] = "foo"
    c["domain"] = "test.python.org"
    c["httponly"] = True
    assert c.__str__() == "foo=bar; Path=/; Comment=foo; Domain=test.python.org; HttpOnly"

    # Cookie with max-age
    c = Cookie("foo", "bar")
    c["max-age"] = "6400"
    assert c.__str__() == "foo=bar; Max-Age=6400"

    # Cookie with max-age and expires

# Generated at 2022-06-12 08:33:30.310642
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("session", "123456789")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["expires"] = datetime(2021, 1, 1)
    cookie["comment"] = "some comment"
    cookie["domain"] = "example.com"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "None"
    assert str(cookie) == 'session=123456789; Path=/; Max-Age=0; ' + \
        'expires=Thu, 01-Jan-2021 00:00:00 GMT; Comment=some comment; ' + \
        'Domain=example.com; Secure; HttpOnly; Version=1; SameSite=None'

# Generated at 2022-06-12 08:33:42.429094
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"

    c["httponly"] = True
    assert c.__str__() == "foo=bar; HttpOnly"

    c["secure"] = True
    assert c.__str__() == "foo=bar; HttpOnly; Secure"

    c["path"] = "/"
    assert c.__str__() == "foo=bar; Path=/; HttpOnly; Secure"

    c["domain"] = "localhost"
    assert (
        c.__str__()
        == "foo=bar; Domain=localhost; Path=/; HttpOnly; Secure"
    )

    c["max-age"] = 59

# Generated at 2022-06-12 08:33:55.398353
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('name', 'value')
    # Test none
    c['max-age'] = None
    assert str(c) == 'name=value'
    # Test int
    c['max-age'] = 0
    assert str(c) == 'name=value; Max-Age=0'
    # Test str
    c['max-age'] = '0'
    assert str(c) == 'name=value; Max-Age=0'
    # Test str
    c['max-age'] = 'a'
    assert str(c) == 'name=value; Max-Age=a'
    # Test datetime
    c['expires'] = datetime.now()
    assert str(c) == 'name=value; Max-Age=a; %s' % c['expires']

    c['max-age']

# Generated at 2022-06-12 08:34:07.509157
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("my_cookie", "my_value")

    cookie["expires"] = "Fri, 31-Dec-99 23:59:59 GMT"
    cookie["path"] = "/"
    cookie["comment"] = "ipython"
    cookie["domain"] = ".example.com"
    cookie["max-age"] = "123"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    cookie["samesite"] = "Strict"


# Generated at 2022-06-12 08:34:17.690580
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from .message import Headers
    from .signals import Signal
    from .utils import text_
    from .typedefs import StrOrURL

    headers = Headers(Signal())
    cookies = CookieJar(headers)
    cookies['name1'] = 'value1'
    cookies['name2'] = 'value2'

    assert headers['Set-Cookie'] == []
    assert headers.getall('Set-Cookie') == []

    headers.add('Set-Cookie', 'name3=value3')
    assert headers['Set-Cookie'] == 'name3=value3'
    assert headers.getall('Set-Cookie') == ['name3=value3']

    del cookies['name2']

    cookies['name1'] = 'value1'
    cookies['name1']['Path'] = '/path'
   

# Generated at 2022-06-12 08:34:20.464840
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('test_key', 'test_value')
    assert c.__str__() == 'test_key=test_value'



# Generated at 2022-06-12 08:34:28.451429
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    response_headers = MultiDict()
    cookie_jar = CookieJar(response_headers)
    assert response_headers.getall("Set-Cookie") is None
    cookie_jar["test_key"] = "test_value"
    assert response_headers.getall("Set-Cookie")[0] == "test_key=test_value; path=/"
    assert cookie_jar["test_key"].value == "test_value"
    assert cookie_jar["test_key"]["path"] == "/"


# Generated at 2022-06-12 08:34:36.732372
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {"Header 1": "Value 1", "Header 2": "Value 2"}
    cookie_jar = CookieJar(headers)
    cookie_jar["cookie1"] = "value1"
    cookie_jar["cookie2"] = "value2"

    assert "cookie1" in cookie_jar
    assert "cookie2" in cookie_jar

    cookie_jar["cookie1"]["path"] = "/test"
    cookie_jar["cookie2"]["path"] = "/test2"
    print(cookie_jar)
    assert "cookie1" in cookie_jar
    assert "cookie2" in cookie_jar

    del cookie_jar["cookie1"]
    print(cookie_jar)
    assert "cookie1" not in cookie_jar
    assert "cookie2" in cookie_jar
    assert "Header 1" in headers

# Generated at 2022-06-12 08:34:44.623594
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    val = datetime(year=2010, month=1, day=1)
    cookie = Cookie("name", "value")
    cookie['max-age'] = 3600 #test max-age
    cookie['expires'] = val #test expires
    cookie['path'] = '/test' #test other keys
    cookie['version'] = 1
    cookie['samesite'] = 'Lax'
    cookie['comment'] = "value"
    cookie['secure'] = 1
    cookie['httponly'] = 1
    cookie['domain'] = "example.com"
    print(cookie.encode('utf-8'))


# Generated at 2022-06-12 08:34:55.578945
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print('test_CookieJar___delitem__()')

    headers = CIMultiDict({"Set-Cookie": "name1=1"})
    jar = CookieJar(headers)

    jar["name2"] = "2"
    jar["name3"] = "3"

    del jar["name2"]
    print(jar._cookie_headers)
    assert len(jar._cookie_headers) == 2

    print(headers)
    assert len(headers.items()) == 1
    assert headers["Set-Cookie"] == "name2=2; Path=/"

    del jar["name1"]
    print(jar._cookie_headers)
    assert len(jar._cookie_headers) == 1

    print(headers)
    print('test_CookieJar___delitem__() [DONE]\n')


# Unit

# Generated at 2022-06-12 08:35:02.387350
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({})
    cookie_jar["foo"] = "bar"
    assert ("Set-Cookie", "foo=bar") in cookie_jar.headers.items()
    cookie_jar["baz"] = "fudge"
    assert ("Set-Cookie", "foo=bar") in cookie_jar.headers.items()
    assert ("Set-Cookie", "baz=fudge") in cookie_jar.headers.items()



# Generated at 2022-06-12 08:35:05.705163
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key","value")
    cookie["key"] = "value"
    assert cookie["key"] == "value"
    cookie["expires"] = "value"
    assert cookie["expires"] == "value"
    cookie["max-age"] = "value"
    assert cookie["max-age"] == "value"



# Generated at 2022-06-12 08:35:22.146493
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "test")
    assert c.__str__() == "test=test"
    c["max-age"] = 0
    c["expires"] = datetime(1970, 1, 1, 0, 0, 0)
    assert c.__str__() == "test=test; Max-Age=0; expires=Thu, 01-Jan-1970 00:00:00 GMT"
    c["secure"] = True
    assert c.__str__() == "test=test; Max-Age=0; expires=Thu, 01-Jan-1970 00:00:00 GMT; Secure"
    c["httponly"] = True
    assert c.__str__() == "test=test; Max-Age=0; expires=Thu, 01-Jan-1970 00:00:00 GMT; Secure; HttpOnly"

# Generated at 2022-06-12 08:35:23.365317
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    print(cookie)


# Generated at 2022-06-12 08:35:31.198948
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("cookie_name", "cookie_value")
    cookie["domain"] = "example.com"
    cookie["path"] = "/"
    cookie["expires"] = datetime(2018, 10, 20)
    cookie["max-age"] = "3600"
    cookie["httponly"] = True
    cookie["secure"] = True
    assert cookie["domain"] == "example.com"
    assert cookie["path"] == "/"
    assert cookie["expires"] == datetime(2018, 10, 20)
    assert cookie["max-age"] == "3600"
    assert cookie["httponly"] == True
    assert cookie["secure"] == True


# Generated at 2022-06-12 08:35:33.608912
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie(
        "test_cookie",
        "test_cookie_value",
    )
    assert str(ck) == "test_cookie=test_cookie_value"
    return 0



# Generated at 2022-06-12 08:35:41.162075
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multipipes import Pipe
    from uvicorn.config import Config
    from uvicorn.middleware.proxy_headers import ProxyHeadersMiddleware
    from uvicorn.protocols.http.httptools import HttpToolsProtocol
    from uvicorn.main import get_logger
    from uvicorn.lifespan import Lifespan

    config = Config(proxy_headers=True)

    lifespan = Lifespan(config, get_logger("uvicorn"))

    events = Pipe()
    lifespan.spawn(events.put, "startup")
    lifespan.spawn(events.put, "shutdown")
    lifespan.spawn(events.put, "exit")

    protocol = HttpToolsProtocol(
        config=config, lifespan=lifespan, client_max_size_in_bytes=1024,
    )

# Generated at 2022-06-12 08:35:48.708367
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Unit test for method __str__ of class Cookie"""

# Generated at 2022-06-12 08:35:51.323453
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {'test': 'value'}
    cookie_jar = CookieJar(headers)
    assert header

# Generated at 2022-06-12 08:36:02.778715
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test Cookie's __str__ method with different parameters
    """

    # cookie doesn't have any key
    cookie = Cookie("Cookie","cookieval")
    assert str(cookie) == "Cookie=cookieval"

    cookie["Max-Age"] = "maxval"
    assert str(cookie) == "Cookie=cookieval; Max-Age=maxval"

    cookie["Path"] = "pathval"
    assert str(cookie) == "Cookie=cookieval; Max-Age=maxval; Path=pathval"

    cookie["Domain"] = "domainval"
    assert str(cookie) == "Cookie=cookieval; Max-Age=maxval; Path=pathval; Domain=domainval"

    # cookie has Expires as current date
    cookie["Expires"] = datetime.now()
    assert str(cookie)

# Generated at 2022-06-12 08:36:05.250512
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c=Cookie('name', 'cookie')
    c['expires']=datetime(2019,1,1)
    assert c['expires'] == datetime(2019,1,1)


# Generated at 2022-06-12 08:36:15.182843
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Testing if deletion from CookieJar leads to removal from headers
    h = Headers()
    c1 = Cookie("cookie1", "1")
    c2 = Cookie("cookie2", "2")
    h.add("Set-Cookie", c1)
    h.add("Set-Cookie", c2)

    jar = CookieJar(h)
    jar["cookie2"] = "2"
    assert c2 in h["Set-Cookie"] and jar["cookie2"]

    del jar["cookie2"]
    assert c2 not in h["Set-Cookie"] and "cookie2" not in jar

    # Testing if deletion of cookie with a previously deleted key results in
    # adding cookie to headers
    del c2["max-age"]
    del jar["cookie2"]

# Generated at 2022-06-12 08:36:29.585613
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import unittest
    from StringIO import StringIO

    class CookieStrTestCase(unittest.TestCase):
        def test_Cookie_No_Value(self):
            cookie = Cookie('test', '')
            output = cookie.__str__()
            self.assertEqual(output, 'test=')

        def test_Cookie_With_Value(self):
            cookie = Cookie('test', 'cookie_content')
            output = cookie.__str__()
            self.assertEqual(output, 'test="cookie_content"')

        def test_Cookie_With_Spaces_Value(self):
            cookie = Cookie('test', 'cookie with spaces')
            output = cookie.__str__()
            self.assertEqual(output, 'test="cookie with spaces"')


# Generated at 2022-06-12 08:36:34.073445
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    assert not cookiejar.headers.get("Set-Cookie")
    cookiejar["test"] = "test"
    assert "test=test; Path=/" in headers["Set-Cookie"]


# Generated at 2022-06-12 08:36:45.112717
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Case 1: set max-age in value = false case
    cookie = Cookie("name", "value")
    cookie["max-age"] = False
    assert cookie["max-age"] == 0
    
    # Case 2: set max-age in value = integer case 
    cookie["max-age"] = 20
    assert cookie["max-age"] == 20

    # Case 3: set max-age to string value
    try:
        cookie["max-age"] = "20"
    except ValueError:
        pass

    # Case 4: set expires in value = false case
    cookie["expires"] = False
    assert cookie["expires"] is None

    # Case 5: set expires in value = datetime case 
    dt = datetime(9999,12,31,23,59,59)
    cookie["expires"] = d

# Generated at 2022-06-12 08:36:48.574552
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cj = CookieJar()
    cj["a"] = "b"
    assert cj["a"].value == "b"
    cj["a"].value = "c"
    assert cj["a"].value == "c"


# Generated at 2022-06-12 08:36:58.819836
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader(case_insensitive=True)
    cookie_jar = CookieJar(headers)
    cookie_jar['name0'] = 'value0'
    cookie_jar['name1'] = 'value1'
    cookie_jar['name2'] = 'value2'
    cookie_jar['name3'] = 'value3'
    assert headers.get('Set-Cookie') == 'name0=value0; Path=/'
    assert headers.get('set-cookie') == 'name1=value1; Path=/'
    assert headers.get('SET-COOKIE') == 'name2=value2; Path=/'
    assert headers.get('sEt-cOoKiE') == 'name3=value3; Path=/'

    del cookie_jar['name3']

# Generated at 2022-06-12 08:37:09.059469
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('name', 'value')
    expected = 'name=value'
    assert str(c) == expected
    c['expires'] = datetime(2020, 2, 4, 12, 34, 56, 123456)
    expected = 'name=value; Expires=Tue, 04-Feb-2020 12:34:56 GMT'
    assert str(c) == expected
    c['path'] = '/somewhere'
    expected = 'name=value; Expires=Tue, 04-Feb-2020 12:34:56 GMT; '
    expected += 'Path=/somewhere'
    assert str(c) == expected
    c['comment'] = 'some comment'
    expected = 'name=value; Expires=Tue, 04-Feb-2020 12:34:56 GMT; '

# Generated at 2022-06-12 08:37:18.923668
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    import collections
    test_headers = collections.defaultdict(list)

    test_jar = CookieJar(test_headers)
    
    # Test case when key is in cookie_headers
    test_jar["test1"] = "test1"
    test_jar["test2"] = "test2"
    del test_jar["test1"]
    assert test_jar["test2"] == "test2" and \
           test_jar.cookie_headers["test2"] == "Set-Cookie" and \
           test_headers["Set-Cookie"] == ['test2="test2"; Path=/']

    # Test case when key is not in cookie_headers
    test_jar = CookieJar(test_headers)
    del test_jar["test1"]
    assert test_jar.cookie_headers.get("test1") == None
    


# Generated at 2022-06-12 08:37:24.834781
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Unit test for Cookie.__str__()"""
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["path"] = "/"
    assert str(cookie) == "name=value; Path=/"
    cookie["httponly"] = True
    assert str(cookie) == "name=value; Path=/; HttpOnly"
    cookie["secure"] = True
    assert str(cookie) == "name=value; Path=/; HttpOnly; Secure"
    cookie["expires"] = datetime(2050, 1, 1)
    assert (
        str(cookie)
        == "name=value; Path=/; HttpOnly; Secure; expires=Fri, 01-Jan-2050 00:00:00 GMT"
    )
    cookie["foo"] = "bar"

# Generated at 2022-06-12 08:37:33.831265
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_name = "cookie"
    cookie_value = "chocolate"
    cookie_jar[cookie_name] = cookie_value
    assert len(cookie_jar) == 1
    assert len(headers) == 1
    assert headers["Set-Cookie"] == f"{cookie_name}={cookie_value}"
    del cookie_jar[cookie_name]
    assert len(cookie_jar) == 0
    assert len(headers) == 0


# Generated at 2022-06-12 08:37:41.642216
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("cookie_name", "this is a test")
    assert str(cookie) == "cookie_name=this is a test", "Invalid cookie string"
    cookie["max-age"] = 17
    cookie["path"] = "/"
    cookie["comment"] = "My Test Cookie"
    cookie["domain"] = ".test_server.com"
    cookie["secure"] = False
    cookie["httponly"] = True
    assert str(cookie) == "cookie_name=this is a test; Max-Age=17; Path=/; Comment=My Test Cookie; Domain=.test_server.com; HttpOnly", "Invalid cookie string"


# Generated at 2022-06-12 08:37:53.356700
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c  = Cookie('my_cookie', 'my_value')
    c['max-age'] = 0
    c['path'] = '/'
    assert c.__str__() == 'my_cookie=my_value; Path=/; Max-Age=0'

# Generated at 2022-06-12 08:37:58.581609
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie.set("max-age", 0)
    cookie.set("expires", datetime.now())
    cookie.set("path", "/")
    cookie.set("secure")
    cookie.set("HttpOnly")
    assert cookie.__str__() == "key=value; Max-Age=0; Expires=Mon, 22-Jun-2020 21:24:00 GMT; Path=/; Secure; HttpOnly"

# Generated at 2022-06-12 08:38:08.693703
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Testing Cookie.__str__"""
    cookie = Cookie("name", "value")
    cookie["max-age"] = 5
    cookie["expires"] = datetime(2005, 2, 3, 10, 10, 10)
    cookie["domain"] = "foo.example.com"
    cookie["path"] = "/bar/baz"
    cookie["secure"] = True
    cookie["httponly"] = True

    assert str(cookie) == (
        "name=value; max-age=5; expires=Sun, 03-Feb-2005 10:10:10 GMT; "
        "domain=foo.example.com; Path=/bar/baz; Secure; HttpOnly"
    )


# ------------------------------------------------------------ #
#  HTTP Exceptions
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:38:18.812356
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cj = CookieJar({})
    c = Cookie("name", "value")
    c["expires"] = datetime(2020, 1, 1)
    c["path"] = "/"
    c["secure"] = True
    c["httponly"] = True
    c["max-age"] = 60

    cj["name"] = "value"
    cj["name"]["expires"] = datetime(2020, 1, 1)
    cj["name"]["path"] = "/"
    cj["name"]["secure"] = True
    cj["name"]["httponly"] = True
    cj["name"]["max-age"] = 60
    assert str(cj["name"]) == str(c)

# Generated at 2022-06-12 08:38:23.788280
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from starlette.headers import Headers
    cookies = CookieJar(Headers())
    cookies["test_cookie_1"] = "hello"
    cookies["test_cookie_2"] = "world"
    assert cookies["test_cookie_1"].value == "hello"
    assert cookies["test_cookie_2"].value == "world"
    del cookies["test_cookie_1"]
    assert cookies["test_cookie_1"].value == ""
    assert cookies["test_cookie_2"].value == "world"



# Generated at 2022-06-12 08:38:30.138091
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar(SimpleHeaders())
    cookie = "val"
    cookie_jar["key"] = cookie
    cookie_jar["key"] = cookie
    cookie_jar["key"] = cookie
    assert len(cookie_jar.headers) == 1
    assert cookie_jar["key"].key == "key"
    assert cookie_jar["key"].value == "val"
    assert cookie_jar["key"]["max-age"] == DEFAULT_MAX_AGE


# Generated at 2022-06-12 08:38:36.322288
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test 1
    cookie = Cookie('Alice', 'Bob')
    cookie["path"] = "/"
    print(cookie.__str__())
    assert cookie.__str__() == 'Alice=Bob; Path=/'
    # Test 2
    cookie = Cookie('Alice', 'Bob')
    cookie["domain"] = "foo.com"
    print(cookie.__str__())
    assert cookie.__str__() == 'Alice=Bob; Domain=foo.com'
    # Test 3
    cookie = Cookie('Alice', 'Bob')
    cookie["max-age"] = '1233'
    print(cookie.__str__())
    assert cookie.__str__() == 'Alice=Bob; Max-Age=1233'
    # Test 4
    cookie = Cookie('Alice', 'Bob')

# Generated at 2022-06-12 08:38:38.314634
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["httponly"] = True
    assert str(cookie) == "name=value; Path=/; HttpOnly"



# Generated at 2022-06-12 08:38:43.129483
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_headers = Headers()
    test_jar = CookieJar(test_headers)
    # add a cookie named testcookie
    test_jar["testcookie"] = "testvalue"
    # test if the cookie is added to cookie_headers and headers
    assert test_jar.cookie_headers["testcookie"] == "Set-Cookie"
    assert "Set-Cookie" in test_headers.keys()
    # delete the cookie named testcookie
    del test_jar["testcookie"]
    # test if the cookie is deleted from cookie_headers and headers
    assert test_jar.cookie_headers == {} and "Set-Cookie" not in \
        test_headers.keys()



# Generated at 2022-06-12 08:38:47.438728
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {"name": "rupa"}
    cj = CookieJar(headers)
    cj["test"] = "test"
    assert cj.headers["Set-Cookie"] == "test=test; Path=/; "
test_CookieJar___setitem__()


# Generated at 2022-06-12 08:39:05.339027
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cookie_jar = CookieJar(headers)
    # First, we test __delitem__ when the item does not exist
    cookie_jar["key1"] = "value1"
    assert headers.getlist("Set-Cookie")[0].value == "key1=value1"
    del cookie_jar["key1"]
    assert not headers.get("Set-Cookie")
    # Then, we test __delitem__ when the item does exist
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    assert headers.getlist("Set-Cookie")[0].value == "key1=value1"
    assert headers.getlist("Set-Cookie")[1].value == "key2=value2"
    del cookie_

# Generated at 2022-06-12 08:39:13.294261
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["username"] = "admin"
    cookie_jar["is_admin"] = "True"
    cookie_jar["is_authenticated"] = "True"

    assert len(headers.getall("Set-Cookie")) == 3
    assert cookie_jar.get("username")["value"] == "admin"
    assert len(cookie_jar.keys()) == 3

    del cookie_jar["is_admin"]

    assert len(headers.getall("Set-Cookie")) == 2
    assert cookie_jar.get("is_admin") is None
    assert len(cookie_jar.keys()) == 2

    cookie_jar["username"] = "admin"

    assert cookie_jar.get("username")["value"] == "admin"

# Generated at 2022-06-12 08:39:19.090487
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_name = "test_cookie"
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar[cookie_name] = "test_cookie_value"
    jar[cookie_name]["max-age"] = DEFAULT_MAX_AGE
    assert jar[cookie_name]["max-age"] == DEFAULT_MAX_AGE
    del jar[cookie_name]
    assert "test_cookie=test_cookie_value" not in str(jar)


# Generated at 2022-06-12 08:39:25.655228
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    output = [
        'foo=bar',
        'Path=/',
        'Domain=localhost',
        'Max-Age=0',
        'HttpOnly',
        'SameSite=Strict'
    ]
    cookie = Cookie('foo', 'bar')
    cookie['path'] = '/'
    cookie['domain'] = 'localhost'
    cookie['max-age'] = 0
    cookie['httponly'] = True
    cookie['samesite'] = 'Strict'
    assert str(cookie) == '; '.join(output)

# ------------------------------------------------------------ #
#  Cookie Response
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:39:29.041766
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie = Cookie("foo", "bar")
    headers = MultiHeader("Set-Cookie")
    jar = CookieJar(headers)
    jar["foo"] = cookie
    del jar["foo"]
    assert not headers.get("Set-Cookie", "foo")


# Generated at 2022-06-12 08:39:33.261690
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar({})
    # setting a cookie to test
    cj["foo"] = "bar"
    # making sure the cookie has been correctly set
    assert cj["foo"] == "bar"
    # deleting the cookie and verifying that it has been deleted
    del cj["foo"]
    assert cj.get("foo") is None
    assert "foo" not in cj.keys()


# Generated at 2022-06-12 08:39:37.377706
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_str_expect = 'a=b; Path=/; Version=1; Domain=.example.com; Secure'
    cookie = Cookie('a', 'b')
    cookie['path'] = '/'
    cookie['version'] = '1'
    cookie['domain'] = '.example.com'
    cookie['secure'] = True
    assert str(cookie) == cookie_str_expect


# Generated at 2022-06-12 08:39:44.123023
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Setup
    headers = {}
    headers["set-cookie"] = "foo=bar"
    headers["set-cookie2"] = "foo2=bar2"
    headers["set-cookie2"] = "foo2=bar2"
    
    cookieJar = CookieJar(headers)
    # Test
    cookieJar["test"] = "test"
    # Assert
    assert cookieJar["test"].value == "test"
    assert cookieJar.headers["Set-Cookie"] == "test=test"
    assert cookieJar.headers["Set-Cookie2"] == "foo=bar"
    assert cookieJar.headers["Set-Cookie2"] == "foo2=bar2"
    assert cookieJar.headers["Set-Cookie2"] == "foo2=bar2"

# Generated at 2022-06-12 08:39:53.943594
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    cookie = Cookie("name1", "value1")
    cookie["expires"] = datetime.utcnow()
    assert cookie["expires"] == datetime.utcnow()

    cookie["path"] = "/"
    assert cookie["path"] == "/"

    cookie["comment"] = "test cookie"
    assert cookie["comment"] == "test cookie"

    cookie["domain"] = "localhost"
    assert cookie["domain"] == "localhost"

    cookie["max-age"] = 100
    assert cookie["max-age"] == 100

    cookie["max-age"] = "100"
    assert cookie["max-age"] == 100

    with pytest.raises(ValueError):
        cookie["max-age"] = "100test"

    cookie["secure"] = True
    assert cookie["secure"] == True

    cookie["httponly"]

# Generated at 2022-06-12 08:39:56.214324
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_out = CookieJar({})
    test_out["testkey"] = 4
    del test_out["testkey"]
    assert test_out == {}


# Generated at 2022-06-12 08:40:16.395495
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cj = CookieJar(headers)
    # Test delete of nonexisting key
    cj['key'] = 'value'
    cj['key2'] = 'value2'
    cj['key'].path = '/blub'
    cj['key2']['max-age'] = 25
    del cj['key']
    del cj['key2']
    set_cookie = headers['Set-Cookie'].split('; ')
    assert set_cookie[0] == 'key=value'
    assert set_cookie[1] == 'path=/blub'
    assert set_cookie[2] == 'max-age=25'
    assert set_cookie[3] == 'key2=value2'
    assert set_cookie[4] == 'max-age=0'




# Generated at 2022-06-12 08:40:26.724311
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookies = CookieJar(headers)
    cookies["test"] = "test_value"
    cookies["test2"] = "test_value2"
    assert len(list(cookies.values())) == 2
    del cookies["test"]
    assert len(list(cookies.values())) == 1
    assert headers.getall("Set-Cookie") == ["test2=test_value2; path=/; Max-Age=0"]
    del cookies["test2"]
    assert len(list(cookies.values())) == 0
    assert headers.getall("Set-Cookie") == ["test2=; path=/; Max-Age=0"]

    cookies["test"] = "test_value"
    assert len(list(cookies.values())) == 1

# Generated at 2022-06-12 08:40:30.719987
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaders()
    cookie_jar = CookieJar(headers)
    cookie_jar["username"] = "foo"
    cookie_jar["password"] = "bar"
    assert headers[
        "Set-Cookie"
    ] == "username=foo; Path=/; password=bar; Path=/"

# Generated at 2022-06-12 08:40:35.721060
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multidict import CIMultiDict
    c = CookieJar(CIMultiDict())
    c['name'] = 'x'
    c['age'] = 'y'
    c['sex'] = 'z'
    del c['name']
    assert("x" not in c.values())
    assert("name" not in c.keys())
    assert("age" in c.keys())
    assert("sex" in c.keys())

# Generated at 2022-06-12 08:40:43.581325
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["max-age"] = 100
    cookie["path"] = "/path"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "strict"
    assert str(cookie) == (
        "key=value; "
        "Max-Age=100; "
        "Path=/path; "
        "Secure; "
        "HttpOnly; "
        "SameSite=strict"
    )


# ------------------------------------------------------------ #
#  Expires
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:40:52.430229
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('key', 'value')

    # Test for invalid property setting
    with pytest.raises(KeyError):
        c['invalid'] = 'i'

    # Test for valid property setting
    assert c['max-age'] is None
    c['max-age'] = '10'
    assert c['max-age'] == '10'
    assert c['max-age'] == 10

    # Test for invalid value setting
    with pytest.raises(ValueError):
        c['max-age'] = 'invalid value'

    with pytest.raises(TypeError):
        c['expires'] = '05-10-2020'

    # Test for valid value setting
    assert c['expires'] is None
    c['expires'] = datetime.now()
    assert c['expires'] is not None

# Generated at 2022-06-12 08:41:01.227074
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["a"] = "1"
    jar["b"] = "2"
    jar["c"] = "3"
    jar["d"] = "4"
    print("Jar: ", jar)
    assert headers[jar.header_key][0] == "a=1; Path=/; HttpOnly"
    assert headers[jar.header_key][1] == "b=2; Path=/; HttpOnly"
    assert headers[jar.header_key][2] == "c=3; Path=/; HttpOnly"
    assert headers[jar.header_key][3] == "d=4; Path=/; HttpOnly"

    del jar["d"]