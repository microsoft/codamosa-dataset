

# Generated at 2022-06-12 08:31:10.954409
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookieJar = CookieJar(headers)

    headers.add('Set-Cookie', Cookie('sue', '32'))
    cookies = headers.getlist('Set-Cookie')
    assert len(cookies) == 1

    del cookieJar['sue']
    cookies = headers.getlist('Set-Cookie')
    assert len(cookies) == 0
    assert len(cookieJar) == 0


# Generated at 2022-06-12 08:31:14.564340
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie(None, None)
    cookie["max-age"] = 60 * 60 * 24 * 365 * 2
    assert cookie["max-age"] == 63072000



# Generated at 2022-06-12 08:31:23.196890
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"

    assert(headers.getone("Set-Cookie") == "test=test; Path=/")

    del cookie_jar["test"]

    assert(headers.getone("Set-Cookie") == "test=; Max-Age=0; Path=/")
    assert(not cookie_jar.get("test"))

# Generated at 2022-06-12 08:31:28.030947
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookiejar = CookieJar()
    cookies = {"foo": "bar", "baz": "qux"}
    for k, v in cookies.items():
        cookiejar[k] = v
    for k in cookies:
        assert k in cookiejar
        del cookiejar[k]
        assert k not in cookiejar
        

# Generated at 2022-06-12 08:31:32.982491
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    dc = Cookie("DummyKey", "DummyValue")
    output = "DummyKey=DummyValue; Path=/"
    assert dc.__str__() == output
    dc = Cookie("DummyKey", "DummyValue")
    dc["Path"] = "/"
    dc["Domain"] = "localhost"
    dc["Max-Age"] = 200
    output = "DummyKey=DummyValue; Path=/; Domain=localhost; Max-Age=200"
    assert dc.__str__() == output

# Generated at 2022-06-12 08:31:45.594581
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("Testing Cookie.__str__()")
    cook = Cookie("name", "value")
    cook["httponly"] = True
    cook["secure"] = True
    cook["max-age"] = 60
    cook["expires"] = datetime.strptime("01 Jan 2027", "%d %b %Y")
    cook["path"] = "/"
    cook["domain"] = "domain"
    cook["comment"] = "comment"
    cook["version"] = "version"
    assert (
        str(cook) == 'name=value; HttpOnly; Secure; Max-Age=60; Expires=Thu, 01-Jan-2027 00:00:00 GMT; Path=/; Domain=domain; Comment=comment; Version=version'
    )



# Generated at 2022-06-12 08:31:55.744943
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test_key", "test_value")
    assert str(cookie) == "test_key=test_value"

    cookie = Cookie("test_key", "test_value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.strptime(
        "Sat, 01-Jan-2022 00:00:00 GMT", "%a, %d-%b-%Y %T GMT"
    )
    assert (
        str(cookie) == "test_key=test_value; Path=%2F; Expires=Sat, 01-Jan-2022 00:00:00 GMT"
    )

# Generated at 2022-06-12 08:32:01.038417
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers({"Set-Cookie": "new=new"})
    cookies = CookieJar(headers)

    cookies["old"] = "old"
    cookies["new"] = "new"

    cookies.__delitem__("old")
    cookies.__delitem__("new")

    print(headers)



# Generated at 2022-06-12 08:32:09.860358
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # unit test for setitem
    key = "my_cookie"
    value = "my_value"
    cookie = Cookie(key, value)
    
    # test set path
    cookie["path"] = "/"
    assert cookie["path"] == "/"

    # test set comment
    comment = "cookie comment"
    cookie["comment"] = comment
    assert cookie["comment"] == comment

    # test set domain
    domain = "example.com"
    cookie["domain"] = domain
    assert cookie["domain"] == domain

    # test set max-age
    age = "12345"
    cookie["max-age"] = age
    assert cookie["max-age"] == age

    # test set secure
    secure = "secure"
    cookie["secure"] = secure
    assert cookie["secure"] == secure

    # test set httponly

# Generated at 2022-06-12 08:32:16.173556
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    headers = Headers()
    cookie1 = Cookie('key1', 'value1')
    cookie2 = Cookie('key2', 'value2')
    cookie1["path"] = "/"
    cookie2["path"] = "/"
    cookie1["expires"] = datetime(2020, 1, 1)
    cookie2["expires"] = datetime(2020, 1, 1)
    cookie1["max-age"] = DEFAULT_MAX_AGE
    cookie2["max-age"] = DEFAULT_MAX_AGE
    cookie1["domain"] = "test"
    cookie2["domain"] = "test"
    cookie1["comment"] = "test"
    cookie2["comment"] = "test"
    cookie1["secure"] = True
    cookie2["secure"] = True
    cookie1["httponly"] = True

# Generated at 2022-06-12 08:32:22.121686
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test = CookieJar({"key": ["value"]})
    del test["key"]
    assert not test.headers
    assert not test.cookie_headers
    assert not test


# Generated at 2022-06-12 08:32:27.471630
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_1 = Cookie("cookie_key_1","cookie_value_1")
    cookie_1['max-age'] = 10
    cookie_1['expires'] = datetime.now()
    cookie_1['secure'] = True
    cookie_1['httponly'] = False
    cookie_1['comment'] = "Good Cookie"
    cookie_1['domain'] = "localhost"
    cookie_1['version'] = 1
    print(cookie_1)



# Generated at 2022-06-12 08:32:34.095959
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = werkzeug.datastructures.Headers()
    cookies = CookieJar(headers)
    cookies["key"] = "value"
    assert headers["Set-Cookie"] == "key=value; Path=/; HttpOnly; SameSite=Lax"

    cookies["path"] = "/test"
    assert headers["Set-Cookie"] == "key=value; Path=/test; HttpOnly; SameSite=Lax"

    cookies["secure"] = True
    assert headers["Set-Cookie"] == "key=value; Path=/test; Secure; HttpOnly; SameSite=Lax"

    try:
        cookies["key"] = "value"
        raise AssertionError
    except KeyError:
        pass


# Generated at 2022-06-12 08:32:36.596532
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Call the object's method and check the output string."""
    a = Cookie('key', 'value')
    output = 'key=value'
    assert str(a) == output

# Generated at 2022-06-12 08:32:46.534534
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"
    c.__setitem__("max-age", 10)
    assert c.__str__() == "foo=bar; Max-Age=10"
    c.__setitem__("expires", datetime.utcnow())
    assert c.__str__() == "foo=bar; Max-Age=10; Expires=%s" % (datetime.utcnow().strftime("%a, %d-%b-%Y %T GMT"))
    c.__setitem__("httponly", True)

# Generated at 2022-06-12 08:32:53.194219
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create a fake header object
    h = Header([])
    # Create a new CookieJar
    cookiejar = CookieJar(h)
    # Add a test cookie
    cookiejar["test_cookie"] = "test_value"
    # Delete the cookie
    del cookiejar["test_cookie"]
    # Check that the cookie key is no longer in the cookie jar
    if "test_cookie" not in cookiejar:
        return True
    else:
        return False

# Generated at 2022-06-12 08:33:04.263973
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert str(cookie) == 'key=value'

    cookie['Max-Age'] = 100
    assert str(cookie) == 'key=value; Max-Age=100'

    import datetime
    cookie['expires'] = datetime.datetime.strptime('Sun, 06 Nov 1994 08:49:37 GMT', '%a, %d %b %Y %H:%M:%S GMT')
    assert str(cookie) == 'key=value; Max-Age=100; expires=Sun, 06-Nov-1994 08:49:37 GMT'

    cookie['secure'] = True
    assert str(cookie) == 'key=value; Max-Age=100; expires=Sun, 06-Nov-1994 08:49:37 GMT; Secure'

    cookie = Cookie('key', 'value')


# Generated at 2022-06-12 08:33:13.870109
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import StringIO
    import sys

    capturedOutput = StringIO.StringIO()
    sys.stdout = capturedOutput

    cookie = Cookie("custom","custom_value")

# Generated at 2022-06-12 08:33:25.624932
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = CIMultiDict()
    cookie_jar = CookieJar(headers)
    assert len(cookie_jar) == 0

    # Simple test
    cookie_jar["hello"] = "world"
    assert headers["Set-Cookie"] == ["hello=world; Path=/"]
    assert cookie_jar["hello"].value == "world"
    assert len(cookie_jar) == 1

    # Test multiple cookies
    cookie_jar["foo"] = "bar"
    assert headers["Set-Cookie"] == [
        "hello=world; Path=/",
        "foo=bar; Path=/",
    ]
    assert len(cookie_jar) == 2

    # Test overwriting cookie
    cookie_jar["hello"] = "new world"

# Generated at 2022-06-12 08:33:30.384359
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("foo", "bar")
    cookie['Path'] = '/'
    cookie['domain'] = 'localtest.me'
    cookie['max-age'] = 1800

    assert(cookie['Path'] == '/')
    assert(cookie['domain'] == 'localtest.me')
    assert(cookie['max-age'] == 1800)

# Generated at 2022-06-12 08:33:38.098791
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_object = Cookie('foo', 'bar')
    cookie_object['max-age'] = '360'
    cookie_object['secure'] = True

    assert str(cookie_object) == 'foo=bar; Max-Age=360; Secure'


# Generated at 2022-06-12 08:33:42.482105
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies: Dict[str, Cookie] = {}
    cookies["test1"] = Cookie("test1", "test1")
    cookies["test2"] = Cookie("test2", "test2")
    cookies["test3"] = Cookie("test3", "test3")
    cookies["test4"] = Cookie("test4", "test4")
    cookies["test5"] = Cookie("test5", "test5")
    cookies["test6"] = Cookie("test6", "test6")
    cookies["test7"] = Cookie("test7", "test7")
    cookies["test8"] = Cookie("test8", "test8")
    cookies["test9"] = Cookie("test9", "test9")
    cookies["test10"] = Cookie("test10", "test10")

# Generated at 2022-06-12 08:33:50.350890
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Set headers for testing purpose
    headers = []
    headers.append("Set-Cookie: user=abc; Path=/")
    headers.append("Set-Cookie: expired_cookie=; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    headers.append("Set-Cookie: foo=bar; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    headers.append("Set-Cookie: bar=foo; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT")
    headersdict = {}
    headersdict["Set-Cookie"] = headers

    # Create a new instance of CookieJar
    c = CookieJar(headersdict)
    # Delete cookie `user`
    del c["user"]
    # Verify the deletion and check number of headers

# Generated at 2022-06-12 08:34:00.284772
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    from datetime import datetime
    from time import strptime

    expires_value = datetime.fromtimestamp(
        strptime("15-Jan-1978 18:42:41 GMT", "%d-%b-%Y %H:%M:%S GMT")[0]
    )


# Generated at 2022-06-12 08:34:10.027113
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    This test verifies that the class CookieJar is removing the cookie key
    from the Set-Cookie header and from the dict.
    """
    headers = CIMultiDict()
    jar = CookieJar(headers)

    # Prepare the headers
    headers.add("Set-Cookie", Cookie("a", "foo"))
    headers.add("Set-Cookie", Cookie("b", "foo"))
    headers.add("Set-Cookie", Cookie("c", "foo"))

    # Expect to delete only "b"
    del jar["b"]
    expected_cookies = [
        "a=foo; Path=/; HttpOnly",
        "c=foo; Path=/; HttpOnly",
    ]

# Generated at 2022-06-12 08:34:15.816856
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_CookieJar = CookieJar()
    test_CookieJar["testCookie"] = "testValue"
    result = "testValue"
    assert test_CookieJar["testCookie"].value == result
    del test_CookieJar["testCookie"]
    assert "testCookie" not in test_CookieJar.cookie_headers
    assert "testCookie" not in test_CookieJar

# Generated at 2022-06-12 08:34:16.453517
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass

# Generated at 2022-06-12 08:34:24.265740
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookieJar = CookieJar(headers)
    key = "key"
    maxage = 0

    # Test deleting without __setitem__
    cookieJar[key] = "value"
    cookieJar[key]["max-age"] = maxage
    del cookieJar[key]
    assert key not in cookieJar

    # Test deleting after __setitem__ but before __delitem__
    cookieJar[key] = ""
    assert key in cookieJar
    cookieJar[key]["max-age"] = maxage
    del cookieJar[key]
    assert key not in cookieJar

# Generated at 2022-06-12 08:34:29.638532
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    Ensure __setitem__ method of CookieJar class is functioning.
    """
    from aiohttp.multidict import MultiDict
    headers = MultiDict()
    cookies = CookieJar(headers)
    cookies["test"] = "testing"
    assert cookies["test"].value == "testing"
    assert headers["Set-Cookie"] == "test=testing; Path=/; HttpOnly"


# Generated at 2022-06-12 08:34:36.956846
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    cookie['expires'] = datetime(2020, 1, 1)
    cookie['max-age'] = 10
    cookie['path'] = '/'
    cookie['comment'] = 'comment'
    cookie['domain'] = 'domain'
    cookie['httponly'] = True
    cookie['secure'] = True

    expected_str = 'name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=10; Path=/; Comment=comment; Domain=domain; HttpOnly; Secure'
    assert str(cookie) == expected_str

# ------------------------------------------------------------ #
#  SimpleCookieTest
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:34:52.127331
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test the removement of the cookie with key "session"

    # requirement: remove the cookie "session"
    # precondition:
    # 1. a cookie jar with cookie "session"
    #    session = Cookie("session", "value")

    # Test the removement of cookie "session"
    # action:
    # 1. delete the cookie "session" from the cookie jar
    # postcondition:
    # 1. the cookie "session" is removed from the cookie jar
    # 2. the header "Set-Cookie" is updated
    #    i.e. there is no cookie "session" in the header
    session = Cookie("session", "test")
    cookie_jar = CookieJar([("Set-Cookie", session)])
    assert session in cookie_jar and len(cookie_jar) == 1

# Generated at 2022-06-12 08:35:03.703868
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_headers = {}
    cookie_jar = CookieJar(cookie_headers)

    # Test key arg is a reserved word
    with pytest.raises(KeyError):
        cookie_jar["expires"] = "Tue, 14-May-2019 08:57:09 GMT"

    # Test key arg contains illegal characters
    with pytest.raises(KeyError):
        cookie_jar["hello.cookie.world"] = "Mon, 13-May-2019 08:57:09 GMT"

    # Test value type is not a datetime
    with pytest.raises(TypeError):
        cookie_jar["hello-cookie-world"] = "123"

    # Test value is not a digit
    with pytest.raises(ValueError):
        cookie_jar["hello-cookie-world"] = "abc"

    # Test for successful write


# Generated at 2022-06-12 08:35:08.573722
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {"Set-Cookie": "random_cookie=something"}
    test_jar = CookieJar(headers)
    test_jar["sample_cookie"] = "random_value"
    assert test_jar["sample_cookie"] == "random_value"
    assert test_jar.headers["Set-Cookie"] == "random_cookie=something,sample_cookie=random_value"


# Generated at 2022-06-12 08:35:14.351956
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookieJar = CookieJar(headers)
    cookieJar['mycookie'] = 'a'
    assert (('Set-Cookie', 'mycookie="a"; Path=/')) in headers.items()
    del cookieJar['mycookie']
    assert (('Set-Cookie', 'mycookie=""; Path=/; Max-Age=0')) in headers.items()



# Generated at 2022-06-12 08:35:23.061433
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"
    assert str(c) == c.__str__()

    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"
    assert str(c) == c.__str__()

    c = Cookie("foo", "bar")
    c["secure"] = True
    assert c.__str__() == "foo=bar; Secure"
    assert str(c) == c.__str__()

    c = Cookie("foo", "bar")
    c["secure"] = True
    c["httponly"] = True
    assert c.__str__() == "foo=bar; Secure; HttpOnly"
    assert str(c) == c.__str__()


# Generated at 2022-06-12 08:35:32.113297
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers={}
    jar = CookieJar(headers)
    jar['my_cookie'] = 'my_value'
    jar['my_cookie'] = 'my_value_1'
    jar['my_cookie'] = 'my_value_2'
    jar['my_cookie'] = 'my_value_3'
    assert headers['Set-Cookie'] == 'my_cookie=my_value_3'
    jar['my_cookie'] = 'my_value_4'
    assert headers['Set-Cookie'] == 'my_cookie=my_value_4'
    jar['my_cookie'] = 'my_value_5'
    assert headers['Set-Cookie'] == 'my_cookie=my_value_5'
    del jar['my_cookie']

# Generated at 2022-06-12 08:35:38.378880
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CaseInsensitiveDict()
    cookieJar = CookieJar(headers)
    assert cookieJar.get("name") is None
    assert headers.get("Set-Cookie") is None
    
    cookieJar["name"] = "value"
    assert cookieJar.get("name") == "value"
    assert headers.get("Set-Cookie") is not None
    assert headers.get("Set-Cookie") == "name=value; Path=/; Max-Age=0"
    
    del cookieJar["name"]
    assert cookieJar.get("name") is None
    assert headers.get("Set-Cookie") is None

# Generated at 2022-06-12 08:35:44.457781
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test_cookie", "value")
    date = datetime.now()
    cookie["expires"] = date
    cookie["path"] = "/"
    cookie["httponly"] = True
    cookie["secure"] = True
    expected_output = "test_cookie=value; Secure; HttpOnly; expires={}; path=/".format(
        date.strftime("%a, %d-%b-%Y %T GMT")
    )
    assert str(cookie) == expected_output



# Generated at 2022-06-12 08:35:50.046878
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    cookie = Cookie("key", "value")
    cookies["key"] = cookie

    cookies.__delitem__("key")
    # Check if the header is removed
    assert len(headers) == 1
    header = headers.getall("Set-Cookie").pop()
    assert header.key == "Set-Cookie"
    assert header.value == "key=; Path=/; Max-Age=0"
    # Check if the cookie is removed
    assert len(cookies) == 0

# Generated at 2022-06-12 08:35:53.494504
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    cookiejar = CookieJar(headers={})
    cookiejar['test_case'] = "test_value"

    # Test
    del cookiejar['test_case']

    # Verify
    assert('test_case' not in cookiejar)

# Generated at 2022-06-12 08:36:08.801931
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # create a cookie with arbitrary key and value
    ck = Cookie('abc', 'xyz')

    # check cookie with minimum required fields
    assert str(ck) == 'abc=xyz'

    # check cookie with all fields

    # cookie with max-age
    ck['max-age'] = 10
    assert str(ck) == 'abc=xyz; Max-Age=10'

    # cookie with expires
    ck['expires'] = datetime.strptime('17 Oct 2019', '%d %b %Y')
    assert str(ck) == 'abc=xyz; Max-Age=10; Expires=Thu, 17-Oct-2019 00:00:00 GMT'

    # cookie with Secure and HttpOnly
    ck['secure'] = True
    ck['httponly'] = True

# Generated at 2022-06-12 08:36:14.780478
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    dict_output = {}
    headers = Headers(dict_output)
    headers_keys = headers.keys()
    cookie_jar = CookieJar(headers)
    test_key = "test"
    dict_output[cookie_jar.header_key] = "test"
    cookie_jar[test_key] = "test"
    cookie_jar.__delitem__(test_key)
    assert dict_output[cookie_jar.header_key] == ""


# Generated at 2022-06-12 08:36:21.295115
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_headers = MultiHeader()
    test_cookiejar = CookieJar(test_headers)
    test_cookiejar["test_name"] = "test_value"
    assert test_headers["Set-Cookie"] == "test_name=test_value; Path=/"
    del test_cookiejar["test_name"]
    assert "Set-Cookie" not in test_headers


# Generated at 2022-06-12 08:36:28.392787
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # create an empty header, then add cookie
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["test"] = "test_cookie"
    # check if cookie added
    assert "test_cookie" in jar
    assert jar["test"].value == "test_cookie"
    # check if cookie added to headers
    assert headers.getall("Set-Cookie")[0].value == "test=test_cookie"
    # delete cookie
    del jar["test"]
    # check if deleted from jar
    assert "test" not in jar
    # check if cookie deleted from headers
    assert "Set-Cookie" not in headers


# Generated at 2022-06-12 08:36:36.860969
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers["Set-Cookie"] = "hello=world"
    headers["Set-Cookie"] = "alpha=beta"

    cookie_jar = CookieJar(headers)
    assert len(cookie_jar) == 2

    del cookie_jar["hello"]
    assert len(cookie_jar) == 1
    assert cookie_jar["alpha"].value == "beta"

    # removing unexisting key
    del cookie_jar["hello"]
    assert len(cookie_jar) == 1
    assert cookie_jar["alpha"].value == "beta"

    # removing existing key
    del cookie_jar["alpha"]
    assert len(cookie_jar) == 0

# Generated at 2022-06-12 08:36:44.109171
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = CIMultiDict()
    c = CookieJar(headers)
    c["foo"] = "bar"
    assert c["foo"] == "bar"
    assert headers.getall("Set-Cookie")[0].value == "foo=bar; Path=/; HttpOnly;"
    c["foo"] = "baz"
    assert c["foo"] == "baz"
    assert headers.getall("Set-Cookie")[0].value == "foo=baz; Path=/; HttpOnly;"



# Generated at 2022-06-12 08:36:50.143856
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "cookie_key"
    value = "cookie_value"
    cookie = Cookie(key, value)
    assert str(cookie) == "cookie_key=cookie_value"

    cookie["path"] = "/"
    assert str(cookie) == "cookie_key=cookie_value; Path=/"

    cookie["expires"] = datetime(2050, 2, 10, 2, 20, 30)
    assert str(cookie) == "cookie_key=cookie_value; expires=Sat, 10-Feb-2050 02:20:30 GMT; Path=/"

    cookie["secure"] = True
    assert str(cookie) == "cookie_key=cookie_value; expires=Sat, 10-Feb-2050 02:20:30 GMT; Secure; Path=/"

    cookie["httponly"] = True

# Generated at 2022-06-12 08:36:57.077273
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

    # check for deleting non existent cookie
    cookie_jar["test_cookie"] = "test_value"
    del cookie_jar["test_cookie"]

    # check for deleting cookie exists
    cookie_jar["test_cookie"] = "test_value"
    del cookie_jar["test_cookie"]
    assert "test_cookie" not in cookie_jar
    assert "test_cookie" not in headers


# Generated at 2022-06-12 08:37:07.489456
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    # Create a new cookie and check if it is created correctly
    cookies['banana'] = 'split'
    cookies['banana']
    assert cookies.headers['Set-Cookie: banana=split; Path=/'] == cookies['banana']
    assert cookies.get('banana') == 'split'
    assert cookies['banana']['path'] == '/'
    assert cookies['banana'].value == 'split'
    # Update an existing cookie and check if it is updated correctly
    cookies['banana'] = 'ice-cream'
    assert cookies.headers['Set-Cookie: banana=ice-cream; Path=/'] == cookies['banana']
    assert cookies.get('banana') == 'ice-cream'

# Generated at 2022-06-12 08:37:13.904036
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar({})
    assert jar.headers == {}
    jar['key1'] = 'value1'
    assert jar.headers == {'Set-Cookie': 'key1=value1; Path=/; HttpOnly'}
    del jar['key1']
    assert jar.headers == {'Set-Cookie': 'key1=; Path=/; Max-Age=0'}



# Generated at 2022-06-12 08:37:44.563865
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie = Cookie('test_cookie', 'test_value')
    headers = MultiDict()
    cookies = CookieJar(headers)

    cookies['test_cookie'] = 'test_value'
    # assert cookie == cookies['test_cookie']
    # assert headers.get('Set-Cookie', None) == cookie

    cookies['test_cookie2'] = 'test_value2'
    # assert headers.getlist('Set-Cookie') == [cookie, cookie]

    cookies['test_cookie3'] = 'test_value3'
    # assert headers.getlist('Set-Cookie') == [cookie, cookie, cookie]

    assert len(headers.getlist('Set-Cookie')) == 3

# Generated at 2022-06-12 08:37:52.789840
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = dict()
    cookie_jar = CookieJar(headers)
    assert len(headers) == 0
    assert len(cookie_jar.cookie_headers) == 0

    # Add cookie directly
    cookie = Cookie("cookie_1", "value_1")
    cookie["max-age"] = 123
    cookie["path"] = "/"
    cookie["comment"] = "Comment 1"
    headers.add("Set-Cookie", cookie)
    # Add cookie in cookie_jar
    cookie_jar["cookie_2"] = "value_2"
    cookie_jar["cookie_2"]["max-age"] = 123
    cookie_jar["cookie_2"]["path"] = "/"
    cookie_jar["cookie_2"]["comment"] = "Comment 2"
    cookie_jar["cookie_3"] = "value_3"

# Generated at 2022-06-12 08:38:00.612928
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = h11.Headers([])
    cookiejar = CookieJar(headers)
    cookiejar["name"] = "value"
    # Assert that an item was added to the headers
    assert headers.get("set-cookie")[0] == h11.Header(name="set-cookie", value="name=value; Path=/")
    # Delete the cookie
    del cookiejar["name"]
    # Assert that the cookie has been removed from the headers
    assert headers.get("set-cookie") == []
    # Assert that headers has not been cleared
    headers.add("Content-Type", "text/html; charset=UTF-8")
    assert headers.get("content-type")[0] == h11.Header(name="content-type", value="text/html; charset=UTF-8")


# Generated at 2022-06-12 08:38:04.627793
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({})
    cookie_jar['test'] = "test"
    assert cookie_jar['test'].value == "test"



# Generated at 2022-06-12 08:38:11.146614
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    h = Headers({"Set-Cookie": "a=b; Domain=localhost"})
    h2 = Headers({"Content-Type": "test"})
    del h2["Content-Type"]
    c = CookieJar(h)
    c["a"] = "b"
    c["a"] = "c"
    c.headers["Set-Cookie"].append("b=a; Domain=localhost")
    c.cookie_headers["b"] = "Set-Cookie"
    assert h.headers == h2.headers
    assert c.headers["Set-Cookie"] == [Cookie("a", "c"), Cookie("b", "a")]
    del c["a"]
    assert c.headers["Set-Cookie"] == [Cookie("b", "a")]

# Generated at 2022-06-12 08:38:19.640939
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    c = CookieJar(headers)
    
    c['a'] = 'a'
    assert len(c) == 1
    assert len(c.cookie_headers) == 1
    assert len(headers) == 1
    
    c['b'] = 'b'
    assert len(c) == 2
    assert len(c.cookie_headers) == 2
    assert len(headers) == 2
    
    c['a'] = 'a111'
    assert len(c) == 2
    assert len(c.cookie_headers) == 2
    assert len(headers) == 2


# Generated at 2022-06-12 08:38:22.668580
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader(COOKIE_KEY)
    cj = CookieJar(headers)
    cj['a'] = 'b'
    assert len(headers) == 1
    assert headers[COOKIE_KEY] == 'a=b'
    assert cj['a'].value == 'b'


# Generated at 2022-06-12 08:38:30.533002
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"

    cookie = Cookie("foo", "bar")
    cookie["Max-Age"] = 360
    assert str(cookie) == "foo=bar; Max-Age=360"

    cookie = Cookie("foo", "bar")
    cookie["Version"] = 1
    assert str(cookie) == "foo=bar; Version=1"

    cookie = Cookie("foo", "bar")
    cookie["HttpOnly"] = True
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; HttpOnly; Secure"


# Generated at 2022-06-12 08:38:39.046057
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers=headers)
    cookie_jar["test"] = "test"
    cookie_jar["test2"] = "test2"
    assert "test" in cookie_jar

    # Test delete value from cookie
    cookie_jar["test"] = ""
    assert "test" in cookie_jar

    # Test delete complete cookie
    del cookie_jar["test"]
    assert "test" not in cookie_jar

    print("Passed delete method test")
    print("Passed delete method test")


test_CookieJar___delitem__()

# Generated at 2022-06-12 08:38:43.144494
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers({"set-cookie": "test=test; path=/"})
    jar = CookieJar(headers)
    jar["test"] = "test"
    del jar["test"]
    assert "test" not in jar
    assert "set-cookie" not in headers


# Generated at 2022-06-12 08:39:12.238343
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from tempfile import NamedTemporaryFile
    from http.cookies import SimpleCookie

    cookie = Cookie('foo', 'bar')
    cookie['path'] = '/foo'
    cookie['expires'] = datetime(2018, 11, 5, 0, 0, 0)
    cookie['HttpOnly'] = True

    expected = 'foo=bar; Path=/foo; expires=Tue, 06-Nov-2018 04:00:00 GMT; HttpOnly'

    actual = str(cookie)

    assert actual == expected

# ------------------------------------------------------------ #
#  Tests
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:39:21.909989
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert c.__str__() == "name=value"

    c["path"] = "path"
    assert c.__str__() == "name=value; Path=path"


# Generated at 2022-06-12 08:39:23.517518
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert c.__str__() == 'name=value'



# Generated at 2022-06-12 08:39:25.908204
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar()
    cookies[1] = 1
    cookies[2] = 2
    cookies[3] = 3
    del cookies[2]
    assert len(cookies) == 2


# Generated at 2022-06-12 08:39:32.037287
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers([])
    cookieJar = CookieJar(headers)
    cookieJar["test"] = "test"
    assert cookieJar["test"].value == "test"
    assert headers["Set-Cookie"] == "test=test; Path=/; HttpOnly; Secure"
    cookieJar["test"] = "test2"
    assert cookieJar["test"].value == "test2"
    assert headers["Set-Cookie"] == "test=test2; Path=/; HttpOnly; Secure"


# Generated at 2022-06-12 08:39:37.721583
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import pytest
    from multidict import MultiDict

    headers = MultiDict()
    cookie_jar = CookieJar(headers)

    cookie_jar["key"] = "value"
    assert headers["Set-Cookie"] == "key=value"

    # set item with reserved name
    with pytest.raises(KeyError):
        cookie_jar["Version"] = "1"

    # set item with illegal name
    with pytest.raises(KeyError):
        cookie_jar["key;"] = "value"



# Generated at 2022-06-12 08:39:44.266782
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import unittest
    import random
    import string

    class TestCookie___str__(unittest.TestCase):
        # Test class Cookie

        # Testing method __str__

        def test_case(self):
            # Test default attribute values and types
            c = Cookie("cookie", "value")
            assert c.key == "cookie"
            assert c.value == "value"
            assert c.max_age == 0
            assert c.path == None
            assert c.comment == None
            assert c.domain == None
            assert c.secure == False
            assert c.httponly == False
            assert c.version == None
            assert c.samesite == None

            # Test that __str__ returns a str object
            c = Cookie("cookie", "value")
            assert isinstance(str(c), str)

           

# Generated at 2022-06-12 08:39:45.703599
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert __delitem__._signature == '(self, key)'

# Generated at 2022-06-12 08:39:55.342590
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert c.__str__() == "name=value"
    c = Cookie("name", "value")
    c["max-age"] = "10"
    assert c.__str__() == "name=value; Max-Age=10"
    c = Cookie("name", "value")
    c["expires"] = datetime(2019, 6, 20, 14, 4, 11)
    assert c.__str__() == "name=value; expires=Thu, 20-Jun-2019 14:04:11 GMT"
    c = Cookie("name", "value")
    c["secure"] = True
    assert c.__str__() == "name=value; Secure"
    c = Cookie("name", "value")
    c["httponly"] = True
    assert c.__str__()

# Generated at 2022-06-12 08:40:03.771496
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie = Cookie("test_cookie", 123)
    cookie["path"] = "/"
    cookie_jar["test_cookie"] = cookie
    cookie = Cookie("test_cookie2", 1235)
    cookie["path"] = "/"
    cookie_jar["test_cookie2"] = cookie
    cookie = Cookie("test_cookie3", 1236)
    cookie["path"] = "/"
    cookie_jar["test_cookie3"] = cookie
    cookie = Cookie("test_cookie4", 1237)
    cookie["path"] = "/"
    cookie_jar["test_cookie4"] = cookie


# Generated at 2022-06-12 08:40:59.641530
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    request_headers = MultiHeader()
    cookiejar = CookieJar(request_headers)
    cookie = Cookie('name', 'value')
    cookiejar['name'] = cookie
    cookiejar['name']['path'] = '/'
    cookiejar['name']['max-age'] = 0
    cookiejar['name']['httponly'] = True
    cookiejar['name']['secure'] = True

    cookiejar['name'] = cookie
    cookiejar['name']['path'] = '/'
    cookiejar['name']['max-age'] = 0
    cookiejar['name']['httponly'] = True
    cookiejar['name']['secure'] = True

    cookiejar['name']['max-age'] = 0
    del cookiejar['name']
    assert(len(cookiejar) == 0)

    cookie

# Generated at 2022-06-12 08:41:00.612085
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert False


# Generated at 2022-06-12 08:41:08.154052
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.requests import Request
    from starlette.responses import Response
    from starlette.testclient import TestClient
    from starlette.types import Scope, Receive, Send

    async def app(scope, receive, send):
        assert scope['type'] == 'http'
        response = Response()
        cookies = CookieJar(response.headers)
        cookies["test"] = "test"
        await response(scope, receive, send)

    client = TestClient(app)
    response = client.get("/")
    assert "test=test" in response.headers["Set-Cookie"]

