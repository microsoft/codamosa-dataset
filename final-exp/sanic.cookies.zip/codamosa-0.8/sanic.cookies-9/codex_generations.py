

# Generated at 2022-06-12 08:31:12.793544
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Tests Cookie.__str__() function
    """
    cookie = Cookie("test", "hello_world")
    cookie["expires"] = datetime(2019, 12, 12, 12, 12, 12)
    cookie["path"] = "/"
    cookie["comment"] = "this is a comment"
    cookie["domain"] = "localhost"
    cookie["max-age"] = 2000
    cookie["secure"] = True
    cookie["httponly"] = False
    cookie["version"] = 1
    cookie["samesite"] = "Lax"

    retstr = "test=hello_world; Expires=Thu, 12-Dec-2019 12:12:12 GMT; Path=/; Comment=this is a comment; Domain=localhost; Max-Age=2000; Secure; Version=1; SameSite=Lax"
    assert str(cookie)

# Generated at 2022-06-12 08:31:20.801020
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    def test_Cookie_noProperties():
        cookie = Cookie("foo", "bar")
        assert str(cookie) == "foo=bar"

    def test_Cookie_maxAge():
        cookie = Cookie("foo", "bar")
        cookie["max-age"] = 1800
        assert str(cookie) == "foo=bar; Max-Age=1800"
        cookie["max-age"] = 1800
        assert str(cookie) == "foo=bar; Max-Age=1800"

    def test_Cookie_expires():
        cookie = Cookie("foo", "bar")
        cookie["expires"] = datetime(2019, 9, 5, 0, 0, 0)
        assert (
            str(cookie)
            == "foo=bar; Expires=Thu, 05-Sep-2019 00:00:00 GMT"
        )



# Generated at 2022-06-12 08:31:29.115187
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    headers = MultiHeaderDict()
    headers.add('Set-Cookie', 'key1=value1')
    headers.add('Set-Cookie', 'key2=value2')
    headers.add('Set-Cookie', 'key3=value3')
    headers.add('Set-Cookie', 'key4=value4')
    cookie_jar = CookieJar(headers)

    # Test
    del cookie_jar['key3']

    # Assert
    assert headers['Set-Cookie'] == 'key1=value1; key2=value2; key4=value4'



# Generated at 2022-06-12 08:31:36.616322
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("key", "value")
    with pytest.raises(KeyError):
        c["Nonexistent"] = "value"
    with pytest.raises(KeyError):
        c["Value"] = "value"
    with pytest.raises(ValueError):
        c["max-age"] = "string"
    with pytest.raises(TypeError):
        c["expires"] = datetime.now()


# Generated at 2022-06-12 08:31:45.951414
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()

    cookie_jar = CookieJar(headers)
    cookie_jar.header_key = "Set-Cookie"

    cookie_jar["key"] = "value"

    assert "key" in cookie_jar
    assert "value" == cookie_jar["key"].value

    del cookie_jar["key"]

    assert "key" not in cookie_jar
    assert "value" != cookie_jar.get("key")

test_CookieJar___delitem__()

# Generated at 2022-06-12 08:31:57.288686
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('cookie_key', 'cookie_value')
    #  1. verify exception when key is in _keys
    with pytest.raises(KeyError):
        cookie['expires'] = 'expires'
    #  2. verify exception when key contains illegal characters
    with pytest.raises(KeyError):
        cookie['c%okie,_key'] = 'cookie_value'
    #  3. verify exception when value is not False and key is max-age, but value is not integer
    with pytest.raises(ValueError):
        cookie['max-age'] = 'cookie_value'
    #  4. verify exception when value is not False and key is expires, but value is not datetime
    with pytest.raises(TypeError):
        cookie['expires'] = 'cookie_value'
    # 

# Generated at 2022-06-12 08:32:08.097694
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("name", "value")
    assert c["path"] == "/"
    with pytest.raises(KeyError):
        c["foo"] = "bar"  # unknow cookie property
    c["max-age"] = "bar"  # argument not integer
    assert c["max-age"] == 0
    c["max-age"] = 1
    assert c["max-age"] == 1
    c["max-age"] = False
    assert c["max-age"] == 0
    c["expires"] = True
    assert c["expires"] == 0

# ------------------------------------------------------------ #
#  SimpleCookie Tests
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:32:19.091898
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Check behavior for valid case
    headers = MultiDict([("Set-Cookie", "test_key=test_value")])
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    # Perform delete
    del cookie_jar["test_key"]
    # Verify header is deleted
    assert "Set-Cookie" not in cookie_jar.headers

    # Check behavior when key is not present
    headers = MultiDict([("Set-Cookie", "test_key=test_value")])
    cookie_jar = CookieJar(headers)
    # Perform delete
    del cookie_jar["test_key"]
    # Verify header is deleted
    assert "Set-Cookie" not in cookie_jar.headers


# Generated at 2022-06-12 08:32:22.653039
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("test_key", "test_value")
    c["KEY"] = "VALUE"
    print(c["KEY"])
    #assert c["KEY"] == "VALUE"

if __name__ == '__main__':
    test_Cookie___setitem__()

# Generated at 2022-06-12 08:32:26.721537
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    request = Request()
    request.headers.add("Set-Cookie", "uid=12345")
    request.cookies["uid"] = "12345"
    request.cookies["uid"]["httponly"] = True
    request.cookies["uid"]["max-age"] = 10
    print(request.cookies["uid"])



# Generated at 2022-06-12 08:32:37.310369
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["cookie1"] = "value1"
    del cookie_jar["cookie1"]
    assert not cookie_jar
    cookies_list = list(headers.items(cookie_jar.header_key))
    assert cookies_list == [("Set-Cookie", "cookie1=; Path=/; Max-Age=0")]


# Generated at 2022-06-12 08:32:46.828549
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "a"
    cookie_jar["a"] = "b"
    cookie_jar["a"] = "c"
    cookie_jar["b"] = "b"
    cookie_jar["c"] = "c"
    assert "a" in cookie_jar
    assert "b" in cookie_jar
    assert "c" in cookie_jar
    assert 3 == len(cookie_jar)
    assert 3 == len(headers)

    del cookie_jar["a"]
    assert "a" not in cookie_jar
    assert "b" in cookie_jar
    assert "c" in cookie_jar
    assert 2 == len(cookie_jar)
    assert 2 == len(headers)

    del cookie_jar["b"]

# Generated at 2022-06-12 08:32:54.464716
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("a", "b")
    assert str(cookie) == "a=b"
    cookie["secure"] = True
    assert str(cookie) == "a=b; Secure"
    cookie["secure"] = False
    cookie["comment"] = "test"
    assert str(cookie) == "a=b; Comment=test"
    cookie["max-age"] = 10
    assert str(cookie) == "a=b; Comment=test; Max-Age=10"

# ------------------------------------------------------------ #
#  Utilities
# ------------------------------------------------------------ #

# Generated at 2022-06-12 08:32:57.611180
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = headers.Headers()
    cj = CookieJar(headers)
    cj["foo"] = "bar"

    assert headers["Set-Cookie"] == "foo=bar; Path=/; Max-Age=0"


# Generated at 2022-06-12 08:33:01.829458
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["expires"] = "Fri, 31 Dec 9999 23:59:59 GMT"
    assert str(cookie) == "name=value; Version=1; Path=/; Expires=Fri, 31 Dec 9999 23:59:59 GMT"

# ------------------------------------------------------------ #
#  Cookie headers
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:33:09.673339
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test case 1
    cookie = Cookie(key="EdibleCookie", value="chocolate")
    cookie["path"] = "/"
    cookie["httponly"] = True
    cookie["secure"] = True
    assert "EdibleCookie=chocolate; HttpOnly; Secure; Path=/" == str(cookie)

    # test case 2
    cookie = Cookie(key="EdibleCookie", value="chocolate")
    cookie["path"] = "/"
    cookie["comment"] = "this is a comment"
    assert "EdibleCookie=chocolate; Path=/; Comment=this is a comment" == str(cookie)

    # test case 3
    cookie = Cookie(key="EdibleCookie", value="chocolate")
    cookie["path"] = "/"
    cookie["comment"] = "this is a comment"

# Generated at 2022-06-12 08:33:11.527700
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("test", "value")
    assert c["expires"] != "expires"



# Generated at 2022-06-12 08:33:23.663965
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
  headers = headers.Headers()
  cookie_jar = CookieJar(headers)
  cookie_jar.__setitem__('test', 'value')
  cookie_jar.__setitem__('test2', 'value2')

  assert headers.get("Set-Cookie") == "test=value; Path=/; test2=value2; Path=/"
  assert len(cookie_jar.keys()) == 2
  assert len(headers) == 1

  cookie_jar.__delitem__('test')
  assert headers.get("Set-Cookie") == "test2=value2; Path=/"
  assert len(cookie_jar.keys()) == 1
  assert len(headers) == 1

  cookie_jar.__delitem__('test2')
  assert len(headers) == 0
  assert len(cookie_jar.keys()) == 0

# Generated at 2022-06-12 08:33:31.088250
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('key', 'value')
    with pytest.raises(KeyError):
        cookie['expires'] = None
    with pytest.raises(KeyError):
        cookie['path'] = None
    with pytest.raises(KeyError):
        cookie['comment'] = None
    with pytest.raises(KeyError):
        cookie['domain'] = None
    cookie['max-age'] = None
    assert cookie['max-age'] == None
    with pytest.raises(ValueError):
        cookie['max-age'] = 'string'
    cookie['expires'] = None
    assert cookie['expires'] == None
    with pytest.raises(TypeError):
        cookie['expires'] = datetime.now()
    cookie['secure'] = False
    assert cookie['secure'] == None
   

# Generated at 2022-06-12 08:33:43.097894
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    fake_headers = MultiHeaderDict()
    fake_headers.add("Set-Cookie", "test1=wassup; Path=/; HttpOnly; SameSite=Lax")
    fake_headers.add("Set-Cookie", "test2=wassup; Path=/; HttpOnly; SameSite=Lax")
    fake_headers.add("Set-Cookie", "test3=wassup; Path=/; HttpOnly; SameSite=Lax")
    cookie_jar = CookieJar(fake_headers)
    # check that the cookie exists in the cookie jar
    assert len(cookie_jar.headers) == 3
    assert "test1" in cookie_jar
    assert "test2" in cookie_jar
    assert "test3" in cookie_jar
    # Remove the test1 cookie

# Generated at 2022-06-12 08:33:54.156929
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('name', 'Tom')
    cookie['max-age'] = 0
    cookie['expires'] = datetime.now()
    cookie['path'] = '/'
    cookie['version'] = 1
    cookie['comment'] = 'A test comment'
    cookie['domain'] = 'localhost:8000'
    cookie['secure'] = True
    cookie['httponly'] = False
    cookie['samesite'] = 'Strict'
    cookie['same-site'] = 'Lax'
    cookie['unknown'] = 'unknown'


# Generated at 2022-06-12 08:34:01.409495
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    headers = Multidict()
    cookie_jar = CookieJar(headers)


    # Testing for case 1
    # Expecting 'cookiename' in cookie_jar.cookie_headers
    # to be true
    cookie_jar.cookie_headers = {
        'cookiename': 'Set-Cookie'
    }

    cookie_jar['cookiename'] = "cookievalue"
    del cookie_jar['cookiename']

    assert 'cookiename' not in cookie_jar.headers
    assert cookie_jar.cookie_headers == {}

    # Testing for case 2
    # Expecting 'cookiename' in cookie_jar.cookie_headers
    # to be false
    cookie_jar['cookiename'] = 'cookievalue'
    del cookie_jar['cookiename']

    assert 'cookiename'

# Generated at 2022-06-12 08:34:10.444025
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    cookie["expires"] = datetime.now()
    cookie["max-age"] = 12345
    cookie["path"] = "/"
    cookie["comment"] = "Test Cookie"
    cookie["domain"] = "example.org"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"


# Generated at 2022-06-12 08:34:20.093162
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert str(Cookie('key', 'value')) == "key=value"
    assert str(Cookie('key', 'value')['path'] == "/") == "key=value; Path=/"
    test_cookie = Cookie('key', 'value')
    test_cookie['max-age'] = '123456'
    assert str(test_cookie) == "key=value; Max-Age=123456; Path=/"
    test_cookie['secure'] = True
    assert str(test_cookie) == "key=value; Max-Age=123456; Path=/; Secure"
    # test expires and comment

# Generated at 2022-06-12 08:34:26.799076
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c= Cookie("test","test")
    assert str(c) == "test=test"
    assert c.encode("utf-8") == b"test=test"
    assert c.encode("iso-8859-1") == b"test=test"

    c= Cookie("test","test")
    c["path"]="/test"
    c["expires"]=datetime(2018,1,1)
    c["max-age"]=0
    c["httponly"]=True

    assert str(c) == "test=test; Path=/test; Expires=Mon, 01-Jan-2018 00:00:00 GMT; Max-Age=0; HttpOnly"

# Generated at 2022-06-12 08:34:33.778424
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    c = CookieJar(headers)
    c["cookie1"] = ""
    c["cookie1"]["max-age"] = 0
    c["cookie2"] = ""
    c["cookie2"]["max-age"] = 0

    c.headers.add(c.header_key, c["cookie1"])
    c.headers.add(c.header_key, c["cookie2"])

    c["cookie1"] = "value"
    c["cookie2"] = "value"

    del c["cookie1"]

    assert c.headers["Set-Cookie"] == "cookie2=value"

# Generated at 2022-06-12 08:34:35.949859
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookies = CookieJar({"name": "test"})
    cookies["name"] = "test"
    cookies["name"] = "test2"
    assert cookies["name"] == "test2"

# Generated at 2022-06-12 08:34:45.956046
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    t0 = Cookie('name', 'value')
    assert t0['name'] == 'value'
    t0['expires'] = 'expires'
    assert t0['expires'] == 'expires'
    t0['max-age'] = 'max-age'
    assert t0['max-age'] == 'max-age'
    t0['path'] = 'path'
    assert t0['path'] == 'path'
    t0['comment'] = 'comment'
    assert t0['comment'] == 'comment'
    t0['domain'] = 'domain'
    assert t0['domain'] == 'domain'
    t0['secure'] = 'secure'
    assert t0['secure'] == 'secure'
    t0['httponly'] = 'httponly'

# Generated at 2022-06-12 08:34:56.005009
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    jar = CookieJar(headers)

    jar['cookie1'] = 'v1'
    jar['cookie2'] = 'v2'
    jar['cookie3'] = 'v3'

    jar['cookie1'] = ''
    jar['cookie2'] = ''
    jar['cookie3'] = ''

    assert headers['Set-Cookie'] == [
        'cookie1=; Max-Age=0',
        'cookie2=; Max-Age=0',
        'cookie3=; Max-Age=0'
    ]

    assert len(jar.headers) == 3

    del jar['cookie1']
    del jar['cookie2']
    del jar['cookie3']

    assert len(jar.headers) == 0

# Generated at 2022-06-12 08:35:05.566980
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers.add('Set-Cookie', Cookie('name1', 'value1'))
    headers.add('Set-Cookie', Cookie('name2', 'value2'))
    headers.add('Set-Cookie', Cookie('name3', 'value3'))
    headers.add('Set-Cookie', Cookie('name4', 'value4'))
    jar = CookieJar(headers)
    assert jar.cookie_headers == {'name1': 'Set-Cookie', 'name2': 'Set-Cookie', 'name3': 'Set-Cookie', 'name4': 'Set-Cookie'}

# Generated at 2022-06-12 08:35:24.712677
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies['foo'] = 'bar'
    assert headers['Set-Cookie'] == 'foo=bar; Path=/'
    cookies['foo'] = 'baz'
    assert headers['Set-Cookie'] == 'foo=baz; Path=/'



# Generated at 2022-06-12 08:35:26.972186
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("ckey", "cvalue")
    assert "ckey=cvalue" in str(cookie)

# Generated at 2022-06-12 08:35:34.098233
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    c["path"] = "."
    c["httponly"] = True
    c["expires"] = datetime(2019, 1, 1)
    c["samesite"] = "Strict"
    c["version"] = 1
    c["domain"] = "test.com"
    c["max-age"] = 365
    c["comment"] = "Comment text"
    assert str(c) == (
        "foo=bar; Path=.; Expires=Tue, 01-Jan-2019 00:00:00 GMT; "
        "HttpOnly; Domain=test.com; Max-Age=365; Version=1; "
        "SameSite=Strict; Comment=Comment text"
    )



# Generated at 2022-06-12 08:35:36.314479
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    jar = CookieJar(headers)
    jar["test"] = "test"
    assert "test" in jar.headers


# Generated at 2022-06-12 08:35:45.830759
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print('test_CookieJar___delitem__')
    cookie_jar = CookieJar(MultiHeader())
    cookie_jar['a'] = 1
    cookie_jar['b'] = 2
    assert cookie_jar['a'] == 1
    assert cookie_jar['b'] == 2
    assert 'Set-Cookie' in cookie_jar.headers.dict
    assert len(cookie_jar.headers.dict['Set-Cookie']) == 2
    del cookie_jar['a']
    assert 'a' not in cookie_jar
    assert 'b' in cookie_jar
    assert len(cookie_jar.headers.dict['Set-Cookie']) == 1
    assert cookie_jar.headers.dict['Set-Cookie'][0] == 'b=2; Path=/; Max-Age=0'


# Generated at 2022-06-12 08:35:49.867186
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar({})
    cookies['key1'] = 'value1'
    cookies['key1'] = 'value2'
    cookies['key2'] = 'value2'
    cookies['key3'] = 'value3'
    del cookies['key1']
    assert cookies.keys() == ['key3']

# Generated at 2022-06-12 08:35:54.026617
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Cookies are strings.

    Cookie jar should allow a Cookie to be rendered as a string.
    """
    cookie = Cookie("key", "value")

    string = str(cookie)

    assert string == "key=value"


# ------------------------------------------------------------ #
#  Templating
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:35:58.430291
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    This unit test is designed to check whether the method __delitem__
    works as intended. The method is used to delete a cookie that was
    created previously by the method __setitem__.
    """

    # First we create a cookie with the method __setitem__ and then we
    # delete it with the method __delitem__, looking for the desired
    # outcome.

    # First we create a dummy headers object with information about the
    # headers from the request.

    headers = Headers({"Set-Cookie": "test=example,test2=example2"})
    # We create a CookieJar object with our headers for it to use
    cookies = CookieJar(headers)
    # We create a cookie with the method __setitem__
    cookies["test"] = "example"
    # We check the new cookie was created correctly

# Generated at 2022-06-12 08:36:07.851030
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("c1", "v1")
    cookie["max-age"] = 10
    cookie["expires"] = datetime.fromtimestamp(0)
    cookie["domain"] = "d1"
    cookie["path"] = "p1"
    assert str(cookie) == 'c1=v1; Max-Age=10; Expires=Thu, 01-Jan-1970 00:00:00 GMT; Domain=d1; Path=p1'

    cookie = Cookie("c1", "v1")
    cookie["expires"] = datetime.fromtimestamp(0)
    cookie["domain"] = "d1"
    cookie["path"] = "p1"

# Generated at 2022-06-12 08:36:16.709738
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo', 'bar')
    assert str(cookie) == 'foo=bar'

    cookie.update({'max-age': 100})
    assert str(cookie) == 'foo=bar; Max-Age=100'

    cookie.update({'secure': True})
    assert str(cookie) == 'foo=bar; Max-Age=100; Secure'

    cookie.update({'httponly': True})
    assert str(cookie) == 'foo=bar; Max-Age=100; Secure; HttpOnly'

    cookie.update({'comment': 'hello'})
    assert str(cookie) == 'foo=bar; Max-Age=100; Secure; HttpOnly; Comment=hello'

    cookie.update({'domain': 'example.com'})

# Generated at 2022-06-12 08:36:44.145575
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # GIVEN
    headers = Headers()
    cookie = CookieJar(headers)
    cookie["key"] = "value"
    headers.add("Set-Cookie", "asd=qwe; Path=/")
    headers.add("Set-Cookie", "zxc=cxz; Path=/")
    headers.add("Set-Cookie", "qwe=asd; Path=/")
    # WHEN
    del cookie["key"]
    # THEN
    expected_headers = "Set-Cookie: asd=qwe; Path=/\n" \
                       "Set-Cookie: zxc=cxz; Path=/\n" \
                       "Set-Cookie: qwe=asd; Path=/\n"
    assert str(headers) == expected_headers

# Generated at 2022-06-12 08:36:50.164888
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from io import BytesIO
    from starlette.responses import Response
    from starlette.testclient import TestClient
    from starlette.middleware.base import BaseHTTPMiddleware, RequestResponseEndpoint
    from starlette.middleware.cookies import CookiesMiddleware
    from starlette.requests import Request

    client = TestClient()

    class App(BaseHTTPMiddleware):
        def __init__(self, *args, **kwargs):
            super().__init__(self.__call__, *args, **kwargs)

        async def __call__(self, request: Request) -> Response:
            response = Response(b"Hello, world!", media_type="text/plain")
            cookiejar = CookieJar(response.headers)
            cookiejar["key"] = "value"
            return response


# Generated at 2022-06-12 08:36:58.206158
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    jar = CookieJar(headers)
    jar["cookie1"] = "value1"
    jar["cookie2"] = "value2"
    jar["cookie3"] = "value3"
    jar["cookie4"] = "value4"
    del(jar["cookie1"])
    del(jar["cookie2"])
    del(jar["cookie3"])
    del(jar["cookie4"])
    assert(str(jar["cookie1"]) == str(jar["cookie2"])==str(jar["cookie3"])==str(jar["cookie4"]))



# Generated at 2022-06-12 08:37:08.596333
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    my_cookie_jar = CookieJar(headers)
    my_cookie_jar["cookie_name_1"] = "cookie_value_1"
    my_cookie_jar["cookie_name_2"] = "cookie_value_2"
    my_cookie_jar["cookie_name_3"] = "cookie_value_3"
    my_cookie_jar["cookie_name_4"] = "cookie_value_4"

    # The only way to get rid of the cookie is to specify a max-age of 0
    # this is a new feature in the RFCs, but it's how you do it.
    del my_cookie_jar["cookie_name_3"]
    del my_cookie_jar["cookie_name_4"]

    assert len(my_cookie_jar) == 2

# Generated at 2022-06-12 08:37:15.981625
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["key"] = "value"
    cookies["key2"] = "value2"
    cookies["key3"] = "value3"
    cookies["key4"] = "value4"
    cookies["key5"] = "value5"
    del cookies["key3"]
    del cookies["key5"]
    assert cookies["key"] == "value"
    assert cookies["key2"] == "value2"
    assert cookies["key4"] == "value4"

# Generated at 2022-06-12 08:37:22.882963
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('secret', 'somevalue')
    cookie['path'] = "/"
    cookie['expires'] = datetime.utcnow()
    assert cookie.__str__() == "secret=somevalue; expires=%s; Path=/" % cookie['expires'].strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-12 08:37:29.394975
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["comment"] = "This is a test"
    cookie["domain"] = "example.com"
    cookie["max-age"] = 1800
    cookie["path"] = "/"
    cookie["httponly"] = True
    cookie["secure"] = True
    cookie["version"] = 1
    string = (
        "name=value; comment=This is a test; domain=example.com; max-age=1800;"
        " path=/; HttpOnly; Secure; Version=1"
    )
    assert str(cookie) == string


# ------------------------------------------------------------ #
#  Response
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:37:36.887815
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cook = Cookie("test", "passed")
    assert str(cook) == "test=passed"

    cook = Cookie("sec", "passed")
    cook["expires"] = datetime(2019, 1, 1, 12, 12, 1)
    assert (
        str(cook)
        == 'sec=passed; Expires=Tue, 01-Jan-2019 12:12:01 GMT'
    )


# ------------------------------------------------------------ #
#  Session
# ------------------------------------------------------------ #


# Generated at 2022-06-12 08:37:41.308011
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie = CookieJar(headers)
    cookie["foo"] = "bar"
    assert cookie.cookie_headers.keys() == {"foo"}
    assert len(cookie) == 1

    del cookie["foo"]
    assert cookie.cookie_headers.keys() != {"foo"}
    assert len(cookie) == 0



# Generated at 2022-06-12 08:37:51.512717
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("my_cookie", "my_value")
    cookie["path"] = "/"
    cookie["domain"] = "foo.bar.baz"
    assert str(cookie) == "my_cookie=my_value; Path=/; Domain=foo.bar.baz"

    cookie = Cookie("my_cookie", "my_value")
    cookie["path"] = "/"
    cookie["domain"] = "foo.bar.baz"
    assert str(cookie) == "my_cookie=my_value; Path=/; Domain=foo.bar.baz"

    cookie = Cookie("my_cookie", "my_value")
    cookie["path"] = "/"
    cookie["domain"] = "foo.bar.baz"
    cookie["expires"] = datetime.now()

# Generated at 2022-06-12 08:38:16.904964
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie("name", "value")
    ck["max-age"] = 0
    assert str(ck) == "name=value; Max-Age=0"

    ck["path"] = "/"
    assert str(ck) == "name=value; Max-Age=0; Path=/"

    ck["expires"] = datetime(2020, 7, 4, 0, 0)
    assert str(ck) == "name=value; Max-Age=0; Path=/; expires=Sat, 04-Jul-2020 00:00:00 GMT"

    ck["domain"] = "python.org"
    assert str(ck) == "name=value; Max-Age=0; Path=/; expires=Sat, 04-Jul-2020 00:00:00 GMT; Domain=python.org"

    ck["secure"] = True

# Generated at 2022-06-12 08:38:26.831558
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # init a Cookie instance
    cookie = Cookie(key = 'cookie_name', value = 'cookie_value')
    # add key-value pairs into it
    cookie['path'] = 'cookie_path'
    cookie['domain'] = 'cookie_domain'
    cookie['max-age'] = 'cookie_max-age'
    cookie['secure'] = False
    cookie['httponly'] = True
    cookie['expires'] = datetime.now()
    cookie['version'] = 1.0
    cookie['samesite'] = 'cookie_samesite'
    # test whether it is equal to the correct format

# Generated at 2022-06-12 08:38:38.643164
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    A stripped down version of Morsel from SimpleCookie #gottagofast"""
    
    Cookie._keys = {
    "expires": "expires",
    "path": "Path",
    "comment": "Comment",
    "domain": "Domain",
    "max-age": "Max-Age",
    "secure": "Secure",
    "httponly": "HttpOnly",
    "version": "Version",
    "samesite": "SameSite",
    }
    Cookie._flags = {"secure", "httponly"}
    
    
    
    # output = ["%s=%s" % (self.key, _quote(self.value))]
    #for key, value in self.items():
    #    if key == "max-age":
    #        try:
    #            output.append

# Generated at 2022-06-12 08:38:49.326635
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = HeaderMap()
    cj = CookieJar(headers)
    cj["key1"] = "val1"
    cj["key2"] = "val2"
    cj["key3"] = "val3"

    del cj["key1"]
    cj["key2"] = "newval2"
    del cj["key2"]
    del cj["key3"]
    del cj["key4"]


# Generated at 2022-06-12 08:38:57.433828
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    key1 = 'key1'
    key2 = 'key2'
    key3 = 'key3'
    cookies = CookieJar(headers)
    cookies[key1] = 'value1'
    cookies[key2] = 'value2'
    cookies[key3] = 'value3'
    assert key1 in cookies
    cookies.__delitem__(key1)
    assert key1 not in cookies
    assert key2 in cookies
    cookies.__delitem__(key2)
    assert key2 not in cookies
    assert key3 in cookies
    cookies.__delitem__(key3)
    assert key3 not in cookies

    # Test for invalid key
    with pytest.raises(KeyError):
        cookies.__delitem__(key1)




# Generated at 2022-06-12 08:39:07.369055
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("a", "b")
    assert c["max-age"] == DEFAULT_MAX_AGE
    assert c.key == "a"
    assert c.value == "b"
    assert str(c) == "a=b"

    c["max-age"] = "5"
    assert str(c) == "a=b; Max-Age=5"

    c["max-age"] = 5
    assert str(c) == "a=b; Max-Age=5"

    c["expires"] = datetime(year=2020, month=5, day=5, hour=5, minute=5, second=5)
    assert str(c) == "a=b; Max-Age=5; Expires=Tue, 05-May-2020 05:05:05 GMT"

    c["secure"] = True


# Generated at 2022-06-12 08:39:15.095084
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "hello world")
    cookie["max-age"] = 3600
    cookie["expires"] = datetime.now()
    cookie["domain"] = "test.com"
    cookie["path"] = "/test"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["comment"] = "This is a test"
    assert (
        str(cookie)
        == 'test=hello%20world; Max-Age=3600; expires=Thu, 24-Oct-2019 17:33:07 GMT; Domain=test.com; Path=/test; Secure; HttpOnly; Version=1; Comment=This%20is%20a%20test'
    )


# Generated at 2022-06-12 08:39:24.489469
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    jar = CookieJar(headers)
    
    jar["key"] = "value"
    jar["key_cookie"] = "value_cookie"
    
    assert list(headers.getall("Set-Cookie")) == ["key=value", "key_cookie=value_cookie"]
    assert jar["key"] == "value"
    assert jar["key_cookie"] == "value_cookie"
    
    del jar["key"]
    
    assert list(headers.getall("Set-Cookie")) == ["key_cookie=value_cookie"]
    assert "key" in jar
    assert jar["key"] == ""
    assert jar["key_cookie"] == "value_cookie"
    
    jar["key"] = "value"
    

# Generated at 2022-06-12 08:39:33.973483
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import pickle
    from multidict import MultiDict
    from starlette.responses import Response
    headers = MultiDict()
    cookies = CookieJar(headers)
    cookies['demo'] = 'value'
    assert headers.getall('Set-Cookie') == ['demo=value; Path=/']
    cookie_backup = pickle.loads(pickle.dumps(cookies))
    del cookies['demo']
    assert headers.getall('Set-Cookie') == ['demo=; max-age=0; Path=/']
    cookies.update(cookie_backup)
    assert headers.getall('Set-Cookie') == ['demo=value; Path=/']
    cookies['demo'] = 'value'
    cookies['demo']['expires'] = datetime(2020, 1, 1)

# Generated at 2022-06-12 08:39:39.748454
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert Cookie("key", "value").__str__() == "key=value"
    assert Cookie("ke y", "value").__str__() == '"ke y"=value'
    assert Cookie("key", "val ue").__str__() == 'key="val ue"'
    assert Cookie("key", "value").__str__() == "key=value"
    assert Cookie("ke y", "val ue").__str__() == '"ke y"="val ue"'


# Generated at 2022-06-12 08:40:19.068459
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    # basic case
    assert "key=value" in str(c)
    # max-age integer
    c["max-age"] = 100
    assert "Max-Age=100" in str(c)
    # max-age string
    c["max-age"] = "200"
    assert "Max-Age=200" in str(c)
    # expires
    c["expires"] = datetime.strptime("01/01/2019", "%d/%m/%Y")
    assert "Expires=Mon, 01-Jan-2019 00:00:00 GMT" in str(c)
    # multiple
    c["httponly"] = True
    c["secure"] = True
    assert "HttpOnly" in str(c)
    assert "Secure" in str(c)


# Generated at 2022-06-12 08:40:27.098521
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    input = {
        "some_key": "some_value",
        "some_other_key": "some_other_value",
        "some_key_again": "some_value_again",
    }

    cookiejar = CookieJar(input)

    cookiejar["some_key"] = "some_value"

    assert cookiejar["some_key"] == "some_value"
    cookiejar["some_key"] = "some_other_value"
    assert cookiejar["some_key"] == "some_other_value"
    del cookiejar["some_key"]



# Generated at 2022-06-12 08:40:32.008199
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({})
    cookie_jar["foo"] = "bar"
    assert len(cookie_jar.headers) == 1
    assert cookie_jar["foo"] == "bar"
    assert any(cookie.value == "bar" for cookie in cookie_jar.headers.getall('Set-Cookie'))



# Generated at 2022-06-12 08:40:37.247867
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert str(cookie) == 'key=value'
    cookie['path'] = '/'
    assert str(cookie) == 'key=value; Path=/'
    cookie = Cookie('key', 'value')
    cookie['max-age'] = 0
    assert str(cookie) == 'key=value; Max-Age=0'
    cookie = Cookie('key', 'value')
    cookie['expires'] = datetime(2019, 12, 12)
    assert str(cookie) == 'key=value; expires=Thu, 12-Dec-2019 00:00:00 GMT'


# Generated at 2022-06-12 08:40:44.577923
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

    cookie_jar["test1"] = "val1"
    cookie_jar["test2"] = "val2"

    assert headers.get("Set-Cookie") == "test1=val1; Path=/;\ntest2=val2; Path=/"

    del cookie_jar["test1"]
    assert "test1" not in cookie_jar
    assert "test2" in cookie_jar
    assert headers.get("Set-Cookie") == "test2=val2; Path=/"

# Generated at 2022-06-12 08:40:53.559998
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import unittest


    class TestCookie(unittest.TestCase):
        def test_default(self):
            cookie = Cookie(key="foo", value="bar")
            self.assertEqual(f"foo=bar", str(cookie))


        def test_one_value(self):
            cookie = Cookie(key="foo", value="bar")
            cookie["Version"] = "1"
            self.assertEqual(f"foo=bar; Version=1", str(cookie))


        def test_one_flag(self):
            cookie = Cookie(key="foo", value="bar")
            cookie["HttpOnly"] = True
            self.assertEqual(f"foo=bar; HttpOnly", str(cookie))



# Generated at 2022-06-12 08:41:02.072543
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("hello", "world")
    assert str(cookie) == "hello=world"
    cookie["expires"] = datetime(2020, 2, 3, 3, 3, 34)
    assert str(cookie) == "hello=world; Expires=Mon, 03-Feb-2020 03:03:34 GMT"
    cookie["secure"] = True
    assert str(cookie) == "hello=world; Expires=Mon, 03-Feb-2020 03:03:34 GMT; Secure"
    cookie["path"] = "/"
    assert str(cookie) == "hello=world; Path=/; Expires=Mon, 03-Feb-2020 03:03:34 GMT; Secure"
    cookie["domain"] = "example.com"