

# Generated at 2022-06-12 08:31:18.237440
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    j = CookieJar(headers)
    assert(j.headers.getall("Set-Cookie") == [])
    j["spam"] = "hello"
    assert(j.headers.getall("Set-Cookie") == ["spam=hello; Path=/"])
    j["spam"] = "goodbye"
    assert(j.headers.getall("Set-Cookie") == ["spam=goodbye; Path=/"])
    del j["spam"]
    assert(j.headers.getall("Set-Cookie") == ["spam=; Max-Age=0; Path=/"])
    j["spam"] = "hello"
    j["eggs"] = "hello"

# Generated at 2022-06-12 08:31:24.064624
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    cookie = CookieJar({"Set-Cookie": []})
    try:
        cookie["cookie_key"] = "cookie_value"
    except KeyError:
        assert False
    assert cookie.headers["Set-Cookie"] == ["cookie_key=cookie_value"]
    return True


# Generated at 2022-06-12 08:31:33.920744
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("my_cookie", "my_value")
    cookie["path"] = "/"
    cookie["comment"] = "this is a comment"
    cookie["max-age"] = 3600
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["expires"] = datetime(
        year=2019, month=10, day=17, hour=14, minute=56, second=26
    )
    str_cookie = str(cookie)
    assert (
        str_cookie
        == 'my_cookie=my_value; Path=/; Comment="this is a comment"; Max-Age=3600; Secure; HttpOnly; Version=1; Expires=Thu, 17-Oct-2019 14:56:26 GMT'
    )



# Generated at 2022-06-12 08:31:46.766514
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["domain"] = "demo.com"
    assert str(cookie) == "key=value; Domain=demo.com"
    cookie["max-age"] = 60
    assert str(cookie) == "key=value; Domain=demo.com; Max-Age=60"
    cookie["expires"] = datetime(2019, 1, 1, 10, 0, 0)
    assert str(cookie) == "key=value; Domain=demo.com; Max-Age=60; Expires=Tue, 01-Jan-2019 10:00:00 GMT"
    cookie["secure"] = True

# Generated at 2022-06-12 08:31:56.757197
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 3
    cookie["expires"] = datetime.today()
    cookie["path"] = "/"
    cookie["secure"] = False
    cookie["httponly"] = False
    cookie["comment"] = "blah"
    cookie["domain"] = "domain"
    cookie["version"] = "V1"
    cookie["samesite"] = "lax"
    assert str(cookie) == "key=value; Max-Age=3; Path=/; Domain=domain; Version=V1; SameSite=lax; Expires=%s; Comment=blah" % datetime.today().strftime("%a, %d-%b-%Y %T GMT")

# Generated at 2022-06-12 08:32:07.613056
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    data = {
        "Set-Cookie": ["a=1", "b=2", "c=3", "d=4"]
    }
    master_CookieJar = CookieJar(data)
    master_CookieJar["f"] = "5"
    assert data["Set-Cookie"] == ["a=1", "b=2", "c=3", "d=4", "f=5"]
    del master_CookieJar["b"]
    assert data["Set-Cookie"] == ["a=1", "c=3", "d=4", "f=5"]
    del master_CookieJar["a"]
    assert data["Set-Cookie"] == ["c=3", "d=4", "f=5"]
    del master_CookieJar["g"]

# Generated at 2022-06-12 08:32:13.276316
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    a = Cookie('foo', 'bar')
    assert a.__str__() == 'foo=bar'
    a['path'] = 'baz'
    assert a.__str__() == 'foo=bar; Path=baz'
    assert a.encode('utf-8') == b'foo=bar; Path=baz'



# Generated at 2022-06-12 08:32:14.685703
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert CookieJar.__delitem__ != None


# Generated at 2022-06-12 08:32:15.964954
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert CookieJar(MultiHeader()).__delitem__("abc") == None




# Generated at 2022-06-12 08:32:19.713448
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    c = CookieJar()
    assert c == dict()

    c["cookie_name"] = "cookie_value"
    assert c == {"cookie_name": "cookie_value"}

    c["cookie_name"] = "another_value"
    assert c == {"cookie_name": "another_value"}



# Generated at 2022-06-12 08:32:28.889555
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("my_cookie", "my_value")
    cookie["path"] = "/"
    output = cookie.__str__()
    expected_output = "my_cookie=my_value; Path=/"

    assert (
        output == expected_output
    ), "Expected: %s\nReceived: %s" % (expected_output, output)


# ------------------------------------------------------------ #
#  Tests
# ------------------------------------------------------------ #

# Generated at 2022-06-12 08:32:32.597652
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    my_headers = MultiHeader()
    my_cookie_jar = CookieJar(my_headers)
    my_cookie_jar["my_cookie"] = "my_value"
    my_cookie_jar["another_cookie"] = "another_value"

    del my_cookie_jar["my_cookie"]
    assert not my_headers.getlist("Set-Cookie")



# Generated at 2022-06-12 08:32:43.287692
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-12 08:32:47.406745
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("my_sessionid", "1234")
    cookie["path"] = "/"
    cookie["domain"] = "example.com"
    cookie["secure"] = True
    assert str(cookie) == "my_sessionid=1234; Path=/; Domain=example.com; Secure"

# Generated at 2022-06-12 08:32:48.790717
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("flask_cookie", "1234")
    assert str(cookie) == "flask_cookie=1234"

# ------------------------------------------------------------ #
#  Cookies
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:32:53.505558
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookiejar = CookieJar(headers)
    cookiejar['test'] = 'test'
    assert headers['Set-Cookie'] == 'test=test'
    del cookiejar['test']
    assert 'test=test' not in headers['Set-Cookie']


# Generated at 2022-06-12 08:33:04.453252
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("cookie_name", "cookie_value")
    cookie["path"] = "/"
    assert (str(cookie) == "cookie_name=cookie_value; Path=/")
    cookie["httponly"] = True
    assert (str(cookie) == "cookie_name=cookie_value; Path=/; HttpOnly")
    cookie["secure"] = True
    assert (str(cookie) == "cookie_name=cookie_value; Path=/; HttpOnly; Secure")
    cookie["secute"] = True
    assert (len(cookie) == 4)
    cookie["expires"] = datetime(2020, 10, 10, 0, 0, 0)

# Generated at 2022-06-12 08:33:09.593846
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader("Set-Cookie", "test=test")
    cookies = CookieJar(headers)
    cookies["test"] = "test"
    assert "test=test" == cookies["test"]
    assert "test=test" == next(iter(cookies.headers))


# Generated at 2022-06-12 08:33:13.870058
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_ = MultiHeader()
    headers_["Hello"] = "World"
    headers_["Set-Cookie"] = "hello=world; secure; samesite=strict"
    cookie = CookieJar(headers=headers_)
    del headers_["Hello"]
    assert "Set-Cookie" not in headers_
    assert "hello" not in cookie.cookie_headers


# Generated at 2022-06-12 08:33:25.623819
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('test_Cookie', 'test_value')
    c_str = c.__str__()
    assert c_str == 'test_Cookie=test_value'
    c['path'] = '/'
    c_str = c.__str__()
    assert c_str == 'test_Cookie=test_value; Path=/'
    c['comment'] = 'test_comment'
    c_str = c.__str__()
    assert c_str == 'test_Cookie=test_value; Path=/; Comment=test_comment'
    c['domain'] = 'test_domain'
    c_str = c.__str__()
    assert c_str == 'test_Cookie=test_value; Path=/; Comment=test_comment; Domain=test_domain'
    c['max-age']

# Generated at 2022-06-12 08:33:41.672533
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Method test_Cookie___str__ of class Cookie
    """
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value&value")
    assert str(cookie) == "key=value%26value"

    cookie = Cookie("key", None)
    assert str(cookie) == "key="

    cookie = Cookie("key", "")
    assert str(cookie) == "key="

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie = Cookie("key", "value")
    cookie["expires"] = datetime(2020, 12, 2, 12, 50, 8)

# Generated at 2022-06-12 08:33:49.914120
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    _cookie_jar = CookieJar()
    _cookie1 = Cookie("a", "b")
    _cookie1["path"] = "/"
    _cookie2 = Cookie("c", "d")
    _cookie2["path"] = "/"
    _cookie_jar.add("Set-Cookie", _cookie1)
    _cookie_jar.add("Set-Cookie", _cookie2)
    # _cookie_jar["c"] should delete both cookies
    assert _cookie_jar["c"] == "d"
    assert _cookie_jar["a"] == "b"
    del _cookie_jar["c"]
    assert _cookie_jar["a"] == "b"
    assert _cookie_jar["c"] == ""
    assert _cookie_jar["c"].value == ""
    del _cookie_jar["a"]
    assert _

# Generated at 2022-06-12 08:33:56.522868
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    Expires = datetime.now()
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    assert cookie["Expires"] == Expires
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    assert cookie["max-age"] != None
    cookie["secure"] = True
    assert cookie["secure"] == True
    assert cookie["secure"] != False
    cookie["httponly"] = True
    assert cookie["httponly"] == True
    assert cookie["httponly"] != False

test_Cookie___setitem__()

# Generated at 2022-06-12 08:34:02.931847
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    # Case 1: Add a valid key and delete it
    key = "admin"
    value = "false"
    cookie_jar[key] = value
    del cookie_jar[key]
    assert cookie_jar.keys() == {}
    assert cookie_jar.values() == {}


# Generated at 2022-06-12 08:34:11.216202
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"

    # Set max-age property
    c["max-age"] = DEFAULT_MAX_AGE
    assert c.__str__() == "foo=bar; Max-Age=0"
    c["max-age"] = -1
    assert c.__str__() == "foo=bar; Max-Age=-1"
    c["max-age"] = "1"
    assert c.__str__() == "foo=bar; Max-Age=1"
    c["max-age"] = "foo"
    assert c.__str__() == "foo=bar; Max-Age=foo"
    c["max-age"] = True
    assert c.__str__() == "foo=bar; Max-Age=True"


# Generated at 2022-06-12 08:34:20.247335
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar([])
    cookie_jar['del_test'] = 'DEL_TEST_VALUE'
    del cookie_jar['del_test']
    cookie_jar['del_test'] = 'DEL_TEST_VALUE'
    del cookie_jar['del_test']
    cookie_jar['del_test'] = 'DEL_TEST_VALUE'
    cookie_jar['del_test']['max-age'] = 0
    del cookie_jar['del_test']
    cookie_jar['del_test'] = 'DEL_TEST_VALUE'
    cookie_jar.headers.add('Set-Cookie', cookie_jar['del_test'])
    del cookie_jar['del_test']
    # If we get here, the test passed.

# Generated at 2022-06-12 08:34:31.519332
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    assert 0 == len(cookie_jar.cookie_headers)
    cookie_jar['csrftoken'] = 'token'
    assert 1 == len(cookie_jar.cookie_headers)
    cookie_jar['sid'] = 'id'
    assert 2 == len(cookie_jar.cookie_headers)
    cookie_jar['language'] = 'en'
    assert 3 == len(cookie_jar.cookie_headers)
    del cookie_jar['csrftoken']
    assert 2 == len(cookie_jar.cookie_headers)
    del cookie_jar['sid']
    assert 1 == len(cookie_jar.cookie_headers)
    del cookie_jar['language']
    assert 0 == len(cookie_jar.cookie_headers)
    print("Everything is ok.")

# Generated at 2022-06-12 08:34:34.237406
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert cookie_jar["test_key"].value == "test_value"

# Generated at 2022-06-12 08:34:35.181272
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    pass


# Generated at 2022-06-12 08:34:38.710451
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar['key'] = 'value'
    del cookie_jar['key']
    assert 'key' not in cookie_jar
    assert headers.get('Set-Cookie', 'key') is None



# Generated at 2022-06-12 08:34:55.538793
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("test_Cookie___setitem__")
    c = Cookie('hi', 'hello')
    c['expires'] = 111111
    assert c['expires'] == 111111, c['expires']
    try:
        c['expires'] = 'not a number'
        assert False, 'Should never get here'
    except ValueError:
        pass
    c['foo'] = 'bar'
    try:
        c['foo'] = 'baz'
        assert False, 'Should never get here'
    except KeyError:
        pass


# Generated at 2022-06-12 08:35:00.540606
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = HTTPHeaderMap()
    cookies = CookieJar(headers)
    try:
        cookies["x"] = "y"
        # if CookieJar.__setitem__ works correctly
    except Exception as e:
        return False
    if "x" in cookies:
        return False
    return True



# Generated at 2022-06-12 08:35:04.687224
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    jar = CookieJar({})
    jar["test"] = "test_value"
    assert jar.headers["Set-Cookie"] == "test=test_value; Path=/; Max-Age=0"


# Generated at 2022-06-12 08:35:08.618364
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader(('Set-Cookie', 'foo=bar'))
    cookie_jar = CookieJar(headers)

    assert cookie_jar['foo'].value == 'bar'
    assert headers['Set-Cookie'] == 'foo="bar"'


# Generated at 2022-06-12 08:35:19.167576
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = CIMultiDict()
    cookie_jar = CookieJar(headers)
    assert headers.getall("Set-Cookie") == []
    cookie_jar["a"] = "a"
    cookies = headers.getall("Set-Cookie")
    assert len(cookies) == 1
    assert cookies[0] == "a=a; Path=/; HttpOnly; Secure"

    cookie_jar["b"] = "b"
    cookies = headers.getall("Set-Cookie")
    assert len(cookies) == 2
    assert cookies[0] == "a=a; Path=/; HttpOnly; Secure"
    assert cookies[1] == "b=b; Path=/; HttpOnly; Secure"

    cookie_jar["a"] = "c"

# Generated at 2022-06-12 08:35:23.406318
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar["foo"] = "bar"
    del cookie_jar["foo"]
    assert cookie_jar == {}
    assert cookie_jar.cookie_headers == {}
    assert dict(cookie_jar.headers) == {'Set-Cookie': 'foo=; Max-Age=0'}


# Generated at 2022-06-12 08:35:31.398661
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    # Set-Cookie: <cookie_name>=<cookie_value>
    assert str(Cookie("test", "test")) == "test=test"
    # Set-Cookie: <cookie_name>=<cookie_value>; Path=<path>
    assert str(Cookie("test", "test")["path"]) == "test=test; Path=/"
    # Set-Cookie: <cookie_name>=<cookie_value>; Domain=<domain>
    assert str(Cookie("test", "test")["domain"]) == "test=test; Domain=None"
    # Set-Cookie: <cookie_name>=<cookie_value>; Max-Age=<max-age>

# Generated at 2022-06-12 08:35:34.996560
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    key = "testkey"
    cookie = Cookie(key, "testvalue")
    cookie["path"] = "/"
    headers["Set-Cookie"] = cookie
    cookie_jar[key] = cookie
    del cookie_jar[key]
    assert "testkey" not in cookie_jar
    assert "Set-Cookie" not in headers



# Generated at 2022-06-12 08:35:40.291755
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj.headers={"Set-Cookie": "a=foo; b=bar"}
    cj.cookie_headers={"b": "Set-Cookie"}
    cj["b"] = "baz"
    cj["c"] = "qux"
    del cj["b"]
    assert cj.headers["Set-Cookie"] == "a=foo; c=qux"
    assert cj.cookie_headers == {"c": "Set-Cookie"}


# Generated at 2022-06-12 08:35:41.198173
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    pass


# Generated at 2022-06-12 08:36:17.851438
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from quart.cookies import CookieJar
    headers = {"cookie":""}
    cookies = CookieJar(headers)
    cookies["test"] = "test cookie"
    assert "Set-Cookie" in headers
    assert cookies["test"].value == "test cookie"



# Generated at 2022-06-12 08:36:25.283367
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    c["expires"] = datetime(2005, 1, 1)
    c["path"] = "/foo"
    c["comment"] = "some comment"
    c["httponly"] = True
    c["max-age"] = 42
    c["samesite"] = "Lax"

    assert str(c) == (
        "foo=bar; Version=1; Domain=; "
        "Path=/foo; Expires=Fri, 31-Dec-2004 23:00:00 GMT; "
        "Max-Age=42; Comment=some comment; HttpOnly; SameSite=Lax"
    )
    
    c2 = Cookie("foo", "bar")
    c2["expires"] = datetime(2005, 1, 1)
    c2["path"] = "/foo"

# Generated at 2022-06-12 08:36:33.598715
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    try:
        header = CookieJar(None)
        header["name"] = "bb"
        if header["name"] != "bb":
            raise AssertionError()
        header["name"] = "cc"
        if header["name"] != "cc":
            raise AssertionError()
    except AssertionError:
        print("test_CookieJar___setitem__ failed")
        return 1
    return 0


# Generated at 2022-06-12 08:36:41.812719
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar(MultiHeader())
    cookies["foo"] = "bar"
    cookies["apples"] ="bar"
    cookies["foo"] = "baz"
    assert cookies["foo"] == "baz"
    assert len(cookies) == 2
    assert "foo" in cookies
    assert cookies["foo"].value == "baz"
    del cookies["foo"]
    assert "foo" not in cookies
    assert len(cookies) == 1
    assert cookies["apples"].value == "bar"

# Generated at 2022-06-12 08:36:48.791087
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test scenario: Cookie is not in cookiejar, but is in header
    class Headers:
        def __init__(self):
            self.data = {}

        def add(self, key, value):
            self.data[key] = value

        def popall(self, key):
            return self.data[key]

    headers = Headers()
    headers.add('Set-Cookie', "Test=value")
    cookies = CookieJar(headers)
    cookies["Test"] = "value"
    assert len(cookies) == 1
    del cookies["Test"]
    assert len(cookies) == 0
    assert len(headers.data) == 0

    # Test scenario: Cookie is not in cookiejar, and is not in header
    del cookies["Test"]
    assert len(cookies) == 0

# Generated at 2022-06-12 08:36:58.967377
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    jar = CookieJar(headers)
    jar["Cookie1"] = "Poop"
    jar["Cookie2"] = "Peepee"
    jar["Cookie3"] = "Toilet Paper"
    jar["Cookie4"] = "More Toilet Paper"
    # print(jar.cookie_headers)
    # print(jar)
    del jar["Cookie1"]
    del jar["Cookie2"]
    del jar["Cookie3"]
    del jar["Cookie4"]
    assert "Set-Cookie" not in jar.headers
    assert "Cookie1" not in jar
    assert "Cookie2" not in jar
    assert "Cookie3" not in jar
    assert "Cookie4" not in jar
    assert {} == jar.cookie_headers



# Generated at 2022-06-12 08:37:08.928879
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    now = datetime.now()
    cookie["max-age"] = int(now.timestamp()) + DEFAULT_MAX_AGE
    cookie["expires"] = now
    cookie["secure"] = True
    cookie["httponly"] = True

    encoded = cookie.encode("utf-8")
    assert isinstance(encoded, bytes)

    cookie["max-age"] = int(now.timestamp()) + DEFAULT_MAX_AGE
    cookie["expires"] = now.strftime("%a, %d-%b-%Y %T GMT")
    cookie["secure"] = True
    cookie["httponly"] = False

    encoded = cookie.encode("utf-8")
    assert isinstance(encoded, bytes)

# Generated at 2022-06-12 08:37:18.863986
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Test with some normal values
    cookie = Cookie('thiscookie', 'thisvalue')
    expected = "thiscookie=thisvalue"
    actual = str(cookie)
    assert actual == expected

    # Test with empty values
    cookie = Cookie('', '')
    expected = "=''"
    actual = str(cookie)
    assert actual == expected

    # Test with non-date values in 'expires'
    cookie = Cookie('', '')
    with pytest.raises(TypeError):
        cookie['expires'] = "something"

    # Test with datetime values in 'expires'
    cookie = Cookie('', '')
    cookie['expires'] = datetime.now()

# Generated at 2022-06-12 08:37:22.776100
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    value = 'value'
    cookie_jar[value] = value
    # Check if cookie is added
    assert cookie_jar[value].key == value
    # Checking if cookie is added to the header
    assert headers[cookie_jar.header_key] == cookie_jar[value]
    del cookie_jar[value]
    # Checking if the cookie is removed from header
    assert not cookie_jar[value]


# Generated at 2022-06-12 08:37:27.608655
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookies = CookieJar(headers)
    cookies["name"] = "value"
    assert "name" in cookies.cookie_headers
    # If key in CookieJar.cookie_headers, pop it from headers
    assert "Set-Cookie" in cookies.headers
    cookies.__delitem__("name")
    assert "name" not in cookies.cookie_headers
    assert "Set-Cookie" not in cookies.headers

# Generated at 2022-06-12 08:38:27.537337
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_value"

    # test cookie is in cookie_jar and headers
    assert "test_cookie" in cookie_jar.keys()
    assert "Set-Cookie" in headers.keys()

    # test cookie is deleted from cookie_jar and headers
    del cookie_jar["test_cookie"]
    assert "test_cookie" not in cookie_jar.keys()
    assert "Set-Cookie" not in headers.keys()


# Generated at 2022-06-12 08:38:39.389545
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    Test case for the CookieJar class method __delitem__.
    """
    # create a new TestClient and use it to get a new TestResponse
    client = TestClient()
    response = client.get("/")

    # create a CookieJar and add a new cookie to it
    cookie_jar = CookieJar(client.app.state.http.headers)
    cookie_jar["test"] = "test"

    # assert the cookie has been added to the CookieJar and to the TestResponse
    assert cookie_jar["test"]
    assert response.cookies["test"]

    # remove the cookie from the CookieJar
    del cookie_jar["test"]

    # assert the cookie has been removed from the CookieJar and from the TestResponse
    assert not cookie_jar.get("test")
    assert not response.cookies.get("test")

# Generated at 2022-06-12 08:38:49.994526
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup initial conditions for test
    headers = Headers()
    cookieJar = CookieJar(headers)

    # Test when key is not in cookie_headers
    key = 'key'
    cookieJar[key] = 'value'
    assert key in cookieJar.cookie_headers
    assert key in cookieJar
    cookieJar[key] = ''
    cookieJar[key]['max-age'] = (DEFAULT_MAX_AGE)
    cookieJarKey = cookieJar[key].key
    cookieHdr = cookieJar[key].__str__()
    assert key == cookieJarKey
    assert 'Set-Cookie' in headers
    assert cookieHdr in headers['Set-Cookie']
    cookieJar.__delitem__(key)
    assert key not in cookieJar.cookie_headers
    assert key not in cookieJar

# Generated at 2022-06-12 08:38:52.619060
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Wrong type for key
    headers = MultiDict()
    cookies = CookieJar(headers)
    with pytest.raises(TypeError):
        cookies.__delitem__(3)


# Generated at 2022-06-12 08:38:56.256838
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj['test'] = 'abc'
    assert cj['test'] == 'abc'
    del cj['test']
    #assert len(cj) == 0
    #assert cj['test'] == None
    #assert cj['test'] == '' #Shouldn't need this line, but it doesn't work without it

# Generated at 2022-06-12 08:39:02.007875
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key='key__str__', value='value__str__')
    cookie['path'] = 'path__str__'
    cookie['max-age'] = 'max-age__str__'
    cookie['expires'] = 'expires__str__'
    assert str(cookie) == 'key__str__=value__str__; Path=path__str__; '\
        + 'Max-Age=max-age__str__; Expires=expires__str__'

# Generated at 2022-06-12 08:39:11.252079
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cj = CookieJar({})
    a = Cookie("cookie-name", "value")
    assert a["key"] == a.key
    assert a["path"] == "/"
    assert a["value"] == "value"
    assert a["max-age"] == DEFAULT_MAX_AGE
    assert a["secure"] == False
    assert a["httponly"] == False
    assert a["version"] == 1

    assert a["key"] == "cookie-name"
    assert str(a) == "cookie-name=value; Path=/; Max-Age=0"

    a["path"] = "not/a/path"
    a["secure"] = True
    a["httponly"] = True
    a["version"] = "Not an integer"


# Generated at 2022-06-12 08:39:15.955211
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["comment"] = 'comment'
    cookie['domain'] = 'domain'
    cookie['expires'] = datetime.utcnow()
    cookie['max_age'] = 10000
    cookie['path'] = '/'
    cookie['secure'] = True
    cookie['version'] = 1
    cookie.output()

# Generated at 2022-06-12 08:39:24.097783
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    CookieJar__setitem__
    """
    from .headers import MultiHeader
    from .utils import Hodor
    from .http import HttpRequest
    from .http import HttpResponse
    headers = MultiHeader()
    headers.add("test", "testval")
    headers.add("test", "testval2")
    cookies = CookieJar(headers)
    cookies["test"] = "testval"
    assert "testval" == headers["set-cookie-test"]
    cookies["test2"] = "testval2"
    assert "testval2" == headers["set-cookie-test2"]
    assert cookies["test2"]["path"] == "/"

# Generated at 2022-06-12 08:39:32.719213
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class FakeHeaders:
        def __init__(self):
            self.keys = []

        def add(self, key, value):
            if len(self.keys) == 0 or key != self.keys[len(self.keys) - 1]:
                self.keys.append(key)

        def popall(self, key):
            self.keys.remove(key)
            return []

    cookiejar = CookieJar(FakeHeaders())
    cookiejar["a"] = "a"
    cookies = cookiejar.headers.keys
    assert len(cookies) == 1
    assert cookies[0] == "Set-Cookie"
    del cookiejar["a"]
    cookies = cookiejar.headers.keys
    assert len(cookies) == 0


# Generated at 2022-06-12 08:40:37.831556
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    assert "expires" not in cookie
    assert "path" not in cookie
    assert "comment" not in cookie
    assert "domain" not in cookie
    assert "max-age" not in cookie
    assert "secure" not in cookie
    assert "httponly" not in cookie
    assert "version" not in cookie
    assert "samesite" not in cookie

    cookie["expires"] = datetime(2019, 1, 1, 0, 0, 0)
    assert "expires" in cookie
    assert str(cookie) == "key=value; expires=Tue, 01-Jan-2019 00:00:00 GMT"
    assert "path" not in cookie
    assert "comment" not in cookie
    assert "domain" not in cookie


# Generated at 2022-06-12 08:40:40.002006
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    print(cookie)


# ------------------------------------------------------------ #
#  Utils
# ------------------------------------------------------------ #


# Generated at 2022-06-12 08:40:49.574071
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert (
        Cookie("fish", "trout").__str__()
        == "fish=trout; Max-Age=0; Path=/; Expires=Mon, 01-Jan-1900 00:00:00 GMT"
    )
    assert (
        Cookie("name", "value").__str__()
        == 'name="value"; Max-Age=0; Path=/; Expires=Mon, 01-Jan-1900 00:00:00 GMT'
    )
    assert (
        Cookie("name", "value").__str__()
        == 'name="value"; Max-Age=0; Path=/; Expires=Mon, 01-Jan-1900 00:00:00 GMT'
    )

# Generated at 2022-06-12 08:40:55.423752
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Cookie.__str__ should never return a string ending with a semi colon.
    https://github.com/Pylons/webob/pull/85#issuecomment-236217394
    """
    from webob.cookies import Cookie
    c = Cookie('foo', 'bar')
    c['max-age'] = 5
    s = str(c)
    assert(s[-1] != ';')

# ------------------------------------------------------------ #
#  Async CookieJar
# ------------------------------------------------------------ #


# Generated at 2022-06-12 08:40:59.760080
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["username"] = "hunter2"
    assert "username=hunter2" in str(headers)
    assert len(headers) == 1
    del cookie_jar["username"]
    assert "username=hunter2" not in str(headers)
    assert len(headers) == 0



# Generated at 2022-06-12 08:41:04.924767
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    jar = CookieJar(headers)
    jar["test"] = "test"
    del jar["test"]
    assert headers.getall("Set-Cookie") == []

    jar["test"] = "test"
    jar["test"] = ""
    del jar["test"]
    assert headers.getall("Set-Cookie") == []

    cookie = Cookie("test", "test")
    cookie_header = "Set-Cookie"
    jar.cookie_headers["test"] = cookie_header
    jar.headers.add(cookie_header, cookie)

    del jar["test"]
    assert headers.getall("Set-Cookie") == []

