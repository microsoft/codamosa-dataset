

# Generated at 2022-06-12 08:31:17.796478
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('test', '123')
    cookie['comment'] = 'this is a root level cookie'
    cookie['path'] = '/'
    cookie['domain'] = 'localhost'
    cookie['max-age'] = 10
    cookie['secure'] = True
    cookie['httponly'] = True
    cookie['version'] = 1

    expected = 'test=123; Comment=this is a root level cookie; Path=/; Domain=localhost; Max-Age=10; Secure; HttpOnly; Version=1'
    actual = str(cookie)
    assert expected == actual


# ------------------------------------------------------------ #
#  Middleware
# ------------------------------------------------------------ #


# Generated at 2022-06-12 08:31:29.665809
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers(
        [
            (b"Server", b"python-hypercorn"),
            (b"Date", b"Tue, 07 Jan 2020 15:29:44 GMT"),
            (b"Content-Type", b"text/html; charset=utf-8"),
            (b"Content-Length", b"2"),
            (b"Connection", b"close"),
            (
                b"Set-Cookie",
                b"key1=value1: comment: expires=Tue, 07-Jan-2020 15:32:44 GMT: version=1",
            ),
            (
                b"Set-Cookie",
                b"key2=value2: comment=thu: expires=Tue, 07-Jan-2020 15:32:44 GMT: version=1",
            ),
        ]
    )


# Generated at 2022-06-12 08:31:42.174300
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    assert c.__str__() == "key=value"

    c = Cookie("key", None)
    assert c.__str__() == "key="

    c = Cookie("key", "value")
    c["expires"] = datetime(2019, 5, 15, 14, 59, 5, 0)
    assert c.__str__() == "key=value; expires=Wed, 15-May-2019 14:59:05 GMT"

    c = Cookie("key", "value")
    c["path"] = "/"
    assert c.__str__() == "key=value; Path=/"

    c = Cookie("key", "value")
    c["comment"] = "test"
    assert c.__str__() == "key=value; Comment=test"


# Generated at 2022-06-12 08:31:51.564466
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie("c", "v")
    assert ck.__str__() == "c=v"
    ck["path"] = "/"
    assert ck.__str__() == "c=v; Path=/"
    ck["path"] = False
    assert ck.__str__() == "c=v"
    ck["max-age"] = 3
    assert ck.__str__() == "c=v; Max-Age=3"
    ck["max-age"] = "3"
    assert ck.__str__() == "c=v; Max-Age=3"
    ck["max-age"] = 3.0
    assert ck.__str__() == "c=v; Max-Age=3"
    ck["max-age"] = None
    assert c

# Generated at 2022-06-12 08:31:54.829264
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("foo", "bar")
    cookie["max-age"] = 20
    assert cookie["max-age"] == 20


if __name__ == "__main__":
    pytest.main(args=[__file__])

# Generated at 2022-06-12 08:31:55.948947
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    a = 5
    assert a == 5

# Generated at 2022-06-12 08:32:06.541349
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers([])
    cookie_jar = CookieJar(headers)
    # Test deletion of existing key-value pair from cookie_jar
    cookie_jar["key1"] = "value1"
    assert len(cookie_jar) == 1
    assert len(headers) == 1
    del cookie_jar["key1"]
    assert len(cookie_jar) == 0
    assert len(headers) == 0
    # Test deletion of key-value pair whose key does not exist in cookie_jar
    cookie_jar["key2"] = "value2"
    assert len(cookie_jar) == 1
    assert len(headers) == 1
    del cookie_jar["key1"]
    assert len(cookie_jar) == 0
    assert len(headers) == 0



# Generated at 2022-06-12 08:32:07.051737
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass



# Generated at 2022-06-12 08:32:13.658647
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class _HeaderStore:
        def __init__(self):
            self.store = {}

        def __setitem__(self, key, value):
            key = key.lower()
            self.store[key] = value

        def pop(self, key):
            return self.store.pop(key.lower())

        def popall(self, *keys):
            results = []
            for key in keys:
                if key in self.store:
                    results.append(self.pop(key))
            return results

        def add(self, key, value):
            key = key.lower()
            self.store.setdefault(key, []).append(value)

        def keys(self):
            return self.store.keys()

    # this is how you make a `HeaderStore` instance
    headers = _HeaderStore()



# Generated at 2022-06-12 08:32:22.368384
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    expected = "key=value"
    assert str(c) == expected

    c["max-age"] = 10
    expected = "key=value; Max-Age=10"
    assert str(c) == expected

    c["max-age"] = "astring"
    expected = "key=value; Max-Age=astring"
    assert str(c) == expected

    today = datetime.utcnow()
    c["expires"] = today
    expected = "key=value; Max-Age=astring; Expires={}".format(
        today.strftime("%a, %d-%b-%Y %T GMT")
    )
    assert str(c) == expected

    c["secure"] = True
    c["httponly"] = True

# Generated at 2022-06-12 08:32:32.412810
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "John"
    cookie_jar["name"] = "Jane"
    cookie_jar["age"] = "25"
    assert len(cookie_jar) == 2
    assert "name" in cookie_jar
    assert "age" in cookie_jar
    del cookie_jar["name"]
    assert "name" not in cookie_jar
    assert len(cookie_jar) == 1
    assert "age" in cookie_jar
    assert headers.get("Set-Cookie") == ["age=25; Path=/"]
    del cookie_jar["age"]
    assert "age" not in cookie_jar
    assert len(cookie_jar) == 0
    assert headers.get("Set-Cookie") == []


# Generated at 2022-06-12 08:32:38.621815
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    assert not cookie_jar.cookie_headers
    cookie_jar["key"] = "value"
    assert len(cookie_jar) == 1
    assert cookie_jar["key"] == "value"
    assert len(cookie_jar.cookie_headers) == 1
    assert len(headers) == 1
    assert headers["Set-Cookie"] == "key=value; Path=/; Max-Age=0"


# Generated at 2022-06-12 08:32:46.895032
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(
        'key', 'value'
    )
    cookie["expires"] = datetime.utcnow()
    cookie["path"] = "/"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = 100
    cookie["secure"] = 1
    cookie["httponly"] = 1
    cookie["version"] = 1
    cookie["samesite"] = ""

    assert str(cookie) == "key=value; expires=Tue, 28-Apr-2020 20:13:37 GMT; Path=/" +\
        "; Comment=Comment; Domain=Domain; Max-Age=100; Version=1; Secure; HttpOnly; SameSite"

# Generated at 2022-06-12 08:32:57.458149
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case 1
    headers = MultiHeader()
    headers.add('Set-Cookie', 'name1=value1')
    headers.add('Set-Cookie', 'name2=value2')
    headers.add('Set-Cookie', 'name3=value3')
    headers.add('Set-Cookie', 'name4=value4')
    headers.add('Set-Cookie', 'name5=value5')
    test_cookie_jar = CookieJar(headers)
    test_cookie_jar.__delitem__('name1')
    test_cookie_jar.__delitem__('name2')
    test_cookie_jar.__delitem__('name3')
    test_cookie_jar.__delitem__('name4')
    assert test_cookie_jar == {}
    test_cookie_jar.__del

# Generated at 2022-06-12 08:33:04.523137
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_value = "some_value"
    test_cookie = Cookie("some_key", test_value)
    test_cookie["path"] = "/"
    test_headers = MultiHeader()
    test_headers.add(test_cookie.header_key, test_cookie)
    test_cookie_headers = {test_cookie.key: test_cookie.header_key}

    # Testing the behavior of CookieJar when the cookie does not exist
    test_headers_clone = test_headers.copy()
    test_cookie_headers_clone = test_cookie_headers.copy()
    c = CookieJar((test_headers, test_cookie_headers))
    del c["some_non_existing_key"]
    assert test_headers == test_headers_clone
    assert test_cookie_headers == test_cookie_headers_clone

    # Testing the

# Generated at 2022-06-12 08:33:08.258536
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers: Dict[str, str] = {}
    cj = CookieJar(headers)
    cj["name"] = "Dan"

    assert headers["Set-Cookie"] == "name=Dan; Path=/; Max-Age=0"


# Generated at 2022-06-12 08:33:11.255522
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("TEST", "FOO")
    cookie["expires"] = datetime.utcnow()

    assert type(cookie.__str__()) == str



# Generated at 2022-06-12 08:33:16.280093
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["path"] = "/"
    cookie["httponly"] = True
    cookie["secure"] = True
    cookie["samesite"] = "Strict"
    return cookie.__str__()

# Generated at 2022-06-12 08:33:26.894341
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {'a': 'A', 'b': 'B', 'Cookie': 'c=C'}
    for k,v in headers.items():
        headers[k] = k + ": " + v
    c = CookieJar(headers)
    assert c['a'].key == 'a' and c['a'].value == 'A'
    del c['a']
    assert 'a' not in c.headers
    assert c['b'].key == 'b' and c['b'].value == 'B'
    del c['b']
    assert 'b' not in c.headers
    assert c['c'].key == 'c' and c['c'].value == 'C'
    del c['c']
    assert 'c' not in c.headers

# Generated at 2022-06-12 08:33:37.100313
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar(MultiHeader())
    jar['name1'] = 'value1'
    jar['name2'] = 'value2'
    del jar['name1']
    # Check if cookie with name 'name1' is deleted
    assert len(jar) == 1
    assert not jar.get('name1')
    assert jar.get('name2')
    assert jar['name2'].value == 'value2'

    # Check if cookie with name 'name3' can be deleted successfully
    jar['name3'] = 'value3'
    assert jar.get('name3')
    del jar['name3']
    assert len(jar) == 1
    assert jar.get('name2')
    assert not jar.get('name3')


# Generated at 2022-06-12 08:33:53.176288
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("cookie_name", "cookie_value")
    cookie["expires"] = datetime(2019, 10, 11, 10, 39, 47, 115981)

    expected = "expires=Fri, 11-Oct-2019 10:39:47 GMT"
    actual = str(cookie["expires"])
    assert actual == expected



# Generated at 2022-06-12 08:34:00.741118
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('', "")
    assert str(cookie) == "="
    assert isinstance(cookie, dict)
    cookie = Cookie('username', "ricky")
    assert str(cookie) == "username=ricky"
    cookie = Cookie('username', "ricky")
    cookie['max-age'] = 10
    assert str(cookie) == "username=ricky; Max-Age=10"
    cookie = Cookie('username', "ricky")
    cookie['max-age'] = "hello"
    assert str(cookie) == "username=ricky; Max-Age=hello"
    cookie = Cookie('username', "ricky")
    cookie['expires'] = datetime(2018, 1, 2, 3, 4, 5)

# Generated at 2022-06-12 08:34:10.119923
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # insert one cookie
    headers = MultiHeader()
    c = CookieJar(headers)
    c["key"] = "value"

    assert c["key"] == "value"
    assert str(c["key"]) == "key=value"
    assert str(headers["Set-Cookie"]) == "key=value"

    # insert a second cookie
    c["key2"] = "value2"
    assert c["key2"] == "value2"
    assert str(c["key2"]) == "key2=value2"
    assert str(headers["Set-Cookie"]) == "\r\n".join(("key=value", "key2=value2"))

    # update a cookie
    c["key2"] = "value3"
    assert str(headers["Set-Cookie"]) == "\r\n".join

# Generated at 2022-06-12 08:34:17.691052
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    headers.add('Set-Cookie', '_test_cookie=test_value; path=/')
    headers.add('Set-Cookie', '_test_cookie2=test_value; path=/')
    jar = CookieJar(headers)

    jar._test_cookie2 = 'test_value2'
    del jar._test_cookie

    assert '_test_cookie=test_value; path=/' in headers.getall('Set-Cookie')
    assert '_test_cookie2=test_value2' in headers.getall('Set-Cookie')



# Generated at 2022-06-12 08:34:28.318926
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert c.__str__() == "name=value"

    c.update({"expires": datetime(2016, 1, 1)})
    assert c.__str__() == "name=value; Expires=Fri, 01-Jan-2016 00:00:00 GMT"

    c.update({"max-age": 60})
    assert c.__str__() == "name=value; Expires=Fri, 01-Jan-2016 00:00:00 GMT; Max-Age=60"

    c.update({"secure": True})
    assert c.__str__() == "name=value; Expires=Fri, 01-Jan-2016 00:00:00 GMT; Max-Age=60; Secure"

    c.update({"httponly": True})
    assert c.__str__

# Generated at 2022-06-12 08:34:36.578564
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Test the __setitem__ function when:

    1. key is a reserved word
    2. key contains illegal characters
    3. value is not False
    4. max-age value is not an integer
    5. expires value is not a datetime
    """

    # Case 1: key is a reserved word
    cookie = Cookie("max-age", "100")
    try:
        cookie["max-age"] = "200"
        assert False
    except KeyError:
        assert True

    # Case 2: key contains illegal characters
    cookie = Cookie("$key", "value")
    try:
        cookie["$key"] = "new_value"
        assert False
    except KeyError:
        assert True

    # Case 3: value is not False
    cookie = Cookie("key", "value")

# Generated at 2022-06-12 08:34:42.714284
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # initial
    headers = Headers()
    cookie_jar = CookieJar(headers)

    # adding an item to the jar
    cookie_jar["cookie_key"] = "cookie_value"
    assert "cookie_key=cookie_value" in headers["Set-Cookie"]

    # deleting an item from the jar
    del cookie_jar["cookie_key"]
    assert "cookie_key=cookie_value" not in headers["Set-Cookie"]



# Generated at 2022-06-12 08:34:50.780228
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo_bar", "baz_qux")
    cookie['max-age'] = 1
    cookie['expires'] = datetime(
        2020, 10, 1, 2, 3, 4, 567890, tzinfo=datetime.utcnow().tzinfo
    )
    assert (
        str(cookie)
        == "foo_bar=baz_qux; Max-Age=1; expires=Thu, 01-Oct-2020 02:03:04 GMT"
    )


# Generated at 2022-06-12 08:34:58.543306
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar()
    cookie_jar.headers = {}
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    del cookie_jar["key1"]

    assert(cookie_jar.cookie_headers.get("key1") is None)
    assert(cookie_jar.headers.get("key1") is None)



# Generated at 2022-06-12 08:35:06.342013
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    def assert_output(cookie, expected_output):
        cookie_str = cookie.__str__()

        assert cookie_str == expected_output

    # Case 1.1
    cookie = Cookie("name", "value")

    assert_output(cookie, "name=value")

    # Case 1.2
    cookie = Cookie("name", "value;")

    assert_output(cookie, "name=value%3B")

    # Case 2.1
    cookie = Cookie("name", "value")
    cookie["comment"] = "Comment"

    assert_output(cookie, "name=value; Comment=Comment")

    # Case 2.2
    cookie = Cookie("name", "value")
    cookie["comment"] = "Com;ment"

    assert_output(cookie, 'name=value; Comment="Com%3Bment"')

   

# Generated at 2022-06-12 08:35:25.407909
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["likes_cookies"] = "yes"
    assert headers["Set-Cookie"] == "likes_cookies=yes; Path=/; HttpOnly; SameSite=Lax"
    assert cookie_jar["likes_cookies"]["Path"] == "/"



# Generated at 2022-06-12 08:35:33.958761
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookies = CookieJar({})

    cookies["foo"] = "bar"
    assert cookies["foo"].value == "bar"

    cookies["foo"] = "baz"
    assert cookies["foo"].value == "baz"

    cookies["foo"]["path"] = "/"
    assert cookies["foo"]["path"] == "/"

    cookies["foo"]["expires"] = datetime.now()
    assert (
        isinstance(cookies["foo"]["expires"], datetime)
        and cookies["foo"]["expires"] != None
    )

    with pytest.raises(KeyError):
        cookies["foo"]["unknown_key"] = "baz"

    with pytest.raises(ValueError):
        cookies["foo"]["max-age"] = "bar"


# Generated at 2022-06-12 08:35:41.387443
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.testclient import TestClient
    from starlette.responses import Response
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.applications import Starlette
    from starlette.middleware.base import BaseHTTPMiddleware
    from starlette.requests import Request

    app = Starlette()


    @app.route("/test1")
    async def test1(request):
        request.session["test"] = "test"
        return Response()


    @app.route("/test2")
    async def test2(request):
        request.session["test"] = "test2"
        return Response()


    @app.route("/test3")
    async def test2(request):
        del request.session["test"]
        return Response()


    client

# Generated at 2022-06-12 08:35:48.216956
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)

    cookie_jar["key1"] = "Cookie 1"
    cookie_jar["key2"] = "Cookie 2"
    cookie_jar["key3"] = "Cookie 3"

    del cookie_jar["key1"]
    assert headers.getall(cookie_jar.header_key) == ["key2=Cookie 2", "key3=Cookie 3"]

    del cookie_jar["key2"]
    assert headers.getall(cookie_jar.header_key) == ["key3=Cookie 3"]

    del cookie_jar["key3"]
    assert headers.getall(cookie_jar.header_key) == []

# Generated at 2022-06-12 08:35:57.279996
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie1 = Cookie("name1", "value1")
    cookie2 = Cookie("name2", "value2")
    cookie3 = Cookie("name3", "value3")
    cookie4 = Cookie("name4", "value4")
    cookie5 = Cookie("name5", "value5")
    cookie6 = Cookie("name6", "value6")
    cookie7 = Cookie("name7", "value7")
    cookie8 = Cookie("name8", "value8")
    cookie9 = Cookie("name9", "value9")

    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

# Generated at 2022-06-12 08:36:04.810983
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    h = MultiHeader([])
    c = CookieJar(h)
    c["test"] = "test"
    assert c["test"] == "test"
    assert len(h.headers) == 1
    del c["test"]
    assert len(h.headers) == 1
    assert c["test"] is None
    assert c.cookie_headers["test"] is None
    c["test"] = "test"
    assert len(h.headers) == 1
    del c["test"]
    assert len(h.headers) == 0
    assert c["test"] is None
    assert c.cookie_headers["test"] is None

if __name__ == "__main__":
    test_CookieJar___delitem__()

# Generated at 2022-06-12 08:36:08.424415
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    cookies['foo'] = 'bar'
    del cookies['foo']

    assert len(cookies) == 0
    assert len(headers) == 0



# Generated at 2022-06-12 08:36:10.364337
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert str(cookie) == 'key=value'



# Generated at 2022-06-12 08:36:17.691018
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = 'key'
    value = 'value'
    cookie = Cookie(key, value)
    assert cookie.__str__() == 'key=value'
    cookie['path'] = '/'
    cookie['comment'] = 'a comment'
    cookie['domain'] = 'another-domain'
    cookie['max-age'] = 'max-age'
    cookie['secure'] = 'secure'
    cookie['httponly'] = 'httponly'
    cookie['version'] = 'version'
    cookie['samesite'] = 'samesite'
    assert cookie.__str__() == 'key=value; Path=/; Comment=a comment; Domain=another-domain; Max-Age=max-age; Secure; HttpOnly; Version=version; SameSite=samesite'


# Generated at 2022-06-12 08:36:25.194155
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from starlette.testclient import TestClient
    from starlette.applications import Starlette

    from starlette_session import SessionMiddleware, InMemorySession, RedisSession
    from starlette_session.backends import RedisBackend
    from starlette_session.middleware import SessionMiddleware

    test_client: TestClient = TestClient(
        Starlette(
            middleware=[
                SessionMiddleware(
                    RedisBackend(host="redis", port=6379, prefix="test")
                )
            ],
            routes=[
                (
                    "/",
                    lambda request: request.session.load({"cheese": "cheddar"}),
                ),
            ],
        )
    )

    # Test if cookies are being set
    response = test_client.get("/").json()

# Generated at 2022-06-12 08:37:01.842465
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime

    cookie = Cookie('foo', 'bar')
    assert str(cookie) == "foo=bar"

    cookie = Cookie('foo', 'bar=baz')
    assert str(cookie) == 'foo="bar=baz"'

    cookie = Cookie('foo', b'bar')
    assert str(cookie) == 'foo=bar'

    cookie['Domain'] = 'example.com'
    cookie['Secure'] = True
    cookie['HttpOnly'] = True
    cookie['Path'] = '/'
    cookie['max-age'] = 123
    cookie['expires'] = datetime.now()
    cookie['SameSite'] = 'Lax'

# Generated at 2022-06-12 08:37:09.440708
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("name","value")
    c["path"] = "/"
    with pytest.raises(KeyError):
        c["key"] = "value"
    c["max-age"] = "abc"
    with pytest.raises(ValueError):
        c["max-age"] = "abc"
    c["expires"] = "abc"
    with pytest.raises(TypeError):
        c["expires"] = "abc"
    with pytest.raises(TypeError):
        c["expires"] = datetime.now()
    assert c["expires"] == datetime.now()



# Generated at 2022-06-12 08:37:12.841865
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["test"] = "test"
    assert jar["test"].value == "test"
    assert jars == {"test": "test"}

# Generated at 2022-06-12 08:37:18.260125
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    expected = 'cookie=value; Version=1; Max-Age=0; Path=/; Domain=example.org; HttpOnly'
    c = Cookie('cookie', 'value')
    c['version'] = 1
    c['max-age'] = 0
    c['path'] = '/'
    c['domain'] = 'example.org'
    c['httponly'] = True
    assert str(c) == expected


# Generated at 2022-06-12 08:37:22.978133
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
  headers = multidict.MultiDict()
  jar = CookieJar(headers)

  jar['foo'] = 'bar'
  assert jar['foo'].value == 'bar'
  del jar['foo']
  assert not jar['foo'].value

# Generated at 2022-06-12 08:37:28.607212
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie = Cookie("test_name", "test_value")
    cookie["path"] = "/"
    cookie["max-age"] = DEFAULT_MAX_AGE

    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies.cookie_headers = {"test_name": "Set-Cookie"}
    cookies["test_name"] = cookie
    headers.add("Set-Cookie", cookie)

    del cookies["test_name"]
    assert "test_name" not in cookies
    assert "Set-Cookie" not in headers

# Generated at 2022-06-12 08:37:38.965994
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from falcon import testing
    import json
    import pytest
    client = testing.TestClient()
    class TestResource(object):
        _cookies = CookieJar(client._headers)
        def on_get(self, req, resp):
            resp.body = json.dumps(self._cookies)
        def on_post(self, req, resp):
            resp.body = json.dumps(self._cookies)
            self._cookies[req.media["key"]] = req.media["value"]
        def on_delete(self, req, resp):
            resp.body = json.dumps(self._cookies)
            del self._cookies[req.media["key"]]

    api = falcon.API()
    api.add_route('/cookies', TestResource())


# Generated at 2022-06-12 08:37:46.430627
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    h = HTTPHeaderMap()
    j = CookieJar(h)
    j["ses"] = "1234"
    print(str(h))
    assert str(h) == "Set-Cookie: ses=1234; Path=/;\r\n"
    j["ses"] = "5678"
    assert str(h) == "Set-Cookie: ses=5678; Path=/;\r\n"



# Generated at 2022-06-12 08:37:53.311044
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from yhttp import Headers
    from yhttp.cookies import CookieJar, Cookie
    cookie_jar = CookieJar(Headers({}))
    cookie_jar["a"] = "a"
    assert cookie_jar["a"] == Cookie("a", "a")
    assert cookie_jar.headers["Set-Cookie"] == "a=a"


# Generated at 2022-06-12 08:38:00.734264
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # case 1: delete non-existing cookie
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "a"
    assert "Set-Cookie" in headers
    assert "a=a" in headers.getlist("Set-Cookie")
    assert len(headers.getlist("Set-Cookie")) == 1

    cookie_jar["b"] = "b"
    assert len(headers.getlist("Set-Cookie")) == 2
    assert "b=b" in headers.getlist("Set-Cookie")

    del cookie_jar["c"]
    assert len(headers.getlist("Set-Cookie")) == 3
    assert headers.getlist("Set-Cookie")[2] == "c=; max-age=0"

    # case 2: delete an existing cookie


# Generated at 2022-06-12 08:39:08.880189
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar['name'] = 'cookie'
    assert 'name' in cookie_jar
    assert cookie_jar['name'].key == 'name'
    assert cookie_jar['name'].value == 'cookie'
    assert cookie_jar.cookie_headers == {'name': 'Set-Cookie'}
    assert headers.get('Set-Cookie') == "name=cookie; Path=/"
    del cookie_jar['name']
    assert 'name' not in cookie_jar
    assert cookie_jar.cookie_headers == {}
    assert headers.get('Set-Cookie') == None
    assert headers.getall('Set-Cookie') == []



# Generated at 2022-06-12 08:39:17.898464
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    assert cookies
    # ------------------------------------------------------------ #
    #  Test Setting Cookies To CookieJar
    # ------------------------------------------------------------ #
    cookies["test"] = "test"
    assert cookies["test"].value == "test"
    assert cookies["test"]["path"] == "/"
    assert cookies.header_key == "Set-Cookie"
    # ------------------------------------------------------------ #
    #  Test Setting Illegal Characters to CookieJar
    # ------------------------------------------------------------ #
    try:
        cookies["test*"] = "test"
    except KeyError:
        assert True
    except:
        assert False
    # ------------------------------------------------------------ #
    #  Test Setting Reserved Words to CookieJar
    # ------------------------------------------------------------ #

# Generated at 2022-06-12 08:39:26.221525
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class TestHeaders:
        """Class used to test functionality of headers in CookieJar"""
        def __init__(self):
            self.headers = []
            self.cookie_headers = {}

        def add(self, header, cookie):
            self.headers.append((header, cookie))

        def popall(self, header):
            tmp_list = []
            for item in self.headers:
                if item[0] == header:
                    tmp_list.append(item[1])
            self.headers = list(filter(lambda x: x[0] != header, self.headers))
            return tmp_list

    class TestCookie:
        """Class used to test functionality of cookies in CookieJar"""
        def __init__(self, key, value):
            self.key = key
            self.value = value
        

# Generated at 2022-06-12 08:39:28.033462
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"



# Generated at 2022-06-12 08:39:34.281015
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test simple deletion
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"

    assert headers[0].value == "test=test; Path=/; Max-Age=0"
    assert headers[0].key == "Set-Cookie"
    assert len(header) == 1

    del cookie_jar["test"]

    assert headers.get("Set-Cookie") == None
    assert len(header) == 0

# Generated at 2022-06-12 08:39:38.244655
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers["Set-Cookie"] = "mycookie=myvalue"
    cookies = CookieJar(headers)

    del cookies["mycookie"]
    assert "mycookie" not in cookies
    assert "mycookie" not in headers["Set-Cookie"]
    assert "mycookie" in headers["Set-Cookie"].keys()


# Generated at 2022-06-12 08:39:44.514136
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_string = Cookie("name", "value")
    assert str(cookie_string) == "name=value"
    cookie_string = Cookie("name", "value")
    cookie_string["path"] = "/"
    assert str(cookie_string) == "name=value; Path=/"
    cookies_string = Cookie("name", "value")
    cookies_string["path"] = "/"
    cookies_string["expires"] = datetime(2018, 10, 10, 10, 10, 10)
    assert str(cookies_string) == "name=value; Path=/; Expires=Wed, 10-Oct-2018 10:10:10 GMT"
    cookies_string = Cookie("name", "value")
    cookies_string["path"] = "/"
    cookies_string["httponly"] = True
    assert str(cookies_string)

# Generated at 2022-06-12 08:39:51.850276
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    output = 'foo=bar; Domain=example.com; Expires=Thu, 01-Jan-1970 00:00:00 GMT; HttpOnly; Max-Age=0; Path=/; Secure; Version=1; comment=%22Hello%20World%22'
    assert str(Cookie('foo','bar')) == output
    assert Cookie('foo','bar') == {'domain': 'example.com', 'expires': datetime(1970, 1, 1, 0, 0), 'httponly': True, 'max-age': 0, 'path': '/', 'secure': True, 'version': 1}

# Generated at 2022-06-12 08:39:59.987963
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert c.__str__() == "name=value"

    c["path"] = "/"
    assert c.__str__() == "name=value; Path=/"

    c["HttpOnly"] = True
    assert c.__str__() == "name=value; Path=/; HttpOnly"

    c["Secure"] = True
    c["Max-Age"] = 10
    assert c.__str__() == "name=value; Path=/; HttpOnly; Secure; Max-Age=10"

    # check with 0
    c["Max-Age"] = 0
    assert c.__str__() == "name=value; Path=/; HttpOnly; Secure; Max-Age=0"

    c["Comment"] = "Some Comment"

# Generated at 2022-06-12 08:40:08.639355
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.testclient import TestClient
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse
    from starlette.middleware.cookies import CookiesMiddleware

    app = Starlette()

    @app.route("/")
    def homepage(request):
        cookies = request.cookies
        cookies["test-cookie"] = "test-cookie-value"
        return JSONResponse({"ok": True})

    client = TestClient(
        app, middleware=[CookiesMiddleware(secret_key="secret")]
    )
    response = client.get("/")
    assert response.headers["Set-Cookie"].startswith("test-cookie")
