

# Generated at 2022-06-12 08:31:18.382278
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_headers = MultiHeader({})
    cookie_jar = CookieJar(cookie_headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["baz"] = "buzz"
    assert len(cookie_jar) == 2
    assert len(cookie_headers) == 2
    
    del cookie_jar["foo"]

    assert len(cookie_jar) == 1
    assert len(cookie_headers) == 1
    assert "foo" not in cookie_jar



# Generated at 2022-06-12 08:31:30.204350
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Test to ensure that the Cookie class does what it's supposed to do,
    and fails for invalid cookies
    """
    # Set an item onto a cookie that doesn't exist
    cookie1 = Cookie("username", "coolguy1234")
    cookie1["domain"] = "google.com"
    assert cookie1["domain"] == "google.com"

    # Set an item that should raise a KeyError
    with pytest.raises(KeyError):
        cookie1["baditem"] = "something"

    # Set an item that should raise a ValueError
    with pytest.raises(ValueError):
        cookie1["max-age"] = "badvalue"

    # Set an item that should raise a TypeError
    with pytest.raises(TypeError):
        cookie1["expires"] = datetime.now()

    #

# Generated at 2022-06-12 08:31:45.369437
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("c1", "v1")
    # test for no property
    assert str(cookie) == "c1=v1"

    # test for all properties except "expires"
    for k, v in Cookie._keys.items():
        if k != "expires":
            cookie[k] = "v2"
    assert str(cookie) == "c1=v1; Version=v2; Path=v2; Domain=v2; HttpOnly; Secure"

    # test for "expires"
    cookie = Cookie("c1", "v1")
    cookie["expires"] = datetime(2018, 8, 3, 15, 8, 3, 0)
    assert str(cookie) == "c1=v1; expires=Fri, 03-Aug-2018 15:08:03 GMT"

    # test for "

# Generated at 2022-06-12 08:31:56.253794
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["domain"] = "google.com"
    cookie["max-age"] = "10"
    cookie["secure"] = True
    cookie["httponly"] = True
    assert str(cookie) == "key=value; Path=/; Domain=google.com; Max-Age=10; Secure; HttpOnly"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["domain"] = "google.com"
    cookie["max-age"] = "0"
    assert str(cookie) == "key=value; Path=/; Domain=google.com; Max-Age=0"



# Generated at 2022-06-12 08:32:07.168309
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)

    # Test: Delete a key that doesn't exist
    cookiejar['key1'] = 'value1'
    cookiejar['key2'] = 'value2'

    del cookiejar['key3']

    assert headers.items() == [
        ('Set-Cookie', 'key1="value1"; Max-Age=0'),
        ('Set-Cookie', 'key2="value2"; Max-Age=0')
    ]
    assert cookiejar['key1'].value == 'value1'
    assert cookiejar['key1']['max-age'] == 0
    assert cookiejar['key2'].value == 'value2'
    assert cookiejar['key2']['max-age'] == 0

    # Test: Delete a key that exists

# Generated at 2022-06-12 08:32:18.529595
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test for class Cookie
    C = Cookie('key', 'value')
    C['path'] = '/'
    C['max-age'] = 0
    C['expires'] = datetime(2077, 8, 7, 12, 30, 30)
    C['comment'] = 'cookie-comment'
    C['domain'] = 'localhost'
    C['secure'] = True
    C['httponly'] = True
    C['version'] = 1
    C['samesite'] = 'Strict'
    assert C.key == 'key'
    assert C['max-age'] == 0
    assert C['expires'] == datetime(2077, 8, 7, 12, 30, 30)
    assert C['secure'] == True
    assert C['httponly'] == True
    assert C['version'] == 1

# Generated at 2022-06-12 08:32:27.394331
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers(CookieJar)
    headers["Cookie"] = (
        "a=b; c=d; e=f; g=h; i=j; k=l; m=n; o=p; q=r; s=t; "
        "u=v; w=x; y=z; A=B; C=D; E=F; G=H; I=J; K=L; M=N; "
        "O=P; Q=R; S=T; U=V; W=X; Y=Z"
    )
    del headers["a"]
    del headers["g"]
    del headers["m"]
    del headers["s"]
    del headers["y"]
    del headers["C"]

# Generated at 2022-06-12 08:32:33.132489
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c1 = Cookie("name1", "value1")
    c1["path"] = "/"
    assert str(c1)=="name1=value1; Path=/"

    c2 = Cookie("name2", "value2")
    c2["max-age"] = 100
    assert str(c2)=="name2=value2; Max-Age=100"

    c3 = Cookie("name3", "value3")
    c3["max-age"] = "100"
    assert str(c3)=="name3=value3; Max-Age=100"

    c4 = Cookie("name4", "value4")
    c4["max-age"] = 100.0
    assert str(c4)=="name4=value4; Max-Age=100"


# Generated at 2022-06-12 08:32:35.449073
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="test", value="test")

    expected = "test=test"
    output = str(cookie)

    assert (expected == output)


# Generated at 2022-06-12 08:32:43.956791
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    test_amphibian_setcookie = 'test_amphibian_setcookie=hi; Path=/'
    cookie_jar = CookieJar({})
    cookie_jar['test_amphibian_setcookie'] = 'hi'
    assert 'Set-Cookie' in cookie_jar.headers.raw
    assert test_amphibian_setcookie in cookie_jar.headers.raw['Set-Cookie']
    cookie_jar['test_existing_setcookie'] = 'buddy'
    assert test_amphibian_setcookie in cookie_jar.headers.raw['Set-Cookie']


# Generated at 2022-06-12 08:32:48.123074
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"



# Generated at 2022-06-12 08:32:54.983635
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    c = CookieJar(headers)
    # Set name and key to a value
    c["chocolate"] = "chip"
    # Make sure that we have a cookie
    assert c.cookie_headers.get("chocolate")
    # Delete it
    del c["chocolate"]
    # Make sure that we have no cookies
    assert not c.cookie_headers.get("chocolate")
    assert not c.headers.get("Set-Cookie")


# Generated at 2022-06-12 08:33:05.676464
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('a', 'b')
    c['max-age'] = 300
    assert str(c) == 'a=b; Max-Age=300'
    c['max-age'] = 'test'
    assert str(c) == 'a=b; Max-Age=test'
    c['expires'] = datetime(2013, 1, 1, 0, 0, 0)
    assert str(c) == 'a=b; Max-Age=test; Expires=Tue, 01-Jan-2013 00:00:00 GMT'
    c['secure'] = True
    assert str(c) == 'a=b; Max-Age=test; Expires=Tue, 01-Jan-2013 00:00:00 GMT; Secure'
    c['secure'] = False

# Generated at 2022-06-12 08:33:10.872964
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie = CookieJar()
    cookie["name"] = "value"
    assert len(cookie) == 1
    assert "name" in cookie
    assert cookie["name"] == "value"
    del cookie["name"]
    assert len(cookie) == 0
    assert "name" not in cookie
    assert cookie.get("name") is None

# Generated at 2022-06-12 08:33:23.009235
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers(
        [("Cookie", b"foo=bar"), ("Cookie", b"baz=blah"), ("Cookie", b"baz=123")]
    )
    cookies = CookieJar(headers)
    assert "foo" in cookies
    assert "baz" in cookies
    assert cookies["foo"].value == "bar"
    assert cookies["baz"].value == "123"
    del cookies["foo"]
    assert "foo" not in cookies
    assert "baz" in cookies
    assert cookies["baz"].value == "123"
    del cookies["baz"]
    assert "foo" not in cookies
    assert "baz" not in cookies
    assert headers["Cookie"] == ["baz=123; Max-Age=0", "foo=bar; Max-Age=0"]

# Generated at 2022-06-12 08:33:29.087164
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers([])
    cookie_dict = CookieJar(headers)
    cookie_dict['key'] = 'value'
    cookie_dict['key2'] = 'value2'
    assert headers['Set-Cookie'] == 'key=value; Path=/; key2=value2; Path=/'
    del cookie_dict['key']
    assert headers['Set-Cookie'] == 'key2=value2; Path=/'
    del cookie_dict['key2']
    assert headers['Set-Cookie'] == 'key2=; Max-Age=0; Path=/'

# Generated at 2022-06-12 08:33:36.085130
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar['name'] = 'value'
    assert b'Set-Cookie: name="value"; Path=/' in headers.getlist('Set-Cookie')
    assert jar['name'] == 'value'
    jar['name'] = 'other'
    assert b'Set-Cookie: name="other"; Path=/' in headers.getlist('Set-Cookie')
    assert jar['name'] == 'other'


# Generated at 2022-06-12 08:33:46.282272
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Without max-age and expires
    cookie = Cookie("name", "value")
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["path"] = "Path"
    cookie["secure"] = "Secure"
    cookie["version"] = "Version"
    cookie["httponly"] = "HttpOnly"
    assert str(cookie) == "name=value; Comment=Comment; Domain=Domain; Path=Path; Secure; Version=Version; HttpOnly"

    # With max-age
    cookie["max-age"] = 15
    assert str(cookie) == "name=value; Comment=Comment; Domain=Domain; Max-Age=15; Path=Path; Secure; Version=Version; HttpOnly"

    # With expires
    expires = datetime.now()
    cookie["expires"] = expires
   

# Generated at 2022-06-12 08:33:53.523474
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["foo1"] = "bar1"
    assert headers.get("Set-Cookie") == "foo=bar"
    assert headers.get("Set-Cookie1") == "foo1=bar1"
    assert len(headers) == 2
    assert cookie_jar.get("foo").value == "bar"
    assert cookie_jar.get("foo1").value == "bar1"


# Generated at 2022-06-12 08:34:00.997407
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    assert "Cookie name is a reserved word" in str(
        Exception(
            "Cookie name is a reserved word",
            Cookie(
                "expires", "a long time ago"
            )["expires"],
            "expires",
        )
    ), "adding an expires property should raise a KeyError"
    assert "Cookie key contains illegal characters" in str(
        Exception(
            "Cookie key contains illegal characters",
            Cookie(
                "max-age", "0"
            )["max-age"],
            "max-age",
        )
    ), "adding a max-age property should raise a KeyError"

# Generated at 2022-06-12 08:34:11.834544
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar.__delitem__("test_key")
    assert True


# Generated at 2022-06-12 08:34:14.063333
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("hey", "ho")
    cookie["max-age"] = 3
    assert cookie["max-age"] == 3


# Generated at 2022-06-12 08:34:21.229926
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    cookiejar['email'] = 'foo@bar.com'
    assert len(cookiejar) == 1
    cookiejar['email']
    assert len(list(cookiejar.keys())) == 1
    assert len(headers) == 1
    del cookiejar['email']
    assert len(list(cookiejar.keys())) == 0
    assert len(headers) == 0



# Generated at 2022-06-12 08:34:32.105797
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test __str__ method of Cookie class
    """

    # Test with max-age
    cookie = Cookie("key", "value")
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Max-Age=0"

    # Test with expires
    expires = datetime(2017, 12, 31, 23, 59, 59)
    cookie["max-age"] = None
    cookie["expires"] = expires
    assert str(cookie) == "key=value; expires=Sun, 31-Dec-2017 23:59:59 GMT"

    # Test with secure and httponly
    cookie["secure"] = True
    cookie["httponly"] = True

# Generated at 2022-06-12 08:34:36.185758
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('key', 'value')
    assert str(c) == 'key=value'
    c = Cookie('key', 'value', path='/', domain='localhost')
    assert str(c) == 'key=value; Path=/; Domain=localhost'


# ------------------------------------------------------------ #
#  HTTP Cookie Parser
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:34:46.256269
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["name1"] = "value1"
    assert jar["name1"] == "value1"
    jar["name2"] = "value2"
    assert jar["name2"] == "value2"
    jar["name3"] = "value3"
    assert jar["name3"] == "value3"
    
    assert headers["Set-Cookie"] == "name1=value1; Path=/; name2=value2; Path=/; name3=value3; Path=/"
    del jar["name1"]
    assert len(headers["Set-Cookie"]) == 2
    assert headers["Set-Cookie"] == "name2=value2; Path=/; name3=value3; Path=/"

    assert jar["name2"] == "value2"
   

# Generated at 2022-06-12 08:34:51.803327
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers: Dict[str, str] = {}
    cookie_jar = CookieJar(headers)
    cookie_jar['test_key2'] = 'test_value2'
    assert headers['Set-Cookie'] == 'test_key2=test_value2; Path=/', '__setitem__ failed to set cookie'

# Generated at 2022-06-12 08:35:03.517383
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Tests for the possible values of the flags set (httponly and secure)

    cookie_httponly_secure_set = Cookie(key='cookie', value='1')
    cookie_httponly_secure_set["httponly"] = True
    cookie_httponly_secure_set["secure"] = True

    # Tests for the possible values of the flags not set (httponly and secure)

    cookie_httponly_secure_not_set = Cookie(key='cookie', value='2')
    cookie_httponly_secure_not_set["httponly"] = False
    cookie_httponly_secure_not_set["secure"] = False

    # Tests for the possible values of the flags mixed (httponly and secure)

    cookie_httponly_secure_mixed = Cookie(key='cookie', value='3')

# Generated at 2022-06-12 08:35:11.606242
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("simple_cookie", "tasty!")
    assert str(cookie) == "simple_cookie=tasty%21"

    cookie["httponly"] = True
    assert str(cookie) == "simple_cookie=tasty%21; HttpOnly"

    cookie["httponly"] = False
    assert str(cookie) == "simple_cookie=tasty%21"

    cookie["expires"] = datetime(2015, 3, 14, 21, 31, 50)
    assert str(cookie) == "simple_cookie=tasty%21"

    cookie["max-age"] = 99
    assert str(cookie) == "simple_cookie=tasty%21; Max-Age=99"


# ------------------------------------------------------------ #
#  Unit Tests
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:35:16.679073
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    # print(c)
    c["path"] = "/"
    # print(c)
    c["max-age"] = 0
    # print(c)
    c["secure"] = True
    # print(c)
    c["httponly"] = True
    # print(c)


# Generated at 2022-06-12 08:35:27.671157
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('cookie_name', 'cookie_value')
    assert str(cookie) == 'cookie_name=cookie_value'

    cookie['max-age'] = '123'
    assert str(cookie) == 'cookie_name=cookie_value; Max-Age=123'

    del cookie['max-age']
    cookie['path'] = '/cookie_path'
    cookie['domain'] = '.localhost:5000'
    cookie['secure'] = True
    cookie['httponly'] = True

    assert str(cookie) == (
        'cookie_name=cookie_value; '
        'Path=/cookie_path; '
        'Domain=.localhost:5000; '
        'Secure; '
        'HttpOnly'
    )

    del cookie['secure']

# Generated at 2022-06-12 08:35:34.865734
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo', 'bar')
    assert str(cookie) == 'foo=bar'
    cookie['max-age'] = DEFAULT_MAX_AGE
    assert str(cookie) == 'foo=bar; Max-Age=0'
    cookie['expires'] = datetime.now()
    assert str(cookie).startswith('foo=bar; Max-Age=0; Expires=')
    cookie['path'] = '/'
    assert str(cookie).startswith('foo=bar; Max-Age=0; Expires=; Path=/')
    cookie['secure'] = True
    assert str(cookie).startswith('foo=bar; Max-Age=0; Expires=; Path=/; Secure')
    cookie['httponly'] = True

# Generated at 2022-06-12 08:35:39.125431
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    headers = MultiHeader()
    cookie_jar = CookieJar(headers=headers)

    cookie_jar["foo"] = "bar"

    assert "foo=bar" in headers["Set-Cookie"]
    assert "foo" in cookie_jar

    del cookie_jar["foo"]

    assert "foo=bar" not in headers["Set-Cookie"]
    assert "foo" not in cookie_jar


# Generated at 2022-06-12 08:35:47.016579
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key='abc', value='123')
    cookie['path'] = '/'
    cookie['comment'] = 'You are here'
    cookie['max-age'] = '120'
    cookie['domain'] = 'localhost'
    cookie['expires'] = datetime.now()
    cookie['secure'] = 'True'
    cookie['httponly'] = 'True'
    cookie['version'] = '0'
    assert str(cookie) == 'abc=123; Path=/; Comment=You are here; Max-Age=120; Domain=localhost; Expires=%s; Secure; HttpOnly; Version=0' % datetime.now().strftime("%a, %d-%b-%Y %T GMT")


# Generated at 2022-06-12 08:35:56.460851
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    class TestHeaders:
        def __init__(self):
            self.headers: Dict[str, str] = {}

        def add(self, key, value):
            self.headers[key] = value

        def popall(self, key):
            popall_headers = []
            for header in self.headers[key].split("; "):
                popall_headers.append(header)
            return popall_headers


    headers = TestHeaders()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "Tobias"
    assert cookie_jar["name"] == "Tobias"
    assert headers.headers["Set-Cookie"] == "name=Tobias; Path=/; HttpOnly"

    cookie_jar["name"] = "Tobias Reinhart"
    assert cookie

# Generated at 2022-06-12 08:36:06.474881
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["expires"] = datetime(year=2020, month=1, day=1,
                                 hour=0, minute=0, second=0)
    assert str(cookie) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT"

    cookie["max-age"] = 3600
    assert str(cookie) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=3600"

    cookie["path"] = "/"
    assert str(cookie) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=3600; Path=/"

    cookie["secure"] = True

# Generated at 2022-06-12 08:36:15.841002
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    def test_expires_is_number():
        """
        This tests that the expires value is an integer that is not
        a string representation of an integer.
        """
        try:
            Cookie("foo", "bar")["expires"] = 123
            raise ValueError("This shouldn't happen")
        except TypeError:
            pass

    test_expires_is_number()
    # Have to use a datetime object because of how class `Cookie`
    # is defined
    expires = datetime.utcnow()
    cookie = Cookie("foo", "bar")
    cookie["expires"] = expires
    assert str(cookie) == \
        "foo=bar; Expires={}".format(expires.strftime("%a, %d-%b-%Y %T GMT"))


# ------------------------------------------------------------ #
#  Custom

# Generated at 2022-06-12 08:36:24.685703
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import datetime
    from time import mktime

    c = Cookie("name", "value")

    assert str(c) == "name=value"

    # No value set for 'expires'
    c["expires"] = None

    assert str(c) == "name=value"

    # The pytest we use does not cover datetime.datetime(..,fold=1)
    # (the fold parameter option is new in Python 3.6)
    # The following code is an alternative to make use of the "fold" parameter
    # It should be removed once we use a more recent pytest
    # https://bugs.python.org/issue29332
    # https://bugs.python.org/issue27579

# Generated at 2022-06-12 08:36:31.420841
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers({"Content-Type": "text/html"})
    cookie_jar = CookieJar(headers)
    cookie_jar["Test"] = "SuccessTest"
    del cookie_jar["Test"]
    assert cookie_jar.get("Test") == None
    assert headers.get("Set-Cookie") is None

# Generated at 2022-06-12 08:36:38.043514
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("Test1", "Val1")
    cookie["path"] = "/"
    cookie["comment"] = "TestComment"
    cookie["domain"] = "www.example.com"
    cookie["max-age"] = 42
    cookie["secure"] = True
    cookie["version"] = 1.0
    cookie["httponly"] = True
    cookie["samesite"] = "Strict"
    assert str(cookie) == "Test1=Val1; Path=/; Comment=TestComment; Domain=www.example.com; Max-Age=42; Secure; HttpOnly; Version=1.0; SameSite=Strict"


# Generated at 2022-06-12 08:36:43.238675
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie = CookieJar(MultiHeader())
    cookie["name"] = "marcelo"
    assert cookie["name"].value == "marcelo"


# Generated at 2022-06-12 08:36:45.335208
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert str(cookie) == "key=value"

# ------------------------------------------------------------ #
#  Exceptions
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:36:56.282845
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_1 = Cookie("test", "test")
    cookie_2 = Cookie("test_2", "test_2")
    cookie_3 = Cookie("test_3", "test_3")

    headers = Headers()

    cookie_jar = CookieJar(headers)
    cookie_jar["test"] = "test"
    cookie_jar["test_2"] = "test_2"
    cookie_jar["test_3"] = "test_3"

    headers_dict = headers.dict

    assert isinstance(headers_dict["Set-Cookie"], list)
    assert len(headers_dict["Set-Cookie"]) == 3
    assert isinstance(headers_dict["Set-Cookie"][0], str)
    assert isinstance(headers_dict["Set-Cookie"][1], str)

# Generated at 2022-06-12 08:37:02.011795
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("Hello", "World")
    with pytest.raises(KeyError):
        cookie["max-age"] = False
    with pytest.raises(KeyError):
        cookie["Hello"] = 1
    with pytest.raises(ValueError):
        cookie["max-age"] = "World"
    with pytest.raises(TypeError):
        cookie["expires"] = time.time()
    cookie["expires"] = datetime.now()

# Generated at 2022-06-12 08:37:03.991696
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"


# Generated at 2022-06-12 08:37:08.986874
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    hd = MultiHeader()
    ck = CookieJar(hd)

    ck["key"] = "Hello"

    assert hd.getall("Set-Cookie") == ["key=Hello;Path=/"]
    del ck["key"]
    assert hd.getall("Set-Cookie") == []

# Generated at 2022-06-12 08:37:18.894665
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # We need a fake header object to be passed to CookieJar
    # This will suffice to test the removal of all cookies
    # and a particular cookie from the header
    # with respect to the CookieJar specific header key
    # which is "Set-Cookie"
    header = CookieJar(None)
    # Check that it is empty initially
    assert header.keys() == set()
    assert header.header_key == "Set-Cookie"
    # Set a cookie with name = "name" and value = "value"
    header["name"] = "value"
    # Check that the cookie is present with the corresponding
    # value
    assert header["name"].value == "value"
    # Check that the Set-Cookie header is present
    # with a key in the cookie_headers dictionary
    # equal to "name"
    assert header.cookie

# Generated at 2022-06-12 08:37:24.806941
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cookies = CookieJar(headers)
    cookies['test']='test'
    assert len(cookies.cookie_headers) == 1

    cookies['test2']='test2'
    assert len(cookies.cookie_headers) == 2

    cookies['test3']='test3'
    assert len(cookies.cookie_headers) == 3

    del cookies['test2']
    assert len(cookies.cookie_headers) == 2

    del cookies['test']
    assert len(cookies.cookie_headers) == 1

    del cookies['test']
    assert len(cookies.cookie_headers) == 1
    del cookies['test']
    assert len(cookies.cookie_headers) == 0

    del cookies['test3']
    assert len(cookies.cookie_headers) == 0

# Generated at 2022-06-12 08:37:37.087925
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader("Set-Cookie")
    cookies = CookieJar(headers)

    # Test that value is set as expected
    cookies["key1"] = "value 1"
    assert cookies["key1"].value == "value 1"
    assert headers["Set-Cookie"] == "key1=value 1; Path=/; Max-Age=0"

    # Test that a cookie can be set twice with different values
    cookies["key1"] = "value 2"
    assert cookies["key1"].value == "value 2"
    assert headers["Set-Cookie"] == "key1=value 2; Path=/; Max-Age=0"

    # Test that a cookie can be set twice with the same value
    cookies["key1"] = "value 2"
    assert cookies["key1"].value == "value 2"

# Generated at 2022-06-12 08:37:41.226652
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)

    cookie_jar['foo'] = 'bar'
    del cookie_jar['foo']
    assert cookie_jar.headers['Set-Cookie'] == 'foo=; Max-Age=0; Path=/'


# Generated at 2022-06-12 08:37:52.523353
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    assert (
        str(Cookie("name", "value")) == 'name=value'
    )
    assert (
        str(Cookie("name", "value", path="/")) == 'name=value; Path=/'
    )
    assert (
        str(
            Cookie(
                "name",
                "value",
                max_age=3600  # type: ignore
            )
        ) == 'name=value; Max-Age=3600'
    )

# Generated at 2022-06-12 08:38:00.589799
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = headers()
    headers.add("Name", "value")
    cookie_jar = CookieJar(headers)
    cookie_jar["Name"] = "Cookie"
    cookie_jar["Age"] = "20"

    assert "Name" in cookie_jar
    assert "Age" in cookie_jar
    assert "Name" in cookie_jar.headers
    assert "Age" in cookie_jar.headers
    assert cookie_jar["Name"]["max-age"] != 0
    assert cookie_jar["Age"]["max-age"] != 0

    del cookie_jar["Name"]

    assert "Name" not in cookie_jar
    assert "Age" in cookie_jar
    assert "Name" not in cookie_jar.headers
    assert "Age" in cookie_jar.headers

# Generated at 2022-06-12 08:38:10.039997
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('spam', 'eggs')
    c['path'] = '/'
    assert str(c) == 'spam=eggs; Path=/'
    c['expires'] = datetime(2002, 10, 20, 1, 30, 0)
    assert str(c) == 'spam=eggs; Path=/; expires=Mon, 20-Oct-2002 01:30:00 GMT'
    c['path'] = '/sub/'
    c['comment'] = 'this is a comment'
    assert str(c) == 'spam=eggs; Comment=this is a comment; Path=/sub/; expires=Mon, 20-Oct-2002 01:30:00 GMT'
    c['secure'] = True
    c['httponly'] = True

# Generated at 2022-06-12 08:38:20.374102
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('name', 'value')
    assert str(c) == 'name=value'
    c['path'] = '/'
    assert str(c) == 'name=value; Path=/'
    c['domain'] = 'example.com'
    assert str(c) == 'name=value; Domain=example.com; Path=/'
    c['expires'] = datetime(2099, 1, 1)
    assert 'name=value; Domain=example.com; Expires=Thu, 01-Jan-2099 00:00:00 GMT; Path=/' == str(c)
    c['max-age'] = 0
    assert 'name=value; Domain=example.com; Max-Age=0; Path=/' == str(c)
    c['secure'] = False

# Generated at 2022-06-12 08:38:23.059257
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    jar = CookieJar(headers)
    jar["test"]="this"
    jar.__delitem__("test")
    assert "test" not in jar.keys()


# Generated at 2022-06-12 08:38:31.663947
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaders()
    cookieJar = CookieJar(headers)
    cookieJar['uid'] = '3'
    assert headers['Set-Cookie'][0].key == 'uid'
    assert cookieJar['uid']['path'] == '/'
    # Test updated the value of cookie
    cookieJar['uid'] = '4'
    assert headers['Set-Cookie'][0].value == '4'
    # Test add new cookie
    cookieJar['test'] = 'test'
    assert headers['Set-Cookie'][1].key == 'test'
    assert headers['Set-Cookie'][1].value == 'test'
    assert headers['Set-Cookie'][0].value == '3'


# Generated at 2022-06-12 08:38:39.133169
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    header = MultiHeader()
    cookie_jar = CookieJar(header)
    cookie_jar["coucou"] = "salut"
    assert cookie_jar["coucou"].value == "salut"
    assert header["Set-Cookie"] == "coucou=salut; Path=/; HttpOnly"
    cookie_jar["coucou"] = "au revoir"
    assert header["Set-Cookie"] == "coucou=au revoir; Path=/; HttpOnly"

# Generated at 2022-06-12 08:38:41.059516
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    result = CookieJar({})
    result["key"] = "value"
    del result["key"]
    assert result.headers == {}


# Generated at 2022-06-12 08:38:51.614215
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("chocolatechip", "tasty")
    cookie["max-age"] = 20
    cookie["domain"] = "pylonsproject.org"
    cookie["comment"] = "This is a test comment"
    cookie["httponly"] = True
    assert str(cookie) == "chocolatechip=tasty; Max-Age=20; Domain=pylonsproject.org; Comment=This is a test comment; HttpOnly"
    max_age = 12345  # type: int
    cookie["max-age"] = max_age
    assert str(cookie) == "chocolatechip=tasty; Max-Age=12345; Domain=pylonsproject.org; Comment=This is a test comment; HttpOnly"
    comment = "a comment with values that need quoting"  # type: str
    cookie["comment"] = comment

# Generated at 2022-06-12 08:38:58.913076
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('b', '2')
    print(str(c)) # b=2
    c = Cookie('b', 'v')
    c["max-age"] = '100'
    print(str(c)) # b=v; Max-Age=100
    c["expires"] = datetime.now()
    print(str(c)) # b=v; Max-Age=100; Expires=Mon, 15-Jul-2019 17:52:52 GMT
    c["domain"] = "example.com"
    print(str(c)) # b=v; Max-Age=100; Domain=example.com; Expires=Mon, 15-Jul-2019 17:52:52 GMT
    c["secure"] = True
    c["HttpOnly"] = True
    print(str(c)) # b=v; Max-Age=100

# Generated at 2022-06-12 08:39:08.712675
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie("test_name", "test_value")
    ck["expires"] = datetime(2015, 1, 1)
    ck["path"] = "/test_path"
    ck["secure"] = True
    ck["httponly"] = True
    assert (
        str(ck)
        == "test_name=test_value; expires=Thu, 01-Jan-2015 00:00:00 GMT; "
        + "Path=/test_path; Secure; HttpOnly"
    )


# Generated at 2022-06-12 08:39:11.233820
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cj = CookieJar(headers)
    cookie_name = "password"
    cookie_value = "test"
    cj[cookie_name] = cookie_value
    del cj[cookie_name]
    assert not cj.headers


# Generated at 2022-06-12 08:39:21.474257
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import pytest
    from datetime import datetime

    def test_cookie():
        cookie = Cookie("foo", "bar")
        cookie["max-age"] = 10
        cookie["path"] = "/"
        cookie["expires"] = datetime.fromtimestamp(20)
        cookie["httponly"] = True
        cookie["secure"] = True
        cookie["comment"] = "Test cookie"
        cookie["domain"] = "www.example.com"
        cookie["samesite"] = "Lax"
        assert str(cookie) == "foo=bar; Max-Age=10; Path=/; Expires=Sun, 01-Jan-1970 00:00:20 GMT; Secure; HttpOnly; Domain=www.example.com; Comment=Test cookie; SameSite=Lax"

    test_cookie()

# Generated at 2022-06-12 08:39:28.142741
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    headers.add("Set-Cookie", Cookie(key="key1", value="value1"))
    headers.add("Set-Cookie", Cookie(key="key2", value="value2"))
    headers.add("Set-Cookie", Cookie(key="key3", value="value3"))
    headers.add("Set-Cookie", Cookie(key="key4", value="value4"))
    cookie_jar = CookieJar(headers)
    cookie_jar["key5"] = "value5"
    assert 'key1' in cookie_jar
    assert 'key2' in cookie_jar
    assert 'key3' in cookie_jar
    assert 'key4' in cookie_jar
    assert 'key5' in cookie_jar

    del cookie_jar["key1"]

    assert 'key2'

# Generated at 2022-06-12 08:39:33.492389
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers = headers)
    cookie = Cookie("aaa-bbb-ccc", "123-789-123")
    cookie_jar["aaa-bbb-ccc"] = cookie
    assert headers["Set-Cookie"] == "aaa-bbb-ccc=123-789-123; Path=/", "Failed to add cookie to CookieJar"


# Generated at 2022-06-12 08:39:36.847854
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/; Domain=; SameSite=Lax"



# Generated at 2022-06-12 08:39:43.568446
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('cname','cvalue')
    cookie['comment'] = 'my comment'
    cookie['domain'] = 'example.com'
    cookie['max-age'] = 0
    cookie['path'] = '/'
    cookie['secure'] = True
    cookie['version'] = 1
    cookie['samesite'] = 'lax'
    assert str(cookie) == "cname=cvalue; Comment=my comment; Domain=example.com; Max-Age=0; Path=/; Secure; Version=1; SameSite=lax"

    cookie['httponly'] = True
    assert str(cookie) == "cname=cvalue; Comment=my comment; Domain=example.com; Max-Age=0; Path=/; Secure; HttpOnly; Version=1; SameSite=lax"

# Generated at 2022-06-12 08:39:53.526774
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers.add('Set-Cookie', 'foo=bar')
    headers.add('Set-Cookie', 'foo2=bar2')
    headers.add('Set-Cookie', 'foo3=bar3')
    jar = CookieJar(headers)
    assert len(filter(lambda k: k.startswith('Set-Cookie'), headers.keys())) == 1
    assert len(headers['Set-Cookie']) == 3
    assert jar.headers['Set-Cookie'] == ['foo=bar, foo2=bar2, foo3=bar3']

    del jar['foo']
    assert len(jar.headers['Set-Cookie']) == 2
    assert jar.headers['Set-Cookie'] == ['foo2=bar2, foo3=bar3']

    del jar['foo2']


# Generated at 2022-06-12 08:39:59.491901
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = mock.Mock()
    headers.add = mock.Mock()
    cookieJar = CookieJar(headers)
    cookieJar["testkey"] = "testvalue"
    assert headers.add.call_count == 1
    assert headers.add.call_args[0] == ("Set-Cookie", "testkey=testvalue")
    assert headers.add.call_args[1] == {}
    assert cookieJar["testkey"].value == "testvalue"
    assert cookieJar.headers["Set-Cookie"] == "testkey=testvalue"


# Generated at 2022-06-12 08:40:02.650361
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_str = Cookie('key', 'value').__str__()
    assert cookie_str == "key=value; Max-Age=0"

if __name__ == "__main__":
    test_Cookie___str__()

# Generated at 2022-06-12 08:40:17.345897
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Test the output of Cookie's __str__ method."""
    cookies = {
        "test_number_only": {"value": 5, "max-age": 100},
        "test_number_string": {"value": "5", "max-age": "100"},
        "test_quote_string": {"value": "a b c", "max-age": '"100"'},
        "test_expires": {"value": "5", "expires": datetime.utcnow()},
        "test_encoding": {"value": "5", "path": "/"},
    }
    for name, kwargs in cookies.items():
        cookie = Cookie(name, **kwargs)
        yield assert_equal, cookie.__str__(), "{}={}".format(
            name, kwargs["value"]
        )

# Generated at 2022-06-12 08:40:20.995277
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    input_headers = CIMultiDict()
    input_headers.add("Set-Cookie", "TestName=TestValue; Path=/")

    cookie_jar = CookieJar(input_headers)
    del cookie_jar["TestName"]
    assert not cookie_jar
    assert "TestName" not in input_headers

# Generated at 2022-06-12 08:40:30.142018
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    with pytest.raises(KeyError):
        cookie["expires"] = "tomorrow"
    with pytest.raises(KeyError):
        cookie["fake"] = "value"
    with pytest.raises(ValueError):
        cookie["max-age"] = "one"
    with pytest.raises(TypeError):
        cookie["expires"] = "tomorrow"
    cookie["max-age"] = 1
    cookie["expires"] = datetime.now()
    assert cookie["max-age"] == 1
    assert cookie["expires"] == datetime.now()


# Generated at 2022-06-12 08:40:37.223403
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    assert_raises(KeyError, cookie.__setitem__, "expires", "invalid_value")
    assert_raises(KeyError, cookie.__setitem__, "unknown_key", "invalid_value")
    assert_raises(ValueError, cookie.__setitem__, "max-age", "not_number")
    assert_raises(TypeError, cookie.__setitem__, "expires", "not_date_time")
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    cookie["secure"] = True
    assert cookie["secure"] == True
    cookie["secure"] = False
    assert cookie["secure"] == False



# Generated at 2022-06-12 08:40:46.756089
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print("test_CookieJar___delitem__ called")
    ## Test for case when cookie does not exist in cookie jar
    jar = CookieJar(MultiHeaders())
    jar["test"] = "test_value"
    assert jar["test"] == "test_value"
    del jar["test"]
    assert "test" not in jar
    print("test_CookieJar___delitem__ test 1 passed")
    ## Test for case when cookie exists in cookie jar
    jar = CookieJar(MultiHeaders())
    jar["test"] = "test_value"
    assert jar["test"] == "test_value"
    jar["test2"] = "test_value"
    assert jar["test2"] == "test_value"
    del jar["test"]
    assert "test" not in jar

# Generated at 2022-06-12 08:40:48.736374
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo', 'bar')
    assert str(cookie) == 'foo=bar'



# Generated at 2022-06-12 08:40:57.680589
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert "foo=bar" == str(Cookie("foo", "bar"))
    assert "foo=bar; Domain=bar.com" == str(Cookie("foo", "bar")["domain"])
    assert "foo=bar; HttpOnly" == str(Cookie("foo", "bar")["httponly"])
    assert "foo=bar; secure" == str(Cookie("foo", "bar")["secure"])
    assert "foo=bar; Path=/foo" == str(Cookie("foo", "bar")["path"])
    assert "foo=bar; Version=1" == str(Cookie("foo", "bar")["version"])
    assert "foo=bar; Comment=foo" == str(Cookie("foo", "bar")["comment"])

# Generated at 2022-06-12 08:41:04.614882
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    c["expires"] = datetime(2015, 1, 1)
    c["secure"] = True
    c["comment"] = "baz"
    assert c.__str__() == "foo=bar; expires=Thu, 01-Jan-2015 00:00:00 GMT; Secure; Comment=baz"
    c = Cookie("foo", "bar")
    c["expires"] = datetime(2015, 1, 1)
    c["max-age"] = 60
    c["secure"] = True
    c["comment"] = "baz"
    assert c.__str__() == "foo=bar; expires=Thu, 01-Jan-2015 00:00:00 GMT; Max-Age=60; Secure; Comment=baz"
