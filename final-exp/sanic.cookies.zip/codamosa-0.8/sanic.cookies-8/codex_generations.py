

# Generated at 2022-06-12 08:31:08.477104
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("test", "value")
    c["expires"] = "foo"
    assert c['expires'] == "foo"


# Generated at 2022-06-12 08:31:17.371695
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Testing Set-Cookie header
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["testname"] = "testvalue"
    assert "testname" in cookie_jar.headers["Set-Cookie"]
    assert "testname=testvalue" in cookie_jar.headers["Set-Cookie"]
    assert "testname" not in headers.keys()

    # Testing Cookie header
    headers = MultiHeaderDict(Cookie="testname=testvalue")
    cookie_jar = CookieJar(headers)
    assert "testname" in cookie_jar.headers["Cookie"]


# Generated at 2022-06-12 08:31:27.353486
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('customer-id', '53fdbc')
    cookie['max-age'] = 10
    cookie['domain'] = '.example.com'
    cookie['secure'] = True
    cookie['path'] = '/'
    cookie['comment'] = 'customer_identification_tag'
    cookie['expires'] = datetime.fromtimestamp(1551593600)
    assert str(cookie) == 'customer-id=53fdbc; Max-Age=10; Domain=.example.com; Secure; Path=/; Comment=customer_identification_tag; Expires=Tue, 05-Mar-2019 00:00:00 GMT'

# Generated at 2022-06-12 08:31:32.166501
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    #assert str(cookie) == 'key=value; Path=/'

    cookie["expires"] = datetime.now()
    #assert str(cookie) == 'key=value; expires=' + cookie['expires'].strftime(
    #    '%a, %d-%b-%Y %T GMT') + '; Path=/'



# Generated at 2022-06-12 08:31:40.968200
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 99
    cookie["expires"] = datetime(1999, 12, 31, 23, 59, 59)
    cookie["domain"] = "example.com"
    assert str(cookie) == (
        r"key=value; Max-Age=99; "
        r"Expires=Thu, 31-Dec-1999 23:59:59 GMT; Domain=example.com"
    )



# Generated at 2022-06-12 08:31:45.234036
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie = CookieJar({})
    cookie["name"] = "cookie_name"
    cookie["value"] = "cookie_value"
    assert cookie["name"].value == "cookie_name"
    assert cookie["value"].value == "cookie_value"



# Generated at 2022-06-12 08:31:53.199361
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Unit test for Cookie.__str__
    Tests the following cases:
        1. A cookie with only key and value
        2. A cookie with all possible values
    """
    # Test 1
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    # Test 2
    cookie = Cookie("key", "value")
    cookie["httponly"] = True
    cookie["secure"] = True
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = 10
    cookie["path"] = "path"
    cookie["version"] = "1"
    cookie["samesite"] = "Strict"


# Generated at 2022-06-12 08:31:59.882439
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar({})
    jar["cookie1"] = "test_cookie"
    assert jar.cookie_headers.get("cookie") == "Set-Cookie"
    assert jar["cookie1"].output() == "cookie1=test_cookie; Path=/; Max-Age=0"
    jar["cookie2"] = "test_cookie"
    assert jar.headers["Set-Cookie"] == ", ".join([
        jar["cookie1"].output(),
        jar["cookie2"].output()
    ])
    del jar["cookie1"]
    assert jar.headers["Set-Cookie"] == ", ".join([
        jar["cookie2"].output()
    ])
    del jar["cookie2"]
    assert jar.headers["Set-Cookie"] == ""
    
    

# Generated at 2022-06-12 08:32:08.797140
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test the __str__ method of class Cookie. This test
    will not test the functionality of add, the functionality
    of add is tested in test_add_cookie. This test is only
    testing the functionality of the __str__ method.
    """

    # Create an instance of the class Cookie, with a key and value
    c = Cookie("key", "value")

    # Create an expected output from a combination of the key, value, and
    # the set-cookie header
    exp = "Set-Cookie: key=value"

    # Check that the output of __str__ matches the expected output
    # if they are not equal, assert that they are equal
    if str(c) != exp:
        assert str(c) == exp


# Generated at 2022-06-12 08:32:19.923253
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """ Test __str__ of Cookie. """
    cookie = Cookie("my_cookie", "my_value")

    assert str(cookie) == "my_cookie=my_value"

    cookie["expires"] = datetime(2017, 7, 14, 0, 0, 0)
    cookie["samesite"] = "Lax"
    cookie["path"] = "/"
    cookie["httponly"] = True

    assert (
        str(cookie)
        == "my_cookie=my_value; SameSite=Lax; HttpOnly; Path=/; expires=Thu, 13-Jul-2017 20:00:00 GMT"
    )

    cookie["expires"] = datetime(2017, 7, 14, 0, 0, 0)
    cookie["samesite"] = "Lax"
    cookie["path"] = "/"

# Generated at 2022-06-12 08:32:26.717214
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar(Headers())
    cookie_jar["cookie-1"] = "val-1"
    assert cookie_jar["cookie-1"].value == "val-1"
    del cookie_jar["cookie-1"]
    assert len(cookie_jar) == 0
    assert "cookie-1" not in cookie_jar


# Generated at 2022-06-12 08:32:32.806421
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__(): 
    headers = MultiDict()
    jar = CookieJar(headers)
    del jar
    assert headers == {}, "Deletion of cookie jar object did not remove all headers"
    jar = CookieJar(headers)
    # Test delete before set
    jar["key"] = "value"
    assert headers.getlist("Set-Cookie")[0] == "key=value", "Setting key-value pair did not work"
    jar.__delitem__("key")
    assert len(headers.getlist("Set-Cookie")) == 0, "Deletion of key-value pair failed"
    assert len(jar) == 0, "Cookie jar not empty after deletion"
    jar["key"] = "value"

# Generated at 2022-06-12 08:32:39.781644
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    for key, value in (
        ("key", "value"),
        ("key", "value;"),
        ("key", "value\x7f"),
        (
            "key",
            "value 123456789012345678901234567890123456789012345678901234567890",
        ),
    ):
        cookie = Cookie(key, value)
        assert str(cookie) == "%s=%s" % (
            key,
            _quote(value),
        )



# Generated at 2022-06-12 08:32:47.407982
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie["expires"] = datetime(2016, 1, 1)
    assert str(cookie) == "foo=bar; Expires=Fri, 01-Jan-2016 00:00:00 GMT"
    cookie["secure"] = True
    assert str(cookie) == "foo=bar; Expires=Fri, 01-Jan-2016 00:00:00 GMT; Secure"
    cookie["httponly"] = True
    assert str(
        cookie
    ) == "foo=bar; Expires=Fri, 01-Jan-2016 00:00:00 GMT; Secure; HttpOnly"



# Generated at 2022-06-12 08:32:50.977397
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_keys = ["expires", "path", "comment", "domain", "max-age", "version"]
    test_flags = ["secure", "httponly"]
    test_expires = {"expires": datetime(2020, 1, 1, 0, 0, 0)}
    test_expires_header_value = "expires=Wed, 01-Jan-2020 00:00:00 GMT"
    test_max_age = {"max-age": DEFAULT_MAX_AGE}
    test_max_age_header_value = "max-age=0"
    test_secure = {"secure": True}
    test_secure_header_value = "secure"
    test_key = "test_key"
    test_value = "test_value"
    test_httponly = {"httponly": True}
    test_httponly_

# Generated at 2022-06-12 08:32:53.890019
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "name"
    value = "foo"
    cookie = Cookie(key, value)
    expected = f"{key}={value}"
    actual = str(cookie)
    assert expected == actual


# Generated at 2022-06-12 08:33:02.232280
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-12 08:33:13.213336
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)

    # Test Delete New Cookie
    cookiejar['test'] = 'test_value'
    assert headers[0] == 'Set-Cookie: test=test_value; Path=/'
    del cookiejar['test']
    assert headers[0] == 'Set-Cookie: test=; Path=/; Max-Age=0'
    assert 'test' not in cookiejar

    # Test Delete Existing Cookie
    cookiejar['test'] = 'test_value'
    assert headers[0] == 'Set-Cookie: test=test_value; Path=/'
    cookiejar['test2'] = 'test_value'
    assert 'Set-Cookie: test=test_value; Path=/' in headers

# Generated at 2022-06-12 08:33:19.773866
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo', 'bar')
    assert str(cookie) == "foo=bar"
    cookie['max-age'] = 12345
    assert str(cookie) == 'foo=bar; Max-Age=12345'
    cookie['path'] = '/'
    assert str(cookie) == 'foo=bar; Max-Age=12345; Path=/'



# Generated at 2022-06-12 08:33:22.771403
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == 'key=value'

if __name__ == "__main__":
    import pytest

    pytest.main(["test.py"])

# Generated at 2022-06-12 08:33:30.626173
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Arrange
    headers = Headers()
    jar = CookieJar(headers)

    # Act
    jar["key"] = "value"

    # Assert
    assert "Set-Cookie" in headers
    assert "key=value" in headers["Set-Cookie"]
    assert "key" in jar
    assert jar["key"].value == "value"


# Generated at 2022-06-12 08:33:41.918664
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from starlette.datastructures import Headers
    jar = CookieJar(Headers({}))
    jar["expired"] = "-5"
    jar["teacher"] = "Jenkins"
    jar["theme"] = "star"
    jar["expired"]
    # assert jar.headers == Headers({
    #     "Set-Cookie": ["expired=-5", "teacher=Jenkins", "theme=star"]
    # })
    del jar["expired"]
    # assert jar.headers == Headers({
    #     "Set-Cookie": ["teacher=Jenkins", "theme=star"]
    # })


if __name__ == "__main__":
    test_CookieJar___delitem__()

# Generated at 2022-06-12 08:33:46.962307
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    print(c.items())
    print(c)

    c['path'] = "/"
    c['expires'] = datetime.utcnow()
    print(c.items())
    print(c)

    c['secure'] = True
    c['httponly'] = True
    print(c.items())
    print(c)


# ------------------------------------------------------------ #
#  Main CookieJar
# ------------------------------------------------------------ #


# Generated at 2022-06-12 08:33:55.574920
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test for method str
    cookie = Cookie("name", "value")
    expected = "name=value"
    assert str(cookie) == expected

    cookie["path"] = "/"
    expected = "name=value; Path=/"
    assert str(cookie) == expected

    cookie["domain"] = "example.com"
    expected = "name=value; Path=/; Domain=example.com"
    assert str(cookie) == expected

    cookie["domain"] = "example.com"
    expected = "name=value; Path=/; Domain=example.com"
    assert str(cookie) == expected

    cookie["max-age"] = "3600"
    expected = "name=value; Path=/; Domain=example.com; Max-Age=3600"
    assert str(cookie) == expected

    cookie["secure"] = True


# Generated at 2022-06-12 08:34:03.378888
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 60
    assert cookie["max-age"] == 60
    with pytest.raises(KeyError):
        cookie["unknow"] = 60

    with pytest.raises(ValueError):
        cookie["max-age"] = "ttt"

    with pytest.raises(TypeError):
        cookie["expires"] = 10086


# Generated at 2022-06-12 08:34:11.294211
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from multidict import MultiDict, CIMultiDict
    from multidict._compat import Mapping, MutableMapping

    headers = MultiDict()
    headers.add("Set-Cookie", "foo=bar; path=/")
    cookie_jar = CookieJar(headers)
    assert isinstance(cookie_jar, Mapping)
    assert isinstance(cookie_jar, MutableMapping)

    # Test for updating an existing cookie

    assert cookie_jar["foo"].value == "bar"
    cookie_jar["foo"] = "cheese"
    assert "foo" in cookie_jar
    assert cookie_jar["foo"].value == "cheese"
    assert cookie_jar.headers["Set-Cookie"] == "foo=cheese; path=/"

    # Test for adding a new cookie

    cookie_

# Generated at 2022-06-12 08:34:15.083355
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar({})
    cj['test'] = 'test'
    cj['test2'] = 'test2'
    del cj['test']

    # delitem must delete one key
    assert len(cj) == 1



# Generated at 2022-06-12 08:34:24.371183
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {
        "Set-Cookie": "name=value",
        "Set-Cookie": "name2=value2"
    }
    jar = CookieJar(headers)
    jar["name"] = "value"
    jar["name2"] = "value2"
    assert jar.headers["Set-Cookie"][0] == "name=value"
    assert jar.headers["Set-Cookie"][1] == "name2=value2"
    assert jar.cookie_headers["name"] == "Set-Cookie"
    assert jar.cookie_headers["name2"] == "Set-Cookie"
    assert jar["name"] == "value"
    assert jar["name2"] == "value2"


# Generated at 2022-06-12 08:34:26.396820
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    Cookie("key", "value")["key"] = "value" # should not raise KeyError


# Generated at 2022-06-12 08:34:31.445795
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    # cookies["key"] = "value"
    # assert "key" not in cookies.keys()
    # assert "Set-Cookie" in headers.headers.keys()
    # cookies["item"] = "value"
    # assert cookies["item"] == "value"
    # assert "item" in cookies.keys()

# Generated at 2022-06-12 08:34:48.613162
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    config_set({"http_cookie_secure": False})
    c = Cookie(key="test", value="testing")
    assert str(c) == "test=testing"

    c = Cookie(key="test", value="testing")
    c["Max-Age"] = 30
    assert str(c) == "test=testing; Max-Age=30"

    c = Cookie(key="test", value="testing")
    c["expires"] = datetime(year=2020, month=1, day=1, hour=0, minute=0, second=0)
    assert str(c) == "test=testing; expires=Wed, 01-Jan-2020 00:00:00 GMT"

    c = Cookie(key="test", value="testing")
    c["secure"] = True
    assert str(c) == "test=testing; Secure"

# Generated at 2022-06-12 08:34:57.414180
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("cookie", "Chocolate Chip")
    assert(str(cookie) == "cookie=Chocolate Chip")
    cookie = Cookie("cookie", "Chocolate Chip")
    cookie["secure"] = True
    assert(str(cookie) == "cookie=Chocolate Chip; Secure")
    cookie = Cookie("cookie", "Chocolate Chip")
    cookie["secure"] = True
    cookie["domain"] = "localhost.localdomain"
    assert(str(cookie) == "cookie=Chocolate Chip; Secure; Domain=localhost.localdomain")
    cookie = Cookie("cookie", "Chocolate Chip")
    cookie["secure"] = True
    cookie["domain"] = "localhost.localdomain"
    cookie["expires"] = datetime.now()

# Generated at 2022-06-12 08:35:05.119186
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "key=value; Max-Age=0"
    cookie["version"] = 1
    assert str(cookie) == "key=value; Max-Age=0; Version=1"
    cookie = Cookie("key", "value")
    cookie["max-age"] = -1
    assert str(cookie) == "key=value; Max-Age=-1"
    assert str(Cookie("key", "value")) == "key=value"

# Generated at 2022-06-12 08:35:09.394293
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Starlette.injector.headers
    jar = CookieJar(headers)
    jar['foo'] = 'bar'
    jar['foo'] = 'qux'
    jar['baz'] = 'qux'
    assert headers.getall('Set-Cookie') == ['foo=qux', 'baz=qux']



# Generated at 2022-06-12 08:35:13.078921
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar['name'] = 'John'
    assert cookie_jar['name'].value == 'John'
    del cookie_jar['name']
    assert not cookie_jar['name'].value


# Generated at 2022-06-12 08:35:22.326117
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie["path"] = "/"
    cookie["expires"] = datetime(year=2014, month=10, day=11)
    cookie["comment"] = "also a value"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    assert str(cookie) == "name=value; expires=Sun, 11-Oct-2014 00:00:00 GMT; Path=/; Comment=also a value; Secure; HttpOnly"

    cookie = Cookie("name", "value")
    cookie["max-age"] = "max-age"
    assert str(cookie) == "name=value; Max-Age=max-age"

    cookie = Cookie("name", "value")

# Generated at 2022-06-12 08:35:31.447976
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)

    # Scenario 1: key not in cookie_headers.
    # Expected result:
    # 1. Call CookieJar.__setitem__ with key, "". 
    # 2. Call Super.__setitem__
    # 3. Set key's item's max-age.
    # 4. Call Super.__delitem__
    # 5. Return Super.__delitem__
    with pytest.raises(KeyError):
        cookie_jar["key_not_in_cookie_headers"]

    cookie_jar["key_not_in_cookie_headers"] = "value_not_in_cookie_headers"

    assert cookie_jar["key_not_in_cookie_headers"] == "value_not_in_cookie_headers"
    assert cookie_

# Generated at 2022-06-12 08:35:35.277245
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    import pytest
    from quart.wrappers import Headers
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_name"] = "test_val"
    cookie_jar["test_name2"] = "test_val2"
    del cookie_jar["test_name"]
    assert cookie_jar == {}
    assert str(headers) == 'Set-Cookie: test_name2=test_val2; Path=/; Max-Age=0'

# Generated at 2022-06-12 08:35:44.701650
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {"Set-Cookie": ""}
    cookie_jar_obj = CookieJar(headers)
    cookie_header = "Set-Cookie"
    cookie_obj = Cookie("test", "test")
    cookie_obj["path"] = "/"
    cookie_obj["version"] = "0"
    cookie_str = cookie_obj.__str__()
    cookie_jar_obj.headers.add(cookie_header, cookie_str)
    cookie_jar_obj.cookie_headers["test"] = cookie_header
    cookie_jar_obj.__delitem__("test")
    if not "test" in cookie_jar_obj.cookie_headers:
        print("test_CookieJar___delitem__ : FAIL")
    else:
        print("test_CookieJar___delitem__ : PASS")

# Unit test

# Generated at 2022-06-12 08:35:52.734552
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    c = CookieJar({})
    c["b"] = "a"
    assert c.headers['Set-Cookie'] == 'b=a; Path=/'
    assert c.cookie_headers == {'b':'Set-Cookie'}
    assert c["b"]["path"] == "/"
    assert c["b"]["max-age"] == "0"
    assert c["b"].value == "a"
    assert c.keys() == ["b"]
    assert c.values() == ['a']
    assert c.items() == [('b', 'a')]
    assert c.get('b') == "a"
    c['b'] = 'b'
    assert c['b'] == 'b'
    assert c.get('b') == "b"

# Generated at 2022-06-12 08:36:02.592767
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = mock.Mock()
    jar = CookieJar(headers)
    jar["test1"] = "hello"
    jar["test1"] = "world"
    assert jar["test1"].value == "world"

    # Delete the cookie
    del jar["test1"]
    assert not jar

    # Delete a cookie that doesn't exist
    del jar["test2"]
    assert not jar

# Generated at 2022-06-12 08:36:08.550549
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multidict import MultiDict

    headers = MultiDict([("Set-Cookie", "foo=bar"), ("Set-Cookie", "bar=baz")])
    cookies: CookieJar = CookieJar(headers)

    assert len(cookies) == 2
    assert "foo" in cookies
    assert "bar" in cookies
    assert cookies.get("foo").value == "bar"
    assert cookies.get("bar").value == "baz"

    del cookies["foo"]

    assert len(cookies) == 1
    assert "foo" not in cookies
    assert "bar" in cookies
    assert cookies.get("bar").value == "baz"



# Generated at 2022-06-12 08:36:14.246652
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict({})
    headers.add('Set-Cookie', 'key1=value1')
    headers.add('Set-Cookie', 'key2=value2')
    cookiejar = CookieJar(headers)
    del cookiejar['key1']
    assert 'key1' not in headers
    assert headers._list == [('Set-Cookie', 'key2=value2')]


# Generated at 2022-06-12 08:36:21.965828
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["b"] = "bar"
    cookies["c"] = ""

    # test method deletion as an escape for setting max-age=0
    del cookies["c"]
    assert "Set-Cookie" not in headers

    # test deletion for a cookie with attributes
    del cookies["b"]
    assert "Set-Cookie: b=deleted; Max-Age=0" in headers
    # cookies exist in the backend
    assert "b" in cookies



# Generated at 2022-06-12 08:36:29.539731
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cj = CookieJar(headers)
    cj["a"] = "b"
    cj["c"] = "d"
    cj["e"] = "f"
    assert cj["c"].value == "d"
    assert "c=d" in headers["Set-Cookie"]
    del cj["c"]
    assert len(headers["Set-Cookie"]) == 2
    assert "a=b" in headers["Set-Cookie"]
    assert "e=f" in headers["Set-Cookie"]
    assert headers["Set-Cookie"][0] == "a=b"
    assert headers["Set-Cookie"][1] == "e=f"
    with pytest.raises(KeyError):
        del cj["c"]


# ------------------------------------------------------------ #

# Generated at 2022-06-12 08:36:37.084493
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar()

    # Case 1: Deleting a cookie that does not exist
    cookies["test_key"] = "test_value"
    assert cookies["test_key"] == "test_value"
    del cookies["test_key"]
    assert "test_key" not in cookies
    assert cookies == {}

    # Case 2: Deleting a cookie that does exist
    cookies["test_key"] = "test_value"
    assert cookies["test_key"] == "test_value"
    del cookies["test_key"]
    assert "test_key" not in cookies
    assert cookies == {}


# Generated at 2022-06-12 08:36:46.361915
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    cookie = Cookie("key", "val")

    cookie["max-age"] = 20
    assert str(cookie) == 'key=val; Max-Age=20'

    cookie["expires"] = datetime(2019, 1, 1)
    assert str(cookie) == 'key=val; Max-Age=20; Expires=Tue, 01-Jan-2019 00:00:00 GMT'

    cookie["secure"] = True
    assert str(cookie) == 'key=val; Max-Age=20; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure'

    cookie["httponly"] = True
    assert str(cookie) == 'key=val; Max-Age=20; Expires=Tue, 01-Jan-2019 00:00:00 GMT; Secure; HttpOnly'

   

# Generated at 2022-06-12 08:36:54.176043
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    CookieJar1 = CookieJar(headers)
    CookieJar1["a"] = "b"
    assert headers.to_wsgi_list() == [('Set-Cookie', 'a=b; Path=/')]
    assert CookieJar1 == {"a": Cookie(key="a", value="b")}
    del CookieJar1["a"]
    assert headers.to_wsgi_list() == [('Set-Cookie', 'a=b; Path=/; Max-Age=0')]
    assert CookieJar1 == {}



# Generated at 2022-06-12 08:36:58.332507
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = HTTPHeaders()
    jar = CookieJar(headers)

    jar['1'] = '1'
    assert 'Set-Cookie' in headers
    assert '1=1' in headers['Set-Cookie'][0]

    del jar['1']
    assert 'Set-Cookie' not in headers



# Generated at 2022-06-12 08:37:06.686204
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key1", "value1")
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = False
    cookie["httponly"] = False
    cookie["samesite"] = "Strict"
    cookie["expires"] = datetime(year=2017, month=12, day=20, hour=21, minute=18)
    cookie["path"] = "a"
    cookie["comment"] = "b"
    cookie["domain"] = "c"
    cookie["version"] = 1
    assert str(cookie) == "key1=value1"


# Generated at 2022-06-12 08:37:21.307834
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    expected_cookie = {
        "expires": None,
        "path": None,
        "comment": None,
        "domain": None,
        "max-age": None,
        "secure": False,
        "httponly": False,
        "version": None,
    }
    assert_equal(cookie, expected_cookie)
    cookie.expires = "date"
    cookie.path = "path"
    cookie.comment = "comment"
    cookie.domain = "domain"
    cookie.max_age = "max-age"
    cookie.secure = "secure"
    cookie.httponly = "httponly"
    cookie.version = "version"

# Generated at 2022-06-12 08:37:24.480484
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    c = CookieJar(MultiHeader())
    c["test"]= "nico"
    print(c.headers)
    del c["test"]
    assert c.headers
    print(c.headers)


# Generated at 2022-06-12 08:37:27.504796
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_key = "cookie_abc_key"
    cookie_value = "cookie_abc_value"
    cookie = Cookie(cookie_key, cookie_value)
    assert str(cookie) == f'{cookie_key}=cookie_abc_value'



# Generated at 2022-06-12 08:37:33.477654
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cj = CookieJar(headers)
    cj['foo'] = 'bar'
    del cj['foo']
    assert headers.get(cj.header_key, None) == None
    cj['foo'] = 'bar'
    assert headers[cj.header_key] == 'foo=bar; Path=/'

# Generated at 2022-06-12 08:37:35.713297
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('token', 'this_is_a_cookie')
    assert str(c) == 'token=this_is_a_cookie'



# Generated at 2022-06-12 08:37:41.104653
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookiejar = CookieJar(headers)

    # test deleting non-existing cookie 
    cookiejar["test"] = None
    cookiejar["test"] = "test"
    del cookiejar["test"]

    # test deleting existing cookie 
    cookiejar["test"] = None
    for i in range(2):
        cookiejar["test"] = "test"+str(i)
    del cookiejar["test"]



# Generated at 2022-06-12 08:37:48.801772
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    expect = Headers()

    cookieJar = CookieJar(headers)
    cookieJar["key"] = "value"
    cookieJar["key2"] = "value2"
    cookieJar["key3"] = "value3"

    cookieJar.__delitem__("key")
    expect.set("Set-Cookie", "key2=value2; Path=/;")
    expect.set("Set-Cookie", "key3=value3; Path=/;")

    assert expect == headers

# Generated at 2022-06-12 08:37:59.135949
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo', 'bar')

    assert str(cookie) == 'foo=bar'

    cookie = Cookie('foo', 'bar')
    cookie['expires'] = datetime(2020, 1, 31, 15, 50, 12)

    assert str(cookie) == 'foo=bar; Expires=Fri, 31-Jan-2020 15:50:12 GMT'

    cookie = Cookie('foo', 'bar')
    cookie['max-age'] = '100'

    assert str(cookie) == 'foo=bar; Max-Age=100'

    cookie = Cookie('foo', 'bar')
    cookie['secure'] = True

    assert str(cookie) == 'foo=bar; Secure'

    cookie = Cookie('foo', 'bar')
    cookie['httponly'] = True


# Generated at 2022-06-12 08:38:05.777245
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Unit test for method __str__ of class Cookie
    """
    aCookie = Cookie('some_key', 'some_value')
    assert aCookie.__str__() == "some_key=some_value"

    aCookie['domain'] = 'some_domain'
    assert aCookie.__str__() == "some_key=some_value; Domain=some_domain"


# Generated at 2022-06-12 08:38:08.611627
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multidict import MultiDictProxy
    headers = MultiDictProxy({})
    CookieJar(headers)['CookieJarTest'] = '1337'
    assert 'CookieJarTest' in headers
    del headers['CookieJarTest']
    assert 'CookieJarTest' not in headers

# Generated at 2022-06-12 08:38:21.094227
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_dict = dict()
    headers = Headers(headers_dict)
    cookie_jar = CookieJar(headers)
    i = 0
    while(i < 10):
        cookie_jar[str(i)] = str(i)
        i += 1
    del cookie_jar["5"]
    del cookie_jar["0"]
    assert headers_dict['headers']['Set-Cookie'] == ['0=0; Max-Age=0', '5=5; Max-Age=0']

# Generated at 2022-06-12 08:38:30.789714
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test normal functioning
    c = Cookie('name', 'value')
    assert str(c) == 'name=value'

    c = Cookie('name', 'value')
    c['max-age'] = 123
    c['expires'] = datetime(2010, 1, 12, 12, 12, 12)
    c['path'] = '/'
    c['comment'] = 'this is a comment'
    c['httponly'] = True
    c['secure'] = True
    c['samesite'] = 'strict'
    c['version'] = '0'
    assert str(c) == 'name=value; expires=Mon, 12-Jan-2010 12:12:12 GMT; Path=/; Comment=this is a comment; HttpOnly; Secure; SameSite=strict; Version=0; Max-Age=123'

    #

# Generated at 2022-06-12 08:38:32.998066
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('foo', 'bar')
    cookie['expires'] = 'hello'
    assert cookie['expires'] == 'hello'



# Generated at 2022-06-12 08:38:39.341681
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_headers = MultiHeaderDict()
    test_CookieJar = CookieJar(test_headers)
    test_CookieJar['a'] = 'b'
    test_CookieJar['c'] = 'd'
    del test_CookieJar['a']
    assert test_headers['Set-Cookie'] == "c=d; Path=/; Max-Age=0"


# Generated at 2022-06-12 08:38:41.807360
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo","bar")
    cookie["Path"] = "/"
    assert str(cookie) == "foo=bar; Path=/"


# Generated at 2022-06-12 08:38:52.169208
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Verify that Cookie.__str__ returns the expected output"""
    cookie = Cookie("test_cookie", "this is a test cookie")
    assert (str(cookie) == "test_cookie=this is a test cookie")
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    expected = (
        "test_cookie=this is a test cookie; "
        "Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    )
    assert (str(cookie) == expected)
    cookie["httponly"] = True
    expected = (
        "test_cookie=this is a test cookie; HttpOnly; "
        "Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    )
    assert (str(cookie) == expected)

# Generated at 2022-06-12 08:38:59.189617
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('f1', 'v1')
    cookie['expires'] = datetime(year=2030, month=4, day=4, hour=10, minute=10, second=10)
    cookie['path'] = '/'
    cookie['comment'] = 'test'
    cookie['domain'] = 'test.com'
    cookie['max-age'] = 60
    cookie['secure'] = True
    cookie['httponly'] = True
    cookie['version'] = '1.0'
    cookie['samesite'] = 'None'
    assert str(cookie) == 'f1=v1; expires=Thu, 04-Apr-2030 10:10:10 GMT; Path=/; Comment=test; Domain=test.com; Max-Age=60; Secure; HttpOnly; Version=1.0; SameSite=None'



# Generated at 2022-06-12 08:39:02.131974
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj["foo"] = "bar"
    assert cj["foo"] == "bar"
    del cj["foo"]
    assert "foo" not in cj


# Generated at 2022-06-12 08:39:11.282211
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    error_message = "Cookie name is a reserved word"
    try:
        x = Cookie("expires", "")
        assert 1 == 2
    except KeyError as e:
        assert e.__str__() == error_message

    error_message = "Cookie key contains illegal characters"
    try:
        x = Cookie("@expire", "")
        assert 1 == 2
    except KeyError as e:
        assert e.__str__() == error_message

    error_message = "Unknown cookie property"
    try:
        x = Cookie("expire", "")
        x["@expire"] = ""
        assert 1 == 2
    except KeyError as e:
        assert e.__str__() == error_message

    error_message = "Cookie 'expires' property must be a datetime"

# Generated at 2022-06-12 08:39:14.997894
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Given
    cookie = Cookie("name", "value")
    expected_output = "name=value"
    # When
    actual_output = str(cookie)
    # Then
    assert actual_output == expected_output



# Generated at 2022-06-12 08:39:24.558033
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar["session"] = "fa6f9d9d7085d95f175ee749e09d0ec6"
    assert "session" in cookie_jar
    cookie_jar.__delitem__("session")
    assert "session" not in cookie_jar

# Generated at 2022-06-12 08:39:33.610122
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert str(Cookie("test", "value1")) == "test=value1"
    assert str(Cookie("", "value1")) == "=\"value1\""
    assert str(Cookie("", "\"value1")) == "=\"\\\"value1\""
    assert str(Cookie("test", "value1\"")) == "test=\"value1\\\"\""
    assert str(Cookie("test", "")) == "test="
    assert str(Cookie("test", " ")) == "test= "
    assert str(Cookie("test", "; ")) == "test=\"; \""
    assert str(Cookie("test", "\" ")) == "test=\"\\\" \""
    assert str(Cookie("test", "\";")) == "test=\"\\\";\""

# Generated at 2022-06-12 08:39:36.666666
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({})
    assert cookie_jar.headers == {}
    cookie_jar.headers = {}
    cookie_jar["key"] = "value"
    assert cookie_jar.headers == {'Set-Cookie': 'key=value'}


# Generated at 2022-06-12 08:39:43.701811
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multidict import MultiDictProxy
    _headers = MultiDictProxy()
    _cookie_headers = {}
    _header_key = "Set-Cookie"
    _cookie_header = "Set-Cookie"
    _key = "test_key"
    _value = "test_value"
    _cookie_index = 0
    _cookie = Cookie(_key, _value)

    # init a CookieJar object
    cookie_jar = CookieJar(_headers)
    cookie_jar.cookie_headers = _cookie_headers
    cookie_jar.header_key = _header_key

    # set the key and value to the CookieJar
    cookie_jar[_key] = _value
    # assign all of the cookie_headers, headers, and cookies
    _cookie_headers[_key] = _cookie_header
    _headers.add

# Generated at 2022-06-12 08:39:52.303372
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Tests formatting of 'expires' property
    # For more information on how to write unit tests for python:
    # https://docs.python-guide.org/writing/tests/
    # As of writing this we are following python 2.7.15 documentation
    c = Cookie("my_cookie", "my_value")
    c["expires"] = datetime.strptime("Wed, 21 Oct 2015 07:28:00 GMT", "%a, %d %b %Y %H:%M:%S %Z")
    assert c.__str__() == "my_cookie=my_value; Expires=Wed, 21-Oct-2015 07:28:00 GMT"

# Generated at 2022-06-12 08:39:55.302165
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("cookie_key", "cookie_value")
    assert str(cookie) == "cookie_key=cookie_value", "Cookie str is broken"

# ------------------------------------------------------------ #
#  Response
# ------------------------------------------------------------ #



# Generated at 2022-06-12 08:40:00.834093
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers.add("Set-Cookie", "cookie1=value1; max-age=1; HttpOnly")
    headers.add("Set-Cookie", "cookie2=value2; max-age=1; HttpOnly")
    headers.add("Set-Cookie", "cookie3=value3; max-age=1; HttpOnly")
    cookiejar = CookieJar(headers)
    del cookiejar["cookie2"]
    assert cookiejar == {"cookie1": "value1", "cookie3": "value3"}

# Generated at 2022-06-12 08:40:05.637024
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie('mykey', 'myvalue')
    ck['path'] = "/abc"
    ck['expires'] = datetime.utcnow()
    assert ck.__str__() == 'mykey=myvalue; Path=/abc; expires={}'.format(
        ck['expires'].strftime("%a, %d-%b-%Y %T GMT")
    )

# Generated at 2022-06-12 08:40:15.624924
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    header = headers.Headers()
    jar = CookieJar(header)
    jar["key1"] = "value1"
    assert header["Set-Cookie"] == "key1=value1; Path=/; HttpOnly"
    jar["key2"] = "value2"
    assert header["Set-Cookie"] == "key1=value1; Path=/; HttpOnly, key2=value2; Path=/; HttpOnly"
    jar["key2"] = "value2.1"
    assert header["Set-Cookie"] == "key1=value1; Path=/; HttpOnly, key2=value2.1; Path=/; HttpOnly"
    del jar["key2"]

# Generated at 2022-06-12 08:40:25.613217
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_dict = {
        "key1": "value1",
        "key2": "value2",
        "key3": "value3",
        "key4": "value4",
        "key5": "value5",
    }
    cookie_header = "Set-Cookie"
    headers = {
        cookie_header: [
            Cookie("key1", "value1"),
            Cookie("key2", "value2"),
            Cookie("key3", "value3"),
            Cookie("key4", "value4"),
            Cookie("key5", "value5"),
        ]
    }
    cookie_jar = CookieJar(headers)
    for key, value in cookie_dict.items():
        cookie_jar[key] = value
    del cookie_jar['key2']
    del cookie_jar['key5']


# Generated at 2022-06-12 08:40:37.927569
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('key','value')
    assert dict(c) == {}
    c['path'] = '/'
    assert dict(c) == {'path': '/'}
    assert c['path'] == '/'
    c['max-age'] = 30
    assert dict(c) == {'max-age': 30, 'path': '/'}
    c['expires'] = datetime(year=2019, month=1, day=1)
    assert dict(c) == {'expires': datetime(year=2019, month=1, day=1), 'max-age': 30, 'path': '/'}
    assert str(c) == 'key=value; Path=/; Max-Age=30; expires=Tue, 01-Jan-2019 00:00:00 GMT'


# Generated at 2022-06-12 08:40:47.357162
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Set up the variables
    key = "ckey"
    value = "cvalue"
    domain = "www.example.com"
    path = "/"
    max_age = DEFAULT_MAX_AGE
    expires = datetime(2030, 1, 1)
    httponly = False

    # Create the cookie
    cookie = Cookie(key, value)
    cookie["domain"] = domain
    cookie["path"] = path
    cookie["max-age"] = max_age
    cookie["expires"] = expires
    cookie["httponly"] = httponly

    # Get the expected string
    expected_list = ["%s=%s" % (key, _quote(value))]
    expected_list.append("%s=%s" % (Cookie._keys["domain"], domain))

# Generated at 2022-06-12 08:40:56.640862
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    input_headers = Headers(
        {
            "Server": "fake-server-name",
            "Content-Type": "fake-content-type",
            "Date": (
                "fake-date"
            ),  # Date is a reserved header key, so this must be removed
            "user-agent": "fake-user-agent",
            "Cookie": "fake-cookie",
        }
    )

    # test incorrect key
    def empty_headers(headers):
        del headers[:]

    cookie_jar = CookieJar(input_headers)
    assert cookie_jar.headers["Cookie"] == "fake-cookie"
    assert cookie_jar.headers["Date"] == "fake-date"
    assert "fake-cookie" in cookie_jar
    assert "fake-date" not in cookie_jar