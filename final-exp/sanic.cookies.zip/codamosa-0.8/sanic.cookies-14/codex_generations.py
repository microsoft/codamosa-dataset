

# Generated at 2022-06-12 08:31:20.708435
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()

    # Test 1:
    # This tests if we can remove a cookie from our headers
    jar = CookieJar(headers)

    jar["test"] = "test_val"

    # The cookie should be set
    assert "test" in jar.keys()

    # The cookie should be added to headers
    assert headers["set-cookie"] == "test=test_val"

    # Make sure the header is removed
    del jar["test"]
    assert not headers
    assert not jar

    # Test 2:
    # This tests if we try to remove a cookie that doesn't exist
    jar = CookieJar(headers)
    assert not jar
    assert not headers

    try:
        del jar["test"]
        assert False
    except KeyError:
        assert True

    # The cookie should not be added to headers

# Generated at 2022-06-12 08:31:24.935167
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    Test method __delitem__ of class CookieJar
    """
    headers = Headers()
    jar = CookieJar(headers)
    jar['foo'] = 'bar'
    assert headers.get_all('Set-Cookie') == [Cookie('foo', 'bar')]
    del jar['foo']
    assert headers.get_all('Set-Cookie') == [Cookie('foo', '')]

# Generated at 2022-06-12 08:31:28.142366
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Test if Cookie KeyError is raised when 
    key is _keys.
    """
    cookie = Cookie("key", "value")
    try:
        cookie["expires"] = "expires"
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-12 08:31:33.706418
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
   cookie = Cookie("hello", "world")
   assert cookie.__str__() == "hello=world"
   cookie["expires"] = datetime.now()
   assert cookie.__str__().startswith("hello=world; Expires=")
   cookie["max-age"] = "100"
   assert cookie.__str__() == "hello=world; Expires=; Max-Age=100"
   cookie["secure"] = True
   assert cookie.__str__() == "hello=world; Expires=; Max-Age=100; Secure"


# Generated at 2022-06-12 08:31:45.321502
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("test", "123")
    c["max-age"] = 123
    assert c["max-age"] == 123
    c["expires"] = datetime.now()
    assert isinstance(c["expires"], datetime)
    c["max-age"] = "321"
    assert c["max-age"] == 321
    with pytest.raises(ValueError):
        c["max-age"] = "xxx"

    with pytest.raises(KeyError):
        c["abc"] = 123
    with pytest.raises(TypeError):
        c["expires"] = 123
    with pytest.raises(KeyError):
        del c["abc"]


# Generated at 2022-06-12 08:31:51.054083
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "value")
    c["max-age"]=100
    c["expires"]=datetime(2017, 8, 11, 13, 0, 1, 1234)
    c["path"]="/abc"
    c["secure"]="secure"
    c["samesite"]="Lax"
    assert str(c)=="test=value; Max-Age=100; Expires=Fri, 11-Aug-2017 13:00:01 GMT; Path=/abc; Secure; SameSite=Lax"

# Generated at 2022-06-12 08:31:59.121662
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from io import StringIO

    cookie = Cookie("name", "value")
    cookie['Version'] = 0
    cookie['Max-Age'] = 1234
    cookie['Domain'] = ".domain.tld"
    cookie['Path'] = "/path/"
    cookie['Secure'] = True
    cookie['HttpOnly'] = False

    # Test format, without "HttpOnly"
    s = StringIO()
    s.write("Set-Cookie: ")
    s.write("%s=%s" % ('name', 'value'))
    s.write("; Version=%d" % cookie['Version'])
    s.write("; Max-Age=%d" % cookie['Max-Age'])
    s.write("; Domain=%s" % cookie['Domain'])

# Generated at 2022-06-12 08:32:09.100174
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('foo', 'bar')
    c.update({'max-age': 100, 'expires': datetime.utcnow()})
    c.update({'path': '/', 'domain': 'localhost', 'secure': True})
    assert isinstance(c['max-age'], int)
    assert isinstance(c['expires'], datetime)
    assert isinstance(c['path'], str)
    assert isinstance(c['domain'], str)
    assert isinstance(c['secure'], bool)
    assert c.key == 'foo'
    assert c.value == 'bar'
    assert c['max-age'] == 100
    assert c['expires'] != datetime.utcnow()
    assert c['path'] == '/'
    assert c['domain'] == 'localhost'

# Generated at 2022-06-12 08:32:16.747282
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar["fav_color"] = "blue"
    cookie_jar["sessions"] = "123456789"
    assert 'fav_color' in cookie_jar
    assert 'sessions' in cookie_jar
    del cookie_jar['fav_color']
    assert not 'fav_color' in cookie_jar

if __name__ == "__main__":
    test_CookieJar___delitem__()

# Generated at 2022-06-12 08:32:26.677217
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    test_http_headers = {}
    test_http_cookies = CookieJar(test_http_headers)

    test_cookie_name = "test"
    test_cookie_value = "test"

    test_cookie = Cookie(test_cookie_name, test_cookie_value)

    test_http_cookies[test_cookie_name] = test_cookie_value

    assert test_http_cookies.cookie_headers.get(test_cookie_name)
    assert test_http_cookies.headers.get(test_http_cookies.header_key)
    assert test_http_cookies.get(test_cookie_name)
    assert test_http_cookies.get(test_cookie_name) == test_cookie
    assert test_http_cookies[test_cookie_name] == test_cookie

# Generated at 2022-06-12 08:32:36.059409
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # None
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    # Default
    cookie = Cookie("name", "value")
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "name=value; Max-Age=0"

    # Max-Age
    cookie = Cookie("name", "value")
    cookie["max-age"] = 3600
    assert str(cookie) == "name=value; Max-Age=3600"

    # Expires
    cookie = Cookie("name", "value")
    cookie["expires"] = datetime.utcnow()
    assert cookie["expires"] == datetime.utcnow().date()

    # Path
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
   

# Generated at 2022-06-12 08:32:45.695141
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # case 1
    cookie = Cookie('foo', 'bar')
    assert str(cookie) == 'foo=bar'

    # case 2
    cookie = Cookie('foo', 'bar')
    cookie["path"] = "/"
    cookie["comment"] = "ms"
    cookie["domain"] = "localhost"
    cookie["max-age"] = 3600
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"

    expected = 'foo=bar; Path=/; Comment=ms; Domain=localhost; Max-Age=3600; Secure; HttpOnly; Version=1; SameSite=lax'
    assert str(cookie) == expected


# Generated at 2022-06-12 08:32:56.371404
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["expires"] = datetime(2010, 8, 8, 17, 0)
    cookie["path"] = "/"
    cookie["comment"] = "My test cookie"
    cookie["domain"] = "example.com"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"
    assert str(cookie) == "test=value; expires=Mon, 08-Aug-2010 17:00:00 GMT; Path=/; Comment=My test cookie; Domain=example.com; Max-Age=0; Secure; HttpOnly; Version=1; SameSite=Lax"

# Generated at 2022-06-12 08:33:01.344482
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    assert len(headers) == 3

    del cookie_jar["key2"]
    assert len(headers) == 2
    assert not headers.getall("Set-Cookie")
    assert "key2" not in cookie_jar


# Generated at 2022-06-12 08:33:06.134015
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # This test is for delete method of CookieJar
    cj = CookieJar(MultiDict())
    cj["test"] = "test"
    del cj["test"]
    assert cj.get("test") == None


# Generated at 2022-06-12 08:33:15.778717
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "value")
    assert str(c) == "test=value"
    c = Cookie("test", "value")
    c["path"] = "/"
    assert str(c) == "test=value; Path=/"
    c = Cookie("test", "value")
    c["path"] = "/"
    c["max-age"] = 123
    assert str(c) == "test=value; Path=/; Max-Age=123"
    c = Cookie("test", "value")
    c["path"] = "/"
    c["expires"] = datetime(year=2017, month=3, day=7, hour=10, minute=42, second=14)
    assert str(c) == "test=value; Path=/; Expires=Tue, 07-Mar-2017 10:42:14 GMT"

# Generated at 2022-06-12 08:33:26.831738
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "testKey"
    value = 'testValue'
    cookie = Cookie(key, value)
    assert str(cookie) == f"{key}={value}"
    cookie["max-age"] = 10
    assert str(cookie) == f"{key}={value}; Max-Age=10"
    cookie["max-age"] = "10"
    assert str(cookie) == f"{key}={value}; Max-Age=10"
    cookie["expires"] = datetime.fromtimestamp(123456789)
    assert (
        str(cookie)
        == f"{key}={value}; Max-Age=10; expires=Sun, 13-Sep-2009 02:46:29 GMT"
    )
    cookie["secure"] = True

# Generated at 2022-06-12 08:33:36.624780
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "hello")
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["path"] = "/test"
    cookie["version"] = 1
    cookie["comment"] = "test"
    cookie["domain"] = "test"
    cookie["secure"] = True
    cookie["httponly"] = True

    assert str(cookie) == (
        "test=hello; Max-Age=0; expires=%s; Path=/test; "
        "Version=1; Comment=test; Domain=test; Secure; HttpOnly"
        % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")
    )

# Generated at 2022-06-12 08:33:42.500191
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    cookiejar["asdf"] = "qwerty"

    assert "Set-Cookie" in headers
    assert "asdf=qwerty; Path=/; HttpOnly" in headers["Set-Cookie"]
    assert "qwerty" == cookiejar["asdf"].value


# Generated at 2022-06-12 08:33:50.374307
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["max-age"] = ""
    assert cookie["max-age"] == ""
    cookie["expires"] = ""
    assert cookie["expires"] == ""
    cookie["path"] = ""
    assert cookie["path"] == ""
    cookie["comment"] = ""
    assert cookie["comment"] == ""
    cookie["domain"] = ""
    assert cookie["domain"] == ""
    cookie["max-age"] = ""
    assert cookie["max-age"] == ""
    cookie["secure"] = ""
    assert cookie["secure"] == ""
    cookie["httponly"] = ""
    assert cookie["httponly"] == ""
    cookie["version"] = ""
    assert cookie["version"] == ""
    cookie["samesite"] = ""
    assert cookie["samesite"] == ""

#

# Generated at 2022-06-12 08:34:00.941857
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    cookie["expires"] = "2018-05-10"
    cookie["path"] = "/"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = 'testcookie.com'
    cookie["max-age"] = 3600
    cookie["secure"] = "Secure"
    cookie["httponly"] = "HttpOnly"
    cookie["version"] = 1
    cookie["samesite"] = "Lax"

    assert cookie["expires"] == "2018-05-10"
    assert cookie["path"] == "/"
    assert cookie["comment"] == "This is a comment"
    assert cookie["domain"] == 'testcookie.com'
    assert cookie["max-age"] == 3600
    assert cookie["secure"] == "Secure"
    assert cookie["httponly"]

# Generated at 2022-06-12 08:34:07.955962
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
  headers = MultiDict()
  cookies = CookieJar(headers)
  cookies["testing"] = "123"
  cookies["session_id"] = "456"
  cookies["stuff"] = "789"
  assert len(cookies) == 3
  assert headers[cookies.header_key] == 'testing="123"; session_id="456"; stuff="789"'
  del cookies["testing"]
  assert len(cookies) == 2
  assert headers[cookies.header_key] == 'session_id="456"; stuff="789"'


# Generated at 2022-06-12 08:34:17.918226
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers: Dict[str, str] = {}
    cookies = CookieJar(headers)
    foo = Cookie("foo", "foo")
    foo["path"] = "/"

    cookies.headers["Set-Cookies"] += "; " + foo.__str__()
    foo.key = "bar"
    cookies.cookie_headers["foo"] = "Set-Cookies"
    cookies.cookie_headers["bar"] = "Set-Cookies"
    cookies["foo"] = "foo"
    cookies["bar"] = "bar"

    cookies.__delitem__("bar")
    assert not any(cookie.key == "bar" for cookie in cookies)
    assert not any(cookie.key == "bar" for cookie in cookies.values())
    assert not any(cookie.key == "bar" for cookie in cookies.cookie_headers)
   

# Generated at 2022-06-12 08:34:22.805206
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from aiohttp.multidict import MultiDict
    headers = MultiDict()
    jar = CookieJar(headers)
    jar["test"] = "testing"
    assert len(headers) == 1
    assert headers[0] == ("Set-Cookie", 'test="testing"; Path=/')
    del jar["test"]
    assert len(headers) == 0


# Generated at 2022-06-12 08:34:32.756063
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test that deleting a value from the cookie jar removes the cookie from headers
    headers = Headers({"Cookie": "foo=bar"})
    cookies = CookieJar(headers)

    assert "foo" in cookies

    del cookies["foo"]

    assert "foo" not in cookies
    assert headers.get("Set-Cookie") is None

    # Test that deleting a value that doesn't exist just removes it (which adds it with max-age=0)
    headers = Headers({"Cookie": "foo=bar"})
    cookies = CookieJar(headers)

    assert "nonexistent" not in cookies

    del cookies["nonexistent"]

    assert "nonexistent" not in cookies
    assert headers.get("Set-Cookie") is not None
    assert "max-age=0" in headers.get("Set-Cookie")


# Generated at 2022-06-12 08:34:40.281220
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Initialize a headers object
    headers = Headers()
    # Initialize a cookie jar object by passing headers object
    cookie_jar = CookieJar(headers)
    # Add a cookie to the cookie jar with key as "test_key_del" and value
    # as "test_value_del"
    cookie_jar["test_key_del"] = "test_value_del"
    # Check if the length of cookie_jar is equal to 1
    assert len(cookie_jar) == 1, "The length of cookie_jar is not equal to 1"
    # Initialize a cookie using the same key and value
    cookie = Cookie("test_key_del", "test_value_del")
    # Check if the cookie is present in the headers object

# Generated at 2022-06-12 08:34:45.158596
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers({"Set-Cookie": "A=1; Path=/;\n Set-Cookie: B=2; Path=/"})
    cookies = CookieJar(headers)
    del cookies["A"]
    assert headers == Headers({"Set-Cookie": "B=2; Path=/"})


# Generated at 2022-06-12 08:34:55.967451
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookie_name = "test"
    cookie_value = "cookie"
    cookies[cookie_name] = cookie_value

    assert cookie_name in cookies.keys()
    assert cookie_name in cookies.cookie_headers
    assert cookie_name in [cookie.key for cookie in cookies.values()]
    assert cookie_name in [c.value for c in headers.headers[cookies.header_key]]

    assert cookie_name in cookies
    del cookies[cookie_name]
    assert cookie_name not in cookies.keys()
    assert cookie_name not in cookies.cookie_headers
    assert cookie_name not in [cookie.key for cookie in cookies.values()]

# Generated at 2022-06-12 08:34:59.846870
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar["a"] = 1
    cookie_jar["b"] = 2
    del cookie_jar["a"]
    del cookie_jar["b"]

# Generated at 2022-06-12 08:35:10.806212
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "1")
    cookie["max-age"] = DEFAULT_MAX_AGE
    assert str(cookie) == "test=1; Max-Age=0"

    cookie = Cookie("test", "1")
    cookie["expires"] = datetime(1999, 9, 9, 9, 9, 9)
    assert str(cookie) == "test=1; expires=Thu, 09-Sep-1999 09:09:09 GMT"

    cookie = Cookie("test", "1")
    cookie["path"] = "/"
    assert str(cookie) == "test=1; Path=/"

    cookie = Cookie("test", "1")
    cookie["secure"] = True
    assert str(cookie) == "test=1; Secure"

    cookie = Cookie("test", "1")
    cookie["version"] = 1

# Generated at 2022-06-12 08:35:22.655499
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-12 08:35:31.738241
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Make sure Cookie is properly formatting key-value pairs
    """
    c = Cookie('test', 'value')
    assert str(c) == 'test=value'
    c['path'] = '/test'
    assert str(c) == 'test=value; Path=/test'
    c['max-age'] = 10
    assert str(c) == 'test=value; Path=/test; Max-Age=10'
    c['expires'] = datetime(2019, 2, 7, 22, 33, 0)
    assert str(c) == 'test=value; Path=/test; Max-Age=10; Expires=Thu, 07-Feb-2019 22:33:00 GMT'
    c['secure'] = True

# Generated at 2022-06-12 08:35:35.586907
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("name", "value")
    c["path"] = "/"
    c["comment"] = "comment"
    c["domain"] = "domain"
    c["max-age"] = 0
    c["secure"] = True
    c["httponly"] = True
    c["version"] = 1
    c["samesite"] = "lax"
    c["max-age"] = "string"
    c["expires"] = datetime.now()
    return c

# Generated at 2022-06-12 08:35:37.966498
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie("foo", "bar")
    ck["path"] = "/"
    assert str(ck) == "foo=bar; Path=/"



# Generated at 2022-06-12 08:35:44.537078
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # test for default parameters
    cookie_1 = Cookie("key", "value")
    assert "key=value" == cookie_1.__str__()

    # test for max-age, expires and httponly
    cookie_2 = Cookie("key", "value")
    cookie_2["max-age"] = 300
    cookie_2["expires"] = datetime.utcnow()
    cookie_2["httponly"] = True
    assert "key=value; Max-Age=300; Expires=; HttpOnly" == cookie_2.__str__()

# Generated at 2022-06-12 08:35:48.874053
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cj = CookieJar(headers)
    cj['ssss'] = 'ssss'
    assert headers["Set-Cookie"] == 'ssss=ssss'
    del cj['ssss']
    assert header_value(headers["Set-Cookie"]) == 'ssss=""; Max-Age=0'


# Generated at 2022-06-12 08:35:55.184917
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar({})
    cookies["a"] = "a"
    cookies["b"] = "b"
    cookies["c"] = "c"

    del cookies["b"]

    # verify cookie does not exist
    assert cookies.get("b") is None

    # verify header can still be read as a multiple header
    assert cookies.headers.getlist("Set-Cookie") == [
        'a=a; Path=/',
        'c=c; Path=/'
    ]

# Generated at 2022-06-12 08:35:59.479391
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Tests for the class Cookie specifically method __str__
    """
    cookie = Cookie('test', 'test value')
    cookie['max-age'] = 0
    assert str(cookie) == 'test=test%20value; Max-Age=0'

# Generated at 2022-06-12 08:36:08.721221
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="test", value="test")
    assert str(cookie) == "test=test"

    cookie = Cookie(key="test", value="test")
    cookie["expires"] = datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    assert str(cookie).startswith('test=test; Expires=')

    cookie = Cookie(key="test", value="test")
    cookie["path"] = "/"
    assert str(cookie) == "test=test; Path=/"

    cookie = Cookie(key="test", value="test")
    cookie["version"] = "1"
    assert str(cookie) == "test=test; Version=1"

    cookie = Cookie(key="test", value="test")
    cookie["domain"] = "test"

# Generated at 2022-06-12 08:36:09.753195
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert None == None
            

# Generated at 2022-06-12 08:36:23.263124
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    key = "name"
    value = "value"
    cookie_jar[key] = value
    cookie_jar.headers.add("Set-Cookie", Cookie("name1", "value1"))
    cookie_jar.headers.add("Set-Cookie", Cookie("name2", "value2"))
    assert "Set-Cookie" in cookie_jar.headers
    cookie_jar.__delitem__(key)
    assert "Set-Cookie" in cookie_jar.headers
    assert "name1" in cookie_jar.headers["Set-Cookie"]
    assert "name2" in cookie_jar.headers["Set-Cookie"]
    assert key not in cookie_jar.headers["Set-Cookie"]
# ------------------------------------------------------------ #
#  MultiHeader


# Generated at 2022-06-12 08:36:35.216690
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # create a dictionary of headers
    headers = dict()
    headers[
        "Set-Cookie"
    ] = '<div class="js-cookie" style="display: none;"><span class="js-cookie-content"></span><a href="https://www.gov.uk/help/cookies">Find out more about cookies</a></div>'
    headers[
        "Set-Cookie"
    ] += '<div class="js-cookie" style="display: none;"><span class="js-cookie-content"></span><a href="https://www.gov.uk/help/cookies">Find out more about cookies</a></div>'

# Generated at 2022-06-12 08:36:41.438562
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_str = "Color=Blue; Expires=Wed, 26-Jun-2024 13:37:21 GMT; Path=/"
    cookie = Cookie('Color', 'Blue')
    cookie['expires'] = datetime(2024, 6, 26, 13, 37, 21)
    assert str(cookie) == cookie_str

# Generated at 2022-06-12 08:36:48.533124
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie('ckey', 'cvalue')
    assert(str(ck) == 'ckey=cvalue')
    ck['path'] = '/'
    assert(str(ck) == 'ckey=cvalue; Path=/')
    ck['expires'] = datetime(2019, 1, 9, 15, 0, 0, 0)
    assert(str(ck) == 'ckey=cvalue; expires=Wed, 09-Jan-2019 15:00:00 GMT; Path=/')
    ck['secure'] = True
    assert(str(ck) == 'ckey=cvalue; expires=Wed, 09-Jan-2019 15:00:00 GMT; Path=/; Secure')
    ck['comment'] = 'foo'

# Generated at 2022-06-12 08:36:52.362533
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_CookieJar = CookieJar(headers=None)
    test_CookieJar["key_one"] = "value_one"
    del test_CookieJar["key_one"]


# Generated at 2022-06-12 08:37:00.604196
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert c.__str__() == 'name="value"'

    c['Max-Age'] = 123
    assert c.__str__() == 'name="value"; Max-Age=123'

    c['Version'] = 1
    assert c.__str__() == 'name="value"; Max-Age=123; Version=1'

    c['Domain'] = "example.com"
    assert c.__str__() == 'name="value"; Max-Age=123; Version=1; Domain=example.com'

    c['secure'] = True
    assert c.__str__() == 'name="value"; Max-Age=123; Version=1; Domain=example.com; Secure'

    c['Secure'] = False

# Generated at 2022-06-12 08:37:09.921943
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value")
    cookie["max-age"] = 60
    assert str(cookie) == "key=value; Max-Age=60"

    cookie = Cookie("key", "value")
    cookie["max-age"] = "60"
    assert str(cookie) == "key=value; Max-Age=60"

    expires = datetime.utcnow()
    cookie = Cookie("key", "value")
    cookie["expires"] = expires
    assert str(cookie) == \
        "key=value; Expires={}".format(expires.strftime("%a, %d-%b-%Y %T GMT"))

    cookie = Cookie("key", "value")
    cookie["secure"] = True

# Generated at 2022-06-12 08:37:19.165536
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert(cookie.__str__() == 'key=value')

    cookie = Cookie('key', 'value')
    cookie['path'] = '/'
    cookie['comment'] = 'comment'
    cookie['domain'] = 'domain'
    cookie['max-age'] = 100
    cookie['version'] = 1
    cookie['expires'] = datetime(2020, 8, 12, 10, 0, 0)
    cookie['secure'] = False
    cookie['httponly'] = True
    cookie['samesite'] = 'lax'

# Generated at 2022-06-12 08:37:25.075963
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import simple_cookie as SimpleCookie
    simple_cookie = SimpleCookie.SimpleCookie()
    cookie = CookieJar(simple_cookie)
    cookie["key"] = "value"
    s = cookie.headers.values()
    print(s)
    assert len(s) == 1

test_CookieJar___setitem__()

# Generated at 2022-06-12 08:37:36.638427
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Inputs
    h = dict()
    h["Set-Cookie"] = "c1=v1"
    h["Set-Cookie"] = "c2=v2"
    p = CookieJar(h)
    key = "c3"
    value = "v3"
    # Outputs
    o1 = dict()
    o1["c3"] = "v3"
    o1["Set-Cookie"] = ["c1=v1", "c2=v2"]
    o2 = dict()
    o2["c3"] = value
    # Test
    p[key] = value
    if p != o1 and p.headers != o2:
        raise SystemExit("Test case failed!")


# Generated at 2022-06-12 08:37:52.153773
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie["comment"] = "its an important comment"
    assert str(
        cookie
    ) == "name=value; Comment=its an important comment"
    cookie["max-age"] = 3600
    assert str(cookie) == "name=value; Comment=its an important comment; Max-Age=3600"
    cookie["expires"] = datetime(year=2020, month=5, day=5)
    assert str(cookie) == "name=value; Comment=its an important comment; Max-Age=3600; Expires=Tue, 05-May-2020 00:00:00 GMT"
    cookie["secure"]=True

# Generated at 2022-06-12 08:37:59.861435
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from CookieJar import CookieJar
    from multidict import CIMultiDict

    cookies = CookieJar(CIMultiDict())

    cookies['cookie1'] = 'cookie1_value'
    cookies['cookie2'] = 'cookie2_value'
    cookies['cookie3'] = 'cookie3_value'

    assert cookies['cookie1'].value == 'cookie1_value'

    cookies.headers.add('Set-Cookie', 'key=value')
    assert cookies.headers['Set-Cookie'] == 'key=value'


    del cookies['cookie1']

    assert not cookies.headers.get('Set-Cookie')
    assert not cookies.get('cookie1')




# Generated at 2022-06-12 08:38:09.655838
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    class Headers:
        def __init__(self):
            self.headers = {}

        def add(self, key, value):
            if self.headers.get(key):
                self.headers[key].append(value)
            else:
                self.headers[key] = [value]

        def popall(self, key):
            if self.headers.get(key):
                cookies = self.headers.pop(key)
                return cookies

    headers = Headers()
    cookie_jar = CookieJar(headers)

    cookie_jar["test1"] = "test1"
    cookie_jar["test2"] = "test2"

    cookie_jar["test0"] = "test"
    del cookie_jar["test0"]

    cookie_jar["test0"] = "test"
    cookie_jar["test1"]

# Generated at 2022-06-12 08:38:20.048097
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    k1, v1 = "name", "bob"
    c1 = Cookie(k1, v1)
    s1 = str(c1)
    assert (s1 == "name=bob")

    k2, v2 = "name", "bob"
    c2 = Cookie(k2, v2)
    c2["domain"] = ".test"
    s2 = str(c2)
    assert (s2 == "name=bob; Domain=.test")

    k3, v3 = "name", "bob"
    c3 = Cookie(k3, v3)
    c3["path"] = "/"
    c3["domain"] = ".test"
    s3 = str(c3)
    assert (s3 == "name=bob; Path=/; Domain=.test")

   

# Generated at 2022-06-12 08:38:27.235611
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()

    cookies = CookieJar(headers)

    cookies["cookie1"] = "value1"
    assert (cookies["cookie1"] == "value1")

    cookies["cookie2"] = "value2"
    assert (cookies["cookie2"] == "value2")

    del cookies["cookie1"]
    assert (cookies["cookie2"] == "value2")

    # Try deleting cookie that has been deleted
    del cookies["cookie1"]
    assert (cookies["cookie2"] == "value2")

    del cookies["cookie2"]
    # Try getting a deleted cookie
    assert (cookies["cookie2"] == "")

    # Try deleting a cookie that has been deleted
    del cookies["cookie2"]
    assert (cookies["cookie2"] == "")



# Generated at 2022-06-12 08:38:39.095251
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test if the str method of class Cookie works.
    """
    cookie = Cookie("test", "value")
    assert(str(cookie) == "test=value")

    cookie = Cookie("test", "value")
    cookie["max-age"] = 123
    assert(str(cookie) == "test=value; Max-Age=123")

    cookie = Cookie("test", "value")
    cookie["max-age"] = "123"
    assert(str(cookie) == "test=value; Max-Age=123")

    cookie = Cookie("test", "value")
    cookie["max-age"] = "abc"
    assert(str(cookie) == "test=value; Max-Age=abc")

    cookie = Cookie("test", "value")

# Generated at 2022-06-12 08:38:49.691553
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import time
    import pytest
    from datetime import datetime
    cookie = Cookie("weeb", "moe")
    cookie["max-age"] = 0
    cookie["expires"] = datetime.utcfromtimestamp(time.time() + 60)
    cookie["path"] = "/"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["comment"] = "WEEB"
    cookie["domain"] = "weeb.moe"
    cookie["version"] = 0
    cookie["samesite"] = "Lax"
    cookie_output = cookie.__str__()
    # print(cookie_output)
    # Weeb=moe; max-age=0; expires=Sat, 12-Oct-2019 08:48:25 GMT; path=/; Secure; HttpOnly; Comment=

# Generated at 2022-06-12 08:38:54.050400
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers([])
    cj = CookieJar(headers)
    cj["name"]="value"
    assert headers.getall("Set-Cookie") == ['name="value"', 'name="value"']
    del cj["name"]
    assert headers.getall("Set-Cookie") == ['name=; Max-Age=0']


# Generated at 2022-06-12 08:39:04.588090
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    import io
    import runpy
    cookiejar = CookieJar()

    cookiejar['asdf'] = 'asdf'
    assert cookiejar['asdf'] == 'asdf'
    assert cookiejar.headers['Set-Cookie'] == 'asdf=asdf; Path=/'

    cookiejar['fdsa'] = 'fdsa'
    assert cookiejar['asdf'] == 'asdf'
    assert cookiejar['fdsa'] == 'fdsa'
    assert cookiejar.headers['Set-Cookie'] == 'asdf=asdf; Path=/\nfdsa=fdsa; Path=/'

    del cookiejar['asdf']
    assert cookiejar['fdsa'] == 'fdsa'
    assert cookiejar.headers['Set-Cookie'] == 'fdsa=fdsa; Path=/'

# Generated at 2022-06-12 08:39:10.020711
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaders()
    cookies = CookieJar(headers)
    cookies["test__delitem__1"] = "exist"
    cookies["test__delitem__2"] = "exist"
    cookies["test__delitem__3"] = "exist"
    del cookies["test__delitem__1"]
    assert "test__delitem__1" not in cookies
    assert "test__delitem__2" in cookies


# Generated at 2022-06-12 08:39:33.679248
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    try:
        cookie["path"] = "/"
        cookie["comment"] = ""
        cookie["domain"] = ""
        cookie["max-age"] = 0
        cookie["secure"] = True
        cookie["httponly"] = True
        cookie["version"] = 1
        cookie["samesite"] = None
    except KeyError:
        raise


# cookie = Cookie('hello', 'world')
# print(cookie)
# c = CookieJar({})
# c.add('hello', 'world')
# print(c)

# Generated at 2022-06-12 08:39:39.377712
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "cookie")
    cookie["path"] = "/"
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    cookie["domain"] = "localhost"
    cookie["version"] = 0
    cookie["SameSite"] = "lax"
    cookie["secure"] = True
    cookie["httponly"] = True

    string = str(cookie)
    assert (
        string
        == 'test=cookie; Path=/; Max-Age=0; expires=%s; Domain=localhost; Version=0; SameSite=lax; Secure; HttpOnly'
        % datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    )



# Generated at 2022-06-12 08:39:48.082329
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('SID', 'qwerty')
    assert str(cookie) == 'SID=qwerty'

    cookie['path'] = '/'
    assert str(cookie) == 'SID=qwerty; Path=/'

    cookie['expires'] = datetime.strptime('2050-01-01', '%Y-%m-%d')
    assert str(cookie) == 'SID=qwerty; Path=/; expires=Fri, 01-Jan-2050 00:00:00 GMT'

    cookie['comment'] = 'Test'
    assert str(cookie) == 'SID=qwerty; Path=/; expires=Fri, 01-Jan-2050 00:00:00 GMT; Comment=Test'

    cookie['domain'] = 'example.com'

# Generated at 2022-06-12 08:39:57.705276
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    from time import time

    # setup cookes
    c1 = Cookie("name_1", "value_1")
    c2 = Cookie("name_2", "value_2")
    c3 = Cookie("name_3", "value_3")
    c4 = Cookie("name_4", "value_4")
    c5 = Cookie("name_5", "value_5")

    # test empty cookies
    assert str(c1) == "name_1=value_1"
    assert str(c2) == "name_2=value_2"
    assert str(c3) == "name_3=value_3"
    assert str(c4) == "name_4=value_4"
    assert str(c5) == "name_5=value_5"

    # test

# Generated at 2022-06-12 08:40:07.474018
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """Unit test for method __setitem__ of class Cookie"""

    c = Cookie("key", "value")

    # test setting object as None in cookie
    c["expires"] = None
    assert c["expires"] is None

    # test setting integer as None in cookie
    c["max-age"] = None
    assert c["max-age"] is None

    # test setting string as None in cookie
    c["comment"] = None
    assert c["comment"] is None

    # test setting float as None in cookie
    c["version"] = None
    assert c["version"] is None

    # test setting boolean as true in cookie
    c["secure"] = True
    assert c["secure"] == True

    # test setting boolean as False in cookie
    c["secure"] = False
    assert c["secure"] == False

    # test setting boolean

# Generated at 2022-06-12 08:40:16.494229
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup instance of CookieJar
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    # Setup a cookie to delete
    cookie = Cookie("key", "value")
    cookie_jar["key"] = cookie
    cookie_jar["key"]["domain"] = "example.com"

    # Test "delete" of non-existing cookie
    del cookie_jar["not_exists"]
    assert headers.getlist("Set-Cookie") == [
        "key=value; Path=/"
    ], "__delitem__ of 'not_exists' did not delete existing cookie"

    # Test "delete" of existing cookie
    del cookie_jar["key"]

# Generated at 2022-06-12 08:40:20.392906
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers: Dict[str, str] = {}
    cookie_jar = CookieJar(headers)
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    assert headers['Set-Cookie'] == 'key1=value1; Path=/; key2=value2; Path=/'

# Generated at 2022-06-12 08:40:27.395369
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("key", "value")
    c.setdefault("max-age", DEFAULT_MAX_AGE)
    assert c["max-age"] == DEFAULT_MAX_AGE
    with pytest.raises(KeyError):
        c["test"] = "test"
    with pytest.raises(ValueError):
        c["max-age"] = "test"
    with pytest.raises(TypeError):
        c["expires"] = datetime.now()

# Generated at 2022-06-12 08:40:34.834742
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar(MultiDict())
    # Case 1
    cookie_jar.__delitem__("testkey")
    assert cookie_jar.cookie_headers["testkey"] == "Set-Cookie"
    assert cookie_jar.headers["Set-Cookie"] == '"testkey"="None"'

    # Case 2
    cookie_jar.__delitem__("testkey")
    assert cookie_jar.cookie_headers["testkey"] == "Set-Cookie"
    assert cookie_jar.headers["Set-Cookie"] == '"testkey"="None"; Max-Age=0'

# Generated at 2022-06-12 08:40:40.297763
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = CIMultiDict()
    cookies = CookieJar(headers)

    cookies["my-key"] = "value"
    assert len(headers) == 1
    cookies["my-key"] = "value"
    assert len(headers) == 1
    cookies["my-key"] = "value2"
    assert len(headers) == 1
    cookies["my-key2"] = "value2"
    assert len(headers) == 2
