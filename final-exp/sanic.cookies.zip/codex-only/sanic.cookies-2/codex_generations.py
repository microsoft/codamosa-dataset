

# Generated at 2022-06-24 03:37:12.867251
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()

# Generated at 2022-06-24 03:37:19.478085
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie = CookieJar({})
    assert "test" not in cookie
    cookie["test"] = "abc"
    assert "test" in cookie
    assert "Set-Cookie" in cookie.headers
    assert "test=abc" in cookie.headers["Set-Cookie"]
    assert "test" in cookie.cookie_headers
    assert cookie["test"] == "abc"

#Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-24 03:37:29.101250
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import pytest
    from email.utils import formatdate, parsedate
    from datetime import datetime, timedelta
    from urllib.parse import quote

    # Exercises the first case: key is not a reserved word, value does not need
    # to be quoted.
    key = 'foo'
    value = 'bar'
    c = Cookie(key, value)
    expected = '{0}={1}'.format(key, value)
    assert expected == str(c)

    # Exercises the case that value needs to be quoted.
    key = 'foo'
    value = 'bar baz'
    c = Cookie(key, value)
    expected = '{0}={1}'.format(key, quote(value))
    assert expected == str(c)

    # Exercises the case that max-age is

# Generated at 2022-06-24 03:37:36.229407
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("my_key", "my_value")
    assert c.key == "my_key"
    assert c.value == "my_value"
    assert c.get("secure", False) == False
    assert c.get("expires", "") == ""
    assert c.get("domain", "") == ""
    assert c.get("path", "") == ""
    assert c.get("comment", "") == ""
    assert c.get("max-age", "") == ""
    assert c.get("version", "") == ""
    assert c.get("samesite", "") == ""

    with pytest.raises(KeyError):
        c = Cookie("expires", "my_value")

# Generated at 2022-06-24 03:37:38.060391
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('name','value')

    assert cookie['path'] == '/'
    
    cookie['path'] = '/path'

    assert cookie['path'] == '/path'


# Generated at 2022-06-24 03:37:50.020859
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers: CIMultiDict = CIMultiDict()
    cookie_jar = CookieJar(headers)

    # Simple tests:
    assert len(cookie_jar.cookie_headers) == 0
    cookie_jar["a"] = "b"
    assert len(cookie_jar.cookie_headers) == 1
    assert cookie_jar["a"] == "b"
    assert "a=b" in headers["Set-Cookie"]

    # Update an existing cookie:
    assert cookie_jar["a"] == "b"
    cookie_jar["a"] = "c"
    assert cookie_jar["a"] == "c"

    # Test that the headers are updated properly:
    headers: CIMultiDict = CIMultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["a"]

# Generated at 2022-06-24 03:37:59.180720
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    headers.add('Set-Cookie', 'first-cookie=one')
    headers.add('Set-Cookie', 'second-cookie=two')
    jar = CookieJar(headers)
    cookie_header = jar.header_key
    jar['first-cookie'] = '0'
    jar['second-cookie'] = '0'
    assert len(jar.headers) == 2
    del jar['first-cookie']
    assert len(jar.headers) == 1
    assert cookie_header in headers
    assert headers.getall(cookie_header) == ['second-cookie=0']
    del jar['second-cookie']
    assert len(jar.headers) == 0
    assert cookie_header not in headers



# Generated at 2022-06-24 03:38:00.615719
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookiejar = CookieJar()
    assert(cookiejar is not None)


# Generated at 2022-06-24 03:38:05.797673
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("id", "123123")
    c["max-age"] = DEFAULT_MAX_AGE
    assert c.encode("utf-8") == b"id=123123; Max-Age=0"
    assert c.encode("latin-1") == b"id=123123; Max-Age=0"

# Generated at 2022-06-24 03:38:13.722927
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("foo", "bar")
    assert cookie.key == "foo", "Cookie.key should be 'foo'"
    assert cookie.value == "bar", "Cookie.value should be 'bar'"
    assert str(cookie) == "foo=bar", "Cookie.__str__ should be 'foo=bar'"
    assert cookie.encode("utf-8") == str(cookie).encode("utf-8"), "Cookie.encode should be the same as Cookie.__str__"


# Generated at 2022-06-24 03:38:22.828413
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test for basic function of method __str__
    #
    # Arrange
    key = "Cookie1"
    value = "Value1"
    cookie = Cookie(key, value)
    cookie["max-age"] = 0
    cookie["path"] = "/"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = "www.example.com"
    cookie["expires"] = datetime(year=2020, month=1, day=1, hour=0, minute=0)
    cookie["version"] = "1"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "Strict"

    # Act
    cookie_str = str(cookie)

    # Assert

# Generated at 2022-06-24 03:38:33.691698
# Unit test for constructor of class Cookie
def test_Cookie():
    from datetime import datetime
    from .test import Catcher
    with Catcher() as catcher:
        Cookie("name", "value")
        Cookie("Expires", "value")
    assert catcher.errors == ["Cookie name is a reserved word"]
    with Catcher() as catcher:
        Cookie("expires", "value")
        Cookie("name", "value")
        Cookie("expires", datetime(2021, 11, 10, 10, 0, 0))
        Cookie("max-age", "value")
        Cookie("max-age", 10)
        Cookie("secure", 1)
        Cookie("secure", True)
    assert not catcher.errors
    with Catcher() as catcher:
        Cookie("max-age", "string")
    assert catcher.errors == ["Cookie max-age must be an integer"]

# Generated at 2022-06-24 03:38:37.123242
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # Create a new CookieJar object
    headers = MultiHeaders()
    CookieJar(headers)

    # It must be of type dict
    assert type(CookieJar) == type(dict)


# Generated at 2022-06-24 03:38:41.061607
# Unit test for constructor of class Cookie
def test_Cookie():
    assert Cookie("foo", "bar") == {"max-age": DEFAULT_MAX_AGE}


# Generated at 2022-06-24 03:38:46.739879
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("foo", "bar")
    assert cookie.key == "foo"
    assert cookie.value == "bar"
    assert str(cookie) == "foo=bar"
    cookie.update({"path": "/foo", "max-age": 600})
    assert str(cookie) == "foo=bar; Path=/foo; Max-Age=600"


# Generated at 2022-06-24 03:38:53.447966
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # not delete un-exist key
    headers = {'cookie': "name=admin"}
    cookie_jar = CookieJar(headers)
    assert cookie_jar.headers == headers
    del cookie_jar['not-exist']
    assert cookie_jar.headers == headers

    # delete cookie from CookieJar
    del cookie_jar['name']
    assert cookie_jar.headers == {'set-cookie': 'name=; Max-Age=0; Path=/'}

    # delete cookie from CookieJar again
    del cookie_jar['name']
    assert cookie_jar.headers == {}

    # delete a key that not exist after deleted
    del cookie_jar['name']
    assert cookie_jar.headers == {}


# Generated at 2022-06-24 03:39:01.664912
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("cookie", "value")
    assert "cookie=value" == cookie.encode("ascii")
    assert "cookie=value".encode("utf-8") == cookie.encode("utf-8")
    cookie = Cookie("cookie", "value1 value2")
    assert "cookie=value1 value2" == cookie.encode("ascii")
    assert "cookie=value1 value2".encode("utf-8") == cookie.encode("utf-8")

# Generated at 2022-06-24 03:39:09.438610
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = HTTPHeaders()
    cookie_jar = CookieJar(headers)

    assert not headers
    assert not cookie_jar

    cookie_jar["new_cookie"] = "new_cookie_value"
    cookie_jar["another_cookie"] = "another_cookie_value"

    assert headers["Set-Cookie"]
    assert len(headers["Set-Cookie"]) == 2
    assert headers["Set-Cookie"] == ["new_cookie=new_cookie_value", "another_cookie=another_cookie_value"]
    assert len(cookie_jar) == 2
    assert "new_cookie" in cookie_jar
    assert "another_cookie" in cookie_jar
    assert cookie_jar["new_cookie"]
    assert cookie_jar["another_cookie"]

# Generated at 2022-06-24 03:39:18.441538
# Unit test for constructor of class CookieJar
def test_CookieJar():
    _headers = Headers()
    _cookie_jar = CookieJar(_headers)
    assert _cookie_jar == {}
    assert _headers == {}

    try:
        _cookie_jar["test"] = "test"
        raise AssertionError("Cookie jar failed to quote")
    except KeyError:
        pass

    _cookie_jar = CookieJar(_headers)
    _cookie_jar["test"] = "test"
    _cookie_jar["test2"] = "test2"
    assert _headers["Set-Cookie"] == "test=test; Path=/"
    assert _headers["Set-Cookie.1"] == "test2=test2; Path=/"



# Generated at 2022-06-24 03:39:23.719569
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {'Set-Cookie': 'foo=bar,baz=bat'}
    c = CookieJar(headers)
    assert headers['Set-Cookie'] == 'foo=bar,baz=bat'
    del c['foo']
    assert headers['Set-Cookie'] == 'baz=bat; Max-Age=0'

# Generated at 2022-06-24 03:39:27.013740
# Unit test for constructor of class Cookie
def test_Cookie():
	coo = Cookie("testkey", "testvalue")
	assert(coo.key == "testkey")
	assert(coo["testkey"] == "testvalue")

# test for adding new item to cookie

# Generated at 2022-06-24 03:39:35.715747
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_name = "__test_Cookie_class"
    class headers:
        header_key = ""
        cookie_headers = dict()
        @staticmethod
        def add(key, val):
            headers.header_key = key
        def popall(self, val):
            return self.header_key
    headers = headers()
    cookie_jar = CookieJar(headers)
    cookie_jar[cookie_name] = "cookie_value"
    assert cookie_name in cookie_jar.cookie_headers
    assert cookie_name in cookie_jar
    del cookie_jar[cookie_name]
    assert cookie_name not in cookie_jar.cookie_headers
    assert cookie_name not in cookie_jar
    print("test passed")


# Generated at 2022-06-24 03:39:47.473403
# Unit test for constructor of class CookieJar
def test_CookieJar():
    temp_headers=Headers()
    cookie_jar=CookieJar(temp_headers)
    cookie_jar["user"] = "Toto"
    assert(cookie_jar["user"].value == "Toto")
    assert(temp_headers["Set-Cookie"] == "user=Toto; path=/")
    cookie_jar["user"] = 1234
    assert(cookie_jar["user"].value == "1234")
    assert(temp_headers["Set-Cookie"] == "user=1234; path=/")
    del cookie_jar["user"]
    assert(temp_headers["Set-Cookie"] == "user=; Max-Age=0; path=/")
    with pytest.raises(KeyError):
        assert(cookie_jar["user"])

# Generated at 2022-06-24 03:39:57.116360
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Testing with empty string
    assert str(Cookie("", "")) == "=", "Cookie not properly formatted"

    # Testing with normal string
    assert str(Cookie("testkey", "testvalue")) == "testkey=testvalue", \
        "Cookie not properly formatted"

    # Testing with illegal key, ValueError should be raised
    with pytest.raises(ValueError):
        str(Cookie("testkey*", "testvalue"))

    # Testing with reserved word
    with pytest.raises(KeyError):
        str(Cookie("expires", "testvalue"))

    # Testing with = in value
    assert str(Cookie("testkey", "testvalue=value")) == "testkey=\"testvalue=value\"", \
        "Cookie not properly formatted"

    # Testing with " in value
    assert str

# Generated at 2022-06-24 03:40:05.938464
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie1 = Cookie("cookie1", "value1")

    # Test case 1
    assert str(cookie1) == "cookie1=value1"

    # add path
    cookie1["path"] = "/cookie"
    assert str(cookie1) == "cookie1=value1; Path=/cookie"

    # add max-age
    cookie1["max-age"] = 100
    assert str(cookie1) == "cookie1=value1; Path=/cookie; Max-Age=100"

    # add secure
    cookie1["secure"] = True
    assert (
        str(cookie1)
        == "cookie1=value1; Path=/cookie; Max-Age=100; Secure"
    )

    # add expires and comment

# Generated at 2022-06-24 03:40:09.753721
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    cookie["key"] = "value"
    assert cookie["key"] == "value"
    
    cookie["expires"] = datetime.utcnow()
    assert type(cookie["expires"])==datetime
    assert cookie["expires"] is not False

    cookie["max-age"] = "20"
    assert cookie["max-age"] == 20
    assert type(cookie["max-age"]) == int
    
    
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    assert cookie["path"] is not False
    
    cookie["comment"] = "Hello, world!"
    assert cookie["comment"] == "Hello, world!"
    assert cookie["comment"] is not False
    

# Generated at 2022-06-24 03:40:16.407077
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    assert headers['Set-Cookie'] == 'foo=bar; Path=/'
    del jar['foo']
    assert headers['Set-Cookie'] == 'foo=; Max-Age=0; Path=/'


# ------------------------------------------------------------ #
#  MultiHeader
# ------------------------------------------------------------ #



# Generated at 2022-06-24 03:40:27.383681
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cj = CookieJar(headers)
    # Add a new cookie
    cj["new_cookie"] = "new_value"
    assert len(cj) == 1
    assert len(headers) == 1
    assert "Set-Cookie" in headers
    assert headers["Set-Cookie"][0] == 'new_cookie="new_value"; Path=/'
    # Change old cookie
    cj["new_cookie"] = "changed"
    assert len(cj) == 1
    assert len(headers) == 1
    assert "Set-Cookie" in headers
    assert headers["Set-Cookie"][0] == 'new_cookie="changed"; Path=/'
    # Delete nonexistent cookie
    with pytest.raises(KeyError) as ex:
        del cj["nonexistent"]


# Generated at 2022-06-24 03:40:30.024268
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_key"] = "test_value"
    assert headers["Set-Cookie"] == 'test_key="test_value"; Path=/'


# Generated at 2022-06-24 03:40:38.262371
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    global Cookie
    c = Cookie("name", "value")
    c["expires"] = datetime.now()
    c["path"] = "/"
    c["comment"] = "fuckfuckyou"
    c["domain"] = "localhost.com"
    c["max-age"] = 768
    c["secure"] = True
    c["httponly"] = True
    c["version"] = "version"
    c["samesite"] = "samesite"
    print(c['path'])


# Generated at 2022-06-24 03:40:46.278762
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookies_property = dict()
    cookies_property['path'] = "/"
    cookies_property['max-age'] = "0"
    cookies_property['Expires'] = "Thu, 01 Jan 1970 00:00:00 GMT"

    cookie = Cookie('test', 'value')
    for key, value in cookies_property.items():
        cookie[key] = value
        assert cookie[key] == value
        assert cookie._keys[key.lower()] == key
        assert cookie.value == 'value'
        assert cookie['path'] == '/'
        assert cookie['max-age'] == 0
        assert cookie['Expires'] == "Thu, 01 Jan 1970 00:00:00 GMT"
        assert isinstance(cookie['Expires'], datetime)


# Generated at 2022-06-24 03:40:53.576395
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Gets executed when Cookie.__str__() is invoked."""
    cookie = Cookie("_test", "_value")
    cookie["domain"] = "google.com"
    cookie["httponly"] = True
    cookie["secure"] = True
    cookie["path"] = "/random"

    assert (
        str(cookie)
        == "_test=_value; Domain=google.com; Path=/random; Secure; HttpOnly"
    )

# Generated at 2022-06-24 03:41:03.232312
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie = CookieJar(headers)
    cookie["a"] = "b"
    assert cookie["a"].value == "b"
    cookie["a"] = "c"
    assert cookie["a"].value == "c"
    assert headers.getall("Set-Cookie")[0] == 'a="c"; Max-Age=0; Path=/'
    cookie["a"] = "d"
    assert cookie["a"].value == "d"
    assert headers.getall("Set-Cookie")[0] == 'a="d"; Max-Age=0; Path=/'
    cookie["b"] = "b"
    assert cookie["b"].value == "b"

# Generated at 2022-06-24 03:41:11.333473
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Unit tests for method __str__ of class Cookie
    """
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'

    cookie['expires'] = datetime(2018, 8, 30, 0, 0, 0)
    assert str(cookie) == 'name=value; Expires=Thu, 30-Aug-2018 00:00:00 GMT'
    del cookie['expires']

    cookie['max-age'] = 100
    assert str(cookie) == 'name=value; Max-Age=100'

    cookie['max-age'] = '100'
    assert str(cookie) == 'name=value; Max-Age=100'

    cookie['path'] = '/foo'
    assert str(cookie) == 'name=value; Max-Age=100; Path=/foo'


# Generated at 2022-06-24 03:41:18.517171
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    headers._headers = {}
    headers._unique = {}
    headers._used = set()
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    curr_time = datetime.now()

    # check if key is a reserved word
    try:
        cookie_jar["expires"] = curr_time.strftime("%a, %d-%b-%Y %T GMT")
        assert False
    except KeyError:
        assert True
    except Exception as e:
        print(e)
        assert False

    # check if key contains reserved characters
    try:
        cookie_jar["key!"] = "value"
        assert False
    except KeyError:
        assert True
    except Exception as e:
        print(e)
        assert False



# Generated at 2022-06-24 03:41:28.769509
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("name", "value")
    assert c["max-age"] == DEFAULT_MAX_AGE
    c.expires = "Wed, 31 Dec 2008 23:59:59 GMT"
    c.path = "/"
    c.comment = "hello world"
    c.domain = "example.com"
    c.max_age = "3600"
    c.secure = True
    c.httponly = True
    c.version = "1"
    c.samesite = "Lax"
    assert c["max-age"] == 3600
    assert c.expires == "Wed, 31 Dec 2008 23:59:59 GMT"
    assert c.path == "/"
    assert c.comment == "hello world"
    assert c.domain == "example.com"
    assert c.max_age == 3600

# Generated at 2022-06-24 03:41:31.527410
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    assert cookie.encode("utf-8") == b"key=value"
    assert cookie.encode("utf-8") == "key=value".encode("utf-8")



# Generated at 2022-06-24 03:41:41.923151
# Unit test for constructor of class Cookie
def test_Cookie():
  c = Cookie('key1','value1')
  c2 = Cookie('key2','value2')
  assert(c['key1']=='value1')
  assert(c2['key2']=='value2')
  assert('Cookie' in str(c))
  assert('key1' in str(c))
  assert('value1' in str(c))
  assert('key1' not in str(c2))
  assert('value1' not in str(c2))
  assert('key2' in str(c2))
  assert('value2' in str(c2))
  try:
    c1 = Cookie('key1','value1')
    assert(False)
  except:
    pass



# Generated at 2022-06-24 03:41:46.330530
# Unit test for constructor of class Cookie
def test_Cookie():
    """
    Test case for the Cookie class constructor.
    """
    # Test with a valid cookie
    cookie_A = Cookie(key="cookie_A", value="cookie_A_value")
    assert cookie_A["path"] == "/"
    assert cookie_A.key == "cookie_A"
    assert cookie_A.value == "cookie_A_value"

    # Test with reserved word
    with pytest.raises(KeyError):
        Cookie(key="httponly", value="httponly_value")

    # Test with illegal character
    with pytest.raises(KeyError):
        Cookie(key="illegal!", value="illegal_value")

    # Test setitem with a reserved word
    with pytest.raises(KeyError):
        cookie_A["httponly"] = "false"

    # Test setitem with value type

# Generated at 2022-06-24 03:41:52.362767
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from starlette.testclient import TestClient
    from starlette.types import Scope
    from starlette.requests import Request
    import asgi_cors

    async def app(scope, receive, send):
        request = Request(scope=scope, receive=receive)
        response = asgi_cors.CorsResponse()
        response.set_cookie('myCookie', 'myValue')
        await response(receive, send)
        return response

    client = TestClient(app)
    response = client.get("/")

    assert "myCookie=myValue" in response.cookies
    assert "myCookie=myValue" in response.headers.getlist("Set-Cookie")

    response.cookies.pop('myCookie')

    assert "myCookie=myValue" not in response.cookies
   

# Generated at 2022-06-24 03:41:57.293931
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    assert cookie_jar is not None


# Generated at 2022-06-24 03:42:07.651442
# Unit test for constructor of class Cookie
def test_Cookie():
    ck = Cookie('name', 'value')
    assert ck.key == 'name'
    assert ck.value == 'value'
    assert str(ck) == 'name=value'

    ck.set_max_age(100)
    assert ck['max-age'] == 100
    assert str(ck) == 'name=value; Max-Age=100'

    ck.set_expires(datetime(1999, 12, 12))
    assert ck['expires'] == datetime(1999, 12, 12)
    assert str(ck) == 'name=value; Expires=Sun, 12-Dec-1999 00:00:00 GMT'

    ck.set_secure()
    assert ck['secure'] == True

# Generated at 2022-06-24 03:42:14.243877
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Arrange
    headers = Headers(CIMultiDict())
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"

    # Act
    cookie_jar.__delitem__("foo")

    # Assert
    assert not "foo" in cookie_jar
    assert not cookie_jar.headers.get("Set-Cookie")



# Generated at 2022-06-24 03:42:23.555096
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cookies = CookieJar(headers)
    assert len(cookies) == 0
    assert len(cookies.headers) == 0
    assert len(cookies.cookie_headers) == 0
    cookies['key1'] = "value1"
    assert len(cookies) == 1
    assert len(cookies.headers) == 1
    assert len(cookies.cookie_headers) == 1
    assert str(cookies['key1']) == 'key1="value1"'
    assert cookies.headers['Set-Cookie'] == 'key1="value1"'



# Generated at 2022-06-24 03:42:35.879377
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("myCookieKey", "myCookieValue")
    assert c.key == "myCookieKey"
    assert c.value == "myCookieValue"
    assert c["path"] == c.get("path") == "/"
    assert c.get("max-age") is None
    c["max-age"] = 1
    assert c["max-age"] == 1
    assert c.get("max-age") == 1
    assert c.get("expires") is None
    c["expires"] = datetime.now()
    assert c.get("expires") is not None
    assert isinstance(c["expires"], datetime)
    assert c.get("secure") is False
    assert c.get("httponly") is False
    assert c.get("version") is None

# Generated at 2022-06-24 03:42:44.002655
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('test', 'value')
    cookie['path'] = '/'
    assert cookie['path'] == '/'
    cookie['httponly'] = False
    assert cookie['httponly'] is False
    cookie['domain'] = '12354'
    assert cookie['domain'] == '12354'
    cookie['domain'] = '\ud800\udfff'
    assert cookie['domain'] == '\ud800\udfff'
    cookie['domain'] = True
    assert cookie['domain'] is True
    with pytest.raises(ValueError):
        cookie['max-age'] = '1234'
    with pytest.raises(TypeError):
        cookie['expires'] = datetime.now()
    cookie['expires'] = datetime.now()
    assert cookie['expires'] == datetime.now()
    cookie

# Generated at 2022-06-24 03:42:45.434699
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('arst', 'wxyz')


# Generated at 2022-06-24 03:42:50.998016
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    cookie["httponly"] = True
    encoded_cookie = cookie.encode("utf-8")
    assert encoded_cookie.decode("utf-8") == "key=value; HttpOnly"



# ------------------------------------------------------------ #
#  Custom SimpleCookie
# ------------------------------------------------------------ #

# Generated at 2022-06-24 03:42:53.294660
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('test_key', 'test_value')
    assert str(cookie) == 'test_key=test_value'


# Generated at 2022-06-24 03:42:55.114470
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    pass

# ------------------------------------------------------------ #
#  Exceptions
# ------------------------------------------------------------ #



# Generated at 2022-06-24 03:43:05.095286
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    test_helper = []

    class Headers:
        def __init__(self):
            self.headers = {'Set-Cookie':[Cookie('test','value')]}
        
        def get(self, key):
            return self.headers[key]
        
        def add(self, key, value):
            test_helper.append(key)
            test_helper.append(value)
    
    test_headers = Headers()
    test_jar = CookieJar(test_headers)
    test_jar['test'] = 'test_value'
    
    assert(test_helper[0] == 'Set-Cookie')
    assert(test_helper[1] == 'test=test_value')
    assert(test_jar['test'].value == 'test_value')

# Unit test

# Generated at 2022-06-24 03:43:15.087110
# Unit test for constructor of class Cookie
def test_Cookie():
    ck = Cookie('s1', 's1')
    ck2 = Cookie('s2', 's2')
    ck3 = Cookie('s3', 's3')
    ck4 = Cookie('s4', 's4')
    assert ck.key == 's1'
    assert ck2.key == 's2'
    assert ck3.key == 's3'
    assert ck4.key == 's4'

# ------------------------------------------------------------ #
#  Server-side Cookies
# ------------------------------------------------------------ #

# The following code related to Server-side cookies is adapted from FastAPI
# original file: fastapi/requests.py


# Generated at 2022-06-24 03:43:23.570313
# Unit test for constructor of class Cookie
def test_Cookie():
    # Cookie constructor with valid key and value arguments
    c0 = Cookie("alpha", "beta")
    assert c0.key == "alpha"
    assert c0.value == "beta"

    # Cookie constructor with key argument that is a reserved word
    # (should raise KeyError)
    with pytest.raises(KeyError):
        c1 = Cookie("expires", "beta")

    # Cookie constructor with key argument that is illegal
    # (should raise KeyError)
    with pytest.raises(KeyError):
        c2 = Cookie("al$ha", "beta")

    # Cookie constructor with value argument that is not a string
    # (should raise TypeError)
    with pytest.raises(TypeError):
        c3 = Cookie("alpha", 123)


# Generated at 2022-06-24 03:43:33.042287
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    r"""
    Tests simple method of CookieJar class
    """
    cookiejar = CookieJar()
    cookiejar["test1"] = "value1"
    cookiejar["test2"] = "value2"
    cookiejar["test3"] = "value3"
    cookiejar["test4"] = "value4"
    
    ## Test 1
    # cookiejar.__delitem__("test")
    # check if cookiejar contains key "test"
    #assert not "test" in cookiejar.keys()

    # Test 2
    #cookiejar.__delitem__("test4")
    # check if cookiejar contains key "test4"
    #assert not "test4" in cookiejar.keys()

# Generated at 2022-06-24 03:43:37.813283
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookies = CookieJar()
    assert not cookies, "cookiejar should be empty"
    assert len(cookies) == 0, "cookiejar should be empty"

    cookies = CookieJar({"foo": "bar"})
    assert cookies["foo"] == "bar", "foo should equal bar"



# Generated at 2022-06-24 03:43:47.069668
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie = CookieJar({})

    # Test valid cookie
    cookie["day"] = "today"
    assert cookie["day"] == "today"
    assert cookie.headers.get("Set-Cookie") == "day=today; Path=/"

    # Test invalid cookie
    with pytest.raises(KeyError) as exception_info:
        cookie["expires"] = "today"

    assert "Cookie name is a reserved word"\
        in str(exception_info.value)

    # Test invalid cookie
    with pytest.raises(KeyError) as exception_info:
        cookie["expires$"] = "today"

    assert "Cookie key contains illegal characters" \
        in str(exception_info.value)



# Generated at 2022-06-24 03:43:48.858846
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('name','value')
    assert cookie.key == 'name'
    assert cookie.value == 'value'


# Generated at 2022-06-24 03:43:54.506538
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = DarkSkyHeaders()
    cookies = CookieJar(headers)
    cookies["username"] = "xuanlong"
    assert headers.get("Set-Cookie") == "username=xuanlong; Path=/", "fail to set cookies"
    del cookies["username"]
    # cookies["username"]["max-age"] = "0"
    assert headers.get("Set-Cookie") == "username=; Max-Age=0; Path=/", "fail to delete cookies"
    assert not cookies.get("username"), "fail to delete cookies"


# Generated at 2022-06-24 03:44:04.039158
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    assert cookie.encode("utf-8") == b'key=value'

    cookie["path"] = "/example"
    cookie["secure"] = True
    cookie["httponly"] = True
    assert cookie.encode("utf-8") == b'key=value; Path=/example; Secure; HttpOnly'

    cookie["max-age"] = 0
    cookie["expires"] = datetime(2017, 12, 12, 12, 12, 12)
    cookie["comment"] = "this is an example"
    cookie["version"] = "7"
    cookie["domain"] = "frozensakura.me"

    encoded = cookie.encode("utf-8")
    expected = b'key=value; Path=/example; Secure; HttpOnly; Max-Age=0; ' \
              

# Generated at 2022-06-24 03:44:13.868172
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 0

    assert cookie == {"path": "/", "max-age": 0}
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0

    with pytest.raises(KeyError):
        cookie["no_key"] = ""
    with pytest.raises(KeyError):
        cookie["expires"] = ""
    with pytest.raises(ValueError):
        cookie["max-age"] = "string"
    with pytest.raises(ValueError):
        cookie["max-age"] = "0xFF"



# Generated at 2022-06-24 03:44:24.179774
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Tests for valid key and value
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = 10
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "Strict"

# Generated at 2022-06-24 03:44:25.661576
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cj = CookieJar(headers)
    assert isinstance(cj, dict)
    assert isinstance(cj, CookieJar)


# Generated at 2022-06-24 03:44:36.107022
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('my-cookie','my_value')
    assert cookie.encode('utf-8') == 'my-cookie=my_value'.encode('utf-8')
    cookie = Cookie('cookie-utf8','nombre-válido')
    assert cookie.encode('utf-8') == 'cookie-utf8="nombre-válido"'.encode('utf-8')
    cookie = Cookie('int-cookie',1)
    assert cookie.encode('utf-8') == 'int-cookie=1'.encode('utf-8')


# ------------------------------------------------------------ #
#  Some tests
# ------------------------------------------------------------ #

import httpcore
from hypercorn.config import Config



# Generated at 2022-06-24 03:44:45.351143
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_data = [([], "test_data=test_value"),
                 (["key1=value1", "key2=value2"], "test_data=test_value; key1=value1; key2=value2"),
                 (["domain=www.example.com", "secure", "key2=value2"], "test_data=test_value; domain=www.example.com; secure; key2=value2"),
                 (["path=/demo", "key2=value2"], "test_data=test_value; path=/demo; key2=value2")]
    for index, (args, expected) in enumerate(test_data):
        cookie = Cookie("test_data", "test_value")
        for arg in args:
            _, key, value = arg.split("=")
            cookie[key]

# Generated at 2022-06-24 03:44:48.859107
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    headers.add("Set-Cookie", "a=5")
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "3"
    assert cookie_jar["a"].value == "3"
    assert headers["Set-Cookie"] == "a=3"


# Generated at 2022-06-24 03:44:55.530670
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    """
    Test the method encode(self, encoding) of class Cookie.
    """
    super_cookie_config = {
        'key': "key"
    }
    cookie_config = {
        'key': "value"
    }
    
    c = Cookie(**cookie_config)
    c.encode(encoding='utf-8')
    assert(True)



# Generated at 2022-06-24 03:45:03.657458
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cj = CookieJar(headers)
    cj["a"] = "a"
    cj["b"] = "b"
    cj["a"] = "c"
    assert cj["a"].value == "c"
    assert cj["b"].value == "b"
    assert len(cj) == 2
    assert "a" in cj
    assert "b" in cj
    assert cj.headers.get("Set-Cookie") == "a=c; Path=/"
    assert cj.headers.get("Set-Cookie1") == "b=b; Path=/"


# Generated at 2022-06-24 03:45:10.581204
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader(delimiter="&")
    cookie_jar = CookieJar(headers)
    cookie_jar["test1"] = "value1"
    cookie_jar["test2"] = "value2"
    # Test deleting a single cookie
    del cookie_jar["test1"]
    assert str(cookie_jar) == ""
    # Test deleting the second cookie in a list
    cookie_jar["test1"] = "value1"
    cookie_jar["test2"] = "value2"
    del cookie_jar["test2"]
    assert str(cookie_jar) == "test1=value1"
    # Test deleting the first cookie in a list
    del cookie_jar["test1"]
    cookie_jar["test1"] = "value1"
    cookie_jar["test2"] = "value2"
    del cookie

# Generated at 2022-06-24 03:45:17.729661
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('name', 'value')
    assert c.__str__() == 'name=value'
    c['domain'] = 'domain'
    c['secure'] = True
    c['HTTPOnly'] = True
    assert c.__str__() == 'name=value; Domain=domain; Secure; HttpOnly'


# ------------------------------------------------------------ #
#  LeakyCookie
# ------------------------------------------------------------ #



# Generated at 2022-06-24 03:45:19.926962
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("clam", "chowder")
    assert c.encode("utf-8") == b"clam=chowder"
    assert c.encode("ascii") == b"clam=chowder"

# Generated at 2022-06-24 03:45:24.563218
# Unit test for constructor of class CookieJar
def test_CookieJar():
    mock_headers = {}
    cookie_jar = CookieJar(mock_headers)
    assert cookie_jar.headers == mock_headers
    assert cookie_jar.cookie_headers == {}
    assert cookie_jar.header_key == "Set-Cookie"



# Generated at 2022-06-24 03:45:29.011356
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    result = cookie.encode("utf-8")
    assert(result == "key=value".encode("utf-8"))
    assert(str(result) == "b'key=value'")

# ------------------------------------------------------------ #
#  Custom SimpleCookie
# ------------------------------------------------------------ #



# Generated at 2022-06-24 03:45:35.425003
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    header = CookieJar(None)
    cookie = Cookie('test', 'hello')

    assert cookie['test'] == "hello"

    cookie['test'] = "test"
    assert cookie['test'] == "test"

    cookie['path'] = '/'
    assert cookie['path'] == "/"

    cookie['test'] = 'test2'
    assert cookie['test'] == "test2"


# Generated at 2022-06-24 03:45:40.204767
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cj = CookieJar({"Set-Cookie": "some stuff that should not get erased"})
    assert isinstance(cj, CookieJar)
    assert isinstance(cj.headers, dict)
    assert cj.headers["Set-Cookie"] == "some stuff that should not get erased"


# Generated at 2022-06-24 03:45:42.820037
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("foo", "baz")
    assert cookie.encode("utf-8") == b'foo="baz"'

# Generated at 2022-06-24 03:45:54.273870
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "cookie")
    with pytest.raises(KeyError) as exc:
        cookie["test"] = 1
    assert "Cookie name is a reserved word" in str(exc.value)
    with pytest.raises(KeyError) as exc:
        cookie["Test"] = 1
    assert "Cookie key contains illegal characters" in str(exc.value)
    with pytest.raises(KeyError) as exc:
        cookie["Test"] = 1
    assert "Unknown cookie property" in str(exc.value)
    with pytest.raises(ValueError) as exc:
        cookie["max-age"] = "hello"
    assert "Cookie max-age must be an integer" in str(exc.value)

# Generated at 2022-06-24 03:46:03.291128
# Unit test for constructor of class Cookie
def test_Cookie():
    with pytest.raises(KeyError):
        Cookie('Cookie','Cookie')
    with pytest.raises(KeyError):
        Cookie('domain','domain')
    with pytest.raises(KeyError):
        Cookie('secure','secure')
    with pytest.raises(KeyError):
        Cookie('httponly','httponly')

    valid_keys = [
        "expires",
        "path",
        "comment",
        "domain",
        "max-age",
        "secure",
        "httponly",
        "version",
        "samesite",
        "something",
        "somethingelse",
    ]
    for k in valid_keys:
        Cookie(k, "value")


# Generated at 2022-06-24 03:46:05.818974
# Unit test for constructor of class Cookie
def test_Cookie():
    dic = Cookie("key", "value")
    assert dic.key == "key"
    assert dic.value == "value"


# Generated at 2022-06-24 03:46:17.325698
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import pytest
    cookie = Cookie("key", "value")

    with pytest.raises(KeyError):
        cookie['expires'] = 1
    
    with pytest.raises(KeyError):
        cookie['path'] = 1

    with pytest.raises(KeyError):
        cookie['max-age'] = 'value'

    cookie['max-age'] = 1
    assert cookie['max-age'] == 1

    with pytest.raises(TypeError):
        cookie['expires'] = 'value'

    cookie['expires'] = datetime.now()
    assert isinstance(cookie['expires'], datetime)

    with pytest.raises(KeyError):
        cookie['secure'] = 1

    with pytest.raises(KeyError):
        cookie['secure'] = True


# Generated at 2022-06-24 03:46:28.405560
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("cookie1", "value")
    assert cookie["version"] == 1
    cookie["max-age"] = 0
    cookie["path"] = "/"
    cookie["httponly"] = True
    cookie["secure"] = True
    assert cookie["max-age"] == 0
    assert cookie["path"] == "/"
    assert cookie["httponly"] == True
    assert cookie["secure"] == True
    assert cookie["version"] == 1

    try:
        cookie["wrong"] = "wrong"
        assert False
    except KeyError:
        assert True
    cookie["comment"] = "comment"
    assert cookie["comment"] == "comment"
    try:
        cookie["max-age"] = "wrong"
        assert False
    except ValueError:
        assert True
    assert cookie["version"] == 1

    # Set version 1

# Generated at 2022-06-24 03:46:39.660203
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="test", value="test")
    assert str(cookie) == "test=test"

    cookie = Cookie(key="test", value="test")
    cookie["max-age"] = 45
    assert str(cookie) == "test=test; Max-Age=45"

    cookie = Cookie(key="test", value="test")
    cookie["secure"] = True
    assert str(cookie) == "test=test; Secure"

    cookie = Cookie(key="test", value="test")
    cookie["expires"] = datetime.now()
    assert str(cookie) == "test=test; Expires=" + datetime.now().strftime("%a, %d-%b-%Y %T GMT")

    cookie = Cookie(key="test", value="test")
    cookie["path"] = "/"

# Generated at 2022-06-24 03:46:43.201752
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cookieJar = CookieJar(headers)
    cookieJar["test"] = "test"
    assert cookieJar.headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"
    del cookieJar["test"]
    assert cookieJar.headers["Set-Cookie"] == ""
    assert cookieJar == {}



# Generated at 2022-06-24 03:46:46.204103
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    assert len(headers) == 0
    assert len(cookie_jar) == 0



# Generated at 2022-06-24 03:46:56.025157
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime as dt
    c = Cookie('key', 'value')
    c['max-age'] = '10'
    c['expires'] = dt(2030, 1, 1, 1, 1, 1)
    c['secure'] = True
    c['httponly'] = True
    c['path'] = 'path'
    c['domain'] = 'domain'
    c['comment'] = 'comment'
    c['version'] = 'version'
    c['samesite'] = 'samesite'

# Generated at 2022-06-24 03:47:08.148471
# Unit test for constructor of class Cookie
def test_Cookie():
    test_cookie = Cookie("Name", "Tester")
    assert test_cookie.key == "Name"
    assert test_cookie["expires"] == None
    assert test_cookie["path"] == None
    assert test_cookie["comment"] == None
    assert test_cookie["domain"] == None
    assert test_cookie["max-age"] == None
    assert test_cookie["secure"] == None
    assert test_cookie["httponly"] == None
    assert test_cookie["version"] == None
    assert test_cookie["samesite"] == None
    assert test_cookie.value == "Tester"
    try:
        test_cookie["Max-Age"] = "Test"
        assert False
    except KeyError:
        assert True