

# Generated at 2022-06-26 03:11:28.076180
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({})
    cookie_jar_0.__delitem__(None)
    assert True



# Generated at 2022-06-26 03:11:35.704968
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie("key_0", "value_0")
    cookie_0["expires"] = "expires"
    cookie_0["path"] = "path"
    cookie_0["comment"] = "comment"
    cookie_0["domain"] = "domain"
    cookie_0["max-age"] = "max-age"
    cookie_0["secure"] = "secure"
    cookie_0["httponly"] = "httponly"
    cookie_0["version"] = "version"
    cookie_0["samesite"] = "samesite"



# Generated at 2022-06-26 03:11:47.088828
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Setup
    # None

    # Testing
    cookie_0 = Cookie('key_0', 'value_0')
    cookie_1 = Cookie('key_1', 'value_1')
    cookie_2 = Cookie('key_2', 'value_2')

    cookie_0['path'] = '/'
    cookie_0['httponly'] = True

    cookie_1['path'] = '/'
    cookie_1['httponly'] = True
    cookie_1['max-age'] = 'cookie_1_max_age'

    cookie_2['path'] = '/'
    cookie_2['httponly'] = True
    cookie_2['max-age'] = 10

    # Verification
    assert str(cookie_0) == 'key_0=value_0; HttpOnly; Path=/'

# Generated at 2022-06-26 03:11:54.079063
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Test case 1
    cookie_1 = Cookie('some cookie', 'some value')
    assert cookie_1.encode('utf-8') == b'some cookie=some value'

    # Test case 2
    cookie_2 = Cookie('some cookie', 'some value')
    cookie_2['max-age'] = '123'
    assert cookie_2.encode('utf-8') == b'some cookie=some value; Max-Age=123'


# Generated at 2022-06-26 03:12:00.270719
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({'Set-Cookie': 'Cookie(max-age=0, Expires=Tue, 18-Dec-2018 00:53:53 GMT)'})
    cookie_jar_0.__delitem__('Cookie')
    assert 'Cookie' not in cookie_jar_0
    assert cookie_jar_0['Cookie'] == None
    assert cookie_jar_0.headers['Set-Cookie'] == 'Cookie(max-age=0, Expires=Tue, 18-Dec-2018 00:53:53 GMT)'


# Generated at 2022-06-26 03:12:02.138223
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key_0", "value_0")
    cookie["path"] = "/"
    cookie["path"] = "/"



# Generated at 2022-06-26 03:12:07.456905
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c1 = Cookie('name1', 'value1')
    if c1.__str__() != 'name1=value1':
        raise Exception('test_Cookie___str__ failed!')

    c2 = Cookie('name1', 'value1')
    c2['version'] = '1'
    if c2.__str__() != 'name1=value1; Version=1':
        raise Exception('test_Cookie___str__ failed!')

    c3 = Cookie('name1', 'value1')
    c3['max-age'] = '1'
    if c3.__str__() != 'name1=value1; Max-Age=1':
        raise Exception('test_Cookie___str__ failed!')

    c4 = Cookie('name1', 'value1')
    c4['expires'] = datetime

# Generated at 2022-06-26 03:12:08.882723
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = None
    cookie.__str__()


# Generated at 2022-06-26 03:12:15.788874
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie_jar_0 = CookieJar({"cookie_key":"cookie_value"})
    cookie_jar_1 = CookieJar(cookie_jar_0)

    # Extracting the value of the cookie from the cookie jar
    value = cookie_jar_1["cookie_key"]["value"]

    # Encoding the cookie in UTF-8
    value_encoded = cookie_jar_1["cookie_key"].encode("UTF-8")

# Generated at 2022-06-26 03:12:20.889817
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "cookie_key"
    value = "cookie_value"
    cookie_0 = Cookie(key, value)
    cookie_0["max-age"] = "2"
    expected = "cookie_key=cookie_value; Max-Age=2"
    actual = cookie_0.__str__()
    assert actual == expected

# Generated at 2022-06-26 03:12:28.861763
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_0 = Cookie("key", "value")
    var_1 = "key"
    var_2 = "value"
    var_0.__setitem__(var_1, var_2)


# Generated at 2022-06-26 03:12:34.297230
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    headers.add("Set-Cookie", Cookie("a", "b").__str__())
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "b"
    del cookie_jar["a"]
    assert headers.getall("Set-Cookie") == ['a=b; Path=/; Max-Age=0']


# Generated at 2022-06-26 03:12:42.302392
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:12:49.983506
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookiejar_0 = CookieJar(MultiHeader())
    cookiejar_0['domain'] = "www.example.com"
    cookiejar_0['expires'] = datetime.strptime("Tue, 01 Feb 2011 00:00:00 GMT", "%a, %d %b %Y %H:%M:%S %Z")
    cookiejar_0['path'] = "/"
    cookie_key = "test_key"
    del cookiejar_0[cookie_key]
    assert cookie_key not in cookiejar_0


# Generated at 2022-06-26 03:12:52.322608
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    args = ( None, None, )
    with pytest.raises(TypeError):
        Cookie.__setitem__( *args )


# Generated at 2022-06-26 03:13:01.484033
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # No exception thrown for the following cases.
    var_0 = Cookie("TESTCOOKIE", "TESTVALUE")
    var_0["expires"] = datetime(2020, 6, 28, 18, 25, 15)
    var_0["path"] = "/"
    var_0["max-age"] = 120
    var_0["secure"] = True
    var_0["httponly"] = True
    var_0["comment"] = "test cookie header"
    var_0["domain"] = "test.me"
    var_0["version"] = 0
    var_0["samesite"] = "strict"


# Generated at 2022-06-26 03:13:07.679229
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Initialize the CookieJar object
    headers = {}
    var_0 = CookieJar(headers)

    # Set the key and value pair
    var_0["test1"] = "value1"

    # Check if the cookie is added in CookieJar object
    assert var_0["test1"].value == "value1"
    assert "test1" in var_0.keys()


# Generated at 2022-06-26 03:13:13.056166
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar({})
    var_0 = None
    _0 = None
    cookie_jar_0[var_0] = _0
    cookie_jar_1 = CookieJar({})
    var_1 = None
    _1 = None
    cookie_jar_1[var_1] = _1
    del cookie_jar_1[var_1]
    cookie_jar_2 = CookieJar({})
    var_2 = None
    _2 = None
    cookie_jar_2[var_2] = _2
    del cookie_jar_2[None]


# Generated at 2022-06-26 03:13:19.508508
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    c = CookieJar(headers)
    with pytest.raises(KeyError):
        c.__delitem__(0)


# Generated at 2022-06-26 03:13:20.084271
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    test_case_0()


# Generated at 2022-06-26 03:13:31.925990
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import pytest

    with pytest.raises(KeyError, match=r".* 'Cookie name is a reserved word'$"):
        var_0 = Cookie(None, None)
        var_1 = None
        try:
            var_0[var_1] = None
        except KeyError as var_2:
            print(var_2)
    with pytest.raises(KeyError, match=r".* 'Unknown cookie property'$"):
        var_0 = Cookie(None, None)
        var_1 = "test_theory"
        try:
            var_0[var_1] = None
        except KeyError as var_2:
            print(var_2)

# Generated at 2022-06-26 03:13:36.157979
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_0 = Cookie('var_0', '1')
    var_0['var_1'] = 'Hello'
    expected = 'Hello'
    actual = var_0['var_1']
    assert expected == actual



# Generated at 2022-06-26 03:13:37.989294
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    new_Cookie_0 = Cookie(key="bytes", value="None")


# Generated at 2022-06-26 03:13:41.498785
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookieJar = CookieJar(headers = {'Cache-Control': 'max-age=0, private, must-revalidate'})
    cookieJar['name'] = 'app'
    cookieJar.__delitem__('name')


# Generated at 2022-06-26 03:13:45.255407
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj['a'] = 'b'
    cj['a']
    assert cj.headers == {'Set-Cookie': ['a=b']}
    del cj['a']
    assert cj.headers['Set-Cookie'] == ['a=; Max-Age=0']
    assert cj == {}



# Generated at 2022-06-26 03:13:57.153672
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from DateTime import DateTime
    from time import time
    from time import timezone
    from time import tzname

    cookie = Cookie("example", "value")

    # case 0
    cookie["expires"] = DateTime(time() + 3600)
    cookie["max-age"] = 3600
    cookie["domain"] = "domain.com"
    cookie["path"] = "/"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "strict"
    test_case_0()

    # case 1
    cookie["expires"] = DateTime(time() + 3600)
    cookie["max-age"] = 3600
    cookie["domain"] = "domain.com"
    cookie["path"] = "/"
    cookie["secure"] = True

# Generated at 2022-06-26 03:14:01.158826
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    assert cookie_jar.headers == {}
    assert cookie_jar.cookie_headers == {}
    assert cookie_jar.header_key == "Set-Cookie"


# Generated at 2022-06-26 03:14:03.492009
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_0 = CookieJar(var_0)
    var_3 = None
    var_3 = var_0.__delitem__(var_3)


# Generated at 2022-06-26 03:14:10.241464
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from multidict import CIMultiDict, MultiDict
    headers = CIMultiDict()
    jar = CookieJar(headers)
    # test default case
    # test default case
    # test default case
    # test default case
    # test default case
    # test default case
    # test deleting item case
    # test deleting item case
    # test deleting item case
    # test deleting item case
    # test deleting item case
    # test deleting item case


# Generated at 2022-06-26 03:14:13.962706
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_0 = CookieJar({})
    var_1 = "__COOKIE_0"
    var_0[var_1] = "testCase"
    del var_0[var_1]
    assert var_0[var_1] == None


# Generated at 2022-06-26 03:14:24.005732
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_1 = Cookie(None, None)
    var_2 = None
    var_3 = None
    var_1.__setitem__(var_2, var_3)


# Generated at 2022-06-26 03:14:29.954639
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_1 = Cookie("foo", "bar")
    var_1["path"] = "/"
    var_1["expires"] = datetime(2049, 5, 15, 3, 33, 33)
    var_1["max-age"] = 3000
    var_1["secure"] = True
    var_1["httponly"] = True
    var_1["samesite"] = "Strict"
    var_2 = "foo=bar; Path=/; expires=Mon, 15-May-2049 03:33:33 GMT; Max-Age=3000; Secure; HttpOnly; SameSite=Strict"
    var_3 = var_1.__str__()
    assert var_2 == var_3, "Expected (%s), got (%s)" % (var_2, var_3)


# Generated at 2022-06-26 03:14:38.299566
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_1 = CookieJar({})
    var_2 = None
    var_3 = None
    def closure_0():
        var_0 = var_1
        var_1 = var_0[var_2]
        def closure_1():
            def closure_2():
                var_1 = var_0
                var_0 = var_1[var_2]
                var_1 = var_0["max-age"]
                var_0[var_2]["max-age"] = 0
            closure_2()
            del var_0[var_2]
        closure_1()
    closure_0()
    var_1 = var_3
    assert(var_1 is None)

# ------------------------------------------------------------ #
#  Main
# ------------------------------------------------------------ #


# Generated at 2022-06-26 03:14:41.511957
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(1,2)

    print('Test Case #0')
    try:
        print(cookie.__str__())
    except Exception as error:
        print(error)


# Generated at 2022-06-26 03:14:45.824898
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Initialize dummy Cookie object
    var_0 = Cookie("var_0","var_1")

    # Assert that method works as expected
    assert var_0.__str__() == "var_0=var_1"

# Generated at 2022-06-26 03:14:55.840637
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    from Cookie import Cookie
    from datetime import datetime

    var_1 = (str()).join((str(str()))).join((str(str())))
    var_2 = (str()).join((str(str()))).join((str(str())))
    var_3 = Cookie(var_1, var_2)
    var_3['expires'] = datetime(1994, 11, 6, 8, 49, 37)

# Generated at 2022-06-26 03:14:58.858308
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # case 0
    params = {}
    retval = CookieJar.__delitem__(**params)
    assert retval == None
    # case 1
    params = {}
    retval = CookieJar.__delitem__(**params)
    assert retval == None



# Generated at 2022-06-26 03:15:01.093319
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_1 = Cookie(key="foo",value="bar")
    assert var_1.__str__() == "foo=bar"


# Generated at 2022-06-26 03:15:11.442604
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # declare
    var_13 = CookieJar(doctest.mock._MagicMock())
    var_14 = CookieJar(doctest.mock._MagicMock())

    var_15 = CookieJar(doctest.mock._MagicMock())
    var_16 = CookieJar(doctest.mock._MagicMock())

    # begin
    var_13['var_5'] = 'var_5'
    var_14['var_5'] = 'var_5'
    var_15['var_5'] = 'var_5'
    var_16['var_5'] = 'var_5'


# Generated at 2022-06-26 03:15:16.734658
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_10 = Cookie("var_9", "var_10")
    var_10["var_2"] = "var_3"
    var_10["var_12"] = "var_15"
    var_10["var_12"] = "var_17"


# Generated at 2022-06-26 03:15:22.984223
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Assignments
    var_0 = None

    var_1 = Cookie(var_0, var_0)



# Generated at 2022-06-26 03:15:24.904470
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar(MultiHeader())
    jar.__delitem__("test")



# Generated at 2022-06-26 03:15:33.700824
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cu_0 = Cookie('name', 'value')
    cu_0['path'] = 'path'
    cu_0['comment'] = 'comment'
    cu_0['domain'] = 'domain'
    cu_0['max-age'] = 'max-age'
    cu_0['secure'] = 'secure'
    cu_0['httponly'] = 'httponly'
    cu_1 = cu_0.__str__()
    assert cu_0==cu_1



# Generated at 2022-06-26 03:15:36.069036
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    assert(cookie_jar == {})
    cookie_jar.__delitem__("key")


# Generated at 2022-06-26 03:15:41.513778
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_3 = Cookie("key0", "value0")
    var_3["path"] = "/"
    assert var_3["path"] == "/"
    var_3["path"] = "/bar"
    assert var_3["path"] == "/bar"
    var_3["path"] = "garbage"
    assert var_3["path"] == "garbage"


# Generated at 2022-06-26 03:15:44.248664
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_0 = Cookie()
    f_assert_object_value_equals(var_0.__str__(), None)


# Generated at 2022-06-26 03:15:48.802934
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_0 = Cookie("name","value")
    var_1 = "name=value; Path=/; Domain=; Max-Age=; Secure; HttpOnly; Version=; SameSite="
    assert var_0.__str__() == var_1


# Generated at 2022-06-26 03:15:59.128605
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_3 = Cookie(
        "test key",
        "test value",
    )
    assert var_3["test key"] == "test value", "test_case_0 failed"

    try:
        var_3["expires"] = "test value"
        assert False, "expected KeyError"
    except KeyError:
        pass

    try:
        var_3["test key"] = "test value"
        assert False, "expected KeyError"
    except KeyError:
        pass

    try:
        var_3["path"] = "test value"
        assert var_3["path"] == "test value", "test_case_0 failed"
    except KeyError:
        assert False, "expected KeyError"

    var_5 = Cookie(
        "test key",
        "test value",
    )
   

# Generated at 2022-06-26 03:16:00.890056
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_0 = Cookie("name", "value")
    assert var_0.__str__() == "name=value"



# Generated at 2022-06-26 03:16:11.863197
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_1 = Cookie(key="test", value="test")
    print(var_1)
    var_2 = Cookie(key="test", value="1")
    print(var_2)
    var_2.update({"secure": True})
    print(var_2)
    var_3 = Cookie(key="test", value="1")
    var_3.update({"path": "/hello"})
    print(var_3)
    var_4 = Cookie(key="test", value="1")
    var_4.update({"domain": "google.com"})
    print(var_4)
    var_5 = Cookie(key="test", value="1")
    var_5.update({"max-age": "123"})
    print(var_5)

# Generated at 2022-06-26 03:16:21.389761
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_0 = Cookie("foo", "bar")
    var_1 = var_0.__setitem__("path", "/")
    assert(var_1 == None)

    try:
        var_1 = var_0.__setitem__("expires", 0)
        print("bad: should have failed")
    except ValueError:
        pass

    try:
        var_1 = var_0.__setitem__("foo", 0)
        print("bad: should have failed")
    except KeyError:
        pass


# Generated at 2022-06-26 03:16:26.794109
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_0 = CookieJar(None)
    var_1 = Cookie("key", "value")
    var_2 = []
    var_3 = "cookie_headers"
    var_4 = Cookie("key", "value")
    var_5 = []
    var_6 = Cookie("key", "value")
    var_7 = []
    var_8 = "cookie_headers"
    var_9 = "key"
    var_10 = ""
    var_11 = Cookie("key", "")
    var_12 = []
    var_13 = "max-age"
    var_14 = 0
    var_15 = []
    var_16 = "cookie_headers"
    var_17 = "key"
    var_18 = "headers"
    var_19 = var_0
    var_20 = var_1

# Generated at 2022-06-26 03:16:38.693947
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_0 = Cookie(key="n1", value="v1")
    var_1 = main.Cookie(key="n2", value="v2")
    var_2 = Cookie(key="n3", value="v3")
    var_3 = Cookie(key="n4", value="v4")
    var_4 = Cookie(key="n5", value="v5")
    var_5 = Cookie(key="n6", value="v6")
    var_6 = Cookie(key="n7", value="v7")
    var_7 = Cookie(key="n8", value="v8")
    var_8 = Cookie(key="n9", value="v9")
    var_9 = Cookie(key="n10", value="v10")

    # assertEquals(value, expected):

# Generated at 2022-06-26 03:16:46.518823
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_1 = Cookie("Set-Cookie", "")
    var_1["httponly"] = False
    var_1["secure"] = False
    var_1["path"] = "/"
    var_1["max-age"] = 0
    var_1["version"] = 0
    var_1["samesite"] = None
    del var_1["Max-Age"]
    del var_1["Path"]
    del var_1["Secure"]
    del var_1["Version"]
    del var_1["HttpOnly"]
    del var_1["SameSite"]
    del var_1["httponly"]
    del var_1["secure"]
    del var_1["path"]
    del var_1["max-age"]
    del var_1["version"]
    del var_1["samesite"]
   

# Generated at 2022-06-26 03:16:52.069230
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_1 = Cookie("name", "value")
    assert ("%s=%s" % ("name", _quote("value"))) == ("%s=%s" % (var_1.key, _quote(var_1.value)))


# Generated at 2022-06-26 03:16:53.008777
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_0 = CookieJar({})


# Generated at 2022-06-26 03:16:57.165763
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Checks whether the content of the object is as expected
    def check_content(obj, expected):
        assert obj == expected, "Expected {0}, got {1}".format(expected, obj)

    # Initialize the object
    obj = CookieJar()
    expected = {}

    check_content(obj, expected)

# Generated at 2022-06-26 03:17:01.264725
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_1 = None
    # Test for __delitem__() without arguments.
    try:
        var_1 = CookieJar()
        test_case_0()
    except:
        print('An exception occurred while testing __delitem__()')
    return

# Run
test_CookieJar___delitem__()

# Generated at 2022-06-26 03:17:08.346230
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    var_0 = Cookie('c1', 'v1')
    var_1 = None
    try:
        # Raises exception when key is not in self._keys
        var_1 = var_0.__setitem__('max-age', '1')
    except KeyError:
        assert True
    else:
        assert False
    assert var_1 == None
    assert var_0.get('max-age') == None
    # test for integer
    var_1 = var_0.__setitem__('max-age', 1)
    assert var_1 == None
    assert var_0.get('max-age') == 1
    # test for string
    var_1 = var_0.__setitem__('max-age', '1')
    assert var_1 == None

# Generated at 2022-06-26 03:17:14.397238
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_1 = {
        'Set-Cookie': 'foo=bar; Path=/', 
        'Host': 'localhost:8080', 
        'Cookie': 'foo=bar', 
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.94 Safari/537.36', 
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8', 
        'Accept-Encoding': 'gzip, deflate, sdch', 
        'Accept-Language': 'en-US,en;q=0.8'
    }
    var_2 = None
    var_

# Generated at 2022-06-26 03:17:28.698790
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("\n** Testing Cookie.__str__ **\n")

    # cookie_1 = Cookie("test", "testing")
    # print(cookie_1)
    # cookie_1["secure"] = True
    # cookie_1["httponly"] = True
    # print(cookie_1)
    # cookie_1["max-age"] = "3600"
    # print(cookie_1)
    # cookie_1["version"] = "9999"
    # print(cookie_1)
    # cookie_1["path"] = "/test"
    # print(cookie_1)
    # cookie_1["domain"] = "test.com"
    # print(cookie_1)
    # cookie_1["comment"] = "test"
    # print(cookie_1)
    # cookie_1["expires"] = datetime

# Generated at 2022-06-26 03:17:31.149279
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Get an instance of the class
    t_0 = CookieJar()
    # Call method __delitem__
    test_case_0()
    return


# Generated at 2022-06-26 03:17:39.765516
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    assert "key" in cookie_jar
    assert "value" in cookie_jar.values()
    cookie_jar["key2"] = "value2"
    assert "key2" in cookie_jar
    assert "value2" in cookie_jar.values()
    del cookie_jar["key"]
    assert "key" not in cookie_jar
    assert "value" not in cookie_jar.values()
    assert "key2" in cookie_jar
    assert "value2" in cookie_jar.values()


# Generated at 2022-06-26 03:17:41.701049
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    expected = None
    actual = Cookie(None, None)

    assert expected == actual, f"Expected: {expected}, Actual: {actual}"


# Generated at 2022-06-26 03:17:43.696122
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_0 = None



# Generated at 2022-06-26 03:17:52.253136
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    params = {"headers": {}}
    if "headers" not in params:
        raise TypeError("expected at least one arguments, got zero")
    headers = params["headers"]
    cookiejar = CookieJar(headers)

    # Do the test here
    print("testing __delitem__")

    # Sample input
    cookiejar["test"] = "test value"
    del cookiejar["test"]

    # Sample input
    cookiejar["test"] = "test value"

    # Sample input
    del cookiejar["test"]

    # Sample input
    cookiejar["test"] = "test"

    # Sample input
    del cookiejar["test"]


# Generated at 2022-06-26 03:17:53.872427
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_case_0()


# Generated at 2022-06-26 03:17:56.780893
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_0 = Cookie(None, None)
    var_1 = str(var_0)


# Generated at 2022-06-26 03:18:02.993918
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    global var_0
    var_0 = Cookie(1,2)
    var_0["k"] = "v"
    assert var_0["k"] == "v"
    assert var_0.k == "v"


# Generated at 2022-06-26 03:18:13.216303
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookie = Cookie("my_cookie_name", "this is a cookie value")

    # Test 1.
    cookies["my_cookie_name"] = "this is a cookie value"
    if cookies["my_cookie_name"] == cookie:
        print("test_CookieJar___setitem__: [PASSED] test 1", flush=True)
    else:
        print("test_CookieJar___setitem__: [FAILED] test 1")
        print(cookies["my_cookie_name"])
        print(cookie)

    # Test 2.
    cookies["my_cookie_name"] = "this is a new cookie value"

# Generated at 2022-06-26 03:18:33.029703
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Initialization of a Cookie object
    cookie_0 = Cookie("key_0", "value_0")
    # Setting the attributes
    cookie_0["cookie_0"] = "cookie-0"
    cookie_0["cookie_1"] = "cookie-1"
    cookie_0["cookie_2"] = "cookie-2"
    cookie_0["cookie_3"] = "cookie-3"
    cookie_0["cookie_4"] = "cookie-4"
    cookie_0["cookie_1"] = "cookie-1"
    cookie_0["cookie_2"] = "cookie-2"
    cookie_0["cookie_3"] = "cookie-3"
    cookie_0["cookie_4"] = "cookie-4"
    cookie_0["cookie_1"] = "cookie-1"

# Generated at 2022-06-26 03:18:41.000381
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('testkey', 'testvalue')
    c["expires"] = "testvalue"
    c["path"] = "testvalue"
    c["comment"] = "testvalue"
    c["domain"] = "testvalue"
    c["max-age"] = "testvalue"
    c["secure"] = "testvalue"
    c["httponly"] = "testvalue"
    c["version"] = "testvalue"
    c["samesite"] = "testvalue"


# Generated at 2022-06-26 03:18:50.098671
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    var_0 = Cookie("key1", "value1")
    test_case_0()
    # Test for '%' operator
    assert (
        (
            "%s=%s; secure; expires=%a, %d-%b-%Y %T GMT; %s=%s; HttpOnly; %s=%s; %s=%s"
            % ("key1", "value1", "expires", "value1")
        )
        == "key1=value1; secure; expires=expires; value1; HttpOnly; Path=value1; Domain=value1; Comment=value1"
    )
    # Test for '%' operator

# Generated at 2022-06-26 03:18:58.784357
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create new CookieJar object
    var_0 = CookieJar({})
    # Modify instance attributes
    var_0['a'] = "b"
    var_0['c'] = "d"
    var_0.headers = {'Set-Cookie': ['Cookie("a", "b")', 'Cookie("a", "b")', 'Cookie("c", "d")']}
    var_0.cookie_headers = {'a': 'Set-Cookie', 'c': 'Set-Cookie'}
    # Return value
    return var_0


# Generated at 2022-06-26 03:19:01.496099
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_case_0()
    # The following code is for a unit test for method __delitem__ of class CookieJar
    assert True


# Generated at 2022-06-26 03:19:06.898287
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Test if exception is raised for the call
    # CookieJar.__setitem__(key, value)
    # with required parameters
    # Example 1 - expected call
    try:
        CookieJar.__setitem__(key, value)
    except TypeError as inst:
        assert(inst == TypeError('__setitem__() missing 1 required positional argument: \'value\''))


# Generated at 2022-06-26 03:19:10.076241
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    c = CookieJar({})
    c["foo"] = "bar"
    del c["foo"]
    assert "foo" not in c.cookie_headers
    assert "foo" not in c


# Generated at 2022-06-26 03:19:17.055081
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Create an instance of the class
    test_obj = Cookie('key_0', 'value_1')

    # Call the method
    try:
        test_obj.__setitem__('key_1', 'value_1')
    except:
        print('Exception: ', 'Cookie name is a reserved word')

    # Call the method
    try:
        test_obj.__setitem__('key_1', 'value_1')
    except:
        print('Exception: ', 'Unknown cookie property')


# Generated at 2022-06-26 03:19:21.562747
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test:
    #   cookie = Cookie("name", "value")
    #   assert str(self) == "name=value"
    var_0 = Cookie("name", "value")
    print(str(var_0))
    assert str(var_0) == "name=value"



# Generated at 2022-06-26 03:19:24.425719
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    var_0 = CookieJar(None)
    var_2 = None
    var_3 = None
    var_0.__setitem__(var_2, var_3)


# Generated at 2022-06-26 03:19:32.597842
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    global var_0
    var_0 = Cookie(None, None)



# Generated at 2022-06-26 03:19:35.653280
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_0 = CookieJar({}, )
    var_1 = var_0
    var_2 = NotImplemented
    var_3 = var_1.__delitem__(var_2)


# Generated at 2022-06-26 03:19:45.434090
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_14 = None
    var_15 = None
    var_16 = None
    var_17 = None
    var_18 = None
    var_19 = None
    var_20 = None
    var_21 = None
    var_22 = None
    var_23 = None
    var_24 = None
    var_25 = None
    var_26 = None
    var_27 = None
    var_

# Generated at 2022-06-26 03:19:48.017982
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_0 = CookieJar()
    # assert var_0.__delitem__("spam") is NoneType
    assert var_0.__delitem__("spam") is None


# Generated at 2022-06-26 03:19:49.058447
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_1 = CookieJar()

    # Invoke method
    var_1.__delitem__()



# Generated at 2022-06-26 03:19:56.121818
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_1 = None
    var_2 = None

    def test_case_1():
        nonlocal var_1, var_2
        var_1 = CookieJar(dict())
        var_2 = var_1.__delitem__("")
        return var_2

    def test_case_2():
        nonlocal var_1, var_2
        var_1 = CookieJar(dict())
        var_2 = var_1.__delitem__("")
        return var_2



# Generated at 2022-06-26 03:19:58.858114
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    var_1 = CookieJar({})
    var_1['a'] = 'b'
    print(var_1)
    del var_1['a']
    print(var_1)


# Generated at 2022-06-26 03:20:02.618823
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar(MultiHeader())
    jar["identifier"] = "abc"
    assert len(jar.headers) == 1
    del jar["identifier"]
    assert len(jar.headers) == 0


# Generated at 2022-06-26 03:20:10.084856
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    Backwards compatibility for __delitem__

    If a cookie does not exist, we delete it by replacing its value with
    the empty string and setting ``max-age`` to 0.
    """
    # Test that method __delitem__ exists, and add a test if applicable
    try:
        c = CookieJar()
        c["foo"]
        a = c["foo"]
        c.__delitem__(a)
    except KeyError:
        pass
    except Exception as e:
        raise Exception(
            "Test failed: Method __delitem__ of class CookieJar " +
            "threw an exception: '{}'".format(str(e))
        )


# Generated at 2022-06-26 03:20:10.975527
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    assert False


# Generated at 2022-06-26 03:20:21.710848
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("string", "string")
    assert (
        cookie_0.__str__() == "string=string"
    ), "Cookie.__str__() function error"



# Generated at 2022-06-26 03:20:24.361978
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = None
    #  test for key
    key = None
    cookie_jar.__delitem__(key)



# Generated at 2022-06-26 03:20:28.163792
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # cookie_jar_0 = CookieJar({})
    cookie_jar_1 = CookieJar(None)
    field_0 = "key"
    field_1 = "value"
    cookie_jar_1.__setitem__(field_0, field_1)


# Generated at 2022-06-26 03:20:30.053899
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0["cookie_0"] = "cookie_value_0"


# Generated at 2022-06-26 03:20:34.338970
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    key_0 = ''
    value_0 = ''
    cookie_jar_0[key_0] = value_0


# Generated at 2022-06-26 03:20:44.938501
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    cookie['path'] = 'path'
    cookie['max-age'] = 0
    cookie['httponly'] = True
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Path=path; Max-Age=0; HttpOnly; Secure'

    cookie['max-age'] = 'max-age'
    assert str(cookie) == 'name=value; Path=path; Max-Age=max-age; HttpOnly; Secure'

    del cookie['max-age']
    cookie['expires'] = datetime(1970, 1, 1, 0, 0, 0)
    assert str(cookie) == 'name=value; Path=path; Expires=Thu, 01-Jan-1970 00:00:00 GMT; HttpOnly; Secure'


# Generated at 2022-06-26 03:20:48.114644
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = None
    cookie_jar_1 = CookieJar(cookie_jar_0)
    cookie_jar_1["Color"] = "red"
    del cookie_jar_1["Color"]


# Generated at 2022-06-26 03:20:53.421372
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    jar = CookieJar(None)
    cookie_0 = Cookie("yummy_cookie", "choco")
    cookie_0['max-age'] = 600
    jar['yummy_cookie'] = "choco"
    str_0 = str(cookie_0)
    assert str_0 == "yummy_cookie=choco; Max-Age=600"


# Generated at 2022-06-26 03:20:56.013343
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_key = "foo"
    test_value = "bar"
    cookie_0 = Cookie(test_key, test_value)
    str_cookie_0 = str(cookie_0)
    assert str_cookie_0 == "foo=bar"

# Generated at 2022-06-26 03:21:00.148848
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = None
    cookie_jar_1 = CookieJar(cookie_jar_0)
    cookie_2 = Cookie(cookie_jar_0, cookie_jar_1)
    cookie_3 = cookie_2.__str__()
    assert cookie_3 is not None



# Generated at 2022-06-26 03:21:15.893996
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar({})



# Generated at 2022-06-26 03:21:21.938200
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Create a CookieJar
    cookie_jar_0: CookieJar = CookieJar(None)
    cookie_jar_1: CookieJar = CookieJar(cookie_jar_0)
    # Set a cookie in cookie_jar_1
    cookie_key: str = "test-key"
    cookie_value: str = "test-value"
    cookie_jar_1[cookie_key] = cookie_value
    # Check if the cookie is stored under the correct key in cookie_jar_1
    assert cookie_jar_1[cookie_key].value == cookie_value
    # Check if the cookie is set in cookie_jar_0
    assert cookie_jar_0[cookie_key].value == cookie_value
