

# Generated at 2022-06-26 03:11:32.571772
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = str()
    value_0 = str()
    cookie_2 = Cookie(key_0, value_0)
    str_0 = cookie_2.__str__()
    assert str_0 == ""



# Generated at 2022-06-26 03:11:37.526264
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_0 = Cookie(bytes_0, bytes_0)

    # Test results
    assert cookie_0.__str__() == '\xb5\xbe\x80:\x8a\x0c=\\xb5\\xbe\\x80:\\x8a\\x0c'



# Generated at 2022-06-26 03:11:51.444631
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-26 03:12:04.464347
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    string_0 = Cookie(b'\x00\x00\x008)', b'\x8e\x0c\x04\x07\x1b\x98\x07\xdb\xc9\x13)(\x1b\x18\x1d\xcb\x8e\x03')['\x00\x00\x008)']
    assert_equal(string_0, None)

# Generated at 2022-06-26 03:12:14.005165
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_obj_0 = Cookie("key_0", "value_0")
    cookie_obj_0["max-age"] = "44"
    cookie_obj_0["expires"] = datetime(2019, 5, 9, 8, 8, 5, 9239)
    cookie_obj_0["secure"] = False
    cookie_obj_0["httponly"] = False
    try:
        str_0 = cookie_obj_0.__str__()
        print(str_0)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 03:12:24.366692
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = '\xfb>\xd9\x01\x06\xfa\x03\x99\x90\x14\x9c\xa9\x9a\x82\x01\x0b\xe8\x00\xe0\x7f\x07\x02\x819\x0f\xde\xc3\x19\x12\xbf\x10\xeb\x15\xd8'

# Generated at 2022-06-26 03:12:34.425535
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test 1
    key = "foo"
    value = ""
    cookie = Cookie(key, value)
    expected = "foo="
    assert cookie.__str__() == expected

    key = "bar"
    value = ""
    cookie = Cookie(key, value)
    expected = "bar="
    assert cookie.__str__() == expected

     # Test 2
    key = "foo"
    value = "bar"
    cookie = Cookie(key, value)
    expected = "foo=bar"
    assert cookie.__str__() == expected
    print("passed: test_Cookie___str__")


# Generated at 2022-06-26 03:12:38.151792
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    cookie_0 = Cookie('cookie_0', 'cookie_0')
    cookie_0['path'] = '/'
    print("Cookie: {}".format(str(cookie_0)))
    assert str(cookie_0) == "/=cookie_0"


# Generated at 2022-06-26 03:12:50.597548
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie("foo", "")
    cookie_0.__setitem__("path", "/")
    cookie_0["path"] = "/"

    try:
        cookie_0.__setitem__("mortal", "snake")
    except KeyError:
        pass
    else:
        assert False, "unexpected exception"

    # Try to set max-age
    cookie_0.__setitem__("max-age", "1")
    cookie_0.__setitem__("max-age", "1")
    cookie_0.__setitem__("max-age", "10")
    cookie_0.__setitem__("max-age", "1")
    cookie_0.__setitem__("max-age", "1")
    cookie_0.__setitem__("max-age", "1")

# Generated at 2022-06-26 03:12:55.299678
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    headers = []


    cookie_jar_0 = CookieJar(headers)
    cookie_jar_0['cookie-name'] = 'cookie_value'
    cookie_jar_1 = CookieJar(headers)
    cookie_jar_1['cookie-name'] = 'cookie_value'
    cookie_jar_1['cookie-name'] = 'cookie_value'
    assert len(headers) == 1



# Generated at 2022-06-26 03:13:04.671618
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    jar = CookieJar(headers={})
    jar["key"] = "value"
    jar.__setitem__("key", "value")
    assert jar["key"].value == "value"

    jar["key"] = "new-value"
    jar.__setitem__("key", "new-value")
    assert jar["key"].value == "new-value"

    jar.__setitem__("key", "new-value-2")
    assert jar["key"].value == "new-value-2"


# Generated at 2022-06-26 03:13:16.205399
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    str_0 = 'û>Ù\x01\x06ú\x03\x99\x90\x14\x9c©\x9a\x82\x01\x0bè\x00à\x7f\x07\x02\x819\x0fÞÃ\x19\x12¿\x10ë\x15Ø'
    str_1 = 'û>Ù\x01\x06ú\x03\x99\x90\x14\x9c©\x9a\x82\x01\x0bè\x00à\x7f\x07\x02\x819\x0fÞÃ\x19\x12¿\x10ë\x15Ø'

# Generated at 2022-06-26 03:13:24.500339
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Setup
    cookie = Cookie()
    cookie.__setitem__('key', 'value')
    cookie.__setitem__('key2', 'value2')
    str_0 = 'key=value; key2=value2'
    # Test
    assert str(cookie) == str_0

# ------------------------------------------------------------ #
#  TESTS
# ------------------------------------------------------------ #


# Generated at 2022-06-26 03:13:30.236791
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    arg_0 = 'LÎ\x1aÜ'
    arg_1 = 'Û\x7fm\x0c'
    arg_2 = '\x08\nÝ\n\x12«\x1cÄ\x1b\tï'
    obj = Cookie(arg_0, arg_1)
    if "httponly" in obj.keys():
        obj.__setitem__("httponly", arg_2)
    pass



# Generated at 2022-06-26 03:13:41.849189
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    print(  CookieJar(headers={"set-Cookie": "Set-Cookie"}))
    with pytest.raises(KeyError):
        print(  CookieJar(headers={"set-Cookie": "Set-Cookie"}).__setitem__(key="", value=""))
    with pytest.raises(KeyError):
        print(  CookieJar(headers={"set-Cookie": "Set-Cookie"}).__setitem__(key="", value=""))
    print(  CookieJar(headers={"set-Cookie": "Set-Cookie"}).__setitem__(key="\"+_LocaL_Host+\":\"+_LocaL_Port+\"", value=""))

# Generated at 2022-06-26 03:13:51.554322
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from overhang.http.cookies import CookieJar
    # Initialization of the class
    headers = None
    cookiejar = CookieJar(headers)
    # Assigning a value to the variable
    key = 'str_0'
    # Assigning a value to the variable
    value = 'str_0'
    # Calling the function
    cookiejar.__setitem__(key, value)
    # Observation
    # The value of the variable
    assert key == 'str_0'
    # The value of the variable
    assert value == 'str_0'


# Generated at 2022-06-26 03:13:55.783188
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        cookie = Cookie(str_0, str_0)
        cookie.__setitem__(str_0, False)
        assert(False)
    except ValueError:
        assert(True)

    try:
        cookie = Cookie(str_0, str_0)
        cookie.__setitem__(str_0, False)
        assert(False)
    except KeyError:
        assert(True)

    try:
        cookie = Cookie(str_0, str_0)
        cookie.__setitem__(str_0, False)
        assert(False)
    except ValueError:
        assert(True)


# Generated at 2022-06-26 03:14:06.001857
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Create object for class Cookie
    object_Cookie = Cookie("key", "value")

    # Test case 0
    test_case_0()
    # Unit test for method __setitem__ of class Cookie
    # This test case sets a reserved word

    # Create object for class Cookie
    object_Cookie = Cookie("key", "value")

    # Call method __setitem__ of class Cookie
    try:
        result = object_Cookie.__setitem__("max-age", 0)
    except KeyError as e:
        print("KeyError:", e)

    # Test case 1
    test_case_0()
    # Unit test for method __setitem__ of class Cookie
    # This test case sets a reserved word

    # Create object for class Cookie
    object_Cookie = Cookie("key", "value")

    # Call

# Generated at 2022-06-26 03:14:09.062501
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    params = {"key": "key", "value": "value"}
    cookie = Cookie(**params)
    with pytest.raises(KeyError):
        cookie.__setitem__("key", "value")


# Generated at 2022-06-26 03:14:13.310757
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key_0", "value_0")
    key = "key_0"
    value = "value_0"
    try:
        cookie.__setitem__(key, value)
        assert True
    except KeyError:
        assert False


# Generated at 2022-06-26 03:14:27.052199
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict({})
    cj = CookieJar(headers)
    str_0 = 'û>Ù\x01\x06ú\x03\x99\x90\x14\x9c©\x9a\x82\x01\x0bè\x00à\x7f\x07\x02\x819\x0fÞÃ\x19\x12¿\x10ë\x15Ø'
    cookies = SimpleCookie(str_0)
    cookie = cookies[str_0]
    cj[str_0] = cookie
    cj_0 = cj[str_0]
    cj_0.__delitem__("max-age")


# Generated at 2022-06-26 03:14:28.408081
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_case_0()


# Generated at 2022-06-26 03:14:37.663455
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    def __delitem__0():
        self = CookieJar(None)

        key = None
        self.cookie_headers = {'a': 'b'}

        # Call the method
        self.__delitem__(key)

        # Verify the result
        assert True

    def __delitem__1():
        self = CookieJar(None)

        key = 'a'
        self.cookie_headers = {'a': 'b', 'c': 'd'}
        self.headers = {'b': ['c'], 'a': ['b']}
        self.header_key = 'Set-Cookie'

        # Call the method
        self.__delitem__(key)

        # Verify the result
        assert True

    def __delitem__2():
        self = CookieJar(None)

        key = 'a'

# Generated at 2022-06-26 03:14:49.351462
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test default argument 'value' of __str__
    cookie_0 = Cookie('key_0', None)

    str_0 = str(cookie_0)

    assert (str_0 == 'key_0=')

    # Test default argument 'key' of __init__
    cookie_1 = Cookie(None, 'value_0')

    assert (cookie_1.value == 'value_0')

    # Test default argument 'key' and 'value' of __init__
    cookie_2 = Cookie(None, None)

    assert (cookie_2.key == 'None')

    assert (cookie_2.value == 'None')

    # Test default argument 'key' of Cookie
    cookie_3 = Cookie('key_1', 'value_1')

    assert (cookie_3.key == 'key_1')


# Generated at 2022-06-26 03:14:55.397700
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        _headers = None
        _jar = CookieJar(_headers)
        _key = 'Str_3'
        _value = 'Str_3'
        _jar[_key] = _value
        _jar.__delitem__(_key)
        assert (_jar.__contains__(_key) == False)
    except:
        print("Exception raised in test_CookieJar___delitem__")
        raise


# Generated at 2022-06-26 03:15:01.584268
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    The method __setitem__ of class Cookie will raise a ValueError if 
    the key 'max-age' is not an integer.

    Here we will test the method __setitem__ of class Cookie by
    supplying a value that is not an integer to the key 'max-age'
    and asserting a ValueError is raised.
    """
    mycookie = Cookie('test_key', 'test_value')
    mycookie["max-age"] = "test_value"

    assert mycookie["max-age"] == "test_value"
    # The next line should raise a ValueError.
    with pytest.raises(ValueError) as exception_info:
        mycookie["max-age"] = 'test_value_2'


# Generated at 2022-06-26 03:15:14.724806
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    class_ = Cookie
    obj = class_('test_key_0', 'test_value_0')
    # set the value of some properties
    obj['comment'] = 'test_value_1'
    obj['domain'] = 'test_value_2'
    obj['expires'] = datetime.fromtimestamp(1598771298)
    obj['max-age'] = 'test_value_4'
    obj['path'] = 'test_value_5'
    obj['same-site'] = 'test_value_6'
    obj['secure'] = False
    obj['version'] = 'test_value_8'

    # Call method
    str_ = obj.__str__()

# Generated at 2022-06-26 03:15:21.122873
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create a new CookieJar object to test
    cookiejar = CookieJar(MultiHeader())
    # Add four item to test
    cookiejar["t1"] = "v1"
    cookiejar["t2"] = "v2"
    cookiejar["t3"] = "v3"
    cookiejar["t4"] = "v4"
    # Delete three items
    del cookiejar["t1"]
    del cookiejar["t3"]
    del cookiejar["t2"]
    # Test if the key is removed
    result = "t4" in cookiejar
    assert result == True


# Generated at 2022-06-26 03:15:24.510971
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_cookie = CookieJar({})
    assert test_cookie.__delitem__("x") is None
    try:
        test_cookie.__delitem__("x")
        return {'status': 1, 'msg': 'exception not thrown'}
    except KeyError:
        return {'status': 0}


# Generated at 2022-06-26 03:15:30.960981
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'key'
    value = 'value'
    c = Cookie(key, value)
    c['expires'] = None
    c['max-age'] = 0
    c['path'] = '/'
    c['comment'] = None
    c['domain'] = None
    c['secure'] = False
    c['httponly'] = False
    c['version'] = None
    c['samesite'] = None
    if (c['expires'] != None):
        raise RuntimeError("Incorrect output for test_Cookie___setitem__")
    if (c['max-age'] != 0):
        raise RuntimeError("Incorrect output for test_Cookie___setitem__")
    if (c['path'] != '/'):
        raise RuntimeError("Incorrect output for test_Cookie___setitem__")

# Generated at 2022-06-26 03:15:45.144149
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_mock_0 = Mock()
    cookie_mock_0.strftime = Mock()
    cookie_mock_0.strftime.return_value = 'N4N@'
    cookie_mock_0.strftime.return_value = 'N4N@'
    cookie_mock_0.strftime.return_value = 'N4N@'
    cookie_mock_0.strftime.return_value = 'N4N@'
    cookie_mock_0.strftime.return_value = 'N4N@'
    cookie_mock_0.strftime.return_value = 'N4N@'
    cookie_mock_0.strftime.side_effect = KeyError()
    cookie_mock_0.key = 'X'
    cookie_mock_0.value

# Generated at 2022-06-26 03:15:48.719467
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # CookieJar() instanciation
    cookie_jar = CookieJar()
    # KeyError test cases
    try:
        cookie_jar['key']='value'
    except KeyError:
        assert True

# Generated at 2022-06-26 03:15:53.279769
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    del cookie_jar_0['\x8d\x0c\x88\x95\x8c']



# Generated at 2022-06-26 03:16:02.040539
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('\x07\x18\x89\x12\x1b', '\x07\x18\x89\x12\x1b')
    cookie_0['path'] = ''
    cookie_0['secure'] = '\x07\x18\x89\x12\x1b'
    cookie_0['samesite'] = '\x07\x18\x89\x12\x1b'
    cookie_0['max-age'] = '\x07\x18\x89\x12\x1b'
    cookie_0['expires'] = datetime.now()
    cookie_0['comment'] = '\x07\x18\x89\x12\x1b'

# Generated at 2022-06-26 03:16:12.679729
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.__delitem__('Q\x14')
    cookie_jar_0.__delitem__('\x1e')
    cookie_jar_0.__delitem__('\x00')
    cookie_jar_0.__delitem__('\x01')
    cookie_jar_0.__delitem__('\x02')
    cookie_jar_0.__delitem__('\x03')
    cookie_jar_0.__delitem__('\x04')
    cookie_jar_0.__delitem__('\x05')



# Generated at 2022-06-26 03:16:20.787684
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'\xd0\x15\x0f)\t\xb1\x95`\xc0\x15\x7f\x90\x00<'
    cookie_jar_0 = CookieJar(headers=bytes_0)
    expected = '<Set-Cookie: .AspNet.ApplicationCookie=; max-age=0>'
    output = str(cookie_jar_0['f.5[!\xc2\x9d\xcc\xa4\xb5\xff'])
    if output != expected:
        raise RuntimeError('test failed: expected %s, got %s' % (expected, output))
    
    

# Generated at 2022-06-26 03:16:23.463893
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Setup
    cookie_jar_0 = Cookie(Cookie, str)
    # AssertionError
    with pytest.raises(AssertionError):
        "; ".join(cookie_jar_0)

# Generated at 2022-06-26 03:16:34.450633
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_0 = Cookie(bytes_0, bytes_0)
    result_0 = cookie_0.__str__()
    assert type(result_0) == str
    print(result_0)

    bytes_1 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_1 = Cookie(bytes_1, bytes_1)
    result_1 = cookie_1.__str__()
    assert type(result_1) == str
    print(result_1)

    bytes_2 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_2 = Cookie(bytes_2, bytes_2)
    result_2 = cookie_

# Generated at 2022-06-26 03:16:38.851826
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    assert cookie_jar_0.__str__() == 'Set-Cookie'


# Generated at 2022-06-26 03:16:46.472796
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key_0 = '\x8f\xaf\x84\xeb\x1c\xd4\xab\x0c\xb9\xc4\xb1\xfe\x11\x13\x0f\xee\xfb\x86\xd9\xc9\x8a\x1b\x16\xc4\x8e\x18\xd4\x12\xd9\xaf\xf4\x83'

# Generated at 2022-06-26 03:17:05.229257
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'h\x00\xb1\x00\xfd\x91T\xb8\x98\xa6\x95\x10N\xc8\xf9\x9b\x01\x00\x00\x18\x00\x00\x00'
    bytes_1 = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-26 03:17:14.948407
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'+\x1c\xaa\xa4\x80\xa3\x0f\x1d\x8e\x1c\x05\x96\x8d\xe7\xbe\xc4\x88\x8d\x98\xde\x00\x17\x9e\xb2\xba\xfe\xe6\x8c\x12\xfb\x83\xd1\x8b\x03\x0f\x17\xa0\x83\x08\x91\x0f\x1c'
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = ';ecP'

# Generated at 2022-06-26 03:17:23.589736
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    key = ''
    headers = {'Accept': 'text/html, application/xhtml+xml, */*', 'Accept-Language': 'en-US', 'User-Agent': 'Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)', 'Accept-Encoding': 'gzip, deflate', 'Host': 'httpbin.org', 'DNT': '1', 'Connection': 'Keep-Alive', 'Cache-Control': 'no-cache'}
    cookie_jar_0 = CookieJar(headers)
    cookie_jar_0['key'] = ''
    cookie_jar_0.__delitem__(key)


# Generated at 2022-06-26 03:17:28.366385
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Initialize the class the test will run on
    cookie_0 = Cookie()

    # Initialize other necessary objects
    bytes_0 = b'test'

    # Run the method to test
    cookie_0___str__(cookie_0, bytes_0)


# Generated at 2022-06-26 03:17:33.702189
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    key_0 = "8o[OgrX5"
    cookie_jar_0[key_0] = DEFAULT_MAX_AGE
    del cookie_jar_0[key_0]


# Generated at 2022-06-26 03:17:42.668067
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xe4\xe4\xd7\xdb\xe3\x8eM\xd4\xa6b\xf6\x9e\xc71\x02\x12\x8f'
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = '\x14'
    str_1 = '\x02'
    bytes_1 = b'\x9f\t\xbb\xbf\xb2)\xe8\xc0\xec\x90\x02\x9c'

# Generated at 2022-06-26 03:17:47.917673
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    try:
        bytes_0 = b'\t\x14\xfe?\x80\x00\xc5\x1b\x0c'
        cookie_jar_0 = CookieJar(bytes_0)
        cookie_jar_0[0] = 0
        assert False
    except IndexError:
        assert True


# Generated at 2022-06-26 03:17:54.866689
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    # Input:
    key_0 = "`"
    value_0 = "f"

    # Invoke method:
    cookie_jar_0 = CookieJar({})
    cookie_jar_0.__setitem__(key_0, value_0)

    # Check results:
    assert cookie_jar_0.headers == {
        "Set-Cookie": '"`=f"; Path=/'
    }, "Incorrect result for method '__setitem__' of class 'CookieJar'"


# Generated at 2022-06-26 03:18:06.937069
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Create an instance of Cookie
    dict_0 = {'expires': datetime(2004, 7, 6, 3, 3, 19), 'samesite': 'Secure', 'httponly': True, 'max-age': -2147483648}
    cookie_0 = Cookie('\u20a8\ue6a4\u5a0a\u1028\u5e29', b'\x17\xd2\x97\xf1\xfd$')
    cookie_0.update(dict_0)
    # Begin unit test for method __str__ of class Cookie
    assert len(cookie_0.__str__()) > 0


# Generated at 2022-06-26 03:18:13.068387
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # init cookie
    cookie_0 = Cookie('\x9d\xb8\xec\xa0\xab\xa74\x8d', '\xcc\xfe\xa9\x15\x93\xb0\x06')
    assert str(cookie_0) == '\x9d\xb8\xec\xa0\xab\xa74\x8d=\xcc\xfe\xa9\x15\x93\xb0\x06'


# Generated at 2022-06-26 03:18:33.190455
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'6\x08\x84\x0c\x8b\x11\x0c'
    dict_0 = dict()
    dict_0["cookie_name_1"] = "cookie_value_2"
    dict_0["cookie_name_2"] = "cookie_value_3"
    cookie_jar_0 = CookieJar(dict_0)
    str_0 = cookie_jar_0.__str__()
    assert str_0 == "cookie_value_2; cookie_value_3"


# Generated at 2022-06-26 03:18:44.284309
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    bytes_1 = b'\x99\x1d!\x96\x06\xa8\xbf\xe5\x81U\x92\xb0\x80\x1d\xac\xd1\x88\xb6\xd2\xc3'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_0 = Cookie(bytes_1, bytes_1)

# Generated at 2022-06-26 03:18:52.492787
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)

# Generated at 2022-06-26 03:18:56.637668
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Set-up test environment

    # Assume
    cookie_0 = Cookie('foo', 'bar')

    # Assert
    assert cookie_0.__str__() == 'foo=bar'



# Generated at 2022-06-26 03:19:04.239197
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'\xde\x96\x8b\xa7\x9c\x1a\x8du\xa6\xac\xab\x16\xd8h\xc3'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.__setitem__("c\xf5", "X\xa7\x1f\x1a\x88\x91\xee\x1e")
    cookie_jar_0.__setitem__("\x8b\xd4", "\xef")


# Generated at 2022-06-26 03:19:09.134787
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_1 = Cookie('foo', 'bar')
    # Unit tests for method encode of class Cookie
    # 
    # Unit tests for method __init__ of class Cookie
    # 
    # Unit tests for method __setitem__ of class Cookie
    # 
    
if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 03:19:14.060335
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b'\xee\x1f\x1c\xb7\x0b'
    cookie_jar_0[bytes_1] = None



# Generated at 2022-06-26 03:19:19.257645
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b'\x84\x06\x02\x99\xab\x12\x9d\xdd'
    cookie_jar_0[bytes_1]


# Generated at 2022-06-26 03:19:27.688712
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:19:38.628150
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import random
    import string
    import tempfile
    import os

    fd, path = tempfile.mkstemp()
    os.close(fd)

    try:
        os.unlink(path)
    except OSError:
        pass

    os.mkdir(path)


# Generated at 2022-06-26 03:20:26.691231
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key_0 = 'K'
    value_0 = 'AFCU6?/U6<'
    cookie_0 = Cookie(key_0, value_0)
    key_1 = '_0(UXY,?5'
    value_1 = -20.095876087156836
    cookie_0[key_1] = value_1
    key_2 = ']*K2ZT)T$=X'

# Generated at 2022-06-26 03:20:32.564422
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    cookie_0 = Cookie('sje', 'jbe')
    assert cookie_0.__str__() == 'sje=jbe'

    cookie_1 = Cookie('sje', 'jbe')
    assert cookie_1.__str__() == 'sje=jbe'

    cookie_2 = Cookie('sje', 'jbe')
    assert cookie_2.__str__() == 'sje=jbe'

    cookie_3 = Cookie('sje', 'jbe')
    assert cookie_3.__str__() == 'sje=jbe'

# Generated at 2022-06-26 03:20:42.852379
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = '\xf2\xcd\xcc\xeb'

# Generated at 2022-06-26 03:20:46.701924
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xadF\x8e\x0f\x1b\x96'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.__delitem__(str())
    assert True


# Generated at 2022-06-26 03:20:54.202088
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'$\x03\xe0\x87\x96yz]'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_0 = Cookie("D?[", "9]\x80")
    cookie_0["path"] = "/"
    cookie_jar_0["D?["] = cookie_0
    cookie_jar_0["D?["] = "F&_>\r"
    cookie_jar_0["D?["]["max-age"] = 0
    assert cookie_jar_0["D?["] == 0


# Generated at 2022-06-26 03:21:03.127994
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_0 = cookie_jar_0[b'\xb5\xbe\x80:\x8a\x0c']
    cookie_0['\xb5\xbe\x80:\x8a\x0c'] = str()
    # assert ';' in str(cookie_0)
    cookie_0['\xb5\xbe\x80:\x8a\x0c'] = bool()
    # assert ';' in str(cookie_0)
    cookie_0['\xb5\xbe\x80:\x8a\x0c'] = bytes()
    # assert ';' in str(cookie_0)
    cookie_

# Generated at 2022-06-26 03:21:12.811887
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xb5\xbe\x80:\x8a\x0c'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.headers = {
        "Set-Cookie": "2; secure",
        "set-cookie": "2; secure"
    }

    cookie_jar_0["test_string"] = "test_value"
    cookie_jar_0["test_string"]["expires"] = datetime(
        2019, 1, 1, 12, 12, 12
    )
    cookie_jar_0["test_string"]["max-age"] = "3600"
    cookie_jar_0["test_string"]["domain"] = ".testdomain.com"
    cookie_jar_0["test_string"]["secure"] = True


# Generated at 2022-06-26 03:21:19.921158
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test with an invalid cookie key
    bytes_0 = b'\x11\x5f\xe7\xba\x9b\xcb\x94\x07\x0c\x16\x0bj\xc6\x92\x9f\x86\x8a\xd4\x98'
    cookie_jar_0 = CookieJar(bytes_0)

    cookie_0 = Cookie("k", "v")
    # AssertionError: Cookie key contains illegal characters
    with pytest.raises(AssertionError):
        cookie_0.__str__()
    # Test with an invalid cookie value
    bytes_1 = b'\xfb\n\xef'
    cookie_jar_1 = CookieJar(bytes_1)

    cookie_1 = Cookie("key", "v")
    #

# Generated at 2022-06-26 03:21:28.134564
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('T-L;\x9c<', '!#\xfd')
    bytes_0 = b'\x12p[\xb6F\xc6\x9f\x91\xdb\x82\xe6'
    cookie_1 = Cookie(bytes_0, b'\xb3.\x1e\x1a\x1e')
    bytes_1 = b'\xc0\xfd\xd1\x86\x9c\xa0\x1d\x91\xb8\xba\xeb\xc1\xd2'
    cookie_2 = Cookie(bytes_1, b'\x1f\x80\x1d\x10\xea\x00\xe9\xe2\x85\x01')