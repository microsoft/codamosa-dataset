

# Generated at 2022-06-26 03:11:28.473157
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("key_0", "")
    str_0 = str(cookie_0)
    assert str_0 == 'key_0=""'



# Generated at 2022-06-26 03:11:32.988713
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    str_0 = "CookieJar.__delitem__"
    try:
        cookie_jar_0.__delitem__(str_0)
    except NotImplementedError:
        pass


# Generated at 2022-06-26 03:11:41.489845
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # If a header with that name exists, delete it.
    bool_0 = True
    dict_0 = {}
    cookie_0 = Cookie(dict_0, bool_0)
    cookie_0["path"] = "/"
    cookie_jar_0 = CookieJar(bool_0)
    cookie_jar_0["foo"] = cookie_0
    cookie_jar_0.__delitem__("foo")
    assert_equal("foo" in cookie_jar_0.cookie_headers, False)

    # If a header with that name doesn't exist, add it in, then delete it.
    bool_1 = True
    dict_1 = {}
    cookie_1 = Cookie(dict_1, bool_1)
    cookie_1["path"] = "/"
    cookie_jar_1 = CookieJar(bool_1)
    cookie

# Generated at 2022-06-26 03:11:54.079199
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = "&C{[5"

# Generated at 2022-06-26 03:11:58.146475
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = "l!qL!mz7a"
    cookie_0 = Cookie(str_0, str_0)
    string_0 = cookie_0.__str__()
    assert string_0 == "l!qL!mz7a=l%21qL%21mz7a"


# Generated at 2022-06-26 03:12:00.159281
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    val = str(cookie)
    assert val == "key=value"



# Generated at 2022-06-26 03:12:02.359032
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-26 03:12:06.565626
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    num_0 = int()
    num_1 = int()
    num_2 = int()
    cookie_jar_0 = CookieJar(num_1)
    cookie_0 = Cookie(num_2, num_2)
    cookie_0["max-age"] = num_2
    cookie_0["expires"] = num_1
    cookie_0["max-age"] = num_2
    cookie_0["secure"] = num_1
    cookie_0["httponly"] = num_0
    assert isinstance(str(cookie_0), str)


# Generated at 2022-06-26 03:12:10.471869
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    instance_0 = Cookie("", "")
    string_0 = "sir"

    try:
        instance_0["sir"] = string_0
        print("Expected exception")
    except KeyError:
        pass


# Generated at 2022-06-26 03:12:14.135313
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({})
    cookie_jar_0.__delitem__('4_Xy:m')
    cookie_jar_0.__delitem__(429394826)



# Generated at 2022-06-26 03:12:27.024448
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    global str_0
    str_0 = '&C{[5'
    dict_0 = dict()
    dict_1 = dict()
    dict_1['method'] = 'POST'
    dict_1['uri'] = 'stooge.com/baz'
    dict_1['headers'] = dict()
    dict_1['post_data'] = 'foobax=4'
    dict_2 = dict()
    dict_2['path'] = '/'
    dict_2['max-age'] = 0
    dict_2['secure'] = False
    dict_2['version'] = ''
    dict_2['httponly'] = False
    dict_2['key'] = 'foo'
    dict_2['value'] = 'baz'
    dict_2['comment'] = ''
    dict_2['domain']

# Generated at 2022-06-26 03:12:37.949347
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = '+5{))$K'
    str_1 = '\\Nz+}'
    str_2 = 'CQ'
    str_3 = '%08U'
    str_4 = 'AGb'
    str_5 = 'q'
    str_6 = 'R'
    str_7 = '%'
    str_8 = '#'
    str_9 = 'AU'
    str_10 = 'tC'
    str_11 = 'D|f'
    str_12 = 'Ek'
    str_13 = 'ZC'
    str_14 = '@i'
    str_15 = '3'
    str_16 = 'H'
    str_17 = 'f1'
    str_18 = 'eD'
    str_19 = ','

# Generated at 2022-06-26 03:12:50.460057
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # should work when no keyword is specified
    cookie = Cookie('keyA', 'valueA')
    expected = "keyA=valueA"
    assert cookie.__str__()==expected

    # should work when multiple keyword is specified
    cookie = Cookie('keyA', 'valueA')
    cookie['Path'] = '/'
    cookie['Expires'] = 'Tue, 31 Jul 2019 03:51:04 GMT'
    cookie['HttpOnly'] = False
    cookie['Secure'] = False
    cookie['Version'] = None
    cookie['SameSite'] = 'Lax'
    expected = "keyA=valueA; Version; SameSite=Lax; Expires=Tue, 31 Jul 2019 03:51:04 GMT; Path=/"
    assert cookie.__str__()==expected

    # should work when keyword is only "secure"
    cookie = Cookie

# Generated at 2022-06-26 03:13:00.546490
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = '&C{[5'
    str_1 = '~m'
    str_2 = '+y'
    str_3 = 'x'
    str_4 = '* 3'
    str_5 = '7B'
    str_6 = 'v*'
    str_7 = '{'
    str_8 = ';'
    str_9 = 'G+'
    str_10 = '@'
    str_11 = 'g'
    str_12 = ','
    str_13 = 'A'
    str_14 = 'Z'
    str_15 = 'I'
    str_16 = 'p'
    str_17 = 'l'
    str_18 = 'c'
    str_19 = '|'
    str_20 = 'J'
   

# Generated at 2022-06-26 03:13:02.108759
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar()
    jar['name'] = "value"
    assert jar['name'] == 'value'
    del jar['name']
    assert not jar.headers


# Generated at 2022-06-26 03:13:14.038930
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test cases
    print("Test 1: Empty dictionary")
    c = Cookie('name', 'value')
    assert c == {}
    print("Test 2: Valid key, value")
    c['expires'] = 0
    assert c == {'expires': 0}
    print("Test 3: Valid key, invalid value")
    c['expires'] = '0'
    assert c == {'expires': 0}
    c['max-age'] = 1
    assert c == {'expires': 0, 'max-age': 1}
    c['secure'] = True
    assert c == {'expires': 0, 'max-age': 1, 'secure': True}
    c['httponly'] = True

# Generated at 2022-06-26 03:13:21.394502
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = "ltj?h!Ffnr"
    str_1 = "9_h1j%c;Y"

    try:
        assert str_0 is not None
    except AssertionError:
        print('AssertionError')


# Generated at 2022-06-26 03:13:28.799729
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

    # Test case 0
    cookie_jar['key'] = 'value'
    assert headers[('set-cookie', 'key=value; Path=/')] == {'Path': '/'}

    # Test case 1
    assert cookie_jar[('key')] == {'Path': '/'}
    assert cookie_jar[('key')]['value'] == 'value'

    # Test case 2
    assert cookie_jar[('key')]['max-age'] == 0


# Generated at 2022-06-26 03:13:34.521978
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    cookie_jar['key1'] = 'value1'
    cookie_jar['key2'] = 'value2'
    cookie_jar['key1'] = 'value1'

# Generated at 2022-06-26 03:13:38.421899
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = "cookie_name"
    value = "cookie_value"
    cookie = Cookie(key, value)

    key = "expires"
    value = datetime.now()
    cookie[key] = value


# Generated at 2022-06-26 03:13:52.213955
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = []
    cookie_0 = CookieJar(headers)
    key = 'u%/8'
    value = 'z:$6'
    cookie_0[key] = value # __setitem__
    assert headers[0].keys == 'u%/8'
    assert headers[0].values == 'z:$6'



# Generated at 2022-06-26 03:13:53.788318
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Test with an empty dict
    headers = {}

    CookieJar(headers)

    # Test with a dict
    headers = {
        "name": "value",
    }

    CookieJar(headers)


# Generated at 2022-06-26 03:13:59.376739
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Multimap()
    cookie_jar = CookieJar(headers)
    cookie = Cookie('key_0', 'value_0')
    cookie_jar.__setitem__('key_0', cookie)
    cookie_jar.__delitem__('key_0')
    str_0 = cookie_jar.__str__()
    assert str_0 == '{}'


# Generated at 2022-06-26 03:14:01.593279
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers, cookie_jar = {}, CookieJar(headers)
    cookie_jar['userid'] = '1'


# Generated at 2022-06-26 03:14:08.221672
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test 1 of 1
    cookie_jar = CookieJar({'key': 'value'})
    cookie_jar['key'] = 'new_value'
    cookie_jar['key']
    cookie_jar_keys = list(cookie_jar.keys())
    assert ('key' in cookie_jar_keys) == True
    assert ('new_key' in cookie_jar_keys) == False
    assert ('key' not in cookie_jar) == False
    assert ('new_key' not in cookie_jar) == True

    # Test 2 of 1
    cookie_jar = CookieJar({'key': 'value'})
    cookie_jar['key'] = 'new_value'
    cookie_jar['key']
    cookie_jar_keys = list(cookie_jar.keys())
    assert ('key' in cookie_jar_keys) == True


# Generated at 2022-06-26 03:14:16.431353
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test case 0
    str_0 = '&C{[5'
    cookie = Cookie(str_0, str_0)
    cookie[str_0] = str_0
    cookie.key = str_0
    assert isinstance(cookie.encode(str_0), str)
    assert isinstance(cookie[str_0], str)
    assert isinstance(str(cookie), str)
    assert isinstance(cookie.value, str)
    assert isinstance(cookie.__str__(), str)
    print('Expected')
    print('-----')
    print(cookie)
    print('-----')
    print('Actual')
    print('-----')
    print(cookie)
    print('-----')
    assert str(cookie) != None

# Generated at 2022-06-26 03:14:22.211981
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    jar = CookieJar(dict())
    jar['test'] = 'cookie_value'
    jar['test'] = 'cookie_new_value'
    assert jar['test'].value == 'cookie_new_value'
    del jar['test']
    assert jar['test'] == ''


# Generated at 2022-06-26 03:14:33.289045
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    assert Cookie(str_0, str_0)["domain"] == 'Domain'
    assert Cookie(str_0, str_0)["path"] == 'Path'
    assert Cookie(str_0, str_0)["samesite"] == 'SameSite'
    assert Cookie(str_0, str_0)["secure"] == 'Secure'
    assert Cookie(str_0, str_0)["httponly"] == 'HttpOnly'
    assert Cookie(str_0, str_0)["expires"] == 'expires'
    assert Cookie(str_0, str_0)["comment"] == 'Comment'
    assert Cookie(str_0, str_0)["version"] == 'Version'
    assert Cookie(str_0, str_0)["max-age"] == 'Max-Age'


# Generated at 2022-06-26 03:14:36.180306
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Instantiate CookieJar
    headers = {'header_key': 'header_value', 'header_key_1': ''}
    _cookie_jar = CookieJar(headers)

    # Invoke method
    result = _cookie_jar.__delitem__('key')

    assert result is None


# Generated at 2022-06-26 03:14:47.997466
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print('Testing Cookie.__str__')
    # case 0
    obj_0 = Cookie('&C{[5', 'S2Q$')
    obj_0['Path'] = '4]&e'
    obj_0['Comment'] = '/}F;w(,'
    obj_0['Domain'] = 'b8U<'
    obj_0['Max-Age'] = 9
    obj_0['Secure'] = False
    obj_0['HttpOnly'] = True
    obj_0['Version'] = ')8'
    obj_0['SameSite'] = 'o[F<c'
    actual_0 = str(obj_0)

# Generated at 2022-06-26 03:14:59.018314
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar({})
    cookies['cookie1'] = 'cookie-value'
    cookies['cookie2'] = 'cookie2-value'
    del cookies['cookie1']
    assert len(cookies) == 1
    assert cookies['cookie2'] == 'cookie2-value'


# Generated at 2022-06-26 03:15:04.049783
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {'Content-Type': 'text/html; charset=utf-8', 'Set-Cookie': 'sid=123; HttpOnly; Path=/'}
    o = CookieJar(headers)
    o.__delitem__('sid')


# Generated at 2022-06-26 03:15:14.975709
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print('Cookie.__setitem__')
    cookie_0 = Cookie(str_0, 'Io&C[^R1(@')

    # Test case number: 0
    try:
        cookie_0[str_0] = '@{[R^;))U$}a'
        # Failure message:
        # expected:
        #  KeyError("Unknown cookie property")
        # got:
        #  None
    except KeyError as e:
        # expected:
        #  KeyError("Unknown cookie property")
        # got:
        #  {type 'exceptions.KeyError'}("Unknown cookie property")
        assert str(e) == "Unknown cookie property"



# Generated at 2022-06-26 03:15:18.501602
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        cookie = Cookie('cookie_key', 'cookie_value')
        try:
            cookie['key'] = 'value'
        except:
            pass
        else:
            assert False
    except:
        pass


# Generated at 2022-06-26 03:15:26.068923
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader({"Set-Cookie": [Cookie("key1", "value1"), Cookie("key2", "value2")]})
    cookiejar = CookieJar(headers)
    cookiejar["key1"]["max-age"] = 0
    cookiejar["key1"]["path"] = "/"
    cookiejar["key2"]["max-age"] = 0
    cookiejar["key2"]["path"] = "/"
    del cookiejar["key1"]
    assert cookiejar["key2"].value == "value2"


# Generated at 2022-06-26 03:15:30.085729
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie('a]R', '-}r5)')
    assert_equal(cookie_0['path'], None)
    assert_equal(cookie_0['max-age'], None)


# Generated at 2022-06-26 03:15:31.285906
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    assert False



# Generated at 2022-06-26 03:15:39.351651
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    key, value = 'key0', 'value0'
    cookies[key] = value
    assert (cookies[key] == value)
    key, value = 'key1', 'value1'
    cookies[key] = value
    assert (cookies[key]['max-age'] == 0)
    assert (cookies[key]['path'] == '/')
    assert (cookies[key]['secure'] == False)
    assert (cookies[key]['httponly'] == False)


# Generated at 2022-06-26 03:15:50.981956
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = '=I'
    str_1 = 'zg'
    str_2 = 'G!'
    # Create an instance of Cookie
    cookie = Cookie(key='h3q', value='S5~')
    cookie['comment'] = 'j4k'
    cookie['version'] = str_2
    cookie['domain'] = '5C5'
    cookie['path'] = '4dw'
    cookie['expires'] = datetime.now()
    cookie['secure'] = True
    # Test __str__ method
    str_3 = cookie.__str__()
    assert str_3 == 'h3q=S5~; Path=4dw; Version=G!; Domain=5C5; Comment=j4k; Expires=%s; Secure' % str(datetime.now())
    cookie

# Generated at 2022-06-26 03:16:00.853261
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    res1 = None
    def test_expression_0(headers, cookie_headers, header_key):
        return delitem(headers, cookie_headers, header_key)

    def test_expression_1(headers, cookie_headers, header_key):
        return headers.popleft(cookie_headers)

    def test_expression_2(headers, cookie_headers, header_key):
        return headers.popright(cookie_headers)
    cookie_headers = None
    headers = deque()
    def test_expression_3(headers, cookie_headers, header_key):
        return headers.add(cookie_headers, header_key)
    #test_expression_3(test_expression_2(test_expression_1(test_expression_0(test_expression_3(res1)))))
    #test_expression_1()
   

# Generated at 2022-06-26 03:16:30.782844
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = "; "
    str_1 = "=%d"
    str_2 = "%s"
    str_3 = "%d"
    str_4 = "="
    str_5 = "max-age"
    str_6 = "expires"
    str_7 = "=%s"
    str_8 = "%s=%s"
    str_9 = "Secure"
    str_10 = "HttpOnly"
    str_11 = "=%s"
    str_12 = "Path"
    str_13 = "b"
    str_14 = "Comment"
    str_15 = "Domain"
    str_16 = "a"
    str_17 = "Cookie=a; Comment=b; Domain=c; Path=d; Max-Age=3; "

    # Initial

# Generated at 2022-06-26 03:16:35.042702
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    key_0 = None
    value_0 = None
    cookie_jar_0.__setitem__(key_0, value_0)
    

# Generated at 2022-06-26 03:16:39.769862
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Prerequisites
    key = "q3EZH2z4L4wN4jz8aNnR"
    value = "f89Cxap8GneZzaokJbZI"
    cookie = Cookie(key, value)
    __str__result = cookie.__str__()


# Generated at 2022-06-26 03:16:41.205962
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_1 = CookieJar(bool_0)


# Generated at 2022-06-26 03:16:43.900759
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    cookie_0 = cookie_jar_0[str_0]
    cookie_jar_0.__delitem__(str_0)



# Generated at 2022-06-26 03:16:56.137896
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Case 1:
    # If the cookie doesn't exist, add it to the header keys.
    header_key_0 = "Set-Cookie"
    cookie_headers_0 = {}
    class Dict_1():
        def add(self, key, value):
            cookie_headers_0[key] = value
        def popall(self, key, value):
            cookies_0 = cookie_headers_0.pop(key, value)
    headers_0 = Dict_1()
    cookie_jar_1 = CookieJar(headers_0)
    cookie_0 = Cookie("key", "value")
    cookie_jar_1["key"] = cookie_0

# Generated at 2022-06-26 03:17:05.119988
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_8 = True
    cookie_jar_1 = CookieJar(bool_8)
    bool_4 = True
    int_1 = 0
    str_0 = "cookie-name-1"
    str_1 = "cookie-value-1"
    bool_0 = True
    str_2 = "cookie-name-2"
    str_3 = "cookie-value-2"
    bool_1 = True
    cookie_jar_1.__setitem__(str_0, str_1)
    # AssertionError is raised, because cookie-name-1 is already in the
    # CookieJar
    try:
        cookie_jar_1.__setitem__(str_0, str_1)
    except AssertionError:
        bool_4 = False
    assert bool_4
    cookie_jar_

# Generated at 2022-06-26 03:17:07.339045
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("key", "value")
    cookie_0["max-age"] = 0
    str_0 = str(cookie_0)


# Generated at 2022-06-26 03:17:10.133496
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)

    assert cookie_jar_0 is not None

# Generated at 2022-06-26 03:17:15.872419
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    string_0 = "cookie_name"
    cookie_jar_0.__delitem__(string_0)
    string_1 = "cookie_name"
    string_2 = "cookie_value"
    cookie_jar_0[string_1] = string_2
    string_3 = "cookie_name"
    cookie_jar_0.__delitem__(string_3)


# Generated at 2022-06-26 03:17:33.784007
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert Cookie.__str__("value='e-bRmz1M8r'") == "value='e-bRmz1M8r'"

# Generated at 2022-06-26 03:17:38.983792
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    # Case 0
    str_0 = "7<d~M"
    str_1 = "zI=w%cT"
    dict_1 = {str_0:str_1}
    cookie_jar_0.__delitem__(str_0)



# Generated at 2022-06-26 03:17:44.097262
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("cookie_0", "cookie_0")
    cookie_1 = Cookie("cookie_1", "cookie_1")
    cookie_2 = Cookie("cookie_2", "cookie_2")
    cookie_3 = Cookie("cookie_3", "cookie_3")

    assert "cookie_0=cookie_0" == str(cookie_0)
    assert "cookie_1=cookie_1" == str(cookie_1)
    assert "cookie_2=cookie_2" == str(cookie_2)
    assert "cookie_3=cookie_3" == str(cookie_3)


# Generated at 2022-06-26 03:17:54.173235
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = []
    cookie_jar_0 = CookieJar(headers)
    str_0 = "xtb2~xpgcbnM9"
    cookie_jar_0[str_0] = "Nz!H1Ubmy9"
    cookie_0 = cookie_jar_0[str_0]
    assert str_0 in cookie_0.key
    assert "Nz!H1Ubmy9" in cookie_0.value

    # Invalid Attribute
    with pytest.raises(KeyError):
        cookie_jar_0[""] = "Nz!H1Ubmy9"

    # Invalid Object Type
    with pytest.raises(ValueError):
        cookie_jar_0[str_0] = 1



# Generated at 2022-06-26 03:17:59.687418
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    str_0 = "test"
    str_0 = cookie_jar_0.__setitem__(bool_0, str_0)
    assert str_0 == None


# Generated at 2022-06-26 03:18:02.679198
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    pass


# Generated at 2022-06-26 03:18:13.030450
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    str_0 = "c9b9a4e4-4ba4-4264-92b5-6edf2fa78410"
    cookie_jar_0[str_0] = bool_0
    str_1 = "afb59a0d-dff7-4c4f-9b48-d4d4ba4c6f23"
    cookie_jar_0[str_1] = str_1
    str_2 = "f202b7dd-b314-47e7-b886-1a98dae83b67"
    cookie_jar_0[str_2] = str_2

# Generated at 2022-06-26 03:18:16.167385
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    e = None
    try:
        char_0 = 'hm'
        cookie_jar_0 = CookieJar(char_0)
    except Exception as e:
        pass
    if e is not None:
        raise Exception("Test case failed")


# Generated at 2022-06-26 03:18:30.938174
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bool_0 = False
    bool_1 = True
    cookie_jar_0 = CookieJar(bool_0)
    cookie_jar_0["cookie_jar_0"] = "eO70T"
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"

# Generated at 2022-06-26 03:18:32.206391
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar()
    assert True


# Generated at 2022-06-26 03:18:50.826497
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    Check if this method handles a case when a cookie is deleted from
    CookieJar and headers by calling CookieJar.__delitem__
    
    1. Declare a new CookieJar object with a headers object as the parameter.
    2. Declare a new cookie and add that to the CookieJar object.
    3. Call on the __delitem__ to delete the cookie, delete the cookie.
    4. If the cookie is not in the cookie_headers and cookie_headers
       doesn't contain the key, throw a KeyError.
    5. If the cookie is in cookie_headers and cookie_headers contains the key,
       pop the cookie from the headers, del the cookie from the cookie_headers.
    """
    cookie_jar_0 = CookieJar({})
    cookie_0 = Cookie("cookie_key", "cookie_value")
    cookie_jar_0

# Generated at 2022-06-26 03:19:02.615694
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test case 0
    cookie_0 = Cookie("test", "hello world")
    cookie_0["expires"] = datetime.now()
    cookie_0["path"] = "/"
    cookie_0["comment"] = "this is a test"
    cookie_0["domain"] = "hello-world.com"
    cookie_0["max-age"] = DEFAULT_MAX_AGE
    cookie_0["secure"] = True
    cookie_0["version"] = "1"
    cookie_0["httponly"] = True

# Generated at 2022-06-26 03:19:11.081568
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = "YF_fskz9"
    value_0 = "pPkV7J:m"
    cookie_0 = Cookie(key_0, value_0)
    cookie_0["path"] = "/"
    cookie_0["domain"] = ""
    cookie_0["max-age"] = 6756
    cookie_0["expires"] = datetime.strptime("Thu, 14 Jan 2016", "%a, %d %b %Y")
    cookie_0["secure"] = True
    cookie_0["httponly"] = True
    cookie_0["version"] = 18
    assert type(cookie_0.__str__()) is str



# Generated at 2022-06-26 03:19:22.037710
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    key_0 = "remo"
    cookie_jar_0.__delitem__(key_0)
    key_0 = "M0vz8W7e"
    cookie_jar_0.__delitem__(key_0)
    key_0 = "emport_f"
    cookie_jar_0.__delitem__(key_0)
    key_0 = "Y"
    cookie_jar_0.__delitem__(key_0)
    key_0 = "(j"
    cookie_jar_0.__delitem__(key_0)
    key_0 = "SODD9e"
    cookie_jar_0.__delitem__(key_0)

# Generated at 2022-06-26 03:19:23.872983
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookies = Cookie('name', 'value')
    str_0 = cookies.__str__()



# Generated at 2022-06-26 03:19:26.674171
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Init
    key = "foo"
    value = "bar"
    cookie = Cookie(key, value)
    cookie["path"] = "/"

    # Invoke method
    output = str(cookie)

    # Assert result
    assert (output == "foo=bar; Path=/")

# Generated at 2022-06-26 03:19:30.476452
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = ... # type: ignore
    cookie_jar = CookieJar(headers)
    key = ... # type: ignore

    # Call the __delitem__ method of the CookieJar class with arguments key
    # assert ... == cookie_jar.__delitem__(key)


# Generated at 2022-06-26 03:19:35.448283
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Precondition
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    key_0 = cookie_jar_0.cookie_headers

    try:
        del cookie_jar_0[key_0]

    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 03:19:45.143012
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    string_0 = "wpv\x18]W\x1bI\x1c"
    string_1 = "0\x00\x00\x008\x00\x00\x00\x02\x00\x00\x00u\x00\x00\x00s\x00\x00\x00r\x00\x00\x00t\x00\x00\x00\x00\x00\x00\x00(\x00\x00\x00(\x00\x00\x00(\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00"

# Generated at 2022-06-26 03:19:50.211962
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case for instance initialization
    cookie_jar_1 = CookieJar("")
    name_0 = str("")
    cookie_jar_1[name_0] = str("")
    # Test case for method __delitem__ of class CookieJar
    cookie_jar_1 = CookieJar("")
    name_0 = 1
    try:
        # Test case for instance initialization
        cookie_jar_1[name_0] = str("")
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-26 03:20:16.024436
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    string_0 = "; "
    bool_0 = True
    string_1 = "d"
    datetime_0 = datetime.now()
    string_2 = "q"
    string_3 = "y"
    cookie_0 = Cookie(string_0, bool_0)
    cookie_1 = Cookie(string_1, datetime_0)
    cookie_2 = Cookie(string_2, string_3)
    string_4 = cookie_0.__str__()
    string_5 = cookie_1.__str__()
    string_6 = cookie_2.__str__()


# Generated at 2022-06-26 03:20:26.690833
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    value_0 = "~ô?#ÎÞPÚ\u000fZòÚËÞ\u0014ôÀÑðÖ\u0017ÅÝÒÔèØôÏÙ¾Y"

# Generated at 2022-06-26 03:20:30.498197
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(True)
    # Verify the type of __str__ return value is string
    assert isinstance(cookie_jar_0.__str__(),str)
    # Verify the correctness of the __str__ return value
    assert cookie_jar_0.__str__() == "<CookieJar: {}>"


# Generated at 2022-06-26 03:20:35.942907
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar("Z[>D")
    cookie_0 = Cookie("g", "y9,!(p")
    cookie_jar_0.append(cookie_0)
    cookie_1 = Cookie("yM>", "KM:")
    cookie_jar_0.append(cookie_1)
    cookie_2 = Cookie("oy`y:K", "R#")
    cookie_jar_0.append(cookie_2)
    cookie_3 = Cookie("YmE^jX", "R")
    cookie_jar_0.append(cookie_3)
    cookie_jar_0["yM>"] = ")a"
    cookie_jar_0.__delitem__("yM>")


# Generated at 2022-06-26 03:20:40.450746
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bool_0 = True
    cookie_jar_1 = CookieJar(bool_0)
    cookie_jar_0 = CookieJar(bool_0)
    str_0 = ""
    cookie_jar_0.__setitem__(str_0, cookie_jar_1)


# Generated at 2022-06-26 03:20:42.333982
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # No assertions are made
    cookie_1 = Cookie("test", "val")
    str_0 = cookie_1.__str__()



# Generated at 2022-06-26 03:20:45.563888
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("9q?Km;", Cookie)
    cookie_0["comment"] = Cookie
    cookie_0["secure"] = Cookie
    cookie_0["expires"] = Cookie


# Generated at 2022-06-26 03:20:50.024947
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_jar_0 = CookieJar(bool_0)
    str_0 = "rH<Ns3"
    cookie_jar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:20:53.354725
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("cookie_0", 0)
    cookie_0["max-age"] = DEFAULT_MAX_AGE
    cookie_0["path"] = "V\"iw &"
    cookie_0["secure"] = True
    str_0 = str(cookie_0)


# Generated at 2022-06-26 03:21:02.486142
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bool_0 = True
    dict_0 = {'path': '/', 'max-age': DEFAULT_MAX_AGE}
    cookie_0 = Cookie(bool_0, dict_0)
    str_0 = cookie_0.__str__()
    dict_1 = {'expires': datetime(2020, 3, 8, 23, 8, 6, 668618), 'path': '/', 'max-age': DEFAULT_MAX_AGE}
    cookie_1 = Cookie(bool_0, dict_1)
    str_1 = cookie_1.__str__()
    dict_2 = {'expires': '2020-03-08 23:08:06.668618', 'path': '/', 'max-age': DEFAULT_MAX_AGE}
    cookie_2 = Cookie(bool_0, dict_2)
   