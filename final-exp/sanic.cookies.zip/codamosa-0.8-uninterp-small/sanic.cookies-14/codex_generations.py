

# Generated at 2022-06-26 03:11:28.606284
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_0 = Cookie("N#Vy2,,", "3V6xz%cU")
    cookie_0["path"] = "/"
    cookie_jar_0[cookie_0.key] = cookie_0


# Generated at 2022-06-26 03:11:38.408662
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = -1.29208666427967
    if not (1.4628898026279487 >= float_0):
        cookie_jar_0 = CookieJar(float_0)
        str_0 = "q|Bj<#\x7fXpMa+I"
        str_1 = "`"
        str_0 = str_0.replace("|", str_1)
        str_2 = "[="
        str_0 = str_0.replace("<", str_2)
        str_3 = "m"
        str_0 = str_0.replace("#", str_3)
        str_4 = "7"
        str_0 = str_0.replace("\x7f", str_4)
        float_1 = 4.086869583418073
       

# Generated at 2022-06-26 03:11:51.342720
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    key_0 = '\u03a9'
    value_0 = '\u03a9'
    cookie = Cookie(key_0, value_0)
    cookie["path"] = "/"
    cookie_jar_0.cookie_headers[key_0] = cookie_jar_0.header_key
    cookie_jar_0.headers.add(cookie_jar_0.header_key, cookie)
    super().__setitem__(key_0, cookie)
    cookie.value = '\u03a9'
    if not cookie_jar_0.cookie_headers.get(key_0):
        cookie = Cookie(key_0, value_0)
        cookie["path"] = "/"


# Generated at 2022-06-26 03:11:58.565958
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0.__delitem__(str(float_0))


# Generated at 2022-06-26 03:12:01.196154
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Tests if the str function works by checking if the function returns a
    string
    """
    cookie = Cookie("name", "value")
    assert isinstance(str(cookie), str)


# Generated at 2022-06-26 03:12:04.671100
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["cookie_key_0"] = "cookie_value_0"
    msg = cookie_jar_0._Cookie__str__()
    assert msg == "cookie_value_0"


# Generated at 2022-06-26 03:12:09.159911
# Unit test for constructor of class Cookie
def test_Cookie():
    key0 = "a"
    value0 = "b"
    cookie0 = Cookie(key0, value0)
    assert cookie0._keys['expires'] == 'expires'
    assert cookie0._keys['path'] == 'Path'
    assert cookie0._keys['comment'] == 'Comment'
    assert cookie0._keys['domain'] == 'Domain'
    assert cookie0._keys['max-age'] == 'Max-Age'
    assert cookie0._keys['secure'] == 'Secure'
    assert cookie0._keys['httponly'] == 'HttpOnly'
    assert cookie0._keys['version'] == 'Version'
    assert cookie0._keys['samesite'] == 'SameSite'
    assert cookie0.key == 'a'
    assert cookie0.value == 'b'


# Generated at 2022-06-26 03:12:12.783888
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    # SimpleCookie
    cookie_jar_0 = CookieJar(0.0)
    str_0 = "P13&4]4NnCSkjx&tN`^C`RV1%c?SK)Xf3a"
    str_1 = "?G`x0_0f*[-"
    assert cookie_jar_0[str_0].value == str_1

    # SimpleCookie #gottagofast
    cookie_jar_0 = CookieJar(0.0)
    int_0 = 1
    str_0 = "w$#)"
    str_1 = "QY&1z:%mRW)f9J%e)3;n3)bi!CQ^l1R(5C"
    assert cookie_jar_0[str_1].value == str_0




# Generated at 2022-06-26 03:12:23.277624
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 9.968028778526506
    cookie_jar_0 = CookieJar(float_0)

    cookie_jar_0["ksdn"].pop("expires")
    cookie_jar_0["ksdn"].pop("secure")
    cookie_jar_0["ksdn"]["Path"] = "ksdn"
    cookie_jar_0["ksdn"]["Domain"] = "ksdn"
    cookie_jar_0["ksdn"]["secure"] = True
    cookie_jar_0["ksdn"]["secure"] = False
    cookie_jar_0["ksdn"]["secure"] = False
    cookie_jar_0["ksdn"]["secure"] = True
    cookie_jar_0["ksdn"]["httponly"] = False

# Generated at 2022-06-26 03:12:27.394336
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_jar_0 = CookieJar(2.414330054922565)

    # Test default
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)

    try:
        float_0 = 2.414330054922565
        cookie_jar_0 = CookieJar(float_0)
        assert False
    except KeyError:
        pass


# Generated at 2022-06-26 03:12:32.520170
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:12:42.887153
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    exp_value = "; ".join(["%s=%s" % (self.key, _quote(self.value))])
    actual_value = Cookie.__str__(self, encoding)
    assert actual_value == exp_value


# Generated at 2022-06-26 03:12:53.550173
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 4.04302819591219E307
    cookie_0 = Cookie("", "")
    assert_0 = "= "
    cookie_0["max-age"] = 0
    str_0 = cookie_0.__str__()
    if str_0 == assert_0:
        print("Test 0 passed.")
        cookie_0["max-age"] = 1.0
        str_0 = cookie_0.__str__()
        if str_0 == assert_0:
            print("Test 1 passed.")
            cookie_0["max-age"] = float_0
            str_0 = cookie_0.__str__()
            if str_0 == assert_0:
                print("Test 2 passed.")
    else:
        print("Test 0 failed.")



# Generated at 2022-06-26 03:12:59.998823
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    key = "test"
    value = "test"
    cookie_jar_0.__setitem__(key, value)
    try:
        cookie_jar_0.__delitem__(key)
        result = True
    except:
        result = False
    assert result



# Generated at 2022-06-26 03:13:02.600346
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = 1.539890749120577
    cookie_0 = Cookie(float_0, 1)
    cookie_0['foo'] = 'bar'


# Generated at 2022-06-26 03:13:14.748679
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = "max-age"
    str_1 = "expires"
    dict_0 = dict()
    dict_0["expires"] = "name"
    dict_0["path"] = "path"
    dict_0["comment"] = "comment"
    dict_0["domain"] = "domain"
    dict_0["max-age"] = "max-age"
    dict_0["secure"] = "secure"
    dict_0["httponly"] = "httponly"
    dict_0["version"] = "version"
    dict_0["samesite"] = "samesite"
    str_2 = "secure"
    str_3 = "httponly"
    str_4 = "Version"
    str_5 = "SameSite"
    str_6 = "Content-type"
    str

# Generated at 2022-06-26 03:13:28.724743
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_1 = 2.414330054922565
    cookie_jar_1 = CookieJar(float_1)
    #
    #  void __setitem__(self, key, value):
    #
    #      if not self.cookie_headers.get(key):
    #          cookie = Cookie(key, value)
    #          cookie["path"] = "/"
    #          self.cookie_headers[key] = self.header_key
    #          self.headers.add(self.header_key, cookie)
    #          return super().__setitem__(key, cookie)
    #      else:
    #          self[key].value = value
    #
    #      if key in self._keys:
    #          raise KeyError("Cookie name is a reserved word")
    #      if not _is_legal_

# Generated at 2022-06-26 03:13:30.097570
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    assert cookie.__setitem__(str_0, str_0) == None


# Generated at 2022-06-26 03:13:36.947904
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_1 = 2.414330054922565
    cookie_jar_1 = CookieJar(float_1)
    cookie_1 = Cookie("key", "value")
    cookie_1["Path"] = "/"
    cookie_1["Secure"] = True
    cookie_1["HttpOnly"] = True
    assert str(cookie_1) == "key=value; Path=/; Secure; HttpOnly"



# Generated at 2022-06-26 03:13:44.948746
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie_0 = Cookie(None, None)
    cookie_0['expires'] = 'Wed, 21 Oct 2015 07:28:00 GMT'
    cookie_0['domain'] = 'foo.com'
    cookie_0['samesite'] = 'foo'
    cookie_0['path'] = 'bar'
    cookie_0['version'] = 'foo'
    cookie_0['comment'] = 'bar'
    cookie_0['secure'] = 'foo'
    cookie_0['httponly'] = 'foo'
    cookie_0['max-age'] = 'bar'
    str_0 = str(cookie_0)


# Generated at 2022-06-26 03:13:52.170269
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(None)
    try:
        cookie_jar_0.__setitem__(None, None)
    except KeyError as e:
        pass


# Generated at 2022-06-26 03:13:58.794253
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("Test method: __str__")
    try:
        float_0 = 2.414330054922565
        cookie_jar_0 = CookieJar(float_0)
        cookie_0 = Cookie("key0", "value0")
        cookie_0["expires"] = datetime.now()
        str_0 = str(cookie_0)
        print(str_0)
    except Exception as inst:
        print(inst)


# Generated at 2022-06-26 03:14:08.584161
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test for exist Cookie
    cookie_jar_0 = CookieJar(1)
    cookie_jar_0.__setitem__("test.CookieJar.cookie_jar_0", "test.CookieJar.cookie_jar_0")
    cookie_jar_0.__delitem__("test.CookieJar.cookie_jar_0")
    # Test for non-exist Cookie
    cookie_jar_1 = CookieJar(1)
    cookie_jar_1.__setitem__("test.CookieJar.cookie_jar_0", "test.CookieJar.cookie_jar_0")
    cookie_jar_1.__delitem__("test.CookieJar.cookie_jar_0")
    cookie_jar_1.__delitem__("test.CookieJar.cookie_jar_0")
    # Test for non-

# Generated at 2022-06-26 03:14:09.785436
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert 0 == 0.0


# Generated at 2022-06-26 03:14:12.374720
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)


# Generated at 2022-06-26 03:14:16.331538
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 1.0863483545750062
    cookie_0 = Cookie('key_0', float_0)
    str_0 = cookie_0.__str__()
    assert str_0 == 'key_0=1.0863483545750062'


# Generated at 2022-06-26 03:14:28.408427
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = 1.0
    cookie_jar_0 = CookieJar(float_0)

# Generated at 2022-06-26 03:14:31.051499
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = -3.572844965703741
    cookie_jar_0 = CookieJar(float_0)


# Generated at 2022-06-26 03:14:33.369350
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test Case #0
    test_case_0()


if __name__ == "__main__":
    test_Cookie___setitem__()

# Generated at 2022-06-26 03:14:34.641427
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    test_Cookie___setitem___0()


# Generated at 2022-06-26 03:14:41.422930
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    with pytest.raises(TypeError):
        cookie_jar_0.__setitem__(None, None)


# Generated at 2022-06-26 03:14:53.116212
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
  # arrange
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    str_0 = '<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8<7V.NvGF8'
    str_1 = 'o]tmg3i4p4c1z'
    # act
    dict_0 = cookie_jar_0.__delitem__(str_0)
    dict_1 = cookie_jar_

# Generated at 2022-06-26 03:14:57.576355
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie("bO(v)Dp&9[H<", "Z]?a0)not}W>")
    cookie_0["path"] = "nx)T&9;D [e{B*"
    assert(cookie_0["path"] == "nx)T&9;D [e{B*")



# Generated at 2022-06-26 03:15:02.919072
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookies = Cookie("chocolate_chip", "tasty")
    cookies.set("name", "candy")
    cookies.set("expires", datetime(2021, 1, 1))
    cookies.set("secure", True)
    cookies_str = cookies.__str__()
    assert isinstance(cookies_str, str)


# Generated at 2022-06-26 03:15:14.468251
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()
    test_case_17()
    test_case_18()
    test_case_19()
    test_case_20()
    test_case_21()



# Generated at 2022-06-26 03:15:26.887343
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Setup
    key = ''
    value = '0'

    # Invocation
    cookie = Cookie(key, value)
    cookie['path'] = "/"
    cookie['version'] = "1"

    # Verification
    try:
        assert cookie['path'] == "/"
    except AssertionError as e:
        print("AssertionError raised: {}".format(e.args[0]))
    try:
        assert cookie['version'] == "1"
    except AssertionError as e:
        print("AssertionError raised: {}".format(e.args[0]))
    try:
        assert cookie.value == "0"
    except AssertionError as e:
        print("AssertionError raised: {}".format(e.args[0]))

# Generated at 2022-06-26 03:15:30.749682
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)

    cookie_jar_0[0] = 0

    cookie_jar_0[0] = 0


# Generated at 2022-06-26 03:15:36.111783
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 1.0
    cookie_jar_0 = CookieJar(float_0)
    cookie_0 = Cookie(str(cookie_jar_0), float_0)
    int_0 = 0
    cookie_0["max-age"] = str(int_0)
    value_0 = cookie_0.__str__()
    print(value_0)



# Generated at 2022-06-26 03:15:47.789062
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 5e5
    cookie_jar_0 = CookieJar(float_0)
    float_1 = float('nan')
    float_2 = float('inf')
    float_3 = float('-inf')
    
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(float_1)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(float_2)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(float_3)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(float_3)
        
    float_4 = float('nan')
    float_5 = float('inf')
    float_6

# Generated at 2022-06-26 03:15:58.477829
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    float_0 = 1.5170335599642042
    float_1 = 1.3364354612362854
    float_2 = 3.0308445571575755
    float_3 = 1.74614386092728
    float_4 = 1.7689191845606891
    float_5 = 1.1197302697398288
    float_6 = 2.342721394454923
    float_7 = 1.3117993403578603
    float_8 = 1.698637153866545
    float_9 = 1.8920581367681916
    float_10 = 3.0692701965056048
    float_11 = 1.6783023338404021
    float_12 = 2.617675122729214


# Generated at 2022-06-26 03:16:12.478905
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 1.75
    cookie_jar_0 = CookieJar(float_0)
    float_1 = 2.07685620880127
    dict_0 = {
        "version": float_1,
        "max-age": float_1,
        "domain": float_1,
        "same-site": float_1,
        "secure": float_1,
        "expires": float_1,
        "comment": float_1,
        "path": float_1,
        "httponly": float_1,
    }
    cookie_0 = Cookie(float_1, float_1)
    for str_0 in dict_0:
        cookie_0[str_0] = dict_0[str_0]
    cookie_0.key = float_1
    cookie_0.value

# Generated at 2022-06-26 03:16:20.913551
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 1.0
    cookie_jar_0 = CookieJar(float_0)
    int_0 = 1
    dict_0 = {}
    dict_0['cookie_jar_0'] = cookie_jar_0
    dict_0['int_0'] = int_0

    for key in dict_0:
        if 'CookieJar' in key:
            cookie_jar_0 = dict_0[key]
        if 'str' in key:
            str_0 = dict_0[key]
        if 'int' in key:
            int_0 = dict_0[key]
        cookie_jar_0.__delitem__(int_0)



# Generated at 2022-06-26 03:16:25.139165
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_1 = 0.947989853104486
    cookie_jar_0 = CookieJar(float_1)
    str_0 = "Sets the value of the cookie with name to value."
    cookie_jar_0[str_0] = str_0
    del cookie_jar_0[str_0]


# Generated at 2022-06-26 03:16:36.180053
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    dict_0 = {}
    cookie_key_0 = "]]-:*7f]?%@!VjhfjeZ.TdZ{Q}@>&0GX9-y:a`?e=M'1_s7,^T[f@r!;QK{&<n>9Xn_i:7hF?=s1DlPhu*>x_g,p<;dh{^3M`uB*G:b7Vu\t&zfLOsyQPZ"
    cookie_0 = Cookie(cookie_key_0, dict_0)
    cookie_key_1 = "expires"
    cookie_value_0 = datetime(1, 1, 1, 0, 0, 1)

# Generated at 2022-06-26 03:16:41.368378
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Tests if the item is deleted from the dict, and the headers are correct
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["a"] = "a"
    del cookie_jar_0["a"]
    assert not cookie_jar_0.headers.getall("Set-Cookie")


# Generated at 2022-06-26 03:16:51.535128
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    with pytest.raises(KeyError):
        cookie_jar_0["sT"] = 0.3305121824284465
        cookie_jar_0.__delitem__("0^Q")
        cookie_jar_0.__delitem__("0^Q")
    with pytest.raises(KeyError):
        cookie_jar_0["sT"] = 0.3305121824284465
        cookie_jar_0.__delitem__("0^Q")
        cookie_jar_0.__delitem__("0^Q")


# Generated at 2022-06-26 03:16:54.801081
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_0 = Cookie(float_0, float_0)
    cookie_0.__str__()


# Generated at 2022-06-26 03:17:00.151350
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {
        'X-Frame': 'deny',
        'X-XSS-Protection': '1',
    }
    cookie_jar_0 = CookieJar(headers)
    cookie_jar_0['cookie_key_0'] = 'cookie_value_0'
    assert 'cookie_value_0' == cookie_jar_0['cookie_key_0']['value']


# Generated at 2022-06-26 03:17:04.336072
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    float_0 = 1.2950701866364237
    cookie_jar_0 = CookieJar(float_0)
    for key in cookie_jar_0.cookie_headers:
        del cookie_jar_0[key]
    cookie_jar_0.__delitem__(None)
    cookie_jar_0.__delitem__(float_0)


# Generated at 2022-06-26 03:17:07.552479
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_1 = 2.3124
    cookie_jar_1 = CookieJar(float_1)
    cookie_0 = Cookie('key', 'val')
    cookie_0['domain'] = 'test.com'



# Generated at 2022-06-26 03:17:22.116792
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 3.3395804637967085
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0.__setitem__("I+")
    cookie_jar_0.__delitem__("pi>")
    if __name__ == '__main__':
        cookie_jar_0.__setitem__("I+", True)



# Generated at 2022-06-26 03:17:33.539102
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 3.764443944641025
    cookie_jar_0 = CookieJar(float_0)
    cookie_0 = cookie_jar_0.__getitem__("2f=)y&+")
    char_0 = "1#q.Z#9<K&.R:+o,nM@$y*n]Y%c@,p|>!l[ZPjJhV%b:foa)7Q_?J(u5YV=h"
    char_1 = "!I"
    cookie_0[char_0] = char_1
    float_1 = 7.354456650242902
    cookie_0[float_1] = float_1
    char_2 = "%"

# Generated at 2022-06-26 03:17:42.526287
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    string_0 = ":D:z#"
    string_1 = "4E;'Xtb/\\"
    string_2 = "\\@N"
    string_3 = "\\Fb\\"
    string_4 = "2"
    string_5 = "\\u{3C3B7F0D}"
    string_6 = "\\<"
    list_0 = ["\\=", "\\u{DADEE7F4}", "'{]2,", "U&", "\\}\\", "`e+QmWn>8", "C", "\\u{1E67B580}", "3\\", "\\N}\\", "N$\\", "'/&z{?5\\", "\\/\\="]

# Generated at 2022-06-26 03:17:47.868370
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = 1.9615705608064606
    cookie_jar_0 = CookieJar(float_0)
    str_0 = "r9*G%c}@6"
    str_1 = "M5UxE{n.e"
    cookie_jar_0[str_0] = str_1


# Generated at 2022-06-26 03:17:51.419011
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Init params for method __delitem__ of class CookieJar
    key = str()

    cookie_jar_0 = CookieJar()
    # invoke method __delitem__ of class CookieJar
    ret = cookie_jar_0.__delitem__(key)



# Generated at 2022-06-26 03:17:57.124618
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(2.414330054922565)
    try:
        cookie_jar_0[7.028555171157877] = (51.835602116115066)
        if(cookie_jar_0[7.028555171157877] == (51.835602116115066)):
            print("Test Case 0 Passed")
        else:
            print("Test Case 0 Failed")
    except KeyError:
        print("Test Case 0 Failed")


# Generated at 2022-06-26 03:18:10.399767
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = 0.3627962520697705
    float_1 = 1.986870542943325
    string_0 = "Cookie"
    string_1 = "Cookie"
    string_2 = "Cookie"
    string_3 = "Cookie"
    string_4 = "Cookie"
    string_5 = "Cookie"
    string_6 = "Cookie"
    string_7 = "Cookie"
    string_8 = "Cookie"
    string_9 = "Cookie"
    string_10 = "Cookie"
    string_11 = "Cookie"
    string_12 = "Cookie"
    string_13 = "Cookie"
    string_14 = "Cookie"
    string_15 = "Cookie"
    string_16 = "Cookie"

# Generated at 2022-06-26 03:18:13.649573
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 1.4871990719491763
    str_0 = str(float_0)
    int_0 = 6
    cookie_0 = Cookie(str_0, int_0)
    str_1 = str(cookie_0)



# Generated at 2022-06-26 03:18:16.163596
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # setup
    instance = Cookie("foo", "bar")
    # exercise
    result = instance.__str__()
    # verify
    expected = "foo=bar"
    assert result == expected


# Generated at 2022-06-26 03:18:19.002866
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(64)
    try:
        cookie_jar_0.__delitem__("6")
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-26 03:18:30.190767
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        self_0 = Cookie('9N,W[_|', 'By*<K6#vU6')
        self_0.__setitem__('G`P,`:mji', '<_K%}h{4,4')
    except KeyError:
        pass


# Generated at 2022-06-26 03:18:33.068417
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0.__delitem__("path")


# Generated at 2022-06-26 03:18:36.645461
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert Cookie.__str__(test_Cookie_0) == ''
    assert Cookie.__str__(test_Cookie_1) == ''


# Generated at 2022-06-26 03:18:46.625604
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 2.414330054922565

    str_0 = Cookie("key_0", "value_0")
    assert str(str_0) == 'key_0="value_0"'

    str_1 = Cookie("key_1", "value_1")
    str_1["path"] = "path_0"
    str_1["secure"] = "secure_0"
    str_1["httponly"] = "httponly_0"
    str_1["max-age"] = float_0
    str_1["expires"] = datetime.now()

# Generated at 2022-06-26 03:18:49.599000
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = Cookie(str(0))
    cookie_1 = Cookie(str(0))
    cookie_jar_2 = CookieJar(cookie_0)
    cookie_jar_2.__delitem__(cookie_1)


# Generated at 2022-06-26 03:19:01.533084
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("key1", "value1")
    cookie_0["expires"] = datetime(2001, 12, 12, 19, 5, 12)
    cookie_0["path"] = "/path/"
    cookie_0["domain"] = "example.com"
    cookie_0["max-age"] = 123
    cookie_0["httponly"] = True
    cookie_0["secure"] = True
    str_0 = str(cookie_0)
    assert str_0 == set_cookie_0

set_cookie_0 = (
    "key1=value1; expires=Mon, 12-Dec-2001 19:05:12 GMT; Path=/path/; Domain=example.com; Max-Age=123; HttpOnly; Secure"
)


# Generated at 2022-06-26 03:19:12.388488
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Assumptions: (1) max-age must be an integer (2) cookie 'expires' property must be a datetime
    cookie = Cookie("CookieKey", "CookieValue")
    cookie["max-age"] = 0
    cookie["expires"] = datetime.now()
    # Assert: (1) cookie['max-age'] == cookie.items()[0][1] (2) cookie['expires'] == cookie.items()[1][1] (3) cookie['max-age'] is an integer (4) cookie['expires'] is a datetime
    assert cookie['max-age'] == cookie.items()[0][1]
    assert cookie['expires'] == cookie.items()[1][1]
    assert isinstance(cookie['max-age'], int)

# Generated at 2022-06-26 03:19:17.272021
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_0 = Cookie(hash(set(bool)), bool)

    # Call method __str__ of class Cookie
    ret_obj = cookie_0.__str__()
    print(ret_obj)

    assert ret_obj != None



# Generated at 2022-06-26 03:19:22.403751
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # CookieJar._CookieJar__delitem__ of class CookieJar
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["test_cookie_test_cookie_test_cookie_test_cookie_test_cookie_test_co"] = datetime.now()


# Generated at 2022-06-26 03:19:29.190752
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import pytest
    from . import random_string

    cookie_0 = Cookie("{", "3")
    str_0 = random_string(10)
    str_1 = random_string(6)
    str_2 = random_string(6)
    str_3 = random_string(1)
    str_4 = random_string(1)
    str_5 = random_string(10)
    str_6 = random_string(1)
    int_0 = random.randint(-9, 3)
    with pytest.raises(KeyError):
        cookie_0[str_0] = True
    with pytest.raises(TypeError):
        str_1 = datetime.now()
        cookie_0[str_2] = str_1

# Generated at 2022-06-26 03:19:45.029847
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0['foo'] = 'bar'
    del cookie_jar_0['foo']
    assert cookie_jar_0.get('foo') == None


# Generated at 2022-06-26 03:19:51.832410
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_1 = -0.93270024473858
    cookie_0 = Cookie(float_1, "HlN")
    float_2 = -1.282913015026757
    str_0 = "zTt"
    str_1 = "Vpv"
    # Type check:
    try:
        cookie_0["path"] = "Vpv"
        assert False
    except TypeError:
        assert True
    # Type check:
    try:
        cookie_0[str_0] = float_2
        assert False
    except TypeError:
        assert True
    # Shouldn't allow assigning a value to a reserved key
    # Shouldn't allow assigning a value to a reserved key
    # Shouldn't allow assigning a value to a reserved key
    # Shouldn't allow assigning a value to

# Generated at 2022-06-26 03:20:02.498262
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    string_0 = "C0zrEoRk8Vx&{Cf1"
    integer_bool_0 = 1
    cookie_0 = Cookie(string_0, integer_bool_0)
    cookie_0["max-age"] = 0
    cookie_0["expires"] = datetime.now()
    cookie_0["httponly"] = True
    cookie_0["path"] = "C5FtB@^bE#"
    cookie_0["domain"] = "C9_|"
    cookie_0["comment"] = "zhw]2"

    cookie_str = cookie_0.__str__()

# Generated at 2022-06-26 03:20:05.619843
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = 1.847009974277318E308 * 2.0
    cookie_jar_0 = CookieJar(float_0)
    assert_equals(cookie_jar_0.float_0, 3.694019948554636E308)


# Generated at 2022-06-26 03:20:08.804026
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 1.3602536756419498
    cookie_0 = Cookie("integer_0", "integer_1")
    assert cookie_0.__str__() == "integer_0=integer_1"



# Generated at 2022-06-26 03:20:13.896984
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = float()
    float_1 = float()
    float_2 = float()
    float_3 = float()
    float_4 = float()

    cookie_0 = Cookie(float_0, float_1)
    cookie_jar_0 = CookieJar(float_4)
    cookie_0.__setitem__(float_2, float_3)

    cookie_0[float_4] = float_0
    assert (cookie_0[float_4] == float_0)


# Generated at 2022-06-26 03:20:22.923633
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_4 = 2.414330054922565
    cookie_jar_4 = CookieJar(float_4)
    # Example from Issue #21
    cookie_jar_4["foo"] = 'bar'

    # Remove the cookie . . .
    del cookie_jar_4['foo']

    # ...and the cookie disappears
    assert "foo" not in cookie_jar_4
    assert "foo" not in cookie_jar_4.headers

    # `foo` was not removed from the original header, so try to add it back
    cookie_jar_4["foo"] = "bar"
    assert "foo" in cookie_jar_4
    assert "foo" in cookie_jar_4.headers



# Generated at 2022-06-26 03:20:27.596007
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    str_0 = "qUFwMZ]W?;I_%Pt["
    dict_0 = cookie_jar_0[str_0]
    assert dict_0.get("samesite") is None


# Generated at 2022-06-26 03:20:34.736083
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    # del cookie_jar_0[b'jK!w~Hr>-\x12\x00\x1d\x00\x13\x00\x14\x00\x16\x00\x12\x00\x17']
    cookie_jar_0[b'jK!w~Hr>-\x12\x00\x1d\x00\x13\x00\x14\x00\x16\x00\x12\x00\x17'] = ''

# Generated at 2022-06-26 03:20:41.460142
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = 2.414330054922565
    cookie_jar_0 = CookieJar(float_0)
    float_0 = 2.414330054922565
    cookie_0 = Cookie(float_0, float_0)
    cookie_0["path"] = "/"
    cookie_jar_0["key"] = cookie_0

    assert cookie_jar_0["key"] == cookie_0
    assert "key" in cookie_jar_0


# Generated at 2022-06-26 03:21:19.092881
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = float(random())
    float_1 = float(random())
    key_0 = 'd7VgIk+U:]7#uIMB6_A('
    key_1 = '\/~9[Z#)guJNs*\"=C>y'
    max_age_0 = int(random())
    max_age_1 = int(random())
    secure_0 = bool(random())
    secure_1 = bool(random())
    value_0 = '$Sq"'
    value_1 = '(A]p=e'
    comment_1 = 'xR0X(.r'
    comment_0 = 'm^Vu8@O'
    httponly_0 = bool(random())
    httponly_1 = bool(random())

    # Test with instance (1)
   