

# Generated at 2022-06-26 03:11:27.499952
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    try:
        result_0 = cookie_jar_0.__setitem__("", "", )
    except KeyError as exception_0:
        result_0 = False
    result_1 = cookie_jar_0.__setitem__("", "", )
    result_2 = cookie_jar_0.__setitem__("", "", )
    result_3 = cookie_jar_0.__setitem__("", "", )
    result_4 = cookie_jar_0.__setitem__("", "", )
    result_5 = cookie_jar_0.__setitem__("", "", )
    assert result_0 == False
    assert result_1 == None
    assert result_2 == None

# Generated at 2022-06-26 03:11:37.525854
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Parameters
    name = "name"
    value = "value"
    # Object
    cookie_headers = {
            "name": "value",
            "name1": "value1",
            "name2": "value2"
        }
    headers = {
            "Set-Cookie": "value",
            "Set-Cookie1": "value1",
            "Set-Cookie2": "value2",
            "value3": "Set-Cookie3"
        }
    cookie_jar = CookieJar(headers)
    cookie_jar.cookie_headers = cookie_headers
    # Test
    cookie_jar[name] = value
    assert name in cookie_jar
    assert value == cookie_jar[name].value
    assert cookie_jar is not None
    assert "value3" in headers

# Generated at 2022-06-26 03:11:51.342421
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = "var_0"
    value_0 = "YnJlYWQ="
    max_age_0 = 1580514681
    key_1 = "var_1"
    value_1 = "cXVpY2s="
    max_age_1 = 1580514692
    key_2 = "var_2"
    value_2 = "Y2hlY2tib3g="
    max_age_2 = 1580514703

    cookie_0 = Cookie(key_0, value_0)
    cookie_0["max-age"] = max_age_0
    result_0 = cookie_0.__str__()
    assert result_0 == "var_0=YnJlYWQ%3D; Max-Age=1580514681"


# Generated at 2022-06-26 03:12:04.378915
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("chocolate-chip", "hello, world!")
    cookie["httponly"] = False
    cookie["expires"] = datetime(2016, 6, 19, 16, 15, 2)
    cookie["domain"] = "localhost"
    cookie["secure"] = True
    cookie["samesite"] = "Strict"
    cookie["path"] = "/"
    cookie["version"] = 1
    cookie["comment"] = "sample comment"
    cookie["max-age"] = 0

    assert str(cookie) == 'chocolate-chip=hello, world!; HttpOnly; expires=Sun, 19-Jun-2016 16:15:02 GMT; domain=localhost; Secure; SameSite=Strict; Path=/; Version=1; Comment="sample comment"; Max-Age=0'


# Generated at 2022-06-26 03:12:16.836422
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Try deleting a cookie from a null cookie jar
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    try:
        assert "cookie_0" in cookie_jar_0
        cookie_jar_0.__delitem__("cookie_0")
        assert "cookie_0" not in cookie_jar_0
    except:
        assert False

    # Try deleting a cookie from a cookie jar that has a cookie
    cookie_1 = Cookie("cookie_1", "chocolate chip")
    cookie_jar_1 = CookieJar(cookie_1)
    try:
        assert "cookie_1" in cookie_jar_1
        cookie_jar_1.__delitem__("cookie_1")
        assert "cookie_1" not in cookie_jar_1
    except:
        assert False

#

# Generated at 2022-06-26 03:12:21.148062
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    result = cookie_jar_0.__setitem__("U6=Fm\",ySGLzm", "YJ\"lJX",)
    assert result == None


# Generated at 2022-06-26 03:12:26.544968
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # in case that the cookie key does not exist
    cookie_1 = MultiDict()
    cookie_jar_1 = CookieJar(cookie_1)
    key_1 = "session"
    cookie_jar_1[key_1] = "65735c2f-6e7e-4a4a-aa14-4c56dc8d2a25"
    cookie_jar_1[key_1]["max-age"] = 0
    print(cookie_jar_1)


# Generated at 2022-06-26 03:12:34.425517
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    try:
        cookie_jar_0.__delitem__(None)
    except (KeyError, TypeError):
        pass
    else:
        assert False
    cookie = Cookie(None, None)
    cookie_jar = CookieJar(cookie)
    try:
        cookie_jar.__delitem__("thisshouldnotexist")
    except (KeyError, TypeError):
        pass
    else:
        assert False


# Generated at 2022-06-26 03:12:37.207474
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Arguments for function call
    key_1 = "key000"
    value_1 = "value000"
    cookie_0 = Cookie(key_1,value_1)
    # Arguments for method call
    key_2 = "path"
    value_2 = "/"
    cookie_0.__setitem__(key_2,value_2)
    # Check return value
    assert cookie_0[key_2] == value_2


# Generated at 2022-06-26 03:12:43.275482
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    name = "cookie_name"
    value = "cookie_value"
    path = "/"
    expires = "expires"
    max_age = "max_age"
    other_key = "other_key"
    other_value = "other_value"
    cookie = Cookie(name, value)
    cookie["path"] = path
    cookie["expires"] = expires
    cookie["max-age"] = max_age
    cookie[other_key] = other_value
    expected = f"{name}={value}; path={path}; expires={expires}; max-age={max_age}; other_key={other_value}"
    actual = str(cookie)
    assert expected == actual


# Generated at 2022-06-26 03:12:53.985424
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = dict()
    cookie_jar_0 = CookieJar(headers)

    # Test: If this cookie doesn't exist, add it to the header keys
    cookie_jar_0['key001'] = 'value001'


# Generated at 2022-06-26 03:13:04.440240
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # cookie = Cookie("name", "value")
    # cookie["session"] = str_0
    # cookie["domain"] = "0"
    # cookie["path"] = "0"
    # cookie["expires"] = "0"
    # cookie["max-age"] = 0
    # cookie["secure"] = "0"
    # cookie["httponly"] = "0"
    # cookie["version"] = "0"
    # cookie["samesite"] = "0"
    cookie_jar = CookieJar({'Set-Cookie': ['session=7d60fb69-3db3-43f0-9d8e-97cecda75f12']})
    # assert isinstance(cookie_jar, CookieJar)
    cookie_jar.__delitem__("session")


# Generated at 2022-06-26 03:13:13.538611
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Cookie_0
    key = 'session'
    value = '72349a54-84a7-11e9-8a7f-0242ac140004'
    cookie_0 = Cookie(key, value)
    key = 'Path'
    value = '/'
    cookie_0[key] = value
    key = 'expires'
    value = datetime(2019, 8, 20, 10, 42, 42, 788353)
    cookie_0[key] = value
    test_case_0()


# Generated at 2022-06-26 03:13:25.538943
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    
    cookie = Cookie('session', '6fdfac6b17e8fa00dc0b064b73d2b6833f8c4ba4')
    cookie['expires'] = datetime(2022, 12, 25, 17, 28, 11)
    cookie['path'] = '/'
    str_1 = str(cookie)

    assert(str_1 == 'session=6fdfac6b17e8fa00dc0b064b73d2b6833f8c4ba4; expires=Tue, 25-Dec-2022 17:28:11 GMT; Path=/')


# Generated at 2022-06-26 03:13:38.329634
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('session', '61913ac6-f8d3-3bbe-b6e3-664430c8a8e6')
    if (cookie_0['max-age'] != None):
        cookie_0['max-age'] = 0
    cookie_0.value = 'c12ee195-ec8c-3e84-83aa-f05b34e8c7a3'
    assert str(cookie_0) == 'session=c12ee195-ec8c-3e84-83aa-f05b34e8c7a3'
    cookie_0['max-age'] = 0

# Generated at 2022-06-26 03:13:46.384483
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(headers=MultiHeader())
    cookie_jar_0.__setitem__(key='session', value='eyJfY3JlYXRlZCI6MTU5MjA5NzA5Nzc0OCwiX2lkIjoiNWVhZWQ5YTYzMDI0YmQ2Y2JjODg1MTIxIn0==.')
    expected__setitem__ = {'session': 'eyJfY3JlYXRlZCI6MTU5MjA5NzA5Nzc0OCwiX2lkIjoiNWVhZWQ5YTYzMDI0YmQ2Y2JjODg1MTIxIn0==.'}
    assert expected__setitem__ == cookie_jar

# Generated at 2022-06-26 03:13:51.310823
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["session"] = "123456"
    del cookie_jar["session"]
    assert not headers.get("Set-Cookie")


# Generated at 2022-06-26 03:13:54.050863
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_1 = CookieJar()
    str_0 = 'session'
    cookie_jar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:14:02.846114
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Initialization

    # Testing
    try:
        test_case_0()
    # AssertionError: None
    except AssertionError as e:
        print("AssertionError:", e)
    # TypeError: Cookie max-age must be an integer
    except TypeError as e:
        print("TypeError:", e)
    # AttributeError: 'NoneType' object has no attribute 'group'
    except AttributeError as e:
        print("AttributeError:", e)
    # KeyError: None
    except KeyError as e:
        print("KeyError:", e)
    # StopIteration
    except StopIteration:
        pass


# Generated at 2022-06-26 03:14:06.065971
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    args = {}

    # Exercise
    cookie_jar_obj = CookieJar(**args)

    # Verify
    str_0 = 'session'
    assert str_0 in cookie_jar_obj

    # Cleanup - N/A


# Generated at 2022-06-26 03:14:12.875538
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["session"] = "kobebryant"
    cookie_jar.__delitem__('session')


# Generated at 2022-06-26 03:14:14.724592
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Try to delete from a None type
    try:
        CookieJar.__delitem__(None)
    except TypeError:
        pass


# Generated at 2022-06-26 03:14:21.710108
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print ('Test CookieJar.__delitem__():')

    # Setup
    obj_0 = CookieJar(headers=MultiHeader())
    str_0 = 'session'
    obj_0[str_0] = str_2

    obj_0.__delitem__(str_0)

    # Assert
    assert obj_0[str_0] == None

# Generated at 2022-06-26 03:14:25.556792
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    obj = CookieJar(headers=None)
    arg_0 = 'session'
    def test_CookieJar___delitem___a():
        assert obj.__delitem__(arg_0)
    test_CookieJar___delitem___a()



# Generated at 2022-06-26 03:14:29.993000
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar['session'] = '123456'
    cookie_jar['nickname'] = 'mike'
    del cookie_jar['session']
    del cookie_jar['non-existent']



# Generated at 2022-06-26 03:14:33.288791
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies[str_0] = '_token=; Path=/; HttpOnly'
    cookies.__delitem__(str_0)

# Generated at 2022-06-26 03:14:36.161718
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # The actual string representation of the cookie, to be compared against the test cases
    actual_str = Cookie(key='hello', value='world').__str__()
    expected_str = 'hello=world'

    assert actual_str == expected_str


# Generated at 2022-06-26 03:14:38.624900
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Format as a Set-Cookie header value.
    cookie = Cookie('session', 'testcase')
    assert "session=testcase" in str(cookie)

# Generated at 2022-06-26 03:14:50.060873
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    jar = CookieJar(MultiHeader())
    jar["key"] = "value"
    assert jar.headers["Set-Cookie"] == {
        "Set-Cookie": "key=value; Path=/"
    }
    jar["key"]["domain"] = "sanic.org"
    assert jar.headers["Set-Cookie"] == {
        "Set-Cookie": "key=value; Path=/; Domain=sanic.org"
    }
    jar["key"]["path"] = "/api"
    assert jar.headers["Set-Cookie"] == {
        "Set-Cookie": "key=value; Path=/api; Domain=sanic.org"
    }
    jar["key"]["expires"] = datetime(2020, 1, 1, 1, 1, 1)

# Generated at 2022-06-26 03:14:54.273003
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = HTTPHeaderMap()
    c_obj_0 = CookieJar(headers)
    str_0 = 'session'
    del c_obj_0[str_0]
    headers.add('Set-Cookie', 'session=""; Max-Age=0')


# Generated at 2022-06-26 03:15:03.010913
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test case for variable 'output' - type (list of strings)
    str_0 = '; '.join(['session=%s' % _quote('Hello World')])
    assert str_0 == Cookie('session', 'Hello World').__str__()


# Generated at 2022-06-26 03:15:05.084900
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('session','')
    s = c.__str__()
    return s


# Generated at 2022-06-26 03:15:08.332837
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert 'Set-Cookie: session=; HttpOnly; Path=/' == str(Cookie('session',''))


# Generated at 2022-06-26 03:15:19.202764
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'session'
    str_1 = 'user-id'
    str_2 = 'user-name'
    str_3 = 'user-email'
    str_4 = 'user-roles'
    str_5 = 'user-permissions'
    int_1 = 10
    test_obj_0 = CookieJar(str_0)
    str_6 = 'totally-correct-username'
    str_7 = 'totally-correct-password'
    str_8 = 'totally-incorrect-username'
    str_9 = 'totally-incorrect-password'
    str_10 = 'totally-correct-username'
    str_11 = 'totally-correct-password'
    str_12 = 'totally-correct-username'

# Generated at 2022-06-26 03:15:28.501714
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_case_0()
    headers = {'Content-Length': '0', 'Content-Type': 'text/plain'}
    cookiejar = CookieJar(headers)
    str_0 = 'session'
    str_1 = 'digest'

# Generated at 2022-06-26 03:15:33.948717
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'session'
    str_1 = '5cc5a5e8b99eb6512f2c36f1b1d30b0e'
    cookie_0 = Cookie(str_0, str_1)
    str_2 = cookie_0.__str__()
    print(str_2)


# Generated at 2022-06-26 03:15:45.334464
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'session'
    str_1 = 'session'
    str_2 = ''
    str_3 = 'session'
    int_1 = 1
    int_0 = 0
    str_4 = 'session'
    str_5 = 'session'
    str_6 = 'session'
    str_7 = 'session'

    headers = MultiHeader()
    jar = CookieJar(headers)
    jar[str_0] = str_1
    assert headers[str_2] == str_3
    assert jar[str_0].value == int_1
    del jar[str_0]
    assert not headers.get(str_0)
    jar.headers[str_0] = str_4
    jar[str_0] = str_5
    assert headers[str_0] == str_6


# Generated at 2022-06-26 03:15:53.180739
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # ---- Setup
    mock_self = Mock(Cookie)
    mock_self.key = 'session'
    mock_self.value = 'session'
    mock_self.items = Mock()
    mock_self.items.return_value = None
    mock_self.__setitem__ = Mock()
    mock_self.__setitem__.return_value = None

    # ---- Exercise
    result = Cookie.__str__(mock_self)

    # ---- Verify
    assert result == 'session=session'



# Generated at 2022-06-26 03:15:56.695533
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_Cookie1 = Cookie('k', 'v')
    test_Cookie1["path"] = "/"
    expected = "k=v; Path=/"
    assert(str(test_Cookie1) == expected)
    


# Generated at 2022-06-26 03:15:57.450867
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Cookie.__str__('session')
    # pass
    pass



# Generated at 2022-06-26 03:16:09.243505
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("tasty_cookie", "yum")
    cookie["Comment"] = "tastes really good"
    cookie["Comment"].set("but expensive", "not a real comment")
    cookie["max-age"] = 3600
    # The Expires header is optional, but it shouldn't appear in the output.
    cookie["expires"] = datetime(2030, 1, 1)
    assert str(cookie) == (
        "tasty_cookie=yum; Comment=tastes really good; max-age=3600; Path=/; "
        "Domain=; Version=; SameSite="
    )

# Generated at 2022-06-26 03:16:15.733094
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # (1) Test case with cookie_0

    # Test case description
    # Test that the method __str__ of cookie_0 returns the expected value.
    # Expected output (string):
    # "cookie_0=None"

    # (1.1)
    # Setup
    cookie_0 = Cookie()

    # Exercise
    actual = cookie_0.__str__()

    # Verify
    assert actual == "cookie_0=None"


# Generated at 2022-06-26 03:16:23.462421
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("test", "cookie")
    cookie_0["path"] = "/"
    cookie_0["comment"] = "test comment"
    cookie_0["version"] = 1
    cookie_0["max-age"] = DEFAULT_MAX_AGE
    cookie_0["secure"] = False
    cookie_0["httponly"] = False
    cookie_0["samesite"] = "Lax"
    expected_result_0 = "test=test; Path=/; HttpOnly; SameSite=Lax; Max-Age=0; Secure; Version=1; Comment=\"test comment\""
    assert (str(cookie_0) == expected_result_0)

test_case_0()
test_Cookie___str__()

# Generated at 2022-06-26 03:16:34.450766
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("c1", "123")
    str_0 = str(cookie_0)
    assert str_0 == "c1=123"

    cookie_1 = Cookie("c1", "123")
    cookie_1["httponly"] = True
    str_1 = str(cookie_1)
    assert str_1 == "c1=123; HttpOnly"

    cookie_2 = Cookie("c1", "123")
    cookie_2["httponly"] = False
    str_2 = str(cookie_2)
    assert str_2 == "c1=123"

    cookie_3 = Cookie("c1", "123")
    cookie_3["httponly"] = True
    cookie_3["secure"] = True
    str_3 = str(cookie_3)

# Generated at 2022-06-26 03:16:40.612959
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    str_0 = '8O#'
    str_1 = 'fE'
    cookie_jar_0[str_0] = str_1
    assert headers_0.get('Set-Cookie') == '8O#=fE; Path=/'
    assert cookie_jar_0['8O#'].value == 'fE'


# Generated at 2022-06-26 03:16:46.849977
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    header_key = "Set-Cookie"
    headers = []
    cookie_0 = Cookie("foo", "bar")
    cookie_0["path"] = "/"
    cookie_jar_0 = CookieJar(headers)
    cookie_jar_0[cookie_0.key] = cookie_0
    cookie_jar_0.cookie_headers[cookie_0.key] = header_key
    assert len(cookie_jar_0.cookie_headers) > 0
    assert len(cookie_jar_0.headers) > 0
    del cookie_jar_0["foo"]
    assert len(cookie_jar_0.cookie_headers) == 0
    assert len(cookie_jar_0.headers) == 0

# Generated at 2022-06-26 03:16:53.504476
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(MultiHeader())
    cookie_jar_0["key"] = "v"
    cookie_jar_0["key"] = "v"
    key = "key"
    try:
        del cookie_jar_0[key]
    except KeyError:
        print("MultiHeader doesn't support deletion")


# Generated at 2022-06-26 03:16:59.416298
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = ''
    cookie_jar_0 = CookieJar(cookie_0)
    key_0 = '7]vEbU.V6'
    value_0 = 'q'
    cookie_jar_0.__setitem__(key_0, value_0)
    key_1 = '7]vEbU.V6'
    cookie_jar_0.__delitem__(key_1)


# Generated at 2022-06-26 03:17:06.581390
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('test_key', 'test_value')
    cookie_0['path'] = '/'
    cookie_0['max-age'] = 0
    assert str(cookie_0) == 'test_key=test_value; Path=/; Max-Age=0'
    cookie_1 = Cookie('test_key', 'test_value_2')
    cookie_1['path'] = '/'
    cookie_1['max-age'] = 0
    assert str(cookie_1) == 'test_key=test_value_2; Path=/; Max-Age=0'


# Generated at 2022-06-26 03:17:16.208117
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("a", "b")
    assert c.key == "a"
    assert c.value == "b"
    assert c["secure"] == False
    assert c["httponly"] == False
    assert c["path"] == None
    assert c["domain"] == None
    assert c["comment"] == None
    assert c["expires"] == None
    assert c["version"] == None
    assert c["max-age"] == None
    assert c["samesite"] == None
    assert str(c) == "a=b"
    c["max-age"] = 0
    assert str(c) == "a=b; Max-Age=0"
    c["max-age"] = 0
    c["secure"] = True
    assert str(c) == "a=b; Max-Age=0; Secure"


# Generated at 2022-06-26 03:17:34.366259
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('key_0', 'value_0')
    cookie_0['path'] = '/'
    cookie_0['version'] = '1'
    cookie_0['domain'] = 'example.com'
    cookie_0['secure'] = True
    cookie_0['httponly'] = True
    cookie_0['max-age'] = 10
    cookie_0['expires'] = datetime(year=2020, month=9, day=10, hour=12, minute=0, second=0)
    cookie_0['samesite'] = None
    expected = "key_0=value_0; Path=/; Secure; HttpOnly; Max-Age=10; Domain=example.com; Expires=Thu, 10-Sep-2020 12:00:00 GMT; Version=1"
    assert str(cookie_0)

# Generated at 2022-06-26 03:17:38.868456
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Setup
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    key = ""

    # Invocation
    cookie_jar_0.__delitem__(key)



# Generated at 2022-06-26 03:17:42.054957
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_name_0 = "7Xu"
    try:
        cookie_jar_0.__delitem__(cookie_name_0)
    except TypeError as e:
        pass


# Generated at 2022-06-26 03:17:47.326235
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {'User-Agent': 'Mozilla/5.0'}
    cookie_jar = CookieJar(headers)
    cookie_jar['key'] = 'value'
    del cookie_jar['key']
    if 'key' not in cookie_jar:
        print("Test passed")
    else:
        print("Test failed")


# Generated at 2022-06-26 03:17:54.591619
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_name_0 = '{X=[y|3@4Y^UP>%c}*Q?E>,vb(S_'
    cookie_value_0 = '@,6U&M6PCR!K=IEZ.x${>/c5B5/}mL'
    cookie_jar_0.add(cookie_name_0, cookie_value_0)



# Generated at 2022-06-26 03:18:06.488398
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create data fixture
    headers = {
        "Content-Type": "text/plain",
        "Set-Cookie": "session=12345; Expires=Thu, 01 Jan 1970 00:00:00 GMT",
    }
    jar = CookieJar(headers)

    # Verify __delitem__ returns expected result
    assert jar["session"] == "12345"
    with pytest.raises(KeyError):
        del jar["foo"]
    del jar["session"]
    assert jar["session"] == ""
    assert headers["Set-Cookie"] == "session=; Max-Age=0"



# Generated at 2022-06-26 03:18:15.651710
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_val_0 = "test 0"
    cookie_key_0 = "test 0"
    cookie_jar_0[cookie_key_0] = cookie_val_0
    cookie_val_1 = "test 1"
    cookie_key_1 = "test 1"
    cookie_jar_0[cookie_key_1] = cookie_val_1
    cookie_val_2 = "test 2"
    cookie_key_2 = "test 2"
    cookie_jar_0[cookie_key_2] = cookie_val_2
    cookie_val_3 = "test 3"
    cookie_key_3 = "test 3"
    cookie_jar_0[cookie_key_3] = cookie_val_3
   

# Generated at 2022-06-26 03:18:20.812702
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Case 0
    # Test for empty cookie
    # Should return empty string
    cookie_0 = Cookie("Cookie", "")
    assert str(cookie_0) == ""

    # Case 1
    # Test for default cookie
    # Should return a string
    cookie_1 = Cookie("Cookie", "1234")
    assert str(cookie_1) == "Cookie=1234"

    # Case 2
    # Test for cookie with properties
    # Should return a string
    cookie_2 = Cookie("Cookie", "1234")
    cookie_2["domain"] = "localhost"
    cookie_2["path"] = "/"
    assert str(cookie_2) == "Cookie=1234; Domain=localhost; Path=/"

    # Case 3
    # Test for cookie with multiple properties
    # Should return a string
    cookie

# Generated at 2022-06-26 03:18:28.500824
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_key_0 = "co>'1"
    cookie_jar_0[cookie_key_0]
    try:
        cookie_jar_0[cookie_key_0] = ""
    except KeyError:
        pass
    assert KeyError



# Generated at 2022-06-26 03:18:33.072921
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)

    cookie_jar["test_key"] = "test_value"
    assert len(cookie_jar) == 1

    del cookie_jar["test_key"]
    assert len(cookie_jar) == 0

    del cookie_jar["test_key"]
    assert len(cookie_jar) == 0


# Generated at 2022-06-26 03:18:49.186289
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # test default case
    headers = {
            'a': 'b',
            'cookie-key': 'cookie-value'
        }
    test_cookie_jar = CookieJar(headers)

    assert test_cookie_jar.cookie_headers == {'cookie-key': 'Set-Cookie'}
    assert test_cookie_jar.headers['Set-Cookie'] == 'cookie-key=cookie-value'

    test_cookie_jar['cookie-key'] = 'updated-cookie-value'
    assert test_cookie_jar.headers['Set-Cookie'] == 'cookie-key=updated-cookie-value'

    test_cookie_jar['new-cookie-key'] = 'new-cookie-value'

# Generated at 2022-06-26 03:18:50.060491
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert False, "Not implemented"


# Generated at 2022-06-26 03:19:01.940173
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    method = Cookie.__str__
    cookie_0 = Cookie("one", "two")
    cookie_0["path"] = "/"
    assert method(cookie_0) == "one=two; Path=/"
    cookie_0["path"] = "/a"
    assert method(cookie_0) == 'one=two; Path="/a"'
    cookie_0["max-age"] = 3
    assert method(cookie_0) == "one=two; Path=/; Max-Age=3"
    cookie_0["secure"] = None
    assert method(cookie_0) == "one=two; Path=/; Max-Age=3; Secure"
    cookie_0["secure"] = True
    assert method(cookie_0) == "one=two; Path=/; Max-Age=3; Secure"
    cookie_0["secure"] = False

# Generated at 2022-06-26 03:19:06.022008
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar_1 = CookieJar(headers)
    cookie_jar_1["key"] = "value"
    del cookie_jar_1["key"]
    assert "Set-Cookie" not in headers.keys()

# AssertionError: 1 != 0


# Generated at 2022-06-26 03:19:16.866906
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    header_name = "Set-Cookie"
    cookie_1 = Cookie("a", "b")
    cookie_jar_1 = CookieJar({})
    cookie_jar_1[header_name] = cookie_1
    cookie_str = str(cookie_1)
    assert cookie_str == "a=b; Path=/; Domain=; Max-Age=; Secure; HttpOnly"

    header_name = "Set-Cookie"
    cookie_2 = Cookie("a", "b")
    cookie_jar_2 = CookieJar({})
    cookie_jar_2[header_name] = cookie_2
    cookie_str = str(cookie_2)
    assert cookie_str == "a=b; Path=/; Domain=; Max-Age=; Secure; HttpOnly"

    header_name = "Set-Cookie"

# Generated at 2022-06-26 03:19:26.441165
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    key_0 = "m^0ydK[Y5"
    value_0 = "XnU6^"
    cookie_jar_0.__setitem__(key_0, value_0)
    key_1 = "dT"
    value_1 = "W8"
    cookie_jar_0.__setitem__(key_1, value_1)
    key_2 = "J"
    value_2 = "kdSG:m"
    cookie_jar_0.__setitem__(key_2, value_2)
    key_3 = ">"
    value_3 = "4}"
    cookie_jar_0.__setitem__(key_3, value_3)

# Generated at 2022-06-26 03:19:37.016952
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    key = "wad;<"
    try:
        cookie_jar_0.__delitem__(key)
    except KeyError:
        assert True
    else:
        assert False
    #  check for exception
    key = "|s%c7kH>"
    try:
        cookie_jar_0.__delitem__(key)
    except KeyError:
        assert True
    else:
        assert False
    #  check for exception
    key = "]t"
    try:
        cookie_jar_0.__delitem__(key)
    except KeyError:
        assert True
    else:
        assert False
    #  check for exception
    assert True



# Generated at 2022-06-26 03:19:46.898392
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("foo", "bar")
    cookie_1 = Cookie("baz", "foo")
    cookie_2 = Cookie("foo", "bar")
    cookie_2["path"] = "/"
    cookie_2["foo"] = "bar"
    cookie_3 = Cookie("foo", "bar")
    cookie_3["path"] = "/"
    cookie_3["foo"] = "bar"
    cookie_3["expires"] = datetime(2019, 11, 18, 16, 47, 45, 153131)
    cookie_3["max-age"] = 0
    cookie_3["secure"] = False
    cookie_3["httponly"] = False
    cookie_4 = Cookie("foo", "bar")
    cookie_4["path"] = "/"
    cookie_4["foo"] = "bar"
    cookie_

# Generated at 2022-06-26 03:19:48.891328
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Test Case 0
    # Test Case 0
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    try:
        cookie_jar_0.__setitem__(None, None)
    except TypeError:
        pass


# Generated at 2022-06-26 03:19:59.059776
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_0 = Cookie("key_0", "value_0")
    cookie_0["secure"] = True
    cookie_0["path"] = "/"
    cookie_0["domain"] = "localhost"
    cookie_0["max-age"] = DEFAULT_MAX_AGE
    cookie_0["httponly"] = True
    cookie_0["expires"] = datetime(1980, 12, 1)
    cookie_0["samesite"] = "Lax"
    cookie_jar_0[cookie_0.key] = cookie_0
    value_1 = cookie_jar_0[cookie_0.key]
    key_0 = cookie_0.key
    value_2 = cookie_0.value
    value_3 = cookie_

# Generated at 2022-06-26 03:20:12.127614
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_1 = None
    cookie_jar_1 = CookieJar(cookie_1)
    cookie_key_1 = 'helpy'
    cookie_value_1 = 'takes a licking and keeps on ticking'
    cookie_jar_1[cookie_key_1] = cookie_value_1
    del cookie_jar_1[cookie_key_1]
    assert not cookie_jar_1


# Generated at 2022-06-26 03:20:14.037789
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('test', 'hello world')
    c['max-age'] = 0
    print(c)


if __name__ == "__main__":
    test_Cookie___str__()

# Generated at 2022-06-26 03:20:17.095441
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__(): 
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_jar_0['key_0'] = 'value_1'
    del cookie_jar_0['key_0']


# Generated at 2022-06-26 03:20:21.479686
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_1 = None
    cookie_jar_1 = CookieJar(cookie_1)
    cookie_1 = cookie_jar_1["test_cookie"] = "test"
    str_cookie_str = str(cookie_1)
    # TODO: AssertionalCode
    pass


# Generated at 2022-06-26 03:20:31.288267
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = Cookie("PYTHON", "PASS")
    cookie_jar_0 = CookieJar({})
    cookie_jar_0["PYTHON"] = "PASS"
    cookie_jar_0["PYTHON"] = "FAIL"
    cookie_jar_0["PYTHON"] = "FAIL"
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_0["PYTHON"]
    del cookie_jar_

# Generated at 2022-06-26 03:20:35.726221
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    str_0 = 'abc'
    str_1 = 'def'
    cookie_jar_0.__setitem__(str_0, str_1)


# Generated at 2022-06-26 03:20:41.682911
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    cookie_1 = Cookie("_test_cookie","test_value")
    cookie_jar_0.__setitem__("_test_cookie",cookie_1)
    cookie_jar_0.__delitem__("_test_cookie")
    assert(cookie_jar_0.get("_test_cookie") == None)


# Generated at 2022-06-26 03:20:45.119839
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
  response = {'A': 1}
  cookie = 'Value'
  cookie_jar = CookieJar(response)
  cookie_jar['Name'] = cookie
  assert cookie_jar['Name'] == 'Value'


# Generated at 2022-06-26 03:20:50.267306
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('name', 'value')
    assert cookie.__str__() == 'name=value'
    new_cookie = Cookie('name', 'value')
    new_cookie['path'] = "/"
    assert new_cookie.__str__() == "name=value; Path=/"




# Generated at 2022-06-26 03:20:56.333699
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = None
    cookie_jar_0 = CookieJar(cookie_0)
    assert_equals(len(cookie_jar_0), 0)

    cookie_1 = "SESSIONID=1234"
    cookie_jar_1 = CookieJar(cookie_1)
    assert_equals(len(cookie_jar_1), 1)

    cookie_jar_0["SESSIONID"] = "1"
    assert_equals(len(cookie_jar_0), 1)
    cookie_jar_0["SESSIONID"] = "2"
    assert_equals(len(cookie_jar_0), 1)
    cookie_jar_0["SESSIONID"] = "3"
    assert_equals(len(cookie_jar_0), 1)
