

# Generated at 2022-06-26 03:11:28.706120
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    cookie_0___setitem__(cookie_0, None)


# Generated at 2022-06-26 03:11:33.936297
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    try:
        cookie_0.__setitem__(bool_0, bool_0)
    except KeyError:
        pass
    try:
        cookie_0.__setitem__(bool_0, bool_0)
    except TypeError:
        pass


# Generated at 2022-06-26 03:11:41.842816
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    cookie_0["expires"] = bool_0
    cookie_0["httponly"] = bool_0
    cookie_0["max-age"] = True
    cookie_0["samesite"] = bool_0
    cookie_0["secure"] = bool_0
    cookie_0["version"] = bool_0
    cookie_0["path"] = "Gx#e"
    cookie_0["domain"] = "Gx#e"
    cookie_0["comment"] = "Gx#e"
    assert isinstance(cookie_0, dict)
    assert isinstance(cookie_0, dict)
    assert isinstance(cookie_0, dict)


# Generated at 2022-06-26 03:11:44.134369
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Impossible to test since it is a pure python function...
    assert True


# Generated at 2022-06-26 03:11:48.751540
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    var_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:11:52.895768
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(None)
    try:
        cookie_jar_0.__delitem__('')
        test_case_0()
    except Exception as e:
        print(e)
        raise

# Generated at 2022-06-26 03:11:55.552649
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    var_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:11:59.710592
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    headers = None
    cookie_jar = CookieJar(headers)
    cookie_jar['key'] = 'cookie value'
    # Test
    cookie_jar.__delitem__('key')



# Generated at 2022-06-26 03:12:03.819448
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)

    cookie_jar['foo'] = 'bar'
    assert 'foo' in cookie_jar

    # Delete foo
    del cookie_jar['foo']
    assert 'foo' not in cookie_jar

    # Delete foo again
    del cookie_jar['foo']
    assert 'foo' not in cookie_jar


# Generated at 2022-06-26 03:12:05.843123
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # initialization
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)

    # method call
    var_0 = cookie_0.__str__()

    # assert
    assert True



# Generated at 2022-06-26 03:12:21.234953
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bool_0 = False
    cookie_0 = Cookie(bool_0, bool_0)
    cookie_0["path"] = bool_0
    cookie_0.__setitem__(bool_0, bool_0)
    cookie_0.__setitem__(bool_0, "true")
    cookie_0.__setitem__(bool_0, bool_0)
    cookie_0.__setitem__(bool_0, "true")
    cookie_0.__setitem__(bool_0, bool_0)
    cookie_0.__setitem__(bool_0, bool_0)
    cookie_0.__setitem__(bool_0, "true")
    cookie_0.__setitem__(bool_0, bool_0)

# Generated at 2022-06-26 03:12:23.700694
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    try:
        cookie_0.__setitem__("comment", bool_0)
    except KeyError:
        pass
    str_0 = cookie_0.__setitem__("max-age", bool_0)
    int_0 = cookie_0.__setitem__("expires", bool_0)


# Generated at 2022-06-26 03:12:28.630209
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    cookie_jar_0 = CookieJar(bool_0)
    cookie_jar_0.__delitem__(cookie_0)


# Generated at 2022-06-26 03:12:30.075976
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    assert True



# Generated at 2022-06-26 03:12:35.437643
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar['cookie'] = 'value'
    cookie_jar.headers = {'Set-Cookie': {'cookie': 'value'}}
    assert cookie_jar.headers == {'Set-Cookie': {'cookie': 'value'}}
    del cookie_jar['cookie']
    assert cookie_jar.headers == {}


# Generated at 2022-06-26 03:12:38.585069
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = dict()
    headers_0["Set-Cookie"] = "; Expires=Thu, 01 Jan 1970 00:00:00 GMT"
    headers_0["Set-Cookie"] = "; Max-Age=0"
    dict_0 = dict()
    dict_0["cookie_headers"] = headers_0
    dict_0["headers"] = headers_0
    dict_0["header_key"] = "Set-Cookie"
    cookiejar_0 = CookieJar(dict_0)
    del cookiejar_0["Set-Cookie"]


# Generated at 2022-06-26 03:12:45.001991
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bool_0 = True
    cookie_0 = Cookie(bool_0, bool_0)
    list_1 = ["foo", "bar"]
    cookie_0.__setitem__(None, None)
    cookie_0.__setitem__(list_1[0], list_1[1])


# Generated at 2022-06-26 03:12:48.501329
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    one = True
    two = True
    cookiejar[one] = two
    cookiejar[one] = two
    cookiejar.__delitem__(one)


# Generated at 2022-06-26 03:12:53.022281
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bool_0 = True
    multi_header_0 = MultiHeader("Set-Cookie", bool_0)
    dict_0 = dict()
    dict_0["Set-Cookie"] = multi_header_0
    cookie_jar_0 = CookieJar(dict_0)
    cookie_jar_0.__delitem__("t")


# Generated at 2022-06-26 03:12:55.756577
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie(True, True)
    var_0 = cookie_0.__str__()
    print(var_0)


# Generated at 2022-06-26 03:13:13.370060
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = '<urlopen error [SSL: CERTIFICATE_VERIFY_FAILED] certificate verify failed: unable to get local issuer certificate (_ssl.c:1056)>'
    str_1 = 'ut'
    cookie_0 = Cookie(str_1, str_1)
    cookie_0.__setitem__(str_1, str_1)
    str_2 = 'b/)'
    cookie_0 = Cookie(str_2, str_2)
    var_0 = cookie_0.encode(str_2)


# Generated at 2022-06-26 03:13:21.901856
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'te'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = ', '
    str_1 = str_1.join(('%s=%s', '%s="te"', '%s=te'))
    assert str_1 == str(cookie_0)


# Generated at 2022-06-26 03:13:31.369922
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'ey'
    str_1 = 'qo'
    str_2 = 'z1'
    cookie_0 = Cookie(str_0, str_0)
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0[str_1] = str_0
    cookie_jar_0[str_2] = str_0
    cookie_jar_0.headers[str_1] = str_0
    cookie_jar_0[str_0] = str_1
    cookie_jar_0[str_1] = str_0
    cookie_jar_0[str_2] = 'f'
    cookie_jar_0.headers[str_1] = str_0

# Generated at 2022-06-26 03:13:35.979958
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {'cookie': 'asdf'}
    cookieJar = CookieJar(headers)
    key = 'nmtt8mb6-c'
    cookieJar.__delitem__(key)
    assert cookieJar['nmtt8mb6-c'] is None


# Generated at 2022-06-26 03:13:40.787454
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    var_0 = CookieJar(str)
    # Assign value to var_0 (CookieJar)

    str_0 = 'ey'
    var_0[str_0] = str_0
    # Assign to key in var_0 (CookieJar)
    del var_0[str_0]


# Generated at 2022-06-26 03:13:52.212309
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    num_1 = -1
    str_0 = '7V'
    str_1 = 'le'
    str_2 = '79'
    str_3 = '6W'
    str_4 = 'Yg'
    str_5 = '6k'
    str_6 = '8f'
    str_7 = '6Q'
    str_8 = 'Ft'
    str_9 = '6C'
    str_10 = '65'
    str_11 = '8g'
    str_12 = '6G'
    str_13 = '7s'
    str_14 = '6T'
    str_15 = '8p'
    str_16 = '6A'
    str_17 = '7o'
    str_18 = '6Z'
    str_19

# Generated at 2022-06-26 03:13:55.355831
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'iL1'
    str_2 = 'eOwG'
    cookie_0[str_1] = str_2
    str_3 = 'b<M'
    str_4 = 'flv'
    cookie_0[str_3] = str_4
    var_0 = cookie_0[str_1]


# Generated at 2022-06-26 03:14:05.500524
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    jar_0 = CookieJar(headers)
    jar_0 = CookieJar(headers)
    var_0 = jar_0.get("not a key")
    str_0 = 'a'
    jar_0[str_0] = str_0
    jar_0 = CookieJar(headers)
    var_1 = jar_0.get("not a key")
    str_0 = 'a'
    jar_0[str_0] = str_0
    str_1 = 'a'
    var_2 = jar_0[str_1]
    str_2 = 'a'
    del jar_0[str_2]
    # Test header has been removed
    var_3 = headers.getlist("Set-Cookie")
    assert var_3 == []

# Generated at 2022-06-26 03:14:10.898747
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # TODO - fix this, it's quite broken
    str_0 = 'q3'
    str_1 = '8'
    cookie_0 = Cookie(str_0, str_1)
    cookie_1 = CookieJar(dict())
    cookie_1[str_0] = str_1
    del cookie_1[str_0]



# Generated at 2022-06-26 03:14:17.900645
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    with pytest.raises(KeyError) as exception_context:
        str_0 = 'Secret'
        cookie_0 = Cookie(str_0, str_0)
        str_1 = 'Secret'
        str_2 = 'Secret'
        try:
            cookie_0.__setitem__(str_1, str_2)
        except Exception as e:
            pytest.fail(f"Exception occurred: {e}")
        else:
            pytest.fail(
                "Expected Exception was not raised for Cookie.__setitem__"
            )

# Generated at 2022-06-26 03:14:27.916320
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    var_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:14:37.418815
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'e*'
    cookie_0 = Cookie(str_0, str_0)

    # Append the header to the header string
    str_1 = 'e^'
    str_2 = 'l+'
    str_3 = 'w1'
    str_4 = '^%c'
    int_0 = 0
    int_1 = 1
    dict_0 = dict()
    dict_0[str_1] = int_0
    dict_0[str_2] = int_1
    dict_0[str_3] = int_0
    dict_0[str_3] = int_0
    dict_0[str_3] = int_0
    dict_0[str_3] = str_4
    dict_0[str_2] = str_4
   

# Generated at 2022-06-26 03:14:40.552812
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({})
    str_0 = 'foo'
    cookie_jar_0.__delitem__(str_0)



# Generated at 2022-06-26 03:14:49.466970
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_1 = '\x00'
    cookie_1 = Cookie(str_1, str_1)
    str_2 = 'tFj34t'
    str_3 = '+_*T'
    var_1 = cookie_1.__setitem__(str_2, str_3)
    str_4 = '\x00'
    cookie_2 = Cookie(str_4, str_4)
    str_5 = 'w'
    str_6 = '\x00'
    var_2 = cookie_2.__setitem__(str_5, str_6)


# Generated at 2022-06-26 03:14:54.046395
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_1 = 'ez'
    value_0 = Cookie(str_1, str_1)
    str_2 = 'ey'
    key_0 = str_2
    str_3 = 'ey'
    value_0.__setitem__(key_0, str_3)


# Generated at 2022-06-26 03:15:01.266632
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Fd'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'rT'
    cookie_1 = Cookie(str_1, str_1)
    str_2 = 'I'
    cookie_2 = Cookie(str_2, str_2)
    cookie_jar_0 = CookieJar({str_2: cookie_2, str_0: cookie_0, str_1: cookie_1})
    str_3 = 'q'
    str_4 = 'S'
    cookie_3 = Cookie(str_4, str_4)
    cookie_3['max-age'] = 0
    str_5 = 'S'
    str_6 = 'B'
    cookie_4 = Cookie(str_6, str_6)

# Generated at 2022-06-26 03:15:05.139999
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    key = 'footle'
    value = 'footle'
    cookie_jar[key] = value


# Generated at 2022-06-26 03:15:09.208522
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    out = str(cookie_0)
    assert out == "ey=\"ey\""


# Generated at 2022-06-26 03:15:11.804736
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = cookie_0.__str__()


# Generated at 2022-06-26 03:15:17.645393
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
	# Create an instance of a CookieJar.
	headers = MultiHeader ()
	cookie_jar = CookieJar (headers)

	try:
		# Call method __delitem__ with a valid input.
		cookie_jar.__delitem__ ("test")
	except KeyError as e:
		print (e)
		raise



# Generated at 2022-06-26 03:15:27.315881
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    cookie_0['expires'] = 'R'
    str_1 = cookie_0.__str__()
    assert str_1 is not None


# Generated at 2022-06-26 03:15:29.191481
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('a', 'b')
    assert str(cookie) == 'a=b'


# Generated at 2022-06-26 03:15:36.996609
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'msrp'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'a'
    str_2 = '\'z'
    str_3 = '\'z'
    cookie_0['a'] = str_1
    str_4 = 'z'
    str_5 = str_4
    try:
        cookie_0['z'] = str_5
    except KeyError:
        pass
    cookie_0[str_2] = str_3



# Generated at 2022-06-26 03:15:48.719529
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case with delection of normal cookies
    cookie_jar_0 = CookieJar({})
    cookie_jar_0['asdf'] = 'asdf'
    assert (cookie_jar_0['asdf'] == 'asdf')
    assert (cookie_jar_0.headers['Set-Cookie'] == 'asdf=asdf')
    del cookie_jar_0['asdf']
    assert (cookie_jar_0.headers['Set-Cookie'] == 'asdf=; Max-Age=0')
    assert (cookie_jar_0.headers.getlist("Set-Cookie") == ['asdf=; Max-Age=0'])

    # Test case with delection of cookies with repeated names
    cookie_jar_1 = CookieJar({})
    cookie_jar_1['asdf'] = 'asdf'
    cookie

# Generated at 2022-06-26 03:15:49.709303
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert True



# Generated at 2022-06-26 03:15:59.975257
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    header_str = 'header_str'
    header_str_1 = 'header_str_1'
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    var_0 = cookie_0.encode(str_0)
    headers = {header_str: header_str_1}
    cookie_jar = CookieJar(headers)
    assert len(cookie_jar) == 0
    cookie_jar[str_0] = str_0
    assert len(cookie_jar) == 1
    assert cookie_jar[str_0] == cookie_0
    cookie_jar[str_0]['path'] = str_0
    assert cookie_jar[str_0]['path'] == str_0
    cookie_jar[str_0]['path'] = str_0

# Generated at 2022-06-26 03:16:07.300576
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = "key"
    str_1 = str(Dataset.getValue())
    str_2 = str(Dataset.getValue())
    cookie_0 = Cookie(str_0, str_1)
    cookie_0["path"] = str_2
    headers_0 = Headers()
    cookiejar_0 = CookieJar(headers_0)
    cookiejar_0[str_0] = str_1
    var_0 = cookiejar_0.headers[str_0]
    assert str_1 in var_0


# Generated at 2022-06-26 03:16:17.395047
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'S;'
    str_1 = '~h'
    str_2 = 'R'
    str_3 = '[E'
    str_4 = 'O1'
    str_5 = '*'
    str_6 = '7'
    str_7 = '`R'
    str_8 = 'c'
    str_9 = 'T'
    str_10 = 'd:r'
    str_11 = '#'
    str_12 = '#N'
    byte_0 = bytes(bytearray([105, 98, 101, 98]))
    byte_1 = bytes(bytearray([116, 98, 114]))
    byte_2 = bytes(bytearray([105, 98, 101, 98]))

# Generated at 2022-06-26 03:16:20.105017
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    try:
        cookie_0['dom'] = str_0
    except KeyError:
        pass


# Generated at 2022-06-26 03:16:22.231523
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_1 = 'f9c'
    cookie_0 = CookieJar(dict())
    cookie_0.__delitem__(str_1)


# Generated at 2022-06-26 03:16:39.891844
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Constructor test
    # Try deleting an item outside of the cookie jar.
    cookie_jar_0 = CookieJar({})
    str_0 = 'o'
    try:
        cookie_jar_0.__delitem__(str_0)
    except KeyError:
        pass
    # Try deleting an item using a key that is not an instance of basestring
    with pytest.raises(TypeError):
        cookie_jar_0.__delitem__(str_0)



# Generated at 2022-06-26 03:16:46.997515
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'iv2700o5'
    str_1 = 'iv2700o5'
    str_2 = 'iv2700o5'
    str_3 = 'iv2700o5'
    str_4 = 'iv2700o5'
    str_5 = 'iv2700o5'
    str_6 = 'iv2700o5'
    str_7 = 'iv2700o5'
    str_8 = 'iv2700o5'
    str_9 = 'iv2700o5'
    str_10 = 'iv2700o5'
    str_11 = 'iv2700o5'
    str_12 = 'iv2700o5'
    cookie_0 = Cookie(str_0, str_1)
    cookie_0['version'] = str_2
    cookie

# Generated at 2022-06-26 03:16:59.041196
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'rmjnmuN  '
    str_1 = '^'
    str_2 = 'Mkqh'
    str_3 = 'un'
    str_4 = 'P'
    str_5 = 'X'
    str_6 = 'LwH'
    str_7 = 'eo'
    str_8 = 'g'
    str_9 = 'm'
    str_10 = '}vK By'
    str_11 = 'Vr'
    str_12 = '~K'
    str_13 = 'h'
    str_14 = 'j'
    str_15 = '{sy'
    str_16 = ';I'
    str_17 = 'eo'
    str_18 = 'l'

# Generated at 2022-06-26 03:17:01.415427
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    var_0 = cookie_0.encode(str_0)


# Generated at 2022-06-26 03:17:07.143759
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers: Dict[str, str] = {}
    cookie_jar = CookieJar(headers)
    del cookie_jar[None]
    assert headers == {}
    assert cookie_jar == {}
    # test duplicate
    cookie_jar["faux"] = 123
    del cookie_jar["faux"]
    assert headers == {}
    assert cookie_jar == {}
    # test direct deletion of __setitem__
    cookie_jar["faux"] = 123
    headers["Set-Cookie"] = "faux=123"
    del cookie_jar["faux"]
    assert headers == {}


# Generated at 2022-06-26 03:17:14.866859
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJleHAiOjI1NjUwNzMzOTksInVzZXJfaWQiOjEyMzQ1Nl0.l_c1mwJfKmvEBP-OtCCeTLKFDerGX9J9tZZ4N4f4dMI'
    cookie_0 = Cookie(str_0, str_0)
    var_0 = cookie_0.encode(str_0)



# Generated at 2022-06-26 03:17:17.256377
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar({})
    str_0 = '-F{'
    str_1 = '/a}Z'
    cookie_jar_0.__setitem__(str_0, str_1)


# Generated at 2022-06-26 03:17:28.417664
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    jar = CookieJar({})
    jar["expires"] = "str"
    jar["test"] = "test"
    jar["test"] = "test"
    jar["test"] = "{}"
    jar["test"] = "test"
    jar["expires"] = "str"
    jar["test"] = "test"
    jar["max-age"] = "bad_value"
    jar["expires"] = "bad_value"
    jar["expires"] = datetime.now()
    jar["max-age"] = 0
    jar["test"] = "test"
    jar["secure"] = "secure"
    jar["secure"] = "secure"
    jar["httponly"] = "httponly"
    jar["httponly"] = "httponly"
    jar["secure"] = "secure"
    jar["httponly"]

# Generated at 2022-06-26 03:17:38.750136
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'G'
    cookie_0 = Cookie(str_0, str_0)
    cookie_0['expires'] = datetime(2014, 6, 12, 21, 35, 35, 353087)
    cookie_0['max-age'] = 12
    cookie_0['secure'] = False
    str_1 = cookie_0.__str__()
    if str_1 == "G=G; Version=1; Max-Age=12; Expires=Thu, 12-Jun-2014 21:35:35 GMT":
        print('Pass')
    else:
        print('Failed: Expected "G=G; Version=1; Max-Age=12; Expires=Thu, 12-Jun-2014 21:35:35 GMT"')


# Generated at 2022-06-26 03:17:52.332112
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Dict[str, str]()
    obj = CookieJar(headers)
    # Check for correct TypeError on invalid key type
    obj = CookieJar(headers)
    try:
        obj.__delitem__(int())
        assert False, "Expected TypeError has not been raised"
    except TypeError:
        assert True
    # Check for correct handling of None key
    obj = CookieJar(headers)
    obj['foo'] = 'bar'
    obj.__delitem__(None)
    assert obj == {}, "Expected {} but got {}"
    # Check for correct handling of missing keys
    obj = CookieJar(headers)
    obj['foo'] = 'bar'
    obj.__delitem__('foobar')
    assert obj == {}, "Expected {} but got {}"
    # Check for correct handling

# Generated at 2022-06-26 03:18:05.352266
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    # Negative test
    with pytest.raises(KeyError):
        del cookie_jar['it']
    # Positive test
    cookie_jar['it'] = "works"
    del cookie_jar['it']


# Generated at 2022-06-26 03:18:10.531904
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("Testcase __setitem__")
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'c'
    try:
        cookie_0.__setitem__(str_1, str_0)
    except KeyError:
        print("Exception thrown")
        return
    assert False


# Generated at 2022-06-26 03:18:15.989423
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    # Test case for __setitem__ of CookieJar
    cookie_jar_0 = CookieJar(headers={})
    key_0 = 'P\x0f$L"O\x0c+\t'
    value_0 = '><G\x1a\x08\x1d\x1a9\n'

    try:
        cookie_jar_0[key_0] = value_0
    except KeyError:

        assert key_0 in cookie_jar_0



# Generated at 2022-06-26 03:18:30.727981
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = '#'
    str_1 = 'j-8'
    str_2 = 'jT'
    str_3 = 'jT'
    dict_0 = dict()
    dict_0['max-age'] = 0
    dict_1 = dict()
    dict_1[str_3] = dict_0
    dict_2 = dict()
    dict_2[str_2] = dict_1
    dict_3 = dict()
    dict_3['expires'] = datetime.now()
    dict_4 = dict()
    dict_4[str_1] = dict_3
    dict_5 = dict()
    dict_5['secure'] = False
    dict_6 = dict()
    dict_6['value'] = str_0
    dict_6[str_0] = dict_

# Generated at 2022-06-26 03:18:33.862791
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    str_1 = 'jdD'
    cookie_0 = Cookie(str_1, str_0)
    assert(cookie_0.__str__() == 'jdD=ey')


# Generated at 2022-06-26 03:18:44.989093
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(None)
    str_0 = 'uh?'
    str_1 = '1(D'
    cookie_jar_0[str_0] = str_1
    var_0 = cookie_jar_0[str_0]
    assert var_0 == str_1
    cookie_0 = Cookie(str_0, str_1)
    cookie_jar_0[str_0] = cookie_0
    var_1 = cookie_jar_0[str_0]
    assert var_1 == cookie_0
    # deletes cookie_0 from cookie_jar_0
    del cookie_jar_0[str_0]
    var_2 = str_0 in cookie_jar_0
    assert var_2 == False
    # deletes cookie_0 from cookie_jar_0

# Generated at 2022-06-26 03:18:50.359447
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'F('
    headers = {}
    cookiejar = CookieJar(headers)
    cookiejar.__setitem__(str_0, str_0)
    str_1 = '/F'
    str_2 = '#'
    cookie_0 = Cookie(str_2, str_1)
    cookie_0.__setitem__(str_2, str_2)
    cookie_0.__setitem__(str_0, str_0)


# Generated at 2022-06-26 03:19:02.067098
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()

    test_cookie_jar_0 = CookieJar(headers)
    test_cookie_key_0 = 'wnepy'
    test_cookie_value_0 = 'ke'

    test_cookie_jar_0[test_cookie_key_0] = test_cookie_value_0

    header_key_0 = 'Set-Cookie'
    header_value_0 = 'wnepy=ke; Path=/'
    test_cookie_jar_0.headers[header_key_0] == header_value_0
    test_cookie_jar_0.cookie_headers[test_cookie_key_0] == header_key_0
    test_cookie_jar_0[test_cookie_key_0].value == test_cookie_value_0

# Generated at 2022-06-26 03:19:13.014747
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = None
    cookieJar_0 = CookieJar(headers)
    str_0 = 'OI3)GIk'
    str_1 = 'y'
    str_2 = 'ey'
    int_0 = -25
    str_3 = '8'
    str_4 = '6'
    bool_0 = False
    str_5 = 'x'
    str_10 = 'l'
    str_11 = '0'
    str_12 = '9'
    str_6 = 'y'
    str_7 = 'ey'
    int_1 = -25
    str_8 = '8'
    str_9 = '6'
    cookieJar_0[str_0] = str_1
    cookieJar_0.__delitem__(str_2)

# Generated at 2022-06-26 03:19:18.004418
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    headers = [('Set-Cookie', 'a=Z')]
    cookie_jar = CookieJar(headers)
    assert cookie_jar.cookie_headers.get('a')

    # Exercise
    del cookie_jar['a']
    assert not cookie_jar.cookie_headers.get('a')
    assert cookie_jar.headers == []


# Generated at 2022-06-26 03:19:44.536465
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # pass
    headers = dict()
    cookie_jar = CookieJar(headers)
    cookie_jar['abc'] = 'xyz'
    assert len(cookie_jar) == 1 and len(headers) == 1
    assert cookie_jar['abc'] == 'xyz'
    assert headers['Set-Cookie'] == 'abc=xyz; path=/'

    del cookie_jar['abc']
    assert len(cookie_jar) == 0 and len(headers) == 0



# Generated at 2022-06-26 03:19:47.509163
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    var_0 = cookie_0.encode(str_0)
    print(var_0)


test_Cookie___str__()

# Generated at 2022-06-26 03:19:49.877208
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    str_0 = 'ey'
    # test formatting as a Set-Cookie header value
    assert cookie_0.__str__() == str_0


# Generated at 2022-06-26 03:19:51.813859
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test for method __str__ of class Cookie
    """
    assert 1 == 1



# Generated at 2022-06-26 03:19:59.845583
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'L8)y'
    cookie_0 = Cookie(str_0, str_0)
    cookie_0["version"] = False
    cookie_0["samesite"] = str_0
    cookie_0["path"] = '!;*$'
    cookie_0['expires'] = datetime(2000, 6, 30, 17, 30, 30, 1100)
    cookie_0["domain"] = str_0
    cookie_0["max-age"] = -2383135
    cookie_0["secure"] = True
    cookie_0["comment"] = 'xy5M'
    cookie_0.__str__()

# Generated at 2022-06-26 03:20:09.497195
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    values = [
        (True, 'Secure'),
        (18, 'Max-Age'),
        ('', 'Domain'),
        ('', 'SameSite'),
        (False, 'HttpOnly'),
        ('', 'Version'),
        ('', 'Path'),
        (0, 'Max-Age'),
    ]
    for tup_0 in values:
        cookie_0[tup_0[1]] = tup_0[0]
    str_0 = cookie_0.__str__()
    var_0 = 'ey=ey; Secure; Max-Age=18; Domain=; SameSite=; HttpOnly; Version=; Path=; Max-Age=0'
    assert var_0 == str_0

# Unit

# Generated at 2022-06-26 03:20:13.208410
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Init a headers
    headers = MultiHeader()

    # Init a cookie jar
    cookie_jar = CookieJar(headers)

    # Set a cookie
    cookie_jar["key"] = "value"

    # Verify the result
    assert headers.getall("Set-Cookie")[0] == "key=value; Path=/"



# Generated at 2022-06-26 03:20:16.492334
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    try:
        assert str(cookie_0) == 'ey=ey'
    except AssertionError:
        raise



# Generated at 2022-06-26 03:20:27.234356
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from random import randint
    from string import ascii_letters
    from string import ascii_uppercase
    from copy import copy
    from copy import deepcopy

    # Setup
    rand_numb = randint(0, 100)
    test_list_01 = []
    test_list_02 = []
    test_list_03 = []
    test_list_04 = []
    test_list_05 = []
    test_list_06 = []
    test_list_07 = []
    test_list_08 = []
    test_list_09 = []
    test_list_10 = []
    test_list_11 = []
    test_list_12 = []
    test_list_13 = []
    test_list_14 = []
    test_list_15 = []
    test_list

# Generated at 2022-06-26 03:20:30.966541
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_0 = CookieJar(headers)
    str_0 = 'ey'
    cookie_0[str_0] = str_0
    assert (str_0 in cookie_0) == True
    del cookie_0[str_0]
    assert (str_0 in cookie_0) == False

# Generated at 2022-06-26 03:20:51.690551
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'ey'
    var_0 = cookie_jar_0.__delitem__(str_0)
    var_1 = cookie_jar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:20:56.978057
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    headers = {}
    jar = CookieJar(headers)
    jar['tt_id'] = 'ASDF'
    jar['tt_id']['max-age'] = 100
    jar['tt_id']['comment'] = 'hello'
    jar['tt_id']['secure'] = True
    jar['tt_id']['httponly'] = True
    jar['tt_id']['version'] = 1
    jar['tt_id']['expires'] = datetime.now()
    jar['tt_id']['domain'] = 'www.example.com'
    jar['tt_id']['path'] = '/'
    

# Generated at 2022-06-26 03:20:59.162141
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # cookies = CookieJar(cookies)

    # cookie = MultiDict()
    assert 0


# Generated at 2022-06-26 03:21:09.006416
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'ey'
    cookie_0 = Cookie(str_0, str_0)
    var_0 = cookie_0.encode(str_0)
    str_1 = '=aM; $QT; yz!; gS'
    cookie_1 = Cookie(str_1, str_1)
    var_1 = cookie_1.encode(str_0)
    str_2 = 'z2d'
    cookie_2 = Cookie(str_2, str_2)
    var_2 = cookie_2.encode(str_0)
    str_3 = '6e]M'
    cookie_3 = Cookie(str_3, str_3)
    var_3 = cookie_3.encode(str_0)


# Generated at 2022-06-26 03:21:10.640224
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert (Cookie('key', 'value').__str__() == 'key=value')


# Generated at 2022-06-26 03:21:16.481470
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'x'
    str_1 = str_0
    cookie_0 = Cookie(str_0, str_0)
    # Printing an attribute of the class
    print(cookie_0.value)
    str_2 = str_1
    # Printing an attribute of the class
    print(cookie_0.value)
    cookie_0['max-age'] = str_1
    cookie_0['expires'] = str_2
    cookie_0['secure'] = True
    str_3 = str_2
    cookie_0['max-age'] = str_3
    cookie_0['expires'] = str_3


# Generated at 2022-06-26 03:21:17.720816
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cookiejar = CookieJar(headers)
    value = "S"
    cookiejar['S'] = value
    if headers['Set-Cookie'] == 'S=S':
        pass


# Generated at 2022-06-26 03:21:25.034357
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'test_CookieJar___setitem__'
    str_1 = 'Test Cookie'
    str_2 = 'test_CookieJar___setitem__=Test Cookie'
    cookie_0 = Cookie(str_0, str_1)
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0[str_0] = str_1
    str_3 = cookie_0.get('httponly', True)
    assert str_1 == str_1, 'Assertion failed'
    assert 'HttpOnly' == str_3, 'Assertion failed'
    str_4 = cookie_jar_0[str_0].value
    assert str_1 == str_1, 'Assertion failed'
    str_5 = cookie_0.value