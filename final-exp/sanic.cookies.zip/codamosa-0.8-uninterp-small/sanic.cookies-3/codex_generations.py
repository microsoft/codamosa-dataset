

# Generated at 2022-06-26 03:11:21.109044
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('key_0', 'value_0')
    expected_str_0 = "\"key_0=value_0\""
    assert str(cookie_0) == expected_str_0


# Generated at 2022-06-26 03:11:28.755661
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    key_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    value_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    # Create a CookieJar object
    cookie_jar_0 = CookieJar(key_0)
    # Add a cookie to the CookieJar object
    cookie_jar_0[key_0] = value_0
    # Delete the cookie from the CookieJar object
    cookie_jar_0.__delitem__(key_0)


# Generated at 2022-06-26 03:11:38.268439
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(b'\x1b\x80\x8a\xb3\xec\x92\xac\xfd\xe9\xc1}\x00\xda\xf1\xfc')
    cookie_jar_0['M\x9c\xe8\x8f\x055\x02\xcc\xfe\xf0\x94\xb6\x9b\x8d\x1c\x14'] = -5.5
    cookie_jar_0.__delitem__('M\x9c\xe8\x8f\x055\x02\xcc\xfe\xf0\x94\xb6\x9b\x8d\x1c\x14')



# Generated at 2022-06-26 03:11:51.342445
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(set([str(i) for i in range(1000)]))
    cookie_jar_1 = CookieJar(set([str(i) for i in range(1000)]))
    assert not cookie_jar_0
    assert not cookie_jar_1
    assert len(cookie_jar_0) == 0
    assert len(cookie_jar_1) == 0
    key_0 = "Q\x1cG\xfdl\x1d\x08\xaa\x8f\x8b\xf9\xdd|\x7f\x06\xd1\xc1\x0b\xbe\xb2\xc0\x05\x02\x1b\x03\x18\x1d\x12\x02\xfb\xdb"
    value_0

# Generated at 2022-06-26 03:12:04.378861
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:12:16.836384
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {
        'cache-control': 'no-cache',
        'Postman-Token': 'd55c96fe-89e3-4fa3-a4ae-584fa4bf4b4c',
    }
    cookie_jar = CookieJar(headers)
    # test the response of the API endpoint at the application level
    assert "cache-control" in cookie_jar.headers
    assert cookie_jar.headers["cache-control"] == "no-cache"
    assert "Postman-Token" in cookie_jar.headers
    assert cookie_jar.headers["Postman-Token"] == "d55c96fe-89e3-4fa3-a4ae-584fa4bf4b4c"
    # invoke delitem() to remove the property "cache-control"
    assert "cache-control" in cookie_jar

# Generated at 2022-06-26 03:12:26.391597
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie(
        "jd", "lI\xbd\xe9\xfc\xa0\xbc\xa0\xbc\x82\xde[\x04\x1b\x9a\xba\x1f\xa4"
    )
    cookie_0.__setitem__("expires", "9-6-2028 9:48:35")
    cookie_0.__setitem__("path", "L\x9b\x9b\x1f\x90f\x0e\xf3\x1c\xce\xe5\xad")
    cookie_0.__setitem__("comment", "jR\x8e,\x86\x9c\xdf\x9d{W\xac\xb6\xac")
    cookie_

# Generated at 2022-06-26 03:12:37.449104
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Method: Cookie.__str__()"""
    # Test case 0
    # Testing simple cookie
    key_0 = "key1"
    value_0 = "value1"
    cookie_0 = Cookie(key_0, value_0)
    expected_0 = "key1=value1"
    actual_0 = cookie_0.__str__()
    assert actual_0 == expected_0

    # Test case 1
    # Testing cookie with spaces in its value
    key_1 = "key2"
    value_1 = "value 2"
    cookie_1 = Cookie(key_1, value_1)
    expected_1 = 'key2="value 2"'
    actual_1 = cookie_1.__str__()
    assert actual_1 == expected_1

    # Test case 2
    # Testing cookie with spaces in

# Generated at 2022-06-26 03:12:50.381392
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = ":"
    str_0 = "eyJpc3MiOiJodHRwczovL3B1bGxhYmxlLmNvbSIsImFsZyI6IkhTMjU2IiwiZXhwIjoxNjAyNDQ3NTY3LCJqdGkiOiJmMGJlOTRjZC1hMDJlLTRkMTMtYThiOC1iYWMwODBjMDA3OWQifQ.eyJzdWIiOiJhZG1pbiJ9.b6UQ88VU-b6Oy7fxJFxlxNBun9KjZh4zc7YU6b2U6BM"

# Generated at 2022-06-26 03:12:51.613223
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_case_0()


# Generated at 2022-06-26 03:13:03.020188
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Get an instance of the class.
    cookie_jar_0 = CookieJar(dict())
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    # Delete the attribute of the class.
    del cookie_jar_0["cookie_jar_0"]
    # Check if the attribute is not in the class.
    if "cookie_jar_0" in cookie_jar_0:
        raise ValueError()


# Generated at 2022-06-26 03:13:09.574052
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_0 = Cookie('\n\t', '\t\n')
    cookie_jar_0['\n\t'] = cookie_0


# Generated at 2022-06-26 03:13:18.260212
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = "\x86 \xcd\xcf\x85\x0c\xd7\x0b\x11\xe8X\x01\x95\r\xed\x84\xd2\x1e\xcf\xc6\x9fI\x903\x90\x1f\x8a\xce\x06\xf1"
    value_0 = "y\x88\xdc\x90u\xb4\xf4\x91\x19\xf2\xc3\x9c\xcb\x0f\xef\x8a\x89\xfb\xad\xe4\x9e\x0c*\x05\xac\x88\xf0\xae\x06"

# Generated at 2022-06-26 03:13:23.888202
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:13:32.319973
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_key_0 = 'g+o$2JhF1^H%2rFqsB=6'
    test_value_0 = 'f6d5:6p'
    cookie_0 = Cookie(test_key_0, test_value_0)
    test_key_1 = 'k-Y+>yd\n8?q\x0c'
    test_value_1 = ']|\x88%cT>wY'
    cookie_1 = Cookie(test_key_1, test_value_1)
    assert (cookie_0.__str__() == 'g+o$2JhF1^H%2rFqsB=6=f6d5:6p')

# Generated at 2022-06-26 03:13:37.410793
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_string_0 = "%s"
    key_string_1 = "%s"
    key_string_2 = "test_value"
    cookie_0 = Cookie(key_string_1, key_string_2)
    str_0 = cookie_0.__str__()
    print(str_0)

# Generated at 2022-06-26 03:13:45.897083
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    # Test exception
    try:
        cookie_jar_0.__delitem__(0.0)
    except KeyError:
        pass
    except:
        exception_instance_0 = sys.exc_info()[1]
        raise exception_instance_0
    # Test exception
    try:
        cookie_jar_0.__delitem__(0.0)
    except KeyError:
        pass
    except:
        exception_instance_1 = sys.exc_info()[1]
        raise exception_instance_1
    # Test exception

# Generated at 2022-06-26 03:13:53.143689
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_0 = Cookie(bytes_0, bytes_0)
    bytes_1 = b'^\xb2\x0b\x0b\xfe\xf7\xf6\xca\x99\x8c\x9b'
    cookie_0[bytes_1] = bytes_0


# Generated at 2022-06-26 03:14:03.668263
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Setup
    headers_0 = MultiHeader('Headers')
    headers_0.add(
        'Set-Cookie',
        'JSESSIONID=HttpHaCkgSv; Path=/; HttpOnly; SameSite=Lax; Secure',
    )
    headers_0.add('Other-Header', 'other header')
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0['JSESSIONID'] = 'c83e2d7b-6860-4a7d-abd9-933a49e1e540'
    cookie_jar_0['Favorite-Beverage'] = 'Latte Macchiato'
    headers_1 = MultiHeader('Headers')

# Generated at 2022-06-26 03:14:08.426253
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    key_0 = '\xbd\x84\xa1\x11\x9f^\xdb\xe2\xa8\xb0\xf0\xfb\xc1?\x8c'
    value_0 = '\xda\xd0\xaa\xb4\xcc\xe4\x06W8\x1e\x9c\x0b}'
    # initializing the object
    cookie_jar_0 = CookieJar(key_0)
    # storing the value
    cookie_jar_0[key_0] = value_0
    # deleting the key and value
    del cookie_jar_0[key_0]



# Generated at 2022-06-26 03:14:28.633079
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    r"""Keyword arguments:
    self
    """
    # Case 0
    # TODO: not sure what to do for this case
    # cookie_0 = Cookie()
    # expected_cookie_0_str = ""
    # assert cookie_0.__str__() == expected_cookie_0_str

    # Case 1
    key_1 = ""
    cookie_1 = Cookie(key_1, "")
    expected_cookie_1_str = ""
    assert cookie_1.__str__() == expected_cookie_1_str

    # Case 2
    key_2 = "test_key"
    cookie_2 = Cookie(key_2, "")
    expected_cookie_2_str = "test_key="
    assert cookie_2.__str__() == expected_cookie_2_str

    # Case 3


# Generated at 2022-06-26 03:14:33.993238
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = "foobarbaz"
    cookie_jar_0[str_0] = 42
    assert True

test_case_0()
test_CookieJar___setitem__()

# Generated at 2022-06-26 03:14:36.760007
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_0 = Cookie(bytes_0, "megabyte")
    assert cookie_0.__str__() == b'\xf4\xe6C\xcd\x96R\x98.=megabyte'


# Generated at 2022-06-26 03:14:48.508060
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(b'd\xca\x1c\x8e\xbd\x0b\xdf\x18\x80\xa7=')
    cookie_0 = cookie_jar_0[cookie_jar_0]
    assert sys.getsizeof(cookie_0) == 88
    cookie_0["comment"] = "f\x1c\x19\x951\xcb\x0e\x9d\xc5\x95"
    cookie_0["expires"] = datetime(2020, 4, 20, 19, 10, 23)
    cookie_0["secure"] = True
    cookie_0["secure"] = True
    cookie_0["secure"] = True
    cookie_0["secure"] = True
    cookie_0["secure"] = True
    cookie_0["secure"]

# Generated at 2022-06-26 03:14:58.405914
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\x9c\x0cF\x84\x1c\x12\x05N\xbb'
    key_0 = '\xb9\x04\xfc\xfe\xa3{\x86\x1d@\xcf\xc8\xd9\x9b\xfe\xbb\xa8\xe2\x08\xcaa\xeed'
    value_0 = '2\xbb\xc4h\xb0\x91\xa4\x93\xee\x839\xb9\x0cF\x84\x1c\xad|e'
    cookie_jar_0 = CookieJar(bytes_0)
    try:
        cookie_jar_0[key_0] = value_0
    except:
        pass
   

# Generated at 2022-06-26 03:15:06.105581
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = {'cookie': 'Cookie'}
    cookie_jar_0 = CookieJar(headers_0)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__("r")
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__("S?}!J")
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__("zB&3_")


# Generated at 2022-06-26 03:15:18.357021
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers_0 = {
        'Connection': 'keep-alive',
        'Content-Type': 'multipart/form-data',
        'Content-Length': '36',
        'Accept': '*/*',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.100 Safari/537.36'
    }
    key_0 = "z\x7f\xde\x08\x82\xee\x00\x89\xef)\xf0\x9b\x9f\x98\x0f\x8e\xfd\xe3\x05"

# Generated at 2022-06-26 03:15:23.675122
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert (
        CookieJar.__delitem__(0)
        == None
    ), 'The function `__delitem__` did not handle the `0` argument.'

    assert (
        CookieJar.__delitem__([0])
        == None
    ), 'The function `__delitem__` did not handle the `[0]` argument.'


# Generated at 2022-06-26 03:15:29.334625
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b'\x85\x96\x80\x0e\x8c\x1d\x1e\xc1'
    cookie_jar_0[bytes_1] = 5
    cookie_jar_0[bytes_1] = 5
    if __name__ == '__main__':
        del cookie_jar_0[bytes_1]


# Generated at 2022-06-26 03:15:33.275608
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    s = 'test'
    try:
        cookie_jar_0.__delitem__(s)
    except:
        pass


# Generated at 2022-06-26 03:15:47.542940
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = {"Content-Type": "text/json; charset=utf-8"}
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0["key"] = "val"
    del cookie_jar_0["key"]



# Generated at 2022-06-26 03:15:58.276535
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Test KeyError if cookie key is a reserved word
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    try:
        cookie_jar_0['expires'] = 'sikha'
    except KeyError:
        pass
    except:
        r = False
        if True:
            pass
        else:
            assert False
    else:
        r = True
        if True:
            assert False
        else:
            pass
    assert not r

    # Test KeyError if cookie key contains illegal characters
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)

# Generated at 2022-06-26 03:16:04.442599
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = "\u0014\u00ea\u0014\u00dc>\u0003\u00c3\u00f6\u00c7\nR\u00a7\u00e9c\u00d0\u00d7"
    value_0 = b'\xea\xdf\x18\x9f\xab\xbf\xbf\xc4\x1c\x90\xae\x11\xad\x9e\xee\xde\xea\x1f\x16\x00\xbf[3\xec\xf9\x9b\xab\x9d'
    cookie_0 = Cookie(key_0, value_0)
    str_0 = str(cookie_0)


# Generated at 2022-06-26 03:16:08.096397
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_str_0 = Cookie('qasymqcqwt', 'xjxcrjfvww')


if __name__ == "__main__":
    test_case_0()
    test_Cookie___str__()

# Generated at 2022-06-26 03:16:18.148368
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\x9d\x0c7\x98\x1cN\x1b\xbf'
    bytes_1 = b'\xdf\x18\x1a\xce\xff\x84\x8d\x86\x97\xa3\x9b'
    cookie_jar_0 = CookieJar(bytes_0)
    str_1 = 'AqkZMo\u9a9c\u81de'
    str_2 = '\u1a8d\u20a2\u7b5c\u827d\u6b85\u5190\u5f46\u6098\u4eee'
    cookie_jar_0[str_1] = str_2

# Generated at 2022-06-26 03:16:20.153152
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    try:
        cookie_0 = Cookie(__str__, bytes_0)
    except Exception:
        pass


# Generated at 2022-06-26 03:16:22.490325
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Setup a mock Cookie, with a key and value

    cookie_0 = Cookie('key', 'value')

    # Assertions
    assert str(cookie_0) == 'key=value'


# Generated at 2022-06-26 03:16:26.580123
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_0 = Cookie('R', bytes_0)
    assert cookie_0.__str__() == "R=%uFFF4%uFFE6C%uFFCD%uFF96R%uFF98."


# Generated at 2022-06-26 03:16:38.491951
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = '\xf4\xe6C\xcd\x96R\x98.'
    str_1 = '\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0[str_0] = str_1
    cookie_jar_0[str_0] = str_1
    str_2 = '\xf4\xe6C\xcd\x96R\x98.'
    str_3 = '\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0[str_2] = str_3

# Generated at 2022-06-26 03:16:45.538314
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    bytes_0 = b'\x8d>\xfe\x87\xf7\xb2\xd0\x01\x87\xdd\xbf\x1f\xa5\x89\xb4\x0c\xae\xc6\x11\x9b\xdc\x81\xde\xb6\xce\xe4\x8a\xdb\xaa\x9c\x03\x93\x1fZ\xb5"\x14\xc8C\xb7\x1b\xa9\xae\x86\x00\x88\x12'
    cookie_jar_0 = CookieJar(bytes_0)

    assert True



# Generated at 2022-06-26 03:17:01.089544
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print('testing method __delitem__ of class CookieJar')
    print('test 1')
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    del cookie_jar_0['\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00']
    print('test 2')
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    del cookie_jar_0['']
    print('test 3')


# Generated at 2022-06-26 03:17:05.718014
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case with output
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    try:
        cookie_jar_0.__delitem__("u]\x14\xb1\x01\xd0\x06\xe4\x84\xdd\x03-")
    except KeyError:
        pass

# Generated at 2022-06-26 03:17:14.497362
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\x97\xed\x89\x9a\xe1\xbc\x18\xf5\xda\xc5\x80\xd5;\x89\x1f\x9e\x8a\x1a\xc5\x92\x8a\xae\x9f\x9b\x04\x00\xfc\xce\xc0\x91\x94\xc5\x9d\x9a\x0f\xfd\xcaV\xc5'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.__delitem__(bytes_0)


# Generated at 2022-06-26 03:17:17.870466
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Test Case 0
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(headers=bytes_0)
    abc_0 = 'abc'
    def_0 = 'def'
    cookie_jar_0[abc_0] = def_0



# Generated at 2022-06-26 03:17:26.997465
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    for test_case in range(0, 1):
        print(f"Test case #{test_case}")
        bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
        cookie_jar_0 = CookieJar(bytes_0)

        # Assert False because a KeyError is expected (key not in self.cookie_headers)
        if not False:
            print(f"  cookie_jar_0.__delitem__(key): {cookie_jar_0.__delitem__(key)}")
        else:
            with pytest.raises(KeyError):
                cookie_jar_0.__delitem__(key)


# Generated at 2022-06-26 03:17:31.326989
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(None)
    assert_equals(cookie_jar_0.__delitem__("expires"), None)
    assert_equals(cookie_jar_0.__delitem__("expires"), None)


# Generated at 2022-06-26 03:17:36.081635
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = HttpHeaders()
    cookie_jar_0 = CookieJar(headers_0)
    try:
        # Test method __delitem__ of class CookieJar
        cookie_jar_0.__delitem__("test")
    except KeyError:
        pass


# Generated at 2022-06-26 03:17:39.492924
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.__delitem__(bytes_0)


# Generated at 2022-06-26 03:17:42.286040
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = MultiHeader()
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0["test"] = ""
    try:
        del cookie_jar_0["test"]
    except KeyError:
        pass


# Generated at 2022-06-26 03:17:53.680096
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b''
    cookie_0 = Cookie(bytes_0, 1)
    bytes_1 = b'\xca\xafQ\xee\xa5\x1b\x17\xd2\xed'
    cookie_0["max-age"] = bytes_1
    bytes_2 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_0["httponly"] = bytes_2
    bytes_3 = b'\xc0\xab\x9a\x84\xfe\x19\x8d=\x87\xb1\xcb\t\x8e\x87R'
    cookie_0["secure"] = bytes_3

# Generated at 2022-06-26 03:18:08.032654
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'test'
    object_0 = Cookie(str_0, str_0)
    object_0.__setitem__('max-age', 0)
    object_0.__setitem__('expires', datetime.now())
    object_0.__setitem__('secure', True)
    str_0 = object_0.__str__()
    assert str_0 is not None


# Generated at 2022-06-26 03:18:09.900324
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # create a new instance of Cookie
    cookie_0 = Cookie('', 'test')
    # call __str__ on it
    str_0 = str(cookie_0)
    # assert that the string returned is correct
    assert str_0 == '="test"'


# Generated at 2022-06-26 03:18:15.881019
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    _str__function = Cookie.__str__

    str_0 = 'test'
    output_str_0 = _str__function(str_0)
    assert str_0 == output_str_0

    str_1 = 'test2'
    output_str_1 = _str__function(str_1)
    assert str_1 == output_str_1

    str_2 = 'test3'
    output_str_2 = _str__function(str_2)
    assert str_2 == output_str_2



# Generated at 2022-06-26 03:18:23.657153
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = {}
    headers = {}
    c = CookieJar(cookies)
    c[str_0] = 'test'
    assert c[str_0] == 'test'
    del c[str_0]
    assert str_0 not in c
    print('Success: test_CookieJar___delitem__')


# Generated at 2022-06-26 03:18:28.789652
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    new_tuple_0 = CookieJar({})
    str_0 = 'test'
    str_1 = 'test'
    # new_tuple_0.__setitem__(str_0, str_1)
    # AssertionError: Cookie name is a reserved word


# Generated at 2022-06-26 03:18:33.819809
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar['key_1'] = 'value_1'
    cookie_jar['key_2'] = 'value_2'
    cookie_jar['key_3'] = 'value_3'
    cookie_jar.__delitem__('key_2')
    assert len(cookie_jar) == 2


# Generated at 2022-06-26 03:18:40.921152
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({})
    cookie_jar_0['test'] = 'test'
    cookie_jar_0['test2'] = 'test2'
    cookie_jar_0['test3'] = 'test3'
    cookie_jar_0['test4'] = 'test4'
    del cookie_jar_0['test4']
    assert len(cookie_jar_0) == 3


# Generated at 2022-06-26 03:18:41.503658
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass

# Generated at 2022-06-26 03:18:45.434300
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case 0
    headers_0 = MultiHeader()
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0.__delitem__('test')
    assert str(headers_0) == "Set-Cookie: test=; Path=/; Max-Age=0"


# Generated at 2022-06-26 03:18:48.446637
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar()
    cookie_jar['test'] = 'value'
    del cookie_jar['test']
    cookie = cookie_jar.get('test')
    assert cookie is None, 'Cookie missing after deletion.'


# Generated at 2022-06-26 03:19:04.123469
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar_0 = CookieJar(headers)
    cookie_jar_0["testkey"] = "testvalue"

    # Test that headers are populated
    assert headers[cookie_jar_0.header_key].value == "testkey=testvalue"

    # Test that cookie_headers are populated
    assert cookie_jar_0.cookie_headers["testkey"] == cookie_jar_0.header_key

    # Test that the dict is populated
    assert cookie_jar_0["testkey"].value == "testvalue"

    # Test that the cookie is deleted
    del cookie_jar_0["testkey"]
    assert "testkey" not in cookie_jar_0
    assert "testkey" not in cookie_jar_0.cookie_headers
    assert cookie_jar_0.header_key not in headers



# Generated at 2022-06-26 03:19:11.457468
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\x13\xde\x7f\xb4R\x11\x1a\x1f\xa8\xa2\xfd\xf4\xbb\xdd\x80'
    key_0 = b'+\x1d\x94\x14\x93\x07\x18\x1f\x07\x94\x0f\x8f\x1d'
    cookie_jar_0 = CookieJar(bytes_0)
    del cookie_jar_0[key_0]


# Generated at 2022-06-26 03:19:22.324554
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)

# Generated at 2022-06-26 03:19:25.391247
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(b'\xc6\x89\xb3')


# Generated at 2022-06-26 03:19:33.089070
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xd3\x1b\x8fL'
    bytes_1 = b'\x8c\xfd\xd0\xbf\x0c\xf1\xfa\x11\x0e\x9c]\x98'
    cookie_0 = Cookie(bytes_0, bytes_1)
    assert_equal(cookie_0.__str__(), '\xd3\x1b\x8fL=\x8c\xfd\xd0\xbf\x0c\xf1\xfa\x11')


# Generated at 2022-06-26 03:19:38.859411
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'\xf4\xe6C\xcd\x96R\x98.'
    cookie_jar_0 = CookieJar(bytes_0)
    try:
        cookie_jar_0[bytes_0] = bytes_0
    except KeyError:
        pass
    else:
        raise Exception("Unexpected exception")
    cookie_jar_0[bytes_0] = bytes_0


# Generated at 2022-06-26 03:19:48.284580
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(key="test_key", value="test_value")
    cookie["domain"] = "test_domain"
    cookie["path"] = "test_path"
    cookie["expires"] = "test_expires"
    cookie["max-age"] = "test_max-age"
    cookie["version"] = "test_version"
    cookie["secure"] = "test_secure"
    cookie["httponly"] = "test_httponly"
    cookie["comment"] = "test_comment"
    cookie["samesite"] = "test_samesite"

    result = cookie.__str__()

# Generated at 2022-06-26 03:19:58.197095
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Check the case where a cookie exists in the headers
    headers_0 = {'Set-Cookie': 'cookie0=value0'}
    cookie_jar_0 = CookieJar(headers_0)
    cookies_0 = {'Set-Cookie': 'cookie0=new_value0'}
    cookie_jar_0['cookie0'] = 'new_value0'
    assert id(cookie_jar_0.headers) == id(headers_0)
    assert headers_0 == cookies_0
    # Check the case where a cookie does not exist in the headers
    headers_1 = {}
    cookie_jar_1 = CookieJar(headers_1)
    cookies_1 = {'Set-Cookie': 'cookie0=new_value0'}
    cookie_jar_1['cookie0'] = 'new_value0'
   

# Generated at 2022-06-26 03:20:04.620641
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = None
    value_0 = None
    cookie_0 = Cookie(key_0, value_0)
    key_0 = "4"
    value_0 = "H3q\u0019\u0017"
    cookie_1 = Cookie(key_0, value_0)
    assert not (cookie_1.__str__() != "4=H3q\u0019\u0017")
    assert not (cookie_0.__str__() != "None=None")


# Generated at 2022-06-26 03:20:12.801577
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    CookieJar dynamically writes headers as cookies are added and removed
    It gets around the limitation of one header per name by using the
    MultiHeader class to provide a unique key that encodes to Set-Cookie.
    """

    headers_0 = {None: None}
    cookiejar_0 = CookieJar(headers_0)
    try:
        cookiejar_0[None] = None
    except KeyError:
        pass
    # AssertionError raised when we try to delete cookie
    # that does not exist
    except AssertionError:
        pass

    # AssertionError raised when cookie that does exist
    # and has been added to headers is not removed
    assert ('NonExistentCookie' and True) == False


# Generated at 2022-06-26 03:20:27.725139
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(TestPy.TestClass())
    cookie_jar_0.headers = pytest.helpers.create_dict()

    # key is not in cookie_jar_0.
    cookie_jar_0['foo'] = 'bar'
    del cookie_jar_0['foo']



# Generated at 2022-06-26 03:20:34.805731
# Unit test for method __setitem__ of class CookieJar

# Generated at 2022-06-26 03:20:43.049648
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "str"
    value = "str"
    cookie = Cookie(key, value)
    cookie["path"] = "/"
    expected_value = "str=str; Path=/"
    # assert cookie.__str__() == expected_value
    try:
        assert cookie.__str__() == expected_value
    except AssertionError as e:
        print(
            "AssertionError: {0} != {1} on line number {2}".format(
                cookie.__str__(), expected_value, sys.exc_info()[2].tb_lineno
            )
        )


# Generated at 2022-06-26 03:20:53.565136
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\x0c\xde\x01\xec\xa5\x83\x90\xf0\x9dGNI\xab\x1b\xc4\xcdA\xfd\x08\xf3\xee\xc9'
    bytes_1 = b'\x01\xd8\xef\xa1\x91\x0c\xe4\x9b\x9a\x92\x0f\x83\xcaM\xb1\x14\x0f\xc0\xeb\xf6'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_1 = CookieJar(bytes_1)
    cookie_jar_0['cookie_jar_0'] = cookie_jar_1['cookie_jar_1']
   

# Generated at 2022-06-26 03:20:55.804172
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(str())
    str_0 = str()
    # Argument 0 has type str
    cookie_jar_0.__delitem__(str_0)



# Generated at 2022-06-26 03:21:04.957779
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b"\xf5\x9e\x93;Tx\x0b\x016\xc3\x87\xf6"
    cookie_jar_0 = CookieJar(bytes_0)

# Generated at 2022-06-26 03:21:14.484279
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Simple test case
    bytes_0 = bytearray()
    bytes_0.extend ((0x6, 0x6, 0xa, 0x9, 0x4, 0x4, 0x4, 0x4, 0xa, ))
    cookie_jar_0 = CookieJar(bytes_0)
    # Testing with a custom dictionary, using an arbitrary key
    custom_dict = {'test_key': 'test_value'}
    cookie_jar_1 = CookieJar(custom_dict)
    cookie_jar_1.__delitem__('test_key')
    assert 'test_key' not in cookie_jar_1
    assert custom_dict == {'test_key': 'test_value'}  # No change to original
    cookie_jar_1.__delitem__('test_key')
    assert len