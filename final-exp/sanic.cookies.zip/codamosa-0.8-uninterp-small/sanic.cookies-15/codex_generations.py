

# Generated at 2022-06-26 03:11:35.868277
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_1 = 'S'
    cookie_2 = Cookie(str_1, str_1)
    str_3 = 'Icr'
    cookie_2[str_3] = str_3
    str_4 = '; '
    str_6 = '%s=%s'
    str_7 = '=%s'
    str_5 = '=%d'
    str_8 = '%d'
    str_9 = '=%s'
    print(cookie_2.__str__( ))
    str_10 = '='
    int_1 = 0
    str_11 = 'expires'
    str_12 = 'max-age'
    str_13 = 'Icr'
    str_14 = '; '
    str_16 = '%s=%s'
    str_17

# Generated at 2022-06-26 03:11:44.258833
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'f$'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    cookie_jar_0 = CookieJar(dict_0)
    str_1 = 'x<'
    cookie_jar_0.__delitem__(str_1)
    assert(dict_0 == {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0})


# Generated at 2022-06-26 03:11:50.400946
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'd-^'
    dict_0 = {str_0: str_0, str_0: str_0}
    dict_1 = dict()
    cookie_jar_0 = CookieJar(dict_1)
    cookie_jar_0.cookie_headers = dict_0
    cookie_jar_0.header_key = str_0
    cookie_jar_0[str_0] = str_0
    # AssertionError is expected
    try:
        cookie_jar_0.__delitem__(str_0)
    except AssertionError:
        pass
    else:
        assert False
    cookie_jar_0[str_0] = str_0
    cookie_jar_0.__delitem__(str_0)



# Generated at 2022-06-26 03:11:56.771406
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = '89Em'
    cookie_jar_0 = CookieJar({str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0})
    str_1 = '89Em'
    cookie_jar_0.__delitem__(str_1)


# Generated at 2022-06-26 03:12:01.798230
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    dict_0 = {}
    class_0 = CookieJar(dict_0)
    # Test for KeyError, not in cookie_headers
    with raises(KeyError, message='Error in test #1'):
        class_0.__delitem__('D$o3@')
    dict_0 = {'D$o3@': {}}
    dict_1 = {'D$o3@': {}}
    class_0.cookie_headers = dict_1
    # Test for KeyError, not found in header
    from falcon.request import _MultiDictProxy
    with raises(KeyError, message='Error in test #2'):
        class_0.__delitem__('D$o3@')
    dict_0 = {'D$o3@': {}}

# Generated at 2022-06-26 03:12:04.037587
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'bz8hA)D0p0j(IcbMVKc%'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    cookie_0 = Cookie(str_0, str_0)
    for i in range(0, 100, 3):
        cookie_0.__setitem__(str_0, str_0)


# Generated at 2022-06-26 03:12:12.720296
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cook_0 = Cookie('\\`U6H', '\\`U6H')
    cook_0['secure'] = False
    cook_0['secure'] = False
    cook_0['secure'] = False
    cook_0['secure'] = False
    print(cook_0)
    print(cook_0['secure'])

    try:
        cook_0['secure'] = False
    except KeyError:
        print("got it!")
#0


# Generated at 2022-06-26 03:12:17.326425
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test for dictionary methods
    str_0 = '6GHg'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    cookie_jar_0 = CookieJar(dict_0)
    str_1 = 'zPt'
    cookie_jar_0[str_1] = str_1
    # Test for dictionary methods
    str_2 = 'a'
    cookie_jar_0[str_2] = str_2
    cookie_jar_0[str_2] = str_2
    cookie_jar_0[str_1] = str_1
    cookie_jar_0[str_2] = str_2
    cookie_jar_0[str_2] = str_2
    cookie_jar

# Generated at 2022-06-26 03:12:26.545415
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    Test __setitem__
    Test that adding a cookie via the dict interface adds it to the headers dict.
    Test that attempting to add a reserved keyword will raises a KeyError
    Test that attempting to add an illegal key will raises a KeyError
    """

    # Case #0
    headers = {
        "Content-Type": "application/json",
        "Connection": "keep-alive",
        "Server": "pytest",
    }
    cookies = CookieJar(headers)
    # Test that adding a cookie via the dict interface adds it to the headers dict.
    cookies["x-cookie-id"] = "super_long_random_string"
    assert len(cookies.keys()) == 1
    assert "super_long_random_string" in cookies.values()
    assert "Set-Cookie" in cookies.headers.keys()

# Generated at 2022-06-26 03:12:37.447748
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = '89Em'
    dict_0 = {str_0: str_0, str_0: str_0, str_0: str_0, str_0: str_0}
    cookie_jar_0 = CookieJar(dict_0)
    cookie_0 = cookie_jar_0['89Em'];
    # Test exception throwing
    try:
        cookie_0['89Em'] = str_0
    except KeyError as e:
        assert(e.args[0] == 'Unknown cookie property')
    # Test exceptions throwing
    try:
        cookie_0['max-age'] = str_0
    except ValueError as e:
        assert(e.args[0] == 'Cookie max-age must be an integer')
    # Test exceptions throwing

# Generated at 2022-06-26 03:12:46.775799
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('S', 'S')
    assert (cookie.__str__() == 'S=S')
    cookie_0 = Cookie('S', 'S')
    assert (cookie_0.__str__() == 'S=S')


# Generated at 2022-06-26 03:12:49.238853
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # __delitem__(self, key: Any) -> None
    assert False  # Not implemented
    pass  # Placeholder
    # pass # type-checking stub


# Generated at 2022-06-26 03:12:58.753311
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    assert cookie_0.__str__() is not None

    cookie_0.__setitem__('expires', datetime.now())
    cookie_0.__str__()

    cookie_0.__setitem__('expires', 1)
    cookie_0.__str__()

    cookie_0.__setitem__('max-age', 1)
    cookie_0.__str__()

    cookie_0.__setitem__('secure', True)
    cookie_0.__str__()

    cookie_0.__setitem__('secure', False)
    cookie_0.__str__()

    cookie_0.__setitem__('httponly', True)
    cookie_0.__str__()

    cookie

# Generated at 2022-06-26 03:13:04.812398
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'j'
    str_1 = 'y'
    dict_0 = {}
    dict_1 = dict_0
    cookie_0 = Cookie(str_0, str_1)
    dict_1.__setitem__(str_0, cookie_0)
    cookie_jar_0 = CookieJar(dict_1)
    _ = cookie_jar_0.__delitem__(str_0)
    assert cookie_jar_0 == dict_1
    print("First test is passed")


# Generated at 2022-06-26 03:13:10.301394
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    for i in range(0, 100):
        str_0 = 'S'
        cookie_0 = Cookie(str_0, str_0)
        cookie_0.__setitem__(str_0, str_0)

# Generated at 2022-06-26 03:13:18.891803
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'd'
    str_1 = '$ku#'
    str_2 = '!'
    str_3 = 'T'
    str_4 = 'a'
    headers = {str_0:str_1,str_2:str_3}
    cookie_0 = Cookie(str_4,str_0)
    cookie_1 = Cookie(str_0,str_1)
    cookie_2 = Cookie(str_2,str_2)
    cookie_3 = Cookie(str_3,str_3)
    cookie_4 = Cookie(str_4,str_4)
    cookie_5 = Cookie(str_4,str_4)
    cookie_5['max-age'] = 0
    cookie_5['HttpOnly'] = 'HttpOnly'
    cookie_5['comment'] = str_

# Generated at 2022-06-26 03:13:27.638200
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'PYXr5k'
    str_1 = ''
    str_2 = 'SC:\\.j'
    str_3 = 'X0"VaR'
    dict_0 = {}
    cookie_0 = Cookie(str_2, str_3)
    dict_0[str_3] = cookie_0
    cookiejar_0 = CookieJar(dict_0)
    cookie_1 = Cookie(str_1, str_0)
    cookiejar_0[str_1] = cookie_1
    del cookiejar_0[str_1]



# Generated at 2022-06-26 03:13:35.208525
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar_0 = CookieJar(headers)
    str_0 = 'S'
    cookiejar_1 = CookieJar(headers)
    str_1 = 'S'
    cookiejar_1[str_0] = str_1
    str_2 = 'S'
    del cookiejar_1[str_2]


# Generated at 2022-06-26 03:13:41.129724
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_0 = Cookie('S', 'w')
    headers_0 = {'S': 'S'}
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0['S'] = cookie_0
    cookie_0['max-age'] = 0
    try:
        del cookie_jar_0['S']
    except KeyError:
        pass


# Generated at 2022-06-26 03:13:52.863636
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    str_0 = 'F'
    str_1 = 'r'
    str_2 = 'y'
    str_3 = ' '
    str_4 = 'T'
    str_5 = 'h'
    str_6 = 'e'
    str_7 = ' '
    str_8 = 'C'
    str_9 = 'o'
    str_10 = 'o'
    str_11 = 'k'
    str_12 = 'i'
    str_13 = 'e'
    str_14 = ' '
    str_15 = 'M'
    str_16 = 'o'
    str_17 = 'n'
    str_18 = 's'
    str_19 = 't'
    str_20 = 'e'
    str_21 = 'r'

    # Call method

# Generated at 2022-06-26 03:14:06.315853
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {'Set-Cookie': "CookieJar=CookieJar; Domain=CookieJar; Path=/CookieJar"}
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'CookieJar'
    cookie_jar_0[str_0] = str_0
    str_1 = 'CookieJar'
    assert cookie_jar_0[str_1] == str_0

    del cookie_jar_0[str_1]
    assert cookie_jar_0[str_1] == None


# Generated at 2022-06-26 03:14:15.863807
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    cookie_0['secure'] = True
    cookie_0['domain'] = 'www.example.com'
    str_1 = 'S'
    cookie_1 = Cookie(str_1, str_1)
    cookie_1['secure'] = True
    cookie_1['domain'] = 'www.example.com'
    cookiejar_0 = CookieJar({'Content-Type': 'text/html; charset="utf-8"'})
    cookiejar_0['S'] = str_0
    cookiejar_0['S'] = str_1
    cookiejar_0['S'] = str_0
    cookie_2 = cookiejar_0.get('S')
    del cookiejar_0['S']

# Generated at 2022-06-26 03:14:20.740766
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'D'
    cookie_jar_0['D'] = str_0
    del cookie_jar_0['D']


# Generated at 2022-06-26 03:14:25.556576
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = ''
    cookie_1 = Cookie(str_1, str_1)
    str_2 = '*$=+'
    cookie_2 = Cookie(str_2, str_2)


# Generated at 2022-06-26 03:14:28.974593
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_4 = 'S'
    cookie_4 = Cookie(str_4, str_4)

    # assertRaises(TypeError, cookie_4.__str__, )



# Generated at 2022-06-26 03:14:37.044760
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_0 = CookieJar(headers)
    str_0 = 'S'
    str_1 = '[hR'
    cookie_0[str_0] = str_1
    str_2 = 'y]m'
    cookie_0[str_0] = str_2
    str_3 = '>I'
    cookie_0[str_0] = str_3
    assert headers == {"Set-Cookie": ["S=y%5Dm", "S=%3EI"]}
    del cookie_0[str_0]
    assert headers == {"Set-Cookie": ["S=y%5Dm"]}



# Generated at 2022-06-26 03:14:38.369945
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert True


# Generated at 2022-06-26 03:14:47.284337
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # cookie_0 = Cookie(str_0, str_0)

    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)

    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)

    # print(cookie_0)

    # print(cookie_0.key)

    # print(cookie_0.value)

    # print(cookie_0.items())

    print(cookie_0.encode('utf-8'))

    # print(cookie_0.__str__())



# Generated at 2022-06-26 03:14:50.463799
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('k', 'v')
    str_0 = cookie_0.__str__()
    if str_0 == "k=v":
        assert True
    else:
        assert False

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 03:14:58.111223
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Dict[str, str]()
    headers.clear()
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    cookie_jar_0.__setitem__(str_0, cookie_0)
    bool_0 = bool()
    bool_1 = bool()
    bool_3 = bool()
    bool_2 = bool()
    bool_2 = bool_1 and bool_2
    bool_1 = bool_0 or bool_2
    assert bool_1 == bool_3


# Generated at 2022-06-26 03:15:08.757148
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'KkHS'
    cookie_0 = Cookie(str_0, str_0)
    test_case_0()
    cstr_0 = cookie_0.__str__()
    return cstr_0

# Generated at 2022-06-26 03:15:12.908929
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    # delete cookie
    cookie = None
    cookiejar[cookie] = cookie
    cookiejar.__delitem__(cookie)
    assert ('{}'.format('') == headers.get('Set-Cookie', ''))



# Generated at 2022-06-26 03:15:16.967758
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(Headers())

    try:
        cookie_jar_0.__delitem__(str_0)
    except:
        pass



# Generated at 2022-06-26 03:15:27.280827
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('S', 'S')

    assert cookie.__str__() == 'S=S'

    cookie = Cookie('S', 'S')
    cookie['secure'] = True

    assert cookie.__str__() == 'S=S; Secure'

    cookie = Cookie('S', 'S')
    cookie['httponly'] = True

    assert cookie.__str__() == 'S=S; HttpOnly'

    cookie = Cookie('S', 'S')
    cookie['secure'] = True
    cookie['httponly'] = True

    assert cookie.__str__() == 'S=S; Secure; HttpOnly'

    cookie = Cookie('S', 'S')
    cookie['httponly'] = True
    cookie['secure'] = True

    assert cookie.__str__() == 'S=S; Secure; HttpOnly'



# Generated at 2022-06-26 03:15:38.453474
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:15:50.097403
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # create a CookieJar instance
    header = CaseInsensitiveMapping()
    cookie_jar = CookieJar(header)
    # create a Cookie instance
    key = 'S'
    value = 'S'
    cookie = Cookie(key, value)
    cookie['path'] = '/'
    # put this cookie in the CookieJar
    cookie_jar[key] = cookie
    cookie_jar.cookie_headers[key] = 'Set-Cookie'
    header.add('Set-Cookie', cookie)
    cookie_jar.header_key = 'Set-Cookie'
    # test
    cookie_jar.__delitem__(key)
    assert isinstance(cookie_jar, dict)
    assert isinstance(cookie_jar, collections.abc.MutableMapping)
    assert cookie_jar == {}

# Generated at 2022-06-26 03:15:54.891865
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = BasicHTTPHeaders()
    cookie_jar_0 = CookieJar(headers_0)
    str_0 = '/'
    cookie_jar_0[str_0] = str_0
    str_1 = 'S'
    del cookie_jar_0[str_1]



# Generated at 2022-06-26 03:15:56.409787
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('S', (3 * str_0))
    str_temp = str(cookie_0)


# Generated at 2022-06-26 03:15:59.398721
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print('Testing ___delitem__')
    headers = Headers()
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'k'
    str_1 = 'k'
    cookie_jar_0[str_1] = str_1
    assert str_0 in cookie_jar_0
    del cookie_jar_0[str_1]
    print('Passed')


# Generated at 2022-06-26 03:16:08.569617
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = MultiHeader("name")
    cookieJar_0 = CookieJar(headers_0)
    # missing cookie
    try:
        cookieJar_0.__delitem__("expires")
    except KeyError:
        pass
    except:
        raise
    else:
        raise Exception("Expected an exception")
    # cookie cookie
    cookie_0 = Cookie("expires", "expires")
    cookieJar_0.__setitem__("expires", cookie_0)
    # default value
    expected_return_value_0 = None
    actual_return_value_0 = cookieJar_0.__delitem__("expires")
    assert actual_return_value_0 == expected_return_value_0


# Generated at 2022-06-26 03:16:27.698491
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass



# Generated at 2022-06-26 03:16:31.979922
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar()
    str_0 = 'j'
    str_1 = '8I'
    cookies[str_0] = str_0

    cookies[str_1] = str_1

    str_2 = 'j'
    del cookies[str_2]
    return cookies


# Generated at 2022-06-26 03:16:42.824374
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'S'
    str_1 = 'R'
    cookie_0 = Cookie(str_1, str_1)
    str_2 = 'S'
    str_3 = 'S'
    cookie_1 = Cookie(str_2, str_3)
    str_4 = 'S'
    str_5 = 'S'
    cookie_2 = Cookie(str_4, str_5)
    str_6 = 'S'
    str_7 = 'S'
    cookie_3 = Cookie(str_6, str_7)
    str_8 = "5$=Y^WT,#RzcI1'@"
    str_9 = 'S'
    cookie_4 = Cookie(str_8, str_9)
    str_10 = 'S'

# Generated at 2022-06-26 03:16:48.513190
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader([])
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'S'
    cookie_jar_0[str_0] = str_0
    assert cookie_jar_0[str_0].value == str_0
    del cookie_jar_0[str_0]
    assert str_0 not in cookie_jar_0



# Generated at 2022-06-26 03:16:57.601998
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = "Cookie key contains illegal characters"
    str_1 = 'S'
    str_2 = "Unknown cookie property"
    cookie_0 = Cookie(str_1, str_1)
    dict_0: Dict[str, str] = {}
    cookiejar_0 = CookieJar(dict_0)
    cookiejar_0[str_1] = cookie_0
    cookiejar_0[str_1] = cookiejar_0[str_1]
    with pytest.raises(KeyError): cookiejar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:17:06.228003
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = ')E-L6'
    dict_0 = dict()
    dict_0[1] = 1
    dict_0[1] = 0
    del dict_0[1]
    del dict_0[1]
    del dict_0[1]
    dict_0[1] = 0
    dict_0[1] = 1
    dict_0[1] = 1
    dict_0[1] = 0
    del dict_0[1]
    dict_0[1] = 0
    dict_0[1] = 1
    dict_0[1] = 1
    dict_0[1] = 1
    dict_0[1] = 1
    dict_0[1] = 1
    dict_0[1] = 1
    dict_0[1] = 0
    dict

# Generated at 2022-06-26 03:17:14.665718
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'S'
    str_1 = 'H0A0h6J3q'
    str_2 = 'H0A0h6J3q'
    str_3 = '5CmRnI'
    expected_output = 'S=H0A0h6J3q; Path=5CmRnI'
    cookie_0 = Cookie(str_0, str_1)
    cookie_0['path'] = str_3

    # Call method __str__ of cookie_0
    assert cookie_0.__str__() == expected_output

if __name__ == "__main__":
    test_Cookie___str__()

# Generated at 2022-06-26 03:17:20.451399
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'S'
    str_1 = 'S'
    cookie_0 = Cookie(str_0, str_1)
    str_2 = 'S'
    str_3 = 'S'
    cookie_1 = Cookie(str_2, str_3)
    str_4 = 'S'
    str_5 = 'S'
    cookie_2 = Cookie(str_4, str_5)
    str_6 = 'S'
    str_7 = 'S'
    cookie_3 = Cookie(str_6, str_7)
    str_8 = 'S'
    str_9 = 'S'
    cookie_4 = Cookie(str_8, str_9)

# Generated at 2022-06-26 03:17:24.983750
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    key = 'C'
    value = 'D'
    cookie_jar[key] = value
    assert cookie_jar[key].value == value

    test_case_0()
    test_delete_cookie(cookie_jar, headers)



# Generated at 2022-06-26 03:17:36.374036
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = '#0o(jBKy.Y|c%\\'
    str_1 = 'G@7'
    str_2 = '\\U^2Sb|Rm*fEb'
    str_3 = ';C6'
    str_4 = 'AaQ-S'
    str_5 = '8!$'
    # Initialize argument
    self = CookieJar(headers={})
    str_6 = 'pY0'
    str_7 = '}tP'
    str_8 = '0~'
    str_9 = '\\'
    str_10 = '\\$szJ>#TdT'
    str_11 = '?\\'
    str_12 = 'B'
    str_13 = 'we'
    str_14 = '.'


# Generated at 2022-06-26 03:18:16.605536
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    str_0 = 'S'
    cookie_0 = cookie_jar[str_0]
    del cookie_jar[str_0]
    assert str_0 is not None


test_case_0()

# Generated at 2022-06-26 03:18:31.462469
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({'Set-Cookie': [Cookie('key', 'value')]})
    try:
        cookie_jar_0.__delitem__('key')
        assert False
    except KeyError:
        pass
    try:
        cookie_jar_0.__delitem__('key') == 0
        assert False
    except KeyError:
        pass
    try:
        cookie_jar_0.__delitem__('key') == 0
        assert False
    except KeyError:
        pass
    try:
        cookie_jar_0.__delitem__('key') == 0
        assert False
    except KeyError:
        pass
    try:
        cookie_jar_0.__delitem__('key') == 0
        assert False
    except KeyError:
        pass

# Generated at 2022-06-26 03:18:34.550159
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    output = str(cookie_0)
    assert (output == 'S=S')


# Generated at 2022-06-26 03:18:37.891339
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    # print('cookies__str__: ', cookie_0)
    return


# Generated at 2022-06-26 03:18:42.621205
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = Headers()
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0["foo"] = "bar"
    del cookie_jar_0["foo"]
    assert cookie_0.get("foo") == None
    assert str(cookie_0) == "foo=bar"



# Generated at 2022-06-26 03:18:51.433874
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_0 = Cookie('X', '')
    cookie_jar_0 = CookieJar(headers=dict())
    cookie_jar_0.setdefault(str(), Cookie('X', ''))
    cookie_jar_0['X'] = ''
    cookie_jar_0.setdefault(str(), Cookie('X', ''))
    cookie_jar_0.clear()
    cookie_jar_0[str()] = Cookie('X', '')
    cookie_jar_0['X'] = ''
    cookie_jar_0.setdefault(str(), Cookie('X', ''))
    cookie_jar_0.clear()
    cookie_jar_0['X'] = ''
    cookie_jar_0.setdefault(str(), Cookie('X', ''))
    cookie_jar_0.clear()


# Generated at 2022-06-26 03:19:03.322115
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaders()
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'ZjU'
    str_1 = '/r:6E\x0b&'
    cookie_jar_0['q7'] = str_1
    str_2 = 'S'
    cookie_jar_0['0'] = str_2
    str_3 = 'URi&\t'
    cookie_jar_0[str_0] = str_3
    str_4 = '<'
    str_5 = 'S'
    cookie_jar_0[str_5] = str_4
    str_6 = '^'
    str_7 = '9i!v'
    cookie_jar_0[str_6] = str_7


# Generated at 2022-06-26 03:19:13.939937
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'S'
    dict_0 = dict(S=cookie_0)
    dict_1 = dict(S=cookie_0)
    str_2 = 'S'
    str_3 = 'S'
    cookie_1 = Cookie(str_3, str_2)
    headers_0 = MultiHeader()
    cookiejar_0 = CookieJar(headers_0)
    cookiejar_0.cookie_headers = dict_1
    cookiejar_0[str_3] = str_2
    cookiejar_0[str_1] = cookie_1
    cookiejar_0.cookie_headers = dict_0
    cookiejar_0[str_1] = dict_0[str_1]
    cookie

# Generated at 2022-06-26 03:19:24.273285
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    dt_0 = datetime.now()
    str_0 = 'V'
    str_1 = 'X'
    dt_1 = datetime.now()
    str_2 = ''
    str_3 = 'D'
    cookie_jar_0 = CookieJar(dict_0)
    str_4 = ''
    str_5 = 'n'
    cookie_jar_0.__setitem__(str_5, str_3)
    cookie_jar_0.__delitem__(str_5)
    cookie_jar_1 = CookieJar(dict_0)
    str_6 = 's'
    cookie_jar_1.__setitem__(str_6, str_6)
    cookie_jar_0.__setitem__(str_6, str_6)

# Generated at 2022-06-26 03:19:27.205693
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print('\n\ntest_Cookie___str__')
    str_0 = 'S'
    cookie_0 = Cookie(str_0, str_0)

run_test(test_Cookie___str__)
run_test(test_case_0)