

# Generated at 2022-06-26 03:11:27.377849
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie(str_0, int_0)
    str_1 = 'Cookie'
    str_2 = 'Expires'
    str_3 = 'Path'
    str_4 = 'Domain'
    str_5 = 'Path'
    str_6 = 'Domain'
    str_7 = 'Path'
    str_8 = 'Domain'
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()

# Generated at 2022-06-26 03:11:32.206323
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_2 = ''
    cookie_jar_0[str_2] = ''
    cookie_jar_0[str_2]['max-age'] = 0
    del cookie_jar_0[str_2]


# Generated at 2022-06-26 03:11:40.967709
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
  test_Cookie = Cookie('test_Cookie', 'test_Cookie')
  test_Cookie['max-age'] = 'test_Cookie'
  test_Cookie['expires'] = 'test_Cookie'
  test_Cookie['secure'] = 'test_Cookie'
  test_Cookie['httponly'] = 'test_Cookie'
  test_Cookie['path'] = 'test_Cookie'
  test_Cookie['comment'] = 'test_Cookie'
  test_Cookie['domain'] = 'test_Cookie'
  test_Cookie['version'] = 'test_Cookie'
  test_Cookie['samesite'] = 'test_Cookie'
  # No input
  # Call the __str__ method of object test_Cookie
  str_return = test_Cookie

# Generated at 2022-06-26 03:11:45.957996
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_1 = CookieJar(str_0)
    with pytest.raises(KeyError):
        cookie_jar_1.__delitem__('')


# Generated at 2022-06-26 03:11:52.602715
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Cookie.__setitem__
    """
    # In case __setitem__ is expected to raise an exception
    # (See class documentation)
    with pytest.raises(KeyError):
        cookie_0 = Cookie(str_0, str_0)
        key = str_0
        value = str_0
        cookie_0.__setitem__(key, value)



# Generated at 2022-06-26 03:12:00.939230
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:12:02.973881
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_jar_0 = CookieJar()
    cookie_jar_0.__setitem__(str_0, str_1)
    assert cookie_jar_0.__getitem__(str_0) == str_1


# Generated at 2022-06-26 03:12:06.313044
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = Cookie('', '').__str__()
    str_1 = 'max-age'
    cookie_jar_0 = CookieJar(str_1)
    assert str_0 == '=; Path=/; Comment=; Domain=; Max-Age=0; Secure; HttpOnly; Version=; SameSite='
    assert str_1 == 'max-age'
    assert cookie_jar_0['max-age'] == 0

# Generated at 2022-06-26 03:12:17.955513
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = ''
    str_1 = 'pnxp^uVUUmXb'
    str_2 = 'o-B/\:>c%i1Z'
    str_3 = 'Q9N!i@!yTn^[&'
    str_4 = 'd|>I\t=uR\^XV'
    str_5 = '7s>i\:@|!YK]'
    str_6 = 'bx(X&M~^K);0.'
    str_7 = ';Q!.6Y!U/n^U'

# Generated at 2022-06-26 03:12:26.215096
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'comment'
    cookie_jar_0[str_1] = 'emuAnmC1'
    str_2 = 'cookie_name'
    str_3 = 'cookie_value'
    cookie_jar_0[str_2] = str_3
    key_0 = str_2
    value_0 = str_3
    cookie_jar_0.__setitem__(key_0, value_0)
    key_1 = str_2
    value_1 = str_3
    cookie_jar_0[key_1] = value_1




# Generated at 2022-06-26 03:12:33.413762
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    arg_1 = Cookie('samesite', 'lax')
    arg_2 = Cookie('secure', True)
    arg_1.__str__()
    arg_2.__str__()



# Generated at 2022-06-26 03:12:34.339631
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert True

# Generated at 2022-06-26 03:12:40.185295
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    if not hasattr(_Cookie___str__, "__error__"):
        try:
            global str_0
            str_0 = '\n    Cookie.__setitem__\n    '
            _Cookie___str__.__assert_wrapper__(
            )
            print("Test passed.")
        except TypeError:
            print("Test failed.")
        except Exception:
            print("An error occured during testing.")
    else:
        print("Unknown error occured during testing.")



# Generated at 2022-06-26 03:12:50.647774
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = '\n    CookieJar.__delitem__\n    '
    # Testing the case where key is not in dict
    dict_0 = CookieJar({})
    dict_0["test"] = "data"
    del dict_0["test"]
    assert dict_0 == {}
    # Testing the case where key is in dict
    dict_1 = CookieJar({})
    dict_1["test"] = "data"
    dict_1.cookie_headers["test"] = "Set-Cookie"
    del dict_1["test"]
    assert dict_1 == {}
    succesful_test("CookieJar", "__delitem__", str_0)


# Generated at 2022-06-26 03:12:51.901935
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    Cookie.__str__()



# Generated at 2022-06-26 03:13:03.401797
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = '\n    Cookie.__setitem__\n    '
    str_1 = '\n    Cookie.__setitem__\n    '
    str_2 = '\n    Cookie.__setitem__\n    '
    str_3 = '\n    Cookie.__setitem__\n    '
    str_4 = '\n    Cookie.__setitem__\n    '
    str_5 = '\n    Cookie.__setitem__\n    '
    str_6 = '\n    Cookie.__init__\n    '
    str_7 = '\n    Cookie.__setitem__\n    '
    str_8 = '\n    Cookie.__setitem__\n    '
    str_9 = '\n    Cookie.__setitem__\n    '


# Generated at 2022-06-26 03:13:07.406447
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie = CookieJar({'a': 'b'})
    cookie['c'] = 'd'
    assert cookie['c'] == 'd'


# Generated at 2022-06-26 03:13:17.045442
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie('Dq', 'NjA')
    cookie_0['max-age'] = -43
    cookie_0['max-age'] = -48
    cookie_0['version'] = 'tY|'
    cookie_0['version'] = 'tY|'
    cookie_0['version'] = 2
    cookie_0['version'] = -24
    cookie_0['version'] = -37
    cookie_0['version'] = -37
    cookie_0['path'] = ':4P4'
    cookie_0['path'] = -29
    cookie_0['version'] = 'gY'
    cookie_0['version'] = 'gY'
    cookie_0['version'] = "hEZ"
    cookie_0['version'] = "hEZ"

# Generated at 2022-06-26 03:13:22.068732
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie(0, 0)
    try:
        cookie_0.__setitem__('\x04(k\x93:', 0)
    except KeyError:
        pass

    cookie_0.__setitem__('\x07\x14\x04\x1c\x1a\x00,\x1d\x10', 0)
    try:
        cookie_0.__setitem__('{""k\'\x14z\x0e', 0)
    except KeyError:
        pass
    str_0 = '\n    Cookie.__setitem__\n    '



# Generated at 2022-06-26 03:13:25.785752
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Create an instance of a Cookie
    cookie = Cookie(key='a', value='b')
    # Call method __str__
    result = cookie.__str__()
    assert type(result) == str
    assert result == 'a=b'

# Generated at 2022-06-26 03:13:39.769960
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    try:
        # Simple but inefficient
        cookie_jar_0.__delitem__(5)
        raise RuntimeError(
            "Unexpected exception thrown. CookieJar.__delitem__() method call succeeded.")
    except KeyError as err:
        print(err)
        if err.args[0] == "Unknown cookie property":
            # Expected exception: KeyError
            pass
        else:
            raise RuntimeError(
                "Unexpected exception thrown. Expected KeyError")


# Generated at 2022-06-26 03:13:41.808872
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, DEFAULT_MAX_AGE)



# Generated at 2022-06-26 03:13:45.456093
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_cookie_0 = Cookie(str_0, 'cookie_value_0')
    str_1 = cookie_cookie_0.__str__()

    # assert str_1 == 'max-age=cookie_value_0'
    assert str_1 == 'max-age=max-age'



# Generated at 2022-06-26 03:13:54.645819
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = '#'
    cookie_jar_0 = CookieJar(str_0)
    assert type(cookie_jar_0) == CookieJar
    cookie_jar_0['max-age'] = 'expires'
    assert cookie_jar_0['max-age'] == 'expires'
    cookie_jar_0['path'] = 'expires'
    assert cookie_jar_0['path'] == 'expires'
    cookie_jar_0['comment'] = 'expires'
    assert cookie_jar_0['comment'] == 'expires'


# Generated at 2022-06-26 03:13:59.174305
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('key', 'value')
    cookie_1 = Cookie('key', 'value')
    cookie_2 = Cookie('key', 'value')
    cookie_3 = Cookie('key', 'value')
    cookie_4 = Cookie('key', 'value')
    print(cookie_1.__str__())

# Generated at 2022-06-26 03:14:01.552088
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
	c = Cookie('key', 'value')
	assert c.__str__().startswith('key=value')


# Generated at 2022-06-26 03:14:05.608267
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # set up context
    str_0 = 'secure'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'secure'

    # test the code
    cookie_jar_0.__delitem__(str_1)

    # assert the result
    # TODO: implement your assert statements here.


# Generated at 2022-06-26 03:14:15.457309
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    str_1 = 'max-age'
    cookie_0 = Cookie(str_0, str_1)
    str_2 = 'max-age'
    str_3 = 'max-age'
    cookie_0 = Cookie(str_2, str_3)
    str_4 = 'max-age'
    str_5 = 'max-age'
    cookie_0 = Cookie(str_4, str_5)
    str_6 = 'max-age'
    str_7 = 'max-age'
    cookie_0 = Cookie(str_6, str_7)
    str_8 = 'max-age'
    str_9 = 'max-age'
    cookie_0 = Cookie(str_8, str_9)

# Generated at 2022-06-26 03:14:20.059452
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_2 = str_0
    cookie_jar_0.__delitem__(str_2)


# Generated at 2022-06-26 03:14:27.842457
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
  try:
    cookie_0 = Cookie('A_0', 'B_1')
    cookie_0.__setitem__('C_2', 'D_3')
  except KeyError as e:
    assert str(e) == "Unknown cookie property"

  try:
    cookie_0 = Cookie('A_0', 'B_1')
    cookie_0.__setitem__('max-age', 'E_4')
  except TypeError as e:
    assert str(e) == "Cookie max-age must be an integer"



# Generated at 2022-06-26 03:14:34.523374
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie()
    try:
        assert str(cookie_0) == '', 'Expected different value for cookie_0'
    except AssertionError as e:
        raise AssertionError(e.args)


# Generated at 2022-06-26 03:14:37.133714
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'expires'
    cookie_jar_0.__delitem__(str_1)


# Generated at 2022-06-26 03:14:42.502723
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_1 = 'max-age'
    cookie_jar_1 = CookieJar(str_1)
    str_2 = '; '
    cookie_jar_2 = CookieJar(str_2)
    str_3 = 'max-age'
    cookie_jar_3 = cookie_jar_2[str_3]


# Generated at 2022-06-26 03:14:50.262426
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)

    str_1 = 'max-age'
    dict_0 = dict()
    dict_0[str_0] = str_1

    exception_occurred = False
    try:
        cookie_jar_0.__setitem__(str_0, str_1)
    except TypeError:
        exception_occurred = True
    assert exception_occurred

test_case_0()
test_Cookie___setitem__()

# Generated at 2022-06-26 03:14:59.517599
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Do you want the test to fail?
    fail = True

    # Remember the initial value of the variable
    var_init = 0

    # Remember the initial values of the variables
    var_init_1 = 0

    # Create an object of Cookie class
    cookie_instance_0 = Cookie('key', 'value')

    # Obtain the output of method __str__ of class Cookie
    str_ret_val_0 = cookie_instance_0.__str__()

    # Compare the types of the return values to ensure that the method works as expected
    if not isinstance(str_ret_val_0, str):
        print('Test Failed: Method __str__ of class Cookie may not work as expected')
        fail = True

    # Assign values to the variables
    var_init = 1

    # Assign values to the variables
    var_

# Generated at 2022-06-26 03:15:04.236903
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'max-age'
    dict_0 = CookieJar(str_0)
    str_1 = '()'
    dict_0[str_1] = 0
    assert dict_0[str_1] == 0


# Generated at 2022-06-26 03:15:16.833516
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'min-age'
    cookie_0 = Cookie(str_1, str_0)
    cookie_0['max-age'] = str_1
    cookie_jar_0[str_0] = cookie_0
    cookie_jar_0[str_1]
    cookie_jar_0[str_1] = str_0
    str_2 = 'secure'
    cookie_1 = Cookie(str_2, str_1)
    cookie_jar_0[str_2] = cookie_1
    cookie_jar_0[str_2] = str_0
    str_3 = 'expires'
    str_4 = 'max-agage'

# Generated at 2022-06-26 03:15:20.083978
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, int_0)
    assert str(cookie_0) == 'max-age=0'


# Generated at 2022-06-26 03:15:23.523519
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:15:28.051800
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # default
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, str_0)
    result_0 = cookie_0.__str__()
    expected_0 = 'max-age=max-age; Max-Age=max-age'
    assert result_0 == expected_0
    print(result_0)
    print(expected_0)



# Generated at 2022-06-26 03:15:34.476197
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('max-age', 'max-age')
    assert cookie_0.__str__() == 'max-age=max-age'


# Generated at 2022-06-26 03:15:38.619520
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    str_1 = '; '
    cookie_0 = CookieJar(str_0)
    assert str_0 != str(cookie_0)
    assert str_1 != str(cookie_0)


# Generated at 2022-06-26 03:15:46.472229
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, 42)
    cookie_1 = Cookie('dev_appserver_login', 'j:0:1234567890:1234567890:test@example.com:1')
    print(cookie_0.__str__())
    print(cookie_1.__str__())

    cookie_0['Path'] = '/'
    cookie_0['Version'] = 1
    print(cookie_0.__str__())


# Generated at 2022-06-26 03:15:50.938758
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar('max-age')
    cookie_jar_0['max-age']
    cookie_jar_0['max-age'] = 'max-age'
    cookie_jar_0['max-age'] = 'max-age'
    assert False


# Generated at 2022-06-26 03:15:54.893201
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'samesite'
    cookie_jar_0.__delitem__(str_1)



# Generated at 2022-06-26 03:15:57.013473
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    test_case_0()


# Generated at 2022-06-26 03:15:59.237713
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # get input values for test
    key_0 = ""
    value_0 = 0
    cookie_jar_0 = CookieJar()
    # call the function
    cookie_jar_0.__setitem__(key_0, value_0)


# Generated at 2022-06-26 03:16:02.339680
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print()
    print("function __str__ in class Cookie")

    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, datetime())

    assert ("%s=%s" % (str_0, str(datetime())) == cookie_0.__str__())


# Generated at 2022-06-26 03:16:05.077461
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    returnValue = Cookie.__setitem__(Cookie, key='5UxCRZ', value='')
    assert returnValue == None


# Generated at 2022-06-26 03:16:09.116551
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('chocolate chip', 'delicious')
    cookie_0['max-age'] = 1000
    str_0 = cookie_0.__str__()
    assert str_0 == "chocolate chip=delicious; Max-Age=1000"


# Generated at 2022-06-26 03:16:16.654247
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    cookie_1 = Cookie('name', 'value')

    cookie_1['path'] = '/'

    assert cookie_1['path'] == '/'

    cookie_1['max-age'] = DEFAULT_MAX_AGE

    assert cookie_1['max-age'] == DEFAULT_MAX_AGE



# Generated at 2022-06-26 03:16:21.442298
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    for key, value in {'key': 'value', 'key_0': 'value_0'}.items():
        CookieJar[key] = value
        CookieJar.key = value

    for key in {'key', 'key_0'}.copy():
        del CookieJar.key

    for key in {'key', 'key_0'}.copy():
        del CookieJar.key
        del CookieJar[key]


# Generated at 2022-06-26 03:16:25.941698
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    # Get the cookie with key "acdf"
    key_0 = 'acdf'
    cookie_0 = cookie_jar_0[key_0]
    # Delete the cookie from CookieJar
    del cookie_jar_0[key_0]



# Generated at 2022-06-26 03:16:31.401985
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0,DEFAULT_MAX_AGE)
    print(cookie_0)
#     cookie_0['expires'] = datetime.now() + timedelta(days=1)
#     print(cookie_0)
    cookie_0['max-age'] = 10
    print(cookie_0)


# Generated at 2022-06-26 03:16:34.795489
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, 0)

# ------------------------------------------------------------ #
#  Main
# ------------------------------------------------------------ #



# Generated at 2022-06-26 03:16:44.399809
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'max-age'
    str_0 = str_1
    cookie_jar_0['foo'] = str_0
    expected_0 = 'max-age'
    assert ('foo' in cookie_jar_0), "Expected cookie_jar_0.keys() to contain 'foo', but it did not.  Got: %s.  Expected: %s" % (
        cookie_jar_0.keys(), 'foo'
    )

    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'max-age'
    str_0 = str_1
    cookie_jar_0[''] = str_0
    expected_

# Generated at 2022-06-26 03:16:49.521405
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Iterate the following code block three times to test different code paths
    for _ in range(3):
        # Assign values to the following variables
        key_0 = ''
        value_0 = ''
        # Call the __setitem__ method of the CookieJar
        test_case_0()



# Generated at 2022-06-26 03:17:00.231864
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0.headers = {}
    cookie_jar_0.cookie_headers = {}
    cookie_jar_0.header_key = "cookie"
    str_1 = 'cookie'
    cookie_0 = Cookie(str_1, DEFAULT_MAX_AGE)
    cookie_0["path"] = "/"
    cookie_jar_0.cookie_headers[str_1] = str_0
    cookie_1 = cookie_jar_0.headers.add(str_0, cookie_0)
    assert cookie_1
    # There are no test cases for the __setitem__ method of the CookieJar class and the Cookie class


# Generated at 2022-06-26 03:17:04.374550
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        cookiejar_0 = CookieJar()
        str_0 = 'max-age'
        cookiejar_0[str_0] = 1
        del cookiejar_0[str_0]
        cookiejar_0 = str_0
    except Exception as exception_0:
        print('Exception caught: {}'.format(exception_0))



# Generated at 2022-06-26 03:17:14.418873
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    text = read_file("CookieJar.py")
    assert text.find("def __delitem__(") != -1, "Method __delitem__ not found"

    # Make sure it uses MultiHeader
    assert text.find("MultiHeader") != -1, "Class MultiHeader is not used"

    # Make sure it does not delete cookie_headers
    assert text.find("del self.cookie_headers") == -1, "You are deleting cookies"
    
    # It deletes key with self[key] = ""
    assert text.find("self[key] =") != -1, "Doesn't set cookie value to empty string"

    # It sets the max age to 0
    assert text.find("max-age") != -1, "Doesn't set max-age to 0"


# Generated at 2022-06-26 03:17:23.946567
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie('QWZDNv', '_MnFaj')
    cookie_0['max-age'] = '65'

# Test class for Cookie

# Generated at 2022-06-26 03:17:29.158648
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie('value', str_0)
    str_1 = '; max-age=max-age; value=value'
    str_2 = cookie_0.__str__()
    assert (str_1 == str_2)


# Generated at 2022-06-26 03:17:30.856375
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'max-age'
    test_case_0(str_0)


# Generated at 2022-06-26 03:17:33.538678
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    assert None


# Generated at 2022-06-26 03:17:42.527194
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'expires'
    cookie_0[str_1] = str_1
    str_2 = 'raise'
    str_3 = 'expires'
    str_4 = 'strftime'
    str_5 = '%a, %d-%b-%Y %T GMT'
    str_6 = '%s=%s'
    str_7 = 'key'
    str_8 = 'value'
    str_9 = '%s=%s'
    str_10 = '%s=%s'
    str_11 = '%s=%d'
    str_12 = 'key'
    str_13 = 'value'
    str_14 = '; '


# Generated at 2022-06-26 03:17:46.835547
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test with positional arguments
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)

    # Test with named arguments
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)



# Generated at 2022-06-26 03:17:51.008600
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie(cookie_jar_0, str_0)
    str_1 = ''
    str_1 = cookie_0.__str__(str_1)



# Generated at 2022-06-26 03:17:54.671271
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, str_0)
    cookie_0['path'] = str_0
    print(cookie_0)


# Generated at 2022-06-26 03:17:58.070887
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert "max-age={}".format(DEFAULT_MAX_AGE) in str(Cookie('cookie_0', ''))


# Generated at 2022-06-26 03:18:03.549953
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    assert (
        (
            'max-age' in cookie_jar_0
        )
    )

# Generated at 2022-06-26 03:18:25.312381
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    strKey = 'test'
    strValue = 'test'
    cookie = Cookie(strKey, strValue)

    try:
        cookie['test'] = 'test'
    except Exception as ex:
        if type(ex) is KeyError or type(ex) is ValueError:
            return
    assert False


# Generated at 2022-06-26 03:18:32.694676
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'testString'
    cookie_jar_0[str_1] = str_1
    var_3 = 0
    cookie_jar_0[str_1]['max-age'] = var_3
    assert str_1 in cookie_jar_0
    del cookie_jar_0[str_1]
    assert str_1 not in cookie_jar_0


# Generated at 2022-06-26 03:18:36.317036
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    assert len(cookie_jar_0) == 0



# Generated at 2022-06-26 03:18:46.266370
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'max-age'
    cookie_0 = Cookie(str_0, '; ')
    try:
        cookie_0.__setitem__('expires', '; ')
    except KeyError:
        exception_0 = True
    else:
        exception_0 = False
    try:
        cookie_0.__setitem__('max-age', '; ')
    except ValueError:
        exception_1 = True
    else:
        exception_1 = False
    try:
        cookie_0.__setitem__('expires', '; ')
    except TypeError:
        exception_2 = True
    else:
        exception_2 = False
    try:
        cookie_0.__setitem__('f', '; ')
    except KeyError:
        exception_3 = True

# Generated at 2022-06-26 03:18:51.897543
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Set up test case
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    key = 'max-age'
    value = 'max-age'

    # Invoke the tested operation
    cookie_jar_0.__setitem__(key, value)

    # Check the result
    if (('max-age' not in cookie_jar_0) or (cookie_jar_0['max-age'] != 'max-age')):
        raise AssertionError



# Generated at 2022-06-26 03:18:58.295859
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    int_0 = 0
    cookie_jar_0[1] = int_0
    assert str_0 in cookie_jar_0.headers
    int_1 = 1
    del cookie_jar_0[int_1]
    assert not str_0 in cookie_jar_0.headers


# Generated at 2022-06-26 03:19:05.285297
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        # initialization
        str_0 = 'max-age'
        cookie_jar_0 = CookieJar(str_0)
        str_1 = 'max-age'
        str_2 = 'max-age'
        cookie_jar_0[str_1] = str_2
        str_3 = 'max-age'
        # check
        cookie_jar_0.__delitem__(str_3)
    except:
        print('Exception:')
        assert False


# Generated at 2022-06-26 03:19:15.954548
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("Testing Cookie class method: __str__")
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    cookie_dict_0 = {'expires': 'expires', 'path': 'Path', 'comment': 'Comment', 'domain': 'Domain', 'max-age': 'Max-Age', 'secure': 'Secure', 'httponly': 'HttpOnly', 'version': 'Version', 'samesite': 'SameSite'}
    cookie_0 = Cookie('key', 'value')
    cookie_0['max-age'] = 10
    assert cookie_0.__str__() == 'key=value; Max-Age=10'

    cookie_1 = Cookie('key', 'value')
    cookie_1['expires'] = datetime(2007, 12, 12, 12, 12, 12)

# Generated at 2022-06-26 03:19:25.922376
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie(str_0, str_0)
    cookie_1 = Cookie(str_0, str_0)
    cookie_2 = Cookie(str_0, str_0)
    cookie_3 = Cookie(str_0, str_0)

    cookie_1['max-age'] = int(0)
    assert repr(cookie_1['max-age']) == repr(int(0))
    assert repr(cookie_1['expires']) == repr('')
    assert cookie_1['domain'] == ''
    cookie_2['expires'] = datetime(1, 1, 1, 1, 1)
    assert repr(cookie_2['max-age']) == repr(0)

# Generated at 2022-06-26 03:19:29.502904
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar_0 = CookieJar(headers)
    key = 'max-age'
    cookie_jar_0[key] = 0
    del cookie_jar_0[key]
    assert key not in cookie_jar_0


# Generated at 2022-06-26 03:20:00.950092
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    max_age = 'max-age'
    cookie_jar = CookieJar(max_age)
    cookie = cookie_jar['test']
    cookie['path'] = '/'
    cookie.value = "test"
    cookie.key = "test"
    str = cookie.__str__()
    pass

test_case_0()
test_Cookie___str__()

# Generated at 2022-06-26 03:20:05.935202
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Setup test data
    key = 'key'
    value = 'value'
    cookie = Cookie(key, value)
    cookie['max-age'] = 0
    cookie['secure'] = True

    # Unit test
    result = str(cookie)
    expected = 'key=value; Max-Age=0; Secure'
    assert result == expected


# Generated at 2022-06-26 03:20:14.091505
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = "SiteId=ABCD"
    str_1 = "1000"
    str_2 = 'max-age'
    str_3 = "value"
    cookie_jar_0 = CookieJar(str_2)
    cookie_jar_1 = CookieJar(str_2)
    cookie_jar_2 = CookieJar(str_2)
    cookie_jar_3 = CookieJar(str_2)
    cookie_jar_0.__setitem__(str_0, str_1)
    try:
        cookie_jar_0.__setitem__(str_0, str_3)
    except KeyError:
        # Expected
        pass
    else:
        # Unexpected
        assert False
    cookie_jar_1.__delitem__(str_0)

# Generated at 2022-06-26 03:20:16.522141
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0.__delitem__(str_0)

# Generated at 2022-06-26 03:20:24.635914
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    key = 'Sec-Fetch-User'
    expected_value = 'Fetch'

    # Invoke method
    cookie_jar_0.__delitem__(key)

    # Check return type
    assert isinstance(expected_value, str)

    # Check return value
    cookie_jar_0.__setitem__(key, 'Fetch')
    assert cookie_jar_0[key] == 'Fetch'

    # Check side effects
    assert str_0 == 'max-age'



# Generated at 2022-06-26 03:20:33.180484
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'max-age'
    str_1 = 'max-age'
    str_2 = '; '
    str_3 = '3b'
    str_4 = 'expires'
    str_5 = 'expires'
    str_6 = '; '
    str_7 = '2c'
    str_8 = 'expires'
    str_9 = 'expires'
    str_10 = '; '
    str_11 = '4c'
    str_12 = 'expires'
    str_13 = 'expires'
    str_14 = '; '
    str_15 = '11b'
    str_16 = 'expires'
    str_17 = 'expires'
    str_18 = '; '
    str_19 = '1a'
    str

# Generated at 2022-06-26 03:20:37.362698
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        str_0 = 'max-age'
        cookie_0 = Cookie()
        cookie_0.__setitem__(str_0, 100)
    except KeyError:
        print("Key error")
    except ValueError:
        print("Value Error")


# Generated at 2022-06-26 03:20:42.503141
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # This method is also tested in class CookieIntegrationTests.
    str_0 = "max-age"
    str_1 = "key"
    str_2 = "value"
    Cookie_0 = Cookie(str_1, str_2)
    Cookie_0["max-age"] = 10
    str_3 = Cookie_0.__str__()
    assert str_3 is not None



# Generated at 2022-06-26 03:20:45.969476
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'max-age'
    cookie_jar_0.__setitem__(str_0, str_1)


# Generated at 2022-06-26 03:20:54.926272
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from cookie import CookieJar
    from http import cookies

    # Test case 1
    str_0 = ''
    cookie_jar_0 = CookieJar(str_0)
    str_0 = 'max-age'
    cookie_jar_0 = CookieJar(str_0)
    str_0 = 'b.a.b'
    cookie_jar_0 = CookieJar(str_0)
    str_0 = 'a'
    cookie_jar_0 = CookieJar(str_0)
    str_0 = 'a'
    cookie_jar_0 = CookieJar(str_0)
    str_0 = 'a'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0['a'] = 'a'
    cookie_jar_0['b'] = 'b'
    cookie_jar