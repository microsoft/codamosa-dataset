

# Generated at 2022-06-26 03:11:24.759772
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Iterate over __test_case_0 to get the key/value pairs for test.
    for test_case in test_case_0:
        key = test_case[0]
        expected_result = test_case[1]

        # Test function __delitem__ of class CookieJar
        actual_result = CookieJar___delitem__(key)

        assert actual_result == expected_result, "Test fail on line {}".format(
            inspect.currentframe().f_lineno
        )

# Run the unit tests
test_CookieJar___delitem__()

# -------------------------------------------------------------------- #

# Generated at 2022-06-26 03:11:28.801406
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = ','
    cookie_jar_0[str_1] = DEFAULT_MAX_AGE


# Generated at 2022-06-26 03:11:36.025753
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(list())
    cookie_jar_1 = CookieJar(list())
    cookie_jar_1["cookie_jar_0"] = "cookie_jar_1"
    try:
        cookie_jar_1["cookie_jar_0"] = 1.6221138549396326
    except KeyError:
        assert True
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_1"
    del cookie_jar_0["cookie_jar_0"]


# Generated at 2022-06-26 03:11:51.394292
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("test_Cookie___str__")
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)

    str_0 = 'Endpoint with name `'
    cookie_1 = Cookie(str_0, str_0)

    str_0 = 'Endpoint with name `'
    str_1 = 'Endpoint with name `'
    cookie_1['expires'] = str_1
    str_0 = ''
    str_1 = 'Endpoint with name `'
    cookie_1['expires'] = str_1
    str_0 = 'Endpoint with name `'
    str_1 = 'Endpoint with name `'
    cookie_1['expires'] = str_1

    str_0 = 'Endpoint with name `'

# Generated at 2022-06-26 03:12:00.702787
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('key', 'value')
    str_0 = cookie_0.__str__()
    # AssertionError: "; Path=/; Domain=\n; Max-Age=0; Expires=Thu, 01-Jan-1970 00:00:00 GMT; HttpOnly; Secure" != "key=value"
    assert str_0 == "key=value"


# Generated at 2022-06-26 03:12:03.824173
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    This method tests the functionality of deleting a cookie.
    :return:
    """
    # Initializing the content of headers
    cookie_jar = CookieJar(headers)
    # Add a cookie to the jar
    cookie_jar["test"] = "true"
    # Delete the cookie
    del cookie_jar["test"]
    # Assert that the cookie has been removed
    assert not cookie_jar



# Generated at 2022-06-26 03:12:16.665742
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_1 = 'Endpoint with name `'
    cookie_jar_1 = CookieJar(str_1)
    cookie_1 = Cookie('nisse', '')
    cookie_1["path"] = "/"
    str_2 = 'Set-Cookie'
    cookie_jar_1.headers.add(str_2, cookie_1)
    cookie_jar_1.cookie_headers["nisse"] = str_2
    cookie_jar_1.header_key = str_2
    cookie_jar_1.__setitem__('nisse', '')
    cookie_jar_1.__setitem__('nisse', 'logged_in')
    cookie_jar_1.__setitem__('nisse', 'logged_out')
    cookie_2 = Cookie('nisse', '')

# Generated at 2022-06-26 03:12:26.250734
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert_obj = Assert()

    # Test with value containing characters
    cookie = Cookie("test-key", "test-value")
    assert_obj.assert_string_equals(str(cookie), "test-key=test-value")

    # Test with value containing spaces
    cookie = Cookie("test-key", "test-value with spaces")
    assert_obj.assert_string_equals(
        str(cookie), "test-key=\"test-value with spaces\""
    )
    
    # Test with a value containing special characters
    cookie = Cookie("test-key", "test-value with <>/@")
    assert_obj.assert_string_equals(
        str(cookie), "test-key=\"test-value with <>/@\""
    )

    # Test with a value containing special characters

# Generated at 2022-06-26 03:12:32.564338
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'g6=r#'
    value_0 = test_CookieJar___delitem___value_0(str_1, str_0)
    cookie_jar_0.__delitem__(str_1)


# Generated at 2022-06-26 03:12:50.254844
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = ''
    for i in range(_random.randint(0, 10)):
        str_0 += _random_string(3)
    str_1 = 'CookieJar'
    cookie_jar_0 = CookieJar(str_1)
    while not _random.randint(0, 2):
        str_0 += _random_string(3)
    cookie_jar_0[str_0] = str_0
    try:
        cookie_jar_0.__delitem__(str_1)
        del cookie_jar_0[str_0]
    except (KeyError, TypeError):
        pass
    else:
        raise AssertionError('Expected TypeError, got %s' % (type(TypeError)))
        del cookie_jar_0[str_1]

# Generated at 2022-06-26 03:12:58.537890
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Generate test case input data

    str_0 = ''
    cookie_0 = Cookie(str_0)

    # Call function to be tested

    str_1 = str(cookie_0)

    # Check the result

    assert str_1 == '""'



# Generated at 2022-06-26 03:13:06.300198
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    print(cookie_jar_0)
    print(cookie_jar_0.headers)
    cookie_jar_0["CookieKey_0"] = "CookieValue_0"
    print(cookie_jar_0.headers)
    cookie_jar_0["CookieKey_1"] = "CookieValue_1"
    print(cookie_jar_0.headers)
    cookie_jar_0["CookieKey_2"] = "CookieValue_2"
    print("CookieKey_1" in cookie_jar_0)
    print("CookieKey_2" in cookie_jar_0)
    test_case_0()
    del cookie_jar_0["CookieKey_1"]
    print

# Generated at 2022-06-26 03:13:10.517803
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'oIy'
    cookie_0 = Cookie(str_0, 'wtw')

    str_1 = '; SameSite=None; Domain=yWPKjX; Max-Age=4D; ' \
            'Secure; Version=1; HttpOnly; ' \
            'Comment=eDi; Path=dNL; expires=Thu, 21-Mar-2019 14:24:43 GMT'
    assert_equal(str(cookie_0), str_1, 'Expected different cookie value')

    cookie_1 = Cookie('NdvlB', 'NljkX')

# Generated at 2022-06-26 03:13:15.317129
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    cookie_jar_0.__setitem__(str_1, 'Endpoint with name `')
    int_0 = -1
    cookie_jar_0.__delitem__(int_0)


# Generated at 2022-06-26 03:13:19.694349
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
	# Write your code here.
	pass


# Generated at 2022-06-26 03:13:28.146333
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_0 = Cookie(str_0, str_0)
    str_0 = 'Endpoint with name `'
    cookie_0[str_0] = str_0
    str_0 = 'Endpoint with name `'
    cookie_0[str_0] = str_0
    # Run method
    str_0 = 'Endpoint with name `'
    str_1 = cookie_0.__str__()
    # Verify method result
    assert(str_1 == str_0)
    # Verify side effects


# Generated at 2022-06-26 03:13:30.348444
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = '<html>\n    <head>\n    <title>My Site</title>\n    </head>\n    <body>\n        <p>The quick brown fox jumps over the lazy dog.</p>\n    </body>\n</html>'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie("Endpoint with name '%s' already exists.", "")


# Generated at 2022-06-26 03:13:38.978124
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)

    cookie_0 = Cookie(cookie_jar_0, str_0)
    str_1 = cookie_0.__str__()
    cookie_0 = Cookie(cookie_jar_0)
    str_2 = cookie_0.__str__()
    str_3 = cookie_jar_0[str_0]
    str_4 = cookie_jar_0[str_0]
    str_5 = cookie_0.__str__()



# Generated at 2022-06-26 03:13:41.686233
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar()
    str_0 = 'Endpoint with name `'
    cookie_jar_0.__setitem__(str_0)


# Generated at 2022-06-26 03:13:47.752118
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    cookie_jar = CookieJar(headers)
    cookie_jar[key] = "value"

    # Make sure the header is set
    assert cookie_jar.headers[cookie_jar.header_key]

    # Now delete the key
    del cookie_jar[key]

    # Make sure the header is gone
    assert cookie_jar.headers[cookie_jar.header_key] is None



# Generated at 2022-06-26 03:13:57.763632
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case 0
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    key_0 = ''
    del cookie_jar_0[key_0]


# Generated at 2022-06-26 03:14:00.123759
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        str_0 = 'Endpoint with name `'
        cookie_jar_0 = CookieJar(str_0)
        try:
            del cookie_jar_0['Endpoint with name `']
        except Exception as e_0:
            raise e_0
    except Exception as e_1:
        print('Exception caught: ' + str(e_1))


# Generated at 2022-06-26 03:14:10.054564
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'Endpoint with name `'
    str_1 = 'Endpoint with name `'
    str_2 = 'v#y_4n*A&4gW'
    str_3 = 'Endpoint with name `'
    str_4 = 'v#y_4n*A&4gW'
    str_5 = 'Endpoint with name `'
    str_6 = 'v#y_4n*A&4gW'
    str_7 = 'Endpoint with name `'
    str_8 = 'v#y_4n*A&4gW'
    str_9 = 'Endpoint with name `'
    str_10 = 'v#y_4n*A&4gW'
    str_11 = 'Endpoint with name `'

# Generated at 2022-06-26 03:14:17.590769
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie("", "")
    cookie_0["HttpOnly"] = False
    cookie_0["Secure"] = True
    cookie_0["SameSite"] = "Lax"
    cookie_0["Domain"] = "localhost"
    cookie_0["Path"] = "/example"
    cookie_0["Version"] = 5
    cookie_0["expires"] = datetime(2020, 5, 9, 1, 35, 28, 994205)
    cookie_0["comment"] = "foobar"
    cookie_0["max-age"] = DEFAULT_MAX_AGE
    cookie_jar_0[cookie_0.key] = cookie_0

# Generated at 2022-06-26 03:14:29.032578
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    global cookie_jar_0
    global str_0
    global str_1
    cookie_jar_0 = CookieJar(str_0)
    str_1 = '` not found.'
    str_2 = '`'
    str_3 = '`'
    str_4 = '`'
    str_5 = '`'
    str_6 = '`'
    str_7 = '`'
    str_8 = '`'
    str_9 = '`'
    str_10 = '`'
    str_11 = '`'
    str_12 = '`'
    str_13 = '`'
    str_14 = '`'
    str_15 = '`'
    str_16 = '`'
    str_17 = '`'
    str_18 = '`'


# Generated at 2022-06-26 03:14:37.976408
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie('d', 'Cookie')
    try:
        cookie_0['__setitem__'] = ''
    except KeyError as e:
        print('KeyError:', e)
    else:
        assert False
    try:
        cookie_0['__setitem__'] = 'd'
    except KeyError as e:
        print('KeyError:', e)
    else:
        assert False
    try:
        cookie_0['__setitem__'] = '\\'
    except KeyError as e:
        print('KeyError:', e)
    else:
        assert False
    try:
        cookie_0['expires'] = False
    except KeyError as e:
        print('KeyError:', e)
    else:
        assert False

# Generated at 2022-06-26 03:14:39.763280
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj.__delitem__(0)


# Generated at 2022-06-26 03:14:46.362582
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_key_0 = 'test'
    str_1 = 'Endpoint with name `'
    cookie_value_0 = str_1
    cookie_jar_0[cookie_key_0] = cookie_value_0


# Generated at 2022-06-26 03:14:51.076402
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    cookie_0 = Cookie(str_1, cookie_jar_0)
    str_2 = 'Endpoint with name `'
    dict_0 = {}
    str_3 = "key"
    dict_0[str_3] = str_2
    str_4 = "value"
    cookie_0[str_4] = dict_0


# Generated at 2022-06-26 03:14:55.016635
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_1)


# Generated at 2022-06-26 03:15:21.474862
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # create a string
    str_0 = 'Endpoint with name `'
    # create a CookieJar
    cookie_jar_0 = CookieJar(str_0)
    # create a new cookie
    cookie_0 = Cookie('cookie_name', 'value')
    # add a cookie to the CookieJar
    cookie_jar_0['cookie_name'] = cookie_0
    # add the cookie to the headers
    cookie_jar_0.headers.add('Set-Cookie', cookie_0)
    # return the cookie formatted as a string
    cookie_0.__str__()


# Generated at 2022-06-26 03:15:23.798309
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:15:30.758548
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)

    dict_0 = dict()
    dict_0['key'] = 'p'
    dict_0['value'] = 'Dk-u&Jt]N$|I'
    dict_0['path'] = ';'
    dict_0['httponly'] = ''
    dict_0['max-age'] = 0
    dict_0['expires'] = datetime(2018, 4, 4, 14, 53, 31, 951882)
    dict_0['comment'] = 'G2K--'
    dict_0['domain'] = '}+S?Jj.{1'
    dict_0['version'] = 1
    dict_0['secure'] = ''
    dict_0['samesite']

# Generated at 2022-06-26 03:15:36.427253
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
  str_0 = 'Endpoint with name `'
  cookie_jar_0 = CookieJar(str_0)
  str_1 = 'Endpoint with name `'
  str_2 = 'cookie_name'
  cookie_jar_0[str_1] = str_2
  str_3 = 'Endpoint with name `'
  del cookie_jar_0[str_3]



# Generated at 2022-06-26 03:15:48.070593
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    #
    str_0 = 'cb43eb71d21161e3b944857e4cc46f4c'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'Path'
    assert not hasattr(cookie_0, str_1)
    str_1 = 'Refresh'
    str_2 = 'refresh'
    assert not hasattr(cookie_0, str_1)
    str_1 = 'P3P'
    str_2 = 'P3P'
    str_3 = '/'
    assert not hasattr(cookie_0, str_1)
    str_1 = 'SameSite'
    str_2 = 'SameSite'
    str_3 = 'SameSite'

# Generated at 2022-06-26 03:15:51.324769
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0.__delitem__()
    return None


# Generated at 2022-06-26 03:16:01.102818
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar('Endpoint with name `')
    cookie_0 = Cookie(cookie_jar_0, cookie_jar_0)
    cookie_0[cookie_jar_0] = cookie_jar_0
    cookie_0['Endpoint with name `'] = 'Endpoint with name `'
    cookie_0[cookie_0] = cookie_jar_0
    cookie_0[cookie_jar_0] = 'Endpoint with name `'
    cookie_0['Endpoint with name `'] = 'Endpoint with name `'
    cookie_0[cookie_0] = cookie_0
    cookie_0[cookie_jar_0] = cookie_0
    cookie_0[cookie_0] = 'Endpoint with name `'
    cookie_0[cookie_jar_0] = cookie_jar_0
    cookie

# Generated at 2022-06-26 03:16:04.142867
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    del cookie_jar_0["F"]


# Generated at 2022-06-26 03:16:08.142977
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    key_0 = ''
    val_0 = False
    cookie_jar_0.__setitem__(key_0, val_0)


# Generated at 2022-06-26 03:16:12.439694
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0.__delitem__('HttpOnly')
    assert 'Content-Type' in cookie_jar_0.headers
    assert 'Server' in cookie_jar_0.headers



# Generated at 2022-06-26 03:16:38.165996
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_1 = 'Endpoint with name `'
    cookie_jar_1 = CookieJar(str_1)
    cookie_1 = cookie_jar_1[str_1]
    str_2 = str_1
    cookie_1[str_2] = str_2
    str_3 = str_1
    str_4 = str_1
    cookie_1[str_3] = str_4
    str_5 = str_1
    del cookie_1[str_5]
    cookie_jar_1[str_1] += '` already exists!'
    str_6 = str_1
    str_7 = str_1
    cookie_1[str_6] = str_7
    str_8 = str_1
    del cookie_1[str_8]
    str_9 = str_1
   

# Generated at 2022-06-26 03:16:45.379923
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create a CookieJar object with header = 'Endpoint with name `'
    cookie_jar_0 = CookieJar('Endpoint with name `')

    # Try to delete the 'cookie_jar_key' key in the cookie_jar_0 object
    try:
        del cookie_jar_0['cookie_jar_key']

    # Catch Exception, if any
    except Exception as e:
        print('Exception: ', e)

    # Test method __setitem__ of class CookieJar
    def test_CookieJar___setitem__():

        # Create a CookieJar object with header = 'Endpoint with name `'
        cookie_jar_0 = CookieJar('Endpoint with name `')

        # Try to set the 'cookie_jar_key' key in the cookie_jar_0 object

# Generated at 2022-06-26 03:16:57.561255
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Encode the cookie content in a specific type of encoding instructed\n        by the developer. Leverages the :func:`str.encode` method provided\n        by python.\n\n        This method can be used to encode and embed ``utf-8`` content into\n        the cookies.\n\n        :param encoding: Encoding to be used with the cookie\n        :return: Cookie encoded in a codec of choosing.\n        :except: UnicodeEncodeError'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    cookie_jar_1 = CookieJar(str_1)

# Generated at 2022-06-26 03:17:00.590158
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Tests if `__str__()` method return value matches expected value
    cookie_0 = Cookie('key', 'value')
    assert(cookie_0.__str__() == "key=value")


# Generated at 2022-06-26 03:17:02.508230
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 03:17:06.035276
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Case 1
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)

# Generated at 2022-06-26 03:17:15.779882
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    cookie_jar_0["Endpoint with name `"] = str_1
    str_2 = 'Endpoint with name `'
    cookie_jar_1 = CookieJar(str_2)
    str_3 = 'Endpoint with name `'
    cookie_jar_1["Endpoint with name `"] = str_3
    str_4 = 'Endpoint with name `'
    cookie_jar_2 = CookieJar(str_4)
    str_5 = 'Endpoint with name `'
    cookie_jar_2["Endpoint with name `"] = str_5
    str_6 = 'Endpoint with name `'
    cookie_jar_3 = CookieJar

# Generated at 2022-06-26 03:17:16.542452
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    test_case_0()


# Generated at 2022-06-26 03:17:19.669676
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    jar = CookieJar(headers={})
    jar['example'] = Cookie('example', 'test')
    assert jar['example']['value'] == 'test'


# Generated at 2022-06-26 03:17:21.266495
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    test_case_0(str_0)

# Generated at 2022-06-26 03:17:39.140277
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_key_0 = 'Endpoint with name `'
    cookie_value_0 = 'Endpoint with name `'
    cookie_jar_0[cookie_key_0] = cookie_value_0


# Generated at 2022-06-26 03:17:44.195878
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Creating cookie jar
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)

    # Creating cookie with no value
    str_1 = 'L3\\'
    cookie_1 = Cookie(str_1, None)
    cookie_1['domain'] = '~:4'
    cookie_1['expires'] = '45'

    # Adding cookie to jar
    cookie_jar_0[str_1] = cookie_1

    # Deleting cookie from jar
    del cookie_jar_0[str_1]
    print(cookie_jar_0)

# Generated at 2022-06-26 03:17:47.771170
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    cookie_jar_0.__delitem__(str_1)


# Generated at 2022-06-26 03:17:56.973729
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({})
    str_0 = 'Endpoint with name `'
    str_1 = 'Endpoint with name `'
    cookie_jar_0.headers = {str_0: str_1}
    cookie_jar_0.header_key = 'Endpoint with name `'
    cookie_jar_0.cookie_headers = {str_0: str_1}
    str_2 = 'Endpoint with name `'
    str_3 = 'Endpoint with name `'
    cookie_jar_0['Endpoint with name `'] = str_2
    str_4 = 'Endpoint with name `'
    assert str_4 not in cookie_jar_0
    str_5 = 'Endpoint with name `'
    cookie_jar_0[str_5] = str_3
    str_

# Generated at 2022-06-26 03:18:05.424814
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'Endpoint with name `'
    str_2 = 'Endpoint with name `'
    cookie_jar_0[str_1] = str_2
    str_1 = 'Endpoint with name `'
    del cookie_jar_0[str_1]



# Generated at 2022-06-26 03:18:07.915350
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie()
    output_0 = cookie_0.__str__()
    assert (output_0 == None)


# Generated at 2022-06-26 03:18:12.145375
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = 'Expires=Mon, 02-Aug-2021 00:09:36 GMT; Max-Age=3600; Domain=; Path=/; '
    assert str_0 == str_1


# Generated at 2022-06-26 03:18:19.000679
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'test_name'
    cookie_1 = Cookie(str_1, 'test_value')
    str_2 = ';'
    cookie_1['Path'] = str_2
    cookie_1.key = 'test_name'
    str_3 = ''
    cookie_1['Comment'] = str_3
    str_4 = ';'
    cookie_1['Domain'] = str_4
    str_5 = ';'
    cookie_1['Max-Age'] = str_5
    str_6 = ';'
    cookie_1['Secure'] = str_6
    str_7 = ';'
    cookie_1['HttpOnly'] = str_7
    str_

# Generated at 2022-06-26 03:18:23.482036
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert True == True

# Generated at 2022-06-26 03:18:30.374717
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'A'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'A'
    cookie_jar_0['A'] = str_1
    str_2 = 'A'
    cookie_jar_0['A'] = str_2
    str_3 = 'CookieJar'
    assert_equals(str_3, type(cookie_jar_0).__name__)


# Generated at 2022-06-26 03:19:05.844214
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie('0F7V', 'E#Zm|&M<f')
    cookie_0['domain'] = '1.0a"F'
    cookie_0['expires'] = 'B6Ux2;k'
    str_1 = '0F7V=E#Zm|&M%3Cf; Domain=1.0a\\"F; Expires=B6Ux2;k'
    assert str(cookie_0) == str_1


# Generated at 2022-06-26 03:19:16.703804
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = Cookie(str_0, int_0)
    str_1 = 'Cookie `` not in cookie jar'
    int_0 = -10
    str_2 = 'Cookie name is a reserved word'
    str_3 = 'Cookie key contains illegal characters'
    int_1 = 1
    str_4 = 'Cookie expires not in cookie jar'
    str_5 = 'Cookie max-age must be an integer'
    str_6 = 'Cookie `` not in cookie jar'
    str_7 = 'Cookie `` not in cookie jar'
    str_8 = 'Cookie `` not in cookie jar'
    str_9 = 'Cookie expires not in cookie jar'
    
    
    # TEST CASE: Test deleting an item from the cookie jar
    key = str_0
    value = str_1


# Generated at 2022-06-26 03:19:26.353727
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('foo', 'bar')
    cookie_0['secure'] = True
    cookie_0['expires'] = datetime(2017, 3, 16, 17, 22, 10)
    cookie_0['max-age'] = DEFAULT_MAX_AGE
    cookie_0['comment'] = 'test'
    cookie_0['domain'] = '.test.com'
    cookie_0['path'] = '/test/test'
    cookie_0['httponly'] = True
    cookie_0['version'] = '1'
    str_0 = str(cookie_0)

# Generated at 2022-06-26 03:19:33.395080
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_key_0 = 'Endpoint with name `'
    cookie_value_0 = 'Endpoint with name `'
    cookie_0 = Cookie(cookie_key_0, cookie_value_0)
    if (not (cookie_0.key == cookie_key_0)):
        print(cookie_0.key)
        print(cookie_key_0)


# Generated at 2022-06-26 03:19:34.808375
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_case_0()

# Generated at 2022-06-26 03:19:44.498150
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = cookie_jar_0['Endpoint with name `']
    cookie_0.value = 'Cookie'
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = cookie_jar_0['Endpoint with name `']
    cookie_0.value = 'Cookie'
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = cookie_jar_0['Endpoint with name `']
    cookie_0.value = 'Cookie'
    str_0 = 'Endpoint with name `'

# Generated at 2022-06-26 03:19:48.978395
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    cookie_0 = Cookie('foo', 'bar')
    try:
        cookie_0['expires'] = False
        print('AssertionError expected')
    except AssertionError:
        print('AssertionError caught')

    try:
        cookie_0['expires'] = datetime.now()
    except Exception as e:
        print(e)
        print('Exception expected')


# Generated at 2022-06-26 03:19:52.432328
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Endpoint with name `'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie("j", "x2")
    cookie_0.__str__()


# Generated at 2022-06-26 03:19:58.098543
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    for _ in range(1000):
        str_0 = 'Endpoint with name `'
        key_name_0 = 'Name 0'
        value_0 = '"0"'
        cookie_jar_0 = CookieJar(str_0)

        cookie_jar_0[key_name_0] = value_0
        del cookie_jar_0[key_name_0]


# Generated at 2022-06-26 03:20:07.881210
# Unit test for method __str__ of class Cookie