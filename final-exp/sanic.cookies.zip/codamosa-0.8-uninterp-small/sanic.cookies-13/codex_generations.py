

# Generated at 2022-06-26 03:11:38.476163
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'_\x91\x92\xa1@\xee\x8f\x10\xc3\x1d\x0e\xa3\x80G\x95\x98'
    key_0 = '\x1d\xcd\x1b\xaa\xa4\x06\x84\xed\x8c'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0[key_0] = '!\xc9\x0f\x1c\x0a\xa3'
    cookie_jar_0[key_0] = '\x9e\xdc\xa8\xac\xf6\xd5\xd1\xdd\xb6;\x84\x9a'

# Generated at 2022-06-26 03:11:51.394559
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)

    # Assert that cookie_0 was added to cookie_jar_0
    cookie_0 = Cookie(None, None)
    cookie_0.value = None
    cookie_jar_0["a"] = cookie_0
    assert "a" in cookie_jar_0

    # Assert that cookie_1 was not added to cookie_jar_0
    with pytest.raises(KeyError):
        cookie_1 = Cookie(None, None)
        cookie_1.key = "test_cookie_key"
        cookie_jar_0[cookie_1]

# Generated at 2022-06-26 03:12:04.501904
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    value_0 = str("1")
    cookie_jar_0["\ufb94"] = value_0
    value_1 = str("1")
    cookie_jar_0["\ufb94"] = value_1

# Generated at 2022-06-26 03:12:15.670423
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b'\x91\x9e\xa8\xec\xcd\x1f\xd9\x08\x11\x98e\xce\xa5\x97'
    cookie_0 = Cookie(bytes_1, True)
    cookie_jar_0.__setitem__(cookie_0, 16.3)
    assert type(cookie_jar_0) == CookieJar


# Generated at 2022-06-26 03:12:22.591003
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    This test case could fail if CookieJar.__setitem__ modifies
    CookieJar.headers in place instead of reassigning a new dict,
    even if the result is logically equivalent.
    """
    bytes_0 = b'\x80D3\xab\x9a\xdeY\x94-\xe4\xca\xc6'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.__setitem__(1, (2 + 8))


# Generated at 2022-06-26 03:12:28.875242
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\xb9\x9c\xa8\x84\xb6\xec\xea?\xbc\x95\x1b\x9c\x8f\x82\xf03\x1e\xea\xe8\xfa\xa0\xa5'
    cookie_0 = Cookie(bytes_0, bytes_0)
    assert (
        cookie_0.__str__() == '`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0=`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    )
   

# Generated at 2022-06-26 03:12:39.081150
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'a\x03\x02\x00\x00'
    bytearray_0 = bytearray(str_0, 'utf-8')
    str_1 = 'a\x03\x02\x00\x00'
    bytearray_1 = bytearray(str_1, 'utf-8')
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0[bytearray(bytearray_0)] = bytearray(bytearray_1)

# Generated at 2022-06-26 03:12:51.418925
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = 'q3\x12'
    str_1 = '\x01+\x7f\x9b<5\x04\x1b\x10'
    # Assign Cookie[str_0] = str_1
    # Verify __setitem__ is working correctly by checking the return value
    str_2 = cookie_jar_0.__setitem__(str_0, str_1)
    assert str(str_2) == str(None)

    dict_0 = dict()
    dict_0["secure"] = False

# Generated at 2022-06-26 03:12:56.172709
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Setup
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    expected = "key=value"

    # Invoke
    result = str(cookie)

    # Verify
    assert result == expected



# Generated at 2022-06-26 03:13:05.528377
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'\xa3\x9a\x8d\x14\x80\x08:\x1d\xcc\x88\xae\x92\x9e\x0f'
    cookie_jar_1 = CookieJar(bytes_0)
    str_0 = 'q3\x9a\x8d\x14\x80\x08:g\x1d\xcc\x88\xae\x92\x9e\x0f'
    int_0 = cookie_jar_1.pop(str_0)
    print(cookie_jar_1)

# Generated at 2022-06-26 03:13:27.916708
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xec\x92\xa0\x8aUb\xda\xfc\xff\xe3\xd9\x06\x11\xc3\xcc \x18'
    headers_0 = {}
    headers_0['Host'] = 'localhost:5000'
    cookie_jar_0 = CookieJar(headers_0)
    cookie_0 = Cookie('key', 'value')
    cookie_0['path'] = '/'
    with pytest.raises(KeyError):
        cookie_0['path'] = 'hi'
    with pytest.raises(KeyError):
        cookie_0['path1'] = '/'
    with pytest.raises(KeyError):
        cookie_0['path1'] = 'hi'
    with pytest.raises(TypeError):
        cookie

# Generated at 2022-06-26 03:13:32.282228
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "test"
    value = "test"
    cookie_0 = Cookie(key, value)
    assert str(cookie_0) == "test=test"


# Generated at 2022-06-26 03:13:42.440002
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = CookieJar(b'\xba\xd3\xf4\x8e')
    cookie_jar_0 = Cookie('f?g\x9b\x95\xe5', '\x8d\xab\xb5\x90\x18\x8f\xe9')
    bytes_0.__setitem__('\x97\xa5\xa1\xb5', cookie_jar_0)
    string_0 = cookie_jar_0.__str__()
    assert string_0 == 'f?g\x9b\x95\xe5=Vy\x1b\x1a\x18\x80\xf3\xff\x8b\xffD\x1c'


# Generated at 2022-06-26 03:13:48.419969
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'

# Generated at 2022-06-26 03:14:00.406395
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Argument and test values
    key = sdl.random_string(0, 0, 2)


# Generated at 2022-06-26 03:14:06.001456
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_2 = Cookie("\x87bg\x9e\x9d\x13", bytes_0)
    cookie_jar_0.__delitem__(cookie_2)


# Generated at 2022-06-26 03:14:10.519571
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(100)
    key = "key"
    value = "value"
    cookie_jar_0[key] = value
    cookie_jar_0[key] = value
    key = "key"
    cookie_jar_0.__delitem__(key)


# Generated at 2022-06-26 03:14:17.747379
# Unit test for method __setitem__ of class Cookie

# Generated at 2022-06-26 03:14:22.796466
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = BytesIO()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    del cookie_jar["foo"]
    assert headers.getvalue() == b"Set-Cookie: foo=deleted; Max-Age=0; "



# Generated at 2022-06-26 03:14:26.678327
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(None)



# Generated at 2022-06-26 03:14:38.879364
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b't\x9b9\xd7\x94\xe9\x1c\x06\x7f\x85T\x7f\xc9\xb2^\x95\xf1\xb3\x1b\xe7\x97F\xdf\xa8\x9bB\x03\xe6\x1f\x06\xc1\xbf\x01\x0b\x9d^\x89\x1e\xc3\xd3\xaf'

# Generated at 2022-06-26 03:14:46.273774
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Task:
    # 1. Create an instance of CookieJar
    # 2. Call it with a key corresponding to a cookie
    # 3. Check that the cookie was deleted

    jar = CookieJar({})
    jar["test"] = "test"
    jar["test_number"] = 123
    del jar["test"]
    del jar["test_number"]
    if "test" not in jar:
        print("test_case_0")


# Generated at 2022-06-26 03:14:54.512423
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    key = 'test'
    value = 'value'
    cookiejar[key] = value
    cookiejar[key] = value
    assert key in cookiejar
    assert key in cookiejar.cookie_headers
    assert cookiejar.cookie_headers[key] in headers
    assert headers[cookiejar.cookie_headers[key]][0] == cookiejar[key]
    del cookiejar[key]
    assert key not in cookiejar
    assert cookiejar.cookie_headers[key] not in headers
    assert headers[cookiejar.cookie_headers[key]] == []


# Generated at 2022-06-26 03:15:01.500440
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = 'uheX9KjPQF'
    value = '\u202fhmZ\u202b\u202fLl\u202b\u202f'
    comment = '#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    domain = '\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    max_age = 6
    httponly = True
    version = 7
    same_site = 'L\u202f\u202b'
    cookie = Cookie(key, value)
    cookie['Comment'] = comment
    cookie['Domain'] = domain
    cookie['Max-Age'] = max_age
    cookie['HttpOnly'] = httponly

# Generated at 2022-06-26 03:15:08.228943
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["id"] = "test"
    assert("id=test" in headers.get("Set-Cookie"))
    del cookie_jar["id"]
    assert("id=test" not in headers.get("Set-Cookie"))


# Generated at 2022-06-26 03:15:10.664413
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'key'
    value = 'value'
    cookie = Cookie(key, value)
    cookie.__setitem__(key, value)


# Generated at 2022-06-26 03:15:20.761478
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    path = b'/home/ubuntu/workspace/bs4/tests/data'
    path_0 = path
    directory_0 = os.listdir(path_0.decode())
    path_1 = path
    directory_1 = os.listdir(path_1.decode())
    path_2 = path
    directory_2 = os.listdir(path_2.decode())
    path_3 = path
    directory_3 = os.listdir(path_3.decode())
    path_4 = path
    directory_4 = os.listdir(path_4.decode())
    path_5 = path
    directory_5 = os.listdir(path_5.decode())
    path_6 = path
    directory_6 = os.listdir(path_6.decode())
    path_7

# Generated at 2022-06-26 03:15:29.335160
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Initializes headers with a MultiDict
    headers = MultiDict({"Set-Cookie": "Cookie_1=Cookie_1",})
    # Initializes CookieJar with the MultiDict, headers
    cookie_jar = CookieJar(headers)
    # Initializes CookieJar_state with a string
    CookieJar_state = 'Cookie_1'
    # Sets key to the CookieJar_state
    key = CookieJar_state
    # Sets value to the cookie
    value = "Cookie_1"
    # Sets cookie_header to the header
    cookie_header = "Set-Cookie"
    # Sets cookie to the cookie
    cookie = cookie_header
    # Sets cookie to the key, value
    cookie = Cookie(key, value)
    # Sets cookie to the cookie, path
    cookie["path"] = "/"

# Generated at 2022-06-26 03:15:40.536931
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xd6\xf7\x90\xda\xab1\xce\x05V\x07\xf2\x90\x83\xecW\x9b\xbe\xd3\x8c\x93H\xf2\xe7[\xec\xd6\xef\xde\x99\xfe\x8a\xed\xcc\xc7\x00\xb8\xddu'

# Generated at 2022-06-26 03:15:42.327013
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    instance = Cookie(key = str(), value = str())
    assert str(instance)


# Generated at 2022-06-26 03:15:57.758023
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-26 03:16:06.892471
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "key"
    value = "value"

    cookie = Cookie(key, value)
    assert str(cookie) == 'key=value'
    cookie["max-age"] = 1
    cookie["expires"] = datetime(2019, 1, 1)
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"


# Generated at 2022-06-26 03:16:14.070691
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key = "test_key"
    value = "example"
    cookie = Cookie( key, value )
    # test for __str__

    result = str( cookie )
    assert cookie == {}, "Failed to raise exception on missing 'expires'"

    cookie["expires"] = "Wed, 31-Jul-2019 14:07:06 GMT"
    result = str( cookie )
    assert result == "test_key=example; Expires=Wed, 31-Jul-2019 14:07:06 GMT", "Failed to raise exception on missing 'expires'"


# Generated at 2022-06-26 03:16:17.632930
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar()
    cookie_jar["name"] = "value"
    del cookie_jar["name"]
    assert cookie_jar.headers["Set-Cookie"] == "name=; max-age=0"


# Generated at 2022-06-26 03:16:24.974660
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\xa6\xc7\x97\xab\x1e\xc2\x0f\x9a\xd7s\xb3\xc3\xa2\x98\x13\x8b'
    bytes_1 = b'\x88\x8f\x91\x14\xb6\x0c\x8a\x1c\xac\xca\x0e\x05\xc0\xcf\x11\xb8'
    bytes_2 = b'\xca\x1d\xecr\xd5\x96\xcc\x8a\xdd\x9e\xa1'

# Generated at 2022-06-26 03:16:28.370960
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
  try:
    obj = Cookie('0', '1')
    obj['path'] = '/'
    obj['max-age'] = 0
    obj.__str__()

  except Exception as e:
    print(str(e))


# Generated at 2022-06-26 03:16:30.969417
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'key'
    value = 'value'
    c = Cookie(key, value)
    c.__setitem__('path', '/')


# Generated at 2022-06-26 03:16:33.124615
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert Cookie('key', 'value').__str__() == 'key=value'


# Generated at 2022-06-26 03:16:38.121398
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Assert: AssertionError is thrown
    try:
        case_0 = Cookie('h', '0{')
    except AssertionError as e:
        assert type(e) == AssertionError
    else:
        assert False


# Generated at 2022-06-26 03:16:46.011363
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:17:02.587990
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key_0', 'value_0')
    # Test for case 0
    cookie["max-age"] = 0
    assert(str(cookie) == 'key_0=value_0; Max-Age=0')
    # Test for case 1
    cookie["max-age"] = 1
    assert(str(cookie) == 'key_0=value_0; Max-Age=1')
    # Test for case 2
    cookie["max-age"] = 100
    assert(str(cookie) == 'key_0=value_0; Max-Age=100')
    # Test for case 3
    cookie["max-age"] = str(10)
    assert(str(cookie) == 'key_0=value_0; Max-Age=10')
    # Test for case 4

# Generated at 2022-06-26 03:17:12.983785
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Tests for cookie __setitem__ for three different scenarios
    # In the first scenario, we try to set a valid key-value pair
    # In the second, we try to set an invalid key
    # In the third, we attempt to set a key which is a reserved word, but with a value that's not False
    # And in the last, we attempt to set a key which is a valid reserved word, with a value of False

    # First test: We try to set a valid key-value pair
    key = "test"
    valid_value = "yes"
    Cookie[key] = valid_value

    # Second test: We try to set an invalid key
    invalid_key = "t_e_s_t"
    value = "yes"

    # Third test: We try to set a key which is a reserved word, but with a value that's

# Generated at 2022-06-26 03:17:15.878813
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\x01\x12\x14\x1c\x1dJ3\x1c\xed\xc8\x9d\xa0\x08\x92\x98'
    bytes_1 = b'\x01\x12\x14\x1c\x1dJ3\x1c\xed\xc8\x9d\xa0\x08\x92\x98'
    str_0 = '; '.join(output)
    str_1 = '; '.join(output)


# Generated at 2022-06-26 03:17:20.072018
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test for __str__ of class Cookie

    # Init a Cookie object
    x = Cookie('test', 'test')

    # Add a new attribute to test
    x['secure'] = True

    # Must be a string
    assert(isinstance(str(x), str))


# Generated at 2022-06-26 03:17:26.383592
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    str_0 = str(bytes_0)
    cookie = Cookie(str_0, str(bytes_0))
    str_1 = str(cookie)
    assert str_1 == str(bytes_0)


# Generated at 2022-06-26 03:17:34.617377
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    key = '_'
    value = bytes_0
    cookie_jar.__setitem__(key, value)
    value = bytes_0
    cookie_jar.__setitem__(key, value)
    value = bytes_0
    cookie_jar.__setitem__(key, value)
    value = ' '
    cookie_jar.__setitem__(key, value)
    value = bytes_0
    cookie_jar.__setitem__(key, value)



# Generated at 2022-06-26 03:17:38.790153
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar["asdf"] = "qwer"
    assert isinstance(cookie_jar["asdf"], Cookie)
    assert headers["Set-Cookie"] == "asdf=qwer; Path=/"


# Generated at 2022-06-26 03:17:45.096575
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDictProxy(MultiDict())
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key"] = "value"
    cookie_jar["key"] = "value"
    cookie_jar["key"] = "value"
    headers = MultiDictProxy(MultiDict())
    cookie_jar = CookieJar(headers)
    cookie_jar["key"] = "value"
    cookie_jar["key"] = "value"
    cookie_jar["key"] = "value"
    cookie_jar["key"] = "value"
    del cookie_jar["key"]

# Generated at 2022-06-26 03:17:55.537309
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = b'\xb4-\xbc\x80\xff\x0b\x84\xb7\xed\xc3\x9c\xe5'

# Generated at 2022-06-26 03:17:56.896962
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass


# Generated at 2022-06-26 03:18:11.811716
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    fixture1 = {
        "expires": "expires",
        "path": "Path",
        "comment": "Comment",
        "domain": "Domain",
        "max-age": "Max-Age",
        "secure": "Secure",
        "httponly": "HttpOnly",
        "version": "Version",
        "samesite": "SameSite",
    }
    cookie_0 = Cookie("key", "value")
    for key, value in fixture1.items():
        cookie_0[key] = value
    cookie_0["security"] = "security"
    assert cookie_0.__str__() == 'key="value"; Max-Age=Max-Age; expires=expires; HttpOnly'



# Generated at 2022-06-26 03:18:18.814209
# Unit test for method __setitem__ of class CookieJar

# Generated at 2022-06-26 03:18:26.298332
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'\x1e\x1c'
    cookie_0 = Cookie(bytes_0, bytes_0)
    str_0 = str(cookie_0)
    assert str_0 == str('`#')

# Generated at 2022-06-26 03:18:37.968399
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:18:46.703637
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\x19#\xb6\xa9\xf9N\xe06\xfa\xfc\xaa\xd8\xec\xfd\x1f\x0f\xe4\x06\xad\xab\xba\x80\x07\x14\xd4'
    cookie_jar_0 = CookieJar(bytes_0)

    # Test cases for exception KeyError
    try:
        key = None
        value = None
        cookie_jar_0[key] = value
        raise Exception("Expected exception: KeyError")
    except Exception as e:
        if e.args[0] != "Cookie name is a reserved word":
            raise


# Generated at 2022-06-26 03:18:53.937715
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar({b'c': b'p'})
    cookie = cookie_jar_0[b'c']
    cookie['max-age'] = -1.9103148248901233
    cookie['domain'] = b'c'
    cookie['path'] = b'p'
    cookie['samesite'] = b'lax'
    cookie['comment'] = b'c'
    cookie['expires'] = datetime(2014, 2, 13, 2, 8, 46, 114076)
    cookie['version'] = b''
    cookie['secure'] = b''
    cookie['httponly'] = b'httponly'
    str_0 = str(cookie)

# Generated at 2022-06-26 03:18:57.325592
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    # Make the following code break so we can see it easier in the test
    # output.
    if not False:
        return

    # Write your code here
    pass



# Generated at 2022-06-26 03:19:07.871839
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    bytes_0 = b'O\xbf\x19\x80\x89\x8a\x86\xb9\xc7\xd0\x8e\x83\xdao\xc3\x1f\x9d|\xbc'
    bytes_1 = b'\xed\xd6\x98\xc1\xfa\xf6\x0c\xde\x92\x0f\xaa\x1c\x115\xc4\xef\x9c\x9c\x0b\x1b\\\x12\x0b\x96\xc6\x8d\xe4\x9f\xc6\xe8\xed\xac\xbf\xe4\xef\xcc\x91\x9a\xc5'
    bytes_

# Generated at 2022-06-26 03:19:13.111898
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Testing dictionary
    headers = {
        "key_0": 1,
        "key_1": 2,
        "key_2": 3,
    }
    cookie_jar_0 = CookieJar(headers)
    for key in headers.copy():
        del headers[key]
        assert headers == cookie_jar_0.headers


# Generated at 2022-06-26 03:19:16.744750
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar( )
    cookie_jar_0['Pytest'] = 'test'
    print(cookie_jar_0)
    del cookie_jar_0['Pytest']
    print(cookie_jar_0)



# Generated at 2022-06-26 03:19:36.453542
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = 'y\xa0\xba\xb9\xd64.\x9cx\x8e\x17\xf2\x94\x83\xcc'
    cookie_jar_0[str_0] = False
    assert str_0 in cookie_jar_0


# Generated at 2022-06-26 03:19:46.251478
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'&\xd5\x0e\x8e\xa8\x07\xa3\x99\xab\x9a\xcf\xd2\x18\x8e\x1f'
    key_0 = '\x8b\x9ag\x91\x19\xbf\xd6'
    value_0 = '\x9e\x8b\x9ag\x91\x19\xbf\xd6'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0.Cookie(key_0, value_0)
    str_0 = str(cookie_jar_0)
    str_1 = cookie_jar_0.__str__()
    str_2 = str(cookie_jar_0)
    str_3

# Generated at 2022-06-26 03:19:53.504885
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    byte_0 = b'\xdc'
    byte_1 = b'!'
    byte_2 = b'\xc4'
    byte_4 = b'\xba'
    byte_6 = b'\xe7'
    byte_8 = b'\xe9'

    # Test 1 - Cookie is empty
    cookie_jar_0 = CookieJar(byte_0)
    cookie_jar_0.__delitem__(byte_1)

    # Test 2 - Cookie is not empty
    cookie_jar_0 = CookieJar(byte_2)
    cookie_jar_0.__delitem__(byte_4)
    cookie_jar_0.__delitem__(byte_6)
    cookie_jar_0.__delitem__(byte_8)


# Generated at 2022-06-26 03:20:03.760456
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'\x8d\xee\x1dG\x0b\xcc\xe5\xf9m\x92\x9c\xc8\xd7\x03\x17'
    cookie_jar_0 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_0['comment'] = False
    cookie_jar_1 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_1['max-age'] = False
    cookie_jar_2 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_2['domain'] = False

# Generated at 2022-06-26 03:20:05.630926
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        CookieJar.__delitem__
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 03:20:12.544557
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_0.__setitem__("h\xde\xb2\x8c\x9eZ\x9d\x9e", "h\xde\xb2\x8c\x9eZ\x9d\x9e")



# Generated at 2022-06-26 03:20:23.042936
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test 0
    bytes_0 = b'\x9a\x03\xd6\x04\x06\x08\x15\x17\x18\x1c\x1e\xf3\xa3\x83\x1c\xb1'
    cookie_jar_0 = CookieJar(bytes_0)

    # Test 1
    bytes_1 = b'\x81\x93\xf0\x9b\x84\x14\x1f\xb8\xfb\x81\x95\xe0\x97\x90'
    cookie_jar_1 = CookieJar(bytes_1)

    # Test 2

# Generated at 2022-06-26 03:20:29.424999
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'`!\xb5\xcf^\x81#\xa2\x87\xc6\xa1\x0b\xd5Oy\xb4\xa8\xf0'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0["cookie_2"] = "cookie value"
    cookie_jar_0["cookie_1"] = "cookie value"
    cookie_jar_0["cookie_1"] = "cookie value"
    pass


# Generated at 2022-06-26 03:20:32.662044
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0.cookie_headers = {"httponly": "Set-Cookie"}
    cookie_jar_0["httponly"] = "httponly"
    assert cookie_jar_0.cookie_headers == {"httponly": "Set-Cookie"}



# Generated at 2022-06-26 03:20:35.159768
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(bytes)
    cookie_jar_0[None] = None
    del cookie_jar_0[None]


# Generated at 2022-06-26 03:21:03.598825
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    try:
        test_case_0()
    except:
        print('Exception in test case: ', sys.exc_info()[0])

if __name__ == "__main__":
    print("Unit test for class CookieJar")
    test_CookieJar___setitem__()
    print("Done")

# Generated at 2022-06-26 03:21:09.045316
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = ""
    value = ""
    cookie_0 = Cookie(key, value)
    key = "testcase.cs"
    value = "testcase.cs"
    cookie_0 = Cookie(key, value)
    key = "testcase.cs"
    value = "testcase.cs"
    cookie_0 = Cookie(key, value)


# Generated at 2022-06-26 03:21:12.774718
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-26 03:21:19.896105
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'N\xeb\x1d\xc5%\xbd\xe7\xe4\xcc\x8c\x93\xce\xf6\x97\xb71\x10\x9e\x17\x8a\xfe'
    cookie_jar_0 = CookieJar(bytes_0)
    byte_array_0 = bytearray([47, 114, 107, 110, 59, 70, 101, 47, 110, 118, 113, 58, 71, 0])
    cookie_jar_0.__setitem__(byte_array_0, True)
    cookie_jar_0.__delitem__(byte_array_0)
    assert len(cookie_jar_0.headers) == 0
    assert cookie_jar_0 == {}

