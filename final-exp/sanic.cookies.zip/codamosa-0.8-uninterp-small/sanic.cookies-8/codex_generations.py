

# Generated at 2022-06-26 03:11:35.789459
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'relief'
    cookie_jar_0.__setitem__(str_0, str_1)
    str_2 = 'str'
    str_3 = 'str'
    str_4 = 'str'
    str_5 = 'str'
    str_6 = 'str'
    str_7 = 'str'
    str_8 = 'str'
    str_9 = 'str'
    str_10 = 'str'
    str_11 = 'str'

# Generated at 2022-06-26 03:11:47.290064
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'costume'
    cookie_0 = Cookie(str_0, True)
    cookie_1 = Cookie(None, False)
    str_1 = None
    str_2 = 'landlord'
    cookie_2 = Cookie(str_1, False)
    str_3 = 'httponly'
    cookie_3 = Cookie(str_3, True)
    cookie_3['expires'] = datetime.now()
    str_4 = 'transcribe'
    cookie_4 = Cookie(str_4, True)
    str_5 = None
    cookie_5 = Cookie(str_4, False)
    cookie_5['expires'] = datetime.now()
    str_6 = '{-H\\'
    cookie_6 = Cookie(str_6, True)

# Generated at 2022-06-26 03:11:48.881143
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_case_0()

test_CookieJar___delitem__()

# Generated at 2022-06-26 03:11:56.452699
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    assert_equal(
        cookie_jar_0.__setitem__('foo', True), None, 'assert_equal failed at line nil')
    assert_equal(
        cookie_jar_0.__setitem__('bar', False), None, 'assert_equal failed at line nil')
    assert_equal(
        cookie_jar_0.__setitem__('baz', 'boo'), None, 'assert_equal failed at line nil')


# Generated at 2022-06-26 03:12:05.402159
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Demonstrate expected behavior
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0['login'] = 'becky'
    try:
        del cookie_jar_0['login']
    except KeyError:
        pass
    str_1 = 'backlog'
    cookie_jar_1 = CookieJar(str_1)
    cookie_jar_1['login'] = 'becky'
    try:
        del cookie_jar_1['login']
    except KeyError:
        pass
    # Force an exception
    str_2 = 'cookie'
    cookie_jar_2 = CookieJar(str_2)
    try:
        del cookie_jar_2['login']
    except KeyError:
        pass
    str_3 = 'cookie'
   

# Generated at 2022-06-26 03:12:11.402096
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'T'
    str_1 = 'c'
    str_2 = 'test'
    cookie_0 = Cookie(str_0, str_1)
    cookie_0['test'] = str_2
    str_2 = cookie_0.__str__()
    # Test for method __str__ of class Cookie
    assert str_2 == 'T=c; test=test'


# Generated at 2022-06-26 03:12:15.633592
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    cookie_0 = Cookie('key', 'value')
    assert cookie_0.__str__() == 'key=value'



# Generated at 2022-06-26 03:12:16.994844
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie_0 = Cookie(str_0, str_0)
    assert str(cookie_0) == cookie_0.__str__()


# Generated at 2022-06-26 03:12:19.269439
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    key_0 = 'backlog'
    value_0 = 'backlog'
    cookie_jar_0.__setitem__(key_0, value_0)
    assert key_0 == cookie_jar_0.__getitem__(key_0)


# Generated at 2022-06-26 03:12:25.156065
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_jar_0 = CookieJar(str)
    str_0 = 'backlog'
    str_1 = 'notify'
    str_2 = 'backlog'
    cookie_jar_0.__setitem__(str_0, str_1)
    cookie_jar_0.__setitem__(str_2, str_1)
    assert len(cookie_jar_0) == 2, 'Expected 2, got %s' % str(len(cookie_jar_0))


# Generated at 2022-06-26 03:12:32.962080
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Test case 0
    str_0 = 'repenetrate'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'backlog'
    cookie_jar_0.__delitem__(str_1)


# Generated at 2022-06-26 03:12:41.473453
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar()
    # Test 0
    assert str(cookie_jar_0) == ''

    cookie_jar_1 = CookieJar()
    # Test 1
    assert str(cookie_jar_1) == ''

    cookie_jar_2 = CookieJar()
    # Test 2
    assert str(cookie_jar_2) == ''

    cookie_jar_3 = CookieJar()
    # Test 3
    assert str(cookie_jar_3) == ''

    cookie_jar_4 = CookieJar()
    # Test 4
    assert str(cookie_jar_4) == ''

    cookie_jar_5 = CookieJar()
    # Test 5
    assert str(cookie_jar_5) == ''

    cookie_jar_6 = CookieJar()
    # Test 6

# Generated at 2022-06-26 03:12:46.317550
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    str_1 = 'value'
    cookie_0 = Cookie(str_0,str_1)
    assert str(cookie_0) == 'backlog=value'


# Generated at 2022-06-26 03:12:48.782662
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test for test_case_0
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0[str_0] = str_1 = 'reproducibility'
    assert str_1 == cookie_jar_0[str_0]


# Generated at 2022-06-26 03:12:53.271247
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'fav-color'
    cookie_jar_0 = CookieJar(str_0)
    # KeyError
    try:
        cookie_jar_0 = CookieJar(str_0)
    except KeyError as e:
        print(e)
    except Exception as e:
        print(e)



# Generated at 2022-06-26 03:13:04.082223
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("Test: Cookie.__setitem__")
    str_0 = '{"expires": ",", "path": "max-age", "comment": "Comment", "domain": "max-age", "secure": "\\u0000"}'
    cookie_1 = Cookie('j', 'h')
    cookie_1["domain"] = 'QP*'
    r = cookie_1["domain"]
    assert cookie_1["domain"] == 'QP*'
    assert r == 'QP*'
    cookie_1["expires"] = '$'
    r = cookie_1["expires"]
    assert cookie_1["expires"] == '$'
    assert r == '$'
    cookie_1["path"] = 'k'
    r = cookie_1["path"]

# Generated at 2022-06-26 03:13:13.283265
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'cameo'
    cookie_jar_0 = CookieJar(str_0)
    key_0 = 'owes'
    value_0 = 'typewriter'
    # setting a cookie in the cookie jar via __setitem__
    cookie_jar_0[key_0] = value_0
    key_1 = 'owes'
    value_1 = 'typewriter'
    # verify that the cookie jar was set correctly
    assert cookie_jar_0[key_1] == value_1


# Generated at 2022-06-26 03:13:27.208213
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('cookie_0', 'cookie_0')
    assert str(cookie_0) == 'cookie_0=cookie_0', 'Expected different value for str'
    assert str(cookie_0) != 'cookie_0=cookie_1', 'Expected different value for str'
    assert str(cookie_0) != 'cookie_0=cookie_0; max-age=0', 'Expected different value for str'
    assert str(cookie_0) != 'cookie_0=cookie_0; expires=Thu, 01-Jan-1970 00:00:00 GMT', 'Expected different value for str'
    assert str(cookie_0) != 'cookie_0=cookie_0; path=/', 'Expected different value for str'


# Generated at 2022-06-26 03:13:32.999315
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    
    # Constants
    str_0 = 'key_2'
    str_1 = 'value_2'
    str_2 = 'path'
    str_3 = 'path_value'
    str_4 = 'key_0'
    str_5 = 'value_0'
    str_6 = 'key_1'
    str_7 = 'value_1'
    
    # Call procedure __setitem__
    cookie_0 = Cookie(str_0, str_1)
    cookie_0[str_2] = str_3
    
    # Assert the result
    assert cookie_0[str_2] == str_3


# Generated at 2022-06-26 03:13:37.279512
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie_0 = Cookie(str_0, str_0)
    res_0 = cookie_0.__str__()
    assert res_0 == 'backlog=backlog'


# Generated at 2022-06-26 03:13:44.983210
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'return'
    cookie_jar_0 = CookieJar(str_0)
    key_0 = 'lung'
    value_0 = 'commutable'
    cookie_jar_0[key_0] = value_0
    cookie_jar_0[key_0]
    del cookie_jar_0[key_0]


# Generated at 2022-06-26 03:13:51.311418
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'mook'
    str_2 = 'chew'
    cookie_jar_0[str_1] = str_2
    assert cookie_jar_0[str_1] == str_2


# Generated at 2022-06-26 03:13:55.426401
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'w'
    str_1 = 'cookie'
    # test that cookie name is not a reserved word
    assert_raises(KeyError, Cookie, str_0, str_1)
    # test that cookie name does not contain illegal characters
    assert_raises(KeyError, Cookie, str_1, str_0)
    # success case
    cookie_0 = Cookie(str_1, str_1)
    str_2 = 'path'
    cookie_0[str_2] = '/'
    assert_equals({str_2: '/'}, cookie_0)


# Generated at 2022-06-26 03:14:05.568735
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    # Call method __setitem__
    # from class Cookie
    key = 'Y6l'
    value = 'Sx'
    #
    # Call of method __setitem__ of class Cookie.
    # Parameters:
    #   key: string
    #   value: string
    #
    key = 'Y6l'
    value = 'Sx'
    cookie_0 = cookie_jar_0[key] = value
    #
    # Call parameterized constructor of class Cookie
    # Parameters:
    #   key: string
    #   value: string
    #
    key = 'Y6l'
    value = 'Sx'
    cookie_1 = Cookie(key, value)
    # Verifying attributes of

# Generated at 2022-06-26 03:14:15.396591
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    cookie_jar_0[str_0] = str_0
    cookie_jar_0[str_0] = cookie_jar_0[str_0]
    assert 'expires' not in cookie_jar_0[str_0]
    cookie_jar_0[str_0] = 1407620187
    cookie_jar_0[str_0] = 'backlog'
    cookie_jar_0[str_0] = 'backlog'
    cookie_jar_0[str_0] = 'backlog'
    str_1 = 'expires'
    cookie_jar_0[str_1] = str_1
    cookie_jar_0.__delitem__(str_1)

# Generated at 2022-06-26 03:14:21.092635
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_1 = 'backlog'
    cookie_jar_1 = CookieJar(str_1)
    cookie_0 = cookie_jar_1['backlog']
    str_2 = cookie_0.__str__()
    print(str_2)


# Generated at 2022-06-26 03:14:22.721401
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    str_1 = 'E'
    str_2 = 'S'
    cookie_jar_0[str_1] = str_2


# Generated at 2022-06-26 03:14:27.491819
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'backlog'
    cookie_jar_0 = CookieJar(str_0)
    key_0 = 'test'
    value_0 = True
    cookie_jar_0[key_0] = value_0
    value_1 = cookie_jar_0[key_0]
    assert value_0 == value_1


# Generated at 2022-06-26 03:14:31.135195
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie_0 = Cookie(str_0, str_0)
    str_1 = cookie_0.__str__()
    print(str_1)


# Generated at 2022-06-26 03:14:34.523948
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Dict[str, str]()
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'backlog'
    assert (cookie_jar_0.__delitem__(str_0) == None)


# Generated at 2022-06-26 03:14:47.155474
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    '''Unit test for method __delitem__ of class CookieJar'''
    # Initialize a CookieJar object
    # cj = CookieJar()
    cj = CookieJar({'Set-Cookie': '{name}={value};'})
    # Add one cookie
    cj['theone'] = 'nothing'

    # Del the previously added cookie
    del cj['theone']

    # Expect all headers to be empty
    assert cj.cookie_headers == {}
    assert cj.headers == {}


# Generated at 2022-06-26 03:14:54.641651
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    # Create an instance of the class
    headers = {}
    instance = CookieJar(headers)

    # Configure some private variables
    instance.cookie_headers = {}
    instance.header_key = 'Set-Cookie'

    # Configure the class instance
    key = str_0
    value = str_0

    # Call the method being tested
    instance[key] = value

    # Check the results
    assert instance.cookie_headers[key] == 'Set-Cookie'
    assert instance.headers['Set-Cookie'][key] == value


# Generated at 2022-06-26 03:14:57.576320
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookiejar_instance_0 = CookieJar(headers)
    key_str_0 = 'backlog'
    cookiejar_instance_0.delitem(key_str_0)
    assert True


# Generated at 2022-06-26 03:15:00.311942
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('key', 'value')
    cookie_1 = Cookie('key', 'value')
    cookie_0.__str__()
    assert(cookie_0 == cookie_1)



# Generated at 2022-06-26 03:15:09.154687
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    key_0 = 'test'
    cookie = Cookie(key_0, 'test')
    cookie['path'] = '/'
    cookie_jar.cookie_headers[key_0] = 'Set-Cookie'
    cookie_jar.headers.add('Set-Cookie', cookie)
    cookie_jar.__delitem__(key_0)
    assert(not cookie_jar.cookie_headers.get(key_0))


# Generated at 2022-06-26 03:15:19.777670
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'backlog'
    dict_0 = dict()
    dict_1 = dict()
    dict_2 = dict()
    dict_3 = dict()
    dict_4 = dict()
    dict_5 = dict()
    dict_6 = dict()
    dict_7 = dict()
    dict_8 = dict()
    dict_9 = dict()
    dict_10 = dict()
    dict_11 = dict()
    dict_12 = dict()
    dict_13 = dict()
    dict_14 = dict()
    dict_15 = dict()
    dict_16 = dict()
    dict_17 = dict()
    dict_18 = dict()
    dict_19 = dict()
    dict_20 = dict()
    dict_21 = dict()
    dict_22 = dict()

# Generated at 2022-06-26 03:15:28.905360
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    with pytest.raises(KeyError):
        # str_0 = 'backlog'
        Cookie('backlog', 'string_0')['backlog'] = 'string_1'
    with pytest.raises(KeyError):
        # str_0 = 'backlog'
        Cookie('backlog', 'string_0')['string_1'] = 'string_1'
    with pytest.raises(KeyError):
        # str_0 = 'backlog'
        Cookie('backlog', 'string_0')['expires'] = 'string_0'
    with pytest.raises(KeyError):
        # str_0 = 'backlog'
        Cookie('backlog', 'string_0')['version'] = 'string_2'

# Generated at 2022-06-26 03:15:31.481509
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'backlog'

    jar = CookieJar({})
    jar[str_0] = '20'


# Generated at 2022-06-26 03:15:36.073023
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # ARRANGE
    str_0 = 'backlog'
    str_1 = 'urgent'
    # ACT
    c = Cookie(str_0, str_1)
    r = c.__str__()
    # ASSERT
    assert r == 'backlog=urgent'


# Generated at 2022-06-26 03:15:39.876248
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Initialize some parameters
    key = 'key_0'
    value = True

    # Constructing the object with the parameter
    obj = CookieJar(key)

    # Calling the method to test
    obj.__delitem__(value)


# Generated at 2022-06-26 03:15:55.324859
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # setup
    cookie1 = Cookie("name", "Bob")
    cookie1["httponly"] = "httponly"
    cookie1["max-age"] = 123
    # assert
    assert str(cookie1) == 'name=Bob; Max-Age=123; HttpOnly'
    # teardown
    del cookie1


# Generated at 2022-06-26 03:15:59.128871
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'backlog'

    # Case 0
    headers = MultiHeaders()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = str_0

    assert headers.getlist("Set-Cookie")[0] == f"name={str_0}"



# Generated at 2022-06-26 03:16:01.880600
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        test_case_0()
    except KeyError:
        print("KeyError")
    except ValueError:
        print("ValueError")
    except TypeError:
        print("TypeError")
    except:
        print("Exception")


# Generated at 2022-06-26 03:16:07.691677
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'

    assert "backlog=None" == str(Cookie(str_0, None))

    assert "backlog=''" == str(Cookie(str_0, ''))

    str_1 = 'value'
    assert "backlog='value'" == str(Cookie(str_0, str_1))



# Generated at 2022-06-26 03:16:10.623214
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    obj = Cookie(str_0, str_0)
    ret = obj.__str__()
    assert ret == 'backlog=backlog'


# Generated at 2022-06-26 03:16:13.259614
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie_1 = Cookie(str_0, '')
    assert (cookie_1.__str__() == 'backlog=')


# Generated at 2022-06-26 03:16:22.513857
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_cookie = Cookie("value_0", "str_0")
    assert str(test_cookie) == "value_0=str_0"

    test_cookie["domain"] = "str_0"
    assert str(test_cookie) == "value_0=str_0; Domain=str_0"

    test_cookie["path"] = "str_1"
    assert str(test_cookie) == "value_0=str_0; Domain=str_0; Path=str_1"

    test_cookie["version"] = "str_2"
    assert str(test_cookie) == "value_0=str_0; Domain=str_0; Path=str_1; Version=str_2"

    test_cookie["max-age"] = 10

# Generated at 2022-06-26 03:16:32.703823
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Case 1
    try:
        key_0 = 'expires'
        value_0 = datetime.now()
        cookie = Cookie(key = key_0, value = value_0)
        cookie.__setitem__(key_0, value_0)
    except KeyError as e:
        print("KeyError caught: " + str(e))
    except Exception as e:
        print("Unexpected exception caught in test_Cookie___setitem___case_1: " + str(e))
    else:
        print("AssertionError caught in test_Cookie___setitem___case_1")

    # Case 2

# Generated at 2022-06-26 03:16:41.985978
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        str_0 = "Set-Cookie"
        try:
            dict_0 = {str_0}
            try:
                cookie = Cookie(dict_0, str_0)
            except ValueError:
                cookie = Cookie(str_0, dict_0)
            try:
                test_case_0()
            except TypeError:
                cookie['expires'] = "Set-Cookie"
            except KeyError:
                cookie['path'] = dict_0
        except ValueError:
            cookie = Cookie(str_0, dict_0)
    except TypeError:
        cookie = Cookie(dict_0, str_0)


# Generated at 2022-06-26 03:16:44.023489
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie()
    cookie.key = str_0
    assert(cookie.__str__() == 'backlog')


# Generated at 2022-06-26 03:17:06.371165
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # test cookie
    cookie = Cookie('key', 'value')

    # test key and value
    cookie['key'] = 'value'
    
    # test that it raises error when key is a reserved word
    try:
        cookie['expires'] = 'value'
    except KeyError as e:
        print(e)

    # test that it raises error when key is not legal
    try:
        cookie['key-with-minus'] = 'value'
    except KeyError as e:
        print(e)




# Generated at 2022-06-26 03:17:16.077338
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    str_1 = 'backlog'
    str_2 = 'backlog'
    str_3 = 'backlog'
    str_4 = 'backlog'
    str_5 = 'backlog'
    str_6 = 'backlog'
    str_7 = 'backlog'
    str_8 = 'backlog'
    str_9 = 'backlog'
    str_10 = 'backlog'
    str_11 = 'backlog'
    str_12 = 'backlog'
    str_13 = 'backlog'
    str_14 = 'backlog'
    str_15 = 'backlog'
    str_16 = 'backlog'
    str_17 = 'backlog'
    str_18 = 'backlog'
    str_19 = 'backlog'

# Generated at 2022-06-26 03:17:27.079668
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'key'
    value = 'value'
    #
    try:
        cookie = Cookie(key, value)
        cookie['expires'] = 'expires'
        cookie['path'] = 'path'
        cookie['comment'] = 'comment'
        cookie['domain'] = 'domain'
        cookie['max-age'] = 'max-age'
        cookie['secure'] = 'secure'
        cookie['httponly'] = 'httponly'
        cookie['version'] = 'version'
        cookie['samesite'] = 'samesite'
    except KeyError as e:
        print(e)
    except ValueError as e:
        print(e)
    except TypeError as e:
        print(e)
    except Exception as e:
        print(e)

test_Cookie___setitem__()

# Generated at 2022-06-26 03:17:38.548397
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    str_0 = 'backlog'
    str_1 = 'push'
    str_2 = 'backlog'
    str_3 = 'push'
    str_4 = 'backlog'
    str_5 = 'push'
    str_6 = 'backlog'
    str_7 = 'push'
    str_8 = 'backlog'
    str_9 = 'push'
    str_10 = 'backlog'
    str_11 = 'push'
    str_12 = 'backlog'
    str_13 = 'push'

    cookie_0 = Cookie( 
        str_0, 
        str_1
    )

    try:
            cookie_0['Version'] = str_2
    except NameError as e:
        pass
    except KeyError as e:
        print(e)
       

# Generated at 2022-06-26 03:17:44.663716
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = DarkMagicMultiHeader()
    jar = CookieJar(headers)
    jar['test'] = 'test'
    test_case_0()


# Generated at 2022-06-26 03:17:50.825788
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("Unit test for Cookie.__str__()")

    # Test Case 0
    str_0 = 'backlog'
    obj_0 = Cookie(key=str_0, value="")
    expected_0 = "backlog="
    assert expected_0 == obj_0.__str__(), "Expected: {0}, Actual: {1}".format(expected_0, obj_0.__str__())
    print("Test Case 0: PASS")


# Generated at 2022-06-26 03:17:57.593710
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'content-type'
    str_1 = 'charset'

    cookie: Cookie = Cookie(str_0, str_1)
    cookie['max-age'] = 0
    cookie['expires'] = datetime(2022, 6, 23, 17, 52, 0)
    cookie['domain'] = '0.0.0.0'
    cookie['path'] = 'path'
    cookie['secure'] = False
    cookie['httponly'] = False
    cookie['version'] = 0
    cookie['samesite'] = None
    cookie['comment'] = 'comment'
    return None


# Generated at 2022-06-26 03:18:04.270487
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('key', 'value')
    cookie_1 = Cookie('key', 'value')
    if (not (not (cookie_0 != cookie_1))):
        raise RuntimeError
    str_0 = cookie_0.__str__()
    assert str_0 == 'key=value'


# Generated at 2022-06-26 03:18:14.159700
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    data_0, data_1, data_2, data_3, data_4, data_5, data_6, data_7, data_8, data_9, data_10, data_11, data_12, data_13, data_14, data_15, data_16, data_17, data_18, data_19, data_20, data_21, data_22, data_23, data_24, data_25, data_26, data_27, data_28, data_29, data_30, data_31, data_32, data_33, data_34, data_35, data_36, data_37, data_38, data_39, data_40, data_41, data_42 = None, None, None, None, None, None, None, None, None, None, None, None, None,

# Generated at 2022-06-26 03:18:20.105246
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = 'backlog'
    str_1 = 'secure'
    fetch_gzipped = False
    expected_1 = 'backlog'
    expected_2 = 'secure'
    print('Testing Cookie.__setitem__')
    cookie_0 = Cookie(str_0, str_1)
    cookie_0['expires'] = datetime.now()
    cookie_0['path'] = '/'
    cookie_0['comment'] = 'abc'
    cookie_0['domain'] = 'abc'
    cookie_0['max-age'] = 1000
    cookie_0['secure'] = False
    cookie_0['httponly'] = True
    cookie_0['version'] = None
    cookie_0['samesite'] = 'Lax'
    cookie_0['expires'] = 'true'
    cookie_0

# Generated at 2022-06-26 03:18:50.649997
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Declare cookie object
    cookie = Cookie('key', 'value')

    # Set attribute 'max-age'
    cookie['max-age'] = 123

    # Set attribute 'expires'
    cookie['expires'] = 'Thu, 02 Jul 2015 12:07:13 GMT'

    # Invoke method str
    assert str(cookie) == 'key=value; Max-Age=123; Expires=Thu, 02 Jul 2015 12:07:13 GMT'


# Generated at 2022-06-26 03:18:55.879169
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookiejar_0 = CookieJar()
    cookiejar_0.__delitem__('porn')
    cookiejar_0.__delitem__('end')
    cookiejar_0.__delitem__('end')
    str_0 = 'backlog'


# Generated at 2022-06-26 03:19:03.558624
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    global str_0
    cookie_jar_0 = CookieJar({})
    str_1 = 'backlog'
    cookie_jar_0.__delitem__(str_1) # __delitem__ takes exactly 1 argument (2 given)
    str_2 = 'backlog'
    cookie_jar_0.__delitem__(str_2) # __delitem__ takes exactly 1 argument (2 given)
    str_3 = 'backlog'
    cookie_jar_0.__delitem__(str_3) # __delitem__ takes exactly 1 argument (2 given)


# Generated at 2022-06-26 03:19:08.077242
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print('Testing Cookie__str__...', end='')
    str_0 = 'backlog'
    assert Cookie(str_0, "4") == {'backlog': '4'}
    print('Done!')

if __name__ == '__main__':
    print("Running unit tests...")
    test_Cookie___str__()

# Generated at 2022-06-26 03:19:11.412286
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = Cookie('hCpjHn', '0RSzB')
    str_1 = str_0.__str__()
    assert str_1 == 'hCpjHn=0RSzB'


# Generated at 2022-06-26 03:19:19.494997
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print('test method: __str__')
    c = Cookie('boo', 'far')
    c.update({'a':1, 'b':2})
    print('Cookie: ', c)
    c.update({'max-age':1})
    print('Cookie: ', c)
    c.update({'expires':datetime(2019, 3, 20, 0, 10, 10)})
    print('Cookie: ', c)
    c.update({'a':1, 'b':2})
    print('Cookie: ', c)
    print()

# Generated at 2022-06-26 03:19:21.480157
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
        print('Testing CookieJar.__delitem__()')
        test_case_0()


# Generated at 2022-06-26 03:19:25.282756
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Setup
    headers = 'headers'
    cookieJava = CookieJar(headers)

    # Invocation
    cookieJava.__delitem__(str_0)

    # Verification
    assert str_0 in headers
    assert headers[str_0].key == str_0

    # Cleanup


# Generated at 2022-06-26 03:19:35.763115
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # In case of failed assertion, an AssertionError will be raised with specific message,
    # otherwise test is considered passed
    pass
    # Test case 0
    cookie = Cookie('jwt', '')
    cookie['max-age'] = 30
    print(cookie.__str__())
    assert cookie.__str__() == "jwt=; Max-Age=30", "Wrong cookie string format"
    # Test case 1
    cookie = Cookie('username', 'nobody')
    cookie['max-age'] = 30
    print(cookie.__str__())
    assert cookie.__str__() == "username=nobody; Max-Age=30", "Wrong cookie string format"
    # Test case 2
    cookie = Cookie('page', 'Theme=%73unrise')
    cookie['max-age'] = 30

# Generated at 2022-06-26 03:19:38.706376
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    assert '%s=%s' % (str_0, _quote(str_0)) == str(Cookie(str_0, str_0))


# Generated at 2022-06-26 03:20:16.421762
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_1 = 'a_name'
    str_2 = 'a_value'
    str_3 = 'a_domain'
    str_4 = 'path=/'
    str_5 = 'a_comment'
    str_6 = 'version=1'
    str_7 = 'secure'
    str_8 = 'httponly'
    str_9 = 'max-age=10'
    datetime_0 = datetime.strptime('May 26 15:34:21 1997', '%b %d %H:%M:%S %Y')
    str_10 = str(datetime_0)
    str_11 = 'expires=Wed, 26-May-2021 07:34:21 GMT'
    str_12 = 'samesite=lax'

# Generated at 2022-06-26 03:20:18.441674
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_obj = Cookie(key_0, value_0)
    try:
        cookie_obj.__str__()
    except:
        assert False


# Generated at 2022-06-26 03:20:29.273057
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Test case 0
    c = Cookie('name', 'value')
    print(c._keys)
    print(c.items())
    print(c)
    c['max-age'] = 100
    print(c)
    c['expires'] = datetime(2013, 1, 1, 0, 0, 0)
    print(c)
    c['domain'] = 'example.com'
    print(c)
    c['path'] = '/'
    print(c)
    c['comment'] = 'This is a test'
    print(c)
    c['secure'] = True
    print(c)
    c['httponly'] = True
    print(c)



# Generated at 2022-06-26 03:20:32.253759
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie = Cookie(str_0, str_0)
    bit_0 = cookie.__str__()

    assert type(bit_0) == str
    assert bit_0 == 'backlog=backlog'


# Generated at 2022-06-26 03:20:41.247473
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie(str_0, str_0)

    str_1 = cookie_0.__str__()
    str_2 = cookie_0.__str__()
    str_3 = cookie_0.__str__()
    str_4 = cookie_0.__str__()
    str_5 = cookie_0.__str__()
    str_6 = cookie_0.__str__()
    str_7 = cookie_0.__str__()
    str_8 = cookie_0.__str__()
    str_9 = cookie_0.__str__()
    str_10 = cookie_0.__str__()

# Generated at 2022-06-26 03:20:42.986671
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    cookie = Cookie(str_0, '')
    assert str(cookie) == 'backlog='



# Generated at 2022-06-26 03:20:53.537064
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar(dict())

    # Test with valid input
    try:
        cookie_jar['key'] = 'value'
    except:
        return False

    # Test with invalid input (KeyError)
    try:
        cookie_jar['expires'] = 'value'
        return False
    except KeyError:
        pass

    # Test with invalid input (ValueError)
    try:
        cookie_jar['key'] = 'value'
        cookie_jar['key']['max-age'] = 'value'
        return False
    except ValueError:
        pass

    try:
        cookie_jar['key']['expires'] = 'value'
        return False
    except TypeError:
        pass

    # Test with invalid input (KeyError)

# Generated at 2022-06-26 03:20:57.999112
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'backlog'
    str_1 = 'bbbb'
    test_cookie = Cookie(str_0, str_1)
    test_cookie['secure'] = False
    test_cookie['httponly'] = True
    str_2 = '; secure; HttpOnly'
    str_3 = str_1 + str_2
    assert str(test_cookie) == str_3

# Generated at 2022-06-26 03:21:01.899593
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    result = False
    # Initialize the object
    headers = {}
    cookie_jar_0 = CookieJar(headers)
    key_0 = 'rhyme'
    try:
        del cookie_jar_0[key_0]
    except KeyError:
        result = True

    assert result


# Generated at 2022-06-26 03:21:11.848698
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # First we create an empty CookieJar
    # In this case, the values for headers and cookie_headers are empty objects
    headers = Dict[str, str]()
    assert headers == {}
    cookie_headers = Dict[str, str]()
    assert cookie_headers == {}
    # Then we call the constructor for CookieJar, and check to make sure
    # the headers object is being passed in and the dict object is being
    # created
    CookieJar(headers)
    assert headers == {}
    assert cookie_headers == {}
    # I need to find the differences between CookieJar and dict and allow
    # them to be passed in like dict(headers).__init__
    # Doesn't make sense to pass in cookie_headers, then initialize it again
    # Also, header_key already has a value
    # Finally, I set the value of cookie_