

# Generated at 2022-06-26 03:11:27.377859
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = None
    int_1 = 0
    str_0 = None
    str_1 = ";"
    str_2 = "2Jl"
    str_3 = "A$q3"
    str_4 = "&CNF"
    str_5 = "bmp"
    str_6 = "-R19"
    str_7 = "DD$"
    str_8 = "1 :"
    str_9 = "o4t"
    str_10 = "F"
    str_11 = "-h5"
    str_12 = "z)4"
    str_13 = "9X "
    str_14 = "3q_"
    str_15 = "`@>"
    str_16 = "6>j"
    str_17 = "ini"
    str_18

# Generated at 2022-06-26 03:11:28.380142
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    __setitem__()


# Generated at 2022-06-26 03:11:38.267864
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-26 03:11:41.517456
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 9
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0.__delitem__(0)


# Generated at 2022-06-26 03:11:44.887231
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie(1, 1)
    str_0 = cookie_0.__str__()
    assert str_0 is None


# Generated at 2022-06-26 03:11:48.956114
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_0 = '6OoW6{8$v(%+[!;@'
    str_1 = 'l9Q3fqb7V]Qw0y8'
    cookie_0 = Cookie(str_0, str_1)
    str_2 = 'Bzix1'
    str_3 = '!5iPn7'
    cookie_0.__setitem__(str_2, str_3)



# Generated at 2022-06-26 03:11:52.228291
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("csrftoken", "asdffdsaasdf")
    assert str(cookie) == "csrftoken=asdffdsaasdf"



# Generated at 2022-06-26 03:12:00.826080
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 998
    cookie_0 = Cookie(int_0, "8tf")
    cookie_0['expires'] = datetime(year=1978, month=12, day=2)
    cookie_0['secure'] = True
    cookie_0['httponly'] = False
    cookie_0['path'] = "/m5hj3"
    cookie_0['max-age'] = -10
    cookie_0['comment'] = ".mMxCFC"
    cookie_0['domain'] = "NhyU"
    cookie_0['version'] = "1"
    cookie_0['samesite'] = "lax"
    cookie_0.encode("cp1251")
    cookie_0.encode("utf_16")
    cookie_0.encode("latin_1")
    cookie_

# Generated at 2022-06-26 03:12:06.404592
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar(42)
    string_0 = "2n6/jT`T%s-Liu,y6F"
    cookie_jar_0[string_0] = string_0
    string_1 = "/Qw,`L^DYK]R_Ea_$g"
    cookie_jar_0[string_0] = string_1
    string_2 = "`rw3h-8Km"
    cookie_jar_0[string_2] = string_2
    string_3 = "c%d$i,7"
    cookie_jar_0[string_3] = string_3
    del cookie_jar_0[string_3]
    assert string_3 not in cookie_jar_0


# Generated at 2022-06-26 03:12:10.838951
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 0
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0.add("cookie0", "")
    print("Output for test_case_0:")
    print("cookie0=; Max-Age=0")


# Generated at 2022-06-26 03:12:17.679570
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # initializing the variables
    expected_result: str = "test_key=test_value; Path=/; Domain=www.test.com"
    str_0: str = "test_key"
    str_1: str = "test_value"
    # testing the method
    cookie_0 = Cookie(str_0, str_1)
    cookie_0["path"] = "/"
    cookie_0["domain"] = "www.test.com"
    result: str = str(cookie_0)
    # asserting the result
    assert result == expected_result



# Generated at 2022-06-26 03:12:26.799257
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test 1
    cookie_0 = cookie_0 = Cookie("key_0", "value_0")
    cookie_0["expires"] = datetime.today()
    # Test 2
    cookie_1 = cookie_1 = Cookie("key_1", "value_1")
    cookie_1["expires"] = datetime.today()
    cookie_1["version"] = "value_1"
    # Test 3
    cookie_2 = cookie_2 = Cookie("key_2", "value_2")
    cookie_2["path"] = "value_2"
    # Test 4
    cookie_3 = cookie_3 = Cookie("key_3", "value_3")
    cookie_3["path"] = "value_3"
    cookie_3["expires"] = datetime.today()
    # Test 5
    cookie_

# Generated at 2022-06-26 03:12:32.424280
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie()
    int_0 = 573
    str_0 = "r=Qn9H3`Ym"
    cookie_0[int_0] = str_0
    assert str(cookie_0) == "Max-Age=573; Max-Age=r=Qn9H3`Ym"


# Generated at 2022-06-26 03:12:41.456687
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_0 = Cookie("key", "value")
    try:
        cookie_0["secure"] = False
    except KeyError:
        print("Exception Caught")


# Generated at 2022-06-26 03:12:46.268808
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar('')
    # test for TypeError
    try:
        cookie_jar_0['key_0'] = 982
    except TypeError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 03:12:53.106184
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_2 = 3
    str_1 = "CookieJar"
    cookie_jar_1 = CookieJar(int_2)
    assert_equal(len(cookie_jar_1), 0)
    cookie_jar_1[str_1] = 3
    assert_equal(cookie_jar_1[str_1], 3)
    del cookie_jar_1[str_1]
    assert_equal(cookie_jar_1[str_1], None)
    assert_equal(len(cookie_jar_1), 0)


# Generated at 2022-06-26 03:12:57.874089
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "fZ"
    str_1 = "M\0"
    cookie_jar_0[str_0] = str_1
    pass



# Generated at 2022-06-26 03:13:00.558521
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("key", "value")
    result_0 = str(cookie_0)
    assert result_0 == "key=value"


# Generated at 2022-06-26 03:13:11.497704
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    # Test Cases 1, 2, 3

    print("Test cases 1, 2, 3:\n")
    
    # Test case 1

    print("Test case 1:")

    max_age = 2

    cookie_jar_1 = CookieJar(max_age)

    key_1 = "key_1"
    value_1 = "value_1"
    
    cookie_jar_1[key_1] = value_1

    print("Added key: {}, value: {} to cookie jar".format(key_1, value_1))

    assert (cookie_jar_1[key_1].value == value_1) is True

    for k, v in cookie_jar_1.cookie_headers.items():
        print(k, v)
    
    print()

    # Test case 2

    print("Test case 2:")



# Generated at 2022-06-26 03:13:19.384602
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    import secret
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie_jar_0.headers[secret.flag()] = secret.flag()
    cookie

# Generated at 2022-06-26 03:13:23.605655
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookieJar_0 = CookieJar()
    cookieJar_0.__setitem__({}, 's')
    cookieJar_0.__delitem__({})


# Generated at 2022-06-26 03:13:25.178090
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("Test method __setitem__")
    assert True


# Generated at 2022-06-26 03:13:32.858670
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(2)
    cookie_0 = Cookie(
        "dqB)op$t#",
        "a6:eCzYl)c1@5h5=\\H5WZ_dDZ<Xg",
    )
    cookie_jar_0.headers.add(
        "Set-Cookie",
        cookie_0,
    )
    cookie_1 = Cookie(
        "oC7k",
        "8@c%R^1E$]X0u@A\"8/cHw.PYOg#",
    )
    cookie_jar_0.headers.add(
        "Set-Cookie",
        cookie_1,
    )

# Generated at 2022-06-26 03:13:41.929158
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 892
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "U6ibRgOQaUvN1Hw"
    str_1 = "2"
    cookie_jar_0[str_0] = str_1
    assert str_1 == cookie_jar_0[str_0].value
    bool_2 = str_1 in cookie_jar_0
    assert bool_2
    cookie_jar_0.__delitem__(str_1)
    bool_2 = str_0 in cookie_jar_0
    assert not bool_2


# Generated at 2022-06-26 03:13:54.452894
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 588
    cookie_jar_0 = CookieJar(int_0)

# Generated at 2022-06-26 03:14:00.406381
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 470
    cookie_jar_0 = CookieJar(int_0)
    bool_0 = True
    cookie_0 = Cookie("test_Cookie___str__", bool_0)
    assert "test_Cookie___str__=true" == str(cookie_0)


if __name__ == "__main__":
    test_case_0()
    test_Cookie___str__()

# Generated at 2022-06-26 03:14:05.126109
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie_0 = Cookie("pS]", "*")
    cookie_0["max-age"] = 0
    cookie_0["secure"] = True
    cookie_0["expires"] = datetime(2014, 7, 31, 23, 59, 59)
    assert cookie_0.__str__() == "pS]=\"*\"; Secure; Max-Age=0; Expires=Fri, 01-Aug-2014 06:59:59 GMT"


# Generated at 2022-06-26 03:14:15.089564
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = "f"
    str_1 = "-5G0"
    int_0 = 967
    # str_0 = "\',wiY+'a\'"
    # str_0 = "\"'\\\" .  . 0=  .*\\\"\""
    cookie_0 = Cookie(str_0, str_1)
    cookie_0["max-age"] = int_0
    str_3 = cookie_0.__str__()
    print(str_3)

    # Cookie(TmpCookie)
    # test_case_0()
    # cookie_0 = Cookie(str_0, str_1)
    # cookie_0["max-age"] = int_0
    # cookie_0.__str__()
    # cookie_0.__str__()



# Generated at 2022-06-26 03:14:21.269239
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 656
    cookie_jar_0 = CookieJar(int_0)
    value_0 = test_case_0()
    for int_0 in range(1000):
        cookie_jar_0.__setitem__("key_0", value_0)


# Generated at 2022-06-26 03:14:32.520442
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 1000
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 941
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 923
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 884
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 1002
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 1005
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 1000
    cookie_jar_0 = CookieJar(int_0)
    int_0 = 981
    cookie_jar_0 = CookieJar

# Generated at 2022-06-26 03:14:48.619226
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "GH>_T#T"
    str_1 = "q=; max-age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT"
    cookie_jar_0[str_0] = str_1
    #
    # The above code should be equivalent to the following
    #   cookie_0 = Cookie(str_0, str_1)
    #   cookie_0['max-age'] = 0
    #   cookie_jar_0[str_0] = cookie_0
    #
    cookie_jar_0[str_0] = str_1
    # Adding it a second time doesn't overwrite the value because
    # CookieJar.__setitem__ checks for existence first
    assert len

# Generated at 2022-06-26 03:14:58.406376
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 934
    cookie_jar_0 = CookieJar(int_0)

    # Test when key is a reserved word
    try:
        cookie_jar_0["max-age"] = "max-age"
        assert False
    except KeyError:
        pass

    # Test when key is not a reserved word and value is a string
    cookie_jar_0["pirate"] = "parrot"
    assert str(cookie_jar_0["pirate"]) == "pirate=parrot; Path=/; Max-Age=0"

    # Test when key is not a reserved word and value is int
    cookie_jar_0["pirate"] = 5
    cookie_jar_0["loot"] = 10

# Generated at 2022-06-26 03:15:00.497296
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    # @TODO: write test


# Generated at 2022-06-26 03:15:12.864706
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    cookie_0 = Cookie(int_0, int_0)
    str_0 = str(cookie_0)
    assert str_0 == ''


# def test_case_1():
#     int_0 = 967
#     cookie_jar_0 = CookieJar(int_0)
#     dict_1 = dict()
#     dict_1['max-age'] = 358
#     dict_1['secure'] = True
#     dict_1['httponly'] = True
#     cookie_1 = Cookie('session', 'QAQQQQQQQQQQQQQQQQQQQQQQQQQQQ', dict_1)
#     str_0 = str(cookie_1)
#

# Generated at 2022-06-26 03:15:21.966664
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Checking for correct exception thrown
    with pytest.raises(ValueError) as exc_info:
        cookie_jar_0 = Cookie()
        cookie_jar_0.__setitem__("max-age", "gZ0")
    with pytest.raises(KeyError) as exc_info:
        cookie_jar_0 = Cookie()
        cookie_jar_0.__setitem__("max-age", "moZ0")
    with pytest.raises(KeyError) as exc_info:
        cookie_jar_0 = Cookie()
        cookie_jar_0.__setitem__("name", "Z0")
    with pytest.raises(TypeError) as exc_info:
        cookie_jar_0 = Cookie()
        cookie_jar_0.__setitem__("expires", 967)
   

# Generated at 2022-06-26 03:15:24.708898
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 272
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "ef"
    cookie_jar_0[str_0] = str_0
    cookie_jar_0.__delitem__(str_0)
    assert str_0  == "ef"



# Generated at 2022-06-26 03:15:27.733391
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Put ur test logic here
    pass



# Generated at 2022-06-26 03:15:32.072743
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 1102
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0[int_0] = int_0

    int_1 = 800
    cookie_jar_0.__delitem__(int_1)


# Generated at 2022-06-26 03:15:33.366961
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert True



# Generated at 2022-06-26 03:15:41.177925
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create CookieJar object
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    # Assign string value to 'key' argument
    str_0 = ":y&wVl3+< $?7Y}9tz'Zdf6zL-I>a`$R?_p]#nGwfS~nH5Y5Xb&!gi2!@4d4%"
    # Delete CookieJar object attribute with key of 'key' argument's value
    del cookie_jar_0[str_0]



# Generated at 2022-06-26 03:15:49.073665
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)

    cookie_jar_0['key1'] = 'value1'
    del cookie_jar_0['key1']
    assert str(cookie_jar_0['key1']) == ""
    assert int(cookie_jar_0['key1']['max-age']) == DEFAULT_MAX_AGE
    assert cookie_jar_0['key1'].key == 'key1'
    assert cookie_jar_0['key1'].value == ""


# Generated at 2022-06-26 03:15:50.096676
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    assert True



# Generated at 2022-06-26 03:15:55.292858
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 550
    cookie_jar_0 = CookieJar(int_0)
    cookie_0 = Cookie("foo", "bar")
    cookie_0["path"] = "/"
    cookie_jar_0["foo"] = cookie_0
    assert str(cookie_0) == "foo=bar; Path=/"


# Generated at 2022-06-26 03:15:59.091855
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 903
    cookie_jar_0 = CookieJar(int_0)
    int_1 = 0
    cookie_jar_0[int_1] = 740
    cookie_0 = cookie_jar_0[int_1]
    assert str(cookie_0) == "0=740"


# Generated at 2022-06-26 03:16:03.121684
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test case for __str__ of Cookie class
    """
    test = Cookie("name", "value")
    for key in test._keys:
        test[key] = None
    set_cookie_string = "name=value; HttpOnly; Comment=None; Max-Age=None; Version=None; Secure; Expires=None; SameSite=None; Path=None; Domain=None"
    assert str(test) == set_cookie_string


# Generated at 2022-06-26 03:16:07.817984
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 891
    cookie_0 = Cookie(int_0, int_0)
    #
    # Exception: KeyError
    try:
        cookie_0.__setitem__("Comment", str())
    except Exception as exc:
        assert type(exc) == KeyError and str(exc) == "'Unknown cookie property'"


# Generated at 2022-06-26 03:16:10.364534
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    result = "X=this&is=a&c%61ke"
    assert result == Cookie('X','this&is=a&c%61ke').__str__()


# Generated at 2022-06-26 03:16:15.224795
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    int_1 = 635
    cookie_jar_1 = CookieJar(int_1)
    cookie_jar_1.__setitem__("?", "}")
    cookie_jar_0.__setitem__("~", "~")


# Generated at 2022-06-26 03:16:23.606582
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print("Testig CookieJar::__delitem__")
    cookie_jar_0 = CookieJar(868)
    cookie_jar_0.__setitem__("8Ov$9d}H", "")
    cookie_jar_0.__setitem__("i|&*hb", "4A")
    cookie_jar_0.__delitem__("8Ov$9d}H")
    cookie_jar_0.__setitem__("", "]s*D^")
    cookie_jar_0.__delitem__("i|&*hb")
    cookie_jar_0.__delitem__("")
    cookie_jar_0.__setitem__("f", "4A")
    cookie_jar_0.__delitem__("/")

# Generated at 2022-06-26 03:16:29.837336
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    int_0 = 677
    cookie_jar_0 = CookieJar(int_0)
    print("1 cookie_jar_0")
    str_0 = 'foobar'
    cookie_jar_0.__setitem__(str_0, None)
    print("2 cookie_jar_0")
    int_1 = 43
    cookie_jar_0.__setitem__(int_1, None)
    print("3 cookie_jar_0")


# Generated at 2022-06-26 03:16:43.539163
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # AssertionError: Exception: 1 instance(s) of <class 'ValueError'> not raised.
    cookie_jar_0 = CookieJar(967)
    cookie_jar_0.__delitem__(0)
    assert isinstance(cookie_jar_0, CookieJar)
    # AssertionError: Exception: 1 instance(s) of <class 'ValueError'> not raised.
    cookie_jar_0.__delitem__(0)
    assert isinstance(cookie_jar_0, CookieJar)
    # AssertionError: Exception: 1 instance(s) of <class 'AttributeError'> not raised.
    cookie_jar_0.__delitem__(0)
    assert isinstance(cookie_jar_0, CookieJar)
    # AssertionError: Exception: 1 instance(s) of <class 'ValueError

# Generated at 2022-06-26 03:16:47.424284
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 688
    cookie_jar_0 = CookieJar(int_0)
    string_0 = "b"
    string_1 = "e"
    cookie_jar_0[string_0] = string_1


# Generated at 2022-06-26 03:16:49.479466
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    s = Cookie("a", "b")
    assert str(s) == "a=b"


# Generated at 2022-06-26 03:16:54.481264
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    int_0 = 964
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0.__setitem__('test', 'test')
    cookie_jar_0.__setitem__('test', 'test')


# Generated at 2022-06-26 03:16:55.788528
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert __delitem__


# Generated at 2022-06-26 03:17:04.827290
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 3
    int_1 = 926
    string_0 = "c%i=v%i"
    string_1 = "Cookie name is a reserved word"
    string_2 = "expires"
    string_3 = "max-age"
    string_4 = "expires"
    string_5 = "False"
    dict_0 = Cookie(int_1, string_5)
    dict_0["expires"] = string_5
    dict_0.setdefault(string_5, True)

    try:
        dict_0.__setitem__(string_0, int_1)
        assert False
    except KeyError:
        assert True


# Generated at 2022-06-26 03:17:06.853207
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("key", "value")
    assert str(cookie_0) == "key=value"


# Generated at 2022-06-26 03:17:12.129292
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "tN9i~q"
    cookie_jar_0[str_0] = "V"
    cookie_jar_0[str_0] = ""
    cookie_jar_0.__delitem__(str_0)


# Generated at 2022-06-26 03:17:13.465895
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # [case-0]
    test_case_0()


# Generated at 2022-06-26 03:17:14.502781
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 374
    cookie_0 = Cookie(int_0, str_0)



# Generated at 2022-06-26 03:17:21.425004
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    cookie_0 = Cookie(str_0, list_0)

    try:
        str_0 = cookie_0.__str__()
        assert False
    except UnboundLocalError:
        pass



# Generated at 2022-06-26 03:17:24.457038
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'Cookie'
    cookie_0 = Cookie(str_0)
    assert isinstance(cookie_0.__str__(), str) == True



# Generated at 2022-06-26 03:17:26.825817
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar("expires")
    cookie_jar_0.__delitem__("expires")



# Generated at 2022-06-26 03:17:30.058748
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 03:17:40.378926
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 173
    int_1 = 906
    str_0 = "y5h5c%@Cf["
    int_2 = 894
    int_3 = 571
    int_4 = 571
    str_1 = "|8Rr{?Y<"
    str_2 = "pG6@]&=^"
    str_3 = "~;+P9{97*"
    cookie_jar_0 = CookieJar(int_0)
    str_4 = "1#E:Nh*|bJ"
    str_5 = ">0A0"
    str_6 = "bi]?0$J"
    cookie_jar_1 = Cookie("", "")
    str_7 = "sB"
    str_8 = "$:7V"
    cookie

# Generated at 2022-06-26 03:17:52.369535
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_str_0 = Cookie("cookie_str_0", "cookie_str_0")
    cookie_str_0["comment"] = "cookie_str_0"
    cookie_str_0["secure"] = False
    expected = "comment=cookie_str_0; secure"
    actual = str(cookie_str_0)
    assert actual == expected
    cookie_str_1 = Cookie("cookie_str_1", "cookie_str_1")
    cookie_str_1["domain"] = "cookie_str_1"
    cookie_str_1["max-age"] = "cookie_str_1"
    expected = "Domain=cookie_str_1; Max-Age=\"cookie_str_1\""
    actual = str(cookie_str_1)
    assert actual == expected

# Generated at 2022-06-26 03:17:54.259173
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import sys
    import io
    import unittest



# Generated at 2022-06-26 03:17:59.736127
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 125
    str_0 = ""
    cookie_0 = Cookie(str_0, int_0)
    str_1 = cookie_0.__str__()
    str_2 = "=125"
    assert str_1 == str_2


# Generated at 2022-06-26 03:18:04.594525
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0.__delitem__(int_0)



# Generated at 2022-06-26 03:18:14.349911
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_name = "__str__"
    cookie = Cookie("foo", "bar")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    expected = (
        "foo=bar; expires=%s; HttpOnly; Domain=domain; Version=version; "
        "Secure; SameSite=samesite; Max-Age=0; Path=/; Comment=comment"
    )
    actual = cookie.__str__()

# Generated at 2022-06-26 03:18:31.023542
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 819
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "iD`e*"
    cookie_jar_0[str_0] = str_0
    str_1 = "l]i*N|FZI"
    cookie_jar_0[str_1] = str_1
    cookie_jar_0[str_1] = str_1
    assert len(cookie_jar_0) == 2
    del cookie_jar_0[str_0]
    assert len(cookie_jar_0) == 1
    assert len(cookie_jar_0) == 1


# Generated at 2022-06-26 03:18:42.118941
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 500
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "\\f0),"
    cookie_jar_0[str_0] = "jn@Q>A9"
    result = cookie_jar_0[str_0]
    assert result["path"] == "/"
    assert result.value == "jn@Q>A9"
    assert result.key == str_0
    cookie_jar_0[str_0] = "q5C6y5-:"
    result = cookie_jar_0[str_0]
    assert result["path"] == "/"
    assert result.value == "q5C6y5-:"
    assert result.key == str_0
    del cookie_jar_0[str_0]

# Generated at 2022-06-26 03:18:47.067438
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_1 = 809
    cookie_jar_1 = CookieJar(int_1)
    str_1 = "test_value"
    str_0 = "test_key"
    cookie_jar_1[str_0] = str_1
    cookie_jar_1.__delitem__(str_0)
    assert str_0 in cookie_jar_1.keys() == False


# Generated at 2022-06-26 03:18:52.432450
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0.__setitem__("TtY", "O", "QV", "9Z{f`V$z")
    cookie_0 = cookie_jar_0.__getitem__("TtY")
    str_0 = cookie_0.__str__()
    assert str_0 == "TtY=O; QV=9Z{f`V$z", "Incorrect cookie string: " + str_0



# Generated at 2022-06-26 03:19:03.686592
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    # Call method __delitem__ of class CookieJar
    try:
        cookie_jar_0.__delitem__("")
    except KeyError:
        pass

    # Call method __delitem__ of class CookieJar
    try:
        cookie_jar_0.__delitem__("")
    except KeyError:
        pass

    # Call method __delitem__ of class CookieJar
    try:
        cookie_jar_0.__delitem__("")
    except KeyError:
        pass

    # Call method __delitem__ of class CookieJar
    try:
        cookie_jar_0.__delitem__("")
    except KeyError:
        pass


# Generated at 2022-06-26 03:19:04.936171
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie()
    assert cookie_0.__str__() == "";

# Generated at 2022-06-26 03:19:15.641170
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)

    cookie_jar_0["asdf"] = "wooo"
    assert(str(cookie_jar_0['asdf']) == "asdf=wooo")

    cookie_jar_0["asdf"] = "wooo"
    assert(str(cookie_jar_0['asdf']) == "asdf=wooo")

    cookie_jar_0["asdf"] = ")"
    assert(str(cookie_jar_0['asdf']) == 'asdf=")"')

    cookie_jar_0["asdf"]["expires"] = datetime.utcnow()
    assert(str(cookie_jar_0['asdf']) == 'asdf=")"')


# Generated at 2022-06-26 03:19:21.481253
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    cookie_jar_0 = CookieJar(int_0)
    def test_def_0():
        cookie_jar_0['key1'] = 'val1'
        cookie_jar_0['key2'] = 'val2'
        assert cookie_jar_0['key1'].value == 'val1'
        assert cookie_jar_0['key2'].value == 'val2'


# Generated at 2022-06-26 03:19:27.525436
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Setup
    cookie_0 = Cookie(None, None)
    # Assertion 1
    assert str(cookie_0) == '='

    # Setup
    cookie_1 = Cookie(None, None)
    # Assertion 2
    assert str(cookie_1) == '='

    # Setup
    cookie_2 = Cookie(None, None)
    # Assertion 3
    assert str(cookie_2) == '='

    # Setup
    cookie_3 = Cookie(None, None)
    # Assertion 4
    assert str(cookie_3) == '='



# Generated at 2022-06-26 03:19:35.039585
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_obj = Cookie("test", "test")
    cookie_obj["path"] = "/path/to"
    cookie_obj["secure"] = True
    cookie_obj["max-age"] = 3600
    cookie_obj["expires"] = datetime(2000, 1, 1, 0, 0, 0)
    assert str(cookie_obj) == "test=test; Path=/path/to; Max-Age=3600; Expires=Thu, 01-Jan-2000 00:00:00 GMT; Secure"



# Generated at 2022-06-26 03:19:50.435727
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = -562
    cookie_jar_0 = CookieJar(int_0)
    # Test case with value and __delitem__
    try:
        cookie_jar_0.__delitem__("poltrona")
    except KeyError:
        assert False
    except:
        assert True
    else:
        assert False
    cookie_jar_0.__delitem__("poltrona")
    # Test case with no value and __delitem__
    try:
        cookie_jar_0.__delitem__("cordova")
    except KeyError:
        assert False
    except:
        assert True
    else:
        assert False
    cookie_jar_0.__delitem__("cordova")
    # Test case with value and __delitem__

# Generated at 2022-06-26 03:19:54.453667
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0['test_case_0'] = 1
    cookie_0 = cookie_jar_0['test_case_0']

# Generated at 2022-06-26 03:19:59.626830
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 301
    cookie_0 = Cookie('fun', int_0)
    cookie_0['max-age'] = 3
    assert getattr(cookie_0, "key", None) == "fun", "Cookie key incorrect!"
    assert getattr(cookie_0, "value", None) == "301", "Cookie value incorrect!"
    assert cookie_0['max-age'] == 3, "Cookie max age incorrect!"


# Generated at 2022-06-26 03:20:03.440364
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    cookie_0 = cookie_jar_0["cookie_0"]
    assert (cookie_0 == "cookie_0=967") is False


# Generated at 2022-06-26 03:20:12.310485
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = "oc"
    str_1 = "b;'0"
    cookie_0 = Cookie(str_0, str_1)
    str_0 = "q`B"
    str_1 = "^RbI'e"
    cookie_1 = Cookie(str_0, str_1)
    str_0 = "eA)l"
    str_1 = "D^U"
    cookie_2 = Cookie(str_0, str_1)
    cookie_2["path"] = "4H f"
    str_0 = "7J-a"
    str_1 = "T1u"
    cookie_3 = Cookie(str_0, str_1)
    cookie_3["path"] = "7*H !"
    str_0 = "4X*!$"
   

# Generated at 2022-06-26 03:20:23.043008
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 0
    cookie_0 = Cookie("xyz", int_0)
    int_0 = 0
    cookie_1 = Cookie("mega", int_0)
    int_0 = 0
    cookie_2 = Cookie("asdf", int_0)
    str_0 = "xyz"
    str_1 = "mega"
    str_2 = "asdf"
    str_3 = "123"
    str_4 = "asdf"
    try:
        cookie_0.__setitem__(str_3, int_0)
        cookie_1.__setitem__(str_3, int_0)
        cookie_2.__setitem__(str_4, int_0)
        print("No errors raised")
    except KeyError:
        print("KeyError")

# Generated at 2022-06-26 03:20:27.770889
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    int_1 = 967
    cookie_0 = Cookie(int_1, cookie_jar_0)
    int_2 = 967
    cookie_0.__setitem__(int_2, int_2)


# Generated at 2022-06-26 03:20:31.171749
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar()
    # Key '$U+00B7' not found in the CookieJar
    try:
        cookie_jar_0['·']
        assert False
    except KeyError as e:
        assert e.args[0] == "'·'"


# Generated at 2022-06-26 03:20:32.563487
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    int_0 = 853
    cookie_jar_0 = CookieJar(int_0)


# Generated at 2022-06-26 03:20:36.553365
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)
    str_0 = "cookie_0"
    try:
        cookie_jar_0.__delitem__(str_0)
    except KeyError:
        pass


# Generated at 2022-06-26 03:20:56.607114
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 990
    cookie_0 = Cookie(int_0, )
    str_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:20:59.509147
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    int_0 = 523
    cookie_jar_0 = CookieJar(int_0)
    cookie_jar_0.__delitem__("Y")


# Generated at 2022-06-26 03:21:06.931711
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    int_0 = 967
    cookie_jar_0 = CookieJar(int_0)

    str_0 = str(int_0)
    str_1 = chr(int_0)
    int_1 = int_0
    str_2 = chr(int_1)
    cookie_jar_0[str_0] = str_1
    int_2 = len(cookie_jar_0)
    if int_2 == 1:
        return 
    int_1 = int_0
    str_3 = chr(int_1)
    cookie_jar_0[str_0] = str_3


# Generated at 2022-06-26 03:21:15.657764
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    int_0 = 887
    cookie_jar_0 = CookieJar(int_0)
    int_1 = 131
    key_0 = "lvDm=`m"
    value_0 = "R>i</{Z"
    cookie_0 = Cookie(key_0, value_0)
    cookie_0["version"] = int_1
    for i in range(10):
        if i != 8 and i != 5:
            cookie_0["path"] = i
    cookie_0["secure"] = False
    actual = str(cookie_0)
    expected = "lvDm=`m=R>i</{Z; Version=131; Path=6"
    assert actual == expected
    print(actual)

test_case_0()
test_Cookie___str__()