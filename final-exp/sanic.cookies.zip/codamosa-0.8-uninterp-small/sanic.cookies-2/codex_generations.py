

# Generated at 2022-06-26 03:11:20.955179
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Initialize a Cookie object
    set_0 = set()
    float_0 = 0.001
    cookie_0 = Cookie(set_0, float_0)
    # Call method __str__
    str_0 = cookie_0.__str__()
    # Check that the output is a string
    assert type(str_0) == type("")
    # Check that the output is non empty
    assert len(str_0) > 0

# Generated at 2022-06-26 03:11:32.047466
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar = CookieJar(headers)
    d = {}
    key = "max-age"
    value = 0
    cookie_jar[key] = value
    d[key] = value
    key = "path"
    value = "/"
    cookie_jar[key] = value
    d[key] = value
    key = "expires"
    value = datetime.now()
    cookie_jar[key] = value
    d[key] = value
    key = "HttpOnly"
    cookie_jar[key] = True
    d[key] = True
    key = "Secure"
    cookie_jar[key] = True
    d[key] = True
    del key
    del value
    del d

# Generated at 2022-06-26 03:11:33.490787
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    set_0 = set()
    float_0 = 0.001
    cookie_0 = Cookie(set_0, float_0)
    str_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:11:37.401479
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    # Create mock object for Cookie class
    cookie_0 = create_cookie_class_mock()

    # Call method __str__ with arguments:
    try:
        cookie_0.__str__()
    except Exception as e:
        assert str(e) == "NotImplemented"



# Generated at 2022-06-26 03:11:41.518635
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Arrange
    set_0 = set()
    float_0 = 0.001
    cookie_0 = Cookie(set_0, float_0)
    key = str
    value = int

    # Act
    cookie_0.__setitem__(key, value)

    # Assert



# Generated at 2022-06-26 03:11:54.080185
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    set_0 = set()
    float_0 = 0.001
    set_1 = set()
    float_1 = 0.001
    cookie_0 = Cookie(set_0, float_1)
    cookie_0 = Cookie(set_1, float_0)
    cookie_1 = Cookie(set_0, float_0)
    cookie_2 = Cookie(set_0, float_1)
    cookie_3 = Cookie(set_1, float_0)
    cookie_jar_0 = CookieJar(set_0)
    cookie_jar_0[set_0] = float_1
    assert float_1 in cookie_jar_0.keys()
    cookie_jar_0[set_1] = float_0
    assert float_0 in cookie_jar_0.keys()

# Generated at 2022-06-26 03:11:57.573754
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    set_0 = set()
    float_0 = 0.001
    cookie_0 = Cookie(set_0, float_0)
    set_1 = set()
    str_0 = str()
    cookie_0[set_1] = str_0


# Generated at 2022-06-26 03:11:58.594287
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('key', 'value')
    assert cookie.__str__() == 'key=value'


# Generated at 2022-06-26 03:12:02.213018
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create a CookieJar object
    cookie_jar = CookieJar(None)
    cookie_jar['key'] = 'value'
    assert len(cookie_jar) == 1
    cookie_jar.__delitem__('key')
    assert len(cookie_jar) == 0
    

# Generated at 2022-06-26 03:12:05.387130
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    set_0 = set()
    float_0 = 0.001
    cookie_0 = Cookie(set_0, float_0)
    cookie_jar_0 = CookieJar(["", ])
    cookie_jar_0[""] = cookie_0
    assert cookie_jar_0[""] == cookie_0
    del cookie_jar_0[""]
    assert cookie_jar_0[""] != cookie_0


# Generated at 2022-06-26 03:12:16.488313
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Assignment statements
    float_0 = 0.001
    # Creation statements
    cookie_0 = Cookie(float_0, float_0)
    # Method call statements
    string_0 = str(cookie_0)
    float_1 = float(string_0)
    float_2 = float(string_0)
    string_1 = str(float_2)
    # Return statements
    return


# Generated at 2022-06-26 03:12:24.366874
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    try:
        cookie_0 = Cookie('p9HjK', 'zcxrB')
        dict_0 = dict()
        dict_0["Set-Cookie"] = cookie_0
        __CookieJar_0 = CookieJar(dict_0)
        __CookieJar_0.__setitem__('9YW', '6rhxU')
        assert __CookieJar_0["9YW"].value == '6rhxU'
    except ValueError as e:
        print(e)
    except KeyError as e:
        print(e)


# Generated at 2022-06-26 03:12:31.402459
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    cookie_jar_0 = CookieJar(headers)
    str_0 = 'b!#'
    cookie_jar_0[str_0] = 15.0
    cookie_jar_0[str_0] = 12.0
    str_1 = str_0
    del cookie_jar_0[str_1]


# Generated at 2022-06-26 03:12:33.593597
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 0.001
    cookie_0 = Cookie(float_0, float_0)
    str_0 = cookie_0.__str__()

# Generated at 2022-06-26 03:12:36.228984
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    headers = Headers()
    cookie_0 = CookieJar(headers)
    cookie_0.pop("host")
    cookie_0.pop("host")
    cookie_0.pop("host")


# Generated at 2022-06-26 03:12:39.675892
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = 0.001
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)

    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__(float_0)


# Generated at 2022-06-26 03:12:48.134925
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    cookie_jar_0["key_0"] = ""
    cookie_jar_0["key_1"] = ""
    cookie_jar_0["key_0"] = "new_value"
    cookie_jar_0["key_0"] = "another_value"
    print(cookie_jar_0)

    del cookie_jar_0["key_1"]
    print(cookie_jar_0)



# Generated at 2022-06-26 03:12:56.437604
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    Tests method __setitem__ of class CookieJar

    :return: None
    """
    string_0 = "b9zS*1kt_"
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()

    def test_function_0():
        float_0 = 0.001
        response_0 = Response(float_0, float_0)
        result = response_0

        assert result == response_0
    bool_2 = bool_4
    bool_4 = bool_2
    bool_2 = bool_5
    bool_

# Generated at 2022-06-26 03:13:05.679680
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_Optimization_0 = CookieJar()
    cookie_0 = Cookie('test_0', 'cookie_0')
    cookie_0['path'] = '/'
    cookie_0['max-age'] = 0
    test_Optimization_0['test_0'] = cookie_0
    test_Optimization_0['test_0'] = cookie_0
    test_Optimization_0['test_0'] = cookie_0
    assert test_Optimization_0['test_0'] == cookie_0
    test_Optimization_0['test_0'] = cookie_0
    assert test_Optimization_0['test_0'] == cookie_0
    assert test_Optimization_0['test_0'] == cookie_0

# Generated at 2022-06-26 03:13:15.168243
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 0.001
    cookie_0 = Cookie(float_0, float_0)
    try:
        # __str__ called on instance.
        assert cookie_0.__str__() == "%s=%s" % (float_0, "...s=%s" % float_0)
    except:
        cookie_0 = Cookie(float_0, float_0)
        # __str__ called on class.
        assert cookie_0.__str__() == "%s=%s" % (float_0, "...s=%s" % float_0)


# Generated at 2022-06-26 03:13:21.555252
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Initialization of 'headers' variable
    headers = {}
    # Initialization of 'CookieJar' object
    cookiejar = CookieJar(headers)
    # Setting value of CookieJar's key '0'
    cookiejar['0'] = 'host'
    # Assertion for __delitem__ method of class CookieJar
    try:
        assert (cookiejar['0'] == 'host')
    except AssertionError:
        print('AssertionError raised for test_CookieJar___delitem__')
    # Calling __delitem__ method of the class CookieJar
    cookiejar.__delitem__('0')


# Generated at 2022-06-26 03:13:24.919878
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    if _is_legal_key(str_0):
        var_1 = _is_legal_key(str_0)
    else:
        var_1 = None
    return var_1


# Generated at 2022-06-26 03:13:27.293604
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie('my_key', 'my_value')
    str_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:13:36.326383
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # A call to instance method __str__ of class Cookie
    # with arguments:
    # - constant of type str;
    # - constant of type int;
    # - empty dict;
    # returns str
    str_0 = 'host'
    int_0 = 16
    dict_0 = {}
    str_returned = Cookie(str_0,int_0).__str__()
    assert type(str_returned) == str


# Generated at 2022-06-26 03:13:39.995935
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Setup
    str_0 = 'host'

    # Call the method being tested
    str_1 = str(Cookie(str_0, str_0))
    assert str_1 == 'host=host'


# Generated at 2022-06-26 03:13:44.992885
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print("Testing method __delitem__ of class CookieJar")
    cj = CookieJar({'accept-language': 'en-US,en;q=0.9'})
    cj['host'] = '127.0.0.1'
    cj['host'] = '127.0.0.1'
    del cj['host']
    assert 'host' not in cj
    print("Passed unit test for method __delitem__ of class CookieJar")


# Generated at 2022-06-26 03:13:56.853441
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    _dict_0 = {
        'key': 'str',
        'value': 'str',
        '_keys': {
            'expires': 'expires',
            'path': 'Path',
            'comment': 'Comment',
            'domain': 'Domain',
            'max-age': 'Max-Age',
            'secure': 'Secure',
            'httponly': 'HttpOnly',
            'version': 'Version',
            'samesite': 'SameSite',
        },
        '_flags': {'secure', 'httponly'},
    }
    _list_0 = [
        'str=str',
        'Max-Age=0',
    ]
    _list_1 = [
        'str=str',
        'Max-Age=0',
        'Secure',
    ]
    _list_2

# Generated at 2022-06-26 03:14:01.200500
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    # Basic test case
    # CookieJar -> test_case_0
    cookie_jar_0 = CookieJar()
    cookie_jar_0['test_case_0'] = 'test_value_0'
    del cookie_jar_0['test_case_0']
    

# Generated at 2022-06-26 03:14:07.479037
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'host'
    cookie = Cookie(str_0, str_0)
    print(cookie['expires'] == None)
    cookie['expires'] = 'Tue, 16 Jun 2020 15:41:38 GMT'
    print(cookie['expires'] == 'Tue, 16 Jun 2020 15:41:38 GMT')
    cookie['expires'] = datetime(2020, 6, 16, 15, 41, 38)
    print(cookie['expires'] == datetime(2020, 6, 16, 15, 41, 38))


# Generated at 2022-06-26 03:14:15.604767
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_1 = 'host'
    str_2 = '127.0.0.1'
    str_3 = 'local'
    str_4 = '127.0.0.1'
    cookie = Cookie(str_1, str_2)
    cookie['domain'] = str_3
    cookie['path'] = str_4
    out_str = str(cookie)
    # self.assertEqual(out_str, 'host=127.0.0.1; Domain=local; Path=127.0.0.1')
    # self.assertTrue(len(cookie) == 3)
    print(out_str)
    print(len(cookie))



# Generated at 2022-06-26 03:14:22.064327
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'host'
    # Cookie: __str__
    data = Cookie('host', 'value')
    content = data.__str__()
    assert content == 'host=value'


# Generated at 2022-06-26 03:14:23.261467
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_case_0()


# Generated at 2022-06-26 03:14:32.240424
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'host'
    str_1 = 'host'
    str_2 = 'host'
    str_3 = 'host'
    str_4 = 'host'
    str_5 = 'host'
    str_6 = 'host'

    obj_0 = Cookie(str_0, str_1)
    obj_0.update({str_2: str_3, str_4: str_5, str_6: 'path'})
    str_7 = obj_0.__str__()
    assert str_7 == "host=host; Domain=host; Path=path; Version=host"
    

# Generated at 2022-06-26 03:14:37.015590
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    c = CookieJar({})
    c["key"] = "value"
    c["key_1"] = "value_2"
    del c["key"]
    str_0 = c.headers[0]
    str_1 = c["key_1"].value
    assert str_0 == "Set-Cookie: key=; Path=/; Max-Age=0"
    assert str_1 == "value_2"


# Generated at 2022-06-26 03:14:41.879473
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test Case 0
    key = 'host'
    value = 'localhost'
    cookie = Cookie(key, value)
    try:
        cookie['max-age'] = 'b'
    except ValueError as e:
        print(e.args)
        print("passed")


# Generated at 2022-06-26 03:14:46.494844
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Initialization
    headers = {str_0: str_0}
    cookie_jar = CookieJar(headers)
    cookie_jar['key'] = 'val'

    # Test
    cookie_jar.__delitem__('key')


# Generated at 2022-06-26 03:14:50.857705
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    # Set up context, _fixture_class, _fixture_func
    c0 = CookieJar(headers={})

    # Call the method
    #c0._fixture_class._fixture_func(c0, c0.key)
    
    # Assert
    #assert c0._fixture_class._fixture_func(c0, c0.key) == c0.__setitem__(c0.key, c0.value)
    
    


# Generated at 2022-06-26 03:14:57.845908
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Setup
    key_0 = None
    value_0 = None
    cookie_0 = Cookie(key_0, value_0)
    key_1 = None
    value_1 = None
    cookie_0 = Cookie(key_1, value_1)
    # AssertionError
    try:
        cookie_0.__setitem__(key_1, value_1)
    except AssertionError:
        pass
    else:
        assert False

test_Cookie___setitem__()


# Generated at 2022-06-26 03:14:59.675242
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    jar = CookieJar({})
    jar["test"] = "test"
    # coverage
    jar["test"] = None



# Generated at 2022-06-26 03:15:07.868153
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test 0
    global str_0
    str_0 = 'host'
    headers = {}
    cookie_jar = CookieJar(headers)
    cookie_jar[str_0] = 'exa-corp.com'
    del cookie_jar['host']
    assert(headers['Set-Cookie'] == 'host="exa-corp.com"'+'; Path=/'+'; Max-Age=0')


# Generated at 2022-06-26 03:15:19.808361
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    str_0 = 'host'

    # Create a cookie jar
    cookie_jar = CookieJar()

    # Create a cookie with the key 'str_0'
    cookie_0 = Cookie(str_0, 'tr-americas-1.analytics.adobe.net')

    # Add the cookie inside the cookie jar
    cookie_jar[str_0] = cookie_0

    # Assert that the cookie is inside the cookie jar
    assert str_0 in cookie_jar

    # Delete the cookie from the cookie jar
    del cookie_jar[str_0]

    # Assert that the cookie is not inside the cookie jar
    assert not str_0 in cookie_jar


# Generated at 2022-06-26 03:15:22.613475
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
	headers = None
	# delitem()
	s = CookieJar(headers)
	# assert
	assert True


# Generated at 2022-06-26 03:15:30.103211
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'os'
    str_1 = '; '
    str_2 = '='
    str_3 = 'host'
    str_4 = 'expires'
    str_5 = ' Fri, 01-Jan-2038 00:00:00 GMT'
    str_6 = 'Path'
    str_7 = 'Comment'
    str_8 = 'Domain'
    str_9 = 'Max-Age'
    str_10 = 'Secure'
    str_11 = 'HttpOnly'
    str_12 = 'Version'
    str_13 = 'SameSite'

    c = Cookie(str_0, str_3)
    str_ret = c.__str__()
    assert str_ret == 'os=host'

    c = Cookie(str_0, str_3)

# Generated at 2022-06-26 03:15:31.325748
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_case_0()

# Generated at 2022-06-26 03:15:33.824426
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie = CookieJar({})
    cookie['host'] = 'host'
    cookie.__delitem__('host')



# Generated at 2022-06-26 03:15:35.123287
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    pass


# Generated at 2022-06-26 03:15:46.646607
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    str_0 = 'host'
    str_1 = 'host'
    str_2 = 'host'
    str_3 = 'host'
    str_4 = 'host'
    str_5 = 'host'
    str_6 = 'host'
    str_7 = 'host'
    obj_0 = CookieJar({})
    obj_0.update({'host': 'host'})
    try:
        obj_0.__setitem__(str_0, str_1)
    except NameError:
        raise RuntimeError("test case failed")
    obj_0.__setitem__(str_2, str_3)
    obj_0.__setitem__(str_4, str_5)
    obj_0.__setitem__(str_6, str_7)


# Generated at 2022-06-26 03:15:54.669394
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)

    cookiejar['cookie_name1'] = 'foo'
    cookiejar['cookie_name2'] = 'bar'
    cookiejar['cookie_name1'] = 'bar'
    cookiejar['cookie_name3'] = 'foo'

    assert headers.headers == {
        'Set-Cookie': [
            Cookie('cookie_name1', 'bar'),
            Cookie('cookie_name2', 'bar'),
            Cookie('cookie_name3', 'foo'),
        ]
    }



# Generated at 2022-06-26 03:15:56.837629
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = 'host'
    # No exception
    try:
        assert str_0 == Cookie(str_0, str_0).__str__()
    except Exception as e:
        print(e)
        return False
    else:
        return True


# Generated at 2022-06-26 03:16:04.629652
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__setitem__(CookieJar, str_0, str_0)
    assert not CookieJar.__

# Generated at 2022-06-26 03:16:17.486983
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Construct cookie_jar_0
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)

    # Construct cookie_1
    str_0 = 'key'
    str_1 = 'value'
    cookie_1 = Cookie(str_0, str_1)
    str_2 = 'max-age'
    int_0 = -1
    cookie_1[str_2] = int_0

    # Add cookie_1 to cookie_jar_0 as 'key'
    cookie_jar_0['key'] = cookie_1

    # Update cookie_jar_0[key]
    cookie_jar_0['key']['max-age'] = 0
    cookie_jar_0['key'] = ""

    # Delete cookie 'key' from cookie_jar_0
    del cookie_jar_

# Generated at 2022-06-26 03:16:22.960874
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b'5'
    cookie_0 = Cookie(bytes_1, bytes_1)
    bytes_2 = b'string'
    cookie_0['path'] = bytes_2
    bytes_3 = b'key1'
    bytes_4 = b'5-path'
    str_0 = cookie_0.__str__()
    assert str_0 == bytes_4


# Generated at 2022-06-26 03:16:32.532890
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    key_0 = 'key1'
    key_1 = 'key2'
    value_0 = 'value1'
    value_1 = 'value2'
    cookie_0 = Cookie(key_0, value_0)
    cookie_0[key_1] = value_1
    cookie_0.key = key_1
    cookie_0.value = value_1
    cookie_key_0 = cookie_0[key_1]
    expected_0 = 'value2; value1'
    actual_0 = str(cookie_0)
    # Testing Str Compatability
    expected_1 = expected_0
    actual_1 = str(actual_0)
    assert True == (expected_1 == actual_1)


# Generated at 2022-06-26 03:16:36.474453
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    pos_0 = 'key_0'
    cookie_jar_0.__delitem__(pos_0)
    assert True


# Generated at 2022-06-26 03:16:42.024786
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    # This needs to be a proper unit test
    # FIXME: Unresolved reference 'assert_raises' for 'unittest.TestCase'
    # with assert_raises(TestCase, ):
    #     cookie_jar_0.__delitem__(bytes_0)


# Generated at 2022-06-26 03:16:44.833544
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print('test_CookieJar___delitem__')
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0['a'] = 'b'
    del cookie_jar_0['a']


# Generated at 2022-06-26 03:16:46.062549
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert True


# Generated at 2022-06-26 03:16:58.153026
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Method __str__ of class Cookie
    """
    cookie_jar_0 = CookieJar({})
    cookie_jar_0[b'dx'].value = 'blitz'
    cookie_jar_0[b'dx'][b'path'] = '/blitz'

    # second cookie
    cookie_jar_0[b'dy'].value = 'foo'
    cookie_jar_0[b'dx'][b'path'] = '/foo'

    cookie_jar_0[b'dz'].value = 'baz'
    cookie_jar_0[b'dx'][b'path'] = '/baz'

    del cookie_jar_0[b'dx']

    for cookie in cookie_jar_0.values():
        output = str(cookie)
        print(output)



# Generated at 2022-06-26 03:17:00.811451
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b''
    cookie_0 = Cookie(bytes_0, bytes_0)
    str_0 = cookie_0.__str__()


# Generated at 2022-06-26 03:17:03.678788
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_0 = Cookie('', '')
    cookie_jar_0['0'] = cookie_0
    return cookie_jar_0



# Generated at 2022-06-26 03:17:11.703630
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Init
    headers_0 = {}
    cookie_jar_0 = CookieJar(headers_0)
    key_0 = ''
    value_0 = ''
    cookie_jar_0[key_0] = value_0


    # Invoke method __delitem__
    cookie_jar_0.__delitem__(key_0)



# Generated at 2022-06-26 03:17:13.540650
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0['key_0'] = 'value_0'


# Generated at 2022-06-26 03:17:22.174519
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b''
    key_0 = 'hkH(\x8d\x19\xa2\x0c\x9f\xd1\x0b\x19'
    value_0 = '\xc3\x1a\xee\xe2\x08\xda\xbe\x81\xc3\x1a\xee\xe2\x08\xda\xbe\x81'
    assert_0 = "\n# -------- TEST --------\n".encode('UTF-8')

# Generated at 2022-06-26 03:17:29.726306
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b'eyJmb28iOiJiYXIifQ=='
    cookie_jar_0 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__('foobar')
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__('baz')
    with pytest.raises(KeyError):
        cookie_jar_0.__delitem__('foo')


# Generated at 2022-06-26 03:17:40.082064
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cookie_0 = Cookie(headers)
    obj_0 = CookieJar(headers, cookie_0)
    dict_0 = {}
    dict_0['asdf'] = 'qwer'
    key_0 = dict_0['asdf']
    value_0 = None
    obj_0.__setitem__(key_0, value_0)
    key_1 = '1234'
    value_1 = dict_0['1234']
    obj_0.__setitem__(key_1, value_1)
    key_2 = '456'
    value_2 = dict_0['456']
    obj_0.__setitem__(key_2, value_2)
    key_3 = 'asdf'
    value_3 = dict_0['asdf']
    obj_0

# Generated at 2022-06-26 03:17:45.131860
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    response_0 = CookieJar('')
    cookie_value_0 = CookieJar.__delitem__(response_0, __name__)
    assert (cookie_value_0 is None)


# Generated at 2022-06-26 03:17:49.749369
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = "ame"
    cookie_jar_0[str_0] = "CookieJar"
    str_1 = "ame"
    cookie_jar_0.__delitem__(str_1)


# Generated at 2022-06-26 03:17:54.569536
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0["abc"] = 1
    cookie_jar_1 = CookieJar(bytes_0)
    del cookie_jar_1["abc"]
    del cookie_jar_0["abc"]


# Generated at 2022-06-26 03:17:58.071028
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    str_0 = str(cookie)


# Generated at 2022-06-26 03:18:11.094363
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = "a_!B]~6Y#"
    cookie_jar_0[str_0] = str_0
    str_1 = "|5l1]R_Y$"
    str_2 = "^#9@{q3(?z"
    cookie_jar_0[str_1] = str_2
    str_3 = "9IW c_vM"
    cookie_jar_0[str_3] = str_1
    assert str_1 in cookie_jar_0
    str_4 = "Zs/%-?*eGSq=w"
    str_5 = "'GXh*"
    cookie_jar_0[str_4] = str_5

# Generated at 2022-06-26 03:18:16.633197
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    expected = None
    cookie_jar_0 = CookieJar(b'')
    cookie_jar_0['cookiename'] = 1234
    cookie_jar_0.__delitem__('cookiename')


# Generated at 2022-06-26 03:18:29.940727
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(MultiHeader())
    # cookies
    cookie_0 = Cookie('key', 'value')
    cookie_0['path'] = '/'
    cookie_jar_0.cookie_headers['key'] = 'Set-Cookie'
    cookie_jar_0.headers.add('Set-Cookie', cookie_0)
    cookie_jar_0['key'] = 'new value'
    assert cookie_jar_0['key'].value == 'new value'
    # cookie does not exist
    cookie_jar_0['missing_key'] = 'new value'
    assert cookie_jar_0['missing_key'].value == 'new value'


# Generated at 2022-06-26 03:18:38.086522
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar(None)  # TypeError
    cookie_jar_0 = CookieJar()  # TypeError
    cookie_jar_1 = CookieJar("str")
    cookie_jar_1['CookieJar_1'] = "str_1"

    cookie_jar_2 = CookieJar()  # TypeError
    cookie_jar_2['CookieJar_2'] = "str_2"

    cookie_jar_3 = CookieJar(None)
    cookie_jar_3['CookieJar_3'] = "str_3"


# Generated at 2022-06-26 03:18:40.333693
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_1 = b''
    cookie_jar_1 = CookieJar(bytes_1)


# Generated at 2022-06-26 03:18:49.459896
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("--------------------------------------------------")
    print("Testing method __str__ in class Cookie")
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)

    # Test 1
    cookie_jar_0["test1"] = "value1"
    cookie_jar_0["test2"] = "value2"
    cookies_string_0 = cookie_jar_0.set("test3", "value3")
    print("Cookies String Test 1:", cookies_string_0)
    assert cookies_string_0 == "test1=value1; Path=/; test2=value2; Path=/"

    # Test 2
    cookie_jar_0["test1"]["max-age"] = 20
    cookie_jar_0["test3"]["max-age"] = 20
    cookies_string_0 = cookie

# Generated at 2022-06-26 03:18:51.456640
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    assert not hasattr(cookie_jar_0, '__delitem__')


# Generated at 2022-06-26 03:19:03.358783
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    key_0 = 'X-Lang-0'
    value_0 = 'en-US'
    cookie_jar_0.__setitem__(key_0, value_0)
    cookie_0 = Cookie(key_0, value_0)
    cookie_0["path"] = "/"
    cookie_jar_0.cookie_headers[key_0] = cookie_jar_0.header_key
    cookie_jar_0.headers.add(cookie_jar_0.header_key, cookie_0)
    cookie_jar_0.__setitem__(key_0, value_0)
    cookie_0 = Cookie(key_0, value_0)
    cookie_0["path"] = "/"
    cookie_

# Generated at 2022-06-26 03:19:08.925807
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print("test_CookieJar___delitem__")
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    try:
        print(cookie_jar_0["key"])
    except KeyError:
        print("KeyError")
    try:
        del cookie_jar_0["key"]
    except KeyError:
        print("KeyError")


# Generated at 2022-06-26 03:19:18.361027
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_0['']
    cookie_jar_1 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_1['']
    cookie_jar_1.__delitem__('')
    cookie_jar_2 = CookieJar(bytes_0)
    with pytest.raises(KeyError):
        cookie_jar_2['']
    cookie_jar_3 = CookieJar(bytes_0)
    cookie_jar_3.__delitem__('')


# Generated at 2022-06-26 03:19:21.523011
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # get an instance of Cookie
    cookie_instance = Cookie('self.value', 'self.value')
    # get the Unicode representation of the class
    cookie___str__ = str(cookie_instance)
    return


# Generated at 2022-06-26 03:19:30.002168
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b''

# Generated at 2022-06-26 03:19:36.307821
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test_case_0
    bytes_1 = b''
    cookie_jar_1 = CookieJar(bytes_1)
    
    bytes_0 = b''
    cookie_0 = Cookie(bytes_0, bytes_0)
    cookie_0['path'] = '/'
    cookie_0['max-age'] = 3600
    # str_0 = str(cookie_0)
    # 'path=/; Max-Age=3600'


# Generated at 2022-06-26 03:19:39.277805
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b''
    cookie_jar_0['bytes_1'] = bytes_1


# Generated at 2022-06-26 03:19:42.177187
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    str_0 = input()
    assert False # TODO: implement your test here


# Generated at 2022-06-26 03:19:50.458822
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    bytes_0 = b''
    cookie_0 = CookieJar(bytes_0)
    # Testing for raising a TypeError on trying to set a None cookie
    try:
        cookie_0.__setitem__(None, None)
    except:
        pass
    # Testing for raising a KeyError on trying to set a invalid key
    try:
        cookie_0.__setitem__("", None)
    except:
        pass
    # Testing for raising a KeyError on trying to set a reserved key
    try:
        cookie_0.__setitem__("expires", None)
    except:
        pass
    # Testing for not raising a KeyError on trying to set a valid key
    try:
        cookie_0.__setitem__("valid", None)
    except:
        pass



# Generated at 2022-06-26 03:19:59.392852
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    from starlette.responses import Response
    from starlette.testclient import TestClient

    from app import app, cookie_jar

    # CASE: Delete item by key
    cookie_jar['cookie-name'] = "cookie-value"
    assert 'cookie-name' in cookie_jar
    cookie_jar.headers['cookie'] = "cookie-name=cookie-value"
    del cookie_jar['cookie-name']
    assert 'cookie-name' not in cookie_jar
    assert 'Cookie' not in cookie_jar.headers
    
    # CASE: Delete non-existing item
    del cookie_jar["cookie-name"]
    assert 'cookie-name' not in cookie_jar




# Generated at 2022-06-26 03:20:00.288202
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    assert False, "No test implemented"


# Generated at 2022-06-26 03:20:09.688974
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import tempfile
    from io import BytesIO

    # Test with a properly set cookie
    cookie_0 = Cookie('key_0', 'value_0')
    temp_file_0 = tempfile.NamedTemporaryFile()

    cookie_jar_0 = CookieJar(temp_file_0)
    cookie_0['path'] = '/'
    cookie_jar_0['key_0'] = cookie_0

    # Test with an improperly set cookie
    cookie_1 = Cookie('key_1', 'value_1')
    cookie_jar_1 = CookieJar(temp_file_0)
    cookie_1['path'] = '/'
    cookie_1['abc'] = 'abc'
    cookie_jar_1['key_1'] = cookie_1


# Generated at 2022-06-26 03:20:13.985093
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    '''
    Test of method __str__ of class Cookie
    '''
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0[0] = None
    cookie_0 = cookie_jar_0[0]
    str_0 = str(cookie_0)
    return str_0

test_Cookie___str__()
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 03:20:24.288507
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cj = CookieJar(dict())
    cj['_headers'] = {'status': '201'}
    cj['location'] = '/foo'
    cj['cookie'] = 'chocolate'
    value = cj['cookie']
    cj.add('location', 'bar')
    cj.add('key', 'val')
    cj.add('key', 'val2')
    cj.add('key2', 'val3')

    _headers = {
        'Set-Cookie': [
            'location=bar', 'key=val', 'key=val2', 'key2=val3'
        ]
    }
    cj['_headers'] = _headers
    cj['_key_prefix'] = 'cookie'

# Generated at 2022-06-26 03:20:35.033632
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    bytes_0 = b'CookieJar'
    cookie_jar_0 = CookieJar(bytes_0)
    cookie_jar_0['key'] = 'value'
    assert cookie_jar_0['key'].value == 'value'


# Generated at 2022-06-26 03:20:45.599690
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-26 03:20:51.691501
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_1 = b'n6e'
    cookie_jar_1 = CookieJar(bytes_1)
    # First check if the method delivers the correct result
    assert cookie_jar_1.__str__(cookie_jar_1) == "; ".join(output)
    # Second check if the method yields the correct type
    assert isinstance(Cookie___str__(cookie_jar_1), str)



# Generated at 2022-06-26 03:20:53.387308
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar('')
    cookie_jar_0.__delitem__('')


# Generated at 2022-06-26 03:20:57.403856
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    data = b''
    cookie_jar_0 = CookieJar(data)

    # Test for __delitem__ exception
    test_CookieJar___delitem__exception_1()

    # Test for __delitem__ exception
    test_CookieJar___delitem__exception_2()

    # Test for __delitem__ exception
    test_CookieJar___delitem__exception_3()


# Generated at 2022-06-26 03:21:00.974458
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'*Cookie*'
    cookie_jar_0 = CookieJar(bytes_0)
    msg = cookie_jar_0.__str__()
    assert msg == "['*Cookie*']"


# Generated at 2022-06-26 03:21:04.955666
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    bytes_0 = b'/{'
    cookie_jar_0 = CookieJar(bytes_0)
    bytes_1 = b'\x00\x00\x00'
    cookie_0 = Cookie(bytes_0, bytes_1)
    assert cookie_0.__str__() == cookie_0.encode()


# Generated at 2022-06-26 03:21:12.334382
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    bytes_0 = b''
    cookie_jar_0 = CookieJar(bytes_0)
    key_0 = '2i\x1f\x18\x1f\x0f'
    cookie_jar_0.__delitem__(key_0)
    key_1 = None
    cookie_jar_0.__delitem__(key_1)
    key_2 = '\x1a\x1f\x1f\x10'
    cookie_jar_0.__delitem__(key_2)
