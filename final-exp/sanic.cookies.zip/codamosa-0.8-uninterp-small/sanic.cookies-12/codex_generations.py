

# Generated at 2022-06-26 03:11:32.069953
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    cookie["path"] = "baz"
    assert str(cookie) == "foo=bar; Path=baz"


if __name__ == "__main__":
    test_Cookie___str__()

# Generated at 2022-06-26 03:11:33.500293
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    str_0 = ""


# Generated at 2022-06-26 03:11:42.550381
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0.__setitem__('`[r`]', '<0{=k#+')
    float_0 = None
    cookie_jar_0.cookie_headers['`[r`]'] = float_0
    str_0 = '`[r`]'
    cookie_jar_0.__delitem__(str_0)
    dict_0 = dict(domain = '=',
                  httponly = False,
                  max_age = DEFAULT_MAX_AGE,
                  path = '/',
                  version = 0)

# Generated at 2022-06-26 03:11:44.804110
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    str_0 = Cookie(float_0, float_0)


# Generated at 2022-06-26 03:11:50.287264
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    try:
        float_0 = None
        cookie_jar_0 = CookieJar(float_0)
        cookie_jar_0["test"] = "test"
        cookie_jar_0.__delitem__("test")
    except KeyError as e:
        print(e)



# Generated at 2022-06-26 03:11:58.091962
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0.__setitem__("", "")


# Generated at 2022-06-26 03:12:01.079548
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_key_0 = ""
    cookie_jar_0.__setitem__(cookie_key_0, str())



# Generated at 2022-06-26 03:12:06.786162
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """
    Tests the Cookie class __setitem__ method
    """
    key_0 = None
    value_0 = None
    cookie_0 = Cookie(key_0, value_0)
    assert isinstance(cookie_0, Cookie), 'Expected Cookie instance, not %s' %type(cookie_0)
    # Testing for key error exception
    with pytest.raises(KeyError) as error_info:
        cookie_0.__setitem__("domain", None)
        assert "Unknown cookie property" in error_info.value
    # Testing for value error exception
    with pytest.raises(ValueError) as error_info:
        cookie_0.__setitem__("max-age", None)
        assert "Cookie max-age must be an integer" in error_info.value
    # Testing for type error exception

# Generated at 2022-06-26 03:12:11.403116
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    string_0 = None
    float_0 = None
    cookie_0 = Cookie(string_0, float_0)
    cookie_0['max-age'] = 9
    string_1 = cookie_0.__str__()
    assert string_1 == "=9"


# Generated at 2022-06-26 03:12:14.699894
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["cookie_name"] = ""
    return



# Generated at 2022-06-26 03:12:31.087452
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Arrange
    cookie_jar = CookieJar({})
    cookie_jar["cookie_key"] = "cookie_value"
    cookie = cookie_jar["cookie_key"]
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "secure"
    cookie["httponly"] = "httponly"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"

    # Act
    cookie_as_string = str(cookie)

    # Assert
    assert type(cookie_as_string) is str

# Generated at 2022-06-26 03:12:34.769818
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    # Call the method
    cookie_jar_0.__delitem__("")

    # Check the results
    assert "not implemented" is "not implemented"


# Generated at 2022-06-26 03:12:39.081029
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_0 = Cookie("test_cookie_0", "test_value_0")
    cookie_jar_0["test_cookie_0"] = cookie_0
    # AssertionError: Cookie name is a reserved word


# Generated at 2022-06-26 03:12:43.506978
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_0 = Cookie("", float_0)
    print("=== Output from method __str__ of class Cookie ===")
    print(cookie_0)


# Generated at 2022-06-26 03:12:51.661524
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie = Cookie(None, None)
    cookie['expires'] = datetime.now()
    cookie['max-age'] = 60
    cookie['HttpOnly'] = True
    cookie['secure'] = True
    cookie['samesite'] = 'strict'
    cookie['other'] = 'unknown property'
    cookie['path'] = '/'
    assert str(cookie) == 'Set-Cookie: Max-Age=60; Path=/; HttpOnly; Secure; SameSite=strict', 'cookie str() method failed'


# Generated at 2022-06-26 03:13:03.253533
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = -124
    float_1 = -124
    float_1 = -124
    float_1 = -124
    float_1 = -124
    float_2 = -124
    float_2 = -124
    float_2 = -124
    int_1 = 124
    int_2 = 124
    int_3 = 124
    int_4 = 124
    int_5 = 124
    int_6 = 124
    int_7 = 124
    str_0 = "Cookie 'expires' property must be a datetime"
    str_1 = "Cookie max-age must be an integer"
    str_2 = "Unknown cookie property"
    str_3 = "Cookie name is a reserved word"
    str_4 = "Cookie key contains illegal characters"

# Generated at 2022-06-26 03:13:08.852578
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["r;m:l;l"] = ""
    assert not "r;m:l;l" in cookie_jar_0


# Generated at 2022-06-26 03:13:17.844810
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # init cookies
    str0 = "sxKc{#"
    str1 = "P&?X,\nrRt_YOdJVb"
    str2 = "|@(3qfD:_tI{&CX]~t\n"
    str3 = "WG-ZlQa<q>iK,:f/gI\r"
    str4 = ",n[s&sW_x|jd|}?n`$|\n"
    str5 = "UuYzAP=*wj`Wb)8_<-L\n"
    str6 = "&hjz2>u\rP_5w5u5Dxge"

# Generated at 2022-06-26 03:13:20.075714
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    var_0 = cookie_jar_0
    var_1 = var_0["key"]
    del var_0[var_1]



# Generated at 2022-06-26 03:13:25.033097
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    string_0 = None
    datetime_0 = None
    cookie_jar_0 = CookieJar(string_0)
    string_0 = None
    string_1 = None
    assertCookie(cookie_jar_0.__setitem__(string_0, string_1), None, None)
    string_0 = None
    cookie_jar_1 = CookieJar(string_0)
    string_0 = None
    string_1 = None
    assertCookie(cookie_jar_0.__setitem__(string_0, string_1), None, None)
    string_0 = None
    cookie_jar_2 = CookieJar(string_0)
    string_0 = None
    cookie_jar_3 = CookieJar(string_0)
    string_0 = None

# Generated at 2022-06-26 03:13:40.990192
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = None
    string_0 = "test-key"
    float_0.add(string_0, float_1)
    float_1 = "test-value"
    string_0 = "test-key"
    float_0.add(string_0, float_1)
    float_1 = "test-value"
    string_0 = "test-key"
    float_0.add(string_0, float_1)
    float_1 = "test-value"
    string_0 = "test-key"
    float_0.add(string_0, float_1)
    float_1 = "test-value"
    string_0 = "test-key"

# Generated at 2022-06-26 03:13:41.591424
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert True



# Generated at 2022-06-26 03:13:48.757475
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["cookie_jar_0"] = "cookie_jar_0"
    str_0 = cookie_jar_0["cookie_jar_0"].__str__()
    # Verify whether the method str__Dictionary of class Cookie works!
    assert str_0 == "cookie_jar_0=cookie_jar_0; HttpOnly; Path=/; Secure"



# Generated at 2022-06-26 03:13:53.143013
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Case 0
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["d"] = "e"
    assert("d" not in cookie_jar_0)


# Generated at 2022-06-26 03:13:57.449141
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_0 = Cookie(float_0, float_0)
    str_0 = cookie_0.__str__()
    # Verifies if str_0 equals "; ".join(output)
    assert str_0 == "; ".join(output)


# Generated at 2022-06-26 03:14:07.338089
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    def test_case_0(CookieJar):
        float_0 = 'set-cookie'
        cookie_jar_0 = CookieJar(float_0)
        result_0 = cookie_jar_0[0]
        assert result_0 == 'set-cookie'

    def test_case_1(CookieJar):
        float_0 = None
        cookie_jar_0 = CookieJar(float_0)
        result_0 = cookie_jar_0[0]
        assert result_0 == None

    def test_case_2(CookieJar):
        float_0 = 'set-cookie'
        cookie_jar_0 = CookieJar(float_0)
        result_0 = cookie_jar_0[0]
        assert result_0 == 'set-cookie'


# Generated at 2022-06-26 03:14:12.754512
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    key = "foobar"
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0[key] = "dummy"
    assert cookie_jar_0[key].value == "dummy"
    del cookie_jar_0[key]
    assert cookie_jar_0.get(key) is None



# Generated at 2022-06-26 03:14:24.516294
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    def side_effect():
        raise KeyError()
    dict_0 = cookie_jar_0
    dict_0.pop = MagicMock(side_effect=side_effect)
    str_0 = "Tz&'9|k$#J@mZ"
    dict_0.popall = MagicMock(side_effect=side_effect)
    dict_0.add = MagicMock(side_effect=side_effect)
    with raises(KeyError):
        cookie_jar_0.__delitem__(str_0)
    def side_effect():
        pass
    cookie_jar_0.pop = MagicMock(side_effect=side_effect)
    with raises(KeyError):
        cookie_jar_0

# Generated at 2022-06-26 03:14:30.727027
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    str_0 = "test"

    test_cookie = Cookie(str_0, str_0)
    test_cookie["path"] = str_0
    set_cookie_header = test_cookie.__str__()
    assert set_cookie_header == "test=test; Path=test"



# Generated at 2022-06-26 03:14:34.114270
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_obj = Cookie(None, None)
    try:
        cookie_obj.__setitem__(None, None)
    except KeyError:
        pass
    except ValueError:
        pass
    except TypeError:
        pass


# Generated at 2022-06-26 03:14:49.429836
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    float_0 = Cookie('', '')
    cookie_jar_0.__setitem__('', float_0)
    float_0 = Cookie('', 'key')
    cookie_jar_0.__setitem__('', float_0)
    float_0 = Cookie('', 'key')
    cookie_jar_0.__setitem__('', float_0)
    float_0 = Cookie('', 'key')
    cookie_jar_0.__setitem__('', float_0)
    float_0 = Cookie('', 'key')
    cookie_jar_0.__setitem__('', float_0)
    float_0 = Cookie('', 'key')
    cookie_jar_0.__setitem__('', float_0)

# Generated at 2022-06-26 03:14:54.001627
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    string_0 = 'xN>p{eXr*'
    cookie_jar_0[string_0] = string_0
    del cookie_jar_0[string_0]



# Generated at 2022-06-26 03:15:00.234059
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = "CookieJar"
    # PASS: If del cookie_jar_0[float_1] == None
    cookie_jar_0[float_1] = None
    float_2 = "CookieJar"
    # PASS: If del cookie_jar_0[float_2] == None
    cookie_jar_0[float_2] = None
    float_3 = "CookieJar"
    # PASS: If del cookie_jar_0[float_3] == None
    cookie_jar_0[float_3] = None


# Generated at 2022-06-26 03:15:09.820113
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Should raise error when key is illegal
    with pytest.raises(KeyError):
        cookie = Cookie("=key=", "value")
    # Should raise error when key is a reserved word
    with pytest.raises(KeyError):
        cookie = Cookie("expires", "value")
        cookie["expires"] = 12345
    # Should raise error when max-age is not an integer
    with pytest.raises(ValueError):
        cookie = Cookie("key", "value")
        cookie["max-age"] = "12345"



# Generated at 2022-06-26 03:15:12.429986
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_1 = None
    cookie_jar_1 = CookieJar(float_1)
    cookie_jar_1.__delitem__("")


# Generated at 2022-06-26 03:15:21.753822
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    map_key_0 = "q3q9IsCv^2"
    dict_0 = cookie_jar_0.__delitem__(map_key_0)
    map_key_1 = "jO.E7_y,Y"
    dict_1 = cookie_jar_0.__delitem__(map_key_1)
    map_key_2 = "+(?p8[wG"
    dict_2 = cookie_jar_0.__delitem__(map_key_2)
    map_key_3 = "5j*M~a]12"
    dict_3 = cookie_jar_0.__delitem__(map_key_3)

# Generated at 2022-06-26 03:15:26.403366
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = 0
    cookie_jar_1 = Cookie(float_1, float_0)
    float_2 = 0
    cookie_jar_2 = Cookie(float_2, float_0)
    cookie_jar_2["comment"] = float_0
    cookie_jar_2["domain"] = float_0
    cookie_jar_2["expires"] = float_0
    cookie_jar_2["max-age"] = float_0
    cookie_jar_2["path"] = float_0
    cookie_jar_2["version"] = float_0
    result = cookie_jar_2.__str__()
    return 0


# Generated at 2022-06-26 03:15:31.161629
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_1 = 1.0
    cookie_jar_1 = CookieJar(float_1)
    float_2 = 2.0
    cookie_jar_1.__setitem__(float_1, float_2)
    cookie_jar_1.__delitem__(float_1)


# Generated at 2022-06-26 03:15:42.163619
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    str_0 = "a"
    cookie_jar_0[str_0] = ""
    cookie_jar_0[str_0]["max-age"] = 0
    assert [str_0] == cookie_jar_0.keys()
    assert ["" if DEFAULT_MAX_AGE else None] == cookie_jar_0.values()
    assert cookie_jar_0[str_0] == cookie_jar_0[str_0]
    assert cookie_jar_0[str_0] != True
    del cookie_jar_0[str_0]
    assert [] == cookie_jar_0.keys()
    assert [] == cookie_jar_0.values()
    assert cookie_jar_0[str_0] != cookie_jar

# Generated at 2022-06-26 03:15:48.256283
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = None
    str_0 = None
    cookie_jar_0[float_1] = str_0
    float_2 = None
    try:
        del cookie_jar_0[float_2]
    except KeyError as e:
        pass


# Generated at 2022-06-26 03:16:01.440906
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

# Generated at 2022-06-26 03:16:12.439210
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    cookie_1 = Cookie("name_0", "value_0")
    cookie_1["expires"] = datetime(
        year=int(2014), month=int(2), day=int(6), hour=int(4), minute=int(38), second=int(11)
    )
    cookie_1["path"] = "/"
    cookie_1["comment"] = "comm_0"
    cookie_1["domain"] = "dom_0"
    cookie_1["secure"] = True
    cookie_1["httponly"] = True
    cookie_1["samesite"] = "strict"


# Generated at 2022-06-26 03:16:17.027637
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    Simple test case for CookieJar.__setitem__
    """
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    str_0 = str(float_0)
    cookie_jar_0.__setitem__(str_0, float_0)

# Generated at 2022-06-26 03:16:24.636233
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == "; "
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == "; "
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == "; "
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == "; "
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == "; "
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == "; "
    cookie_0 = Cookie(float_0, float_0)

# Generated at 2022-06-26 03:16:27.102212
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    string_0 = cookie_jar_0.__delitem__()


# Generated at 2022-06-26 03:16:34.795222
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    # Code coverage for __str__
    cookie_0 = cookie_jar_0.get("COOKIE_NAME")
    if cookie_0 is not None:
        # Get the cookie and print it out
        try:
            value_0 = str(cookie_0).encode(encode)
        except UnicodeEncodeError as e_0:
            #need to do something here
            pass


# Generated at 2022-06-26 03:16:44.399835
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_2 = None
    cookie_jar_2 = CookieJar(float_2)
    float_1 = None
    str_1 = ''
    float_3 = None
    cookie_jar_2.__setitem__(float_1, str_1)

    float_4 = None
    cookie_jar_2 = CookieJar(float_4)
    float_3 = None
    str_3 = ''
    float_5 = None
    cookie_jar_2.__setitem__(float_3, str_3)

    float_6 = None
    cookie_jar_2 = CookieJar(float_6)
    float_5 = None
    str_5 = ''
    float_7 = None
    cookie_jar_2.__setitem__(float_5, str_5)

    float_8 = None


# Generated at 2022-06-26 03:16:52.501852
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    # Set the value of attribute
    cookie_jar_0.headers = {'Content-Type': 'application/json'}
    # Test if the expected result is equal to the actual result
    assert cookie_jar_0.headers == {'Content-Type': 'application/json'}, \
        'Test failed: Cookie.__str__() method test failed!'


# Generated at 2022-06-26 03:16:55.582888
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    dict_0 = CookieJar(float_0)
    dict_0.__delitem__(dict_0)
    dict_0.__delitem__(dict_0)


# Generated at 2022-06-26 03:16:57.202167
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_1 = None
    cookie_jar_1 = CookieJar(float_1)


# Generated at 2022-06-26 03:17:08.638227
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    assert_raises(KeyError, cookie_jar_0.__setitem__, "0.6", 'U6')


# Generated at 2022-06-26 03:17:11.399590
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar_0 = CookieJar(None)
    str_0 = 'SAMEORIGIN'
    cookie_jar_0['Set-Cookie'] = str_0


# Generated at 2022-06-26 03:17:13.456412
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Prepare
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    # Invoke method
    cookie_jar_0.__delitem__("test_key")



# Generated at 2022-06-26 03:17:15.916070
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = None
    key = "test_Cookie___setitem__"
    value = "test_Cookie___setitem__"
    cookie_jar_0[key] = float_1

    assert float_1 == cookie_jar_0[key].value
    cookie_jar_0[key] = value

    assert value == cookie_jar_0[key].value


# Generated at 2022-06-26 03:17:21.713587
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie_1 = Cookie('key', 'value')
    cookie_jar_0['cookie_1'] = cookie_1
    result_1 = str(cookie_1)

    assert result_1 == 'key=value'
    assert 'key' in cookie_jar_0
    assert cookie_jar_0['key'].value == 'value'


# Generated at 2022-06-26 03:17:32.972119
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie_0 = Cookie("key_0", "value_0")
    cookie_0["max-age"] = str(1)
    cookie_0["max-age"] = 0
    cookie_0["expires"] = datetime.now()
    cookie_0["expires"] = datetime.now()
    cookie_0["path"] = "/"
    cookie_0["comment"] = "comment_0"
    cookie_0["domain"] = "example.com"
    cookie_0["max-age"] = 0
    cookie_0["secure"] = True
    cookie_0["httponly"] = False
    cookie_0["version"] = "1"
    cookie_0["samesite"] = "strict"
    cookie_0.encode("utf-8")


# Generated at 2022-06-26 03:17:42.318197
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c1 = Cookie("1", "1")
    c1["bb"] = "2"
    c1["cc"] = "3"
    assert c1["bb"] == "2"
    assert c1["cc"] == "3"
    assert c1.value == "1"
    assert c1.key == "1"
    assert c1["max-age"] == 0

    assert c1.encode("utf-8") == "1=1; Max-Age=0; bb=2; cc=3"
    # c1["expires"] = datetime.now()
    # assert "expires" in c1
    # c1["secure"] = True
    # assert "secure" in c1
    # c1["httponly"] = True
    # assert "httponly" in c1



# Generated at 2022-06-26 03:17:53.721487
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-26 03:17:56.634909
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)


# Generated at 2022-06-26 03:18:03.447505
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0[0] = 0
    str_0 = cookie_jar_0[0]
    del cookie_jar_0[0]


# Generated at 2022-06-26 03:18:13.215533
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar_0 = CookieJar({})
    assert_equal(cookie_jar_0.__delitem__(0.5), NotImplemented)


# Generated at 2022-06-26 03:18:16.333854
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = None
    try:
        cookie_jar_0.__delitem__(float_1)
        assert False
    except:
        assert True


# Generated at 2022-06-26 03:18:17.744337
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    string_0 = None
    cookie_0 = Cookie(string_0, None)


# Generated at 2022-06-26 03:18:24.015805
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("test", "test_value")
    assert cookie_0.__str__() == cookie_0.output()



# Generated at 2022-06-26 03:18:29.727569
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    num_0 = None
    num_1 = None
    cookie_jar_0 = CookieJar(num_0)
    # Assert: AssertionError
    try:
        cookie_jar_0.__delitem__(num_1)
    except AssertionError:
        print("AssertionError")



# Generated at 2022-06-26 03:18:32.944408
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    string_0 = None
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0[string_0] = "test"
    del cookie_jar_0["test"]


# Generated at 2022-06-26 03:18:39.002743
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    for _ in range(10):
        float_0 = None
        cookie_jar_0 = CookieJar(float_0)
        for _ in range(10):
            cookie_0 = CookieJar(float_0)
            cookie_0["path"] = "/"
            cookie_jar_0.__setitem__(cookie_0, 1)


# Generated at 2022-06-26 03:18:46.145369
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0["my_cookie"] = "my_value"
    cookie_jar_0["my_cookie"]["max-age"] = 123
    test_Cookie___str__.actual = str(cookie_jar_0["my_cookie"])
    test_Cookie___str__.expected = 'my_cookie=my_value; Max-Age=123'
    assert test_Cookie___str__.actual == test_Cookie___str__.expected


# Generated at 2022-06-26 03:18:53.599057
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    str_0 = "CookieJar.__setitem__"
    str_1 = "CookieJar.__setitem__"
    cookie_jar_0[str_0] = str_1
    var_0 = cookie_jar_0.headers
    var_1 = cookie_jar_0.header_key
    var_2 = cookie_jar_0.header_key
    int_0 = var_0.get(var_1, var_2)
    str_2 = "CookieJar.__setitem__"
    str_3 = "CookieJar.__setitem__"
    cookie_jar_0[str_2] = str_3
    print(int_0)


# Generated at 2022-06-26 03:19:04.980826
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    float_0 = type("",(),{'add': (lambda self, arg_0, arg_1: type("",(),{'key': arg_0 + arg_1})), 'get': (lambda self, arg_0: arg_0), 'popall': (lambda self, arg_0: arg_0)})()
    dict_0 = dict()
    dict_0["0"] = type("",(),{'__init__': (lambda self, arg_0, arg_1: super().__init__()), '__setitem__': (lambda self, arg_0, arg_1: type("",(),{'__setitem__': (lambda self, arg_0, arg_1: arg_1), '__str__': (lambda self: "")})()), '__str__': (lambda self: "")})()
    cookie_jar_

# Generated at 2022-06-26 03:19:23.195521
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_0 = None

# Generated at 2022-06-26 03:19:25.392430
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_1 = CookieJar(float_0)
    cookie_jar_1.__delitem__("key")


# Generated at 2022-06-26 03:19:27.205550
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    str_0 = None
    float_0 = None
    cookie_0 = Cookie(str_0, float_0)


# Generated at 2022-06-26 03:19:30.363934
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Initialization
    float_0 = None
    cookie_0 = Cookie(float_0, float_0)

    # Function call
    cookie_0.__str__()


# Generated at 2022-06-26 03:19:33.453102
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
  float_0 = None
  param_0 = Cookie(float_0, None)
  cookie_base_0 = param_0.__str__()
  print(cookie_base_0)

# Generated at 2022-06-26 03:19:42.578424
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = 5
    return_value_0 = abs(float_0)
    return_value_1 = -float_0
    return_value_2 = ~float_0
    return_value_3 = not float_0
    cookie_0 = Cookie(return_value_0, return_value_1)
    cookie_0["max-age"] = return_value_2
    cookie_0["expires"] = return_value_3
    cookie_0["expires"] = return_value_0
    cookie_0["max-age"] = None
    return_value_4 = cookie_0.encode(float_0)
    return_value_5 = str(cookie_0)


# Generated at 2022-06-26 03:19:47.236267
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    # See that we don't need to add the cookie first
    cookie_jar_0.__delitem__("foo")
    # See that we can add it and remove it
    cookie_jar_0.__setitem__("foo", "bar")
    cookie_jar_0.__delitem__("foo")


# Generated at 2022-06-26 03:19:49.316702
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    try:
        cookie_jar_0 = CookieJar(1)
        str_0 = None
        str_1 = None
        cookie_jar_0.__setitem__(str_0, str_1)
    except:
        print("Exception caught")


# Generated at 2022-06-26 03:19:56.120641
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)

    # Check if CookieJar.__delitem__() deletes the cookies in the given HTTP
    # headers
    cookie_jar_0["test"] = "test"
    assert ("test" == list(cookie_jar_0.keys())[0])
    cookie_jar_0.__delitem__("test")
    assert (not bool(cookie_jar_0))



# Generated at 2022-06-26 03:20:05.379399
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Simple creation of the object with explicit typing
    dict_0 = dict()
    cookie_0: Cookie = Cookie('b', dict_0)
    str_0 = cookie_0.__str__()
    assert str_0 == 'b=None; Path=None; Comment=None; Domain=None; Max-Age=None; Secure; HttpOnly; Version=None; SameSite=None'
    # Simple creation of the object with implicit typing
    dict_0 = dict()
    cookie_0 = Cookie('b', dict_0)
    str_0 = cookie_0.__str__()
    assert str_0 == 'b=None; Path=None; Comment=None; Domain=None; Max-Age=None; Secure; HttpOnly; Version=None; SameSite=None'



# Generated at 2022-06-26 03:20:26.501447
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Test cases
    float_0 = None
    cookie_0 = Cookie(float_0, float_0)
    cookie_0[float_0] = float_0
    cookie_1 = Cookie(float_0, float_0)
    cookie_1["path"] = float_0
    cookie_2 = Cookie(float_0, float_0)
    cookie_2[float_0] = float_0
    cookie_3 = Cookie(float_0, float_0)
    cookie_3["path"] = float_0
    cookie_4 = Cookie(float_0, float_0)
    cookie_4[float_0] = float_0
    cookie_5 = Cookie(float_0, float_0)
    cookie_5["path"] = float_0

# Generated at 2022-06-26 03:20:34.020519
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is the variable name of the value of the expression x[:]
    # string_0 is

# Generated at 2022-06-26 03:20:37.519198
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    set_cookie_0 = CookieJar(None)
    set_cookie_0.__setitem__(None, None)
    set_cookie_0.__delitem__(None)


# Generated at 2022-06-26 03:20:39.770611
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_0 = Cookie("foo", "bar")
    assert "foo=bar" == str(cookie_0)


# Generated at 2022-06-26 03:20:42.437340
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    float_1 = None
    cookie_jar_1 = CookieJar(float_1)
    string_0 = None
    str_0 = cookie_jar_1.__delitem__(string_0)


# Generated at 2022-06-26 03:20:45.634189
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    arg_key = 'test'
    arg_value = 'test'
    with CookieJar(headers = {}) as cookie_jar:
        cookie_jar[arg_key] = arg_value


# Generated at 2022-06-26 03:20:51.150209
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_key_0 = 's;N:z;I'
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    cookie_jar_0[cookie_key_0] = 1.67995500738036
    del cookie_jar_0[cookie_key_0]


# Generated at 2022-06-26 03:20:55.256594
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test for method Cookie.__str__ ():
    float_0 = None
    cookie_0 = Cookie(float_0, float_0)
    assert str(cookie_0) == 'a=a'  # Make sure it's correctly quoting
    # Test for method Cookie.__str__ ():
    float_1 = None
    cookie_1 = Cookie(float_1, float_1)
    assert str(cookie_1) == 'a=a'  # Make sure it's correctly quoting


# Generated at 2022-06-26 03:21:04.381619
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie_jar_0["test_key_0"] = 4
    cookie_jar_0["test_key_0"]["test_key_1"] = 3.0
    assert cookie_jar_0["test_key_0"].__str__() == "test_key_0=4; Path=3.0"
    cookie_jar_0["test_key_0"]["test_key_2"] = "test_string_0"
    assert cookie_jar_0["test_key_0"].__str__() == 'test_key_0=4; Path=3.0; Path="test_string_0"'
    cookie_jar_0["test_key_0"]["test_key_3"] = True

# Generated at 2022-06-26 03:21:11.026367
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_jar_0 = CookieJar(None)
    cookie_0 = Cookie("", "")
    float_0 = float("None")
    cookie_0[float_0] = "No"
    try:
        float_0 = float("None")
        cookie_0[float_0] = 0
    except Exception as e:
        assert type(e) == KeyError
    assert str(cookie_0) == "=; Path=No; Max-Age=0"


# Generated at 2022-06-26 03:21:26.981629
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    float_0 = None
    cookie_jar_0 = CookieJar(float_0)
    float_1 = None
    cookie_jar_0["c"] = float_1

    try:
        cookie_jar_0["c"]["max-age"] = "text"
    except ValueError as exception:
        assert exception.args and type(exception.args) is tuple
        assert exception.args[0] == "Cookie max-age must be an integer"
    else:
        assert False
    try:
        "test".encode("ascii")
    except UnicodeEncodeError as exception:
        assert exception.args and type(exception.args) is tuple
        assert exception.args[0] == "test"
        assert exception.args[1] == 4
        assert exception.args[2] == 4