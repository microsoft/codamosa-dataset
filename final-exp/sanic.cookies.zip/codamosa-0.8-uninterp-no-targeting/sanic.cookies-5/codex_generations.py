

# Generated at 2022-06-21 22:40:09.001928
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers=MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["cookie_key"] = "cookie_value"
    assert "cookie_key=cookie_value" in str(cookie_jar)
    cookie_jar["cookie_key"] = "cookie_value2"
    assert "cookie_key=cookie_value2" in str(cookie_jar)
    del cookie_jar["cookie_key"]
    assert "cookie_key=cookie_value2" not in str(cookie_jar)

# Generated at 2022-06-21 22:40:16.167473
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers(content_type="text/plain", server="Werkzeug/0.15.0")
    cookies = CookieJar(headers)
    # no error will be emitted when delete an not existing cookie
    cookies.__delitem__("cookie_name")
    # add a cookie
    cookies["cookie_name"] = "cookie_value"
    # delete the cookie
    cookies.__delitem__("cookie_name")
    # check header
    if "cookie_name=cookie_value; Path=/; Max-Age=0" not in cookies.headers["Set-Cookie"]:
       return "Error"
    return "Success"



# Generated at 2022-06-21 22:40:19.541821
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    assert cookie.key == key
    assert cookie.value == value
    assert cookie.items() == []


# Generated at 2022-06-21 22:40:31.459868
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar['a'] = 'a'
    assert headers['Set-Cookie'] == 'a=a; Path=/'
    jar['b'] = 'b'
    jar['c'] = 'c'
    assert headers['Set-Cookie'] == 'a=a; Path=/\nb=b; Path=/\nc=c; Path=/'
    jar['a'] = 'a new'
    assert headers['Set-Cookie'] == 'a=a new; Path=/\nb=b; Path=/\nc=c; Path=/'
    jar['b'] = 'b new'
    assert headers['Set-Cookie'] == 'a=a new; Path=/\nb=b new; Path=/\nc=c; Path=/'



# Generated at 2022-06-21 22:40:34.758897
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    """
    Checks if method encode of class Cookie works properly, 
    encoding the Cookie with the defined encoding.
    """
    cookie_value = "123456789"
    cookie_key = "cookie_key"
    cookie = Cookie(cookie_key, cookie_value)
    assert cookie_value in cookie.encode("utf-8")
    assert cookie_key in cookie.encode("utf-8")

# Generated at 2022-06-21 22:40:39.547590
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = {'content-type': ['text/plain; charset=utf-8']}
    cookie_jar = CookieJar(headers)
    assert cookie_jar == {}
    assert headers['Set-Cookie'] == []


# Generated at 2022-06-21 22:40:46.321633
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    cookies = CookieJar({})
    cookies["a"] = 1
    cookies["b"] = 2
    cookies["c"] = 3

    assert cookies["a"] == 1
    assert cookies["b"] == 2
    assert cookies["c"] == 3

    cookies.delete("b")
    cookies.delete("c")

    assert cookies["a"] == 1
    assert cookies.get("b") == None
    assert cookies.get("c") == None

# unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-21 22:40:52.161600
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    header = MultiHeader()
    cookie_jar = CookieJar(header)
    cookie_jar['one'] = 'one'
    cookie_jar['two'] = 'two'

    # Test deletion of keys present in cookie
    del cookie_jar['one']
    assert 'one' not in list(cookie_jar.keys())
    assert 'one' not in list(cookie_jar.values())
    assert 'one' not in list(cookie_jar.cookie_headers.keys())
    assert 'one' not in list(header.keys())

    # Test deletion of keys not present in cookie
    del cookie_jar['two']
    assert 'two' not in list(cookie_jar.keys())
    assert 'two' not in list(cookie_jar.values())
    assert 'two' not in list(cookie_jar.cookie_headers.keys())


# Generated at 2022-06-21 22:40:56.407429
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("test", "foo bar")
    assert c["path"] == "/"
    assert c.value == "foo bar"
    assert c.key == "test"


# Generated at 2022-06-21 22:41:02.100514
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    """Unit test for method __setitem__ of class Cookie."""
    cookie = Cookie("foo", "bar")
    for key, value in dict(foo=1, bar=2, foo_bar=3, foo1=4).items():
        try:
            cookie[key] = value
        except KeyError as exc:
            if key in cookie._keys:
                continue
            raise Exception(
                "Unexpected exception raised: %s" % type(exc)
            )
    for value in (1, "a", None):
        try:
            cookie["foo"] = value
        except KeyError:
            continue

# Generated at 2022-06-21 22:41:12.470954
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie(key = 'mycookie',value = 'cookievalue')
    assert cookie['key'] == 'mycookie'
    assert cookie['value'] == 'cookievalue'



# Generated at 2022-06-21 22:41:16.455486
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test", "Awesome")
    assert cookie.encode("utf-8") == b"test=Awesome"
    assert cookie.encode("latin-1") == b"test=Awesome"



# Generated at 2022-06-21 22:41:20.693730
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    my_headers = MultiHeader("Set-Cookie")
    cookie_jar = CookieJar(my_headers)
    cookie_jar["my_key"] = "my_value"
    assert "my_key" in cookie_jar
    assert "my_key=my_value; Path=/" in my_headers["Set-Cookie"]


# Generated at 2022-06-21 22:41:25.438702
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('key', 'value')
    assert "key" in cookie.keys()
    cookie["expires"] = "2016-03-14T14:25:27.141414"
    assert cookie["expires"] == "2016-03-14T14:25:27.141414"


# Generated at 2022-06-21 22:41:33.220068
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie(
        'ck',
        'Now we can start to use Cookie for free, but surely with limitation.')
    ck['domain'] = '127.0.0.1'
    ck['max-age'] = '100'
    ck['secure'] = True
    ck['httponly'] = True
    test_string = (
        'ck=Now we can start to use Cookie for free, but surely with limitation.; '
        'Domain=127.0.0.1; Max-Age=100; Secure; HttpOnly'
    )
    assert str(ck) == test_string

# Generated at 2022-06-21 22:41:40.259986
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """Test CookieJar___delitem__"""
    headers = MultiHeaderDict()
    headers.add("Set-Cookie", "foo=bar")
    headers.add("Set-Cookie", "bizz=bazz")
    cj = CookieJar(headers)
    cj.__delitem__("foo")
    assert("foo=bar" not in cj)


# Generated at 2022-06-21 22:41:48.602875
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["type"] = "ninja"
    print("Cookie header before deletion : ", headers["Set-Cookie"])
    print("Cookie data before deletion   : ", cookie_jar)
    print("Deleting cookie")
    del cookie_jar["type"]
    print("Cookie header after deletion  : ", headers["Set-Cookie"])
    print("Cookie data after deletion    : ", cookie_jar)

if __name__ == '__main__':
    test_CookieJar___delitem__()

# Generated at 2022-06-21 22:41:52.640340
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    value = "Sample-cookie"
    encoding = "utf-8"
    cookie = Cookie("cookie-name",value)
    assert cookie.encode(encoding) == value.encode(encoding)
    assert type(cookie.encode(encoding)) == bytes

# Generated at 2022-06-21 22:41:56.104860
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    assert isinstance(cookies, dict)
    assert isinstance(cookies, CookieJar)
    assert cookies.headers == headers
    assert cookies.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:41:57.764101
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["key"] = "value"
    assert cookie["key"] == "value"


# Generated at 2022-06-21 22:42:13.626340
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("blah", "whatever")
    cookie["path"] = "/"
    cookie["expires"] = datetime.utcnow()
    cookie["max-age"] = 10
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["comment"] = "This is a test"
    cookie["domain"] = "locahost"
    cookie["samesite"] = "lax"
    try:
        cookie["crazy"] = "bananas"
    except KeyError:
        pass
    else:
        raise AssertionError("Cookie should not accept random keys")

    try:
        cookie["max-age"] = "whoops"
    except ValueError:
        pass

# Generated at 2022-06-21 22:42:23.436115
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Factory.SimpleHeaders()
    cookie_jar = CookieJar(headers)
    headers.add('ted', 'was here first')
    headers.add('cookie', 'chocolate chip')
    cookie_jar['summer'] = 'Love is Blue'
    cookie_jar['winter'] = 'Rock-a-bye my baby'
    cookie_jar['spring'] = 'Welcome back my Friends to the show that never ends'
    headers['cookie'] = 'Cookie is not a cookie'
    print(headers)
    assert headers['Set-Cookie'] == 'summer=Love+is+Blue; Path=/'


# Generated at 2022-06-21 22:42:27.761693
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'key'
    assert(key not in Cookie._keys)
    value = 'value'
    cookie = Cookie(key, value)

    # TEST1: should raise KeyError
    try:
        cookie['expires'] = datetime.now()
    except KeyError as err:
        assert(err == KeyError("Unknown cookie property"))
    else:
        assert(False)
    # TEST2: should raise ValueError
    try:
        cookie['max-age'] = 'a'
    except ValueError as err:
        assert(err == ValueError("Cookie max-age must be an integer"))
    else:
        assert(False)
    # TEST3: should raise TypeError

# Generated at 2022-06-21 22:42:33.585617
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader(["Set-Cookie", "set-cookie"])
    cookiejar = CookieJar(headers)
    assert len(cookiejar) == 0
    assert cookiejar.headers == headers
    assert cookiejar.cookie_headers == {}
    assert cookiejar.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:42:41.242736
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cook = Cookie("foo", "bar")
    assert str(cook) == "foo=bar"

    cook = Cookie("foo", "bar")
    cook["path"] = "/"
    assert str(cook) == "foo=bar; Path=/"

    cook = Cookie("foo", "bar")
    cook["path"] = "/"
    cook["max-age"] = 120
    assert str(cook) == "foo=bar; Path=/; Max-Age=120"

    cook = Cookie("foo", "bar")
    cook["path"] = "/"
    cook["max-age"] = 120
    cook["comment"] = "some comments"
    assert (
        str(cook)
        == "foo=bar; Path=/; Max-Age=120; Comment=some comments"
    )

    cook = Cookie("foo", "bar")


# Generated at 2022-06-21 22:42:44.373593
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cj = CookieJar(headers)
    assert type(cj) is CookieJar


# Generated at 2022-06-21 22:42:46.983608
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('nick', 'Aquarius')
    assert cookie.encode('utf-8') == b'nick=Aquarius'
    assert cookie.encode('ascii') == b'nick=Aquarius'

# Generated at 2022-06-21 22:42:50.492634
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers: Dict[str, str] = dict()
    cookies = CookieJar(headers)
    cookies["test"] = "test"

    assert headers["Set-Cookie"] == "test=test; Path=/; Max-Age=0"



# Generated at 2022-06-21 22:43:00.243693
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cj = CookieJar(headers)
    cj["key"] = "value1"
    assert headers.getall("Set-Cookie")[0].key == "key"
    assert headers.getall("Set-Cookie")[0].value == "value1"
    cj["key"] = "value2"
    assert headers.getall("Set-Cookie")[0].key == "key"
    assert headers.getall("Set-Cookie")[0].value == "value2"
    assert "key" in cj
    assert cj["key"] == headers.getall("Set-Cookie")[0]


# Generated at 2022-06-21 22:43:09.212944
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c.expires = datetime(year=2020, month=1, day=1)
    assert str(c) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["httponly"] = True
    assert str(c) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; HttpOnly"
    c["secure"] = True
    assert str(c) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly"


# ------------------------------------------------------------ #
#  Response Cookies Mixin
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:43:35.090312
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    fake_cookie = Cookie('fake_name', 'fake_value')
    assert isinstance(fake_cookie, dict), 'fake_cookie is not dict'
    assert isinstance(fake_cookie.__str__(), str), "Cookie.__str__() does not return a str"


# Generated at 2022-06-21 22:43:46.084914
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("name", "value")
    assert cookie.key == 'name'
    assert cookie['key'] == 'name'
    assert cookie.value == 'value'

    # Set and get use the same logic.
    # The set logic has better exception handling so we'll use that.
    cookie['version'] = 1
    assert cookie['version'] == 1
    assert cookie['version'] == cookie['Version']
    assert cookie['version'] == cookie['VERSION']
    assert cookie.get('version') == 1

    cookie['secure'] = True
    assert cookie['secure'] == True
    assert cookie['secure'] == cookie['Secure']
    assert cookie['secure'] == cookie['SECURE']
    assert cookie.get('secure') == True

    cookie['httponly'] = True
    assert cookie['httponly'] == True

# Generated at 2022-06-21 22:43:51.907105
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('key', 'value')
    assert cookie['key'] == 'value'
    assert cookie['Path'] == '/'
    assert cookie.key == 'key'
    assert cookie.value == 'value'
    assert str(cookie) == 'key=value; Path=/'
    cookie['max-age'] = '200'
    assert str(cookie) == 'key=value; Path=/; Max-Age=200'



# Generated at 2022-06-21 22:43:59.655748
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie('key', 'value')
    assert c.encode('ascii') == b'key=value'
    c['expires'] = datetime.now()
    assert c.encode('ascii') == b'key=value; Expires=Wed, 10-Jul-2013 14:36:04 GMT'
    c['max-age'] = 1
    assert c.encode('ascii') == b'key=value; Expires=Wed, 10-Jul-2013 14:36:04 GMT; Max-Age=1'


# Generated at 2022-06-21 22:44:00.824503
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("foo", "bar")
    assert cookie["path"] == "/"


# Generated at 2022-06-21 22:44:04.760431
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cj = CookieJar(headers)
    assert (headers==cj.headers)
    assert (headers["Set-Cookie-0"] == None)
    assert ("Set-Cookie-0" not in cj.cookie_headers)

# Unit tests for add and delete methods of class CookieJar

# Generated at 2022-06-21 22:44:13.586363
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime(2025, 12, 31, 23, 59, 59)
    cookie["secure"] = True
    cookie["httponly"] = True
    assert (
        str(cookie) == "test=value; expires=Wed, 31-Dec-2025 23:59:59 GMT; Path=\\/; Secure; HttpOnly"
    )

# ------------------------------------------------------------ #
#  Utilities
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:44:18.353084
# Unit test for constructor of class Cookie
def test_Cookie():
    c1 = Cookie("my", "value")
    c1["path"] = "/"
    c1["httponly"] = True
    c1["secure"] = True
    c1["expires"] = "9 sep 2020"
    print(c1) # should print Set-Cookie: my=value ; Path=/ ; Expires=9 sep 2020 ; HttpOnly ; Secure


# Generated at 2022-06-21 22:44:20.358329
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('key', 'value')
    assert cookie.encode('utf-8') == b'key=value; Path=/; HttpOnly'

# Generated at 2022-06-21 22:44:28.731845
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("hello", "world")
    cookie["path"] = "/"
    assert str(cookie) == "hello=world; Path=/"
    cookie["path"] = "/foo"
    assert str(cookie) == "hello=world; Path=/foo"
    cookie["path"] = None
    assert str(cookie) == "hello=world"
    cookie["httponly"] = True
    assert str(cookie) == "hello=world; HttpOnly"
    cookie["expires"] = datetime(2018, 1, 1)
    assert (
        str(cookie)
        == "hello=world; Expires=Mon, 01-Jan-2018 00:00:00 GMT; HttpOnly"
    )
    cookie["max-age"] = 30

# Generated at 2022-06-21 22:44:53.740482
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_cookie = Cookie("test", "success")
    test_cookie['path'] = "/"
    test_cookie['max-age'] = 1240
    test_cookie['expires'] = datetime.strptime("2018/12/12 08:00:00", "%Y/%m/%d %H:%M:%S")
    test_cookie['secure'] = True
    print(test_cookie)



# Generated at 2022-06-21 22:45:04.700411
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie_key = 'test'
    cookie_value = 'python'
    cookie = Cookie(cookie_key, cookie_value)

    assert cookie.key == 'test'
    assert cookie.value == 'python'
    assert cookie.encode('utf8') == "\x74\x65\x73\x74=\x70\x79\x74\x68\x6f\x6e".encode("utf8")
    assert cookie['path'] == "/"
    assert cookie['secure'] == False
    assert cookie['httponly'] == False

    cookie['path'] = "/hello"
    assert cookie['path'] == "/hello"
    cookie['secure'] = True
    assert cookie['secure'] == True
    cookie['httponly'] = True
    assert cookie['httponly'] == True


# Generated at 2022-06-21 22:45:11.781796
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Cookie content will be encoded in utf-8 to be set in HTTP headers
    try:
        cookie = Cookie("test", "stuff")
        assert cookie.encode("utf-8") == b"test=stuff"
        assert isinstance(cookie.encode("utf-8"), bytes)
    except UnicodeEncodeError:
        # Raised when encoding is not supported by python by default.
        # User can add custom encodings for python to use with the method
        # .encode()
        raise UnicodeEncodeError


# Generated at 2022-06-21 22:45:15.803376
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("encoded", "cookie")
    encoded = cookie.encode("utf-8")
    assert isinstance(encoded, bytes), "Encoded result is not a bytes"
    assert b"=%c3%a7" in encoded, "Encoded result does not contain utf-8 representation"

# Generated at 2022-06-21 22:45:27.115455
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)

    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"

    # Test delete existing keys
    cookie_jar.__delitem__("key1")
    assert len(headers) == 1
    assert headers.getall("Set-Cookie")[0] == 'key2="value2"; Path=/'
    assert "key1" not in cookie_jar

    # Test delete non-existing keys
    cookie_jar.__delitem__("key3")
    assert len(headers) == 2
    assert headers.getall("Set-Cookie")[0] == 'key2="value2"; Path=/'

# Generated at 2022-06-21 22:45:32.261875
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    del cookie_jar["foo"]
    assert headers["Set-Cookie"] == "foo=bar; path=/; max-age=0"


# Generated at 2022-06-21 22:45:35.065516
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiDict()
    test = CookieJar(headers)
    assert test.headers == headers
    assert test.cookie_headers == {}
    assert test.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:45:38.482643
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookie_jar = CookieJar({})
    assert isinstance(cookie_jar, dict)
    assert isinstance(cookie_jar, CookieJar)
    assert cookie_jar.headers == {}

# Unit test to check if CookieJar has been cleared when delitems is used

# Generated at 2022-06-21 22:45:43.049253
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    '''
    Test if CookieJar properly writes headers
    '''
    request = Request.blank('/')
    cookie_jar = CookieJar(request.headers)
    assert request.headers.get('Set-Cookie') is None
    cookie_jar['foo'] = 'bar'
    # check if header has been set and value matches
    assert 'foo=bar' in request.headers.get('Set-Cookie')
    # check if the cookie value is stored
    assert cookie_jar['foo'].value == 'bar'


# Generated at 2022-06-21 22:45:45.053960
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    assert cookie.encode("utf-8") == b"key=value"


# Generated at 2022-06-21 22:46:08.052263
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie = Cookie("key", "value;")
    assert str(cookie) == "key=value;"

    cookie = Cookie("key", '"value"')
    assert str(cookie) == 'key="\\"value\\""'

    cookie = Cookie("key", "éééé")
    assert str(cookie) == 'key="\\303\\251\\303\\251\\303\\251\\303\\251"'

    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    cookie["comment"] = "test"
    cookie["domain"] = "mydomain.com"
    cookie["max-age"] = 60
    cookie["version"] = 1
    cookie["secure"] = True
    cookie["httponly"] = False


# Generated at 2022-06-21 22:46:11.870994
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    dict_headers = dict()
    jar = CookieJar(dict_headers)
    jar["name1"] = "cookie_value"
    del jar["name1"]
    assert(not dict_headers.get("name1"))

# Generated at 2022-06-21 22:46:19.212722
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('test_cookie', 'test_value')
    assert str(cookie) == 'test_cookie=test_value'

    cookie['path'] = '/'
    assert str(cookie) == 'test_cookie=test_value; Path=/'

    cookie['max-age'] = DEFAULT_MAX_AGE
    assert str(cookie) == 'test_cookie=test_value; Path=/; Max-Age=0'

    cookie['secure'] = True
    assert str(cookie) == 'test_cookie=test_value; Path=/; Max-Age=0; Secure'

    cookie['comment'] = 'Some comments here'
    assert str(cookie) == 'test_cookie=test_value; Path=/; Max-Age=0; Secure; Comment=Some comments here'

# Generated at 2022-06-21 22:46:29.269240
# Unit test for constructor of class Cookie
def test_Cookie():
    from collections import Counter

    cookie = Cookie(key='key', value='value')
    assert cookie.key == 'key'
    assert cookie.value == 'value'

    cookie['expires'] = datetime(2019, 2, 28, 2, 34, 8)
    assert cookie['expires'] == datetime(2019, 2, 28, 2, 34, 8)

    cookie['path'] = '/'
    assert cookie['path'] == '/'

    cookie['max-age'] = '100'
    assert cookie['max-age'] == '100'

    cookie['httponly'] = True
    assert cookie['httponly'] == True

    cookie['httponly'] = False
    assert cookie['httponly'] == False

    cookie['secure'] = True
    assert cookie['secure'] == True

    cookie['secure'] = False

# Generated at 2022-06-21 22:46:33.470917
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    assert isinstance(cookies, dict)
    assert isinstance(headers, MultiHeader)
    assert headers.getlist("Set-Cookie") == []
    cookies["name1"] = "value1"
    cookies["name1"] = "value2"
    cookies["name3"] = "value3"
    cookies["name4"] = "value4"

    assert cookies["name4"].value == "value4"


# Generated at 2022-06-21 22:46:35.605427
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("a", "b")
    assert cookie.key == "a"
    assert cookie["a"] == "b"
    assert str(cookie) == "a=b"

# Generated at 2022-06-21 22:46:37.934044
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    "Unit test for method __str__ of class Cookie"
    cookie = Cookie(
        'foo',
        'bar',
    )
    assert str(cookie) == "foo=bar"



# Generated at 2022-06-21 22:46:48.049291
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test with empty cookie
    cookie_str = str(Cookie("", ""))
    assert cookie_str == "=", "Empty Cookie __str__ returns incorrect result"

    # test with key-value cookie
    cookie_str = str(Cookie("foo", "bar"))
    assert cookie_str == "foo=bar", "Key-value Cookie __str__ returns incorrect result"

    # test with key-value cookie which has some special characters
    cookie_str = str(Cookie("foo", "bar + # $ ^"))
    assert cookie_str == "foo=bar + # $ ^", "Key-value Cookie with special characters __str__ returns incorrect result"

    # test basic key-value cookie with some parameters
    cookie_str = str(Cookie("foo", "bar"))
    cookie_str += "; " + "Path=/;"
    cookie

# Generated at 2022-06-21 22:46:54.996406
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from httpcore import Headers
    from httpcore import MultiHeader
    h = Headers(MultiHeader)

    cj = CookieJar(h)
    cj['foo'] = 'bar'
    assert cj.headers['Set-Cookie'] == 'foo=bar; Path=/'
    cj['baz'] = 'bla'
    assert cj.headers['Set-Cookie'] == 'foo=bar; Path=/\nbaz=bla; Path=/'
    del cj['foo']
    assert cj.headers['Set-Cookie'] == 'baz=bla; Path=/'
    cj['foo'] = 'bar'
    assert cj.headers['Set-Cookie'] == 'baz=bla; Path=/\nfoo=bar; Path=/'
    del cj['foo']
    assert len

# Generated at 2022-06-21 22:47:06.076286
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('a', 'b')
    with pytest.raises(KeyError):
        c['expires'] = 'c'
    with pytest.raises(KeyError):
        c['Comment'] = 'c'
    with pytest.raises(KeyError):
        c['c'] = 'c'
    with pytest.raises(ValueError):
        c['max-age'] = 'c'
    with pytest.raises(TypeError):
        c['expires'] = 1
    c['max-age'] = 1
    assert c['max-age'] == 1
    c['expires'] = datetime.now()
    with pytest.raises(TypeError):
        c['expires'] = 1
    assert c['expires']
    assert c['expires'] is not None

#

# Generated at 2022-06-21 22:47:22.664409
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("name", "value")
    assert cookie["path"] == "/"
    assert cookie["max-age"] == 0
    assert "name" in cookie
    assert "value" in cookie


# Generated at 2022-06-21 22:47:28.608443
# Unit test for constructor of class Cookie
def test_Cookie():
    # _keys = ['expires', 'path', 'comment', 'domain', 'max-age', 'secure', 'httponly', 'version', 'samesite']
    # _flags = {'secure', 'httponly'}
    key = 'kiwi'
    value = 'cookie'
    c1 = Cookie(key,value)
    assert c1.key == key
    assert c1.value == value
    assert c1.keys() == {}


# Generated at 2022-06-21 22:47:39.226147
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    # test for forbidden keys
    for forbidden_key in ("expires", "path", "comment", "domain", "max-age", "secure", "httponly", "version", "samesite"):
        try:
            cookie[forbidden_key] = "value"
        except:
            pass
        else:
            assert False
    # test for illegal ke
    key = "a!#$%&'*+-.^_`|~:"
    try:
        cookie = Cookie(key, "value")
    except KeyError:
        pass
    else:
        assert False
    # test for legal key
    key = "Aa0-_"
    cookie = Cookie(key, "value")
    assert cookie.key == key

# Generated at 2022-06-21 22:47:41.405696
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('uid', '1')
    assert cookie.encode('utf-8') == b'uid=1'


# Unit tests for method __str__ of class Cookie

# Generated at 2022-06-21 22:47:41.910647
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert True

# Generated at 2022-06-21 22:47:43.786071
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie(key='blah',value='stuff')
    assert c.value == 'stuff'



# Generated at 2022-06-21 22:47:55.241203
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers={"Set-Cookie": ["0=a; Secure; Path=/; HttpOnly; SameSite=Lax",
                             "1=b; Secure; Path=/; HttpOnly; SameSite=Lax",
                             "2=c; Secure; Path=/; HttpOnly; SameSite=Lax",
                             "3=d; Secure; Path=/; HttpOnly; SameSite=Lax"]}

    jar = CookieJar(headers)
    assert len(jar) == 4
    assert jar.headers.getall("Set-Cookie") == headers["Set-Cookie"]
    assert jar["0"] == "a"
    assert jar["1"] == "b"
    assert jar["2"] == "c"
    assert jar["3"] == "d"    
    
    del jar["0"]

# Generated at 2022-06-21 22:48:02.320409
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test empty case
    headers = MultiHeaderDict()
    ck = CookieJar(headers)
    assert ck == {}
    del ck['test']
    assert ck == {}

    # Test no key case
    ck['test'] = '123'
    assert ck == {'test': '123'}
    del ck['test1']
    assert ck == {'test': '123'}

    # Test key exists case
    del ck['test']
    assert ck == {}

    # Test key with space
    ck['test test'] = '123'
    assert ck == {'test test': '123'}
    del ck['test test']
    assert ck == {}

    # Test keys with space
    ck['test test'] = '123'

# Generated at 2022-06-21 22:48:07.996594
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["max-age"] = 30
    cookie["path"] = "/"
    cookie["httponly"] = True
    cookie["expires"] = datetime(2050, 8, 31)
    assert str(cookie) == "key=value; Max-Age=30; Path=/; HttpOnly; expires=Tue, 31-Aug-2050 09:00:00 GMT"


# Generated at 2022-06-21 22:48:18.392635
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    c = Cookie('a', 'b')
    c['max-age'] = 1
    c['expires'] = datetime(year=2042, month=8, day=22, hour=0)
    c['domain'] = 'c'
    c['path'] = 'd'
    c['comment'] = 'e'
    c['version'] = 'f'
    c['secure'] = True
    c['httponly'] = True
    assert str(c) == 'a=b; Max-Age=1; Expires=Sat, 22-Aug-2042 00:00:00 GMT; Domain=c; Path=d; Comment=e; Version=f; Secure; HttpOnly'

# Generated at 2022-06-21 22:48:36.986022
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cj = CookieJar(headers)
    cj.__setitem__("test", "testval")
    assert cj["test"].value == "testval"
    assert headers["Set-Cookie"][0] == "test=testval; Path=/; HttpOnly;"


# Generated at 2022-06-21 22:48:39.252917
# Unit test for constructor of class Cookie
def test_Cookie():
    assert Cookie("name", "value") == {}


# ------------------------------------------------------------ #
# Response object
# ------------------------------------------------------------ #


# Generated at 2022-06-21 22:48:43.217996
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("peter", "griffin")
    assert (c.encode("utf-8") == b"peter=griffin")


__all__ = [
    "CookieJar",
    "Cookie",
    "test_Cookie_encode"
]

# Generated at 2022-06-21 22:48:50.311121
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    cookie['max-age'] = 10
    assert str(cookie) == "name=value; Max-Age=10"
    cookie['expires'] = datetime.now()
    assert str(cookie) == "name=value; Max-Age=10; Expires=%s" % cookie['expires'].strftime("%a, %d-%b-%Y %T GMT")
    cookie['path'] = "/"
    assert str(cookie) == "name=value; Max-Age=10; Expires=%s; Path=/" % cookie['expires'].strftime("%a, %d-%b-%Y %T GMT")
    cookie['domain'] = "localhost"

# Generated at 2022-06-21 22:48:56.624798
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "testing")
    assert str(cookie) == "test=testing"
    cookie["max-age"] = 3600
    assert str(cookie) == "test=testing; Max-Age=3600"
    cookie["expires"] = datetime.utcnow()
    assert str(cookie).startswith("test=testing; Max-Age=3600; Expires")



# Generated at 2022-06-21 22:49:02.573323
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    c = CookieJar({})
    c["a"] = "b"
    c["b"] = "c"
    del c["a"]
    assert c["b"] == "c"
    assert "a" not in c
    assert "b" in c
    assert c["b"] == "c"
    del c["a"]
    assert "a" not in c
    assert "b" in c
    assert c["b"] == "c"


# Generated at 2022-06-21 22:49:12.587954
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar: CookieJar = CookieJar(headers)
    cookie_string: str = "test_cookie_name=test_cookie_value"

    cookie_jar["test_cookie_name"] = "test_cookie_value"

    # Have to manually append an existing cookie because
    # FastAPI removes the duplicate ones
    headers.add(name="Set-Cookie", value=cookie_string)

    expected_result: str = str(headers["Set-Cookie"])
    assert expected_result.startswith(cookie_string)

    # Have to manually append an existing cookie because
    # FastAPI removes the duplicate ones
    headers.add(name="Set-Cookie", value=cookie_string)
run_test(test_CookieJar___setitem__, "Set-Cookie")


# Generated at 2022-06-21 22:49:20.409946
# Unit test for constructor of class CookieJar
def test_CookieJar():
    """Unit test for constructor of class CookieJar"""
    multiple_headers = [
        'cookie1="value1"; Path=/; Secure',
        'cookie2="value2"; Path=/; Secure',
        'cookie3="value3"; Path=/; Secure',
        'cookie4="value4"; Path=/; Secure',
        'cookie5="value5"; Path=/; Secure',
    ]
    cookies = CookieJar(multiple_headers)
    assert len(cookies) == 5
    assert len(cookies.cookie_headers) == 5
    assert len(cookies.headers) == 2
    with pytest.raises(TypeError) as e:
        CookieJar(["cookie1=value1; Path=/; Secure", 10])
    assert str(e.value) == 'Cookie header must be in string format'

# Generated at 2022-06-21 22:49:31.021417
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test 1
    cookie = Cookie(
        "cookie1", "cookie1value"
    )
    expected = "cookie1=cookie1value; Path=/"
    assert str(cookie) == expected
    # Test 2
    cookie = Cookie(
        "cookie2", "cookie2value"
    )
    cookie["path"] = "/path"
    cookie["domain"] = "example.com"
    cookie["max-age"] = 432000
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["samesite"] = "Strict"
    expected = "cookie2=cookie2value; Path=/path; Domain=example.com; Max-Age=432000; Secure; HttpOnly; SameSite=Strict"
    assert str(cookie) == expected

# ------------------------------------------------------------ #
#  Middlewares

# Generated at 2022-06-21 22:49:39.336349
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("spam", "eggs")
    cookie["comment"] = "Does this look like eggs to you?"
    cookie["version"] = 2
    cookie["domain"] = "spam.gov"
    cookie["path"] = "spam/eggs"
    cookie["max-age"] = "99"
    cookie["secure"] = True
    cookie["httponly"] = False
    expected = (
        "spam=eggs;"
        + "comment=Does%20this%20look%20like%20eggs%20to%20you%3F;version=2;"
        + "domain=spam.gov;path=spam/eggs;Max-Age=99;Secure"
    )
    assert str(cookie) == expected