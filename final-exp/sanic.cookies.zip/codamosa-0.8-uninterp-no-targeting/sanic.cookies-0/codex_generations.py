

# Generated at 2022-06-21 22:40:12.937573
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class DummyHeaders():
        def __init__(self):
            self.header = []

        def add(self, key, value):
            self.header.append(value)

        def popall(self, key):
            return self.header

    headers = DummyHeaders()

    cookie_jar = CookieJar(headers)
    cookie_jar["test_key1"] = "cookie1"
    cookie_jar["test_key2"] = "cookie2"
    cookie_jar["test_key3"] = "cookie3"

    del cookie_jar["test_key2"]

    assert "cookie2" not in headers.header, "deleting cookie from CookieJar failed"

    assert "test_key2" not in cookie_jar, "deleting cookie from CookieJar failed"


# Generated at 2022-06-21 22:40:23.876270
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    c1 = Cookie("John", "Doe")
    c2 = Cookie("Jane", "Doe")
    c3 = Cookie("Jerry", "Doe")
    headers.add("Set-Cookie", c1)
    headers.add("Set-Cookie", c2)
    headers.add("Set-Cookie", c3)
    cookies = CookieJar(headers)
    cookies["John"] = "Doe"
    cookies["Jane"] = "Doe"
    cookies["Jerry"] = "Doe"
    print(cookies)
    del cookies["Jerry"]
    print(cookies)
    print(headers)


# Generated at 2022-06-21 22:40:30.170380
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    """
    Test method encode of class Cookie
    """
    cookie1 = Cookie("c", u"\u6d4b\u8bd5")
    assert cookie1.value == u"\u6d4b\u8bd5"
    assert isinstance(cookie1.value, unicode)
    assert cookie1.encode("utf-8") == u"c=\u6d4b\u8bd5".encode("utf-8")

    cookie2 = Cookie("c", u"\u6d4b\u8bd5")
    cookie2.value = u"\u6d4b\u8bd5".encode("utf-8")
    assert isinstance(cookie2.value, str)

# Generated at 2022-06-21 22:40:34.758480
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = case.Headers()
    cookies = CookieJar(headers)
    cookies['hello'] = 'world'
    assert headers.getall('Set-Cookie') == ['hello=world']

    # Invalid cookie key
    with pytest.raises(KeyError):
        del cookies['test']
    
    del cookies['hello']
    assert not headers.getall('Set-Cookie')


# Generated at 2022-06-21 22:40:40.788585
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookiejar = CookieJar()
    cookiejar['key1'] = 'value1'
    assert cookiejar['key1'] == 'value1'
    cookiejar['key2'] = 'value2'
    assert cookiejar['key2'] == 'value2'
    cookiejar['key3'] = 'value3'
    assert coo

# Generated at 2022-06-21 22:40:43.478218
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    assert cookie_jar, "Unable to instantiate CookieJar."
    return


# Generated at 2022-06-21 22:40:49.750751
# Unit test for constructor of class CookieJar
def test_CookieJar():
    """
    Check that the CookieJar is a dict and that it sets the header key as
    'Set-Cookie'
    """
    from starlette.datastructures import Headers, MutableHeaders

    headers = Headers()
    cookie_jar = CookieJar(headers)
    for h in ["Set-Cookie", "set-cookie"]:
        assert cookie_jar.header_key == h

    headers = MutableHeaders()
    cookie_jar = CookieJar(headers)
    for h in ["Set-Cookie", "set-cookie"]:
        assert cookie_jar.header_key == h


# Generated at 2022-06-21 22:40:55.785927
# Unit test for constructor of class CookieJar
def test_CookieJar():
    c = CookieJar('Set-Cookie: key=value\r\n')
    assert c.headers['Set-Cookie'] == 'key=value'
    assert c['key'] == 'value'

    c['key'] = 'value-modified'
    assert c.headers['Set-Cookie'] == 'key=value-modified'
    assert c['key'] == 'value-modified'

    del c['key']
    assert c.headers['Set-Cookie'] == 'key=; max-age=0'
    assert 'key' not in c.keys()

# Generated at 2022-06-21 22:40:58.748559
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookieJar = CookieJar()
    cookieJar["name"] = "Charmander"
    assert cookieJar["name"] == "Charmander", "cookieJar[key] __setitem__ doesn't work"


# Generated at 2022-06-21 22:41:01.768689
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie_http = "cookie_http"
    cookie_value = "cookie_value"
    cookie = Cookie(cookie_http, cookie_value)
    assert cookie.encode("utf-8") == "cookie_http=cookie_value"


# Generated at 2022-06-21 22:41:17.236799
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('name', 'value')
    assert c == {}
    assert c.key == 'name'
    assert c.value == 'value'

    with pytest.raises(KeyError):
        Cookie('expires', 'some_date')
    with pytest.raises(KeyError):
        Cookie('path', 'some_path')

    c = Cookie('123', 'value')
    assert c.key == '123'
    assert c.value == 'value'

    c = Cookie(string.digits, 'value')
    assert c.key == string.digits
    assert c.value == 'value'

    with pytest.raises(KeyError):
        Cookie('123@', 'value')



# Generated at 2022-06-21 22:41:29.820011
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookiejar = CookieJar(headers)
    cookiejar['key1'] = 'value1'
    cookiejar['key2'] = 'value2'
    cookiejar['key3'] = 'value3'
    cookiejar['key4'] = 'value4'
    cookiejar['key5'] = 'value5'
    cookiejar['key6'] = 'value6'
    cookiejar['key7'] = 'value7'
    cookiejar['key8'] = 'value8'
    cookiejar['key9'] = 'value9'
    cookiejar['key10'] = 'value10'

# Generated at 2022-06-21 22:41:33.026176
# Unit test for constructor of class Cookie
def test_Cookie():
  c = Cookie("name", "value")
  assert c.key == "name", "Cookie key should be name"
  assert c.value == "value", "Cookie value should be value"

# ------------------------------------------------------------ #
#  Session Class
# ------------------------------------------------------------ #


# Generated at 2022-06-21 22:41:40.763905
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers=MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"
    cookie_jar["key2"] = "value2"
    cookie_jar["key3"] = "value3"
    cookie_jar["key4"] = "value4"
    if len(cookie_jar.cookie_headers.keys()) == 4 and len(cookie_jar.headers) == 4:
        del cookie_jar["key1"]
        assert len(cookie_jar.cookie_headers.keys()) == 3 and len(cookie_jar.headers) == 3
        assert len(cookie_jar.headers["Set-Cookie"]) == 3
        del cookie_jar["key2"]
        assert len(cookie_jar.cookie_headers.keys()) == 2 and len(cookie_jar.headers) == 2

# Generated at 2022-06-21 22:41:41.611066
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    assert "test_CookieJar___delitem__"



# Generated at 2022-06-21 22:41:50.910575
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "me")
    c["max-age"] = DEFAULT_MAX_AGE
    assert str(c) == "test=me; Max-Age=0"
    c["max-age"] = 100
    assert str(c) == "test=me; Max-Age=100"
    c["expires"] = datetime.now()
    assert str(c) == "test=me; Expires=" + c["expires"].strftime("%a, %d-%b-%Y %T GMT")
    c["secure"] = True
    assert str(c) == "test=me; Expires=" + c["expires"].strftime("%a, %d-%b-%Y %T GMT") + "; Secure"
    c["secure"] = False

# Generated at 2022-06-21 22:41:52.740006
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('name', 'value')
    assert cookie.encode('utf-8') == b'name=value'

# Generated at 2022-06-21 22:42:00.630468
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = dict()
    cookie_jar = CookieJar(headers)
    cookie_jar['A'] = 'B'
    cookie_jar['C'] = 'D'
    assert "Set-Cookie: A=B; Path=/; Domain=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT" in headers["Set-Cookie"]
    assert "Set-Cookie: C=D; Path=/; Domain=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT" in headers["Set-Cookie"]
    del cookie_jar['A']
    assert "Set-Cookie: A=B; Path=/; Domain=; Max-Age=0; Expires=Thu, 01 Jan 1970 00:00:00 GMT" not in headers["Set-Cookie"]

# Generated at 2022-06-21 22:42:02.810896
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("UserName", "Clark Kent")
    assert str(cookie) == "UserName=Clark Kent"


# Generated at 2022-06-21 22:42:05.815265
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("test", "value")
    assert cookie.value == "value"
    assert cookie.key == "test"
    assert cookie == {}


# Generated at 2022-06-21 22:42:19.038319
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_name = "name"
    cookie_value = "value"
    headers = {"Set-Cookie": [Cookie(cookie_name, cookie_value)]}
    cookie_jar = CookieJar(headers)
    print (cookie_jar.values())
    del cookie_jar[cookie_name]
    print(type(cookie_jar.get("Set-Cookie")))
    assert(len(cookie_jar.values()) == 0)


# Generated at 2022-06-21 22:42:20.685051
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('c','vc')
    print(c)

# Generated at 2022-06-21 22:42:29.647582
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    with pytest.raises(KeyError) as kie:
        Cookie("key","value")["expires"] = 10
    with pytest.raises(KeyError) as kie:
        Cookie("key","value")["path"] = "/test"
    with pytest.raises(KeyError) as kie:
        Cookie("key","value")["comment"] = "test"
    with pytest.raises(KeyError) as kie:
        Cookie("key","value")["domain"] = "test.com"
    with pytest.raises(KeyError) as kie:
        Cookie("key","value")["max-age"] = 10
    with pytest.raises(KeyError) as kie:
        Cookie("key","value")["secure"] = True

# Generated at 2022-06-21 22:42:33.585090
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cj = CookieJar(headers={})
    cj['a'] = 'b'
    print(cj)
    assert False, "output me"


test_CookieJar___setitem__()

# Generated at 2022-06-21 22:42:45.041435
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("my_cookie_key", "my_cookie_value")
    assert str(c) == "my_cookie_key=my_cookie_value"
    c["max-age"] = 100
    assert str(c) == "my_cookie_key=my_cookie_value; Max-Age=100"
    c["max-age"] = "100"
    assert str(c) == "my_cookie_key=my_cookie_value; Max-Age=100"
    c["expires"] = datetime(2018, 1, 1, 10, 0, 0, 0)
    assert (
        str(c)
        == "my_cookie_key=my_cookie_value; Max-Age=100; expires=Mon, 01-Jan-2018 10:00:00 GMT"
    )
    c["secure"] = True

# Generated at 2022-06-21 22:42:47.866321
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("key", "value")
    assert cookie["key"] == "value"
    assert cookie.value == "value"
    assert cookie.key == "key"


# -------------------------------------------------------------------- #
#  Util functions
# -------------------------------------------------------------------- #



# Generated at 2022-06-21 22:42:52.821152
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaders(test=True)
    cookie_jar = CookieJar(headers)
    # Basic operation
    cookie_jar["test_key"] = "test_value"
    # Overwrite functionality
    cookie_jar["test_key"] = "test_value_2"
    # Delete functionality
    del cookie_jar["test_key"]
    # Should return False for "test"
    return "test" not in headers


# Generated at 2022-06-21 22:42:58.174037
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    c = CookieJar(headers)
    c['key'] = 'value'
    assert c['key'] == 'value'
    headers.add('key', 'value')
    assert headers.getall('Set-Cookie') == ["key=value"]


# Generated at 2022-06-21 22:43:01.723297
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    header = MultiHeader("Set-Cookie")
    cookie = CookieJar(header)
    cookie["key"] = "value"
    assert cookie._headers["Set-Cookie"] == [("key", "value")]
    cookie["key2"] = "value2"
    assert cookie._headers["Set-Cookie"] == [("key", "value"), ("key2", "value2")]
    del cookie["key"]
    assert cookie._headers["Set-Cookie"] == [("key2", "value2")]
    del cookie["key2"]
    assert cookie._headers["Set-Cookie"] == []


# Generated at 2022-06-21 22:43:10.118496
# Unit test for method __setitem__ of class Cookie

# Generated at 2022-06-21 22:43:31.925202
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)

    assert "Set-Cookie" not in headers
    cookies["foo"] = "bar"
    assert "Set-Cookie" in headers
    assert "foo" in cookies
    del cookies["foo"]
    assert "Set-Cookie" not in headers
    assert "foo" not in cookies

# Generated at 2022-06-21 22:43:37.138016
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("foo", "bar")
    assert cookie.encode(
        "utf-8") == b"foo=bar", "Cookie.encode() should return the encoded value of the cookie"
    assert cookie.encode(
        "latin-1") == b"foo=bar", "Cookie.encode() should return the encoded value of the cookie"



# Generated at 2022-06-21 22:43:47.879767
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    Unit test for method __delitem__ of class CookieJar
    """
    headers = MultiHeaders()
    jar = CookieJar(headers)
    jar['foo'] = 'bar'
    headers.add('Set-Cookie', 'foo=baz')
    jar['other'] = 'qux'

    assert headers.getall('Set-Cookie') == ['foo=bar', 'foo=baz', 'other=qux']

    del jar['other']

    assert headers.getall('Set-Cookie') == ['foo=bar', 'foo=baz']

    del jar['foo']

    assert headers.getall('Set-Cookie') == ['foo=baz']

    del jar['foo']

    assert headers.getall('Set-Cookie') == ['foo=baz; max-age=0']

# Generated at 2022-06-21 22:43:58.835680
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("key", "value")
    assert c.key == "key"
    assert c.value == "value"
    assert c.get("max-age") is None

    c["path"] = "/"
    assert c.get("path") == "/"

    c["max-age"] = DEFAULT_MAX_AGE
    assert c.get("max-age") == DEFAULT_MAX_AGE

    with pytest.raises(TypeError) as e:
        c["max-age"] = "forty-two"
    assert e.type == TypeError
    assert e.value.args[0] == "Cookie max-age must be an integer"

    c["secure"] = True
    assert c.get("secure") is True


# Generated at 2022-06-21 22:44:01.051685
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('mycookie', 'myvalue')
    assert c.key == 'mycookie'
    assert c.value == 'myvalue'


# Generated at 2022-06-21 22:44:02.711535
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    assert len(cookies) == 0


# Generated at 2022-06-21 22:44:07.795419
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test", "test")
    assert c.key == "test"
    assert c.value == "test"
    assert c._keys == {
        "expires": "expires",
        "path": "Path",
        "comment": "Comment",
        "domain": "Domain",
        "max-age": "Max-Age",
        "secure": "Secure",
        "httponly": "HttpOnly",
        "version": "Version",
        "samesite": "SameSite",
    }
    assert c.encode("utf-8") == b"test=test"



# Generated at 2022-06-21 22:44:11.440905
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers({"Content-Type": "text/plain"})
    cookies = CookieJar(headers)
    cookies["hello"] = "world"
    assert headers["Set-Cookie"] == 'hello="world"; Path=/'



# Generated at 2022-06-21 22:44:21.788254
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('key', 'value')
    assert cookie.key == 'key'
    assert cookie['key'] == 'value'
    cookie['path'] = '/'
    assert cookie['path'] == '/'
    cookie['expires'] = 0
    assert cookie['expires'] == 0
    cookie['expires'] = datetime.now()
    assert isinstance(cookie['expires'], datetime)
    cookie['key'] = 'value'
    assert cookie['key'] == 'value'
    cookie['secure'] = True
    assert 'secure' in cookie
    cookie['httponly'] = True
    assert 'httponly' in cookie
    cookie['version'] = 1
    assert 'version' in cookie
    cookie['samesite'] = 'None'
    assert 'samesite' in cookie
    # Test for errors
    cookie

# Generated at 2022-06-21 22:44:22.372474
# Unit test for constructor of class Cookie
def test_Cookie():
    assert Cookie


# Generated at 2022-06-21 22:44:43.209740
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("some","value")
    assert cookie.key == "some"
    assert cookie.value == "value"


# Generated at 2022-06-21 22:44:53.594324
# Unit test for constructor of class CookieJar
def test_CookieJar():
    """
    Test if CookieJar can be constructed and operates.
    """
    from quart.build_utils import MultiDict
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    assert not cookie_jar
    assert len(headers) == 0
    cookie_jar["foo"] = "bar"
    assert len(headers) == 1
    assert headers["Set-Cookie"][0] == "foo=bar; Path=/; Max-Age=0"
    cookie_jar["foo"] = "baz"
    assert len(headers) == 1
    assert headers["Set-Cookie"][0] == "foo=baz; Path=/; Max-Age=0"
    del cookie_jar["foo"]
    assert len(headers) == 1

# Generated at 2022-06-21 22:44:55.263147
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("name", "value")
    assert cookie.encode("utf-8") == b"name=value"


# Generated at 2022-06-21 22:45:06.898871
# Unit test for constructor of class Cookie
def test_Cookie():
    with pytest.raises(KeyError):
        c = Cookie("key", "value")
        c["key"] = "val"
    with pytest.raises(KeyError):
        c = Cookie("key", "value")
        c["max-age"] = "val"
    with pytest.raises(KeyError):
        c = Cookie("key", "value")
        c["expires"] = "val"
    with pytest.raises(KeyError):
        c = Cookie("key", "value")
        c["domain"] = "val"
    with pytest.raises(KeyError):
        c = Cookie("key", "value")
        c["path"] = "val"
    with pytest.raises(KeyError):
        c = Cookie("key", "value")

# Generated at 2022-06-21 22:45:14.138197
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    ck = Cookie('name', 'value')
    assert ck.__str__() == 'name=value'
    ck['expires'] = datetime.now()
    assert ck.__str__() != 'name=value'
    ck['max-age'] = 123
    assert ck.__str__() != 'name=value'
    ck['secure'] = True
    assert ck.__str__() != 'name=value'
    ck['httponly'] = True

# Generated at 2022-06-21 22:45:18.107777
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"

    assert jar['foo'] == "bar"
    assert headers["Set-Cookie"] == ["foo=bar; Path=/"]
    assert headers["set-cookie"] == ["foo=bar; Path=/"]
    assert headers["SET-COOKIE"] == ["foo=bar; Path=/"]


# Generated at 2022-06-21 22:45:21.729327
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('cookie_key', 'cookie_value')
    c['max-age'] = 10
    assert c['max-age'] == 10


# Generated at 2022-06-21 22:45:28.537017
# Unit test for constructor of class Cookie
def test_Cookie():
    c1 = Cookie('mycookie', 'cookievalue')
    assert c1._keys == {
        "expires": "expires",
        "path": "Path",
        "comment": "Comment",
        "domain": "Domain",
        "max-age": "Max-Age",
        "secure": "Secure",
        "httponly": "HttpOnly",
        "version": "Version",
        "samesite": "SameSite",
    }
    assert c1._flags == {"secure", "httponly"}
    assert c1.key == 'mycookie'
    assert c1.value == 'cookievalue'
    assert c1 == {}



# Generated at 2022-06-21 22:45:38.792497
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie(
        key = 'SecretKey',
        value = 'SecretValue',
    )
    # With empty items
    assert cookie.__str__() == 'SecretKey=SecretValue'
    # With one item
    cookie['path'] = '/'
    assert cookie.__str__() == 'SecretKey=SecretValue; Path=/'
    # With one flag
    cookie['secure'] = True
    assert cookie.__str__() == 'SecretKey=SecretValue; Path=/; Secure'
    # With several items
    cookie['expires'] = datetime(2020, 1, 1)
    cookie['domain'] = 'localhost'
    assert cookie.__str__() == 'SecretKey=SecretValue; Path=/; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Domain=localhost; Secure'
    # With max

# Generated at 2022-06-21 22:45:49.681393
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["x"] = "x"
    cookie_jar["x1"] = "x1"
    cookie_jar["x2"] = "x2"
    cookie_jar["x1"] = "x1"
    cookie_jar["y"] = "y"
    assert headers.getlist("Set-Cookie") == ['x="x"; Path=/;', 'x1="x1"; Path=/;', 'x2="x2"; Path=/;', 'y="y"; Path=/;']
    del cookie_jar["x1"]
    del cookie_jar["y"]
    assert headers.getlist("Set-Cookie") == ['x="x"; Path=/;', 'x2="x2"; Path=/;']
    cookie_jar["x1"]

# Generated at 2022-06-21 22:46:32.798615
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    assert "foo=bar" == str(cookie)
    cookie["comment"] = "baz"
    assert "foo=bar; Comment=baz" == str(cookie)
    cookie["max-age"] = 123
    assert "foo=bar; Comment=baz; Max-Age=123" == str(cookie)
    cookie["secure"] = True
    assert "foo=bar; Comment=baz; Max-Age=123; Secure" == str(cookie)
    cookie["httponly"] = True
    assert (
        "foo=bar; Comment=baz; HttpOnly; Max-Age=123; Secure"
        == str(cookie)
    )
    cookie["expires"] = datetime(2020, 1, 1)

# Generated at 2022-06-21 22:46:40.848830
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():

    expiry_time = datetime(year=2019, day=5, month=11)

    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"

    cookie["path"] = "0"
    assert str(cookie) == "key=value; Path=0"

    cookie["path"] = "1"
    assert str(cookie) == "key=value; Path=1"

    cookie["path"] = "a"
    assert str(cookie) == "key=value; Path=a"

    cookie["path"] = "b"
    assert str(cookie) == "key=value; Path=b"

    cookie["path"] = "z"

# Generated at 2022-06-21 22:46:46.412893
# Unit test for method encode of class Cookie
def test_Cookie_encode():
  cookie = Cookie(b"test", b"test")
  assert cookie.encode("utf-8") == b"test=test"
  assert cookie.encode("utf-8") == b"test=test"
  assert cookie.encode("ascii") == b"test=test"
  assert cookie.encode("latin-1") == b"test=test"
  assert cookie.encode("ISO-8859-2") == b"test=test"

# Generated at 2022-06-21 22:46:52.991965
# Unit test for constructor of class CookieJar
def test_CookieJar():
    import japronto
    from japronto.request import Request

    app = japronto.Application()

    @app.route('/')
    def handler(request):
        cookies = request.cookies
        assert isinstance(cookies, CookieJar)
        assert isinstance(cookies.headers, MultiHeader)
        return request.Response(text="Hi, I'm a cookie")

    request = Request.factory(app=app, path='/')
    resp = app.handle(request)

    assert request.cookies['foo'] == ''
    assert resp.code == 200

# Generated at 2022-06-21 22:47:02.409210
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "val")
    assert str(cookie) == "test=val"
    cookie["path"] = "/"
    assert str(cookie) == "test=val; Path=/"
    cookie["domain"] = "hacker.com"
    assert str(cookie) == "test=val; Path=/; Domain=hacker.com"
    cookie["httponly"] = True
    assert str(cookie) == "test=val; Path=/; Domain=hacker.com; HttpOnly"
    cookie["secure"] = True
    assert str(cookie) == "test=val; Path=/; Domain=hacker.com; HttpOnly; Secure"
    cookie["max-age"] = 100

# Generated at 2022-06-21 22:47:10.196877
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("test", "чебурашка")
    assert c.encode("utf-8") == b"test=%D1%87%D0%B5%D0%B1%D1%83%D1%80%D0%B0%D1%88%D0%BA%D0%B0"
    assert c.encode("utf-16") == "test=чебурашка".encode("utf-16")


# Generated at 2022-06-21 22:47:18.786992
# Unit test for constructor of class Cookie
def test_Cookie():
    # Cookies should not be constructed with reserved names.
    with pytest.raises(KeyError):
        Cookie("expires", "Friday")
    with pytest.raises(KeyError):
        Cookie("max-age", "12345")
    with pytest.raises(KeyError):
        Cookie("httponly", "true")
    with pytest.raises(KeyError):
        Cookie("secure", "true")
    with pytest.raises(KeyError):
        Cookie("path", "/")
    with pytest.raises(KeyError):
        Cookie("domain", "test.com")
    with pytest.raises(KeyError):
        Cookie("version", "1")

    # Cookies should not be constructed with keys containing illegal
    # characters.

# Generated at 2022-06-21 22:47:20.648751
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    del jar["foo"]
    assert jar == {}
    assert headers.get("Set-Cookie") == ""

# Generated at 2022-06-21 22:47:28.828605
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["a"] = 1
    assert jar["a"].value == "1"
    assert headers.getlist("Set-Cookie")[0] == 'a="1"'
    jar["b"] = 2
    assert jar["b"].value == "2"
    assert headers.getlist("Set-Cookie")[1] == 'b="2"'

    jar["b"] = 3
    assert jar["b"].value == "3"
    assert headers.getlist("Set-Cookie")[1] == 'b="3"'



# Generated at 2022-06-21 22:47:33.782356
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    assert "test" not in cookies.headers
    cookies["test"] = "test"
    assert "test" in cookies.headers
    del cookies["test"]
    assert "test" not in cookies.headers
    assert not cookies.headers

# Generated at 2022-06-21 22:49:56.527004
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_dict1 = {
        'domain': 'example.com',
        'httponly': True,
        'max-age': 3600,
        'path': '/',
        'secure': True,
        'samesite': 'lax',
    }
    cookie1 = Cookie(key = 'hello', value = 'world')
    for k, v in cookie_dict1.items():
        cookie1[k] = v
    output1 = str(cookie1)
    # output1 should be 'hello=world; Domain=example.com; Path=/; Max-Age=3600; Secure; HttpOnly; SameSite=lax'
    assert output1 ==  'hello=world; Domain=example.com; Path=/; Max-Age=3600; Secure; HttpOnly; SameSite=lax'
    cookie2 = Cookie