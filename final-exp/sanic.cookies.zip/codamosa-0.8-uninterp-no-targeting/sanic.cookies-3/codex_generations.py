

# Generated at 2022-06-21 22:40:09.001113
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("name", "value")
    # print(cookie)
    # print(cookie.encode("utf-8"))
    return

# ------------------------------------------------------------ #
#  testCookieJar
# ------------------------------------------------------------ #

# Generated at 2022-06-21 22:40:12.651230
# Unit test for constructor of class Cookie
def test_Cookie():
    name = "test_name"
    value = "test_value"
    c = Cookie(name, value)
    assert c["path"] == "/"
    assert c.key == name
    assert c.value == value


# Generated at 2022-06-21 22:40:16.116605
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie('test', 'test')
    assert c.encode('utf-8').decode('utf-8') == 'test=test', "Cookie encode fail"


# Generated at 2022-06-21 22:40:19.112016
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    assert headers.getall("Set-Cookie") == []



# Generated at 2022-06-21 22:40:31.125664
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('name', 'value')
    assert cookie.key == 'name'
    assert cookie.value == 'value'
    assert cookie['path'] == '/'
    assert 'name' in cookie
    assert 'value' in cookie
    assert 'max-age' in cookie
    assert 'expires' in cookie
    assert 'secure' in cookie
    assert 'httponly' in cookie
    assert 'domain' in cookie
    assert 'version' in cookie

    cookie['comment'] = 'Hello World!'
    assert cookie['comment'] == 'Hello World!'
    assert cookie.key == 'name'
    assert cookie.value == 'value'
    assert cookie['path'] == '/'

    with pytest.raises(KeyError):
        cookie['max-age'] = False


# Generated at 2022-06-21 22:40:33.963450
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from framework.http.response import Response
    response = Response()
    response.cookies["key"] = "value"
    assert response.cookies["key"]
    del response.cookies["key"]
    assert response.cookies["key"] == "deleted"

# Generated at 2022-06-21 22:40:45.572919
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Tests whether cookies output the correct string
    """
    cookies = []
    # outputs a regular cookie
    cookies.append(Cookie("name", "value"))
    # outputs a cookie with sub-values
    cookies.append(Cookie("name", "value;with;semicolons"))
    # outputs a cookie with a different path

# Generated at 2022-06-21 22:40:54.689595
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('k', 'v')
    cookie['expires'] = 2
    cookie['path'] = 2

    with pytest.raises(KeyError) as e_info:
        cookie['wrong_key'] = 2
    assert 'Unknown cookie property' in str(e_info.value)

    with pytest.raises(ValueError) as e_info:
        cookie['max-age'] = 'test'
    assert 'must be an integer' in str(e_info.value)

    with pytest.raises(TypeError) as e_info:
        cookie['expires'] = 2
    assert 'must be a datetime' in str(e_info.value)


# Generated at 2022-06-21 22:41:04.099723
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    from anyblok.blok import BlokManager
    from anyblok.tests.testcase import DBTestCase
    from anyblok_pyramid.security import CookieJar

    registry = BlokManager.get('test_blok_pyramid').load().registry

    registry.session = registry.Test.Session()

    c = CookieJar({"a": "b"})
    c["e"] = "f"
    c["e"] = "g"
    c["e"]["expires"] = datetime(year=2019, month=10, day=13, hour=17, minute=2)
    c["e"]["max-age"] = 100
    assert c["e"] == "g"

    # Test max-age raise

# Generated at 2022-06-21 22:41:07.362659
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "test_key"
    value = "test_value"
    cookie = Cookie(key, value)

    assert cookie['key'] == key
    assert cookie['value'] == value


# Generated at 2022-06-21 22:41:21.742464
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    cookies["session-1"] = "hello"
    cookies["session-2"] = "my cookie!"
    cookies["session-3"] = "my cookie!"
    del cookies["session-2"]
    cookie_headers = headers["set-cookie"]
    assert len(cookie_headers) == 2
    assert str(cookie_headers[0]) == "session-1=hello; path=/"
    assert str(cookie_headers[1]) == "session-3=my cookie!; path=/"
    del cookies["session-1"]
    cookie_headers = headers["set-cookie"]
    assert len(cookie_headers) == 1
    assert str(cookie_headers[0]) == "session-3=my cookie!; path=/"
    del cookies["session-3"]


# Generated at 2022-06-21 22:41:26.846608
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    headers.add("Content-Type", "text/html")
    headers.add("Content-Length", "380")
    headers.add("Set-Cookie", "foo=bar")
    headers.add("Set-Cookie", "foo1=bar1")
    headers.add("Set-Cookie", "foo2=bar2")
    jar = CookieJar(headers)
    del jar["foo"]
    del jar["foo1"]
    assert not headers.get("Set-Cookie")
    assert len(jar) == 1
    assert len(headers) == 2

# Generated at 2022-06-21 22:41:37.429366
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookies = CookieJar(headers)

    # cookie.remove("name", path="", domain="")
    cookies["test_cookie"] = "test_value"

    # cookie.remove("name", path=="", domain=="")
    del cookies["test_cookie"]
    assert "test_cookie" not in cookies

    # cookie.remove("name", path="", domain="")
    cookies["test_cookie"] = "test_value"
    assert cookies["test_cookie"] == "test_value"

    # cookie.remove("name", path="", domain="")
    cookies.__delitem__("test_cookie")
    assert "test_cookie" not in cookies


# Generated at 2022-06-21 22:41:44.054126
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('cookie_name', 'cookie_value')
    assert c['expires'] is None
    assert c['path'] is None
    assert c['comment'] is None
    assert c['domain'] is None
    assert c['max-age'] is None
    assert c['secure'] is False
    assert c['httponly'] is False
    assert c['version'] is None
    assert c['samesite'] is None


# Generated at 2022-06-21 22:41:52.439350
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():

    headers = MultiHeader()
    cj = CookieJar(headers=headers)
    cj["foo"] = "bar"
    cj["foo"] = "baz"
    cj["hello"] = "world"
    cj["hello"] = "cookie"
    cj["foo"] = "cookie"
    cj.pop("foo", None)
    cj.pop("hello", None)
    assert "foo" not in cj
    assert "hello" not in cj
    assert cj.cookie_headers == {}
    assert headers.headers == {}
    return



# Generated at 2022-06-21 22:42:00.748587
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'key'
    value = 'value'
    cookie = Cookie(key, value)
    cookie['expires'] = datetime.now()
    cookie['path'] = '/'
    cookie['comment'] = 'comment'
    cookie['domain'] = 'domain'
    cookie['max-age'] = 0
    cookie['secure'] = False
    cookie['httponly'] = False
    cookie['version'] = 0
    cookie['samesite'] = 'None'
    assert cookie['expires'] == datetime.now()
    assert cookie['path'] == '/'
    assert cookie['comment'] == 'comment'
    assert cookie['domain'] == 'domain'
    assert cookie['max-age'] == 0
    assert cookie['secure'] == False
    assert cookie['httponly'] == False
    assert cookie['version'] == 0
   

# Generated at 2022-06-21 22:42:04.990158
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('name','value')
    assert c.key == 'name'
    assert c.value == 'value'
    # Test if special char are accepted
    c['expires'] = str(datetime.now().strftime(
        "%a, %d-%b-%Y %T GMT"
    ))
    c['path'] = '/'
    c['domain'] = 'www.example.com'
    c['max-age'] = 3600
    c['secure'] = 'secure'
    c['httponly'] = 'httponly'
    c['version'] = 'version'
    c['samesite'] = 'samesite'
    assert c['expires'] == str(datetime.now().strftime(
        "%a, %d-%b-%Y %T GMT"
    ))
    assert c

# Generated at 2022-06-21 22:42:15.146958
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies['lol'] = '123'
    assert isinstance(cookies, dict)
    assert 'lol' in cookies.headers
    assert len(cookies.headers) == 1
    cookies['lol'] = 'yes'
    assert len(cookies.headers) == 1
    del cookies['lol']
    assert len(cookies.headers) == 0
    cookies['lol'] = 'lol'
    cookies['lol2'] = 'lol2'
    cookies['lol3'] = 'lol3'
    cookies['lol4'] = 'lol4'
    cookies['lol5'] = 'lol5'
    cookies['lol6'] = 'lol6'
    cookies['lol7'] = 'lol7'
    cookies['lol8'] = 'lol8'

# Generated at 2022-06-21 22:42:24.434967
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeaderDict()
    cookieJar = CookieJar(headers)
    assert headers.getall(cookieJar.header_key) == []
    assert cookieJar.cookie_headers == {}

    cookieJar["newcookie"] = "chocolate chip cookie"
    assert headers.getall(cookieJar.header_key) != []
    assert cookieJar.cookie_headers != {}

    assert headers.getall(cookieJar.header_key) == ['newcookie=chocolate chip cookie; path=/']
    assert cookieJar['newcookie'] == 'chocolate chip cookie'



# Generated at 2022-06-21 22:42:26.629956
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers([('Set-Cookie', 'foo=foo_value; path=/')])
    expected = Headers([('Set-Cookie', '')])
    cookies = CookieJar(headers)
    del cookies['foo']
    assert headers == expected


# Generated at 2022-06-21 22:42:33.984176
# Unit test for constructor of class Cookie
def test_Cookie():
    key = 'key'
    value = 'value'
    cookie = Cookie(key,value)

    assert cookie.value == value
    assert cookie.key == key

#Unit test for the setitem method of class Cookie

# Generated at 2022-06-21 22:42:41.075961
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("name", "value")
    assert c["path"] == "/"
    assert c["expires"] == 0
    assert c["max-age"] == DEFAULT_MAX_AGE
    assert c["comment"] == None
    assert c["domain"] == None
    assert c["secure"] == False
    assert c["httponly"] == False
    assert c["version"] == None
    assert c["samesite"] == None
    assert c.key == "name"
    assert c.value == "value"
    assert c.encode("utf8") == b"name=value; path=/; max-age=0"
    assert str(c) == "name=value; Path=/; Max-Age=0"


# Generated at 2022-06-21 22:42:43.808430
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('key', 'value')
    assert cookie.encode('utf-8') == 'key=value'

# Generated at 2022-06-21 22:42:48.095504
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    expected = 'foo=bar; Expires=Wed, 09 Jun 2021 10:18:14 GMT'.encode("utf-8")
    cookie = Cookie('foo', 'bar')
    cookie['expires'] = datetime(2021, 6, 9, 10, 18, 14)
    assert cookie.encode("utf-8") == expected

# Generated at 2022-06-21 22:42:57.735878
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test_Cookie___setitem__", "test_Cookie___setitem__")
    cookie["expires"] = datetime.utcnow()
    cookie["path"] = "/"
    cookie["comment"] = "test_Cookie___setitem__"
    cookie["domain"] = "test_Cookie___setitem__"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = False
    cookie["httponly"] = False
    cookie["version"] = "test_Cookie___setitem__"
    cookie["samesite"] = "lax"

    cookie["test_Cookie___setitem__"] = "test"


# Generated at 2022-06-21 22:43:04.550793
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    dict_headers: Dict[str, str] = {}
    my_jar = CookieJar(headers=dict_headers)
    my_jar['test'] = 'test'
    my_jar['test1'] = 'test1'
    my_jar['test2'] = 'test2'
    assert dict_headers['Set-Cookie'] == 'test=test; Path=/; test1=test1; Path=/; test2=test2; Path=/;'



# Generated at 2022-06-21 22:43:06.061661
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('name', 'value')
    assert cookie.encode('utf-8') == str(cookie).encode('utf-8')

# Generated at 2022-06-21 22:43:16.704853
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Case 1: Ensure encode works for success case
    cookie = Cookie(key="foo", value="bar")
    cookie_str = cookie.encode(encoding="utf-8")

    assert cookie_str.decode("utf-8") == "foo=bar"

    # Case 2: Ensure encode raises UnicodeEncodeError for encoding
    # that does not support
    invalid_encoding = "ascii"
    invalid_cookie_val = "bar🎂"
    invalid_cookie = Cookie(key="foo", value=invalid_cookie_val)

    with pytest.raises(UnicodeEncodeError):
        invalid_cookie.encode(invalid_encoding)

# Generated at 2022-06-21 22:43:28.248686
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie('foo', 'bar')
    cookie['path'] = '/'
    assert str(cookie) == 'foo=bar; Path=/'
    cookie['secure'] = True
    assert str(cookie) == 'foo=bar; Path=/" Secure'
    cookie = Cookie('foo', 'bar')
    cookie['max-age'] = 'baz'
    with pytest.raises(TypeError):
        str(cookie)
    cookie['max-age'] = 300
    assert str(cookie) == 'foo=bar; Max-Age=300'
    cookie['expires'] = datetime(2020, 2, 20, 15, 0, 1)
    assert str(cookie) == 'foo=bar; Max-Age=300; Expires=Thu, 20-Feb-2020 15:00:01 GMT'

# Generated at 2022-06-21 22:43:33.585488
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    jar["foo"] = "baz"
    jar["foo"] = "qux"

    assert jar["foo"] == "qux"
    cookies = headers.popall("Set-Cookie")
    assert len(cookies) == 1
    assert cookies[0].key == "foo"
    assert cookies[0].value == "qux"



# Generated at 2022-06-21 22:43:41.680332
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookies_object = CookieJar(headers)
    cookies_object['key_1'] = "value_1"
    key = 'key_1'
    del cookies_object[key]
    assert 'key_1' not in cookies_object


# Generated at 2022-06-21 22:43:47.268738
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "foo"
    value = "bar"
    cookie = Cookie(key, value)
    assert cookie.key == "foo"
    assert cookie.value == "bar"
    assert cookie.encode("utf-8")
    assert str(cookie) == "foo=bar"
    cookie = Cookie(key, value)
    assert cookie.encode("utf-8")
    assert str(cookie) == "foo=bar"


# Generated at 2022-06-21 22:43:58.194771
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # Make a fake request object and add a couple of different headers
    # that can be accessed using the dictionary interface (the same
    # interface that is defined in the BaseRequest class).
    headers = MultiHeader()

    headers.add('Header', 'a')
    headers.add('Set-Cookie', 'b')
    headers.add('Set-Cookie', 'c')
    headers.add('Set-Cookie', 'd')

    cookie_jar = CookieJar(headers)

    cookie_jar['key1'] = 'value1'
    assert cookie_jar['key1'].value == 'value1'

    cookie_jar['key2'] = 'value2'
    assert cookie_jar['key2'].value == 'value2'

    assert cookie_jar['key1'].value == 'value1'


# Generated at 2022-06-21 22:44:05.666338
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.requests import Request
    from starlette.responses import Response

    # Create a CookieJar instance with default headers
    response = Response()
    cookie_jar = CookieJar(response.headers)
    # Test CookieJar instance if it has headers
    assert response.headers is not None
    # Test CookieJar instance if it has a key-value field "header_key"
    assert hasattr(cookie_jar, "header_key")
    # Check if "header_key" field is a string type
    assert isinstance(cookie_jar.header_key, str)
    # Test CookieJar instance if it has a key-value field "headers"
    assert hasattr(cookie_jar, "headers")
    # Check if "headers" field is a dictionary type
    assert isinstance(cookie_jar.headers, dict)
    # Test CookieJar

# Generated at 2022-06-21 22:44:10.494588
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    content = b"\xce\xbb"
    encoding_type = "utf-8"
    test_Cookie = Cookie("name", content)
    result = test_Cookie.encode(encoding_type)
    assert result == b"name=%CE%BB"

# Generated at 2022-06-21 22:44:14.613841
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test", "this is a test")
    cookie_iso8859 = cookie.encode("ISO-8859-1")
    assert isinstance(cookie_iso8859, bytes)


# ------------------------------------------------------------ #
#  Middleware
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:44:24.278724
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    test_jar = CookieJar(headers)

    # ------------------------------------------------------------ #
    #  Add first item
    # ------------------------------------------------------------ #
    test_jar[b"key1"] = b"value1"

    # Check that the key was added to the cookie jar
    assert b"key1" in test_jar
    assert test_jar[b"key1"].value == b"value1"

    # Check the header was added to the headers object
    assert headers[b"Set-Cookie"].value == b"key1=\"value1\"; Path=/; Max-Age=0"

    # ------------------------------------------------------------ #
    #  Add second item
    # ------------------------------------------------------------ #
    test_jar[b"key2"] = b"value2"

    # Check that the key was added to the cookie jar

# Generated at 2022-06-21 22:44:25.607167
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    newCookie = Cookie("key", "value")
    assert newCookie.__str__() == "key=value"


# Generated at 2022-06-21 22:44:38.083012
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """ Test __delitem__ method of CookieJar class """
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["key1"] = "value1"
    cookies["key2"] = "value2"
    cookies["key3"] = "value3"
    assert len(cookies.keys()) == 3
    del cookies["key2"]
    keys_list = ["key1", "key2", "key3"]
    assert cookies.keys() < keys_list
    assert keys_list != cookies.keys()
    assert len(cookies.keys()) == 2
    assert cookies.get("key2") is None
    assert headers.getfirst("Set-Cookie") == "key1=value1; Path=/; key3=value3; Path=/"



# Generated at 2022-06-21 22:44:39.617855
# Unit test for constructor of class Cookie
def test_Cookie():
    _t = Cookie('a', 'b')
    assert _t.key == 'a'
    assert _t.value == 'b'


# Generated at 2022-06-21 22:44:47.710955
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    assert str(cookie) == "key=value"
    assert cookie.key == key
    assert cookie.value == value


# Generated at 2022-06-21 22:44:56.050764
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class MultiHeader(list):
        def add(self, *args, **kwargs):
            self.append(args)

        def popall(self, key):
            self.pop(0)
            return []

    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "value"
    cookie_jar["expires"] = datetime.now()
    cookie_jar["path"] = "/"
    cookie_jar["comment"] = "Comment"
    cookie_jar["domain"] = "Domain"
    cookie_jar["max-age"] = "Max-Age"
    cookie_jar["secure"] = "Secure"
    cookie_jar["httponly"] = "HttpOnly"
    cookie_jar["version"] = "Version"

# Generated at 2022-06-21 22:45:07.890325
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_str0 = Cookie(b"test_key", b"test_value").__str__()
    assert cookie_str0 == 'test_key=test_value'

    cookie0 = Cookie(b"test_key", b"test_value")
    cookie0['path'] = '/'
    cookie_str1 = cookie0.__str__()
    assert cookie_str1 == 'test_key=test_value; Path=/'

    cookie0['max-age'] = '123'
    cookie_str2 = cookie0.__str__()
    assert cookie_str2 == 'test_key=test_value; Path=/; Max-Age=123'

    cookie0 = Cookie(b"test_key", b"test_value")
    cookie0['expires'] = datetime.now()
    cookie_str3 = cookie0

# Generated at 2022-06-21 22:45:17.324850
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("key","value")
    try:
        assert (c["expires"] == "expires")
    except KeyError:
        assert True
    else:
        assert False
    try:
        assert (c["version"] == "Version")
    except KeyError:
        assert True
    else:
        assert False
    try:
        assert (c["httponly"] == "HttpOnly")
    except KeyError:
        assert True
    else:
        assert False
    try:
        assert (c["secure"] == "Secure")
    except KeyError:
        assert True
    else:
        assert False
    try:
        assert (c["max-age"] == "Max-Age")
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 22:45:27.582614
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = {"Header": "Value"}
    jar = CookieJar(headers)

    assert jar.header_key == "Set-Cookie"
    assert jar.headers == {"Header": "Value"}
    assert jar.cookie_headers == {}

    cookie = Cookie("cookie", "value")
    jar[cookie.key] = cookie.value
    
    assert jar.header_key == "Set-Cookie"
    assert len(jar.headers) == 2
    assert jar.headers["Header"] == "Value"
    assert jar.headers["Set-Cookie"] == "cookie=value; Path=/; Version=0"
    assert jar.cookie_headers == {"cookie": "Set-Cookie"}

    del jar[cookie.key]

    assert jar.header_key == "Set-Cookie"
    assert jar.headers == {}
    assert jar

# Generated at 2022-06-21 22:45:31.404416
# Unit test for constructor of class Cookie
def test_Cookie():
    testCookie = Cookie("CookieKey", "CookieValue")
    assert testCookie["Comment"] == "Comment"
    assert testCookie.key == "CookieKey"
    assert testCookie.value == "CookieValue"


# Generated at 2022-06-21 22:45:40.099531
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # Test CookieJar constructor
    headers = MultiHeader()
    cookieJar = CookieJar(headers)

    # Test addition of key/value pair to cookieJar
    cookieJar["test"] = "test"
    assert cookieJar["test"].value == "test"
    assert cookieJar["test"]["path"] == "/"

    # Test double-quoted string
    cookieJar["test"] = '"test"'
    assert cookieJar["test"].value == '"test"'

    # Test basic string
    cookieJar["test"] = "test"
    assert cookieJar["test"].value == "test"

    # Test None value
    cookieJar["test"] = None
    assert cookieJar["test"].value == None


# Generated at 2022-06-21 22:45:47.082056
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('key', 'value')
    assert c.key == 'key'
    assert c.value == 'value'
    assert c == {}
    assert str(c) == 'key=value'

    c = Cookie('key', 'value;')
    assert c.key == 'key'
    assert c.value == 'value;'
    assert c == {}
    assert str(c) == r'key="value;"'


# Generated at 2022-06-21 22:45:58.080706
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    cj = CookieJar(headers)
    cj["hello"] = "world"
    assert(cj.get("hello").value == "world")
    assert(headers[cj.header_key] == "hello=world; Path=/")
    cj["hello"] = "universe"
    assert(cj.get("hello").value == "universe")
    assert(headers[cj.header_key] == "hello=universe; Path=/")
    cj["testing"] = "testing"
    assert(cj.get("hello").value == "universe")
    assert(cj.get("testing").value == "testing")
    assert(headers[cj.header_key] == ["hello=universe; Path=/", "testing=testing; Path=/"])

# Generated at 2022-06-21 22:46:01.123104
# Unit test for constructor of class CookieJar
def test_CookieJar():

    headers = dict()
    cookie_jar = CookieJar(headers)

    assert not cookie_jar

    cookie_jar['key'] = 'value'

    assert cookie_jar['key'] == 'value'

# Generated at 2022-06-21 22:46:11.818064
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from types import SimpleNamespace
    c = CookieJar(SimpleNamespace(headers=[]))
    c["foo"] = "bar"
    assert c["foo"] == "bar"

# Generated at 2022-06-21 22:46:18.942019
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "")
    cookie["path"] = "/"
    cookie["expires"] = datetime.now()
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "lax"
    cookie["test"] = ""
    cookie["test"] = False
    cookie["test"] = 0

    try:
        cookie["test"] = 1.0
    except:
        pass

    try:
        cookie["test"] = None
    except:
        pass


# Generated at 2022-06-21 22:46:29.080121
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    import json

    def _test_encoding_output(cookie_encoded, encoding):
        """
        Add assert statements to test decoded value returned by
        cookie.encode()
        """
        # Simple test for utf-8 encoding
        assert cookie_encoded.decode("utf-8") == "name=té, سلام, 你好, 반갑습니다."
        # Simple test for ascii encoding
        assert (
            cookie_encoded.decode("ascii")
            == "name=tÃ©, Ø³ÙØ±Ù?, ä½ å¥½, Ã¬Ã¥Ã¬Ã¦Ã¬Ã­Ã¥Â¬Ã¬."
        )

   

# Generated at 2022-06-21 22:46:32.683730
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from .test_utils import get_headers
    headers = get_headers()

    # create a CookieJar instance
    cookies = CookieJar(headers)

    # set a cookie named hello and assign it an empty string as its value
    cookies["hello"] = ""

    # delete it
    del cookies["hello"]

    # make sure that it has been deleted
    assert "hello" not in cookies



# Generated at 2022-06-21 22:46:40.818459
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Headers doesn't have a cookie
    headers = MultiHeader(dict())
    cookiejar = CookieJar(headers)
    key = 'abc'
    value = 'value'
    cookiejar.__setitem__(key, value)
    assert isinstance(cookiejar[key], Cookie)
    assert key in cookiejar
    cookiejar.__delitem__(key)
    assert key not in cookiejar

    # Headers have a cookie
    headers = MultiHeader(dict())
    cookiejar = CookieJar(headers)
    cookiejar[key] = value
    assert isinstance(cookiejar[key], Cookie)
    assert key in cookiejar
    cookiejar.__delitem__(key)
    assert key not in cookiejar

    # Invalid key type
    headers = MultiHeader(dict())
    cookiejar = CookieJar(headers)
   

# Generated at 2022-06-21 22:46:49.359758
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Test method Cookie.__str__."""
    from datetime import datetime

    cookie = Cookie('key', 'value')
    assert str(cookie) == 'key=value'

    cookie['expires'] = datetime(2018, 2, 1, 9, 30, 0)
    assert str(cookie) == 'key=value; Expires=Thu, 01-Feb-2018 09:30:00 GMT'

    cookie['httponly'] = True
    assert str(cookie) == 'key=value; Expires=Thu, 01-Feb-2018 09:30:00 GMT; HttpOnly'

    cookie['secure'] = True
    assert str(cookie) == 'key=value; Expires=Thu, 01-Feb-2018 09:30:00 GMT; HttpOnly; Secure'

    cookie['comment'] = 'test'

# Generated at 2022-06-21 22:46:55.733562
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDictProxy(CIMultiDict())
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert headers == {"Set-Cookie":[Cookie('foo',"bar")]}
    cookie_jar["foo"] = "baz"
    assert headers == {"Set-Cookie":[Cookie('foo',"baz")]}
    cookie_jar["bar"] = "foo"
    assert headers == {"Set-Cookie":[Cookie('foo',"baz"), Cookie('bar',"foo")]}
    cookie_jar["bar"] = ""
    assert headers == {"Set-Cookie":[Cookie('foo',"baz"), Cookie('bar',"")]}
    cookie_jar["bar"] = None
    assert headers == {"Set-Cookie":[Cookie('foo',"baz"), Cookie('bar',"")]}


# Generated at 2022-06-21 22:47:07.047811
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    headers.add("Set-Cookie", "foo=bar")
    headers.add("Set-Cookie", "lel=lol")
    headers.add("Set-Cookie", "bar=foo")
    assert headers.getall("Set-Cookie") == ["foo=bar", "lel=lol", "bar=foo"]
    cookies["foo"] = "newbar"
    cookies["lel"] = "newlol"
    cookies["bar"] = "newfoo"
    assert headers.getall("Set-Cookie") == ["foo=newbar", "lel=newlol", "bar=newfoo"]
    del cookies["bar"]

# Generated at 2022-06-21 22:47:12.091105
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('a', 'b')
    cookie['path'] = '/'
    cookie['max-age'] = DEFAULT_MAX_AGE
    cookie['comment'] = 'test'
    assert cookie['path'] == '/'
    assert cookie['max-age'] == DEFAULT_MAX_AGE
    assert cookie['comment'] == 'test'
    assert cookie['secure'] == 0



# Generated at 2022-06-21 22:47:15.619711
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookiejar = CookieJar()
    cookiejar["test_key_1"] = "test_value_1"
    # Remove key from cookiejar
    del cookiejar["test_key_1"]
    assert not "test_key_1" in cookiejar


# Generated at 2022-06-21 22:47:30.592113
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("test", "testvalue")
    assert(str(c)) == "test=testvalue"
    assert(c.value) == "testvalue"
    c["httponly"] = True
    assert(str(c)) == "test=testvalue; HttpOnly"
    c = Cookie("test", "testvalue")
    c["max-age"] = 200
    assert(str(c)) == "test=testvalue; Max-Age=200"
    c = Cookie("test", "testvalue")
    c["expires"] = datetime.now()
    assert(c["expires"] == datetime.now())
    assert(str(c).startswith("test=testvalue; Expires="))


# Generated at 2022-06-21 22:47:31.575997
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    pass

# Generated at 2022-06-21 22:47:41.512208
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    assert cookie.encode("utf-8") == b"name=value"

    cookie["max-age"] = "12345"
    assert str(cookie) == "name=value; Max-Age=12345"

    cookie["max-age"] = 12345
    assert str(cookie) == "name=value; Max-Age=12345"

    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("name=value; Max-Age=12345; Expires=") is True

    del cookie["max-age"]
    assert str(cookie).startswith("name=value; Expires=") is True

    cookie["secure"] = True
    assert str(cookie).endswith("; Secure")

# Generated at 2022-06-21 22:47:47.578677
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    expected_dict = {'expires': None, 'path': '/', 'Comment': None, 'Domain': None, 'Max-Age': 0, 'Secure': None, 'HttpOnly': None, 'Version': None, 'SameSite': None}
    expected_key = 'first_name'
    expected_value = 'first_value'
    #Case 1: The key is not contained in _keys, an exception is expected and it is caught
    unique_key = 'unique'
    #Case 2: The key is contained in _keys, no exception is expected and the value is in the dictionary
    key = 'expires'
    value = datetime.today()
    cookie = Cookie(expected_key, expected_value)

# Generated at 2022-06-21 22:47:58.101994
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

    # Set a cookie.
    cookie_jar['tasty_cookie'] = 'yum'
    print(headers['Set-Cookie'])
    assert headers['Set-Cookie'] == 'tasty_cookie=yum; Path=/'

    # Overwrite an existing cookie with a new value.
    cookie_jar['tasty_cookie'] = 'super-yum'
    print(headers['Set-Cookie'])
    assert headers['Set-Cookie'] == 'tasty_cookie=super-yum; Path=/'

    # Delete a cookie, by setting max-age to zero.
    del cookie_jar['tasty_cookie']
    print(headers['Set-Cookie'])

# Generated at 2022-06-21 22:48:01.688664
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_name = "sess_id"
    cookie_value = "1"
    headers = gh.MultiHeader()
    cookie_jar = gh.CookieJar(headers)

    try:
        del cookie_jar[cookie_name]
    except KeyError:
        return True
    return False


# Generated at 2022-06-21 22:48:03.899980
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("name", "value")
    assert cookie.key == "name"
    assert cookie.value == "value"
    assert cookie["path"] == "/"
    assert not cookie["max-age"]



# Generated at 2022-06-21 22:48:15.917317
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["expires"] = datetime.utcnow()
    cookie["path"] = "/"
    cookie["comment"] = "This is a comment"
    cookie["domain"] = "localhost"
    cookie["max-age"] = 10
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = "1"
    str_cookie = str(cookie)
    assert ("name=value; expires=%s" % cookie["expires"].strftime("%a, %d-%b-%Y %T GMT")) in str_cookie
    assert "domain=localhost" in str_cookie
    assert "path=/; " in str_cookie
    assert "comment=This is a comment" in str_cookie
    assert "max-age=10" in str_cookie

# Generated at 2022-06-21 22:48:27.566390
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test-cookie", "default")

    # Standard setting of a cookie
    cookie["domain"] = "localhost"
    assert cookie["domain"] == "localhost"

    # Reject setting of reserved word
    with pytest.raises(KeyError):
        cookie["expires"] = "yesterday"

    # Reject setting of illegal chars
    with pytest.raises(KeyError):
        cookie["illegal characters"] = "yesterday"

    # Reject setting of unrecognized key
    with pytest.raises(KeyError):
        cookie["unrecognized key"] = "yesterday"

    # Accept setting of integer
    cookie["max-age"] = 20
    assert cookie["max-age"] == 20

    # Reject setting of non-integer

# Generated at 2022-06-21 22:48:32.049774
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("test", "value")
    cookie["path"] = "/"
    cookie["expires"] = datetime.utcnow() + timedelta(days=1)
    assert str(cookie).startswith("test=value")


# ------------------------------------------------------------ #
#  Tests
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:48:55.862709
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = HTTPHeaders()
    headers.add("Set-Cookie", "a=1")
    jar = CookieJar(headers)
    jar["b"] = 2
    assert len(jar) == 2
    assert jar["a"].value == "1"
    assert jar["b"].value == "2"
    assert headers.get_all("Set-Cookie") == ["a=1", "b=2"]



# Generated at 2022-06-21 22:49:01.490251
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cj = CookieJar(None)
    cj["key"] = "val"
    assert cj["key"].value == "val", "Setting cookie value failed"
    assert cj["key"].key == "key", "Setting cookie key failed"
    assert type(cj["key"]) == Cookie, "Setting cookie type failed"
    assert cj.header_key == "Set-Cookie", "Setting header key failed"


# Generated at 2022-06-21 22:49:08.522726
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("A", "\u2713")
    assert cookie.encode("utf-8") == b"A=\xe2\x9c\x93"

    # UnicodeEncodeError is raised if encoding parameter is set to a value other
    # than "utf-8"
    with pytest.raises(UnicodeEncodeError):
        cookie.encode("ascii")
    # If the developer forgets to pass the encoding parameter,
    # KeyError is raised
    with pytest.raises(TypeError):
        cookie.encode()

# Generated at 2022-06-21 22:49:10.348599
# Unit test for constructor of class Cookie
def test_Cookie():
    try:
        cookie = Cookie("a", "b")
    except Exception:
        assert False



# Generated at 2022-06-21 22:49:15.618699
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    cookie["path"] = "path"
    cookie["max-age"] = "max-age"
    cookie["expires"] = datetime(2020, 1, 1)
    cookie["secure"] = True
    cookie["httponly"] = True

    assert str(cookie) == 'key=value; Path=path; Max-Age=max-age; expires=Wed, 01-Jan-2020 00:00:00 GMT; Secure; HttpOnly'

# Generated at 2022-06-21 22:49:23.744486
# Unit test for method __str__ of class Cookie

# Generated at 2022-06-21 22:49:35.294826
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class Headers:
        def __init__(self):
            self.key_dict = {}
        def add(self, key, value):
            if key in self.key_dict:
                self.key_dict[key].append(value)
            else:
                self.key_dict[key] = [value]

        def popall(self, key):
            if key not in self.key_dict:
                return []
            else:
                return self.key_dict.pop(key)

    headers = Headers()
    cj = CookieJar(headers)

    # test that deleting a non-existent key raises KeyError
    try:
        del cj['non-existent-key']
    except KeyError as k:
        print('Key {0} not in dictionary when deleting'.format(k))

    # test that deleting

# Generated at 2022-06-21 22:49:37.746490
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    tst_cookie = Cookie("test", "test_cookie")
    # encode
    assert tst_cookie.encode(encoding="utf-8").decode("utf-8") == "test=test_cookie"

# Generated at 2022-06-21 22:49:39.450941
# Unit test for constructor of class CookieJar
def test_CookieJar():
    jar = CookieJar()
    assert isinstance(jar, CookieJar)
    assert not jar
    return jar



# Generated at 2022-06-21 22:49:40.466949
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookieJar = CookieJar([])
    assert cookieJar
