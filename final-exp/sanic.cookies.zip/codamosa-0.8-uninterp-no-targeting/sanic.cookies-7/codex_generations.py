

# Generated at 2022-06-21 22:40:06.255497
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("cookieName", "cookieValue")
    assert c.key == "cookieName"
    assert c.value == "cookieValue"
    assert c.items() == [("max-age", DEFAULT_MAX_AGE)]


# Generated at 2022-06-21 22:40:08.453585
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("a", "b")
    actual = str(cookie)
    assert actual == "a=b"



# Generated at 2022-06-21 22:40:11.324540
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    cookies["name"] = "value"
    assert cookies["name"].value == "value"



# Generated at 2022-06-21 22:40:17.472330
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("name", "value")
    assert cookie.key == "name"
    assert cookie.value == "value"
    assert len(cookie) == 0
    assert cookie["max-age"] == DEFAULT_MAX_AGE

# Generated at 2022-06-21 22:40:19.674429
# Unit test for constructor of class CookieJar
def test_CookieJar():
  cookieJar = CookieJar({})
  assert len(cookieJar) == 0

# Generated at 2022-06-21 22:40:31.541863
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("a", "b")
    assert str(c) == "a=b"
    c["path"] = "/user"
    assert str(c) == "a=b; Path=/user"
    c["max-age"] = 3
    assert str(c) == "a=b; Path=/user; Max-Age=3"
    c["expires"] = datetime(2020, 8, 1, 0, 0)
    assert str(c) == "a=b; Path=/user; Max-Age=3; expires=Sat, 01-Aug-2020 00:00:00 GMT"
    c["secure"] = False
    assert str(c) == "a=b; Path=/user; Max-Age=3; expires=Sat, 01-Aug-2020 00:00:00 GMT"
    c["secure"] = True


# Generated at 2022-06-21 22:40:41.305909
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.types import ASGIApp, Scope, Receive, Send
    from starlette.datastructures import Headers
    from starlette.responses import Response
    
    async def app(scope: Scope, receive: Receive, send: Send) -> None:
        headers = Headers()
        cj = CookieJar(headers)
        cj["test-cookie"] = "test-cookie-value"
        cj["test-cookie-path"] = "test-cookie-path-value"
        cj["test-cookie-path"]["path"] = "/test_cookie_path"
        cj["test-cookie-path"]["max-age"] = "3600"
        cj["test-cookie-path"]["expires"] = datetime.now()

# Generated at 2022-06-21 22:40:51.499847
# Unit test for constructor of class CookieJar
def test_CookieJar():
    class Headers:
        def __init__(self):
            self.header_keys = {}

        def add(self, header_key: str, header_value: str):
            if header_key not in self.header_keys:
                self.header_keys[header_key] = []
            self.header_keys[header_key].append(header_value)

        def popall(self, header_key: str):
            return self.header_keys.pop(header_key)

    headers = Headers()
    cookies = CookieJar(headers)
    assert len(headers.header_keys) == 0
    assert len(cookies.cookie_headers) == 0



# Generated at 2022-06-21 22:40:56.951722
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Initialize a cookie
    cookie = Cookie('sampleCookie', 'sampleValue')
    # Encode in UTF-8
    encodedCookie = cookie.encode('utf-8')
    # Assert values
    assert encodedCookie == b'sampleCookie=sampleValue'

# Generated at 2022-06-21 22:41:05.351710
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Test when 'ascii' is passed as encoding
    cookie = Cookie('name1', 'value1')
    assert cookie.encode('ascii') == b'name1=value1; Max-Age=0'
    # Test when 'utf-8' is passed as encoding
    cookie = Cookie('name2', 'value2')
    assert cookie.encode('utf-8') == b'name2=value2; Max-Age=0'
    # Test when utf-8 encoded values are passed
    cookie = Cookie('n\xc3\xa3me3', 'val\xc3\xa3ue3')
    assert cookie.encode('ascii') == b'n\\303\\243me3=val\\303\\243ue3; Max-Age=0'
    # Test when utf-8 encoded values are passed
   

# Generated at 2022-06-21 22:41:18.244219
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie(key="key", value="value")
    assert cookie.key == "key"
    assert cookie.value == "value"
    assert cookie["expires"] == None
    with pytest.raises(KeyError):
        cookie["max-age2"] = 200
    with pytest.raises(ValueError):
        cookie["max-age"] = "200A"
    with pytest.raises(TypeError):
        cookie["expires"] = datetime.now()


# Generated at 2022-06-21 22:41:30.488872
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # Create a new Cookie Jar
    headers = MultiDict()
    cookies = CookieJar(headers)

    # Creating a cookie with a cookie name that is a reserved word should
    # Throw a KeyError
    with pytest.raises(KeyError):
        cookies["expires"] = "123"

    # Creating a cookie with an illegal name should throw a KeyError
    with pytest.raises(KeyError):
        cookies["domain="] = "123"

    # Create two cookies, make sure they get added to the header list
    cookies["a"] = "1"
    cookies["a"]["domain"] = "localhost"
    cookies["b"] = "2"

    # Check that the header value is correct
    assert cookies["a"].key == "a"
    assert cookies["a"].value == "1"

# Generated at 2022-06-21 22:41:34.593264
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["key1"] = "value1"

    assert "value1" == cookie_jar["key1"].value
    assert 'key1=value1' in headers["Set-Cookie"]
    assert 'key1=value1' not in headers["Set-Cookie1"]



# Generated at 2022-06-21 22:41:40.316294
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    jar = CookieJar(headers)
    jar["test1"] = "cookie1"
    assert jar["test1"] == "cookie1"
    cookie = jar["test1"]
    assert cookie["path"] == "/"
    assert headers[CookieJar.header_key] == cookie



# Generated at 2022-06-21 22:41:42.450803
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("test_cookies", "should_work")
    assert cookie["value"] == "should_work"

# Generated at 2022-06-21 22:41:50.394414
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    with pytest.raises(KeyError):
        cookie["expires"] = "expires"
    with pytest.raises(KeyError):
        cookie["path"] = "Path"
    with pytest.raises(KeyError):
        cookie["comment"] = "Comment"
    with pytest.raises(TypeError):
        cookie["max-age"] = "not type of integer"
    with pytest.raises(KeyError):
        cookie["unknown key"] = "unknown value"

if __name__ == "__main__":
    pytest.main(["-x", "--pdb", __file__])

# Generated at 2022-06-21 22:41:53.454931
# Unit test for constructor of class CookieJar
def test_CookieJar():
    from aiohttp.multidict import CIMultiDict

    headers = CIMultiDict()
    cookie_jar = CookieJar(headers)
    assert not cookie_jar
    assert not headers



# Generated at 2022-06-21 22:41:54.320794
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    pass



# Generated at 2022-06-21 22:41:56.155316
# Unit test for constructor of class CookieJar
def test_CookieJar():
    c = CookieJar(headers={})
    assert c.headers == {}
    assert c.cookie_headers == {}
    assert c.header_key == "Set-Cookie"



# Generated at 2022-06-21 22:42:02.560400
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    jar = CookieJar(headers)

    jar["test_cookie_1"] = "1"
    jar["test_cookie_2"] = "2"
    jar["test_cookie_3"] = "3"

    assert jar.cookie_headers == {"test_cookie_1": "Set-Cookie", "test_cookie_2": "Set-Cookie", "test_cookie_3": "Set-Cookie"}
    assert jar._items == {"test_cookie_1": "1", "test_cookie_2": "2", "test_cookie_3": "3"}
    assert headers == {'Set-Cookie': ['test_cookie_1="1"; Path=/;', 'test_cookie_2="2"; Path=/;', 'test_cookie_3="3"; Path=/;']}

# Generated at 2022-06-21 22:42:15.266176
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "Hello, world!")
    cookie["Version"] = "1"
    str_out = str(cookie)
    assert str_out == "key=Hello%2C%20world%21; Version=1"

    # Test for empty value
    cookie.value = ""
    cookie["Version"] = "1"
    str_out = str(cookie)
    assert str_out == "key=; Version=1"

    # Test for empty value
    cookie.value = "; "
    cookie["Version"] = "1"
    str_out = str(cookie)
    assert str_out == 'key="; "; Version=1'

    # Test for keys must be legal characters
    cookie = Cookie("!", "Hello, world!")
    str_out = str(cookie)
    assert str_out

# Generated at 2022-06-21 22:42:18.328987
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("key","value")
    s = c.encode("utf-8")
    assert isinstance(s, bytes)
    assert s == b"key=value"

# Generated at 2022-06-21 22:42:25.594594
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("foo", "bar")
    assert c.encode("latin-1") == b"foo=bar"
    # encode using utf-8
    assert c.encode("utf-8") == b"foo=bar"
    # encode using hex encoding
    c["comment"] = "£✓"
    assert c.encode("hex_codec") == b"foo=bar; Comment=c2a3e29c"

# Generated at 2022-06-21 22:42:35.994074
# Unit test for constructor of class Cookie
def test_Cookie():
    # test constructor of Cookie
    key = "key"
    value = "value"
    cookie = Cookie(key, value)
    # test existance of all fields
    assert cookie.key == key
    assert cookie.value == value
    assert cookie["path"] == "/"
    # test illegal keys
    illegal_key = "key,,"
    try:
        cookie = Cookie(illegal_key, value)
        assert False
    except KeyError:
        assert True
    # test illegal value
    illegal_value = "key,,"
    try:
        cookie = Cookie(key, illegal_value)
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 22:42:46.537856
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """ Constructor for Cookie class"""
    # test values
    key = "hello"
    value = "persistent world"
    encoding = "utf-8"
    test_s = 'hello="persistent world"; Path=/; Expires=Tue, 01-Jan-2020 00:00:00 GMT'

    cookie = Cookie(key, value)
    cookie["path"] = "/"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)

    s = cookie.encode(encoding)
    assert(test_s == s.decode(encoding))


# Generated at 2022-06-21 22:42:53.913186
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("c", "v")
    assert str(c) == "c=v"

    c = Cookie("c", "v")
    c["secure"] = True
    assert str(c) == "c=v; Secure"

    # The following are updated in the repo version of Cookie 
    # and borrowed from the uwsgi version of Cookie__str__
    c = Cookie("c", '"quoted value"')
    assert str(c) == 'c="\\"quoted value\\""'

    c = Cookie("c", "quotes\\")
    assert str(c) == 'c="quotes\\\\"'

    c = Cookie("c", "\\")
    assert str(c) == 'c="\\\\"'



# Generated at 2022-06-21 22:43:03.424366
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "Zuck")

    # Test if Cookie name is a reserved word
    with pytest.raises(KeyError):
        cookie["path"] = "test"

    # Test if Cookie name contains illegal characters
    with pytest.raises(KeyError):
        cookie["&^*%$()/.,^#@!()/.,^#@!$" * 5] = "test"

    with pytest.raises(ValueError):
        cookie["max-age"] = "max-age"

    with pytest.raises(TypeError):
        cookie["expires"] = 0



# Generated at 2022-06-21 22:43:08.395037
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("foo", "bar")
    assert cookie["secure"] is False
    assert cookie["httponly"] is False
    assert cookie["version"] == 1
    assert cookie["samesite"] is None
    assert cookie["comment"] is None
    assert cookie["path"] is None
    assert cookie["domain"] is None
    assert cookie["max-age"] == DEFAULT_MAX_AGE
    assert cookie["expires"] is None



# Generated at 2022-06-21 22:43:20.965817
# Unit test for constructor of class Cookie
def test_Cookie():

    # Create an instance of class Cookie
    # test_cookie = Cookie(key, value)

    # test_cookie = Cookie(key, value)
    # test_cookie['key'] = 'value'

    # illegal_cookie = Cookie('key=value', 'value')
    # illegal_cookie['key'] = 'value'

    # legal_key_cookie = Cookie('key_value', 'value')
    # legal_key_cookie['expires'] = 0

    legal_key_cookie = Cookie('key_value', 'value')
    legal_key_cookie['max-age'] = 0

    # illegal_key_cookie = Cookie('key/value', 'value')
    # illegal_key_cookie['expires'] = 0

    # nonnumber_maxage_cookie = Cookie('key_value', 'value')
    # nonnumber_maxage

# Generated at 2022-06-21 22:43:25.615772
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test_Cookie_encode", 1)
    assert cookie.encode("utf-8") == "test_Cookie_encode=1".encode("utf-8")


# ------------------------------------------------------------ #
#  Deprecated
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:43:35.966894
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers: Dict[str, str] = {}
    cookieJar: CookieJar = CookieJar(headers)
    cookieJar["test_cookie_key"] = "test_cookie_value"
    cookieJar["test_cookie_key_2"] = "test_cookie_value_2"
    del cookieJar["test_cookie_key"]
    assert "test_cookie_key" not in cookieJar.headers["Set-Cookie"]
    assert "test_cookie_key_2" in cookieJar.headers["Set-Cookie"]


# Generated at 2022-06-21 22:43:46.874670
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    print("test_Cookie___str__()")
    cookie = Cookie("fred", "bob")

    cookie["max-age"] = 0
    print("cookie:", cookie)
    assert cookie.__str__() == "fred=bob; Max-Age=0"

    print("Test Default")
    cookie = Cookie("fred", "bob")
    print("cookie:", cookie)
    assert cookie.__str__() == "fred=bob"

    cookie["max-age"] = 0
    print("cookie:", cookie)
    assert cookie.__str__() == "fred=bob; Max-Age=0"

    print("Test Expires")
    cookie = Cookie("fred", "bob")
    cookie["expires"] = datetime(1789, 7, 14, 12, 0, 0)

# Generated at 2022-06-21 22:43:51.565853
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["my_name"] = "my_value"
    cookie_jar["my_name"] = "my_value_changed"
    assert headers["Set-Cookie"] == "my_name=my_value_changed; Path=/; Version=1"



# Generated at 2022-06-21 22:43:59.740207
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from core.http.headers import Headers
    print("\n-----------test_CookieJar___setitem__-----------")
    headers = Headers()
    cookies = CookieJar(headers)

    cookies["test-name"] = "test-value"

    expected_output = "Set-Cookie: test-name=test-value; Path=/; Max-Age=0"

    print("Expected output: ", end="")
    print(expected_output)
    print("Actual output: ", end="")
    print(headers["Set-Cookie"])

    assert headers["Set-Cookie"] == expected_output


# Generated at 2022-06-21 22:44:02.571231
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    assert (cookie_jar["foo"] == "bar")
    del cookie_jar["foo"]
    try:
        test = cookie_jar["foo"]
    except KeyError:
        test = None
    assert (test == None)

# Generated at 2022-06-21 22:44:08.302880
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    test_data = {
        "key": "foo",
        "value": "bar",
        "expires": "Sat, 22 Feb 2020 06:22:11 GMT",
        "comment": "This is a cookie",
        "domain": "www.google.com",
        "max-age": 0,
        "secure": False,
        "httponly": True,
        "version": 0,
    }

    cookie = Cookie(**test_data)
    expected = "foo=bar; Expires=Sat, 22 Feb 2020 06:22:11 GMT; Comment=This is a cookie; Domain=www.google.com; Max-Age=0; HttpOnly"
    actual = str(cookie)
    assert expected == actual

# Generated at 2022-06-21 22:44:18.637665
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("_unit_test", "value")

    # Test encode
    assert c.encode("utf-8") == b"_unit_test=value"
    assert c.encode("utf-16") == b"\xff\xf8\x00_\x00u\x00n\x00i\x00t\x00_\x00t\x00e\x00s\x00t\x00=\x00v\x00a\x00l\x00u\x00e"
    c["expires"] = "value"
    with pytest.raises(TypeError):
        c.encode("utf-8")
    # Test for encoding errors
    c = Cookie("_unit_test", "\u2028\ud83d\ude02")

# Generated at 2022-06-21 22:44:20.661506
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    print(c)

# ------------------------------------------------------------ #
#  Functions
# ------------------------------------------------------------ #


# Generated at 2022-06-21 22:44:23.501806
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookies = CookieJar(headers=headers)
    assert(cookies.headers == headers)
    assert(cookies.cookie_headers == {})



# Generated at 2022-06-21 22:44:27.939075
# Unit test for constructor of class Cookie
def test_Cookie():
    exp = Cookie("c1", "val1")
    assert exp["expires"] == None
    assert exp["path"] == None
    assert exp["comment"] == None
    assert exp["domain"] == None
    assert exp["max-age"] == None
    assert exp["secure"] == None
    assert exp["httponly"] == None
    assert exp["version"] == None
    assert exp["samesite"] == None


# Generated at 2022-06-21 22:44:42.465269
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar({"SetCookie": "a=b"})
    assert cj == {"a": "b"}
    del cj["a"]
    assert cj == {}
    return True


# Generated at 2022-06-21 22:44:51.043513
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiDict()
    headers['Content-Type'] = 'text/plain; charset=utf-8'
    headers['Set-Cookie'] = 'name="Cookie"; version="1";'
    cookie_jar = CookieJar(headers)
    assert headers == MultiDict({'Content-Type': 'text/plain; charset=utf-8',
                                 'Set-Cookie': 'name="Cookie"; version="1";'})
    assert cookie_jar == {'name': Cookie('name', 'Cookie'),
                          'version': Cookie('version', '1')}


# Generated at 2022-06-21 22:44:57.642679
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Test case 1
    headers = MultiDict()
    cookie1 = CookieJar(headers)
    cookie1["foo"] = "bar"
    cookie1["foo"]["max-age"] = 0
    assert cookie1["foo"] == "bar"
    assert headers.getall("Set-Cookie")[0] == "foo=bar"

    # Test case 2
    cookie2 = CookieJar(headers)
    cookie2["foo"] = "bar"
    cookie2["foo"]["max-age"] = 0
    del cookie2["foo"]
    assert "foo" not in cookie2
    assert headers.getall("Set-Cookie")[0] == "foo=; Max-Age=0"


# Generated at 2022-06-21 22:45:08.836305
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_value = Cookie("key", "value")
    # check output if we have no arguments
    assert str(cookie_value) == "key=value"
    # check if we have max-age
    cookie_value["max-age"] = 10
    assert str(cookie_value) == "key=value; Max-Age=10"
    # check if we have expires
    cookie_value.__delitem__("max-age")
    cookie_value["expires"] = datetime(year=2000, month=1, day=1)
    assert (
        str(cookie_value)
        == "key=value; Expires=Sat, 01-Jan-2000 00:00:00 GMT"
    )
    # check if we have secure
    cookie_value["secure"] = True

# Generated at 2022-06-21 22:45:17.812336
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import pytest
    test_set = [("expires", "www.google.com"), ("path", "/"), ("comment", "first_comment"), ("domain", "google.com"), ("max-age", "1"),("secure", False),("httponly", False),("version", "1.0"),("samesite", "strict")]
    cookie_keys = Cookie("first","last")
    for key, value in test_set:
        if key not in cookie_keys._keys:
            with pytest.raises(KeyError) as e:
                cookie_keys[key] = value
                assert e.value == "Unknown cookie property"

# Generated at 2022-06-21 22:45:27.880045
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import pytest
    test_data = [
        (1, {"key": "comment", "value": "test"}, "Cookie comment must be a string"),
        (2, {"key": "max-age", "value": "test"}, "Cookie max-age must be an integer"),
        (3, {"key": "expires", "value": 1}, "Cookie 'expires' property must be a datetime"),
        (4, {"key": "comment", "value": "test", "encoding": 'utf-8'}, "test"),
        (5, {"key": "comment", "value": "test", "encoding": 'ascii'}, "test")
    ]


# Generated at 2022-06-21 22:45:32.461789
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    request = Request(cookies=[Cookie("a", "b")])
    request.cookies["a"] = "b"
    del request.cookies["a"]
    assert not request.cookies
    assert not request.headers.getall("Set-Cookie")


# Generated at 2022-06-21 22:45:39.113671
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cookies1 = Cookie('1', '1')
    cookies2 = Cookie('2', '2')
    cookiejar = CookieJar(headers)
    cookiejar['1'] = cookies1
    cookiejar['2'] = cookies2
    cookiejar['1']['max-age'] = 0
    cookiejar['2']['max-age'] = 0
    cookiejar.__delitem__('2')
    assert headers['Set-Cookie'][0] == cookies1
    assert headers['Set-Cookie'][1] != cookies2

# Generated at 2022-06-21 22:45:46.509851
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    imgCookies = CookieJar(None)

    assert imgCookies.get("username") is None
    imgCookies["username"] = "admin"
    assert imgCookies["username"] == "admin"
    assert imgCookies.get("username") is not None

    del imgCookies["username"]
    assert imgCookies.get("username") is None
    assert imgCookies.get("username") is None


if __name__ == "__main__":
    test_CookieJar___delitem__()

# Generated at 2022-06-21 22:45:49.406031
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    with pytest.raises(KeyError):
        cookie["expires"] = "Thu, 01-Jan-2000 00:00:00 GMT"
    with pytest.raises(ValueError):
        cookie["max-age"] = "123abc"


# Generated at 2022-06-21 22:46:17.896970
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "john"
    del cookie_jar["name"]
    assert len(headers["Set-Cookie"]) == 0


# Generated at 2022-06-21 22:46:24.626567
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("MyCookie", "66.249.66.1")
    assert cookie["version"] == "1"
    assert cookie["max-age"] == DEFAULT_MAX_AGE
    assert cookie["path"] == "/"
    assert cookie["samesite"] == "Lax"
    assert cookie.encode("utf-8") == b'MyCookie=66.249.66.1; Max-Age=0; Path=/; SameSite=Lax'

# Generated at 2022-06-21 22:46:30.077926
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("n", "v")
    cookie["ma"] = 12345
    expected = {
        "expires": "expires",
        "path": "Path",
        "comment": "Comment",
        "domain": "Domain",
        "max-age": 12345,
        "secure": "Secure",
        "httponly": "HttpOnly",
        "version": "Version",
        "samesite": "SameSite",
        "ma": 12345,
    }
    assert(cookie == expected)

# Generated at 2022-06-21 22:46:33.054630
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test", "value")
    cookie.encode("utf-8")

    assert True

# Generated at 2022-06-21 22:46:39.121448
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie('test', 'test')
    cookie['path'] = '/'
    cookie['domain'] = 'test.com'
    cookie['version'] = '1'
    cookie['max-age'] = 0
    cookie['secure'] = False
    cookie['httponly'] = False
    cookie['comment'] = 'comment'
    cookie['samesite'] = 'Lax'

    assert str(cookie) == '"test=test"; Domain="test.com"; Path="/"; Version="1"; Max-Age=0; Comment="comment"; Secure; HttpOnly; SameSite="Lax"'


# Generated at 2022-06-21 22:46:47.870684
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test_name", "test_value")
    # test illegal key in keys
    with pytest.raises(KeyError):
        cookie["path"] = "test_path"
    # test illegal key not in keys
    with pytest.raises(KeyError):
        cookie["test_illegal_key"] = "test_value"
    # test legal key in keys but value is False
    with pytest.raises(KeyError):
        cookie["comment"] = False
    # test key expires, value not a instance of datetime
    with pytest.raises(TypeError):
        cookie["expires"] = "test_time"
    # test key max-age, value not a integral number
    with pytest.raises(ValueError):
        cookie["max-age"] = "test_max_age"
    #

# Generated at 2022-06-21 22:46:54.879783
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cj = CookieJar()
    cj["foo"] = "bar"

    assert cj.get("foo") == "bar"
    assert cj.get("foo", "baz") == "bar"
    assert cj.get("missing") is None
    assert cj.get("missing", "baz") == "baz"

    assert len(cj) == 1
    assert cj["foo"] == "bar"
    assert cj.get("foo") == "bar"
    assert "foo" in cj
    assert "missing" not in cj

    assert list(cj) == ["foo"]
    assert list(cj.items()) == [("foo", "bar")]
    assert list(cj.keys()) == ["foo"]
    assert list(cj.values()) == ["bar"]

    cj

# Generated at 2022-06-21 22:47:00.864019
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    import pickle

    _COOKIE_CONTENT = "test cookie content"
    _ENCODING_TESTS = ["utf-8", "ascii", "latin-1", "utf-16", "utf-32"]

    for test in _ENCODING_TESTS:
        cookie_obj = Cookie("test_key", _COOKIE_CONTENT)
        pickle.loads(pickle.dumps(cookie_obj.encode(test)))


# Generated at 2022-06-21 22:47:06.999838
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaders()
    cookiejar = CookieJar(headers)

    assert(cookiejar.cookie_headers == {})
    assert(headers.getlist("Set-Cookie") == [])
    cookiejar["key"] = "value"
    assert(headers.getlist("Set-Cookie") == ["key=value; path=/"])



# Generated at 2022-06-21 22:47:09.992857
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie_dict = {'user': 'foo', 'pw': 'bar', 'path': '/', 'expires': datetime.today()}
    cookie = Cookie(**cookie_dict)
    assert cookie.key == 'user'

# Generated at 2022-06-21 22:47:44.593572
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    jar = CookieJar(headers)
    assert jar.headers == headers
    assert jar.cookie_headers == {}
    assert jar.header_key == "Set-Cookie"
    assert jar == {}
    jar["banana"] = "blob"
    assert jar == {
        "banana": Cookie("banana", "blob")
    }
    assert jar["banana"].key == "banana"
    assert jar.cookie_headers == {
        "banana": "Set-Cookie",
    }
    assert jar.headers == {
        "Set-Cookie": [Cookie("banana", "blob")]
    }
    jar["banana"] = "blob"
    assert jar == {
        "banana": Cookie("banana", "blob")
    }


# Generated at 2022-06-21 22:47:48.175639
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = {}
    c = CookieJar(headers)
    assert len(c) == 0
    assert len(c.cookie_headers) == 0
    assert c.headers["Set-Cookie"] == None


# Generated at 2022-06-21 22:47:58.457225
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test for normal case
    c = Cookie("name", "value")
    assert c.__str__() == "name=value"
    # test for the case "max-age"
    c["max-age"] = "123"
    assert c.__str__() == "name=value; Max-Age=123"
    # test for the case 'expires'
    c["expires"] = datetime(2018, 7, 29, 21, 38, 49, 604640)
    assert c.__str__() == "name=value; Max-Age=123; Expires=Sun, 29-Jul-2018 21:38:49 GMT"
    # test for the case "secure"
    c["secure"] = False

# Generated at 2022-06-21 22:48:05.821321
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = {}
    testCookieJar = CookieJar(headers)

    # Test case 1
    # delete non-exist cookie
    testCookieJar.__delitem__("testCookie")
    assert headers == {}

    # Test case 2
    # delete one cookie
    cookie1 = Cookie("testCookie", "testValue")
    testCookieJar["testCookie"] = cookie1
    assert headers["Set-Cookie"] == cookie1
    testCookieJar.__delitem__("testCookie")
    assert headers == {}

    # Test case 3
    # delete one out of three cookies
    cookie1 = Cookie("testCookie1", "testValue")
    cookie2 = Cookie("testCookie2", "testValue")
    cookie3 = Cookie("testCookie3", "testValue")

    # Add three cookies to headers

# Generated at 2022-06-21 22:48:12.244985
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    print("\n---------\nUnit test for method __setitem__ of class CookieJar")
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    cookies["foo"] = "bar"
    print(headers["Set-Cookie"])
    assert headers["Set-Cookie"] == "foo=bar; Path=/", "Error in method __setitem__ of class CookieJar"


# Generated at 2022-06-21 22:48:21.875217
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("cookie_name", "cookie_value")
    # Correct construction
    assert c.key == "cookie_name"
    assert c.value == "cookie_value"
    # Reserved word as key
    with pytest.raises(KeyError):
        c = Cookie("path", "")
    # Wrong characters as key
    with pytest.raises(KeyError):
        c = Cookie("$$$$$$", "")
    # This should have no effect
    c["path"] = False
    assert c["path"] is None
    # Wrong characters as value
    c.value = "$$$$$$"
    assert c.key == "cookie_name"
    assert c.value == "$$$$$$"
    assert str(c) == "cookie_name=%24%24%24%24%24%24"
    # Set path


# Generated at 2022-06-21 22:48:27.427106
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cl = CookieJar(headers)
    #scenario 1: key not in cookie, and assign it the value
    cl["foo"] = "bar"
    cl["another_cookie"] = "another_value"
    del cl["another_cookie"]
    assert "foo" in cl.cookie_headers
    assert "another_cookie" not in cl.cookie_headers
    assert "another_cookie" not in cl
    #scenario 2: key in cookie_headers
    cl["foo"] = "bar"
    cl["another_cookie"] = "another_value"
    del cl["foo"]
    assert "foo" not in cl.cookie_headers
    assert "foo" not in cl
    assert "another_cookie" in cl
    assert cl["another_cookie"].value == "another_value"

# --------------------------------

# Generated at 2022-06-21 22:48:32.562591
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    cookies["key"] = "value"

    assert headers[0][0] == "Set-Cookie"
    assert headers[0][1] == "key=value; Path=/; Version=0"

    cookies["key"] = "value"

    assert len(headers) == 1
    assert len(cookies) == 1



# Generated at 2022-06-21 22:48:34.952106
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('name', 'value')
    assert str(c) == "name=value"

# Generated at 2022-06-21 22:48:45.788174
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaders()
    jar = CookieJar(headers)
    jar['k1'] = 'v1'
    jar['k2'] = 'v1'
    jar['k3'] = 'v1'
    assert headers[b'Set-Cookie'].decode() == 'k1=v1; Path=/; k2=v1; Path=/; k3=v1; Path=/'
    jar.__delitem__('k1')
    assert headers[b'Set-Cookie'].decode() == 'k2=v1; Path=/; k3=v1; Path=/'
    jar.__delitem__('k1')
    assert headers[b'Set-Cookie'].decode() == 'k2=v1; Path=/; k3=v1; Path=/'
    jar.__del

# Generated at 2022-06-21 22:49:26.665824
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers: Dict[str, str] = {
        "set-cookie": ["cookie1=value1; path=/; max-age=42", "cookie2=value2; path=/; max-age=42"]
    }
    cookiejar = CookieJar(headers)
    assert cookiejar.cookie_headers["cookie1"] == "Set-Cookie"
    assert cookiejar.cookie_headers["cookie2"] == "Set-Cookie"
    assert headers["Set-Cookie"] == [
        "cookie1=value1; path=/; max-age=42",
        "cookie2=value2; path=/; max-age=42",
    ]
    # Test delete operation
    del cookiejar["cookie1"]
    assert not cookiejar.cookie_headers.get("cookie1")
    assert cookiejar.cookie_headers["cookie2"]

# Generated at 2022-06-21 22:49:37.365753
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_key = "CookieTest"
    cookie_value = "Cookie value"
    cookie_max_age = "0"
    cookie_path = "/cookies"
    cookie_comment = "#testing-hash"
    cookie_domain = "example.com"
    cookie_secure = "Secure"
    cookie_httponly = "HttpOnly"
    cookie_version = "1"
    cookie_samesite = "Strict"

    cookies = Cookie(cookie_key, cookie_value)
    cookies["max-age"] = cookie_max_age
    cookies["path"] = cookie_path
    cookies["comment"] = cookie_comment
    cookies["domain"] = cookie_domain
    cookies["secure"] = cookie_secure
    cookies["httponly"] = cookie_httponly
    cookies["version"] = cookie_version

# Generated at 2022-06-21 22:49:39.867994
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Given
    cookie = Cookie("some_key", "some_value")
    cookie["secure"] = True

    # When
    encoded_cookie = cookie.encode("utf-8")

    # Then
    assert encoded_cookie == b"some_key=some_value; Secure"

# Generated at 2022-06-21 22:49:41.417312
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    cookie["path"] = "/"
    assert cookie["path"] == "/", "path was wrongly formatted"



# Generated at 2022-06-21 22:49:45.086558
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cookies = CookieJar(headers)
    assert list(cookies.cookie_headers.keys()) == []
    cookies['a'] = 'a'
    cookies['b'] = 'b'
    assert list(cookies.cookie_headers.keys()) == ['a', 'b']
    assert headers['Set-Cookie'] == 'a=a; Path=/; b=b; Path=/'
    assert cookies['a'] == 'a'
    assert cookies['b'] == 'b'


# Generated at 2022-06-21 22:49:56.106973
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "test")
    # test1: None value
    assert str(cookie) == "name=test"

    # test2: max_age value
    cookie["max-age"] = 1
    assert str(cookie) == "name=test; Max-Age=1"

    # test3: expires value
    cookie["expires"] = datetime(2020, 9, 1, 0, 0, 0)
    assert str(cookie) == "name=test; Max-Age=1; Expires=Tue, 01-Sep-2020 00:00:00 GMT"

    # test4: secure
    cookie["secure"] = True
    assert str(cookie) == "name=test; Max-Age=1; Expires=Tue, 01-Sep-2020 00:00:00 GMT; Secure"

    # test5: httponly
