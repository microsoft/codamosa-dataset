

# Generated at 2022-06-21 22:40:17.938669
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("Hello", "World!")
    assert str(cookie) == "Hello=World!"
    assert cookie.encode("utf-8") == b"Hello=World!"
    assert cookie.encode("utf-16") == b"\xff\xfeH\x00e\x00l\x00l\x00o\x00=\x00W\x00o\x00r\x00l\x00d\x00!\x00"
    cookie = Cookie("\u00e9", "Hello \u00e9 World!")
    assert str(cookie) == "\u00e9=Hello \u00e9 World!"
    assert cookie.encode("utf-8") == b"\xc3\xa9=Hello \xc3\xa9 World!"
    assert cookie.encode("utf-16")

# Generated at 2022-06-21 22:40:22.177657
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_headers = MultiHeader()
    test_CookieJar = CookieJar(test_headers)
    test_CookieJar[1] = '1'
    test_CookieJar[2] = '22'
    test_CookieJar[3] = '333'
    test_CookieJar[4] = '4444'
    test_CookieJar[5] = '55555'
    test_CookieJar[6] = '666666'
    del test_CookieJar[1]
    del test_CookieJar[2]
    del test_CookieJar[3]
    del test_CookieJar[4]
    del test_CookieJar[5]
    assert len(test_headers) == 0


# Generated at 2022-06-21 22:40:29.297602
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader({"Set-Cookie":[Cookie("test-1", "1"),
                                        Cookie("test-2", "2"),
                                        Cookie("test-3", "3")]})
    cookie_jar = CookieJar(headers)
    del cookie_jar["test-1"]
    assert "test-1" not in cookie_jar
    assert cookie_jar["test-2"] == Cookie("test-2", "2")
    assert cookie_jar["test-3"] == Cookie("test-3", "3")
    assert headers["Set-Cookie"] == [Cookie("test-2", "2"), Cookie("test-3", "3")]


# Generated at 2022-06-21 22:40:36.821870
# Unit test for constructor of class CookieJar
def test_CookieJar():
    from starlette.types import Headers
    test_headers = Headers({"cookie": "test=value; name=value2; a=b; b=c"})
    jar = CookieJar(test_headers)
    assert jar["test"].value == "value"
    assert jar["name"].value == "value2"
    assert jar["a"].value == "b"
    assert jar["b"].value == "c"
    jar["test"] = "newvalue"
    assert jar["test"].value == "newvalue"
    jar["test"]["path"] = "/test"
    assert jar["test"]["path"] == "/test"
    assert jar["test"]["max-age"] == DEFAULT_MAX_AGE
    jar["test"]["max-age"] = 100

# Generated at 2022-06-21 22:40:40.609870
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    h = Headers()
    cookies = CookieJar(h)
    cookies["foo"] = 42
    assert h == {"Set-Cookie": ["foo=42; Path=/"]}



# Generated at 2022-06-21 22:40:52.020410
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_key = "cookie_key"
    cookie_value = "cookie_value"
    cookie = Cookie(cookie_key, cookie_value)
    cookie["expires"] = datetime.now()
    cookie["path"] = "/"
    cookie["comment"] = "Comment"
    cookie["domain"] = "Domain"
    cookie["max-age"] = DEFAULT_MAX_AGE
    cookie["secure"] = False
    cookie["httponly"] = False
    cookie["version"] = "Version"
    cookie["samesite"] = "SameSite"

# Generated at 2022-06-21 22:40:56.412183
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({'Set-Cookie': 'asd'})

    cookie_jar['abc'] = 'def'

    assert cookie_jar['abc'] == 'def'


# Generated at 2022-06-21 22:41:04.970696
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"
    
    cookie["version"] = "1.0"
    assert str(cookie) == "name=value; Version=1.0"
    
    cookie["max-age"] = 0
    assert str(cookie) == "name=value; Version=1.0; Max-Age=0"
    
    cookie["max-age"] = None
    assert str(cookie) == "name=value; Version=1.0"
    
    cookie["max-age"] = "123"
    assert str(cookie) == "name=value; Version=1.0; Max-Age=123"
    
    cookie = Cookie("name", "value")
    cookie["max-age"] = 123.123

# Generated at 2022-06-21 22:41:12.690153
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    """
    Unit test for Cookie.encode
    :return:
    """

    cookie = Cookie("name", "value")
    assert cookie.encode("utf-8").decode("utf-8") == "name=value"

    # Special characters should be encoded
    cookie = Cookie("äöü", "ß↑€")
    assert cookie.encode("utf-8").decode("utf-8") == "\\xe4\\xf6\\xfc=\\xdf\\u2191\\u20ac"



# Generated at 2022-06-21 22:41:22.377372
# Unit test for constructor of class CookieJar
def test_CookieJar():
    hdict = dict()
    headers = Headers(hdict)
    test_cookie = CookieJar(headers)
    test_cookie["hello"] = "world"
    assert test_cookie["hello"].value == "world"
    assert hdict[b"Set-Cookie"] == [b"hello=world; Path=/"]
    del test_cookie["hello"]
    assert hdict.get(b"Set-Cookie") is None
    assert test_cookie.get("hello") is None
    assert not test_cookie

    test_cookie["hello2"] = "world"
    assert test_cookie["hello2"].value == "world"
    assert hdict[b"Set-Cookie"] == [b"hello2=world; Path=/"]
    del test_cookie["hello2"]

# Generated at 2022-06-21 22:41:40.985467
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiDict()
    cookies = CookieJar(headers)
    assert cookies == {}
    assert headers == {}
    assert cookies.headers == {}
    assert cookies.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:41:44.510143
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('my_cookie', 'my_value')
    assert cookie.value == 'my_value'
    cookie.encode('utf-8')
    assert cookie.value == 'my_value'

# Generated at 2022-06-21 22:41:48.985876
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    print("CookieJar.__delitem__")
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    del jar["foo"]
    assert "foo" not in jar
    assert "foo" not in headers
    assert "Set-Cookie" not in headers


# Generated at 2022-06-21 22:41:56.294366
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["expires"] = "date"
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = "max-age"
    cookie["secure"] = "true"
    cookie["httponly"] = "true"
    cookie["version"] = "version"
    cookie["samesite"] = "samesite"
    assert cookie == {
        "expires": "date",
        "path": "/",
        "comment": "comment",
        "domain": "domain",
        "max-age": "max-age",
        "secure": "true",
        "httponly": "true",
        "version": "version",
        "samesite": "samesite",
    }

# Generated at 2022-06-21 22:42:01.752693
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime
    cookie = Cookie("key1", "value1")
    cookie["path"] = "/"
    cookie["comment"] = "test comment"
    cookie["domain"] = "localhost"
    cookie["max-age"] = "3600"
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    print(cookie)

# Generated at 2022-06-21 22:42:08.885504
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    import pytest
    with pytest.raises(KeyError):
        c = Cookie("key","value")
        c["expires"] = "expires"
    with pytest.raises(KeyError):
        c = Cookie("key","value")
        c["path"] = "path"
    with pytest.raises(ValueError):
        c = Cookie("key","value")
        c["max-age"] = "not an integer"
    with pytest.raises(TypeError):
        c = Cookie("key","value")
        c["expires"] = "not a datetime"
    with pytest.raises(KeyError):
        c = Cookie("key","value")
        c["not a real property"] = "not a real property"


# Generated at 2022-06-21 22:42:20.331035
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie = CookieJar(headers)

    cookie["hello"] = "world"
    assert cookie["hello"].value == "world"
    assert headers["Set-Cookie"] == ['hello=world; Path=/;']
    assert headers["set-cookie"] == ['hello=world; Path=/;']

    cookie["hello"] = "world1"
    assert cookie["hello"].value == "world1"
    assert headers["Set-Cookie"] == ['hello=world1; Path=/;']
    assert headers["set-cookie"] == ['hello=world1; Path=/;']


# Generated at 2022-06-21 22:42:29.533789
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class FakeHeaders:
        def __init__(self):
            self.headers = []

        def add(self, key, value):
            self.headers.append((key, value))

        def popall(self, key):
            for (i, (header, value)) in enumerate(self.headers):
                if header == key:
                    return self.headers.pop(i)

    h = FakeHeaders()
    c = CookieJar(h)
    c["a"] = "b"
    assert h.headers == [("Set-Cookie", "a=b; Path=/")]
    c["a"]
    assert h.headers == [("Set-Cookie", "a=b; Path=/")]
    del c["a"]
    assert h.headers == []


test_CookieJar___delitem__()

# Generated at 2022-06-21 22:42:33.455386
# Unit test for constructor of class Cookie
def test_Cookie(): 
    c = Cookie("name", "value") 
    assert (c.key == "name") 
    assert (c.value == "value")
    assert (c["key"] == "value")
    

# Generated at 2022-06-21 22:42:39.406451
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookie_jar = CookieJar({})
    # CookieJar.__init__ {

# Generated at 2022-06-21 22:42:59.844171
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    CookieJar(headers)["test"] = "test"
    assert "test" in CookieJar(headers)
    del CookieJar(headers)["test"]
    assert "test" not in CookieJar(headers)
 

# Generated at 2022-06-21 22:43:05.361833
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_jar = CookieJar({})
    cookie_jar["test"] = "text"
    len_before = len(cookie_jar)
    del cookie_jar["test"]
    len_after = len(cookie_jar)
    assert len_before > len_after
    with pytest.raises(KeyError):
        cookie_jar["test"]


# Generated at 2022-06-21 22:43:09.538506
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # Test __init__
    headers = MultiHeader()
    ck1 = CookieJar(headers)
    assert ck1.headers is headers
    assert ck1.cookie_headers is {}
    assert ck1.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:43:22.115623
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("name", "value")
    c['expires'] = datetime(2019, 4, 5)
    c['max-age'] = 43
    c['same-site'] = None
    c['secure'] = True
    assert c.encode("ascii") == b"name=value; Secure; Max-Age=43; expires=Fri, 05-Apr-2019 00:00:00 GMT; SameSite="
    assert c.encode("unicode_escape") == b"name=value; Secure; Max-Age=43; expires=Fri, 05-Apr-2019 00:00:00 GMT; SameSite="
    assert c.encode("raw_unicode_escape") == b"name=value; Secure; Max-Age=43; expires=Fri, 05-Apr-2019 00:00:00 GMT; SameSite="
   

# Generated at 2022-06-21 22:43:32.335845
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("a", "b")
    assert str(c) == "a=b"

    c = Cookie("a", "b")
    c["expires"] = datetime(
        year=2020,
        month=11,
        day=12,
        hour=13,
        minute=14,
        second=15)
    assert str(c) == "a=b; Expires=Thu, 12-Nov-2020 13:14:15 GMT"

    c = Cookie("a", "b")
    c["expires"] = datetime(
        year=2020,
        month=11,
        day=12,
        hour=13,
        minute=14,
        second=15)
    c["secure"] = True

# Generated at 2022-06-21 22:43:43.947351
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("name", "value")
    assert c == {}
    assert c.key == "name"
    assert c.value == "value"

    c = Cookie("  ", "value")
    assert c == {}
    assert c.key == "  "
    assert c.value == "value"

    with pytest.raises(KeyError):
        c = Cookie("max-age", "value")

    with pytest.raises(KeyError):
        c = Cookie("path", "value")

    with pytest.raises(KeyError):
        c = Cookie("comment", "value")

    with pytest.raises(KeyError):
        c = Cookie("domain", "value")

    with pytest.raises(KeyError):
        c = Cookie("secure", "value")


# Generated at 2022-06-21 22:43:46.258346
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    Test if the method works by accessing a cookie that doesn't exist
    and adding it to the header.
    """
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

    cookie_jar["fred"] = "my_value"
    assert headers["Set-Cookie"] == "fred=my_value; Path=/"



# Generated at 2022-06-21 22:43:57.163428
# Unit test for constructor of class Cookie

# Generated at 2022-06-21 22:44:03.301346
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    test_headers = MultiHeader({"Cookie": "foo=bar; quux=baz"})
    test_jar = CookieJar(test_headers)
    assert test_jar.headers == {"Cookie": "foo=bar; quux=baz"}
    del test_jar["quux"]
    assert test_jar.headers == {"Cookie": "foo=bar"}
    assert test_jar == {"foo": "bar"}
    del test_jar["foo"]
    assert test_jar == {}
    assert test_jar.headers == {}


# Generated at 2022-06-21 22:44:05.019539
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("test","testvalue")
    assert cookie.value == "testvalue"
    assert cookie.key == "test"


# Generated at 2022-06-21 22:44:15.594674
# Unit test for method encode of class Cookie
def test_Cookie_encode():
        cookie = Cookie("foo", "bar")
        assert isinstance(cookie.encode("utf-8"), bytes)
        assert cookie.encode("utf-8") == "foo=bar".encode("utf-8")



# Generated at 2022-06-21 22:44:22.322047
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("key", "value")
    assert cookie["key"] == "value"
    assert cookie["value"] == "value"
    assert cookie.key == "key"
    assert cookie.value == "value"
    # testing for reserved property names
    for prop in cookie._keys:
        with pytest.raises(KeyError):
            cookie[prop] = "fail"
    # testing for illegal characters
    cookie = Cookie("key", "value")
    with pytest.raises(KeyError):
        cookie["illegal_key!"] = "fail"

# Generated at 2022-06-21 22:44:32.697336
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("key", "value")
    assert c.encode("utf-8") == b"key=value"
    assert c.encode("utf-16") == b"k\x00e\x00y\x00=\x00v\x00a\x00l\x00u\x00e\x00"
    assert c.encode("ascii") == b"key=value"
    assert c.encode("latin-1") == b"key=value"

# Generated at 2022-06-21 22:44:35.481258
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name", "value")
    cookie["cookie_type"] = "chocolate"
    assert cookie == {"cookie_type": "chocolate"}



# Generated at 2022-06-21 22:44:39.580816
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    import unittest

    class Cookie___str__s_TestCase(unittest.TestCase):
        def test___str__(self):
            data = [["foo", "bar"]]
            for d in data:
                # cookie = Cookie({"foo": "bar"})
                cookie = Cookie(*d)
                result = str(cookie)
                expected = "foo=bar"
                self.assertEqual(result, expected)

    unittest.main()


# Generated at 2022-06-21 22:44:46.370754
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from starlette.responses import Response
    from starlette.testclient import TestClient

    app = TestClient(Hello)
    resp = app.get("/")
    assert len(resp.cookies) == 1

    resp = app.get("/del/name3")
    assert len(resp.cookies) == 1

    resp = app.get("/del/name2")
    assert len(resp.cookies) == 0


# Generated at 2022-06-21 22:44:50.568653
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Default setup:
    key = "name"
    value = "value"

    # Creating the cookie with given key and value
    cookie = Cookie(key, value)
    assert cookie.encode("utf-8") == str(cookie).encode("utf-8")

# Generated at 2022-06-21 22:44:52.765450
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("testKey", "testValue")
    assert c.key == "testKey"
    assert c.value == "testValue"


# Generated at 2022-06-21 22:44:59.062131
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    for key, value in (
        (":", None),
        ("foo", "bar"),
        ("foo", "Bar"),
        ("foo", "Bar: baz"),
        ("foo", "Bar;baz"),
        ("foo", "Bar,baz"),
        ("foo", "Bar baz"),
    ):
        if value is None:
            value = key
        cookie = Cookie(key, value)
        assert str(cookie) == _set_cookie(key, value)
        cookie["path"] = "/"
        assert str(cookie) == _set_cookie(key, value, "/")
        cookie["comment"] = "Comment"
        assert (
            str(cookie) == _set_cookie(key, value, "/", comment="Comment")
        )
        cookie["domain"] = "example.com"

# Generated at 2022-06-21 22:45:10.363623
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    random_day = datetime.now().strftime("%a, %d-%b-%Y %T GMT")
    type_of_encoding = "utf-8"
    sample_cookie_1 = Cookie(key="key", value="value")
    assert sample_cookie_1.encode(type_of_encoding) == b"key=value"
    sample_cookie_2 = Cookie(
        key="key", value="value", expires=datetime(2018, 2, 15, 2, 37, 9)
    )
    assert sample_cookie_2.encode(type_of_encoding) == b"key=value; Expires=Thu, 15-Feb-2018 02:37:09 GMT"
    sample_cookie_3 = Cookie(key=u"key", value=u"value")
    assert sample_cookie_3

# Generated at 2022-06-21 22:45:35.415872
# Unit test for constructor of class Cookie
def test_Cookie():
    # Correctly raises error when cookie name is a reserved word
    with pytest.raises(KeyError):
        Cookie("expires", "Jan 1, 2020")

    # Correctly raises error when cookie name has illegal characters
    with pytest.raises(KeyError):
        Cookie("key #", "value")

    # Correctly raises error when setting unknown cookie property
    with pytest.raises(KeyError):
        Cookie("key", "value")["key"] = "value"

    # Correctly raises error when cookie max-age is not an integer
    with pytest.raises(ValueError):
        Cookie("key", "value")["max-age"] = "1.01"

    # Correctly raises error when cookie expires is not a datetime

# Generated at 2022-06-21 22:45:42.935780
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():

    # Test different input types
    cookie = Cookie('key', 'value')

    try:
        cookie["max-age"] = "string"
    except ValueError:
        # pass
        print("Cookie max-age must be an integer")
    except TypeError:
        raise TypeError("Cookie 'expires' property must be a datetime")
    except KeyError:
        raise KeyError("Unknown cookie property")

    try:
        cookie["expires"] = "string"
    except ValueError:
        raise ValueError("Cookie max-age must be an integer")
    except TypeError:
        print("Cookie 'expires' property must be a datetime")
    except KeyError:
        raise KeyError("Unknown cookie property")

    try:
        cookie["key"] = "string"
    except ValueError:
        raise ValueError

# Generated at 2022-06-21 22:45:46.350296
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    key = "test_key"
    value = "test_value"
    encoding = "utf-8"
    result = Cookie(key, value).encode(encoding)
    assert result == "test_key=test_value".encode(encoding), result

# Generated at 2022-06-21 22:45:50.838329
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    new_header = CookieJar(headers)
    new_header["cookie1"] = "value1"
    new_header["cookie2"] = "value2"
    assert new_header["cookie1"].value == "value1"
    assert new_header["cookie2"].value == "value2"
    assert new_header["cookie1"].key == "cookie1"
    assert new_header["cookie2"].key == "cookie2"
# ------------------------------------------------------------ #
#  MultiHeader
# ------------------------------------------------------------ #




# Generated at 2022-06-21 22:45:57.243375
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test that __str__ returns a string in the format of a
    'Set-Cookie' header field as per RFC 6265

    >>> from starlette.responses import Cookie
    >>> cookie = Cookie('name', 'value')
    >>> str(cookie)
    'name=value'
    """
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'



# Generated at 2022-06-21 22:46:03.926647
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("username", "rwev")
    cookie["max-age"] = "123"
    assert cookie["max-age"] == 123
    with pytest.raises(ValueError):
        cookie["max-age"] = "hello"
    with pytest.raises(KeyError):
        cookie["max-age2"] = "hello"
    with pytest.raises(KeyError):
        cookie["max_age"] = "hello"
    with pytest.raises(KeyError):
        cookie["max-agee"] = "hello"

# Generated at 2022-06-21 22:46:10.491364
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("name", "value")
    assert str(c) == "name=value"
    c["expires"] = datetime(2020, 1, 1)
    assert str(c) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    c["max-age"] = 123
    assert str(c) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=123"
    c["max-age"] = "123"
    assert str(c) == "name=value; Expires=Wed, 01-Jan-2020 00:00:00 GMT; Max-Age=123"
    c["path"] = "/"

# Generated at 2022-06-21 22:46:12.581683
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    assert isinstance(cookie_jar, dict)
    assert isinstance(headers, Headers)
    assert cookie_jar.headers == headers
    assert cookie_jar.cookie_headers == {}
    assert cookie_jar.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:46:15.827979
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    cookie_jar['hello'] = 'world'

    assert headers['Set-Cookie'] == 'hello="world"'


# Generated at 2022-06-21 22:46:18.370944
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookiejar = CookieJar({})
    assert isinstance(cookiejar, dict)
    assert isinstance(cookiejar, CookieJar)

# Generated at 2022-06-21 22:46:52.081644
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "b"
    assert cookie_jar == {"a": "b"}
    assert headers == {"Set-Cookie": ["a=b; Path=/"]}
    cookie_jar["c"] = "d"
    assert cookie_jar == {"a": "b", "c": "d"}
    assert headers == {
        "Set-Cookie": ["a=b; Path=/", "c=d; Path=/"]
    }



# Generated at 2022-06-21 22:46:58.244557
# Unit test for constructor of class Cookie
def test_Cookie():
    myCookie = Cookie("name", "David")
    myCookie["path"] = "/"
    myCookie["expires"] = "date"
    myCookie["comment"] = "This is my cookie"
    myCookie["domain"] = "localhost"
    myCookie["max-age"] = "0"
    myCookie["version"] = "1" 
    myCookie["secure"] = "1"
    myCookie["httponly"] = "1"
    myCookie["samesite"] = "1"


# Generated at 2022-06-21 22:47:06.905571
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from uvicorn.headers import Headers
    h = Headers(
        {
            "Set-Cookie": (
                "session_id=15c6d48f-bd8b-4cac-ac88-de5a5bd5b5dc; Path=/;"
            ),
            "X-Forwarded-Host": "localhost",
        }
    )
    cj = CookieJar(h)
    cj["a"] = "b"
    assert cj["a"] == "b"
    del cj["a"]



# Generated at 2022-06-21 22:47:16.212589
# Unit test for constructor of class Cookie
def test_Cookie():
    """Test that the Cookie constructor works as expected."""
    # Test cookie constructor with `key` and `value` as strings.
    cookie = Cookie("key", "value")
    assert isinstance(cookie, dict)
    assert cookie.key == "key"
    assert cookie.value == "value"

    # Test cookie constructor with `key` as string and `value` as int.
    cookie = Cookie("key", 5)
    assert isinstance(cookie, dict)
    assert cookie.key == "key"
    assert cookie.value == "5"

    # Test cookie constructor with `key` as string and `value` as float.
    cookie = Cookie("key", 5.0)
    assert isinstance(cookie, dict)
    assert cookie.key == "key"
    assert cookie.value == "5.0"

    # Test cookie constructor with

# Generated at 2022-06-21 22:47:22.317053
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test with simple cookie
    cookie = Cookie("testcookie", "testvalue")
    assert str(cookie) == "testcookie=testvalue"
    # Test with httponly flag
    cookie["httponly"] = True
    assert str(cookie) == "testcookie=testvalue; HttpOnly"
    # Test with max-age
    cookie["max-age"] = 55
    assert str(cookie) == "testcookie=testvalue; HttpOnly; Max-Age=55"
    # Test with path
    cookie["path"] = "/test"
    assert str(cookie) == "testcookie=testvalue; HttpOnly; Max-Age=55; Path=/test"
    # Test with custom property
    cookie["customkey"] = "customvalue"
    with pytest.raises(KeyError):
        str(cookie)

# Unit

# Generated at 2022-06-21 22:47:28.049427
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    c = CookieJar(headers)
    assert not c.headers.get("Set-Cookie")
    c['foo'] = 'bar'
    assert c.headers.get("Set-Cookie") == 'foo=bar; Path=/'

    c['foo'] = 'bar2'
    assert c.headers.get("Set-Cookie") == 'foo=bar2; Path=/'


# Generated at 2022-06-21 22:47:29.832046
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("name", "value")
    assert cookie.encode("utf-8") == str(cookie).encode("utf-8")

# Generated at 2022-06-21 22:47:36.446307
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("name", "value")
    try:
        cookie = Cookie("expires", "value")
        assert False
    except KeyError:
        assert True
    try:
        cookie = Cookie("samesite", "value")
        assert False
    except KeyError:
        assert True
    try:
        cookie = Cookie("illegal%ckey", "value")
        assert False
    except KeyError:
        assert True



# Generated at 2022-06-21 22:47:38.672619
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('test', '1')
    assert cookie['key'] == 'test'
    assert cookie['value'] == '1'



# Generated at 2022-06-21 22:47:45.975060
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    assert cookie.encode("utf-8") == b"key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["comment"] = "This cookie was created by me"
    assert str(cookie) == "key=value; Path=/; Comment=This cookie was created by me"
    cookie["domain"] = "test.com"
    assert str(cookie) == "key=value; Path=/; Comment=This cookie was created by me; Domain=test.com"
    cookie["max-age"] = 10
    assert str(cookie) == "key=value; Path=/; Comment=This cookie was created by me; Domain=test.com; Max-Age=10"
   

# Generated at 2022-06-21 22:48:38.325994
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    from starlette.testclient import TestClient

    app = Starlette(debug=True)

    @app.route("/")
    async def homepage(request):
        response = Response("Hello World")
        cookie = Cookie(key="cookie_key", value="cookie_value")
        response.set_cookie(cookie, encoding="utf-8")
        return response

    client = TestClient(app)
    response = client.get("/")
    raw_headers = response.headers["Set-Cookie"]
    raw_cookie = raw_headers.split(":")[1].strip()
    cookie = Cookie(key="cookie_key", value="cookie_value")
    cookie.encode(encoding="utf-8")
    assert str(cookie) == raw_cookie

# Generated at 2022-06-21 22:48:41.422541
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('foo', 'bar')

    if cookie['key'] != 'foo':
        raise Exception('Cookie key not set')

    if cookie['value'] != 'bar':
        raise Exception('Cookie value not set')

# Generated at 2022-06-21 22:48:49.304702
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    ck = Cookie("name", "value")
    ck["max-age"] = 36
    assert ck["max-age"] == 36
    ck["expires"] = datetime.fromtimestamp(2 ** 32)
    assert ck["expires"] == datetime.fromtimestamp(2 ** 32)
    ck["path"] = "/"
    assert ck["path"] == "/"
    ck["comment"] = "comment"
    assert ck["comment"] == "comment"
    ck["domain"] = "domain"
    assert ck["domain"] == "domain"
    ck["secure"] = True
    assert ck["secure"] == True
    ck["httponly"] = True
    assert ck["httponly"] == True

# Generated at 2022-06-21 22:48:53.297515
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiDict({"key": "value"})
    cook = CookieJar(headers)
    try:
        del cook["key"]
    except KeyError:
        pass


# Generated at 2022-06-21 22:49:03.166721
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c1 = Cookie("test1", "test2")
    assert str(c1) == "test1=test2"
    c2 = Cookie("test1", "test2")
    c2["domain"] = "google.com"
    assert str(c2) == "test1=test2; Domain=google.com"
    c3 = Cookie("test1", "test2")
    c3["domain"] = "google.com"
    c3["max-age"] = 500
    assert str(c3) == "test1=test2; Domain=google.com; Max-Age=500"
    c4 = Cookie("test1", "test2")
    c4["domain"] = "google.com"
    c4["max-age"] = 500
    c4["samesite"] = "strict"
    c

# Generated at 2022-06-21 22:49:13.113722
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["path"] = "/"
    cookie["max-age"] = 3600
    cookie["version"] = "1"
    cookie["samesite"] = "Strict"
    assert str(cookie) == "name=value; path=/; max-age=3600; version=1; SameSite=Strict"
    cookie["secure"] = True
    assert str(cookie) == "name=value; path=/; max-age=3600; version=1; SameSite=Strict; Secure"
    cookie["secure"] = False
    assert str(cookie) == "name=value; path=/; max-age=3600; version=1; SameSite=Strict"
    cookie["httponly"] = True

# Generated at 2022-06-21 22:49:14.648400
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # test that initializing an instance of CookieJar is successful
    headers = MultiHeader()
    CookieJar(headers)

# Generated at 2022-06-21 22:49:18.980109
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    jar = CookieJar(headers)
    jar["sid"] = "123"
    assert "123" == jar["sid"].value
    del jar["sid"]
    assert jar.get("sid") is None
    assert "Set-Cookie" in headers
    assert "sid" in headers["Set-Cookie"]


# ------------------------------------------------------------ #
#  MultiHeader
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:49:25.948932
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    Test case for Cookie.__str__ method
    """
    c = Cookie("TestCookie","testValue")
    c["Version"] = 1
    c["Comment"] = "Testing Cookie"
    c["Expires"] = "Thu, 01-Jan-1970 00:00:01 GMT"
    c["Domain"] = "testDomain.com"
    c["Path"] = "/test/path"
    c["Max-Age"] = 100
    c["Secure"] = True
    c["HttpOnly"] = True

# Generated at 2022-06-21 22:49:36.538050
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader("Set-Cookie")
    # new cookie, should be added to the header keys
    cookie_jar = CookieJar(headers)
    cookie_jar['mycookie'] = "myvalue"
    # Find cookies in the headers and make sure that the encodes to the correct
    # HTTP header
    cookies = headers.getall("Set-Cookie")
    assert len(cookies) == 1
    cookie = cookies[0]
    assert "mycookie" in str(cookie)
    assert "myvalue" in str(cookie)
    # adding the same cookie, should not add a new header
    cookie_jar['mycookie'] = "myvalue"
    cookies = headers.getall("Set-Cookie")
    assert len(cookies) == 1
