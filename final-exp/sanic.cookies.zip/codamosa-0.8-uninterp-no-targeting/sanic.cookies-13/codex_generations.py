

# Generated at 2022-06-21 22:40:14.653854
# Unit test for constructor of class CookieJar
def test_CookieJar():
  headers = Headers()
  cookies = CookieJar(headers)
  assert len(cookies) == 0
  assert len(cookies.cookie_headers) == 0
  cookies["foo"] = "bar"
  assert len(cookies) == 1
  assert len(cookies.cookie_headers) == 1
  # assert headers.get("Set-Cookie") == 'foo="bar"'
  cookies["foo2"] = "bar2"
  assert len(cookies) == 2
  assert len(cookies.cookie_headers) == 2
  # assert headers.get("Set-Cookie") == 'foo="bar"; foo2="bar2"'
  del cookies["foo2"]
  assert len(cookies) == 1
  assert len(cookies.cookie_headers) == 1
  # assert headers.get("Set-Cookie") ==

# Generated at 2022-06-21 22:40:26.622836
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    jar = CookieJar(headers)
    jar["user"] = "Bugs"

    # Test normal
    assert headers["Set-Cookie"] == 'user=Bugs; Path=/'
    assert jar["user"] == 'Bugs'
    del jar["user"]
    assert headers["Set-Cookie"] == 'user=; Path=/; Max-Age=0'
    assert "user" not in jar

    # Test nonexistent
    jar["user"] = "Bugs"
    assert headers["Set-Cookie"] == 'user=Bugs; Path=/'
    assert jar["user"] == 'Bugs'
    del jar["user2"]
    assert headers["Set-Cookie"] == 'user=; Path=/; Max-Age=0'
    assert "user" not in jar

    # Test multiple headers


# Generated at 2022-06-21 22:40:37.897690
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # For these tests, we'll use the dict to store the cookies
    # so that we can more easily create test cases by hand.
    headers = {"Set-Cookie1": "key1=val1"}
    cookies = CookieJar(headers)
    # assert headers["Set-Cookie"] == "key1=val1"
    assert cookies["key1"] == "val1"
    assert len(headers) == 1

    cookies["key2"] = "val2"
    # assert headers["Set-Cookie"] == "key1=val1; key2=val2"
    assert cookies["key2"] == "val2"
    assert len(headers) == 1

    del cookies["key2"]
    # assert headers["Set-Cookie"] == "key1=val1; key2=; max-age=0"

# Generated at 2022-06-21 22:40:41.768421
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers=MultiHeader({"test":"test"})
    instance=CookieJar(headers)
    instance["test"]="a"
    if (instance.headers["Set-Cookie"] == "test=a"):
        print("set item OK")
    else:
        print("set item ERROR")
    if (instance["test"] == "a"):
        print("get item OK")
    else:
        print("get item ERROR")
    del instance["test"]
    if (instance.headers["Set-Cookie"] == "test=; Path=/; Max-Age=0"):
        print("del item OK")
    else:
        print("del item ERROR")


# Generated at 2022-06-21 22:40:47.645285
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_string = str(Cookie("SESSIONID", "value"))
    assert cookie_string == "SESSIONID=value"

    cookie_string = str(Cookie("SESSIONID", "value", {"max-age": 60}))
    assert cookie_string == "SESSIONID=value; Max-Age=60"


# ------------------------------------------------------------ #
#  Response
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:40:57.098211
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("Test Cookie.__setitem__()")
    cookie = Cookie("test_key", "test_value")
    cookie["expires"] = datetime(2000,1,1,0,0,0)
    cookie["path"] = "/"
    cookie["comment"] = "comment1"
    cookie["domain"] = "domain.com"
    cookie["max-age"] = 100
    cookie["secure"] = True
    cookie["httponly"] = False
    cookie["version"] = 1
    cookie["samesite"] = "Strict"
    print("Test different keys and True values")
    assert str(cookie) == "test_key=test_value; Max-Age=100; Domain=domain.com; Path=/; Expires=Sat, 01-Jan-2000 00:00:00 GMT; SameSite=Strict; Secure"


# Generated at 2022-06-21 22:41:03.854014
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("zidane", "good")
    cookie["path"] = "/"
    assert str(cookie) == "zidane=good; Path=/"
    cookie["max-age"] = "45"
    assert str(cookie) == "zidane=good; Path=/; Max-Age=45"
    cookie["secure"] = True
    assert str(cookie) == "zidane=good; Path=/; Max-Age=45; Secure"
    cookie["version"] = "1"
    assert str(cookie) == "zidane=good; Path=/; Max-Age=45; Secure; Version=1"

# Generated at 2022-06-21 22:41:11.921027
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    cookie["max-age"] = 123
    cookie["expires"] = datetime.utcnow()
    cookie["domain"] = "example.com"
    cookie["path"] = "/"
    cookie["samesite"] = "None"
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["comment"] = "Hello World"
    assert isinstance(str(cookie), str)


# Generated at 2022-06-21 22:41:19.586366
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    instances = [
        CookieJar(MultiHeader()),
        CookieJar(MultiHeader()),
        CookieJar(MultiHeader()),
    ]
    for cookie_jar in instances:
        this_length = len(cookie_jar)
        for i in range(this_length):
            del cookie_jar[chr(ord("a") + i)]
        assert len(cookie_jar) == 0
    assert instances[0] == instances[1] == instances[2]
    print("Passed delitem")


# Generated at 2022-06-21 22:41:22.161024
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

# Generated at 2022-06-21 22:41:27.281775
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    test_cookie = Cookie('test_cookie', 'cookie_value')
    assert not test_cookie['path']
    test_cookie['path'] = '/'
    assert test_cookie['path'] == '/'
    print('test_Cookie___setitem__: pass.')



# Generated at 2022-06-21 22:41:36.083157
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_name = 'test_cookie'
    invalid_cookie_name = 'invalid_cookie'
    cookie_value = 'value'
    cookies = CookieJar(MultiHeader())
    assert not cookies.get(cookie_name)
    cookies[cookie_name] = cookie_value
    assert cookies[cookie_name].value == cookie_value
    del cookies[cookie_name]
    assert not cookies.get(cookie_name)
    try:
        del cookies[invalid_cookie_name]
    except KeyError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 22:41:41.730422
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cj = CookieJar(headers)

    # check cj is an instance of CookieJar
    assert isinstance(cj, CookieJar)

    # check cj is an instance of dict
    assert isinstance(cj, dict)

    # check headers is passed correctly
    assert isinstance(cj.headers, Headers)


# Generated at 2022-06-21 22:41:44.737853
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cj = CookieJar({})
    cj['key'], cj['value'] = 'key', 'value'

    assert cj['key'] == 'value'



# Generated at 2022-06-21 22:41:49.925868
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    key = "testCookie"
    value = "testValue"
    cookie_jar[key] = value
    assert(key in cookie_jar.keys())
    cookie_jar.__delitem__(key)
    assert(key not in cookie_jar.keys())
    assert(key not in cookie_jar.cookie_headers.keys())


# Generated at 2022-06-21 22:41:55.968296
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    headers.add("Set-Cookie", "key=value")
    cookieJar = CookieJar(headers)
    assert headers["Set-Cookie"] == "key=value"
    assert cookieJar.get("key").value == "value"
    assert cookieJar["key"].value == "value"
    assert cookieJar["key"] == cookieJar.get("key")
    assert repr(cookieJar) == "CookieJar(key='value')"


# Generated at 2022-06-21 22:41:58.230137
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    new_cookie = Cookie(key='test', value='')
    new_cookie['test'] = 'test'
    assert new_cookie.encode('utf-8') == b'test=test'

# Generated at 2022-06-21 22:42:05.865347
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = aiohttp.multidict.MultiDict()
    cookie_jar = CookieJar(headers)
    test_key = "test_key"
    test_value = "test_value"

    cookie_jar[test_key] = test_value
    assert test_key in cookie_jar
    assert cookie_jar[test_key]["path"] == "/"
    assert cookie_jar.cookie_headers[test_key] == "Set-Cookie"
    assert cookie_jar.headers.getall("Set-Cookie")[0].key == test_key
    assert cookie_jar.headers.getall("Set-Cookie")[0].value == test_value



# Generated at 2022-06-21 22:42:08.776062
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('a', 'b')
    assert cookie.encode('utf-8') == b'a=b'

# Generated at 2022-06-21 22:42:13.993503
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)

    cookie_jar["foo"] = "bar"
    assert headers["set-cookie"] == "foo=bar"

    cookie_jar["foo"] = "bang"
    assert headers["set-cookie"] == "foo=bang"

    cookie_jar["foo"] = "baz"
    assert headers["set-cookie"] == "foo=baz"


# Generated at 2022-06-21 22:42:28.260678
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from quart.datastructures import MultiHeader
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    cookie_jar["a"] = "1"
    cookie_jar["a"] = "2"
    cookie_jar["b"] = "3"
    cookie_jar["b"] = "4"
    cookie_jar["c"] = "5"
    cookie_jar["c"] = "6"
    del cookie_jar["a"]
    del cookie_jar["b"]
    del cookie_jar["c"]
    assert len(headers) == 0
    assert len(cookie_jar) == 0


# Generated at 2022-06-21 22:42:35.844172
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('name', 'value')
    assert c.key == 'name'
    assert c.value == 'value'
    assert c['path'] == '/'
    assert not 'secure' in c
    assert not 'httponly' in c
    assert not 'samesite' in c
    assert not 'version' in c
    assert not 'comment' in c
    assert not 'domain' in c
    assert not 'expires' in c
    assert not 'max-age' in c



# Generated at 2022-06-21 22:42:48.654543
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeaderDict()
    cookies = CookieJar(headers)
    key = 'key1'
    value = 'value1'
    cookies[key] = value
    header_key_1 = 'Set-Cookie'
    expected_header_key_1 = cookies.header_key
    expected_header_value_1 = f'{key}={value}; Path=/'
    actual_header_key_1 = cookies.cookie_headers[key]
    actual_header_value_1 = tuple(cookies.headers[header_key_1])
    assert expected_header_key_1 == actual_header_key_1
    assert expected_header_value_1 == actual_header_value_1
    header_key_2 = 'Set-Cookie2'
    cookies[key] = value

# Generated at 2022-06-21 22:42:51.552363
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("key", "value")
    assert c["key"] == "value"
    assert not c["httponly"]
    assert c.value == "value"
    assert c.key == "key"

# Generated at 2022-06-21 22:42:52.854663
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("coco", value="nut")
    assert isinstance(cookie.encode("utf-8"), bytes)

# Generated at 2022-06-21 22:42:58.983722
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers({"Content-Type": "text/html"})
    cookies = CookieJar(headers)
    cookies["session_id"] = "abc123"
    assert cookies["session_id"].value == "abc123"
    cookies["session_id"] = "xyz789"
    assert cookies["session_id"].value == "xyz789"


# Generated at 2022-06-21 22:43:01.267878
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test", "is passed")
    assert cookie.encode("utf-8") == b"test=is%20passed"

# Generated at 2022-06-21 22:43:08.816566
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("test-cookie", "test value")
    assert cookie["path"] == "/"
    try:
        cookie["test-cookie"] = "override"
        assert False
    except KeyError:
        assert True == True

    try:
        cookie = Cookie("test-cookie", "test value")
        assert False
    except KeyError:
        assert True == True

    try:
        cookie = Cookie("test cookie", "test value")
        assert False
    except KeyError:
        assert True == True

    assert cookie.encode("utf-8") == b'test-cookie="test value"; Path=/'



# Generated at 2022-06-21 22:43:14.449068
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cookies = CookieJar(headers)
    cookies["test"] = "test_value"
    assert cookies["test"].value == "test_value"
    assert "Set-Cookie" in headers
    assert "test=test_value" in headers["Set-Cookie"]



# Generated at 2022-06-21 22:43:19.427520
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("foo", "bar")
    assert c["path"] == "/"
    assert c["max-age"] == DEFAULT_MAX_AGE
    assert str(c) == "foo=bar; Max-Age=0; Path=/"
    assert c.key == "foo"
    assert c.value == "bar"



# Generated at 2022-06-21 22:43:35.829610
# Unit test for constructor of class CookieJar
def test_CookieJar():
  # Test constructor
  headers = {}
  cj = CookieJar(headers)

  # Test add
  cj["hello"] = "world"
  assert headers == {"Set-Cookie": ["hello=world; Path=/; HttpOnly"]}

  # Test remove
  del cj["hello"]
  assert headers == {"Set-Cookie": ["hello=; Max-Age=0; Path=/; HttpOnly"]}

  # Test add again
  cj["hello"] = "world"
  assert headers == {"Set-Cookie": ["hello=world; Path=/; HttpOnly"]}

  # Test save to file
  with open("cookies.txt", "w") as f:
    f.write(str(cj))

  # Test load from file

# Generated at 2022-06-21 22:43:38.117789
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    assert cookie.encode("utf-8") == b"key=value"


# Generated at 2022-06-21 22:43:48.423363
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["foo"] = "bar"
    cookies["bar"] = "baz"
    cookies["baz"] = "qux"
    assert headers["Set-Cookie"] == "foo=bar; Path=/; bar=baz; Path=/; baz=qux; Path=/"
    del cookies["foo"]
    assert headers["Set-Cookie"] == "bar=baz; Path=/; baz=qux; Path=/"
    del cookies["bar"]
    assert headers["Set-Cookie"] == "baz=qux; Path=/"
    del cookies["baz"]
    assert headers["Set-Cookie"] == "baz=; Path=/; Max-Age=0"


# Generated at 2022-06-21 22:43:56.395222
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    c = CookieJar(headers)
    c["test"] = "test"
    assert c["test"].value == "test"
    assert headers.get("Set-Cookie").value == "test=test"
    del c["test"]
    assert "Set-Cookie" not in headers
    c["test"] = "test"
    c["test"]["max-age"] = 0
    assert headers.get("Set-Cookie").value == "test=test; Max-Age=0"


# Generated at 2022-06-21 22:43:59.279974
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie(key='foo', value='bar')
    cookie['path'] = '/'
    cookie['max-age'] = 0
    cookie['expires'] = datetime.now()
    assert cookie['max-age'] == 0
    assert cookie['expires'].__class__ == datetime
    assert cookie['path'] == '/'
    assert cookie['secure'] is False
    assert cookie['httponly'] is False

# Generated at 2022-06-21 22:44:08.806093
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from core.http.headers import Headers

    # Populate CookieJar
    jar = CookieJar(Headers())
    jar["hello"] = "world"
    jar["one"] = "1"
    # Delete Cookie
    del jar["hello"]
    # Check if the expired cookie is present in the headers
    assert jar.headers["Set-Cookie: hello=; Max-Age=0"] == "Set-Cookie: hello=; Max-Age=0"
    # Check if cookie is actually deleted from the headers
    assert not "hello" in jar
    # Check if other cookie is still present in the headers
    assert jar.headers["Set-Cookie: one=1"] == "Set-Cookie: one=1"
    # Check if the other cookie is present in the cookie_headers

# Generated at 2022-06-21 22:44:11.993972
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("dummy_name", "dummy_val")
    assert c.key == "dummy_name"
    assert c.value == "dummy_val"
    assert c == {}



# Generated at 2022-06-21 22:44:20.322896
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    import json
    from datetime import timedelta
    from datetime import datetime

    cookie = Cookie("foo", "é")
    cookie["expires"] = datetime.now() + timedelta(days=2)
    cookie["max-age"] = 10

    try:
        assert cookie.encode("utf-8") == b"foo=%C3%A9; Max-Age=10; expires="
        assert cookie.encode("latin-1") == b"foo=\\351; Max-Age=10; expires="
    except UnicodeEncodeError:
        cookie.encode("utf-8")
    assert isinstance(cookie.encode("utf-8"), bytes)

# Generated at 2022-06-21 22:44:25.450877
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = CIMultiDict()
    jar = CookieJar(headers)
    jar['foo'] = 'bar'
    jar['baz'] = 'qux'
    assert headers.getall("Set-Cookie")[0] == "baz=qux; Path=/"
    assert headers.getall("Set-Cookie")[1] == "foo=bar; Path=/"


# Generated at 2022-06-21 22:44:31.373876
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    str_key = "abcd"
    value = "11"
    cookie = Cookie(str_key, value)
    assert(cookie["path"] == None)
    assert(cookie["max-age"] == None)
    cookie["path"] = "/"
    cookie["max-age"] = 0
    assert(cookie["path"] == "/")
    assert(cookie["max-age"] == 0)
    try:
        cookie["max-age"] = "1234"
    except ValueError as error:
        assert(str(error) == "Cookie max-age must be an integer")
    try:
        cookie["abcd"] = "1234"
    except KeyError as error:
        assert(str(error) == "Unknown cookie property")

# Generated at 2022-06-21 22:44:40.276036
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    h = MultiDict()
    c = CookieJar(h)
    name = "cookie-name"
    value = "cookie-value"
    c[name] = value
    assert c[name].value == value
    assert h[name].value == value



# Generated at 2022-06-21 22:44:45.263750
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = multidict.MultiDict()
    jar1 = CookieJar(headers)
    assert jar1.headers == {}
    assert jar1.cookie_headers == {}
    assert jar1.header_key == "Set-Cookie"
    assert jar1 == {}
    assert headers == {}


# Generated at 2022-06-21 22:44:48.083263
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie('id', '1234')
    print(c.key)


# Generated at 2022-06-21 22:44:52.561272
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test","test")
    assert str(cookie.encode("utf-8")) == "test=test".encode("utf-8")
    cookie = Cookie("test","中国")
    assert str(cookie.encode("utf-8")) == "test=%E4%B8%AD%E5%9B%BD".encode("utf-8")

# Generated at 2022-06-21 22:44:58.955417
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    cookie['max-age'] = 100
    assert str(cookie) == "foo=bar; Max-Age=100"
    cookie['max-age'] = '100'
    assert str(cookie) == "foo=bar; Max-Age=100"
    cookie['max-age'] = '100.0'
    assert str(cookie) == "foo=bar; Max-Age=100.0"
    cookie['max-age'] = 'hello'
    assert str(cookie) == "foo=bar; Max-Age=hello"
    cookie['max-age'] = False
    assert str(cookie) == "foo=bar"

    cookie = Cookie("foo", "bar")
    assert str(cookie) == "foo=bar"
    cookie['httponly'] = True
    assert str(cookie)

# Generated at 2022-06-21 22:45:02.649954
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cj = CookieJar(headers={})
    assert cj.headers == {}
    assert cj.cookie_headers == {}
    assert cj.header_key == 'Set-Cookie'


# Generated at 2022-06-21 22:45:04.597269
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    abc = Cookie(key="abc", value="123")
    assert str(abc) == "abc=123"



# Generated at 2022-06-21 22:45:07.021713
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    expected = "name=value; samesite=Strict; Max-Age=180"
    cookie = Cookie("name", "value")
    cookie["max-age"] = 180
    cookie["samesite"] = "Strict"
    assert str(cookie) == expected



# Generated at 2022-06-21 22:45:12.039996
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeaderDict()
    cookiejar = CookieJar(headers)
    cookiejar.__setitem__('test', 'yay')
    assert len(headers) != 0
    assert 'test' in cookiejar
    cookiejar.__delitem__('test')
    assert len(headers) == 0
    assert 'test' not in cookiejar


# Generated at 2022-06-21 22:45:19.537938
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    assert str(Cookie("key", "value")) == "key=value"
    assert str(Cookie(None, None)) == "None=None"
    assert str(Cookie("key", None)) == "key=None"
    assert str(Cookie(None, "value")) == "None=value"
    assert str(Cookie("Key", "Value")) == "Key=Value"
    assert str(Cookie("K0ey", "v@lue")) == "K0ey=v@lue"

    cookies = {"max-age": 0, "httponly": True, "secure": True}
    cookie = Cookie("key", "value")
    for k, v in cookies.items():
        cookie[k] = v

    assert str(cookie) == "key=value; HttpOnly; Secure; Max-Age=0"



# Generated at 2022-06-21 22:45:33.261381
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie("key","value")
    c["name"] = "value"
    assert c["name"] == "value"
    try:
        c["key"] = "value"
        assert False
    except KeyError:
        assert True
    try:
        c["Key"] = "value"
        assert False
    except KeyError: 
        assert True


# Generated at 2022-06-21 22:45:34.935554
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookie_jar = CookieJar([])
    assert cookie_jar != None
    return


# Generated at 2022-06-21 22:45:42.666533
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("1", "2")
    assert str(cookie) == "1=2"
    cookie["max-age"] = 10
    assert str(cookie) == "1=2; Max-Age=10"
    cookie["expires"] = datetime(2020, 1, 1, 0, 0, 0)
    assert str(cookie) == "1=2; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT"
    cookie["httponly"] = True
    assert str(cookie) == "1=2; Max-Age=10; Expires=Wed, 01-Jan-2020 00:00:00 GMT; HttpOnly"
    cookie["secure"] = True

# Generated at 2022-06-21 22:45:47.404564
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("a", "b")
    assert(str(c) == "a=b")
    c["path"] = "/"
    assert(str(c) == "a=b; Path=/")
    c["max-age"] = 60
    assert(str(c) == "a=b; Path=/; Max-Age=60")
    c["expires"] = datetime.now()
    assert(str(c) == "a=b; Path=/; Max-Age=60; Expires=Mon, 26-Aug-2019 07:34:42 GMT")

test_Cookie___str__()


# Generated at 2022-06-21 22:45:53.400241
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.testclient import TestClient
    from starlette.endpoints import HTTPEndpoint, WebSocketEndpoint
    from starlette.applications import Starlette
    from starlette.responses import JSONResponse

    class SetCookieEndpoint(HTTPEndpoint):
        async def get(self, request):
            request.cookies["User"] = "John Doe"
            request.cookies["Age"] = "20"
            return JSONResponse({"OK": True})

    class ReadCookieEndpoint(HTTPEndpoint):
        async def get(self, request):
            return JSONResponse({"User": request.cookies["User"], "Age": request.cookies["Age"]})

    app = Starlette()
    app.mount("/set", SetCookieEndpoint)
    app.mount("/read", ReadCookieEndpoint)



# Generated at 2022-06-21 22:45:55.058128
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    assert 0



# Generated at 2022-06-21 22:46:04.654546
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("foo", "bar")
    assert c.__str__() == "foo=bar"
    # check for max-age as int
    c["max-age"] = 1
    assert c.__str__() == "foo=bar; Max-Age=1"
    # check for max-age as str
    c["max-age"] = "1"
    assert c.__str__() == "foo=bar; Max-Age=1"
    # check for expires
    c["expires"] = datetime.now()
    assert str(c).startswith("foo=bar; Max-Age=1; Expires=")
    # check for flags
    c["secure"] = True
    assert c.__str__() == "foo=bar; Max-Age=1; Expires=; Secure"

# Generated at 2022-06-21 22:46:14.455198
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('a', 'b')
    assert cookie.encode("utf-8") == b'a=b'
    assert cookie.encode("iso-8859-1") == b'a=b'
    cookie['expires'] = datetime.fromtimestamp(int("1121710000"))
    assert cookie.encode("utf-8") == b'a=b; Expires=Thu, 01-Jan-2004 22:50:00 GMT'
    assert cookie.encode("iso-8859-1") == b'a=b; Expires=Thu, 01-Jan-2004 22:50:00 GMT'



# Generated at 2022-06-21 22:46:17.416423
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar['key'] = 'value'
    assert(headers.get('Set-Cookie') == 'key=value; Path=/')

# Generated at 2022-06-21 22:46:27.602237
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("name", "value")
    assert c["path"] == "/"
    assert c["max-age"] == DEFAULT_MAX_AGE
    assert isinstance(c["expires"], datetime)
    assert not c["secure"]
    assert not c["httponly"]
    assert c["version"] == 1
    c["expires"] = datetime(2020, 1, 1, 0, 0)
    assert c["expires"] == datetime(2020, 1, 1, 0, 0)
    c["max-age"] = 100
    assert c["max-age"] == 100
    c["secure"] = True
    assert c["secure"]
    c["httponly"] = True
    assert c["httponly"]
    c["version"] = 2
    assert c["version"] == 2
    assert "max-age" in c

# Generated at 2022-06-21 22:46:41.788673
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test scenarios
    # Test 1: Test a cookie without any property
    cookie = Cookie('user', 'john')
    assert str(cookie) == "user=john"

    # Test 2: Test a cookie with all the properties being set
    cookie = Cookie('user', 'john')
    cookie['path'] = '/'
    cookie['comment'] = 'a comment'
    cookie['domain'] = 'localhost'
    cookie['max-age'] = 123
    cookie['secure'] = True
    cookie['httponly'] = True
    cookie['version'] = '1'
    cookie['samesite'] = 'Strict'
    
    assert str(cookie) == "user=john; Path=\\/; Comment=a comment; Domain=localhost; Max-Age=123; Secure; HttpOnly; Version=1; SameSite=Strict"



# Generated at 2022-06-21 22:46:42.817816
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass


# Generated at 2022-06-21 22:46:50.407755
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    import httptools

    headers = httptools.Headers()
    cookie_jar = CookieJar(headers)

    cookie_jar[b"test"] = "testing"
    assert len(headers["Set-Cookie"]) == 1

    del cookie_jar[b"test"]
    assert len(headers["Set-Cookie"]) == 0

    cookie_jar[b"test"] = "testing"
    assert len(headers["Set-Cookie"]) == 1

    cookie_jar[b"test"] = "another test"
    assert len(headers["Set-Cookie"]) == 1

# Generated at 2022-06-21 22:46:52.486458
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "testkey"
    value = "testval"
    cookie = Cookie(key, value)
    assert cookie.key == key
    assert cookie.value == value


# Generated at 2022-06-21 22:46:56.770458
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = headers = MultiHeaderDict()
    jar = CookieJar(headers)
    assert isinstance(jar, dict)
    assert isinstance(jar, CookieJar)
    assert isinstance(jar.headers, dict)
    assert isinstance(jar.headers, MultiHeaderDict)
    assert jar.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:47:01.296813
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie_dict = {"expires": "Tue, 19 Jan 2021 17:28:15 GMT"}
    cookie = Cookie("key", "value")
    cookie.update(cookie_dict)
    assert str(cookie) == "key=value; Path=; Expires=Tue, 19 Jan 2021 17:28:15 GMT"



# Generated at 2022-06-21 22:47:05.589568
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("chocolate_chip", "is_favorite")
    assert _quote(cookie["chocolate_chip"]) == cookie.value
    assert cookie["chocolate_chip"] == "is_favorite"


# Generated at 2022-06-21 22:47:15.045659
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("hello", "world")
    assert str(cookie) == "hello=world"

    cookie["domain"] = "www.example.com"
    cookie["path"] = "/"
    cookie["expires"] = datetime(2017, 1, 1)
    assert str(cookie) == "hello=world; Domain=www.example.com; Path=/; Expires=Sun, 01-Jan-2017 00:00:00 GMT"

    cookie["samesite"] = "strict"
    cookie["secure"] = True
    cookie["httponly"] = True
    assert str(
        cookie
    ) == "hello=world; Domain=www.example.com; Path=/; Expires=Sun, 01-Jan-2017 00:00:00 GMT; SameSite=Strict; Secure; HttpOnly"



# Generated at 2022-06-21 22:47:27.366190
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {"Set-Cookie": "Cookie1=hello; expires=10;",
               "Set-Cookie2": "Cookie2=blah; expires=10;",
               "Set-Cookie3": "Cookie3=cookie; expires=10;"}

    cookie_jar = CookieJar(headers)
    assert cookie_jar == {}
    assert cookie_jar.headers == headers
    assert cookie_jar.cookie_headers == {}
    assert "Cookie1" not in cookie_jar
    assert "Cookie2" not in cookie_jar

    cookie_jar["Cookie1"] = "hello"
    assert cookie_jar == {"Cookie1": "hello"}
    assert cookie_jar.headers == headers
    assert cookie_jar.cookie_headers == {"Cookie1": "Set-Cookie"}

# Generated at 2022-06-21 22:47:28.621806
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("mycookie", "value")
    assert c["path"] == "/"



# Generated at 2022-06-21 22:47:43.262106
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("name", b"\xCE\xBD\xCE\xB5\xCF\x84")
    cookie.encode("utf-8") == "name=\xce\xbd\xce\xb5\xcf\x84"

# Generated at 2022-06-21 22:47:47.560532
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    actual = Cookie("mycookie", "myvalue").encode("utf-8")
    expected = b"mycookie=myvalue"
    assert actual == expected, "Cookie.encode() expected %s, got %s" % (
        expected, actual
    )


# Generated at 2022-06-21 22:47:51.361004
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("key", "value")
    assert cookie.key == "key"
    assert cookie.value == "value"
    assert cookie.items() == []
    assert str(cookie) == "key=value"
    return cookie


# Generated at 2022-06-21 22:48:00.594467
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    c = Cookie('a', 'b')
    with pytest.raises(KeyError):
        c['extension'] = 'data'

    with pytest.raises(KeyError):
        c['version'] = '1.0'
    assert 'version' not in c

    with pytest.raises(ValueError):
        c['max-age'] = 'a'
    assert 'max-age' not in c

    assert c['max-age'] is None
    c['max-age'] = 0
    assert c['max-age'] == 0

    with pytest.raises(TypeError):
        c['expires'] = 'some date'

    assert c['expires'] is None
    c['expires'] = datetime.now()
    assert isinstance(c['expires'], datetime) is True

# Generated at 2022-06-21 22:48:04.051355
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    jar["test"] = "test"
    del jar["foo"]
    assert not headers.getall("Set-Cookie")
    assert not jar.cookie_headers
    assert len(jar) == 0


# Generated at 2022-06-21 22:48:15.128427
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    def encode_test_data():
        for encoding in ("utf-8", "utf8", "UTF-8", "UTF8"):
            yield (encoding,)

    @pytest.mark.parametrize("encoding", encode_test_data())
    def test_encode(encoding):
        cookie = Cookie("test_cookie", "Hällo, Wörld!")
        expected_output = "test_cookie=Hällo%2C%20Wörld!".encode(encoding)
        actual_output = cookie.encode(encoding)
        assert actual_output == expected_output, "encode(utf-8) is not working"

    test_encode()


if __name__ == "__main__":
    pass

# Generated at 2022-06-21 22:48:18.143221
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("Cookie1", "value1")
    assert c.key == "Cookie1"
    assert c.value == "value1"
    assert c.get("path") == "/"



# Generated at 2022-06-21 22:48:27.137826
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = StarletteMultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["test_cookie"] = "test_value"

    expected = {
        "test_cookie": {
            "value": "test_value",
            "path": "/",
        }
    }
    assert cookie_jar == expected

    del cookie_jar["test_cookie"]

    assert cookie_jar == {}
    assert headers["Set-Cookie"] == "test_cookie=; Path=/; Max-Age=0; HttpOnly; Secure"


# ------------------------------------------------------------ #
#  Tests
# ------------------------------------------------------------ #


# Generated at 2022-06-21 22:48:37.576873
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from hypercorn.header import Headers
    headers_dict = {}
    headers = Headers(headers_dict)
    cookiejar = CookieJar(headers)

    # delitem non-existing cookie
    cookiejar.__delitem__("fake")
    assert headers_dict.get("Set-Cookie") is None

    # delitem existing cookie
    cookiejar["name"] = "value"
    cookiejar.__delitem__("name")
    assert headers_dict.get("Set-Cookie") is None

    # delitem existing cookie, has other cookie
    cookiejar["name"] = "value"
    cookiejar["name2"] = "value2"
    cookiejar.__delitem__("name")
    assert headers_dict.get("Set-Cookie") == "name2=value2; Path=/; Max-Age=0"



# Generated at 2022-06-21 22:48:47.790530
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar['chocolate'] = 'chip'
    cookie_jar['sugar'] = 'cookie'
    cookie_jar['oatmeal'] = 'raisin'
    del cookie_jar["sugar"]
    assert cookie_jar == {'chocolate': Cookie(key='chocolate', value='chip'),
                                  'oatmeal': Cookie(key='oatmeal', value='raisin')}
    assert headers == {'Set-Cookie':
                            ['chocolate=chip; Path=/; Max-Age=0',
                             'oatmeal=raisin; Path=/; Max-Age=0']}
    cookie_jar['sugar'] = 'cookie'
    cookie_jar['oatmeal'] = 'raisin'
    del cookie_jar["sugar"]
   

# Generated at 2022-06-21 22:49:17.853676
# Unit test for constructor of class Cookie
def test_Cookie():
    assert Cookie("test", "This is a value")



# Generated at 2022-06-21 22:49:26.310243
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # case 1
    headers = CIMultiDict([])
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "value"
    assert cookie_jar["name"] == "value"
    assert cookie_jar.headers["Set-Cookie"] == "name=value; Path=/; Version=1"

    # case 2
    headers = CIMultiDict([])
    cookie_jar = CookieJar(headers)
    cookie_jar["name"] = "value"
    cookie_jar["name"] = "new_value"
    assert cookie_jar["name"] == "new_value"
    assert cookie_jar.headers["Set-Cookie"] == "name=new_value; Path=/; Version=1"



# Generated at 2022-06-21 22:49:34.063018
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("chocolate chip", "Yum")
    assert cookie["value"] == "Yum"
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    assert "secure" not in cookie
    cookie["secure"] = True
    assert cookie["secure"] is True
    assert "secure" not in cookie
    cookie["secure"] = False
    assert cookie["secure"] is False
    del cookie["secure"]
    assert "secure" not in cookie



# Generated at 2022-06-21 22:49:38.987029
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    from base64 import urlsafe_b64encode
    b64_user_id_key_value = urlsafe_b64encode(b"<user_id>").decode("ascii")

    # Create a cookie to save user id
    cookie_user_id = Cookie("user_id", b64_user_id_key_value)

    # Pass it to the client
    output = cookie_user_id.encode("utf-8")


# Generated at 2022-06-21 22:49:41.120522
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cj = CookieJar()
    cj.set('name', 'value')
    cj.set('expires', datetime.utcnow())

    assert(cj['name'] == 'value')


# Generated at 2022-06-21 22:49:43.708365
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie('name', 'value')
    c['max-age'] = 120
    c['path'] = '/'
    c['domain'] = 'localhost'
    c['secure'] = True
    c['httponly'] = True
    print(c.encode('utf-8'))


# Generated at 2022-06-21 22:49:48.240568
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('test-key', 'test-value')
    cookie['max-age'] = 123
    assert cookie['max-age'] == 123
    assert cookie['max-age'] != False
    assert cookie['max-age'] != True


test_Cookie()


# ------------------------------------------------------------ #
#  Cookies
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:49:52.108589
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    """
    This method tests if the :meth:`~Cookie.encode` method works
    and does not raise any exceptions.
    """
    cookie = Cookie("name", "lanka")
    cookie.encode("utf-8")


# Generated at 2022-06-21 22:50:01.432999
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "cookie")
    cookie["path"] = "/"
    cookie["path"] = "/test"
    cookie["expires"] = datetime.now()
    cookie["domain"] = "localhost"
    cookie["max-age"] = 0
    cookie["httponly"] = True
    cookie["httponly"] = False
    cookie["secure"] = True
    cookie["secure"] = False
    cookie["version"] = 1
    cookie["comment"] = "hello"
    cookie["samesite"] = "lax"
    assert True
    try:
        cookie["other"] = "other"
    except KeyError:
        assert True
    else:
        assert False
    try:
        cookie["test"] = "test"
    except KeyError:
        assert True
    else:
        assert False