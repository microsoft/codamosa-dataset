

# Generated at 2022-06-21 22:40:08.495273
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("key", "value")
    assert c.key == "key"
    assert c.value == "value"



# Generated at 2022-06-21 22:40:11.799471
# Unit test for constructor of class Cookie
def test_Cookie():
    ck = Cookie("name", "value")
    assert ck.key == "name"
    assert ck.value == "value"
    assert ck.items() == []


# Generated at 2022-06-21 22:40:19.253456
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    assert len(cookies) == 0
    assert len(headers.headermap.keys()) == 1
    assert list(headers.headermap.keys())[0] == "Set-Cookie"
    assert len(headers.headermap["Set-Cookie"]) == 0


# Generated at 2022-06-21 22:40:21.926611
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    c = CookieJar()
    c["a"] = "b"
    assert c["a"] == "b"

# Generated at 2022-06-21 22:40:25.049099
# Unit test for constructor of class CookieJar
def test_CookieJar():
    assert CookieJar.__init__

# Generated at 2022-06-21 22:40:25.722668
# Unit test for constructor of class CookieJar
def test_CookieJar():
    pass

# Generated at 2022-06-21 22:40:37.004090
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    '''
    Test for Cookie.__str__
    '''
    # Test for class Cookie
    cookie = Cookie('name', 'value')
    cookie['version'] = 2
    assert str(cookie) == 'name=value; Version=2'

    cookie = Cookie('name', 'value')
    cookie['secure'] = True
    assert str(cookie) == 'name=value; Secure'

    cookie = Cookie('name', '"value"')
    cookie['domain'] = 'example.com'
    cookie['path'] = '/'
    cookie['max-age'] = 3600
    assert str(cookie) == 'name="\\"value\\""' + \
                          '; Domain=example.com' + \
                          '; Max-Age=3600' + \
                          '; Path=/'


# Generated at 2022-06-21 22:40:41.742607
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    ck = Cookie("test", "test")
    ck["path"] = "/"
    assert ck["path"] == "/"
    ck["expires"] = "test"
    assert ck["expires"] == "test"
    ck["secure"] = True
    assert ck["secure"] == True


# Generated at 2022-06-21 22:40:53.282243
# Unit test for constructor of class Cookie
def test_Cookie():
    expected_result = "key=value; Path=value2; Comment=value3; Domain=value4; Max-Age=5; Secure; HttpOnly; Version=value8; SameSite=value9"
    values = {
        "key": "value",
        "Path": "value2",
        "Comment": "value3",
        "Domain": "value4",
        "Max-Age": "5",
        "Secure": True,
        "HttpOnly": True,
        "Version": "value8",
        "SameSite": "value9",
    }

    cookie = Cookie(values["key"], values["key"])
    for k, v in values.items():
        cookie[k] = v
    assert str(cookie) == expected_result
    print("test_Cookie passed")

# ------------------------------------------------------------ #
#

# Generated at 2022-06-21 22:41:03.633566
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # test case 1
    cookie = Cookie("foo", "bar")
    assert cookie.value == "bar"
    assert cookie.key == "foo"
    assert cookie.as_output() == 'foo=bar'

    # test case 2
    cookie = Cookie("foo", "bar")
    cookie["max-age"] = 200
    assert cookie.value == "bar"
    assert cookie.key == "foo"
    assert cookie.as_output() == 'foo=bar; Max-Age=200'

    # test case 3
    cookie = Cookie("foo", "bar")
    cookie["expires"] = datetime.utcnow()
    assert cookie.value == "bar"
    assert cookie.key == "foo"
    assert 'foo=bar' in cookie.as_output()
    assert 'GMT' in cookie.as_output()

# Generated at 2022-06-21 22:41:11.501207
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = http_cookies.SimpleCookie()
    headers.add("Set-Cookie", "biscuit=chocolate")
    jar = CookieJar(headers)
    assert jar["biscuit"] == "chocolate"


# Generated at 2022-06-21 22:41:21.851580
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from http import cookies
    cookie = cookies.SimpleCookie("name=value")
    cookie["expires"] = "Mon, 01-Jan-1990 00:00:00 GMT"
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"
    cookie["max-age"] = 0
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["version"] = 1
    cookie["samesite"] = "Lax"

    # Create a copy with our cookie class
    cookie = Cookie("name", "value")
    cookie["expires"] = datetime(1990, 1, 1, 0, 0, 0)
    cookie["path"] = "/"
    cookie["comment"] = "comment"
    cookie["domain"] = "domain"

# Generated at 2022-06-21 22:41:32.671553
# Unit test for constructor of class Cookie
def test_Cookie():
    try:
        cookie = Cookie("foo bar", "spam")
        print("FAILED: able to set a cookie with illegal characters")
    except KeyError as e:
        pass

    try:
        cookie = Cookie("expires", "spam")
        print("FAILED: able to set a reserved cookie key")
    except KeyError as e:
        pass

    try:
        cookie = Cookie("spam", "spam")
        cookie["expires"] = False
        print("FAILED: able to set false value for cookie")
    except KeyError as e:
        pass


# Generated at 2022-06-21 22:41:40.812070
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    headers.add("Content-Type", "application/json")
    headers.add("Set-Cookie", "name=shahriar")

    cookie_jar = CookieJar(headers)
    del cookie_jar["name"]

    assert len(headers.getall("Set-Cookie")) == 1
    assert ("name=shahriar; Max-Age=0" in headers.getall("Set-Cookie"))


# Generated at 2022-06-21 22:41:43.433461
# Unit test for constructor of class CookieJar
def test_CookieJar():
  headers = MultiHeader("hello")
  cookie_jar = CookieJar({"headers": headers})
  return cookie_jar


# Generated at 2022-06-21 22:41:46.304019
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("z", "d")
    assert c["path"] is "/"
    assert str(c) == "z=d; Path=/"


# Generated at 2022-06-21 22:41:54.990696
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers({"Set-Cookie": [
            Cookie("MyCookie", "TheValue"),
            Cookie("MyOtherCookie", "TheOtherValue")
        ]})
    cookiejar = CookieJar(headers)
    assert len(headers.getall("Set-Cookie")) == 2
    del cookiejar['MyCookie']
    assert len(headers.getall("Set-Cookie")) == 1
    assert headers.get("Set-Cookie") == Cookie("MyOtherCookie", "TheOtherValue")
    assert headers.get("Set-Cookie").key == "MyOtherCookie"
    assert headers.get("Set-Cookie").value == "TheOtherValue"


# Generated at 2022-06-21 22:41:56.888088
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("test", "value")
    cookie["max-age"] = 600
    assert cookie["max-age"] == 600


# Generated at 2022-06-21 22:41:59.456592
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = CaseInsensitiveDict()    
    cookies = CookieJar(headers)
    cookies['test'] = 'test'
    assert cookies['test'].value == 'test'
    assert cookies['test']['path'] == '/'


# Generated at 2022-06-21 22:42:08.011836
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    from datetime import datetime

    cookie_value = "value"
    cookie_key = "my_cookie"

    cookie = Cookie(cookie_key, cookie_value)
    assert str(cookie) == "my_cookie=value"

    cookie_value = "value"
    cookie_key = "my_cookie"

    cookie = Cookie(cookie_key, cookie_value)
    cookie["path"] = "/"
    assert str(cookie) == "my_cookie=value; Path=/; Max-Age=0"

    cookie_value = "value"
    cookie_key = "my_cookie"

    cookie = Cookie(cookie_key, cookie_value)
    cookie["path"] = "/"
    cookie["max-age"] = "10"

# Generated at 2022-06-21 22:42:28.658060
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["path"] = "/"
    assert str(cookie) == "key=value; Path=/"
    cookie["expires"] = datetime.now()
    assert str(cookie).startswith("key=value; Path=/; Expires=")
    cookie["secure"] = True
    assert str(cookie).startswith("key=value; Path=/; Expires=") and "Secure" in str(cookie)
    cookie["httponly"] = True
    assert str(cookie).startswith("key=value; Path=/; Expires=") and "HttpOnly" in str(cookie)
    cookie["max-age"] = 600

# Generated at 2022-06-21 22:42:37.012047
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "mycookie"
    value = "myvalue"
    cookie = Cookie(key, value)
    assert cookie.key == key
    assert cookie.value == value
    assert cookie["max-age"] == DEFAULT_MAX_AGE
    assert cookie["expires"] == None
    assert cookie["path"] == "/"
    assert cookie["comment"] == None
    assert cookie["domain"] == None
    assert cookie["secure"] == False
    assert cookie["httponly"] == False
    assert cookie["version"] == None
    assert cookie["samesite"] == None



# Generated at 2022-06-21 22:42:49.405436
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    print("test_Cookie___setitem__()")
    cookie = Cookie("test", "test")
    cookie["httponly"] = False
    if cookie["httponly"] == False:
        print("[test_Cookie___setitem__] Test 1\n")
    else:
        print("[test_Cookie___setitem__] Test 1 failed")
    cookie["path"] = "/"
    if cookie["path"] == "/":
        print("[test_Cookie___setitem__] Test 2\n")
    else:
        print("[test_Cookie___setitem__] Test 2 failed")

# Generated at 2022-06-21 22:42:58.627103
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar[b"key1"] = b"value1"

    assert "Set-Cookie" in headers
    assert len(headers.getall("Set-Cookie")) == 1
    assert "key1=value1" in headers.getall("Set-Cookie")[0]

    del cookie_jar[b"key1"]
    assert "Set-Cookie" in headers
    assert len(headers.getall("Set-Cookie")) == 1
    assert "key1=; Max-Age=0; Path=/" in headers.getall("Set-Cookie")[0]

# Generated at 2022-06-21 22:43:03.134784
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from .message import Headers
    from .helpers import noop_width
    from .test_helpers import JSONResponse

    # Example from https://tools.ietf.org/html/rfc6265#section-4.1
    # Response Cookie:
    #
    # Set-Cookie: lang=en-US; Domain=example.com; Path=/; Expires=Wed,
    # 13-Jan-2100 22:23:01 GMT
    #
    # We should be able to delete this cookie
    #
    # First we need to create one

    # Check positive case of deleting cookie

# Generated at 2022-06-21 22:43:05.366849
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    import base64
    c = Cookie("example", "test")
    assert c.value == 'test'
    initialstring = b'this is a test'
    encodedstring = base64.b64encode(initialstring)
    # encodedstring is of type bytes
    # decode the encoded string before passing to cookie object
    c.value = encodedstring.decode('utf-8')
    assert c.value == encodedstring.decode('utf-8')

# Generated at 2022-06-21 22:43:10.924156
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    # Set up a cookie
    cookie = Cookie(key="example", value="example_value")
    assert cookie.encode(encoding="utf-8") == b"example=example_value"
    assert cookie.encode(encoding="ascii") == b"example=example_value"
    assert cookie.encode(encoding="utf32") == b"example=example_value"

# Generated at 2022-06-21 22:43:12.992622
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = dict()
    cookie_jar = CookieJar(headers)



# Generated at 2022-06-21 22:43:22.217402
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    result = Cookie("abc", "123").__str__()
    assert result == "abc=123"
    result = Cookie("a!b4c", "12#3").__str__()
    assert result == "a!b4c=12#3"
    result = Cookie("a&b4c", "12;3").__str__()
    assert result == "a&b4c=12;3"
    result = Cookie("a#b4c", "12?3").__str__()
    assert result == "a#b4c=12?3"

test_Cookie___str__()

# Generated at 2022-06-21 22:43:24.977152
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cj = CookieJar(headers)
    cj["name"] = "leo"

    assert cj.cookie_headers.get("name")

    cj.__delitem__("name")

    assert "name" not in cj.cookie_headers

    assert "Set-Cookie" in headers.raw()
    assert 'name=leo; Path=/; Expires=Thu, 01 Jan 1970 00:00:00 GMT; Max-Age=0' in headers.raw()['Set-Cookie']


# Generated at 2022-06-21 22:43:47.139478
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from hashlib import md5
    from .helpers import build_environ
    from .router import Router
    from .middleware import Middleware
    from .handler import Handler
    from .server import Server
    from .responses import Response

    class CookieTester(Middleware):
        async def process_request(self, req, resp):
            resp.cookies["foo"] = "bar"
            assert "foo" in resp.cookies
            del resp.cookies["foo"]
            assert "foo" not in resp.cookies

        async def process_response(self, req, resp):
            resp.body = md5(resp.body).hexdigest()

    class Root(Handler):
        async def get(self, req, resp, *, name):
            resp.body = name.encode()

    router = Router()


# Generated at 2022-06-21 22:43:54.408028
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie('wap', '123')
    c['path'] = '/'
    c['expires'] = datetime(2017, 11, 15, 10, 29, 55)
    c['comment'] = 'afs'
    c['samesite'] = 'Lax'
    c['secure'] = True

    output = c.__str__()
    assert output == 'wap=123; Path=/; expires=Thu, 15-Nov-2017 10:29:55 GMT; comment=afs; samesite=Lax; Secure'

# Generated at 2022-06-21 22:44:04.070561
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """
    test the Cookie str method
    this test case is provided as an example
    """
    cookie = Cookie("Nombre", "Valor")
    assert str(cookie) == "Nombre=Valor"
    cookie["version"] = 1
    assert str(cookie) == "Nombre=Valor; Version=1"
    cookie["Version"] = 2
    assert str(cookie) == "Nombre=Valor; Version=2"
    cookie["Domain"] = "localhost"
    assert str(cookie) == "Nombre=Valor; Version=2; Domain=localhost"
    cookie["Max-Age"] = 3600
    assert str(cookie) == "Nombre=Valor; Version=2; Domain=localhost; Max-Age=3600"
    cookie["Path"] = "/"

# Generated at 2022-06-21 22:44:09.130193
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = CookieJar(HeaderMap())
    cookie["name"] = "value"
    encoded_cookie = cookie["name"].encode("utf-8")
    assert encoded_cookie == "name=value".encode("utf-8")

# Generated at 2022-06-21 22:44:15.778098
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from .multidict import CIMultiDictProxy

    headers = CIMultiDictProxy()
    headers.add('Set-Cookie', 'foo=bar; path=/')
    jar = CookieJar(headers)
    jar["foo"]
    assert jar.headers['Set-Cookie'] == 'foo=bar; Path=/'
    del jar["foo"]
    assert jar.headers['Set-Cookie'] == 'foo=; Max-Age=0; Path=/'


# Generated at 2022-06-21 22:44:18.718341
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Test case data
    headers = {}
    cookies = CookieJar(headers)

    cookies["a"] = "b"
    assert headers["Set-Cookie"] == "a=b; Path=/; Max-Age=0"


# Generated at 2022-06-21 22:44:21.960017
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie(key="dummy", value="dummy")
    assert cookie.key == "dummy"
    assert cookie.value == "dummy"
    assert cookie["expires"] == None


# Generated at 2022-06-21 22:44:27.317230
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    from quart.wrappers.headers import Headers
    headers = Headers()
    cookie_jar = CookieJar(headers)
    # test delete an item which doesn't exist
    assert len(headers.getlist('Set-Cookie')) == 0
    del cookie_jar['key']
    assert len(headers.getlist('Set-Cookie')) == 1
    # test delete an item which exist
    del cookie_jar['key']
    assert len(headers.getlist('Set-Cookie')) == 0



# Generated at 2022-06-21 22:44:30.936439
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("c", "1")
    assert c["version"] == 1
    assert c.value == "1"
    assert c.key == "c"
    assert c.encode("utf-8") == b"c=1"
    c = Cookie("c", "1")
    assert c["version"] == 1
    assert c.value == "1"
    assert c.key == "c"
    assert c.encode("utf-8") == b"c=1"


# Generated at 2022-06-21 22:44:40.621057
# Unit test for constructor of class Cookie
def test_Cookie():
    header_key = "Set-Cookie"
    cookie1 = Cookie("key1","value1")
    assert cookie1.value == "value1"
    cookie1["path"] = "/"
    cookie_header = header_key
    cookies = {key:Cookie(key,value) for key,value in {"key1":"value1", "key2":"value2"}.items()}
    cookies["key1"]["path"] = "/"
    cookies["key1"]["max-age"] = 10
    cookies["key2"]["expires"] = datetime(2021, 1, 1)
    assert cookie1.encode("UTF-8") == 'key1=value1; Path=/; Max-Age=10'

# Generated at 2022-06-21 22:45:00.197445
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = http_cookies.MultiDict()
    cookies = CookieJar(headers)
    assert headers.getall("Set-Cookie") == []
    assert cookies == {}
    assert cookies.cookie_headers == {}



# Generated at 2022-06-21 22:45:05.659544
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from quart.wrappers.headers import CIMultiDict
    cookie_jar = CookieJar(CIMultiDict())
    cookie_jar['test'] = 'test'
    assert cookie_jar['test'].value == 'test'
    assert cookie_jar.headers['Set-Cookie'] == 'test=test; Path=/'


# Generated at 2022-06-21 22:45:13.485252
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    import http.cookies
    from header import Header
    from multidict import CIMultiDict

    headers = CIMultiDict()

    c = CookieJar(headers)

    c['test'] = 1
    print(headers)

    c['test'] = 2
    print(headers)

    c['test2'] = 3
    print(headers)

    del c['test']
    print(headers)
    print(c.cookie_headers)

    del c['test2']
    print(headers)
    print(c.cookie_headers)



# Generated at 2022-06-21 22:45:15.353200
# Unit test for constructor of class Cookie
def test_Cookie():
    key = "test_Cookie"
    value = "test_value"
    cookie = Cookie(key, value)
    print(cookie)



# Generated at 2022-06-21 22:45:24.970617
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    test_headers = MultiDict()
    cj = CookieJar(test_headers)
    cj["name"] = "value"
    assert cj == {"name": "value"}
    assert cj.headers.get("Set-Cookie") == 'name="value"; Path=/'
    assert cj.headers.get("Set-Cookie") == test_headers.get("Set-Cookie")
    assert len(cj.cookie_headers) == 1
    assert len(cj.headers) == 1
    assert not test_headers.get("Cookie")


# Generated at 2022-06-21 22:45:27.308095
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from hypercorn.config import Config
    h = MultiHeader()
    c = CookieJar(h)
    c["test"] = "test"
    assert h["Set-Cookie"] == "test=test"


# Generated at 2022-06-21 22:45:35.961728
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    try:
        cookie = Cookie("key", "value")
        cookie["expires"] = "expires"
        cookie["path"] = "Path"
        cookie["comment"] = "Comment"
        cookie["domain"] = "Domain"
        cookie["max-age"] = "Max-Age"
        cookie["secure"] = "Secure"
        cookie["httponly"] = "HttpOnly"
        cookie["version"] = "Version"
        cookie["samesite"] = "SameSite"
    except Exception as e:
        print(f"Test case failed with error: {e}")



# Generated at 2022-06-21 22:45:40.148159
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = CIMultiDict()
    jar = CookieJar(headers)

    jar["some-key"] = "some-value"

    assert jar["some-key"].value == "some-value"
    assert jar["some-key"]["path"] == "/"
    assert headers["set-cookie"] == "some-key=some-value; Path=/"

# Generated at 2022-06-21 22:45:49.706293
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookie_name = 'test'
    cookie_value = 'value'

    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)

    # Add item to cookie jar
    cookie_jar[cookie_name] = cookie_value
    assert cookie_jar[cookie_name].value == cookie_value

    # Delete item from cookie jar
    del cookie_jar[cookie_name]
    assert cookie_name not in cookie_jar

    # Confirm that it was removed from the headers
    cookie_header = cookie_jar.header_key
    cookies = headers.popall(cookie_header)
    assert len(cookies) == 0

# Generated at 2022-06-21 22:45:55.157361
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cookies = CookieJar({})
    assert cookies == {}
    cookies["cookie1"] = "value1"
    assert len(cookies) == 1
    assert cookies["cookie1"] == "value1"
    del cookies["cookie1"]
    assert len(cookies) == 0
    assert cookies["cookie1"] != "value1"



# Generated at 2022-06-21 22:47:01.632959
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("cookie_key", "cookie_value")
    cookie["expires"] = datetime.now()
    assert "expires" in cookie
    cookie["max-age"] = 5
    assert "max-age" in cookie
    with pytest.raises(TypeError):
        cookie["max-age"] = "5"



# Generated at 2022-06-21 22:47:12.326126
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("username", "john")
    assert str(c) == "username=john; Path=/"
    c["secure"] = True
    assert str(c) == "username=john; Path=/; Secure"
    c["secure"] = False
    c["httponly"] = True
    assert str(c) == "username=john; Path=/; HttpOnly"

    # Test with utf-8
    c["comment"] = "🐦"
    assert str(c) == "username=john; Path=/; HttpOnly; Comment=🐦"
    # Test encoding method
    assert c.encode("utf-8") == b"username=john; Path=/; HttpOnly; Comment=\xf0\x9f\x90\xa6"

# Generated at 2022-06-21 22:47:15.046051
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cj = CookieJar({})
    assert cj.headers == {}
    assert cj.cookie_headers == {}
    assert cj.header_key == "Set-Cookie"


# Generated at 2022-06-21 22:47:17.697968
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    assert Cookie("username", "John Doe").encode("utf-8") == b"username=\"John Doe\""

# Generated at 2022-06-21 22:47:21.875132
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("key", "value")
    assert c.encode("utf-8") == b"key=value"
    assert c.encode("latin1") == b"key=value"
    assert c.encode("unicode-escape") == b"key=value"
    assert c.encode("windows-1252") == b"key=value"
    assert c.encode("ascii") == b"key=value"


# ------------------------------------------------------------ #
#  Session
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:47:30.551878
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("key", "value")
    assert cookie.encode("utf-8") == "key=value".encode("utf-8")
    cookie = Cookie("key", "th=is is a fancy value")
    assert cookie.encode("utf-8") == "key=th=is is a fancy value".encode("utf-8")
    cookie = Cookie("k=y", "val=ue")
    assert cookie.encode("utf-8") == 'k=y=val%3Due'.encode("utf-8")
    cookie = Cookie("key", "this is a fancy value")
    assert cookie.encode("utf-8") == "key=this is a fancy value".encode("utf-8")
    cookie = Cookie("ke=y", "v=alue")

# Generated at 2022-06-21 22:47:41.039413
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    headers = SimpleHeaders()
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    assert jar["foo"].encode("utf-8") == "foo=bar; Path=/".encode("utf-8")
    jar["foo"]["some-key"] = "some-value"
    assert jar["foo"].encode("utf-8") == "foo=bar; Path=/; some-key=some-value".encode("utf-8")
    jar["foo"]["some-key"] = "new-some-value"
    assert jar["foo"].encode("utf-8") == "foo=bar; Path=/; some-key=new-some-value".encode("utf-8")
    jar["foo"]["some-key2"] = "some-value2"
    assert jar

# Generated at 2022-06-21 22:47:42.833022
# Unit test for constructor of class CookieJar
def test_CookieJar():

    m = multidict.CIMultiDict()
    rc = CookieJar(m)
    return rc


# Generated at 2022-06-21 22:47:50.615787
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers([])
    jar = CookieJar(headers)
    jar["foo"] = "bar"
    assert "foo" in jar.cookie_headers
    assert "foo" in jar
    jar["foo"] = "baz"
    assert "foo" in jar.cookie_headers
    assert "foo" in jar
    del jar["foo"]
    # Assert nothing happens when deleting a non-existent key
    del jar["foo"]
    assert "foo" not in jar.cookie_headers
    assert "foo" not in jar


# Generated at 2022-06-21 22:48:00.226453
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    class Cook():
        pass

    cookie1 = Cook()
    cookie1.key = "test"
    cookie1.value = "test"
    cookie1.output = 'test=test; Max-Age=10; expires=2000-01-01 00:00:00; Version=1; Path=/; Domain=test.com; Comment="test"; HttpOnly; SameSite=strict; Secure'

    c = Cookie("test", "test")
    c["max-age"] = 10
    c["expires"] = datetime(2000, 1, 1)
    c["version"] = 1
    c["path"] = "/"
    c["domain"] = "test.com"
    c["comment"] = "test"
    c["httponly"] = True
    c["samesite"] = "strict"
    c["secure"]

# Generated at 2022-06-21 22:49:47.704049
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("testing", "123")
    assert c.key == "testing"
    assert c.value == "123"
    assert c == dict()
    assert str(c) == "testing=123"


# Generated at 2022-06-21 22:49:54.418566
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["key_1"] = "value_1"
    assert "value_1" == cookie_jar["key_1"].value
    assert "Set-Cookie" in headers
    del cookie_jar["key_1"]
    assert "key_1" not in cookie_jar
    assert "Set-Cookie" not in headers


# Generated at 2022-06-21 22:49:55.137258
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    pass


# Generated at 2022-06-21 22:49:57.447363
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = {}
    cj = CookieJar(headers)
    cj["mycookie"] = "myval"
    assert cj["mycookie"] == "myval"
    assert headers["Set-Cookie"] == "mycookie=myval; Path=/"


# Generated at 2022-06-21 22:50:03.660640
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = headers = MultiDict()
    newCookie = CookieJar(headers)
    assert isinstance(newCookie, CookieJar)
    # Should fail because this cookie name is a reserved word
    with pytest.raises(KeyError):
        newCookie["expires"] = "26-09-2019"
    newCookie["myCookie"] = "ROCK"
    assert newCookie["myCookie"].value == "ROCK"
    with pytest.raises(KeyError):
        newCookie["WRONG/COOKIE"] = "ROCK"

