

# Generated at 2022-06-21 22:39:58.790579
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("foo", "bar")
    cookie["domain"] = ".example.com"
    cookie["httponly"] = True
    cookie["max-age"] = 10
    cookie["secure"] = True
    expected = "foo=bar; max-age=10; domain=.example.com; HttpOnly; Secure"
    assert cookie.__str__() == expected

# Generated at 2022-06-21 22:40:01.590406
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    cookiejar["testcookie"] = "hello world"
    del cookiejar["testcookie"]
    print(headers)
    assert headers.get("Set-Cookie") == None
    assert cookiejar.get("testcookie") == None
    assert cookiejar.cookie_headers.get("testcookie") == None


# Generated at 2022-06-21 22:40:05.704496
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    cookie_jar = CookieJar({})
    cookie_jar["key"] = "value"

    assert cookie_jar["key"] == "value"
    assert cookie_jar.headers["Set-Cookie"] == "key=value; Path=/"


# Generated at 2022-06-21 22:40:12.006673
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("cookie", "value")
    assert c.__str__() == "cookie=value"

    c["comment"] = "A comment"
    assert c.__str__() == "cookie=value; Comment=A comment"

    c["comment"] = False
    c["secure"] = True
    assert c.__str__() == "cookie=value; Secure"


# ------------------------------------------------------------ #
#  Utilities
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:40:18.074150
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("cookie_name", "value")
    assert cookie.key == "cookie_name"
    assert cookie.value == "value"

    cookie = Cookie("cookie_name", "value_1")
    assert cookie.key == "cookie_name"
    assert cookie.value == "value_1"


# Generated at 2022-06-21 22:40:22.200967
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('name', 'value')
    assert str(cookie) == 'name=value'
    assert str(cookie.encode('utf-8')) == str(cookie).encode('utf-8')

# Generated at 2022-06-21 22:40:25.443887
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('name', 'foo')
    assert cookie.encode('utf-8') == b'name=foo'

# Generated at 2022-06-21 22:40:36.735111
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("name", "value")
    assert c.key == "name"
    assert c.value == "value"
    c["path"] = "/test/"
    assert c["path"] == "/test/"
    c["max-age"] = "10"
    assert c["max-age"] == 10
    c["expires"] = datetime(1970, 1, 1)
    assert c["expires"].strftime("%a, %d-%b-%Y %T GMT") == "Sat, 01-Jan-1970 00:00:00 GMT"
    c["secure"] = True
    assert c["secure"]
    assert c.encode("utf-8") == b"name=value; Path=/test/; Max-Age=10; expires=Sat, 01-Jan-1970 00:00:00 GMT; Secure"
   

# Generated at 2022-06-21 22:40:39.965191
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookiejar = CookieJar(headers)
    cookiejar["key1"] = "val1"
    cookiejar["key2"] = "val2"
    del cookiejar["key1"]
    assert len(headers) == 1
    del cookiejar["key2"]
    assert len(headers) == 0

# Generated at 2022-06-21 22:40:49.309653
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"

    cookie["path"] = "path"
    assert str(cookie) == "key=value; Path=path"

    cookie["path"] = "path/path"
    assert str(cookie) == "key=value; Path=path/path"

    cookie["secure"] = True
    assert str(cookie) == "key=value; Path=path/path; Secure"

    cookie["httponly"] = True
    assert str(cookie) == "key=value; Path=path/path; Secure; HttpOnly"

    cookie["samesite"] = "Lax"
    assert str(cookie) == "key=value; Path=path/path; Secure; HttpOnly; SameSite=Lax"


# Generated at 2022-06-21 22:41:03.188164
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies["name"] = "asdf"
    assert headers.raw == [('Set-Cookie', 'name=asdf; Path=/')]
    cookies["another"] = "name"
    assert headers.raw == [('Set-Cookie', 'name=asdf; Path=/'),
                           ('Set-Cookie', 'another=name; Path=/')]
    cookies["name"] = "new"
    assert headers.raw == [('Set-Cookie', 'name=new; Path=/'),
                           ('Set-Cookie', 'another=name; Path=/')]
    del cookies["name"]

# Generated at 2022-06-21 22:41:08.685497
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    
    headers = MultiHeader()
    cookies = CookieJar(headers)
    cookies.set("name","value")
    cookies.set("name1","value1")
    cookies.set("name2","value2")
    cookies.set("name3","value3")
    cookies.set("name4","value4")
    cookies.set("name5","value5")
    cookies.delete("name3")
    cookies.delete("name2")
    assert(len(cookies) == 4)
    assert(cookies["name"] == "value")
    assert(cookies["name1"] == "value1")
    assert(cookies["name4"] == "value4")
    assert(cookies["name5"] == "value5")

    # __delitem__ with one cookie
    cookies = CookieJar(headers)
    cookies.set

# Generated at 2022-06-21 22:41:16.821963
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    from base64 import b64encode

    def _encode_response_cookie(cookie):
        return "=".join([cookie.key, b64encode(cookie.value.encode("utf-8"))])

    def set_test_cookie():
        return Cookie("test_cookie", "test cookie value")

    cookie = set_test_cookie()
    encoded_cookie = cookie.encode("base64")

    assert encoded_cookie == _encode_response_cookie(cookie)

# Generated at 2022-06-21 22:41:19.716861
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeaders()
    headers.add(cookie_name, cookie_values)
    print(headers)


if __name__ == '__main__':
    test_CookieJar()

# Generated at 2022-06-21 22:41:21.851438
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    jar = CookieJar(headers)

    jar['foo'] = 'bar'
    assert headers['Set-Cookie'] == 'foo=bar; Path=/'



# Generated at 2022-06-21 22:41:24.884509
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    assert cookie_jar.cookie_headers == {}
    assert cookie_jar.headers == headers



# Generated at 2022-06-21 22:41:32.616030
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """Test function for method __str__ of class Cookie"""
    cookie = Cookie("key", "value")
    assert str(cookie) == "key=value"
    cookie["max-age"] = 100
    assert str(cookie) == "key=value; Max-Age=100"
    cookie["expires"] = datetime(2020, 2, 24, 15, 20, 0)
    assert (
        str(cookie)
        == "key=value; Max-Age=100; Expires=Mon, 24-Feb-2020 15:20:00 GMT"
    )
    cookie["path"] = "/"
    assert (
        str(cookie)
        == "key=value; Max-Age=100; Expires=Mon, 24-Feb-2020 15:20:00 GMT; Path=/"
    )
    cookie["domain"] = "localhost"

# Generated at 2022-06-21 22:41:37.211010
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    c = CookieJar(MultiDict())
    c.__setitem__("hello", "world")
    assert c.headers.getlist("Set-Cookie")[0].value == 'hello="world"'


# Generated at 2022-06-21 22:41:43.614461
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
	headers = MultiHeader()
	cookies = CookieJar(headers)
	cookies["session"] = "1"
	assert headers[0].value.value == "1"
	cookies["session"] += "2"
	assert headers[0].value.value == "12"
	cookies["session"] = 43287
	assert headers[0].value.value == "43287"
	cookies["session"] = True
	assert headers[0].value.value == "True"
	cookies["session"] = None
	assert headers[0].value.value == "None"
	cookies["session"] = 4.5
	assert headers[0].value.value == "4.5"

 # Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-21 22:41:52.047704
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cj = CookieJar(headers)
    cj["key1"] = "value1"
    cj["key2"] = "value2"
    cj["key3"] = "value3"
    cj["key4"] = "value4"
    cj["key5"] = "value5"
    cj["key6"] = "value6"



# Generated at 2022-06-21 22:42:04.377921
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    # Test case 1
    cookies = Cookie("hello", "world")
    cookies["max-age"] = 9380
    cookies["secure"] = True
    cookies["version"] = "123"
    cookies["domain"] = "testmalicious.com"
    cookies["samesite"] = "lax"
    cookies["comment"] = "This is a test"
    cookies["httponly"] = True
    cookies["path"] = "/"
    cookies["expires"] = datetime(2020, 1, 1)

    cookie_header = cookies.__str__()

# Generated at 2022-06-21 22:42:09.612046
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    resp = Response()
    resp.cookies.set("test_cookie", "a value")
    assert resp.cookies["test_cookie"].encode("utf-8") == b"test_cookie=a+value"



# Generated at 2022-06-21 22:42:13.585272
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiDict()
    cookie_jar = CookieJar(headers)
    print(headers)
    assert not headers
    cookie_jar["test"] = "test"
    assert len(headers) == 1
    print(headers)
    del cookie_jar["test"]
    assert len(headers) == 0
    print(headers)


# Generated at 2022-06-21 22:42:18.109607
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    cj = CookieJar()
    cj["d1"] = "d1"
    cj["d2"] = "d2"
    del cj["d1"]
    assert len(cj) == 1 and len(cj.headers) == 1



# Generated at 2022-06-21 22:42:24.544879
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeader()
    j = CookieJar(headers)

    j["fake-cookie"] = "fakevalue"
    assert j["fake-cookie"].value == "fakevalue"
    assert headers.get("Set-Cookie", None) is not None
    assert headers.get("Set-Cookie") == "fake-cookie=fakevalue; Path=/; Version=1"



# Generated at 2022-06-21 22:42:29.826282
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar['gonzo'] = 'stuff'
    assert cookie_jar['gonzo'] == 'stuff'
    assert headers['Set-Cookie'] == 'gonzo=stuff'
    del cookie_jar['gonzo']
    assert 'gonzo' not in cookie_jar
    assert 'gonzo' not in headers


# Generated at 2022-06-21 22:42:39.653204
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = CIMultiDict()
    cookie_jar = CookieJar(headers)
    cookie_jar["foo"] = "bar"
    cookie_jar["quux"] = "baz"
    assert len(headers) == 1
    assert headers.getall("Set-Cookie")[0] == "foo=bar; Path=/; HttpOnly"
    assert headers.getall("Set-Cookie")[1] == "quux=baz; Path=/; HttpOnly"
    del cookie_jar["foo"]
    assert len(headers) == 1
    assert headers.getall("Set-Cookie")[0] == "quux=baz; Path=/; HttpOnly"
    del cookie_jar["quux"]
    assert len(headers) == 0


# Generated at 2022-06-21 22:42:46.419879
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    headers = MultiHeader()
    jar = CookieJar(headers)
    cookie = Cookie("foo", b"bar")

    jar["foo"] = "bar"
    assert jar["foo"] == cookie
    assert headers["Set-Cookie"] == cookie

    jar["foo"] = "baz"
    assert jar["foo"] == cookie
    assert headers["Set-Cookie"] == cookie



# Generated at 2022-06-21 22:42:49.129251
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    from hypercorn.asyncio.constants import ASGI_ENCODING

    cookie = Cookie("hello", "world")
    encoded_str = cookie.encode(ASGI_ENCODING)

    assert encoded_str == b'hello=world'

# Generated at 2022-06-21 22:42:55.408363
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("test", "value")
    assert c.key == "test"
    assert c.value == "value"
    assert c["max-age"] == DEFAULT_MAX_AGE
    assert c["path"] == '/'
    assert c["comment"] == None
    assert c["domain"] == None
    assert c["secure"] == False
    assert c["httponly"] == False
    assert c["version"] == None
    assert c["samesite"] == None
    assert c["expires"] == None

    c["max-age"] = 5
    c["path"] = '/test'
    c["comment"] = "Test Comment"
    c["domain"] = "test"
    c["secure"] = True
    c["httponly"] = True
    c["version"] = 5

# Generated at 2022-06-21 22:43:05.866787
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    headers = Headers({"X-Foo": "bar"})

    # Normal
    headers["Set-Cookie"] = "test=test; path=/;"
    assert len(headers["Set-Cookie"]) == 1
    headers.popall("Set-Cookie")

    # Loop
    for i in range(5):
        headers[f"Set-Cookie-{i}"] = f"test{i}=test{i}; path=/;"
    assert len(headers["Set-Cookie"]) == 5



# Generated at 2022-06-21 22:43:13.099096
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    """
    It is a test for the method __setitem__ of class CookieJar with one key and value
    It is tested if the key and value are correctly stored in the headers.
    """
    headers = Headers()
    cookie_jar = CookieJar(headers)

    cookie_jar["test_key"] = "test_value"

    assert "test_key=test_value" in headers.get("Set-Cookie")



# Generated at 2022-06-21 22:43:21.497386
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    assert Cookie("key", "value")["path"] == "/"
    assert Cookie("key", "value")["max-age"] == DEFAULT_MAX_AGE
    assert Cookie("key", "value")["version"] == None
    assert Cookie("key", "value")["secure"] == False
    assert Cookie("key", "value")["httponly"] == False
    assert Cookie("key", "value")["comment"] == None
    assert Cookie("key", "value")["domain"] == None
    assert Cookie("key", "value")["expires"] == None



# Generated at 2022-06-21 22:43:26.430297
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    cookiejar = CookieJar({})
    cookiejar["a"] = "a"
    assert cookiejar["a"].value == "a"

    cookiejar = CookieJar({})
    cookiejar["a"] = "bbbbb"
    assert cookiejar["a"].value == "bbbbb"

# Generated at 2022-06-21 22:43:28.504539
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("test_cookie", "test value")
    assert(cookie.encode("utf-8") == b"test_cookie=test value")

# Generated at 2022-06-21 22:43:33.511512
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie_jar = CookieJar({})
    cookie_jar["test_cookie"] = "test_value"
    # Test that the cookie exists in the cookie jar
    assert cookie_jar["test_cookie"]
    # Test that the value of the cookie is correct
    assert cookie_jar["test_cookie"].value == "test_value"
    # Test that a cookie was added to the headers
    assert cookie_jar.headers["Set-Cookie"]


# Generated at 2022-06-21 22:43:44.808531
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    from starlette.testclient import TestClient
    from starlette.responses import JSONResponse

    headers = Headers()
    cookies = CookieJar(headers)

    cookies["foo"] = "bar"
    assert headers[cookies.header_key][0] == f"foo=bar; Path=/; HttpOnly"

    cookies["foo"] = "baz"
    assert headers[cookies.header_key][0] == f"foo=baz; Path=/; HttpOnly"

    del cookies["foo"]
    assert cookies.header_key not in headers

    async def app(scope, receive, send):
        headers = Headers(scope=scope)
        cookies = CookieJar(headers)

        assert "foo" not in cookies
        assert headers[cookies.header_key] is None

        cookies["foo"] = "bar"


# Generated at 2022-06-21 22:43:50.182150
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = Headers.create([])
    cookies = CookieJar(headers)
    cookies["monkey"] = "banana"
    # Delete the cookie
    del cookies["monkey"]
    # If a cookie expires, it returns an empty string
    assert cookies["monkey"].value == ""
    # If a cookie expires. It returns a "expires" value of 0
    assert cookies["monkey"]["max-age"] == 0



# Generated at 2022-06-21 22:43:56.905667
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("message", "Hello from the other side")
    cookie["expires"] = datetime.now().replace(microsecond=0) + timedelta(days=1)
    cookie["max-age"] = "86400"
    cookie["httponly"] = True
    cookie["secure"] = True
    cookie["path"] = "/"
    cookie["samesite"] = "Lax"
    print(cookie)



# Generated at 2022-06-21 22:44:00.280258
# Unit test for constructor of class CookieJar
def test_CookieJar():
    # cookieJar setup
    headers = CIMultiDict()
    cookieJar = CookieJar(headers)
    assert headers["set-cookie"] == []
    assert cookieJar.headers == headers
    assert cookieJar.header_key == 'Set-Cookie'



# Generated at 2022-06-21 22:44:09.670633
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("test_cookie", "test_value")
    c["expires"] = datetime.utcnow()
    c["max-age"] = DEFAULT_MAX_AGE

    assert str(c) == "test_cookie=test_value; Max-Age=0; Expires=" + str(c["expires"])


# Generated at 2022-06-21 22:44:16.694980
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    class CustomCookie(CookieJar):
        def __setitem__(self, key, value):
            super().__delitem__(key)

    headers = MultiHeader()
    cjar = CustomCookie(headers)

    cjar["key"] = "value"
    cjar["key"] = "value2"
    cjar["key"] = "value3"
    assert len(headers) == 1
    cjar["key"] = "value4"
    assert len(headers) == 0


# Generated at 2022-06-21 22:44:18.873719
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("Test", "value")
    cookie = cookie.encode("utf-8")
    return cookie.decode("utf-8")

# Generated at 2022-06-21 22:44:27.815534
# Unit test for constructor of class Cookie
def test_Cookie():
    # Test normal usage
    c1 = Cookie("name", "value")
    assert c1["comment"] == "This is a test cookie"
    c1["comment"] = "Another comment"
    c1["path"] = "/"
    c1["max-age"] = 3600 * 24 * 7 * 2
    c1["expires"] = datetime.utcnow()
    c1["secure"] = True
    c1["version"] = 0
    assert c1["expires"] == "Thu, 01 Jan 1970 00:00:00 GMT"
    c1["expires"] = datetime.utcnow()
    c1["secure"] = False
    assert c1.value == "value"
    c1.value = "another value"
    assert c1["secure"] == False
    print(c1)

    # Test error

# Generated at 2022-06-21 22:44:32.928498
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    headers = ResponseHeaders()
    cookie_jar = CookieJar(headers)

    # First set two cookies with the same name
    # then call __delitem__
    cookie_jar["foo"] = "bar"
    cookie_jar["foo"] = "bar2"
    cookie_jar["cookie_with_path"] = "baz"
    cookie_jar["cookie_with_path"]["path"] = "/"
    del cookie_jar["foo"]

    # Now we should have empty cookies with max-age: 0
    assert headers.get("Set-Cookie", "foo") == "foo=; Max-Age=0"
    assert headers.get("Set-Cookie", "foo2") == "foo2=; Max-Age=0"

# Generated at 2022-06-21 22:44:41.211329
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    cookie["comment"] = "comment"
    cookie["max-age"] = "age"
    cookie["expires"] = datetime.now()
    cookie["secure"] = True
    cookie["httponly"] = True
    cookie["path"] = "/"
    cookie["domain"] = "127.0.0.1"
    cookie["samesite"] = "lax"
    assert str(cookie) == "name=value; Path=/; Domain=127.0.0.1; Max-Age=age; Expires=Thu, 01-Jan-1970 00:00:00 GMT; SameSite=lax; Secure; HttpOnly; Comment=comment"

# Generated at 2022-06-21 22:44:42.757444
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    pass



# Generated at 2022-06-21 22:44:47.988014
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["cookie_name"] = "cookie_value"
    assert cookie_jar["cookie_name"] == "cookie_value"
    assert str(cookie_jar) == "cookie_name=cookie_value"


# Generated at 2022-06-21 22:44:55.195864
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # Tests for property expires
    # Tests for values that raise TypeError when datetime is not specified
    with pytest.raises(TypeError):
        cookie_expires = Cookie("cookie_expires", "session")
        cookie_expires["expires"] = "1"

    # Tests for property max-age
    cookie_max_age = Cookie("cookie_max_age", "session")
    # Tests for value that raises ValueError when string is passed when int is expected.
    with pytest.raises(ValueError):
        cookie_max_age["max-age"] = "1"

    # Tests for property httponly
    cookie_httponly = Cookie("cookie_httponly", "session")
    # Tests for value that raises ValueError when value is invalid.

# Generated at 2022-06-21 22:44:58.977111
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():

    print("test_CookieJar___setitem__()")
    from starlette.datastructures import Headers

    headers = Headers()
    cookie_jar = CookieJar(headers)
    cookie_jar["session_id"] = "123456789"
    assert(headers == {"Set-Cookie": [Cookie("session_id", "123456789")]})

    cookie_jar.__delitem__("session_id")
    assert(headers == {})

test_CookieJar___setitem__()

# Generated at 2022-06-21 22:45:04.916905
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("foo", "bar")
    assert cookie["value"] == "bar"
    assert cookie["key"] == "foo"



# Generated at 2022-06-21 22:45:13.485762
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("Hob", "Nob")
    assert c.key == "Hob"
    assert c.value == "Nob"
    assert c.encode("utf-8") == b"Hob=Nob"
    assert not c.get("path")
    assert not c.get("expires")
    assert not c.get("max-age")

    # Test that keys are not case-sensitive
    assert not c.get("EXPIRES")
    assert not c.get("expires")
    c["expires"] = "15/Jan/1998"
    assert c.get("EXPIRES") == "15/Jan/1998"


# Generated at 2022-06-21 22:45:22.286285
# Unit test for constructor of class Cookie
def test_Cookie():
    c = Cookie("foo","bar")
    assert c["key"] == "foo"
    assert c["value"] == "bar"
    try:
        c["path"] = "my_path"
        raise AssertionError("No exception thrown!")
    except KeyError:
        pass
    c["path"] = "/"
    assert c["path"] == "/"
    try:
        c["invalid"] = "invalid"
        raise AssertionError("No exception thrown!")
    except KeyError:
        pass



# Generated at 2022-06-21 22:45:25.560968
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('age', '20')

    if cookie.encode('utf-8') == b'age=20':
        print('Cookie.encode(utf-8) passed')
    else:
        print('Cookie.encode(utf-8) failed')

    try:
        cookie.encode('unknown_codec')
    except:
        print('Cookie.encode(unknown_codec) passed')
    else:
        print('Cookie.encode(unknown_codec) failed')

# Generated at 2022-06-21 22:45:34.329296
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    # Create mock object for headers
    headers = MagicMock()
    headers.popall = MagicMock(return_value=[])
    headers.add = MagicMock()

    # Create cookie jar
    cookies = CookieJar(headers)

    # Set one cookie
    cookies["test"] = "test"

    # Delete the cookie
    cookies.__delitem__("test")

    # Assert if test cookie exists in cookie_headers
    assert "test" not in cookies.cookie_headers


# Generated at 2022-06-21 22:45:37.064579
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("test", "value")
    assert c.encode("ascii") == b"test=value"


# ------------------------------------------------------------ #
#  Response
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:45:42.637504
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    s = Cookie('username', 'myname')
    assert (s.encode('utf-8') == b'username=myname')
    assert (s.encode('utf-16') == b'username=myname')
    assert (s.encode('ascii') == b'username=myname')
    assert (s.encode('latin-1') == b'username=myname')
    assert (s.encode('base64') == b'username=bXluYW1l')
    assert (s.encode('rot-13') == b'username=zbxynaqb')


# Generated at 2022-06-21 22:45:51.941411
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    cookie = Cookie("name", "value")
    assert str(cookie) == "name=value"

    cookie = Cookie("name", "value")
    cookie["max-age"] = 100
    assert str(cookie) == "name=value; Max-Age=100"

    cookie = Cookie("name", "value")
    cookie["expires"] = datetime(2015, 1, 1)
    assert str(cookie) == (
        "name=value; Expires=Thu, 01-Jan-2015 00:00:00 GMT"
    )

    cookie = Cookie("name", "value")
    cookie["secure"] = True
    assert str(cookie) == "name=value; Secure"

    cookie = Cookie("name", "value")
    cookie["httponly"] = True
    assert str(cookie) == "name=value; HttpOnly"

# Generated at 2022-06-21 22:46:03.028497
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    c = Cookie("example_cookie", "example_value")
    assert c.encode("utf-8") == b"example_cookie=example_value"

# Generated at 2022-06-21 22:46:06.918937
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    from mediawikiformat.cookie import Cookie
    cookie = Cookie("key", b"value".decode("utf-8"))
    assert cookie.encode("utf-8").decode("utf-8") == str(cookie), (
        "Cookie.encode and Cookie.__str__ should return the same "
        "value encoding in utf-8"
    )

# Generated at 2022-06-21 22:46:16.020436
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie('sessionID', '123')
    cookie['max-age'] = datetime(year=2020, month=1, day=2, hour=3, minute=4, second=5)
    assert cookie.encode('utf-8') == b'sessionID=123; Max-Age=62135596800; Expires=Thu, 02-Jan-2020 03:04:05 GMT'

# Generated at 2022-06-21 22:46:18.916141
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie('cookie_name', 'cookie_value')
    assert cookie.key == 'cookie_name'
    assert cookie.value == 'cookie_value'



# Generated at 2022-06-21 22:46:24.236463
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = Headers()
    cookies = CookieJar(headers)
    assert cookies["test"] == ""
    cookies["test"] = "value"
    assert cookies["test"] == "value"
    # Test reserved words
    cookies["expires"] = "value"
    assert cookies["expires"] == "value"



# Generated at 2022-06-21 22:46:34.570869
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookie_jar = CookieJar(headers)
    # Create a cookie and add to cookie jar
    cookie_key = "test_CookieJar___setitem__"
    cookie_value = "test_Value"
    cookie_jar[cookie_key] = cookie_value
    # Check that the cookie is created
    assert cookie_key in cookie_jar
    assert cookie_key in cookie_jar.cookie_headers
    assert headers.get(cookie_jar.header_key) == cookie_value
    # Change the cookie value and check that the header is updated
    new_cookie_value = "new_test_Value"
    cookie_jar[cookie_key] = new_cookie_value
    assert headers.get(cookie_jar.header_key) == new_cookie_value
    # Delete the cookie and check that the header

# Generated at 2022-06-21 22:46:36.989387
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    req = Request({"header":""})
    req.cookies["user"] = "test"
    req.cookies.__delitem__("user")
    assert len(req.cookies) == 0


# Generated at 2022-06-21 22:46:47.978374
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    import types
    import unittest
    from unittest.mock import create_autospec
    from .multidict import MultiDict

    headers = create_autospec(MultiDict, spec_set=True)

# Generated at 2022-06-21 22:46:50.825160
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("name1", "value1")
    cookie["Max-Age"] = "10"

    expected = {'max-age': 10}

    assert cookie == expected, \
        "Cookie.__setitem__ with key 'Max-Age' should set value to 10."



# Generated at 2022-06-21 22:46:51.953119
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    # cookie = Cookie('key', 'value')
    assert True

# Generated at 2022-06-21 22:46:58.116612
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    key = 'test'
    value = True
    cookie = Cookie(key, value)
    cookie['httponly'] = True
    cookie['version'] = False
    cookie['samesite'] = 'Lax'
    cookie['domain'] = 'foo.com'
    cookie['path'] = 'some/path'
    assert cookie['max-age'] != 12
    assert cookie['expires'] != datetime.now()
    assert cookie['secure'] != True
    assert cookie['version'] != True


test_Cookie___setitem__()



# Generated at 2022-06-21 22:47:00.823388
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("key", "value")
    assert cookie.key == "key"
    assert cookie["key"] == "value"
    assert cookie.value == "value"

# Generated at 2022-06-21 22:47:09.707307
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers={}
    c = CookieJar(headers)
    c['key'] = 'value'
    assert c['key'].value == 'value'
    assert headers['Set-Cookie'] == 'key=value; Path=/'


# Generated at 2022-06-21 22:47:14.926850
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # Arrange
    headers = dict()
    cookie_jar = CookieJar(headers)
    key = "cookie1"
    value = "value1"

    # Act
    cookie_jar[key] = value

    # Assert
    assert headers[cookie_jar.header_key][0] == f"{key}={value}"
    assert cookie_jar[key] == value


# Generated at 2022-06-21 22:47:27.291560
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("c", "d")
    assert str(c) == "c=d"

    c["secure"] = True
    assert str(c) == "c=d; Secure"

    c["domain"] = "example.com"
    assert str(c) == "c=d; Secure; Domain=example.com"

    c["max-age"] = "100"
    assert str(c) == "c=d; Secure; Domain=example.com; Max-Age=100"

    c["path"] = "foo"
    assert str(c) == "c=d; Secure; Domain=example.com; Max-Age=100; Path=foo"


# Generated at 2022-06-21 22:47:37.622569
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    """test :func:`__str__` of class :class:`Cookie`"""
    c = Cookie('ckey', 'cvalue')
    assert str(c) == 'ckey="cvalue"'
    c['Path'] = '/'
    assert str(c) == 'ckey="cvalue"; Path="/"'
    c['Max-Age'] = '100'
    assert str(c) == 'ckey="cvalue"; Path="/"; Max-Age=100'
    c['Expires'] = datetime.now()
    assert 'Expires' in str(c)
    c['Domain'] = 'example.com'
    assert str(c) == 'ckey="cvalue"; Path="/"; Max-Age=100; Expires=%s; Domain=example.com' % str(c['Expires'])

# Generated at 2022-06-21 22:47:45.350818
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    # cookie is not in the header keys
    key = 'foo'
    value = 'bar'
    headers = Headers({})
    cookie_jar = CookieJar(headers)
    cookie_jar[key] = value
    
    assert cookie_jar[key].value == value
    assert cookie_jar[key].key == key
    assert key in headers['Set-Cookie']
    assert 'foo=bar' in headers['Set-Cookie']
    assert 'foo=bar' in str(headers['Set-Cookie'])

    # cookie is in the header keys
    key = 'foo'
    value = 'bar2'
    headers = Headers({})
    cookie_jar = CookieJar(headers)
    cookie_jar[key] = 'bar'
    cookie_jar[key] = value
    

# Generated at 2022-06-21 22:47:56.630272
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = MultiHeaderDict()
    cookie_jar = CookieJar(headers)
    # Setting the 'cookie_name' cookie in json format
    cookie_jar['cookie_name'] = 'cookie_value'
    assert(str(cookie_jar['cookie_name']) == "cookie_name=cookie_value; Path=/")
    # Setting the 'cookie_name' cookie as a regular string
    cookie_jar['cookie_name'] = 'cookie_value'
    assert(str(cookie_jar['cookie_name']) == "cookie_name=cookie_value; Path=/")
    # Setting the 'cookie_name' cookie as a regular integer
    cookie_jar['cookie_name'] = 1
    assert(str(cookie_jar['cookie_name']) == "cookie_name=1; Path=/")
    # Deleting the 'cookie_name

# Generated at 2022-06-21 22:48:02.910531
# Unit test for method __setitem__ of class CookieJar
def test_CookieJar___setitem__():
    headers = MultiHeader()
    cookiejar = CookieJar(headers)
    # 1.
    headers["Set-Cookie"] = 'sessionId="testId"'
    cookiejar["testId"] = 'value'
    assert cookiejar["testId"] == headers.get("Set-Cookie")
    # 2.
    del cookiejar["testId"]
    assert len(headers.get("Set-Cookie")) == 0
    # 3.
    cookiejar["testId"] = 'value'
    assert cookiejar["testId"] == headers.get("Set-Cookie")
    # 4.
    cookiejar["testId"] = 'value-modify'
    #assert cookiejar["testId"] == 'value-modify'
    assert cookiejar["testId"] == headers.get("Set-Cookie")

# Generated at 2022-06-21 22:48:05.309592
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookiejar=CookieJar({"key":"value"})
    assert(cookiejar.headers=={"key":"value"})


# Generated at 2022-06-21 22:48:06.724635
# Unit test for constructor of class CookieJar
def test_CookieJar():
    cookie_jar = CookieJar()
    assert cookie_jar == {}


# Generated at 2022-06-21 22:48:18.348135
# Unit test for method __delitem__ of class CookieJar

# Generated at 2022-06-21 22:48:35.040095
# Unit test for method __str__ of class Cookie
def test_Cookie___str__():
    c = Cookie("key", "value")
    assert str(c) == "key=value"

# Test max-age

# Generated at 2022-06-21 22:48:42.594530
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    """Unit test for method encode of class Cookie"""
    cookie = Cookie("k", "v")

    # Encode cookie object with utf-8 as encoding
    utf8 = cookie.encode("utf-8")

    # Check if encoding is of a byte string
    assert isinstance(utf8, bytes)

    # Check if the decoding of the encoded byte string is same with original
    # cookie string.
    assert str(cookie) == str(utf8.decode("utf-8"))


# ------------------------------------------------------------ #
#  MultiHeader
# ------------------------------------------------------------ #



# Generated at 2022-06-21 22:48:47.890158
# Unit test for constructor of class Cookie
def test_Cookie():
    cookie = Cookie("foo", "bar")
    assert cookie["key"] == "foo"
    assert cookie["value"] == "bar"
    assert cookie["version"] is None
    assert cookie["path"] is None
    assert cookie["domain"] is None
    assert cookie["max-age"] is None
    assert cookie["secure"] is None
    assert cookie["httponly"] is None
    assert cookie["expires"] is None



# Generated at 2022-06-21 22:48:59.377973
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("cookie_key", "cookie_value")
    # Assert that the method __setitem__ raises a KeyError if the key is one of the reserved words
    with pytest.raises(KeyError):
        cookie["secure"] = "secure"
    # Assert that the method __setitem__ raises a KeyError if the key contains illegal characters
    with pytest.raises(KeyError):
        cookie[","] = "some_value"
    # Assert that the method __setitem__ raises a TypeError if the value of key "max-age" is not a digit
    with pytest.raises(TypeError):
        cookie["max-age"] = "some_value"
    # Assert that the method __setitem__ raises a TypeError if the value of key "expires" is not a datetime

# Generated at 2022-06-21 22:49:03.460007
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    CookieJar({})
    cookie = Cookie("name", "value")

    # check item is added if value is not False
    cookie["expires"] = "datetime.datetime(2021, 5, 15, 0, 0)"
    assert cookie["expires"] == "datetime.datetime(2021, 5, 15, 0, 0)"

    # check item is added if value is not false
    cookie["secure"] = True
    assert cookie["secure"] == True

    # check item is added if value is not false
    cookie["httponly"] = True
    assert cookie["httponly"] == True

    # check item is not added if value is false
    cookie["max-age"] = False
    assert "max-age" not in cookie

    # check item is not added if value is false
    cookie["expires"] = False

# Generated at 2022-06-21 22:49:06.156244
# Unit test for method encode of class Cookie
def test_Cookie_encode():
    cookie = Cookie("name", "value")
    assert cookie.encode("utf-8") == b"name=value"



# Generated at 2022-06-21 22:49:08.107076
# Unit test for constructor of class CookieJar
def test_CookieJar():
    headers = h11.Headers()
    cookiejar = CookieJar(headers)
    assert isinstance(cookiejar, CookieJar)

# Generated at 2022-06-21 22:49:15.363353
# Unit test for method __delitem__ of class CookieJar
def test_CookieJar___delitem__():
    """
    Unit test for method __delitem__ of class CookieJar
    """
    headers = DictNode()
    cookies = CookieJar(headers)
    cookies['key'] = 'value'
    cookies['key2'] = 'value2'
    cookies['key3'] = 'value3'
    del cookies['key2']

    process_headers(headers)
    assert 'Set-Cookie: key="value"' in headers['Set-Cookie']
    assert 'key2="value2"; Max-Age=0' in headers['Set-Cookie']
    assert 'key3="value3"' in headers['Set-Cookie']



# Generated at 2022-06-21 22:49:23.563868
# Unit test for method __setitem__ of class Cookie
def test_Cookie___setitem__():
    cookie = Cookie("key", "value")
    with pytest.raises(KeyError):
        cookie["key"] = "value"
    cookie["path"] = "/"
    assert cookie["path"] == "/"
    with pytest.raises(KeyError):
        cookie["invalid"] = "invalid"
    with pytest.raises(ValueError):
        cookie["max-age"] = "value"
    with pytest.raises(TypeError):
        cookie["expires"] = "value"
    cookie["max-age"] = 0
    assert cookie["max-age"] == 0
    cookie["expires"] = datetime.now()
    assert cookie["expires"] == cookie["expires"]
    with pytest.raises(KeyError):
        cookie["secure"] = "value"

# test cookie encoding


# Generated at 2022-06-21 22:49:35.165586
# Unit test for method __str__ of class Cookie