

# Generated at 2022-06-25 09:50:57.805380
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert_success = True
    assert_message = ""
    try:
        inventory_module_parse.parse('', '', '', '')
        assert_success = True
        assert_message = "Successfully parsed."
    except Exception as e:
        assert_message = str(e)
    finally:
        assert assert_success, assert_message


# Generated at 2022-06-25 09:51:05.111030
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()

    # call the method
    host_list_0 = "host_list_0"
    actual = inventory_module_0.verify_file(host_list_0)

    # assert the results
    assert actual

    # reset the context
    inventory_module_0 = InventoryModule()
    inventory = None
    loader = None
    host_list = "host_list"
    cache = None
    inventory_module_0.parse(inventory, loader, host_list, cache)

    # reset the context
    inventory_module_0 = InventoryModule()
    inventory = None
    loader = None
    host_list = "host_list"
    cache = None
    inventory_module_0.parse(inventory, loader, host_list, cache)

# Generated at 2022-06-25 09:51:10.348840
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    sample_host_list = 'host1,host2'
    inventory_module = InventoryModule()
    inventory_module.parse(None, None, sample_host_list)

    verify_result = False
    if inventory_module._hosts_list_count == 2:
        verify_result = True
    assert verify_result == True



# Generated at 2022-06-25 09:51:13.352988
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()

    # Test for run of method verify_file of class InventoryModule with valid parameters
    result = inventory_module_1.verify_file("10.10.2.6, 10.10.2.4")
    assert result == True


# Generated at 2022-06-25 09:51:17.145575
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.display = display
    inventory_module_1.loader = loader
    inventory_module_1.inventory = inventory
    assert inventory_module_1.parse(inventory, loader, "host_list")


# Generated at 2022-06-25 09:51:18.380045
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    #assert inventory_module_0.verify_file(host_list='') == True
    assert inventory_module_0.verify_file(host_list='') == False


# Generated at 2022-06-25 09:51:20.121661
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('host_list_0') == True

# Generated at 2022-06-25 09:51:24.124829
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse() ==  None

# Generated at 2022-06-25 09:51:32.514142
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    x = InventoryModule()
    assert x.verify_file('my.hosts, your.hosts') == True
    assert x.verify_file(', ') == True
    assert x.verify_file('my.hosts, ') == True
    assert x.verify_file(' my.hosts, ') == True
    assert x.verify_file(' my.hosts, your.hosts') == True
    assert x.verify_file('/etc/ansible/hosts') == False
    assert x.verify_file('/etc/ansible/hosts,') == True
    assert x.verify_file('my.hosts') == False
    assert x.verify_file('/etc/ansible/hosts, ') == True

# Generated at 2022-06-25 09:51:34.169652
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert(inventory_module_0.verify_file("abcdefg"))



# Generated at 2022-06-25 09:51:39.174590
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    inventory_module_0 = inventory_module.verify_file('dummy')
    assert inventory_module_0 is False
    inventory_module_0 = inventory_module.verify_file('dummy,dummy')
    assert inventory_module_0 is True


# Generated at 2022-06-25 09:51:43.022655
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    file = 'hosts'
    inventory_obj = InventoryModule()
    assert inventory_obj.verify_file(file) is False


# Generated at 2022-06-25 09:51:51.123846
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()

    #########
    # ARRANGE
    #########
    inventory_1 = {}
    loader_1 = {}
    host_list_1 = "10.10.2.6, 10.10.2.4"
    cache_1 = True

    #########
    # ACT
    #########
    try:
        inventory_module_1.parse(inventory_1, loader_1, host_list_1, cache_1)
    except Exception as e:
        print("Exception: %s" % e)

    #########
    # ASSERT
    #########
    assert isinstance(inventory_1, dict)
    assert isinstance(inventory_1['_meta'], dict)
    assert isinstance(inventory_1['_meta']['hostvars'], dict)

# Generated at 2022-06-25 09:51:59.668476
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    hl = '10.10.2.6, 10.10.2.4'
    inv = { 'hosts': dict() }
    inv['hosts']['10.10.2.6'] = dict()
    inv['hosts']['10.10.2.6']['port'] = '22'
    inv['hosts']['10.10.2.6']['groups'] = ['all']
    inv['hosts']['10.10.2.4'] = dict()
    inv['hosts']['10.10.2.4']['port'] = '22'
    inv['hosts']['10.10.2.4']['groups'] = ['all']
    obj = InventoryModule()
    obj.inventory = inv

# Generated at 2022-06-25 09:52:04.227783
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import pytest

    inventory_module_1 = InventoryModule()

    with pytest.raises(AnsibleParserError) as excinfo:
        inventory_module_1.parse(inventory=None, loader=None, host_list="192.168.0.1, 192.168.0.2")
    assert "Invalid data from string, could not parse" in str(excinfo.value)


# Generated at 2022-06-25 09:52:08.778648
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(None, None, "host1,host2")


# Generated at 2022-06-25 09:52:13.476792
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    host_list = 'one_host.example.com'
    result = inventory_module_0.parse(None, None, host_list)
    assert result is None


# Generated at 2022-06-25 09:52:21.427389
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    inventory_module_1_verify_file = inventory_module_1.verify_file("host_list")
    assert inventory_module_1_verify_file == None, "inventory_module_1.verify_file(host_list) failed"
    inventory_module_2 = InventoryModule()
    inventory_module_2_verify_file = inventory_module_2.verify_file("host_list")
    assert inventory_module_2_verify_file == None, "inventory_module_2.verify_file(host_list) failed"


# Generated at 2022-06-25 09:52:25.140340
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    host_list_0 = "host_0"
    cache_0 = None
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:52:35.274101
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    InventoryModule.parse(): Test case for parse() method of InventoryModule class
    """
    # Test variables
    inventory = None
    loader = None
    host_list = '10.10.2.4, 10.10.2.6'
    cache = True

    # Test function
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list, cache)

if __name__ == "__main__":
    print("Running test cases")
    print("------------------")
    print("")

    test_case_0()
    test_InventoryModule_parse()

    print("")
    print("No test case failed")
    print("Total test cases executed: 2")

# Generated at 2022-06-25 09:52:45.544246
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    host_list = 'test_0'
    InventoryModule_verify_file_expected_result = True
    InventoryModule_verify_file_actual_result = inventory_module_0.verify_file(host_list)
    assert InventoryModule_verify_file_expected_result == InventoryModule_verify_file_actual_result

# Run all tests
test_case_0()
test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:52:48.790852
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_test = InventoryModule()
    inventory_module_test.parse(loader, host_list='10.10.2.6, 10.10.2.4' )

# Unit testing for method verify_file of class InventoryModule

# Generated at 2022-06-25 09:52:50.611279
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

# Generated at 2022-06-25 09:52:57.192164
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  inventory_module_0 = InventoryModule()

  # Test cases for validate the arguments
  host_list_0 = "10.101.4.4,10.101.4.3"
  assert inventory_module_0.verify_file(host_list_0) == True
  host_list_1 = "10.101.4.4,10.101.4.3"
  assert inventory_module_0.verify_file(host_list_1) == True

  # Test cases for validate the return type
  host_list_2 = "10.101.4.4,10.101.4.3"
  assert isinstance(inventory_module_0.verify_file(host_list_2), bool) == True


# Generated at 2022-06-25 09:53:05.944300
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_module_1.inventory
    loader_1 = mock.Mock(autospec=DataLoader)
    host_list_1 = '10.10.2.6, 10.10.2.4'
    cache_1 = True
    assert inventory_module_1.parse(inventory_1, loader_1, host_list_1, cache_1 == None)

# Generated at 2022-06-25 09:53:11.554879
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    b_path = to_bytes(host_list, errors='surrogate_or_strict')
    for h in host_list.split(','):
        (host, port) = parse_address(h, allow_ranges=False)
    inventory_module_parse.parse(inventory, loader, host_list)
    inventory_module_parse.parse(inventory, loader, host_list)


# Generated at 2022-06-25 09:53:15.151437
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = object()
    loader = object()
    host_list = "hostlist"
    inventory_module_1.parse(inventory, loader, host_list)


# Generated at 2022-06-25 09:53:20.912942
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse0 = InventoryModule()
    inventory_module_parse1 = InventoryModule()
    inventory_module_parse2 = InventoryModule()
    inventory_module_parse0.parse(None, None, 'host_1', None)
    inventory_module_parse1.parse(None, None, 'host_1,')
    inventory_module_parse2.parse(None, None, 'host_1,,host_2')

# Generated at 2022-06-25 09:53:24.098826
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()
    inventory_source = 'localhost,'
    loader = None
    cache = True
    # call method
    inventory_module.parse(inventory_source, loader, inventory_source, cache)

# Generated at 2022-06-25 09:53:31.655105
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    # Testing with a host_list that is not a path but contains a comma
    assert inventory_module_1.verify_file('non-existent-path,10.10.2.4') == True
    # Testing with a host_list that is a path but does not contain a comma
    assert inventory_module_1.verify_file('/etc/hosts') == False

# Generated at 2022-06-25 09:53:44.985277
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Unit test for method parse of class InventoryModule
    '''
    # define 2 hosts in command line
    # ansible -i '10.10.2.6, 10.10.2.4' -m ping all

    # create a new object of class InventoryModule
    inventory_module_0 = InventoryModule()
    # create a new object of class Inventory
    inventory_0 = inventory_module_0.inventory
    # create a new object of class BaseInventoryPlugin
    base_inventory_plugin_0 = BaseInventoryPlugin()

    # invoke method parse of inventory_module_0
    inventory_module_0.parse(inventory_0, base_inventory_plugin_0, '10.10.2.6, 10.10.2.4')
    # check if inventory_0.hosts is not empty

# Generated at 2022-06-25 09:53:49.236102
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # inventory = dict
    # loader = dict
    host_list = "10.10.2.6, 10.10.2.4,host1.example.com, host2,localhost,"
    cache = True
    inventory_module.parse(inventory=dict,loader=dict,host_list=host_list,cache=True)

# Generated at 2022-06-25 09:54:00.683571
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    loader = DataLoader()
    host_list_0 = '10.10.2.4,10.10.2.5'
    inventory_module_0 = InventoryModule()
    inventory = InventoryManager(loader=loader, sources=[''])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    play_source = dict(
        name="Ansible Play 0",
        hosts='all',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello Ansible Playbook 0')))
        ]
    )
    play

# Generated at 2022-06-25 09:54:06.857819
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = InventoryModule()
    host_list_0 = InventoryModule()
    cache_0 = InventoryModule()
    x = inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)
    assert True



# Generated at 2022-06-25 09:54:13.027630
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.set_options('localhost,')
    inventory_module_1.parse('inventory_1', 'loader_1', 'localhost,')
    assert(inventory_module_1.plugin_type == 'inventory')
    assert(inventory_module_1.plugin_name == 'host_list')
    assert(inventory_module_1.UUID == 'host_list:localhost,')
    assert(inventory_module_1.NAME == 'host_list')
    assert(inventory_module_1.source == 'localhost,')
    assert(inventory_module_1.cache_key == 'inventory_1|loader_1|host_list:localhost,')
    assert(inventory_module_1.host_list == 'localhost,')

# Generated at 2022-06-25 09:54:16.165014
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    host_list_0 = object()
    cache_0 = object()
    assert isinstance(inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0), bool)


# Generated at 2022-06-25 09:54:17.270408
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert True

# Generated at 2022-06-25 09:54:24.331809
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    inventory = dict()
    module.parse(inventory, None, "test.example.com,test2.example.com", None)

    assert inventory["test.example.com"] == {'_meta': {'hostvars': {'test.example.com': {}}}}
    assert inventory["test2.example.com"] == {'_meta': {'hostvars': {'test2.example.com': {}}}}


import pytest


# Generated at 2022-06-25 09:54:29.874237
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    """test for parse"""
    inventory_0 = dict()
    loader_0 = dict()
    host_list_0 = ''
    cache_0 = False

    inventory_module_0.parse(inventory_0, loader_0, host_list=host_list_0, cache=cache_0)



# Generated at 2022-06-25 09:54:32.001632
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_data = inventory_module_0.parse(inventory, loader, host_list, cache=True)
    assert inventory_data == None

# Generated at 2022-06-25 09:54:37.737078
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    assert module.parse(inventory=None, loader=None, host_list="", cache=True) is None


# Generated at 2022-06-25 09:54:44.709776
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Check with invalid value
    inventory_module = InventoryModule()
    inventory = dict()
    inventory['_ansible_verbose_always'] = True
    loader = dict()
    #parser = dict()
    #expect_value = False

    host_list = "fe80::250:56ff:fe8a:2c6c, 10.10.2.6, 10.10.2.4"
    inventory_module.parse(inventory, loader, host_list)
    assert len(inventory.hosts) == 3
    #assert inventory.hosts['fe80::250:56ff:fe8a:2c6c']['vars']['ansible_connection'] == 'network_cli'
    #assert inventory.hosts['10.10.2.6']['vars']['ansible_connection']

# Generated at 2022-06-25 09:54:47.490694
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()

    print(inventory_module_0.parse())


# Generated at 2022-06-25 09:54:54.267304
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    host_list_0 = 'localhost,192.168.1.1,'
    test_InventoryModule_parse_default_0 = inventory_module_0.parse(inventory_0, loader_0, host_list_0)
    assert test_InventoryModule_parse_default_0 == None
"""
if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    unittest.main()
"""

# Generated at 2022-06-25 09:54:55.902178
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(5, True, 'test_str', 'test_str2')

# Generated at 2022-06-25 09:54:59.541458
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    hostList_1 = "localhost"
    inventory_1 = None
    loader_1 = None
    inventory_module_1.parse(inventory_1,loader_1,hostList_1)
    print("Pass test_InventoryModule_parse")


# Generated at 2022-06-25 09:55:06.488956
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    host_list_0 = '10.10.2.6, 10.10.2.4'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:55:10.767958
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = inventory_module_1
    loader_1 = inventory_module_1
    host_list_1 = "host1.example.com, host2"
    cache_1 = True
    inventory_module_1.parse(inventory_1, loader_1, host_list_1, cache_1)


# Generated at 2022-06-25 09:55:14.714722
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert callable(getattr(inventory_module_parse, "parse", None))


# Generated at 2022-06-25 09:55:22.032920
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_loader_0 =  InventoryModule()
    inventory_dict_0 = dict()
    inventory_module_0 = InventoryModule()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict()
    inventory_loader_0.options = dict()
    inventory_loader_0._options = dict

# Generated at 2022-06-25 09:55:36.636919
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    text_0 = "10.10.2.4, 10.10.2.6"
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory
    loader_0 = inventory_module_0.loader
    host_list_0 = inventory_module_0.host_list
    inventory_module_0.parse(inventory_0, loader_0, host_list_0)
    

# Generated at 2022-06-25 09:55:46.501045
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print("Testing parse for InventoryModule")
    test_case_parse(
        # a comma separated list of hosts
        "10.10.2.6, 10.10.2.4",
        [
            {
                'host': '10.10.2.6',
                'groups': ['ungrouped']
            },
            {
                'host': '10.10.2.4',
                'groups': ['ungrouped']
            }
        ]
    )

# Generated at 2022-06-25 09:55:53.199428
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test variable inventory
    # In the variable inventory, you need to add the data format to the variable
    inventory = None
    # Test variable loader
    # In the variable loader, you need to add the data format to the variable
    loader = None
    # Test variable host_list
    # In the variable host_list, you need to add the data format to the variable
    host_list = None
    # Test variable cache
    # In the variable cache, you need to add the data format to the variable
    cache = None
    # Test function call of InventoryModule.parse with arguments inventory, loader, host_list and cache
    result = InventoryModule().parse(inventory, loader, host_list, cache)
    assert result == None

test_InventoryModule_parse()

# Generated at 2022-06-25 09:55:58.594787
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("", "", "host1.example.com,host2,host3.example.com,host4.example.com,host5.example.com")
    assert inventory_module.parse("", "", "host1.example.com,host2,host3.example.com,host4.example.com,host5.example.com").strip() == 'host1.example.com, host2, host3.example.com, host4.example.com, host5.example.com'

# Generated at 2022-06-25 09:56:02.181493
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    loader = None
    host_list = '10.10.2.6, 10.10.2.4'
    inventory_module.parse(None, loader, host_list)

# Generated at 2022-06-25 09:56:09.554171
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = 'inventory_0'
    loader_0 = 'loader_0'
    host_list_0 = 'host_list_0'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:56:12.545735
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    host_list_0 = "host1,host2"

    inventory = {}
    loader = {}
    cache = True

    InventoryModule.parse(InventoryModule, inventory, loader, host_list_0, cache)


# Generated at 2022-06-25 09:56:18.713707
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    loader_0 = None
    host_list_0 = 'www.example.com'
    cache_0 = True
    inventory_module_0.parse(loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:56:22.275703
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Arrange
    inventory_module = InventoryModule()
    inventory = object()
    loader = object()
    host_list = "localhost"

    # Act
    result = inventory_module.parse(inventory, loader, host_list)

    # Assert
    expected = None
    assert result == expected


# Generated at 2022-06-25 09:56:27.464898
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = {}
    loader = {}
    host_list = "host1.example.com,host2"
    cache = True
    inventory_module_1.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:56:47.444980
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {'hosts': {'testhost1.example.com': {'hostname': 'testhost1.example.com'}}}
    loader = None
    host_list = 'testhost1.example.com, testhost2.example.com'
    cache = None
    result = inventory_module.parse(
        inventory,
        loader,
        host_list,
        cache)
    assert result == {'hosts': {'testhost1.example.com': {'hostname': 'testhost1.example.com'},
                                'testhost2.example.com': {'hostname': 'testhost2.example.com'}}}


# Generated at 2022-06-25 09:56:51.546339
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    args = {}
    if not os.environ['ANSIBLE_LANG'] or os.environ['ANSIBLE_LANG'] == 'en_US.utf-8':
        args['host_list'] = "host1.example.com, host2"
    else:
        args['host_list'] = "host1.example.com, host2"
    inventory_module_0.parse(**args)

# Generated at 2022-06-25 09:56:53.210308
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = ""
    loader = ""
    host_list = ""

    print(inventory_module.parse(inventory, loader, host_list))

# Generated at 2022-06-25 09:56:55.240441
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert inventory_module.parse({'foo': 'bar'}, 'my_loader', 'host1') == None, "InventoryModule.parse() returned unexpected result"


# Generated at 2022-06-25 09:56:56.790834
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_instance = InventoryModule()
    assert inventory_instance.verify_file('host1.example.com, host2') == True



# Generated at 2022-06-25 09:56:58.054288
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(None, None, 'h1')

# Generated at 2022-06-25 09:57:03.725454
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    b_host_list = to_bytes('host_list', errors='surrogate_or_strict')
    b_cache = to_bytes('cache', errors='surrogate_or_strict')
    # Call method parse of inventory_module_0
    # AnsibleMap: {'inventory': AnsibleMap: {'_restriction': None, '_subset': None, '_vars_per_host': AnsibleMap: {}, '_vars_per_group': AnsibleMap: {}, '_hosts_cache': AnsibleMap: {}, '_pattern_cache': AnsibleMap: {}, 'groups': AnsibleMap: {}}, 'loader': AnsibleBaseVars: {'_task_vars': {}, '_nonpersistent_fact_cache': {}}, 'host

# Generated at 2022-06-25 09:57:10.241179
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    class MockInventory():
        hosts = dict()
    loader = None
    host_list = "test_host"
    cache = True
    inventory_module_0.parse(MockInventory(), loader, host_list, cache)

# Generated at 2022-06-25 09:57:12.448976
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Set up test case
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory_module_1.inventory, None, host_list=None)


# Generated at 2022-06-25 09:57:16.268932
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_obj_0 = InventoryModule()
    inventory_module_0.parse(inventory_obj_0, loader, "host_list")

# Generated at 2022-06-25 09:57:41.023790
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    x = inventory_module_0.parse(inventory=None, loader=None, host_list='host_list', cache=True)


# Generated at 2022-06-25 09:57:43.405601
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(inventory_module_0, loader, '127.0.0.1, 192.168.1.1')

# Generated at 2022-06-25 09:57:45.510478
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list = 'localhost'
    inventory_module_1 = InventoryModule()
    loader = True
    inventory_obj_1 = inventory_module_1.parse(loader, host_list)
    assert(inventory_obj_1 is not False)


# Generated at 2022-06-25 09:57:51.369195
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    try:
        inventory_module_parse.parse(inventory='', loader='', host_list='', cache=True)
    except AnsibleParserError as e:
        assert e.message == "Invalid data from string, could not parse: %s" % to_native(e)

# Generated at 2022-06-25 09:58:02.817029
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    inventory_module_1.validate_conf({'host_list': 'host1.example.com, host2'})
    inventory_module_1.parse(inventory = {}, loader = {}, host_list = 'host1.example.com, host2')
    assert inventory_module_1.inventory == {'hosts': {}, 'all': {'children': ['ungrouped']}, '_meta': {'hostvars': {}}, 'ungrouped': {'hosts': ['host1.example.com', 'host2'], 'vars': {}}}, "Test #0 - method parse of class InventoryModule failed"

    inventory_module_2 = InventoryModule()
    inventory_module_2.validate_conf({'host_list': 'host1.example.com'})
   

# Generated at 2022-06-25 09:58:05.812971
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {}
    loader = {}
    host_list = '10.10.2.6, 10.10.2.4'
    cache = True
    inventory_module.parse(inventory, loader, host_list, cache)



# Generated at 2022-06-25 09:58:08.966757
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse('test_inventory', 'test_loader', 'test_host_list')


# Generated at 2022-06-25 09:58:13.241454
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    fstr = 'test/test_host_list.txt'
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file(fstr) == True
    assert inventory_module_1.parse(None,None,fstr,True) == None


# Generated at 2022-06-25 09:58:15.801600
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list=''
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse(inventory_module_parse.inventory, None, host_list)


# Generated at 2022-06-25 09:58:18.233011
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    result = inventory_module_1.parse(inventory = '', loader = '', host_list = '')
    assert isinstance(result, object)


# Generated at 2022-06-25 09:59:23.018284
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    str_0 = 'localhost,'
    loader_0 = 'loader'
    host_list_0 = str_0
    inventory_0 = ''
    inventory_module_0.parse(inventory_0, loader_0, host_list_0)


# Generated at 2022-06-25 09:59:27.217747
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert True == inventory_module.parse(None, None, "", False)


# Generated at 2022-06-25 09:59:32.718265
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory_0 = 0
    loader_1 = 1
    host_list_0 = 0
    cache_1 = 1
    inventory_module_1.parse(inventory_0, loader_1, host_list_0, cache_1)


# Generated at 2022-06-25 09:59:36.753308
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list, cache=True)

# Generated at 2022-06-25 09:59:43.727111
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_1 = "inventory"
    loader_1 = "loader"
    host_list_1 = "host_list"
    cache_1 = True
    result = inventory_module_0.parse(inventory_1, loader_1, host_list_1, cache_1)
    assert result is None


# Generated at 2022-06-25 09:59:45.220556
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert inventory_module_parse.parse('localhost', '', 'host1,host2') == None



# Generated at 2022-06-25 09:59:46.040866
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(None, None, '') == None


# Generated at 2022-06-25 09:59:52.386957
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert True == inventory_module_1.verify_file('10.10.2.6, 10.10.2.4'), "test_InventoryModule_parse True == inventory_module_1.verify_file('10.10.2.6, 10.10.2.4')"
    assert False == inventory_module_1.verify_file('host1.example.com, host2'), "test_InventoryModule_parse False == inventory_module_1.verify_file('host1.example.com, host2')"
    assert False == inventory_module_1.verify_file('localhost,'), "test_InventoryModule_parse False == inventory_module_1.verify_file('localhost,')"

# Generated at 2022-06-25 09:59:54.430010
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('inventory','loader','host_list', cache=True)

# Generated at 2022-06-25 09:59:59.844823
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_inventory_module_parse_arguments = {
        u'loader': None,
        u'host_list' : u'',
        u'cache': None,
        u'inventory': None
    }
    InventoryModule_parse(test_inventory_module_parse_arguments)
