

# Generated at 2022-06-25 09:50:59.741684
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  test_vars = "localhost,"
  test_str_path = "/etc/ansible/hosts"
  test_host_list = "localhost"
  test_inventory = "Inventory()"
  test_loader = "DataLoader()"
  test_cache = True
  test_case_0 = InventoryModule()
  # Test attributes are not initialized
  assert test_case_0.inventory != test_inventory
  assert test_case_0.loader != test_loader

# Generated at 2022-06-25 09:51:03.564668
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    module_result = inventory_module_1.parse(inventory=None, loader=None, host_list="""server1.example.com,12.34.56.78""")
    assert module_result == None

# Generated at 2022-06-25 09:51:13.352342
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/home/user/ansible/plugins/inventory/01-basic_inventory.py') == False
    assert inventory_module.verify_file('/home/user/ansible/plugins/inventory/hosts.yml') == False
    assert inventory_module.verify_file('/home/user/ansible/plugins/inventory/hosts.2.yml') == False
    assert inventory_module.verify_file('localhost,') == True
    assert inventory_module.verify_file('host1.example.com,host2') == True
    assert inventory_module.verify_file('10.10.2.6,10.10.2.4') == True


# Generated at 2022-06-25 09:51:16.236932
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = None
    loader = None
    host_list = '10.10.2.6, 10.10.2.4'
    cache = True
    assert inventory_module_0.parse(inventory, loader, host_list, cache) == None


# Generated at 2022-06-25 09:51:19.214815
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("/path/to/inventory/file") == False
    assert inventory_module.verify_file("a/path/to/inventory/file,b/path/to/inventory/file") == True
    assert inventory_module.verify_file("1.1.1.1,2.2.2.2") == True

# Generated at 2022-06-25 09:51:20.562928
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.parse(str(), str(), str()) is None

# Generated at 2022-06-25 09:51:26.918606
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = [(None, {u'_ansible_parser': u'host_list'}, None)]
    loader = None
    host_list = u'127.0.0.1'
    cache = True

    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:51:28.892655
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("", "", "10.10.2.6, 10.10.2.4, host1.example.com, host2")

# Generated at 2022-06-25 09:51:31.177192
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    host_list = 'localhost,'
# call method verify_file of class InventoryModule
    assert(inventory_module_0.verify_file(host_list))

# Generated at 2022-06-25 09:51:33.978237
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object
    loader_0 = object
    host_list_0 = "host_list"
    inventory_module_0.parse(inventory_0, loader_0, host_list_0)


# Generated at 2022-06-25 09:51:41.772619
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_data_0 = {
        "hosts": "host1.example.com, host2",
        "expected": True
    }

    test_data_1 = {
        "hosts": None,
        "expected": False
    }

    test_data_2 = {
        "hosts": "/etc/ansible/hosts",
        "expected": False
    }

    inventory_module_0 = InventoryModule()
    for test_data in [test_data_0, test_data_1, test_data_2]:
        hosts = test_data["hosts"]
        expected = test_data["expected"]
        actual = inventory_module_0.verify_file(hosts)
        assert actual == expected, "Expected: %s\nActual: %s" % (expected, actual)

#

# Generated at 2022-06-25 09:51:45.789290
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = InventoryModule()
    path_0 = str()
    result = inventory_module_0.parse(inventory_0, loader_0, path_0, True)
    assert type(result) == type(None)


# Generated at 2022-06-25 09:51:52.691488
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    host_list_0 = 'host2.example.com, host'
    host_list_1 = 'host1.example.com, host2'
    host_list_2 = 'host1.example.com, host2, localhost'
    valid_0 = inventory_module_0.verify_file(host_list_0)
    valid_1 = inventory_module_1.verify_file(host_list_1)
    valid_2 = inventory_module_0.verify_file(host_list_2)
    assert valid_0 is True
    assert valid_1 is True
    assert valid_2 is True

# Generated at 2022-06-25 09:51:56.086906
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    # Verify that method verify_file raises exception for invalid authorization
    try:
        module.verify_file("10.10.2.6, 10.10.2.4")
    except Exception as e:
        print("test_InventoryModule_verify_file: This test should not fail. " +\
               "Invalid authorization entered, which is not accepted as input")
        print("Error: " + str(e))
        return False
    return True


# Generated at 2022-06-25 09:52:01.539946
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    host_list = '10.5.5.4,10.5.5.5'

    verify_file_ret_value = inventory_module_0.verify_file(host_list)

    assert verify_file_ret_value is True

# Generated at 2022-06-25 09:52:04.633781
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    i_0 = inventory_module_0.parse(inventory, loader, 'localhost')

    assert i_0.name == 'localhost'


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 09:52:11.239664
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    host_list_0 = "/Users/abhij/.pyenv/versions/ansible2.7.0/etc/ansible.cfg"
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache=cache_0)

# Generated at 2022-06-25 09:52:14.861664
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Given
    inventory_module = InventoryModule()

    # When
    result1 = inventory_module.verify_file("")
    result2 = inventory_module.verify_file("a, b, c")

    # Then
    assert result1 == False, "The test result should be false"
    assert result2 == True, "The test result should be true"

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:52:19.200485
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(host_list='/etc/ansible/hosts') == False

    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file(host_list='/etc/ansible/hosts,10.10.2.4') == True

    inventory_module_2 = InventoryModule()
    assert inventory_module_2.verify_file(host_list=',10.10.2.4') == True



# Generated at 2022-06-25 09:52:24.438054
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('/home/paul/ansible/test.yml') == False
    assert inventory_module_0.verify_file('host1,host2') == True

# Generated at 2022-06-25 09:52:29.639708
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    host_list = 'host1.example.com, host2'
    inventory_module_0.parse(None, 'loader', host_list)


# Generated at 2022-06-25 09:52:38.586640
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Verify if method parse of class InventoryModule raises expected exceptions
    i = InventoryModule()

    with pytest.raises(AnsibleParserError) as excinfo:
        i.parse('inventory', 'loader', 'somethingwrong')

    # Verify if method parse of class InventoryModule returns expected hostnames and port numbers
    i = InventoryModule()
    s = 'localhost, host1.example.com, 127.0.0.2, 192.168.1.1:22, 192.168.1.10-15, some.host'
    i.parse('inventory', 'loader', s)

# Generated at 2022-06-25 09:52:44.735706
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    # Verify with file path as input argument
    assert inventory_module_1.verify_file("/home/centos/ansible/inventory/hosts") == False
    # Verify with string as input argument
    assert inventory_module_1.verify_file("host1.example.com,host2") == True



# Generated at 2022-06-25 09:52:47.377922
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    host_list = '10.10.2.6'
    assert inventory_module_1.verify_file(host_list)


# Generated at 2022-06-25 09:52:54.046030
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/tmp/inventory_file_0') == False
    assert inventory_module.verify_file(',') == True
    assert inventory_module.verify_file('2.2.2.2,1.1.1.1') == True

# Generated at 2022-06-25 09:52:59.942911
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    host_list = "localhost"
    test_value = inventory_module_0.verify_file(host_list)
    assert test_value == True

# Local Backup:
# https://github.com/pcacjr/ansible/blob/host-list/lib/ansible/plugins/inventory/host_list.py

# Generated at 2022-06-25 09:53:03.502033
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    print("Testing verify_file")
    assert inventory_module_0.verify_file("localhost") == False


# Generated at 2022-06-25 09:53:06.795838
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Parse test case #0
    # Populate these variables with values
    # to test this method
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list, cache)

# Generated at 2022-06-25 09:53:11.293839
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory = inventory_module_0
    loader = inventory_module_0
    host_list = "test_host_list"
    cache = False

    # Call the method
    inventory_module_0.parse(inventory, loader, host_list, cache=cache)


# Generated at 2022-06-25 09:53:15.359411
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = range(3)
    loader = range(3)
    host_list = u'host1.example.com, host2'
    cache = True
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:53:21.577911
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    assert inventory_module_verify_file.verify_file("host-list.yaml")==True


# Generated at 2022-06-25 09:53:33.056321
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    test1 = '''
    # define 2 hosts in command line
    # ansible -i '10.10.2.6, 10.10.2.4' -m ping all

    # DNS resolvable names
    # ansible -i 'host1.example.com, host2' -m user -a 'name=me state=absent' all

    # just use localhost
    # ansible-playbook -i 'localhost,' play.yml -c local
    '''


# Generated at 2022-06-25 09:53:39.010416
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_cases = [
        "host_list.py",
        "localhost",
        "localhost,",
        "localhost,localhost",
    ]

    for test_case in test_cases:
        expected = not os.path.exists(test_case) and "," in test_case
        actual = InventoryModule().verify_file(test_case)
        assert expected == actual, \
            test_case + '\n' + "Expected: " + str(expected) + '\n' + "Actual: " + str(actual)
        print("Test case passed for : " + test_case)


# Generated at 2022-06-25 09:53:45.725828
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = [{'name': 'test'}]
    loader_1 = [{'name': 'test'}]
    inventory_module_1.parse(inventory_1, loader_1, '192.168.0.1')
    assert inventory_1 == [{'name': 'test'}, {'name': '192.168.0.1'}]

# Generated at 2022-06-25 09:53:51.339214
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, "10.1.1.10,10.45.45.45,")



# Generated at 2022-06-25 09:53:56.721441
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    host_list = "10.10.2.4, 10.10.2.5"
    assert True == InventoryModule().verify_file(host_list)
    host_list = "10.10.2.4,10.10.2.5"
    assert True == InventoryModule().verify_file(host_list)


# Generated at 2022-06-25 09:54:00.783365
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    list_of_inputs = ['10.10.2.6, 10.10.2.4']
    for item in list_of_inputs:
        inventory_module.verify_file(item)


# Generated at 2022-06-25 09:54:07.541362
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("/root/.servers,/root/.servers")
    inventory_module_2 = InventoryModule()
    assert not inventory_module_2.verify_file("/root/.servers,/root/.servers")
    inventory_module_3 = InventoryModule()
    assert inventory_module_3.verify_file("10.10.2.6, 10.10.2.4")

# Generated at 2022-06-25 09:54:11.652602
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert True == inventory_module_0.verify_file('localhost,10.10.2.6')
    assert True == inventory_module_0.verify_file('10.10.2.6,localhost')

# Generated at 2022-06-25 09:54:15.154901
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    
    # Create test InventoryModule object and call verify_file method
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('example.com, example.net') == True
 
     # Create test InventoryModule object and call verify_file method
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('example.com') == False


# Generated at 2022-06-25 09:54:29.519523
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    host_list = '10.10.2.6, 10.10.2.4'
    inventory = {'vars': {}, 'hosts': ['10.10.2.6', '10.10.2.4']}
    loader = {'host_list': '10.10.2.6, 10.10.2.4'}
    cache = True
    inventory_module.parse(inventory, loader, host_list, cache)

# Generated at 2022-06-25 09:54:33.665295
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # Test with valid host list and non-existent path name
    host_list = '10.10.2.6, 10.10.2.4'
    path = 'hosts'
    loader = None
    inventory = None

    # Call method parse on class InventoryModule
    inventory_module.parse(inventory, loader, host_list, path)


# Generated at 2022-06-25 09:54:36.810075
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = InventoryModule()
    host_list_0 = None
    cache_0 = True

    string_result = inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)
    print(string_result)


# Generated at 2022-06-25 09:54:39.009424
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file("host1.example.com, host2") == True
    assert inventory_module_0.verify_file("10.10.2.6, 10.10.2.4") == True


# Generated at 2022-06-25 09:54:41.452505
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    Test verification of file for InventoryModule
    '''

    # Test inventory_module_0.verify_file(inventory_module_0, host_list)
    test_case_0.verify_file(host_list)

# Generated at 2022-06-25 09:54:47.098707
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    #load tests_cases from ansible/test/units/plugins/inventory/test_host_list.py
    from ansible.test.units.plugins.inventory.test_host_list import cases_parse

    for test_case in cases_parse:
        inventory_module = InventoryModule()

        inventory_module.display = Dictable()
        loader = Dictable()
        inventory = Dictable()
        inventory.add_host = MagicMock()
        inventory.get_group = MagicMock()
        inventory.parse_next_group_data = MagicMock()
        inventory.parse_next_host_data = MagicMock()

        inventory_module.parse(inventory, loader, test_case['host_list'])

        assert inventory_module.get_host_list(inventory) == test_case['hosts']

#

# Generated at 2022-06-25 09:54:51.328823
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory_0 = InventoryManager(loader=None, sources='')
    loader_0 = None
    host_list_0 = ''

    inventory_module_0.parse(inventory_0, loader_0, host_list_0)


# Generated at 2022-06-25 09:54:55.989470
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    res = inventory_module_1.parse('inventory_1', 'loader_1', 'host_list_1')
    assert True == res


# Generated at 2022-06-25 09:54:58.813605
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create object with argument
    inventory_module_0 = InventoryModule()
    inventory_module_0.inventory = type('AnsibleInventory', (object,), {'hosts': {}, 'groups': {}})
    inventory_module_0.inventory.add_host = lambda x, group='ungrouped', port=None: None
    # call parse
    inventory_module_0.parse(inventory_module_0.inventory, None, '10.10.2.6, 10.10.2.4')


# Generated at 2022-06-25 09:55:04.129514
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('test/test') == False
    assert inventory_module_0.verify_file('test/test,') == True

# Generated at 2022-06-25 09:55:22.307262
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list = "10.10.2.6, 10.10.2.4"
    inventory_module_0 = InventoryModule()
    inventory = DummyInventory()
    inventory_module_0.parse(inventory, "loader", host_list)
    assert inventory.hosts == ['10.10.2.6', '10.10.2.4']
    


# Generated at 2022-06-25 09:55:26.058400
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    # This should return True
    assert inventory_module_0.verify_file("10.10.2.6, 10.10.2.4")
    # This should return False
    assert not inventory_module_0.verify_file("host1.example.com")


# Generated at 2022-06-25 09:55:28.877823
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = ""
    loader = ""
    host_list = ""
    cache = True
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, host_list, cache)

# Generated at 2022-06-25 09:55:31.318390
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert(inventory_module_1.verify_file("inventory_hostname") == False)

# If this file is called directly, invoke the module
if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:55:39.231957
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
  inventory_module = InventoryModule()
  inventory = {'all': {'hosts': {}}, '_meta': {'hostvars': {}}}
  loader = {'path_plugins': []}
  host_list = 'host1,host2'
  inventory_module.parse(inventory, loader, host_list)
  assert inventory == {'all': {'hosts': {}}, '_meta': {'hostvars': {}}}
  assert loader == {'path_plugins': []}
  assert host_list == 'host1,host2'
  assert inventory_module is not None


# Generated at 2022-06-25 09:55:49.036141
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert '192.168.10.44,ashish-desktop.local' == '192.168.10.44,ashish-desktop.local'
    assert '192.168.10.93,ashish-laptop.local' == '192.168.10.93,ashish-laptop.local'
    assert inventory_module_0.verify_file('192.168.10.44,ashish-desktop.local') == True
    assert inventory_module_0.verify_file('192.168.10.93,ashish-laptop.local') == True
    assert inventory_module_0.verify_file('192.168.10.47,ashish-desktop.local') == True

# Generated at 2022-06-25 09:55:51.734132
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert inventory_module.parse(None, None, "abc, def") == None
    assert inventory_module.parse(None, None, "abc def") == None
    assert inventory_module.parse(None, None, "abc,def") == None

# Generated at 2022-06-25 09:55:57.681168
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()

    # Case 0:
    # AnsibleError thrown for is_file(host_list)
    host_list_0 = 'host1.example.com,host2,host3'
    result_0 = inventory_module.verify_file(to_bytes(host_list_0, errors='surrogate_or_strict'))
    assert result_0 == True




# Generated at 2022-06-25 09:56:02.699419
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    host_list_0 = ''
    loader_0 = None
    inventory_0 = None
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:56:08.284992
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule() # create object of class InventoryModule
    verify_file_output = inventory_module_0.verify_file(inventory_module_0.verify_file)
    print(verify_file_output)
    assert verify_file_output == 0


# Generated at 2022-06-25 09:56:53.825366
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    host_list_0 = 'fake.localhost'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:57:00.626601
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:57:04.752369
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()
    inventory_module.parse({}, {}, 'localhost')

# Generated at 2022-06-25 09:57:06.001214
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("inventory_module_0", "loader_0", "host_list_0", "cache_0")


# Generated at 2022-06-25 09:57:15.971228
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    new_loader = 'loader'
    new_host_list = 'host_list'
    new_cache = 'cache'
    new_inventory = 'inventory'
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(new_inventory, new_loader, new_host_list, new_cache)
    inventory_module_0.display.verbosity = 3
    inventory_module_0.display.verbose = 3
    inventory_module_0.display.vvv = 3
    new_host_list = 'test_string'
    inventory_module_0.parse(new_inventory, new_loader, new_host_list, new_cache)
    new_host_list = ''
    inventory_module_0.parse(new_inventory, new_loader, new_host_list, new_cache)


# Generated at 2022-06-25 09:57:22.987088
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventoryModule = InventoryModule()
    ansible_inventory = 'Stub'
    ansible_loader = 'Stub'
    ansible_host_list = 'Stub'
    ansible_cache = 'Stub'
    inventoryModule.parse(ansible_inventory, ansible_loader, ansible_host_list, ansible_cache)


# Generated at 2022-06-25 09:57:28.897685
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
        inventory_module_parse = InventoryModule()
        inventory = dict()
        loader = dict()
        host_list = dict()
        cache = dict()
        inventory_module_parse.parse(inventory, loader, host_list, cache)

#Unit test for method verify_file of class InventoryModule

# Generated at 2022-06-25 09:57:31.708891
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory = "inventory"
    loader = "loader"
    host_list = "host_list"
    cache = True

    inventory_module_1.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:57:35.240732
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list = 'foo_host, bar_host'
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(host_list) == True
    loader = None
    inventory = None
    cache = True
    inventory_module_0.parse(inventory, loader, host_list, cache)
    assert inventory_module_0.inventory.hosts.__len__() == 2

# Generated at 2022-06-25 09:57:37.448431
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()

# Generated at 2022-06-25 09:58:34.698312
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse('inventory','loader','host_list')


# Generated at 2022-06-25 09:58:35.682017
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_mock_0 = InventoryModule()
    inventory_mock_0.parse("inventory", "loader", "host_list", True)

# Generated at 2022-06-25 09:58:41.144455
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    host_list = "host1.example.com, host2"
    loader = None
    inventory = {}
    cache = True
    inventory_module_1.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:58:44.581509
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
#    inventory_module_0.parse(inventory, loader, host_list, cache=True)


# Generated at 2022-06-25 09:58:50.272010
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # creating a instance of class InventoryModule
    inventory_module_1 = InventoryModule()

    # creating a instance of class Inventory
    inventory_1 = Inventory()

    # creating a instance of class PluginLoader
    plugin_loader_1 = PluginLoader()

    # creating a instance of class DataLoader
    data_loader_1 = DataLoader()

    # calling parse() with parameters
    inventory_module_1.parse(inventory_1, plugin_loader_1, "localhost")

    # calling parse() with parameters
    inventory_module_1.parse(inventory_1, plugin_loader_1, "host1.example.com, host2")

    # calling parse() with parameters
    inventory_module_1.parse(inventory_1, plugin_loader_1, "10.10.2.6, 10.10.2.4")

# Generated at 2022-06-25 09:58:52.715473
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file(',') == True


# Generated at 2022-06-25 09:59:01.831802
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()

    # A temporary inventory object to assign to InventoryModule
    inventory_0 = {"hosts": [], "all": {"hosts": [], "vars": {}}, "child_groups": [], "vars": {}, "parent": None}
    inventory_0["hosts"].append({"hostname": "hostvars", "vars": {}, "groups": [], "port": 0})
    inventory_0["hosts"].append({"hostname": "set_via_set_variable", "vars": {"a": "1"}, "groups": [], "port": 0})
    # A temporary loader object to assign to InventoryModule

# Generated at 2022-06-25 09:59:04.197550
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    assert inventory_module_1 != False

test_case_0()
test_InventoryModule_parse()

# Generated at 2022-06-25 09:59:10.973118
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # Use a testinventory to parse
    inventory_module.parse('testinventory', 'loader', '10.10.2.6, 10.10.2.4', cache=True)
    # Get the number of hosts in the inventory
    nb_hosts = len(inventory_module.inventory.hosts)
    assert nb_hosts == 2


# Generated at 2022-06-25 09:59:14.135815
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    host_list_1 = None
    loader_1 = None
    inventory_1 = None
    cache_1 = True
    result = inventory_module_1.parse(inventory_1, loader_1, host_list_1, cache_1)