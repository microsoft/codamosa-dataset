

# Generated at 2022-06-25 09:51:00.768425
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert isinstance(inventory_module_0, InventoryModule)
    inventory_module_1 = InventoryModule()
    inventory_module_0.parse(inventory_module_1, loader=None, host_list='10.10.2.6, 10.10.2.4')
    assert isinstance(inventory_module_1, InventoryModule)
    return inventory_module_1

# Generated at 2022-06-25 09:51:03.635849
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    # host_list is of type str
    host_list = '127.0.0.1'
    loader = 'ansible.parsing.dataloader.DataLoader'
    inventory = 'ansible.inventory.manager.InventoryManager'
    cache = 'True'
    assert inventory_module.verify_file(host_list) == True

# Generated at 2022-06-25 09:51:06.015234
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory="inventory", loader="loader", host_list="host_list")

# Generated at 2022-06-25 09:51:10.837170
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
   module = InventoryModule()
   loader = 'test_loader'
   host_list = 'test_host_list'
   cache = 'test_cache'
   # Invoke parse()
   rv = module.parse(host_list, loader, host_list, cache)
   assert rv == None

# Generated at 2022-06-25 09:51:13.208639
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    inventory_module.parse(inventory=None, loader=None, host_list="10.10.2.6, 10.10.2.4", cache=True)

# Generated at 2022-06-25 09:51:19.312125
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Case 1:
    # Testing when no hosts are provided in the string

    # Set up variables for test
    inventory = None
    loader = None
    host_list = ""
    cache = True

    # Call method under test with set up parameters
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, host_list, cache)

    # Check assert statements
    assert inventory_module_1.inventory == inventory
    assert inventory_module_1.loader == loader
    assert inventory_module_1.host_list == host_list
    assert inventory_module_1.inventory_basedir == ''
    assert inventory_module_1.cache == cache

    assert inventory_module_1.inventory.hosts is not None
    assert inventory_module_1.inventory.groups is not None
    assert inventory_module

# Generated at 2022-06-25 09:51:20.703362
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
# no test case generated for parse
    return None

# Generated at 2022-06-25 09:51:23.264377
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mod = InventoryModule()
    inventory = '10.10.2.6, 10.10.2.4'
    loader = 'AnsibleModule'
    host_list = '10.10.2.6, 10.10.2.4'
    cache = True
    inv_mod.parse(inventory, loader, host_list, cache)

# Generated at 2022-06-25 09:51:31.807910
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()

    # Test with bad host_list
    host_list = ''
    try:
        inventory_module_0.parse(host_list)
        assert False
    except AnsibleParserError:
        assert True

    host_list = 'a b c'
    try:
        inventory_module_0.parse(host_list)
        assert False
    except AnsibleParserError:
        assert True

    host_list = 'a, b, c'
    try:
        inventory_module_0.parse(host_list)
        assert False
    except AnsibleParserError:
        assert True

    # Test good host_list
    host_list = 'a,b,c'

# Generated at 2022-06-25 09:51:34.010151
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i = InventoryModule()
    i.parse(1, 2, "one, two, three")
    assert(i.get_hosts('all')) == ['one', 'two', 'three']

# Generated at 2022-06-25 09:51:42.221330
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {'_meta': {'hostvars': {}}}
    loader = {'path': None}
    host_list = 'a,b,c'

    inventory_module.parse(inventory, loader, host_list)

    assert inventory == {'all': {'hosts': ['a', 'b', 'c']}, '_meta': {'hostvars': {}}, 'ungrouped': {'hosts': ['a', 'b', 'c']}}

# Generated at 2022-06-25 09:51:44.245635
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory_module_parse.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:51:47.857402
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    ansible_inventory_0 = ansible_inventory()
    loader_0 = loader()
    str_0 = str()
    bool_0 = False
    inventory_module_0.parse(ansible_inventory_0, loader_0, str_0, bool_0)


# Generated at 2022-06-25 09:51:52.059741
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0.inventory
    loader_0 = inventory_module_0.loader
    host_list_0 = inventory_module_0.host_list
    # call method parse of class InventoryModule
    InventoryModule.parse(inventory_module_0, inventory_0, loader_0, host_list_0)


# Generated at 2022-06-25 09:51:56.488725
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host_list = ''
    inventory = None
    loader = None
    cache = None

    inventory_module_0 = InventoryModule()
    try:
        assert inventory_module_0.parse(inventory, loader, host_list, cache) == None
    except AnsibleParserError as e:
        raise AssertionError(e)


# Generated at 2022-06-25 09:52:01.264065
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Test for parse of class InventoryModule"""
    inventory_module_0 = InventoryModule()
    test = inventory_module_0.parse("", None, "localhost,")
    assert test == "localhost"

test_case_0()

# Generated at 2022-06-25 09:52:04.373333
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    host_list = "host.example.com, host2.example.com"
    inventory = object
    loader = object
    cache = True
    inventory_module_0.parse(inventory, loader, host_list, cache)


# Generated at 2022-06-25 09:52:06.692092
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = None
    loader = None
    host_list = 'localhost, localhost'
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory, loader, host_list, cache=True)


# Generated at 2022-06-25 09:52:16.380440
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    dummy_inventory_0 = dict()
    dummy_loader_0 = dict()
    dummy_host_list_0 = u'localho'
    inventory_module_1.parse(dummy_inventory_0, dummy_loader_0, dummy_host_list_0, cache=True)
    dummy_inventory_1 = dict()
    dummy_inventory_1['_meta'] = dict()
    dummy_inventory_1['_meta']['hostvars'] = dict()
    dummy_inventory_1['_meta']['hostvars']['localhost'] = dict()
    dummy_inventory_1['_meta']['hostvars']['localhost']['ansible_connection'] = u'local'

# Generated at 2022-06-25 09:52:20.691434
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    class_inventory_0 = MockInventory()
    class_loader_0 = MockLoader()
    inventory_module_0.parse(class_inventory_0, class_loader_0, 'localhost,')
    inventory_module_0.parse(class_inventory_0, class_loader_0, 'localhost, localhost,')
    inventory_module_0.parse(class_inventory_0, class_loader_0, 'localhost')
    inventory_module_0.parse(class_inventory_0, class_loader_0, 'localhost, localhost')


# Generated at 2022-06-25 09:52:29.273843
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()

    inventory = {'hosts': []}

    host_list = '10.10.2.6, 10.10.2.4'
    inventory_module.parse(inventory, None, host_list)

    assert inventory['hosts'] == [('10.10.2.6', None), ('10.10.2.4', None)]

# Generated at 2022-06-25 09:52:31.970825
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('10.10.2.6, 10.10.2.4')


# Generated at 2022-06-25 09:52:40.023475
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()

    # Test case with one host

    test_host_list = "10.10.2.6"

    inventory_module_0.parse(inventory_module_0.inventory, inventory_module_0.loader, test_host_list, cache=True)

    assert("10.10.2.6" in inventory_module_0.inventory.hosts)

    assert("10.10.2.6" in inventory_module_0.inventory.get_hosts("all"))

    assert("10.10.2.6" in inventory_module_0.inventory.get_hosts(""))

    assert("10.10.2.6" in inventory_module_0.inventory.get_hosts("ungrouped"))

    # Test case with two hosts

    # Reset the list of hosts

    inventory

# Generated at 2022-06-25 09:52:46.397226
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert callable(InventoryModule.parse)
    inventory_module_1 = InventoryModule()
    h_list = "192.168.0.0/16,10.10.2.6, 10.10.2.4"
    assert inventory_module_1.verify_file(h_list)
    loader_arg = None
    cache_arg = True
    inventory_arg = None
    result = inventory_module_1.parse(inventory_arg, loader_arg, h_list, cache_arg)
    assert result is None


# Generated at 2022-06-25 09:52:48.684591
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    assert inventory_module_2.parse('inventory', 'loader', 'host_list')

# Generated at 2022-06-25 09:52:51.571757
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object
    loader_0 = object
    host_list_0 = ''
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)

# Generated at 2022-06-25 09:53:02.778385
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test for InventoryModule.parse - when the host_list contains a path,
    # _parse_host_list should not be called

    # instantiate InventoryModule
    inventory_module = InventoryModule()
    
    # make class inventory as an object
    class inventory:
        
        # make class host as an object
        class host:
            def __init__(self):
                self.set_variable = []
            def add_host(self, host, group='ungrouped', port=None):
                self.set_variable = [host, group, port]

        def __init__(self):
            self.set_variable = []
            self.hosts = self.host()
            
    # test parse method using the above objects
    inventory_module.parse(inventory(), [], '/path/to/hosts', False)
    


# Generated at 2022-06-25 09:53:07.598729
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    arg_0 = None
    arg_1 = None
    arg_2 = "10.10.2.6, 10.10.2.4"
    arg_3 = True
    inventory_module_0.parse(arg_0, arg_1, arg_2, cache=arg_3)


# Generated at 2022-06-25 09:53:11.017958
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory = None
    loader = None
    host_list = None
    cache = None
    assert inventory_module_1.parse(inventory, loader, host_list, cache) == None


# Generated at 2022-06-25 09:53:15.487296
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object
    loader_0 = object
    host_list_0 = '_'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:53:30.298954
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # make inventory object with localhost
    ih = InventoryModule()

    test_gh = "localhost"

    # add group to inventory
    ih.parse(
        inventory=None,
        loader=None,
        host_list=test_gh,
        cache=True
    )

    # check that host has been added to group
    assert ih.inventory.get_groups_dict()['ungrouped']['hosts'][0]['name'] == 'localhost'


# Generated at 2022-06-25 09:53:35.015116
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = inventory_module_1.parse(inventory_module_1, None, "10.10.2.6, 10.10.2.4", cache=True)
    assert inventory.hosts == {'10.10.2.6': {'groups': ['ungrouped'], 'vars': {}}, '10.10.2.4': {'groups': ['ungrouped'], 'vars': {}}}, "parse() failed"


# Generated at 2022-06-25 09:53:45.966476
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test the case where we create a hostlist plugin
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list)
    # Test the case where we create a hostlist plugin
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list)
    # Test the case where we create a hostlist plugin
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list)
    # Test the case where we create a hostlist plugin
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, host_list)
    # Test the case where we create a hostlist plugin
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:53:56.553286
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    arg_0 = MockInventory()
    arg_1 = Mock()
    arg_2 = 'str_0'
    arg_3 = False

    with patch('ansible.parsing.utils.addresses.parse_address', new=Mock(side_effect=AnsibleError("An exception occurred"))):
        # Exception raised in parse_address in parse_address
        inventory_module_0.parse(arg_0, arg_1, arg_2, arg_3)


# Generated at 2022-06-25 09:54:03.304903
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import re
    import os
    import sys
    import tempfile
    temp = tempfile.mkdtemp(prefix="ansible-test-plugin")
    ansible_file = os.path.join(temp, 'ansible.cfg')
    with open(ansible_file, "w") as f:
        f.write("""[defaults]\n""")
    os.environ['ANSIBLE_CONFIG'] = ansible_file
    try:
        inv_module = InventoryModule()
        inv_module.parse("")
    finally:
        os.remove(ansible_file)
        os.removedirs(temp)

# Generated at 2022-06-25 09:54:06.140208
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inv_1 = inventory_module_1.parse(inventory=None, loader=None, host_list=None, cache=True)


# Generated at 2022-06-25 09:54:12.609250
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert [inventory_module_1.parse(), inventory_module_1.parse(inventory=None, loader=None, host_list='1.1.1.1', cache=True), inventory_module_1.parse(inventory=None, loader=None, host_list='1.1.1.1', cache=False)] == [[], [], []]

# Generated at 2022-06-25 09:54:22.881122
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    test_data = 'test_data'
    inventory = []
    loader = []
    host_list = 'host_list'
    
    # Case 0:
    # test_data = 'test_data'
    # inventory = []
    # loader = []
    # host_list = 'host_list'
    res0 = inventory_module_0.parse(inventory, loader, host_list)
    
    # Case 1
    # test_data = 'test_data'
    # inventory = []
    # loader = []
    # host_list = 'host_list'
    res1 = inventory_module_0.parse(inventory, loader, host_list)
    
    # Case 2
    # test_data = 'test_data'
    # inventory = []
    #

# Generated at 2022-06-25 09:54:29.731926
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(None, '', '''
    {
      "all": {
        "hosts": [
          "10.10.2.4",
          "10.10.2.6"
        ],
        "vars": {
          "ansible_ssh_user": "ansible"
        }
      }
    }
    ''')


# Generated at 2022-06-25 09:54:32.145401
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    assert inventory_module_parse.verify_file('host1.example.com,host2')
    assert inventory_module_parse.verify_file('localhost,')

# Generated at 2022-06-25 09:54:48.594168
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Validate parse method of class InventoryModule"""

    # Case 0: empty host_list
    inventory_module_0 = InventoryModule()
    result = inventory_module_0.parse('', '', '')
    assert isinstance(result, bool) and result is True

    # Case 1: empty host_list
    inventory_module_1 = InventoryModule()
    result = inventory_module_1.parse('', '', ' ')
    assert isinstance(result, bool) and result is True

    # Case 2: empty host_list
    inventory_module_2 = InventoryModule()
    result = inventory_module_2.parse('', '', ',')
    assert isinstance(result, bool) and result is True

    # Case 3: empty host_list
    inventory_module_3 = InventoryModule()
    result = inventory_module_3

# Generated at 2022-06-25 09:54:52.443572
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Mock_inventory()
    loader_0 = Mock_loader()
    args = (inventory_0, loader_0, '10.10.2.6, 10.10.2.4')
    inventory_module_0.parse(*args)


# Generated at 2022-06-25 09:54:57.931406
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory

    host_list = '10.10.2.6, 10.10.2.4'
    inventory_module_0 = InventoryModule()

    loader = DataLoader()
    inventory = Inventory(loader=loader)
    inventory_module_0.parse(inventory, loader, host_list, cache=True)
    assert len(inventory.get_hosts()) == 2

# Generated at 2022-06-25 09:55:06.175393
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    test_case = '''
[all]
test1
test2
'''
    inventory_module = InventoryModule()
    inventory =  {}
    loader = None
    host_list = 'test_host_1, test_host_2'

    inventory_module.parse(inventory, loader, host_list)

    if host_list in to_text(inventory):
        assert True
    elif host_list not in to_text(inventory):
        assert False


# Generated at 2022-06-25 09:55:09.354726
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory=inventory_module, loader=None, host_list='localhost, 127.0.0.1')

# Generated at 2022-06-25 09:55:15.100710
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    module_input_0 = 'test/test_ansible_host_list_0.txt'
    inventory_module.parse(None, None, module_input_0)
    assert True


# Generated at 2022-06-25 09:55:19.073037
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory_module_0, loader, host_list)

# Generated at 2022-06-25 09:55:20.976481
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:55:27.290029
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    inventory_module_1.parse('foo')

    inventory_module_2 = InventoryModule()
    inventory_module_2.parse('foo', cache=True)

    inventory_module_3 = InventoryModule()
    inventory_module_3.parse('foo', cache=False)


# Generated at 2022-06-25 09:55:30.586490
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = ''
    loader_0 = ''
    host_list_0 = ''
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)


# Generated at 2022-06-25 09:55:38.762347
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('inventory', loader=None, host_list='host_list', cache=True)
    return inventory_module_0

# Generated at 2022-06-25 09:55:43.662949
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inv = MagicMock()
    inv.add_host.return_value = None
    loader = MagicMock()
    inventory_module_0.parse(inv, loader, "192.168.0.1")

# Generated at 2022-06-25 09:55:48.972662
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory=None, loader=None, host_list='localhost,')


# Generated at 2022-06-25 09:55:53.335861
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Setup
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse({
        'hosts': {},
    }, {
        'get_basedir': lambda path: ''
    }, '10.10.2.6, 10.10.2.4')
    assert '10.10.2.6' in inventory_module_1.inventory.hosts
    assert '10.10.2.4' in inventory_module_1.inventory.hosts


# Generated at 2022-06-25 09:55:57.621153
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule.Inventory(loader='loader_0')
    loader_0 = InventoryModule.Loader()
    host_list = 'host_list_0'
    cache_0 = True
    inventory_module_0.parse(inventory_0, loader_0, host_list, cache=cache_0)

# Generated at 2022-06-25 09:56:02.656767
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    hl = ""
    inv = None
    loader = None
    host_list = "10.10.2.6, 10.10.2.4"
    cache = True
    InventoryModule().parse(inv, loader, host_list, cache)

if __name__ == '__main__':
    pass

# Generated at 2022-06-25 09:56:05.874891
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    result = InventoryModule.parse(['localhost'])
    assert result == 'localhost'

# Generated at 2022-06-25 09:56:15.791578
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = {}
    loader_0 = {}
    host_list_0 = 'a'

    inventory_module_0.parse(inventory_0, loader_0, host_list_0)

test_case_1_host_list_0 = ''
test_case_1_host_list_1 = ''
test_case_1_host_list_2 = ''
test_case_1_host_list_3 = ''
test_case_1_host_list_4 = ''
test_case_1_host_list_5 = ''
test_case_1_host_list_6 = ''
test_case_1_host_list_7 = ''
test_case_1_host_list_8 = ''

# Generated at 2022-06-25 09:56:21.192289
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert 'host_list' == inventory_module_0.NAME
    assert 'parse' == inventory_module_0.parse.__name__
    assert 0 == inventory_module_0.parse.__code__.co_argcount
    assert 'parse' == inventory_module_0.parse.__qualname__
    assert inventory_module_0.parse.__module__ == 'ansible.plugins.inventory.host_list'

# Generated at 2022-06-25 09:56:24.762387
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()
    assert inventory_module_1.parse([], [], ["localhost,"])


# Generated at 2022-06-25 09:56:34.909570
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_1 = InventoryModule()

    # execute the tested method
    inventory_module_1.parse(inventory="inventory", loader="loader", host_list="host_list", cache=True)



# Generated at 2022-06-25 09:56:39.599120
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    host_list = "localhost,"
    inventory = "inventory"
    loader = "loader"
    cache = "cache"
    result = inventory_module_0.parse(inventory,loader,host_list,cache)
    assert (result is None)


# Generated at 2022-06-25 09:56:43.890698
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    host_list = "10.10.2.6, 10.10.2.4"
    inventory = ""
    inventory_module_parse.parse(inventory,None,host_list)

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:56:44.425797
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-25 09:56:51.879751
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_1 = object()
    loader_1 = object()
    host_list_1 = "10.10.2.6, 10.10.2.4"
    cache_1 = True
    assert inventory_module_0.parse(inventory_1, loader_1, host_list_1, cache_1) == 'inventory_1.hosts'


# Generated at 2022-06-25 09:56:54.056547
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.parse(inventory="ansible.inventory.manager.InventoryManager", loader="ansible.parsing.dataloader.DataLoader", host_list="localhost,", cache=True) is None

# Generated at 2022-06-25 09:56:56.658504
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1._inventory = "TEST_INVENTORY"
    inventory_module_1.parse(inventory_module_1._inventory, "TEST_LOADER", "TEST_HOST_LIST", False)


# Generated at 2022-06-25 09:57:02.028122
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    #this is the inventory
    inventory_module = InventoryModule()

    #this is a list of required variables to pass to the plugin
    loader = None
    host_list = "192.168.10.10,192.168.10.1"

    #this will populate the inventory
    inventory_module.parse(inventory_module, loader, host_list)

    #this will get the list of all hosts in the inventory
    inventory = sorted(inventory_module.hosts.keys())

    #this variable is the expected output
    expected = ["192.168.10.1","192.168.10.10"]

    if inventory != expected:
        print("Unit test failed!")

# Generated at 2022-06-25 09:57:03.185951
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.parse("inventory", "loader", "host_list")

# Generated at 2022-06-25 09:57:06.290129
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = type('',(),{ "hosts":{}, "add_host": lambda self, a,b,c: self.hosts.update({a: c})})()
    inventory_module_1.parse(inventory_1, None, "10.10.2.6, 10.10.2.4")
    assert inventory_1.hosts == {'10.10.2.6': {'ansible_inventory_port':None}, '10.10.2.4': {'ansible_inventory_port':None}}


# Generated at 2022-06-25 09:57:22.713440
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    inventory = ""
    loader = ""
    host_list = ""
    cache = ""
    result = inventory_module_parse.parse(inventory, loader, host_list, cache)
    assert result == None


# Generated at 2022-06-25 09:57:29.027968
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    host_list = "foo.com, bar.com"
    inventory_module_0.parse(host_list)
    assert inventory_module_0.inventory.hosts["foo.com"]
    assert inventory_module_0.inventory.hosts["bar.com"]



# Generated at 2022-06-25 09:57:33.077854
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    test_inventory_0 = inventory_module_0
    test_loader_0 = inventory_module_0
    test_host_list_0 = ','
    test_cache_0 = True
    inventory_module_0.parse(test_inventory_0, test_loader_0, test_host_list_0, test_cache_0)


# Generated at 2022-06-25 09:57:37.856382
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, 'host_list', cache=False)

# Generated at 2022-06-25 09:57:41.135639
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_module.inventory = MockInventory([])
    inventory_module.display = MockDisplay()
    inventory_module.parse("", None, '10.10.2.6, 10.10.2.4')


# Generated at 2022-06-25 09:57:46.971808
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    host_list_0 = str()
    cache_0 = object()

    # Invoke method
    answer = inventory_module_0.parse(inventory_0, loader_0, host_list_0, cache_0)

    assert answer is None


# Generated at 2022-06-25 09:57:51.954771
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    mock_inventory_1 = ["localhost", "test"]
    host_list_1 = "localhost, test"
    inventory_module_1.parse(mock_inventory_1, "", host_list_1, True)
    assert mock_inventory_1 == ["localhost", "test"]


# Generated at 2022-06-25 09:57:58.547808
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    inventory_module_1.parse(inventory_module_1.inventory, loader=inventory_module_1.loader, host_list='localhost,')

    assert inventory_module_1.inventory.hosts == {'localhost': {'hostname': 'localhost', 'vars': {}}}
    assert inventory_module_1.inventory._vars == {}

# Generated at 2022-06-25 09:58:01.651310
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    real_inventory = inventory_module.inventory
    host_list = '10.10.2.6, 10.10.2.4'
    inventory_module.parse(real_inventory, None, host_list, cache=True)

# Generated at 2022-06-25 09:58:06.503192
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = inventory_module_0
    loader_0 = inventory_0
    host_list_0 = '10.10.2.6, 10.10.2.4'
    inventory_module_0.parse(inventory_0, loader_0, host_list_0)
    print('Hosts: {0}'.format(inventory_0.hosts))


# Generated at 2022-06-25 09:58:39.768741
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = object()
    loader = object()
    host_list = '10.10.2.6, 10.10.2.4'
    cache = True
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, host_list, cache)

# Generated at 2022-06-25 09:58:44.860276
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse(inventory=None, loader=None, host_list=None, cache=True)


# Generated at 2022-06-25 09:58:53.691084
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = "inventory_0"
    # Invalid parameters for method 'parse' of class 'InventoryModule'
    assert_raises(AnsibleParserError, inventory_module_0.parse, inventory_0)
    inventory_module_0.parse(inventory_0, loader="loader_0", host_list="host_list_0", cache="cache_0")


# Generated at 2022-06-25 09:59:02.868880
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    host_list_0 = '10.10.2.5,10.10.2.6'
    cache_0 = True

    # Testing the type of an if condition (line 129)
    if hasattr(inventory_module_0, 'parse') and callable(inventory_module_0.parse):
        
        # Assigning a Attribute to a Name (line 129)
        # Getting the type of 'inventory_module_0' (line 129)
        inventory_module_0_type_1 = module_type_store.get_type_of(stypy.reporting.localization.Localization(__file__, 129, 18), 'inventory_module_0')
        # Obtaining the member 'parse' of a type (line 129

# Generated at 2022-06-25 09:59:12.955914
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    yml_file = """
    hosts:
      host1:
      host2:
    """

    inv_file = """
    [group1]
    host1 ansible_port=2222

    [group2]
    host2
    """

    for host_list in ('host1,host2', 'host2,host1', 'host1, host2', 'host2, host1', 'host2, host1, host2'):
        inventory_module_0 = InventoryModule()
        inventory = inventory_module_0.parse(loader=None, host_list=host_list, cache=False)
        assert inventory.hosts['host1'] == 'host1'
        assert inventory.hosts['host2'] == 'host2'


# Generated at 2022-06-25 09:59:20.867396
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory = "127.0.0.1"
    loader = ""
    host_list = "127.0.0.1"
    cache = "127.0.0.1"

    inventory_module_0 = InventoryModule()
    if inventory_module_0.verify_file(host_list):
        ret_val = inventory_module_0.parse(inventory, loader, host_list, cache)
        assert ret_val is None
    else:
        print("Test case in not applicable")


# Generated at 2022-06-25 09:59:26.081103
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    #Invoking parse method with below args
    #inventory_module_0.parse(inventory, loader, host_list, cache=True)

# Generated at 2022-06-25 09:59:32.171582
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    assert( type(inventory_module_0.parse(inventory = 'Some inventory', loader = 'Some loader', host_list = 'Some host_list', cache = True)) == None)


# Generated at 2022-06-25 09:59:40.468403
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_1 = InventoryModule()
    inventory_module_2 = InventoryModule()
    inventory_module_3 = InventoryModule()
    inventory_module_4 = InventoryModule()
    inventory_module_5 = InventoryModule()
    inventory_module_6 = InventoryModule()
    inventory_module_7 = InventoryModule()
    inventory_module_8 = InventoryModule()

    try:
        inventory_module_0.parse(inventory=inventory_module_1, loader=inventory_module_2, host_list=inventory_module_3)
    except Exception as e:
        assert False


# Generated at 2022-06-25 09:59:43.496754
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    host_list_0 = ':'
    inventory_module_0.parse(inventory_0, loader_0, host_list_0)



# Generated at 2022-06-25 10:00:47.493940
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert True == inventory_module.verify_file(test1)
#
test1 = "'test1', 'test2'"