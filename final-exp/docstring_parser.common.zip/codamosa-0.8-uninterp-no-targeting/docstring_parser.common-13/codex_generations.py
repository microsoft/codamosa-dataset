

# Generated at 2022-06-21 11:34:18.384662
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta."""
    args = ['arg']
    description = 'description'
    dm = DocstringMeta(args, description)
    assert dm is not None
    assert dm.args == args
    assert dm.description == description


# Generated at 2022-06-21 11:34:21.570344
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    import pytest
    x = DocstringRaises(args=["first","second"], description="asdf", type_name="int")
    assert x.args == ["first","second"]
    assert x.description == "asdf"
    assert x.type_name == "int"



# Generated at 2022-06-21 11:34:27.227118
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(['Type'], 'Desc', 'arg_name', 'str', True, "none")

    assert doc.description == 'Desc'
    assert doc.arg_name == 'arg_name'
    assert doc.type_name == 'str'
    assert doc.is_optional == True
    assert doc.default == "none"


# Generated at 2022-06-21 11:34:28.660994
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert(err.args == ())

# Generated at 2022-06-21 11:34:31.115784
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args=["yields"], description="The next number.", type_name="int", is_generator=True)


# Generated at 2022-06-21 11:34:40.133964
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    class DocstringParam:
        def __init__(
                self,
                args: T.List[str],
                description: T.Optional[str],
                arg_name: str,
                type_name: T.Optional[str],
                is_optional: T.Optional[bool],
                default: T.Optional[str],
        ):
            super().__init__(args, description)
            self.arg_name = arg_name
            self.type_name = type_name
            self.is_optional = is_optional
            self.default = default

    print(DocstringParam(["1", "2"], "123", "123", "123", False, None).args)
    print(DocstringParam(["1", "2"], "123", "123", "123", False, None).description)

# Generated at 2022-06-21 11:34:49.867789
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # mypy not recognizing imported class DocstringParam
    # noinspection PyTypeHints
    assert DocstringParam
    assert type(DocstringParam.__init__) == function
    param = DocstringParam(["param"], None, "arg", "type", "is_optional", "default")
    assert type(param) == DocstringParam
    assert param.args == ["param"]
    assert param.description == None
    assert param.arg_name == "arg"
    assert param.type_name == "type"
    assert param.is_optional == "is_optional"
    assert param.default == "default"


# Generated at 2022-06-21 11:34:53.248948
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert(DocstringParam(["param"], "type_name", "arg_name", "type_name", None, None).type_name == "type_name")


# Generated at 2022-06-21 11:34:56.797710
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(
        args=["deprecated"],
        description="use ...",
        version="0.5.0"
    )
    assert d.args == ["deprecated"]
    assert d.description == "use ..."
    assert d.version == "0.5.0"

# Generated at 2022-06-21 11:35:01.490247
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args = ['info'], description = 'This function is deprecated.', version = '0.0.1')
    assert a.args[0] == 'info'
    assert a.description == 'This function is deprecated.'
    assert a.version == '0.0.1'

# Generated at 2022-06-21 11:35:09.978252
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
  # initialization of class DocstringMeta
  dm = DocstringMeta(args = ['class', 'object', 'instance'], description = 'a new class')

  # list of arguments
  assert dm.args == ['class', 'object', 'instance']

  # description
  assert dm.description == 'a new class'


# Generated at 2022-06-21 11:35:15.758243
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_DocstringParam = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert test_DocstringParam.args == []
    assert test_DocstringParam.description == ""
    assert test_DocstringParam.arg_name == ""
    assert test_DocstringParam.type_name == ""
    assert test_DocstringParam.is_optional == ""


# Generated at 2022-06-21 11:35:18.226854
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("A parse error occurred.");
    assert pe.args[0] == "A parse error occurred."


# Generated at 2022-06-21 11:35:20.879752
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['3args']
    res = DocstringReturns(args, 'haha', 'int', True)
    assert res.args == args
    assert res.type_name == 'int'
    assert res.is_generator == True
    assert res.return_name == None
    assert res.description == 'haha'
    assert len(res.__dict__) == 5


# Generated at 2022-06-21 11:35:25.113223
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args=['deprecated', 'since', 'version', '2.2.0'], description=None, version='2.2.0')
    assert d.args == ['deprecated', 'since', 'version', '2.2.0']


# Generated at 2022-06-21 11:35:31.835559
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    arg_name = "arg"
    type_name = "type"
    is_optional = False
    default = "default"
    description = "description"

    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-21 11:35:40.237583
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['some', 'args']
    description = ''
    type_name = ''
    is_generator = True
    return_name = None
    docstring_return = DocstringReturns(args, description, type_name, is_generator, \
                                        return_name)
    assert docstring_return.args == args
    assert docstring_return.description == description
    assert docstring_return.type_name == type_name
    assert docstring_return.is_generator == is_generator
    assert docstring_return.return_name == return_name



# Generated at 2022-06-21 11:35:42.315682
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("msg")
    assert str(e) == "msg"


# Generated at 2022-06-21 11:35:45.212012
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj = DocstringRaises(['param'], None, None)
    assert obj.args == ['param']
    assert obj.description is None
    assert obj.type_name is None


# Generated at 2022-06-21 11:35:46.629435
# Unit test for constructor of class ParseError
def test_ParseError():
    if not issubclass(ParseError, RuntimeError):
        raise AssertionError()

# Generated at 2022-06-21 11:35:54.743789
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    result = DocstringDeprecated(
        args=['deprecated', 'since', '1.3.0'],
        description=None,
        version=None)

    assert result is not None


# Generated at 2022-06-21 11:35:59.546639
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([], 'description', 'type_name', True)
    assert a.description == 'description'
    assert a.type_name == 'type_name'
    assert a.is_generator == True
    assert a.return_name == None



# Generated at 2022-06-21 11:36:05.303378
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args=['param','name']
    description='The name of the instance.'

    dm=DocstringMeta(args,description)
    print('\n')
    print("-------------------")
    print("Test for DocstringMeta")
    print("-------------------")
    print("args is:")
    print(dm.args)
    print("description is:")
    print(dm.description)


# Generated at 2022-06-21 11:36:06.662002
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # assert DocstringDeprecated([],[],"") == None
    pass


# Generated at 2022-06-21 11:36:12.699896
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None



# Generated at 2022-06-21 11:36:17.311348
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = "test description"
    type_name = "test_type"
    doc_string = DocstringRaises(args, description, type_name)

    assert doc_string.args is args
    assert doc_string.description is description
    assert doc_string.type_name is type_name
    return



# Generated at 2022-06-21 11:36:25.244677
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:36:32.900199
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for Docstring"""
    d = Docstring()
    assert(d.short_description == None)
    assert(d.long_description == None)
    assert(d.blank_after_short_description == False)
    assert(d.blank_after_long_description == False)
    assert(d.meta == [])
    assert(d.params == [])
    assert(d.raises == [])
    assert(d.returns == None)
    assert(d.deprecation == None)

# Generated at 2022-06-21 11:36:41.977533
# Unit test for constructor of class Docstring
def test_Docstring():
    test1 = Docstring()
    test2 = Docstring()
    assert(test1.short_description == None)
    assert(test2.short_description == None)
    assert(test1.long_description == None)
    assert(test2.long_description == None)

# Generated at 2022-06-21 11:36:43.098558
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print(DocstringParam)



# Generated at 2022-06-21 11:36:51.971118
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-21 11:36:56.069579
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['a', 'b']
    description = 'd'
    a = DocstringMeta(args, description)
    assert a.args == ['a', 'b']
    assert a.description == 'd'


# Generated at 2022-06-21 11:36:57.532093
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "description")


# Generated at 2022-06-21 11:37:04.475494
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_int_docstring = DocstringReturns(
        args=["returns"],
        description="Return a number of type int.",
        type_name="int",
        is_generator=False,
    )
    assert isinstance(return_int_docstring, DocstringMeta)
    assert return_int_docstring.description == "Return a number of type int."

# Generated at 2022-06-21 11:37:06.335618
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param", "arg"], "The argument is a number", "arg", "int", True, "0")

# Generated at 2022-06-21 11:37:08.735409
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=["Hello", "World"], description="test", arg_name="test", type_name="str", is_optional=True, default="Hi")


# Generated at 2022-06-21 11:37:12.408930
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [":raises"]
    description = "Test description"
    type_name = "TypeName"
    raises = DocstringRaises(args, description, type_name)
    assert raises.args == [":raises"]
    assert raises.description == "Test description"
    assert raises.type_name == "TypeName"


# Generated at 2022-06-21 11:37:13.153341
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    raise NotImplementedError()

# Generated at 2022-06-21 11:37:17.033783
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'since', '1.2']
    description = 'This function is deprecated.'
    version = '1.2'
    obj = DocstringDeprecated(args, description, version)
    assert obj.args == args
    assert obj.description == description
    assert obj.version == version


# Generated at 2022-06-21 11:37:18.948112
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    x = DocstringMeta([], "test")
    assert x.args == []
    assert x.description == "test"


# Generated at 2022-06-21 11:37:29.234556
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return DocstringReturns(["returns","return","bla bla"],None,None)


# Generated at 2022-06-21 11:37:30.940232
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], " ", " ", " ", True, " ")


# Generated at 2022-06-21 11:37:37.107217
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'version', 'desc']
    Description = 'this function is deprecated'
    version = '8.0'
    test_metadata = DocstringDeprecated(args, Description, version)
    assert test_metadata.args == args
    assert test_metadata.description == Description
    assert test_metadata.version == version


# Generated at 2022-06-21 11:37:41.580474
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description == None
    assert test_docstring.long_description == None
    assert test_docstring.blank_after_short_description == False
    assert test_docstring.blank_after_long_description == False
    assert test_docstring.meta == []



# Generated at 2022-06-21 11:37:45.886378
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-21 11:37:51.323494
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    Test that errors are thrown when passing invalid values to the ParseError constructor.
    """
    try:
        raise ParseError('Invalid docstring: Missing colon at line 2.')
    except ParseError:
        pass
    except:
        raise AssertionError('Failed to throw ParseError exception.')


# Generated at 2022-06-21 11:37:57.723525
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['param', 'arg'], 'description of test')
    output = 'DocstringMeta(args=\'' + str(docstring_meta.args) + '\', description=\'' \
        + str(docstring_meta.description) + '\')'
    print(output)
    assert output == 'DocstringMeta(args=[\'param\', \'arg\'], description=\'description of test\')'


# Generated at 2022-06-21 11:38:00.550345
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('TEST')
    except ParseError:
        pass
    except Exception:
        assert False, 'Exception'


# Generated at 2022-06-21 11:38:02.854102
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([], '')
    assert a.args == []
    assert a.description == ''


# Generated at 2022-06-21 11:38:08.227029
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test normal case
    try:
        raise ParseError("This is a test")
    except ParseError:
        pass

    # Test null input
    try:
        ParseError(None)
    except:
        pass
    try:
        raise ParseError(None)
    except ParseError:
        pass


# Generated at 2022-06-21 11:38:28.164753
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test1 = DocstringMeta(args=['tester'], description='testing')
    assert test1.args == ['tester']
    assert test1.description == 'testing'
    

# Generated at 2022-06-21 11:38:30.837542
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(None, None, None)
    assert docstringRaises.type_name == None
    assert docstringRaises.description == None
    assert docstringRaises.args == None


# Generated at 2022-06-21 11:38:40.012915
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    from darglint.parser import DocstringDeprecated
    # check with description
    assert (
        str(
            DocstringDeprecated(
                args=["deprecated", "since", "version", "1.0"],
                description="use ``something`` instead",
                version="1.0",
            )
        )
        == 'Deprecated since version 1.0: use ``something`` instead'
    )
    # check without description
    assert (
        str(
            DocstringDeprecated(
                args=["deprecated", "since", "version", "1.0"],
                description=None,
                version="1.0",
            )
        )
        == 'Deprecated since version 1.0'
    )

# Generated at 2022-06-21 11:38:43.606460
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    item = DocstringDeprecated(["hello"], "world", "1.0")
    assert item.args[0] == "hello"
    assert item.description == "world"
    assert item.version == "1.0"

# Generated at 2022-06-21 11:38:47.837817
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError as e:
        assert(e != None)
    try:
        raise ParseError(None)
    except ParseError as e:
        assert(e == None)


# Generated at 2022-06-21 11:38:52.981315
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["raises", "ValueError"], "description", None, False)
    assert ds.args == ["raises", "ValueError"]
    assert ds.description == "description"
    assert ds.type_name is None
    assert ds.is_generator is False
    assert ds.return_name is None


if __name__ == "__main__":
    # Test for constructor
    test_DocstringReturns()

# Generated at 2022-06-21 11:38:54.142819
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        return 1
    return 0



# Generated at 2022-06-21 11:38:55.183140
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns(["args"], "description", "int")
    assert doc.type_name == 'int'

# Generated at 2022-06-21 11:38:56.230797
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(Docstring())


# Generated at 2022-06-21 11:39:01.361050
# Unit test for constructor of class Docstring
def test_Docstring():
    temp = Docstring()
    assert temp.short_description == None
    assert temp.long_description == None
    assert temp.params == []
    assert temp.raises == []
    assert temp.returns == None
    assert temp.deprecation == None


# Generated at 2022-06-21 11:39:50.735443
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    report = 'DocstringParam constructor failed'
    args = ['arg']
    description = 'desc'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert param.args == args, report
    assert param.description == description, report
    assert param.arg_name == arg_name, report
    assert param.type_name == type_name, report
    assert param.is_optional == is_optional, report
    assert param.default == default, report
    

# Generated at 2022-06-21 11:39:53.840805
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta = DocstringMeta(['a', 'b'], 'c')
    assert docstringMeta.args == ['a', 'b']
    assert docstringMeta.description == 'c'

# Generated at 2022-06-21 11:39:58.737478
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_deprecated = DocstringDeprecated(["param"], "this is a test", "1.1")
    assert doc_deprecated.args == ["param"]
    assert doc_deprecated.description == "this is a test"
    assert doc_deprecated.version == "1.1"


# Generated at 2022-06-21 11:40:00.311581
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], "", "")


# Generated at 2022-06-21 11:40:01.327819
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-21 11:40:07.534866
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args=[]
    description=""
    type_name=""
    is_generator=False
    return_name=""
    a=DocstringReturns(args, description, type_name, is_generator, return_name)
    print(a.args, a.description, a.type_name, a.is_generator, a.return_name, sep='\n')
    return a


# Generated at 2022-06-21 11:40:11.648488
# Unit test for constructor of class Docstring
def test_Docstring():
    docs = Docstring()
    assert docs.short_description == None
    assert docs.long_description == None
    assert docs.blank_after_short_description == False
    assert docs.blank_after_long_description == False
    assert docs.meta == []


# Generated at 2022-06-21 11:40:12.284196
# Unit test for constructor of class Docstring
def test_Docstring():
    assert isinstance(Docstring(), Docstring)


# Generated at 2022-06-21 11:40:16.298626
# Unit test for constructor of class ParseError
def test_ParseError():
    class MyParseError(ParseError):
        pass
    msg = "test message"
    err = MyParseError(msg)
    assert err.args == (msg,)
    assert str(err) == msg


# Generated at 2022-06-21 11:40:22.266156
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = "description"
    type_name = "type_name"
    doc_raises = DocstringRaises(args,description,type_name)
    assert doc_raises.args == args
    assert doc_raises.description == description
    assert doc_raises.type_name == type_name


# Generated at 2022-06-21 11:41:59.809602
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:42:05.559983
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # if we call the constructor of DocstringMeta with these arguments,
    # then we get an error, because we can't instantiate this class
    try:
        DocstringMeta(["param", "arg"], "description")
    except TypeError:
        pass
    # because the class DocstringMeta is an abstract class


# Generated at 2022-06-21 11:42:10.243392
# Unit test for constructor of class Docstring
def test_Docstring():
    docString = Docstring()
    assert docString.short_description == None
    assert docString.long_description == None
    assert docString.blank_after_short_description == False
    assert docString.blank_after_long_description == False
    assert docString.meta == []

# Unit tests for getter of property params of class Docstring

# Generated at 2022-06-21 11:42:16.269225
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['test1', 'test2']
    description = 'test description'
    type_name = 'test type'
    is_generator = False
    return_name = 'test'

    test1 = DocstringReturns(args, description, type_name, is_generator, return_name)

    assert isinstance(test1, DocstringReturns)
    assert test1.args == ['test1', 'test2']
    assert test1.description == 'test description'
    assert test1.type_name == 'test type'
    assert test1.is_generator == False
    assert test1.return_name == 'test'

# Generated at 2022-06-21 11:42:27.058843
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg']
    description = "A description"
    arg_name = "arg1"
    type_name = "str"
    is_optional = True
    default = "default value"
    doc_string_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert doc_string_param.args == args
    assert doc_string_param.description == description
    assert doc_string_param.arg_name == arg_name
    assert doc_string_param.type_name == type_name
    assert doc_string_param.is_optional == is_optional
    assert doc_string_param.default == default


# Generated at 2022-06-21 11:42:32.827617
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args = ("test1", "test2")
    test_description = "test3"
    test_version = "test4"
    res = DocstringDeprecated(test_args, test_description, test_version)
    assert(res.args == test_args and res.description == test_description and res.version == test_version)

test_DocstringDeprecated()

# Generated at 2022-06-21 11:42:34.661314
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Unit test")
    assert "Unit test" == str(error)


# Generated at 2022-06-21 11:42:41.062526
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(
        args = ["param"],
        description = "some description",
        arg_name = "arg",
        type_name = "T.Optional[bool]",
        is_optional = True,
        default = "None",
    )
    assert docstring.args == ["param"]
    assert docstring.description == "some description"
    assert docstring.arg_name == "arg"
    assert docstring.type_name == "T.Optional[bool]"
    assert docstring.is_optional == True
    assert docstring.default == "None"


# Generated at 2022-06-21 11:42:43.869940
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    with open("/Users/mac/Documents/GitHub/Sphinx-autodoc-typehints/parser_test.py", "r") as lines:
        for line in lines:
            print(line)


if __name__ == '__main__':
    test_DocstringReturns()

# Generated at 2022-06-21 11:42:45.124559
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert(DocstringReturns(["return"], "returning a value", "None") != None)
