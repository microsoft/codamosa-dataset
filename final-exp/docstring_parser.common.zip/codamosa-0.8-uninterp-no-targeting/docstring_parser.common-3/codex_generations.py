

# Generated at 2022-06-21 11:34:20.686141
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc1 = DocstringParam(args = ['a'], description = "desc", arg_name = "arg_name",
                          type_name = "type_name", is_optional = True, default = "default")
    doc2 = DocstringParam(args = ['b'], description = "desc2", arg_name = "arg_name2",
                          type_name = "type_name2", is_optional = False, default = "default2")
    assert doc1.args == ['a']
    assert doc1.description == "desc"
    assert doc1.arg_name == "arg_name"
    assert doc1.type_name == "type_name"
    assert doc1.is_optional == True
    assert doc1.default == "default"


# Generated at 2022-06-21 11:34:24.039548
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_1=DocstringMeta(['i,j'], 'test')
    assert test_1.args == ['i,j']
    assert test_1.description == 'test'


# Generated at 2022-06-21 11:34:34.942362
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    if docstring.short_description != None:
        print("short_description is NOT set to None")
    else:
        print("short_description is set to None")
    if docstring.long_description != None:
        print("long_description is NOT set to None")
    else:
        print("long_description is set to None")
    if docstring.blank_after_short_description == False:
        print("blank_after_short_description is set to False")
    else:
        print("blank_after_short_description is NOT set to False")
    if docstring.blank_after_long_description == False:
        print("blank_after_long_description is set to False")
    else:
        print("blank_after_long_description is set to False")

# Generated at 2022-06-21 11:34:46.166829
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # TODO - this should probably be a property, or at least a @classmethod
    # This should be a docstring for a method

    s = ":param name: The name of the person to greet."
    j = s.split(':', 1)
    if len(j) != 2:
        raise ParseError("Malformed parameter tag: {}".format(s))
    key, value = j

    key = key.strip()
    if key not in PARAM_KEYWORDS:
        raise ParseError("Unknown tag: '{}'".format(key))

    is_optional = False
    default = None
    if "=" in value:
        if value[0] != " ":
            raise ParseError("Expected a space after '=': {}".format(s))
        is_optional = True
        value, default

# Generated at 2022-06-21 11:34:49.771139
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    parameters = [item for item in doc.params]
    raises = [item for item in doc.raises]
    returns = doc.returns
    deprecation = doc.deprecation

# Generated at 2022-06-21 11:34:55.240426
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    '''
    Test for constructor of class DocstringDeprecated
    '''
    # There is no version
    assert DocstringDeprecated(['deprecated'], '',None)
    # There is a version
    d = DocstringDeprecated(['deprecated'], '','2.0')
    # Check the version
    assert d.version == '2.0'



# Generated at 2022-06-21 11:34:56.540428
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    
    DocstringReturns([],[],None,False)

# Generated at 2022-06-21 11:34:59.882990
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta(["param", ":param", ":param", "param"], "some text")
    assert dsm.args == ["param", ":param", ":param", "param"]
    assert dsm.description == "some text"


# Generated at 2022-06-21 11:35:04.843798
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()

    assert doc.short_description is None
    assert doc.long_description is None
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert [] == doc.meta

# Generated at 2022-06-21 11:35:09.047301
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():

    args = ["raises", "ValueError"]
    description = "If you're looking for a birthday present, don’t buy a gray one. "
    type_name = "ValueError"

    dr = DocstringRaises(args, description, type_name)
    assert dr



# Generated at 2022-06-21 11:35:13.301456
# Unit test for constructor of class ParseError
def test_ParseError():
    error=ParseError("Test")
    assert str(error) == "Test"


# Generated at 2022-06-21 11:35:14.743212
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds is not None


# Generated at 2022-06-21 11:35:20.302072
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(['returns'], None, None, False, return_name='x')
    assert ds.args == ['returns']
    assert ds.description == None
    assert ds.type_name == None
    assert ds.return_name == 'x'
    assert ds.is_generator == False


# Generated at 2022-06-21 11:35:26.461322
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
   return DocstringDeprecated(
        [":deprecated"], "do not pass", "2.0"
    )

if __name__ == "__main__":
    # Testcase for the DocstringDeprecated constructor
    dd = test_DocstringDeprecated()
    assert dd.args == [":deprecated"]
    assert dd.description == "do not pass"
    assert dd.version == "2.0"

    assert dd.__init__ is not None

# Generated at 2022-06-21 11:35:30.650939
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(['args'], "description")
    assert doc.args == ['args']
    assert doc.description == "description"


# Generated at 2022-06-21 11:35:31.521392
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta()
    except Exception:
        pass
    else:
        assert False

# Generated at 2022-06-21 11:35:38.614872
# Unit test for constructor of class Docstring
def test_Docstring():
    # Test initialization to make sure we get what we expect
    docstring = Docstring()

    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:35:40.722343
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError('foo')
    assert(pe.args == ('foo',))


# Generated at 2022-06-21 11:35:43.951432
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(['a'], None, None)
    assert ds.args == ['a']
    assert ds.description == None
    assert ds.type_name == None


# Generated at 2022-06-21 11:35:48.509787
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test = DocstringReturns(
        args=["returns"],
        description=None,
        type_name="str",
        is_generator=True,
        return_name=None,
    )

    assert(test.args==["returns"])
    assert(test.description==None)
    assert(test.type_name=="str")
    assert(test.is_generator==True)
    assert(test.return_name==None)


# Generated at 2022-06-21 11:35:55.677606
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(["param", "py:param"], "a description", "a_name", \
        "a_type", None, None)
    return d.args, d.description, d.arg_name, d.type_name, d.is_optional, \
        d.default


# Generated at 2022-06-21 11:36:00.776974
# Unit test for constructor of class Docstring
def test_Docstring():
    assert isinstance(Docstring(), Docstring)
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-21 11:36:09.620622
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """
    This function is used to test the __init__() function of the DocstringDeprecated class.
    :return: True, if test passes
    """
    args = ['type_name']
    description = 'description'
    version = 'version'
    d = DocstringDeprecated(args, description, version)
    assert args == d.args, "Expected: " + str(args) + " | Got: " + str(d.args)
    assert description == d.description, "Expected: " + str(description) + " | Got: " + str(d.description)
    assert version == d.version, "Expected: " + str(version) + " | Got: " + str(d.version)
    return True


# Generated at 2022-06-21 11:36:11.296636
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["rtype", "str"], "", "str")

# Generated at 2022-06-21 11:36:13.445984
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    
    args = ["param"]
    description = "desc"
    a = DocstringMeta(args, description)
    assert a.__init__(["param"], "desc") == None


# Generated at 2022-06-21 11:36:19.842378
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  args = ["a"]
  description = "print hello"
  arg_name="a"
  type_name="int"
  is_optional=True
  default=1
  ans = DocstringParam(args,description,arg_name,type_name,is_optional,default)
  assert ans.args == ["a"]
  assert ans.description == "print hello"
  assert ans.arg_name == "a"
  assert ans.type_name == "int"
  assert ans.is_optional == True
  assert ans.default == 1


# Generated at 2022-06-21 11:36:25.044199
# Unit test for constructor of class DocstringParam
def test_DocstringParam(): 
    d = DocstringParam([], None, "arg", "None", True, None)
    assert d.arg_name == "arg"
    assert d.type_name == "None"
    assert d.is_optional == True
    assert d.default == None


# Generated at 2022-06-21 11:36:28.309406
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["param"],None,"None")
    assert(a.args == ["param"])
    assert(a.description == None)
    assert(a.type_name == "None")


# Generated at 2022-06-21 11:36:35.510495
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """
       test_DocstringMeta : Testing the DocstringMeta constructor
                                
       :param : NONE
      
       :return: NONE
       """
                                
    try:
        test_docstring_meta = DocstringMeta(['param','arg'], 'description')
    except ParseError as error:
        assert False, "Error occurred while initialising DocstringMeta"
    else:
        assert True, "Successfully initialised DocstringMeta"

# Generated at 2022-06-21 11:36:38.032740
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    parse_error = "Parse error"
    args = {"test": "arguments"}
    description = "description"
    version = "version"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-21 11:36:43.721869
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(
        ["deprecated"], "This function is deprecated.", "1.0"
    ).type_name == "deprecated"



# Generated at 2022-06-21 11:36:45.939102
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("no data error")
    except ParseError:
        assert True

# Generated at 2022-06-21 11:36:54.941288
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    ds = DocstringParam(
        ['param'],
        'this is a test',
        'argument',
        'string',
        True,
        'default value',
    )
    assert isinstance(ds, DocstringParam)
    assert ds.args == ['param']
    assert ds.description == 'this is a test'
    assert ds.arg_name == 'argument'
    assert ds.type_name == 'string'
    assert ds.is_optional is True
    assert ds.default == 'default value'

# Generated at 2022-06-21 11:36:56.836501
# Unit test for constructor of class ParseError
def test_ParseError():
    # Instantiate an object of class ParseError with error message
    object_of_ParseError=ParseError("error")


# Generated at 2022-06-21 11:37:00.880264
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    result = DocstringDeprecated(args = [], description = '', version = '')
    assert result.args == []
    assert result.description == ''
    assert result.version == ''

# Generated at 2022-06-21 11:37:06.973211
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r = DocstringReturns(args=None, is_generator=False, type_name='int', description='returns the result of operation', return_name='value')
    assert r.is_generator == False
    assert r.description == 'returns the result of operation'
    assert r.return_name == 'value'
    assert r.type_name == 'int'

# Generated at 2022-06-21 11:37:09.621445
# Unit test for constructor of class Docstring
def test_Docstring():
    assert not Docstring().params
    assert not Docstring().raises
    assert not Docstring().returns
    assert not Docstring().deprecation


# Base class for parser that may be used by inspecter

# Generated at 2022-06-21 11:37:12.851508
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['args'], 'Description', 'type_name', True)
    assert a.args == ['args']
    assert a.description =='Description'
    assert a.type_name == 'type_name'
    assert a.is_generator == True


# Generated at 2022-06-21 11:37:13.568020
# Unit test for constructor of class ParseError
def test_ParseError():
    """Testing constructor."""
    pass



# Generated at 2022-06-21 11:37:17.078436
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    description = ":deprecated: version 1.0"
    version = "1.0"
    deprecation = DocstringDeprecated(["deprecated"], description, version)
    assert deprecation.description == description
    assert deprecation.version == version



# Generated at 2022-06-21 11:37:23.150295
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from typing import List
    from typing import Optional

    args = []
    description = ""
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-21 11:37:30.498490
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    cw = DocstringParam(
        ['param'], 'description', 'arg_name', 'type_name', True, 'default'
    )
    if cw.args != ['param']:
        raise Exception('DocstringParam method fails')
    if cw.description != 'description':
        raise Exception('DocstringParam method fails')
    if cw.arg_name != 'arg_name':
        raise Exception('DocstringParam method fails')
    if cw.type_name != 'type_name':
        raise Exception('DocstringParam method fails')
    if cw.is_optional != True:
        raise Exception('DocstringParam method fails')
    if cw.default != 'default':
        raise Exception('DocstringParam method fails')

# Generated at 2022-06-21 11:37:36.447781
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []
    return
test_Docstring()



# Generated at 2022-06-21 11:37:41.609628
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['param'], "description", 'arg', 'type_name', 0, 'default')
    assert a.arg_name == 'arg'
    assert a.type_name == 'type_name'
    assert a.is_optional == 0
    assert a.default == 'default'
    assert a.args == ['param']
    assert a.description == 'description'



# Generated at 2022-06-21 11:37:43.855083
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam()
    assert isinstance(docstring_param, DocstringParam), "DocstringParam object is not being created"


# Generated at 2022-06-21 11:37:48.785128
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["raises", "ValueError"], "if something happens", None)
    assert test.args == ["raises", "ValueError"]
    assert test.description == "if something happens"
    assert test.type_name == None


# Generated at 2022-06-21 11:37:49.664479
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["a"], "b")
# Test for constructor of class DocstringParam

# Generated at 2022-06-21 11:37:51.525277
# Unit test for constructor of class ParseError
def test_ParseError():
    # Constructor
    ex = ParseError("test")
    assert str(ex) == "test"

# Generated at 2022-06-21 11:37:55.663040
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []
    pass


# Generated at 2022-06-21 11:38:00.430427
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # DocstringParam(args, description, arg_name, type_name, is_optional, default)
    d1 = DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, None)
    d2 = DocstringParam(['param'], None, 'arg_name', 'type_name', True, None)
    d3 = DocstringParam(['param'], 'description', 'arg_name', None, True, None)
    d4 = DocstringParam(['param'], 'description', 'arg_name', 'type_name', False, None)
    d5 = DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-21 11:38:06.665660
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_DocstringReturns = DocstringReturns(["return_description"], "", "", False)
    assert test_DocstringReturns.description == "return_description"

# Generated at 2022-06-21 11:38:08.809204
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises('args', 'description', type_name='type_name')


# Generated at 2022-06-21 11:38:10.850216
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=[''], description='', type_name='')
    return None


# Generated at 2022-06-21 11:38:14.454626
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr = DocstringReturns(["returns"], "", "", True)
    assert docstr.args == ["returns"]
    assert docstr.description is ""
    assert docstr.type_name is ""
    assert docstr.is_generator is True
    assert docstr.return_name is None


# Generated at 2022-06-21 11:38:20.542113
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam([], None, 'x', 'str', True, 's')
    # assert type(docstringParam.arg_name) is str
    # assert type(docstringParam.type_name) is str
    # assert type(docstringParam.is_optional) is bool
    # assert type(docstringParam.default) is str

# Generated at 2022-06-21 11:38:23.778663
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # testing
    print(DocstringReturns.__init__.__doc__)
    print(DocstringReturns.description)
    assert DocstringReturns.description is not None
    # implementation
    assert DocstringReturns.description == "description"


# Generated at 2022-06-21 11:38:27.345892
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    t = DocstringReturns(["returns"], "description", "int", False)
    assert t.description == "description"
    assert t.return_name == None
    assert t.is_generator == False
    assert t.type_name == "int"



# Generated at 2022-06-21 11:38:30.099046
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False



# Generated at 2022-06-21 11:38:33.417244
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns([], "", "", False, "")



# Generated at 2022-06-21 11:38:37.389601
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-21 11:38:49.891805
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    assert test.short_description == None
    assert test.long_description == None
    assert test.blank_after_short_description == False
    assert test.blank_after_long_description == False
    assert test.meta == []


# Generated at 2022-06-21 11:38:55.064781
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d=DocstringRaises(["raises"], "description", "type_name")
    if(d.args!=["raises"]):
        print("Test Failed: args not set properly")
    if(d.description!="description"):
        print("Test Failed: description not set properly")
    if(d.type_name!="type_name"):
        print("Test Failed: type_name not set properly")
    print("Test Passed")


# Generated at 2022-06-21 11:39:00.245976
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    item = DocstringDeprecated(["deprecated"], "test", "2.0")
    assert isinstance(item, DocstringDeprecated) == True
    assert item.args == ["deprecated"]
    assert item.description == "test"
    assert item.version == "2.0"



# Generated at 2022-06-21 11:39:05.176670
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(
        ["deprecated", "since"],
        "The `my_function(a, b, c)` function is deprecated since version 1.2.\nUse `my_new_function(a, b, c)` instead.",
        "1.2",
    )



# Generated at 2022-06-21 11:39:06.668018
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], None, None)


# Generated at 2022-06-21 11:39:07.809913
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	assert DocstringMeta('args','description')


# Generated at 2022-06-21 11:39:15.249825
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = 'A description of a Docstring'
    arg_name = 'name of the argument'
    type_name = 'type of the argument'
    is_optional = True
    default = None
    a = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert a.args == args
    assert a.description == description
    assert a.arg_name == arg_name
    assert a.type_name == type_name
    assert a.is_optional == is_optional
    assert a.default == default


# Generated at 2022-06-21 11:39:19.213863
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test case for class DocstringMeta."""
    args = "arg"
    description = "description"
    dm = DocstringMeta(args, description)

    assert isinstance(dm, DocstringMeta)
    assert dm.args == args
    assert dm.description == description


# Generated at 2022-06-21 11:39:20.365023
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError('RuntimeError')

# Generated at 2022-06-21 11:39:23.145584
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["param"], "description", "type_name", True, "return_name")



# Generated at 2022-06-21 11:39:35.892633
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert len(doc.meta) == 0



# Generated at 2022-06-21 11:39:39.156621
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(
        args=[],
        description="",
        type_name="test_type",
        is_generator=True,
        return_name="test_name",
    )


# Generated at 2022-06-21 11:39:48.583663
# Unit test for constructor of class Docstring
def test_Docstring():
    # docstring object
    docstring = Docstring()
    docstring.short_description = "This is a short description"
    docstring.long_description = "This is a long description"
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True
    docstring.meta = []

    # test whether all attributes were initialized correctly
    assert docstring.short_description == "This is a short description"
    assert docstring.long_description == "This is a long description"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True
    assert docstring.meta == []



# Generated at 2022-06-21 11:39:54.842587
# Unit test for constructor of class ParseError
def test_ParseError():
    try:  # pragma: no cover
        error = ParseError("this is a test error message")
        assert(str(error) == "this is a test error message")
    except AssertionError as e:
        print("FAIL: ParseError constructor failed: {0}".format(str(e)))
        return False
    else:
        print("PASS: ParseError constructor passed")
        return True


# Generated at 2022-06-21 11:39:59.695051
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-21 11:40:03.065048
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert isinstance(DocstringParam(args=[], description=None, arg_name=None, type_name=None, is_optional=None, default=None), DocstringParam) == True



# Generated at 2022-06-21 11:40:12.454541
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert type(DocstringMeta)==type(1)
    # assert type(DocstringMeta.__init__)==type(1)
    assert DocstringMeta.__init__.__name__ == "__init__"
    assert DocstringMeta.__init__.__qualname__ == "DocstringMeta.__init__"
    assert DocstringMeta.__init__.__doc__ == "Initialize self.\n\n        :param args: list of arguments. The exact content of this variable is\n                     dependent on the kind of docstring; it's used to distinguish between\n                     custom docstring meta information items.\n        :param description: associated docstring description.\n        "


# Generated at 2022-06-21 11:40:17.573108
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None, "Not None!"
    assert a.long_description == None, "Not None!"
    assert a.blank_after_short_description == False, "Not False!"
    assert a.blank_after_long_description == False, "Not False!"

# Generated at 2022-06-21 11:40:22.167591
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = None
    type_name = None
    is_generator = False
    return_name = None
    assert DocstringReturns(args,description,type_name,is_generator,return_name)


# Generated at 2022-06-21 11:40:26.234983
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "attribute", "parameter"]
    description = "description"
    dm = DocstringMeta(args, description)
    assert dm.args == args
    assert dm.description == description


# Generated at 2022-06-21 11:40:37.385073
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([],
                        "description",
                        "type_name")
    assert a.description == "description"
    assert a.type_name == "type_name"
    assert a.args == []


# Generated at 2022-06-21 11:40:38.934977
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(['param'], 'descr', 'True')



# Generated at 2022-06-21 11:40:44.661444
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    desc='Description'
    type_name='Object'
    is_generator=False
    return_name='return_name'
    args=['args']
    doc_return=DocstringReturns(args,desc,type_name,is_generator,return_name)
    assert doc_return.description==desc
    assert doc_return.type_name==type_name
    assert doc_return.is_generator==is_generator
    assert doc_return.return_name==return_name
    assert doc_return.args==args
    

# Generated at 2022-06-21 11:40:48.632756
# Unit test for constructor of class Docstring
def test_Docstring():
    t = Docstring()
    assert t.short_description is None
    assert t.long_description is None
    assert t.blank_after_short_description == False
    assert t.blank_after_long_description == False
    assert t.meta == []

# Unit tests for properties of class Docstring

# Generated at 2022-06-21 11:40:58.843471
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    arg_name = "arg"
    type_name = "int"
    is_optional = True
    default = "1"
    desc = "some description"
    
    test_DocstringParam = DocstringParam(args, desc, arg_name, type_name, is_optional, default)
    
    assert test_DocstringParam.args[0] == "param"
    assert test_DocstringParam.arg_name == "arg"
    assert test_DocstringParam.type_name == "int"
    assert test_DocstringParam.is_optional == True
    assert test_DocstringParam.default == "1"
    assert test_DocstringParam.description == "some description"
    
test_DocstringParam()


# Generated at 2022-06-21 11:41:01.434868
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "something"]
    description = "something happened"
    type_name = "TypeError"
    DocstringRaises(args, description, type_name)


# Generated at 2022-06-21 11:41:04.695555
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert not d.blank_after_short_description
    assert not d.blank_after_long_description
    assert d.meta == []


# Generated at 2022-06-21 11:41:08.439845
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None

# Generated at 2022-06-21 11:41:17.944635
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["arg1", "arg2"]
    description = "desc"
    type_name = "type1"
    is_generator = True
    return_name = "my_return"
    a = DocstringReturns(args, description, type_name, is_generator)
    b = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(a.args == args and b.args == args)
    assert(a.description == description and b.description == description)
    assert(a.type_name == type_name and b.type_name == type_name)
    assert(a.is_generator == is_generator and b.is_generator == is_generator)
    assert(a.return_name == None and b.return_name == return_name)

# Generated at 2022-06-21 11:41:24.765806
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr=DocstringReturns(1,"description","type")
    assert docstr.description=="description"
    assert docstr.args==1
    assert docstr.type_name=="type"
    assert docstr.is_generator==True
    assert docstr.return_name==None


# Generated at 2022-06-21 11:41:49.915200
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raise_1 = DocstringRaises(["raises"], "ValueError", "int")
    raise_2 = DocstringRaises(["raises"], "ValueError", "int")

    assert str(raise_1) == str(raise_2)


# Generated at 2022-06-21 11:41:50.919124
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError('bla')



# Generated at 2022-06-21 11:41:56.202252
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:41:58.245864
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['deprecated'], '', '0.1')

if __name__ == '__main__':
    test_DocstringDeprecated()


# Generated at 2022-06-21 11:42:00.628197
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    parameter = DocstringParam(["param", "x"], "description", "x", "int", None, None)
    assert parameter.description == "description"
    assert parameter.arg_name == "x"
    assert parameter.type_name == "int"
    assert parameter.default is None

# Generated at 2022-06-21 11:42:03.500741
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        res = 1 / 0
    except Exception as err:
        raise ParseError('modified error!') from err
    return res


# Generated at 2022-06-21 11:42:07.525117
# Unit test for constructor of class ParseError
def test_ParseError():
    #ensure that an error is raised
    try:
        raise ParseError("test")
    except ParseError as e:
        assert "test" in str(e)


# Generated at 2022-06-21 11:42:13.651412
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args = ["Deprecated", "0.1"]
    test_descr = "Deprecated and will be removed in 0.1"
    test_version = "0.1"
    testDocstringDeprecated = DocstringDeprecated(test_args, test_descr, test_version)
    assert(testDocstringDeprecated.args == test_args)
    assert(testDocstringDeprecated.description == test_descr)
    assert(testDocstringDeprecated.version == test_version)


# Generated at 2022-06-21 11:42:21.742706
# Unit test for constructor of class Docstring
def test_Docstring():
    str = Docstring()
    assert(str.short_description == None)
    assert(str.long_description == None)
    assert(str.blank_after_short_description == False)
    assert(str.blank_after_long_description == False)
    assert(str.meta == [])

    assert(str.params == [])
    assert(str.raises == [])
    assert(str.returns == None)
    assert(str.deprecation == None)
    return


# Generated at 2022-06-21 11:42:24.397640
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    return DocstringParam(["args"], "description", "arg_name", "type_name", True, "default")


# Generated at 2022-06-21 11:43:08.432337
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("foo")
    assert pe.args == ("foo",)


# Generated at 2022-06-21 11:43:09.394851
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('test')
    assert(str(err) == 'test')

# Generated at 2022-06-21 11:43:11.492052
# Unit test for constructor of class Docstring
def test_Docstring():
    instance = Docstring()
    assert instance != None


# Generated at 2022-06-21 11:43:15.583875
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param", "type", "name", "{}", "desc"]
    description = "Test"
    version = "1.1.1"
    assert DocstringDeprecated(args, description, version).type_name == "type"
    assert DocstringDeprecated(args, description, version).description == "desc"
    assert DocstringDeprecated(args, description, version).version == "1.1.1"

# Generated at 2022-06-21 11:43:16.896021
# Unit test for constructor of class ParseError
def test_ParseError():
    value = "Error msg"
    error = ParseError(value)
    assert str(error) == value

# Generated at 2022-06-21 11:43:19.839247
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises([], "desc", "str")
    assert x.type_name == "str"
    assert x.description == "desc"

#Unit test for docstring constructor

# Generated at 2022-06-21 11:43:21.665478
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["test"], "test", "test")


# Generated at 2022-06-21 11:43:26.440216
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ['test_args', 'test_args']
    test_desc = 'test_desc'
    test_docstringmeta = DocstringMeta(test_args,test_desc)
    
    assert test_docstringmeta.args == test_args
    assert test_docstringmeta.description == test_desc



# Generated at 2022-06-21 11:43:30.026449
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    item = DocstringDeprecated(
        ["deprecated"], "description", version="0.0.1"
    )
    assert item.type_name == None
    assert item.description == "description"
    assert item.version == "0.0.1"

# Generated at 2022-06-21 11:43:34.799624
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([':return', ':returns'], 'function returns a string', 'str', False, 'return_name')
    assert a.args == [':return', ':returns']
    assert a.description == 'function returns a string'
    assert a.type_name == 'str'
    assert a.is_generator == False
    assert a.return_name == 'return_name'

test_DocstringReturns()