

# Generated at 2022-06-21 11:34:20.977890
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["0", "1", "2"]
    description = "desc"
    version = "version"

    # Constructor
    docstringDeprecated1 = DocstringDeprecated(args, description, version)

    # Accessors
    assert args[0] == docstringDeprecated1.args[0]
    assert args[1] == docstringDeprecated1.args[1]
    assert args[2] == docstringDeprecated1.args[2]
    assert docstringDeprecated1.description == description
    assert docstringDeprecated1.version == version



# Generated at 2022-06-21 11:34:23.700525
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "description")
    assert d.args == ["param"]
    assert d.description == "description"


# Generated at 2022-06-21 11:34:30.647884
# Unit test for constructor of class Docstring
def test_Docstring():
    my_docstring = Docstring()
    assert not my_docstring.params
    assert not my_docstring.raises
    assert not my_docstring.returns
    assert not my_docstring.deprecation
    assert my_docstring.short_description == None
    assert my_docstring.long_description == None
    assert not my_docstring.blank_after_short_description
    assert not my_docstring.blank_after_long_description
    assert my_docstring.meta == []

# Generated at 2022-06-21 11:34:33.062766
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test ParseError."""
    with pytest.raises(ParseError):
        raise ParseError("Test error")


# Generated at 2022-06-21 11:34:33.838419
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d


# Generated at 2022-06-21 11:34:41.628490
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['raises', 'raise', 'except', 'exception']
    description = 'some description'
    type_name = 'some type'
    is_generator = True;
    return_name = 'some name'

    docstring = DocstringReturns(args, description, type_name, is_generator, return_name)

    assert docstring.args == args
    assert docstring.description == description
    assert docstring.type_name == type_name
    assert docstring.is_generator == is_generator
    assert docstring.return_name == return_name

# Generated at 2022-06-21 11:34:44.550008
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass
    else:
        assert False, "Exception is not raised"



# Generated at 2022-06-21 11:34:52.293101
# Unit test for constructor of class DocstringParam
def test_DocstringParam():

    good_docstring = DocstringParam("arg", "description", "arg_name", "type", False, True)
    assert good_docstring.args == "arg"
    assert good_docstring.description == "description"
    assert good_docstring.arg_name == "arg_name"
    assert good_docstring.type_name == "type"
    assert good_docstring.is_optional == False
    assert good_docstring.default == True



# Generated at 2022-06-21 11:34:53.248299
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()
    return

# Generated at 2022-06-21 11:34:56.658060
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test constructor."""
    doc = DocstringDeprecated(["deprecated"], "text", "2.0")
    assert doc.args == ["deprecated"]
    assert doc.description == "text"
    assert doc.version == "2.0"

# Generated at 2022-06-21 11:35:03.685064
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test constructor of class DocstringRaises."""
    DocstringRaises(['raises'], 'description', 'ValueError')

# Generated at 2022-06-21 11:35:08.006373
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    DocstringDeprecated(["a"], None, None)
    DocstringDeprecated(["b"], "b", None)
    DocstringDeprecated(["c"], None, "c")
    DocstringDeprecated(["d"], "d", "d")

# Generated at 2022-06-21 11:35:11.716725
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    class Test:

        def __init__(self):
            self.test = DocstringReturns(
                [],'test', '', False
            )
        def get_test(self):
            print(self.test)

    test = Test()
    test.get_test()

# Generated at 2022-06-21 11:35:12.516279
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  assert DocstringRaises != None


# Generated at 2022-06-21 11:35:17.565397
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

# unit test for property params of class Docstring

# Generated at 2022-06-21 11:35:19.185751
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	assert_equal('version' in dir(DocstringDeprecated), True)


# Generated at 2022-06-21 11:35:21.101255
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated("args", "des", "v") is not None


# Generated at 2022-06-21 11:35:23.303734
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([":returns:", "description"], "description", None, None)


# Generated at 2022-06-21 11:35:28.805335
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_docstring = DocstringParam(["param"], "description", "arg", "int", False, "123")
    assert test_docstring.args == ["param"]
    assert test_docstring.description == "description"
    assert test_docstring.arg_name == "arg"
    assert test_docstring.type_name == "int"
    assert test_docstring.is_optional == False
    assert test_docstring.default == "123"


# Generated at 2022-06-21 11:35:36.996740
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    newline_test = DocstringMeta(["a"], "The parameter a is being tested for newline separation")
    assert(newline_test.args[0] == "a")
    assert(newline_test.description == "The parameter a is being tested for newline separation")
    newline_test = DocstringMeta(["a", "b"], "The parameter a, b is being tested for newline separation")
    assert(newline_test.args[0] == "a")
    assert(newline_test.args[1] == "b")
    assert(newline_test.description == "The parameter a, b is being tested for newline separation")
    newline_test = DocstringMeta(["a", "b"], "The parameter  is being tested for newline separation")

# Generated at 2022-06-21 11:35:42.177022
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    with pytest.raises(TypeError):
        assert DocstringDeprecated()

# Generated at 2022-06-21 11:35:45.813408
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []



# Generated at 2022-06-21 11:35:48.806829
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert docstring.DocstringReturns([], "", "")
    assert docstring.DocstringReturns([], "", "", False, False)


# Generated at 2022-06-21 11:35:50.936347
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as e:
        assert e is not None


# Generated at 2022-06-21 11:36:03.198777
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ['deprecated', 'version', 'str']
    test_description = 'the version in which something is deprecated'
    test_type_name = 'str'
    test_is_generator = False
    test_return_name = None
    test_returns = DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    # test_returns.args = test_args
    # test_returns.description = test_description
    # test_returns.type_name = test_type_name
    # test_returns.is_generator = test_is_generator
    # test_returns.return_name = test_return_name
    assert test_returns.args == test_args
    assert test_returns.description

# Generated at 2022-06-21 11:36:08.359130
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValError"]
    description = "if x"
    type_name = "ValError"
    test_DocstringRaises = DocstringRaises(args, description, type_name)
    assert test_DocstringRaises.args == args
    assert test_DocstringRaises.description == description
    assert test_DocstringRaises.type_name == type_name


# Generated at 2022-06-21 11:36:17.600575
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the constructor DocstringParam"""
    args =["extended_description"]
    description = "short_description"
    arg_name = "a"
    type_name = "None"
    is_optional = False
    default = "3"
    dsp = DocstringParam(
        args, description, arg_name, type_name, is_optional, default)
    assert dsp.args == args
    assert dsp.description == description
    assert dsp.arg_name == arg_name
    assert dsp.type_name == type_name
    assert dsp.is_optional == is_optional
    assert dsp.default == default


# Generated at 2022-06-21 11:36:22.935871
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([':deprecated', ':'], 'This is a depreacted function', '0.1.0')
    assert DocstringDeprecated([':deprecated', ':'], 'This is a depreacted function', '0.1.0')


# Generated at 2022-06-21 11:36:26.800882
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(args=[":deprecated"], description="This function is deprecated.", version="2.0")
    assert obj.args[0] == ":deprecated"
    assert obj.description == "This function is deprecated."
    assert obj.version == "2.0"



# Generated at 2022-06-21 11:36:31.982703
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc_string_returns = DocstringReturns(args = ["return"], description = "return description", type_name = "string", is_generator = False, return_name = "a")
    assert doc_string_returns.args == ["return"]
    assert doc_string_returns.description == "return description"
    assert doc_string_returns.type_name == "string"
    assert doc_string_returns.return_name == "a"
    assert doc_string_returns.is_generator == False


# Generated at 2022-06-21 11:36:40.330589
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # test constructor of class DocstringDeprecated
    DocstringDeprecated(args=None, description=None, version=None)



# Generated at 2022-06-21 11:36:47.510386
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring() # Create an instance of class Docstring
    assert docstr.short_description == None  
    assert docstr.long_description == None
    assert docstr.blank_after_short_description == False
    assert docstr.blank_after_long_description == False
    assert docstr.meta == []
   
    assert docstr.params == []
    assert docstr.raises == []
    assert docstr.returns == None
    assert docstr.deprecation == None

# Generated at 2022-06-21 11:36:57.898466
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    Tests that constructor of DocstringReturns is working as expected.
    """
    args = ["args"]
    description = "I'm a description"
    type_name = "type"
    is_generator = "generator"
    return_name = "name"
    docstring = DocstringReturns(args, description, type_name, is_generator, return_name)

    assert docstring.args == args
    assert docstring.description == description
    assert docstring.type_name == type_name
    assert docstring.is_generator == is_generator
    assert docstring.return_name == return_name


# Generated at 2022-06-21 11:37:04.114961
# Unit test for constructor of class Docstring
def test_Docstring():
    # Test constructor of Docstring class
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:37:05.988765
# Unit test for constructor of class ParseError
def test_ParseError():
    error=ParseError("failed")
    assert isinstance(error,RuntimeError)



# Generated at 2022-06-21 11:37:09.076826
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    testDocstring = DocstringDeprecated(["param"], "description", "version")
    assert testDocstring.args == ["param"]
    assert testDocstring.description == "description"
    assert testDocstring.version == "version"


# Generated at 2022-06-21 11:37:12.136324
# Unit test for constructor of class ParseError
def test_ParseError():
    """test_ParseError."""
    try:
        raise ParseError("test")
    except ParseError as e:
        assert(str(e) == "test")


if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-21 11:37:18.570914
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringparam = DocstringParam(
        ["param"],
        "The description.",
        "arg",
        "str",
        True,
        "default"
    )
    assert docstringparam.args == ["param"]
    assert docstringparam.description == "The description."
    assert docstringparam.arg_name == "arg"
    assert docstringparam.type_name == "str"
    assert docstringparam.is_optional == True
    assert docstringparam.default == "default"


# Generated at 2022-06-21 11:37:20.666308
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["arg1"], "description", "version")
    assert a.args == ["arg1"]
    assert a.description == "description"
    assert a.version == "version"


# Generated at 2022-06-21 11:37:22.833397
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(args=["arg"], description="test", type_name="test")
    assert a.args == ["arg"]
    assert a.description == "test"
    assert a.type_name == "test"



# Generated at 2022-06-21 11:37:37.897646
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("Should have raised this error").args == ('Should have raised this error',)

# Generated at 2022-06-21 11:37:40.724532
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    passes = False
    try:
        DocstringReturns(['returns'], 'returns something', 'returns', True, 'function')
        passes = True
    except TypeError:
        pass
    assert passes


# Generated at 2022-06-21 11:37:41.450777
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([], "description", "type_name")

# Generated at 2022-06-21 11:37:42.846014
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as msg:
        assert msg.args[0] == "Test"


# Generated at 2022-06-21 11:37:47.288260
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """ This function is the unit test for the constructor of DocstringRaises class """
    # Test when all the arguments are correct
    assert DocstringRaises([None, None, None], None, 'ValueError')

    # Test when all the arguments are correct
    assert DocstringRaises([None, None, None], None, None)

    # Test when all the arguments are correct
    assert DocstringRaises([None, None, None], 'Something\'s wrong', None)



# Generated at 2022-06-21 11:37:48.324027
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-21 11:37:55.613940
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:37:58.883931
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [1, 2, 3]
    description = "This is a description."

    test_object = DocstringMeta(args, description)
    assert test_object.args == args
    assert test_object.description == description


# Generated at 2022-06-21 11:38:06.241265
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    actual = DocstringParam(
        args=["param"],
        description="description",
        arg_name="arg",
        type_name="type",
        is_optional=None,
        default="default"
    )
    assert actual.args == ["param"]
    assert actual.description == "description"
    assert actual.arg_name == "arg"
    assert actual.type_name == "type"
    assert actual.is_optional == None
    assert actual.default == "default"


# Generated at 2022-06-21 11:38:13.020302
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:38:42.019101
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns([], "", "", False)
    assert ds


# Generated at 2022-06-21 11:38:47.161544
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"
        print("test_ParseError succesful")
    except:
        assert False

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-21 11:38:49.383329
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Wrong Input')
    except ParseError as e:
        print(e)

# Generated at 2022-06-21 11:38:50.112458
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-21 11:38:51.773055
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("Incorrect indentation after block quote")

# Generated at 2022-06-21 11:38:54.578761
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description      == None
    assert doc.long_description       == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description  == False
    assert doc.meta                   == []


# Generated at 2022-06-21 11:38:58.887949
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["param"], "description", "type_name")
    assert a.args == ["param"]
    assert a.description == "description"
    assert a.type_name == "type_name"
    assert a

# Generated at 2022-06-21 11:38:59.984029
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("Test message.")


# Generated at 2022-06-21 11:39:04.325111
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-21 11:39:07.946540
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    myDeprecated = DocstringDeprecated(
        [":deprecated: test description"],
        "test description",
        "test version",
    )
    assert myDeprecated.version == "test version"
    assert myDeprecated.description == "test description"


# Generated at 2022-06-21 11:40:10.833244
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["raises"], "description", "TypeError")
    assert isinstance(d, DocstringRaises)


# Generated at 2022-06-21 11:40:16.075947
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test DocstringDeprecated()."""
    test_args = ["hello","world"]
    test_description = "This is a test"
    test_version = "1.0"
    test_param = DocstringDeprecated(test_args,test_description,test_version)
    assert test_param.args==["hello","world"]
    assert test_param.description=="This is a test"
    assert test_param.version=="1.0"


# Generated at 2022-06-21 11:40:19.109639
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([':param'], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-21 11:40:27.031782
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam"""
    # A. Arrange
    args = ["accelerated", "is", "not", "a", "word"]
    arg_name = "accelerated"
    type_name = "0.1"
    is_optional = True
    default = "0.1"

    # B. Act
    DocstringParam(args, 'description', arg_name, type_name, is_optional, default)

    # C. Assert
    pass


# Generated at 2022-06-21 11:40:30.258227
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["raises"], "stuff", 'ValueError')
    assert a.args == ["raises"]
    assert a.description == "stuff"


# Generated at 2022-06-21 11:40:37.583348
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['args', 'arg']
    description = 'description' 
    type_name = 'type_name' 
    is_generator = True 
    return_name = 'return_name' 
    # Check that constructor will not throw any exceptions
    assert DocstringReturns(args, description, type_name, is_generator, return_name) is not None

# Generated at 2022-06-21 11:40:38.837804
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([],None,"str",False,"name").return_name == "name"

# Generated at 2022-06-21 11:40:43.818113
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # test non-empty args
    t_DocstringMeta = DocstringMeta(['param', 'arg'], 'description')
    assert t_DocstringMeta.args == ['param', 'arg']
    assert t_DocstringMeta.description == 'description'
    # test empty args
    t_DocstringMeta = DocstringMeta([], 'description')
    assert t_DocstringMeta.args == []
    assert t_DocstringMeta.description == 'description'


# Generated at 2022-06-21 11:40:44.550369
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([], None, None)



# Generated at 2022-06-21 11:40:47.267257
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['test', '10', 'test']
    desc = 'this is a short description'
    md = DocstringDeprecated(args, desc, version = None)
    assert md.__class__ == DocstringDeprecated
    assert md.args == args
    assert md.version == None 
    assert md.description == desc


# Generated at 2022-06-21 11:43:27.776754
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = DocstringReturns(["returns"], "description", "int", False)
    assert isinstance(docstring, DocstringMeta)
    assert docstring.args[0] == "returns"
    assert docstring.description == "description"
    assert docstring.type_name == "int"
    assert docstring.is_generator == False


# Generated at 2022-06-21 11:43:32.208642
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Testing DocstringMeta"""
    args = ['param', 'arg', 'description']
    description = "This is a description."
    x = DocstringMeta(args, description)
    assert x.args==['param', 'arg', 'description']
    assert x.description=="This is a description."


# Generated at 2022-06-21 11:43:37.024147
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Arrange
    args = ["param", "test"]
    description = "description"
    type_name = "test"
    is_generator = False
    return_name = "test"
    # Act
    result = DocstringReturns(args, description, type_name, is_generator, return_name)
    # Assert
    assert result.args == ["param", "test"]
    assert result.description == "description"
    assert result.type_name == "test"
    assert result.is_generator == False
    assert result.return_name == "test"

# Generated at 2022-06-21 11:43:38.132781
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert(str(DocstringDeprecated) == "<class '_pytest_sphinx.docstrings.DocstringDeprecated'>")


# Generated at 2022-06-21 11:43:42.387078
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises
    args = ['a','b']
    description = 'some descr'
    type_name = 'a type'
    a_1 = DocstringRaises(args, description, type_name)
    result_1 = a.__init__(args, description, type_name)
    
    

# Generated at 2022-06-21 11:43:50.246958
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description is None
    assert test_docstring.long_description is None
    assert test_docstring.blank_after_short_description is False
    assert test_docstring.blank_after_long_description is False
    assert test_docstring.meta == []
    assert test_docstring.params == []
    assert test_docstring.raises == []
    assert test_docstring.returns is None
    assert test_docstring.deprecation is None



# Generated at 2022-06-21 11:43:51.988960
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error occurred")
    except ParseError as err:
        print(err.args)


# Generated at 2022-06-21 11:43:57.146337
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = "description"
    arg_name = "arg"
    type_name = "string"
    is_optional = True
    default = "abc"
    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert param.args == args
    assert param.description == description
    assert param.arg_name == arg_name
    assert param.type_name == type_name
    assert param.is_optional == is_optional
    assert param.default == default



# Generated at 2022-06-21 11:43:59.229270
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("error text")


# Generated at 2022-06-21 11:44:03.172951
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    var = DocstringReturns([""], None, None, True)
    assert var.args == [""]
    assert var.description == None
    assert var.type_name == None
    assert var.is_generator
    assert var.return_name == None