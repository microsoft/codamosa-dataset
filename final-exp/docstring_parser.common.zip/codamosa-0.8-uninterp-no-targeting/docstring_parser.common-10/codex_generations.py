

# Generated at 2022-06-21 11:34:16.789791
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises(["description"], "description", "description")
    assert raises.description == "description"
    assert raises.type_name == "description"
    assert raises.args == ["description"]


# Generated at 2022-06-21 11:34:19.696423
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['m', 'a', 'r', 'k'], 'mark mark mark')
    assert docstring_meta.args == ['m', 'a', 'r', 'k']
    assert docstring_meta.description == 'mark mark mark'


# Generated at 2022-06-21 11:34:22.685419
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d1 = DocstringDeprecated(['deprecated'], 'Some description', None)
    assert type(d1) == DocstringDeprecated
    assert d1.args == ['deprecated']
    assert d1.description == 'Some description'
    assert d1.version == None


# Generated at 2022-06-21 11:34:24.102961
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['args'], 'description')



# Generated at 2022-06-21 11:34:31.761538
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    l = ["param", "arg"]
    d = "description"
    an = "arg_name"
    t = "type_name"
    io = True
    d = "default"
    param = DocstringParam(l, d, an, t, io, d)
    return param.args == l and \
        param.description == d and \
        param.arg_name == an and \
        param.type_name == t and \
        param.is_optional == io and \
        param.default == d


# Generated at 2022-06-21 11:34:35.216904
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test the constructor of class DocstringMeta."""
    docstring = DocstringMeta(['args'], 'description')
    assert docstring.args==['args']
    assert docstring.description=='description'


# Generated at 2022-06-21 11:34:38.169243
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['a'], 'b', '1.0')
    assert d.args[0] == 'a'
    assert d.description == 'b'
    assert d.version == '1.0'


# Generated at 2022-06-21 11:34:50.065479
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert(DocstringParam(['param'], None, 'arg', None, None, None) ==
           DocstringParam(['param'], None, 'arg', None, None, None))
    assert(DocstringParam(['param'], None, 'arg', None, None, None) !=
           DocstringParam(['param'], '', 'arg', None, None, None))
    assert(DocstringParam(['param'], None, 'arg', None, None, None) !=
           DocstringParam(['param'], None, 'arg', '', None, None))
    assert(DocstringParam(['param'], None, 'arg', None, None, None) !=
           DocstringParam(['param'], None, 'arg', None, True, None))

# Generated at 2022-06-21 11:34:59.465264
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['deprecated', 'in', 'version', 'fork'], 'nothing to say', 'fork') is not None
    assert DocstringDeprecated(['deprecated', 'since', 'version', 'fork'], 'nothing to say', 'fork') is not None
    assert DocstringDeprecated(['deprecated'], 'nothing to say', 'fork') is not None
    assert DocstringDeprecated(['deprecated', 'in', 'fork'], 'nothing to say', 'fork') is not None
    assert DocstringDeprecated(['deprecated', 'since', 'fork'], 'nothing to say', 'fork') is not None
    assert DocstringDeprecated(['deprecated', 'in'], 'nothing to say', 'fork') is not None

# Generated at 2022-06-21 11:35:09.805151
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    
    try:
        d.short_description
    except:
        assert False,"short_description of Docstring not defined."
    try:
        d.long_description
    except:
        assert False,"long_description of Docstring not defined."
    try:
        d.blank_after_short_description
    except:
        assert False,"blank_after_short_description of Docstring not defined."
    try:
        d.blank_after_long_description
    except:
        assert False,"blank_after_long_description of Docstring not defined."
    try:
        d.meta
    except:
        assert False,"meta of Docstring not defined."



# Generated at 2022-06-21 11:35:19.984741
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=['param'], description='test', arg_name='test', type_name='test', is_optional='test', default='test')

# Generated at 2022-06-21 11:35:23.062102
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()
    assert x.long_description is None
    assert x.short_description is None
    assert x.meta == []


# Generated at 2022-06-21 11:35:25.645166
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["keyword"], "description").args
    b = DocstringMeta(["keyword"], "description").description
    assert a == ["keyword"]
    assert b == "description"


# Unit tests for constructor of class DocStringParam

# Generated at 2022-06-21 11:35:33.188022
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "desc", "arg", "typename", False, "default")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "desc"
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "typename"
    assert docstring_param.is_optional == False
    assert docstring_param.default == "default"


# Generated at 2022-06-21 11:35:35.560947
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print(DocstringDeprecated(["Version 2.2"], "New version has new stuff", "2.2"))




# Generated at 2022-06-21 11:35:46.664362
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Test for __init__
    try:
        D = DocstringReturns('a', 'b', 'c', False, 'd')
    except:
        print("DocstringReturns constructor is not working correctly")
        sys.exit(0)
    # Test for is_generator
    if D.is_generator != False:
        print("DocstringReturns.is_generator is not working correctly")
        sys.exit(0)
    # Test for return_name
    if D.return_name != 'd':
        print("DocstringReturns.return_name is not working correctly")
        sys.exit(0)
    # Test for type_name
    if D.type_name != 'c':
        print("DocstringReturns.type_name is not working correctly")
        sys.exit(0)

    #Test for __init__

# Generated at 2022-06-21 11:35:50.284642
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Unit test for Python Parser")
    except ParseError as e:
        print(e)
        print(type(e))


# Generated at 2022-06-21 11:35:52.282025
# Unit test for constructor of class ParseError
def test_ParseError():
    parseError = ParseError("Test Error")
    assert(parseError.args == ("Test Error",))

# Generated at 2022-06-21 11:35:55.189818
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['parameter', 'arguments']
    description = 'This is description.'
    type_name = 'int'




# Generated at 2022-06-21 11:35:56.292034
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-21 11:36:05.348986
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass

# Generated at 2022-06-21 11:36:06.100112
# Unit test for constructor of class ParseError
def test_ParseError():
	assert 42 == 42


# Generated at 2022-06-21 11:36:09.269714
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args="parm", description="desc", version="1.0.0")
    print(a.description)
    print(a.version)
    print(a.args)

# Generated at 2022-06-21 11:36:17.065133
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    def __init__(
        self,
        args: T.List[str],
        description: T.Optional[str],
        type_name: T.Optional[str],
        is_generator: bool,
        return_name: T.Optional[str] = None,
    ) -> None:
        """Initialize self."""
        super().__init__(args, description)
        self.type_name = type_name
        self.is_generator = is_generator
        self.return_name = return_name



# Generated at 2022-06-21 11:36:23.459244
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['args', 'args2'], 'desc', 'type')
    assert test.args == ['args', 'args2'], 'args initialized incorrectly'
    assert test.description == 'desc', 'description initialized incorrectly'
    assert test.type_name == 'type', 'type_name initialized incorrectly'


# Generated at 2022-06-21 11:36:29.950474
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    print("short description ", doc.short_description)
    print("long description ", doc.long_description)
    print("blank after short description ", doc.blank_after_short_description)
    print("blank after long description ", doc.blank_after_long_description)
    print("meta ", doc.meta)
    print("params ", doc.params)
    print("raises ", doc.raises)
    print("returns ", doc.returns)
    print("deprecation", doc.deprecation)



# Generated at 2022-06-21 11:36:33.256649
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    lst = []
    d = DocstringMeta(lst, 'a')
    assert d.args == lst
    assert d.description == 'a'
    return d

# Generated at 2022-06-21 11:36:40.853407
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = list()
    description = "Here is the description"
    type_name = "int"
    is_generator = False
    return_name = "T"
    obj = DocstringReturns(args, description, type_name, is_generator, return_name)  # type: ignore
    assert obj.args == args
    assert obj.description == description
    assert obj.type_name == type_name
    assert obj.is_generator == is_generator
    assert obj.return_name == return_name

# Generated at 2022-06-21 11:36:43.480340
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["key"], "description", "version")
    assert d.args == ["key"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-21 11:36:45.847494
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass


# Generated at 2022-06-21 11:36:57.249772
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:37:09.034390
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(AssertionError):
        ParseError()
    with pytest.raises(AssertionError):
        ParseError(None)
    with pytest.raises(AssertionError):
        ParseError('')
    with pytest.raises(AssertionError):
        ParseError(' ')
    with pytest.raises(AssertionError):
        ParseError('  ')
    with pytest.raises(AssertionError):
        ParseError('   ')
    with pytest.raises(AssertionError):
        ParseError('\t')
    with pytest.raises(AssertionError):
        ParseError('\n')

# Generated at 2022-06-21 11:37:12.920565
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ob=DocstringReturns([], 'description', 'type_name', False, 'return_name')
    assert(ob.args == [])
    assert(ob.description == 'description')
    assert(ob.type_name == 'type_name')
    assert(ob.is_generator == False)
    assert(ob.return_name == 'return_name')

# Generated at 2022-06-21 11:37:21.593059
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    doc.meta.append(DocstringRaises(["raises"], "description", "TypeError"))
    doc.meta.append(DocstringRaises(["raises"], "description", "NotImplementedError"))
    doc.meta.append(DocstringParam(["param"], "description", "arg_name", "MyType", False, "default"))
    doc.meta.append(DocstringDeprecated(["deprecated"], "description", "2.0"))
    doc.meta.append(DocstringReturns(["return"], "description", "MyType", False, "return_name"))
    assert len(doc.params) == 1
    assert len(doc.raises) == 2
    assert doc.deprecation is not None
    assert doc.returns is not None



# Generated at 2022-06-21 11:37:25.079863
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns("RETURNS", "This function returns a number", "int")
    assert a.args == "RETURNS"
    assert a.description == "This function returns a number"
    assert a.type_name == "int"
    assert a.is_generator == False
    assert a.return_name == None


# Generated at 2022-06-21 11:37:28.025352
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(
        args=["arg1","arg2"],
        description="A test description",
        type_name="test_type",
    )

# Generated at 2022-06-21 11:37:30.088230
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Houston, we have a problem!")
    assert err.args == ('Houston, we have a problem!',)



# Generated at 2022-06-21 11:37:36.857214
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    Tests the constructor of class DocstringReturns
    """
    doc = DocstringReturns(['returns'], "description", "Type", False)

    assert doc.__class__.__name__ == "DocstringReturns"
    assert doc.description == "description"
    assert doc.type_name == "Type"
    assert doc.is_generator == False

# Generated at 2022-06-21 11:37:39.605254
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam('args', 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    print(a.description)
    print(a.args)
    

# Generated at 2022-06-21 11:37:41.746103
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid option foo")
    except ParseError as e:
        assert str(e) == "Invalid option foo"



# Generated at 2022-06-21 11:37:57.835573
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string.long_description == None
    assert doc_string.short_description == None
    assert doc_string.blank_after_short_description == False
    assert doc_string.blank_after_long_description == False
    assert doc_string.meta == []


# Generated at 2022-06-21 11:38:01.054904
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # pylint: disable = missing-function-docstring
    doc = DocstringMeta(["a"], "b")
    assert doc.args == ["a"]
    assert doc.description == "b"


# Generated at 2022-06-21 11:38:02.983337
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('a')
    assert (err.args == ('a',))


# Generated at 2022-06-21 11:38:05.557772
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_string_deprecated = DocstringDeprecated([],None,"2.0")
    assert doc_string_deprecated.version == "2.0"

# Generated at 2022-06-21 11:38:09.543872
# Unit test for constructor of class ParseError
def test_ParseError():
    """unit test for constructor of class ParseError"""
    try:
        raise ParseError('test')
    except ParseError as e:
        assert e.args == ('test',)
    else:
        assert False


# Generated at 2022-06-21 11:38:15.916444
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['wewe', 'ehne', 'dude']
    desc = 'fuck'
    type_name = 'float'
    is_generator = False
    return_name = None
    a = DocstringReturns(args, desc, type_name, is_generator, return_name)
    # the next line is to throw the exception if the object was not created properly
    if a.args and a.is_generator and a.return_name and a.type_name and a.description:
        print('test_DocstringReturns() passed.')
    else:
        raise RuntimeError('test_DocstringReturns() failed.')

# Generated at 2022-06-21 11:38:18.186098
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("Error")


# Generated at 2022-06-21 11:38:20.733852
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    line = ":deprecated: description"
    assert len(parse_docstring_meta(line)) == 1
    assert isinstance(parse_docstring_meta(line)[0], DocstringDeprecated)


# Generated at 2022-06-21 11:38:30.178756
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Case 1:
    args1 = ['raises']
    description1 = 'This method is not supported in python'
    type_name1 = 'Not Support'

    test1 = DocstringRaises(args1, description1, type_name1)
    assert test1.args == ['raises']
    assert test1.description == 'This method is not supported in python'
    assert test1.type_name == 'Not Support'

    # Case 2:
    args2 = ['exc']
    description2 = 'This method is not supported in python'
    type_name2 = 'Not Support'

    test2 = DocstringRaises(args2, description2, type_name2)
    assert test2.args == ['exc']
    assert test2.description == 'This method is not supported in python'
    assert test2.type_

# Generated at 2022-06-21 11:38:33.916240
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-21 11:39:03.677854
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_param = DocstringParam(['param'], 'description', 'arg', 'type', True, 'default')
    assert test_param.args == ['param']
    assert test_param.description == 'description'
    assert test_param.arg_name == 'arg'
    assert test_param.type_name == 'type'
    assert test_param.is_optional == True
    assert test_param.default == 'default'


# Generated at 2022-06-21 11:39:07.001099
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises(): 
    obj4 = DocstringRaises(args=[], description='Not enough parameters', type_name=None)
    obj4.args
    obj4.description
    obj4.type_name



# Generated at 2022-06-21 11:39:09.798967
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated([":deprecated"], "it is deprecated", "3.0")
    assert d.type_name is None
    assert d.description == "it is deprecated"
    assert d.version == "3.0"



# Generated at 2022-06-21 11:39:12.181072
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(["a"], "b")
    assert docstring.args == ["a"]
    assert docstring.description == "b"



# Generated at 2022-06-21 11:39:16.697345
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(['param'], "Help", "x", "int", False, None)
    assert(p.args == ['param'])
    assert(p.description == "Help")
    assert(p.arg_name == "x")
    assert(p.type_name == "int")
    assert(p.is_optional == False)
    assert(p.default == None)

#Unit test for constructor of class DocstringReturns

# Generated at 2022-06-21 11:39:20.101640
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []
# End unit test for constructor of class Docstring


# Generated at 2022-06-21 11:39:21.402153
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Error")
    assert("Error" in error.args[0])

# Generated at 2022-06-21 11:39:25.294422
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(
    args=['deprecated'],
    description='This is old since version 2.3',
    version='2.3'
    )



# Generated at 2022-06-21 11:39:30.311925
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated", "since", "v1"], "description", "v1")
    assert d.args[0] == "deprecated"
    assert d.args[1] == "since"
    assert d.args[2] == "v1"
    assert d.description == "description"
    assert d.version == "v1"

# Generated at 2022-06-21 11:39:32.796226
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test constructor with minimal required arguments
    param = DocstringParam(args=["param"], description="Test docstring")
    assert param.args == ["param"]
    assert param.description == "Test docstring"


# Generated at 2022-06-21 11:40:18.897523
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([], None, None)


# Generated at 2022-06-21 11:40:24.207995
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # pylint: disable=C0103
    assert DocstringReturns(['returns', ':', 'type', ':', 'str'], None, 'str', False)
    assert DocstringReturns(['yields', ':', 'type', ':', 'str'], None, 'str', True)

# Generated at 2022-06-21 11:40:30.742446
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Check the constructor of class DocstringDeprecated.

    Parameters:
        args (str): DocstringArgs
        description (str): DocstringDecription
        version (str): DocstringVersion

    Return:
        init (DocstringDeprecated): docstring metadata.

    """
    return DocstringDeprecated(args = 'DocstringArgs',
                               description = 'DocstringDecription',
                               version = 'DocstringVersion')


# Generated at 2022-06-21 11:40:34.578636
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError()
    assert issubclass(p.__class__, RuntimeError)



# Generated at 2022-06-21 11:40:37.942256
# Unit test for constructor of class Docstring
def test_Docstring():
    test1 = Docstring()
    test1.short_description = "complex"
    assert test1.short_description == "complex"
    test1.long_description = "complex"
    assert test1.long_description == "complex"


# Generated at 2022-06-21 11:40:42.102701
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["a", "b", "c"], "test").args == ["a", "b", "c"]
    assert DocstringMeta(["a", "b", "c"], "test").description == "test"
    assert DocstringMeta([], "test").args == []
    assert DocstringMeta([], "test").description == "test"


# Generated at 2022-06-21 11:40:43.783483
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["and","and"], "sdjfkdjf", "  str    ", True, "__init__")


# Generated at 2022-06-21 11:40:45.501055
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["param"], "Simple description")
    assert dm.args == ["param"]
    assert dm.description == "Simple description"



# Generated at 2022-06-21 11:40:49.098347
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([""], "")
    DocstringReturns([""], "", None)
    DocstringReturns([""], "", "None")
    DocstringReturns([""], "", "None", True)
    DocstringReturns([""], "", "None", False, "arg_name")

# Generated at 2022-06-21 11:40:52.519684
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(args=[], description="test description")
    assert docstring_meta.args == []
    assert docstring_meta.description == "test description"



# Generated at 2022-06-21 11:43:04.248133
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['mystring']
    description = 'This is a string'
    arg_name = 'mystring'
    type_name = 'string'
    is_optional = False
    default = 'Hello World'
    instance = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert(instance.args == ['mystring'])
    assert(instance.description == 'This is a string')
    assert(instance.arg_name == 'mystring')
    assert(instance.type_name == 'string')
    assert(instance.is_optional == False)
    assert(instance.default == 'Hello World')
    print('test_DocstringParam passed')



# Generated at 2022-06-21 11:43:05.008362
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    pass


# Generated at 2022-06-21 11:43:08.589913
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None


# Generated at 2022-06-21 11:43:12.624036
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    new_docstringReturns = DocstringReturns(
        "Testing", "Testing the docstring class", "test1", True)
    assert new_docstringReturns.args == "Testing"
    assert new_docstringReturns.description == "Testing the docstring class"
    assert new_docstringReturns.type_name == "test1"
    assert new_docstringReturns.is_generator == True
    assert new_docstringReturns.return_name == None
    

# Generated at 2022-06-21 11:43:14.268376
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """docstring for testing DocstringMeta class."""
    try:
        DocstringMeta([], '')
    except Exception:
        return False
    return True


# Generated at 2022-06-21 11:43:19.447691
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Check single line argument
    docstring = DocstringDeprecated(
        args=[":deprecated:"], description=None, version=None
    )
    assert docstring.args == [":deprecated:"]
    assert docstring.description == None
    assert docstring.version == None

    # Check multi line argument
    docstring = DocstringDeprecated(
        args=":deprecated:", description="test", version="0.1"
    )
    assert docstring.args == ":deprecated:"
    assert docstring.description == "test"
    assert docstring.version == "0.1"



# Generated at 2022-06-21 11:43:25.865438
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.meta == []
    ds.meta = [1]
    assert ds.meta == [1]
    assert ds.short_description is None
    ds.short_description = "Short"
    assert ds.short_description == "Short"
    assert ds.long_description is None
    ds.long_description = "Long"
    assert ds.long_description == "Long"

# Generated at 2022-06-21 11:43:28.286911
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ds = DocstringMeta("args", "description")
    assert ds.args == "args"
    assert ds.description == "description"



# Generated at 2022-06-21 11:43:34.454552
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises"""
    # inputs
    args = ['a', 'b', 'c']
    description = 'Test raises'
    type_name = 'ValueError'
    # init and test
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name
    assert docstring_raises.args == args
    

# Generated at 2022-06-21 11:43:40.023631
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg1','arg2','arg3','arg4']
    description = "Description1"
    assert(DocstringMeta(args, description).args == args)
    assert(DocstringMeta(args, description).description == description)
    assert(isinstance(DocstringMeta(args, description), DocstringMeta))
