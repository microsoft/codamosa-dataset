

# Generated at 2022-06-21 11:34:18.685714
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['param', 'arg'], 'description', 'arg_name',\
            'type_name', True, 'default')
    assert param.args == ['param', 'arg']
    assert param.description == 'description'
    assert param.arg_name == 'arg_name'
    assert param.type_name == 'type_name'
    assert param.is_optional == True
    assert param.default == 'default'



# Generated at 2022-06-21 11:34:21.323823
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta = DocstringRaises(["a"], "s", "Test")
    assert meta.args == ["a"]
    assert meta.type_name == "Test"
    assert meta.description == "s"



# Generated at 2022-06-21 11:34:25.795856
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    args = []
    description = None
    type_name = None
    is_generator = False
    return_name = None
    assert DocstringReturns(args, description, type_name, is_generator, return_name)

# Generated at 2022-06-21 11:34:36.323570
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = Docstring()
    line = ":raises ValueError: if something happens"
    buf = line.split()
    i = 1
    item_args = []
    while i < len(buf):
        if buf[i][0] == ":":
            break
        item_args.append(buf[i])
        i += 1
    # i points to the first colon of the first meta argument
    # item_args is a list of the words "raises", "ValueError"
    # buf[i] is ":raises"
    type_name = None
    description = None
    if i + 1 < len(buf) and buf[i + 1][0] != ":":
        # The meta spec has a type name
        type_name = buf[i + 1]

# Generated at 2022-06-21 11:34:38.698442
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(
        ["raises"], T.Optional[str]("description"), "ValueError"
    )
    assert doc.description == "description"


# Generated at 2022-06-21 11:34:43.903308
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    x = DocstringDeprecated([':deprecated'], 'this is deprecated', '3.3.3')
    assert(x.args[0] == ':deprecated')
    assert(x.description == 'this is deprecated')
    assert(x.version == '3.3.3')


# Generated at 2022-06-21 11:34:48.331204
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_docstring_deprecated = DocstringDeprecated([], "description", None)
    assert test_docstring_deprecated.description == "description"
    assert test_docstring_deprecated.args == []
    assert test_docstring_deprecated.version is None


# Generated at 2022-06-21 11:34:51.478312
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """DocstringMeta symbolizing :raises metadata."""
    DocstringRaises(["a", "b", "c"], "descr", "typename")

# Generated at 2022-06-21 11:34:59.813081
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    parameter_name = "age"
    description = "Age of the person"
    type = "int"
    is_optional = False
    default = None
    doc_string_param = DocstringParam([], description, parameter_name, type, is_optional, default)
    # Test for parameters is sucessful
    assert(len(doc_string_param.args) == 0)
    assert(doc_string_param.description == description)
    assert(doc_string_param.arg_name == parameter_name)
    assert(doc_string_param.type_name == type)
    assert(doc_string_param.is_optional == is_optional)
    assert(doc_string_param.default == default)
    # Check if the is_optional parameter is inferable
    doc_string_param.default = "something"
   

# Generated at 2022-06-21 11:35:08.006805
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args1 = ["yield", "yields"]
    description1 = "Even numbers."
    type_name1 = "int"
    is_generator1 = True
    returns1 = DocstringReturns(args1, description1, type_name1, is_generator1)
    
    assert returns1.args == args1
    assert returns1.description == description1
    assert returns1.type_name == type_name1
    assert returns1.is_generator == is_generator1

# Generated at 2022-06-21 11:35:20.646783
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []
    assert Docstring().params == []
    assert Docstring().raises == []
    assert Docstring().returns == None
    assert Docstring().deprecation == None

# Generated at 2022-06-21 11:35:32.041097
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=[], description=None, arg_name=None, type_name=None, is_optional=True, default=None).args == []
    assert DocstringParam(args=[], description=None, arg_name=None, type_name=None, is_optional=True, default=None).description == None
    assert DocstringParam(args=[], description=None, arg_name=None, type_name=None, is_optional=True, default=None).arg_name == None
    assert DocstringParam(args=[], description=None, arg_name=None, type_name=None, is_optional=True, default=None).type_name == None

# Generated at 2022-06-21 11:35:36.407925
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["raises", "Exception"], description="exceptional", type_name="Exception")
    assert(a.args == ["raises", "Exception"])
    assert(a.description == "exceptional")
    assert(a.type_name == "Exception")


# Generated at 2022-06-21 11:35:46.272203
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = "is_optional"
    default = "default"

    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == []
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == "is_optional"
    assert dp.default == "default"

test_DocstringParam()


# Generated at 2022-06-21 11:35:51.623219
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []

# Unit tests for property params of class Docstring

# Generated at 2022-06-21 11:36:03.049218
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns_args = ["Raises", "ValueError", "if", "something", "happens"]
    returns_description = "Raises a ValueError if something happens"
    returns_type_name = "ValueError"
    returns_is_generator = False
    returns_return_name = "returns"
    returns = DocstringReturns(returns_args,
            returns_description,
            returns_type_name,
            returns_is_generator,
            returns_return_name)
    assert returns.description == returns_description
    assert returns.type_name == returns_type_name
    assert returns.is_generator == returns_is_generator
    assert returns.return_name == returns_return_name


# Generated at 2022-06-21 11:36:05.636217
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_obj = DocstringMeta(["param"], "description")
    assert test_obj.args == ["param"]
    assert test_obj.description == "description"


# Generated at 2022-06-21 11:36:07.770273
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert(DocstringMeta([], "description").args == [])
    assert(DocstringMeta([], "description").description == "description")


# Generated at 2022-06-21 11:36:14.950487
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Confirm that default values provided by the DocstringRaises class are initialized."""
    # Create a new instance of DocstringRaises class
    docstring_raises = DocstringRaises("args", "description", "type_name")
    # Check each of the values
    assert docstring_raises.args == "args"
    assert docstring_raises.description == "description"
    assert docstring_raises.type_name == "type_name"


# Generated at 2022-06-21 11:36:23.042604
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    import pytest
    args = ["args", "example", "examples"]
    description = "description"
    doc_string = DocstringMeta(args, description)
    assert doc_string.args == ["args", "example", "examples"]
    assert doc_string.description == "description"
    args = []
    description = None
    doc_string = DocstringMeta(args, description)
    assert doc_string.args == []
    assert doc_string.description == None


# Generated at 2022-06-21 11:36:28.782434
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(Docstring, object)

# Generated at 2022-06-21 11:36:40.949317
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    # unit test for constructor of class DocstringReturns with full parameter
    def test_DocstringReturns_with_full_parameter():
        args = ["return", "returns"]
        description = "return type"
        type_name = "str"
        return_name = "dummy variable"
        is_generator = False
        returns = DocstringReturns(args, description, type_name, is_generator, return_name)
        assert returns.args == args
        assert returns.description == description
        assert returns.type_name == type_name
        assert returns.return_name == return_name
        assert returns.is_generator == is_generator

    # unit test for constructor of class DocstringReturns with optional parameter
    def test_DocstringReturns_with_optional_parameter():
        args = ["return", "returns"]


# Generated at 2022-06-21 11:36:44.316080
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(args=['a', 'b'], description='c')
    assert a.args == ['a', 'b']
    assert a.description == 'c'



# Generated at 2022-06-21 11:36:46.443459
# Unit test for constructor of class ParseError
def test_ParseError():
    me = ParseError('test')
    assert str(me) == 'test'


# Generated at 2022-06-21 11:36:50.849039
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(args=[], description=None, type_name=None)
    assert ds.type_name is None
    assert ds.description is None
    assert ds.args ==[]

# Generated at 2022-06-21 11:36:55.764193
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    return docstring

# Generated at 2022-06-21 11:36:57.075959
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param", "arg"], "description")

# Generated at 2022-06-21 11:37:00.352491
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test msg")
        assert False
    except ParseError:
        assert True
    except:
        assert False


# Generated at 2022-06-21 11:37:04.922764
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test the constructor of class DocstringMeta."""
    obj = DocstringMeta(args = ['arg', 'arg'], description = 'description')
    assert obj.args == ['arg', 'arg']
    assert obj.description == 'description'


# Generated at 2022-06-21 11:37:09.874710
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        ["param"],
        "Test param",
        "arg",
        "arg_type",
        False,
        None)
    assert param.description == "Test param"
    assert param.arg_name == "arg"
    assert param.type_name == "arg_type"
    assert not param.is_optional
    assert param.default is None


# Generated at 2022-06-21 11:37:20.812078
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d_param = DocstringParam(
        args=['param', 'p'],
        description='a parameter',
        arg_name='p',
        type_name=None,
        is_optional=False,
        default=None
    )
    assert d_param.args == ['param', 'p']
    assert d_param.description == 'a parameter'
    assert d_param.arg_name == 'p'
    assert d_param.type_name is None
    assert d_param.is_optional is False
    assert d_param.default is None


# Generated at 2022-06-21 11:37:23.687965
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []



# Generated at 2022-06-21 11:37:25.220042
# Unit test for constructor of class ParseError
def test_ParseError():
    parseError = ParseError("test")
    assert parseError.args == ("test",)


# Generated at 2022-06-21 11:37:28.994286
# Unit test for constructor of class Docstring
def test_Docstring():
    test_Docstring = Docstring()
    assert isinstance(test_Docstring, Docstring)
    assert test_Docstring.short_description is None
    assert test_Docstring.long_description is None
    assert test_Docstring.blank_after_short_description is False
    assert test_Docstring.blank_after_long_description is False
    assert test_Docstring.meta == []

# Generated at 2022-06-21 11:37:30.394481
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err is not None


# Generated at 2022-06-21 11:37:32.865461
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test = DocstringReturns(['a'], 'b', 'c', True)



# Generated at 2022-06-21 11:37:39.249188
# Unit test for constructor of class Docstring
def test_Docstring():
    d= Docstring()
    assert d.short_description== None
    assert d.long_description== None
    assert d.blank_after_short_description== False
    assert d.blank_after_long_description== False
    assert d.meta== []
    assert d.params== []
    assert d.raises== []
    assert d.returns== None
    assert d.deprecation== None

# Generated at 2022-06-21 11:37:42.285284
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_meta = DocstringParam(
        args=['param'],
        description='A parameter',
        arg_name='arg',
        type_name='type',
        is_optional=True,
        default='default',
    )


# Generated at 2022-06-21 11:37:46.178029
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'Yes'
    version = '2.0'
    assert DocstringDeprecated(args, description, version).args == ['deprecated']
    assert DocstringDeprecated(args, description, version).description == 'Yes'
    assert DocstringDeprecated(args, description, version).version == '2.0'

# Generated at 2022-06-21 11:37:52.829667
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []
    assert a.params == []
    assert a.raises == []
    assert a.returns is None
    assert a.deprecation is None


# Generated at 2022-06-21 11:37:59.695098
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["desc"], None, None)
    assert d.args == ["desc"]
    assert d.description == None
    assert d.version == None


# Generated at 2022-06-21 11:38:11.216190
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    D1 = DocstringDeprecated(['deprecated'], 'This function is deprecated.', '7.5.0')
    D2 = DocstringDeprecated(['deprecated'], 'This function is deprecated.', None)
    D3 = DocstringDeprecated(['deprecated'], None, '7.5.0')
    assert (D1.args == ['deprecated'])
    assert (D1.description == 'This function is deprecated.')
    assert (D1.version == '7.5.0')
    assert (D2.args == ['deprecated'])
    assert (D2.description == 'This function is deprecated.')
    assert (D2.version is None)
    assert (D3.args == ['deprecated'])
    assert (D3.description is None)

# Generated at 2022-06-21 11:38:13.366826
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert 1 == 1

# Generated at 2022-06-21 11:38:23.916209
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test constructor with empty string
    _DocstringDeprecated_ = DocstringDeprecated("", None, None)
    assert _DocstringDeprecated_.description is None
    assert _DocstringDeprecated_.version is None
    assert _DocstringDeprecated_.args == []

    # Test constructor with empty list
    _DocstringDeprecated_ = DocstringDeprecated([], None, None)
    assert _DocstringDeprecated_.description is None
    assert _DocstringDeprecated_.version is None
    assert _DocstringDeprecated_.args == []

    # Test constructor with different values
    _DocstringDeprecated_ = DocstringDeprecated("deprecated", None, "1.0.0")
    assert _DocstringDeprecated_.description is None
    assert _DocstringDeprecated_.version == "1.0.0"
    assert _DocstringDeprecated_.args

# Generated at 2022-06-21 11:38:28.461244
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	# Test for DocstringMeta with arg, description, arg_name, type_name, is_optional, default
	test_DocstringMeta_object = DocstringMeta(["args"], "description lines")
	assert test_DocstringMeta_object.args == ["args"]
	assert test_DocstringMeta_object.description == "description lines"


# Generated at 2022-06-21 11:38:30.347398
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 11:38:40.215247
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"
    try:
        raise ParseError("{}")
    except ParseError as e:
        assert str(e) == "{}"
    try:
        raise ParseError("{}, {}")
    except ParseError as e:
        assert str(e) == "{}, {}"
    try:
        raise ParseError("{}, {}", 1, 2)
    except ParseError as e:
        assert str(e) == "{}, {}"
    try:
        raise ParseError("{}, {}", (1, 2))
    except ParseError as e:
        assert str(e) == "{}, {}"

# Generated at 2022-06-21 11:38:44.141101
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    #Arrange
    arguments = ["Argument"]
    description = "description"

    # Act
    test = DocstringMeta(arguments, description)

    # Assert
    assert test.args == arguments
    assert test.description == description


# Generated at 2022-06-21 11:38:48.830640
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []



# Generated at 2022-06-21 11:38:51.983315
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg_list"]
    description = "This is a description"

    docstringMeta = DocstringMeta(args, description)

    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-21 11:39:07.940573
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['param', 'arg'], 'description')
    assert d.args == ['param', 'arg']
    assert d.description == 'description'
    
    d1 = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    d2 = DocstringReturns(['raises', 'except'], 'description', 'type_name', True)
    assert isinstance(d1, DocstringMeta)
    assert isinstance(d2, DocstringMeta)
    assert d1.arg_name == 'arg_name'
    assert d1.type_name == 'type_name'
    assert d1.is_optional == 'is_optional'
    assert d1.default == 'default'

# Generated at 2022-06-21 11:39:09.164514
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError('A value error occurred')


# Generated at 2022-06-21 11:39:10.910182
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1: test with no parameter
    assert(DocstringParam([], "test") != None)


# Generated at 2022-06-21 11:39:15.763874
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_test = DocstringDeprecated(["deprecated"], "this method is deprecated", "2")
    assert docstring_deprecated_test.args == ["deprecated"], "should be ['deprecated']"
    assert docstring_deprecated_test.description == "this method is deprecated", "should be this method is deprecated"
    assert docstring_deprecated_test.version == "2", "should be 2"



# Generated at 2022-06-21 11:39:21.044356
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Creation of a DocstringDeprecated instance
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'deprecated', '2.0')
    assert docstring_deprecated is not None
    # Test of the attributes
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'deprecated'
    assert docstring_deprecated.version == '2.0'


# Generated at 2022-06-21 11:39:23.107510
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([],[], [])

# Generated at 2022-06-21 11:39:29.603617
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(['returns', 'string'], 'the return thingy', 'string', False, 'result')
    assert docstring_returns.args == ['returns', 'string']
    assert docstring_returns.description == 'the return thingy'
    assert docstring_returns.type_name == 'string'
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == 'result'

# Generated at 2022-06-21 11:39:32.759269
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for Docstring constructor."""
    try:
        raise ParseError("message")
    except ParseError as e:
        assert e.args[0] == "message"
    else:
        assert False, "No exception raised"



# Generated at 2022-06-21 11:39:41.109702
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    parametros = list()
    parametros.append(':returns')
    parametros.append(':descrição retorno')
    parametros.append(':tipo string')
    parametros.append(':parâmetro opcional')
    parametros.append(':default parametro')
    parametros.append(':generator')
    returns = DocstringReturns(args = parametros, description = "descrição retorno", type_name = "string", is_generator = True, return_name = 'opcional')
    print(returns)

# Generated at 2022-06-21 11:39:49.116824
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "this is a docstring"
    arg_name = "arg"
    type_name = "int"
    is_optional = True
    default = " 0"
    ds = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert ds.args==args
    assert ds.description == description
    assert ds.arg_name == arg_name
    assert ds.type_name == type_name
    assert ds.is_optional == is_optional
    assert ds.default == default

# Generated at 2022-06-21 11:40:01.327988
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(['parameter'], 'description', 'type_name')
    assert x.args == ['parameter']
    assert x.description == 'description'
    assert x.type_name == 'type_name'

# Generated at 2022-06-21 11:40:06.236202
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg', 'argument']
    description = 'description'
    type_name = 'type_name'
    is_generator = False
    return_name = 'return_name'
    DocstringReturns(args, description, type_name,
                     is_generator, return_name)



# Generated at 2022-06-21 11:40:11.246198
# Unit test for constructor of class Docstring
def test_Docstring():
    my_Docstring=Docstring()
    assert my_Docstring.short_description == None
    assert my_Docstring.long_description == None
    assert my_Docstring.blank_after_short_description == False
    assert my_Docstring.blank_after_long_description == False
    assert my_Docstring.meta == []



# Generated at 2022-06-21 11:40:18.508295
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        args=["param"],
        description="This is a parameter",
        arg_name="test",
        type_name="int",
        is_optional=True,
        default="5",
    )
    assert param.args == ["param"], "param.args should be ['param']"
    assert param.description == "This is a parameter", "param.description should be 'This is a parameter'"
    assert param.arg_name == "test", "param.arg_name should be 'test'"
    assert param.type_name == "int", "param.type_name should be 'int'"
    assert param.is_optional == True, "param.is_optional should be True"
    assert param.default == "5", "param.default should be '5'"

# Generated at 2022-06-21 11:40:22.216146
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param']
    description = 'description'
    dm = DocstringMeta(args, description)
    assert dm.args == ['param']
    assert dm.description == 'description'


# Generated at 2022-06-21 11:40:24.449727
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['raises'], 'value error', 'int', False)


# Generated at 2022-06-21 11:40:31.229814
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns is None
    assert ds.deprecation is None


# Generated at 2022-06-21 11:40:37.224193
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # with
    docstring_item = DocstringDeprecated(args=["args"], description="description", version="version")

    # assert
    assert docstring_item.args == ["args"]
    assert docstring_item.description == "description"
    assert docstring_item.version == "version"


# Generated at 2022-06-21 11:40:39.054032
# Unit test for constructor of class ParseError
def test_ParseError():
    with raises(ParseError):
        raise ParseError("oops")

# Unit Test for function is_param_line

# Generated at 2022-06-21 11:40:42.261898
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test the class DocstringMeta."""
    args = ["args", "arg", "argument"]
    description = "The description of the DocstringMeta"
    meta = DocstringMeta(args, description)
    assert meta.args == args
    assert meta.description == description


# Generated at 2022-06-21 11:41:11.471876
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"], "description")
    assert docstring_meta.args == ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    assert docstring_meta.description == "description"


# Generated at 2022-06-21 11:41:14.485651
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["DeprecationWarning"]
    description = "this function is deprecated"
    version = "0.0.1"
    DocstringDeprecated(args, description, version)

# Generated at 2022-06-21 11:41:16.829520
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(['Raises ValueError'], 'If something goes wrong')
    assert meta.args == ['Raises ValueError']
    assert meta.description == 'If something goes wrong'



# Generated at 2022-06-21 11:41:24.006891
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a=DocstringReturns(args=['arg1'], description=None, type_name=None, is_generator=True, return_name=None)
    assert a.args == ['arg1']
    assert a.description == None
    assert a.type_name == None
    assert a.is_generator == True
    assert a.return_name == None



# Generated at 2022-06-21 11:41:25.615807
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert error


# Generated at 2022-06-21 11:41:32.182762
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  docstr = 'DocstringMeta symbolizing :param metadata'
  args = 'list of arguments'
  description = 'associated docstring description'
  arg_name = 'arg'
  type_name = 'string'
  is_optional = True
  default = 'None'
  doc_par = DocstringParam(args, description, arg_name, type_name, is_optional, default)
  assert doc_par.description == description
  assert doc_par.args == args
  assert doc_par.arg_name == arg_name
  assert doc_par.type_name == type_name
  assert doc_par.is_optional == is_optional
  assert doc_par.default == default

if __name__ == '__main__':
  test_DocstringParam()

# Generated at 2022-06-21 11:41:34.041412
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    sample = DocstringMeta([], "")
    assert sample.args == []
    assert sample.description == ""


# Generated at 2022-06-21 11:41:35.376149
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['param', 'arg'], 'description')


# Generated at 2022-06-21 11:41:40.233046
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring()
    assert (docstr.short_description is None)
    assert (docstr.long_description is None)
    assert (docstr.blank_after_short_description is False)
    assert (docstr.blank_after_long_description is False)
    assert (docstr.meta == [])
# test_Docstring


# Generated at 2022-06-21 11:41:45.662254
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("Testing constructor of DocstringParam()")
    args = ["arg1", "arg2"]
    description = "Returns an instance of the DocstringParam class"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = False
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-21 11:42:37.246490
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_object = DocstringReturns(args=['return', 'returns'], description=None, type_name=None, is_generator=False, return_name=None)

    assert return_object is not None
    assert return_object.args == ['return', 'returns']
    assert return_object.description == None
    assert return_object.type_name == None
    assert return_object.is_generator == False
    assert return_object.return_name == None
#test end


# Generated at 2022-06-21 11:42:42.394907
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	print ("-----TESTING DocstringParam-----")
	args = []
	description = "test dsc"
	arg_name = "argName"
	type_name = "int"
	is_optional = False
	default = 4
	assert args == []
	assert description == "test dsc"
	assert arg_name == "argName"
	assert type_name == "int"
	assert is_optional == False
	assert default == 4
	print ("SUCCESSFULLY PASSED TESTING OF DocstringParam")



# Generated at 2022-06-21 11:42:44.080792
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["a"], "b").args == ["a"]
    assert DocstringMeta(["a"], "b").description == "b"

# Generated at 2022-06-21 11:42:44.890346
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert True


# Generated at 2022-06-21 11:42:46.445632
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], None, None)



# Generated at 2022-06-21 11:42:49.928478
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['raises', 'ValueError', ':', 'if', 'something', 'happens'], 'description', 'ValueError')
    assert a.args == ['raises', 'ValueError', ':', 'if', 'something', 'happens']
    assert a.description == 'description'
    assert a.type_name == 'ValueError'


# Generated at 2022-06-21 11:42:52.096026
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['a'], 'b', 'c')
    assert d.args == ['a']
    assert d.description == 'b'
    assert d.type_name == 'c'


# Generated at 2022-06-21 11:42:56.931286
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['yields'], None, None, False)
    b = DocstringReturns(['raises'], None, None, False)
    c = DocstringReturns(['returns'], None, None, False)
    d = DocstringReturns(['Raises'], None, None, False)
    e = DocstringReturns(['YIELDS'], None, None, False)
    assert a.is_generator == False
    assert b.is_generator == False
    assert c.is_generator == False
    assert d.is_generator == False
    assert e.is_generator == False

# Generated at 2022-06-21 11:42:58.524471
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "")


# Generated at 2022-06-21 11:43:00.456724
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(['a','b'], 'c')
    assert doc.args == ['a','b']
    assert doc.description == 'c'