

# Generated at 2022-06-21 11:34:15.070606
# Unit test for constructor of class Docstring
def test_Docstring():

    d = Docstring()
    print("Docstring has successfully been created!")


# Generated at 2022-06-21 11:34:19.661184
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test function for the constructor of the class DocstringRaises."""
    args = ["raises"]
    description = "This raises an exception of type ValueError"
    type_name = "ValueError"
    test_instance = DocstringRaises(args, description, type_name)
    assert test_instance.args == ["raises"]
    assert test_instance.description == description
    assert test_instance.type_name == type_name



# Generated at 2022-06-21 11:34:24.325996
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []
    assert a.params == []
    assert a.raises == []
    assert a.returns is None
    assert a.deprecation is None

# Unit tests for property 'params' of class Docstring

# Generated at 2022-06-21 11:34:27.976639
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    check = DocstringRaises(
        [' :', 'raises', 'IOError', ':'], 'An error occured while reading.', 'IOError'
    )
    assert isinstance(check, DocstringRaises)


# Generated at 2022-06-21 11:34:30.433508
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert isinstance(DocstringRaises(["param"], "description", "type_name"), DocstringRaises)


# Generated at 2022-06-21 11:34:34.139243
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "version 3.2")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "version 3.2"
    assert docstring.version == "3.2"

# Generated at 2022-06-21 11:34:36.252672
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        DocstringReturns([], None, None, True)
        assert False
    except:
        assert True


# Generated at 2022-06-21 11:34:37.144054
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	assert DocstringReturns(None,None,None,None)

# Generated at 2022-06-21 11:34:43.389098
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(None, "test description", "test arg", "test type", False, "test def")
    assert d.args is None
    assert d.description == "test description"
    assert d.arg_name == "test arg"
    assert d.type_name == "test type"
    assert d.is_optional == False
    assert d.default == "test def"


# Generated at 2022-06-21 11:34:47.222407
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Oops!")
    except ParseError as exception:
        assert str(exception) == "Oops!"
    else:
        assert False, "No exception was raised"


# Generated at 2022-06-21 11:34:54.093326
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(["deprecated"], "", "")
    assert(obj.args == ["deprecated"])
    assert(obj.description is "")
    assert(obj.version is "")


# Generated at 2022-06-21 11:34:56.328068
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert isinstance(DocstringReturns(["a", "b", "c"], "hello", "", True), DocstringReturns)


# Generated at 2022-06-21 11:34:58.363971
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    Test for ParseError
    """
    with pytest.raises(ParseError):
        raise ParseError


# Generated at 2022-06-21 11:35:06.959809
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the DocstringParam constructor."""
    docstring_meta = DocstringParam(['param'], None, 'arg', 'str', True, None)
    assert isinstance(docstring_meta, DocstringParam)
    assert docstring_meta.args == ['param']
    assert docstring_meta.description == None
    assert docstring_meta.arg_name == 'arg'
    assert docstring_meta.type_name == 'str'
    assert docstring_meta.is_optional == True
    assert docstring_meta.default == None


# Generated at 2022-06-21 11:35:12.726731
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        from mock import Mock

        docstring = DocstringDeprecated(Mock(), None, None)
        assert getattr(docstring, "_DocstringDeprecated__args", None) is not None
        assert getattr(docstring, "_DocstringDeprecated__description", None) is not None
        assert getattr(docstring, "_DocstringDeprecated__version", None) is not None
    except:
        pass
    finally:
        print("Unit test for constructor in DocstringDeprecated finished")


# Generated at 2022-06-21 11:35:19.134387
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises
    """
    args = ['raises', 'Raises']
    type_name = 'ValueError'
    description = 'if something happens'
    raises_error = DocstringRaises(args, description, type_name)
    assert raises_error.args == args
    assert raises_error.description == description
    assert raises_error.type_name == type_name

# Generated at 2022-06-21 11:35:20.646769
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description")


# Generated at 2022-06-21 11:35:24.874576
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 0




# Generated at 2022-06-21 11:35:26.515480
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert isinstance(a, Docstring)




# Generated at 2022-06-21 11:35:35.618437
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # try to initialize the class with expected parameters

    args = ['arg','args','argument','arguments','param','parameter','params','parameters','key','keyword','keys','keywords','attributes','attribute']
    description = 'description'
    dp = DocstringParam(args, description, 'arg_name', 'type_name', 'is_optional', 'default')
    assert(dp.args) == args
    assert(dp.description) == description
    assert(dp.arg_name) == 'arg_name'
    assert(dp.type_name) == 'type_name'
    assert(dp.is_optional) == 'is_optional'
    assert(dp.default) == 'default'


# Generated at 2022-06-21 11:35:43.000484
# Unit test for constructor of class ParseError
def test_ParseError():
    print("Running test_ParseError()...")
    err = ParseError("test")
    assert isinstance(err, ParseError)
    print("Finished test_ParseError()")



# Generated at 2022-06-21 11:35:50.017919
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns = DocstringReturns(["return", "returns"], 'x', 'int', False, 'result')
    assert docstringReturns.args == ["return", "returns"]
    assert docstringReturns.description == 'x'
    assert docstringReturns.type_name == 'int'
    assert docstringReturns.is_generator is False
    assert docstringReturns.return_name == 'result'


# Generated at 2022-06-21 11:35:56.983292
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    parameters = [":raises", ":exception", ":except"]
    type_name = "Error"
    description = "Something went wrong"
    docstringRaises = DocstringRaises(parameters, description, type_name)
    
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name
    assert docstringRaises.args == parameters
    
test_DocstringRaises()


# Generated at 2022-06-21 11:36:07.999373
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    name = "args"
    argument_name = "arg"
    type_name = None
    is_optional = True
    default = None
    description = "description"

    assert (
        DocstringParam(name, description, argument_name, type_name,
        is_optional, default).args == name
    )
    assert (
        DocstringParam(name, description, argument_name, type_name,
        is_optional, default).type_name == type_name
    )
    assert (
        DocstringParam(name, description, argument_name, type_name,
        is_optional, default).is_optional == is_optional
    )
    assert (
        DocstringParam(name, description, argument_name, type_name,
        is_optional, default).description == description
    )

# Generated at 2022-06-21 11:36:13.536194
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['args']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = 1
    default = 'default'

    assert DocstringParam(args, description, arg_name, type_name, is_optional, default) is not None

# Generated at 2022-06-21 11:36:15.399407
# Unit test for constructor of class ParseError
def test_ParseError():
    assert True
    print("ERR: Couldn't test constructor of class ParseError")


# Generated at 2022-06-21 11:36:22.299048
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param"]
    description = "Some description"
    arg_name = "arg"
    type_name = None
    is_optional = True
    default = "None"
    item = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    if item.arg_name != arg_name:
        raise Exception("Error: wrong arg_name")
    if item.args != args:
        raise Exception("Error: wrong args")
    if item.description != description:
        raise Exception("Error: wrong description")
    if item.type_name != type_name:
        raise Exception("Error: wrong type_name")
    if item.is_optional != is_optional:
        raise Exception("Error: wrong is_optional")

# Generated at 2022-06-21 11:36:24.905039
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_long_description is False
    assert docstring.blank_after_short_description is False
    assert docstring.meta is []


# Generated at 2022-06-21 11:36:29.088031
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["test", "test", "test"], "test", "test")
    assert docstring_raises.args == ["test", "test", "test"]
    assert docstring_raises.description == "test"
    assert docstring_raises.type_name == "test"

# Generated at 2022-06-21 11:36:34.465284
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns([":return:",":returns:"], "returns something","type_name")
    assert d.args == [":return:",":returns:"]
    assert d.description == "returns something"
    assert d.type_name == "type_name"


# Generated at 2022-06-21 11:36:54.165814
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['description'], 'test', 'int').description == 'test'
    assert DocstringReturns(['description'], 'test', 'int').type_name == 'int'
    assert DocstringReturns(['description'], 'test', 'int').return_name == None
    assert DocstringReturns(['description'], 'test', 'int', False, 'var').return_name == 'var'
    assert DocstringReturns(['description'], 'test', 'int').is_generator == False
    assert DocstringReturns(['description'], 'test', 'int', True).is_generator == True
# Test for property returns

# Generated at 2022-06-21 11:36:54.905275
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError('test')


# Generated at 2022-06-21 11:36:57.442431
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["key"], "description", "type_name")
    assert test.description == "description"
    assert test.type_name == "type_name"


# Generated at 2022-06-21 11:37:06.779389
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["type:", "parameter:", "arg:", "attribute:", "key:", "keyword:"]
    test_docstringmeta = DocstringMeta(args, 'arg1, arg2, and arg3 are the names of the arguments, and docstring is the corresponding description.')
    assert (test_docstringmeta.args == args)
    assert (test_docstringmeta.description == 'arg1, arg2, and arg3 are the names of the arguments, and docstring is the corresponding description.')
    print("test_DocstringMeta pass")

# Generated at 2022-06-21 11:37:09.833296
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    #create object
    ds = DocstringRaises(["hello"], "description", "type")
    assert ds.description == "description"
    assert ds.args == ["hello"]
    assert ds.type_name == "type"

# Generated at 2022-06-21 11:37:14.173612
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated("hello_world", "Hi", "3")
    assert docstring.version == "3"
    assert docstring.description == "Hi"
    assert docstring.args == "hello_world"


# Generated at 2022-06-21 11:37:15.902996
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test")
    assert pe.args == ("test", )


# Generated at 2022-06-21 11:37:18.273741
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error Message")
    except ParseError as err:
        assert err.args[0] == "Error Message"


# Generated at 2022-06-21 11:37:19.865228
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("ParseError")
    assert error.args == "ParseError"
    assert str(error) == "ParseError"

# Generated at 2022-06-21 11:37:22.070642
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = 1
    description = 2
    meta = DocstringMeta(args,description)
    assert meta.args == args
    assert meta.description == description

if __name__ == '__main__':
    test_DocstringMeta()

# Generated at 2022-06-21 11:37:34.537224
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of ParseError."""
    err = ParseError('message')
    assert err.args[0] == 'message'


# Generated at 2022-06-21 11:37:39.208512
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring()
    assert docstr.short_description is None
    assert docstr.long_description is None
    assert docstr.blank_after_short_description is False
    assert docstr.blank_after_long_description is False
    assert docstr.meta == []


# Generated at 2022-06-21 11:37:41.812731
# Unit test for constructor of class Docstring
def test_Docstring():
    # Constructor of class Docstring
    test = Docstring()
    assert test.short_description == None
    assert test.long_description == None
    assert test.meta == []


# Generated at 2022-06-21 11:37:43.349739
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('my message')
    except ParseError as e:
        print(e)

# Generated at 2022-06-21 11:37:50.349516
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # test constructor of class DocstringRaises
    docstring_raises = DocstringRaises(args=["raises"], description="if something happens", type_name="ValueError")
    assert docstring_raises.args == ["raises"]
    assert docstring_raises.description == "if something happens"
    assert docstring_raises.type_name == "ValueError"



# Generated at 2022-06-21 11:37:52.976674
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(1,"",1)
    assert d.args == 1
    assert d.description == ""
    assert d.version == 1


# Generated at 2022-06-21 11:37:57.277610
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test initialization of DocstringMeta object."""
    args = ["param"]
    description = "Describes the arg."
    dsm = DocstringMeta(args, description)
    assert dsm.args == ["param"]
    assert dsm.description == "Describes the arg."


# Generated at 2022-06-21 11:38:07.422749
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns']
    description = 'docstring'
    type_name = 'type'
    is_generator = 'yields'
    return_name = 'return'
    doc = DocstringReturns(args,description,type_name,is_generator,return_name)
    assert doc.description == 'docstring','description should return True'
    assert doc.type_name == 'type', 'type_name should return True'
    assert doc.is_generator == 'yields', 'is_generator should return True'
    assert doc.return_name == 'return', 'return_name should return True'
    assert doc.args == ['returns'], 'args should return True'


# Generated at 2022-06-21 11:38:13.745669
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Check whether the constructor of DocstringParam can be called without raising exception
    try:
        docstringParam = DocstringParam(args=[], description=None, arg_name='arg_name', type_name=None, is_optional=None, default=None)
        print('Test: constructor of DocstringParam is called without raising exception')
        print('Test passed')
    except:
        print('Test: constructor of DocstringParam is called with raising exception')
        print('Test failed')


# Generated at 2022-06-21 11:38:17.536528
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=[],description=None,type_name=None)


# Generated at 2022-06-21 11:38:29.995888
# Unit test for constructor of class ParseError
def test_ParseError():

    # creates a ParseError object
    test_error = ParseError()

    # checks if the object is an instance of the class and raises a TypeError
    assert isinstance(test_error, ParseError), TypeError('not of type ParseError?')



# Generated at 2022-06-21 11:38:34.467368
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated([], "", "")
    print(ds.args)
    print(ds.description)
    print(ds.version)
DocstringDeprecated([], "", "")

# Generated at 2022-06-21 11:38:39.106218
# Unit test for constructor of class Docstring
def test_Docstring():
    x=Docstring()
    assert x.short_description == None  # type: T.Optional[str]
    assert x.long_description == None  # type: T.Optional[str]
    assert x.blank_after_short_description == False
    assert x.blank_after_long_description == False
    assert x.meta == []  # type: T.List[DocstringMeta]



# Generated at 2022-06-21 11:38:43.302006
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['returns', ':', 'type_name'], 'description', 'type_name', False)
    DocstringReturns(['returns', ':', 'type_name'], 'description', 'type_name', False, 'return_name')

# Generated at 2022-06-21 11:38:48.420667
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args=['raises']
    description='if something happens'
    type_name='ValueError'
    dsr=DocstringRaises(args,description,type_name)

    assert dsr.args==args
    assert dsr.description==description
    assert dsr.type_name==type_name


# Generated at 2022-06-21 11:38:52.521206
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args=['TypeError']
    desc='Error when file not found'
    name='TypeError'
    d=DocstringRaises(args,desc,name)
    assert d.args==['TypeError']
    assert d.description=='Error when file not found'
    assert d.type_name=='TypeError'


# Generated at 2022-06-21 11:38:55.431177
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["asd"]
    dscr = "asd"
    tname = "asd"
    is_generator = True
    print(DocstringReturns(args, dscr, tname, is_generator))


# Generated at 2022-06-21 11:39:07.275027
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param']
    description = 'description'
    type_name = 'str'
    test_obj = DocstringRaises(args,description,type_name)
    if (test_obj.args == args) and \
       (test_obj.description == description) and \
       (test_obj.type_name == type_name):
        print('PASSED: test_DocstringRaises(self,args,description,type_name)')
        print('PASSED: test_DocstringRaises(self,args,None,None)')
    else:
        print('FAILED: test_DocstringRaises(self,args,description,type_name)')
        print('FAILED: test_DocstringRaises(self,args,None,None)')

# Generated at 2022-06-21 11:39:14.728359
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DR = DocstringReturns(['param', 'argument'], 'Type of the argument', 'int', False)
    assert DR.args == ['param', 'argument']
    assert DR.is_generator == False
    assert DR.type_name == 'int'
    assert DR.description == 'Type of the argument'

    DR = DocstringReturns(['raises', 'exception'], 'If an error occurs', 'ValueError', True)
    assert DR.args == ['raises', 'exception']
    assert DR.is_generator == True
    assert DR.type_name == 'ValueError'
    assert DR.description == 'If an error occurs'



# Generated at 2022-06-21 11:39:19.509061
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dr = DocstringReturns(
        args=['args'],
        description='description',
        type_name=None,
        is_generator=False,
    )
    assert dr.args == ['args']
    assert dr.description == 'description'
    assert dr.type_name == None
    assert dr.is_generator == False
    assert dr.return_name == None


# Generated at 2022-06-21 11:39:45.481454
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(args=['a','b'],description='description',type_name='int')
    ds.description = 'description'
    ds.type_name = 'int'
    assert ds.description == 'description'
    assert ds.type_name == 'int'


# Generated at 2022-06-21 11:39:47.642909
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError(0)
    except ParseError as e:
        assert e
# Test for constructor of class DocstringMeta

# Generated at 2022-06-21 11:39:56.082422
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert(docstring.short_description == None)
    assert(docstring.long_description == None)
    assert(docstring.blank_after_short_description == False)
    assert(docstring.blank_after_long_description == False)
    assert(len(docstring.meta) == 0)
    assert(len(docstring.params) == 0)
    assert(len(docstring.raises) == 0)
    assert(docstring.returns == None)
    assert(docstring.deprecation == None)
    return


# Generated at 2022-06-21 11:40:07.586101
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test the constructor of class DocstringRaises."""
    # Initialize args
    args = ["param", "parameter", "arg", "argument", "argument"]
    # Initialize description
    #description = ["Description"]
    #description = [description]
    description = "Description"
    type_name = "type_name"
    # Initialize DocstringRaises
    #docstringRaises = DocstringRaises(args, description, type_name)
    docstringRaises = DocstringRaises(args, description, type_name)
    # Assert DocstringRaises
    assert docstringRaises.args == ['param', 'parameter', 'arg', 'argument', 'argument']
    assert docstringRaises.description == "Description"
    assert docstringRaises.type_name == "type_name"

# Generated at 2022-06-21 11:40:10.031988
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(TypeError) as e_info:
        #no argument for ParseError
        raise ParseError


# Generated at 2022-06-21 11:40:12.226223
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["return", "foo"], "bar", "foobar", True)
    assert docstring_returns


# Generated at 2022-06-21 11:40:17.209709
# Unit test for constructor of class Docstring
def test_Docstring():
    # Setup
    docstring = Docstring()
    # Exercise
    # Verify
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-21 11:40:23.034232
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_string_meta = DocstringMeta(
        ["args", "list", "of", "arguments"], "associated docstring description"
    )
    assert doc_string_meta.args == ["args", "list", "of", "arguments"]
    assert doc_string_meta.description == "associated docstring description"


# Generated at 2022-06-21 11:40:30.429481
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None



# Generated at 2022-06-21 11:40:39.576349
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam([':param'], 'i am the description', 'arg_name', 'type_name', False, 'default')
    print(f'd.args: {d.args}')
    print(f'd.description: {d.description}')
    print(f'd.arg_name: {d.arg_name}')
    print(f'd.type_name: {d.type_name}')
    print(f'd.is_optional: {d.is_optional}')
    print(f'd.default: {d.default}')



# Generated at 2022-06-21 11:40:58.656110
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'version']
    description = 'This is deprecated because'
    version = '5.5.5'
    d = DocstringDeprecated(args, description, version)
    assert isinstance(d, DocstringMeta)
    assert d.args == ['deprecated', 'version']
    assert d.description == 'This is deprecated because'
    assert d.version == '5.5.5'


# Generated at 2022-06-21 11:40:59.563724
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns.__init__


# Generated at 2022-06-21 11:41:03.885664
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:41:07.281624
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['one', 'two']
    description = 'Optional[str]'
    type_name = 'str'
    ds = DocstringRaises(args, description, type_name)
    assert ds.args == ['one', 'two']
    assert ds.description == 'Optional[str]'
    assert ds.type_name == 'str'


# Generated at 2022-06-21 11:41:11.079973
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(args = ["arg1","arg2"], description = "Documentation for the arguments")
    assert docstring.args == ["arg1","arg2"] and docstring.description == "Documentation for the arguments"


# Generated at 2022-06-21 11:41:19.046697
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    # Test short description
    assert doc_string.short_description is None
    # Test long description
    assert doc_string.long_description is None
    # Test blank after short description
    assert doc_string.blank_after_short_description is False
    # Test blank after long description
    assert doc_string.blank_after_long_description is False
    # Test meta
    assert doc_string.meta == []
    # Test params
    assert doc_string.params == []
    # Test raises
    assert doc_string.raises == []
    # Test returns
    assert doc_string.returns is None
    # Test deprecation
    assert doc_string.deprecation is None


# Generated at 2022-06-21 11:41:22.045163
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta(["args"], "description")
    assert dsm.args == ['args']
    assert dsm.description == "description"

# Generated at 2022-06-21 11:41:28.501673
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(args=['arg1', 'arg2'], description="test", type_name=None, is_generator=False, return_name="return1")
    assert a.args == ['arg1', 'arg2']
    assert a.description == "test"
    assert a.type_name == None
    assert a.is_generator == False
    assert a.return_name == "return1"


# Generated at 2022-06-21 11:41:30.318367
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["param"], "This is a parameter", "version 1.0")
    return

# Generated at 2022-06-21 11:41:32.225045
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Some message")
    except ParseError:
        assert True


# Generated at 2022-06-21 11:41:59.717947
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args = None, description = None, version = None)
    assert(d.args == None)
    assert(d.description == None)
    assert(d.version == None)

# Generated at 2022-06-21 11:42:03.049937
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['a','b'], 'abcd', '1.0') == DocstringDeprecated(['a','b'], 'abcd', '1.0')


# Generated at 2022-06-21 11:42:10.172622
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(['raises', 'ValueError'], 'description', 'ValueError').description \
        == 'description'
    assert DocstringRaises(['raises', 'ValueError'], 'description', 'ValueError').args \
        == ['raises', 'ValueError']
    assert DocstringRaises(['raises', 'ValueError'], 'description', 'ValueError').type_name \
        == 'ValueError'

# Generated at 2022-06-21 11:42:14.823970
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert not docstring.short_description
    assert not docstring.long_description
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta
    assert not docstring.params
    assert not docstring.raises
    assert not docstring.returns
    assert not docstring.deprecation
    return 0


# Generated at 2022-06-21 11:42:20.112597
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert not ds.blank_after_short_description
    assert not ds.blank_after_long_description
    assert ds.meta == []

# Generated at 2022-06-21 11:42:25.101457
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for class DocstringReturns."""
    doc = DocstringReturns(args=[":returns"], description="")

    assert doc.args == [":returns"]
    assert doc.description == ""
    assert doc.type_name is None
    assert doc.is_generator is None
    assert doc.return_name is None


# Generated at 2022-06-21 11:42:26.343794
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert isinstance(d, Docstring)



# Generated at 2022-06-21 11:42:27.564739
# Unit test for constructor of class ParseError
def test_ParseError():
    assert isinstance(ParseError("error message"), ParseError)


# Generated at 2022-06-21 11:42:33.115461
# Unit test for constructor of class Docstring
def test_Docstring():
    '''
    Test: Docstring
    '''
    ds = Docstring()
    assert ds.long_description is None
    assert ds.short_description is None
    assert ds.blank_after_long_description == False
    assert ds.blank_after_short_description == False
    assert ds.meta == []
test_Docstring()



# Generated at 2022-06-21 11:42:37.405236
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta([], "")
    assert d.args == []
    assert d.description == ""

d = DocstringMeta(["arg1", "arg2", "arg3"], "description")
assert d.args == ["arg1", "arg2", "arg3"]
assert d.description == "description"


# Generated at 2022-06-21 11:43:27.349589
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['type:', 'version:', 'date:'], 'The function being deprecated', '3.8')
    assert doc.version == '3.8'
    assert doc.type_name == 'type:'



# Generated at 2022-06-21 11:43:33.388085
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_a = Docstring()
    assert docstring_a.short_description == None
    assert docstring_a.long_description == None
    assert docstring_a.blank_after_short_description == False
    assert docstring_a.blank_after_long_description == False
    assert docstring_a.meta == []
    assert docstring_a.params == []
    assert docstring_a.raises == []
    assert docstring_a.returns == None

# Generated at 2022-06-21 11:43:39.693487
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns = DocstringReturns
    assert(docstringReturns != None)
    assert(docstringReturns.type_name == None)
    assert(docstringReturns.description == None)
    assert(docstringReturns.returns == None)
    assert(docstringReturns.is_generator == False)
    assert(docstringReturns.arg_name == None)
    


# Generated at 2022-06-21 11:43:40.674567
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta


# Generated at 2022-06-21 11:43:42.625114
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test if DocstringMeta initialisation produces correct attributes."""
    DocstringMeta(args=["param"], description="description")



# Generated at 2022-06-21 11:43:48.516976
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This method is deprecated"
    version = "2.0.1"
    doc_string = DocstringDeprecated(args, description, version)
    assert doc_string.args == args
    assert doc_string.description == description
    assert doc_string.version == version

# Generated at 2022-06-21 11:43:50.543405
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns"""
    assert(DocstringReturns(["raises"], None, "ValueError", False) is not None)


# Generated at 2022-06-21 11:43:53.415401
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Create an instance of class DocstringMeta
    doc_meta = DocstringMeta(args=["arg"], description="description")
    # Check members
    assert doc_meta.args == ["arg"]
    assert doc_meta.description == "description"


# Generated at 2022-06-21 11:43:55.791106
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["a", "b", "c"], "test", "exception")
    assert test.args == ["a", "b", "c"]
    assert test.description == "test"
    assert test.type_name == "exception"


# Generated at 2022-06-21 11:43:58.035398
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta(['a', 'b', 'c'], 'This is a test')

    # Check the contents of the DocstringMeta object
    assert dsm.args == ['a', 'b', 'c']
    assert dsm.description == 'This is a test'
