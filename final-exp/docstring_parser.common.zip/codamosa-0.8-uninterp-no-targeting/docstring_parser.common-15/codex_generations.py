

# Generated at 2022-06-21 11:34:19.215870
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []

# Generated at 2022-06-21 11:34:22.315137
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:34:25.030729
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('error')
    assert str(err) == 'error'
    assert repr(err) == 'error'



# Generated at 2022-06-21 11:34:27.327051
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg_name", "type_name", False, "default")


# Generated at 2022-06-21 11:34:31.012786
# Unit test for constructor of class Docstring
def test_Docstring():
    from pytest import raises

    Docstring()

    # Test if signature is correct
    with raises(TypeError):
        # TypeError: __init__() takes 0 positional arguments but 1 was given
        Docstring(1)



# Generated at 2022-06-21 11:34:38.722782
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test normal input
    param = DocstringParam(
        ["param", "parameter"],
        "The argument is a string",
        "arg_name",
        "str",
        False,
        "None",
    )
    assert param.arg_name == "arg_name"
    assert param.type_name == "str"
    assert param.is_optional == False
    assert param.default == "None"
    assert param.args == ["param", "parameter"]
    assert param.description == "The argument is a string"

    # Test empty string input

    # Test None input

    # Test invalid input



# Generated at 2022-06-21 11:34:45.960096
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(['type: int'], 'This is an int', 'example', 'int', False, None)
    assert isinstance(p, DocstringParam)
    assert p.args == ['type: int']
    assert p.description == 'This is an int'
    assert p.arg_name == 'example'
    assert p.type_name == 'int'
    assert p.is_optional == False
    assert p.default == None


# Generated at 2022-06-21 11:34:51.685561
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []



# Generated at 2022-06-21 11:34:53.693218
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    c = DocstringMeta([], "description")
    assert c.args == []
    assert c.description == "description"



# Generated at 2022-06-21 11:34:57.463534
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    try:
        raise ParseError("foo")
    except ParseError as e:
        assert str(e) == "foo"


# Some unit tests for function parse_first_line. (pylint: disable=missing-docstring,unused-argument)

# Generated at 2022-06-21 11:35:11.675164
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert (DocstringReturns([],None,None,True,None).is_generator == True)
    assert (DocstringReturns([],None,None,False,None).is_generator == False)
    assert (DocstringReturns([],None,None,True,'doc').is_generator == True)
    assert (DocstringReturns([],None,None,False,'doc').is_generator == False)
    assert (DocstringReturns(['a'],None,None,True,None).is_generator == True)
    assert (DocstringReturns(['a'],None,None,False,None).is_generator == False)
    assert (DocstringReturns(['a'],None,None,True,'doc').is_generator == True)

# Generated at 2022-06-21 11:35:17.193589
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg1', 'arg2']
    description = 'This is test'
    type_name = 'type_name'
    test_obj = DocstringRaises(args, description, type_name)
    assert(test_obj.description == description and
           test_obj.type_name == type_name and
           test_obj.args == args)



# Generated at 2022-06-21 11:35:22.962347
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "description", "arg", "int", True, "2")
    assert param.args == ["param"]
    assert param.description == "description"
    assert param.arg_name == "arg"
    assert param.type_name == "int"
    assert param.is_optional == True
    assert param.default == "2"


# Generated at 2022-06-21 11:35:26.282092
# Unit test for constructor of class ParseError
def test_ParseError():
	x = ParseError('please use a type hint')
	assert(x.__class__.__name__ == 'ParseError')
	assert(x.__str__() == 'please use a type hint')


# Generated at 2022-06-21 11:35:31.356942
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docStringReturns = DocstringReturns(['returns'], '', 'int')
    assert docStringReturns.args == ['returns'] and docStringReturns.description == '' and docStringReturns.type_name == 'int'


# Generated at 2022-06-21 11:35:34.073680
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(
        ['param', 'str'],
        'Lorem ipsum',
        type_name = 'str',
        return_name = 'test',
        is_generator = True
    )
    return


# Generated at 2022-06-21 11:35:37.119295
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['args'], 'description', 'arg', 'type', False, 'default')
    assert dp is not None


# Generated at 2022-06-21 11:35:41.259038
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(args = [], description = "", type_name = "")
    assert(a.args == [])
    assert(a.description == "")
    assert(a.type_name == "")

# Generated at 2022-06-21 11:35:45.387298
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("testing.")
    except ParseError as e:
        assert 'testing.' in str(e)
    try:
        raise ParseError("testing.", "a1", "b2")
    except ParseError as e:
        assert 'testing.' in str(e)


# Generated at 2022-06-21 11:35:46.938466
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    return doc.__dict__


# Generated at 2022-06-21 11:35:57.464635
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None

# Generated at 2022-06-21 11:36:07.356159
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test the __init__ method in class DocstringParam
    dp = DocstringParam(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"], "description", "arg_name", "type_name", "is_optional", "default")
    assert dp.args == ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == "is_optional"
    assert dp.default == "default"


# Generated at 2022-06-21 11:36:10.682036
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []

# Generated at 2022-06-21 11:36:18.300460
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    docstring_returns = DocstringReturns("args", "description", "type_name", "is_generator", "return_name")

    assert docstring_returns.args == "args"
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == "is_generator"
    assert docstring_returns.return_name == "return_name"
    print("test_DocstringReturns DONE")


test_DocstringReturns()

# Generated at 2022-06-21 11:36:25.091300
# Unit test for constructor of class Docstring
def test_Docstring():
    """ test_Docstring is the unittest function for Docstring class """
    # create an instance of Docstring
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:36:30.984873
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Initialize object
    args = ['type_name']
    description = 'something'
    type_name = 'type_name'
    ds = DocstringRaises(args, description, type_name)
    # Test initialization
    assert args == ds.args
    assert description == ds.description
    assert type_name == ds.type_name


# Generated at 2022-06-21 11:36:37.970102
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert isinstance(doc, Docstring)
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns == None
    assert doc.deprecation == None



# Generated at 2022-06-21 11:36:39.647153
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], None, None)



# Generated at 2022-06-21 11:36:43.153194
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["test_arg", "test_arg2"]
    description = "test_description"
    type_name = "type_test"
    is_generator = True
    DocstringReturns(args, description, type_name, is_generator)


# Generated at 2022-06-21 11:36:46.649298
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(['param', 'arg'], 'description')
    assert obj.args == ['param', 'arg']
    assert obj.description == 'description'


# Generated at 2022-06-21 11:36:56.955797
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docRaises = DocstringRaises(
        args = ["a", "b"],
        description = "Raises an error",
        type_name = "Error",
    )
    
    return docRaises

# Generated at 2022-06-21 11:37:00.192999
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    def __init__(self,args,description,type_name,is_generator,return_name) -> None:
        pass

test_DocstringReturns()

# Generated at 2022-06-21 11:37:05.582994
# Unit test for constructor of class Docstring
def test_Docstring():
    docObj = Docstring()
    assert docObj.short_description == None
    assert docObj.long_description == None
    assert docObj.blank_after_short_description == False
    assert docObj.blank_after_long_description == False
    assert docObj.meta == []


# Generated at 2022-06-21 11:37:09.362097
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This function is deprecated"
    version = "5.7"
    obj = DocstringDeprecated(args, description, version)
    assert obj.type_name is None
    assert obj.args == args
    assert obj.description == description
    assert obj.version == version



# Generated at 2022-06-21 11:37:10.885533
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([],[],"")

if __name__ == "__main__":
    test_DocstringReturns()

# Generated at 2022-06-21 11:37:14.519669
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'none')
    assert item.args == ['param']
    assert item.description == 'description'
    assert item.arg_name == 'arg_name'
    assert item.type_name == 'type_name'
    assert item.is_optional == True
    assert item.default == 'none'


# Generated at 2022-06-21 11:37:18.012067
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    item = DocstringRaises(["any_args"], "any_description", "TypeError")
    # Test
    assert item.args == ["any_args"]
    assert item.description == "any_description"
    assert item.type_name == "TypeError"


# Generated at 2022-06-21 11:37:20.232262
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(args=[1,2,3,4], description="This is a description", type_name="string", is_generator=True, return_name="hello")


# Generated at 2022-06-21 11:37:22.254088
# Unit test for constructor of class ParseError
def test_ParseError():
    test = ParseError("Invalid docstring: not enough ':' in line 0")
    assert test.args == ("Invalid docstring: not enough ':' in line 0", )


# Generated at 2022-06-21 11:37:26.482867
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(args=['arg1', 'arg2'], description='very nice description', type_name='complexity', is_generator=True, return_name='return name')


# Generated at 2022-06-21 11:37:40.610020
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = list()
    assert len(args) == 0
    description = None
    assert description == None
    arg_name = str()
    assert len(arg_name) == 0
    type_name = None
    assert type_name == None
    is_optional = False
    default = None
    assert default == None
    dcp = DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-21 11:37:41.913329
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()



# Generated at 2022-06-21 11:37:45.317469
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "arg"
    arg_name = "arg"
    type_name = None
    default = None
    is_optional = None
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-21 11:37:50.198850
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Create an object of DocstringMeta
    docstring_meta = DocstringMeta(['para', 'meter'], 'description')
    assert docstring_meta.args == ['para', 'meter']
    assert docstring_meta.description == 'description'



# Generated at 2022-06-21 11:37:53.219842
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta(['arg1', 'arg2'], 'Descrition')
    assert dsm.args == ['arg1', 'arg2']
    assert dsm.description == 'Descrition'


# Generated at 2022-06-21 11:38:00.153763
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args = ['arg'], description = '', arg_name = 'arg1', type_name = 'int', is_optional = False, default = None)
    assert dp
    assert dp.args == ['arg']
    assert dp.description == ''
    assert dp.arg_name == 'arg1'
    assert dp.type_name == 'int'
    assert dp.is_optional == False
    assert dp.default == None


# Generated at 2022-06-21 11:38:03.822278
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["a", "b"], "c", "d")
    assert d.args == ["a", "b"]
    assert d.description == "c"
    assert d.version == "d"



# Generated at 2022-06-21 11:38:06.345134
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error")
    except RuntimeError as e:
        assert(str(e)=="error")


# Generated at 2022-06-21 11:38:11.164624
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ret = DocstringReturns(['returns'], 'the function returns something', 'int')
    assert ret.args == ['returns']
    assert ret.description == 'the function returns something'
    assert ret.type_name == 'int'
    assert ret.is_generator == False


# Generated at 2022-06-21 11:38:16.254482
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["deprecated"], "dummy_description", "dummy_version")
    assert a.args[0] == "deprecated"
    assert a.description == "dummy_description"
    assert a.version == "dummy_version"


# Generated at 2022-06-21 11:38:37.792485
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """ Test the DocstringRaises constructor."""
    item = DocstringRaises(
        args = ["args", "args", "args"],
        description = "This is a description",
        type_name = "Type"
    )
    assert isinstance(item, DocstringRaises)
    assert item.type_name == "Type"
    assert item.description == "This is a description"
    return

# Generated at 2022-06-21 11:38:41.503890
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print(DocstringParam(args=['a'],description='description',arg_name='arg_name', type_name='type_name',is_optional='is_optional',default='default'))


# Generated at 2022-06-21 11:38:45.589772
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta([':parameter', 'p:', 'description'], 'description')
    assert d.args == [':parameter', 'p:', 'description']
    assert d.description == 'description'


# Generated at 2022-06-21 11:38:50.483285
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ("param", "argument", "arg")
    description = "blah"
    arg_name = "arg"
    is_optional = True
    default = "default"
    type_name = "type"
    DocstringParam(args, description, arg_name,type_name, is_optional, default)
    

    
    

# Generated at 2022-06-21 11:38:52.410806
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None



# Generated at 2022-06-21 11:38:55.820767
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    ds = DocstringParam(["Test"], "Description of test", "Test", "Integer", True, "2")
    assert isinstance(ds, DocstringParam)
    assert isinstance(ds, DocstringMeta)
    assert ds.arg_name == "Test"
    assert ds.type_name == "Integer"
    assert ds.is_optional == True
    assert ds.default == "2"


# Generated at 2022-06-21 11:38:57.995608
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['a', 'b'], 'c', 'd')

# Generated at 2022-06-21 11:39:02.457859
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(['1.2'], 'This should not be used', '1.0')
    assert test.description == 'This should not be used'
    assert test.version == '1.0'
    assert test.args == ['1.2']


# Generated at 2022-06-21 11:39:05.476373
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test for the constructor of class ParseError."""
    err = ParseError()
    assert err.args[0] == 'ParseError'


# Generated at 2022-06-21 11:39:10.252105
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = ""
    arg_name = ""
    type_name = ""
    is_optional = False
    default = ""
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == args
    assert dp.description == description
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default


# Generated at 2022-06-21 11:39:49.543863
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    type(DocstringReturns(['param'], 'None', 'None', 'True', 'None'))


# Generated at 2022-06-21 11:39:54.660839
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    object = DocstringParam([], "", "", "", "", "")
    assert object.args is not None
    assert object.description is not None
    assert object.arg_name is not None
    assert object.type_name is not None
    assert object.is_optional is not None
    assert object.default is not None


# Generated at 2022-06-21 11:39:59.087549
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring1 = Docstring()
    assert docstring1.short_description == None
    assert docstring1.long_description == None
    assert docstring1.blank_after_short_description == False
    assert docstring1.blank_after_long_description == False



# Generated at 2022-06-21 11:40:03.933785
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []



# Generated at 2022-06-21 11:40:08.504288
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args = ['param'], description = 'test', version = 1.0)
    assert docstring_deprecated.args == ['param']
    assert docstring_deprecated.description == 'test'
    assert docstring_deprecated.version == 1.0



# Generated at 2022-06-21 11:40:13.563445
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test the initialization of the class DocstringDeprecated."""
    args = ['0.0.1', 'Deprecated.']
    description = None
    version = '0.0.1'
    doc = DocstringDeprecated(args, description, version)
    assert doc.args == args
    assert doc.description == description
    assert doc.version == version


# Generated at 2022-06-21 11:40:16.718736
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['param', 'arg'], 'description', 'arg', 'str', None, None) != None



# Generated at 2022-06-21 11:40:18.642453
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["a", "b"], "description", "str")


# Generated at 2022-06-21 11:40:24.723843
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert isinstance(docstring, Docstring)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0


# Generated at 2022-06-21 11:40:30.211884
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_docstring_deprecated = DocstringDeprecated(["Deprecated:"], "toto", "titi")
    assert test_docstring_deprecated.args == ["Deprecated:"]
    assert test_docstring_deprecated.description == "toto"
    assert test_docstring_deprecated.version == "titi"


# Generated at 2022-06-21 11:42:02.033401
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()


# Generated at 2022-06-21 11:42:07.473450
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test for DocstringMeta class."""
    param_init = DocstringMeta(['param'], "description")
    param_args = param_init.args
    param_description = param_init.description
    assert param_args == ['param']
    assert param_description == "description"


# Generated at 2022-06-21 11:42:12.046268
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # DocstringRaises(args, description, type_name)
    array = ['args', 'description', 'type_name']
    for item in array:
        DocstringRaises(['args', 'description', 'type_name'], 'description', 'type_name')
        print(item + ' is OK')


# Generated at 2022-06-21 11:42:15.135780
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta"""
    args = ["param"]
    description = "description"
    ds_meta = DocstringMeta(args, description)
    assert ds_meta.args == ["param"]
    assert ds_meta.description == "description"


# Generated at 2022-06-21 11:42:20.063381
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert str(DocstringRaises(["param"], "Testing", "Type")) == "DocstringRaises(args=['param'], description='Testing', type_name='Type')"
if __name__ == '__main__':
    test_DocstringRaises()

# Generated at 2022-06-21 11:42:24.396816
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        print('Testing constructor of class ParseError')
        raise ParseError('test')
    except ParseError as e:
        print('Successfully created ParseError: "{}"'.format(e))
        print('Successfully passed test')
        print()


# Generated at 2022-06-21 11:42:30.121900
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None


# Generated at 2022-06-21 11:42:39.241577
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1
    args = ["param:"]
    description = """This is an example."""
    arg_name =  "arg"
    type_name = None
    is_optional = None
    default = None
    docstring = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.arg_name == arg_name
    assert docstring.type_name == type_name
    assert docstring.is_optional == is_optional
    assert docstring.default == default
    
    # Test 2
    args = ["parameter:"]
    description = """This is an example."""
    arg_name =  "arg"
    type_name = None
    is_optional = None
    default

# Generated at 2022-06-21 11:42:46.166126
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "Any"
    is_optional = True
    default = "Test"
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == args, "dk"
    assert dp.description == description, "description"
    assert dp.arg_name == arg_name, "arg_name"
    assert dp.type_name == type_name, "type_name"
    assert dp.is_optional == is_optional, "is_optional"
    assert dp.default == default, "default"



# Generated at 2022-06-21 11:42:47.267588
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert isinstance(err, ParseError)