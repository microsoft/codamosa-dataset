

# Generated at 2022-06-21 11:34:16.646997
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated', 'since', '1.0'], None, '1.0')
    assert docstring
    assert docstring.args == ['deprecated', 'since', '1.0']
    assert docstring.description is None
    assert docstring.version == '1.0'

# Generated at 2022-06-21 11:34:23.250621
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg', 'description']
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, 'description', arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == 'description'
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default



# Generated at 2022-06-21 11:34:29.598453
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    #print(type(DocstringMeta([":param", "arg"], "description")))
    #print(type(DocstringMeta(args=["arg", "param"], description= "description")))
    #print(isinstance(DocstringMeta([":param", "arg"], "description"), DocstringMeta))
    doc_str = DocstringMeta([":param", "arg"], "description")
    print(type(doc_str))
    print(doc_str.args)



# Generated at 2022-06-21 11:34:32.167926
# Unit test for constructor of class ParseError
def test_ParseError():

    parse_error = ParseError('message')
    assert parse_error

# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-21 11:34:39.159046
# Unit test for constructor of class Docstring
def test_Docstring():
    t =Docstring()
    assert (isinstance(t.short_description, str) and t.short_description == None)
    assert (isinstance(t.long_description, str) and t.long_description == None)
    assert (isinstance(t.blank_after_short_description, bool) and t.blank_after_short_description == False)
    assert (isinstance(t.blank_after_long_description, bool) and t.blank_after_long_description == False)
    assert (isinstance(t.meta, list) and len(t.meta) == 0)


# Generated at 2022-06-21 11:34:47.531113
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    class DocstringRaises(DocstringMeta):
        """DocstringMeta symbolizing :raises metadata."""
        def __init__(self, args: T.List[str], description: T.Optional[str], type_name: T.Optional[str]) -> None:
            super().__init__(args, description)
            self.type_name = type_name
    d=DocstringRaises(None, None, None)
    assert d.type_name==None
    assert d.args==None
    assert d.description==None

# Generated at 2022-06-21 11:34:56.127513
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    expected = DocstringParam(args=["a"], description="b", arg_name="c", type_name="d", is_optional=False, default="e")
    actual = DocstringParam(args=["a"], description="b", arg_name="c", type_name="d", is_optional=False, default="e")

    assert expected.args == actual.args
    assert expected.description == actual.description
    assert expected.arg_name == actual.arg_name
    assert expected.type_name == actual.type_name
    assert expected.is_optional == actual.is_optional
    assert expected.default == actual.default


# Generated at 2022-06-21 11:34:59.499499
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-21 11:35:08.721553
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns = DocstringReturns(
        args = ["returns"],
        description = "Trả về một chuỗi đã được mã hóa",
        type_name = "String",
        is_generator = False,
        return_name = None
    )
    assert isinstance(docstringReturns.args, list)
    assert isinstance(docstringReturns.description, str)
    assert isinstance(docstringReturns.type_name, str)
    assert isinstance(docstringReturns.is_generator, bool)

# Generated at 2022-06-21 11:35:14.645358
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated', 'since', '3.0'], 'This is deprecated', '3.0')
    assert docstring_deprecated.args == ['deprecated', 'since', '3.0']
    assert docstring_deprecated.description == 'This is deprecated'
    assert docstring_deprecated.version == '3.0'


# Generated at 2022-06-21 11:35:21.564818
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    with pytest.raises(TypeError):
        DocstringReturns(args=None, description=None, type_name=None, is_generator=None, return_name=None)
        DocstringReturns(args='', description='', type_name='', is_generator='', return_name='')
    with pytest.raises(AttributeError):
        DocstringReturns(args=[""], description="", type_name="", is_generator=True, return_name="")


# Generated at 2022-06-21 11:35:26.920532
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print("test_DocstringDeprecated")
    obj = DocstringDeprecated(["Hello", "World"], "Test", "1.2.3")
    print(obj.args)
    print(obj.description)
    print(obj.version)
    assert(obj.args == ["Hello", "World"])
    assert(obj.description == "Test")
    assert(obj.version == "1.2.3")

# Generated at 2022-06-21 11:35:35.138724
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = "test"
    type_name = None
    is_generator = False
    return_name = None
    # Create DocstringReturns object
    item = DocstringReturns(args, description, type_name, is_generator, return_name)

    # Check DocstringReturns object
    assert item.args == args
    assert item.description == description
    assert item.type_name == type_name
    assert item.is_generator == is_generator
    assert item.return_name == return_name


# Generated at 2022-06-21 11:35:40.342919
# Unit test for constructor of class Docstring
def test_Docstring():
    d1 = Docstring()
    assert d1.short_description == None
    assert d1.long_description == None
    assert d1.blank_after_short_description == False
    assert d1.blank_after_long_description == False
    assert d1.meta == []

# Generated at 2022-06-21 11:35:44.728774
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises([2, 3], "testing DocstringRaises", type_name="Testing")
    assert test.args[0] == 2
    assert test.args[1] == 3
    assert test.description == "testing DocstringRaises"
    assert test.type_name == "Testing"

# Generated at 2022-06-21 11:35:46.532886
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "This is deprecated function.", "Version 11.0")


# Generated at 2022-06-21 11:35:56.452659
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(
        "param",
        "param description",
        "param_name",
        "param_type",
        "is_optional",
        "default"
    )
    assert(docstring.args == "param")
    assert(docstring.description == "param description")
    assert(docstring.arg_name == "param_name")
    assert(docstring.type_name == "param_type")
    assert(docstring.is_optional == "is_optional")
    assert(docstring.default == "default")
    print("test_DocstringParam passed!")


# Generated at 2022-06-21 11:36:02.897674
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.params == []
    assert a.raises == []
    assert a.returns is None
    assert a.deprecation is None
    assert a == a



# Generated at 2022-06-21 11:36:07.040939
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['param'], None, 'arg', 'type', True, None)
    assert param.arg_name == 'arg'
    assert param.type_name == 'type'
    assert param.is_optional == True
    assert param.default == None
    return True



# Generated at 2022-06-21 11:36:12.082549
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "help", "arg", "str", True, "")
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "str"
    assert docstring_param.is_optional == True
    assert docstring_param.default == ""


# Generated at 2022-06-21 11:36:24.493345
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        m1 = DocstringRaises(["x"], "nice", "good")
        assert m1.type_name == "good"
    except:
        print("Error when test_DocstringRaises")
        raise


# Generated at 2022-06-21 11:36:28.832409
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    args = [':deprecated']
    description = 'This class has been deprecated.'
    version = '2.1.0'
    expected = DocstringDeprecated(args, description, version)
    assert expected.description == description
    assert expected.version == version


# Generated at 2022-06-21 11:36:33.206181
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['raises'], 'if something happens', 'ValueError')
    assert d.args == ['raises']
    assert d.description == 'if something happens'
    assert d.type_name == 'ValueError'


# Generated at 2022-06-21 11:36:36.768563
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        assert_that(ParseError).is_not_none
    except:
        raise AssertionError('"ParseError".assert_that() == "None"')


# Generated at 2022-06-21 11:36:39.777857
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringmeta = DocstringMeta(["arg"], "description")
    assert docstringmeta.args == ["arg"]
    assert docstringmeta.description == "description"


# Generated at 2022-06-21 11:36:44.326004
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Unit test for constructor of class DocstringMeta
    meta = DocstringMeta(["hello", "there", "9"], "this is a description")
    assert meta
    assert meta.args
    assert meta.args[0] == 'hello'
    assert meta.args[1] == 'there'
    assert meta.args[2] == '9'
    assert meta.description == "this is a description"


# Generated at 2022-06-21 11:36:47.993003
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  try:
        DocstringRaises("0, 1, 2", "The following error is occured", "ValueError")
        # assert True
  except:
        assert False




# Generated at 2022-06-21 11:36:51.750656
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstrparam = DocstringParam(["param"], "Test Parameter", "arg", None, None, None)
    assert (docstrparam.arg_name == "arg")


# Generated at 2022-06-21 11:36:57.100084
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    D = DocstringDeprecated(
        args=['hello'],
        description='I am not None',
        version='1.0.0'
    )  
    assert D.version == '1.0.0'
    assert D.description == 'I am not None'
    assert D.args == ['hello']


# Generated at 2022-06-21 11:37:00.406627
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of DocstringMeta."""
    doc_string = DocstringMeta(["arg"], "description")
    assert doc_string.args == ["arg"]



# Generated at 2022-06-21 11:37:16.436507
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm1 = DocstringMeta([], '')
    assert dm1.args == []


# Generated at 2022-06-21 11:37:18.543744
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated', 'since'], "description", "version")
    assert(docstring.description =="description")
    assert(docstring.version =="version")
    assert(len(docstring.args)==2)


# Generated at 2022-06-21 11:37:24.938203
# Unit test for constructor of class Docstring
def test_Docstring():
    # Unit testing for constructor
    empty_string = Docstring()
    assert empty_string.short_description is None
    assert empty_string.long_description is None
    assert empty_string.blank_after_short_description is False
    assert empty_string.blank_after_long_description is False
    assert empty_string.meta == []
    assert empty_string.params == []
    assert empty_string.raises == []
    assert empty_string.returns == None
    return
test_Docstring()

# Generated at 2022-06-21 11:37:26.175026
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['args','description','typename'],
                'description','typename')

# Generated at 2022-06-21 11:37:31.309801
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    param_list = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = 'Some description'
    type_name = 'int'
    is_generator = False
    returns = DocstringReturns(param_list, description, type_name, is_generator)
    assert returns.args == param_list
    assert returns.description == description
    assert returns.type_name == type_name
    assert returns.is_generator == is_generator
    assert returns.return_name is None


# Generated at 2022-06-21 11:37:38.960036
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args=['param'], description='description', arg_name='arg', type_name='type_name', is_optional=None, default='default')
    assert dp.args[0] == 'param'
    assert dp.description == 'description'
    assert dp.arg_name == 'arg'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == None
    assert dp.default == 'default'

# Generated at 2022-06-21 11:37:42.763722
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_dep = DocstringDeprecated(
        ["deprecated"], """This function is deprecated, use new_func instead.""",
        """1.0""",
    )
    assert doc_dep.type == "deprecated"
    assert doc_dep.description == """This function is deprecated, use new_func instead."""
    assert doc_dep.version == """1.0"""


# Generated at 2022-06-21 11:37:46.300192
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["param"], "asdf", None, False)
    assert ds.args == ["param"]
    assert ds.description == "asdf"
    assert ds.type_name is None
    assert not ds.is_generator
    assert ds.return_name is None



# Generated at 2022-06-21 11:37:48.569330
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args=['arg'], description='description', type_name='int', is_generator=False, return_name='return_name')

# Generated at 2022-06-21 11:37:55.814646
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    assert hasattr(docstring, "args")
    assert hasattr(docstring, "description")
    assert hasattr(docstring, "type_name")
    assert docstring.args == ["raises", "ValueError"]
    assert docstring.description == "if something happens"
    assert docstring.type_name == "ValueError"


# Generated at 2022-06-21 11:38:29.537562
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-21 11:38:35.611591
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(
        args=["deprecated"], description="Deprecated since version 1.2.0", version=None
    )
    assert a.args == ["deprecated"]
    assert a.description == "Deprecated since version 1.2.0"
    assert a.type_name is None
    assert a.version is None


# Generated at 2022-06-21 11:38:37.264601
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # assert DocstringMeta([], "")
    assert DocstringMeta("param", "description")



# Generated at 2022-06-21 11:38:41.503185
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert d.args == ['deprecated']
    assert d.description == 'description'
    assert d.version == 'version'

# Unit Test for constructor of class DocstringParam

# Generated at 2022-06-21 11:38:44.756378
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['raises'], 'description', 'type_name')
    assert docstringRaises.args == ['raises']
    assert docstringRai

# Generated at 2022-06-21 11:38:48.245970
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Tests for DocstringRaises constructor."""
    raise_args = ['args', 'Raises ValueError', 'ValueError']
    DocstringRaises(raise_args, 'if something happens')



# Generated at 2022-06-21 11:38:52.061915
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:38:55.613410
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(args = [],description = 'None',arg_name = 'None', type_name = 'None', is_optional = False, default = 'None')
    assert doc.args == []
    assert doc.description == 'None'
    assert doc.arg_name == 'None'
    assert doc.type_name == 'None'
    assert doc.is_optional == False
    assert doc.default == 'None'



# Generated at 2022-06-21 11:38:59.620884
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(args=["raises"], description="testing", type_name=None)
    assert doc.type_name == None
    assert doc.description == "testing"



# Generated at 2022-06-21 11:39:01.464070
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except:
        pass

# Generated at 2022-06-21 11:39:41.951729
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test1 = DocstringMeta("args", "description")
    assert test1.args == "args"
    assert test1.description == "description"


# Generated at 2022-06-21 11:39:46.721842
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    assert isinstance(error, RuntimeError)

    ParseError("test")
    try:
        raise ParseError("test")
    except ParseError as error:
        assert isinstance(error, RuntimeError)


# Generated at 2022-06-21 11:39:50.558133
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    err = ParseError("what happened?")
    assert str(err) == "what happened?"
    assert type(err) == ParseError
    assert type(err) != RuntimeError
    assert isinstance(err, RuntimeError)


# Generated at 2022-06-21 11:40:02.324009
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param','type','raise','example','error']
    description = 'this is a test for this case'
    type = 'type'
    raises = DocstringRaises(args,description,type)
    assert raises.args == args
    assert raises.description == description
    assert raises.type_name == type
    assert raises.type_name == 'type'
    args = ['param','type','raise','example','error']
    description = 'this is a test for this case'
    type = 'type'
    raises = DocstringRaises(args,description,type)
    assert raises.description == description
    assert raises.description == 'this is a test for this case'
    assert raises.args == args
    assert raises.args == ['param','type','raise','example','error']

# Generated at 2022-06-21 11:40:12.683051
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(["param", "p", "<type>"], "My description", "p", "<type>"
                       , True, "None")
    assert isinstance(p, DocstringParam), "Wrong object returned."
    assert p.args == ["param", "p", "<type>"], "Args don't match"
    assert p.description == "My description", "Descriptions don't match"
    assert p.arg_name == "p", "Arg names don't match"
    assert p.type_name == "<type>", "Type names don't match"
    assert p.is_optional == True, "is_optional don't match"
    assert p.default == "None", "Defaults don't match"


# Generated at 2022-06-21 11:40:20.474851
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docparam = DocstringParam(['param'], 'open a file', ['fname'], ['str'], True, 'None')
    assert isinstance(docparam.args, list)
    assert docparam.description == 'open a file'
    assert docparam.arg_name == 'fname'
    assert docparam.type_name == 'str'
    assert docparam.is_optional == True
    assert docparam.default == 'None'


# Generated at 2022-06-21 11:40:26.335355
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [""]
    description = ""
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args,description,version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-21 11:40:32.565411
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(['param'], "this is the description for the input value x", 'x', 'float', True, 0.0)
    assert doc.args == ['param']
    assert doc.description == 'this is the description for the input value x'
    assert doc.arg_name == 'x'
    assert doc.type_name == 'float'
    assert doc.is_optional == True
    assert doc.default == 0.0

# Test to see if the constructor works properly for class DocstringReturns

# Generated at 2022-06-21 11:40:33.877720
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(["arg1","arg2"], "description")
    assert obj.args == ["arg1","arg2"]
    assert obj.description == "description"


# Generated at 2022-06-21 11:40:35.602794
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['raises'], 'bla', 'ValueError')

# Generated at 2022-06-21 11:42:09.303372
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = 'description'

    param = DocstringParam(args,description,'arg_name',None,None,None)
    assert param.args == args
    assert param.description == description
    assert param.arg_name == 'arg_name'


# Generated at 2022-06-21 11:42:10.493484
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert("deprecation for init" == "deprecation for init")


# Generated at 2022-06-21 11:42:12.825244
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_obj = DocstringMeta(['args'], 'description')

    assert doc_obj.args == ['args']
    assert doc_obj.description == 'description'


# Generated at 2022-06-21 11:42:15.015364
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['args1', 'args2'], 'description')
    assert(a.args == ['args1', 'args2'])
    assert(a.description == 'description')


# Generated at 2022-06-21 11:42:17.002139
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(args=['var:', 'str'], description='Null', type_name='None')


# Generated at 2022-06-21 11:42:21.544671
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_DocstringDeprecated = DocstringDeprecated(['one', 'two', 'three'], None, None)
    assert(test_DocstringDeprecated.args[1] == 'two')

# Generated at 2022-06-21 11:42:24.179459
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("Unexpected identifier")
    assert(a.args[0] == "Unexpected identifier")


# Generated at 2022-06-21 11:42:26.140154
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc =  DocstringRaises([None],[None],None)
    assert type(doc) == DocstringRaises


# Generated at 2022-06-21 11:42:32.582530
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    desc = "This is the return type of foo"
    type_name = "str"
    is_gen = True
    return_name = "foo"
    d = DocstringReturns(args, desc, type_name, is_gen)
    assert d.return_name == None
    d = DocstringReturns(args, desc, type_name, is_gen, return_name)
    assert d.return_name == return_name

# Generated at 2022-06-21 11:42:38.910905
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test for constructor of class DocstringDeprecated
    args = []
    description = "This is for benchmark test."
    version = "2.5"
    test_DocstringDeprecated = DocstringDeprecated(args, description, version)
    print("Test for DocstringDeprecated, get args: " + str(test_DocstringDeprecated.args))
    print("Test for DocstringDeprecated, get description: " + test_DocstringDeprecated.description)
    print("Test for DocstringDeprecated, get version: " + test_DocstringDeprecated.version)