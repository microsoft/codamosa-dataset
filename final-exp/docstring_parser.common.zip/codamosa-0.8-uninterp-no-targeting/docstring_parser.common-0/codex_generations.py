

# Generated at 2022-06-21 11:34:17.279364
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["123", "234"],'abcd', 'abcd.efg')

# Generated at 2022-06-21 11:34:18.893028
# Unit test for constructor of class ParseError

# Generated at 2022-06-21 11:34:24.443893
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(['param','argument','arg','parameter','attribute','key','keyword'], "Optional[bool]", "Optional[bool]", "Optional[bool]", True, "Optional[bool]")
    assert x.args == ['param','argument','arg','parameter','attribute','key','keyword']
    assert x.description == "Optional[bool]"
    assert x.arg_name == "Optional[bool]"
    assert x.type_name == "Optional[bool]"
    assert x.is_optional == True
    assert x.default == "Optional[bool]"


# Generated at 2022-06-21 11:34:26.053240
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("error")
    assert e.args == ("error",)

# Generated at 2022-06-21 11:34:32.710158
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert isinstance(docstring, Docstring)
    assert isinstance(docstring.meta, list)
    assert isinstance(docstring.params, list)
    assert isinstance(docstring.raises, list)
    assert isinstance(docstring.returns, T.Optional[DocstringReturns])
    assert isinstance(docstring.deprecation, T.Optional[DocstringDeprecated])
# End of unit test


# Generated at 2022-06-21 11:34:37.138687
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    assert issubclass(ParseError, RuntimeError)
    assert ParseError.__doc__ == 'Base class for all parsing related errors.'
    assert ParseError.__init__.__doc__ == """Initialize self.

        :param message: error message
        """


# Generated at 2022-06-21 11:34:38.282028
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('Invalid syntax')
    assert error


# Generated at 2022-06-21 11:34:43.388487
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None
    
    

# Generated at 2022-06-21 11:34:54.869676
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam.

    Raises:
        AssertionError: if test does not pass.
    """
    args = ['arg1', 'arg2']
    description = 'This is a description'
    arg_name = 'arg_name'
    type_name = 'int'
    is_optional = True
    default = 99
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default

# Unit test

# Generated at 2022-06-21 11:34:59.686982
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg"]
    description = "description"
    type_name = "int"
    assert DocstringRaises(args, description, type_name).args == args
    assert DocstringRaises(args, description, type_name).description == description
    assert DocstringRaises(args, description, type_name).type_name == type_name



# Generated at 2022-06-21 11:35:04.941184
# Unit test for constructor of class ParseError
def test_ParseError():
    from random import randrange
    try:
        raise ParseError("Test is OK")
    except ParseError:
        pass
    else:
        assert False

# Generated at 2022-06-21 11:35:08.815872
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr = DocstringReturns(["para", "param"], None, None)
    if len(docstr.args) == 2 and docstr.description == None and docstr.type_name == None:
        pass
    else:
        assert(False)


# Generated at 2022-06-21 11:35:10.082507
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    return error

# Generated at 2022-06-21 11:35:17.992053
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(args=["param", "parameter"],
                           description="description",
                           arg_name="arg_name",
                           type_name="type_name",
                           is_optional=True,
                           default="default")
    assert param.args == ["param", "parameter"]
    assert param.description == "description"
    assert param.arg_name == "arg_name"
    assert param.type_name == "type_name"
    assert param.is_optional is True
    assert param.default == "default"


# Generated at 2022-06-21 11:35:19.340825
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    print(err)
    assert(err)
    assert(isinstance(err, ParseError))



# Generated at 2022-06-21 11:35:26.417269
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param", "parameter", "arg", "argument"], "Some description", "p1", "", False, "")
    print("\nArguments:", a.args)
    print("Description:", a.description)
    print("Name of argument:", a.arg_name)
    print("Type of argument:", a.type_name)
    print("Default value of argument:", a.default)
    print("Is optional:", a.is_optional)


# Generated at 2022-06-21 11:35:31.511433
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['a', 'b', 'c'], 'the description', 'arg_name', 'type_name', True, 'default')
    assert(param.args == ['a', 'b', 'c'])
    assert(param.description == 'the description')
    assert(param.arg_name == 'arg_name')
    assert(param.type_name == 'type_name')
    assert(param.is_optional == True)
    assert(param.default == 'default')


# Generated at 2022-06-21 11:35:32.576876
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "sample description") is not None


# Generated at 2022-06-21 11:35:38.448891
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["raises"], "if something happens",  "ValueError")
    assert docstring_raises.args[0] == "raises" and docstring_raises.description == "if something happens" \
           and docstring_raises.type_name == "ValueError"
    print(docstring_raises.description)


# Generated at 2022-06-21 11:35:47.249814
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['I', 'didn\'t', 'give', 'a', 'type', 'name']
    description = 'I gave this description'
    type_name = 'I gave a type name'
    test_case = DocstringRaises(args, description, type_name)
    assert test_case.args == args
    assert test_case.description == description
    assert test_case.type_name == type_name
    assert test_case.args != ['I', 'gave', 'a', 'type', 'name']
    assert test_case.description != 'I didn\'t give this description'
    assert test_case.type_name != 'I didn\'t give a type name'


# Generated at 2022-06-21 11:35:55.564887
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
  param = DocstringDeprecated(None, None, '0.1')
  assert param.version == '0.1'
  assert param.description is None
  assert param.args is None

  param = DocstringDeprecated(None, 'it is deprecated', '0.1')
  assert param.version == '0.1'
  assert param.description == 'it is deprecated'
  assert param.args is None

# Generated at 2022-06-21 11:36:03.300277
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['arg', 'arg2'], 'des', 'aname', 'aname', False, 'adef')
    assert(dp.args == ['arg', 'arg2'])
    assert(dp.description == 'des')
    assert(dp.arg_name == 'aname')
    assert(dp.type_name == 'aname')
    assert(dp.is_optional == False)
    assert(dp.default == 'adef')
    # Unit test for constructor of class DocstringReturns

# Generated at 2022-06-21 11:36:05.154318
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        assert True


# Generated at 2022-06-21 11:36:10.219946
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test to check constructor of Docstring."""
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []
    assert Docstring().params == []
    assert Docstring().raises == []
    assert Docstring().returns == None
    assert Docstring().deprecation == None



# Generated at 2022-06-21 11:36:17.013978
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.meta == []
    assert isinstance(doc.params, list)
    assert isinstance(doc.raises, list)
    assert isinstance(doc.returns, DocstringReturns) or doc.returns == None
    assert isinstance(doc.deprecation, DocstringDeprecated) or doc.deprecation == None

# Test if DocstringParam constructor works

# Generated at 2022-06-21 11:36:19.150780
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "description", "10.0")


# Generated at 2022-06-21 11:36:27.232665
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(['param'], 'description', 'arg', 'str', True, '1')
    assert x.args == ['param'], 'args'
    assert x.description == 'description', 'description'
    assert x.arg_name == 'arg', 'arg_name'
    assert x.type_name == 'str', 'type_name'
    assert x.is_optional == True, 'is_optional'
    assert x.default == '1', 'default'


# Generated at 2022-06-21 11:36:34.191086
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_meta = DocstringReturns(['returns'], "desc", "type", False)
    assert isinstance(docstring_meta, DocstringMeta)
    assert docstring_meta.args == ['returns']
    assert docstring_meta.description == "desc"
    assert isinstance(docstring_meta, DocstringReturns)
    assert docstring_meta.is_generator == False
    assert docstring_meta.type_name == "type"

# Generated at 2022-06-21 11:36:36.393091
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("RuntimeError raised")


# Generated at 2022-06-21 11:36:40.245663
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    instance = DocstringReturns(["returns"], "description", "type_name", True, "return_name")
    assert instance.description == "description"
    assert instance.is_generator == True
    assert instance.return_name == "return_name"

# Generated at 2022-06-21 11:36:47.296524
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    my_DocstringDeprecated = DocstringDeprecated(["myargs"], "mydescription", "myversion")
    assert my_DocstringDeprecated.args == ["myargs"]
    assert my_DocstringDeprecated.description == "mydescription"
    assert my_DocstringDeprecated.version == "myversion"


# Generated at 2022-06-21 11:36:53.265704
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dd = DocstringDeprecated(args = [], description = "", version = "")
    print(dd.args)
    print(dd.description)
    print(dd.version)
    print(dd.meta)


if __name__ == "__main__":
    test_DocstringDeprecated()

# Generated at 2022-06-21 11:36:56.916194
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta = DocstringRaises(
        "asd", "asd",  "asd"
    )
    assert meta.type_name == "asd"
    assert meta.description == "asd"
    assert meta.args == "asd"



# Generated at 2022-06-21 11:37:00.614813
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dd = DocstringDeprecated(["key"], "description", "version")
    assert dd.args == ["key"]
    assert dd.description == "description"
    assert dd.version == "version"



# Generated at 2022-06-21 11:37:09.241391
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = Docstring()
    docstring.short_description = 'test'
    assert docstring.short_description == 'test'
    docstring.long_description = 'test2'
    assert docstring.long_description == 'test2'
    docstring.blank_after_short_description = True
    assert docstring.blank_after_short_description
    docstring.blank_after_long_description = False
    assert not docstring.blank_after_long_description
    docstring.meta.append('test3')
    assert docstring.meta[0] == 'test3'
    return True


# Generated at 2022-06-21 11:37:11.191158
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("this is a test")
    assert e.args == ("this is a test",)


# Generated at 2022-06-21 11:37:13.996249
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r = DocstringReturns(1,2,3,4,5)
    return isinstance(r, DocstringReturns)

# Generated at 2022-06-21 11:37:22.567763
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_docstring_param = DocstringParam(
        args=["param"],
        description="A parameter",
        arg_name="x",
        type_name="int",
        is_optional=False,
        default=None,
    )
    assert test_docstring_param.args == ["param"], "args not added to DocstringParam"
    assert (
        test_docstring_param.description == "A parameter"
    ), "description not added to DocstringParam"
    assert test_docstring_param.arg_name == "x", "arg_name not added to DocstringParam"
    assert (
        test_docstring_param.type_name == "int"
    ), "type_name not added to DocstringParam"

# Generated at 2022-06-21 11:37:25.588044
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated([],None,None)
    assert d.args==[]

# Generated at 2022-06-21 11:37:27.480160
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['return'], None, 'None', True) is not None
    

# Generated at 2022-06-21 11:37:32.764150
# Unit test for constructor of class DocstringReturns

# Generated at 2022-06-21 11:37:36.863699
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test constructor of class DocstringRaises."""

# Generated at 2022-06-21 11:37:38.554985
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError(1, 2, 3)


# Generated at 2022-06-21 11:37:41.409406
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta = DocstringRaises(["args"], "description", "type")
    assert meta.args == ["args"]
    assert meta.description == "description"
    assert meta.type_name == "type"

# Generated at 2022-06-21 11:37:46.468433
# Unit test for constructor of class Docstring
def test_Docstring():
    ds0 = Docstring()
    # Check short_description
    assert ds0.short_description == None

    # Check long_description
    assert ds0.long_description == None

    # Check blank_after_short_description
    assert ds0.blank_after_short_description == False

    # Check blank_after_long_description
    assert ds0.blank_after_long_description == False

    # Check meta
    assert ds0.meta == []

    # Check params
    assert ds0.params == []
    # Check raises
    assert ds0.raises == []

    # Check returns
    assert ds0.returns == None

    # Check deprecation
    assert ds0.deprecation == None


# Generated at 2022-06-21 11:37:47.544142
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()


# Generated at 2022-06-21 11:37:52.484127
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    return 0

# Generated at 2022-06-21 11:38:02.789908
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    testdata = [
        (
            ["param"],
            "description",
            "arg_name",
            "type_name",
            False,
            "default",
        ),
    ]
    for t in testdata:
        docstring_param = DocstringParam(t[0], t[1], t[2], t[3], t[4], t[5])
        assert docstring_param.args == t[0]
        assert docstring_param.description == t[1]
        assert docstring_param.arg_name == t[2]
        assert docstring_param.type_name == t[3]
        assert docstring_param.is_optional == t[4]
        assert docstring_param.default == t[5]


# Generated at 2022-06-21 11:38:05.271424
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test message")
    print("Error message: {0}".format(error.args[0]))


# Generated at 2022-06-21 11:38:12.935551
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    ds = Docstring()
    assert ds
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns is None
    assert ds.deprecation is None


# Generated at 2022-06-21 11:38:28.374708
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns = DocstringReturns(
        args=['args'],description='description', type_name='type_name', is_generator=True, return_name='return_name')
    assert docstringReturns.args == ['args'], 'args should be set to args'
    assert docstringReturns.description == 'description', 'description should be set to description'
    assert docstringReturns.type_name == 'type_name', 'type_name should be set to type_name'
    assert docstringReturns.is_generator == True, 'is_generator should be set to True'
    assert docstringReturns.return_name == 'return_name', 'return_name should be set to return_name'


# Generated at 2022-06-21 11:38:29.883380
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("This is a test error")


# Generated at 2022-06-21 11:38:36.276175
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], "", "", "", "").type_name == ""
    assert DocstringReturns([], "", "", "", "").is_generator == ""
    assert DocstringReturns([], "", "", "", "").return_name == ""
    assert DocstringReturns([], "", "", "", "").description == ""


# Generated at 2022-06-21 11:38:38.757060
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["param"], "description", "version")
    assert d.args == ["param"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-21 11:38:50.797393
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    #Test1
    args1 = ["type_name", "description"]
    description1 = "description"
    type_name1 = "type_name"
    DocstringRaises1 = DocstringRaises(args1, description1, type_name1)
    assert DocstringRaises1.type_name == "type_name"
    assert DocstringRaises1.description == "description"
    assert DocstringRaises1.args == ["type_name", "description"]

    #Test2
    args2 = ["type_name", "description"]
    description2 = None
    type_name2 = "type_name"
    DocstringRaises2 = DocstringRaises(args=args2, description=description2, type_name=type_name2)
    assert DocstringRaises2.type_name == "type_name"


# Generated at 2022-06-21 11:38:54.634065
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert(doc.short_description is None)
    assert(doc.long_description is None)
    assert(doc.blank_after_short_description is False)
    assert(doc.blank_after_long_description is False)
    assert(doc.meta == [])


# Generated at 2022-06-21 11:38:55.636445
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-21 11:38:58.780856
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta("args", "description")
    assert a.args == "args"
    assert a.description == "description"


# Generated at 2022-06-21 11:39:01.873785
# Unit test for constructor of class ParseError
def test_ParseError():
    # Create an instance of ParseError
    err = ParseError("Test")
    # Check if the object has the same message
    assert str(err) == "Test"


# Generated at 2022-06-21 11:39:09.409591
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():  # type: ()->None
    doc_returns = DocstringReturns(
        args=['Yields'],
        description='None',
        type_name='None',
        is_generator=False,
        return_name=None
    )
    assert isinstance(doc_returns, DocstringReturns)
    assert isinstance(doc_returns, DocstringMeta)
    assert doc_returns.args == ['Yields']
    assert doc_returns.description == 'None'
    assert doc_returns.type_name == 'None'
    assert doc_returns.is_generator == False
    assert doc_returns.return_name == None


# Generated at 2022-06-21 11:39:28.185263
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid operation")
    except ParseError as e:
        print("Expected type is: %s" %e)
        

# Generated at 2022-06-21 11:39:29.181621
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta("args", "description") != None

# Generated at 2022-06-21 11:39:32.682213
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-21 11:39:40.798777
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "argument", "arg", "str", True, "None")
    assert param.args == ["param"], "failed to initialize args"
    assert param.description == "argument", "failed to initialize description"
    assert param.arg_name == "arg", "failed to initialize arg_name"
    assert param.type_name == "str", "failed to initialize type_name"
    assert param.is_optional == True, "failed to initialize is_optional"
    assert param.default == "None", "failed to initialize default"



# Generated at 2022-06-21 11:39:51.402735
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(args=['param'], description='description', arg_name='arg_name', type_name='type_name', is_optional='is_optional', default='default')
    assert type(item) == DocstringParam
    assert item.args == ['param'] and item.description == 'description' and item.arg_name == 'arg_name' and item.type_name == 'type_name' and item.is_optional == 'is_optional' and item.default == 'default'
    item = DocstringParam(args=['param'], description=None, arg_name='arg_name', type_name='type_name', is_optional='is_optional', default='default')
    assert item.description == None

# Generated at 2022-06-21 11:39:59.240039
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args=['arg', 'arg2'], description='test description', arg_name='arg', type_name='int', is_optional=True, default='None')
    assert dp.args == ['arg', 'arg2']
    assert dp.description == 'test description'
    assert dp.arg_name == 'arg'
    assert dp.type_name == 'int'
    assert dp.is_optional == True
    assert dp.default == 'None'


# Generated at 2022-06-21 11:40:01.754619
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None

# Unit tests for Docstring class

# Generated at 2022-06-21 11:40:06.561136
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []



# Generated at 2022-06-21 11:40:13.355338
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring"""
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:40:21.806001
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test Docstring's constructor."""
    comment = Docstring()
    assert comment.short_description is None
    assert comment.long_description is None
    assert comment.blank_after_short_description is False
    assert comment.blank_after_long_description is False
    assert comment.meta == []
    assert comment.params == []
    assert comment.raises == []
    assert comment.returns is None
    assert comment.deprecation is None


# Generated at 2022-06-21 11:40:53.769525
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError("bla")


# Generated at 2022-06-21 11:40:56.693287
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['parameter', 'arg', 'argument', 'attribute', 'key', 'keyword'], 'description', 'type_name')


# Generated at 2022-06-21 11:41:01.690319
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    class C:
        """C docstring.""" 
        def f(self, x):
            """Function docstring.
             """
            a = x

    x = C()
    ra = x.f(1)
    assert isinstance(ra, DocstringReturns) 
    ra = x.f(1,2)
    assert not isinstance(ra, DocstringReturns) 

# Generated at 2022-06-21 11:41:02.975058
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([":raises", "RuntimeError"], "description", "RuntimeError")

# Generated at 2022-06-21 11:41:07.215429
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(['param', 'arg'], ' description \n', 'arg', 'str', 'True', 'None')
    assert(x.args == ['param', 'arg'])
    assert(x.description == ' description \n')
    assert(x.arg_name == 'arg')
    assert(x.type_name == 'str')
    assert(x.is_optional == 'True')
    assert(x.default == 'None')


# Generated at 2022-06-21 11:41:10.985585
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(args=["arg1", "arg2"], description="hey, here's some description")
    assert d.args == ["arg1", "arg2"]
    assert d.description == "hey, here's some description"


# Generated at 2022-06-21 11:41:15.030305
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_Docstring = DocstringDeprecated(["param", "argument"], "description", "version")
    assert test_Docstring.args == ["param", "argument"]
    assert test_Docstring.description == "description"
    assert test_Docstring.version == "version"


# Generated at 2022-06-21 11:41:16.856134
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    aDocstringDeprecated = DocstringDeprecated(["arg1", "arg2"], "description", "version")

    assert aDocstringDeprecated.args == ["arg1", "arg2"]
    assert aDocstringDeprecated.description == "description"
    assert aDocstringDeprecated.version == "version"
# test end


# Generated at 2022-06-21 11:41:19.293430
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "since version 2", "2")



# Generated at 2022-06-21 11:41:27.056954
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        ["param"],
        "argument of the function",
        "arg",
        None,
        None,
        None,
    )
    if param.args == ["param"] and param.description == "argument of the function" and param.arg_name == "arg":
        print("Constructor of class DocstringParam is correct")
    else:
        print("Constructor of class DocstringParam is NOT correct")


# Generated at 2022-06-21 11:42:44.547657
# Unit test for constructor of class ParseError
def test_ParseError():

    # Test cases:
    #   Valid Argument
    #   Invalid Argument Type
    #   Invalid Argument Value

    # Valid Argument
    try:
        ParseError("This is a valid argument")
        assert True
    except:
        assert False

    # Invalid Argument Type
    try:
        ParseError(0)
        assert False
    except:
        assert (True)

    # Invalid Argument Value
    try:
        ParseError("")
        assert False
    except:
        assert True




# Generated at 2022-06-21 11:42:48.751915
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["as"], "as", "as")
    assert a.args == ["as"]
    assert a.description == "as"
    assert a.type_name == "as"
    a = DocstringDeprecated([], "as", "as")
    assert a.args == []
    assert a.description == "as"
    assert a.type_name == "as"


# Generated at 2022-06-21 11:42:50.129185
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None


# Generated at 2022-06-21 11:42:51.567080
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["param"], "description")
    assert meta.args == ["param"]
    assert meta.description == "description"


# Generated at 2022-06-21 11:42:55.737505
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args = ["param", "argument"], description = "a string", arg_name = "a", type_name = "b", is_optional = True, default = "c")
    assert dp.args == ["param", "argument"]
    assert dp.description == "a string"
    assert dp.arg_name == "a"
    assert dp.type_name == "b"
    assert dp.is_optional == True
    assert dp.default == "c"


# Generated at 2022-06-21 11:42:57.566465
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()
    assert isinstance(x, Docstring)



# Generated at 2022-06-21 11:43:06.071930
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default value"
    doc_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert isinstance(doc_param, DocstringParam)
    assert len(doc_param.args) == 7
    assert doc_param.args == args
    assert doc_param.description == description
    assert doc_param.arg_name == arg_name
    assert doc_param.type_name == type_name
    assert doc_param.is_optional == is_optional
    assert doc_param.default == default


# Generated at 2022-06-21 11:43:10.668460
# Unit test for constructor of class Docstring
def test_Docstring():
    d1 = Docstring()
    assert d1.short_description is None
    assert d1.long_description is None
    #assert d1.blank_after_short_description is False
    #assert d1.blank_after_long_description is False
    #assert d1.meta == []

# Generated at 2022-06-21 11:43:13.060643
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [1,2,3]
    description = "I am Docstring Meta"
    obj = DocstringMeta(args, description)
    assert obj.args == args
    assert obj.description == description


# Generated at 2022-06-21 11:43:19.499975
# Unit test for constructor of class DocstringReturns