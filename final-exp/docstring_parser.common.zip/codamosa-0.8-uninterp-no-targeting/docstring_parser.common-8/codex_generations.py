

# Generated at 2022-06-21 11:34:17.973175
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(["param arg: description"],
                         "description",
                         "arg",
                         None,
                         None,
                         None)
    assert doc.arg_name == "arg"
    assert doc.description == "description"
    assert doc.type_name is None
    assert doc.is_optional is None
    assert doc.default is None
    assert doc.args == ["param arg: description"]



# Generated at 2022-06-21 11:34:21.451076
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """test constructor of class DocstringMeta."""

    # arrange
    args = ["args", "arg1", "param1"]
    description = "This is description"

    # act
    doc = DocstringMeta(args, description)

    # assert
    assert doc.args == args
    assert doc.description == description


# Generated at 2022-06-21 11:34:24.553317
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises"]
    description = None
    type_name = None
    return DocstringRaises(args, description, type_name)


# Generated at 2022-06-21 11:34:35.397908
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr_ret = DocstringReturns(['return', 'returns'], 'Return a value', 'str', False)
    assert docstr_ret.args == ['return', 'returns']
    assert docstr_ret.description == 'Return a value'
    assert docstr_ret.type_name == 'str'
    assert docstr_ret.is_generator == False
    assert docstr_ret.return_name == None
    docstr_ret = DocstringReturns(['yield', 'yields'], 'Return a value', 'str', True)
    assert docstr_ret.args == ['yield', 'yields']
    assert docstr_ret.description == 'Return a value'
    assert docstr_ret.type_name == 'str'
    assert docstr_ret.is_generator == True

# Generated at 2022-06-21 11:34:37.100974
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], "", "")


# Generated at 2022-06-21 11:34:38.782266
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Error")
    assert err.args == ("Error",)


# Generated at 2022-06-21 11:34:42.903696
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1: args is the empty list, and the description is abc
    assert(DocstringParam([], "abc", "arg", "type_name", True, "default").args == [])
    assert(DocstringParam([], "abc", "arg", "type_name", True, "default").description == "abc")
    assert(DocstringParam([], "abc", "arg", "type_name", True, "default").arg_name == "arg")
    assert(DocstringParam([], "abc", "arg", "type_name", True, "default").type_name == "type_name")
    assert(DocstringParam([], "abc", "arg", "type_name", True, "default").is_optional == True)

# Generated at 2022-06-21 11:34:45.600651
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        docstring = DocstringParam(1,2,3,4,5,6)
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-21 11:34:51.733224
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta."""
    dm = DocstringMeta([''], '')
    if dm.args == [''] and dm.description == '':
        print('Interior test of DocstringMeta constructor passed.')
    else:
        print('Interior test of DocstringMeta constructor did not pass.')


# Generated at 2022-06-21 11:34:53.248063
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['arg', 'description'], 'description')
    assert d.args == ['arg', 'description']
    assert d.description == 'description'


# Generated at 2022-06-21 11:35:06.307984
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['parameter', 'arg', 'argument', 'attribute', 'key']
    description = 'description'
    arg_name = 'args'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    a = DocstringParam(args,description,arg_name,type_name,is_optional,default)
    assert a.arg_name == 'args'
    assert a.description == 'description'
    assert a.type_name == 'type_name'
    assert a.is_optional == True
    assert a.default == 'default'


# Generated at 2022-06-21 11:35:13.067673
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # :deprecated: since 2.0: Use ``get_loaded_package_names`` instead.
    args = ['deprecated']
    description = 'since 2.0: Use ``get_loaded_package_names`` instead.'
    version = '2.0'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'since 2.0: Use ``get_loaded_package_names`` instead.'
    assert docstring_deprecated.version == '2.0'



# Generated at 2022-06-21 11:35:15.443196
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test DocstringReturns."""
    assert DocstringReturns([':returns'], 'returns description', 'int', False)



# Generated at 2022-06-21 11:35:17.779915
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        print(e)


# Generated at 2022-06-21 11:35:24.334768
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(args=["param"], description="parameter", arg_name="arg", type_name="int", is_optional=True, default=3)
    assert param.args == ["param"]
    assert param.description == "parameter"
    assert param.arg_name == "arg"
    assert param.type_name == "int"
    assert param.is_optional == True
    assert param.default == 3


# Generated at 2022-06-21 11:35:28.043981
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:35:32.848587
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    return 0


# Generated at 2022-06-21 11:35:39.155906
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    _test = DocstringReturns(["arg1","arg2"], "description", "return_type", False)
    assert(_test.args == ["arg1","arg2"])
    assert(_test.description == "description")
    assert(_test.type_name == "return_type")
    assert(_test.is_generator == False)
    assert(_test.return_name is None)


# Generated at 2022-06-21 11:35:42.526755
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # This will raise an exception
    try:
        DocstringRaises(["param"], "description", "type_name", "fail")
    except:
        return True
    raise Exception


# Generated at 2022-06-21 11:35:46.697267
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(['param', 'my_param'], 'My description for my_param.', 'my_param', 'str', True, 'my_default_value')
        print('Constructor of DocstringParam works as expected')
    except Exception:
        print('Constructor of DocstringParam caused an exception')



# Generated at 2022-06-21 11:35:56.825892
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_name = None
    assert DocstringReturns(None, None, None, "docstring returns, where is my return?")
    


# Generated at 2022-06-21 11:36:04.853810
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'test description'
    result = DocstringMeta(args, description)
    if(result.args != args):
        print('Test 1 failed')
        print('Expected ' + str(args))
        print('Got ' + str(result.args))
    if(result.description != description):
        print('Test 2 failed')
        print('Expected ' + description)
        print('Got ' + result.description)

if __name__ == "__main__":
    test_DocstringMeta()

# Generated at 2022-06-21 11:36:12.607249
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['raises']
    description = 'if something happens'
    type_name = None
    is_generator = False
    return_name = None

    docstring_returns = DocstringReturns(
        args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == ['raises']
    assert docstring_returns.description == 'if something happens'
    assert docstring_returns.type_name == None
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == None

    return_name = 'return_name'
    docstring_returns = DocstringReturns(
        args, description, type_name, is_generator, return_name)

# Generated at 2022-06-21 11:36:17.269210
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'dépréciée', 'veraltet']
    description = 'Use this method for deprecated reason.'
    version = '0.1.0'
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version

# Generated at 2022-06-21 11:36:26.851338
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['test', 'test1']
    type_name = 'type1'
    is_generator = True
    description = 'tthis is a test description'
    return_name = 'return_name'
    test_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    print(test_returns.args)
    print(test_returns.description)
    print(test_returns.type_name)
    print(test_returns.is_generator)
    print(test_returns.return_name)


# Generated at 2022-06-21 11:36:35.406661
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstr_param = DocstringParam(['param'], 'description', 'arg', 'str', False, None)
    assert isinstance(docstr_param, DocstringParam)
    assert docstr_param.args == ['param']
    assert docstr_param.description == 'description'
    assert docstr_param.arg_name == 'arg'
    assert docstr_param.type_name == 'str'
    assert docstr_param.is_optional == False
    assert docstr_param.default == None


# Generated at 2022-06-21 11:36:38.339394
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['a'], 'b')
    assert a.args == ['a']
    assert a.description == 'b'


# Generated at 2022-06-21 11:36:44.852610
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [] # type: T.List[str]
    description = None
    type_name = None
    is_generator = False
    return_name = None 
    return_test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert return_test.args == args
    assert return_test.description == description
    assert return_test.type_name == type_name
    assert return_test.is_generator == is_generator
    assert return_test.return_name == return_name


# Generated at 2022-06-21 11:36:46.105488
# Unit test for constructor of class ParseError
def test_ParseError():
    print(ParseError)


# Generated at 2022-06-21 11:36:58.563246
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    input_args = ['arg1', 'arg2', 'arg3', 'arg4']
    input_description = 'Testing'
    input_arg_name = 'input_arg_name'
    input_type_name = 'input_type_name'
    input_is_optional = False
    input_default = 'input_default'
    output = DocstringParam(input_args, input_description, input_arg_name,
                            input_type_name, input_is_optional, input_default)
    assert output.args == input_args, "Wrong value in args"
    assert output.description == input_description, "Wrong value in description"
    assert output.arg_name == input_arg_name, "Wrong value in arg_name"

# Generated at 2022-06-21 11:37:15.947867
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([":deprecated"], "description", "version")

test_DocstringDeprecated()

# Generated at 2022-06-21 11:37:21.867474
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstrparam = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert docstrparam.args == ['param', 'arg']
    assert docstrparam.description == 'description'
    assert docstrparam.arg_name == 'arg_name'
    assert docstrparam.type_name == 'type_name'
    assert docstrparam.is_optional == 'is_optional'
    assert docstrparam.default == 'default'
    

# Generated at 2022-06-21 11:37:26.607346
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test DocstringParam constructor."""
    dp = DocstringParam(['param', 'arg'], 'description', 'arg1', 'type1', True,
                        'default')
    assert dp.args == ['param', 'arg']
    assert dp.description == 'description'
    assert dp.arg_name == 'arg1'
    assert dp.type_name == 'type1'
    assert dp.is_optional == True
    assert dp.default == 'default'



# Generated at 2022-06-21 11:37:30.452760
# Unit test for constructor of class Docstring
def test_Docstring():
    docObj = Docstring()
    assert (docObj.short_description == None)
    assert (docObj.long_description == None)
    assert (docObj.blank_after_short_description == False)
    assert (docObj.blank_after_long_description == False)
    assert (docObj.meta == [])

# Unit tests for params and raises methods of class Docstring

# Generated at 2022-06-21 11:37:38.789657
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d1=DocstringParam(["param","arg"], "desc", "a", "b", True, "c")
    d1.args[0]=="param" # test the first element in list
    d1.args[1]=="arg"   # test the second element in list
    d1.description=="desc"
    d1.arg_name=="a"
    d1.type_name=="b"
    d1.is_optional==True
    d1.default=="c"

# Generated at 2022-06-21 11:37:41.590040
# Unit test for constructor of class Docstring
def test_Docstring():
    docs = Docstring()
    if not (docs.short_description is None and docs.long_description is None and len(docs.meta) == 0):
        raise AssertionError()


# Generated at 2022-06-21 11:37:44.466532
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(
        ["raises"], "if something", "ValueError"
    )
    assert d.description == "if something"
    assert d.args == ["raises"]
    assert d.type_name == "ValueError"

# Generated at 2022-06-21 11:37:47.262851
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None  # type: ignore
    assert doc.long_description is None  # type: ignore
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []



# Generated at 2022-06-21 11:37:57.983768
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """
    Unit test for constructor of class DocstringParam
    """
    args=["a","b"]
    description="this is description"
    arg_name="this is arg_name"
    type_name="this is type_name"
    is_optional = False
    default="this is default"
    ds = DocstringParam(args=args, description=description, arg_name=arg_name, type_name=type_name, is_optional=is_optional, default=default)
    assert ds.args == args
    assert ds.description == description
    assert ds.arg_name == arg_name
    assert ds.type_name == type_name
    assert ds.is_optional == is_optional
    assert ds.default == default



# Generated at 2022-06-21 11:37:59.436490
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('Error')
    assert(error.args == 'Error')

# Generated at 2022-06-21 11:38:30.604919
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg", "type", False, "default")


# Generated at 2022-06-21 11:38:39.456735
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["test_args"];
    description = "test_description"
    type_name = "test_type_name"
    is_generator = True;
    return_name= "test_name"
    obj = DocstringReturns(args,description,type_name,is_generator,return_name)
    if (obj.args == args and obj.description == description and obj.type_name == type_name
        and obj.is_generator == is_generator and obj.return_name == return_name):
        print("Test for DocstringReturns passed")
    else:
        print("Test for DocstringReturns failed")
        
test_DocstringReturns()


# Generated at 2022-06-21 11:38:50.120538
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """
    Test the constructor for DocstringRaises.
    """
    new_raise = DocstringRaises(["param"], "description", "type_name")
    assert isinstance(new_raise, DocstringRaises)
    assert new_raise.args == ["param"]
    assert new_raise.description == "description"
    assert new_raise.type_name == "type_name"

    with raises(AssertionError):
        DocstringRaises([], "description", "type_name")
    with raises(AssertionError):
        DocstringRaises(["param"], "", "type_name")
    with raises(AssertionError):
        DocstringRaises(["param"], "description", "")


# Generated at 2022-06-21 11:38:55.433464
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = ""
    type_name = ""
    is_generator = False
    return_name = ""
    test_case = DocstringReturns(args,description,type_name,is_generator,return_name)
    assert test_case.args == []
    assert test_case.description == ""
    assert test_case.type_name == ""
    assert test_case.is_generator == False
    assert test_case.return_name == ""

# Generated at 2022-06-21 11:38:56.143113
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError()

# Generated at 2022-06-21 11:38:59.249822
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(args = [], description = "")
    assert doc.args == []
    assert doc.description == ""


# Generated at 2022-06-21 11:39:06.997774
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        args=["param", "name"],
        description="my docstring",
        arg_name="name",
        type_name="str",
        is_optional=True,
        default="None",
    )
    assert param.args == ["param", "name"]
    assert param.description == "my docstring"
    assert param.arg_name == "name"
    assert param.type_name == "str"
    assert param.is_optional == True
    assert param.default == "None"


# Generated at 2022-06-21 11:39:11.017693
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param"]
    description = "Return the value of the test"
    arg_name = "test"
    type_name = "Class"
    is_optional = False
    default = "None"
    assert DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-21 11:39:12.929287
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_type = DocstringReturns([], "", "list")
    assert return_type.type_name == "list"



# Generated at 2022-06-21 11:39:18.447337
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # string is constructed so that there is no :param, :returns, or :raises in the string
    # as no error or handling code was written to handle this case
    args = ['foo'] 
    description = 'This is the description'
    type_name = 'int'

    raises = DocstringRaises(args, description, type_name)

    # Testing that constructor correctly assigned values in all cases.
    assert raises.args == args, "Wrong value for args"
    assert raises.description == description, "Wrong value for description"
    assert raises.type_name == type_name, "Wrong value for type_name"
test_DocstringRaises()



# Generated at 2022-06-21 11:40:26.834522
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """ Test the DocstringReturns class constructor. """
    dr = DocstringReturns([], "", "", False)
    assert dr.type_name == ""
    assert dr.is_generator == False

# Generated at 2022-06-21 11:40:30.052818
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    item = DocstringMeta([":param"], "parameter")
    assert item.args == [":param"]
    assert item.description == "parameter"


# Generated at 2022-06-21 11:40:36.490988
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=[":param", "value", ":", "", "type"],
                        description="value must be of type int",
                        arg_name="value",
                        type_name="int",
                        is_optional=False,
                        default=None)


# Generated at 2022-06-21 11:40:39.012558
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta1=DocstringMeta(['param'], 'string1')
    assert(meta1.args == ['param'])
    assert(meta1.description == 'string1')


# Generated at 2022-06-21 11:40:41.146900
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "descr").description == "descr"
    assert DocstringMeta(["args"], "descr").args == ["args"]

# Generated at 2022-06-21 11:40:43.292161
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    my_meta = DocstringMeta(["arg"], "description")
    assert my_meta.args == ["arg"]
    assert my_meta.description == "description"

# Generated at 2022-06-21 11:40:45.200746
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    npe = ParseError()
    print(npe.__doc__)
    assert npe is not None


# Generated at 2022-06-21 11:40:48.632742
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error!")
    except ParseError:
        pass

try:
    raise ParseError("Error!")
except ParseError:
    pass

# Unit for constructor of class DocstringMeta

# Generated at 2022-06-21 11:40:51.716642
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    r = DocstringRaises(['raises'], 'something', 'ValueError')
    assert r.type_name == 'ValueError'
    assert r.description == 'something'

# Generated at 2022-06-21 11:40:54.181611
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep = DocstringDeprecated(['deprecated'], 'Dummy description', '42')
    assert dep.args == ['deprecated']
    assert dep.description == 'Dummy description'
    assert dep.version == '42'

# Generated at 2022-06-21 11:42:30.486753
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg"]
    description = "description"
    dt = DocstringMeta(args, description)
    assert dt.args == args
    assert dt.description == description


# Generated at 2022-06-21 11:42:31.781461
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.params == []


# Generated at 2022-06-21 11:42:35.260173
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['param'], 'This is a description', "arg_name", "type", True, "default")
    #print("type:", a.type_name)
    #print("optional:", a.is_optional)
    #print("default:", a.default)

# Generated at 2022-06-21 11:42:40.438858
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test docstring arguments for class DocstringRaises"""
    args = ["arg1"]
    description = "some description"
    type_name = "ClassName"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == ["arg1"]
    assert docstring_raises.description == "some description"
    assert docstring_raises.type_name == "ClassName"


# Generated at 2022-06-21 11:42:46.238786
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    from object_analysis.parser import DocstringReturns
    d_ret = DocstringReturns(args = [], description = "The docstring returns." , type_name = "int", is_generator = False, return_name = None)

    # basic test
    assert isinstance(d_ret,DocstringReturns)

    # test of function
    assert d_ret.args == []
    assert d_ret.description == "The docstring returns."
    assert d_ret.type_name == "int"
    assert d_ret.is_generator == False
    assert d_ret.return_name == None




# Generated at 2022-06-21 11:42:49.293424
# Unit test for constructor of class Docstring
def test_Docstring():
    import autodocstring
    docstring = autodocstring.Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

# Generated at 2022-06-21 11:42:55.658243
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # test_inheritance
    assert issubclass(DocstringParam, DocstringMeta)
    assert issubclass(DocstringRaises, DocstringMeta)
    assert issubclass(DocstringReturns, DocstringMeta)
    assert issubclass(DocstringDeprecated, DocstringMeta)

    # test_one_instance
    docstring_meta = DocstringMeta(['param'], 'description')
    assert isinstance(docstring_meta, DocstringMeta)

    # test_other_instances
    docstring_param = DocstringParam(['param'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert isinstance(docstring_param, DocstringParam)

    docstring_raises = DocstringRaises(['raises'], 'description', 'type_name')

# Generated at 2022-06-21 11:43:03.417562
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    with pytest.raises(TypeError) as excinfo:
        DocstringDeprecated(
            ["test", "test", "test", "test"], "test", "test"
        )
    assert excinfo.value.args[0] == '__init__() takes 3 positional arguments but 4 were given'

    with pytest.raises(TypeError) as excinfo:
        DocstringDeprecated(
            ["test", "test", "test"], "test"
        )
    assert excinfo.value.args[0] == '__init__() missing 1 required positional argument: \'version\''


# Generated at 2022-06-21 11:43:07.857554
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """test constructor of class DocstringRaises."""
    a=DocstringRaises(["a"], "b", "c")
    assert a.args==["a"]
    assert a.description=="b"
    assert a.type_name=="c"
    a=DocstringRaises(["a"], None, None)
    assert a.args==["a"]
    assert a.description==None
    assert a.type_name==None
    assert a.description==None


# Generated at 2022-06-21 11:43:11.532358
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(
        args=["default"], description="a string", version="1.2.3"
    )
    assert docstringDeprecated.version == "1.2.3"
    assert docstringDeprecated.description == "a string"
    assert docstringDeprecated.type_name is None
    assert docstringDeprecated.args == ["default"]

