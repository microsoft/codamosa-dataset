

# Generated at 2022-06-21 11:34:19.625637
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', True, 'default')
    assert dp.args == ['param', 'arg']
    assert dp.description == 'description'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == True
    assert dp.default == 'default'


# Generated at 2022-06-21 11:34:22.200558
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    args = ["args1", "args2"]
    description = "description"

    docMetaObj = DocstringMeta(args, description)
    assert (docMetaObj.args == args)
    assert (docMetaObj.description == description)


# Generated at 2022-06-21 11:34:24.039733
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "", "", "", "", "")


# Generated at 2022-06-21 11:34:27.225577
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta(["a", "b", "c"], "d")
        assert False, "no exception raised"
    except NotImplementedError:
        assert True


# Generated at 2022-06-21 11:34:32.268586
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(
        args=['deprecated'],
        description='functionality being removed',
        version='1.0.0'
    )
    assert meta.args == ['deprecated']
    assert meta.description == 'functionality being removed'
    assert meta.version == '1.0.0'



# Generated at 2022-06-21 11:34:37.426534
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.params == []
    assert a.raises == []
    assert a.returns == None
    assert a.deprecation == None


# Generated at 2022-06-21 11:34:41.638211
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring1 = Docstring()
    assert docstring1.short_description == None
    assert docstring1.long_description == None
    assert docstring1.blank_after_short_description == False
    assert docstring1.blank_after_long_description == False
    assert docstring1.meta == []
    assert docstring1.params == []
    assert docstring1.raises == []
    assert docstring1.returns == None
    assert docstring1.deprecation == None

# Generated at 2022-06-21 11:34:43.381769
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert isinstance(error,ParseError)


# Generated at 2022-06-21 11:34:44.400008
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises()


# Generated at 2022-06-21 11:34:48.019135
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("Something wrong happened")
    try:
        raise ParseError("Something wrong happened")
    except RuntimeError:
        pass


# Generated at 2022-06-21 11:34:55.016771
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-21 11:35:06.569448
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["return", "returns"], None, None, False)
    assert a.args == ["return", "returns"]
    assert a.description == None
    assert a.type_name == None
    assert a.is_generator == False
    assert a.return_name == None
    b = DocstringReturns(["returns"], None, None, True, "value")
    assert b.args == ["returns"]
    assert b.description == None
    assert b.type_name == None
    assert b.is_generator == True
    assert b.return_name == "value"
    c = DocstringReturns(["return"], None, None, False, None)
    assert c.args == ["return"]
    assert c.description == None
    assert c.type_name == None

# Generated at 2022-06-21 11:35:09.890902
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns([':param', 'arg', 'description'],
    'this is a test for constructor',
    'type_name',
    True,
    'return_name')

    assert doc.args == [':param', 'arg', 'description']

# Generated at 2022-06-21 11:35:12.484739
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        doc_meta = DocstringMeta([], 'This is a test')

    except:
        print("DocstringMeta constructor not working")


# Generated at 2022-06-21 11:35:18.918701
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam(["hey"], "yo", "1", "2", True, "3")
    assert docstringParam.args == ["hey"]
    assert docstringParam.description == "yo"
    assert docstringParam.arg_name == "1"
    assert docstringParam.type_name == "2"
    assert docstringParam.is_optional == True
    assert docstringParam.default == "3"


# Generated at 2022-06-21 11:35:22.860439
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["test"], "Test description", "1.0")
    assert test.args == ["test"]
    assert test.description == "Test description"
    assert test.version == "1.0"


# Generated at 2022-06-21 11:35:27.527417
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = "descrip"
    type_name = 'name'
    a = DocstringRaises(args, description, type_name)
    a.args = args
    a.description = description
    a.type_name = type_name
    assert a.type_name == type_name
    assert a.description == description
    assert a.args == args

# Generated at 2022-06-21 11:35:33.965596
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-21 11:35:45.603815
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["param"], "description")
    assert a.args == ["param"]
    assert a.description == "description"
    # test for constructor of class DocstringParam
    b = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert b.args == ["param"]
    assert b.description == "description"
    assert b.arg_name == "arg_name"
    assert b.type_name == "type_name"
    assert b.is_optional == True
    assert b.default == "default"
    # test for constructor of class DocstringReturns
    c = DocstringReturns(["raises"], "description", "type_name", True, "return_name")
    assert c.args == ["raises"]

# Generated at 2022-06-21 11:35:58.615066
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Just in case
    a = DocstringReturns([], None, None, False, None).args
    assert a is not None
    b = DocstringReturns([], None, None, False, None).description
    assert b is not None
    c = DocstringReturns([], None, None, False, None).type_name
    assert c is not None
    d = DocstringReturns([], None, None, False, None)
    assert d is not None
    # Testing constructor
    a = DocstringReturns([], "Description", "TypeName", True, "type").args
    assert a is not None
    b = DocstringReturns([], "Description", "TypeName", True, "type").description
    assert b is not None
    c = DocstringReturns([], "Description", "TypeName", True, "type").type_name

# Generated at 2022-06-21 11:36:15.757598
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test a valid docstring
    s = DocstringRaises(
        ["type", "ValueError"],
        "if something happens",
        "ValueError",
    ).type_name
    assert s == "ValueError"
    # Test an invalid docstring
    s = DocstringRaises(
        ["type", "ValueError"],
        "if something happens",
        "ValueError",
    ).description
    assert s == "if something happens"
    # Test an invalid docstring
    s = DocstringRaises(
        ["type", "ValueError"],
        "if something happens",
        "ValueError",
    ).args
    assert s == ["type", "ValueError"]


# Generated at 2022-06-21 11:36:19.221559
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    item = DocstringReturns(['a', 'b'], 'description', 10, True, "return_name")
    assert item.description == "description"
    assert item.type_name == 10
    assert item.is_generator == True
    assert item.return_name == "return_name"

# Generated at 2022-06-21 11:36:23.671261
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    Test ParseError by calling the constructor with a test message.
    """
    error = ParseError("TEST")
    assert str(error) == "TEST"


# Generated at 2022-06-21 11:36:27.469898
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False


# Generated at 2022-06-21 11:36:29.745949
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case = ParseError('Testing')
    assert test_case is not None


# Generated at 2022-06-21 11:36:34.919511
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0


# Generated at 2022-06-21 11:36:40.606984
# Unit test for constructor of class Docstring
def test_Docstring():
        d = Docstring()
        assert not d.params
        assert not d.raises
        assert d.returns is None
        assert d.deprecation is None

        assert d.short_description is None
        assert d.long_description is None
        assert not d.blank_after_short_description
        assert not d.blank_after_long_description


# Generated at 2022-06-21 11:36:43.879440
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raise", "arg", "lalala"]
    description = "lalala"
    type_name = "boolean"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises != None


# Generated at 2022-06-21 11:36:49.600705
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    para = DocstringReturns(['return'], 'A list of nodes.', 'List', False)
    assert para.args == ['return']
    assert para.description == 'A list of nodes.'
    assert para.type_name == 'List'
    assert para.is_generator == False
    

# Generated at 2022-06-21 11:36:56.224335
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    list_arg = []
    assert type(list_arg) == list
    assert list_arg == []

    assert type(description) == str
    assert description == 'description'

    assert type(args) == list
    assert args == []
    assert args == list_arg

    assert type(parent) == DocstringMeta
    assert parent.args == args
    assert parent.description == description



# Generated at 2022-06-21 11:37:05.582615
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = 'Test'
    err = ParseError(msg)
    assert str(err) == msg


# Generated at 2022-06-21 11:37:08.027423
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("")
    except ParseError:
        pass
    else:
        raise Exception('ParseError not raised')


# Generated at 2022-06-21 11:37:15.345827
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # input for test
    args = ['returns', 'typedparam2']
    description = 'This is a docstring test'
    is_generator = False
    type_name = 'typedparam2'
    return_name = 'return_name'

    # expected output
    args_expected = ['returns', 'typedparam2']
    description_expected = 'This is a docstring test'
    is_generator_expected = False
    type_name_expected = 'typedparam2'
    return_name_expected = 'return_name'

    # testing constructor
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)

    # assert testing result
    assert(docstring_returns.args == args_expected)

# Generated at 2022-06-21 11:37:17.328687
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "argument"]
    description = "description"
    test = DocstringMeta(args, description)

    assert test.args == ["param", "argument"]
    assert test.description == "description"



# Generated at 2022-06-21 11:37:21.301975
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["a", "b", "c"]
    description = "abc"
    param_type_name = "abc"
    a = DocstringRaises(args, description, param_type_name)
    assert isinstance(a, DocstringMeta)
    assert isinstance(a, DocstringRaises)
    assert isinstance(a.args, list)
    assert isinstance(a.description, str)
    assert isinstance(a.type_name, str)
    assert a.args == args
    assert a.description == description
    assert a.type_name == param_type_name



# Generated at 2022-06-21 11:37:30.335489
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["abc", "def"]
    description = "describe"
    type_name = "typename"
    is_generator = 1
    return_name = "return name"
    docstringReturns = DocstringReturns(args=args, description=description, type_name=type_name, is_generator=is_generator, return_name=return_name)
    # print(docstringReturns.args)
    # print(docstringReturns.description)
    # print(docstringReturns.type_name)
    # print(docstringReturns.is_generator)
    # print(docstringReturns.return_name)


if __name__ == "__main__":
    test_DocstringReturns()

# Generated at 2022-06-21 11:37:38.659830
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert (DocstringReturns(["return"], None, None, False).args == ["return",]) 
    assert (DocstringReturns(["return"], None, None, False).is_generator == False)
    assert (DocstringReturns(["return"], None, None, False).type_name == None)
    assert (DocstringReturns(["return"], None, None, False).return_name == None)
    assert (DocstringReturns(["return"], None, None, False).description == None)


# Generated at 2022-06-21 11:37:43.191496
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([], None, 'arg_name', None, True, '3')
    assert docstring_param.args == [] 
    assert docstring_param.description == None 
    assert docstring_param.arg_name == 'arg_name'
    assert docstring_param.type_name == None
    assert docstring_param.is_optional == True
    assert docstring_param.default == '3' 


# Generated at 2022-06-21 11:37:44.653731
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError("This is an error.")
    assert x.msg == "This is an error."


# Generated at 2022-06-21 11:37:45.709812
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("foo").args[0] == "foo"


# Generated at 2022-06-21 11:37:54.952145
# Unit test for constructor of class ParseError
def test_ParseError():
    myParseError = ParseError("EONOW")

# Generated at 2022-06-21 11:38:02.566354
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args=['arg1', 'arg2']
    description='desc'
    type_name='type_name'
    is_generator='false'
    return_name='ret_name'

    ret = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert ret.args == ['arg1', 'arg2']
    assert ret.description == 'desc'
    assert ret.type_name == 'type_name'
    assert ret.is_generator == 'false'
    assert ret.return_name == 'ret_name'


# Generated at 2022-06-21 11:38:11.057544
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d_para = DocstringParam(
        args = [],
        description = None,
        arg_name = 'arg',
        type_name = None,
        is_optional = None,
        default = None,
    )
    assert d_para.args is not None
    assert d_para.description is None
    assert d_para.arg_name == 'arg'
    assert d_para.type_name is None
    assert d_para.is_optional is None
    assert d_para.default is None


# Generated at 2022-06-21 11:38:16.150065
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringMeta = DocstringDeprecated(["param"], "hello world", "1.0")
    assert docstringMeta.args == ["param"]
    assert docstringMeta.description == "hello world"
    assert docstringMeta.version == "1.0"


# Generated at 2022-06-21 11:38:17.540992
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("Test")


# Generated at 2022-06-21 11:38:21.519165
# Unit test for constructor of class ParseError
def test_ParseError():
    # noinspection PyUnusedLocal
    @staticmethod
    def func_for_parseerror(required_param, optional_param=1):
        raise ParseError('exception_message')

    try:
        func_for_parseerror(1, 2)
    except ParseError as error:
        print(error)


# Generated at 2022-06-21 11:38:30.538457
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=[], description='', arg_name='', type_name='', is_optional=True, default='')
    test_param = DocstringParam(['param', 'x'], 'description',
                                'x', 'int', False, None)
    assert docstring_param.args == []
    assert docstring_param.description == ''
    assert docstring_param.arg_name == ''
    assert docstring_param.type_name == ''
    assert docstring_param.is_optional == True
    assert docstring_param.default == ''
    assert test_param.args == ['param', 'x']
    assert test_param.description == 'description'
    assert test_param.arg_name == 'x'
    assert test_param.type_name == 'int'

# Generated at 2022-06-21 11:38:34.842832
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(['a', 'b'], 'c')
    assert dm.args == ['a', 'b']
    assert dm.description == 'c'


# Generated at 2022-06-21 11:38:36.887029
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['1', '2']
    description = 'XYZ'
    d = DocstringMeta(args, description)
    assert d



# Generated at 2022-06-21 11:38:40.090513
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert(a.short_description == None)
    assert(a.long_description == None)
    assert(a.params == [])
    assert(a.raises == [])
    assert(a.returns == None)
    assert(a.deprecation == None)


# Generated at 2022-06-21 11:38:53.483722
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test constructor
    assert DocstringMeta(args=["flag"], description="Documentation")
    # Test no args
    try:
        DocstringMeta(args=[], description="Documentation")
    except ParseError:
        pass
    # Test no description
    try:
        DocstringMeta(args=["flag"], description="")
    except ParseError:
        pass


# Generated at 2022-06-21 11:38:55.612021
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(['parameter','arg','argument','attribute','key','keyword'],
                                     'description',
                                     'arg',
                                     'type_name',
                                     'is_optional',
                                     'default')


# Generated at 2022-06-21 11:39:00.453435
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        DocstringRaises(['args'], 'my_description', 'my_type_name')
        print("test_DocstringRaises passed")
    except:
        print("test_DocstringRaises failed")

test_DocstringRaises()

# Generated at 2022-06-21 11:39:06.269697
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['raises', 'KeyError'], 'description', 'type_name')
    assert(docstring_raises.type_name == "type_name")
    assert (docstring_raises.description == "description")
    assert(docstring_raises.args == ['raises', 'KeyError'])


# Generated at 2022-06-21 11:39:08.404710
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dD = DocstringDeprecated(["args"], "description", "version")
    print(dD.description)
test_DocstringDeprecated()


# Generated at 2022-06-21 11:39:09.601780
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta([1,2,3], "testing constructor")


# Generated at 2022-06-21 11:39:12.353031
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    import doctring
    a = doctring.DocstringMeta(["abc"],["abc"])
    b = doctring.DocstringDeprecated([a],["abc"],["abc"])
    return

# Generated at 2022-06-21 11:39:14.645122
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dmd = DocstringMeta(['args'], 'desc')
    assert dmd.args == ['args'] and dmd.description == 'desc'


# Generated at 2022-06-21 11:39:18.470438
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dsr = DocstringReturns(['returns'], 'this returns something', 'int', True, 'foo')
    assert dsr
    assert dsr.args
    assert dsr.description
    assert dsr.type_name
    assert dsr.is_generator
    assert dsr.return_name

# Generated at 2022-06-21 11:39:20.553935
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert (DocstringDeprecated(["param", "parameter", "arg", "argument"], "some description", "some version") is 
        not None)


# Generated at 2022-06-21 11:39:45.721423
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """
    Test for constructor of class DocstringDeprecated
    """
    args = []
    description = ""
    version = ""
    d = DocstringDeprecated(args, description, version)
    assert(d.args == [])
    assert(d.description == "")
    assert(d.version == "")



# Generated at 2022-06-21 11:39:50.026793
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['raises', 'ValueError'], 'If the input is too small', 'ValueError')
    assert str(a.args) == "['raises', 'ValueError']"
    assert str(a.description) == 'If the input is too small'
    assert str(a.type_name) == 'ValueError'


# Generated at 2022-06-21 11:39:57.193108
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:40:03.886928
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated, testing the given values for self.version and self.description"""
    assert DocstringDeprecated(['deprecated', 'since'], '1.0.0', "1.0.0").version == '1.0.0'
    assert DocstringDeprecated(['deprecated', 'since'], '1.0.0', "1.0.0").description == '1.0.0'

# Generated at 2022-06-21 11:40:05.914446
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['param', 'type'], 'self.test', 'int')


# Generated at 2022-06-21 11:40:09.218123
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_line = DocstringMeta(['param'], 'Parameter description')
    assert test_line.args == ['param']
    assert test_line.description == 'Parameter description'


# Generated at 2022-06-21 11:40:13.006555
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from examine_docstrings.examine_docstrings import DocstringMeta
    docstring_meta = DocstringMeta(['args'], 'description')
    assert docstring_meta.args == ['args']
    assert docstring_meta.description == 'description'


# Generated at 2022-06-21 11:40:16.450057
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("An error")
    except ParseError as e:
        assert str(e) == "An error"


# Generated at 2022-06-21 11:40:24.073056
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises."""
    args = ["a", "b", "c"]
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name

# Generated at 2022-06-21 11:40:28.267452
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    param = DocstringRaises(["param"], "description", "type_name")
    assert param.args == ["param"]
    assert param.description == "description"
    assert param.type_name == "type_name"

test_DocstringRaises()

# Generated at 2022-06-21 11:40:52.919961
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [':raises', 'ValueError:']
    description = "if something happens"
    type_name = "ValueError"
    def_str = DocstringRaises(args, description, type_name)
    assert def_str.args == args
    assert def_str.description == description
    assert def_str.type_name == type_name



# Generated at 2022-06-21 11:40:54.426299
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring1 = Docstring()
    assert isinstance(docstring1, Docstring)


# Generated at 2022-06-21 11:41:00.807816
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    res = doc
    assert res.short_description == None
    assert res.long_description == None
    assert res.blank_after_short_description == False
    assert res.blank_after_long_description == False
    assert res.meta == []
    assert res.params == []
    assert res.raises == []
    assert res.returns == None
    assert res.deprecation == None


# Generated at 2022-06-21 11:41:01.563470
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print(__name__)


# Generated at 2022-06-21 11:41:06.575322
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(['deprecated'], 'long description', 'version')
    # test for property args of class DocstringDeprecated
    if docstringDeprecated.args != ['deprecated']:
        raise Exception('test failed')
    # test for property description of class DocstringDeprecated
    if docstringDeprecated.description != 'long description':
        raise Exception('test failed')
    # test for property version of class DocstringDeprecated
    if docstringDeprecated.version != 'version':
        raise Exception('test failed')

# Generated at 2022-06-21 11:41:07.364558
# Unit test for constructor of class ParseError
def test_ParseError():
    raise ParseError("...")


# Generated at 2022-06-21 11:41:17.382737
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    c = DocstringReturns(
        args=['return'],
        description="returned value",
        type_name=None,
        is_generator=False,
        return_name="value",
    )
    assert c.args == ['return']
    assert c.description == "returned value"
    assert c.type_name == None
    assert c.is_generator == False
    assert c.return_name == "value"
    # Make sure the constructor of the parent class is working
    d = DocstringReturns(args=["raise"], description="raises an exception")
    assert d.args == ["raise"]
    assert d.description == "raises an exception"
    assert not hasattr(d, "type_name")
    assert not hasattr(d, "is_generator")

# Generated at 2022-06-21 11:41:19.251509
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()

# Generated at 2022-06-21 11:41:23.167697
# Unit test for constructor of class ParseError
def test_ParseError():
    """Consistency test for the ParseError class."""
    err = ParseError("something went wrong here")
    assert err.args == ("something went wrong here",)

# Generated at 2022-06-21 11:41:29.066227
# Unit test for constructor of class ParseError
def test_ParseError():
    """."""
    # without specifying any parameter
    pe = ParseError()
    assert pe.args == ()
    # specifying a parameter in the constructor
    pe = ParseError("Something wrong")
    assert pe.args == ("Something wrong",)
    # specifying the variable "Exception"
    pe = ParseError("Something wrong", "Exception")
    assert pe.args == ("Something wrong", "Exception")
    return


# Generated at 2022-06-21 11:42:20.787479
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().params == []

# Generated at 2022-06-21 11:42:23.382604
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is an error!")
    except ParseError as e:
        print(e)


# Generated at 2022-06-21 11:42:25.385869
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        assert str(e) == "Error"


# Generated at 2022-06-21 11:42:27.311230
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arg_list = ['arg']
    description = 'description'
    _ = DocstringMeta(arg_list,description)
    return object

# Generated at 2022-06-21 11:42:29.561483
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except:
        assert True


# Generated at 2022-06-21 11:42:32.623548
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(['a','b','c'], 'd', 'e')
    assert doc.args == ['a','b','c']
    assert doc.description == 'd'
    assert doc.type_name == 'e'

# Generated at 2022-06-21 11:42:34.128595
# Unit test for constructor of class ParseError
def test_ParseError():
    assert(ParseError('raised') == 'raised')


# Generated at 2022-06-21 11:42:38.548392
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(
        args=["raises", "RuntimeError"],
        description="some text",
        type_name="RuntimeError"
    )
    assert docstringRaises.args == ["raises", "RuntimeError"]
    assert docstringRaises.description == "some text"
    assert docstringRaises.type_name == "RuntimeError"

# Generated at 2022-06-21 11:42:39.908702
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["d"], "d", "d")
    return d


# Generated at 2022-06-21 11:42:42.361628
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring
    print(docstring.short_description)
    print(docstring.long_description)
    assert docstring.short_description == None
    assert docstring.long_description == None

# Generated at 2022-06-21 11:43:15.203718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(
        args=['a'],
        description='b',
        arg_name='c',
        type_name='d',
        is_optional='e',
        default='f',
    ).args == ['a']
    assert DocstringParam(
        args=['a'],
        description='b',
        arg_name='c',
        type_name='d',
        is_optional='e',
        default='f',
    ).description == 'b'
    assert DocstringParam(
        args=['a'],
        description='b',
        arg_name='c',
        type_name='d',
        is_optional='e',
        default='f',
    ).arg_name == 'c'

# Generated at 2022-06-21 11:43:15.750039
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    pass

# Generated at 2022-06-21 11:43:19.221308
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = "this is a description"
    type_name = "this is a type"
    assert DocstringRaises(args, description, type_name).args == ['arg']
    assert DocstringRaises(args, description, type_name).description == "this is a description"
    assert DocstringRaises(args, description, type_name).type_name == "this is a type"



# Generated at 2022-06-21 11:43:22.123381
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = DocstringReturns(['returns'], None, None, None, None)
    assert isinstance(docstring, DocstringReturns)


# Generated at 2022-06-21 11:43:23.961622
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(args=[], description=None, type_name=None)


# Generated at 2022-06-21 11:43:33.964999
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    par_name = 'version'
    par_descr = 'This is a version string'
    par_args = ['version']
    par_default = '1.0'
    par_type = 'str'
    par_is_optional = True
    kwarg_list = [
        par_name,
        par_descr,
        par_args,
        par_default,
        par_type,
        par_is_optional
    ]

    # Since there is no __init__ method for DocstringDeprecated, this expression can cause an exception
    if hasattr(DocstringDeprecated, '__init__'):
        param = DocstringDeprecated(par_args, par_descr, par_name)
        for kwarg in kwarg_list:
            assert hasattr(param, kwarg)

# Generated at 2022-06-21 11:43:35.619639
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(None, None, None)

# Generated at 2022-06-21 11:43:39.828732
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep = DocstringDeprecated(["pytest"], "is turned on", "1.3.3")
    assert dep.args == ["pytest"]
    assert dep.description == "is turned on"
    assert dep.version == "1.3.3"



# Generated at 2022-06-21 11:43:40.420659
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert True

# Generated at 2022-06-21 11:43:44.075493
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_metadata = DocstringDeprecated(["deprecated"], "TEST", "TEST2")
    assert docstring_deprecated_metadata.args == ["deprecated"]
    assert docstring_deprecated_metadata.description == "TEST"
    assert docstring_deprecated_metadata.version == "TEST2"