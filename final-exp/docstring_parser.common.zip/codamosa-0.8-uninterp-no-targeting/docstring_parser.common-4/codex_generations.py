

# Generated at 2022-06-21 11:34:19.646314
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args=["code"]
    description= "code"
    type_name= "int"
    myclass= DocstringRaises(args, description, type_name)
    args=myclass.args
    description=myclass.description
    type_name=myclass.type_name
    print(args, description, type_name)



# Generated at 2022-06-21 11:34:24.301872
# Unit test for constructor of class Docstring
def test_Docstring():
    
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-21 11:34:26.734197
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta([":param"], "parameters")
    assert obj.args == [":param"]
    assert obj.description == "parameters"

# Generated at 2022-06-21 11:34:28.119456
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["args"],
                        "description",
                        "version")

# Generated at 2022-06-21 11:34:34.034477
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["return","returns"], 'Description of return and returns', 'return', False, 'return')
    assert a.args == ["return","returns"]
    assert a.description == 'Description of return and returns'
    assert a.type_name == 'return'
    assert a.is_generator == False
    assert a.return_name == 'return'


# Generated at 2022-06-21 11:34:36.453527
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args = ["return"], description = "Example Description", type_name = "int", is_generator = True, return_name = "a")

# Generated at 2022-06-21 11:34:44.596990
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "description"
    type_name = "type_name"
    is_generator = False
    return_name = "return_name"
    docstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstringReturns.args == args
    assert docstringReturns.description == description
    assert docstringReturns.type_name == type_name
    assert docstringReturns.is_generator == is_generator
    assert docstringReturns.return_name == return_name


# Generated at 2022-06-21 11:34:49.867475
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	assert DocstringReturns(
		args=["param", "parameter", "arg", "argument", "attribute", "key", "keyword"],
		description='description',
		type_name='str',
		is_generator=False,
		return_name=None,
	).type_name == 'str'



# Generated at 2022-06-21 11:34:52.159713
# Unit test for constructor of class Docstring
def test_Docstring():
    blablabla = Docstring()
    assert blablabla


# Generated at 2022-06-21 11:34:56.482404
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ret=DocstringReturns(args=['arg1','arg2'],description=None,type_name=None,is_generator=False,return_name=None)
    assert ret.args == ['arg1','arg2']
    assert ret.type_name == None
    assert ret.is_generator == False
    assert ret.return_name == None


# Generated at 2022-06-21 11:35:05.883168
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of the class ParseError."""
    with pytest.raises(RuntimeError):
        raise ParseError


# Generated at 2022-06-21 11:35:07.756927
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("test")
    assert(a.args[0] == "test")


# Generated at 2022-06-21 11:35:09.812805
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta([0],0)
    assert dm.description == 0
    assert dm.args == [0]


# Generated at 2022-06-21 11:35:13.831270
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-21 11:35:15.382550
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string is not None


# Generated at 2022-06-21 11:35:22.021227
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  dp = DocstringParam(["arg"], "description", "arg_name", "type_name", False, "")
  assert len(dp.args) == 1
  assert dp.description == "description"
  assert dp.arg_name == "arg_name"
  assert dp.type_name == "type_name"
  assert dp.is_optional == False
  assert dp.default == ""


# Generated at 2022-06-21 11:35:29.009116
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_type = "return_type"
    return_description = "return_description"
    return_name = "return_name"
    return_args = "return_args"
    return_is_generator = True
    dr = DocstringReturns(return_args, return_description, return_type, return_is_generator, return_name)
    assert (dr.description == return_description)
    assert (dr.type_name == return_type)
    assert (dr.return_name == return_name)
    assert (dr.is_generator == return_is_generator)


# Generated at 2022-06-21 11:35:31.996158
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta( ['param'], 'description')
    assert dm.args == ['param']
    assert dm.description == 'description'



# Generated at 2022-06-21 11:35:34.274558
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated([":deprecated"], "description", "1.0")
    assert(d.version == "1.0")
    return


# Generated at 2022-06-21 11:35:42.107864
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False    
    assert d.meta == []
    assert isinstance(d.params, list)
    assert isinstance(d.raises, list)
    assert isinstance(d.returns, None)
    assert isinstance(d.deprecation, None)

# Generated at 2022-06-21 11:35:52.015427
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring"""
    x = Docstring()
    assert x.short_description == None
    assert x.long_description == None
    assert x.blank_after_short_description == False
    assert x.blank_after_long_description == False
    assert x.meta == []


# Generated at 2022-06-21 11:35:58.561740
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_args = [""]
    test_description = None
    test_type_name = None

    test_return = DocstringRaises(test_args, test_description, test_type_name)

    assert test_return.args == test_args
    assert test_return.description == test_description
    assert test_return.type_name == test_type_name

# Generated at 2022-06-21 11:36:01.429862
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=['raises'], description='valueError', arg_name='arg', type_name='type', is_optional=True, default='default')


# Generated at 2022-06-21 11:36:06.946183
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns([], None, None, True)
    assert doc.type_name == None
    doc = DocstringReturns(["foo"], "f", "bar", True)
    assert doc.args == ["foo"]
    assert doc.return_name == None
    doc = DocstringReturns(["foo"], "f", "bar", True, "foo")
    assert doc.return_name == "foo"

# Generated at 2022-06-21 11:36:13.070629
# Unit test for constructor of class Docstring
def test_Docstring():
    s = Docstring()
    assert s.short_description == None
    assert s.long_description == None
    assert s.blank_after_short_description == False
    assert s.blank_after_long_description == False
    assert s.meta == []
    assert s.params == []
    assert s.raises == []
    assert s.returns == None
    assert s.deprecation == None

# Generated at 2022-06-21 11:36:16.926218
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=["param", "arg", "argument", "attribute", "key"],
                   description="description",
                   arg_name="arg",
                   type_name="int",
                   is_optional=True,
                   default="10")
test_DocstringParam()



# Generated at 2022-06-21 11:36:22.512896
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_meta = DocstringDeprecated(["deprecated"], "deprecated description", "1.0.0")
    assert "1.0.0" == docstring_meta.version
    assert "deprecated description" == docstring_meta.description


# Generated at 2022-06-21 11:36:24.184338
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass
    else:
        raise AssertionError("Should have raised ParseError")



# Generated at 2022-06-21 11:36:28.783060
# Unit test for constructor of class Docstring
def test_Docstring():
    """ test Docstring() constructor"""
    test_docstring = Docstring()
    assert test_docstring.short_description == None
    assert test_docstring.long_description == None
    assert test_docstring.blank_after_short_description == False
    assert test_docstring.blank_after_long_description == False
    assert test_docstring.meta == []

# Generated at 2022-06-21 11:36:33.585428
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(args=["param"], description="description", type_name="type_name")
    assert docstring.args == ["param"]
    assert docstring.description == "description"
    assert docstring.type_name == "type_name"


# Generated at 2022-06-21 11:36:42.261784
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['param', 'arg', 'attribute'], 'returns', 'int')
    
    

# Generated at 2022-06-21 11:36:50.384103
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test the contructor for class DocstringDeprecated"""
    test_Deprecated1 = DocstringDeprecated(["version: 0.0.0"], "description", "version: 0.0.0")
    assert test_Deprecated1.args == ["version: 0.0.0"]
    assert test_Deprecated1.version == "version: 0.0.0"
    assert test_Deprecated1.description == "description"


# Generated at 2022-06-21 11:36:53.209452
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError.__module__ == '__main__'
    assert ParseError.__name__ == 'ParseError'



# Generated at 2022-06-21 11:36:57.485459
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param", "arg1"], "description of argument 1", "arg1", None, None, None)
    dp2 = DocstringParam(["parameter", "arg2"], "description of argument 2", "arg2", None, None, None)



# Generated at 2022-06-21 11:37:03.554776
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.params == []
    assert docstring.deprecation == None
    assert docstring.long_description == None
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.short_description == None


# Generated at 2022-06-21 11:37:10.765045
# Unit test for constructor of class Docstring
def test_Docstring():
    doctring = Docstring()
    doctring.short_description = 1
    doctring.long_description = 2
    doctring.blank_after_short_description = 3
    doctring.blank_after_long_description = 4
    doctring.meta = [1, 2, 3, 4]

    assert doctring.short_description == 1
    assert doctring.long_description == 2
    assert doctring.blank_after_short_description == 3
    assert doctring.blank_after_long_description == 4
    assert doctring.meta == [1, 2, 3, 4]



# Generated at 2022-06-21 11:37:14.173117
# Unit test for constructor of class ParseError
def test_ParseError():
    '''
    Test for constructor of class ParseError
    '''
    with pytest.raises(RuntimeError):
        raise ParseError("Error!")



# Generated at 2022-06-21 11:37:16.462923
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None and\
         d.long_description == None and\
         d.blank_after_short_description == False and\
         d.blank_after_long_description == False and\
         d.meta == []

# Generated at 2022-06-21 11:37:18.725683
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("hello")
    assert e.args[0] == "hello"
    assert str(e) == "hello"


# Generated at 2022-06-21 11:37:24.045049
# Unit test for constructor of class Docstring
def test_Docstring():
    from pynguin.utils.parser.parser import Docstring
    doc = Docstring()
    assert(doc.short_description is None)
    assert(doc.long_description is None)
    assert(doc.blank_after_short_description is False)
    assert(doc.blank_after_long_description is False)
    assert(len(doc.meta) == 0)
    assert(len(doc.params) == 0)
    assert(len(doc.raises) == 0)
    assert(doc.returns is None)
    assert(doc.deprecation is None)


# Generated at 2022-06-21 11:37:40.686224
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from mfixgui.tools.pyqt.python3 import Docstring

    #create an object of class DocstringMeta
    args = ['abc', 'xyz']
    description = 'DocstringMeta:Symbolizes lines in form of'
    my_object = Docstring(args, description)
    # test_DocstringMeta(args, description)
    # assert (my_object.args == ['abc', 'xyz'])
    assert (my_object.description == 'DocstringMeta:Symbolizes lines in form of')
    # assert (my_object.description == 'DocstringMeta:Symbolizes lines in form of')


# Generated at 2022-06-21 11:37:47.231953
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of class DocstringParam."""
    assert DocstringParam(["param", "arg"],
                          "description",
                          "arg_name",
                          "type_name",
                          True,
                          "default")
    assert DocstringParam(["parameter", "argument"],
                          "description",
                          "argument_name",
                          "type_name",
                          True,
                          "default")
    assert DocstringParam(["arg", "keyword"],
                          "description",
                          "arg_name",
                          "type_name",
                          True,
                          "default")


# Generated at 2022-06-21 11:37:49.772730
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        return True
    return False


# Generated at 2022-06-21 11:37:50.815368
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
  assert 1 == 1


# Generated at 2022-06-21 11:37:53.028567
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["param", "X"], "foobar", "v1.0") is not None


# Generated at 2022-06-21 11:37:55.518734
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)
    assert ParseError.__name__ == 'ParseError'


# Generated at 2022-06-21 11:37:57.649507
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([1,2,3,"arg",4], "description")
    b = "DocstringMeta(args=[1, 2, 3, 'arg', 4], description='description')"
    assert str(a) == b

# Generated at 2022-06-21 11:37:59.512701
# Unit test for constructor of class ParseError
def test_ParseError():
    assert(ParseError("Something went wrong").args[0] == "Something went wrong")


# Generated at 2022-06-21 11:38:02.858930
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"
    else:
        raise AssertionError("Should not be reached")


# Generated at 2022-06-21 11:38:04.394849
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "", "", "", "", "")


# Generated at 2022-06-21 11:38:23.532707
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Tests for _DocstringReturns."""
    args = ['arg_name']
    description = 'dummy'
    type_name = 'dummy'
    is_generator = 'dummy'
    return_name = 'dummy'
    a = DocstringReturns(args, description, type_name, is_generator, return_name)
    print('ok')

if __name__ == '__main__':
    test_DocstringReturns()

# Generated at 2022-06-21 11:38:26.732368
# Unit test for constructor of class ParseError
def test_ParseError():
    """Testing constructor of class ParseError"""
    try:
        raise ParseError("Test ParseError")
    except RuntimeError:
        return
    raise AssertionError("Constructor of class ParseError was not initialised correctly")


# Generated at 2022-06-21 11:38:33.199491
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	"""Use parameters of the __init__ method to instantiate a new class DocstringParam
		
		with the name of the class, class DocstringParam, we can instantiate a new object from
		the class. We use this object to veify if the ID (and the value) of the object is equal
		to the ID of a given parameter. This parameter is passed to the __init__ method which
		is used to initialize the object. We then verify if the IDs of the object and the parameter
		are equal. If the IDs are equal we can say the object is successfully constructed. """
	
	docstring = Docstring()
	print(id(docstring))
	print(id(docstring.params))

# Generated at 2022-06-21 11:38:34.073220
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass

# Generated at 2022-06-21 11:38:39.108104
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = Docstring()

    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None


# Generated at 2022-06-21 11:38:45.349708
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = [':param', 'parameter']
    b = ":raises ValueError: if something happens"
    c = None
    obj = DocstringRaises(a, b, c)
    assert obj.args==[':param', 'parameter']
    assert obj.description== "if something happens"
    assert obj.type_name==None


# Generated at 2022-06-21 11:38:50.614650
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["args"]
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-21 11:38:52.713987
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """ Test the constructor of DocstringDeprecated """
    assert DocstringDeprecated(["param"], "description", "version").description == "description"

# Generated at 2022-06-21 11:38:58.995492
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "Description", "arg_name", "type_name", False, "default")
    assert(param.args == ["param"])
    assert(param.description == "Description")
    assert(param.arg_name == "arg_name")
    assert(param.type_name == "type_name")
    assert(param.is_optional == False)
    assert(param.default == "default")


# Generated at 2022-06-21 11:39:07.734118
# Unit test for constructor of class Docstring
def test_Docstring():
    '''Create instance of Docstring object with dummy data'''
    a = Docstring()
    a.short_description = "A short description"
    a.long_description = "A long description"
    a.blank_after_short_description = True
    a.blank_after_long_description = False
    a.meta = [1,2,3]

    assert a.short_description == "A short description"
    assert a.long_description == "A long description"
    assert a.blank_after_short_description == True
    assert a.blank_after_long_description == False
    assert a.meta == [1,2,3]

# Generated at 2022-06-21 11:39:45.883446
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    assert ParseError("Test")


# Generated at 2022-06-21 11:39:47.641472
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert isinstance(DocstringRaises(['raises'], '', ''), DocstringRaises)


# Generated at 2022-06-21 11:39:54.982116
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(list(), "lorem ipsum", "parameter_name", "String", True, "default value")
    assert docstring_param.args == list()
    assert docstring_param.description == "lorem ipsum"
    assert docstring_param.arg_name == "parameter_name"
    assert docstring_param.type_name == "String"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default value"


# Generated at 2022-06-21 11:39:57.188614
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("This is a error.")


# Generated at 2022-06-21 11:40:00.641358
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['deprecated'], 'no longer supported', '0.0.1')
    print(a.args)
    print(a.description)
    print(a.version)

# Generated at 2022-06-21 11:40:05.110994
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []

# Generated at 2022-06-21 11:40:08.301785
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    x = DocstringMeta(['a', 'b', 'c'], 'd')
    assert x.args == ['a', 'b', 'c']
    assert x.description == 'd'
    

# Generated at 2022-06-21 11:40:17.125280
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    import unittest
    from unittest.mock import patch
    class TestDocstringParam(unittest.TestCase):
        def test_DocstringParam_args(self):
            args = ['arg','description']
            subject = DocstringParam(args, none, 'arg_name','type_name', 'is_optional', 'default')
            self.assertEqual(subject.args, args)
        def test_DocstringParam_description(self):
            description = 'description'
            subject = DocstringParam(none, description, 'arg_name','type_name', 'is_optional', 'default')
            self.assertEqual(subject.description, description)
        def test_DocstringParam_arg_name(self):
            arg_name = 'arg_name'

# Generated at 2022-06-21 11:40:29.794326
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_string = """This function does a lot of useful things.

Args:
    param1: This is the first param.
    param2: This is a second param.

Returns:
    This is a description of what is returned.
    This can be multiple lines.

    The return type is not specified.
"""
    meta = DocstringMeta(args=["param1", "param2"], description="This is the first param")
    assert(meta.args[0] == "param1")
    assert(meta.args[1] == "param2")
    assert(meta.description == "This is the first param")
    meta = DocstringMeta(args=["param1", "param2"], description="This is a second param")
    assert(meta.args[0] == "param1")

# Generated at 2022-06-21 11:40:33.497929
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_args = ["Test of args"]
    test_description = "Test of description"
    test_type_name = "Test of type_name"
    test = DocstringRaises(test_args, test_description, test_type_name)
    assert test.args == test_args
    assert test.description == test_description
    assert test.type_name == test_type_name


# Generated at 2022-06-21 11:42:02.477981
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param']
    description = 'This is a description'
    type_name = 'int'
    return DocstringRaises(args, description, type_name)

# Generated at 2022-06-21 11:42:11.342757
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "lorem ipsum"
    arg_name = "arg"
    type_name = "Argument"
    is_optional = True
    default = "lorem"
    item = DocstringParam(args,description,arg_name,type_name,is_optional,default)
    print(item.args)
    print(item.description)
    print(item.arg_name)
    print(item.type_name)
    print(item.is_optional)
    print(item.default)

# Generated at 2022-06-21 11:42:13.294297
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    DocstringMeta(args, description)


# Generated at 2022-06-21 11:42:18.130838
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """test for the DocstringReturns class"""
    args = ['param', 'argument', 'type_name', 'is_optional', 'default']
    description = "DocstringMeta symbolizing :param metadata."
    assert DocstringReturns(args, description, 'type_name', 'generator', 'return_name') == DocstringReturns(args, description, 'type_name', 'generator', 'return_name')
    assert DocstringReturns(args, description, 'type_name', 'generator', 'return_name') != DocstringReturns(args, 'DocstringMeta symbolizing :raises metadata.', 'type_name', 'generator', 'return_name')


# Generated at 2022-06-21 11:42:24.265880
# Unit test for constructor of class Docstring
def test_Docstring():
    new_Docstring = Docstring()
    assert new_Docstring.short_description is None
    assert new_Docstring.long_description is None
    assert new_Docstring.blank_after_short_description is False
    assert new_Docstring.blank_after_long_description is False
    assert new_Docstring.meta == []



# Generated at 2022-06-21 11:42:27.224945
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	doc = DocstringReturns(["returns"], "Test", "test", False)
	assert doc.description == 'Test'
	assert doc.type_name == 'test'
	assert doc.is_generator == False

# Generated at 2022-06-21 11:42:29.843632
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    testDocstringReturns = DocstringReturns(["type_name"], "test_description", "str")

# Generated at 2022-06-21 11:42:30.798098
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()


# Generated at 2022-06-21 11:42:34.006255
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["arg:[type]", "description"], "description")
    assert a.args[0] == "arg:[type]"
    b = DocstringMeta("args", "description")
    assert b.description == "description"

# Generated at 2022-06-21 11:42:36.509946
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test')
    except Exception as exc:
        if exc.args[0] != 'test':
            raise 
