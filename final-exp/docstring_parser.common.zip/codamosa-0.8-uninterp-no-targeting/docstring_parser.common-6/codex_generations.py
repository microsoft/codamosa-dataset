

# Generated at 2022-06-21 11:34:19.591207
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a_obj = DocstringDeprecated(args=["test"],description="test",version="test")
    assert a_obj.args==["test"]
    assert a_obj.description=="test"
    assert a_obj.version=="test"

# Generated at 2022-06-21 11:34:21.223102
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    parse_error = ParseError()


# Generated at 2022-06-21 11:34:25.645983
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """DocstringMeta test."""
    a = ['a', 'b', 'c']
    b = 'good'
    test_dict = DocstringMeta(a, b)
    assert test_dict.args == a
    assert test_dict.description == b


# Generated at 2022-06-21 11:34:30.434479
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg", "param", "argument", "parameter"]
    description = "description"
    doc = DocstringMeta(args, description)
    assert doc.args == [
        "arg",
        "param",
        "argument",
        "parameter"
    ]
    assert doc.description == "description"


# Generated at 2022-06-21 11:34:36.366326
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    t = DocstringParam(["param", "type"], "description", "arg_name", "type_name", True, "default")
    assert t.args == ["param", "type"]
    assert t.description == "description"
    assert t.arg_name == "arg_name"
    assert t.type_name == "type_name"
    assert t.is_optional == True
    assert t.default == "default"


# Generated at 2022-06-21 11:34:37.621494
# Unit test for constructor of class ParseError
def test_ParseError():
    assert type(ParseError("fizzbuzz")) == ParseError

# Generated at 2022-06-21 11:34:39.297183
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert(DocstringParam("args", "description", "arg_name", "type_name", True, "default" ) != None)


# Generated at 2022-06-21 11:34:44.800356
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['raises', 'ValueError'], 'if ...', 'ValueError')
    assert docstring_raises.args == ['raises', 'ValueError']
    assert docstring_raises.description == 'if ...'
    assert docstring_raises.type_name == 'ValueError'



# Generated at 2022-06-21 11:34:49.668548
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r:DocstringReturns = DocstringReturns([], "docstr_returns", "str", False)
    assert r.type_name == "str"
    assert r.foreach is None
    assert r.description == "docstr_returns"
    assert r.return_name is None


# Generated at 2022-06-21 11:34:53.783863
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["asd"]
    description = "some description"
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta
    assert docstringMeta.args == args
    assert docstringMeta.description == description

# Generated at 2022-06-21 11:34:59.876822
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a=DocstringRaises(['param','key'], 'default', 'int')
    print(a.args)
    print(a.description)
    print(a.type_name)

# Generated at 2022-06-21 11:35:05.238748
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print('DocstringMeta test')
    doc_meta = DocstringMeta(['param'], 'Test description')
    assert doc_meta.args == ['param']
    assert doc_meta.description == 'Test description'
    print('DocstringMeta test passed')


# Generated at 2022-06-21 11:35:09.451820
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raise_example = DocstringRaises(["raises"], None, Exception)
    # check that input parameters were stored correctly in the instance of DocstringRaises
    assert raise_example.args == ["raises"]
    assert raise_example.type_name == Exception
    assert raise_example.description == None

# Generated at 2022-06-21 11:35:11.163399
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Parse error")
    except ParseError:
        pass

# Generated at 2022-06-21 11:35:16.978728
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    # Unit test for property params of class Docstring
    def test_property_params():
        docstring = Docstring()
        docstring.meta = [
            DocstringParam(["param"], "", "", None, None, None),
            DocstringRaises(["raises"], "", None),
            DocstringRaises(["raises"], "", None),
        ]
        assert docstring.params == [
            DocstringParam(["param"], "", "", None, None, None)
        ]

    # Unit test for property raises of class Doc

# Generated at 2022-06-21 11:35:21.155610
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pas = DocstringMeta(['args'], 'description')
    docstring_meta = DocstringMeta
    assert isinstance(pas,docstring_meta)
    assert isinstance(pas.description, str)
    assert isinstance(pas.args, list)


# Generated at 2022-06-21 11:35:23.395847
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Bad!")
    assert str(err) == "Bad!"


# Generated at 2022-06-21 11:35:26.712942
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    test_DocstringReturns = DocstringReturns(["args"], "description", "type_name", False)
    assert(test_DocstringReturns.type_name == "type_name")


# Generated at 2022-06-21 11:35:34.311413
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for DocstringDeprecated constructor."""
    # GIVEN an args, description and version
    args = [" :deprecated", "version"]
    description = "description"
    version = 1.0

    # WHEN DocstringDeprecated is initialized
    docstring_deprecated = DocstringDeprecated(args, description, version)

    # THEN value should be correct
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version



# Generated at 2022-06-21 11:35:39.916857
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    type_name = 'str'
    description = 'test description'
    args = ['raises']

    test = DocstringRaises(args, description, type_name)
    assert test.type_name == type_name
    assert test.description == description
    assert test.args == args


# Generated at 2022-06-21 11:35:46.862096
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a=DocstringDeprecated(["param"], "description", "version")
    assert(a.args[0] == "param")
    assert(a.description == "description")
    assert(a.version == "version")


# Generated at 2022-06-21 11:35:49.108423
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['param'], 'description')


# Generated at 2022-06-21 11:35:51.150082
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        print('ParseError raised')


# Generated at 2022-06-21 11:35:54.043745
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("This is a parse error")
    assert str(error) == "ParseError: This is a parse error"



# Generated at 2022-06-21 11:35:58.781699
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = ":raises PqrError: In case of error"
    doc = doc.split(':')
    args = [doc[1].strip(), doc[2].strip()]
    return DocstringRaises(args, *args)



# Generated at 2022-06-21 11:35:59.586895
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert True



# Generated at 2022-06-21 11:36:01.105241
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(Exception) as excinfo:
        ParseError()

# Generated at 2022-06-21 11:36:02.222989
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert True



# Generated at 2022-06-21 11:36:05.319539
# Unit test for constructor of class Docstring
def test_Docstring():
    # Create a Docstring object
    docstring = Docstring()
    # Check whether the description is None
    assert docstring.short_description is None
    assert docstring.long_description is None
    # Check whether the empty lists are initialized
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-21 11:36:09.032654
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "Description"
    version = "version"
    obj = DocstringDeprecated(args, description, version)
    assert obj.args == ["deprecated"]
    assert obj.description == "Description"
    assert obj.version is "version"

# Generated at 2022-06-21 11:36:16.190497
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'Raises']
    description = 'This is a description of the raises'
    type_name = 'ValueError'
    dr = DocstringRaises(args, description, type_name)
    assert dr.args == args
    assert dr.description == description
    assert dr.type_name == type_name


# Generated at 2022-06-21 11:36:17.256905
# Unit test for constructor of class ParseError
def test_ParseError():
    assert True

# Generated at 2022-06-21 11:36:19.394638
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([':deprecated', ':deprecate'], "dummy description", "dummy version")

# Generated at 2022-06-21 11:36:25.806487
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    my_DocstringDeprecated = DocstringDeprecated(args=['abc', 'abc2'], description='hello', version='1.2.3')
    assert my_DocstringDeprecated.args == ['abc', 'abc2']
    assert my_DocstringDeprecated.description == 'hello'
    assert my_DocstringDeprecated.version == '1.2.3'



# Generated at 2022-06-21 11:36:29.302635
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert len(a.meta) == 0


# Generated at 2022-06-21 11:36:40.088189
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam"""

    args = ["a", "b", "c"]
    description = "Test description"
    arg_name = "Test"
    type_name = "int"
    is_optional = True
    default = 3

    myDocstringParam = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    myDocstringParam.args == args
    myDocstringParam.description == description
    myDocstringParam.arg_name == arg_name
    myDocstringParam.type_name == type_name
    myDocstringParam.is_optional == is_optional
    myDocstringParam.default == default



# Generated at 2022-06-21 11:36:42.492916
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(['param'], 'doc')
    assert doc_meta.args == ['param']
    assert doc_meta.description == 'doc'


# Generated at 2022-06-21 11:36:46.106382
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        temp = DocstringRaises(['a', 'b'], 'hello', 'hello')
        return True
    except:
        return False

# Generated at 2022-06-21 11:36:48.903765
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    _ = DocstringMeta(['a', 'b', 'c'], 'd')


# Generated at 2022-06-21 11:36:53.208713
# Unit test for constructor of class ParseError
def test_ParseError():
    arg = ''
    msg = 'This is a test'
    err = ParseError(arg, msg)
    assert(err.args[0] is arg)
    assert(err.args[1] == msg)
    

# Generated at 2022-06-21 11:37:08.467668
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    Unit test for constructor of class Docstring
    """
    print("START: test_Docstring")
    my_docstring = Docstring()
    assert my_docstring.short_description == None
    assert my_docstring.long_description == None
    assert my_docstring.blank_after_short_description == False
    assert my_docstring.blank_after_long_description == False
    assert my_docstring.meta == []
    print("FINISH: test_Docstring")


# Generated at 2022-06-21 11:37:11.921996
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = None
    type_name = None
    is_generator = False
    return_name = None
    doc_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    return doc_returns


# Generated at 2022-06-21 11:37:19.198077
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """verify the python object."""
    args = [":returns:", "str", "--", "the", "return", "value"]
    description = "a string"
    type_name = "str"
    is_generator = False
    return_name = None
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)    
    assert returns.description is description
    assert returns.type_name is type_name
    assert returns.is_generator == is_generator
    assert returns.return_name is return_name    


# Generated at 2022-06-21 11:37:22.690125
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the ParseError class"""
    
    error1 = ParseError("this is an error")
    error2 = ParseError(error1, "this is another error")

    assert(isinstance(error1, RuntimeError))
    assert(isinstance(error2, RuntimeError))
    assert(isinstance(error2, ParseError))

test_ParseError()



# Generated at 2022-06-21 11:37:25.211428
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta("test", "test")



# Generated at 2022-06-21 11:37:26.836665
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert(docstring!=None)


# Generated at 2022-06-21 11:37:32.564718
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-21 11:37:34.437320
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], None, None, False)


# Generated at 2022-06-21 11:37:39.131375
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Constructor for the DocstringMeta data class."""
    args = ["param"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == ["param"]
    assert docstring_meta.description == "description"


# Generated at 2022-06-21 11:37:42.226136
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    type_name = 'It is a test'
    description = ''
    raises = DocstringRaises(args, description, type_name)
    assert raises.type_name == type_name
    assert raises.args == args
    assert raises.description == description

# Generated at 2022-06-21 11:38:01.609803
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "this is a test.")
    assert d.__class__ == DocstringMeta
    assert d.args == ["param"]
    assert d.description == "this is a test."


# Generated at 2022-06-21 11:38:03.611094
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["return","returns"],None,None,False)


# Generated at 2022-06-21 11:38:13.105609
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([''], None, None)
    DocstringRaises([''], 1, None)
    DocstringRaises([''], 'string', None)
    DocstringRaises(['', '', '', ''], None, None)
    DocstringRaises(['', '', '', ''], 1, None)
    DocstringRaises(['', '', '', ''], 'string', None)
    DocstringRaises(['', '', '', ''], None, 'string')
    DocstringRaises(['', '', '', ''], 1, 'string')
    DocstringRaises(['', '', '', ''], 'string', 'string')


# Generated at 2022-06-21 11:38:16.535272
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(args = ['ar'], description = 'desc', type_name = 'val')
    assert hasattr(x, 'description')
    assert hasattr(x, 'args')
    assert hasattr(x, 'type_name')


# Generated at 2022-06-21 11:38:19.614234
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    myItem = DocstringReturns([], None, None, False)
    assert(myItem.args == [] and myItem.type_name == None and myItem.is_generator == False)


# Generated at 2022-06-21 11:38:21.237604
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["deprecated"], "description", "version")

# Generated at 2022-06-21 11:38:21.933270
# Unit test for constructor of class ParseError
def test_ParseError():
    assert True

# Generated at 2022-06-21 11:38:26.000981
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(["description"], "description", "arg", "type", True, None)
    assert doc.description == "description"
    assert doc.arg_name == "arg"
    assert doc.type_name == "type"
    assert doc.is_optional == True
    assert doc.default == None
    assert doc.args == ["description"]

# Generated at 2022-06-21 11:38:27.064182
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of class ParseError."""
    obj = ParseError()



# Generated at 2022-06-21 11:38:28.979977
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('test', 'error')
    assert err == 'error'


# Generated at 2022-06-21 11:39:06.669090
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    msg = DocstringDeprecated(['deprecated', 'since'], 'will be removed in next release', '3.0')
    assert isinstance(msg, DocstringDeprecated)
    assert msg.description == 'will be removed in next release'
    assert msg.version == '3.0'


# Generated at 2022-06-21 11:39:08.162960
# Unit test for constructor of class Docstring
def test_Docstring():
    p = Docstring()
    assert p.short_description == None
    assert p.long_description == None



# Generated at 2022-06-21 11:39:10.555703
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated([], "description", "1.6.1")
    assert (docstring.args == []) and (docstring.description == "description")


# Generated at 2022-06-21 11:39:16.209407
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    # Test docstring.short_description
    assert docstring.short_description is None
    # Test docstring.long_description
    assert docstring.long_description is None
    # Test docstring.blank_after_long_description
    assert docstring.blank_after_long_description is False
    # Test docstring.blank_after_short_description
    assert docstring.blank_after_short_description is False
    # Test docstring.meta
    assert docstring.meta == []



# Generated at 2022-06-21 11:39:17.934074
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([""], "", "")

# Generated at 2022-06-21 11:39:19.438133
# Unit test for constructor of class ParseError
def test_ParseError():
    print("testing ParseError...")
    assert ParseError("test")
    print("passed")


# Generated at 2022-06-21 11:39:30.536592
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg', 'arg1', 'arg2']
    description = 'this is a description'
    type_name = 'int'
    is_generator = True
    d1 = DocstringReturns(args, description, type_name, is_generator)
    d2 = DocstringReturns(args, description, None, is_generator)
    d3 = DocstringReturns(args, description, type_name, False)
    d4 = DocstringReturns(args, description, None, False)
    d5 = DocstringReturns(args, None, None, False)
    assert d1.args == args
    assert d1.description == description
    assert d1.type_name == type_name
    assert d1.is_generator == is_generator
    assert d1.return_name == None

# Generated at 2022-06-21 11:39:41.589540
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert isinstance(DocstringParam(['a'], 'b', 'c', 'd', True, 'f'), DocstringParam) == True
    assert isinstance(DocstringParam(['a', 'b'], 'c', 'd', 'e', True, 'g'), DocstringParam) == True
    assert isinstance(DocstringParam(['a'], 'b', 'c', None, True, 'f'), DocstringParam) == True
    assert isinstance(DocstringParam(['a'], 'b', 'c', [], True, 'f'), DocstringParam) == True
    assert isinstance(DocstringParam(['a'], 'b', 'c', {}, True, 'f'), DocstringParam) == True

# Generated at 2022-06-21 11:39:47.805167
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print ("Testing constructor of class DocstringDeprecated")
    doc = DocstringDeprecated(["deprecated"], "This class is deprecated", "1.1")
    assert doc.args == ["deprecated"], "Incorrect args"
    assert doc.description == "This class is deprecated", "Incorrect description"
    assert doc.version == "1.1", "Incorrect version"

test_DocstringDeprecated()



# Generated at 2022-06-21 11:39:52.827325
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['raises', 'ValueError'], 'if something happens', 'ValueError')
    assert type(a.args[0]) is str, 'arg[0] is not string'
    assert type(a.description) is str, 'description is not string'
    assert type(a.type_name) is str, 'type_name is not string'



# Generated at 2022-06-21 11:41:06.251238
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(None, None, None, None)

# Generated at 2022-06-21 11:41:08.826534
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    args = []
    description = None
    version = None
    docstringDeprecated = DocstringDeprecated(args, description, version)

    args = [""]
    description = ""
    version = ""
    docstringDeprecated = DocstringDeprecated(args, description, version)


# Generated at 2022-06-21 11:41:10.821023
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('message')
    assert err.args[0] == 'message'



# Generated at 2022-06-21 11:41:19.319350
# Unit test for constructor of class DocstringParam
def test_DocstringParam():

    dp = DocstringParam([], "description", "arg_name", "type_name", False, "default")
    assert len(dp.args) == 0
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == False
    assert dp.default == "default"

    dp = DocstringParam(["arg1", "arg2"], "description", "arg_name", "type_name", False, "default")
    assert len(dp.args) == 2
    assert dp.args[0] == "arg1"
    assert dp.args[1] == "arg2"
    assert dp.description == "description"

# Generated at 2022-06-21 11:41:28.991510
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['return', ':returns:', 'returns']
    description = 'The number of times the bar'
    return_name = 'bar'
    type_name = 'int'
    is_generator = True
    return_ = DocstringReturns(args, description, type_name, is_generator, return_name)
    
    assert return_.args == ['return', ':returns:', 'returns']
    assert return_.description == 'The number of times the bar'
    assert return_.type_name == 'int'
    assert return_.is_generator == True
    assert return_.return_name == 'bar'


# Generated at 2022-06-21 11:41:32.797283
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep = DocstringDeprecated(['deprecated'], 'deprecated', '1.0.0')
    assert dep.args == ['deprecated']
    assert dep.description == 'deprecated'
    assert dep.version == '1.0.0'


# Generated at 2022-06-21 11:41:38.506570
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # unit test for constructor
    d = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", True, "default")

    assert d.args == ["param", "arg"]
    assert d.description == "description"
    assert d.arg_name == "arg_name"
    assert d.type_name == "type_name"
    assert d.is_optional == True
    assert d.default == "default"


# Generated at 2022-06-21 11:41:42.057672
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(['arg'], 'description', 'version')
    assert s.args == ['arg']
    assert s.description == 'description'
    assert s.version == 'version'

l_2 = [3, 4, 5]


# Generated at 2022-06-21 11:41:43.787712
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        DocstringDeprecated([], None, None)
    except Exception as e:
        print(e.args)

# Generated at 2022-06-21 11:41:46.365346
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["hello"], "world")
    print(meta.args)
    print(meta.description)

