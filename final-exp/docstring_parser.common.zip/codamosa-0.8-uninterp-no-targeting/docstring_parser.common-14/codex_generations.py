

# Generated at 2022-06-21 11:34:21.189301
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'int'
    is_optional = True
    default = ''
    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert param is not None


# Generated at 2022-06-21 11:34:28.024803
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    "Function to test DocstringParam constructor"
    obj = DocstringParam(args=['param'],description="""description""",arg_name="""arg_name""",type_name=None,is_optional=True,default="""default""")
    print(obj.args)
    print(obj.description)
    print(obj.arg_name)
    print(obj.type_name)
    print(obj.is_optional)
    print(obj.default)


# Generated at 2022-06-21 11:34:32.316355
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    params = []
    docstringRaises = DocstringRaises(params, None, None)
    assert (docstringRaises.args == [])
    assert (docstringRaises.description == None)
    assert (docstringRaises.type_name == None)


# Generated at 2022-06-21 11:34:34.316191
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    t = DocstringReturns()
    assert t.is_generator == False, "test_DocstringReturns: is_generator == False"
    assert t.return_name == None, "test_DocstringReturns: return_name == None"

# Generated at 2022-06-21 11:34:35.633080
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	"""Unit test for constructor of class DocstringReturns"""
	assert DocstringReturns([], '', '', True) == None

# Generated at 2022-06-21 11:34:36.896142
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert True


# Generated at 2022-06-21 11:34:40.284680
# Unit test for constructor of class Docstring
def test_Docstring():
    # initialize
    string = Docstring()
    assert(string.short_description is None)
    assert(string.long_description is None)
    assert(string.blank_after_short_description is False)
    assert(string.blank_after_long_description is False)
    assert(len(string.meta) == 0)
# End of unit test

# Generated at 2022-06-21 11:34:45.365908
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert len(ds.meta) == 0


# Generated at 2022-06-21 11:34:49.820104
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['raises'], 'Hola', 'ValueError')
    assert a.args[0] == 'raises'
    assert a.description == 'Hola'
    assert a.type_name == 'ValueError'
    return True


# Generated at 2022-06-21 11:34:54.953846
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print('Unit test for constructor of class DocstringDeprecated')
    docstringDeprecated = DocstringDeprecated(["foo"], "foo", "foo")
    assert docstringDeprecated.description == "foo"
    assert docstringDeprecated.version == "foo"
    assert docstringDeprecated.args == ["foo"]


# Generated at 2022-06-21 11:35:04.992610
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():    
    test_args = ["a", "b", "c", "d"]
    test_description = 'Test'
    test = DocstringRaises(test_args, test_description, "type")
    assert test.args == test_args
    assert test.description == test_description
    assert test.type_name == "type"


# Generated at 2022-06-21 11:35:10.329778
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(
        ['deprecated', 'since'],
        None,
        '0.0.1',
    )
    if docstringDeprecated.args != ['deprecated', 'since']:
        raise AssertionError("wrong args")
    if docstringDeprecated.description is not None:
        raise AssertionError("wrong description")
    if docstringDeprecated.version != '0.0.1':
        raise AssertionError("wrong version")

test_DocstringDeprecated()


# Generated at 2022-06-21 11:35:13.567704
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg"]
    desc = "a docstring meta object"
    assert args == DocstringMeta(args, desc).args
    assert desc == DocstringMeta(args, desc).description


# Generated at 2022-06-21 11:35:18.173487
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "Hello World"
    version = "0.0.0"
    test = DocstringDeprecated(args, description, version)
    assert test.args == ["deprecated"]
    assert test.description == "Hello World"
    assert test.version == version


# Generated at 2022-06-21 11:35:20.088846
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', True, 'default')

# Generated at 2022-06-21 11:35:21.964689
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert not error.__dict__

# Generated at 2022-06-21 11:35:26.504589
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "fial", "0.0.0")
    assert d.args == ["deprecated"]
    assert d.type_name is None
    assert d.description == "fial"
    assert d.version == "0.0.0"
    assert d.is_generator is False


# Generated at 2022-06-21 11:35:32.169911
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringMeta = DocstringDeprecated(
        ['param', 'arg', 'attribute'], 'desc', 1.0)
    assert docstringMeta.args == ['param', 'arg', 'attribute']
    assert docstringMeta.description == 'desc'
    assert docstringMeta.version == 1.0



# Generated at 2022-06-21 11:35:33.827029
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("test error")
    assert err.args[0] == "test error"


# Generated at 2022-06-21 11:35:37.221769
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ":param arg: description"
    version = "1.0"
    description = "arg is a parameter"
    assert DocstringDeprecated(args, description, version)



# Generated at 2022-06-21 11:35:47.986624
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['a', 'b', 'c'], 'abc')
    assert a.args == ['a', 'b', 'c']
    assert a.description == 'abc'


# Generated at 2022-06-21 11:36:00.883027
# Unit test for constructor of class Docstring
def test_Docstring():
    # Test constructor
    docstring = Docstring()
    # Test attribute assignments
    docstring.short_description = "test"
    assert docstring.short_description == "test"
    docstring.long_description = "test1"
    assert docstring.long_description == "test1"
    docstring.blank_after_short_description = True
    assert docstring.blank_after_short_description == True
    docstring.blank_after_long_description = True
    assert docstring.blank_after_long_description == True
    docstring.meta.append("test2")
    docstring.meta.append("test3")
    assert docstring.meta == ["test2", "test3"]
    # Test property assignments
    docstring.params.append("test4")
    docstring.params.append("test5")


# Generated at 2022-06-21 11:36:06.059851
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns([':raises', 'SomeException'], "if something happens",
                         "MyException")
    assert d.args == [':raises', 'SomeException']
    assert d.description == "if something happens"
    assert d.type_name == "MyException"
    assert d.is_generator == False
    assert d.return_name == None


# Generated at 2022-06-21 11:36:09.816774
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated(): pass
    #args=["deprecated"]
    #description="Function foo has been deprecated"
    #version="0.5"
    #meta = [DocstringDeprecated(args=args, description=description, version=version)]
    #assert meta.version =="0.5"
    #assert meta.description =="Function foo has been deprecated"

# Generated at 2022-06-21 11:36:18.944144
# Unit test for constructor of class ParseError
def test_ParseError():
    from mypy_extensions import TypedDict
    class ParseErrorTD(TypedDict):
        message: str
    ParseErrorTD['__missing__'] = lambda: ParseErrorTD(message="")

    counter = 0
    for message in ["", "a", "abc"]:
        try:
            if message == "a":
                raise ParseError(message=message)
            else:
                raise ParseError()
        except ParseError as e:
            assert e.__class__.__name__ == "ParseError"
            assert ParseErrorTD(message=message) == ParseErrorTD(message=e.args[0])
            counter += 1
    assert counter == 3


# Generated at 2022-06-21 11:36:22.988303
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d1 = DocstringMeta(['param', 'description'], 'description')
    assert d1.description == 'description'
    assert d1.args == ['param', 'description']

# Generated at 2022-06-21 11:36:31.643468
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    ds.short_description = "Test short description"
    assert ds.short_description == "Test short description"
    ds.long_description = "Test long description"
    assert ds.long_description == "Test long description"
    ds.blank_after_short_description = True
    assert ds.blank_after_short_description == True
    ds.blank_after_long_description = True
    assert ds.blank_after_long_description == True
    dp = DocstringParam(["key"], "description", "arg_name", "type_name", True, "default")
    dr = DocstringRaises(["key"], "description", "type_name")
    dd = DocstringDeprecated(["key"], "description", "version")
    ds.meta.append

# Generated at 2022-06-21 11:36:40.504782
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param"]
    description = "long_description"
    type_name = "type"
    is_generator = False
    return_name = "returnName"
    
    return_doc = DocstringReturns(args,description,type_name,is_generator,return_name)
    assert return_doc.args == ["param"]
    assert return_doc.description == "long_description"
    assert return_doc.type_name == "type"
    assert return_doc.is_generator == False
    assert return_doc.return_name == "returnName"


# Generated at 2022-06-21 11:36:42.210322
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['a','b'], 'c')


# Generated at 2022-06-21 11:36:51.533353
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert isinstance(docstring, Docstring)
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:37:08.642425
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a= DocstringMeta(['a','b','c'],'abc')
    assert isinstance(a,DocstringMeta)


# Generated at 2022-06-21 11:37:15.762571
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([':returns:', 'returns'], 'hehe', 'int', False)
    assert isinstance(a, DocstringMeta)
    assert a.args == [':returns:', 'returns']
    assert a.description == 'hehe'
    assert a.type_name == 'int'
    assert a.is_generator == False
    assert a.return_name is None
    b = DocstringReturns([':returns:', 'returns'], 'hehe', 'int', False, 'b')
    assert isinstance(b, DocstringMeta)
    assert b.args == [':returns:', 'returns']
    assert b.description == 'hehe'
    assert b.type_name == 'int'
    assert b.is_generator == False
    assert b.return_

# Generated at 2022-06-21 11:37:16.456919
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  a = DocstringRaises("a", "b", "c")
  print(a)

# Generated at 2022-06-21 11:37:21.627380
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-21 11:37:23.763870
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg1"]
    description = "description"
    doc = DocstringMeta(args, description)
    assert doc.args == args
    assert doc.description == description


# Generated at 2022-06-21 11:37:27.552244
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert isinstance(test_docstring, Docstring)
    assert test_docstring.short_description == None
    assert test_docstring.long_description == None
    assert test_docstring.params == []
    assert test_docstring.raises == []
    assert test_docstring.returns == None
    assert test_docstring.deprecation == None



# Generated at 2022-06-21 11:37:39.086927
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises"""
    # T.Optional[str]
    assert isinstance(DocstringRaises([":raises"], ""), DocstringRaises)
    assert isinstance(DocstringRaises([":raises"], None), DocstringRaises)
    assert isinstance(DocstringRaises([":raises"], "ValueError"), DocstringRaises)
    assert isinstance(DocstringRaises([":raises"], "if something happens"), DocstringRaises)
    assert isinstance(DocstringRaises([":raises"], "Raises when something happens"), DocstringRaises)
    assert isinstance(DocstringRaises([":raises"], "Raise when something happens"), DocstringRaises)
    assert isinstance(DocstringRaises([":raises"], "If something happens"), DocstringRaises)
    assert isinstance

# Generated at 2022-06-21 11:37:40.304658
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()


# Generated at 2022-06-21 11:37:43.261722
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["a","b"], "Hello")
    assert docstring_meta.args == ["a","b"]
    assert docstring_meta.description == "Hello"


# Generated at 2022-06-21 11:37:44.428790
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([],[]) == DocstringMeta([],[])


# Generated at 2022-06-21 11:38:18.875380
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(["param", "arg"], "Very cool description")
    assert doc_meta.args == ["param", "arg"]
    assert doc_meta.description == "Very cool description"


# Generated at 2022-06-21 11:38:23.669528
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param=DocstringParam(['param'], 'description', 'arg', 'type', 'True', 'default')
    assert docstring_param.args==['param']
    assert docstring_param.description=='description'
    assert docstring_param.arg_name=='arg'
    assert docstring_param.type_name=='type'
    assert docstring_param.is_optional=='True'
    assert docstring_param.default=='default'


# Generated at 2022-06-21 11:38:25.235564
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass


# Generated at 2022-06-21 11:38:28.360056
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	type_name = 'int'
	args = ['arg']
	description = 'desc'
	result = DocstringRaises(args, description, type_name)
	assert type(result) == DocstringRaises
	assert type(result.type_name) == str
	assert result.type_name == type_name
	assert type(result.args) == list
	assert result.args == args
	assert result.description == description


# Generated at 2022-06-21 11:38:33.417165
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description is False
    assert Docstring().blank_after_long_description is False
    assert Docstring().meta == []


# Generated at 2022-06-21 11:38:37.200464
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=['param'], description=None, arg_name="self", type_name=None, is_optional=None, default=None)
    assert(docstring_param.args == ['param'])
    assert(docstring_param.description == None)
    assert(docstring_param.arg_name == 'self')
    assert(docstring_param.type_name == None)
    assert(docstring_param.is_optional == None)
    assert(docstring_param.default == None)

# Generated at 2022-06-21 11:38:48.832000
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Sample data to be parsed
    X = ":param arg_name"
    Y = ":param arg_name: description"
    Z = ":param arg_name: type_name: description"
    A = ":param arg_name: arg_name_2"

    x = parse_docstring_meta(X)
    y = parse_docstring_meta(Y)
    z = parse_docstring_meta(Z)
    a = parse_docstring_meta(A)

    assert isinstance(x, DocstringParam)
    assert x.args[0] == "arg_name"
    assert x.description is None
    assert x.arg_name is None
    assert x.type_name is None
    assert x.is_optional is False

    assert isinstance(y, DocstringMeta)

# Generated at 2022-06-21 11:38:51.254635
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("Should have raised exception, but not.")

if __name__ == '__main__':
    test_ParseError()

# Generated at 2022-06-21 11:38:54.249514
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    >>> a = Docstring()
    >>> a.short_description
    >>> a.long_description
    >>> a.blank_after_short_description 
    False
    >>> a.blank_after_long_description
    False
    >>> a.meta
    []
    """


# Generated at 2022-06-21 11:38:55.288328
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Example
    assert DocstringMeta(["param"], "description").args == ["param"]
    

# Generated at 2022-06-21 11:40:06.290560
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test error")
    except ParseError as err:
        assert err.args[0] == "test error"

test_ParseError()


# Generated at 2022-06-21 11:40:15.943571
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    import pytest
    from typing import List
    args = ["param", "arg"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default
    assert docstring_param.args == ["param", "arg"]
    assert docstring_param.description == "description"

# Generated at 2022-06-21 11:40:19.938132
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["version"], "This is a test", None )
    assert docstring.args == ["version"]
    assert docstring.description is None
    assert docstring.version is None



# Generated at 2022-06-21 11:40:29.659828
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    # Unit test for constructor of class DocstringParam
    # Define arguments
    args = ['param', 'arguments']
    description = 'This is an argument'
    arg_name = 'arg'
    type_name = 'type of arg'
    is_optional = True
    default = 'default'
    # Initialize class DocstringParam
    obj_docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    # Assert
    assert obj_docstring_param is not None
    

# Generated at 2022-06-21 11:40:31.771473
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    temp = DocstringMeta(args = ['a'], description = '1')
    assert temp.args == ['a']
    assert temp.description == '1'


# Generated at 2022-06-21 11:40:37.742524
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert type(ds.meta) is list
    assert len(ds.meta) is 0


# Generated at 2022-06-21 11:40:42.841335
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["args"], "description", "type_name", True)
    assert docstring_returns is not None
    assert docstring_returns.args == ["args"]
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name is None


# Generated at 2022-06-21 11:40:44.151809
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("para")
    assert isinstance(pe, RuntimeError)



# Generated at 2022-06-21 11:40:46.949171
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises']
    description = 'Description of exception'
    type_name = 'ValueError'
    exc = DocstringRaises(args, description, type_name)
    assert exc._args == ['raises']
    assert exc._description == 'Description of exception'
    assert exc._type_name == 'ValueError'

# Generated at 2022-06-21 11:40:50.357202
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ar = DocstringReturns(["return"],None,"int",False)
    assert ar.args == ["return"]
    assert ar.description == None
    assert ar.type_name == "int"
    assert ar.is_generator == False
    assert ar.return_name == None

# Generated at 2022-06-21 11:43:40.765073
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([":raises"], "if something happens", "ValueError")



# Generated at 2022-06-21 11:43:42.699855
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    #makes an instance of DocstringRaises
    test=DocstringRaises(['param', 'arg', 'keyword'], 'description', 'none')

# Generated at 2022-06-21 11:43:48.914472
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg1 = 1", "arg2 = 2"]
    description = "description"
    type_name = "type_name"
    docstringRaises = DocstringRaises(
        args, description, type_name
    )
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name

# Generated at 2022-06-21 11:43:51.528367
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doctest_returns = DocstringReturns(["return", "returns"], "Hey there", "str", False)
    assert doctest_returns.args == ["return", "returns"]
    assert doctest_returns.description == "Hey there"
    assert doctest_returns.type_name == "str"
    assert doctest_returns.is_generator == False

# Generated at 2022-06-21 11:43:52.955711
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    instance = DocstringDeprecated(["deprecated"], "", "0.0.1")
    assert isinstance(instance, DocstringDeprecated)


# Generated at 2022-06-21 11:43:54.729286
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docst_meta1 = DocstringMeta(['param', 'arg'], "description")
    assert docst_meta1.args == ['param', 'arg']
    assert docst_meta1.description == "description"
# Test ended


# Generated at 2022-06-21 11:43:55.735990
# Unit test for constructor of class ParseError
def test_ParseError():
	error = ParseError("A custom error occurred!")
	assert str(error) == "A custom error occurred!"



# Generated at 2022-06-21 11:44:01.521786
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    # No description
    args = [':deprecated', ':version 2.0']
    description = None
    version = '2.0'
    doc = DocstringDeprecated(args, description, version)
    assert doc.args == args
    assert doc.description == description
    assert doc.version == version

    # With description
    args = [':deprecated', ':version 2.0']
    description = 'test desc'
    version = '2.0'
    doc = DocstringDeprecated(args, description, version)
    assert doc.args == args
    assert doc.description == description
    assert doc.version == version

    # No version
    args = [':deprecated']
    description = 'test desc'
    version = None
    doc = DocstringDep

# Generated at 2022-06-21 11:44:04.294321
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj1 = DocstringMeta(["param", "arg"], "description")
    assert obj1.args == ["param", "arg"]
    assert obj1.description == "description"
    

# Generated at 2022-06-21 11:44:05.087399
# Unit test for constructor of class ParseError
def test_ParseError():
    pass
