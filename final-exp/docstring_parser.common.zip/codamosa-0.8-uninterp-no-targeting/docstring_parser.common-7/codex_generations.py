

# Generated at 2022-06-21 11:34:16.414982
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()


# Generated at 2022-06-21 11:34:20.723980
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param=DocstringParam([":param arg:","description"], "description", "arg", "type_name", False, "default");
    assert docstring_param.arg_name=="arg"
    assert docstring_param.type_name=="type_name"
    assert docstring_param.is_optional==False
    assert docstring_param.default=="default"


# Generated at 2022-06-21 11:34:24.414733
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Blank
    DocstringMeta(args=[], description="")
    DocstringMeta(args=[], description="desc")
    # Normal
    DocstringMeta(args=["arg1", "arg2"], description="desc")


# Generated at 2022-06-21 11:34:27.630008
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['deprecated'], 'This method is deprecated', '2.0') == DocstringDeprecated(['deprecated'], 'This method is deprecated', '2.0')


# Generated at 2022-06-21 11:34:33.522966
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc_param = DocstringParam(
        args=[], description="", arg_name="", type_name="", is_optional=False
    )
    assert doc_param.args == []
    assert doc_param.description == ""
    assert doc_param.arg_name == ""
    assert doc_param.type_name == ""
    assert doc_param.is_optional is False



# Generated at 2022-06-21 11:34:40.033422
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "attribute", "key", "keyword"]
    arg_name = "arg"
    type_name = "int"
    is_optional = True
    default = "01"
    test_docstring = DocstringParam(args, None, arg_name, type_name, is_optional, default)
    test_docstring.args == args
    test_docstring.arg_name == arg_name
    test_docstring.is_optional == is_optional
    test_docstring.type_name == type_name
    test_docstring.default == default


# Generated at 2022-06-21 11:34:45.960262
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d1 = DocstringRaises(["arg"], "d", "t")
    assert d1.type_name == "t"
    assert d1.description == "d"
    assert d1.args[0] == "arg"
    d2 = DocstringRaises(["arg", "arg2"], "d", "t")
    assert d2.args[1] == "arg2"

# Generated at 2022-06-21 11:34:56.836506
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    unittest for Docstring constructor
    :return: None
    """
    from unittest import TestCase, main
    from copy import copy
    from doctrans.parsing.docstrings import Docstring, DocstringMeta, DocstringParam, DocstringReturns, DocstringRaises, DocstringDeprecated

    class DocstringTestCase(TestCase):
        """
        unittest for Docstring constructor
        """

        def setUp(self):
            """
            set up unit test
            :return: None
            """
            self.d1 = Docstring()
            self.d1.short_description = 'short description'
            self.d1.long_description = 'long description'

# Generated at 2022-06-21 11:34:59.879202
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Create DocstringMeta and verify
    docstringMeta = DocstringMeta(['testArgs'], 'testDescription')
    assert docstringMeta.args[0] == "testArgs"
    assert docstringMeta.description == "testDescription"


# Generated at 2022-06-21 11:35:01.823140
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-21 11:35:09.672687
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args= []
    description = "Test description"
    type_name = "type"
    test_raises = DocstringRaises(args, description, type_name)
    expected_raises = DocstringRaises([], "Test description", "type")
    assert test_raises == expected_raises

# Generated at 2022-06-21 11:35:16.236033
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["a", "b"], "description", "arg_name", "type_name", "is_optional", "default")
    assert a.args == ["a", "b"]
    assert a.description == "description"
    assert a.arg_name == "arg_name"
    assert a.type_name == "type_name"
    assert a.is_optional == "is_optional"
    assert a.default == "default"


# Generated at 2022-06-21 11:35:19.563596
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_meta = DocstringRaises("args", "description", "type")
    assert test_meta.type_name == "type"
    assert isinstance(test_meta, DocstringRaises)


# Generated at 2022-06-21 11:35:22.710971
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    DocstringReturns(
        args=[":returns"],
        description="return the value",
        type_name="str",
        is_generator=False,
    )

# Generated at 2022-06-21 11:35:24.827283
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(['args'], 'Catch ValueError', 'ValueError')
    assert doc.type_name == 'ValueError'
    assert doc.description == 'Catch ValueError'

# Generated at 2022-06-21 11:35:27.808706
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ret = DocstringRaises(["raises"], "if something", "ValueError")
    assert ret.args == ["raises"]
    assert ret.description == "if something"
    assert ret.type_name == "ValueError"


# Generated at 2022-06-21 11:35:33.566709
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    foo = DocstringRaises([':raises ZeroDivisionError: if y == 0'], "ZeroDivisionError if y == 0", 'ZeroDivisionError')
    assert(foo.args == [':raises ZeroDivisionError: if y == 0'])
    assert(foo.description == "ZeroDivisionError if y == 0")
    assert(foo.type_name == 'ZeroDivisionError')



# Generated at 2022-06-21 11:35:35.604847
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises('args','description','type_name') == DocstringRaises('args','description','type_name')

# Generated at 2022-06-21 11:35:41.418336
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(["hey","boi"], "watup", "2.0.0")
    assert isinstance(ds, DocstringDeprecated)
    assert ds.args == ["hey","boi"]
    assert ds.description == "watup"
    assert ds.version == "2.0.0"


# Generated at 2022-06-21 11:35:43.297196
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param"], "description", "arg_name", "type_name", True, None)



# Generated at 2022-06-21 11:35:52.384122
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([param, arg], description)


# Generated at 2022-06-21 11:36:00.724849
# Unit test for constructor of class ParseError
def test_ParseError():
    import io
    import sys
    import traceback
    try:
        raise ParseError("a")
    except Exception as e:
        _, _, tb = sys.exc_info()
        traceback.print_tb(tb)
        assert "  File \"tests/test_parse.py\", line 6, in test\n    raise ParseError(\"a\")" in io.getvalue()
        assert "tests.test_parse.ParseError: a" in io.getvalue()

# Generated at 2022-06-21 11:36:05.538565
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns(): 
    assert(DocstringReturns.description == None) 
    assert(DocstringReturns.args == None) 
    assert(DocstringReturns.type_name == None)
    assert(DocstringReturns.is_generator == True)
    assert(DocstringReturns.return_name == None)
    
    
    
    

# Generated at 2022-06-21 11:36:09.458875
# Unit test for constructor of class Docstring
def test_Docstring():
    new_Docstring = Docstring()
    assert new_Docstring.short_description is None
    assert new_Docstring.long_description is None
    assert new_Docstring.blank_after_short_description == False
    assert new_Docstring.blank_after_long_description == False
    assert new_Docstring.meta == []



# Generated at 2022-06-21 11:36:14.843047
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test for DocstringReturns."""
    x = DocstringReturns([], 'str', False, False, False)
    assert x.return_name == 'str'
    assert x.type_name == False
    assert x.is_generator == False
    assert x.description == False
    assert x.args == []


# Generated at 2022-06-21 11:36:18.594681
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args='args'
    expected_args=['args']
    description='description'
    version='version'
    test=DocstringDeprecated(args,description, version)
    assert test.args==expected_args
    assert test.description==description
    assert test.version==version

# Generated at 2022-06-21 11:36:24.597059
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, None, False).is_generator == False
    assert DocstringReturns([], None, None, True).is_generator == True
    assert DocstringReturns([], None, "str", True).type_name == "str"
    assert DocstringReturns([], None, None, True).type_name is None


# Generated at 2022-06-21 11:36:27.185815
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert e, "e is true"
    #assert e.__init__(), "ParseError.__init__() is true"

# Generated at 2022-06-21 11:36:28.817836
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert type(DocstringDeprecated(["",""],"", "") is DocstringDeprecated)



# Generated at 2022-06-21 11:36:32.805358
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    d = DocstringRaises(args, "", "")
    assert(d.args == ["raises", "ValueError"])


# Generated at 2022-06-21 11:36:59.203398
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam
    # test for __init__(self, ...)
    # TypeError: __init__() missing 6 required positional arguments: 'args', 'description', 'arg_name', 'type_name', 'is_optional', and 'default'
    try:
        DocstringParam()
    except TypeError as e:
        assert e.args == (
            "__init__() missing 6 required positional arguments: 'args', 'description', 'arg_name', 'type_name', 'is_optional', and 'default'",
        )
    # TypeError: __init__() missing 6 required positional arguments: 'args', 'description', 'arg_name', 'type_name', 'is_optional', and 'default'

# Generated at 2022-06-21 11:37:04.628536
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError', ':']
    description = 'error'
    type_name = 'ValueError'
    a = DocstringRaises(args, description, type_name)
    assert a.args == args
    assert a.description == description
    assert a.type_name == type_name

# Generated at 2022-06-21 11:37:08.296808
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-21 11:37:11.480058
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    v = DocstringDeprecated(args=[], description=None, version=None)
    print(v.args)
    print(v.description)
    print(v.version)
    v.version = 1
    print(v.version)


# Generated at 2022-06-21 11:37:19.158812
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "Test description."
    arg_name = "arg1"
    type_name = "int"
    is_optional = True
    default = "1"

    obj = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert obj.args == []
    assert obj.description == "Test description."
    assert obj.arg_name == "arg1"
    assert obj.type_name == "int"
    assert obj.is_optional == True
    assert obj.default == "1"


# Generated at 2022-06-21 11:37:21.327259
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid syntax")
    except ParseError as e:
        assert e.args == ("Invalid syntax",)


# Generated at 2022-06-21 11:37:22.806465
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert 'DocstringRaises' == str(DocstringRaises.__init__.__name__)
    pass


# Generated at 2022-06-21 11:37:29.650642
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-21 11:37:32.964971
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "In here is the description"
    doc = DocstringMeta(args, description)
    assert doc.args == args
    assert doc.description == description

# Generated at 2022-06-21 11:37:43.693765
# Unit test for constructor of class ParseError
def test_ParseError():
    print('--- Constructor of class ParseError ---')
    my_error = ParseError('This is my error.')
    print(my_error)
    print('')
    

print('--- Constructor of class DocstringMeta ---')
my_meta = DocstringMeta(['param'], 'description of the param')
print(my_meta.__dict__)
print('')
    
print('--- Constructor of class DocstringParam ---')
my_param = DocstringParam(['param'], 'description of the param', 'my_param', 'str', True, None)
print(my_param.__dict__)
print('')

print('--- Constructor of class DocstringReturns ---')
my_returns = DocstringReturns(['returns'], 'description of the returns value', 'str', True)
print

# Generated at 2022-06-21 11:38:16.254241
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raise_doc = DocstringRaises(["raises", "RuntimeError"], "test")
    assert isinstance(raise_doc, DocstringRaises)
    assert raise_doc.description == "test"
    assert raise_doc.args == ["raises", "RuntimeError"]


# Generated at 2022-06-21 11:38:26.348658
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    import unittest
    from mypy.build import DocstringRaises
    
    class TestDocstringRaisesMethods(unittest.TestCase):
        # Test initialization of DocstringRaises methods
        def test_initialization(self):
            test_args = ["test_args"]
            test_description = "test_description"
            test_type_name = "test_type_name"
            test_docstringRaises = DocstringRaises(test_args, test_description, test_type_name)
            self.assertEqual(test_docstringRaises.args, test_args)
            self.assertEqual(test_docstringRaises.description, test_description)
            self.assertEqual(test_docstringRaises.type_name, test_type_name)
            

# Generated at 2022-06-21 11:38:31.233575
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    R = DocstringReturns(args=None,description='description',type_name='type_name',is_generator='is_generator',return_name='return_name')
    assert R.args is None
    assert R.description == 'description'
    assert R.type_name == 'type_name'
    assert R.is_generator == 'is_generator'
    assert R.return_name == 'return_name'

# Generated at 2022-06-21 11:38:39.485981
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Tests for the constructor of DocstringDeprecated
    docstring_deprecated_1 = DocstringDeprecated(["deprecated"], "This is deprecated", "1.0")
    assert docstring_deprecated_1.args == ["deprecated"]
    assert docstring_deprecated_1.version == "1.0"
    assert docstring_deprecated_1.description == "This is deprecated"

    # Tests if the constructor throws an exception if the args parameter is not of type List of str
    from pytest import raises

    with raises(TypeError):
        DocstringDeprecated("deprecated", "This is deprecated", "1.0")



# Generated at 2022-06-21 11:38:42.881088
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated([], "description", "version")
    if doc.description is not "description" or doc.version is not "version":
        raise AssertionError


# Generated at 2022-06-21 11:38:51.024430
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_inst = DocstringParam(['param'], 'shows the username', 'username', 'str', True, 'None')
    assert param_inst.args == ['param']
    assert param_inst.description == 'shows the username'
    assert param_inst.arg_name == 'username'
    assert param_inst.type_name == 'str'
    assert param_inst.is_optional == True
    assert param_inst.default == 'None'
    # check if the DocstringParam is a child of DocstringMeta
    assert isinstance(param_inst, DocstringMeta)


# Generated at 2022-06-21 11:38:52.847846
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    obj = DocstringReturns(['return'], 'Return name of this method', 'str', False)
    return obj

# Generated at 2022-06-21 11:38:56.368232
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [":param", "arg", ":arg", ":parameter", "argument", ":attribute", ":key", ":keyword"]
    description = "This is description"
    type_name = "str"
    assert DocstringRaises(args, description, type_name)

# Generated at 2022-06-21 11:38:58.620734
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["type"], None, None)


# Generated at 2022-06-21 11:39:02.120494
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        a = DocstringRaises(1,2,3)
    except Exception as e:
        print(f"Something went wrong!\n{e}")
    else:
        print("All good")

# Generated at 2022-06-21 11:40:07.953663
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass


# Generated at 2022-06-21 11:40:14.755072
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    "Unit test for constructor of DocstringDeprecated"
    # Arrange
    # Nothing to arrange.
    # Act
    # Create DocstringDeprecated object.
    actual = DocstringDeprecated(args=None, description=None, version=None)
    # Assert
    # Check __init__() of parent DocstringMeta:
    assert isinstance(actual, DocstringMeta)
    assert actual.args is None
    assert actual.description is None
    # Check __init__() of DocstringDeprecated:
    assert actual.version is None



# Generated at 2022-06-21 11:40:17.674131
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test')
    except ParseError as err:
        assert str(err) == 'test'


# Generated at 2022-06-21 11:40:21.288614
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error message")
    except ParseError as err:
        assert(str(err) == "error message")



# Generated at 2022-06-21 11:40:24.038429
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('error')
    except ParseError as e:
        assert str(e) == 'error'


# Generated at 2022-06-21 11:40:26.883272
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["args"], "description", "arg_name",
                                     "type_name", True, "True")
    assert docstring_param


# Generated at 2022-06-21 11:40:35.176945
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    # Check docstring meta data attributes
    assert obj.short_description is None
    assert obj.long_description is None
    assert not obj.blank_after_short_description
    assert not obj.blank_after_long_description
    assert obj.meta == []
    # Check docstring getter properties
    assert obj.params == []
    assert obj.raises == []
    assert obj.returns is None
    assert obj.deprecation is None
    # Build DocstringParam
    d = Docstring()
    d.meta = [DocstringParam([], "desc", "x", None, False, None)]
    # Check docstring properties
    assert len(obj.params) == 1
    assert obj.raises == []
    assert obj.returns is None
    assert obj.deprecation is None



# Generated at 2022-06-21 11:40:38.296548
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # A dummy DocstringReturns object is created by initialization
    dsr = DocstringReturns(args=['type_name'], description='Test description', is_generator=1, type_name='None')

    # The variable is_generator should be 1
    assert(dsr.is_generator == 1)

# Generated at 2022-06-21 11:40:45.950357
# Unit test for constructor of class Docstring
def test_Docstring():
    import sys
    import os
    import inspect
    import doctest
    from rsdoc.parser.docstring import Docstring
    from rsdoc.parser.docstring import DocstringParam
    from rsdoc.parser.docstring import DocstringRaises
    from rsdoc.parser.docstring import DocstringMeta
    from rsdoc.parser.docstring import DocstringReturns
    from rsdoc.parser.docstring import DocstringDeprecated
    from rsdoc.parser.docstring import ParseError
    from rsdoc.parser.parser import DocstringParser
    # Retrieve the path to the current file
    cur_file_path = os.path.abspath(inspect.getfile(inspect.currentframe()))
    # Change the path to the test directory
    test_dir_path = os.path.dirname(cur_file_path)

# Generated at 2022-06-21 11:40:50.504843
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    X = DocstringReturns(["A","B","C"], "D", "F", "G", "I")
    assert X.args == ["A","B","C"]
    assert X.description == "D"
    assert X.type_name == "F"
    assert X.is_generator == "G"
    assert X.return_name == "I"


# Generated at 2022-06-21 11:41:49.400222
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "description", "arg", "str", True, "None")
    assert param.description == "description"
    assert param.arg_name == "arg"
    assert param.type_name == "str"
    assert param.is_optional == True
    assert param.default == "None"

# Generated at 2022-06-21 11:41:52.810522
# Unit test for constructor of class ParseError
def test_ParseError():
    #returns: str
    """test_ParseError.py"""
    expect_true = isinstance(ParseError, RuntimeError)
    expect_false = isinstance(ParseError, Docstring)
    return expect_true, expect_false


# Generated at 2022-06-21 11:41:57.741466
# Unit test for constructor of class Docstring
def test_Docstring():
    instance = Docstring()

    assert instance.short_description is None
    assert instance.long_description is None
    assert instance.blank_after_short_description is False
    assert instance.blank_after_long_description is False
    assert instance.meta == []

    assert instance.params == []
    assert instance.raises == []
    assert instance.returns is None
    assert instance.deprecation is None


# Generated at 2022-06-21 11:42:01.246205
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    pa = DocstringParam(["param"], "parameter description", "a", "int", False, "2")
    assert(pa.args == ["param"])
    assert(pa.description == "parameter description")
    assert(pa.arg_name == "a")
    assert(pa.type_name == "int")
    assert(pa.is_optional == False)
    assert(pa.default == "2")



# Generated at 2022-06-21 11:42:05.781560
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Test')
    except BaseException as exc:
        type_exc = type(exc)
        assert type_exc is ParseError
        assert str(exc) == 'Test'



# Generated at 2022-06-21 11:42:10.752755
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["This", "is", "a", "test", "for", "docstring_meta"]
    meta = DocstringReturns(args,"this is a test","int",1)
    assert meta.args == args
    assert meta.description == "this is a test"
    assert meta.type_name == "int"
    assert meta.is_generator == 1

# Generated at 2022-06-21 11:42:15.315389
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    params = DocstringParam(["name"], "this is the description", "name", 'str', True, "this is the default value")
    assert params.args == ["name"]
    assert params.description == "this is the description"
    assert params.arg_name == "name"
    assert params.type_name == "str"
    assert params.is_optional == True
    assert params.default == "this is the default value"


# Generated at 2022-06-21 11:42:20.787002
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj1 = DocstringMeta(["a", "b", "c"], "testing constructor")
    obj2 = DocstringMeta(["z", "y", "x"], "$#%@#$%@")
    assert obj1 is not None and obj2 is not None


# Generated at 2022-06-21 11:42:24.948963
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['args']
    description = 'description'
    version = 'version'
    output = DocstringDeprecated(args, description, version)
    assert output.args == args
    assert output.description == description
    assert output.version == version


# Generated at 2022-06-21 11:42:27.523143
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg"]
    description = "description"
    docstringMeta = DocstringMeta(args,description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-21 11:44:06.836721
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([""], "", "").type_name == ""
    assert DocstringRaises([""], "", "").description == ""

# Generated at 2022-06-21 11:44:09.944253
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(args=['a'], description='test', type_name='test', is_generator=False)
    assert(a)


#Unit test for the Docstring constructor