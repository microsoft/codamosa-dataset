

# Generated at 2022-06-21 11:34:21.189390
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(1, 2, 3, 4, 5, 6).args == 1
    assert DocstringParam(1, 2, 3, 4, 5, 6).description == 2
    assert DocstringParam(1, 2, 3, 4, 5, 6).arg_name == 3
    assert DocstringParam(1, 2, 3, 4, 5, 6).type_name == 4
    assert DocstringParam(1, 2, 3, 4, 5, 6).is_optional == 5
    assert DocstringParam(1, 2, 3, 4, 5, 6).default == 6

# Generated at 2022-06-21 11:34:24.653080
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm =  DocstringMeta(['args'], 'description')
    assert dm.args == ['args']
    assert dm.description == 'description'

test_DocstringMeta()


# Generated at 2022-06-21 11:34:25.610961
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["a","b"], "description")
    assert dm.args == ["a","b"]
    assert dm.description == "description"


# Generated at 2022-06-21 11:34:32.271155
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc1 = DocstringDeprecated(["deprecated"], "This is a deprecation message.", "")
    assert doc1.description == "This is a deprecation message."
    assert doc1.args == ["deprecated"]
    assert doc1.version == ""
    doc2 = DocstringDeprecated(["deprecated"], None, None)
    assert doc2.description == None
    assert doc2.args == ["deprecated"]
    assert doc2.version == None


# Generated at 2022-06-21 11:34:35.356332
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(Exception):
        raise ParseError("Exception")
    error = ParseError("Problem parsing dunder line")
    assert str(error) == "Problem parsing dunder line"


# Generated at 2022-06-21 11:34:41.952849
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert isinstance(docstring.params, list)
    assert isinstance(docstring.raises, list)
    assert docstring.returns == None
    assert docstring.deprecation == None

# Generated at 2022-06-21 11:34:51.632578
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg1 = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    arg2 = DocstringParam(["param"], "description", "arg_name", "type_name", None, None)
    assert arg1.args == ["param"]
    assert arg2.description == "description"
    assert arg1.arg_name == "arg_name"
    assert arg2.type_name == "type_name"
    assert arg2.is_optional == None
    assert arg1.default == "default"

# Unit tests for constructor of class DocstringReturns

# Generated at 2022-06-21 11:34:53.555105
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from inspect import cleandoc
    example_docstring = DocstringMeta(['a', 'b'], 'c')
    assert example_docstring.args == ['a', 'b']
    assert example_docstring.description == 'c'


# Generated at 2022-06-21 11:34:59.458660
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError('spam')
    # Check implementation of __str__
    assert str(exc) == 'spam'
    # Check implementation of __repr__
    assert repr(exc) == "ParseError('spam',)"
    # Check implementation of __getitem__
    assert exc[0] == 'spam'
    # Check implementation of __len__
    assert len(exc) == 1
    # Check implementation of __iter__
    assert list(iter(exc)) == ['spam']

# Generated at 2022-06-21 11:35:04.642583
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arguments = []  # type: List[str]
    description = "this is DocstringReturns"
    type_name = None
    is_generator = False
    return_name = None
    assert DocstringReturns(arguments, description, type_name, is_generator) is not None

# Generated at 2022-06-21 11:35:08.999984
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test = DocstringMeta(["arg"], "description")
    assert test.args == ["arg"]
    assert test.description == "description"


# Generated at 2022-06-21 11:35:16.129350
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string.short_description is None
    assert doc_string.long_description is None
    assert doc_string.blank_after_short_description is False
    assert doc_string.blank_after_long_description is False
    assert doc_string.meta == []
    assert doc_string.params == []
    assert doc_string.raises == []
    assert doc_string.returns is None
    assert doc_string.deprecation is None



# Generated at 2022-06-21 11:35:21.155504
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        raise DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    except DocstringRaises as raised_e:
        assert raised_e.args == ["raises", "ValueError"]
        assert raised_e.description == "if something happens"
        assert raised_e.type_name == "ValueError"

# Generated at 2022-06-21 11:35:24.633053
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(
        args=['arg'],
        description=['arg'],
        type_name=['arg']
    )
    assert docstring_raises


# Generated at 2022-06-21 11:35:27.967750
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises"]
    description = "Value Error"
    type_name = "Value"

    error = DocstringRaises(args, description, type_name)
    print(error.args, error.description, error.type_name)


# Generated at 2022-06-21 11:35:31.406943
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test Error")
    except ParseError as e:
        assert str(e) == "Test Error"


# Generated at 2022-06-21 11:35:33.826676
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    m = DocstringMeta(args=['param'], description='DocstringMeta description')
    assert m.args == ['param']
    assert m.description == 'DocstringMeta description'


# Generated at 2022-06-21 11:35:37.221878
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args", "args2"]
    description = "description"
    a = DocstringMeta(args, description)
    assert (a.args == args)
    assert (a.description == description)



# Generated at 2022-06-21 11:35:41.312227
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    b = DocstringRaises(['raises'], 'error', 'int')
    assert b.args == ['raises']
    assert b.description == 'error'
    assert b.type_name == 'int'

# Generated at 2022-06-21 11:35:46.435845
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['true'], 'true', 'true')
    a.arg_name = 'true'
    a.description = 'true'
    a.type_name = 'true'
    a.is_optional = 'true'
    a.default = 'true'
    a.is_generator = 'true'
    a.version = 'true'
    assert a is not None

# Generated at 2022-06-21 11:35:55.620328
# Unit test for constructor of class Docstring
def test_Docstring():
    doctest = Docstring()
    assert doctest.short_description == None
    assert doctest.long_description == None
    assert doctest.blank_after_short_description == False
    assert doctest.blank_after_long_description == False
    assert doctest.meta == []


# Generated at 2022-06-21 11:36:00.301041
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    my_docstring_meta = DocstringMeta(['example'], 'An example of a DocstringMeta')
    assert (my_docstring_meta.args == ['example'])
    assert (my_docstring_meta.description == 'An example of a DocstringMeta')


# Generated at 2022-06-21 11:36:05.919022
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    correctArgs = ["param", "argument", "key", "keyword"]
    correctDescription = "If this type of error occurs, it raises a ValueError"
    correctTypeName = "ValueError"
    test = DocstringRaises(correctArgs, correctDescription, correctTypeName)

    assert test.args == correctArgs
    assert test.description == correctDescription
    assert test.type_name == correctTypeName



# Generated at 2022-06-21 11:36:11.858596
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    actual = DocstringParam(['param', 'argument'], 'description', 'argument', 'string', 1, 'default')
    assert actual.args == ['param', 'argument']
    assert actual.description == 'description'
    assert actual.arg_name == 'argument'
    assert actual.type_name == 'string'
    assert actual.is_optional == 1
    assert actual.default == 'default'


# Generated at 2022-06-21 11:36:13.179923
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([],None,None)

# Generated at 2022-06-21 11:36:17.013085
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['deprecation', 'deprecated'], "description", "version")
    assert doc.args == ['deprecation', 'deprecated']
    assert doc.description == "description"
    assert doc.version == "version"


# Generated at 2022-06-21 11:36:25.398515
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    with self.subTest('Given list of args, description and type_name'):
        args = ["Raises", "Raise", "Except", "Exception"]
        description = "Expected"
        type_name = "ValueError"
        obj = DocstringRaises(args, description, type_name)
        self.assertEqual(args, obj.args)
        self.assertEqual(description, obj.description)
        self.assertEqual(type_name, obj.type_name)


# Generated at 2022-06-21 11:36:27.284044
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError("Error")


# Generated at 2022-06-21 11:36:29.905150
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test for constructor of class ParseError
    p=ParseError()
    assert isinstance(p, ParseError)


# Generated at 2022-06-21 11:36:36.503197
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    ds.short_description = "A short description"
    ds.long_description = "A long description"
    ds.blank_after_long_description = True
    assert ds.short_description == "A short description"
    assert ds.long_description == "A long description"
    assert ds.blank_after_long_description == True



# Generated at 2022-06-21 11:36:41.303849
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['args'],'description', 'type_name')


# Generated at 2022-06-21 11:36:45.939043
# Unit test for constructor of class Docstring
def test_Docstring():
    token = Docstring()
    assert token.short_description == None
    assert token.long_description == None
    assert token.blank_after_short_description == False
    assert token.blank_after_long_description == False
    assert token.meta == []


# Generated at 2022-06-21 11:36:50.217109
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test parse error")
    except ParseError as e:
        assert str(e) == "test parse error", 'Failed to generate correct ParseError'


# Generated at 2022-06-21 11:36:52.470738
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta([params], "Hello ")
    assert doc, args
    assert doc, description



# Generated at 2022-06-21 11:36:55.293042
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['args'], 'desc', 'type_name')
    assert d.args == ['args']
    assert d.description == 'desc'
    assert d.type_name == 'type_name'


# Generated at 2022-06-21 11:37:03.355686
# Unit test for constructor of class Docstring
def test_Docstring():
    #test description
    docstring=Docstring()
    assert docstring.short_description==None
    docstring.short_description="test description"
    docstring.long_description="test long description"
    assert docstring.short_description=="test description"
    assert docstring.long_description=="test long description"
    
    #test params
    docstringParam=DocstringParam(['param','arg','argument','attribute','key','keyword'],'test arg description','arg_name','type_name',True,'default_value')
    docstring.meta.append(docstringParam)
    assert docstring.params[0].arg_name=='arg_name'
    
    #test returns
    docstringReturn=DocstringReturns(['return','returns'],'test docstringReturn description','return type name',True,'return name')


# Generated at 2022-06-21 11:37:04.500962
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Test msg")
    assert str(err) == "Test msg"


# Generated at 2022-06-21 11:37:09.837285
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert (docstring.short_description == None)
    assert (docstring.long_description == None)
    assert (docstring.blank_after_short_description == False)
    assert (docstring.blank_after_long_description == False)
    assert (len(docstring.meta) == 0)
    assert (docstring.params == [])
    assert (docstring.raises == [])
    assert (docstring.returns == None)
    assert (docstring.deprecation == None)



# Generated at 2022-06-21 11:37:12.205174
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta("args", "description").args == "args"
    assert DocstringMeta("args", "description").description == "description"
    print("test_DocstringMeta finished")



# Generated at 2022-06-21 11:37:13.722341
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(['args'], 'description', 'version')
    assert isinstance(obj, DocstringDeprecated)

# Generated at 2022-06-21 11:37:22.243457
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['param', 'argument'], 'description', 'arg_name', 'type_name', False, "default")
    assert type(param.args) == list
    assert type(param.description) == str
    assert type(param.arg_name) == str
    assert type(param.type_name) == str
    assert type(param.is_optional) == bool
    assert type(param.default) == str


# Generated at 2022-06-21 11:37:26.481160
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test exception")
    except ParseError as err:
        if str(err) == "Test exception":
            assert True
        else:
            assert False


# Generated at 2022-06-21 11:37:29.404461
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(["version","x"],"x","x")
    assert ds.version == "x"
    assert ds.description == "x"
    assert ds.args == ["version","x"]

# Generated at 2022-06-21 11:37:32.360345
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(["raises", "ValueError", "if something happens"], "if something happens", "ValueError")


# Generated at 2022-06-21 11:37:43.124352
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d1 = DocstringReturns(["returns"], "...", None, False, "test")
    d2 = DocstringReturns(["returns"], "...", None, False, None)
    assert d1.return_name == "test"
    assert d2.return_name == None
    d3 = DocstringReturns(["returns"], None, None, False, "test")
    d4 = DocstringReturns(["returns"], None, None, False, None)
    assert d3.description == None
    assert d4.description == None
    d5 = DocstringReturns(["returns"], "...", "str", False, "test")
    assert d5.type_name == "str"
    d6 = DocstringReturns(["returns"], "...", "str", False, None)

# Generated at 2022-06-21 11:37:46.732813
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """test__DocstringMeta"""
    x = DocstringMeta(['a', 'b'], 'c')
    assert x.args == ['a', 'b']
    assert x.description == 'c'


# Generated at 2022-06-21 11:37:47.338865
# Unit test for constructor of class Docstring
def test_Docstring():
  pass

# Generated at 2022-06-21 11:37:49.824151
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["my_argument"], "my_description", "my_type_name")

# Generated at 2022-06-21 11:37:50.864554
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test ParseError constructor."""
    error = ParseError("error message")
    assert str(error) == "error message"

# Generated at 2022-06-21 11:37:51.898423
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None


# Generated at 2022-06-21 11:38:02.262967
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test = DocstringParam (["param", "parameter"], "description", "arg_name",
        "type_name", "is_optional", "default")
    assert test.args == ["param", "parameter"]
    assert test.description == "description"
    assert test.arg_name == "arg_name"
    assert test.type_name == "type_name"
    assert test.is_optional == "is_optional"
    assert test.default == "default"

# Generated at 2022-06-21 11:38:06.085284
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    my_DocstringDeprecated = DocstringDeprecated(['1','0','0'], '1','0','0','0')
    assert my_DocstringDeprecated.version == '0' and my_DocstringDeprecated.description == '1'

# Generated at 2022-06-21 11:38:06.842663
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated('a', 'b', 'c')



# Generated at 2022-06-21 11:38:11.112117
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = None
    arg_name = 'arg_name'
    type_name = None
    is_optional = None
    default = None
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-21 11:38:20.249420
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print("Create an instance of DocstringDeprecated")
    docstring_deprecated = DocstringDeprecated([" :deprecated: "], "", "")
    print("Check if the value of attribute 'args' is empty")
    print(docstring_deprecated.args == [])
    print("Check if the value of attribute 'description' is empty")
    print(docstring_deprecated.description == "")
    print("Check if the value of attribute 'version' is empty")
    print(docstring_deprecated.version == "")
    print("Check if the value of attribute 'type_name' is None")
    print(docstring_deprecated.type_name == "")


# Generated at 2022-06-21 11:38:22.533963
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(["Test", ":", "T"])
    assert doc.args == ["Test", ":", "T"]

# Generated at 2022-06-21 11:38:27.431324
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raise", "exception"]
    desc = "If the supplied string is empty."
    type_name = "Exception"

    docstring_raises = DocstringRaises(args, desc, type_name)

    assert docstring_raises.args == args
    assert docstring_raises.description == desc
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-21 11:38:28.280472
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args, description, type_name, is_generator, return_name)

# Generated at 2022-06-21 11:38:30.220141
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(message = "Invalid entry at line: 1")
    assert str(error) == "Invalid entry at line: 1"
    pass

# Generated at 2022-06-21 11:38:35.136327
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises([""], "", "")
    assert hasattr(docstring, "args")
    assert hasattr(docstring, "description")
    assert hasattr(docstring, "type_name")


# Generated at 2022-06-21 11:38:44.214476
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['deprecated'], '', '1.0') is not None

# Generated at 2022-06-21 11:38:50.342795
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test = DocstringReturns(args = ["args"], description = "this is a description", type_name = "type_name", is_generator = True, return_name = "test")
    assert test.args == ["args"]
    assert test.description == "this is a description"
    assert test.type_name == "type_name"
    assert test.is_generator == True
    assert test.return_name == "test"



# Generated at 2022-06-21 11:38:53.163345
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['a'], '1.0', 'image')
    assert(a.args == ['a'])
    assert(a.description == '1.0')
    assert(a.version == 'image')


# Generated at 2022-06-21 11:38:54.741516
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['return:1'], 'this is return', 'string', True, 'retName')


# Generated at 2022-06-21 11:38:59.932589
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    e = DocstringRaises(['something', 'I do not know'], "This is description", 'Sth')
    print(e.args)
    print(e.description)
    print(e.type_name)


if __name__ == "__main__":
    test_DocstringRaises()

# Generated at 2022-06-21 11:39:04.670420
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    r = DocstringRaises(["raises"], "", "ValueError")
    assert r.args == ["raises"]
    assert r.type_name == "ValueError"
    assert r.is_generator is False
    assert r.return_name is None
    assert r.description == ""

# Generated at 2022-06-21 11:39:09.901378
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(
        args=["param"],
        description="description",
        arg_name="arg_name",
        type_name="type_name",
        is_optional=False,
        default=None,
    )
    assert a.args == ["param"]
    assert a.description == "description"
    assert a.arg_name == "arg_name"
    assert a.type_name == "type_name"
    assert a.is_optional == False
    assert a.default == None



# Generated at 2022-06-21 11:39:15.796497
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string is not None
    assert doc_string.short_description is None
    assert doc_string.long_description is None
    assert doc_string.blank_after_short_description is False
    assert doc_string.blank_after_long_description is False
    assert doc_string.meta == []
    assert doc_string.params == []
    assert doc_string.raises == []
    assert doc_string.returns is None
    assert doc_string.deprecation is None



# Generated at 2022-06-21 11:39:17.048255
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated([], '', '')

# Generated at 2022-06-21 11:39:20.281978
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ["a", "b", "c"]
    test_description = "This is a test description."
    test_obj = DocstringMeta(test_args, test_description)
    assert test_obj.args == test_args
    assert test_obj.description == test_description



# Generated at 2022-06-21 11:39:40.174441
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass

# Generated at 2022-06-21 11:39:45.289037
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(["returns"], "description", "return type", False, "return")
    assert d.args == ["returns"]
    assert d.description == "description"
    assert d.type_name == "return type"
    assert d.is_generator == False
    assert d.return_name == "return"

# Generated at 2022-06-21 11:39:46.919225
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['parameter'], 'description', 'version')

# Generated at 2022-06-21 11:39:50.735542
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    
    docstring_meta = DocstringDeprecated(args=None, description=None, version=None)
    assert docstring_meta.args is None
    assert docstring_meta.description is None
    assert docstring_meta.version is None
    
test_DocstringDeprecated()


# Generated at 2022-06-21 11:40:02.507823
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test valid DocstringDeprecated
    args = ['deprecated']
    description = 'example'
    version = '2.0'
    result = DocstringDeprecated(args,description,version)
    expected = 'DocstringDeprecated(args=\'deprecated\',description=\'example\',version=\'2.0\')'
    assert (str(result) == expected), "DocstringDeprecated() does not work"

    # Test if args is missing passed into constructor
    args = None
    description = 'example'
    version = '2.0'
    result = DocstringDeprecated(args,description,version)
    expected = 'DocstringDeprecated(args=None,description=\'example\',version=\'2.0\')'
    assert (str(result) == expected), "DocstringDeprecated() does not work"

   

# Generated at 2022-06-21 11:40:06.179704
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(['param', 'arg'], 'a description')
    assert dm.args == ['param', 'arg']
    assert dm.description == 'a description'


# Generated at 2022-06-21 11:40:12.682537
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc_param = DocstringParam(['param'], 'desc', 'arg', 'type', True, 'None')
    assert(doc_param.arg_name == 'arg')
    assert(doc_param.type_name == 'type')
    assert(doc_param.is_optional == True)
    assert(doc_param.default == 'None')
    assert(doc_param.args == ['param'])
    assert(doc_param.description == 'desc')


# Generated at 2022-06-21 11:40:14.868430
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    temp = DocstringRaises(["1"], "test", "IndexError")
    assert temp.type_name == "IndexError"
    assert temp.description == "test"


# Generated at 2022-06-21 11:40:24.898593
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(':param', 'description')
    assert docstring.args == [':param']
    assert docstring.description == 'description'
    # Test different constructor args
    docstring2 = DocstringMeta([':param', ':param'], 'description')
    assert docstring2.args == [':param', ':param']
    assert docstring2.description == 'description'
    # Test different constructor args
    docstring3 = DocstringMeta([':param'], 'description')
    assert docstring3.args == [':param']
    assert docstring3.description == 'description'


# Generated at 2022-06-21 11:40:29.309585
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    
    d = DocstringMeta(args=['12','23','24','25'], description='This is a description')
    assert d.args == ['12','23','24','25']
    assert d.description == 'This is a description'


# Generated at 2022-06-21 11:41:14.558868
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["param"], "desc", "type", False, "name")


# Generated at 2022-06-21 11:41:16.601464
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    x = DocstringMeta(['param', 'arg'], 'description')
    assert x.args == ['param', 'arg']
    assert x.description == 'description'


# Generated at 2022-06-21 11:41:17.366686
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError()

# Generated at 2022-06-21 11:41:22.457738
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test 1
    args = [
        "param",
        "arg",
    ]
    description = "this is a test"
    ds_meta = DocstringMeta(args, description)
    assert ds_meta.args == args
    assert ds_meta.description == description
    # Test 2
    args = [
        "param",
        "arg",
    ]
    description = "this is a test"
    ds_meta = DocstringMeta(args, description)
    ds_meta.args[0] = "This has been changed"
    assert ds_meta.args == [
        "This has been changed",
        "arg",
    ]
    ds_meta.description = "this description has been changed"
    assert ds_meta.description == "this description has been changed"

# Unit

# Generated at 2022-06-21 11:41:28.433249
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta([":param", "list", "of", "args"], "description")
    check = DocstringMeta([":param", "list", "of", "args"], "description")
    if meta.args != check.args or meta.description != check.description:
        raise Exception("The constructor of class DocstringMeta does not work")
    print("The constructor of class DocstringMeta works")


# Generated at 2022-06-21 11:41:31.300323
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta([], "description")
    assert d.args == []
    assert d.description == "description"

if __name__ == "__main__":
    test_DocstringMeta()

# Generated at 2022-06-21 11:41:33.601036
# Unit test for constructor of class ParseError
def test_ParseError():
    """Build ParseError with the default constructor."""
    test_error = ParseError()
    print(test_error)


# Generated at 2022-06-21 11:41:40.908083
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test if constructor works."""
    try: raise ParseError("Hello world!")
    except ParseError as error: assert error.args[0] == "Hello world!"
    try: raise ParseError("Hello world!", "YUNO")
    except ParseError as error: assert error.args[0:2] == ("Hello world!", "YUNO")
    try: raise ParseError("Hello world!", "YUNO", "SUPRISE")
    except ParseError as error: assert error.args[0:3] == ("Hello world!", "YUNO", "SUPRISE")


# Generated at 2022-06-21 11:41:42.088670
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    d = DocstringDeprecated('xx_args', 'xx_description', 'xx_version')

# Generated at 2022-06-21 11:41:46.974347
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    foo = DocstringReturns(["return", "returns"], "description", None, False, None)
    assert foo.args == ["return", "returns"]
    assert foo.description == "description"
    assert foo.type_name == None
    assert foo.is_generator == False
    assert foo.return_name == None


# Generated at 2022-06-21 11:43:16.864530
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError) as excinfo:
        raise ParseError()
    assert excinfo.value.args[0] == "Parse error"



# Generated at 2022-06-21 11:43:21.078305
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(["return"], "this is bool", "bool")
    assert returns.args == ["return"]
    assert returns.type_name == "bool"
    assert returns.description == "this is bool"
    assert returns.is_generator == False


# Generated at 2022-06-21 11:43:29.798578
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg = 'arg1'
    description = 'description'
    type_name = 'int'
    is_optional = True
    default = '0'
    args = ['param', 'arg1', ':', 'type=']

    test = DocstringParam(args, description, arg, type_name, is_optional, default)
    assert test.args == args
    assert test.description == description
    assert test.arg_name == arg
    assert test.type_name == type_name
    assert test.is_optional == is_optional
    assert test.default == default

test_DocstringParam()

# # Unit test for constructor of class DocstringReturns

# Generated at 2022-06-21 11:43:31.173819
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError


# Generated at 2022-06-21 11:43:37.330443
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = "default"

    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-21 11:43:40.810312
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert(a)


"""
Helper functions used for parsing docstrings.

To add your own custom docstring meta information item, add a function that
returns a subclass of DocstringMeta.
"""


# Generated at 2022-06-21 11:43:43.566523
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args=["raises","Value","Error"]
    description="unknown"
    type_name="unknown"
    a=DocstringRaises(args,description,type_name)
    if type(a)==DocstringRaises:
        return 0

# Generated at 2022-06-21 11:43:45.470287
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises'], 'description', 'ValueError')

# Generated at 2022-06-21 11:43:46.393067
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert True

# Generated at 2022-06-21 11:43:54.538724
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_args = ["args"]
    test_description = "description"
    test_arg_name = "arg_name"
    test_type_name = "type_name"
    test_is_optional = True
    test_default = "default"

    param = DocstringParam(
        test_args,
        test_description,
        test_arg_name,
        test_type_name,
        test_is_optional,
        test_default,
    )

    assert param.args == test_args
    assert param.description == test_description
    assert param.arg_name == test_arg_name
    assert param.type_name == test_type_name
    assert param.is_optional == test_is_optional
    assert param.default == test_default
