

# Generated at 2022-06-11 21:15:47.776365
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Init a DocstringMeta object
    obj = DocstringMeta(["args"], "A test description")
    # assert that args is equal to ['args']
    assert obj.args[0] == 'args'
    # assert that description is equal to 'A test description'
    assert obj.description == 'A test description'


# Generated at 2022-06-11 21:15:55.534670
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringparam = DocstringParam(["param"], "description", "arg_name", "type_name", False, "default")
    assert docstringparam.args == ["param"]
    assert docstringparam.description == "description"
    assert docstringparam.arg_name == "arg_name"
    assert docstringparam.type_name == "type_name"
    assert docstringparam.is_optional == False
    assert docstringparam.default == "default"


# Generated at 2022-06-11 21:16:00.793934
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    class_ = DocstringDeprecated(['DeprecationWarning'], 'See: github.com/some/repo', '1.0')
    assert class_.args == ['DeprecationWarning']
    assert class_.description=='See: github.com/some/repo'
    assert class_.version == '1.0'

# Generated at 2022-06-11 21:16:01.663120
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError
    assert err

# Generated at 2022-06-11 21:16:06.595236
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []
    assert a.params == []
    assert a.raises == []
    assert a.returns is None
    assert a.deprecation is None


# Generated at 2022-06-11 21:16:10.946202
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    return DocstringParam(
        ["param", "type_name", "is_optional"],
        "This method is used for testing.",
        "arg",
        "type_name",
        True,
        "default",
    )


# Generated at 2022-06-11 21:16:17.107614
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        d = DocstringParam(["param","arg"], "desc", "arg_name", "type_name", True, "default")
    except Exception as e:
        print(e)
    assert d.args[0] == "param"
    assert d.args[1] == "arg"
    assert d.description == "desc"
    assert d.arg_name == "arg_name"
    assert d.type_name == "type_name"
    assert d.is_optional == True
    assert d.default == "default"


# Generated at 2022-06-11 21:16:23.798305
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description == None
    assert test_docstring.long_description == None
    assert test_docstring.blank_after_long_description == False
    assert test_docstring.blank_after_short_description == False
    assert test_docstring.meta == []

# Generated at 2022-06-11 21:16:27.637065
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['arg'], 'description', 'type_name' )
    assert test.description == 'description'
    assert test.args == ['arg']
    assert test.type_name == 'type_name'


# Generated at 2022-06-11 21:16:30.091992
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description") == DocstringMeta(["param"], "description")
    assert Docstring.__init__()


# Generated at 2022-06-11 21:16:42.750194
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-11 21:16:50.284401
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    Test function for Docstring class constructor
    """
    d = Docstring()
    try:
        assert d.short_description == None
        assert d.long_description == None
        assert d.blank_after_short_description == False
        assert d.blank_after_long_description == False
        assert d.meta == []
    except Exception:
        raise AssertionError("One of the properties of class Docstring is wrong.")
    print("Passed")


# Generated at 2022-06-11 21:16:53.605961
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=[], description="", arg_name="", type_name="", is_optional=True, default="")



# Generated at 2022-06-11 21:16:59.881483
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_DocstringReturns = DocstringReturns(["asd"], "asdasd", "a")
    assert test_DocstringReturns.args == ["asd"]
    assert test_DocstringReturns.description == "asdasd"
    assert test_DocstringReturns.type_name == "a"
    assert test_DocstringReturns.is_generator == False
    assert test_DocstringReturns.return_name == None


# Generated at 2022-06-11 21:17:03.031978
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
        import unittest.mock
        DocstringReturns(["args"], "descr", "type_name", False)
        DocstringReturns(["args"], ["descr"], ["type_name"], [False])


# Generated at 2022-06-11 21:17:10.599848
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    l = ["deprecated", "since 3.4"]
    s = None
    v = "3.4"
    test_docstring_deprecated = DocstringDeprecated(l, s, v)
    assert test_docstring_deprecated.args == l
    assert test_docstring_deprecated.description == s
    assert test_docstring_deprecated.version == v


# Generated at 2022-06-11 21:17:11.923303
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta([], "")



# Generated at 2022-06-11 21:17:15.419734
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(
        args=["version"], description="Not used anymore", version="1.0.0"
    )

# Generated at 2022-06-11 21:17:20.955432
# Unit test for constructor of class Docstring
def test_Docstring():
    #Expected: create a non-empty Docstring object
    assert len(Docstring().params) == 0
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert len(Docstring().meta) == 0


# Generated at 2022-06-11 21:17:26.151558
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    expect_args = ["raises"]
    expect_description = "This function raises an exception"
    expect_type_name = "Exception"
    target = DocstringRaises(expect_args, expect_description, expect_type_name)
    assert target.args == expect_args
    assert target.description == expect_description
    assert target.type_name == expect_type_name

# Generated at 2022-06-11 21:17:43.539727
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(
        args=["deprecated"],
        description="This function is deprecated",
        version="1.2.3",
    )

    assert docstring.args == ["deprecated"]
    assert docstring.description == "This function is deprecated"
    assert docstring.version == "1.2.3"

# Generated at 2022-06-11 21:17:52.734068
# Unit test for constructor of class Docstring
def test_Docstring():
    """Testing constructor method of class Docstring, by checking attributes of
    variable x."""

    x = Docstring()

    assert x.short_description is None
    assert x.long_description is None
    assert x.blank_after_short_description is False
    assert x.blank_after_long_description is False
    assert x.meta == []
    # test properties
    assert x.params == []
    assert x.raises == []
    assert x.returns is None
    assert x.deprecation is None



# Generated at 2022-06-11 21:17:56.085431
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ['args']
    test_description = 'description'
    test_DocstringMeta = DocstringMeta(test_args, test_description)
    assert test_DocstringMeta != None


# Generated at 2022-06-11 21:17:57.712445
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([], None, None)



# Generated at 2022-06-11 21:18:01.593668
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["arg"], "description", "type_name")
    assert d.args[0] == "arg"
    assert d.description == "description"
    assert d.type_name == "type_name"


# Generated at 2022-06-11 21:18:04.666187
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("error message")
    if pe.args[0] == "error message":
        print('test_ParseError passed')
    else:
        print('test_ParseError failed')


# Generated at 2022-06-11 21:18:08.318362
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(["args","arg"], "arg description")
    assert doc_meta.args == ["args", "arg"]
    assert doc_meta.description == "arg description"


# Generated at 2022-06-11 21:18:14.870245
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = "if something happens"
    type_name = "ValueError"

    x = DocstringRaises(args, description, type_name)
    assert x.args == ['raises', 'ValueError']
    assert x.description == "if something happens"
    assert x.type_name == "ValueError"

    print("DocstringRaises test successful.")


# Generated at 2022-06-11 21:18:17.912832
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args=['param']
    description="description"
    test = DocstringMeta(args,description)
    assert isinstance(test, DocstringMeta)

# Generated at 2022-06-11 21:18:29.021658
# Unit test for constructor of class Docstring
def test_Docstring():
    short = "This is short desc"
    long = "This is long desc"
    blank = False
    meta = []
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    docstring.short_description = short
    docstring.long_description = long
    docstring.blank_after_short_description = blank
    docstring.blank_after_long_description = blank
    docstring.meta = meta
    assert docstring.short_description == short
    assert docstring.long_description == long
    assert docstring.blank_after_short_description == blank
    assert docstring.blank_

# Generated at 2022-06-11 21:18:56.515298
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test whether DocstringDeprecated is correctly initialized."""
    d = DocstringDeprecated(["deprecated"], "description", "version")
    assert d.args == ["deprecated"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-11 21:18:57.377055
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("error message")
    assert str(e) == "error message"

# Generated at 2022-06-11 21:18:58.986507
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert type(DocstringMeta) == type


# Generated at 2022-06-11 21:19:01.103400
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam([], None, "arg", None, False, False)
    assert a.arg_name == "arg"

# Generated at 2022-06-11 21:19:06.463035
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of class Docstring."""
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-11 21:19:10.874219
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "testing", "description"]
    DocstringMeta_ = DocstringMeta(args, "description")
    assert DocstringMeta_.args == ["param", "testing", "description"]
    assert DocstringMeta_.description == "description"


# Generated at 2022-06-11 21:19:15.098253
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns"""
    returned_docstring_returns_object = DocstringReturns(['param', 'name'], 'Some input', 'int')
    assert returned_docstring_returns_object.args == ['param', 'name']
    assert returned_docstring_returns_object.description == 'Some input'
    assert returned_docstring_returns_object.type_name == 'int'


# Generated at 2022-06-11 21:19:16.909184
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(['deprecated'], 'vvvvvvvvvvvvvvvvvvv', '9')
    assert test != None

# Generated at 2022-06-11 21:19:26.181791
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print ("\nTesting DocstringRaises")
    aList = [":raises", "ValueError", ":", "if", "something", "happens"]
    aDescription = "if something happens"
    aTypeName = "ValueError"
    aRaises1 = DocstringRaises(aList, aDescription, aTypeName)
    assert aRaises1.args == aList
    assert aRaises1.description == aDescription
    assert aRaises1.type_name == aTypeName


# Generated at 2022-06-11 21:19:31.972257
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['a', 'b']
    description = 'this is something'
    type_name = 'string'
    is_generator = True
    return_name = 'abc'
    dr = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert dr.args == args
    assert dr.description == description
    assert dr.type_name == type_name
    assert dr.is_generator == is_generator
    assert dr.return_name == return_name


# Generated at 2022-06-11 21:20:02.724340
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a=DocstringMeta(["a","b"],"abc")
    assert (a.args==["a","b"])
    assert (a.description=="abc")


# Generated at 2022-06-11 21:20:05.797347
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['prueba'], 'description')
    assert a.description == "description"
    assert a.args[0] == "prueba"


# Generated at 2022-06-11 21:20:10.899449
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=['raises'], description="raise it", arg_name=None, type_name=None, is_optional=False, default=None)
    print(docstring_param.args)
    print(docstring_param.description)
    

# Generated at 2022-06-11 21:20:12.837470
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError()
    assert isinstance(parse_error, RuntimeError)


# Generated at 2022-06-11 21:20:22.972574
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # empty arguments
    docstring_returns = DocstringReturns([], None, None, False, None)
    # check variable declarations
    assert hasattr(docstring_returns, "args")
    assert hasattr(docstring_returns, "description")
    assert hasattr(docstring_returns, "type_name")
    assert hasattr(docstring_returns, "is_generator")
    assert hasattr(docstring_returns, "return_name")
    # check variable types
    assert isinstance(docstring_returns.args, list)
    assert isinstance(docstring_returns.description, str)
    assert isinstance(docstring_returns.type_name, str)
    assert isinstance(docstring_returns.is_generator, bool)

# Generated at 2022-06-11 21:20:30.083700
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["a"], "b")
    assert a.args == ["a"]
    assert a.description == "b"
    assert not hasattr(a, "type_name")
    assert not hasattr(a, "arg_name")
    assert not hasattr(a, "default")
    assert not hasattr(a, "is_generator")
    a = DocstringMeta(["a"], "b")


# Generated at 2022-06-11 21:20:36.151254
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    
    args = ['a', 'b', 'c']
    description = 'this is the description'
    type_name = 'yes'
    doc = DocstringRaises(args, description, type_name)
    assert doc.description == 'this is the description'
    assert doc.type_name == 'yes'


# Generated at 2022-06-11 21:20:42.272949
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg']
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = None

    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert param.args == args
    assert param.description == description
    assert param.arg_name == arg_name
    assert param.type_name == type_name
    assert param.is_optional == is_optional
    assert param.default == default


# Generated at 2022-06-11 21:20:53.825629
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_args = []
    test_description = "test"
    test_arg_name = "a"
    test_type_name = "type_name"
    test_is_optional = True
    test_default = "default"

    param = DocstringParam(test_args, test_description, test_arg_name, test_type_name, test_is_optional, test_default)

    assert param.args == test_args
    assert param.description == test_description
    assert param.arg_name == test_arg_name
    assert param.type_name == test_type_name
    assert param.is_optional == test_is_optional
    assert param.default == test_default


# Generated at 2022-06-11 21:20:57.251398
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
  args = ["a","list"]
  description = "to be deprecated"
  version = "0.0.1"
  d1 = DocstringDeprecated(args, description, version)
  assert d1.args == args
  assert d1.description == description
  assert d1.version == version


# Generated at 2022-06-11 21:21:59.199867
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(args = ['parameter'],
                       description = 'test',
                       arg_name = 'arg',
                       type_name = 'type',
                       is_optional = True,
                       default = 'default')


# Generated at 2022-06-11 21:22:00.137041
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises


# Generated at 2022-06-11 21:22:08.357940
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = "default"

    a = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert a.args == ["param"]
    assert a.description == "description"
    assert a.arg_name == "arg_name"
    assert a.type_name == "type_name"
    assert a.is_optional == False
    assert a.default == "default"

# Generated at 2022-06-11 21:22:13.820258
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    D=DocstringDeprecated(["a","b"],"some desc", "some version")
    assert D.version == "some version"
    assert D.description == "some desc"


# Unit tests for constructor of class DocstringReturns

# Generated at 2022-06-11 21:22:16.749767
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise(ParseError("test ParseError"))
    except:
        return True
    return False



# Generated at 2022-06-11 21:22:18.205577
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated([], "", "")


# Generated at 2022-06-11 21:22:20.541509
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    assert ("test" == error.args[0])


# Generated at 2022-06-11 21:22:22.203074
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['returns'], 'description', 'type', 'is_generator', 'return_name')

# Generated at 2022-06-11 21:22:26.965295
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["parameter","arg"]
    description = "not optional"
    assert(DocstringMeta(args,description).args == ["parameter","arg"])
    assert(DocstringMeta(args,description).description == "not optional")


# Generated at 2022-06-11 21:22:28.691695
# Unit test for constructor of class ParseError
def test_ParseError():
    assert (str(ParseError("Unit test", ParseError)) == "Unit test")


# Generated at 2022-06-11 21:23:32.081745
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated1 = DocstringDeprecated(["deprecated"], "foo", "1")
    assert(DocstringDeprecated1.args == ["deprecated"])
    assert(DocstringDeprecated1.description == "foo")
    assert(DocstringDeprecated1.version == "1")


# Generated at 2022-06-11 21:23:34.133892
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d1 = DocstringReturns(
        args=["return", "returns", "ret", "ret"],
        description="",
        type_name=None,
        is_generator=False,
        return_name=None,
    )



# Generated at 2022-06-11 21:23:40.543509
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", False, "default")
    assert(a.args == ["param", "arg"])
    assert(a.description == "description")
    assert(a.arg_name == "arg_name")
    assert(a.type_name == "type_name")
    assert(a.is_optional == False)
    assert(a.default == "default")


# Generated at 2022-06-11 21:23:45.343263
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test message")
    except ParseError as e:
        assert str(e) == "Test message"


# Generated at 2022-06-11 21:23:50.876492
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []

    assert a.params == []
    assert a.raises == []
    assert a.returns == None
    assert a.deprecation == None



# Generated at 2022-06-11 21:23:54.669818
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
        raise AssertionError("Expected ParseError to be raised")
    except ParseError:
        pass
    except RuntimeError:
        raise AssertionError("Expected ParseError to be raised")


# Generated at 2022-06-11 21:23:56.148633
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)


# Generated at 2022-06-11 21:23:57.176300
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["a","b"],"c")

# Generated at 2022-06-11 21:24:02.710068
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["1"]
    description = None
    type_name = None
    is_generator = False
    return_name = None
    obj = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert obj.args == ["1"]
    assert obj.description is None
    assert obj.type_name is None
    assert obj.is_generator == False
    assert obj.return_name is None


# Generated at 2022-06-11 21:24:10.597640
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args_list = [
        ":param arg: description",
        ":raises ValueError: if something happens",
    ]
    desc_list = ["description", " if something happens"]
    for i in range(len(args_list)):
        a = DocstringMeta(args_list[i].split(), desc_list[i])
        assert a.args == args_list[i].split()
        assert a.description == desc_list[i]
