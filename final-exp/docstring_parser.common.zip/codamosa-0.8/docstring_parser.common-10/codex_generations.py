

# Generated at 2022-06-11 21:15:47.439906
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:15:53.031951
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(["return", "returns"], "The return value.", "int")
    assert d.args == ["return", "returns"]
    assert d.description == "The return value."
    assert d.type_name == "int"
    assert d.is_generator is False
    assert d.return_name is None


# Generated at 2022-06-11 21:15:55.492511
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError("failed")
    assert x.args[0] == "failed"


# Generated at 2022-06-11 21:16:01.331528
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"], "description", "type_name", True, "return_name")
    DocstringReturns(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"], "description", "type_name", False)

# Generated at 2022-06-11 21:16:04.805824
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    instance = DocstringParam(["param"], "description", "arg_name", "type_name", "is_optional", "default")
    assert instance.arg_name == "arg_name"
    assert instance.is_optional == "is_optional"


# Generated at 2022-06-11 21:16:08.869707
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.long_description == None
    assert d.meta == []
    assert d.short_description == None



# Generated at 2022-06-11 21:16:12.736497
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["args"]
    desc = "desc"
    ver = "ver"
    d = DocstringDeprecated(args, desc, ver)
    assert d.args == ["args"]
    assert d.description == "desc"
    assert d.version == "ver"


# Generated at 2022-06-11 21:16:18.746602
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "The description of the parameter"
    arg_name = "arg"
    type_name = "int"
    is_optional = False
    default = "False"
    instance = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert instance.args == ["param", "arg", "description"]
    assert instance.description == "The description of the parameter"
    assert instance.arg_name == "arg"
    assert instance.type_name == "int"
    assert instance.is_optional == False
    assert instance.default == "False"


# Generated at 2022-06-11 21:16:25.718950
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for the constructor of class DocstringRaises"""
    ds = DocstringRaises(args=[], description="test", type_name="test")
    assert(ds.type_name == "test")
    assert(ds.args == [])
    assert(ds.description == "test")

# Generated at 2022-06-11 21:16:27.545112
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None

# Generated at 2022-06-11 21:16:39.865619
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert not ds.blank_after_short_description
    assert not ds.blank_after_long_description
    assert len(ds.meta) == 0
    assert len(ds.params) == 0
    assert len(ds.raises) == 0
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-11 21:16:44.038272
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    asdf = DocstringReturns(['asdf'], 'asdf', 'asdf', True)
    asdf.args
    asdf.description
    asdf.type_name
    asdf.is_generator
    asdf.return_name

# Generated at 2022-06-11 21:16:56.525910
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("Testing constructor of class DocstringParam...")
    test_args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    test_description = "Evaluates a boolean expression"
    test_arg_name = "expression"
    test_type_name = "bool"
    test_is_optional = True
    test_default = ""
    test_DocstringParam = DocstringParam(test_args, test_description, test_arg_name, test_type_name, test_is_optional, test_default)
    assert test_DocstringParam.args == test_args
    assert test_DocstringParam.description == test_description
    assert test_DocstringParam.arg_name == test_arg_name
    assert test_DocstringParam.type_name == test_type_name

# Generated at 2022-06-11 21:16:58.461960
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([], "")
    assert a.args == []
    assert a.description == ""


# Generated at 2022-06-11 21:17:03.522957
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = "raises TypeError"
    type_name = "TypeError"
    description = "Raise TypeError if ..."
    test_DocstringRaises = DocstringRaises(args, description, type_name)
    assert test_DocstringRaises.args == "raises TypeError"
    assert test_DocstringRaises.description == "Raise TypeError if ..."
    assert test_DocstringRaises.type_name == "TypeError"


# Generated at 2022-06-11 21:17:04.867340
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    pass

# Generated at 2022-06-11 21:17:10.556331
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['deprecated'], "First line with just one word in short_desc", "1.1.1")
    assert a.args == ['deprecated']
    assert a.description == "First line with just one word in short_desc"
    assert a.version == "1.1.1"


# Generated at 2022-06-11 21:17:14.117407
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Config parameters
    args = ["arg"]
    description = "description"
    # Run Test
    DocstringMeta(args, description)



# Generated at 2022-06-11 21:17:20.159046
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["arg", "function", "argument", "param", "int"]
    description = "This is the description."
    arg_name = "arg"
    type_name = "int"
    is_optional = False
    default = 0
    test_object = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert test_object.args == args
    assert test_object.description == description
    assert test_object.arg_name == arg_name
    assert test_object.type_name == type_name
    assert test_object.is_optional == is_optional
    assert test_object.default == default


# Generated at 2022-06-11 21:17:26.834923
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns is None
    assert ds.deprecation is None


# Generated at 2022-06-11 21:17:35.251328
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(
        "returns", "description", "return_name", "type_name", True, True)
    d.args == "returns"
    d.description == "description"
    # ...
    # add the others ...
    # ...

# Generated at 2022-06-11 21:17:37.623927
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("hi")

# Unit tests for class DocstringMeta

# Generated at 2022-06-11 21:17:40.324455
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], None, None).args == []
    assert DocstringDeprecated([], None, None).description == None
    assert DocstringDeprecated([], None, None).version == None

# Generated at 2022-06-11 21:17:45.133675
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    Tester method for testing the constructors of Docstring
    """
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []

# Generated at 2022-06-11 21:17:47.859251
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "alo"
    err = ParseError(msg)
    assert err.args[0] == msg



# Generated at 2022-06-11 21:17:50.504741
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(
        args = ["raises", "ValueError"],
        description = "If something happens",
        type_name = "ValueError"
    )

# Generated at 2022-06-11 21:17:55.079807
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dsr = DocstringRaises('a', 'b', 'c')
    assert dsr.args == 'a'
    assert dsr.description == 'b'
    assert dsr.type_name == 'c'


# Generated at 2022-06-11 21:18:00.249380
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-11 21:18:05.540452
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert isinstance(DocstringDeprecated(["deprecated"], "is deprecated", "3.3"), DocstringDeprecated)
    assert DocstringDeprecated(["deprecated"], "is deprecated", "3.3").args[0] == "deprecated"
    assert DocstringDeprecated(["deprecated"], "is deprecated", "3.3").description == "is deprecated"
    assert DocstringDeprecated(["deprecated"], "is deprecated", "3.3").version == "3.3"


# Generated at 2022-06-11 21:18:12.543959
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(['param'], 'the parameter', 'arg', 'str',
                               False, 'hello')
    assert docstring.args == ['param']
    assert docstring.description == 'the parameter'
    assert docstring.arg_name == 'arg'
    assert docstring.type_name == 'str'
    assert docstring.is_optional == False
    assert docstring.default == 'hello'


# Generated at 2022-06-11 21:18:22.205025
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("")
    except ParseError:
        pass


# Generated at 2022-06-11 21:18:26.562318
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d_meta = DocstringMeta(["param"], "This is a parameter.")
    assert d_meta.args == ["param"]
    assert d_meta.description == "This is a parameter."


# Generated at 2022-06-11 21:18:31.079827
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "testing"
    type_name = "type"
    returns = DocstringReturns(args, description, type_name, is_generator=False)
    assert returns.type_name == type_name
    assert returns.args == []
    assert returns.description == "testing"

# Generated at 2022-06-11 21:18:39.182869
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["Hello", "World"]
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = "is_optional"
    default = "default"
    meta = DocstringParam(args, None, arg_name=arg_name, type_name=type_name, is_optional=is_optional, default=default)
    assert meta.args == args
    assert meta.description == None
    assert meta.arg_name == arg_name
    assert meta.type_name == type_name
    assert meta.is_optional == is_optional
    assert meta.default == default


# Generated at 2022-06-11 21:18:46.201976
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    my_args = []
    my_desc = ""
    my_type = "type"
    my_is_generator = True
    my_return_name = "None"
    my_instance = DocstringReturns(my_args, my_desc, my_type, my_is_generator, my_return_name)
    assert my_instance.description == my_desc
    assert my_instance.type_name == my_type
    assert my_instance.is_generator == my_is_generator
    assert my_instance.return_name == my_return_name


# Generated at 2022-06-11 21:18:47.366533
# Unit test for constructor of class Docstring
def test_Docstring():
    desc = Docstring()
    assert desc is not None


# Generated at 2022-06-11 21:18:50.184651
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta([], '')
    raise AssertionError


# Generated at 2022-06-11 21:18:51.590990
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d is not None


# Generated at 2022-06-11 21:19:00.355165
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(["a", "b", "c"], "d", "e", "f", True, "g")
    assert(repr(d) == "DocstringParam(args=['a', 'b', 'c'], description='d', arg_name='e', type_name='f', is_optional=True, default='g')")
    assert(d.args == ["a", "b", "c"])
    assert(d.arg_name == "e")
    assert(d.description == "d")
    assert(d.default == "g")
    assert(d.is_optional == True)
    assert(d.type_name == "f")
    d.arg_name = "e'"
    assert(d.arg_name == "e'")


# Generated at 2022-06-11 21:19:06.063796
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	args = ["args", "kwargs"]
	description = "description"
	type_name = "int"
	assert args == DocstringRaises(args, description, type_name).args
	assert description == DocstringRaises(args, description, type_name).description
	assert type_name == DocstringRaises(args, description, type_name).type_name


# Generated at 2022-06-11 21:19:25.699455
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    my_doc = DocstringMeta(args = ['param'], description = "description")
    assert(my_doc.args == ["param"])
    assert(my_doc.description == "description")


# Generated at 2022-06-11 21:19:27.689504
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(["returns"], "hello", None, False)
    assert DocstringReturns(["returns"], "hello", "unknown", False)


# Generated at 2022-06-11 21:19:32.944905
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(['returns'], 'a string', 'str', False)
    assert returns.type_name == 'str'
    assert returns.args == ['returns']
    assert returns.description == 'a string'
    assert not returns.is_generator
    

# Generated at 2022-06-11 21:19:37.006169
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "An error occurred while parsing the docstring."
    parse_error = ParseError(msg)
    assert parse_error.args[0] == msg
    print('Success: ParseError constructor')


# Generated at 2022-06-11 21:19:42.441493
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []

# Test initialization of Docstring via constructor Docstring()
# The Docstring is initialized with the required values

# Generated at 2022-06-11 21:19:46.050304
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = ""
    try:
        DocstringMeta(args, description)
    except TypeError:
        raise ParseError


# Generated at 2022-06-11 21:19:47.045631
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta1 = DocstringMeta(['args'], 'description')
    docstring_meta1.args
    docstring_meta1.description

# Generated at 2022-06-11 21:19:48.881517
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("foo")
    assert(str(err) == "foo")

# Generated at 2022-06-11 21:19:54.132489
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1: Basic working
    param_1 = DocstringParam(
        ["param"], "a new param", "arg", "int", False, None
    )
    assert param_1.is_optional == False

    # Test 2: Another basic working
    param_2 = DocstringParam(
        ["param"], "another new param", "arg", "int", True, "None"
    )
    assert param_2.is_optional == True


# Generated at 2022-06-11 21:20:01.703700
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Constructor of DocstringReturns
    args = ["args"]
    description = "description"
    type_name = "type_name"
    is_generator = True

    docstringReturns = DocstringReturns(args, description, type_name, is_generator)
    assert docstringReturns != None
    assert docstringReturns.type_name == type_name
    assert docstringReturns.is_generator == is_generator
    assert docstringReturns.description == description
    assert docstringReturns.args == args


# Generated at 2022-06-11 21:20:37.321018
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=["parameter"], description="bla bla", arg_name="x", type_name="int", is_optional=True,
                   default="-1")
    DocstringParam(args=["parameter"], description="bla bla", arg_name="x", type_name="int", is_optional=False,
                   default=None)


# Generated at 2022-06-11 21:20:39.240405
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(
        args=["Args"],
        description=["desc"],
        type_name="TypeName",
    )

# Generated at 2022-06-11 21:20:40.539421
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(["arg"], "desc", "str")
    assert doc.args == ["arg"]

# Generated at 2022-06-11 21:20:49.737749
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(['param'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert docstring != None
    assert isinstance(docstring, DocstringParam)
    assert docstring.args == ['param']
    assert docstring.description == 'description'
    assert docstring.arg_name == 'arg_name'
    assert docstring.type_name == 'type_name'
    assert docstring.is_optional == 'is_optional'
    assert docstring.default == 'default'


# Generated at 2022-06-11 21:20:51.551930
# Unit test for constructor of class ParseError
def test_ParseError():
    assert(ParseError('').args == (''))


# Generated at 2022-06-11 21:20:53.162561
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("")
    assert err is not None

# Generated at 2022-06-11 21:20:54.672324
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["arg"], "description")
    assert meta.args == ["arg"]
    assert meta.description == "description"


# Generated at 2022-06-11 21:20:57.251238
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	
	assert DocstringDeprecated(["deprecated", "deprecation"]).args[0] == "deprecated"
	assert DocstringDeprecated(["deprecated", "deprecation"]).args[1] == "deprecation"

# Generated at 2022-06-11 21:20:58.384947
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("sample")
    except ParseError:
        pass


# Generated at 2022-06-11 21:21:03.178445
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=['param'], description='description', arg_name='arg', type_name='type_name', is_optional=True, default='None')
    assert docstring_param.type_name == 'type_name'
    assert docstring_param.is_optional == True

# Generated at 2022-06-11 21:22:04.641616
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "", "")

# Generated at 2022-06-11 21:22:07.010841
# Unit test for constructor of class ParseError
def test_ParseError():
    foo =ParseError("Example of ParseError")
    assert foo.args == ("Example of ParseError",)


# Generated at 2022-06-11 21:22:15.695532
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-11 21:22:18.179335
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(['args'], 'description')
    assert dm.args == ['args']
    assert dm.description == 'description'


# Generated at 2022-06-11 21:22:20.456165
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    myObject = DocstringMeta(['arg'], "description")
    assert myObject.args[0] == 'arg'
    assert myObject.description == 'description'


# Generated at 2022-06-11 21:22:30.236888
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args: List[str] = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description: str = "description"
    type_name: Optional[str] = None
    return_name: Optional[str] = 'return_name'
    is_generator: bool = False

    docstringReturn = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstringReturn.args == args
    assert docstringReturn.description == description
    assert docstringReturn.type_name == type_name
    assert docstringReturn.is_generator == is_generator
    assert docstringReturn.return_name == return_name
    

# Generated at 2022-06-11 21:22:34.679466
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None



# Generated at 2022-06-11 21:22:36.657812
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("test error")
    assert (a.args[0] == "test error")


# Generated at 2022-06-11 21:22:44.378151
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp=DocstringParam(['param'], "This is the description of the parameter" , "arg", "str", None, None)
    assert dp.args==['param']
    assert dp.arg_name=="arg"
    assert dp.type_name=="str"
    assert dp.is_optional == None
    assert dp.default == None
    assert dp.description=="This is the description of the parameter"


# Generated at 2022-06-11 21:22:48.886143
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    testVar = DocstringReturns(["returns"], "test", None, False)
    assert (testVar.args == ["returns"]) and (testVar.description == "test") and (testVar.type_name is None) and (testVar.is_generator == False) and (testVar.return_name is None)


# Generated at 2022-06-11 21:25:02.880648
# Unit test for constructor of class DocstringParam

# Generated at 2022-06-11 21:25:04.849383
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["args"], None, "version")
    print(d.description)
    assert d.description is None


# Generated at 2022-06-11 21:25:06.816963
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(isinstance(Docstring(), Docstring))



# Generated at 2022-06-11 21:25:09.925333
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated("args", "description", "version")
    assert d.args == "args"
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-11 21:25:20.435936
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds_raises_string = ":raises Exception: if something happens"
    ds_raises_string2 = ":raises Exception: else"
    ds_raises_string3 = ":raises ValueError: if something happens"
    ds_raises_string4 = ":raises ValueError: else"
    ds_raises_string5 = ":raises ValueError:"
        
    ds_raises_args = ds_raises_string.split(":")
    ds_raises_args2 = ds_raises_string2.split(":")
    ds_raises_args3 = ds_raises_string3.split(":")
    ds_raises_args4 = ds_raises_string4.split(":")
    ds_

# Generated at 2022-06-11 21:25:24.904328
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(args=['test', 'test1'], description='test description')
    assert meta.args == ['test', 'test1']
    assert meta.description == 'test description'
    assert meta.args == ['test', 'test1']
    assert meta.description == 'test description'

# Generated at 2022-06-11 21:25:30.219832
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docMeta1 = DocstringMeta(['args1', 'args2'], 'description')
    assert docMeta1.args == ['args1', 'args2']
    assert docMeta1.description == 'description'
    assert docMeta1.__str__() == 'DocstringMeta(' + str(docMeta1.args) + ', ' + docMeta1.description + ')'
    assert docMeta1.__repr__() == 'DocstringMeta(' + str(docMeta1.args) + ', ' + docMeta1.description + ')'
    return


# Generated at 2022-06-11 21:25:31.599158
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["a", "b"], "description", "typeName")

# Generated at 2022-06-11 21:25:33.813077
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string.short_description is None
    assert doc_string.long_description is None
    assert doc_string.blank_after_short_description is False
    assert doc_string.blank_after_long_description is False
    assert doc_string.meta == []


# Generated at 2022-06-11 21:25:37.394559
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=['parameter', 'arg'], description='description', arg_name='arg', type_name='Optional[str]', is_optional=True, default='None')
    assert docstring_param is not None