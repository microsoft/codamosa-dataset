

# Generated at 2022-06-11 21:15:46.611314
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "description").description == "description"
    assert DocstringMeta(["arg"], "description").args == ["arg"]


# Generated at 2022-06-11 21:15:52.731720
# Unit test for constructor of class Docstring
def test_Docstring():
    '''Função para testar a classe Docstring.'''
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert not docstring.meta


# Generated at 2022-06-11 21:15:56.895421
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(
        args=[],
        description=None,
        type_name=None,
        is_generator=False,
        return_name=None,
    )
    assert type(x.type_name) == type(None)




# Generated at 2022-06-11 21:15:59.974039
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-11 21:16:01.549782
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        assert True
    except:
        assert False


# Generated at 2022-06-11 21:16:05.360917
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0



# Generated at 2022-06-11 21:16:11.105451
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = "A description"
    version = "1.0.0"

    docstringDeprecated = DocstringDeprecated(args, description, version)

    assert docstringDeprecated.args == args
    assert docstringDeprecated.description == description
    assert docstringDeprecated.version == version


# Generated at 2022-06-11 21:16:13.373478
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_test = DocstringMeta(["param"], "description")
    print(docstring_meta_test.description)


# Generated at 2022-06-11 21:16:15.253646
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test class ParseError."""
    err = ParseError("Test")
    assert str(err) == "Test"



# Generated at 2022-06-11 21:16:26.028115
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "dsadasdasd"
    type_name = "str"
    is_generator = False
    return_name = "dasdasd"
    doc_obj_returns = DocstringReturns(args,description,type_name,is_generator,return_name)
    print(doc_obj_returns.description)
    print(doc_obj_returns.type_name)
    print(doc_obj_returns.return_name)
    print(doc_obj_returns.args)
    print(doc_obj_returns.is_generator)


# Generated at 2022-06-11 21:16:32.234006
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "This is a description")
    assert d.args[0] == "param"
    assert d.description == "This is a description"


# Generated at 2022-06-11 21:16:36.928096
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta
    #assertEqual(a[0], "args")
    #assertEqual(a[1], "description")


# Generated at 2022-06-11 21:16:37.935397
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], "", "")

# Generated at 2022-06-11 21:16:45.147584
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
        # test_1
        a = DocstringRaises(
            args=['param', 'attribute', 'arg', 'key'],
            arg_name='arg',
            description='description',
            type_name='type_name'
        )
        assert a.args == ['param', 'attribute', 'arg', 'key']
        assert a.arg_name == 'arg'
        assert a.description == 'description'
        assert a.type_name == 'type_name'
        

# Generated at 2022-06-11 21:16:48.362899
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    x = DocstringMeta(args=['arg'], description="description")
    assert x.args == ['arg']
    assert x.description == "description"



# Generated at 2022-06-11 21:16:54.231846
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []

# Test for property 'params' of class Docstring

# Generated at 2022-06-11 21:16:55.659923
# Unit test for constructor of class ParseError
def test_ParseError():
    assert str(ParseError()) == ''


# Generated at 2022-06-11 21:16:58.733650
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    line = ":para arg: description"
    em = DocstringMeta(":para arg: description", "description")
    assert em.args == [":para arg: description"]
    assert em.description == "description"


# Generated at 2022-06-11 21:17:06.588403
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test case #1
    arg = ["param"]
    description = ["description"]
    DocstringMetaTest = DocstringMeta(arg, description)
    assert DocstringMetaTest.args == arg
    assert DocstringMetaTest.description == description

    # Test case #2
    arg = ["param", "other"]
    description = ["description"]
    DocstringMetaTest = DocstringMeta(arg, description)
    assert DocstringMetaTest.args == arg
    assert DocstringMetaTest.description == description

    # Test case #3
    arg = ["param"]
    description = ["description", "other"]
    DocstringMetaTest = DocstringMeta(arg, description)
    assert DocstringMetaTest.args == arg
    assert DocstringMetaTest.description == description



# Generated at 2022-06-11 21:17:09.730009
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg_name", "type_name", False, "this is default")




# Generated at 2022-06-11 21:17:25.777756
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated"""
    doc_string_meta_arg_list = ["deprecated"]
    doc_string_meta_description = "This function is deprecated"
    doc_string_meta_version = "v5.6"
    construct_DocstringDeprecated = DocstringDeprecated(doc_string_meta_arg_list, doc_string_meta_description, doc_string_meta_version)
    assert construct_DocstringDeprecated.args == ["deprecated"]
    assert construct_DocstringDeprecated.description == "This function is deprecated"
    assert construct_DocstringDeprecated.version == "v5.6"


# Generated at 2022-06-11 21:17:30.876642
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Set up parameters
    args = ["deprecated"]
    description = "This function is deprecated. Use another function."
    version = "1.6"
    # Assert it is an instance of DocstringDeprecated
    assert (isinstance(DocstringDeprecated(args, description, version), DocstringDeprecated))


# Generated at 2022-06-11 21:17:33.312119
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=["a", "b"], description="desc", version="v")


# Generated at 2022-06-11 21:17:37.359057
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    t1 = DocstringRaises(["a","b"], "ValueError", "ValueError")
    assert t1.type_name == "ValueError"
    assert t1.description == "ValueError"
    assert t1.args == ["a","b"]


# Generated at 2022-06-11 21:17:41.435022
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = ''
    type_name = ''
    new = DocstringRaises(args, description, type_name)
    assert new.args == []
    assert new.description == ''
    assert new.type_name == ''
    print("Unit test for constructor of class DocstringRaises finished.\n")


# Generated at 2022-06-11 21:17:44.087621
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([":param"], "description").args == [":param"]
    assert DocstringMeta([":param"], "description").description == "description"


# Unit tests for constructor of class DocstringParam

# Generated at 2022-06-11 21:17:49.920755
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [":", "return", ":"]
    type_name = "int"
    description = ""
    is_generator = False
    foo = DocstringReturns(args, description, type_name, is_generator)
    print (foo.description)
    print (foo.args)
    print (foo.type_name)



# Generated at 2022-06-11 21:17:56.655084
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    a = DocstringReturns(['a', 'b', 'c'], 'd', 'e', True)
    assert a.args == ['a', 'b', 'c']
    assert a.description == 'd'
    assert a.type_name == 'e'
    assert a.is_generator == True
    return a

# Generated at 2022-06-11 21:17:59.828083
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error Message")
    except:
        pass


# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-11 21:18:01.856228
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta([], '')
    assert dm.args == []
    assert dm.description == ''


# Generated at 2022-06-11 21:18:19.179140
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta."""
    test = DocstringMeta([":param"], "description")
    assert test.args == [":param"]
    assert test.description == "description"



# Generated at 2022-06-11 21:18:20.995756
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['param'], 'description of the parameter', 'the type of the parameter', True)

# Generated at 2022-06-11 21:18:26.698258
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj = DocstringRaises(
        ["raises"], "description", "TypeError"
    )
    assert isinstance(obj, DocstringRaises)
    assert obj.args == ["raises"]
    assert obj.description == "description"
    assert obj.type_name == "TypeError"


# Generated at 2022-06-11 21:18:29.195588
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as err:
        assert str(err) == "test"

# Generated at 2022-06-11 21:18:34.629315
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    #Arrange
    args = []
    description = None
    version = None
    ds = DocstringDeprecated(args, description, version)
    #Act
    #Assert
    assert str(ds.args) == "[]"
    assert str(ds.description) == 'None'
    assert str(ds.version) == 'None'

# Generated at 2022-06-11 21:18:40.197183
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringparam = DocstringParam(['param','arg','type'], 'Describes the argument', 'arg', 'int', 'T.bool','T.NoneType')
    assert docstringparam.args == ['param','arg','type']
    assert docstringparam.description == 'Describes the argument'
    assert docstringparam.arg_name == 'arg'
    assert docstringparam.type_name == 'int'
    assert docstringparam.is_optional == 'T.bool'
    assert docstringparam.default == 'T.NoneType'


# Generated at 2022-06-11 21:18:42.107627
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(["arg"], "description", "version")
    assert obj != None



# Generated at 2022-06-11 21:18:46.711227
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None  # type: T.Optional[str]
    assert ds.long_description == None  # type: T.Optional[str]
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []  # type: T.List[DocstringMeta]
    assert ds.params == []



# Generated at 2022-06-11 21:18:54.694951
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        args=['param'],
        description='some description',
        arg_name='arg',
        type_name='int',
        is_optional=False,
        default='40'
    )
    assert param.args == ['param']
    assert param.description == 'some description'
    assert param.arg_name == 'arg'
    assert param.type_name == 'int'
    assert param.is_optional == False
    assert param.default == '40'


# Generated at 2022-06-11 21:18:55.456788
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises("arg", "description", "type_name")


# Generated at 2022-06-11 21:19:25.848760
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()
    assert(x.short_description == None)



# Generated at 2022-06-11 21:19:27.522729
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringMeta = DocstringDeprecated([], "", "")
    assert type(docstringMeta) == DocstringDeprecated



# Generated at 2022-06-11 21:19:32.927145
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    my_docstring_param = DocstringParam(
        ["optional"], "description", "arg_name", "arg_type_name", True, "instance"
    )
    assert my_docstring_param.description == "description"
    assert my_docstring_param.args == ["optional"]
    assert my_docstring_param.arg_name == "arg_name"
    assert my_docstring_param.type_name == "arg_type_name"
    assert my_docstring_param.is_optional == True
    assert my_docstring_param.default == "instance"


# Generated at 2022-06-11 21:19:36.474544
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    with pytest.raises(TypeError):
        DocstringMeta()
    assert DocstringMeta([1, 2, 3], 'Docstr')



# Generated at 2022-06-11 21:19:40.784043
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-11 21:19:46.001176
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    deprecated_docstring = DocstringDeprecated(args=['param'], description='description', version='1.1')

    assert deprecated_docstring.args == ['param']
    assert deprecated_docstring.description == 'description'
    assert deprecated_docstring.version == '1.1'



# Generated at 2022-06-11 21:19:52.873533
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # TEST 1
    import doctest
    doctest.testmod()

    # TEST 2
    print('Test 2: "DocstringParam" constructor')
    args = ['arg']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'None'

    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    print(' constructor', param)


# Generated at 2022-06-11 21:20:01.418494
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor for DocstringDeprecated"""
    test_list = ['deprecated', 'Since 2.0.0', 'Use newer function']
    test_description = 'Use newer function'
    test_version = '2.0.0'
    docstring = DocstringDeprecated(test_list, test_description, test_version)
    assert isinstance(docstring, DocstringMeta)
    assert isinstance(docstring, DocstringDeprecated)
    assert docstring.args == test_list
    assert docstring.description == test_description
    assert docstring.version == test_version



# Generated at 2022-06-11 21:20:13.082718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """
    Test to check if the instantiation of class DocstringParam produces the expected output.

    The expected output is the list of attributes of class DocstringParam.
    """

    # Initialize the attributes of class DocstringParam
    args = None
    description = None
    arg_name = None
    type_name = None
    is_optional = None
    default = None

    # Initialize an object of class DocstringParam and check if the class attributes are correctly set
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert isinstance(docstring_param.args, None.__class__)
    assert isinstance(docstring_param.description, None.__class__)
    assert isinstance(docstring_param.arg_name, None.__class__)
   

# Generated at 2022-06-11 21:20:15.950252
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(
        args = ['param'],
        description = 'The parameter of the test function.',
        arg_name = 'arg',
        type_name = None,
        is_optional = False,
        default = None,
    )

    assert dp.args == ['param']
    assert dp.description == 'The parameter of the test function.'
    assert dp.arg_name == 'arg'
    assert dp.type_name is None
    assert dp.is_optional is False
    assert dp.default is None



# Generated at 2022-06-11 21:21:17.046960
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(["deprecated"], "Description of deprecated.", "1.0")
    assert isinstance(ds,DocstringDeprecated)
    assert ds.description == "Description of deprecated."

# Generated at 2022-06-11 21:21:21.748320
# Unit test for constructor of class Docstring
def test_Docstring():
        """Test constructor of class Docstring."""
        doc = Docstring()
        # assert doc.short_description == None
        # assert doc.long_description == None
        # assert doc.blank_after_short_description == False
        # assert doc.blank_after_long_description == False
        # assert doc.meta == []

# Generated at 2022-06-11 21:21:33.111460
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(
        args=['param', 'arg', 'argument', 'attribute', 'key'],
        description='description', arg_name='arg_name',
        type_name='str', is_optional=True, default='None'
    )
    for arg in a.args:
        if not arg in PARAM_KEYWORDS:
            raise ValueError('Not in PARAM_KEYWORDS')
    assert a.description == 'description'
    assert a.arg_name == 'arg_name'
    assert a.type_name == 'str'
    assert a.is_optional == True
    assert a.default == 'None'


# Generated at 2022-06-11 21:21:40.030997
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    params = ['', '', '', '', '']
    description = None
    type_name = 'str'
    is_generator = True
    return_name = 'some'
    returns = DocstringReturns(params, description, type_name, is_generator, return_name)
    assert(returns.type_name == 'str')
    assert(returns.is_generator == True)
    assert(returns.return_name == 'some')

test_DocstringReturns()

# Generated at 2022-06-11 21:21:42.665143
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(["asd", "asd"], None, None)
    assert isinstance(s, DocstringDeprecated)


# Generated at 2022-06-11 21:21:49.088421
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.meta == []
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-11 21:21:59.545241
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = [
        {'args': ['parameter'],
        'description': 'description of parameter'},
        {'args': ['return', 'returns'],
        'description': 'description of return'}
    ]
    
    answer = [
        DocstringParam(['parameter'], 'description of parameter', 'parameter', None, None, None),
        DocstringReturns(['return', 'returns'], 'description of return', None, False)
    ]

    for i in range(2):
        assert isinstance(docstring[i], type(answer[i]))
        assert docstring[i].args == answer[i].args
        assert docstring[i].description == answer[i].description


# Generated at 2022-06-11 21:22:01.945841
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['deprecated'], 'sample', '1.0.0')

# Generated at 2022-06-11 21:22:03.410174
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring


# Generated at 2022-06-11 21:22:07.009871
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = "changement de version"
    version = "1.0"

    docstring = DocstringDeprecated(args, description, version)
    print(docstring)

test_DocstringDeprecated()

# Generated at 2022-06-11 21:24:05.123314
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring() != None



# Generated at 2022-06-11 21:24:09.452321
# Unit test for constructor of class Docstring
def test_Docstring():

    new = Docstring()

    assert new.short_description == None
    assert new.long_description == None
    assert new.blank_after_short_description == False
    assert new.blank_after_long_description == False
    assert new.meta == []



# Generated at 2022-06-11 21:24:14.632432
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    

# Generated at 2022-06-11 21:24:17.965264
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test = DocstringMeta(args = ['a', 'b', 'c'], description = 'Description example')
    assert test.args == ['a', 'b', 'c']
    assert test.description == 'Description example'


# Generated at 2022-06-11 21:24:21.529471
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args=[":deprecated:"], description="description", version="version")
    assert d.args == [":deprecated:"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-11 21:24:28.509797
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['parameter', 'arg', 'keyword', 'arg1']
    description = 'an argument'
    arg_name = 'arg1'
    type_name = None
    is_optional = None
    default = None
    assert DocstringParam(args, description, arg_name, type_name,
                     is_optional, default) is not None


# Generated at 2022-06-11 21:24:33.962229
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dsd = DocstringDeprecated(args=['a', 'b'], description='desc', version='v')
    assert dsd.args == ['a', 'b']
    assert dsd.description == 'desc'
    assert dsd.version == 'v'
    print('DocstringDeprecated test passed')


# Generated at 2022-06-11 21:24:38.215138
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta = DocstringMeta([], "This is a docstring")

    assert docstringMeta.args == []
    assert docstringMeta.description == "This is a docstring"



# Generated at 2022-06-11 21:24:40.713633
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error")
    except RuntimeError as err:
        assert str(err) == "error"


# Generated at 2022-06-11 21:24:45.306411
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg1", ":type", "int", ":default", "10"]
    description = "The description"
   
    test_docstr_param = DocstringParam(args, description, 'arg1', 'int', True, '10')

