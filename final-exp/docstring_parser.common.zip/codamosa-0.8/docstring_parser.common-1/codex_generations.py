

# Generated at 2022-06-11 21:15:48.229266
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = ""
    type_name = ""
    a = DocstringRaises(args, description, type_name)
    assert a.args == []
    assert a.description == ""
    assert a.type_name == ""

# Generated at 2022-06-11 21:15:52.322453
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    "Run the tests."
    args = ['param', 'arg', 'description']
    test_object = DocstringMeta(args, 'arg')
    assert test_object.args is args
    assert test_object.description == 'arg'



# Generated at 2022-06-11 21:15:53.454483
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("test")

# Generated at 2022-06-11 21:15:58.547771
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args = ["hello", "world"]
    test_description = "This is a test"
    test_version = "1.0"
    docstring = DocstringDeprecated(args=test_args, description=test_description, version=test_version)
    assert docstring.args == test_args and docstring.description == test_description and docstring.version == test_version



# Generated at 2022-06-11 21:16:00.755723
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Docstring doesn't follow Numpy style.")
    assert str(error) == "Docstring doesn't follow Numpy style."


# Generated at 2022-06-11 21:16:04.009574
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = 'Not Available'
    version = 'Not Available'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert args == docstring_deprecated.args
    assert description == docstring_deprecated.description
    assert version == docstring_deprecated.version



# Generated at 2022-06-11 21:16:12.488419
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test constructor of class DocstringRaises"""
    args = []
    description = "test desc"
    type_name = "test type"
    test_docstring_raises = DocstringRaises(args, description, type_name)
    assert test_docstring_raises.args == []
    assert test_docstring_raises.description == "test desc"
    assert test_docstring_raises.type_name == "test type"


# Generated at 2022-06-11 21:16:14.727050
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dt = DocstringDeprecated()
    assert dt.version is None
    assert dt.description is None


# Generated at 2022-06-11 21:16:21.269897
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # create a DocstringDeprecated object
    object = DocstringDeprecated(['deprecated'], 'function is deprecated', '0.1')
    # test the __init__ function
    assert object.args == ['deprecated'], "initialization failed"
    assert object.description == 'function is deprecated', "initialization failed"
    assert object.version == '0.1', "initialization failed"


# Generated at 2022-06-11 21:16:28.444740
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(args = [''], description = None, arg_name = '', type_name = None, is_optional = None, default = None)
    assert a.args == ['']
    assert a.description == None
    assert a.arg_name == ''
    assert a.type_name == None
    assert a.is_optional == None
    assert a.default == None


# Generated at 2022-06-11 21:16:38.628083
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(["return","returns"], "anything", "None", True)
    assert returns.__dict__ == {'args': ['return', 'returns'], 'description': 'anything', 'type_name': 'None', 'is_generator': True, 'return_name': None}


# Generated at 2022-06-11 21:16:42.298382
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test error")
    except ParseError:
        assert True
    finally:
        assert True

# Generated at 2022-06-11 21:16:48.579562
# Unit test for constructor of class Docstring
def test_Docstring():
  docstr = Docstring()
  assert docstr.short_description is None
  assert docstr.long_description is None
  assert docstr.blank_after_short_description is False
  assert docstr.blank_after_long_description is False
  assert len(docstr.meta) == 0
  assert len(docstr.params) == 0
  assert len(docstr.raises) == 0



# Generated at 2022-06-11 21:16:51.394038
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
  obj = DocstringMeta(['a', 'b'], 'c')

if __name__ == "__main__":
  test_DocstringMeta()

# Generated at 2022-06-11 21:16:57.424241
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["returns"], "returns something", "string", False, "retval")
    assert ds.args==["returns"]
    assert ds.description=="returns something"
    assert ds.type_name=="string"
    assert ds.is_generator==False
    assert ds.return_name=="retval"


# Generated at 2022-06-11 21:17:00.752968
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    error = ParseError("some message")
    assert(error.args[0] == "some message")


# Generated at 2022-06-11 21:17:01.800074
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    import doctest
    assert doctest.testmod() == (0, 0)

# Generated at 2022-06-11 21:17:04.497446
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(1, 2, 3)


# Generated at 2022-06-11 21:17:07.432559
# Unit test for constructor of class Docstring
def test_Docstring():
    # Test default values
    a = Docstring()

    assert a.short_description is None
    assert a.long_description is None
    assert a.meta == []


# Generated at 2022-06-11 21:17:10.510286
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    version = None
    item = DocstringDeprecated(args, None, version)
    assert item is not None



# Generated at 2022-06-11 21:17:21.976678
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "comments"
    type_name = "list"
    is_generator = "True"
    return_name = "return_name"
    docstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstringReturns != None, "Constructor returns None."
    assert type(docstringReturns) is DocstringReturns, "docstringReturns is not DocstringReturns."


# Generated at 2022-06-11 21:17:23.404551
# Unit test for constructor of class ParseError
def test_ParseError():
    e1 = ParseError()
    assert e1 != None

# unit test for constructor of class DocstringMeta

# Generated at 2022-06-11 21:17:26.879799
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param']
    description = 'description'
    d = DocstringMeta(args, description)
    assert(d.args == args)
    assert(d.description == description)


# Generated at 2022-06-11 21:17:32.802701
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raiseDocstringRaises = DocstringRaises(['a', 'b', 'c'], 'd')
    assert(raiseDocstringRaises.args == ['a', 'b', 'c'])
    assert(raiseDocstringRaises.description == 'd')
    assert(raiseDocstringRaises.type_name == None)


# Generated at 2022-06-11 21:17:35.991890
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns(['arg1','arg2'], 'blah', 'str')
    assert doc.args == ['arg1', 'arg2']
    assert doc.description == 'blah'


# Generated at 2022-06-11 21:17:38.759334
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    desc_meta = DocstringMeta(["param"], "description for current parameter")
    assert desc_meta.args == ["param"]
    assert desc_meta.description == "description for current parameter"


# Generated at 2022-06-11 21:17:43.020408
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Given
    args = ['arg']
    description = "description"
    type_name = "TypeName"
    # When
    DocstringRaises(args, description, type_name)
    # Then
    assert args == ['arg']
    assert description == "description"
    assert type_name == "TypeName"


# Generated at 2022-06-11 21:17:52.516256
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=["param", "arg"], description="Test description", arg_name="arg", type_name="int", is_optional=True, default="None"
    )
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "int"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "None"
    assert docstring_param.args == ["param", "arg"]
    assert docstring_param.description == "Test description"



# Generated at 2022-06-11 21:17:56.288441
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args", "description"]
    description = "Describe the input"
    test_object = DocstringMeta(args, description)
    assert test_object.args == args
    assert test_object.description == description


# Generated at 2022-06-11 21:18:06.072328
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(
        "arg", "description", "arg_name", "type_name", True, "default"
    ).args == "arg"
    assert DocstringParam(
        "arg", "description", "arg_name", "type_name", True, "default"
    ).description == "description"
    assert DocstringParam(
        "arg", "description", "arg_name", "type_name", True, "default"
    ).arg_name == "arg_name"
    assert DocstringParam(
        "arg", "description", "arg_name", "type_name", True, "default"
    ).type_name == "type_name"
    assert DocstringParam(
        "arg", "description", "arg_name", "type_name", True, "default"
    ).is_optional is True
   

# Generated at 2022-06-11 21:18:19.088757
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-11 21:18:22.259004
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        x = DocstringRaises([1, 2], "error", "ValueError")
    except Exception:
        raise Exception("Wrong constructor format on DocstringRaises")




# Generated at 2022-06-11 21:18:24.738158
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    assert isinstance(obj, Docstring)



# Generated at 2022-06-11 21:18:27.427003
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(['a'], 'b')
    assert meta.args == ['a']
    assert meta.description == 'b'



# Generated at 2022-06-11 21:18:35.129070
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring1 = Docstring()
    assert docstring1.short_description is None
    assert docstring1.long_description is None
    assert docstring1.blank_after_short_description is False
    assert docstring1.blank_after_long_description is False
    assert docstring1.meta == []
    assert docstring1.params == []
    assert docstring1.raises == []
    assert docstring1.returns is None
    assert docstring1.deprecation is None



# Generated at 2022-06-11 21:18:38.456574
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["keyword", "deprecated", "2.0"]
    description = "deprecated description"
    version = "2.0"
    DocstringDeprecated(args, description, version)

# Generated at 2022-06-11 21:18:45.231101
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # params = [1,2,3]
    # description = 'test'
    # type_name = 'test'
    # is_generator = True
    # return_name = 'test'
    # test = DocstringReturns(params, description, type_name, is_generator, return_name)
    # assert test.description == description
    # assert test.type_name == type_name
    # assert test.is_generator == is_generator
    # assert test.return_name == return_name
    # assert test.args == params
    pass



# Generated at 2022-06-11 21:18:47.491209
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta( ['param'], 'description')

    # Check args
    assert d.args == ['param']

    # Check description
    assert d.description == 'description'

# Generated at 2022-06-11 21:18:55.393948
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Create an empty DocstringDeprecated object
    # and check if the attributes are initialized with their default values.
    sample_docstring_deprecated = DocstringDeprecated([], None, None)
    assert sample_docstring_deprecated.description == None  # pylint: disable=comparison-with-callable
    assert sample_docstring_deprecated.version == None  # pylint: disable=comparison-with-callable
    assert sample_docstring_deprecated.args == []


# Generated at 2022-06-11 21:18:59.266811
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns']
    description = 'a string'
    doc_return = DocstringReturns(args,description,None, False)
    assert doc_return.description == 'a string'
    assert doc_return.args == args
    assert doc_return.type_name == None
    assert doc_return.is_generator == False


# Generated at 2022-06-11 21:19:11.092041
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    deprecated = DocstringDeprecated("args", "description", "version")
    assert deprecated.args == "args"
    assert deprecated.description == "description"
    assert deprecated.version == "version"



# Generated at 2022-06-11 21:19:13.443132
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns("args", "description", "type_name", False, "return_name")
    print("test_DocstringReturns: " + str(x.is_generator))



# Generated at 2022-06-11 21:19:15.897945
# Unit test for constructor of class ParseError
def test_ParseError():

    # Calling constructor with a string
    pe1 = ParseError("parse exception")

    # Calling constructor without argument
    pe2 = ParseError()


# Generated at 2022-06-11 21:19:20.317558
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['parameter','description'], 'This is a description.').args == ['parameter','description']
    assert DocstringMeta(['parameter','description'], 'This is a description.').description == 'This is a description.'


# Generated at 2022-06-11 21:19:24.921187
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["Args", "Description", "Type_name"]
    docstringRaises = DocstringRaises(args, "Args", "Type_name")
    assert isinstance(docstringRaises, DocstringRaises)


# Generated at 2022-06-11 21:19:27.569248
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=['deprecated'], description='This function is deprecated!', version='4.3.2')


# Generated at 2022-06-11 21:19:36.288297
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(
        ['a', 'b'], 'testing DocstringMeta object construction'
    ).args == ['a', 'b']
    assert DocstringMeta(
        ['a', 'b'], 'testing DocstringMeta object construction'
    ).description == 'testing DocstringMeta object construction'
    assert DocstringMeta(
        ['a', 'b'], 'testing DocstringMeta object construction'
    ).description == 'testing DocstringMeta object construction'
    assert DocstringMeta(
        ['a', 'b'], 'testing DocstringMeta object construction'
    ).description == 'testing DocstringMeta object construction'
    assert DocstringParam(
        ['a', 'b'], 'testing DocstringParam object construction', 'a', None, None, None
    ).args == ['a', 'b']

# Generated at 2022-06-11 21:19:37.918891
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert(DocstringRaises(["raises"], None, None))


# Generated at 2022-06-11 21:19:45.847071
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of class DocstringParam."""
    doc = DocstringParam(args = ["param"], description = "description", arg_name = "arg", type_name = "int", is_optional = True, default = "default")
    assert doc.args == ["param"]
    assert doc.description == "description"
    assert doc.arg_name == "arg"
    assert doc.type_name == "int"
    assert doc.is_optional == True
    assert doc.default == "default"


# Generated at 2022-06-11 21:19:51.149159
# Unit test for constructor of class Docstring
def test_Docstring():
    s = Docstring()
    assert s.short_description is None
    assert s.long_description is None
    assert s.blank_after_short_description == False
    assert s.blank_after_long_description == False
    assert s.meta == []
    return

# Unit tests for Docstring.params
# No params

# Generated at 2022-06-11 21:20:11.167139
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    t = DocstringMeta(["param", "arg"], "description")
    assert t.args == ["param", "arg"]
    assert t.description == "description"


# Generated at 2022-06-11 21:20:13.419659
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(["returns"], "returns description", "returns_type", True).type_name == "returns_type"

# Generated at 2022-06-11 21:20:16.175340
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dr = DocstringRaises(args = [], description = None, type_name = 'type_name')
    assert dr.description == None
    assert dr.type_name == 'type_name'

# Generated at 2022-06-11 21:20:21.429645
# Unit test for constructor of class Docstring
def test_Docstring():
    d1 = Docstring()
    assert d1.short_description is None
    assert d1.long_description is None
    assert len(d1.meta) == 0
    assert d1.params == []
    assert d1.raises == []
    assert d1.returns is None
    assert d1.deprecation is None



# Generated at 2022-06-11 21:20:24.490421
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    if isinstance(obj, DocstringParam):
        print("test passed")
    else:
        print("test failed")

test_DocstringParam()


# Generated at 2022-06-11 21:20:27.796457
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Test")
    assert err.args[0] == "Test"


# Generated at 2022-06-11 21:20:31.840471
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstr = DocstringDeprecated(['arg1', 'arg2'], 'description', 'version')
    assert docstr.args == ['arg1', 'arg2']
    assert docstr.description == 'description'
    assert docstr.version == 'version'

# Generated at 2022-06-11 21:20:38.913110
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None



# Generated at 2022-06-11 21:20:40.540423
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta=DocstringRaises(["raises"], "This is the description", "Exception")
    assert meta.type_name == "Exception"


# Generated at 2022-06-11 21:20:48.491126
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(
        ['arg'],
        'description',
        'arg_name',
        'type_name',
        True,
        'default'
    )
    assert dp.args == ['arg']
    assert dp.description == 'description'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == True
    assert dp.default == 'default'


# Generated at 2022-06-11 21:21:25.804891
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dsR=DocstringRaises(['a'], 'a', 'a')
    assert dsR is not None

# Generated at 2022-06-11 21:21:31.879961
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(
        args = ["param"],
        description = "description",
        arg_name = "arg_name",
        type_name = "type_name",
        is_optional = True,
        default = "default",
    )


# Generated at 2022-06-11 21:21:35.137063
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(args = ["deprecated"], description = "Deprecated", version = "1.0.0")
    assert s.args[0] == "deprecated"
    assert s.description == "Deprecated"
    assert s.version == "1.0.0"

# Generated at 2022-06-11 21:21:38.481537
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], description=None, version=None)
    assert d.args == ["deprecated"]
    assert d.description is None
    assert d.version is None
    assert isinstance(d, DocstringMeta)



# Generated at 2022-06-11 21:21:42.158650
# Unit test for constructor of class Docstring
def test_Docstring():
    d1 = Docstring()
    assert isinstance(d1, Docstring), "Docstring is not instance of Docstrings."

    d2 = Docstring()
    assert (d1 is not d2), "Docstring objects are not separated."


# Generated at 2022-06-11 21:21:44.402176
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from test_DocStringParsing import test_DocstringMeta
    assert(test_DocstringMeta() == 1)


# Generated at 2022-06-11 21:21:49.340288
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    class_docstring = DocstringDeprecated(["deprecated"], "Deprecated description", "1.0.1")
    assert class_docstring.args == ["deprecated"]
    assert class_docstring.description == "Deprecated description"
    assert class_docstring.version == "1.0.1"

# Generated at 2022-06-11 21:21:55.416749
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_name = "a"
    type_name = "int"
    is_generator = True

    assert return_name == DocstringReturns(return_name, type_name, is_generator).return_name
    assert type_name == DocstringReturns(return_name, type_name, is_generator).type_name
    assert is_generator == DocstringReturns(return_name, type_name, is_generator).is_generator

# Generated at 2022-06-11 21:22:04.740485
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert docstring.args == ["param"]
    assert docstring.description == "description"
    assert docstring.arg_name == "arg"
    assert docstring.type_name == "type"
    assert docstring.is_optional == True
    assert docstring.default == "default"


# Generated at 2022-06-11 21:22:09.652268
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    version = '0.0.1'
    desc = 'Test the docstring deprecation'
    args = "deprecated,deprecated"
    docstringDeprecated = DocstringDeprecated(args, desc, version)
    assert docstringDeprecated.args == "deprecated,deprecated"
    assert docstringDeprecated.description == "Test the docstring deprecation"
    assert docstringDeprecated.version == "0.0.1"


# Generated at 2022-06-11 21:23:23.198550
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_DocstringMeta = DocstringMeta(["param"], "Clear docstring")
    assert type(test_DocstringMeta.args) is list
    assert type(test_DocstringMeta.description) is str


# Generated at 2022-06-11 21:23:25.743670
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	a = DocstringReturns(["return", "type"], "desc", "return_type")
	assert isinstance(a, DocstringReturns)	


# Generated at 2022-06-11 21:23:30.029005
# Unit test for constructor of class Docstring
def test_Docstring():

    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []



# Generated at 2022-06-11 21:23:41.892271
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test the constructors for DocstringMeta and its subclasses."""

    test_docstring_meta = DocstringMeta(["test_meta"], "test description")
    assert test_docstring_meta.args == ["test_meta"]
    assert test_docstring_meta.description == "test description"

    test_docstring_param = DocstringParam(
        ["test_param"],
        "test description",
        "test_arg",
        "test_type",
        True,
        "test_default",
    )
    assert test_docstring_param.args == ["test_param"]
    assert test_docstring_param.description == "test description"
    assert test_docstring_param.arg_name == "test_arg"
    assert test_docstring_param.type_name == "test_type"

# Generated at 2022-06-11 21:23:44.519272
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([], None, None)
    assert(a.args == [])
    assert(a.description is None)
    assert(a.type_name is None)


# Generated at 2022-06-11 21:23:48.085429
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam()
    assert docstring_param.param_name == ''
    assert docstring_param.type_name == ''
    assert docstring_param.is_optional == False
    assert docstring_param.default == ''

# Generated at 2022-06-11 21:23:49.374434
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "", "")

# Generated at 2022-06-11 21:23:54.418545
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print("test_DocstringRaises")
    args = []
    description = ""
    type_name = "ValueError"
    c = DocstringRaises(args, description, type_name)
    if c.args != args:
        print("error")
    elif c.description != description:
        print("error")
    elif c.type_name != type_name:
        print("error")
    else:
        print("ok")


# Generated at 2022-06-11 21:23:57.226558
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError) as e:
        raise ParseError("Error occurred")
    assert "Error occurred" == e.value.args[0]


# Generated at 2022-06-11 21:23:58.677593
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert error != None
