

# Generated at 2022-06-11 21:15:48.368532
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['param'], 'description', 'arg_name', 'type_name', None, None)
    assert dp.args == ['param']
    assert dp.description == 'description'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == None
    assert dp.default == None


# Generated at 2022-06-11 21:15:52.401024
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta("aa", "bb")
    assert d.args == ["aa"], "DocstringMeta: args field is incorrect"
    assert d.description == "bb", "DocstringMeta: description is incorrect"


# Generated at 2022-06-11 21:15:56.690057
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["test_args"]
    description = "test_description"
    type_name = "test_type_name"
    test = DocstringRaises(args, description, type_name)
    assert test.type_name == type_name
    assert test.description == description


# Generated at 2022-06-11 21:16:01.611803
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert not doc.blank_after_short_description
    assert not doc.blank_after_long_description
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None

# Generated at 2022-06-11 21:16:08.529663
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Create DocstringParam object."""
    args = ['arg', 'param']
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    # Check class members
    assert(param.args == args)
    assert(param.description == description)
    assert(param.arg_name == arg_name)
    assert(param.type_name == type_name)
    assert(param.is_optional == is_optional)
    assert(param.default == default)



# Generated at 2022-06-11 21:16:10.759000
# Unit test for constructor of class ParseError
def test_ParseError():
    print('test_ParseError')
    ParseError()
    print('test_ParseError finish')


# Generated at 2022-06-11 21:16:13.067261
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg']
    description = 'description'
    DocstringMeta(args, description)


# Generated at 2022-06-11 21:16:15.912715
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [':deprecated:']
    description = "description"
    version = "1.0.0"
    docstringDeprecated = DocstringDeprecated(args, description, version)
    assert docstringDeprecated.args == args


# Generated at 2022-06-11 21:16:18.698157
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    s = "This is a docstring"
    assert len(s) == 20
    assert s.startswith("This")
    assert s.endswith("docstring")


# Generated at 2022-06-11 21:16:26.490720
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["1", "2"], "desc", "type name")
    assert isinstance(d.type_name, str) == True
    assert isinstance(d.args, list) == True
    assert d.type_name == "type name"
    assert d.args == ["1", "2"]
    assert d.description == "desc"


# Generated at 2022-06-11 21:16:45.807332
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Object docstringRaises1 is an instance of class DocstringRaises with the following parameters:
    docstringRaises1 = DocstringRaises([""], None, None)
    assert docstringRaises1.type_name == None and docstringRaises1.description == None
    # Object docstringRaises2 is an instance of class DocstringRaises with the following parameters:
    docstringRaises2 = DocstringRaises([""], None, None)
    assert docstringRaises2.type_name == None and docstringRaises2.description == None
    #  Object docstringRaises3 is an instance of class DocstringRaises with the following parameters:
    docstringRaises3 = DocstringRaises([""], None, None)
    assert docstringRaises3.type_name == None and docstringRaises3.description == None


# Generated at 2022-06-11 21:16:50.905999
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case = DocstringDeprecated(["deprecation"], "This is deprecated in version 1.0", "1.0")
    assert test_case.args == ["deprecation"]
    assert test_case.description == "This is deprecated in version 1.0"
    assert test_case.version == "1.0"

# Generated at 2022-06-11 21:16:52.228642
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta()



# Generated at 2022-06-11 21:16:57.206995
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []


# Generated at 2022-06-11 21:17:03.032575
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    params = ["arg1", "arg2", "arg3"]
    description = "test_DocstringRaises"
    type_name = "type"
    
    doc = DocstringRaises(params, description, type_name)
    
    assert doc.args == params
    assert doc.description == description
    assert doc.type_name == type_name
    
    

# Generated at 2022-06-11 21:17:09.022121
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    o = DocstringRaises(["arg1", "arg2"], "description", "type_name")
    assert o.args == ["arg1", "arg2"]
    assert o.description == "description"
    assert o.type_name == "type_name"

# Generated at 2022-06-11 21:17:14.858810
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    # Constructor with empty parameters
    dd = DocstringDeprecated([], "", None)
    assert dd is not None
    assert dd.args == []
    assert dd.description == ""
    assert dd.version is None

    # Constructor with full parameters
    args = ['deprecated', ':deprecation:']
    description = "description"
    version = "1.1.1"
    dd2 = DocstringDeprecated(args, description, version)
    assert dd2 is not None
    assert dd2.args == args
    assert dd2.description == description
    assert dd2.version == version

# Generated at 2022-06-11 21:17:19.674082
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(args=["a", "b", "c"], description="some description", type_name="type_name")
    assert a.args == ["a", "b", "c"]
    assert a.description == "some description"
    assert a.type_name == "type_name"



# Generated at 2022-06-11 21:17:22.889416
# Unit test for constructor of class Docstring
def test_Docstring():
    """Function to test constructor."""
    docstring_obj = Docstring()
    assert docstring_obj.short_description is None
    assert docstring_obj.long_description is None


# Generated at 2022-06-11 21:17:30.874955
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test Docstring class constructor."""
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert isinstance(docstring.meta, list)
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None

# Generated at 2022-06-11 21:17:41.434559
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = 'bla'
    type_name = 'int'
    doc_raise = DocstringRaises(args, description, type_name)


# Generated at 2022-06-11 21:17:45.254587
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = ""
    type_name = ""
    is_generator = True
    return_name = ""
    obj = DocstringReturns(args, description, type_name, is_generator, return_name)

# Generated at 2022-06-11 21:17:47.530146
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises.__init__(DocstringRaises, [], "descr", "type")
    return 1

# Generated at 2022-06-11 21:17:48.893467
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    new_doc=DocstringRaises(['args'],"description",'type name')

# Generated at 2022-06-11 21:17:50.806241
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(":param arg: description", ":param arg: description")


# Generated at 2022-06-11 21:17:53.112141
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["test content"], "test description")


# Generated at 2022-06-11 21:17:55.640909
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args = ['a'], description = 'error', type_name = 'value')
   


# Generated at 2022-06-11 21:18:05.691445
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    raw = """
    :param param: description
    :parameter param: description
    :arg param: description
    :argument param: description
    :attribute param: description
    :key param: description
    :keyword param: description
    :param param: description
    :type param: parameter
    :param param: description
    :param param: description
    :param param: description
    :param param: description
    """
    raw += "some random text\n"
    raw += """
    :param param: description
    :type param: parameter
    :param param: description
    :rtype parameter: description
    """
    raw += "some random text"

# Generated at 2022-06-11 21:18:08.786570
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword'],
        'description')


# Generated at 2022-06-11 21:18:11.183811
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	DocstringDeprecated(["deprecated"], "Symbolizes :deprecated metadata", "2.0")


# Generated at 2022-06-11 21:18:30.333376
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x=DocstringParam(args=["param"], description=None, arg_name=None, type_name=None, is_optional=None, default=None)
    assert x.description == None
    assert x.is_optional == None
    assert x.arg_name == None

# Generated at 2022-06-11 21:18:39.573024
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # :deprecated

    test_d = DocstringDeprecated(
        ["deprecation"], "the docstring is deprecated", "1.0.0"
    )
    assert test_d.description == "the docstring is deprecated"
    assert test_d.args[0] == "deprecation"
    assert test_d.version == "1.0.0"
    # :deprecated the docstring is deprecated
    test_deprecated = DocstringDeprecated(
        ["deprecated", "the docstring is deprecated"], None, None
    )
    assert test_deprecated.description == "the docstring is deprecated"
    assert test_deprecated.args[0] == "deprecated"
    assert test_deprecated.version == None



# Generated at 2022-06-11 21:18:41.674287
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("message")
    assert err.args == ("message",)


# Generated at 2022-06-11 21:18:43.408949
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg","description"]
    d = DocstringMeta(args,"description")
    assert(d.args == args)
    assert(d.description == "description")


# Generated at 2022-06-11 21:18:44.828797
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringParam()
    assert docstring.args == None
    assert docstring.description == None

# Generated at 2022-06-11 21:18:52.982822
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg"
    type_name = "int"
    is_optional = False
    default = "2"
    my_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert(my_param.arg_name == "arg")
    assert(my_param.type_name == "int")
    assert(my_param.is_optional == False)
    assert(my_param.default == "2")


# Generated at 2022-06-11 21:18:56.801427
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["args"], "description", "version")
    assert str(type(docstring_deprecated)) == "<class 'sphinx_autodoc_typehints.parsing.DocstringDeprecated'>"


# Generated at 2022-06-11 21:18:57.459424
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("test")

# Generated at 2022-06-11 21:19:04.380842
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test Docstring()
    """
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []
    assert a.params == []
    assert a.raises == []
    assert a.returns is None
    assert a.deprecation is None


# Generated at 2022-06-11 21:19:11.176777
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(args=["param"], description="First argument", arg_name="arg", type_name=None, is_optional=False, default=None)
    print(item.__dict__)
    assert item.args == ["param"]
    assert item.description == "First argument"
    assert item.arg_name == "arg"
    assert item.type_name is None
    assert item.is_optional is False
    assert item.default is None


# Generated at 2022-06-11 21:19:34.685879
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test constructor of class DocstringDeprecated."""
    args = []
    description = ""
    version = ""
    test_docstring_deprecated = DocstringDeprecated(args, description, version)
    assert hasattr(test_docstring_deprecated, "args")
    assert hasattr(test_docstring_deprecated, "description")
    assert hasattr(test_docstring_deprecated, "version")


# Generated at 2022-06-11 21:19:36.475019
# Unit test for constructor of class ParseError
def test_ParseError():
    """Do a unit test on ParseError."""
    pass


# Generated at 2022-06-11 21:19:41.974000
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', True, 'default')
    print(a.args)
    print(a.description)
    print(a.arg_name)
    print(a.type_name)
    print(a.is_optional)
    print(a.default)


# Generated at 2022-06-11 21:19:45.648188
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["arg"], "Description").args == ["arg"]
    assert DocstringMeta(["arg"], "Description").description == "Description"


# Generated at 2022-06-11 21:19:52.342842
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    check = DocstringReturns(args = ['a', 'b'], description = "desc", type_name = "type_name",
                             is_generator = False, return_name = "return_name")
    assert check.args == ['a', 'b']
    assert check.description == "desc"
    assert check.type_name == "type_name"
    assert check.is_generator == False
    assert check.return_name == "return_name"



# Generated at 2022-06-11 21:19:57.114820
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []

# Generated at 2022-06-11 21:19:59.880653
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # first test
    DocstringReturns([], "desc1", "type1", True)
    # second test
    DocstringReturns([], "desc2", "type2", False)


# Generated at 2022-06-11 21:20:00.962765
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "This is a description")


# Generated at 2022-06-11 21:20:01.877904
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass


# Generated at 2022-06-11 21:20:03.912471
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("foo")
    assert e.args[0] == "foo"


# Generated at 2022-06-11 21:20:21.939764
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        x = ParseError('123')
    except RuntimeError as e:
        assert str(e) == '123'


# Generated at 2022-06-11 21:20:30.567971
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", True, "default")
    assert dp.args == ["param", "arg"]
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == True
    assert dp.default == "default"

if __name__ == "__main__":
    test_DocstringParam()
    print("Everything passed")

# Generated at 2022-06-11 21:20:31.942643
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert(error)

# Generated at 2022-06-11 21:20:34.843659
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    with pytest.raises(TypeError):
        DocstringMeta()  # pylint: disable=no-value-for-parameter


# Generated at 2022-06-11 21:20:40.052856
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta."""
    argslist = ['param', 'arg', 'attribute']
    description ='this is a description'
    test1 = DocstringMeta(argslist, description)
    assert test1.args == argslist
    assert test1.description == description
    print (test1)

if __name__ == '__main__':
    test_DocstringMeta()



# Generated at 2022-06-11 21:20:48.594334
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = None
    arg_name = "arg"
    type_name = "int"
    is_optional = True
    default = "10"
    doc = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert doc.args==["param"]
    assert doc.arg_name=="arg"
    assert doc.type_name=="int"
    assert doc.is_optional==True
    assert doc.default=="10"
    return
test_DocstringParam()

# Generated at 2022-06-11 21:20:56.407069
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        ['param'],
        'the description',
        'arg_name',
        None,
        None,
        None,
    )
    assert docstring_param.args[0] == 'param'
    assert docstring_param.arg_name == 'arg_name'
    assert docstring_param.type_name == None
    assert docstring_param.is_optional == None
    assert docstring_param.default == None
    assert docstring_param.description == 'the description'


# Generated at 2022-06-11 21:20:58.580505
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test for constructor of class DocstringDeprecated."""
    assert(True)



# Generated at 2022-06-11 21:21:08.339375
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert (DocstringParam(["param", "arg"], "description", "arg", "int", None, None).description == "description")
    assert (DocstringParam(["param", "arg"], "description", "arg", "int", None, None).arg_name == "arg")
    assert (DocstringParam(["param", "arg"], "description", "arg", "int", None, None).type_name == "int")
    assert (DocstringParam(["param", "arg"], "description", "arg", "int", None, None).default == None)
    assert (DocstringParam(["param", "arg"], "description", "arg", "int", None, None).is_optional == None)


# Generated at 2022-06-11 21:21:10.668124
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [
        "param",
        "description",
    ]
    try:
        DocstringMeta(
            args,
        )
    except:
        pass


# Generated at 2022-06-11 21:21:47.285325
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    assert obj.short_description == None
    assert obj.long_description == None
    assert obj.blank_after_short_description == False
    assert obj.blank_after_long_description == False
    assert obj.meta == []


# Generated at 2022-06-11 21:21:50.771220
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["a"], "b", "c", True)
    a.args
    assert a.args == ["a"]
    assert a.description == "b"
    assert a.type_name == "c"
    assert a.is_generator == True


# Generated at 2022-06-11 21:21:56.998592
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(['deprecated'], 'A description of what was deprecated', version='0.2.3')
    assert meta.type_name == None
    assert meta.args[0] == 'deprecated'
    assert meta.description == 'A description of what was deprecated'
    assert meta.version == '0.2.3'



# Generated at 2022-06-11 21:21:58.031323
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    pass


# Generated at 2022-06-11 21:22:04.895553
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-11 21:22:09.285569
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta is []
    assert ds.params is []
    assert ds.returns is None


# Generated at 2022-06-11 21:22:12.428312
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d1 = DocstringMeta(["param"], "description")
    assert d1.args == ["param"]
    assert d1.description == "description"

# Generated at 2022-06-11 21:22:14.283632
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-11 21:22:18.762365
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert not docstring.blank_after_short_description
    assert docstring.long_description is None
    assert not docstring.blank_after_long_description
    assert docstring.meta == []



# Generated at 2022-06-11 21:22:27.059566
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Call the constructor of DocstringReturns."""
    print("Calling the constructor of DocstringReturns")
    test_DocstringReturns = DocstringReturns([],[],None,False,"test_name")
    print(test_DocstringReturns.args)
    print(test_DocstringReturns.description)
    print(test_DocstringReturns.type_name)
    print(test_DocstringReturns.is_generator)
    print(test_DocstringReturns.return_name)

# Generated at 2022-06-11 21:23:39.867599
# Unit test for constructor of class ParseError
def test_ParseError():
  runtimeerror = RuntimeError("Test")
  parseerror = ParseError("Test", runtimeerror)
  assert parseerror.args[0] == "Test"
  assert parseerror.args[1] == runtimeerror

# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-11 21:23:40.832568
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError()



# Generated at 2022-06-11 21:23:47.578578
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(args='x', description='y', type_name='z')
    if d.args == 'x' and d.description == 'y' and d.type_name == 'z':
        print('test_DocstringRaises OK')
    else:
        print('test_DocstringRaises FAILED')


# Generated at 2022-06-11 21:23:52.030945
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises","ValueError","if something happens"]
    description = "..."
    type_name = "ValueError"
    raises = DocstringRaises(args,description,type_name)
    assert raises.args == args
    assert raises.description == description
    assert raises.type_name == type_name



# Generated at 2022-06-11 21:23:55.499614
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    new_instance = DocstringDeprecated([""], "", "")
    assert isinstance(new_instance, DocstringDeprecated)
    assert isinstance(new_instance, DocstringMeta)

# Generated at 2022-06-11 21:23:58.576160
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert (docstring.short_description == None)
    assert (docstring.long_description == None)
    assert (len(docstring.meta) == 0)


# Generated at 2022-06-11 21:24:05.544205
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises("Hello", "World", "World2", )
    assert a.type_name == "World2"
    assert a.description == "World"

# Generated at 2022-06-11 21:24:08.437841
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(['arg'], 'description')
    assert isinstance(docstring, DocstringMeta)


# Generated at 2022-06-11 21:24:15.095291
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    argList = ["a", "b"]
    listReturn = DocstringReturns(argList, "description", "type_name", True)
    assert(listReturn.args == argList)
    assert(listReturn.description == "description")
    assert(listReturn.type_name == "type_name")
    assert(listReturn.is_generator == True)
    assert(listReturn.return_name == None)


# Generated at 2022-06-11 21:24:20.092777
# Unit test for constructor of class Docstring
def test_Docstring():
    """docstring."""
    # Create a new Docstring instance
    docstring = Docstring()
    # Test that the default values of all attributes are correct
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    return 0
