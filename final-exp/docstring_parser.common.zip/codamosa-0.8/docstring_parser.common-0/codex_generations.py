

# Generated at 2022-06-11 21:15:47.619723
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        a = DocstringMeta(['a'], 'b')
        assert a.args == ['a']
        assert a.description == 'b'
    except:
        print('Some error in DocstringMeta constructor')


# Generated at 2022-06-11 21:15:55.401698
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-11 21:16:00.792572
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = "Error"
    type_name = ""
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name

# Generated at 2022-06-11 21:16:04.558811
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds_ret = DocstringReturns(["return"], "A value", "int", False)
    assert ds_ret.args == ["return"]
    assert ds_ret.description == "A value"
    assert ds_ret.type_name == "int"
    assert ds_ret.is_generator == False
    assert ds_ret.return_name == None

test_DocstringReturns()



# Generated at 2022-06-11 21:16:10.864344
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test Docstring constructor."""
    doc_string = Docstring()
    assert doc_string.short_description is None
    assert doc_string.long_description is None
    assert doc_string.blank_after_short_description is False
    assert doc_string.blank_after_long_description is False
    assert doc_string.meta == []



# Generated at 2022-06-11 21:16:15.507020
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0


# Generated at 2022-06-11 21:16:18.384141
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dmeta = DocstringDeprecated("args", "description", "version")
    assert dmeta.args == 'args'
    assert dmeta.description == 'description'
    assert dmeta.version == 'version'



# Generated at 2022-06-11 21:16:21.574918
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    with pytest.raises(TypeError):
        DocstringReturns()


# Unit tests for constructor of class DocstringRaises

# Generated at 2022-06-11 21:16:24.495881
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    Docstring("a", "b", "c", "d")

# Generated at 2022-06-11 21:16:30.905717
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test for class DocstringRaises."""
    # Initialize DocstringRaises object
    docstring_raises = DocstringRaises(
        ["arg1", "arg2"], "description", "type_name"
    )

    assert docstring_raises.args == ["arg1", "arg2"]
    assert docstring_raises.description == "description"
    assert docstring_raises.type_name == "type_name"



# Generated at 2022-06-11 21:16:43.309091
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["yo"]
    description = "Returns 1"
    return_name = "yo"
    type_name = "int"
    is_generator = False
    y = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert isinstance(y, DocstringReturns)
    assert (y.args, y.description, y.type_name, y.is_generator, y.return_name)\
           == (args, description, type_name, is_generator, return_name)


# Generated at 2022-06-11 21:16:46.573243
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test DocstringReturns constructor."""
    assert isinstance(DocstringReturns(['return', 'returns'], None, None, True, None),
                      DocstringReturns)


# Generated at 2022-06-11 21:16:49.914926
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a=DocstringReturns(args,description,type_name,is_generator,return_name)
    assert a.description == 'description'
    
    

# Generated at 2022-06-11 21:16:51.509164
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=[], description="", version="")

# Generated at 2022-06-11 21:16:56.802893
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'version', 'description']
    version = '0.8.0'
    description = 'This method is deprecated.'
    deprec = DocstringDeprecated(args, description, version)
    assert deprec.version == version
    assert deprec.description == description



# Generated at 2022-06-11 21:16:59.329080
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "").args == []
    assert DocstringMeta([], "").description == ""


# Generated at 2022-06-11 21:17:06.633109
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = DocstringReturns(args=['returns'], description='a', type_name='a', is_generator=True)
    # Assert if type_name attribute is correctly assigned
    assert docstring.type_name == 'a'
    # Assert if is_generator attribute is correctly assigned
    assert docstring.is_generator is True
    # Assert if return name is correctly assigned
    assert docstring.return_name is None

# Generated at 2022-06-11 21:17:12.884765
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_init = DocstringParam([":param"], "Test Description", "arg_name",
                               "type_name", False, "default")
    test_init.args == [":param"]
    test_init.description == "Test Description"
    test_init.arg_name == "arg_name"
    test_init.type_name == "type_name"
    test_init.is_optional == False
    test_init.default == "default"


# Generated at 2022-06-11 21:17:18.597372
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test DocstringRaises class by creating an instance and inspecting state of instance."""
    raises = DocstringRaises(["param","arg"], "descr", "type")
    assert isinstance(raises, DocstringMeta)
    assert raises.args == ["param", "arg"]
    assert raises.description == "descr"
    assert raises.type_name == "type"


# Generated at 2022-06-11 21:17:22.112223
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [":param", "arg", "description"]
    description = "If something happens"
    exception_type = "ValueError"
    DocstringRaises(args, description, exception_type)

# Generated at 2022-06-11 21:17:34.423577
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    parsing_names = DocstringReturns(["return"], "", "None")
    assert isinstance(parsing_names, DocstringReturns)
    assert parsing_names.args == ["return"]
    assert parsing_names.description == ""
    assert parsing_names.type_name == "None"


# Generated at 2022-06-11 21:17:37.249744
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert(DocstringRaises(['raises'], 'description', 'type_name').__class__.__name__ == 'DocstringRaises')


# Generated at 2022-06-11 21:17:45.135583
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["hello", "world"]
    description = "hello world"
    type_name = "int"
    is_generator = True
    return_name = "b"
    d = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(d.args == ["hello", "world"])
    assert(d.description == "hello world")
    assert(d.type_name == "int")
    assert(d.is_generator == True)
    assert(d.return_name == "b")

# Calling function test_DocstringReturns() directly
test_DocstringReturns()

# Generated at 2022-06-11 21:17:52.787167
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["sachin"], "Tendulkar", "Tendulkar", "batsman", "False", "True")
    assert a.args == ["sachin"]
    assert a.description == "Tendulkar"
    assert a.arg_name == "Tendulkar"
    assert a.type_name == "batsman"
    assert a.is_optional == "False"
    assert a.default == "True"


# Generated at 2022-06-11 21:17:55.486501
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert len(doc.meta) == 0
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None

# Generated at 2022-06-11 21:17:59.437331
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    check_docs = DocstringReturns(args=["return"], description="return a new DocstringReturns object", type_name=None, is_generator=False, return_name=None)
    return check_docs


# Generated at 2022-06-11 21:18:00.384447
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-11 21:18:04.534648
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_object = Docstring()
    assert docstring_object.short_description == None
    assert docstring_object.long_description == None
    assert docstring_object.blank_after_short_description == False
    assert docstring_object.blank_after_long_description == False
    assert docstring_object.meta == []


# Generated at 2022-06-11 21:18:09.037555
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_long_description == False
    assert d.blank_after_short_description == False
    assert len(d.meta) == 0


# Generated at 2022-06-11 21:18:16.630427
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    # Create object DocstringReturns
    item = DocstringReturns(['returns'], 'return something', 'something', True)
    # Do unittest
    assert item.args == ['returns']
    assert item.description == 'return something'
    assert item.type_name == 'something'
    assert item.is_generator
    print("test_DocstringReturns: All tests passed!")



# Generated at 2022-06-11 21:18:25.273101
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    assert str(error) == "test"


# Generated at 2022-06-11 21:18:29.012661
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []



# Generated at 2022-06-11 21:18:35.589934
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args = [], description = None, arg_name = 'arg1', type_name = None, is_optional = None, default = None)
    assert not dp.args
    assert dp.description == None
    assert dp.arg_name == 'arg1'
    assert dp.type_name == None
    assert dp.is_optional == None
    assert dp.default == None


# Generated at 2022-06-11 21:18:39.419418
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['param'], 'test_args') == DocstringMeta(['param'], 'test_args')
    assert DocstringMeta(['param'], 'test_args') != DocstringMeta(['test_args'], 'test_args')


# Generated at 2022-06-11 21:18:40.754088
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(RuntimeError)


# Generated at 2022-06-11 21:18:42.725291
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    return DocstringParam(["param", ":", "arg"], "description", "arg", "int", False, None)


# Generated at 2022-06-11 21:18:46.163999
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta."""
    args = ["parameter", "arg", "param"]
    description = "This is some description text."
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-11 21:18:52.982011
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['param', 'arg type'], 'description', 'arg', 'type', False, 'None')
    assert dp.args==['param', 'arg type']
    assert dp.description=='description'
    assert dp.arg_name=='arg'
    assert dp.type_name=='type'
    assert dp.is_optional==False
    assert dp.default=='None'


# Generated at 2022-06-11 21:18:57.823220
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["arg", "description"], "arg: description", "arg", "description", True, "True")
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "description"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "True"


# Generated at 2022-06-11 21:19:00.031701
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Failed to parse.")
    except ParseError:
        print("test_ParseError successful")



# Generated at 2022-06-11 21:19:26.137805
# Unit test for constructor of class Docstring
def test_Docstring():
    # Create a new instance of Docstring
    meta_data = Docstring()

    # Check the values of properties and attributes
    assert meta_data.short_description is None
    assert meta_data.long_description is None
    assert meta_data.blank_after_short_description is False
    assert meta_data.blank_after_long_description is False
    assert meta_data.meta == []
    assert meta_data.params == []
    assert meta_data.raises == []
    assert meta_data.returns is None
    assert meta_data.deprecation is None

    # Print the values and check the output
    print(meta_data)
    assert str(meta_data) == '<Docstring>'


# Generated at 2022-06-11 21:19:31.702523
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(
        ["deprecated","version"], "deprecated since version 3.0", "3.0")

    # Tests for DocstringDeprecated
    assert s.args == (["deprecated","version"])
    assert s.description == "deprecated since version 3.0"
    assert s.version == "3.0"

    # Tests for DocstringMeta
    assert s.args == (["deprecated","version"])
    assert s.description == "deprecated since version 3.0"


# Generated at 2022-06-11 21:19:34.296323
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('This is a parse error.')
    except ParseError as err:
        assert str(err) == "This is a parse error."



# Generated at 2022-06-11 21:19:40.885813
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert param.arg_name == "arg_name"
    assert param.description == "description"
    assert param.type_name == "type_name"
    assert param.args == ["param"]
    assert param.is_optional == True
    assert param.default == "default"


# Generated at 2022-06-11 21:19:44.010037
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Testing ParseError Exception")
    except ParseError as pe:
        assert str(pe) == "Testing ParseError Exception"


# Generated at 2022-06-11 21:19:48.689820
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated("param", "Hello","1.5").args == ["param"]
    assert DocstringDeprecated("param", "Hello","1.5").description == "Hello"
    assert DocstringDeprecated("param", "Hello","1.5").version == "1.5"


# Generated at 2022-06-11 21:19:52.481567
# Unit test for constructor of class ParseError
def test_ParseError():
    # Initialize ParseError
    error = ParseError()

    # Test runtimeerror is a subclass of ParseError
    assert issubclass(RuntimeError, ParseError)

    # Test that we can create a ParseError without any arguments
    error = ParseError()

# Generated at 2022-06-11 21:19:55.914069
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("An error occurred.")
    except RuntimeError as e:
        assert e.args[0] == "An error occurred."

# Generated at 2022-06-11 21:20:01.561954
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-11 21:20:04.362907
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # DocstringDeprecated.__init__(...)
    assert DocstringDeprecated([], "", "") == DocstringDeprecated([], "", "")


# Generated at 2022-06-11 21:20:39.077438
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    args = []
    description = "Return the value of the element at position index"
    type_name = "object"
    is_generator = False
    return_name = None
    assert DocstringReturns(args, description, type_name, is_generator, return_name)

# Generated at 2022-06-11 21:20:42.231855
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["test", ], "test", "test")
    assert docstring_deprecated.args == ["test", ]
    assert docstring_deprecated.description == "test"
    assert docstring_deprecated.version == "test"



# Generated at 2022-06-11 21:20:53.461332
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Build object to test constructor
    object_DocstringReturns = DocstringReturns("args", "description", "type_name", True)
    # Check that all attributes of the object have the expected value
    assert object_DocstringReturns.args == "args"
    assert object_DocstringReturns.description == "description"
    assert object_DocstringReturns.type_name == "type_name"
    assert object_DocstringReturns.is_generator == True
    # Check that constructor sets return_name as expected
    assert object_DocstringReturns.return_name is None
    # Check that object is an instance of DocstringMeta
    assert isinstance(object_DocstringReturns, DocstringMeta)

# Generated at 2022-06-11 21:20:55.201169
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("A test error")
    except ParseError as e:
        assert str(e) == "A test error"

# Generated at 2022-06-11 21:21:04.605586
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    # test meta property
    assert docstring.meta == []
    # test params property
    assert docstring.params == []
    # test raises property
    assert docstring.raises == []
    # test returns property
    assert docstring.returns is None
    # test deprecation property
    assert docstring.deprecation is None

# Unit tests for docstring_param

# Generated at 2022-06-11 21:21:12.920032
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['a'], 'a', 'b', 'c', True, 'd').args == ['a']
    assert DocstringParam(['a'], 'a', 'b', 'c', True, 'd').description == 'a'
    assert DocstringParam(['a'], 'a', 'b', 'c', True, 'd').arg_name == 'b'
    assert DocstringParam(['a'], 'a', 'b', 'c', True, 'd').type_name == 'c'
    assert DocstringParam(['a'], 'a', 'b', 'c', True, 'd').is_optional == True
    assert DocstringParam(['a'], 'a', 'b', 'c', True, 'd').default == 'd'



# Generated at 2022-06-11 21:21:23.437141
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        ["param"],
        "current ip address",
        "ip",
        "string",
        True,
        "localhost",
    )
    assert docstring_param.args == ["param"], "Error: args not initialized properly"
    assert docstring_param.description == "current ip address", "Error: description not initialized properly"
    assert docstring_param.arg_name == "ip", "Error: arg_name not initialized properly"
    assert docstring_param.type_name == "string", "Error: type_name not initialized properly"
    assert docstring_param.is_optional == True, "Error: is_optional not initialized properly"
    assert docstring_param.default == "localhost", "Error: default not initialized properly"


# Generated at 2022-06-11 21:21:26.057028
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "", "", None, None, None)


# Generated at 2022-06-11 21:21:31.359536
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert (DocstringRaises([], '', 'int') is not None)
    assert (DocstringRaises(['hi', 'string'], '', 'int') is not None)


# Generated at 2022-06-11 21:21:36.057094
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(["args", "args"], "test_description", "test_type").args == ["args", "args"]
    assert DocstringRaises(["args", "args"], "test_description", "test_type").description == "test_description"
    assert DocstringRaises(["args", "args"], "test_description", "test_type").type_name == "test_type"


# Generated at 2022-06-11 21:22:45.285657
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from pytest import raises
    from darglint.parse_transformer import ParseError

    with raises(TypeError):
        #  TypeError errors if args is not a list of strings
        assert DocstringMeta(1, 1)
    with raises(TypeError):
        #  TypeError errors if description is not a string
        assert DocstringMeta(['a'], 1)
    with raises(ValueError):
        #  ValueError errors if args is empty
        assert DocstringMeta([], 'a')
    #  test that DocstringMeta is properly initialized
    assert DocstringMeta(['a', 'b'], 'c')



# Generated at 2022-06-11 21:22:49.896346
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-11 21:22:55.842942
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam([1], "Description", "arg", "int", None, None)
    assert d.args == [1]
    assert d.description == "Description"
    assert d.arg_name == "arg"
    assert d.type_name == "int"
    assert d.is_optional == None


# Generated at 2022-06-11 21:22:59.720613
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(args=['some kind of error'], description='some kind of description', type_name='A')
    assert docstring


# Generated at 2022-06-11 21:23:01.391517
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    inst = DocstringMeta(["a"], "b")
    assert isinstance(inst, DocstringMeta)


# Generated at 2022-06-11 21:23:04.357588
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    pass
    assert DocstringReturns(args="", description="", type_name="", is_generator="", return_name="") is not None


# Generated at 2022-06-11 21:23:07.257666
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(
        ["deprecated"],
        "Some description",
        "v3.3.3",
    )
    assert doc.description == "Some description"
    assert doc.version == "v3.3.3"

# Generated at 2022-06-11 21:23:12.141648
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['0', '1', '2']
    description = 'exception'
    type_name = 'int'
    test_DocstringRaises = DocstringRaises(args, description, type_name)
    assert test_DocstringRaises.args == args
    assert test_DocstringRaises.description == description
    assert test_DocstringRaises.type_name == type_name


# Generated at 2022-06-11 21:23:13.219034
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    pass


# Generated at 2022-06-11 21:23:16.152571
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError"""
    try:
        raise ParseError('This is a message')
    except ParseError as exc:
        assert exc.args == ['This is a message']



# Generated at 2022-06-11 21:25:23.649575
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Arrange
    docstring = Docstring()
    list_of_args = [1, 2, 3]
    description = "description"

    # Act
    ds = DocstringMeta(list_of_args, description)

    # Assert
    assert ds.args == [1, 2, 3]
    assert ds.description == "description"


# Generated at 2022-06-11 21:25:26.221719
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.long_description == None
    assert docstring.short_description == None
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None

# Generated at 2022-06-11 21:25:35.493991
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['param']
    description = 'The description'
    type_name = 'The type name'
    is_generator = False
    return_name = 'The return name'
    obj = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert obj.args == ['param']
    assert obj.description == 'The description'
    assert obj.type_name == 'The type name'
    assert obj.is_generator == False
    assert obj.return_name == 'The return name'
    print('DocstringReturns passed')



# Generated at 2022-06-11 21:25:36.464884
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert(error is not None)


# Generated at 2022-06-11 21:25:39.209252
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(args=['deprecated'],
                              description='this method is deprecated',
                              version='1.0')
    assert doc.args == ['deprecated']
    assert doc.description == 'this method is deprecated'
    assert doc.version == '1.0'

# Generated at 2022-06-11 21:25:43.403383
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dsr = DocstringReturns(
        args=["x"],
        description="This is a method that removes a string 'x'",
        type_name="None",
        is_generator=False,
        return_name="y",
    )
    assert dsr.type_name == "None"
    assert dsr.is_generator == False
    assert dsr.return_name == "y"