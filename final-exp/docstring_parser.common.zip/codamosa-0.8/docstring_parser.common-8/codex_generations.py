

# Generated at 2022-06-11 21:15:45.869268
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-11 21:15:47.679586
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
        description = "description"
        args = []
        a = DocstringMeta(args, description)
        assert a.description == description
        assert a.args == args


# Generated at 2022-06-11 21:15:58.600212
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Valid arguments
    DocstringReturns(args=['return', 'returns'], description='The return value', is_generator=False, type_name='int', return_name='The return value')
    DocstringReturns(args=['yield', 'yields'], description='The yield value', is_generator=True, type_name='tuple', return_name='The yield value')
    # Invalid argument: args
    try:
        DocstringReturns(args=[], description='The return value', is_generator=False, type_name='int', return_name='The return value')
    except TypeError as e:
        assert str(e) == '__init__() missing 1 required positional argument: \'args\''
    # Invalid argument: description

# Generated at 2022-06-11 21:15:59.484980
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-11 21:16:03.218692
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['a', 'b'], 'c', None, False)
    assert x.args == ['a', 'b']
    assert x.description == 'c'
    assert x.type_name == None
    assert x.is_generator == False
    assert x.return_name == None

# Generated at 2022-06-11 21:16:07.977002
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Create an object for testing
    expected_args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    expected_description = 'description'
    test_object = DocstringMeta(expected_args, expected_description)

    # Assert DocstringMeta constructor initialized attribute 'args' as expected
    assert test_object.args == expected_args

    # Assert DocstringMeta constructor initialized attribute 'description' as expected
    assert test_object.description == expected_description


# Generated at 2022-06-11 21:16:17.196658
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = ""
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    if docstring_raises.description != "":
        raise RuntimeError("Failed to assign empty docstring to description")
    if docstring_raises.type_name != "type_name":
        raise RuntimeError("Failed to assign type_name to type_name")

    args = []
    description = ""
    type_name = None
    docstring_raises = DocstringRaises(args, description, type_name)
    if docstring_raises.description != "":
        raise RuntimeError("Failed to assign empty docstring to description")

# Generated at 2022-06-11 21:16:21.044806
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This function is deprecated.'
    version = '2.0'
    docstring_deprecated = DocstringDeprecated(args, description, version)

# Generated at 2022-06-11 21:16:26.642610
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(['args'], 'description', None)
    x.type_name = 'type_name'
    x.description = 'description'
    assert x.type_name == 'type_name'
    assert x.description == 'description'

# Generated at 2022-06-11 21:16:27.763161
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message")
    except ParseError:
        pass


# Generated at 2022-06-11 21:16:37.386352
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = list()
    description = "any"
    type_name = "any"
    ds = DocstringRaises(args, description, type_name)
    ds.args.append("any")
    print(ds.args[0])


# Generated at 2022-06-11 21:16:38.762652
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "Return value", "str", True)

# Generated at 2022-06-11 21:16:46.575604
# Unit test for constructor of class Docstring
def test_Docstring():

    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert isinstance(docstring.meta, list)
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-11 21:16:57.543376
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], None, None)
    assert DocstringDeprecated(1, None, None)
    assert DocstringDeprecated(True, None, None)
    assert DocstringDeprecated(1.0, None, None)
    assert DocstringDeprecated(" ", None, None)
    assert DocstringDeprecated([], [], [])
    assert DocstringDeprecated(1, 1, 1)
    assert DocstringDeprecated(True, True, True)
    assert DocstringDeprecated(1.0, 1.0, 1.0)
    assert DocstringDeprecated(" ", ["a"], ["b"])
test_DocstringDeprecated()


# Generated at 2022-06-11 21:16:59.988846
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error!")
    except Exception:
        pass


# Generated at 2022-06-11 21:17:07.281549
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = ""
    version = ""
    a = DocstringDeprecated(args, description, version)
    # Test if a object of DocstringDeprecated is created
    assert isinstance(a, DocstringDeprecated)
    # Test if __str__ function is working properly
    assert str(a) == f"DocstringDeprecated(args={args}, description='{description}', version='{version}')"  


# Generated at 2022-06-11 21:17:11.052668
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["some args"]
    description = "some description"

    meta = DocstringMeta(args, description)

    assert args == meta.args
    assert description == meta.description


# Generated at 2022-06-11 21:17:23.463277
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [
        ":param",
        "arg_name"
    ]
    description = "Description"
    type_name = None
    is_optional = None
    default = None
    arg_name = "arg_name"
    docstring_param = DocstringParam(args,description,arg_name,type_name,is_optional,default)
    assert docstring_param.args == [
        ":param",
        "arg_name"
    ]
    assert docstring_param.description == "Description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == None
    assert docstring_param.is_optional == None
    assert docstring_param.default == None

# Unit Test for constructor of class DocstringReturns

# Generated at 2022-06-11 21:17:34.624312
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "parameter", "arg", "argument", "attr", "attrib"]
    description = "this is a very good parameter"
    type_name = "int"
    is_generator = "True"
    return_name = "something"
    my_class = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert my_class.description == description
    assert my_class.type_name == type_name
    assert my_class.is_generator == True
    assert my_class.return_name == return_name
    for i in range(len(args)):
        assert my_class.args[i] == args[i]

test_DocstringReturns()


# Generated at 2022-06-11 21:17:40.142364
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(["param"], "desc", "arg", "str", True, "5")
    assert item.args == ["param"]
    assert item.description == "desc"
    assert item.is_optional == True
    assert item.arg_name == "arg"
    assert item.type_name == "str"
    assert item.default == "5"
    assert isinstance(item, DocstringParam)
    assert isinstance(item, DocstringMeta)



# Generated at 2022-06-11 21:17:56.037506
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'

    DocstringParam1 = DocstringParam(args=args, description=description, arg_name=arg_name, type_name=type_name, is_optional=is_optional, default=default)
    assert DocstringParam1.args == args
    assert DocstringParam1.description == description
    assert DocstringParam1.arg_name == arg_name
    assert DocstringParam1.type_name == type_name
    assert DocstringParam1.is_optional == is_optional
    assert DocstringParam1.default == default


# Generated at 2022-06-11 21:18:04.002778
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    # Test params
    assert docstring.params == []
    # Test raises
    assert docstring.raises == []
    # Test returns
    assert docstring.returns is None
    # Test deprecation
    assert docstring.deprecation is None



# Generated at 2022-06-11 21:18:15.380294
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param"]
    description = None
    arg_name = "test_name"
    type_name = "test_type"
    is_optional = True
    default = "test_default"

    doc_string_param1 = DocstringParam(
        args=args,
        description=description,
        arg_name=arg_name,
        type_name=type_name,
        is_optional=is_optional,
        default=default
    )
    doc_string_param2 = doc_string_param1.__init__(
        args=args,
        description=description,
        arg_name=arg_name,
        type_name=type_name,
        is_optional=is_optional,
        default=default
    )

# Generated at 2022-06-11 21:18:22.047728
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-11 21:18:26.787013
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(['args'], "description", "type_name")
    assert docstring.args == ['args']
    assert docstring.description == "description"
    assert docstring.type_name == "type_name"

# Generated at 2022-06-11 21:18:29.599989
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam([], 'description', 'arg_name', 'type_name', True, 'default')

# Unit tests for constructor of class DocstringReturns

# Generated at 2022-06-11 21:18:32.218616
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Bad type")
    except ParseError:
        pass
#~


# Generated at 2022-06-11 21:18:38.622705
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test DocstringReturns.__init__."""
    DocstringReturns([], "", "return_type", "return_name", is_generator = True)
    DocstringReturns([], "", "return_type", is_generator = True)
    DocstringReturns([], "", "return_type", return_name = "return_name", is_generator = True)
    DocstringReturns([], "", "return_type", return_name = "return_name", is_generator = False)


# Generated at 2022-06-11 21:18:41.357578
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docmeta = DocstringMeta(["param", "arg"], "description")
    assert docmeta.args == ["param", "arg"]
    assert docmeta.description == "description"

# Generated at 2022-06-11 21:18:45.101570
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns."""
    test_object = DocstringReturns(
        ['arg'], 'example description', 'type', True, 'name'
    )
    assert test_object.description == 'example description'
    assert test_object.type_name == 'type'
    assert test_object.is_generator is True
    assert test_object.return_name == 'name'



# Generated at 2022-06-11 21:18:52.362896
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["a", "b"], "c")
    assert d.args == ["a", "b"]
    assert d.description == "c"

# Generated at 2022-06-11 21:18:55.438465
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_deprecated = DocstringDeprecated(["deprecation"], ["description"], ["version"])
    assert doc_deprecated.description is "description"
    assert doc_deprecated.version is "version"

# Generated at 2022-06-11 21:19:00.716610
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_DocstringParam = DocstringParam(['a', 'b'], 'c', 'd', 'e', True, 'f')
    assert test_DocstringParam.args == ['a', 'b']
    assert test_DocstringParam.description == 'c'
    assert test_DocstringParam.arg_name == 'd'
    assert test_DocstringParam.type_name == 'e'
    assert test_DocstringParam.is_optional == True
    assert test_DocstringParam.default == 'f'



# Generated at 2022-06-11 21:19:04.330967
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["raises"],None,None,True)
    assert a.args == ["raises"]
    assert a.is_generator == True
    assert a.description == None


# Generated at 2022-06-11 21:19:09.117439
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.meta == []
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False


# Generated at 2022-06-11 21:19:14.795577
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []

    assert ds.params == []
    assert ds.raises == []

    with pytest.raises(AttributeError):
        ds.returns

    with pytest.raises(AttributeError):
        ds.deprecation

test_Docstring()

# Generated at 2022-06-11 21:19:22.728101
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['a'], 'hi', None, False)

    # test for class variable args
    assert x.args == ['a']

    # test for class variable description
    assert x.description == 'hi'

    # test for class variable type_name
    assert x.type_name is None

    # test for class variable is_generator
    assert x.is_generator == False

    # test for class variable return_name
    assert x.return_name is None



# Generated at 2022-06-11 21:19:27.893662
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(args=["a", "b", "c"], description="abc", version="abc")
    assert ds.args == ["a", "b", "c"]
    assert ds.description == "abc"
    assert ds.version == "abc"


# Generated at 2022-06-11 21:19:32.233934
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringMeta = DocstringDeprecated(['args'], 'description', 'version')
    assert DocstringMeta.args == ['args']
    assert DocstringMeta.description == 'description'
    assert DocstringMeta.version == 'version'


# Generated at 2022-06-11 21:19:36.765059
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    parsed = DocstringParam(['param'], 'description', 'arg', 'int', True, 'default')
    assert parsed.args == ['param']
    assert parsed.description == 'description'
    assert parsed.arg_name == 'arg'
    assert parsed.type_name == 'int'
    assert parsed.is_optional == True
    assert parsed.default == 'default'


# Generated at 2022-06-11 21:19:46.101451
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()


# Generated at 2022-06-11 21:19:52.341177
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a is not None
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []
    assert a.params == []
    assert a.raises == []
    assert a.returns is None
    assert a.deprecation is None


# Generated at 2022-06-11 21:19:57.511820
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    o = DocstringRaises(["a", "b", "c"], "d", "e")
    assert o.args == ["a", "b", "c"]
    assert o.description == "d"
    assert o.type_name == "e"


# Generated at 2022-06-11 21:20:01.739170
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    init_test = DocstringReturns(['return', 'returns'], None, 'int', False)
    assert init_test.args == ['return', 'returns']
    assert init_test.description is None
    assert init_test.type_name == 'int'
    assert init_test.is_generator == False
    assert init_test.return_name is None

# Generated at 2022-06-11 21:20:03.320348
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("")
    except ParseError:
        pass

# Generated at 2022-06-11 21:20:04.697960
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err


# Generated at 2022-06-11 21:20:09.148431
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "Some description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description



# Generated at 2022-06-11 21:20:11.617689
# Unit test for constructor of class ParseError
def test_ParseError():
    exception=Exception("there is an error")
    pe=ParseError("there is an error")
    assert exception.args==pe.args


# Generated at 2022-06-11 21:20:13.034455
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test')
    except:
        assert 1==1

# Generated at 2022-06-11 21:20:14.131908
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated", "1.2.3"], "This is deprecated", "1.2.3")


# Generated at 2022-06-11 21:20:28.070867
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	liste = [":returns:"]
	d = DocstringReturns(liste, None, None, False, None)
	assert d.args == liste
	assert d.description is None
	assert d.type_name is None
	assert d.is_generator is False
	assert d.return_name is None


# Generated at 2022-06-11 21:20:32.143814
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError("error")
    assert parse_error.__str__() == "error"
    assert parse_error.__repr__() == "error"

if __name__ == '__main__':
    test_ParseError()

# Generated at 2022-06-11 21:20:35.589986
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    testObject = DocstringMeta(["param"], "description")
    assert testObject.args == ["param"]
    assert testObject.description == "description"


# Generated at 2022-06-11 21:20:40.243990
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert len(docstring.meta) == 0
    assert str(docstring.short_description) == 'None'
    assert str(docstring.long_description) == 'None'
    assert str(docstring.blank_after_long_description) == 'False'
    assert str(docstring.blank_after_short_description) == 'False'



# Generated at 2022-06-11 21:20:46.915727
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta = DocstringRaises(["test1", "test2"], "testDescription", "testTypeName")
    assert isinstance(meta, DocstringRaises)
    assert meta.args == ["test1", "test2"]
    assert meta.description == "testDescription"
    assert meta.type_name == "testTypeName"
    assert not isinstance(meta, DocstringParam)
    assert not isinstance(meta, DocstringReturns)


# Generated at 2022-06-11 21:20:50.879250
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringmeta = DocstringMeta(["args"], "description" )
    assert docstringmeta.description == "description"
#Unit test for constructor of class DocstringParam

# Generated at 2022-06-11 21:20:56.724172
# Unit test for constructor of class Docstring
def test_Docstring():
    obj1 = Docstring()
    assert obj1.short_description is None
    assert obj1.long_description is None
    assert obj1.blank_after_short_description == False
    assert obj1.blank_after_long_description == False
    assert obj1.meta == []
    assert obj1.params == []
    assert obj1.raises == []
    assert obj1.returns == None
    assert obj1.deprecation == None


# Generated at 2022-06-11 21:21:02.052457
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param", "param1", ":", "param2"]
    type_name = "type1"
    arg_name = "arg1"
    description = "This is the description"
    is_optional = True
    default = "None"
    docstring_param = DocstringParam(
        args, 
        description,
        arg_name, 
        type_name, 
        is_optional, 
        default
    )
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-11 21:21:03.872211
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()


# Generated at 2022-06-11 21:21:08.235166
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['parameters']
    description = 'some description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    a = DocstringParam(args, description, arg_name, type_name, is_optional, default)

# Generated at 2022-06-11 21:21:34.341279
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test Docstring constructor."""
    tester = Docstring()
    assert tester.short_description is None
    assert tester.long_description is None
    assert tester.blank_after_short_description is False
    assert tester.blank_after_long_description is False
    assert tester.meta == []
    assert tester.params == []
    assert tester.raises == []
    assert tester.returns is None
    assert tester.deprecation is None


# Generated at 2022-06-11 21:21:41.353772
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test constructor with correct input
    assert DocstringParam(["param", "arg", "description"], "arg description", "arg", "a", True, "b")
    # Test constructor with wrong input
    try:
        if not DocstringParam(["param", "arg", "a", "b", "c"], 1, 2, 3, 4, 5) == TypeError:
            print("Error: test_DocstringParam_TypeError()")
    except TypeError:
        assert True
    # Test the docstring
    assert DocstringParam.__doc__


# Generated at 2022-06-11 21:21:46.468446
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert(docstring.long_description == None)
    assert(docstring.blank_after_short_description == False)
    assert(docstring.blank_after_long_description == False)
    assert(docstring.meta == [])

# unit test for the property function params

# Generated at 2022-06-11 21:21:50.366497
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arguments = ["Returns:"]
    description = None
    type_name = None
    is_generator = False
    return_name = None
    return_item = DocstringReturns(arguments, description, type_name, is_generator, return_name)
    return_item = None

# Generated at 2022-06-11 21:21:55.139969
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["param", "-version"], "fdsfafs", "0.0.1")
    assert docstring.args == ["param", "-version"]
    assert docstring.description == "fdsfafs"
    assert docstring.version == "0.0.1"

# Generated at 2022-06-11 21:21:58.645640
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    assert test.short_description == None
    assert test.long_description == None
    assert test.meta == []


# Generated at 2022-06-11 21:22:01.234273
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args == ("test", )


# Generated at 2022-06-11 21:22:06.286403
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = None
    type_name = None
    assert DocstringRaises(args, description, type_name).args == args
    assert DocstringRaises(args, description, type_name).description == description
    assert DocstringRaises(args, description, type_name).type_name == type_name
    

# Generated at 2022-06-11 21:22:08.411996
# Unit test for constructor of class ParseError
def test_ParseError():
    with raises(Exception):
        ParseError(1)
    assert repr(ParseError('test')) == "ParseError('test')"


# Generated at 2022-06-11 21:22:12.195013
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstr = DocstringMeta(['args'], 'description')
    assert docstr.args == ['args']
    assert docstr.description == 'description'


# Generated at 2022-06-11 21:22:51.431737
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [":param", "arg:"]
    description = " Hello"
    version = "1"
    DocstringDeprecated(args=args, description=description, version=version)

    args = [":param", "arg:"]
    description = " Hello"
    version = None
    DocstringDeprecated(args=args, description=description, version=version)

    args = []
    description = " Hello"
    version = None
    DocstringDeprecated(args=args, description=description, version=version)



# Generated at 2022-06-11 21:22:52.860144
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError


# Generated at 2022-06-11 21:22:55.927578
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dsr = DocstringRaises([], None, None);
    assert(dsr.args == [] and dsr.description == None and dsr.type_name == None)


# Generated at 2022-06-11 21:22:59.451199
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError as e:
        assert isinstance(e, RuntimeError)


# Generated at 2022-06-11 21:23:01.130992
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError("error")


# Generated at 2022-06-11 21:23:03.200426
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dummy = DocstringMeta(["param"], "description")
    assert dummy.args == ["param"]
    assert dummy.description == "description"

# Generated at 2022-06-11 21:23:05.616810
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    import sys
    m = DocstringParam([], '', 'arg_name', 'int', True, 'default')
    return m

# Generated at 2022-06-11 21:23:10.642903
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['raises'], 'description', 'ValueError')
    assert docstringRaises is not None
    assert docstringRaises.description == 'description'
    assert docstringRaises.type_name == 'ValueError'
    assert docstringRaises.args == ['raises']


# Generated at 2022-06-11 21:23:13.637687
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["param"], "desc")
    assert a.args == ["param"]
    assert a.description == "desc"


# Generated at 2022-06-11 21:23:18.147065
# Unit test for constructor of class Docstring
def test_Docstring():
    """Constructor of Docstring.

    :return:
    """
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []



# Generated at 2022-06-11 21:24:02.780897
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ['param', 'argument']
    test_description = 'Takes two numbers as input and returns their sum.'
    test_return_name = 'sum_result'
    test_type_name = 'int'
    test_is_generator = False
    # All the input args are valid, hence function should not raise an exception
    assert DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    # Invalid type_name
    test_type_name = 1
    try:
        DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    except:
        assert True
    # Invalid description
    test_description = 1

# Generated at 2022-06-11 21:24:06.182728
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Bad stuff happened")
    except ParseError as e:
        assert str(e) == "Bad stuff happened"



# Generated at 2022-06-11 21:24:10.440751
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert a.description == 'description'
    assert a.args == ['deprecated']
    assert a.version == 'version'


# Generated at 2022-06-11 21:24:14.632277
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsMeta = DocstringMeta(["args", "description"], ["args", "description"])
    assert dsMeta.args == ["args", "description"]
    assert dsMeta.description == ["args", "description"]



# Generated at 2022-06-11 21:24:16.257624
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam()
    assert type(dp) == DocstringParam
    return

# Generated at 2022-06-11 21:24:19.060010
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a=DocstringRaises([12,"hi",25,"wtf"], "hihello", None)
    assert a.args==[12,"hi",25,"wtf"]
    assert a.type_name==None
    assert a.description=="hihello"

# Generated at 2022-06-11 21:24:20.660582
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], None, None, None)


# Generated at 2022-06-11 21:24:24.305240
# Unit test for constructor of class Docstring
def test_Docstring():
    string = Docstring()
    print(string.short_description)
    print(string.long_description)



# Generated at 2022-06-11 21:24:27.599724
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of ParseError.

    :returns: ``None``
    """
    #Write your unit test here
    pass  # replace with your code

# Generated at 2022-06-11 21:24:33.013637
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'Test', '1.0.0')
    print("Args:"+str(docstring_deprecated.args))
    print("Description:"+str(docstring_deprecated.description))
    print("Version:" + str(docstring_deprecated.version))