

# Generated at 2022-06-11 21:15:46.475019
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    assert(DocstringDeprecated(["deprecated"], "", "2.0"))


# Generated at 2022-06-11 21:15:51.748378
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = "this is a test"
    version = "2.0"
    deprecated = DocstringDeprecated(args, description, version)
    #assert deprecated.args==[]
    assert deprecated.description == description
    assert deprecated.version == version


# Generated at 2022-06-11 21:15:56.411594
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['a'], 'b', 'c')
    assert isinstance(a, DocstringMeta)
    assert a.args == ['a']
    assert a.description == 'b'
    assert a.type_name == 'c'
    assert a.is_generator == False


# Generated at 2022-06-11 21:16:01.963998
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-11 21:16:05.030764
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    try:
        raise ParseError("")
    except ParseError as e:
        assert str(e) == ""
        print("Test Pass")


# Generated at 2022-06-11 21:16:12.609358
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-11 21:16:14.952965
# Unit test for constructor of class ParseError
def test_ParseError():
    """Create a ParseError object."""
    obj = ParseError()
    assert isinstance(obj, ParseError)
    # Unit test for constructor of class DocstringMeta

# Generated at 2022-06-11 21:16:18.431173
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns['is_generator'] = True
    DocstringReturns['type_name'] = str
    DocstringReturns['return_name'] = 'x'
    assert DocstringReturns['is_generator'] == True
 

# Generated at 2022-06-11 21:16:20.365829
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()

Docstring()

# Generated at 2022-06-11 21:16:24.617307
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    r = DocstringDeprecated( args=['a'], description=['a'], version=['1'])
    assert isinstance(r, DocstringDeprecated)


# Generated at 2022-06-11 21:16:30.834701
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as err:
        print(str(err))


# Generated at 2022-06-11 21:16:36.496583
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test for constructor of class DocstringDeprecated."""
    d = DocstringDeprecated(['deprecated'], 'Test', '1.0')
    assert d.args == ['deprecated']
    assert d.description == 'Test'
    assert d.version == '1.0'

# Generated at 2022-06-11 21:16:44.759693
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam"""
    docstring_param = DocstringParam(["args"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["args"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"
    


# Generated at 2022-06-11 21:16:51.831974
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    first_arg = ["param", "parameter", "arg", "argument", "attribute", "key","keyword"]
    second_arg = "description"
    third_arg = None
    fourth_arg = "type_name"
    fifth_arg = True
    sixth_arg = None
    assert DocstringReturns(first_arg, second_arg, third_arg, fourth_arg, fifth_arg, sixth_arg)


# Generated at 2022-06-11 21:16:55.403131
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError) as err:
        raise ParseError('90')
    assert str(err.value) == '90'


# Generated at 2022-06-11 21:16:59.581538
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    do_raises = DocstringRaises("raises",None,"ValueError")
    assert do_raises.args == ["raises"]
    assert do_raises.description == None
    assert do_raises.type_name == "ValueError"
    
    

# Generated at 2022-06-11 21:17:04.601371
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["s"]
    description = "This is a docstring"
    ds = DocstringMeta(args, description)
    assert ds is not None
    assert ds.args == ["s"]
    assert ds.description == "This is a docstring"


# Generated at 2022-06-11 21:17:08.028312
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of DocstringParam"""
    args = docstring_meta_args
    description = "DocstringParam instance"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = "default"
    DocstringParam_instance =  DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert isinstance(DocstringParam_instance, DocstringParam)


# Generated at 2022-06-11 21:17:13.532974
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docParam = DocstringParam(args = ["param"], description = "desc", arg_name = "arg_name", type_name = "type_name", is_optional = True, default = "default")
    assert docParam.description == "desc"
    assert docParam.arg_name == "arg_name"
    assert docParam.type_name == "type_name"
    assert docParam.is_optional == True
    assert docParam.default == "default"


# Generated at 2022-06-11 21:17:16.297721
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    import re
    m = re.search("Description", "Description: ")
    assert m.group(0) == "Description"

# Generated at 2022-06-11 21:17:21.357327
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([],[], None)



# Generated at 2022-06-11 21:17:24.843347
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    temp = DocstringMeta(['test'], 'test description')
    assert temp is not None
    assert len(temp.args) == 1
    assert temp.args[0] == 'test'
    assert temp.description == 'test description'



# Generated at 2022-06-11 21:17:29.875427
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(["a","b"], "QQQQQQ", "X")
    assert x.args == ["a","b"]
    assert x.description == "QQQQQQ"
    assert x.type_name == "X"

test_DocstringRaises()


# Generated at 2022-06-11 21:17:35.200860
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds is not None
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_long_description == False
    assert ds.blank_after_short_description == False
    assert len(ds.meta) == 0


# Generated at 2022-06-11 21:17:37.624341
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        a = DocstringParam([], '', '', '', '', '')
    except BaseException:
        pass


# Generated at 2022-06-11 21:17:39.031844
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['args'], 'description', 'type_name', True)

# Generated at 2022-06-11 21:17:45.133081
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # create some sample args
    myargs: [str] = ["param"]
    # create some sample description
    mydescr: str = " this is a description "
    # create a new instance of DocstringMeta
    dm = DocstringMeta(myargs, mydescr)
    # check if the initialization was done properly
    assert dm.args[0] == "param"
    assert dm.description == "this is a description"



# Generated at 2022-06-11 21:17:47.485306
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(['args'], 'Description', 'Type') == None


# Generated at 2022-06-11 21:17:55.791814
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(["param"], "parameter description","arg", "str", True, "None")
    assert p.args == ["param"], "args mismatch"
    assert p.description == "parameter description", "description mismatch"
    assert p.arg_name == "arg", "arg_name mismatch"
    assert p.type_name == "str", "type_name mismatch"
    assert p.is_optional == True, "is_optional mismatch"
    assert p.default == "None", "default mismatch"




# Generated at 2022-06-11 21:18:00.832253
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from modules.models.Docstrings import DocstringMeta
    from typing import List
    args = [":param"]
    description = "This is a description of the parameter"
    d1 = DocstringMeta(args, description)
    assert d1.args == args
    assert d1.description == description


# Generated at 2022-06-11 21:18:11.379211
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as e:
        assert str(e) == ""


# Generated at 2022-06-11 21:18:13.710646
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """ Test function."""
    DocstringReturns(["returns"], None, "int", True, "a_result")



# Generated at 2022-06-11 21:18:19.926141
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  x = DocstringParam(['a'], 'Description', 'b', 'c', 'd', 'e')
  assert x.args == ['a']
  assert x.description == 'Description'
  assert x.arg_name == 'b'
  assert x.type_name == 'c'
  assert x.is_optional == 'd'
  assert x.default == 'e'


# Generated at 2022-06-11 21:18:27.175716
# Unit test for constructor of class Docstring
def test_Docstring():
    '''
    Test constuctor of class Docstring with set values for parameters
    '''
    docstring_instance = Docstring()
    assert docstring_instance.short_description == None
    assert docstring_instance.long_description == None
    assert docstring_instance.blank_after_short_description == False
    assert docstring_instance.blank_after_long_description == False
    assert docstring_instance.meta == []
    
    

# Generated at 2022-06-11 21:18:31.426119
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-11 21:18:35.053807
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test for DocstringMeta class."""
    meta = DocstringMeta(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"], "Docstring Meta")
    # Test __init__ method
    assert meta.args == ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    assert meta.description == "Docstring Meta"

# Generated at 2022-06-11 21:18:40.197384
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test init with required arguments
    args = []
    description = 'test_description'
    type_name = 'test_type_name'
    test_object = DocstringRaises(args, description, type_name)
    assert test_object.args == args
    assert test_object.description == description
    assert test_object.type_name == type_name

# Generated at 2022-06-11 21:18:42.446577
# Unit test for constructor of class ParseError
def test_ParseError():
    def func():
        raise ParseError
    try:
        func()
    except RuntimeError:
        pass


# Generated at 2022-06-11 21:18:43.878495
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err is not None, "Constructor of ParseError should not return None"


# Generated at 2022-06-11 21:18:46.671714
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(
        args=["1", "2"], description="some description"
    )
    assert docstring_meta.args == ["1", "2"]
    assert docstring_meta.description == "some description"



# Generated at 2022-06-11 21:19:03.529899
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], None, None)

# Generated at 2022-06-11 21:19:05.861135
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError:
        pass
    else:
        assert False



# Generated at 2022-06-11 21:19:11.009292
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = ''
    type_name = ''

    a = DocstringReturns(args, description, type_name)
    a.return_name = ''
    assert a.return_name == ''
    assert a.meta
    assert a.args
    assert a.description
    assert a.type_name


# Generated at 2022-06-11 21:19:16.549813
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # initialization
    param = DocstringParam(["arg", "description"], arg_name="arg", type_name=None, is_optional=False, default=None)

    # Expected results
    args = ["arg", "description"]
    description = None
    type_name = None
    is_optional = False
    default = None
    arg_name = "arg"

    # assert statements
    assert param.args == args
    assert param.description == description
    assert param.type_name == type_name
    assert param.is_optional == is_optional
    assert param.default == default
    assert param.arg_name == arg_name



# Generated at 2022-06-11 21:19:22.019762
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []




# Generated at 2022-06-11 21:19:24.920155
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(args = None, description = None, type_name = None)


# Generated at 2022-06-11 21:19:28.321724
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], None, "version")
    assert d.args == ["deprecated"]
    assert d.description == None
    assert d.version == "version"


# Generated at 2022-06-11 21:19:30.326131
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['returns'], 'Return nothing.', '', False)



# Generated at 2022-06-11 21:19:33.998246
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["a"], "b", "c")
    assert a.args == ["a"]
    assert a.description == "b"
    assert a.version == "c"


# Generated at 2022-06-11 21:19:39.525683
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_DocstringRaises = DocstringRaises([],[],"test")
    assert test_DocstringRaises
    assert test_DocstringRaises.args == []
    assert test_DocstringRaises.description == []
    assert test_DocstringRaises.type_name == "test"


# Generated at 2022-06-11 21:20:13.733837
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args1", "args2"]
    description = "description"
    meta = DocstringMeta(args,description)
    assert meta.args == args
    assert meta.description == description



# Generated at 2022-06-11 21:20:17.926999
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test constructor of class DocstringDeprecated."""
    test_instance = DocstringDeprecated(['1.2', '3.4'], "description", "")
    assert isinstance(test_instance, DocstringDeprecated)


# Generated at 2022-06-11 21:20:19.513064
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        DocstringDeprecated(['deprecated'], 'test', 'version')
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-11 21:20:26.198608
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring=Docstring()
    if test_docstring.short_description is None:
        print ("short_description is None OK \n")
    else :
        print ("short_description is NOT None bad \n")
    if test_docstring.long_description is None:
        print ("long_description is None OK \n")
    else :
        print ("long_description is NOT None bad \n")
    if test_docstring.blank_after_short_description == False:
        print ("blank_after_short_description is False OK \n")
    else :
        print ("blank_after_short_description is NOT False bad \n")
    if test_docstring.blank_after_long_description == False:
        print ("blank_after_long_description is False OK \n")

# Generated at 2022-06-11 21:20:28.762254
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    assert error.args==("test",)

# Generated at 2022-06-11 21:20:31.892129
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test for constructor of class DocstringReturns."""
    docstringReturns = DocstringReturns(None, None, None, None, None)
    assert docstringReturns


# Generated at 2022-06-11 21:20:34.182302
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    return DocstringRaises(['raises', 'MyError'], 'Error was raised', 'MyError')


# Generated at 2022-06-11 21:20:40.360369
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(["returns"], "First line of description.\nSecond line of description.\nThird line of description.", "int", False, "x")
    assert d.args == ["returns"]
    assert d.description == "First line of description.\nSecond line of description.\nThird line of description."
    assert d.type_name == "int"
    assert d.return_name == "x"
    assert d.is_generator == False

# Generated at 2022-06-11 21:20:41.810855
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError

# Generated at 2022-06-11 21:20:54.452179
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    class_docstring = DocstringReturns([], "This is a class", "class", False)
    assert class_docstring.description == "This is a class"
    assert class_docstring.type_name == "class"
    function_docstring = DocstringReturns(
        [], "This is a function", "function", False)
    assert function_docstring.description == "This is a function"
    assert function_docstring.type_name == "function"
    function_generator_docstring = DocstringReturns(
        [], "This is a function", "function", True)
    assert function_generator_docstring.description == "This is a function"
    assert function_generator_docstring.type_name == "function"
    assert function_generator_docstring.is_generator

# Generated at 2022-06-11 21:21:59.200814
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Something went wrong")
    except ParseError as err:
        assert err.args == ("Something went wrong",)



# Generated at 2022-06-11 21:22:07.957274
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "The content of the parameter", "parameter_name", "parameter_type", True, "default",)
    assert len(docstring_param.args) == 1
    assert type(docstring_param.args[0]) == str
    assert docstring_param.description == "The content of the parameter"
    assert docstring_param.arg_name == "parameter_name"
    assert docstring_param.type_name == "parameter_type"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-11 21:22:12.922077
# Unit test for constructor of class ParseError
def test_ParseError():
    OK="OK"
    print("Testing Constructor of Class ParseError ->", end=" ")
    try:
        raise ParseError("Erreur")
    except ParseError as e:
        print(OK)


# Generated at 2022-06-11 21:22:22.828733
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["args"]
    description = "this is a description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = "32"
    test_var = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert test_var.args == ["args"]
    assert test_var.description == "this is a description"
    assert test_var.arg_name == "arg_name"
    assert test_var.is_optional == False
    assert test_var.type_name == "type_name"
    assert test_var.default == "32"


# Generated at 2022-06-11 21:22:26.672998
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    testReturns = DocstringReturns(["return"], "This is a test", "int", False, "")
    assert testReturns.description == "This is a test"
    return


# Generated at 2022-06-11 21:22:29.438766
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        assert True
    else:
        assert False

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-11 21:22:37.630972
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test DocstringRaises."""
    test_args = ['raises', 'exception']
    test_description = 'a description of the exception'
    test_type_name = 'ValueError'
    test_docstring_raises = DocstringRaises(test_args, test_description, test_type_name)
    # test the constructor of class DocstringRaises
    assert test_docstring_raises.args == test_args
    assert test_docstring_raises.description == test_description
    assert test_docstring_raises.type_name == test_type_name


# Generated at 2022-06-11 21:22:46.149289
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(
        [],
        "This is the parameter description",
        "param1",
        "str",
        False,
        "default value is a string",
    )
    assert item.args == []
    assert item.description == "This is the parameter description"
    assert item.arg_name == "param1"
    assert item.type_name == "str"
    assert item.is_optional == False
    assert item.default == "default value is a string"



# Generated at 2022-06-11 21:22:49.895845
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test for incorrect input
    try:
        m = DocstringMeta(None, None)
    except Exception:
        assert True
    # Test for correct input
    assert DocstringMeta(["param"], "asdf").args == ["param"]
    assert DocstringMeta(["param"], "asdf").description == "asdf"


# Generated at 2022-06-11 21:22:56.494128
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["arg1", "arg2"]
    description = "description"
    version = "1.0"
    assert DocstringDeprecated(args, description, version).type_name is None
    assert DocstringDeprecated(args, description, version).description == description
    assert DocstringDeprecated(args, description, version).version == version
    assert DocstringDeprecated(args, description, version).args == args

# Generated at 2022-06-11 21:25:05.393780
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam('param arg description', 'description', 'arg', 'arg', True, 'default')


# Generated at 2022-06-11 21:25:10.200316
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta = DocstringMeta([":param"], "docstring")
    assert docstringMeta.args == [":param"], "docstringMeta.args should equal [':param']."
    assert docstringMeta.description == "docstring", "docstringMeta.description should equal 'docstring'. "



# Generated at 2022-06-11 21:25:13.388890
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert isinstance(doc, DocstringParam)
    assert isinstance(doc, DocstringMeta)



# Generated at 2022-06-11 21:25:15.846014
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(["param"], "description")
    assert obj.args == ["param"]
    assert obj.description == "description"



# Generated at 2022-06-11 21:25:17.982739
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    k = DocstringMeta(["param"], "description")
    assert k.args == ["param"]
    assert k.description == "description"


# Generated at 2022-06-11 21:25:24.163041
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam([], "", "", "", "", "")
    assert dp.arg_name == "", "arg_name should be ''"
    assert dp.type_name == "", "type_name should be ''"
    assert dp.is_optional == "", "is_optional should be ''" 
    assert dp.default == "", "default should be ''"


# Generated at 2022-06-11 21:25:26.619975
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """
    >>> import doctyping
    >>> docstring_raises = doctyping.DocstringRaises([':param'], 'abc', 'abc')
    >>> docstring_raises
    <DocstringMeta symbolizing :raises metadata.>
    """
    pass


# Generated at 2022-06-11 21:25:29.997707
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(['a'], 'asd', None)
    assert doc.type_name == None
    assert isinstance(doc, DocstringMeta)


# Generated at 2022-06-11 21:25:34.166161
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(['deprecated(since=2.0)'], '', '2.0')
    assert meta.args == ['deprecated(since=2.0)']
    assert meta.description == None
    assert meta.version == '2.0'


# Generated at 2022-06-11 21:25:36.619539
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    m = DocstringMeta([], "desc")
    assert m.description == "desc"
    assert m.args == []
