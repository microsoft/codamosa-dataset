

# Generated at 2022-06-11 21:15:45.454787
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    length = 10
    
    args = list(range(length))
    description = "Test"
    type_name = "Test"
    test = DocstringRaises(args, description, type_name)
    
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name


# Generated at 2022-06-11 21:15:48.760020
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "type_name <- None"]
    description = None
    type_name = None
    docstringRaises = DocstringRaises(args, description, type_name)
    assert (docstringRaises.args == ["param", "type_name <- None"])
    assert (docstringRaises.description == None)
    assert (docstringRaises.type_name == None)


# Generated at 2022-06-11 21:15:51.417456
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "desc", "typedesc", False)
    return None


# Generated at 2022-06-11 21:15:55.658091
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-11 21:15:58.964430
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["some_arg"]
    description = "Some description"
    type_name = "SomeType"
    o = DocstringRaises(args, description, type_name)
    assert o.args == args
    assert o.description == description
    assert o.type_name == type_name



# Generated at 2022-06-11 21:16:04.312153
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    type_name = "Type_name"
    description = "Description"
    args = []
    Docstring_Raises = DocstringRaises(args, description, type_name)
    assert type(Docstring_Raises) == DocstringRaises
    assert Docstring_Raises.args == []
    assert Docstring_Raises.type_name == type_name
    assert Docstring_Raises.description == description


# Generated at 2022-06-11 21:16:11.736598
# Unit test for constructor of class Docstring
def test_Docstring():
  test = Docstring()
  assert test.short_description == None
  assert test.long_description == None
  assert test.blank_after_short_description == False
  assert test.blank_after_long_description == False
  assert test.meta == []
  assert test.params == []
  assert test.raises == []
  assert test.returns == None
  assert test.deprecation == None

# Generated at 2022-06-11 21:16:15.716205
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "description", "version")
    assert d.description == "description"
    assert d.version == "version"

    d = DocstringDeprecated(["deprecated"], "description", None)
    assert d.description == "description"
    assert d.version is None



# Generated at 2022-06-11 21:16:18.192443
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["a", "b"], "c")
    assert meta.args == ["a", "b"]
    assert meta.description == "c"


# Generated at 2022-06-11 21:16:28.309641
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["return","returns"], "Returns a number", "int", False)
    assert a.args == ["return", "returns"]
    assert a.description == "Returns a number"
    assert a.type_name == "int"
    assert a.is_generator == False
    assert a.return_name == None

    b = DocstringReturns(
        ["returns"],
        "Returns the name of a person",
        "str",
        False,
        return_name="name",
    )
    assert b.return_name == "name"

# Generated at 2022-06-11 21:16:37.076972
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(args = ['param', 'arg'], description = 'describing')
    assert d.args == ['param', 'arg']
    assert d.description == 'describing'


# Generated at 2022-06-11 21:16:44.000167
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(["param","arg","argument"],None,"arg_name","type_name",True,"default")
    assert str(obj.args) == "['param', 'arg', 'argument']"
    assert obj.description == None
    assert obj.arg_name == "arg_name"
    assert obj.type_name == "type_name"
    assert obj.is_optional == True
    assert obj.default == "default"


# Generated at 2022-06-11 21:16:46.906277
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['args', 'description'], 'desc')
    assert d.args == ['args', 'description']
    assert d.description == 'desc'
    

# Generated at 2022-06-11 21:16:54.696629
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError', 'if', 'something', 'happens']
    description = 'if something happens'
    type_name = 'ValueError'
    
    a = DocstringRaises(args, description, type_name)

    print(a.args)
    print(a.description)
    print(a.type_name)


if __name__ == '__main__':
    test_DocstringRaises()

# Generated at 2022-06-11 21:16:59.723067
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():  # noqa: D103
    args = ['deprecated']
    description = 'a deprecated function'
    version = '1.0'
    ds = DocstringDeprecated(args, description, version)
    assert ds.args == args
    assert ds.description == description
    assert ds.version == version


# Generated at 2022-06-11 21:17:01.789278
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns([],None,None,False)
    assert ds.args == []
    assert ds.description == None



# Generated at 2022-06-11 21:17:06.847421
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg1", "arg2"]
    dm = DocstringMeta(args, "DocstringMeta object")
    assert args == dm.args
    assert "DocstringMeta object" == dm.description


# Generated at 2022-06-11 21:17:10.725531
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['param'], 'desc')
    assert docstring_meta.args[0] == 'param'
    assert docstring_meta.description == 'desc'


# Generated at 2022-06-11 21:17:15.244906
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args", "arg", "argument", "attribute", "key", "keyword"]
    description = "some description"
    docMet = DocstringMeta(args, description)


# Generated at 2022-06-11 21:17:23.241592
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    arg_name = 'arg'
    type_name = None
    is_optional = False
    default = None
    a = DocstringParam(args, 'description', arg_name, type_name, is_optional, default)
    assert a.args == ['param', 'arg', 'description']
    assert a.description == 'description'
    assert a.arg_name == 'arg'
    assert a.type_name == None
    assert a.is_optional == False
    assert a.default == None


# Generated at 2022-06-11 21:17:34.852466
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert len(a.meta) == 0


# Generated at 2022-06-11 21:17:38.645354
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []


# Generated at 2022-06-11 21:17:43.235176
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args= ['arg','description']
    x = DocstringParam(args,'description','arg','string','is_optional','default')
    assert x.description == 'description'
    assert x.arg_name == 'arg'
    assert x.type_name == 'string'
    assert x.is_optional == 'is_optional'
    assert x.default == 'default'

# Generated at 2022-06-11 21:17:48.229275
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d=DocstringMeta(["a", "b", "c"], "hello")
    assert d.args == ["a", "b", "c"], "args should be a,b,c"
    assert d.description == "hello", "args should be hello"
    return


# Generated at 2022-06-11 21:17:55.420499
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['returns', 'type_name', 'is_generator', 'return_name'], 'description', 'type_name', True, 'return_name')
    assert isinstance(a, DocstringReturns)
    assert a.description == 'description'
    assert a.type_name == 'type_name'
    assert a.is_generator == True
    assert a.return_name == 'return_name'


# Generated at 2022-06-11 21:18:05.572969
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns_list = [item for item in dir(DocstringReturns) if "__" not in item]
    for i in range(4):
        for j in range(4):
            for k in range(4):
                for l in range(4):
                    with pytest.raises(TypeError):
                        DocstringReturns(*range(10))
                    DocstringReturns(*[None for _ in range(4)])

# Generated at 2022-06-11 21:18:12.978532
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    # Create a DocstringDeprecated() object, verify that it's attributes
    # match the expected values
    args = ['param', 'arg']
    description = "description"
    version = "version"
    d = DocstringDeprecated(args, description, version)
    assert(d.args[0] == 'param' and d.args[1] == 'arg')
    assert(d.description == description)
    assert(d.version == version)


# Generated at 2022-06-11 21:18:18.832970
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test = DocstringReturns(["returns"], "description", "type_name", True, "return_name")
    assert test.args == ["returns"]
    assert test.description == "description"
    assert test.type_name == "type_name"
    assert test.is_generator == True
    assert test.return_name == "return_name"


# Generated at 2022-06-11 21:18:24.590859
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(["deprecated", "since", "1.0"], "description", "1.0")

    assert docstringDeprecated.args == ["deprecated", "since", "1.0"]
    assert docstringDeprecated.description == "description"
    assert docstringDeprecated.version == "1.0"

# Generated at 2022-06-11 21:18:31.559942
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test is_optional = True
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'str'
    is_optional = True
    default = 'None'
    DocstringParam(args, description, arg_name, type_name, is_optional, default)

    # Test is_optional = False
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'str'
    is_optional = False
    default = 'None'
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-11 21:18:53.111518
# Unit test for constructor of class Docstring
def test_Docstring():
    test_instance = Docstring()
    assert test_instance.short_description is None
    assert test_instance.long_description is None
    assert test_instance.blank_after_short_description is False
    assert test_instance.blank_after_long_description is False
    assert test_instance.meta == []
    assert test_instance.params == []
    assert test_instance.raises == []
    assert test_instance.returns is None
    assert test_instance.deprecation is None



# Generated at 2022-06-11 21:18:57.275594
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param"]
    description = "This is the description"
    version = "2.0.0"
    d = DocstringDeprecated(args, description, version)
    assert d is not None
    assert d.args is args
    assert d.description is description
    assert d.version is version


# Generated at 2022-06-11 21:19:01.343268
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert isinstance(ds.meta, list)



# Generated at 2022-06-11 21:19:07.665553
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns == None
    assert doc.deprecation == None

# Generated at 2022-06-11 21:19:14.029748
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['param'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert dp.args == ['param']
    assert dp.description == 'description'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == 'is_optional'
    assert dp.default == 'default'

if __name__ == '__main__':
    test_DocstringParam()

# Generated at 2022-06-11 21:19:15.858246
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as e:
        assert str(e) == 'Argument is missing'


# Generated at 2022-06-11 21:19:18.669767
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    r = DocstringRaises([], "", "")
    assert r.args == []
    assert r.description == ""
    assert r.type_name == ""


# Generated at 2022-06-11 21:19:26.182056
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    string = "this is a string"
    docstring = DocstringParam([string], string, string, string, False, string)
    assert docstring.args[0] == string
    assert docstring.description == string
    assert docstring.arg_name == string
    assert docstring.type_name == string
    assert docstring.is_optional == False
    assert docstring.default == string


# Generated at 2022-06-11 21:19:27.891447
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['arg'], 'description', 'version') is not None

# Generated at 2022-06-11 21:19:31.795869
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a=DocstringRaises(['param'], None, None)
    assert a.args==['param']
    assert a.description==None
    assert a.type_name==None


# Generated at 2022-06-11 21:19:47.926460
# Unit test for constructor of class ParseError
def test_ParseError():
    """Expects AssertionError because args aren't given."""
    assert False, "TODO"

# Generated at 2022-06-11 21:19:54.958806
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "type_name", "is_generator", "return_name"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_re = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_re.args==args
    assert docstring_re.description==description
    assert docstring_re.type_name==type_name
    assert docstring_re.is_generator==is_generator
    assert docstring_re.return_name==return_name


# Generated at 2022-06-11 21:20:03.066326
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "Raises", "Ra", "R", "raise", "raiseexception", "raiseex", "exception"]
    description = "This is an example description"
    type_name = "IOError"
    test_case1 = DocstringRaises(args, description, type_name)
    assert test_case1.args == args
    assert test_case1.description == description
    assert test_case1.type_name == type_name

    test_case2 = DocstringRaises(args, None, None)
    assert test_case2.args == args
    assert test_case2.description == None
    assert test_case2.type_name == None


# Generated at 2022-06-11 21:20:05.899875
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["param"], "hello world")
    assert dm.args == ["param"]
    assert dm.description == "hello world"



# Generated at 2022-06-11 21:20:12.786899
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = 'Something is wrong'
    type_name = 'ValueError'
    assert DocstringRaises(args, description, type_name).__class__.__name__ == 'DocstringRaises'
    #assert DocstringRaises(args, description, type_name).description == 'Something is wrong'
    #assert DocstringRaises(args, description, type_name).type_name == 'ValueError'


# Generated at 2022-06-11 21:20:18.113136
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['param'], "Description", "Type")
    assert isinstance(docstringRaises, DocstringRaises)
    assert docstringRaises.args == ['param']
    assert docstringRaises.description == "Description"
    assert docstringRaises.type_name == "Type"


# Generated at 2022-06-11 21:20:24.822618
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_para = DocstringParam(
        args = ["param", ":", "arg"],
        description = "type of arg",
        arg_name = "arg",
        type_name = str,
        is_optional = True,
        default = "some_string",
    )
    assert docstring_para.args == ["param", ":", "arg"]
    assert docstring_para.description == "type of arg"
    assert docstring_para.arg_name == "arg"
    assert docstring_para.type_name == str
    assert docstring_para.is_optional == True
    assert docstring_para.default == "some_string"
    print("Test for constructor of DocstringParam passed!")


# Generated at 2022-06-11 21:20:30.770855
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "typename"
    dr = DocstringRaises(args, description, type_name)
    assert dr.args == args
    assert dr.description == description
    assert dr.type_name == type_name

# Generated at 2022-06-11 21:20:32.550168
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta("args", "description")


# Generated at 2022-06-11 21:20:34.436783
# Unit test for constructor of class ParseError
def test_ParseError():

    with pytest.raises(RuntimeError):
        
        raise ParseError("error")

# Generated at 2022-06-11 21:21:07.929728
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = (['return'], 'string', None, None, None)
    obj = DocstringReturns(args[0], args[1], args[2], args[3], args[4])
    assert obj.args == ['return']
    assert obj.description == 'string'
    assert obj.type_name == None
    assert obj.is_generator == None
    assert obj.return_name == None


# Generated at 2022-06-11 21:21:12.609354
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring"""
    doc_string = Docstring()
    assert doc_string.short_description == None
    assert doc_string.long_description == None
    assert doc_string.blank_after_short_description == False
    assert doc_string.blank_after_long_description == False
    assert doc_string.params == []
    assert doc_string.raises == []
    assert doc_string.returns ==  None

# Generated at 2022-06-11 21:21:14.162664
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['a', 'b'], 'c', 'd')

# Generated at 2022-06-11 21:21:16.925297
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()


# Generated at 2022-06-11 21:21:20.986669
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """ DocstringMeta class constructor test."""
    meta = DocstringMeta(['arg'], 'Docstring description.')
    assert meta.args == ['arg']
    assert meta.description == 'Docstring description.'


# Generated at 2022-06-11 21:21:24.890149
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([1,2,3], 'desc', 'Type')
    assert a.args == [1,2,3]
    assert a.description == 'desc'
    assert a.type_name == 'Type'

# Generated at 2022-06-11 21:21:29.335086
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['paramp'], 'description', 'arg_name', 'type_name', 'is_optional','default') != None


# Generated at 2022-06-11 21:21:30.589048
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert True



# Generated at 2022-06-11 21:21:31.657898
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()


# Generated at 2022-06-11 21:21:35.694464
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert issubclass(ParseError, RuntimeError)
    assert isinstance(error, ParseError)
    assert not isinstance(error, RuntimeError)
    assert isinstance(error, RuntimeError)
    assert isinstance(error, Exception)
    assert isinstance(error, BaseException)


# Generated at 2022-06-11 21:22:37.843978
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    Test DocString object as it is not tested by test_parser.py
    """
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-11 21:22:43.183406
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    '''
    This is unit test for DocstringReturns()
    '''
    a = DocstringReturns(args=['aa'], description='bb', type_name='aa', is_generator=False, return_name=None)
    print(a.description)


# Generated at 2022-06-11 21:22:49.228941
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringparam = DocstringParam(["param", "arg"], "parameter description", "arg", "int", True, "10")
    assert docstringparam.args == ["param", "arg"]
    assert docstringparam.description == "parameter description"
    assert docstringparam.arg_name == "arg"
    assert docstringparam.type_name == "int"
    assert docstringparam.is_optional == True
    assert docstringparam.default == "10"


# Generated at 2022-06-11 21:22:56.799541
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(['a', 'b', 'c'],'qwerty', 'i', 'j', True, 'dfgh')
    assert d.args == ['a', 'b', 'c']
    assert d.description == 'qwerty'
    assert d.arg_name == 'i'
    assert d.type_name == 'j'
    assert d.is_optional == True
    assert d.default == 'dfgh'


# Generated at 2022-06-11 21:23:03.352517
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test the constructor of DocstringReturns."""
    d = DocstringReturns([], '', '')
    assert d.args == []
    assert d.type_name == ""
    assert d.is_generator == False
    assert d.return_name == None
    assert d.description == ''
    d = DocstringReturns([], '', '', True, "abc")
    assert d.return_name == "abc"


# Generated at 2022-06-11 21:23:10.767383
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'typename'
    is_generator = True
    return_name = None
    s = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert s.args == args
    assert s.description == description
    assert s.type_name == type_name
    assert s.is_generator == is_generator
    assert s.return_name == return_name
    

# Generated at 2022-06-11 21:23:12.807683
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert type(err) is ParseError

# Generated at 2022-06-11 21:23:18.493347
# Unit test for constructor of class Docstring
def test_Docstring():
    '''
    Test the constructor of Docstring
    '''
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0
    assert len(docstring.params) == 0
    assert len(docstring.raises) == 0


# Generated at 2022-06-11 21:23:24.922228
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep = DocstringDeprecated(args=['deprecated'], description='This method is deprecated.', version='1.0')
    assert dep.args == ['deprecated'], "FAILED test_DocstringDeprecated"
    assert dep.description == 'This method is deprecated.', "FAILED test_DocstringDeprecated"
    assert dep.version == '1.0', "FAILED test_DocstringDeprecated"


# Generated at 2022-06-11 21:23:30.518564
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    var = DocstringDeprecated(['a', 'b', 'c'], 'Description', 'Version')
    assert var.args[0] == 'a'
    assert var.args[1] == 'b'
    assert var.args[2] == 'c'
    assert var.description == 'Description'
    assert var.version == 'Version'


# Generated at 2022-06-11 21:25:31.378905
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dsr = DocstringRaises(["raises"], "description", "type_name")
    print(dsr.description)
    assert dsr.description == 'description'



# Generated at 2022-06-11 21:25:34.528136
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string.short_description is None
    assert doc_string.long_description is None
    assert doc_string.blank_after_short_description == False
    assert doc_string.blank_after_long_description == False
    assert doc_string.meta == []

    assert doc_string.params == []
    assert doc_string.raises == []
    assert doc_string.returns == None
    assert doc_string.deprecation == None
