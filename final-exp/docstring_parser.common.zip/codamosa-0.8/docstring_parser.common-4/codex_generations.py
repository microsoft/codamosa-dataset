

# Generated at 2022-06-11 21:15:48.636552
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns([':return:','returns','return'],
                        "Test description",'none','False','TestName')
    assert docstring_returns.args == [':return:','returns','return']
    assert docstring_returns.description == 'Test description'
    assert docstring_returns.type_name == 'none'
    assert docstring_returns.is_generator == 'False'
    assert docstring_returns.return_name == 'TestName'

# Generated at 2022-06-11 21:15:53.089833
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []



# Generated at 2022-06-11 21:15:57.523151
# Unit test for constructor of class ParseError
def test_ParseError():
    # First test with no args passed
    try:
        raise ParseError()
    except RuntimeError as err:
        pass
    # Second test with args passed
    try:
        raise ParseError("Testing the constructor of class ParseError")
    except RuntimeError as err:
        pass


# Generated at 2022-06-11 21:16:00.793221
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['a', 'b', 'c']
    description = 'this is the description'
    obj = DocstringMeta(args, description)
    assert obj.args == args
    assert obj.description == description


# Generated at 2022-06-11 21:16:02.727129
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns("returns", "a number", "int", False, "my_name")


# Generated at 2022-06-11 21:16:06.009651
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(
                args=['version'],
                description="",
                version="0.1"
            )
    assert(docstring.args == ['version'])
    assert(docstring.description == "")
    assert(docstring.version == "0.1")

# Generated at 2022-06-11 21:16:07.061739
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns()

# Generated at 2022-06-11 21:16:09.129323
# Unit test for constructor of class Docstring
def test_Docstring():
    my_docstring = Docstring()


# Generated at 2022-06-11 21:16:14.412211
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [
        "function",
        ":param",
        "foo",
        ":type",
        "object",
        ":default",
        None,
        ":opt",
        "True",
    ]
    DocstringParam(
        args, "foo does something", arg_name="foo", type_name="object", is_optional="True", default=None
    )


# Generated at 2022-06-11 21:16:18.914879
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_ = DocstringRaises(args=None,
                                        description=None,
                                        type_name=None)
    assert docstring_raises_.args is None
    assert docstring_raises_.description is None
    assert docstring_raises_.type_name is None



# Generated at 2022-06-11 21:16:25.928038
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Parse error")
    except ParseError as e:
        assert str(e) == "Parse error"

# Generated at 2022-06-11 21:16:27.765927
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    with pytest.raises(TypeError) as excinfo:
        DocstringReturns()



# Generated at 2022-06-11 21:16:30.798045
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated([""], "message", "version")
    assert docstring_deprecated.description == "message"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-11 21:16:34.961609
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['a']
    description = 'raises ValueError'
    type_name = 'ValueError'
    DocstringRaises(args, description, type_name)



# Generated at 2022-06-11 21:16:38.617891
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    try:
        raise ParseError
    except ParseError:  # NOQA
        pass


if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-11 21:16:41.423700
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert isinstance(error, RuntimeError)


# Generated at 2022-06-11 21:16:42.439004
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-11 21:16:48.804920
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test Docstring constructor."""
    docstring = Docstring()

    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert isinstance(docstring.meta, list)
    assert docstring.meta == []


# Generated at 2022-06-11 21:16:57.541912
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args: T.List[str] = ["deprecated"]
    description: T.Optional[str] = "This function is deprecated"
    version: T.Optional[str] = "1.0.0"
    deprecation = DocstringDeprecated(args, description, version)
    assert isinstance(deprecation, DocstringDeprecated)
    assert deprecation.args == ["deprecated"]
    assert deprecation.description == "This function is deprecated"
    assert deprecation.version == "1.0.0"


# Generated at 2022-06-11 21:17:00.488411
# Unit test for constructor of class ParseError
def test_ParseError():
    """Check ParseError constructor."""
    with pytest.raises(ParseError):
        raise ParseError("error")


# Generated at 2022-06-11 21:17:09.430140
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["raises", "ValueError"], "Something happens","ValueError")
    assert d.args == ["raises", "ValueError"]
    assert d.description == "Something happens"
    assert d.type_name == "ValueError"


# Generated at 2022-06-11 21:17:14.570995
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    info = DocstringReturns(["return", "returns"], "description", "int")
    assert info.type_name == "int"
    assert info.description == "description"
    assert info.is_generator == False



# Generated at 2022-06-11 21:17:18.206581
# Unit test for constructor of class Docstring
def test_Docstring():
	d1 = Docstring()
	print("Params :",d1.params)
	print("Raises :",d1.raises)
	print("Returns :",d1.returns)
	print("Deprecation :",d1.deprecation)


#test_Docstring()


# Generated at 2022-06-11 21:17:23.591496
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    '''Unit test for the constructor of DocstringDeprecated'''
    args = ['arg1','arg2']
    description = 'This is the description'
    version = '2.0'
    test = DocstringDeprecated(args,description,version)
    assert test.args == args
    assert test.description == description
    assert test.version == version


# Generated at 2022-06-11 21:17:25.234866
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError()
    assert a.args == ()

# Generated at 2022-06-11 21:17:26.195772
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("testing")

# Generated at 2022-06-11 21:17:28.589077
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring!=None

# Unit tests for properties of Docstring

# Generated at 2022-06-11 21:17:32.120742
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["a", "b"], "c")
    assert a.args == ["a", "b"]
    assert a.description == "c"


# Generated at 2022-06-11 21:17:41.064568
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    _DocstringReturns = DocstringReturns(["returns", "return"], "This function returns a string", "str", False)
    assert _DocstringReturns.args == ["returns", "return"]
    assert _DocstringReturns.description == "This function returns a string"
    assert _DocstringReturns.type_name == "str"
    assert _DocstringReturns.is_generator == False
    assert _DocstringReturns.return_name == None
    _DocstringReturns = DocstringReturns(["returns", "return"], "This function returns a string", "str", False, "ret")
    assert _DocstringReturns.args == ["returns", "return"]
    assert _DocstringReturns.description == "This function returns a string"
    assert _DocstringReturns.type_name == "str"
    assert _DocstringReturns.is_generator

# Generated at 2022-06-11 21:17:48.882899
# Unit test for constructor of class DocstringParam
def test_DocstringParam():

    d = DocstringParam(args = ["param"],
                    description = "A person's name",
                    arg_name = "name" ,
                    type_name = "string",
                    is_optional = False,
                    default = "None")

    assert d.args is not None
    assert d.description == "A person's name"
    assert d.arg_name == "name"
    assert d.type_name == "string"
    assert d.is_optional == False
    assert d.default is "None"
    

# Generated at 2022-06-11 21:17:55.418380
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta([], "good")
    assert dm.args == []
    assert dm.description == "good"


# Generated at 2022-06-11 21:17:59.395197
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docMeta = DocstringMeta(["param", "arg", "type"], "description")
    assert docMeta.args==["param", "arg", "type"]
    assert docMeta.description=="description"


# Generated at 2022-06-11 21:18:02.698041
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = str("This is description")
    a = DocstringMeta(args,description)
    args.append("args")
    assert a.args == ["args"]
    assert a.description == "This is description"


# Generated at 2022-06-11 21:18:11.184384
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        DocstringRaises([0], "", "")
    except Exception as err:
        print(err.__repr__())
    try:
        DocstringRaises([0], "", 0)
    except Exception as err:
        print(err.__repr__())
    try:
        DocstringRaises([0], 0, "")
    except Exception as err:
        print(err.__repr__())
    try:
        DocstringRaises(0, "", "")
    except Exception as err:
        print(err.__repr__())


# Generated at 2022-06-11 21:18:16.732309
# Unit test for constructor of class Docstring
def test_Docstring():
    """Ensure that Docstring class's constructor is working as intended."""
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-11 21:18:17.817457
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError('test')


# Generated at 2022-06-11 21:18:19.636170
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError('Sample error')
    assert x.args[0] == 'Sample error'


# Generated at 2022-06-11 21:18:20.996709
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	"""
	"""
	assert True
	#assert False


# Generated at 2022-06-11 21:18:27.384845
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [1, 2]
    description = "test"
    arg_name = "arg"
    type_name = "3"
    is_optional = False
    default = "test"
    test_test_test = DocstringParam(
        args, description, arg_name, type_name, is_optional, default
    )
    return


# Generated at 2022-06-11 21:18:37.175054
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param", "arg", "arg_name"], "description", "arg_name", "type_name", True, None).arg_name == "arg_name"
    assert DocstringParam(["param", "arg", "arg_name"], "description", "arg_name", "type_name", True, None).type_name == "type_name"
    assert DocstringParam(["param", "arg", "arg_name"], "description", "arg_name", "type_name", True, None).is_optional == True
    assert DocstringParam(["param", "arg", "arg_name"], "description", "arg_name", "type_name", True, None).default == None


# Generated at 2022-06-11 21:18:43.859722
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-11 21:18:49.128040
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "1", "2", "3"]
    description = "description"
    typename = "type_name"
    docstr = DocstringRaises(args, description, typename)
    assert docstr.args == ["param", "1", "2", "3"]
    assert docstr.description == "description"
    assert docstr.type_name == "type_name"


# Generated at 2022-06-11 21:18:52.363392
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    myDoc = DocstringMeta(['arg'], 'description')
    assert myDoc.args == ['arg']
    assert myDoc.description == 'description'
    

# Generated at 2022-06-11 21:18:55.089759
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises.__init__
    a = DocstringRaises(["a", "b", "c"], "description", "type_name")
    assert a


# Generated at 2022-06-11 21:18:57.499863
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['args'], 'descr', 'type', False, '')
    assert isinstance(a, DocstringReturns)


# Generated at 2022-06-11 21:18:58.434423
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    pass

# Generated at 2022-06-11 21:19:06.362353
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [
        "returns"
    ]
    description = "Return the number of elements with the value x."
    type_name = "int"
    is_generator = True
    return_name = "return"
    doc = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert doc.args == args
    assert doc.description == description
    assert doc.type_name == type_name
    assert doc.is_generator == is_generator
    assert doc.return_name == return_name


# Generated at 2022-06-11 21:19:12.100713
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args=['param']
    description='Descripcion de test'
    param=DocstringParam(args,description,'arg',None,None,None)
    assert param.args==args
    assert param.description==description
    assert param.arg_name=='arg'
    assert param.type_name is None
    assert param.is_optional is None
    assert param.default is None


# Generated at 2022-06-11 21:19:15.332869
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test1 = DocstringDeprecated(['Version'], 'Testing', '3.3.3')
    assert test1.args[0] == 'Version'
    assert test1.description == 'Testing'
    assert test1.version == '3.3.3'


# Generated at 2022-06-11 21:19:17.418034
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """DocstringParam constructor unit test."""
    DocstringParam([":param"], "description", "arg_name", "type_name", False, "default")


# Generated at 2022-06-11 21:19:30.333790
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta(): # type: ignore
    """Unit test for constructor of class DocstringMeta."""
    # Empty docstring with short description
    docstring = Docstring()
    docstring.short_description = 'Hello world'
    docstring.long_description = ''
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True

    assert docstring.short_description == 'Hello world'
    assert docstring.long_description == ''
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

# Generated at 2022-06-11 21:19:35.763892
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises(): 
    """Test for correct initalization of class member variables."""
    args = []
    type_name = ""
    description = "Hello"
    doc_string = DocstringRaises(args, description, type_name)

    assert doc_string.args == args
    assert doc_string.type_name == type_name
    assert doc_string.description == description


# Generated at 2022-06-11 21:19:43.742922
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print("Testing DocstringRaises class constructor in parseutils.py")
    print("Constructing sample DocstringRaises object")
    testDocstringRaises = DocstringRaises(["raises", "exception"], "description", "ValueError")
    print("Checking various fields for accuracy of constructor")
    assert(testDocstringRaises.args == ["raises", "exception"])
    assert(testDocstringRaises.type_name == "ValueError")
    assert(testDocstringRaises.description == "description")


# Generated at 2022-06-11 21:19:46.049589
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(1,2,3)
#Unit test for constructor of class DocstringReturns

# Generated at 2022-06-11 21:19:47.644984
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(args = ["param"], description = "description")


# Generated at 2022-06-11 21:19:51.149370
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(["test"], "this is a test")
    assert docstring.args == ["test"]
    assert docstring.description == "this is a test"


# Generated at 2022-06-11 21:19:53.661396
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        # pylint: disable=unused-variable
        err = ParseError("Error message")
    except:
        print("Raised an exception")


# Generated at 2022-06-11 21:20:00.130985
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param', 'arg', 'docstring'], 'first argument', 'arg', 'str', True, 'None')
    DocstringParam(['parameter', 'arg', 'docstring'], 'second argument', 'arg', 'str', True, 'None')
    DocstringParam(['key', 'arg', 'docstring'], 'third argument', 'arg', 'str', True, 'None')



# Generated at 2022-06-11 21:20:06.709188
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args = ["deprecated", "since", "3.3"]
    test_description = "this is a test description"
    test_version = "1.2"
    test_docstringDeprecated = DocstringDeprecated(
        test_args, test_description, test_version
    )
    assert test_docstringDeprecated.args == test_args
    assert test_docstringDeprecated.description == test_description
    assert test_docstringDeprecated.version == test_version


# Generated at 2022-06-11 21:20:18.596480
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args: T.List[str] = []
    is_generator = False
    return_name = None
    return_type = None
    return_description = None
    assert args == []
    assert is_generator is False
    assert return_name is None
    assert return_type is None
    assert return_description is None
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).args == []
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).description is None
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).type_name is None

# Generated at 2022-06-11 21:20:37.080140
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        DocstringRaises([], "test")
    except TypeError:
        print("Catch TypeError: missing 1 required positional argument: 'type_name'")

    try:
        DocstringRaises([""], "test")
    except TypeError:
        print("Catch TypeError: missing 1 required positional argument: 'type_name'")

    try:
        v = DocstringRaises([""], "test", "")
        print("pass: DocstringRaises(, 'test', '')")
    except TypeError:
        print("catch TypeError: missing 1 required positional argument: 'type_name'")



# Generated at 2022-06-11 21:20:40.332039
# Unit test for constructor of class Docstring
def test_Docstring():
    """Confirm that initialised objects are as expected."""
    test_docstring = Docstring()
    assert test_docstring.short_description is None
    assert test_docstring.long_description is None
    assert test_docstring.meta == []
    assert test_docstring.blank_after_short_description is False
    assert test_docstring.blank_after_long_description is False


# Generated at 2022-06-11 21:20:46.668258
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None

# Generated at 2022-06-11 21:20:49.037356
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('text')
    print('object ParseError')

test_ParseError()

# Generated at 2022-06-11 21:20:55.653503
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-11 21:20:58.189323
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
   a = DocstringReturns(["param","parameter","arg","argument","attribute","key","keyword"],None,None,False,False)


# Generated at 2022-06-11 21:21:09.005508
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test case 1
    args = ["deprecated"]
    version = "0.1"
    description = "This function is deprecate"
    docstringDeprecated = DocstringDeprecated(args, description, version)
    assert docstringDeprecated.args ==  args
    assert docstringDeprecated.description == description
    assert docstringDeprecated.version == version
    # Test case 2
    args = ["deprecated"]
    version = None
    description = None
    docstringDeprecated = DocstringDeprecated(args, description, version)
    assert docstringDeprecated.args ==  args
    assert docstringDeprecated.description == description
    assert docstringDeprecated.version == version
    # Test case 3
    args = ["deprecated"]
    version = None
    description = "This function is deprecate"
    docstringDeprecated

# Generated at 2022-06-11 21:21:10.294093
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['arg'], 'desc', 'class', False, 'return')

# Generated at 2022-06-11 21:21:14.807565
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        x = DocstringMeta(['A', 'B'], 'C')
        assert x.args[0] == 'A'
        assert x.args[1] == 'B'
        assert x.description == 'C'
    except:
        print('Test failed for DocstringMeta')


# Generated at 2022-06-11 21:21:17.552875
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("message")
    assert e.args == ("message",)


# Generated at 2022-06-11 21:21:37.261039
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["arg", "raises"], "test", "None")
    assert isinstance(d, DocstringMeta)
    assert isinstance(d, DocstringRaises)


# Generated at 2022-06-11 21:21:39.442571
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["hello","world"],"My super description!") is not None


# Generated at 2022-06-11 21:21:41.541908
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test')
    except ParseError as e:
        assert str(e) == 'test'


# Generated at 2022-06-11 21:21:45.066305
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["a"], "b", "c")
    assert a.args == ["a"]
    assert a.description == "b"
    assert a.type_name == "c"



# Generated at 2022-06-11 21:21:50.611939
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns([], None, None, False)
    assert(isinstance(d, DocstringReturns))
    assert(d.args == [])
    assert(d.description == None)
    assert(d.return_name == None)
    assert(d.type_name == None)
    assert(d.is_generator == False)


# Generated at 2022-06-11 21:22:01.036133
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args1 = []
    description1 = None
    type_name1 = None

    x = DocstringRaises(args1, description1, type_name1)
    assert x.args == []
    assert x.description == None
    assert x.type_name == None

    args2 = [':ghi', ':jkl']
    description2 = "sample description"
    type_name2 = ":abc"

    x = DocstringRaises(args2, description2, type_name2)
    assert x.args == [':ghi', ':jkl']
    assert x.description == "sample description"
    assert x.type_name == ":abc"


# Generated at 2022-06-11 21:22:07.885060
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam"""
    params = DocstringParam(['param','arg','key'],"if the value of parameter is wrong, ValueError will be raised", "input", "int", True, 0)
    assert params.arg_name == "input"
    assert params.type_name == "int"
    assert params.is_optional == True
    assert params.default == 0
    assert params.description == "if the value of parameter is wrong, ValueError will be raised"
    
    

# Generated at 2022-06-11 21:22:14.284167
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    temp1 = DocstringReturns(['returns'], "", "None")
    temp2 = DocstringReturns(['returns'], "", "None")
    temp3 = DocstringReturns(['returns'], "", "None")
    assert temp1 == temp2
    assert temp1 == temp3


# Generated at 2022-06-11 21:22:18.387161
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated([], "", "")
    assert meta.type_name is None
    print("type_name: ", meta.type_name)
    assert meta.description is None
    print("description: ", meta.description)

# Generated at 2022-06-11 21:22:19.672377
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated([], None, None)
    assert doc != None

# Generated at 2022-06-11 21:23:01.050221
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_name = "myparam"
    description = "My description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default_value"

    my_DocstringParam = DocstringParam([], description, arg_name, type_name, is_optional, default)
    assert(my_DocstringParam.args == [])
    assert(my_DocstringParam.description == description)
    assert(my_DocstringParam.arg_name == arg_name)
    assert(my_DocstringParam.type_name == type_name)
    assert(my_DocstringParam.is_optional == is_optional)
    assert(my_DocstringParam.default == default)



# Generated at 2022-06-11 21:23:07.062748
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-11 21:23:08.250478
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("test") != None

# Generated at 2022-06-11 21:23:12.758874
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    dm = DocstringMeta(args,description)
    dm.args[0]=='arg'
    dm.description=='description'


# Generated at 2022-06-11 21:23:13.854669
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta()


# Generated at 2022-06-11 21:23:17.070197
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['para1', 'para2'], 'this is a description')
    assert d.args == ['para1', 'para2']
    assert d.description == 'this is a description'


# Generated at 2022-06-11 21:23:23.532512
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args_list=["Deprecated", "Description", "Version=1.0"]
    docstring_deprecated_test=DocstringDeprecated(args_list, "Description", "Version=1.0")
    assert docstring_deprecated_test.args==args_list
    assert docstring_deprecated_test.description=="Description"
    assert docstring_deprecated_test.version=="Version=1.0"


# Generated at 2022-06-11 21:23:28.200917
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_string = DocstringMeta(
        args=['param', 'arg', 'argument'], description='desc'
    )
    assert doc_string.args == ['param', 'arg', 'argument']
    assert doc_string.description == 'desc'


# Generated at 2022-06-11 21:23:34.719456
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the constructor of class DocstringParam."""
    # Test creating a DocstringParam object using the default value
    param = DocstringParam([], None, "arg", None, None, None)

    # Test creating a DocstringParam object with a custom description
    param = DocstringParam([], "description for argument arg", "arg", None, None, None)

    # Test creating a DocstringParam object with a custom type_name
    param = DocstringParam([], None, "arg", "string", None, None)

    # Test creating a DocstringParam object with a custom is_optional
    param = DocstringParam([], None, "arg", None, True, None)

    # Test creating a DocstringParam object with a custom default
    param = DocstringParam([], None, "arg", None, None, "default value")



# Generated at 2022-06-11 21:23:38.337955
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        1/0
    except Exception as e:
        pass
    # <class 'ZeroDivisionError'>
    assert(e.__class__ == ZeroDivisionError)


# Generated at 2022-06-11 21:24:49.687376
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError('parse error')



# Generated at 2022-06-11 21:24:53.666047
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Cannot parse docstring: ...")
    except ParseError as err:
        assert str(err) == "Cannot parse docstring: ..."
    else:
        assert False, "Constructor of class ParseError failed"


# Generated at 2022-06-11 21:25:01.541722
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['k=v']
    description = 'desc'
    arg_name = 'arg'
    type_name = 'int'
    is_optional = True
    default = '1'
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == args
    assert dp.description == description
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default


# Generated at 2022-06-11 21:25:05.634218
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    data = (["arg1", "arg2"], "description", "ValueError")
    assert DocstringRaises(*data).args == ["arg1", "arg2"]
    assert DocstringRaises(*data).description == "description"
    assert DocstringRaises(*data).type_name == "ValueError"

#Unit test for constructor of class DocstringReturns

# Generated at 2022-06-11 21:25:07.610774
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(RuntimeError)

# Generated at 2022-06-11 21:25:12.581661
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    my_args = ["arg1", "arg2"]
    my_description = "It's possible that it's not the right description"
    my_type_name = "my_type"
    my_docstring_meta = DocstringRaises(my_args, my_description, my_type_name)

    assert(my_docstring_meta.args == my_args)
    assert(my_docstring_meta.description == my_description)
    assert(my_docstring_meta.type_name == my_type_name)


# Generated at 2022-06-11 21:25:13.736725
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(1,2,"3")


# Generated at 2022-06-11 21:25:18.201810
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns('both', 'type name and description', 'returns', False, 'None')
    print(a.args)
    print(a.description)
    print(a.type_name)
    print(a.is_generator)
    print(a.return_name)


# Generated at 2022-06-11 21:25:19.924298
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises('args', 'description', 'type_name')


# Generated at 2022-06-11 21:25:21.517960
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("test").args == ("test",)
