

# Generated at 2022-06-11 21:15:47.876939
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta(["hello", "there"], "I am a description of the thing to be parsed")

    except:
        assert False


# Generated at 2022-06-11 21:15:52.909818
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None

# Generated at 2022-06-11 21:15:58.548410
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["arg"], "description", "arg_name", "type_name", True, "default")
    assert dp.args == ["arg"]
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == True
    assert dp.default == "default"


# Generated at 2022-06-11 21:16:02.233248
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["int"], "", "arg", "type_name", True, None)
    # DocstringParam(["int"], "", None, "type_name", True, None) # ValueError: too few values to unpack (expected 7, got 6)


# Generated at 2022-06-11 21:16:03.837940
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("fatal error")
    except ParseError as e:
        assert(e == "fatal error")
 

# Generated at 2022-06-11 21:16:09.128288
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    item = DocstringMeta('[a, b]', 'description')
    assert isinstance(item, DocstringMeta)
    assert item.args == ['a', 'b'] and item.description == 'description'



# Generated at 2022-06-11 21:16:12.288461
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of class ParseError."""
    try:
        raise ParseError("Test ParseError")
    except ParseError as error:
        print(str(error))


# Generated at 2022-06-11 21:16:15.912158
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['param', 'arg'], "desc")
    assert isinstance(docstring_meta, DocstringMeta)
    assert docstring_meta.args == ['param', 'arg']
    assert docstring_meta.description == "desc"


# Generated at 2022-06-11 21:16:16.903540
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "")



# Generated at 2022-06-11 21:16:28.125743
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    arg_name = "arg"
    type_name = "None"
    is_optional = True
    default = "default"
    description = "I'm a description."

    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-11 21:16:35.577256
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta([], "")
    assert d

# Generated at 2022-06-11 21:16:41.786129
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-11 21:16:43.376092
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert isinstance(error, RuntimeError)


# Generated at 2022-06-11 21:16:45.785402
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam([":param"], "", "arg", "int", True, 2)


# Generated at 2022-06-11 21:16:50.391976
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-11 21:16:53.721781
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["3"], "2")
    assert d.args == ["3"]
    assert d.description == "2"

# Generated at 2022-06-11 21:16:56.376610
# Unit test for constructor of class ParseError
def test_ParseError():
    new_ParseError = ParseError("This is the reason.")
    assert str(new_ParseError) == "This is the reason."



# Generated at 2022-06-11 21:17:00.655976
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring()
    assert docstr.short_description == None
    assert docstr.long_description == None
    assert docstr.blank_after_short_description == False
    assert docstr.blank_after_long_description == False
    assert docstr.meta == []


# Generated at 2022-06-11 21:17:01.697418
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta(["param"], "parameter description")


# Generated at 2022-06-11 21:17:05.848185
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(["param"], "A description")
    assert doc_meta.args == ["param"]
    assert doc_meta.description == "A description"


# Generated at 2022-06-11 21:17:11.974773
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("parsing failed")
    except:
        pass
    return True

# Generated at 2022-06-11 21:17:23.199499
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arg = ["abc", "def"]
    description = "description"
    type_name = "int"
    return_name = "ret_name"
    doc_returns = DocstringReturns(arg, description, type_name, True, return_name)
    assert doc_returns.args == arg, "args in DocstringReturns incorrect"
    assert doc_returns.description == description, "description in DocstringReturns incorrect"
    assert doc_returns.type_name == type_name, "type_name in DocstringReturns incorrect"
    assert doc_returns.is_generator == True, "is_generator in DocstringReturns incorrect"
    assert doc_returns.return_name == return_name, "return_name in DocstringReturns incorrect"

# Generated at 2022-06-11 21:17:35.152369
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta"""


# Generated at 2022-06-11 21:17:37.533270
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam( ["param"], None, "test", "type", None, None)
    assert obj is not None

# Generated at 2022-06-11 21:17:40.544973
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	example = DocstringDeprecated(['deprecated'], 'description', 'version')
	assert example.description == 'description'
	assert example.version == 'version'
	assert example.args == ['deprecated']



# Generated at 2022-06-11 21:17:49.100644
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(args=["3"], type_name="float", description="float number", is_generator=False).is_generator==False
    assert DocstringReturns(args=["3"], type_name="float", description="float number", is_generator=False).type_name=='float'
    assert DocstringReturns(args=["3"], type_name="float", description="float number", is_generator=False).description=="float number"
    assert DocstringReturns(args=["3"], type_name="float", description="float number", is_generator=False).args==[3]


# Generated at 2022-06-11 21:17:55.039334
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns(['Returns:'], 'this is the return', str, False);
    assert doc.args == ['Returns:']
    assert doc.description == 'this is the return'
    assert doc.type_name == str
    assert not doc.is_generator
    assert doc.return_name == None
    

# Generated at 2022-06-11 21:17:59.863368
# Unit test for constructor of class ParseError
def test_ParseError():

    # Create a new ParseError
    error = ParseError("A parsing error occured")

    # Check that error is of type RuntimeError and ParseError
    assert isinstance(error, RuntimeError)
    assert isinstance(error, ParseError)


# Generated at 2022-06-11 21:18:00.674447
# Unit test for constructor of class ParseError
def test_ParseError():
	E = ParseError
	assert 1


# Generated at 2022-06-11 21:18:03.841382
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    item = DocstringReturns(["returns"], "description", "type_name", False)
    assert item.description == "description"
    assert item.is_generator
    assert item.type_name == "type_name"



# Generated at 2022-06-11 21:18:13.687019
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test if DocstringParam is initialized correctly
    args="[]"
    description="description"
    arg_name="arg_name"
    type_name="typename"
    is_optional=True
    default=None

    doc_param=DocstringParam(
        args=args,
        description=description,
        arg_name=arg_name,
        type_name=type_name,
        is_optional=is_optional,
        default=default
        )

    assert args == doc_param.args
    assert description == doc_param.description
    assert arg_name == doc_param.arg_name
    assert type_name == doc_param.type_name
    assert is_optional == doc_param.is_optional
    assert default == doc_param.default



# Generated at 2022-06-11 21:18:18.689583
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()

    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:18:29.370730
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param", "parameter", "arg", "argument"], "this is description", "arg_name", "type_name", "is_optional", "default")
    b = DocstringParam(["param"], "this is description", "arg_name", "type_name", "is_optional", "default")
    
    assert a.args == ["param", "parameter", "arg", "argument"]
    assert b.args == ["param"]
    assert a.description == "this is description"
    assert b.description == "this is description"
    assert a.arg_name == "arg_name"
    assert a.type_name == "type_name"
    assert a.is_optional == "is_optional"
    assert a.default == "default"


# Generated at 2022-06-11 21:18:34.066672
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['.'], '.', '.')
    assert docstring_deprecated.args == ['.']
    assert docstring_deprecated.description == '.'
    assert docstring_deprecated.version == '.'


# Generated at 2022-06-11 21:18:34.684216
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass

# Generated at 2022-06-11 21:18:37.989451
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg1", "arg2"]
    type_name = "type"
    description = "description"
    doc = DocstringRaises(args, description, type_name)
    assert doc.type_name == type_name
    assert doc.description == description

# Generated at 2022-06-11 21:18:41.494904
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(["raises"], "Test description", "ValueError")
    assert doc.args == ["raises"]
    assert doc.description == "Test description"
    assert doc.type_name == "ValueError"


# Generated at 2022-06-11 21:18:45.265998
# Unit test for constructor of class Docstring
def test_Docstring():
    ''' Testing the constructor of Docstring class '''
    docstr = Docstring()
    assert isinstance(docstr.short_description, type(None))
    assert isinstance(docstr.long_description, type(None))
    assert docstr.blank_after_short_description is False
    assert docstr.blank_after_long_description is False
    assert docstr.meta == []


# Generated at 2022-06-11 21:18:52.493291
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(
        ['param', 'arg'], 'description', 'arg_name', 'type_name', True, 'default'
    )
    assert obj.args == ['param', 'arg']
    assert obj.description == 'description'
    assert obj.is_optional == True
    assert obj.arg_name == 'arg_name'
    assert obj.type_name == 'type_name'
    assert obj.default == 'default'


# Generated at 2022-06-11 21:18:58.028575
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docst = DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')
    assert docst.args == ['param']
    assert docst.description == 'description'
    assert docst.arg_name == 'arg_name'
    assert docst.type_name == 'type_name'
    assert docst.is_optional == True
    assert docst.default == 'default'


# Generated at 2022-06-11 21:19:06.162188
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    
    a = DocstringMeta(['args1','args2'], "this is for testing")
    print("args: ", a.args, "\n", "description", a.description)


# Generated at 2022-06-11 21:19:11.270175
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta( ["param", "arg", "argument", "attribute", "key", "keyword"], "5")
    assert(d.args == ["param", "arg", "argument", "attribute", "key", "keyword"])
    assert(d.description=="5")
test_DocstringMeta()


# Generated at 2022-06-11 21:19:13.119129
# Unit test for constructor of class Docstring
def test_Docstring():
    container = Docstring()
    assert container.short_description == None
    assert container.long_description == None
    assert container.meta == []

# test_Docstring()

# Generated at 2022-06-11 21:19:17.064089
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    with pytest.raises(TypeError): 
        DocstringRaises(['1'], 'description', 'int')
    with pytest.raises(ValueError):
        DocstringRaises(['1'], 'description', 'int', '1', '2')
    DocstringRaises(['1'], 'description', True)

# Generated at 2022-06-11 21:19:23.590637
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:19:28.403122
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:19:33.142370
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "arg_name", "description"]
    doc = DocstringMeta(args, "arg_name")
    assert doc.args == ["param", "arg", "arg_name", "description"]
    assert doc.description == "arg_name"


# Generated at 2022-06-11 21:19:37.632126
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(args = ["deprecated", "since 1.0"], description = "this feature is removed")
    assert obj.args == ["deprecated", "since 1.0"] and obj.description == "this feature is removed"


# Generated at 2022-06-11 21:19:40.535768
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid input")
    except ParseError as e:
        assert str(e) == "Invalid input"


# Generated at 2022-06-11 21:19:44.111283
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    _docstringParam = DocstringParam(args="args", description="description", arg_name="arg_name", type_name="type_name", is_optional="is_optional", default="default")


# Generated at 2022-06-11 21:19:59.667694
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    my_param = DocstringParam(['param'], 'desc', 'arg', 'type', True, 'True')
    assert my_param.args == ['param']
    assert my_param.description == 'desc'
    assert my_param.arg_name == 'arg'
    assert my_param.type_name == 'type'
    assert my_param.is_optional == True
    assert my_param.default == 'True'


# Generated at 2022-06-11 21:20:05.094832
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param", "arg"], "description", "arg_name", "str", False, "value")
    assert param is not None
    assert param.args == ["param", "arg"]
    assert param.description == "description"
    assert param.arg_name == "arg_name"
    assert param.type_name == "str"
    assert param.is_optional == False
    assert param.default == "value"


# Generated at 2022-06-11 21:20:09.557635
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg', 'example', 'description']
    description = 'description example'
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-11 21:20:15.823811
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg", "int", False, "None")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "int"
    assert docstring_param.is_optional == False
    assert docstring_param.default == "None"



# Generated at 2022-06-11 21:20:18.206532
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["parameter"], "", "") is not None

# Generated at 2022-06-11 21:20:20.898240
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args=["deprecated", "since", "0.1"]
    description="..."
    version="0.1"
    docstringDeprecated = DocstringDeprecated(args, description, version)
    assert docstringDeprecated.args == args
    assert docstringDeprecated.description == description
    assert docstringDeprecated.version == version


# Generated at 2022-06-11 21:20:23.720467
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    desc_meta = DocstringMeta(['param'], 'description')
    assert desc_meta.args == ['param'], "DocstringMeta class constructor is not working"
    assert desc_meta.description == 'description', "DocstringMeta class constructor is not working"


# Generated at 2022-06-11 21:20:28.160536
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(1,2,3)
    assert(d.args == 1)
    assert(d.description == 2)
    assert(d.version == 3)


# Generated at 2022-06-11 21:20:35.796560
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta is []
    #assert docstring.params is []
    #assert docstring.raises is []
    #assert docstring.returns is None
    #assert docstring.deprecation is None

# Generated at 2022-06-11 21:20:37.807543
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param","toto"], "abc", "abc", "int", False, "5")



# Generated at 2022-06-11 21:20:56.847340
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    string = "Description of the meta element"
    args = ["param"]
    meta = DocstringMeta(args, string)
    assert meta.description == string
    assert meta.args == args


# Generated at 2022-06-11 21:21:02.667819
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["return", "returns"], "Value returned.", "int", False, None)
    assert a.args == ["return", "returns"]
    assert a.description == "Value returned."
    assert a.type_name == "int"
    assert a.is_generator == False
    assert a.return_name == None


# Generated at 2022-06-11 21:21:06.267079
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(
        ['deprecated'],
        'The easiest way to build an interactive dialogue bot.',
        None,
    )
    assert docstring.description == 'The easiest way to build an interactive dialogue bot.'


# Generated at 2022-06-11 21:21:11.713557
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param","arg","attribute"],None,"arg_name",None,True,None)
    assert docstring_param.args == ["param", "arg", "attribute"]
    assert docstring_param.description is None
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name is None
    assert docstring_param.is_optional is True
    assert docstring_param.default is None


# Generated at 2022-06-11 21:21:19.286312
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam('args', 'description', 'arg_name', 'type_name', True, 'default')
    assert docstringParam.args == 'args'
    assert docstringParam.description == 'description'
    assert docstringParam.arg_name == 'arg_name'
    assert docstringParam.type_name == 'type_name'
    assert docstringParam.is_optional == True
    assert docstringParam.default == 'default'


# Generated at 2022-06-11 21:21:21.622710
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta([], "some description")
    assert meta.args == []
    assert meta.description == "some description"


# Generated at 2022-06-11 21:21:23.280324
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert(DocstringDeprecated(['param'], 'description', 'version'))


# Generated at 2022-06-11 21:21:25.853182
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # create instance of DocstringReturns
    DocstringReturns(['returns'], '2', None, False)

# Generated at 2022-06-11 21:21:31.507304
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecation']
    description = 'A function that is no longer used'
    version = '1.0.0'
    d = DocstringDeprecated(args,description, version)
    assert d.description == description



# Generated at 2022-06-11 21:21:34.987061
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dr = DocstringRaises("TypeError", "description", "type_name")
    assert type(dr) == DocstringRaises
    assert dr.args == "TypeError"
    assert dr.description == "description"
    assert dr.type_name == "type_name"

# Generated at 2022-06-11 21:22:17.364807
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "type_name"
    a = DocstringRaises(args, description, type_name)
    assert isinstance(a, DocstringRaises)
    assert isinstance(a, DocstringMeta)
    assert a.args == ["arg1", "arg2"]
    assert a.description == "description"
    assert a.type_name == "type_name"


# Generated at 2022-06-11 21:22:21.279691
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("The type of argument error_msg1 is not str")
    ParseError("The type of argument error_msg2 is not str")
    ParseError("The type of argument error_msg2 is not int")

# Generated at 2022-06-11 21:22:25.303411
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # DocstringRaises(args, description, type_name)
    DocstringRaises(["docstring"], "description", "type")
    DocstringRaises(["doc"], "desc", "type")


# Generated at 2022-06-11 21:22:30.989293
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", False, "default")
    assert dp.args == ["param", "arg"]
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == False
    assert dp.default == "default"


# Generated at 2022-06-11 21:22:36.139910
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  args = ["args"]
  description = "test description"
  type_name = "test_type_name"
  dr = DocstringRaises(args, description, type_name)
  assert dr.args == ["args"]
  assert dr.description == "test description"
  assert dr.type_name == "test_type_name"


# Generated at 2022-06-11 21:22:42.837113
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # ...
    doc = DocstringParam(['param', 'arg', 'description'], 'arg', arg_name='arg', type_name='description', is_optional=False, default='0')
    assert (doc.arg_name == 'arg')
    assert (doc.type_name == 'description')
    assert (doc.is_optional == False)
    assert (doc.default == '0')


# Generated at 2022-06-11 21:22:48.060904
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Constructor DocstringParam(1, 2, 3, 4) does not work
    # Constructor DocstringParam(1, 2, 3, 4, 5) does not work
    # Constructor DocstringParam(1, 2, 3, 4, 5, 6) works
    assert(DocstringParam(1, 2, 3, 4, 5, 6) != None)
    return

# Generated at 2022-06-11 21:22:52.764564
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')
    DocstringParam(['param'], 'description', 'arg_name', 'type_name', None, None)



# Generated at 2022-06-11 21:22:56.215553
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    it = DocstringMeta(args=["a", "b", "c"], description="abc")
    assert it.args==['a', 'b', 'c']
    assert it.description=='abc'



# Generated at 2022-06-11 21:22:58.973867
# Unit test for constructor of class ParseError
def test_ParseError():
  try:
    raise ParseError()
  except ParseError:
    pass


# Generated at 2022-06-11 21:24:10.934902
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Constructor
    test = DocstringRaises(['a'], 'b', 'c')
    assert test.args == ['a']
    assert test.description == 'b'
    assert test.type_name == 'c'

# Generated at 2022-06-11 21:24:17.349243
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args: T.List[str] = ['a', 'b']
    description = "test"
    type_name = "type_name"
    is_generator = True
    d = DocstringReturns(args, description, type_name, is_generator)

    assert d.args == args
    assert d.description == description
    assert d.type_name == type_name
    assert d.is_generator == is_generator



# Generated at 2022-06-11 21:24:31.258391
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dsr1 = DocstringReturns(["return", "returns"], "returns the test variable", "str")
    dsr2 = DocstringReturns(["yield", "yields"], "yields the test variable", "int")

    assert dsr1.args == ["return", "returns"]
    assert dsr1.description == "returns the test variable"
    assert dsr1.type_name == "str" 
    assert dsr1.is_generator == False
    assert dsr1.return_name == None

    assert dsr2.args == ["yield", "yields"]
    assert dsr2.description == "yields the test variable"
    assert dsr2.type_name == "int" 
    assert dsr2.is_generator == True

# Generated at 2022-06-11 21:24:33.435421
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert len(DocstringDeprecated(['toto', 'tata'], 'raise ValueError', 'version').args) == 2


# Generated at 2022-06-11 21:24:37.617564
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        dr = DocstringRaises(["a", "b"], "d", "t")
        dr.args
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-11 21:24:46.550216
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_obj = Docstring()
    assert type(doc_obj) == Docstring
    assert isinstance(doc_obj, Docstring)
    assert doc_obj.short_description == None
    assert doc_obj.long_description == None
    assert not doc_obj.blank_after_short_description
    assert not doc_obj.blank_after_long_description
    assert doc_obj.meta == []
    assert doc_obj.params == []
    assert doc_obj.raises == []
    assert doc_obj.returns == None
    assert doc_obj.deprecation == None

# Test for class DocstringMeta

# Generated at 2022-06-11 21:24:51.726007
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DP = DocstringParam(["a","b","c"],"It's a test.","arg_name",None,None,None)
    assert DP.args == ["a","b","c"]
    assert DP.description == "It's a test."
    assert DP.arg_name == "arg_name"
    assert DP.type_name == None
    assert DP.is_optional == None
    assert DP.default == None


# Generated at 2022-06-11 21:24:55.581878
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["Deprecated"], "1221", "4")
    assert docstring.args == ["Deprecated"]
    assert docstring.description == "1221"
    assert docstring.version == "4"
    

# Generated at 2022-06-11 21:25:04.399709
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # parameters for constructor
    args: T.List[str] = []
    description: T.Optional[str] = None
    type_name: T.Optional[str] = None
    is_generator: bool = True
    return_name: T.Optional[str] = None

    docstr_retargs = DocstringReturns(args, description, type_name, is_generator, return_name)

    assert docstr_retargs.args == args
    assert docstr_retargs.description == description
    assert docstr_retargs.type_name == type_name
    assert docstr_retargs.is_generator == is_generator
    assert docstr_retargs.return_name == return_name


# Generated at 2022-06-11 21:25:08.229841
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is an error")
    except ParseError as e:
        assert str(e) == "This is an error"
