

# Generated at 2022-06-11 21:15:46.328158
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = ""
    DocstringMeta(args, description)



# Generated at 2022-06-11 21:15:51.341720
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["raises"], "Error", "int")
    assert a.args == ['raises']
    assert a.description == 'Error'
    assert a.type_name == 'int'
    

# Generated at 2022-06-11 21:15:52.909699
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    x = DocstringMeta([], u'')
    assert isinstance(x, DocstringMeta)


# Generated at 2022-06-11 21:15:56.031587
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"

# Unit tests for constructor of class Docstring

# Generated at 2022-06-11 21:16:00.117466
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "test", "string", "test", True, "None")
    assert param.is_optional
    assert param.args == ["param"]
    assert param.description == "test"
    assert param.arg_name == "string"
    assert param.type_name == "test"
    assert param.default == "None"


# Generated at 2022-06-11 21:16:04.473273
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-11 21:16:07.019468
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError('Parsing failed')



# Generated at 2022-06-11 21:16:09.463103
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():

    DocstringRaises("args", "description", "type_name")

# Generated at 2022-06-11 21:16:17.772210
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    param = DocstringParam(['param'], 'description', 'arg', 
                           'type_name', 'is_optional', 'default')
    assert param.args == ['param']
    assert param.description == 'description'
    assert param.arg_name == 'arg'
    assert param.type_name == 'type_name'
    assert param.is_optional == 'is_optional'
    assert param.default == 'default'
    
    returns = DocstringReturns(['return'], 'description', 'type_name', 
                               'is_generator', 'return_name')
    assert returns.args == ['return']
    assert returns.description == 'description'
    assert returns.type_name == 'type_name'
    assert returns.is_generator == 'is_generator'
    assert returns.return_name

# Generated at 2022-06-11 21:16:22.028117
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises("args", "desc", "type")
    assert raises.args == "args"
    assert raises.description == "desc"
    assert raises.type_name == "type"


# Generated at 2022-06-11 21:16:29.524844
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is a test error")
    except ParseError as err:
        print(err)
# ParseError: This is a test error


# Generated at 2022-06-11 21:16:37.285438
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_object = DocstringReturns(["testArgs"], "testDescription", "testTypeName", False, "testReturnName")
    assert(test_object.args[0] == "testArgs")
    assert(test_object.description == "testDescription")
    assert(test_object.type_name == "testTypeName")
    assert(test_object.is_generator == False)
    assert(test_object.return_name == "testReturnName")


# Generated at 2022-06-11 21:16:42.837210
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:16:46.808640
# Unit test for constructor of class ParseError
def test_ParseError():
    # test constructor
    try:
        raise ParseError("something went wrong")
    except ParseError as e:
        print(e)
        msg = str(e)
        assert msg == "something went wrong"


# Generated at 2022-06-11 21:16:50.118163
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_stmt = DocstringReturns(["return"], "This is a test", "str", False)
    assert return_stmt.type_name == "str"

# Generated at 2022-06-11 21:16:51.228242
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta


# Generated at 2022-06-11 21:16:53.657631
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()

# Generated at 2022-06-11 21:16:55.769903
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dr = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    assert dr.args == ["raises","ValueError"]
    assert dr.description == "if something happens"
    assert dr.type_name == "ValueError"


# Generated at 2022-06-11 21:17:05.028803
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args=['param', 'arg', 'description']
    arg_name='arg'
    type_name='type'
    is_optional=True
    default="123"
    description='description'
    obj=DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert obj.is_optional
    assert obj.arg_name==arg_name
    assert obj.type_name==type_name
    assert obj.is_optional==is_optional
    assert obj.default==default
    assert obj.description==description
    assert obj.args==args


# Generated at 2022-06-11 21:17:06.124179
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError


# Generated at 2022-06-11 21:17:15.527515
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ds_meta = DocstringMeta("arg", "description")
    assert isinstance(ds_meta, DocstringMeta)
    assert ds_meta.args == "arg"
    assert ds_meta.description == "description"



# Generated at 2022-06-11 21:17:18.256436
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    item = DocstringReturns(["type"], "a", "b")
    assert item.description == "a"
    assert item.type_name == "b"


# Generated at 2022-06-11 21:17:20.832276
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Testing ParseError constructor")
    except ParseError as p:
        print(p)


# Generated at 2022-06-11 21:17:22.737386
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('test')
    assert(e.args[0] == 'test')


# Generated at 2022-06-11 21:17:34.571176
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["args", "arg", "argument", "params", "param", "parameter"]
    description = "this is a description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert len(docstring_param.args) == 6
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default



# Generated at 2022-06-11 21:17:37.001030
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except Exception as e:
        print(e)  # prints exception type


# Generated at 2022-06-11 21:17:38.186232
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], "description", "type_name", False, "return_name")

# Generated at 2022-06-11 21:17:41.340013
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['str', 'str2']
    description = 'String made of 2 strings'
    docstring = DocstringMeta(args, description)
    assert docstring.args == args
    assert docstring.description == description


# Generated at 2022-06-11 21:17:43.234499
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta("args", "description")
    assert a.args == "args"
    assert a.description == "description"


# Generated at 2022-06-11 21:17:45.438943
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns([""], "", None)
    assert doc

# Generated at 2022-06-11 21:18:04.498044
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1
    # Test description: Test with normal data type
    args = ["some args"]
    description = "some description"
    arg_name = "arg name"
    type_name = "some type"
    is_optional = "is optional?"
    default = "default value"
    a = DocstringParam(args, description, arg_name, type_name,
                        is_optional, default)
    assert a.args == ["some args"]
    assert a.description == "some description"
    assert a.arg_name == "arg name"
    assert a.type_name == "some type"
    assert a.is_optional == "is optional?"
    assert a.default == "default value"
    # Test 2
    # Test description: Test with non-normal data type
    args = ["some args"]

# Generated at 2022-06-11 21:18:08.075576
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arguments = ['arg']
    description = 'description'
    dm = DocstringMeta(arguments,description)
    assert dm.args == arguments
    assert dm.description == description


# Generated at 2022-06-11 21:18:12.978481
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    b = DocstringReturns(['return'], None, 'str')
    assert b.args == ['return']
    assert b.description is None
    assert b.type_name == 'str'
    assert b.is_generator is False
    assert b.return_name is None



# Generated at 2022-06-11 21:18:15.277750
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(args=[], type_name="", description="", is_generator=False)
    assert isinstance(d, DocstringReturns)

# Generated at 2022-06-11 21:18:19.876593
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    reda = DocstringRaises(["raises"], "This function raises an error", "Error")
    assert reda.args == ["raises"]
    assert reda.description == "This function raises an error"
    assert reda.type_name == "Error"


# Generated at 2022-06-11 21:18:27.132667
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    temp_r = DocstringReturns([": returns:","description"], "description", "type_name", True, "return_name")
    assert temp_r.args == [": returns:","description"]
    assert temp_r.description == "description"
    assert temp_r.type_name == "type_name"
    assert temp_r.is_generator == True
    assert temp_r.return_name == "return_name"

# Generated at 2022-06-11 21:18:29.210904
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args, description, type_name, is_generator, return_name)

# Generated at 2022-06-11 21:18:36.832899
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["raises"]
    desript = "error"
    yield_type = "int"
    is_gen = False
    yield_name = None
    a = DocstringReturns(args=args, description=desript, type_name=yield_type, is_generator=is_gen, return_name=yield_name)
    print(a.args, a.description, a.is_generator, a.type_name, a.return_name)


if __name__ == "__main__":
    test_DocstringReturns()

# Generated at 2022-06-11 21:18:38.703619
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('ParseException')
    except ParseError as e:
        assert str(e) == 'ParseException'

# Generated at 2022-06-11 21:18:45.390194
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DParam = DocstringParam(
        args=[':param x: '],
        description='the only variable',
        arg_name='x',
        type_name='int',
        is_optional=False,
        default='9',
    )
    assert DParam.args == [":param x: "]
    assert DParam.description == "the only variable"
    assert DParam.arg_name == 'x'
    assert DParam.type_name == 'int'
    assert DParam.is_optional == False
    assert DParam.default == '9'



# Generated at 2022-06-11 21:19:04.281403
# Unit test for constructor of class ParseError
def test_ParseError():
    parseError = ParseError("Testing.")


# Generated at 2022-06-11 21:19:14.101126
# Unit test for constructor of class Docstring
def test_Docstring():
	"""Test for Docstring constructor:
	Test for short_description, long_description, blank_after_short_description, blank_after_long_description, meta
	"""
	docstring = Docstring()
	if docstring.short_description != None:
		print ("docstring.short_description: should be None")
	if docstring.long_description != None:
		print ("docstring.long_description: should be None")
	if docstring.blank_after_short_description != False:
		print ("docstring.blank_after_short_description: should be False")
	if docstring.blank_after_long_description != False:
		print ("docstring.blank_after_short_description: should be False")

# Generated at 2022-06-11 21:19:17.941518
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg1']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-11 21:19:28.194193
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['args', 'args']
    description = 'NoDescription'
    type_name = 'NoType'
    is_generator = True
    return_name = 'NoReturnName'
    docstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstringReturns.args == ['args', 'args']
    assert docstringReturns.description == description
    assert docstringReturns.type_name == type_name
    assert docstringReturns.is_generator == is_generator
    assert docstringReturns.return_name == return_name

# Generated at 2022-06-11 21:19:29.308012
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises()


# Generated at 2022-06-11 21:19:30.571722
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError()


# Generated at 2022-06-11 21:19:36.486785
# Unit test for constructor of class Docstring
def test_Docstring():
    D = Docstring()
    assert D.short_description == None
    assert D.long_description == None
    assert D.blank_after_short_description == False
    assert D.blank_after_long_description == False
    assert D.meta == []

    assert D.params == []
    assert D.raises == []
    assert D.returns == None
    assert D.deprecation == None


# Generated at 2022-06-11 21:19:43.244052
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    d = DocstringReturns(
        ["returns", "return"], "not None", "str", False, return_name="s"
    )
    assert d.args == ["returns", "return"]
    assert d.description == "not None"
    assert d.type_name == "str"
    assert d.return_name == "s"


# whole test suite

# Generated at 2022-06-11 21:19:46.493775
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args = [], description = 1, version = 2)
    a.args
    a.description
    a.version
    
    

# Generated at 2022-06-11 21:19:49.113429
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docStringParam = DocstringParam([], '', '', '', None, None)
    assert docStringParam


# Generated at 2022-06-11 21:20:24.271546
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('not so bad')
    except ParseError:
        pass


# Generated at 2022-06-11 21:20:32.093133
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returnDocString = DocstringReturns(
        args=["raises", "ValueError"], description="if something happens", type_name="ValueError", is_generator = False, return_name = None
    )
    assert returnDocString.description == "if something happens"
    assert returnDocString.type_name == "ValueError"
    assert returnDocString.is_generator == False
    assert returnDocString.return_name == None

# Generated at 2022-06-11 21:20:42.019435
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert (DocstringParam(["param", "p"],
                           "Some Description",
                           "p", None, None, None)).args == ["param", "p"]
    assert (DocstringParam(["param", "p"],
                           "Some Description",
                           "p", None, None, None)).description == "Some Description"
    assert (DocstringParam(["param", "p"],
                           "Some Description",
                           "p", None, None, None)).arg_name == "p"
   # assert (DocstringParam(["param", "p"],
    #                       "Some Description",
     #                      "p", None, None, None)).type_name == None
    assert (DocstringParam(["param", "p"],
                           "Some Description",
                           "p", None, None, None)).is_optional == None


# Generated at 2022-06-11 21:20:45.490420
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    >>> ParseError('TEST')
    Traceback (most recent call last):
    ...
    __main__.ParseError: TEST
    """

# Generated at 2022-06-11 21:20:49.224555
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    m = DocstringRaises(['raises'], 'description', 'type')
    assert m.args == ['raises']
    assert m.description == 'description'
    assert m.type_name == 'type'

# Generated at 2022-06-11 21:20:52.815505
# Unit test for constructor of class DocstringRaises

# Generated at 2022-06-11 21:20:57.156177
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_args = ["args"]
    test_type_name = "type_name"
    test_description = "description"
    doc = DocstringRaises(test_args, test_description, test_type_name)
    assert doc.args == test_args
    assert doc.type_name == test_type_name
    assert doc.description == test_description

# Generated at 2022-06-11 21:21:01.516276
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    simple_doc = DocstringDeprecated(['deprecated'], 'test1', 'test2')
    assert simple_doc.args == ['deprecated']
    assert simple_doc.description == 'test1'
    assert simple_doc.version == 'test2'


# Generated at 2022-06-11 21:21:06.477836
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    
    docstring_meta_1 = DocstringMeta(args=["param"], description="This is a test")
    assert docstring_meta_1.args == ["param"]
    assert docstring_meta_1.description == "This is a test"
    
    assert isinstance(docstring_meta_1, DocstringMeta)
    

# Generated at 2022-06-11 21:21:09.638919
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """ Test for Valid DocstringRaises Object """
    raises = DocstringRaises([":raises"], "description", "type_name")
    assert raises.description == "description"
    assert raises.type_name == "type_name"


# Generated at 2022-06-11 21:22:20.906499
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg"]
    description = "description"
    type_name = "type_name"
    raises = DocstringRaises(args, description, type_name)
    assert raises.description == description
    assert raises.type_name == type_name

# Generated at 2022-06-11 21:22:25.659202
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["raises"], "description", "type_name")
    print(docstring_raises.args)
    print(docstring_raises.description)
    print(docstring_raises.type_name)


# Generated at 2022-06-11 21:22:30.079528
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam([""], None, None, None, None, None)
    assert p.args == [""]
    assert p.description is None
    assert p.arg_name is None
    assert p.type_name is None
    assert p.is_optional is None
    assert p.default is None


# Generated at 2022-06-11 21:22:37.197723
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["a"], "a=a", "int")
    b = DocstringRaises(["b"], "b=b", "str")
    c = DocstringRaises(["c"], "c=c", "bool")
    assert a.type_name == "int"
    assert b.type_name == "str"
    assert c.type_name == "bool"
    print(a.type_name, b.type_name, c.type_name)



# Generated at 2022-06-11 21:22:40.302782
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=['p1', 'p2'], description=None, arg_name='value', type_name='None', is_optional=None, default=None)


# Generated at 2022-06-11 21:22:44.870611
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	obj = DocstringMeta(['a', 'b'], "hello world")
	assert obj.args == ['a', 'b']
	assert obj.description == 'hello world'
	return True


# Generated at 2022-06-11 21:22:50.256940
# Unit test for constructor of class Docstring
def test_Docstring():
	test1 = Docstring()
	assert test1.short_description == None
	assert test1.long_description == None
	assert test1.blank_after_short_description == False
	assert test1.blank_after_long_description == False
	assert test1.params == []
	assert test1.raises == []
	assert test1.returns == None
	assert test1.deprecation == None
	return "Finished"


# Generated at 2022-06-11 21:22:56.095078
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["test"]
    description = "Test Description"
    version = "Test Version"
    result = DocstringDeprecated(args, description, version)

    assert result is not None
    assert result.args == ["test"]
    assert result.description == "Test Description"
    assert result.version == "Test Version"


# Generated at 2022-06-11 21:23:03.114195
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = "I should have a description"
    type_name = "I should have a type_name"
    a = DocstringRaises(args, description, type_name)
    assert a.args == args
    assert a.description == description
    assert a.type_name == type_name

#- Unit test for constructor of class DocstringReturns

# Generated at 2022-06-11 21:23:06.913834
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    argument = "TypeError"
    description = "if something happens"
    meta = DocstringRaises([argument], description, "TypeError")
    assert meta.args == [argument]
    assert meta.description == description
    assert meta.type_name == "TypeError"


# Generated at 2022-06-11 21:25:31.599469
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args=["arg1", "arg2"], description="Documentation", version="1.0.0")
    assert a.description == "Documentation"
    assert a.version == "1.0.0"
    assert a.args == ["arg1", "arg2"]

# Generated at 2022-06-11 21:25:34.451090
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_args = ['parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    test_description = 'My description'
    test_type_name = 'int'

    test_item = DocstringRaises(test_args, test_description, test_type_name)

    assert test_item.args == test_args
    assert test_item.description == test_description
    assert test_item.type_name == test_type_name

# Generated at 2022-06-11 21:25:35.798733
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(None, None)



# Generated at 2022-06-11 21:25:39.732010
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = DocstringReturns(args = ["rob"], description = "string", type_name = "int", is_generator = True)
    assert type(docstring.args) == list
    assert type(docstring.description) == str
    assert type(docstring.type_name) == str
    assert type(docstring.is_generator) == bool
    assert type(docstring.return_name) == str
