

# Generated at 2022-06-11 21:15:45.024527
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert type(docstring.meta) == list
    return


# Generated at 2022-06-11 21:15:46.715123
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    o = DocstringMeta(["args"], "description")
    assert o.args == ["args"]
    assert o.description == "description"


# Generated at 2022-06-11 21:15:50.861830
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(["param"], "description")
    assert doc.args[0] == "param"
    assert doc.description == "description"


# Generated at 2022-06-11 21:15:58.856932
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test Normal use
    args = [":raises"]
    description = 'Description'
    type_name = "TypeName"
    test_obj = DocstringRaises(args, description, type_name)
    assert test_obj.args == [":raises"]
    assert test_obj.description == 'Description'
    assert test_obj.type_name == "TypeName"

    # Test TypeError
    args = []
    description = 'Description'
    type_name = 'Description'
    try:
        DocstringRaises(args, description, type_name)
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-11 21:16:03.914944
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None



# Generated at 2022-06-11 21:16:12.039102
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam([], description="", arg_name="n", type_name="str", is_optional=True, default="")
    assert(x.args == [])
    assert(x.description == "")
    assert(x.arg_name == "n")
    assert(x.type_name == "str")
    assert(x.is_optional == True)
    assert(x.default == "")


# Generated at 2022-06-11 21:16:16.548489
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["param"], "desc", "str", False)
    assert ds.description == "desc"
    assert ds.type_name == "str"
    assert ds.return_name is None
    assert ds.is_generator is False
    assert ds.args == ["param"]
    assert ds.return_name is None



# Generated at 2022-06-11 21:16:18.873172
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-11 21:16:26.591727
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['param'], None, 'arg', 'int', None, None)
    assert param.args == ['param']
    assert param.description == None
    assert param.arg_name == 'arg'
    assert param.type_name == 'int'
    assert param.is_optional == None
    assert param.default == None


# Generated at 2022-06-11 21:16:28.023619
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert (DocstringMeta([], ""))


# Generated at 2022-06-11 21:16:39.959965
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        ["param"],
        "info",
        "arg",
        "type",
        True,
        "default"
    )
    assert param.description == "info"
    assert param.args == ["param"]
    assert param.arg_name == "arg"
    assert param.type_name == "type"
    assert param.is_optional == True
    assert param.default == "default"


# Generated at 2022-06-11 21:16:44.974536
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r = DocstringReturns(['returns'], 'description', 'int', False, 'retval')
    assert r.args == ['returns']
    assert r.description == 'description'
    assert r.type_name == 'int'
    assert r.is_generator == False
    assert r.return_name == 'retval'



# Generated at 2022-06-11 21:16:53.262299
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # expected outcome:
    # DocstringRaises(args, description, type_name)

    args = ["type_name", "description"]
    description = "This is a descriptive field"
    type_name = "TypeError"
    a = DocstringRaises(args, description, type_name)
    assert a.args == ["type_name", "description"]
    assert a.description == "This is a descriptive field"
    assert a.type_name == "TypeError"



# Generated at 2022-06-11 21:16:55.724168
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False 
    assert d.blank_after_long_description == False 
    assert d.meta == [] 
# Unit tests for property Docstring.params

# Generated at 2022-06-11 21:17:01.091313
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['', '', '', '', ''], '', '', '', '', '')
    assert dp.args == ['', '', '', '', '']
    assert dp.description == ''
    assert dp.arg_name == ''
    assert dp.type_name == ''
    assert dp.is_optional == ''
    assert dp.default == ''


# Generated at 2022-06-11 21:17:02.384521
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("123")
    assert a.args == ("123",)


# Generated at 2022-06-11 21:17:11.011318
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-11 21:17:17.863370
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = "Test if constructor of class DocstringDeprecated works."
    a1 = ["deprecated"]
    a2 = "Not implemented"
    a3 = "1.0"
    b1 = DocstringDeprecated(a1, a2, a3)

    assert a1 == b1.args
    assert a2 == b1.description
    assert a3 == b1.version

# Generated at 2022-06-11 21:17:19.297408
# Unit test for constructor of class Docstring
def test_Docstring():
	doc = Docstring()
	assert doc is not None
	

# Generated at 2022-06-11 21:17:21.556925
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['returns'], 'description', 'type', False, 'return_name')


# Generated at 2022-06-11 21:17:28.581309
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringMeta(['param'], 'description')
    assert meta.args[0] == 'param'
    assert meta.description == 'description'



# Generated at 2022-06-11 21:17:30.673885
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("raise a test case")
    except ParseError as e:
        print(e)

# Generated at 2022-06-11 21:17:32.343754
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-11 21:17:35.015043
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("No good")
    except ParseError as e:
        assert str(e) == "No good"


# Generated at 2022-06-11 21:17:38.131744
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    input = DocstringReturns(["return"], "", "", False)
    assert input.return_name == None
    assert input.is_generator == False
    assert input.type_name == ""


# Generated at 2022-06-11 21:17:43.713082
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(args = ["testarg1","testarg2"], description = "testdescription", type_name = "testtype_name", is_generator = False, return_name = None)
    assert a.args == ["testarg1","testarg2"]
    assert a.description == "testdescription"
    assert a.type_name == "testtype_name"
    assert a.is_generator == False
    assert a.return_name == None


# Generated at 2022-06-11 21:17:49.628962
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    _DocstringDeprecated = DocstringDeprecated(args=['a', 'b', 'c'], description='d', version='e')
    assert _DocstringDeprecated.args == ['a','b','c']
    assert _DocstringDeprecated.description == 'd'
    assert _DocstringDeprecated.version == 'e'

# Generated at 2022-06-11 21:17:57.725904
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    type_name = "type_name"
    is_generator = False
    return_name = None
    description = None
    dr = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert dr.type_name == type_name
    assert dr.args == args
    assert dr.description == description
    assert dr.is_generator == is_generator
    assert dr.return_name == return_name


# Generated at 2022-06-11 21:18:00.878472
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("on_error")
    except ParseError as err:
        assert err.args[0] == "on_error"


# Generated at 2022-06-11 21:18:05.475409
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Testing DocstringRaises constructor."""
    args = ["raises", "ValueError", "if", "something", "happens"]
    description = "some description"
    type_name = "ValueError"
    obj = DocstringRaises(args, description, type_name)
    assert obj.args == args
    assert obj.description == description
    assert obj.type_name == type_name



# Generated at 2022-06-11 21:18:13.087909
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(["args"], "description", "type_name")
    assert doc.args == ["args"]
    assert doc.description == "description"
    assert doc.type_name == "type_name"

# Generated at 2022-06-11 21:18:19.359149
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """ Tests the constructor of class DocstringDeprecated"""
    # Setup
    deprecation = DocstringDeprecated(["deprecated", "depr"], "Deprecated funcion", "0.x")
    # Test
    assert deprecation.args == ["deprecated", "depr"]
    assert deprecation.description == "Deprecated funcion"
    assert deprecation.version == "0.x"


# Generated at 2022-06-11 21:18:27.671925
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    t1 = DocstringParam(
        args=[":param"],
        description="description",
        arg_name="arg",
        type_name="boolean",
        is_optional=True,
        default=True
    )
    assert t1.args == [":param"]
    assert t1.description == "description"
    assert t1.arg_name == "arg"
    assert t1.type_name == "boolean"
    assert t1.is_optional == True
    assert t1.default == True
    

# Generated at 2022-06-11 21:18:34.117315
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []

    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None

# Generated at 2022-06-11 21:18:36.535498
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docs = DocstringMeta(["parm"], "description")
    assert docs.args == ["parm"]
    assert docs.description == "description"


# Generated at 2022-06-11 21:18:42.471499
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['param'], 'descr', 'name', 'int', True, '5').arg_name == 'name'
    assert DocstringParam(['param'], 'descr', 'name', 'int', True, '5').is_optional == True
    assert DocstringParam(['param'], 'descr', 'name', 'int', True, '5').args == ['param']
    assert DocstringParam(['param'], 'descr', 'name', 'int', True, '5').type_name == 'int'
    assert DocstringParam(['param'], 'descr', 'name', 'int', True, '5').description == 'descr'
    assert DocstringParam(['param'], 'descr', 'name', 'int', True, '5').default == '5'


# Generated at 2022-06-11 21:18:47.186071
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-11 21:18:58.347815
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam1 = DocstringParam(["param"], "description", "arg", "type_name", True, "default")
    assert DocstringParam1.args == ["param"]
    assert DocstringParam1.description == "description"
    assert DocstringParam1.arg_name == "arg"
    assert DocstringParam1.type_name == "type_name"
    assert DocstringParam1.is_optional == True
    assert DocstringParam1.default == "default"
    DocstringParam2 = DocstringParam(["param", "param1"], "description1", "arg1", "type_name1", False, "default1")
    assert DocstringParam2.args == ["param", "param1"]
    assert DocstringParam2.description == "description1"
    assert DocstringParam2.arg_name == "arg1"


# Generated at 2022-06-11 21:19:00.706195
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(["param","parameter","arg"], "desc", "version")
    assert isinstance(meta, DocstringDeprecated)


# Generated at 2022-06-11 21:19:08.078234
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    class Test(DocstringDeprecated):
        def __init__(self, args, description, version):
            super().__init__(args, description, version)
            self.args = args
            self.description = description
            self.version = version
    test = Test(["true"],"true", "true")
    assert test != None
    assert test.args == ["true"]
    assert test.description == "true"
    assert test.version == "true"


# Generated at 2022-06-11 21:19:21.650469
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args=[]
    description=''
    arg_name=''
    type_name=None
    is_optional=None
    default=None
    docParam=DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert 1==1


# Generated at 2022-06-11 21:19:25.649745
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Verify that the DocstringDeprecated constructor is syntactically correct"""
    DocstringDeprecated(args=["kw"], description="Text.", version="v1.2.3")

# Generated at 2022-06-11 21:19:26.784125
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], None, None)
    assert True

# Generated at 2022-06-11 21:19:30.584501
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []




# Generated at 2022-06-11 21:19:35.885592
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam(0, 1, 2, 3, 4, 5)
    assert docstringParam.args == 0
    assert docstringParam.description == 1
    assert docstringParam.arg_name == 2
    assert docstringParam.type_name == 3
    assert docstringParam.is_optional == 4
    assert docstringParam.default == 5


# Generated at 2022-06-11 21:19:47.833510
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test first case
    params = DocstringParam(["param"], "", "arg", "type_name", "is_optional", "default")
    assert params.args == ["param"]
    assert params.description == ""
    assert params.arg_name == "arg"
    assert params.type_name == "type_name"
    assert params.is_optional == "is_optional"
    assert params.default == "default"
    # Test second case
    params = DocstringParam(["param", "type_name"], "", "arg", "type_name", "is_optional", "default")
    assert params.args == ["param", "type_name"]
    assert params.description == ""
    assert params.arg_name == "arg"
    assert params.type_name == "type_name"
    assert params.is_optional

# Generated at 2022-06-11 21:19:53.618973
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-11 21:19:59.755704
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["{}", ":", "param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "str"
    is_optional = True
    default = "None"
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-11 21:20:01.492266
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(["deprecated"], "description", "version")
    print(ds.description)
    return


# Generated at 2022-06-11 21:20:10.116845
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert isinstance(ds, Docstring)
    assert (ds.short_description == None)
    assert (ds.long_description == None)
    assert (ds.blank_after_short_description == False)
    assert (ds.blank_after_long_description == False)
    assert (ds.meta == [])
    assert (ds.params == [])
    assert (ds.raises == [])
    assert (ds.returns == None)
    assert (ds.deprecation == None)
    return True


# Generated at 2022-06-11 21:20:28.396917
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError('a')
    assert a!=None


# Generated at 2022-06-11 21:20:34.437023
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated"""
    test_instance = DocstringDeprecated(['param', 'parameter'], 'descrption', 'version')
    assert test_instance.args == ['param', 'parameter']
    assert test_instance.description == 'descrption'
    assert test_instance.version == 'version'


# Generated at 2022-06-11 21:20:40.544267
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    my_object = DocstringParam(["hello", "world"], "Description", "myvalue", "mytype", False, None)
    assert my_object.args == ["hello", "world"]
    assert my_object.description == "Description"
    assert my_object.arg_name == "myvalue"
    assert my_object.type_name == "mytype"
    assert my_object.is_optional == False
    assert my_object.default == None


# Generated at 2022-06-11 21:20:44.963662
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Test: Type_name == None
    DocstringReturns(["param"], "description", None, True, "return_name")
    # Test: Is_generator == False
    DocstringReturns(["param"], "description", "type_name", False, "return_name")



# Generated at 2022-06-11 21:20:50.449811
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], "", None, False, "")
    DocstringReturns([], "", "", False, "")
    DocstringReturns([], "", None, True, "")
    DocstringReturns([], "", "", True, "")


# Generated at 2022-06-11 21:20:54.817686
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docStringRaises = DocstringRaises([":raises","ValueError"], "error", "ValueError")

    assert docStringRaises.args == [":raises","ValueError"]
    assert docStringRaises.description == "error"
    assert docStringRaises.type_name == "ValueError"


# Generated at 2022-06-11 21:20:59.566556
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args_val = ["arg", "description"]
    description_val = "description"
    test_DocstringMeta = DocstringMeta(args_val, description_val)
    assert test_DocstringMeta.args == args_val
    assert test_DocstringMeta.description == description_val


# Generated at 2022-06-11 21:21:05.288658
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(args=['return', 'returns'], description='returns a generator', type_name='generator', is_generator=True)
    assert str(returns) == "<DocstringReturns[args=['return', 'returns'], description='returns a generator', type_name='generator', is_generator=True]>"


# Generated at 2022-06-11 21:21:07.503608
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta("arg", "test")
    assert d.args == "arg"
    assert d.description == "test"



# Generated at 2022-06-11 21:21:10.546961
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args=1,description=1,version=1)
    assert docstring_deprecated.args==1
    assert docstring_deprecated.description==1
    assert docstring_deprecated.version==1

# Generated at 2022-06-11 21:21:33.702850
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_name = "arg1"
    description = "return description"
    args = ["return", return_name]
    is_generator = True
    ret = DocstringReturns(args=args, description=description, is_generator=is_generator, return_name=return_name)
    ret.return_name



# Generated at 2022-06-11 21:21:35.532862
# Unit test for constructor of class ParseError
def test_ParseError():
    for i in range(4):
        assert ParseError(i, i)


# Generated at 2022-06-11 21:21:38.936811
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError()
    assert ParseError("message")
    assert ParseError("message", "msg2")


# Generated at 2022-06-11 21:21:40.306443
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("N/A")
    assert(err.args == "N/A")

# Generated at 2022-06-11 21:21:42.549313
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(["param"], None, "arg_name", "type_name", None, None)


# Generated at 2022-06-11 21:21:48.636256
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = [':param','arg','description']
    d = DocstringParam(a, 'description', 'arg', 'type', True, 'default')
    assert d.args==a
    assert d.description == 'description'
    assert d.arg_name == 'arg'
    assert d.type_name == 'type'
    assert d.is_optional == True
    assert d.default == 'default'


# Generated at 2022-06-11 21:21:51.126706
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        # test normal case
        raise ParseError("This is an test error.")
    except ParseError as error:
        assert(error.__str__() == "This is an test error.")



# Generated at 2022-06-11 21:21:54.085580
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of DocstringMeta."""
    meta = DocstringMeta(['args'], 'Test')
    assert meta.args == ['args']
    assert meta.description == 'Test'


# Generated at 2022-06-11 21:21:59.546370
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    '''Unit test for constructor of class DocstringMeta'''
    assert DocstringMeta([":param arg:", "parameter arg"], "description").args == [":param arg:", "parameter arg"]
    assert DocstringMeta([":param arg:", "parameter arg"], "description").description == "description"


# Generated at 2022-06-11 21:22:01.504360
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
   assert DocstringRaises(['param'], 'description', 'type_name')

# Generated at 2022-06-11 21:22:19.491550
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], "description", "version")



# Generated at 2022-06-11 21:22:25.819450
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError.

    The method should throw an exception if the user doesn't provide a message
    """
    try:
        raise ParseError()
    except TypeError:
        pass
    try:
        raise ParseError("Test message")
    except TypeError:
        assert False


# Generated at 2022-06-11 21:22:27.845151
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(args=None, description= None, version=None)
    return s


# Generated at 2022-06-11 21:22:29.394139
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  DocstringParam("args","description","arg_name","type_name",is_optional=True,default="default")

# Generated at 2022-06-11 21:22:33.275593
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_returns = DocstringReturns(["return","returns"], "return a string", "str", False, "name")
    assert test_returns.type_name == "str"
    assert test_returns.description == "return a string"

# Generated at 2022-06-11 21:22:35.285863
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docmeta = DocstringMeta(["a", "b"])
    assert docmeta.args == ["a", "b"]


# Generated at 2022-06-11 21:22:37.933223
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "blub")
    assert d.args == ["param"]
    assert d.description == "blub"


# Generated at 2022-06-11 21:22:38.516393
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    pass

# Generated at 2022-06-11 21:22:40.964376
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("exception").get_error() == "exception"


# Generated at 2022-06-11 21:22:47.899825
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = None
    type_name = "float"
    is_generator = False
    return_name = None

    assert isinstance(args, list)
    assert isinstance(description, str) or description is None
    assert isinstance(type_name, str)
    assert isinstance(is_generator, bool)
    assert isinstance(return_name, str) or return_name is None
    
    

# Generated at 2022-06-11 21:23:10.578010
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # constructor
    arg_lst = []
    arg_str = ''
    args = DocstringMeta(arg_lst, arg_str)
    assert args.args == []
    assert args.description == ''


# Generated at 2022-06-11 21:23:19.410662
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    list_args = ["returns", "return", "yields", "yield",]
    description = "The number of the week"
    type_name = "int"
    is_generator = True
    return_name = "week_nbr"

    docstring = DocstringReturns(list_args, description, type_name, is_generator, return_name)

    assert docstring.args == list_args
    assert docstring.description == description
    assert docstring.type_name == type_name
    assert docstring.is_generator == is_generator
    assert docstring.return_name == return_name


# Generated at 2022-06-11 21:23:28.373236
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=['attr'], description='my_description', arg_name='my_arg_name', type_name='type', is_optional=True, default='val')
    assert docstring_param.args == ['attr']
    assert docstring_param.description == 'my_description'
    assert docstring_param.arg_name == 'my_arg_name'
    assert docstring_param.type_name == 'type'
    assert docstring_param.is_optional is True
    assert docstring_param.default == 'val'


# Generated at 2022-06-11 21:23:33.894033
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dummy_args = ["param"]
    dummy_desc=["test desc"]
    dummy_type=["type"]
    dummy_generator=[True]
    new_return =DocstringReturns(dummy_args,dummy_desc,dummy_type,dummy_generator)
    assert new_return.type_name == dummy_type[0]
    assert new_return.is_generator == dummy_generator[0]
    assert new_return.arg_name == None
    assert new_return.default == None
    assert new_return.return_name == None
    assert new_return.description == dummy_desc[0]



# Generated at 2022-06-11 21:23:37.537142
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of class DocstringMeta."""
    result = DocstringMeta(["param"], "description")
    assert result.args == ["param"]
    assert result.description == "description"



# Generated at 2022-06-11 21:23:42.237122
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []

# Generated at 2022-06-11 21:23:49.324982
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []
    assert Docstring().params == []
    assert Docstring().raises == []
    assert Docstring().returns == None
    assert Docstring().deprecation == None

# Generated at 2022-06-11 21:23:52.965271
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-11 21:24:02.710757
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["one", "two", "three"]

# Generated at 2022-06-11 21:24:05.442120
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises"], "description", "type_name")


# Generated at 2022-06-11 21:24:47.472646
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    param_args = ["param"]
    param_description = "description"
    param = DocstringReturns(param_args, param_description, "type_name", True)
    assert param.args == param_args
    assert param.description == param_description
    assert param.type_name == "type_name"
    assert param.is_generator == True
    assert param.return_name == None


# Generated at 2022-06-11 21:24:49.195995
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], "Test description", "1.2.3")



# Generated at 2022-06-11 21:24:51.079743
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("error")
    assert e.args[0] == "error"

# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-11 21:24:54.829140
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args"]
    description = "test description"
    dm = DocstringMeta(args, description)
    assert dm.args == ["args"]
    assert dm.description == "test description"


# Generated at 2022-06-11 21:24:57.363565
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('This is a error!')
    assert error.args[0] == 'This is a error!'



# Generated at 2022-06-11 21:25:00.290632
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(
        args=['version'],
        description='a deprecated string',
        version='1.0.0'
    )
    assert docstring != None


# Generated at 2022-06-11 21:25:03.368306
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta("arg","desc")
    assert(dm.args == "arg")
    assert(dm.description == "desc")
    

# Generated at 2022-06-11 21:25:08.528053
# Unit test for constructor of class Docstring
def test_Docstring():
    # Arrange
    docstring = Docstring()
    
    # Act
    params = docstring.params
    raises = docstring.raises
    returns = docstring.returns
    deprecation = docstring.deprecation

    # Assert
    assert params == [], "docstring Test Failed!"
    assert raises == [], "docstring Test Failed!"
    assert returns is None, "docstring Test Failed!"
    assert deprecation is None, "docstring Test Failed!"

# Test Cases for constructor of Docstring
test_Docstring()

# Generated at 2022-06-11 21:25:11.909673
# Unit test for constructor of class Docstring
def test_Docstring():
    # 1. test construtor
    docstring = Docstring()

    # 2. test fields
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert len(docstring.meta) == 0


# Generated at 2022-06-11 21:25:16.953490
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test for correct construction
    docraises_obj = DocstringRaises(
        ["raises"], description="New description", type_name="ValueError"
    )

    assert docraises_obj.args == ["raises"]
    assert docraises_obj.description == "New description"
    assert docraises_obj.type_name == "ValueError"