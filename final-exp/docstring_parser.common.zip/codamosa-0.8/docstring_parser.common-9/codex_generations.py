

# Generated at 2022-06-11 21:15:44.955560
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated([], None, None)
    assert docstring.args == []
    assert docstring.description is None
    assert docstring.version is None



# Generated at 2022-06-11 21:15:46.916895
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args"]
    description = "description"
    d = DocstringMeta(args, description)
    assert d.args == args
    assert d.description == description


# Generated at 2022-06-11 21:15:56.859748
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises([], "", "")
    # test if the type of the object d is the same as DocstringRaises
    assert(isinstance(d, DocstringRaises) == True)
    # test if the type of the object d is the not the same as DocstringParam
    assert(isinstance(d, DocstringParam) == False)
    # test if the type of the object d is the not the same as DocstringReturns
    assert(isinstance(d, DocstringReturns) == False)
    # test if the type of the object d is the not the same as DocstringDeprecated
    assert(isinstance(d, DocstringDeprecated) == False)


# Generated at 2022-06-11 21:16:01.314417
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_dep = DocstringDeprecated([":deprecated:", "since 0.1"],
                                  "no longer supported", "0.1")
    assert doc_dep.args == [":deprecated:", "since 0.1"]
    assert doc_dep.description == "no longer supported"
    assert doc_dep.version == "0.1"


# Generated at 2022-06-11 21:16:02.970477
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is a ParseError")
    except ParseError:
        print("ParseError raised")


# Generated at 2022-06-11 21:16:06.526660
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = None
    version = None
    r = DocstringDeprecated(args, description, version)
    assert isinstance(r, DocstringMeta)
    assert isinstance(r, DocstringDeprecated)
    assert r.args == args
    assert r.description == description
    assert r.version == version



# Generated at 2022-06-11 21:16:10.857965
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    t = DocstringDeprecated(['bar'], 'Some description', 'baz')
    assert t.args == ['bar']
    assert t.description == 'Some description'
    assert t.version == 'baz'

# Generated at 2022-06-11 21:16:12.824686
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "parameter", "arg", "argument", True, "returns")


# Generated at 2022-06-11 21:16:16.087227
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-11 21:16:20.628469
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-11 21:16:26.860106
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['type'], None, 'int', False)
    assert a.type_name == 'int'


# Generated at 2022-06-11 21:16:28.963042
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(list("abc"), "test", "int")
    assert d.args == ['a', 'b', 'c']
    assert d.description == "test"
    assert d.type_name == "int"

# Generated at 2022-06-11 21:16:32.158127
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d1 = DocstringRaises([], "", "")
    assert isinstance(d1, DocstringMeta)
    assert d1.args == []
    assert d1.description == ""
    assert d1.type_name == ""
    print("test_DocstringRaises() finished!")
    

# Generated at 2022-06-11 21:16:45.061536
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test creating a new ParseError w/o argument
    with pytest.raises(TypeError):
        parseError = ParseError()
    # Test creating a new ParseError w/o a string as argument
    with pytest.raises(TypeError):
        parseError = ParseError(8)
    # Test creating a new ParseError with one string as argument
    parseError = ParseError("Test Error")
    assert parseError.args == ("Test Error",)
    assert str(parseError) == "Test Error"
    # Test creating a new ParseError with two strings as argument
    parseError = ParseError("Test Error", "TESTERR")
    assert parseError.args == ("Test Error", "TESTERR")
    assert str(parseError) == "Test ErrorTESTERR"

# Unit

# Generated at 2022-06-11 21:16:49.913978
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises."""
    ds = DocstringRaises([], "", "TypeError")
    assert ds.args == []
    assert ds.description == ""
    assert ds.type_name == "TypeError"


# Generated at 2022-06-11 21:16:54.324971
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    param_list1 = ["return", "returns", "Generator[typing.Any, None, None]"]
    param_list2 = [
        "return",
        "returns",
        "Generator",
        "[",
        "typing",
        ".",
        "Any",
        ",",
        "None",
        ",",
        "None",
        "]",
    ]
    param_list3 = ["return", "returns", "Generator", "[", "]"]
    param_list4 = ["return", "returns", "Generator[", "typing", ".", "Any", "]"]
    param_list5 = ["return", "returns", "Generator", "[", "typing", "]"]
    param_list6 = ["return", "returns", "Generator[]"]

# Generated at 2022-06-11 21:16:56.058449
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ds = DocstringMeta(["some_args"], "some_description")
    assert ds.args == ["some_args"]
    assert ds.description == "some_description"



# Generated at 2022-06-11 21:17:00.764118
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert hasattr(ds, "short_description")
    assert hasattr(ds, "long_description")
    assert hasattr(ds, "blank_after_short_description")
    assert hasattr(ds, "blank_after_long_description")
    assert hasattr(ds, "meta")


# Generated at 2022-06-11 21:17:03.761174
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-11 21:17:09.680273
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['a','b'], 'description', 'type')
    # Test the constructor of class DocstringRaises
    assert d.args == ['a','b']
    assert d.description == 'description'
    assert d.type_name == 'type'


# Generated at 2022-06-11 21:17:20.306404
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    assert test.short_description is None
    assert test.long_description is None
    assert test.meta == []
    assert test.params == []
    assert test.raises == []



# Generated at 2022-06-11 21:17:25.913943
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_type = DocstringReturns(["a", "b", "c"], "desc", "type", True)
    assert return_type.args == ["a", "b", "c"]
    assert return_type.description == "desc"
    assert return_type.type_name == "type"
    assert return_type.is_generator == True
    assert return_type.return_name == None


# Generated at 2022-06-11 21:17:32.850775
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    temp = DocstringParam("args", "description", "arg_name", "type_name", True, "default")
    assert temp.args == "args"
    assert temp.description == "description"
    assert temp.arg_name == "arg_name"
    assert temp.type_name == "type_name"
    assert temp.is_optional == True
    assert temp.default == "default"



# Generated at 2022-06-11 21:17:36.484633
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ra = DocstringRaises(['raises'], 'It raises', 'TypeError')
    assert ra.args == ['raises']
    assert ra.description == 'It raises'
    assert ra.type_name == 'TypeError'


# Generated at 2022-06-11 21:17:38.451069
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a=DocstringRaises([], None, None)
    assert a.description == None
    assert a.args == []
    assert a.type_name == None

# Generated at 2022-06-11 21:17:42.689124
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_obj = DocstringDeprecated(["param","argument"], "desc", "1.0")
    assert docstring_deprecated_obj.args == ["param","argument"]
    assert docstring_deprecated_obj.description == "desc"
    assert docstring_deprecated_obj.version == "1.0"


# Generated at 2022-06-11 21:17:47.212708
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['1', '2'], '3', '4').args == ['1', '2']
    assert DocstringDeprecated(['1', '2'], '3', '4').type_name == '4'

# Generated at 2022-06-11 21:17:52.734891
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["yields"], "Generator of names.", "list", False)
    assert ds.args == ["yields"]
    assert ds.description == "Generator of names."
    assert ds.type_name == "list"
    assert ds.is_generator == False


# Generated at 2022-06-11 21:17:56.136575
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(
            ["param"],
            None,
            "arg",
            None,
            False,
            None
        )
    except Exception:
        return False
    return True

# Generated at 2022-06-11 21:17:58.580704
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "Some description", "name", "SomeType", "False", "None")



# Generated at 2022-06-11 21:18:17.413027
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor."""
    dm = DocstringMeta(["param"], "description")

    assert dm.args == ["param"]
    assert dm.description == "description"


# Generated at 2022-06-11 21:18:25.924564
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "raises"]
    description = "Something"
    type_name = "int"
    is_generator = True
    return_name = "x"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    if docstring_returns is None:
        raise ParseError("Could not parse DocstringReturns")
    if docstring_returns.type_name != type_name:
        raise ParseError("Could not parse DocstringReturns.type_name")

# Generated at 2022-06-11 21:18:27.059992
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["hello"], "world", "3.3")


# Generated at 2022-06-11 21:18:30.284058
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args"]
    description = "description"
    actual = DocstringMeta(args, description)
    expected = (args, description)
    assert expected == actual.args, actual.description


# Generated at 2022-06-11 21:18:35.678201
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(args = ['a', 'b'], description = "asdf", type_name = "asdf", is_generator = False)
    assert ds.type_name == "asdf"
    assert ds.is_generator == False
    assert ds.return_name == None
    

# Generated at 2022-06-11 21:18:39.504633
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    x = DocstringDeprecated([':deprecated'], "since version 3.2", "3.2")
    assert x.args == [':deprecated']
    assert x.description == "since version 3.2"
    assert x.version == "3.2"


# Generated at 2022-06-11 21:18:44.954597
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc1 = DocstringReturns(['args'], 'description', 'type_name', True, 'return_name')
    assert isinstance(doc1, DocstringReturns)
    assert doc1.args == ['args']
    assert doc1.description == 'description'
    assert doc1.type_name == 'type_name'
    assert doc1.is_generator == True
    assert doc1.return_name == 'return_name'
    

# Generated at 2022-06-11 21:18:56.015213
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Attributes
    test_args = ["returns", "description", "type_name", "is_generator", "return_name"]
    test_description = "DocstringReturns"
    test_type_name = "string"
    test_is_generator = False
    test_return_name = "test_return_name"

    # Init
    test_DocstringReturns = DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    # Verify
    assert test_description == test_DocstringReturns.description
    assert test_type_name == test_DocstringReturns.type_name
    assert test_is_generator == test_DocstringReturns.is_generator
    assert test_return_name == test_DocstringReturns.return_name
# Unit

# Generated at 2022-06-11 21:18:59.953591
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(['deprecated', 'since', '1.0'], "bla", "1.0")
    assert docstringDeprecated.args == ['deprecated', 'since', '1.0']
    assert docstringDeprecated.description == "bla"
    assert docstringDeprecated.version == "1.0"


# Generated at 2022-06-11 21:19:11.396794
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("Testing constructor of class DocstringParam")
    args = ['args', 'arg']
    description = 'This is the docstring description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    test_param = DocstringParam(args, 
                                description,
                                arg_name,
                                type_name,
                                is_optional,
                                default)
    assert len(test_param.args) == len(args)
    assert len(test_param.args) == len(test_param.args)
    assert test_param.arg_name == arg_name
    assert test_param.type_name == type_name
    assert test_param.is_optional == is_optional
    assert test_param.default

# Generated at 2022-06-11 21:19:43.688998
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("message")
    except ParseError as exception:
        pass
    assert str(exception) == "message"

# Generated at 2022-06-11 21:19:50.757315
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    type_name = None
    is_generator = False
    return_name = None
    temp = DocstringReturns(args, "", type_name, is_generator, return_name)
    assert temp.description == ""
    assert temp.args == []
    assert temp.type_name is None
    assert temp.is_generator == False
    assert temp.return_name is None



# Generated at 2022-06-11 21:19:56.189438
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises([], "test description", None)
    assert test.args == []
    assert test.description == "test description"
    assert test.type_name is None
    test.type_name = "TypeError"
    assert test.type_name == "TypeError"
    

# Generated at 2022-06-11 21:19:58.392942
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("why hello there")
    except ParseError:
        return True
    return False


# Generated at 2022-06-11 21:20:00.962945
# Unit test for constructor of class ParseError
def test_ParseError():
    ra = RuntimeError("a")
    pe = ParseError("b")
    assert isinstance(pe, Exception)
    assert isinstance(pe, RuntimeError)

# Generated at 2022-06-11 21:20:07.940243
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_obj = DocstringReturns(
        args=["yields"],
        description="intermediate results",
        type_name=None,
        is_generator=True,
    )
    assert isinstance(test_obj, DocstringReturns)
    assert test_obj.args == ["yields"]
    assert test_obj.description == "intermediate results"
    assert test_obj.type_name is None
    assert test_obj.is_generator is True



# Generated at 2022-06-11 21:20:09.709789
# Unit test for constructor of class ParseError
def test_ParseError():

    error = ParseError("Example error message")
    assert error == "Example error message"

# Generated at 2022-06-11 21:20:13.419664
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param', 'arg']
    description = 'if something happens'
    type_name = 'ValueError'
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises


# Generated at 2022-06-11 21:20:14.739880
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print("DocstringMeta")
    ds = DocstringMeta([1,2], "description")
    assert ds.args == [1,2]
    assert ds.description == "description"


# Generated at 2022-06-11 21:20:19.586997
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-11 21:20:53.611330
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ma = ['a', 'b']
    ca = 'c'
    meta = DocstringMeta(ma, ca)
    assert meta.args == ['a', 'b']
    assert meta.description == 'c'

# Generated at 2022-06-11 21:20:55.348007
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d_m = DocstringMeta(['abc'], 'abc')
    assert d_m.args == ['abc']
    assert d_m.description == 'abc'


# Generated at 2022-06-11 21:21:01.468335
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(["return"], "some return", "some_type", False)
    assert(returns.args == ["return"])
    assert(returns.description == "some return")
    assert(returns.type_name == "some_type")
    assert(returns.is_generator == False)
    assert(returns.return_name == None)



# Generated at 2022-06-11 21:21:03.054901
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args = [], description = None, type_name = 'ValueError')

# Generated at 2022-06-11 21:21:05.862576
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['param','arg'], 'description')
    assert d.args == ['param','arg']
    assert d.description =='description'


# Generated at 2022-06-11 21:21:08.784862
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ds_meta = DocstringMeta(["args"], "description")
    assert ds_meta.args == ["args"]
    assert ds_meta.description == "description"


# Generated at 2022-06-11 21:21:10.075345
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], None, None)



# Generated at 2022-06-11 21:21:11.821501
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  line = DocstringRaises("hoge","fuga","piyo")
  line.args
  line.description
  line.type_name

# Generated at 2022-06-11 21:21:13.034055
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass


# Generated at 2022-06-11 21:21:19.620573
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'attribute']
    description = 'a parameter'
    import re
    assert re.compile(r'\w+').search(description)
    docstr = DocstringMeta(args, description)
    assert docstr.args[1] == 'arg'
    assert re.compile(r'\w+').search(docstr.description)


# Generated at 2022-06-11 21:21:54.622207
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    t1 = DocstringMeta(['param'], 'description')
    assert t1.args[0] == 'param'
    assert t1.description == 'description'


# Generated at 2022-06-11 21:21:57.457837
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError('Error')


# Generated at 2022-06-11 21:21:59.301349
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert isinstance(docstring, Docstring)



# Generated at 2022-06-11 21:22:02.048289
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(["param"], "desc")
    assert obj.args == ["param"]
    assert obj.description == "desc"


# Generated at 2022-06-11 21:22:04.739785
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        print("test ParseError successfully!\n")
test_ParseError()


# Generated at 2022-06-11 21:22:09.412844
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-11 21:22:12.478350
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param", "arg", "name"], "description of the parameter", "name", "str", False, "none")
    return True

# Generated at 2022-06-11 21:22:17.466155
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['args'], 'description', 'type_name')
    assert a.args == ['args']
    assert a.description == 'description'
    assert a.type_name == 'type_name'


# Generated at 2022-06-11 21:22:20.980629
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test of ParseError constructor."""
    try:
        raise ParseError("ABC")
    except ParseError as e:
        assert e.args == ("ABC",)


# Generated at 2022-06-11 21:22:29.030002
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False
    assert docstring_1.blank_after_long_description is False
    assert docstring_1.meta == []
    assert docstring_1.params == []
    assert docstring_1.raises == []
    assert docstring_1.returns is None
    assert docstring_1.deprecation is None
    return

# Generated at 2022-06-11 21:23:39.990248
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['t'], 't', 't')
    assert test.args == ['t']
    assert test.description == 't'
    assert test.type_name == 't'


# Generated at 2022-06-11 21:23:48.365559
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["Param", "Deprecated"], "Explanation", "1.0")
    #Test the attribute type_name
    assert test.type_name == "Param"
    #Test the attribute description
    assert test.description == "Explanation"
    #Test the attribute version
    assert test.version == "1.0"
    assert test.args[0] == "Param"
    assert test.args[1] == "Deprecated"

# Generated at 2022-06-11 21:23:49.665820
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError('fatal')

# Generated at 2022-06-11 21:23:51.629376
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(['raises'], 'some description', 'some type')
    assert ds.type_name == 'some type'

# Generated at 2022-06-11 21:23:58.033999
# Unit test for constructor of class Docstring
def test_Docstring():
    """
	"""
    # Unit test for constructor of class Docstring
    # test 1
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    # test 2
    # test 3
    # test 4



# Generated at 2022-06-11 21:24:05.023507
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    description = "Description"
    args = ["args"]
    type_name = "int"
    is_generator = True
    return_name = "return_name"

    DocstringReturns_1 = DocstringReturns(args, description, type_name, is_generator)
    assert DocstringReturns_1.args == args
    assert DocstringReturns_1.type_name == type_name
    assert DocstringReturns_1.is_generator == is_generator
    assert DocstringReturns_1.return_name == None
    assert DocstringReturns_1.description == description

    DocstringReturns_2 = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert DocstringReturns_2.args == args
    assert DocstringReturns_2.type_name == type_name
    assert Doc

# Generated at 2022-06-11 21:24:07.689027
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["param"], "description", "version")
    assert docstring_deprecated is not None


# Generated at 2022-06-11 21:24:09.144918
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, None)


# Generated at 2022-06-11 21:24:16.171581
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None


# Generated at 2022-06-11 21:24:20.092470
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of class DocstringParam"""
    # This test case currently only tests if the constructor is callable,
    # the correctness of the parameters is not tested
    DocstringParam(
        args = ["param"],
        description = None,
        arg_name = "x",
        type_name = "float",
        is_optional = True,
        default = "0.0"
    )