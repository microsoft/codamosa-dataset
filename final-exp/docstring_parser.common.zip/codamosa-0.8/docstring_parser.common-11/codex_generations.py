

# Generated at 2022-06-11 21:15:47.169021
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param", "arg", "arg2"], "description")



# Generated at 2022-06-11 21:15:47.896714
# Unit test for constructor of class Docstring
def test_Docstring():
    pass

# Generated at 2022-06-11 21:15:53.454733
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    rev = DocstringReturns(
        ["arg"],
        "test",
        "type",
        True)

    assert rev.args == ["arg"]
    assert rev.description == "test"
    assert rev.type_name == "type"
    assert rev.is_generator == True

# Generated at 2022-06-11 21:15:57.418499
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["raises", "ValueError"], description = "description", type_name = "exception")
    assert test.args == ["raises", "ValueError"]
    assert test.description == "description"
    assert test.type_name == "exception"

# Generated at 2022-06-11 21:15:58.660592
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated is not None


# Generated at 2022-06-11 21:16:01.061270
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises("", "", "")
    assert a.args == ""
    assert a.description == ""
    assert a.type_name == ""



# Generated at 2022-06-11 21:16:05.428278
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    _args = ["return", "Returns", ":return:", ":returns:"]
    _description = "some description"
    _type_name = "str"
    _is_generator = False

    def_1 = DocstringReturns(args=_args, description=_description, type_name=_type_name, is_generator=_is_generator)
    assert def_1.args == _args
    assert def_1.description == _description
    assert def_1.type_name == _type_name
    assert def_1.is_generator == _is_generator



# Generated at 2022-06-11 21:16:10.758387
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-11 21:16:14.455380
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    pd = DocstringParam([":param f: "], "function f's doc string","f","function", None, None)
    assert pd.arg_name == "f"
    assert pd.type_name == "function"
    assert pd.description == "function f's doc string"

# Generated at 2022-06-11 21:16:17.145441
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert str(DocstringRaises(["1", "r1", "r2"], "description", "t")) != None

# Generated at 2022-06-11 21:16:26.960981
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of class Docstring."""
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-11 21:16:31.075496
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta = DocstringMeta(["a", "b", "c"], "This is a description.")
    assert type(docstringMeta) == DocstringMeta
    assert docstringMeta.args == ["a", "b", "c"]
    assert docstringMeta.description == "This is a description."


# Generated at 2022-06-11 21:16:41.423046
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["s"], "TEST", "TEST", "TEST", "TEST", "TEST")
    assert docstring_param.args == ["s"]
    assert docstring_param.description == "TEST"
    assert docstring_param.arg_name == "TEST"
    assert docstring_param.type_name == "TEST"
    assert docstring_param.is_optional == "TEST"
    assert docstring_param.default == "TEST"


# Generated at 2022-06-11 21:16:43.810265
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a=DocstringMeta(['a'], 'desc')
    assert a.args == ['a']
    assert a.description == 'desc'


# Generated at 2022-06-11 21:16:47.101060
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a=DocstringRaises(["a"], "b", "c")
    assert a.args == ["a"]
    assert a.type_name == "c"
    assert a.description == "b"


# Generated at 2022-06-11 21:16:49.304783
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["a"], "b", "c")
    assert type(d) == DocstringDeprecated
    return


# Generated at 2022-06-11 21:16:52.172184
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam([
        "param", "arg"
    ], "description", "name", "type", False, "default")


# Generated at 2022-06-11 21:16:54.334503
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["param"], "Description.", "1.1")

# Generated at 2022-06-11 21:16:56.978971
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises"]
    description = "raising"
    type_name = "TypeError"
    assert DocstringRaises(args, description, type_name)


# Generated at 2022-06-11 21:17:01.756895
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:17:15.617001
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(
        ['param'], 'description', 'arg_name', 'type_name', True, 'default'
    )
    assert dp.args == ['param'], 'args should be ["param"]'
    assert (
        dp.description == 'description'
    ), 'description should be "description"'
    assert dp.arg_name == 'arg_name', 'arg_name should be "arg_name"'
    assert dp.type_name == 'type_name', 'type_name should be "type_name"'
    assert dp.is_optional == True, 'is_optional should be True'
    assert dp.default == 'default', 'default should be "default"'



# Generated at 2022-06-11 21:17:16.726863
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError


# Generated at 2022-06-11 21:17:23.746731
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["arg"]
    description = "desc"
    type_name = "type"
    is_generator = True
    return_name = "name"
    d = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert d.args == args
    assert d.description == description
    assert d.type_name == type_name
    assert d.is_generator == is_generator
    assert d.return_name == return_name


# Generated at 2022-06-11 21:17:26.150471
# Unit test for constructor of class Docstring
def test_Docstring():
    from typeguard import check_type
    do = Docstring()
    check_type('do', do, Docstring)


# Generated at 2022-06-11 21:17:32.287129
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of class Docstring."""
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-11 21:17:34.525090
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises_object = DocstringRaises(args = [], description = "", type_name = "")


# Generated at 2022-06-11 21:17:37.712236
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(args=["param"], description="docstring").args == ["param"]
    assert DocstringMeta(args=["param"], description="docstring").description == "docstring"


# Generated at 2022-06-11 21:17:40.076336
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    result = DocstringDeprecated(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"],None,None)
    assert result != None


# Generated at 2022-06-11 21:17:43.404786
# Unit test for constructor of class ParseError
def test_ParseError():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-11 21:17:46.451012
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        ParseError("error")


# Generated at 2022-06-11 21:18:01.332146
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()

# Generated at 2022-06-11 21:18:04.717616
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(['returns'], 'This is a return value', 'int', False)
    assert returns.args == ['returns']
    assert returns.description == 'This is a return value'
    assert returns.is_generator == False


# Generated at 2022-06-11 21:18:08.424250
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert str(DocstringReturns("args","description","type_name", False, "return_name")) == "DocstringReturns(args, description, type_name, False, return_name)"


# Generated at 2022-06-11 21:18:12.843363
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns([], "", "")
    assert returns.type_name == ""
    assert returns.description == ""
    assert returns.is_generator is False
    assert returns.return_name is None
    assert returns.args == []


# Generated at 2022-06-11 21:18:19.179840
# Unit test for constructor of class ParseError
def test_ParseError():
    err1 = ParseError('This is a ParseError1')
    assert(str(err1))
    assert(type(err1) is ParseError)
    try:
        raise ParseError('This is a raise ParseError2')
    except ParseError as err2:
        print(err2)
        assert(type(err2) is ParseError)


# Generated at 2022-06-11 21:18:29.947153
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Simple DocstringDeprecated
    docstring_deprecated_simple = DocstringDeprecated(["deprecated"], "simple deprecation")
    assert docstring_deprecated_simple.args[0] == "deprecated"
    assert docstring_deprecated_simple.description == "simple deprecation"
    assert docstring_deprecated_simple.version is None

    # DocstringDeprecated with specified version
    docstring_deprecated_version = DocstringDeprecated(["deprecated", "since", "2.2"], "deprecated with version")
    assert docstring_deprecated_version.args[0] == "deprecated"
    assert docstring_deprecated_version.args[1] == "since"
    assert docstring_deprecated_version.args[2] == "2.2"

# Generated at 2022-06-11 21:18:39.574138
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["this", "is", "a", "test"]
    description = "test description"
    arg_name = "test_argument"
    type_name = "test_type"
    is_optional = True
    default = "10"

    test_DocstringParam = DocstringParam(args, description,
                                         arg_name, type_name,
                                         is_optional, default)

    assert test_DocstringParam.args == args
    assert test_DocstringParam.description == description
    assert test_DocstringParam.arg_name == arg_name
    assert test_DocstringParam.type_name == type_name
    assert test_DocstringParam.is_optional == is_optional
    assert test_DocstringParam.default == default



# Generated at 2022-06-11 21:18:43.707960
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-11 21:18:54.648617
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Case 1 - initialize a DocstringParam item with the following parameters:
    # args = []
    # description = "this is the description of the item"
    # arg_name = "arg_name"
    # type_name = "type_name"
    # is_optional = True
    # default = "None"
    test_obj = DocstringParam(args = [], description = "this is the description of the item", arg_name = "arg_name", type_name = "type_name", is_optional = True, default = "None")
    assert test_obj.description == "this is the description of the item"
    assert test_obj.default == "None"
    assert test_obj.is_optional == True
    assert test_obj.arg_name == "arg_name"

# Generated at 2022-06-11 21:18:57.231559
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None


# Generated at 2022-06-11 21:19:31.979551
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param", "type_name"], "description", "arg_name", "type_name", "is_optional", "default")
    assert a.args == ["param", "type_name"]
    assert a.arg_name == "arg_name"
    assert a.type_name == "type_name"
    assert a.is_optional == "is_optional"
    assert a.default == "default"


# Generated at 2022-06-11 21:19:34.600637
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([], None, None, False)
    b = DocstringReturns([], None, None, False)
    assert isinstance(a, DocstringReturns)

# Generated at 2022-06-11 21:19:40.536023
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(None, None, None)
    assert x.args == None
    assert x.description == None
    assert x.type_name == None
    x = DocstringRaises([], "test", "5")
    assert x.args == []
    assert x.description == "test"
    assert x.type_name == "5"


# Generated at 2022-06-11 21:19:45.007900
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    assert test.short_description == None
    assert test.long_description == None
    assert test.blank_after_short_description == False
    assert test.blank_after_long_description == False
    assert test.meta == []


# Generated at 2022-06-11 21:19:53.954593
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg_name"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "True"

    d_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert d_param.args[0] == "param"
    assert d_param.description == "description"
    assert d_param.arg_name == "arg_name"
    assert d_param.type_name == "type_name"
    assert d_param.is_optional == True
    assert d_param.default == "True"


# Generated at 2022-06-11 21:19:59.060778
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args = [], description = 'test_description', version = '0.0.1')
    assert a.args == []
    assert a.description == 'test_description'
    assert a.version == '0.0.1'


# Generated at 2022-06-11 21:20:10.216522
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert (DocstringParam(["param", "arg"], "description", "arg_name", "type_name",
                           "is_optional", "default")).arg_name == 'arg_name'
    assert (DocstringParam(["param", "arg"], "description", "arg_name", "type_name",
                           "is_optional", "default")).type_name == 'type_name'
    assert (DocstringParam(["param", "arg"], "description", "arg_name", "type_name",
                           "is_optional", "default")).is_optional == 'is_optional'
    assert (DocstringParam(["param", "arg"], "description", "arg_name", "type_name",
                           "is_optional", "default")).default == 'default'

# Generated at 2022-06-11 21:20:13.083681
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(
        args=['param', 'str'],
        description="Max number of items for a user",
        type_name="IOError"
    )

# Generated at 2022-06-11 21:20:14.173564
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_type = DocstringMeta([], "test")
    assert test_type.args == []
    assert test_type.description == "test"



# Generated at 2022-06-11 21:20:23.932679
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    import pytest
    item = DocstringReturns(["args"], "description", "type", "is_generator", "return_name")
    assert item.args == ["args"]
    assert item.return_name == "return_name"
    assert item.type == "type"
    assert item.is_generator == "is_generator"
    assert item.description == "description"
    item1 = DocstringReturns(["args"], "description", "type", "is_generator")
    assert item1.args == ["args"]
    assert item1.return_name == None
    assert item1.type == "type"
    assert item1.is_generator == "is_generator"
    assert item1.description == "description"

# Generated at 2022-06-11 21:21:25.956260
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['param', 'arg'], 'Some description')
    assert a.args[0] == 'param'
    assert a.args[1] == 'arg'
    assert a.description == 'Some description'


# Generated at 2022-06-11 21:21:28.407959
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-11 21:21:33.386759
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	d = DocstringReturns(['param'], "This is a test!", None, False)
	assert d.args == ['param']
	assert d.description == "This is a test!"
	assert d.type_name == None
	assert d.is_generator == False
	assert d.return_name == None


# Generated at 2022-06-11 21:21:35.839656
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    
    """
    pe = ParseError("a")
    assert pe.args[0] == "a"
    assert pe.args[1] == "b"
    


# Generated at 2022-06-11 21:21:41.205307
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    d = Docstring()
    assert d is not None
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-11 21:21:45.775373
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    _DocstringDeprecated = DocstringDeprecated(['deprecated'], 'Deprecated', '1.0')
    assert _DocstringDeprecated.description == 'Deprecated'
    assert _DocstringDeprecated.version == '1.0'
    assert _DocstringDeprecated.args == ['deprecated']



# Generated at 2022-06-11 21:21:52.809656
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    import pytest
    params = [
        (["arg1", "arg2", "arg3"], "", "arg1", "arg2", "arg3"),
        (["arg1", "arg2", "arg3"], "", "arg1", "", ""),
        (["arg1", "arg2", "arg3"], "", "arg1", "", None),
    ]
    for arg1 in params:
        with pytest.raises(TypeError):
            DocstringParam(arg1[0], arg1[1], arg1[2], arg1[3])



# Generated at 2022-06-11 21:21:54.167178
# Unit test for constructor of class ParseError
def test_ParseError():
    parseError = ParseError("Test")
    assert parseError.args == ("Test",)

# Generated at 2022-06-11 21:21:58.808286
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta."""
    d = DocstringMeta(["a", "b"], "ab")
    assert (d.args == ["a", "b"])
    assert (d.description == "ab")


# Generated at 2022-06-11 21:21:59.779835
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError('Boom!')

# Generated at 2022-06-11 21:24:03.035404
# Unit test for constructor of class Docstring
def test_Docstring():
    # not parameter
    test_short_description = "This is a Docstring."
    test_meta = []
    test_Docstring = Docstring()
    assert test_Docstring.short_description == test_short_description
    assert test_Docstring.meta == test_meta
    # parameter
    test_short_description = "This is a Docstring."
    test_meta = []
    test_Docstring = Docstring(test_short_description, test_meta)
    assert test_Docstring.short_description == test_short_description
    assert test_Docstring.meta == test_meta


# Generated at 2022-06-11 21:24:13.633157
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'str'
    is_optional = True
    default = 'default'

    d = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    # Test class attributes
    assert(d.args == ['arg', 'description'])
    assert(d.description == 'description')
    assert(d.arg_name == 'arg')
    assert(d.type_name == 'str')
    assert(d.is_optional == True)
    assert(d.default == 'default')


# Generated at 2022-06-11 21:24:16.659560
# Unit test for constructor of class Docstring
def test_Docstring():
    testDocstring = Docstring()
    print(type(testDocstring.params))
    print(type(testDocstring.meta))
test_Docstring()


# Generated at 2022-06-11 21:24:20.284998
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr = DocstringReturns([], "", "")
    assert docstr.args == []
    assert docstr.description == ""
    assert docstr.type_name == ""
    assert docstr.is_generator == False
    assert docstr.return_name == None

# Generated at 2022-06-11 21:24:20.826649
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()

# Generated at 2022-06-11 21:24:24.108155
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises'], 'description', 'TypeError')

# Generated at 2022-06-11 21:24:31.300215
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    message = DocstringParam(['param', 'arg', 'argument'], 'argument_name', 'type_name', True, 'default_value')
    assert message.args == ['param', 'arg', 'argument']
    assert message.arg_name == 'argument_name'
    assert message.type_name == 'type_name'
    assert message.is_optional == True
    assert message.default == 'default_value'

# Generated at 2022-06-11 21:24:33.921958
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([], None, None)
    assert a.args == []
    assert a.description == None
    assert a.type_name == None


# Generated at 2022-06-11 21:24:46.200240
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    description = "Constructor of class DocstringParam"
    arg_name = 'parameter arg_name'
    type_name = 'typing.Optional[bool]'
    is_optional = True
    default = 'None'
    args = ["param","python"]
    ds_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert ds_param.arg_name == arg_name, "Getting the value of DocstringParam.arg_name failed."
    assert ds_param.type_name == type_name, "Getting the value of DocstringParam.type_name failed."
    assert ds_param.is_optional == is_optional, "Getting the value of DocstringParam.is_optional failed."

# Generated at 2022-06-11 21:24:51.675472
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    kwargs = {"args":["parameter","arg","argument","attribute","key","keyword"],"description":"if something happens","arg_name":"arg_name","type_name":"int","is_optional":False,"default":None}

    to_test = DocstringRaises(**kwargs)
    expected = TestDocstringRaises(**kwargs)
    print("Expected: ",expected, "Got: ",to_test)
    assert to_test == expected
