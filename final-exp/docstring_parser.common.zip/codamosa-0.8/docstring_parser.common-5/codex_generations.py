

# Generated at 2022-06-11 21:15:44.988175
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert True


# Generated at 2022-06-11 21:15:48.156521
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises({'a','b'},'desc','type')
    print(doc.args) # {'a','b'}
    print(doc.description) # desc
    print(doc.type_name) # type


# Generated at 2022-06-11 21:15:51.018310
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], 'description', 'a', 'int', 'True', '5')

# Generated at 2022-06-11 21:15:52.169215
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
   assert DocstringRaises.__name__ == 'DocstringRaises'


# Generated at 2022-06-11 21:15:58.262905
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test the constructor of DocstringMeta."""
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    assert docstringMeta.description == description

#Unit test for constructor of class DocstringParam

# Generated at 2022-06-11 21:15:59.533109
# Unit test for constructor of class ParseError
def test_ParseError():
    obj = ParseError("test")
    assert str(obj) == "test"

# Generated at 2022-06-11 21:16:01.613864
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    item = DocstringRaises
    assert isinstance(item, DocstringRaises)


# Generated at 2022-06-11 21:16:04.195836
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['a1'], "a2", "a3", "a4", "a5", "a6").type_name == "a4"


# Generated at 2022-06-11 21:16:07.019894
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("my message")
    assert e.args[0] == "my message"


# Generated at 2022-06-11 21:16:14.876795
# Unit test for constructor of class Docstring
def test_Docstring():
    # object
    test = Docstring()
    # test if all attributes are initialized to None
    assert test.short_description == None
    assert test.long_description == None
    assert test.blank_after_short_description == False
    assert test.blank_after_long_description == False
    assert test.meta == []
    # test if an uninitialized object can be used as a property
    assert test.params == []
    assert test.raises == []
    assert test.deprecation == None
    assert test.returns == None


# Generated at 2022-06-11 21:16:26.335427
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # docstring meta information with one argument, a description and a list of arguments
    args = ["param", "arg", "argument"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)

    assert isinstance(docstring_meta, DocstringMeta)
    assert docstring_meta.args == args
    assert docstring_meta.description == description



# Generated at 2022-06-11 21:16:30.007170
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    example = DocstringRaises(['a', 'b', 'a'], 'sopme description', 'Exception')  # noqa E501
    assert example.type_name == 'Exception'
    assert example.description == 'sopme description'

# Generated at 2022-06-11 21:16:37.181452
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["returns"], "foo", "int", True)
    assert ds.is_generator
    ds = DocstringReturns(["yields"], "foo", "int", True)
    assert ds.is_generator
    assert ds.args == ['yields']
    assert ds.description == 'foo'
    assert ds.type_name == 'int'



# Generated at 2022-06-11 21:16:47.825651
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    docstring.short_description = "hello"
    docstring.long_description = "world"
    docstring.blank_after_short_description = True
    param1 = DocstringParam(["param", "arg"], "arg description", "arg", None, None, None)
    param2 = DocstringParam(["param", "arg"], "arg description", "arg", None, None, None)
    docstring.meta.append(param1)
    docstring.meta.append(param2)
    assert docstring.short_description == "hello"
    assert docstring.long_description == "world"
    assert docstring.blank_after_short_description == True
    assert len(docstring.meta) == 2
    assert docstring.params[0].args == ["param", "arg"]

# Generated at 2022-06-11 21:16:58.695136
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["raises"]
    description = "description"
    type_name = "ValueError"
    is_generator = True
    return_name = "return_name"
    assert DocstringReturns(args, description, type_name, is_generator, return_name).description == "description"
    assert DocstringReturns(args, description, type_name, is_generator, return_name).type_name == "ValueError"
    assert DocstringReturns(args, description, type_name, is_generator, return_name).is_generator == True
    assert DocstringReturns(args, description, type_name, is_generator, return_name).return_name == "return_name"
test_DocstringReturns()

# Generated at 2022-06-11 21:17:00.513847
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("test")  # returns nothing if test is true


# Generated at 2022-06-11 21:17:01.271084
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises.__init__

# Generated at 2022-06-11 21:17:09.979823
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["param", "keyword", "argument"], "demo description", "param type")
    assert docstring_raises.args == ["param", "keyword", "argument"], "test_DocstringRaises fails"
    assert docstring_raises.description == "demo description", "test_DocstringRaises fails"
    assert docstring_raises.type_name == "param type", "test_DocstringRaises fails"


# Generated at 2022-06-11 21:17:16.187092
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    my_test = DocstringRaises(['raises', 'ValueError'], 'if something happens', 'ValueError')
    assert my_test.args == ['raises', 'ValueError']
    assert my_test.description == 'if something happens'
    assert my_test.type_name == 'ValueError'



# Generated at 2022-06-11 21:17:18.311594
# Unit test for constructor of class ParseError
def test_ParseError():
    p_error = ParseError("Mismatched indentation.")
    assert p_error is not None


# Generated at 2022-06-11 21:17:33.301502
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["arg"], "description", "arg_name", None, False, None)
    assert docstring_param.args == ["arg"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name is None
    assert docstring_param.is_optional is False
    assert docstring_param.default is None


# Generated at 2022-06-11 21:17:34.740443
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["a", "b"], "c")


# Generated at 2022-06-11 21:17:38.527896
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["raises", "test", "k"], "test", "NameError")
    assert d.args == ["raises","test","k"]
    assert d.description == "test"
    assert d.type_name =="NameError"

# Generated at 2022-06-11 21:17:39.984028
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "parameter description")


# Generated at 2022-06-11 21:17:41.602595
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	assert DocstringDeprecated("args", "description", "version").args == "args"


# Generated at 2022-06-11 21:17:46.359734
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()
    assert x.short_description == None
    #assert x.long_description == None
    assert x.blank_after_short_description == False
    assert x.blank_after_long_description == False
    assert x.meta == []


# Generated at 2022-06-11 21:17:55.509786
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring.__init__.__annotations__ == {
        'return': None
    }
    # Testing invocation with no parameters
    assert Docstring()
    # Testing the default values
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert not Docstring().blank_after_short_description
    assert not Docstring().blank_after_long_description
    assert Docstring().meta == []
    assert Docstring().params == []
    assert Docstring().raises == []
    assert Docstring().returns is None
    assert Docstring().deprecation is None



# Generated at 2022-06-11 21:18:03.923012
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["a","b"], "methode Add(a,b) Add a and b", "Add", "int", True, "a+b")
    print("DocstringParam a a été crée")
    print("a.args:",a.args)
    print("a.description:",a.description)
    print("a.arg_name:",a.arg_name)
    print("a.type_name:",a.type_name)
    print("a.is_optional:",a.is_optional)
    print("a.default:",a.default)


# Generated at 2022-06-11 21:18:05.051929
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated([], "", "")
    return a


# Generated at 2022-06-11 21:18:17.553864
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_type = "int"
    return_description = "calculated score."
    return_name = "score"
    args = ["return", "returns"]
    is_generator = False
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).return_name == return_name
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).type_name == return_type
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).description == return_description
    assert DocstringReturns(args, return_description, return_type,
                            is_generator, return_name).is_generator == is_generator
# End unit test



# Generated at 2022-06-11 21:18:33.421223
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Sample ParseError")
    except ParseError as e:
        print("Exception: ", e)


# Generated at 2022-06-11 21:18:37.614666
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(['param', 'arg:', 'description'], None, 'arg:', None, None, None)
    assert x.args == ['param', 'arg:', 'description']
    assert x.description == None
    assert x.arg_name == 'arg:'
    assert x.type_name == None
    assert x.is_optional == None
    assert x.default == None



# Generated at 2022-06-11 21:18:39.343107
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert type(e) == ParseError


# Generated at 2022-06-11 21:18:43.829538
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test correct initialization of object DocstringDeprecated
    args = ['deprecated']
    description = 'this function is deprecated'
    version = '0.2.0'
    doc = DocstringDeprecated(args, description, version)
    assert doc.args == args
    assert doc.description == description
    assert doc.version == version

# Generated at 2022-06-11 21:18:47.278723
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(
        args=["parameter"],
        description="description",
        version="version",
    )
    assert isinstance(doc.args, list)
    assert isinstance(doc.description, str)
    assert isinstance(doc.version, str)


# Generated at 2022-06-11 21:18:53.515813
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test function for DocstringDeprecated."""
    docstring_deprecated = DocstringDeprecated(["param"], "description", "version")
    assert docstring_deprecated
    assert docstring_deprecated.args == ["param"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-11 21:18:54.826094
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    pass


# Generated at 2022-06-11 21:18:55.735230
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        DocstringDeprecated([], None, None)
    except:
        assert False



# Generated at 2022-06-11 21:18:57.657060
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-11 21:19:02.154784
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert len(docstring.meta) == 0
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.deprecation == None
    assert docstring.returns == None

# Generated at 2022-06-11 21:19:32.944662
# Unit test for constructor of class ParseError
def test_ParseError():
    # check if works without message
    assert ParseError()

    # check if works with message
    assert ParseError("test message")


# Generated at 2022-06-11 21:19:40.586702
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(["param"], "description", "arg_name", "type_name", "is_optional", "default")
    assert(d.args == ["param"])
    assert(d.description == "description")
    assert(d.arg_name == "arg_name")
    assert(d.type_name == "type_name")
    assert(d.is_optional == "is_optional")
    assert(d.default == "default")


# Generated at 2022-06-11 21:19:45.006108
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["Exception", "ValueError"], "description", "type_name")
    assert a.args == ["Exception", "ValueError"]
    assert a.description == "description"
    assert a.type_name == "type_name"


# Generated at 2022-06-11 21:19:54.194765
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = None
    default = None
    # test Meta
    doc = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert doc.args == args
    assert doc.description == description
    # test Param
    assert doc.arg_name == arg_name
    assert doc.type_name == type_name
    assert doc.is_optional == is_optional
    assert doc.default == default


# Generated at 2022-06-11 21:20:00.500403
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # create a DocstringRaises class object
    docstring_raises_class = DocstringRaises(['raises'], 'error', 'ValueError')
    # Assert description is 'error'
    assert docstring_raises_class.description == 'error'
    # Assert type_name is 'ValueError'
    assert docstring_raises_class.type_name == 'ValueError'



# Generated at 2022-06-11 21:20:04.601053
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises(['raises', 'raise', 'except'], 'if something went wrong', 'ValueError')
    assert raises.args == ['raises', 'raise', 'except']
    assert raises.type_name == 'ValueError'
    assert raises.description == 'if something went wrong'


# Generated at 2022-06-11 21:20:11.318732
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-11 21:20:14.674379
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["test"], None, "var", "string", True, None)
    assert isinstance(docstring_param, DocstringParam)
    assert isinstance(docstring_param, DocstringMeta)


# Generated at 2022-06-11 21:20:18.113902
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-11 21:20:20.393408
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    print(docstring.short_description)
    print(docstring.long_description)
    print(docstring.meta)
    print(docstring.params)
    print(docstring.raises)
    print(docstring.returns)
    print(docstring.deprecation)

# Generated at 2022-06-11 21:21:20.208046
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg1", "arg2"]
    description = "description"
    a = DocstringMeta(args, description)
    assert a.args == args
    assert a.description == description


# Generated at 2022-06-11 21:21:23.823597
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-11 21:21:32.245238
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # print("The function is DocstringRaises")
    docstring = DocstringRaises(["I","am","an","idiot"], "I am a value", "you fucker")
    assert docstring.args == ["I","am","an","idiot"]
    assert docstring.description == "I am a value"
    assert docstring.type_name == "you fucker"


# Generated at 2022-06-11 21:21:33.566176
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "Hello")

# Generated at 2022-06-11 21:21:36.016177
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(1,[2,3],"arg_name", "type_name", "is_optional", "default").arg_name == "arg_name"


# Generated at 2022-06-11 21:21:40.546681
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-11 21:21:51.360166
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a_1 = ['a', 'b']
    d_1 = 'работает'
    t_1 = 'переменная'
    g_1 = True
    r_1 = 'None'
    ds_1 = DocstringReturns(a_1, d_1, t_1, g_1, r_1)
    assert ds_1.args == ['a', 'b']
    assert ds_1.description == 'работает'
    assert ds_1.is_generator == True
    assert ds_1.return_name == 'None'
    assert ds_1.type_name == 'переменная'
    
    
    
    

# Generated at 2022-06-11 21:21:52.684229
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["args"], "description", "type_name")

# Generated at 2022-06-11 21:21:58.457390
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test DocstringRaises."""
    arr = ['a', 'b', 'c']
    obj = DocstringRaises(arr, 'decr', 'type')
    assert(obj.args == arr)
    assert(obj.description == 'decr')
    assert(obj.type_name == 'type')

# Generated at 2022-06-11 21:22:01.649399
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(['test'], 'test')
    assert obj.args == ['test']
    assert obj.description == 'test'


# Generated at 2022-06-11 21:24:00.976131
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["1", "2", "3"]
    description = "a"
    arg_name = "b"
    type_name = "c"
    is_optional = False
    default = "d"
    DocstringParam(args, description, arg_name, type_name, is_optional, default)
    return 0


# Generated at 2022-06-11 21:24:09.734101
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_param = DocstringParam(["param", "parameter"], "description", "arg_name", "type_name", False, "default")
    assert test_param.args == ["param", "parameter"]
    assert test_param.description == "description"
    assert test_param.arg_name == "arg_name"
    assert test_param.type_name == "type_name"
    assert test_param.is_optional == False
    assert test_param.default == "default"


# Generated at 2022-06-11 21:24:12.542559
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass


# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-11 21:24:16.435828
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["args"], "description", "type_name")
    assert a.args == ["args"]
    assert a.description == "description"
    assert a.type_name == "type_name"


# Generated at 2022-06-11 21:24:18.345946
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    x = DocstringDeprecated('123', '456')
    assert x.args == '123'
    assert x.description == '456'

# Generated at 2022-06-11 21:24:20.243741
# Unit test for constructor of class ParseError
def test_ParseError():
    '''Unit test for constructor of class ParseError'''
    ParseError(Exception,Exception)

# Generated at 2022-06-11 21:24:27.265670
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("Docstring is invalid")
    assert(repr(e) == "Docstring is invalid")
    e = ParseError("Docstring is invalid","https://github.com/python-attrs/attrs/issues/719")
    assert(repr(e) == "Docstring is invalid")



# Generated at 2022-06-11 21:24:36.851219
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns"""
    return_list = ['return']
    expected_calls = ['DocstringMeta.__init__']
    args = [return_list,'description','type_name',True]
    expected_return_values = {
        'DocstringMeta.__init__': None,
    }
    with patch.multiple('source.docstring_parse.DocstringReturns',
                        __init__=DEFAULT,
                        ) as mocks:
        mocks['__init__'].return_value = None
        obj = source.docstring_parse.DocstringReturns(return_list,'description','type_name',True)
    for call in expected_calls:
        assert call in mocks
        mocks[call].assert_called_once_with(*args)

# Generated at 2022-06-11 21:24:37.985519
# Unit test for constructor of class Docstring
def test_Docstring():
    pass


# Generated at 2022-06-11 21:24:41.201422
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test parse error setting."""
    pe = ParseError("test")
    assert isinstance(pe, ParseError)
    assert pe.args[0] == "test"

