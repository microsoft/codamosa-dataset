

# Generated at 2022-06-25 16:12:39.413684
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns([], "Output type: integer", "int", False)


# Generated at 2022-06-25 16:12:50.000282
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(['arg'], 'description', 'type_name', True, 'return_name')
    assert docstring_returns_0.args == ['arg']
    assert docstring_returns_0.description == 'description'
    assert docstring_returns_0.type_name == 'type_name'
    assert docstring_returns_0.is_generator == True
    assert docstring_returns_0.return_name == 'return_name'
    docstring_returns_1 = DocstringReturns(['args'], 'description', 'type_name', False, 'return_name')
    assert docstring_returns_1.args == ['args']
    assert docstring_returns_1.description == 'description'
    assert docstring_returns_1.type_

# Generated at 2022-06-25 16:12:53.229435
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_0 = []
    description_0 = None
    type_name_0 = None
    docstring_raises_0 = DocstringRaises(args_0, description_0, type_name_0)


# Generated at 2022-06-25 16:12:56.351571
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated_0 = DocstringDeprecated([], str(), str())


# Generated at 2022-06-25 16:13:02.069309
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "description"]
    description = "description"
    type_name = "type"
    is_generator = False
    return_name = "return_name"

    DocstringReturns(args, description, type_name, is_generator, return_name)

# Generated at 2022-06-25 16:13:10.839617
# Unit test for constructor of class ParseError
def test_ParseError():
    docstring_0 = Docstring()
    docstring_0.short_description = 'test'
    docstring_0.long_description = 'test'
    docstring_0.blank_after_short_description = True
    docstring_0.blank_after_long_description = True
    docstring_0.meta.append(DocstringParam)
    docstring_0.meta.append(DocstringRaises)
    docstring_0.meta.append(DocstringReturns)
    docstring_0.meta.append(DocstringDeprecated)
    assert docstring_0.meta[0]
    assert docstring_0.meta[1]
    assert docstring_0.meta[2]
    assert docstring_0.meta[3]

    docstring_1 = Docstring()
    docstring_1.short_description

# Generated at 2022-06-25 16:13:14.819888
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam([], "")
    docstring_param_1 = DocstringParam(["param"], "")
    docstring_param_2 = DocstringParam(["param"], "")
    docstring_param_3 = DocstringParam(["param"], "description")


# Generated at 2022-06-25 16:13:15.585480
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:13:17.063181
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_Deprecated = DocstringDeprecated(['param'], 'description', 'version')


# Generated at 2022-06-25 16:13:18.478744
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_0 = DocstringRaises(["raises"], "test", "ValueError")


# Generated at 2022-06-25 16:13:28.430450
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_1 = DocstringReturns(args=["test","test"], description="test", type_name="test", is_generator=False)


# Generated at 2022-06-25 16:13:33.197749
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-25 16:13:34.366773
# Unit test for constructor of class Docstring
def test_Docstring():
    assert isinstance(Docstring(), Docstring)


# Generated at 2022-06-25 16:13:42.569573
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        docstring_deprecated_0 = DocstringDeprecated(['deprecated:', '1.0'], '', '1.0')
    except TypeError as e:
        print("Argument type error: " + str(e))
    except ValueError as e:
        print("Value error: " + str(e))
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise
    else:
        print("Constructor of DocstringDeprecated executed successfully")


# Generated at 2022-06-25 16:13:46.808807
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta
    args=['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description='This function does something'
    docstring_0.args=args
    docstring_0.description=description


# Generated at 2022-06-25 16:13:59.897839
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test case without is optional, default, type_name
    dp = DocstringParam(['param'], 'desc', 'arg', None, None, None)
    assert dp.arg_name == 'arg'
    assert dp.type_name == None
    assert dp.is_optional == None
    assert dp.default == None
    assert dp.description == 'desc'

    # Test case with is optional, default, type_name
    dp = DocstringParam(['param'], 'desc', 'arg', 'int', True, 'None')
    assert dp.arg_name == 'arg'
    assert dp.type_name == 'int'
    assert dp.is_optional == True
    assert dp.default == 'None'
    assert dp.description == 'desc'



# Generated at 2022-06-25 16:14:04.670335
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:14:08.299114
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstr_param = DocstringParam(args=[''],description='',arg_name='',type_name='',is_optional=True,default='')


# Generated at 2022-06-25 16:14:12.231925
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d0 = DocstringRaises(['args0'], "description0", "name0")
    assert d0.description == "description0"
    assert d0.type_name == "name0"
    assert d0.args == ['args0']



# Generated at 2022-06-25 16:14:24.258813
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_4 = Docstring()
    assert(docstring_4.short_description == None)
    assert(docstring_4.long_description == None)
    assert(docstring_4.blank_after_short_description == False)
    assert(docstring_4.blank_after_long_description == False)
    assert(docstring_4.meta == [])
    docstring_3 = Docstring()
    assert(docstring_3.short_description == None)
    assert(docstring_3.long_description == None)
    assert(docstring_3.blank_after_short_description == False)
    assert(docstring_3.blank_after_long_description == False)
    assert(docstring_3.meta == [])
test_case_0.__name__ = "test_case_0"

# Generated at 2022-06-25 16:14:38.855960
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = list()
    description = 'description'
    type_name = 'type_name'
    docstring_raises = DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:14:40.630633
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['raises'], 'exception', 'ValueError')
    assert docstring_raises.args == ['raises']
    assert docstring_raises.description == 'exception'
    assert docstring_raises.type_name == 'ValueError'


# Generated at 2022-06-25 16:14:44.858813
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [":param", "arg", "description"]
    description = "associated docstring description"
    test_0 = DocstringMeta(args, description)



# Generated at 2022-06-25 16:14:52.783173
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1 = DocstringReturns(
        ['returns'], 'a list of length 2', 'List[int]', False
    )
    docstring_2 = DocstringReturns(
        ['yields'], 'a list of length 2', 'List[int]', True
    )
    docstring_3 = DocstringReturns(
        ['returns'], 'a list of length 2', 'List[int]', False, 'x'
    )
    docstring_4 = DocstringReturns(
        ['yields'], 'a list of length 2', 'List[int]', True, 'x'
    )


# Generated at 2022-06-25 16:14:58.110574
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(
        ['param', 'arg'],
        'This is the docstring meta',
    )
    # print(docstring_meta_0.args)
    # print(docstring_meta_0.description)


# Generated at 2022-06-25 16:15:03.560806
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['args', ':', 'param', ':', 'arg_name', ':',
                                       'type_name', ':', 'is_optional', ':', 'default'],
                                       'description', 'arg_name', 'type_name', 'is_optional', 'default')


# Generated at 2022-06-25 16:15:05.062557
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(keywords=[], description="")

# Generated at 2022-06-25 16:15:07.027013
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-25 16:15:12.132900
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    assert(docstring_0.short_description == None)
    assert(docstring_0.long_description == None)
    assert(docstring_0.blank_after_short_description == False)
    assert(docstring_0.blank_after_long_description == False)
    assert(docstring_0.meta == [])


# Generated at 2022-06-25 16:15:13.017869
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert isinstance(DocstringRaises([], "", ""), DocstringRaises)

# Generated at 2022-06-25 16:15:42.214573
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()


# Generated at 2022-06-25 16:15:45.679792
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = "test description"
    type_name = "test type"
    raises = DocstringRaises(args, description, type_name)
    assert raises.args == []
    assert raises.description == "test description"
    assert raises.type_name == "test type"
    assert raises.__repr__() == "DocstringRaises(args=(), description=test description, type_name=test type)"


# Generated at 2022-06-25 16:15:54.349077
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    metameta = ["param", "arg", "argument", "attribute", "key", "keyword"]
    args = ["param"]
    arg_name = "name"
    docstring_param = DocstringParam(args, None, arg_name, None, True, None)
    assert docstring_param.args == metameta
    assert docstring_param.description == None
    assert docstring_param.arg_name == "name"
    assert docstring_param.type_name == None
    assert docstring_param.is_optional == True
    assert docstring_param.default == None

# Generated at 2022-06-25 16:15:56.650230
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta([], '')


# Generated at 2022-06-25 16:16:00.256153
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_0 = []
    description_0 = 'Test'
    type_name_0 = 'Test'
    docstringRaises_0 = DocstringRaises(args_0, description_0, type_name_0)



# Generated at 2022-06-25 16:16:01.433084
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Case 0:
    test_case_0()


test_DocstringMeta()

# Generated at 2022-06-25 16:16:02.334524
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_case_0()


# Generated at 2022-06-25 16:16:09.371025
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_dep = DocstringDeprecated(args=['_version'], description="The version in which the feature became deprecated.", version="3.9")
    assert docstring_dep.args == ["_version"]
    assert docstring_dep.description == "The version in which the feature became deprecated."
    assert docstring_dep.version == "3.9"


# Generated at 2022-06-25 16:16:11.293444
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    def test_case_0():
        docstringMeta_0 = DocstringMeta(["param"], "description")



# Generated at 2022-06-25 16:16:13.437593
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("This is an error")



# Generated at 2022-06-25 16:16:47.368779
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    # Constructor of class Docstring does not have any parameters
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


if __name__ == "__main__":
    test_case_0()
    test_Docstring()

# Generated at 2022-06-25 16:16:58.471547
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param", "name", "type"], "Docstring description")
    DocstringMeta(["raise", "Exception", "Type"], "Docstring description")
    DocstringMeta(["arg", "parameter"], "Docstring description")
    DocstringMeta(["argument", "key", "keyword"], "Docstring description")
    DocstringMeta(["exception"], "Docstring description")
    DocstringMeta(["raises", "except"], "Docstring description")
    DocstringMeta(["return", "returns"], "Docstring description")
    DocstringMeta(["yield", "yields"], "Docstring description")



# Generated at 2022-06-25 16:17:00.508496
# Unit test for constructor of class ParseError
def test_ParseError():
    # test if error message is displayed correctly
    ParseError(RuntimeError.args[0])


# Generated at 2022-06-25 16:17:11.552714
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_1 = ParseError()
    parse_error_1_args = ['.', '.']
    parse_error_1_args_0 = ['.', '.']
    parse_error_1_args_1 = ['.', '.']
    parse_error_1_args_0[0] = '.'
    parse_error_1_args_0[1] = '.'
    parse_error_1_args_1[0] = '.'
    parse_error_1_args_1[1] = '.'
    parse_error_1_args[0] = parse_error_1_args_0
    parse_error_1_args[1] = parse_error_1_args_1
    parse_error_1.args = parse_error_1_args


# Generated at 2022-06-25 16:17:13.910261
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['you', 'are'], 'hello', 'arg_name', 'type_name', 'is_optional', 'default')


# Generated at 2022-06-25 16:17:14.909838
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:17:20.875415
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError", "if", "something", "happens"]
    description = "if something happens"
    type_name = "ValueError"
    value = DocstringRaises(args, description, type_name)
    assert value.args == ["raises", "ValueError", "if", "something", "happens"]
    assert value.description == "if something happens"
    assert value.type_name == "ValueError"


# Generated at 2022-06-25 16:17:22.486876
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()
    print("Unit test for Docstring completed")


# Generated at 2022-06-25 16:17:24.204051
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["args"], "test", "arg", "test", True, "test")


# Generated at 2022-06-25 16:17:26.159235
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(['deprecated'], 'This function is deprecated.', '0.1.0')


# Generated at 2022-06-25 16:18:00.887193
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:18:08.032947
# Unit test for constructor of class DocstringReturns

# Generated at 2022-06-25 16:18:09.969887
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta([],[])


# Generated at 2022-06-25 16:18:14.323684
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated("args","description","version")
    assert docstring_deprecated.args == "args"
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-25 16:18:19.582105
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(
        args=["param", "parameter", "arg", "argument"],
        description="The number x",
        arg_name="x",
        type_name="int",
        is_optional=false,
        default="42"
    )


# Generated at 2022-06-25 16:18:21.515075
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['param'], 'No Data', 'Does not have any data')


# Generated at 2022-06-25 16:18:32.561874
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    if docstring_0.short_description is None:
        print("Short description is None. Passed")
    else:
        print("Short description is not None. Failed")
    if docstring_0.long_description is None:
        print("Long description is None. Passed")
    else:
        print("Long description is not None. Failed")
    if docstring_0.blank_after_short_description == False:
        print("Blank after short description is False. Passed")
    else:
        print("Blank after short description is not False. Failed")
    if docstring_0.blank_after_long_description == False:
        print("Blank after long description is False. Passed")
    else:
        print("Blank after long description is not False. Failed")

# Generated at 2022-06-25 16:18:34.012107
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err


# Generated at 2022-06-25 16:18:42.240334
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg_name_0 = DocstringParam(['param'], 'description', 'arg_name', None, None, None)
    assert arg_name_0.arg_name == 'arg_name'
    type_name_0 = DocstringParam(['param'], 'description', 'arg_name', 'type_name', None, None)
    assert type_name_0.type_name == 'type_name'
    is_optional_0 = DocstringParam(
        ['param'], 'description', 'arg_name', 'type_name', True, None
    )
    assert is_optional_0.is_optional == True
    default_0 = DocstringParam(
        ['param'], 'description', 'arg_name', 'type_name', True, 'default'
    )
    assert default_0.default == 'default'


# Generated at 2022-06-25 16:18:43.594102
# Unit test for constructor of class ParseError
def test_ParseError():
    ex = ParseError(' ')


# Generated at 2022-06-25 16:19:58.570108
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "Some descriptions", "1.0")
    assert 'Some descriptions' == docstring.description
    assert '1.0' == docstring.version


# Generated at 2022-06-25 16:20:00.458076
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['param'], 'description', 'type_name')


# Generated at 2022-06-25 16:20:01.507320
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_0 = DocstringRaises([], "", "")


# Generated at 2022-06-25 16:20:02.951190
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        assert True


# Generated at 2022-06-25 16:20:04.083338
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        ParseError()


# Generated at 2022-06-25 16:20:05.471667
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated([""], "", "")


# Generated at 2022-06-25 16:20:06.442718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "", "", "", True, "")


# Generated at 2022-06-25 16:20:11.125974
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(
            None,
            None,
            '1.0',
        )
    assert docstring_deprecated_0.description == None
    assert docstring_deprecated_0.args == None
    assert docstring_deprecated_0.version == '1.0'


# Generated at 2022-06-25 16:20:13.012494
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(args=[], description="")



# Generated at 2022-06-25 16:20:14.268856
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()