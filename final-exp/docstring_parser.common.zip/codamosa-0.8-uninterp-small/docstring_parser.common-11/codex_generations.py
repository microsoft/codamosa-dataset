

# Generated at 2022-06-25 16:12:44.208995
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        assert True
    return


# Generated at 2022-06-25 16:12:46.910125
# Unit test for constructor of class ParseError
def test_ParseError():
    _ParseError = ParseError('test')
    if _ParseError.args != ('test',):
        raise AssertionError()


# Generated at 2022-06-25 16:12:53.319890
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError
    assert type(pe) == type
    assert str(pe) == "<class 'py2md.parse.ParseError'>"


# Generated at 2022-06-25 16:13:03.792213
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """
    Unit test for constructor of class DocstringMeta
    """
    docstring_0 = Docstring()

    # Test for assignment to attribute description
    # Failure message:
    # Attribute description does not exist.
    assert hasattr(docstring_0, "description"), "Attribute %s does not exist." % "description"

    # Test for assignment to attribute args
    # Failure message:
    # Attribute args does not exist.
    assert hasattr(docstring_0, "args"), "Attribute %s does not exist." % "args"

    # Test for return type
    # Failure message:
    # Return value assignment is not type string.
    assert(isinstance(docstring_0.description, str)), "Return value assignment is not type %s." % str

# Generated at 2022-06-25 16:13:05.624071
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-25 16:13:06.549877
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:13:07.478804
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:13:09.313481
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None


# Generated at 2022-06-25 16:13:12.000250
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp_0 = DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-25 16:13:15.225630
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['arg'], 'description')
    assert docstring_meta.args == ['arg']
    assert docstring_meta.description == 'description'


# Generated at 2022-06-25 16:13:20.074141
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:13:22.271073
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(
        ['arg', 'arg'], 'Description of a DocstringMeta')


# Generated at 2022-06-25 16:13:24.617189
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg_name", "type_name", "is_optional", "default")


# Generated at 2022-06-25 16:13:28.107252
# Unit test for constructor of class Docstring
def test_Docstring():
    print("Testing __init__ of class Docstring")
    test_case_0()
    print("Test passed")
    print()



# Generated at 2022-06-25 16:13:29.858485
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises([], "", "Test")


# Generated at 2022-06-25 16:13:33.974220
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(  ["param", "arg", "attribute", "key", "keyword"], "description", "str" )
    assert type(docstring_0) == DocstringDeprecated


# Generated at 2022-06-25 16:13:37.598181
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d1 = DocstringReturns(['return', 'returns'], None, 'type_name', False, 'return_name')
    assert d1 is not None


# Generated at 2022-06-25 16:13:45.669506
# Unit test for constructor of class Docstring
def test_Docstring():
	docstring_0 = Docstring()
	docstring_1 = Docstring()
	docstring_1.short_description = "This method adds two numbers.\n"
	docstring_2 = Docstring()
	docstring_2.long_description = "This is longer description.\n"
	docstring_3 = Docstring()
	docstring_3.meta = [DocstringParam(["param", "a", ":", "int"], "First number"), DocstringParam(["param", "b", ":", "int"], "Second number")]
	

# Generated at 2022-06-25 16:13:50.066884
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args="", description="", version="")
    assert docstring_deprecated.args == ""
    assert docstring_deprecated.description == ""
    assert docstring_deprecated.version == ""

# Generated at 2022-06-25 16:13:52.729098
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass


# Generated at 2022-06-25 16:14:00.745559
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-25 16:14:01.963639
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated([], None, None)


# Generated at 2022-06-25 16:14:06.661738
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        args=["return", "returns"],
        description="The return value.",
        type_name="list",
        is_generator=False,
        return_name=None,
    )


# Generated at 2022-06-25 16:14:09.826780
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(["param", "args"], "description", "arg", None, None, None)


# Generated at 2022-06-25 16:14:13.767005
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_obj = DocstringMeta(
        ['1', '2', '3'],
        "It's a docstring description",
    )
    assert (docstring_meta_obj.args == ['1', '2', '3'])
    assert (docstring_meta_obj.description == "It's a docstring description")


# Generated at 2022-06-25 16:14:17.662877
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args=[], description=None, version=None)


# Generated at 2022-06-25 16:14:18.687439
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()



# Generated at 2022-06-25 16:14:19.312728
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError()


# Generated at 2022-06-25 16:14:25.164880
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=[], description=None, arg_name=None, type_name=None, is_optional=None, default=None
    )
    assert docstring_param.args == []
    assert docstring_param.description == None
    assert docstring_param.arg_name == None
    assert docstring_param.type_name == None
    assert docstring_param.is_optional == None
    assert docstring_param.default == None
    return 0


# Generated at 2022-06-25 16:14:30.734738
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_0 = DocstringParam(["param", "arg"], "description", "arg_name",
                            "type_name", "is_optional", "default")


# Generated at 2022-06-25 16:14:46.067954
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("a")



# Generated at 2022-06-25 16:14:47.115834
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-25 16:14:48.442366
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0 is not None


# Generated at 2022-06-25 16:14:50.054678
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("Error")
    assert e.args[0] == "Error"


# Generated at 2022-06-25 16:14:52.329713
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_1 = DocstringDeprecated(["deprecated"], None, None)
    assert docstring_1.args == ["deprecated"]

# Generated at 2022-06-25 16:14:58.110411
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['meta'], 'description', 'version')
    assert(docstring_deprecated.args == ['meta'])
    assert(docstring_deprecated.description == 'description')
    assert(docstring_deprecated.version == 'version')


# Generated at 2022-06-25 16:15:02.625354
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["deprecated"], "", None)
    s = str(a)
    s_expected = "DocstringDeprecated(args=['deprecated'], description='', version=None)"
    assert s==s_expected


# Generated at 2022-06-25 16:15:06.084636
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(
        args=[], description=None, type_name=None, is_generator=False, return_name=None,
    )


# Generated at 2022-06-25 16:15:11.286939
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = 'this is a test'
    description = 'this is a description'
    version = 'v1'
    test_case = DocstringDeprecated(args, description, version)
    assert test_case.args == args
    assert test_case.description == description
    assert test_case.version == version


# Generated at 2022-06-25 16:15:15.994869
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.meta == []
    assert docstring_0.long_description == None
    assert docstring_0.short_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False


# Generated at 2022-06-25 16:15:50.072329
# Unit test for constructor of class Docstring
def test_Docstring():
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:15:51.998352
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(['arg'], 'desc', 'ver')


# Generated at 2022-06-25 16:15:53.429853
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert issubclass(DocstringMeta, DocstringMeta)

# Generated at 2022-06-25 16:16:02.323583
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'test function', None)
    assert isinstance(docstring_deprecated, DocstringMeta)
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'test function'
    assert docstring_deprecated.version == None


# Generated at 2022-06-25 16:16:04.996555
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(["tag"], None, None)



# Generated at 2022-06-25 16:16:08.290307
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_1 = DocstringDeprecated(args=['test'], description= 'test description', version = 'test version')


# Generated at 2022-06-25 16:16:16.040619
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    instance_0 = DocstringDeprecated(['deprecated'], 'Test description.', 'Version 1.0.0')
    assert instance_0.args == ['deprecated']
    assert instance_0.description == 'Test description.'
    assert instance_0.version == 'Version 1.0.0'


# Generated at 2022-06-25 16:16:20.005338
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test with Example 1 of 3 - Params
    # DocstringMeta should have 2 attributes:
    # args, description
    # Test with Example 1 of 3 - Params
    # Initialize args as an empty list.
    args = []
    # Initialize description as "description"
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    # The length of args should be 0
    assert len(docstring_meta.args) == 0
    # The value of description should be a string "description"
    assert docstring_meta.description == "description"


# Generated at 2022-06-25 16:16:25.386892
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring != None
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []


# Generated at 2022-06-25 16:16:26.612333
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError()
    assert (p.args is None)

# Generated at 2022-06-25 16:17:28.682368
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam("args", "description", "arg_name",
                                 "type_name", True, "default")


# Generated at 2022-06-25 16:17:37.487480
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()  # Expected to pass silently
    assert docstring_0.short_description == None 
    assert docstring_0.long_description == None 
    assert docstring_0.blank_after_short_description == False 
    assert docstring_0.blank_after_long_description == False 
    assert docstring_0.meta == [] 


# Generated at 2022-06-25 16:17:39.525297
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises(['a','b','c','d','e','f'], 'Description', 'Type')


# Generated at 2022-06-25 16:17:40.380204
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()


# Generated at 2022-06-25 16:17:43.327238
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_1 = DocstringParam(args=['param', 'attr'], description=None, arg_name='attr', type_name=None, is_optional=None, default=None)


# Generated at 2022-06-25 16:17:54.774988
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for class DocstringParam.

    Function parameters:
        args - a list of arguments
        description - a short summary of what the parameter does
        arg_name -
        type_name -
        is_optional -
        default -

    Raises:
        TypeError - if argument passed to constructor is not a
                    correct type.
    """
    docstring = DocstringParam(
        args=['param', 'argument', 'attribute'],
        description='description',
        arg_name='arg_name',
        type_name='type_name',
        is_optional=True,
        default='default',
    )
    assert docstring.args == ['param', 'argument', 'attribute'], "Failed test_DocstringParam"
    assert docstring.description == 'description', "Failed test_DocstringParam"

# Generated at 2022-06-25 16:18:00.063709
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == ["raises"]
    assert docstring_raises.description == "if something happens"
    assert docstring_raises.type_name == "ValueError"


# Generated at 2022-06-25 16:18:02.078222
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Test error')
    except ParseError as e:
        assert str(e) == 'Test error'


# Generated at 2022-06-25 16:18:08.205865
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    # test for attributes
    assert not docstring_0.short_description
    assert not docstring_0.long_description
    assert not docstring_0.blank_after_short_description
    assert not docstring_0.blank_after_long_description
    assert not docstring_0.params
    assert not docstring_0.raises

# Generated at 2022-06-25 16:18:12.603436
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(["arg"], "description")
    assert len(docstring_meta_0.args) == 1
    assert docstring_meta_0.args[0] == "arg"
    assert docstring_meta_0.description == "description"


# Generated at 2022-06-25 16:20:35.304609
# Unit test for constructor of class Docstring
def test_Docstring():
    assert test_case_0() == None


# Generated at 2022-06-25 16:20:36.438244
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "", "arg", None, None, None)


# Generated at 2022-06-25 16:20:37.195282
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["raises"], "if something happens", None)



# Generated at 2022-06-25 16:20:39.574323
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    return True


# Generated at 2022-06-25 16:20:42.072760
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(["return", "returns"], "Returns a user", "string", False)
    assert test_DocstringReturns.__name__ == "test_DocstringReturns"



# Generated at 2022-06-25 16:20:43.538651
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(['return'], 'Tuple', None, False)


# Generated at 2022-06-25 16:20:46.299338
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['param', 'arg', 'arg1'], 'description', 'arg_name', 'type_name', True, 'default')



# Generated at 2022-06-25 16:20:48.869532
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "desc", "arg_name", "Type", True, "default")


# Generated at 2022-06-25 16:20:51.155734
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(['raises/raise/except/exception', 'ValueError'], 'if something happens')



# Generated at 2022-06-25 16:20:55.243148
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Create instance of DocstringMeta class
    docstringMeta_0 = DocstringMeta(["args"], "description")
    # Assert instance variables
    assert docstringMeta_0.args == ["args"]
    assert docstringMeta_0.description == "description"
