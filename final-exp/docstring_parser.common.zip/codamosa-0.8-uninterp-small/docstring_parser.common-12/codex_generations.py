

# Generated at 2022-06-25 16:12:41.284749
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    _ = DocstringRaises(["a", "b"], "c", "d")

# Generated at 2022-06-25 16:12:48.745518
# Unit test for constructor of class ParseError
def test_ParseError():
    assert CALLABLE(ParseError)
    assert ISINSTANCE(ParseError(), ParseError)
    assert len(ParseError.__init__.__defaults__) == 0
    assert ParseError.__doc__ == 'Base class for all parsing related errors.\n'
    assert ParseError.__name__ == 'ParseError'
    assert ParseError.__qualname__ == 'ParseError'
    assert ParseError.__module__ == 'sphinxcontrib.napoleon.docstring'


# Generated at 2022-06-25 16:12:51.428650
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()
    try:
        raise ParseError()
    except ParseError:
        pass


# Generated at 2022-06-25 16:12:54.427439
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert len(DocstringMeta(['param'], 'help').args) == len(['param'])
    assert DocstringMeta(['param'], 'help').args == ['param']
    assert DocstringMeta(['param'], 'help').description == 'help'


# Generated at 2022-06-25 16:12:58.036314
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["return:", "returns:"], "", "", False)



# Generated at 2022-06-25 16:12:59.748807
# Unit test for constructor of class ParseError
def test_ParseError():
    print('Test constructor of class ParseError')
    test_case_0()


# Generated at 2022-06-25 16:13:09.089322
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    from re import compile
    from pydocstyle.violations import Error
    from pydocstyle.parser import DocstringReturns
    from pydocstyle.violations import Convention
    try:
        docstring_return = DocstringReturns(
            'returns', 'It returns a dictionary', 'dict', False
        )
    except TypeError:
        pass
    else:
        raise Exception("Could not instantiate a class DocstringReturns")
    docstring_return = DocstringReturns(
        ['returns'], 'It returns a dictionary', 'dict', False
    )
    if docstring_return.args != ['returns']:
        raise Exception("Could not instantiate a class DocstringReturns")
    if docstring_return.description != 'It returns a dictionary':
        raise Exception("Could not instantiate a class DocstringReturns")

# Generated at 2022-06-25 16:13:10.376266
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_case_0()

# Generated at 2022-06-25 16:13:12.000388
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(["param"], "description")


# Generated at 2022-06-25 16:13:13.427753
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:13:20.280423
# Unit test for constructor of class Docstring
def test_Docstring():
    try:
        docstring_0 = Docstring()
    except:
        assert False


# Generated at 2022-06-25 16:13:21.584558
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta_0 = DocstringMeta([], "")


# Generated at 2022-06-25 16:13:22.656441
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:13:24.516644
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(args=[], description="This ")


# Generated at 2022-06-25 16:13:31.805639
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_1 = Docstring()
    docstring_2 = Docstring()
    docstring_3 = Docstring()
    docstring_4 = Docstring()
    docstring_5 = Docstring()
    docstring_6 = Docstring()
    docstring_7 = Docstring()
    DocstringReturns(docstring_0.meta, docstring_1.short_description, docstring_2.type_name, docstring_3.is_generator, docstring_4.return_name)
    DocstringReturns(docstring_5.meta, docstring_6.short_description, docstring_7.type_name, docstring_3.is_generator, docstring_4.return_name)

# Generated at 2022-06-25 16:13:37.068569
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(
        args=['return'], 
        description='bla bla', 
        type_name='string', 
        is_generator=False, 
        return_name='ret'
    )


# Generated at 2022-06-25 16:13:39.582543
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Error Found')
    except ParseError as exc:
        print(exc)


# Generated at 2022-06-25 16:13:42.513728
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_example = DocstringParam(['param'], "description", "arg_name", "type_name", "is_optional", "default")
    assert param_example.description == "description"



# Generated at 2022-06-25 16:13:44.867204
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(
        args = [], 
        description = "add two numbers"
    )


# Generated at 2022-06-25 16:13:46.217387
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert True


# Generated at 2022-06-25 16:13:52.250446
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(0, 0, 0, 0, 0)


# Generated at 2022-06-25 16:13:56.176339
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', False, 'default')


# Generated at 2022-06-25 16:13:57.182894
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:14:01.959964
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dsr = DocstringReturns(["dummy"], "dummy", "dummy", "dummy")

# Generated at 2022-06-25 16:14:03.840597
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """We assume that DocstringMeta is working when used by other classes in __init__ methods"""
    return True


# Generated at 2022-06-25 16:14:07.159897
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta is not None, "DocstringMeta class not defined"
    args = None
    description = None
    docstringMeta = DocstringMeta(args, description)


# Generated at 2022-06-25 16:14:09.786303
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam = DocstringParam(['param', 'arg'],\
    'description', 'arg_name', 'type_name', True , 'default')


# Generated at 2022-06-25 16:14:20.384981
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0_args = {
        "abspath",
        "relpath",
        "suffix",
        "dirname",
        "basename",
        "abspath",
        "relpath",
        "suffix",
        "dirname",
        "basename",
    }
    docstring_0_description = "description"
    docstring_0_type_name = "type_name"
    # Test for constructor of class DocstringRaises
    docstring_0 = DocstringRaises(
        docstring_0_args,
        docstring_0_description,
        docstring_0_type_name
    )
    assert isinstance(docstring_0, DocstringRaises)


# Generated at 2022-06-25 16:14:22.311969
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(True)


# Generated at 2022-06-25 16:14:23.165601
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()


# Generated at 2022-06-25 16:14:32.346922
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('a', 'b', 'c')
    except ParseError as e:
        assert str(e) == 'b'

# Generated at 2022-06-25 16:14:34.107670
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test for constructor of class ParseError
    ParseError(1, 2)


# Generated at 2022-06-25 16:14:38.262561
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test: constructor of class DocstringRaises"""
    docstringRaises_0 = DocstringRaises(['arg', 'exception'], 'description', 'ValueError')


# test for readDocstring

# Generated at 2022-06-25 16:14:39.899963
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-25 16:14:43.619099
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('some_error')
    assert(e.args[0] == 'some_error')


# Generated at 2022-06-25 16:14:45.451590
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns([], None, None, False)


# Generated at 2022-06-25 16:14:45.940925
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:14:54.893196
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = Docstring()
    docstring.short_description = "Test function"
    docstring.long_description = "This function does nothing."
    docstring_0 = DocstringRaises(["raises TypeError", "if error"], "This function does nothing.",
                                  "error")
    # Test for the string returned by get_type_name()
    assert docstring_0.type_name == "error"
    # Test for the string returned by get_description()
    assert docstring_0.description == "This function does nothing."
    # Test for the list of strings returned by get_args()
    assert docstring_0.args == ["raises TypeError", "if error"]
    # Test for the presence of the short_description variable
    assert docstring.short_description == "Test function"
    # Test for the presence of the

# Generated at 2022-06-25 16:14:57.364221
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta("", "")


# Generated at 2022-06-25 16:15:02.730943
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'type'
    is_optional = True
    default = 'default'
    testCase_0 = DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-25 16:15:21.825462
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-25 16:15:31.204020
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(["arg1", "arg2"], "returns description", "string", True).args == ["arg1", "arg2"]
    assert DocstringReturns(["arg1", "arg2"], "returns description", "string", True).description == "returns description"
    assert DocstringReturns(["arg1", "arg2"], "returns description", "string", True).type_name == "string"
    assert DocstringReturns(["arg1", "arg2"], "returns description", "string", True).is_generator == True
    assert DocstringReturns(["arg1", "arg2"], "returns description", "string", True).return_name == None


# Generated at 2022-06-25 16:15:39.268178
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1 = DocstringReturns(
        ["return","returns"],
        "Will return a value",
        "int",
        False,
        "return_value",
    )
    assert isinstance(docstring_1, DocstringReturns)
    assert docstring_1.args == ["return","returns"]
    assert docstring_1.description == "Will return a value"
    assert docstring_1.type_name == "int"
    assert docstring_1.is_generator == False
    assert docstring_1.return_name == "return_value"


# Generated at 2022-06-25 16:15:44.112659
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["None"], "None")
    assert docstring_meta.__init__(["None"], "None") is None


# Generated at 2022-06-25 16:15:46.923271
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_Meta = DocstringMeta(["args"], "description")


# Generated at 2022-06-25 16:15:47.634856
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring()

# Generated at 2022-06-25 16:15:49.403760
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    print(type(err))
    print(err)


# Generated at 2022-06-25 16:15:50.867909
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(None, None, None, None, None, None)


# Generated at 2022-06-25 16:15:53.117105
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-25 16:15:55.217652
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([':param system:', 'Description:'], 'System to test.', 'system', 'str', True, None)



# Generated at 2022-06-25 16:16:30.856526
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_1 = DocstringMeta(
        ["param", "parameter", "arg", "argument"], "description 1"
    )
    assert docstring_meta_1.args == ["param", "parameter", "arg", "argument"]
    assert docstring_meta_1.description == "description 1"

    docstring_meta_2 = DocstringMeta(
        ["raises", "raise", "except", "exception"], "description 2"
    )
    assert docstring_meta_2.args == ["raises", "raise", "except", "exception"]
    assert docstring_meta_2.description == "description 2"

    docstring_meta_3 = DocstringMeta(
        ["return", "returns"], "description 3"
    )

# Generated at 2022-06-25 16:16:36.848573
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(["param"], "This is a test", "int", False)
    assert docstring_0.args == ["param"]
    assert docstring_0.description == "This is a test"
    assert docstring_0.type_name == "int"
    assert docstring_0.is_generator == False
    assert docstring_0.return_name == None


# Generated at 2022-06-25 16:16:42.662969
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta is None

# Generated at 2022-06-25 16:16:44.361054
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("The string is not correct.")
    assert isinstance(error, ParseError)



# Generated at 2022-06-25 16:16:48.969847
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(['return', 'returns'], 'test docstring', 'str')
    assert docstring_0.args == ['return', 'returns']
    assert docstring_0.description == 'test docstring'
    assert docstring_0.type_name == 'str'
    assert docstring_0.is_generator == False
    assert docstring_0.return_name == None


# Generated at 2022-06-25 16:16:50.620878
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()



# Generated at 2022-06-25 16:16:51.751479
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:16:53.984556
# Unit test for constructor of class ParseError
def test_ParseError():
    # The constructor is tested in test_case_0
    ParseError('test')


# Unit tests for class DocstringMeta

# Generated at 2022-06-25 16:16:54.761825
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-25 16:16:57.345461
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(None, None, None)


# Generated at 2022-06-25 16:18:01.944344
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=["param"],
        description="docstring param",
        arg_name="param",
        type_name="type",
        is_optional=False,
        default="default",
    )
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "docstring param"
    assert docstring_param.arg_name == "param"
    assert docstring_param.type_name == "type"
    assert docstring_param.is_optional == False
    assert docstring_param.default == "default"


# Generated at 2022-06-25 16:18:06.328145
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print('Unit test for constructor of class DocstringMeta')
    test_case_0()
    print('Test pass')

if __name__ == '__main__':
    test_DocstringMeta()

# Generated at 2022-06-25 16:18:08.007623
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0: DocstringMeta = DocstringDeprecated(
            [], "", "")



# Generated at 2022-06-25 16:18:11.275302
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args1 = []
    description1 = ""
    dm1 = DocstringMeta(args1, description1)
    assert (dm1.args == [])
    assert (dm1.description == "")


# Generated at 2022-06-25 16:18:16.496100
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_1 = DocstringParam(["arg"], "description", "arg_name", "type_name", True, "default")
    docstring_2 = DocstringParam(["arg", "parameter"], "description", "arg_name", "type_name", True, "default")


# Generated at 2022-06-25 16:18:25.320429
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(['param'], 'description', 'arg_name',
                                     'type_name', True, 'default')
    assert isinstance(docstring_param, DocstringMeta)
    assert docstring_param.args == ['param']
    assert docstring_param.description == 'description'
    assert docstring_param.arg_name == 'arg_name'
    assert docstring_param.type_name == 'type_name'
    assert docstring_param.is_optional == True
    assert docstring_param.default == 'default'


# Generated at 2022-06-25 16:18:26.792885
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "This is deprecated", "0.0.1")


# Generated at 2022-06-25 16:18:35.602341
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert(DocstringParam([], "", "", None, False, None).args == [])
    assert(DocstringParam([], "", "", None, False, None).description == "")
    assert(DocstringParam([], "", "", None, False, None).arg_name == "")
    assert(DocstringParam([], "", "", None, False, None).type_name is None)
    assert(DocstringParam([], "", "", None, False, None).is_optional is False)
    assert(DocstringParam([], "", "", None, False, None).default is None)


# Generated at 2022-06-25 16:18:38.317446
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Parameter is not valid")
    except ParseError:
        print("ok")


# Generated at 2022-06-25 16:18:42.919474
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_metadata = DocstringDeprecated(['param', 'arg', 'argument', 'attribute', 'key', 'keyword'], 'description', 'version')
    assert docstring_metadata.args == ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    assert docstring_metadata.description == 'description'
    assert docstring_metadata.version == 'version'
    assert isinstance(docstring_metadata.args, list)
    assert isinstance(docstring_metadata.description, str)
    assert isinstance(docstring_metadata.version, str)


# Generated at 2022-06-25 16:21:09.741040
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError('test')


# Generated at 2022-06-25 16:21:14.218352
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(args=[
        "param", "arg", "description"], description="description", arg_name="arg", type_name=None, is_optional=None, default=None)
    assert docstring_param_0.args == ['param', 'arg', 'description']
    assert docstring_param_0.description == 'description'
    assert docstring_param_0.arg_name == 'arg'
    assert docstring_param_0.type_name is None
    assert docstring_param_0.is_optional is None
    assert docstring_param_0.default is None


# Generated at 2022-06-25 16:21:16.711494
# Unit test for constructor of class Docstring
def test_Docstring():
        docstring_0 = Docstring()
        return isinstance(docstring_0,Docstring)


# Generated at 2022-06-25 16:21:20.928168
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(["arg"], "description", "type_name")
    assert docstring.args == ["arg"]
    assert docstring.description == "description"
    assert docstring.type_name == "type_name"



# Generated at 2022-06-25 16:21:23.936905
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()


# Generated at 2022-06-25 16:21:25.928803
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['param','arg'], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-25 16:21:29.328815
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 's', 'description', 'test']
    description = "description"
    # test for constructor (1)
    test = DocstringMeta(args, description)
    assert test.args == args
    assert test.description == description


# Generated at 2022-06-25 16:21:32.788218
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()


# Generated at 2022-06-25 16:21:38.334179
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []
    print("Constructor for Docstring works as expected.")


# Generated at 2022-06-25 16:21:41.724970
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_str = DocstringMeta([], "This is a demo sentence")
    assert doc_str.args == []
    assert doc_str.description == "This is a demo sentence"
    print("DocstringMeta class constructor test pass")
