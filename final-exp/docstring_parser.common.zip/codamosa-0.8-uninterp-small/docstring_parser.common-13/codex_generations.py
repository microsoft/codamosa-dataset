

# Generated at 2022-06-25 16:12:49.096380
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(args, description, type_name, is_generator)
    assert docstring_returns_0.description == description, 'description is wrong'
    assert docstring_returns_0.is_generator == is_generator, 'is_generator is wrong'
    assert docstring_returns_0.type_name == type_name, 'type_name is wrong'
    assert docstring_returns_0.args == args, 'args is wrong'
    assert docstring_returns_0.return_name == return_name, 'return_name is wrong'


# Generated at 2022-06-25 16:12:53.191029
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []


# Generated at 2022-06-25 16:13:03.528048
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_0.short_description = "Test short description"
    docstring_0.long_description = "Test long description"
    docstring_0.blank_after_short_description = True
    docstring_0.blank_after_long_description = True

    docstring_meta = DocstringReturns(
        args=["returns"], description="return description",
        type_name="int", is_generator=False)
    docstring_0.meta.append(docstring_meta)

    assert docstring_0.short_description == "Test short description"
    assert docstring_0.long_description == "Test long description"
    assert docstring_0.blank_after_short_description is True
    assert docstring_0.blank_after_long_description is True

# Generated at 2022-06-25 16:13:04.294264
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:13:05.265040
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:13:06.185934
# Unit test for constructor of class Docstring
def test_Docstring():
    assert (test_case_0() is None)

# Generated at 2022-06-25 16:13:08.819796
# Unit test for constructor of class ParseError
def test_ParseError():
    instance = ParseError("Test")
    assert isinstance(instance, Exception) == True
    #instance = ParseError()
    #assert isinstance(instance, Exception) == True


# Generated at 2022-06-25 16:13:17.298181
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    arg_name = 'arg'
    type_name = 'type'
    default = '2'
    is_optional = True
    description = 'description'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert(docstring_param.args == ['param'])
    assert(docstring_param.arg_name == 'arg')
    assert(docstring_param.type_name == 'type')
    assert(docstring_param.default == '2')
    assert(docstring_param.is_optional == True)
    assert(docstring_param.description == 'description')
    return


# Generated at 2022-06-25 16:13:20.733215
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_obj = DocstringReturns(["return", "returns"], " Return description", "type_name", False)


# Generated at 2022-06-25 16:13:22.539959
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    docstring_param = docstring_0.params


# Generated at 2022-06-25 16:13:28.784395
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('parse exception')
    except ParseError as e:
        assert str(e) == 'parse exception'
        assert isinstance(e, RuntimeError)



# Generated at 2022-06-25 16:13:37.598033
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(["param"], "description of parameter")
    doc = DocstringParam(["param", "attribute"], "description of parameter", "arg", "str", True, None)
    doc = DocstringReturns(["return", "returns"], "description of return", "str", False, "ret")
    doc = DocstringRaises(["raises", "raise", "except", "exception"], "description of raise", "str")
    doc = DocstringDeprecated(["deprecated"], "description of deprecation", "version")


# Generated at 2022-06-25 16:13:39.683378
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    new_DocstringRaises = DocstringRaises(args=[], description="", type_name=None)


# Generated at 2022-06-25 16:13:48.083115
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        ["param", "arg"], "description", "arg name", "type name", True, "default"
    )
    assert docstring_param.args == ["param", "arg"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg name"
    assert docstring_param.type_name == "type name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"
    

if __name__ == "__main__":
    #test_case_0()
    test_DocstringParam()

# Generated at 2022-06-25 16:13:52.351465
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep = DocstringDeprecated([], None, None)
    assert hasattr(dep, 'args')
    assert hasattr(dep, 'description')
    assert hasattr(dep, 'version')


# Generated at 2022-06-25 16:13:54.025249
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:13:55.037563
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:14:00.230921
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Initialize docstring
    docstring = Docstring()
    # Add parameters
    docstring.meta.append(DocstringReturns(
        ['return', 'returns'], "Dummy description", "int", False))
    # Add parameters
    docstring.meta.append(DocstringReturns(
        ['return', 'returns'], "Dummy description 2", "int 2", False))
    # Test return condition
    test_case_0()


# Generated at 2022-06-25 16:14:02.325551
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:14:04.183350
# Unit test for constructor of class ParseError
def test_ParseError():
    instance = ParseError()
# Test for setter of property 'args' of class DocstringMeta

# Generated at 2022-06-25 16:14:14.903981
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d1 = DocstringDeprecated(['deprecated', 'since','3.9.3'],'test', '3.9.3')
    assert d1.type_name == None
    assert d1.args == ['deprecated', 'since','3.9.3']
    assert d1.description == 'test'
    assert d1.version == '3.9.3'
    d2 = DocstringDeprecated(['deprecated', 'since'],'test', '3.9.3')
    assert d2.type_name == None
    assert d2.args == ['deprecated', 'since']
    assert d2.description == 'test'
    assert d2.version == '3.9.3'
    d3 = DocstringDeprecated([ 'since','3.9.3'],'test', '3.9.3')


# Generated at 2022-06-25 16:14:21.963853
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    line = ":param arg: description"
    d = line.split(":", 1)
    args = d[0].split()
    description = d[1].strip() if len(d) == 2 else ""
    my_DocstringReturns = DocstringReturns(args, description, None, None)


# Generated at 2022-06-25 16:14:29.784883
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = None
    arg_name = "arg_name"
    type_name = None
    is_optional = False
    default = None
    param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert param.arg_name == arg_name
    assert param.type_name == type_name
    assert param.is_optional == is_optional
    assert param.default == default


# Generated at 2022-06-25 16:14:35.087271
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param"]
    description = "text"
    version = "1.0"
    x = DocstringDeprecated(args, description, version)


# Generated at 2022-06-25 16:14:40.387968
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    meta = DocstringParam(['-arg1', 'arg2', '-arg3'], None, arg_name='arg2', type_name=None, is_optional=False, default=None)
    assert meta.arg_name == 'arg2'
    assert meta.type_name == None
    assert meta.is_optional == False
    assert meta.default == None


# Generated at 2022-06-25 16:14:45.401340
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([], "description", "type_name")
    DocstringRaises([], None, None)
    DocstringRaises([], None, "type_name")
    DocstringRaises([], "description", None)


# Generated at 2022-06-25 16:14:47.905556
# Unit test for constructor of class ParseError
def test_ParseError():
    string_0 = "ParseError"
    error_0 = ParseError(string_0)
    assert(error_0.args == (string_0,))


# Generated at 2022-06-25 16:14:48.969855
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("test")


# Generated at 2022-06-25 16:14:50.359470
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(args=[], description=None)



# Generated at 2022-06-25 16:14:52.580239
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    parsed_docstring_0 = DocstringRaises(args = None, description = None, type_name = None)


# Generated at 2022-06-25 16:14:57.582041
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(["Param"], "desc")


# Generated at 2022-06-25 16:15:04.345431
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(['param'], 'This is a description', 'str', True, 'result')
    assert docstring_0.args == ['param']
    assert docstring_0.description == 'This is a description'
    assert docstring_0.type_name == 'str'
    assert docstring_0.is_generator == True
    assert docstring_0.return_name == 'result'

# Generated at 2022-06-25 16:15:10.296315
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_0 = ['int']
    description_0 = "variable description"
    arg_name_0 = 'arg1'
    type_name_0 = 'int'
    is_optional_0 = False
    default_0 = None
    obj_0 = DocstringParam(args_0,description_0,arg_name_0,type_name_0,is_optional_0,default_0)


# Generated at 2022-06-25 16:15:14.514848
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_0.long_description = "Hello"
    docstring_0.short_description = "Hello"
    docstring_returns_0=DocstringReturns(["returns"],"empty",None,False)

# Generated at 2022-06-25 16:15:15.815399
# Unit test for constructor of class ParseError
def test_ParseError():
  a = ParseError(args, description)
  return a


# Generated at 2022-06-25 16:15:17.550271
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    with pytest.raises(TypeError):
        x = DocstringParam()


# Generated at 2022-06-25 16:15:19.156042
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-25 16:15:20.781617
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(["a"], "b", "c")


# Generated at 2022-06-25 16:15:26.137428
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError', 'if something happens']
    description = 'if something happens'
    type_name = 'ValueError'

    item = DocstringRaises(args, description, type_name)
    assert (item.args == args)
    assert (item.description == description)
    assert (item.type_name == type_name)


# Generated at 2022-06-25 16:15:27.013605
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:15:31.089790
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    assert docstring_0.returns == None


# Generated at 2022-06-25 16:15:33.918902
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None, "Short description should be None"
    assert docstring.long_description is None, "Long description should be None"
    assert (
        not docstring.blank_after_short_description
    ), "Should not be blank after short description"
    assert (
        not docstring.blank_after_long_description
    ), "Should not be blank after long description"
    assert docstring.meta == [], "Meta should be empty list"

# Generated at 2022-06-25 16:15:36.418551
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("expected parameter name but got ':type'")


# Generated at 2022-06-25 16:15:37.997436
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert isinstance(
        DocstringMeta([], ""),
        DocstringMeta
    )


# Generated at 2022-06-25 16:15:40.329024
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param", "arg"], "description")
    assert docstring_meta.args == ["param", "arg"]
    assert docstring_meta.description == "description"


# Generated at 2022-06-25 16:15:47.443977
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description is False
    assert Docstring().blank_after_long_description is False
    assert isinstance(Docstring().meta, list)
    assert Docstring().meta == []


# Generated at 2022-06-25 16:15:48.461404
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:15:52.961347
# Unit test for constructor of class ParseError
def test_ParseError():
    import pytest
    from mypy_extensions import TypedDict
    from typing import Optional, List
    from docparser import ParseError
    with pytest.raises(ParseError):
        docstring_0 = ParseError()


# Generated at 2022-06-25 16:15:56.514175
# Unit test for constructor of class ParseError
def test_ParseError():
    with raises(ParseError):
        from docstring_parser.parser import _ParseErrorException
        raise _ParseErrorException("Some message")


# Generated at 2022-06-25 16:15:58.449918
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("ParseError has been raised")


# Generated at 2022-06-25 16:16:02.177399
# Unit test for constructor of class ParseError
def test_ParseError():
    exception = ParseError()
    assert isinstance(exception, ParseError)
    assert isinstance(exception, Exception)


# Generated at 2022-06-25 16:16:09.125387
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [':param', 'arg', 'description']
    desc = "desc"
    arg_name = "arg"
    type_name = "type"
    is_optional = "is_optional"
    default = "default"
    test0 = DocstringParam(args, desc, arg_name, type_name, is_optional, default)


# Generated at 2022-06-25 16:16:10.132977
# Unit test for constructor of class Docstring
def test_Docstring():
    assert test_case_0() is None

# Generated at 2022-06-25 16:16:10.993258
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:16:13.075894
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err


# Generated at 2022-06-25 16:16:15.841164
# Unit test for constructor of class ParseError
def test_ParseError():
    TestVar = ParseError
    TestVar = TestVar("Test")
    TestVar = TestVar("Test", "Test")
    TestVar = TestVar()


# Generated at 2022-06-25 16:16:17.591427
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(
        ['param'], 'description', 'version'
    )


# Generated at 2022-06-25 16:16:23.197928
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_1 = DocstringRaises(['docstring_1'], 'description', 'type_name')
    assert docstring_1.args == ['docstring_1']
    assert docstring_1.description == 'description'
    assert docstring_1.type_name == 'type_name'

# Generated at 2022-06-25 16:16:30.913359
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # test with shortest args (no description provided)
    test_case_0a = DocstringMeta(
        args=["param", "arg"], description="Long description"
    )
    print("DocstringMeta: args: {}".format(test_case_0a.args))
    print(
        "DocstringMeta: description: {}".format(test_case_0a.description)
    )

    # test with longest args (description provided)
    test_case_0b = DocstringMeta(args=["yield", "yields"], description=None)
    print("DocstringMeta: args: {}".format(test_case_0b.args))
    print(
        "DocstringMeta: description: {}".format(test_case_0b.description)
    )



# Generated at 2022-06-25 16:16:33.038323
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(["a", "b"], "c", "d", False, "e")


# Generated at 2022-06-25 16:16:36.980897
# Unit test for constructor of class Docstring
def test_Docstring():
    assert test_case_0() == None

# Generated at 2022-06-25 16:16:40.959504
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Constructor with given return_name
    DocstringReturns(args=None, description=None, type_name=None, is_generator=None, return_name="")


# Generated at 2022-06-25 16:16:43.084745
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([],[], [])


# Generated at 2022-06-25 16:16:44.506729
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_0()


# Generated at 2022-06-25 16:16:45.732145
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_0 = DocstringRaises(['raises'], None, None)

# Generated at 2022-06-25 16:16:48.851124
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_0 = DocstringMeta(["kw0","kw1","kw2"], "test description")
    assert test_0.args[0] == "kw0"
    assert test_0.description == "test description"


# Generated at 2022-06-25 16:16:50.103175
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(['param'], 'description', 'version')


# Generated at 2022-06-25 16:16:53.230331
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_test = DocstringParam(['parameter'], 'test', 'test', 'test', True, True)
    assert docstring_test.args == ['parameter']
    assert docstring_test.description == 'test'
    assert docstring_test.arg_name == 'test'
    assert docstring_test.type_name == 'test'
    assert docstring_test.is_optional == True
    assert docstring_test.default == True


# Generated at 2022-06-25 16:17:01.559986
# Unit test for constructor of class Docstring

# Generated at 2022-06-25 16:17:02.743193
# Unit test for constructor of class ParseError
def test_ParseError():
    new_ParseError = ParseError("")


# Generated at 2022-06-25 16:17:15.677711
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = {}
    docstring_1["short_description"] = None
    docstring_1["long_description"] = None
    docstring_1["blank_after_short_description"] = False
    docstring_1["blank_after_long_description"] = False
    docstring_1["meta"] = []
    docstring_2 = Docstring()
    assert docstring_2.short_description == docstring_1["short_description"]
    assert docstring_2.long_description == docstring_1["long_description"]
    assert docstring_2.meta == docstring_1["meta"]
    assert docstring_2.blank_after_short_description == docstring_1["blank_after_short_description"]

# Generated at 2022-06-25 16:17:21.437274
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = None
    type_name = None
    is_generator = True
    return_name = None
    obj = DocstringReturns(args, description, type_name, is_generator, return_name)
    if isinstance(obj, DocstringReturns) == True:
        print("Unit test for constructor DocstringReturns is passed")
    else:
        print("Unit test for constructor DocstringReturns is failed")


# Generated at 2022-06-25 16:17:27.038240
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    # Assert that result of instantiation of 'Docstring' is correct
    assert docstring_0.params == [] and \
        docstring_0.raises == [] and \
        docstring_0.returns is None and \
        docstring_0.short_description is None and \
        docstring_0.long_description is None and \
        docstring_0.blank_after_short_description == False and \
        docstring_0.blank_after_long_description == False and \
        docstring_0.meta == [] and \
        docstring_0.deprecation is None

# Generated at 2022-06-25 16:17:32.324890
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam([1, 2, 3], 3, 99, 'a', True, 0)


# Generated at 2022-06-25 16:17:36.055846
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test case")
    except ParseError as e:
        print("Passed")


# Generated at 2022-06-25 16:17:37.414400
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta([], "")


# Generated at 2022-06-25 16:17:42.897759
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["arg1", "arg2"]
    description = "This is the description"
    type_name = "type_name"
    return_name = "return_name"

    docstring_return = DocstringReturns(
        args,
        description,
        type_name,
        return_name = return_name
    )
    assert docstring_return.args == args
    assert docstring_return.description == description
    assert docstring_return.type_name == type_name
    assert docstring_return.return_name == return_name

# Generated at 2022-06-25 16:17:48.731768
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(["param"],"","")
    assert docstring_0.args[0] == "param"
    assert docstring_0.description == ""
    assert docstring_0.version == ""


# Generated at 2022-06-25 16:17:57.869154
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["raises"], "The foo() function raises a TypeError when there is no bar() function.", "TypeError")
    
    assert docstring_raises.args == ["raises"]
    assert docstring_raises.description == "The foo() function raises a TypeError when there is no bar() function."
    assert docstring_raises.type_name == "TypeError"


# Generated at 2022-06-25 16:18:01.907151
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta_0 = DocstringMeta(["param"], "This is a test")


# Generated at 2022-06-25 16:18:10.828648
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(args=["param"], description="description", arg_name="arg_name", type_name="type_name", is_optional=False, default="default")


# Generated at 2022-06-25 16:18:13.524977
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ""
    description = ""
    version = ""
    type(DocstringDeprecated(args, description, version))



# Generated at 2022-06-25 16:18:14.567105
# Unit test for constructor of class ParseError
def test_ParseError():
	# Test case 0
	ParseError()



# Generated at 2022-06-25 16:18:16.955922
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta('args', 'description').args == 'args'
    assert DocstringMeta('args', 'description').description == 'description'


# Generated at 2022-06-25 16:18:20.035958
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    DocstringParam(["param"], None, "arg", "str", True, "")

# Generated at 2022-06-25 16:18:21.156214
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()



# Generated at 2022-06-25 16:18:22.233512
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['param', 'arg'], 'description')


# Generated at 2022-06-25 16:18:26.470253
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("abc")
    except ParseError as e:
        assert e.args == ("abc",)
    try:
        raise ParseError("abc", "def")
    except ParseError as e:
        assert e.args == ("abc", "def")


# Generated at 2022-06-25 16:18:31.277441
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    docstring_param_0 = DocstringParam(['param','arg','argument','attribute','key','keyword'],docstring_0.short_description,str(),str(),True,str())


# Generated at 2022-06-25 16:18:33.457570
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam([], "", "arg_name", "type_name",True, "default")


# Generated at 2022-06-25 16:18:50.973122
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Add unit test for constructor of class DocstringRaises"""
    docstring_raises_0 = DocstringRaises(
        ['param'], 'string', 'str'
    )
    assert docstring_raises_0.args == ['param']
    assert docstring_raises_0.description == 'string'
    assert docstring_raises_0.type_name == 'str'



# Generated at 2022-06-25 16:18:53.509509
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("constructor of class ParseError")
    except ParseError:
        pass


# Generated at 2022-06-25 16:19:03.354493
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_param = DocstringParam([], "4", "4", "4", "4", "4")
    docstring_return = DocstringReturns([""], "", [""])
    assert docstring_return.args == [""]
    assert docstring_return.description == ""
    assert docstring_return.type_name == [""]
    assert docstring_return.is_generator is False
    assert docstring_return.return_name is None
    assert docstring_return.description is not None
    assert docstring_return.description == ""


# Generated at 2022-06-25 16:19:04.769625
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:19:09.993306
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_returns_0 = DocstringReturns(["args"], "description", "type_name", False)
    assert docstring_0.returns is None
    assert docstring_returns_0.return_name is None
    assert docstring_returns_0.args == ["args"]
    assert docstring_returns_0.description == "description"
    assert docstring_returns_0.type_name == "type_name"
    assert docstring_returns_0.is_generator is False


# Generated at 2022-06-25 16:19:17.603986
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []
    print("Test for constructor of class Docstring passes!")


# Generated at 2022-06-25 16:19:19.095862
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:19:24.422004
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(["param", "arg", "argument", "attribute", "key", "keyword"], "description", "arg_name", "type_name", True, "default")

    # Testing 'args' attribute
    assert (docstring_0.args == ["param", "arg", "argument", "attribute", "key", "keyword"])

    # Testing 'description' attribute
    assert (docstring_0.description == "description")

    # Testing 'arg_name' attribute
    assert (docstring_0.arg_name == "arg_name")

    # Testing 'type_name' attribute
    assert (docstring_0.type_name == "type_name")

    # Testing 'is_optional' attribute
    assert (docstring_0.is_optional == True)

    # Testing 'default' attribute
   

# Generated at 2022-06-25 16:19:28.083258
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(["param", "arg", "argument", "attribute", "key", "keyword"], "description", "arg_name", "type_name", False, "default")


# Generated at 2022-06-25 16:19:29.565065
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated([], "", "")


# Generated at 2022-06-25 16:19:53.563430
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Check if is_generator is accepted
    docstring_1 = DocstringRaises(["Parameter", "arg", "is required"], "Here is a description for Docstring class", "int")
    assert(docstring_1.args == ["Parameter", "arg", "is required"])
    assert(docstring_1.description == "Here is a description for Docstring class")
    assert(docstring_1.type_name == "int")


# Generated at 2022-06-25 16:19:57.294534
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        docstring0 = DocstringRaises(['-', 'yields'], '-', '-')
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-25 16:20:01.923958
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This is deprecated.'
    version = '0.1'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-25 16:20:03.320065
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError:
        pass


# Generated at 2022-06-25 16:20:06.563555
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'This is a docstring', '1.0')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'This is a docstring'
    assert docstring_deprecated.version == '1.0'



# Generated at 2022-06-25 16:20:09.203639
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises([],None,None)
    assert docstring.type_name == None
    assert docstring.description == None


# Generated at 2022-06-25 16:20:12.003534
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('This is a ParseError.')
    except ParseError:
        pass
    else:
        assert False, 'ParseError not raised.'


# Generated at 2022-06-25 16:20:18.652036
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = Docstring()
    result = DocstringRaises(["raises"], "Exception", "Exception")
    assert result.args == ["raises"], "Args is not equal"
    assert result.description == "Exception", "Description is not equal"
    assert result.type_name == "Exception", "Type name is not equal"


# Generated at 2022-06-25 16:20:28.842755
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', True, 'default')
    assert docstring_param_0.arg_name == 'arg_name'
    assert docstring_param_0.type_name == 'type_name'
    assert docstring_param_0.is_optional == True
    assert docstring_param_0.default == 'default'
    assert docstring_param_0.description == 'description'
    # Cannot test attributes args since __init__ does not return them


# Generated at 2022-06-25 16:20:31.312627
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(["arg"], "description")
    docstring_meta_0_args = docstring_meta_0.args
    docstring_meta_0_description = docstring_meta_0.description




# Generated at 2022-06-25 16:20:45.861602
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()

# Generated at 2022-06-25 16:20:50.594841
# Unit test for constructor of class Docstring
def test_Docstring():
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:20:56.141438
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = Docstring()
    args = ['hey', 'green', 'apple']
    description = 'a green apple'
    arg_name = 'apple'
    type_name = 'String'
    is_optional = True
    default = 'green'
    docstring_param = DocstringParam(args, description, arg_name,type_name,is_optional,default)


# Generated at 2022-06-25 16:21:02.883213
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(['return', 'returns'], 'The sum of a, b', 'int', False)
    assert docstring_returns.args == ['return', 'returns']
    assert docstring_returns.description == 'The sum of a, b'
    assert docstring_returns.type_name == 'int'
    assert docstring_returns.is_generator is False


# Generated at 2022-06-25 16:21:12.908936
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(
        ['parameter', 'arg', 'keyword', 'attribute', 'param', 'arg', 'key'],
        'description',
        None, )
    docstring_1 = DocstringDeprecated(
        ['param', 'parameter', 'keyword', 'attribute', 'arg'],
        'description',
        'version', )
    docstring_2 = DocstringDeprecated(
        ['raises', 'except', 'exception'],
        'description',
        'version', )
    docstring_3 = DocstringDeprecated(
        ['parameter', 'attribute', 'keyword', 'arg', 'param', 'key', 'return'],
        'description',
        'version', )
    docstring_4 = DocstringDeprecated([], 'description', 'version')
    docstring

# Generated at 2022-06-25 16:21:18.362853
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(["param"], None, "arg", "test", True, "None")
    assert docstring_0.arg_name == "arg"
    assert docstring_0.type_name == "test"
    assert docstring_0.is_optional == True
    assert docstring_0.default == None


# Generated at 2022-06-25 16:21:26.082881
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:21:27.836820
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated("args","description","version")


# Generated at 2022-06-25 16:21:33.344497
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises([], None, None)
    print(docstring_raises.args)
    print(docstring_raises.description)
    print(docstring_raises.type_name)



# Generated at 2022-06-25 16:21:35.729896
# Unit test for constructor of class ParseError
def test_ParseError():
    # Case 0
    try:
        raise ParseError('Error')
    except ParseError:
        pass



# Generated at 2022-06-25 16:21:59.449920
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns_object = DocstringReturns(["type:","List[int]"], "description", "List[int]", True, "ReturnName")

    # testing whether the attributes of DocstringReturns are properly set
    assert DocstringReturns_object.args == ["type:","List[int]"]
    assert DocstringReturns_object.description == "description"
    assert DocstringReturns_object.type_name == "List[int]"
    assert DocstringReturns_object.is_generator == True
    assert DocstringReturns_object.return_name == "ReturnName"


# Generated at 2022-06-25 16:22:03.301856
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(['a', 'b'], 'description', 'arg', 'type', 'Optional', 'default')


# Generated at 2022-06-25 16:22:06.502410
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    constructor = DocstringDeprecated(
        args=["th"], description="giang", version="3.6"
    )
    assert constructor.args == ["th"]
    assert constructor.description == "giang"
    assert constructor.version == "3.6"



# Generated at 2022-06-25 16:22:10.542223
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        docstring_0 = DocstringRaises([], "", "")
        print("DocstringRaises constructor test passed")
    except:
        print("DocstringRaises constructor test failed")


# Generated at 2022-06-25 16:22:13.629332
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for class Docstring."""
    try:
        docstring_0 = Docstring()
        return True
    except:
        return False


# Generated at 2022-06-25 16:22:17.642407
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(
        ['param', 'arg', 'argument', 'attribute', 'key', 'keyword'],
        'description',
        'arg_name',
        'type_name',
        'is_optional',
        'default',
    )



# Generated at 2022-06-25 16:22:18.705369
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["param"], "test description", "test version")



# Generated at 2022-06-25 16:22:20.286681
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_0 = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")


# Generated at 2022-06-25 16:22:23.538758
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(["Deprecated"], "Api method is not supported", "My version")
    assert docstring_0.args[0] == 'Deprecated'
    assert docstring_0.description == 'Api method is not supported'
    assert docstring_0.version == 'My version'


# Generated at 2022-06-25 16:22:25.935247
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_obj_0 = DocstringMeta(
        "arg", "description"
    )
    assert docstring_meta_obj_0.description == "description"
    assert docstring_meta_obj_0.args == "arg"
