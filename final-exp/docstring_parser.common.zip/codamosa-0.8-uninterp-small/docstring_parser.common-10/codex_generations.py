

# Generated at 2022-06-25 16:12:43.803450
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam([], '', '', '', True, '', )


# Generated at 2022-06-25 16:12:47.123980
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('eskimos')
    except ParseError as pe:
        assert pe.args == ('eskimos', ), 'Bad args'
    test_case_0()

# Generated at 2022-06-25 16:12:49.064820
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    list_0 = []
    str_0 = '*l~$Z'
    docstring_meta_0 = DocstringMeta(list_0, str_0)


# Generated at 2022-06-25 16:12:53.781639
# Unit test for constructor of class Docstring
def test_Docstring():
    assert isinstance(Docstring().short_description, None.__class__)
    assert isinstance(Docstring().long_description, None.__class__)
    assert isinstance(Docstring().blank_after_short_description, bool)
    assert isinstance(Docstring().blank_after_long_description, bool)
    assert isinstance(Docstring().meta, list)



# Generated at 2022-06-25 16:13:01.769736
# Unit test for constructor of class Docstring
def test_Docstring():
    str_0 = '`0J}\\dr'
    list_0 = [str_0, str_0]
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_0)
    docstring_0 = Docstring()
    assert isinstance(docstring_0.params, list) == True
    assert isinstance(docstring_0.raises, list) == True
    assert docstring_0.returns == None
    assert docstring_0.deprecation == None


# Generated at 2022-06-25 16:13:05.671421
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    str_0 = 'bH2`~5G;'
    str_1 = '9(<x'
    list_0 = [str_0, str_1]
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)


# Generated at 2022-06-25 16:13:08.659025
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    str_0 = '`0J}\\dr'
    list_0 = [str_0, str_0]
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_0)




# Generated at 2022-06-25 16:13:14.228380
# Unit test for constructor of class Docstring
def test_Docstring():
    expected_values = {'short_description': None,
                       'long_description': None,
                       'blank_after_short_description': False,
                       'blank_after_long_description': False,
                       'meta': [],
                       }
    docstring_0 = Docstring()
    for key, val in expected_values.items():
        assert getattr(docstring_0, key) == val


# Generated at 2022-06-25 16:13:15.688834
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()
    print("DocstringDeprecated constructor unit test completed.")



# Generated at 2022-06-25 16:13:16.200942
# Unit test for constructor of class Docstring
def test_Docstring():

    assert True

# Generated at 2022-06-25 16:13:19.574645
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-25 16:13:22.583820
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    params = [1, 2]
    description = "abcd"
    obj = DocstringMeta(params, description)
    assert obj.args == params
    assert obj.description == description


# Generated at 2022-06-25 16:13:28.896269
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert (docstring_0.short_description == None)
    assert (docstring_0.long_description == None)
    assert (docstring_0.blank_after_short_description == False)
    assert (docstring_0.blank_after_long_description == False)
    assert (docstring_0.meta == [])
    assert (docstring_0.params == [])
    assert (docstring_0.raises == [])
    assert (docstring_0.returns == None)
    assert (docstring_0.deprecation == None)


# Generated at 2022-06-25 16:13:38.153959
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    var_0 = docstring_0.short_description
    var_0 = docstring_0.long_description
    var_1 = docstring_0.blank_after_short_description
    var_1 = docstring_0.blank_after_long_description
    var_2 = docstring_0.meta
    var_2 = docstring_0.params
    var_3 = docstring_0.raises
    var_4 = docstring_0.returns
    var_5 = docstring_0.deprecation

# Generated at 2022-06-25 16:13:39.433112
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-25 16:13:41.810746
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(['param', 'arg', 'arg_name'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')


# Generated at 2022-06-25 16:13:44.597072
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_1 = DocstringDeprecated(["arg1", "arg2"], "Docstring description", "version")
    assert docstring_1


# Generated at 2022-06-25 16:13:46.709669
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    var_0 = DocstringRaises([], None, 'arg_name', None)


# Generated at 2022-06-25 16:13:53.209847
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    a: T.List[str] = []
    b: T.Optional[str] = None
    c: T.Optional[str] = None
    d: T.Optional[bool] = False
    e: T.Optional[str] = None
    f = docstring_0.params
    g = docstring_0.raises
    h = docstring_0.returns
    i = docstring_0.deprecation
    assert isinstance(g, T.List[DocstringRaises])
    assert isinstance(h, T.Optional[DocstringReturns])
    assert isinstance(i, T.Optional[DocstringDeprecated])


# Generated at 2022-06-25 16:13:55.953679
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("error_in_docstring")
    assert True


# Generated at 2022-06-25 16:14:01.572289
# Unit test for constructor of class Docstring
def test_Docstring():
    # Initialization
    docstring = Docstring()

    # Assertion
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []



# Generated at 2022-06-25 16:14:09.992637
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    var_1 = DocstringReturns(['foo'], 'bla bla bla', 'str')
    assert var_1.args == ['foo']
    assert var_1.description == 'bla bla bla'
    assert var_1.type_name == 'str'
    assert var_1.is_generator == False
    assert var_1.return_name == None


# Generated at 2022-06-25 16:14:11.567251
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    var_0 = docstring_0.params
    

# Generated at 2022-06-25 16:14:12.338511
# Unit test for constructor of class ParseError
def test_ParseError():
    var_0 = ParseError

# Generated at 2022-06-25 16:14:14.354950
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    version=None
    description=None
    args=["param"]
    obj = DocstringDeprecated(args, description, version)


# Generated at 2022-06-25 16:14:17.816436
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Error Message")


# Generated at 2022-06-25 16:14:18.839900
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()

# Generated at 2022-06-25 16:14:20.138390
# Unit test for constructor of class ParseError
def test_ParseError():
    # Init
    err = ParseError()


# Generated at 2022-06-25 16:14:23.329030
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta(args=[], description="This is a docstring meta info.")
    except Exception:
        assert False
    else:
        assert True


# Generated at 2022-06-25 16:14:35.337888
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(["raises", "Variable"], None, None, False)
    assert docstring_0.description is None
    assert docstring_0.is_generator is False
    assert docstring_0.args == ['raises', 'Variable']
    assert docstring_0.type_name is None
    # testing for line 13
    docstring_1 = DocstringReturns(["raises", "Variable", "One"], None, None, False)
    assert docstring_1.description is None
    assert docstring_1.is_generator is False
    assert docstring_1.args == ['raises', 'Variable', 'One']
    assert docstring_1.type_name is None
    # testing for line 19

# Generated at 2022-06-25 16:14:50.965281
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args_0 = ["1"]
    description_0 = "2"
    type_name_0 = "3"
    is_generator_0 = False
    return_name_0 = "5"
    docstring_returns_0 = DocstringReturns(args_0, description_0, type_name_0, is_generator_0, return_name_0)
    assert(docstring_returns_0.args == args_0)
    assert(docstring_returns_0.description == description_0)
    assert(docstring_returns_0.type_name == type_name_0)
    assert(docstring_returns_0.is_generator == is_generator_0)
    assert(docstring_returns_0.return_name == return_name_0)


# Unit test

# Generated at 2022-06-25 16:14:55.045429
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_0 = ['param']
    description_0 = 'description'
    arg_name_0 = 'arg_name'
    type_name_0 = 'type_name'
    is_optional_0 = True
    default_0 = 'default'
    DocstringParam(args_0, description_0, arg_name_0, type_name_0, is_optional_0, default_0)


# Generated at 2022-06-25 16:14:58.417998
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(
        ["raises"],
        "if something happens",
        "ValueError",
    )


# Generated at 2022-06-25 16:15:07.869357
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Assume all variable are initialized
    args_0 = ["param", "def"]
    description_0 = "description"
    type_name_0 = ":return: int"
    is_generator_0 = False
    return_name_0 = None
    docstringMeta_0 = DocstringReturns(
        args_0, description_0, type_name_0, is_generator_0, return_name_0
    )
    type_name_0 = docstringMeta_0.type_name
    is_generator_0 = docstringMeta_0.is_generator
    return_name_0 = docstringMeta_0.return_name


# Generated at 2022-06-25 16:15:11.787440
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    constructor_1 = DocstringMeta(['example', 'arg'], 'Example description')
    print(constructor_1.args)
    print(constructor_1.description)


# Generated at 2022-06-25 16:15:20.539445
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Test docstring with no arguments and no description
    test_returns_0 = DocstringReturns(['return', 'returns'], None, None, False)
    assert(test_returns_0.args == ['return', 'returns'])
    assert(test_returns_0.description == None)
    assert(test_returns_0.type_name == None)
    assert(test_returns_0.is_generator == False)
    assert(test_returns_0.return_name == None)

    # Test docstring with multiple arguments, a type name, and a description
    test_returns_1 = DocstringReturns(['return', 'returns', 'type', 'NoReturn'], 'type should be NoReturn', 'NoReturn', False)

# Generated at 2022-06-25 16:15:21.384903
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises()


# Generated at 2022-06-25 16:15:26.744135
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    var_1 = DocstringRaises(['param'], "description", "type_name")
    var_1.args
    var_1.description
    var_1.type_name
    assert var_1.args == ['param']
    assert var_1.description == "description"
    assert var_1.type_name == "type_name"


# Generated at 2022-06-25 16:15:28.829702
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(index=1, message="Creating a parse error")


# Generated at 2022-06-25 16:15:30.754191
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises', 'ValueError'], None, 'ValueError')


# Generated at 2022-06-25 16:15:39.919080
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['returns','return','returns'], 'Description', 'type', True, 'return_name') is not None


# Generated at 2022-06-25 16:15:47.395744
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['--arg', 'arg'], 'description')
    assert isinstance(docstring_meta, DocstringMeta)
    assert docstring_meta.args == ['--arg', 'arg']
    assert docstring_meta.description == 'description'
    print('Success')


# Generated at 2022-06-25 16:15:48.812878
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], None, 'Optional[str]', False, None)

# Generated at 2022-06-25 16:15:53.378321
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # TypeError if not all arguments have a valid type
    try:
        docstringraises_0 = DocstringRaises(["param"], "desc")
        print(docstringraises_0.__dict__)
    except TypeError:
        print("TypeError")


# Generated at 2022-06-25 16:15:56.514593
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d1 = DocstringMeta([], "")
    assert d1.args == []
    assert d1.description == ""


# Generated at 2022-06-25 16:16:01.328129
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test if the instance variable description is initialized correctly.
    description = "This is description."
    obj = DocstringDeprecated(["deprecated"], description, "2.3.0")
    assert obj.description == description, "Description is not set correctly."
    # Test if the instance variable version is initialized correctly.
    version = "2.3.0"
    obj = DocstringDeprecated(["deprecated"], description, version)
    assert obj.version == version, "Version is not set correctly."


# Generated at 2022-06-25 16:16:06.802179
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_args = 'args'
    return_description = 'description'
    return_type_name = 'type'
    return_is_generator = 'isGenerator'
    return_name = 'name'

    docstring_return = DocstringReturns(return_args, return_description,
                                        return_type_name, return_is_generator, return_name)
    assert docstring_return.args == return_args
    assert docstring_return.description == return_description
    assert docstring_return.type_name == return_type_name
    assert docstring_return.is_generator == return_is_generator
    assert docstring_return.return_name == return_name


# Generated at 2022-06-25 16:16:09.707324
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([1,2,3], "Hi")
    assert a.args == [1,2,3]
    assert a.description == "Hi"


# Generated at 2022-06-25 16:16:15.885776
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []
    assert docstring_1.params == []
    assert docstring_1.raises == []
    assert docstring_1.returns == None
    assert docstring_1.deprecation == None


# Generated at 2022-06-25 16:16:17.618925
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1 = DocstringReturns([
        "return",
        "description",
    ], "description", "type_name", True)


# Generated at 2022-06-25 16:16:36.373602
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    temp_0 = DocstringRaises(['a'], 'a', 'a')
    assert(temp_0.type_name == 'a')
    assert(temp_0.args == ['a'])
    assert(temp_0.description == 'a')


# Generated at 2022-06-25 16:16:46.938221
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    class_ = DocstringDeprecated
    method_ = class_.__init__
    assert_method_args(
        method_,
        [
            Parameter(
                name="args",
                kind=Parameter.POSITIONAL_OR_KEYWORD,
                type=typing.List[str],
                default=Parameter.empty,
            ),
            Parameter(
                name="description",
                kind=Parameter.POSITIONAL_OR_KEYWORD,
                type=typing.Optional[str],
                default=Parameter.empty,
            ),
            Parameter(
                name="version",
                kind=Parameter.POSITIONAL_OR_KEYWORD,
                type=typing.Optional[str],
                default=Parameter.empty,
            ),
        ],
        "self",
        typing.Any,
    )


# Generated at 2022-06-25 16:16:51.315792
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param", "@arg"], "desc") is not None


# Generated at 2022-06-25 16:16:53.292622
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(["param"], None, version=None)

# Generated at 2022-06-25 16:16:57.539154
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1 = DocstringReturns('params', 'test', 'str')
    print(docstring_1.args)
    print(docstring_1.description)
    print(docstring_1.type_name)


# Generated at 2022-06-25 16:17:01.915331
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "TypeError"]
    description = "If wrong input provided"
    type_name = "TypeError"
    raises = DocstringRaises(args, description, type_name)
    assert raises.type_name == type_name
    assert raises.args == args

# Generated at 2022-06-25 16:17:03.968598
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=[], description=None, type_name=None)


# Generated at 2022-06-25 16:17:08.893504
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-25 16:17:11.713984
# Unit test for constructor of class Docstring
def test_Docstring(): 
    docstring_0 = Docstring()
    var_0 = docstring_0.params


if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-25 16:17:14.365309
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_3 = Docstring()
    var_3 = docstring_3.meta
    docstring_4 = Docstring()
    var_4 = docstring_4.raises



# Generated at 2022-06-25 16:17:49.531138
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(
        args=[],
        description=None,
        arg_name="value",
        type_name=None,
        is_optional=None,
        default=None,
    )


# Generated at 2022-06-25 16:17:59.651717
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Declare DocstringReturns obj_0 that call constructor DocstringReturns, with inputs:
    obj_0 = DocstringReturns([
        "arg",
        "description",
        "arg_name",
        "type_name",
        "is_optional",
        "default"
    ], 'description', 'type_name', False)
    # Declare return_0 that is returned by calling function: get_return_0
    return_0 = get_return_0(obj_0)

    # FIXME: Add return value check here
    # Check that isequal(return, return_0) == true
    assert return_0 == obj_0



# Generated at 2022-06-25 16:18:00.648825
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises((), None, None)


# Generated at 2022-06-25 16:18:05.152593
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    var_0 = docstring_0.short_description
    var_1 = docstring_0.long_description
    var_2 = docstring_0.blank_after_short_description
    var_3 = docstring_0.blank_after_long_description
    var_4 = docstring_0.meta
    var_5 = docstring_0.params
    var_6 = docstring_0.raises
    var_7 = docstring_0.returns
    var_8 = docstring_0.deprecation


# Generated at 2022-06-25 16:18:08.284691
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([1, 2, 3], "", "arg_name", "type_name", False, "default")

test_case_0()
test_DocstringParam()

# Generated at 2022-06-25 16:18:09.362124
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()

# Generated at 2022-06-25 16:18:11.275086
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = Docstring()
    var_0 = docstring_0.params


# Generated at 2022-06-25 16:18:12.603556
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated([], '', None)



# Generated at 2022-06-25 16:18:15.644270
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("An error occurred")
    except ParseError:
        pass

# Generated at 2022-06-25 16:18:23.660628
# Unit test for constructor of class Docstring
def test_Docstring():
    my_object = Docstring()
    assert my_object.short_description == None
    assert my_object.long_description == None
    assert my_object.blank_after_short_description == False
    assert my_object.blank_after_long_description == False
    assert my_object.meta == []
    assert my_object.params == []
    assert my_object.raises == []
    assert my_object.returns == None
    assert my_object.deprecation == None


# Generated at 2022-06-25 16:19:31.231901
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = Docstring()
    var_0 = docstring_0.params



# Generated at 2022-06-25 16:19:33.794577
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    #
    # TODO: Improve check assertions
    #
    docstring_meta = DocstringMeta([1, 2, 3], "assoc_desc")
    var = docstring_meta.args
    var = docstring_meta.description


# Generated at 2022-06-25 16:19:38.380443
# Unit test for constructor of class Docstring
def test_Docstring():
    src = Docstring()
    assert src.short_description == None
    assert src.long_description == None
    assert src.blank_after_short_description == False
    assert src.blank_after_long_description == False
    assert src.meta == []


# Generated at 2022-06-25 16:19:51.810960
# Unit test for constructor of class Docstring
def test_Docstring():
    # Docstring object
    docstring_0 = Docstring()

    # short_description
    assert isinstance(docstring_0.short_description, T.Optional[str])

    # long_description
    assert isinstance(docstring_0.long_description, T.Optional[str])

    # blank_after_short_description
    assert isinstance(docstring_0.blank_after_short_description, bool)

    # blank_after_long_description
    assert isinstance(docstring_0.blank_after_long_description, bool)

    # meta
    assert isinstance(docstring_0.meta, T.List[DocstringMeta])

    # params
    assert isinstance(docstring_0.params, T.List[DocstringParam])

    # raises

# Generated at 2022-06-25 16:19:52.836433
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:19:53.762913
# Unit test for constructor of class Docstring
def test_Docstring():
    var_0 = Docstring()


# Generated at 2022-06-25 16:19:57.582423
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test for constructor of DocstringRaises
    assert isinstance(DocstringRaises(['param', 'arg', 'argument'], None, None), DocstringMeta), 'DocstringMeta return is wrong'


# Generated at 2022-06-25 16:20:00.843259
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    var_1 = DocstringDeprecated(args=["test"], description="test", version="test")
    assert var_1
    var_2 = DocstringDeprecated()
    assert var_2


# Generated at 2022-06-25 16:20:03.833397
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    assert obj.type_name == "ValueError"
    assert obj.args == ["raises", "ValueError"]
    assert obj.description == "if something happens"



# Generated at 2022-06-25 16:20:08.674354
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    test_1 = docstring_0.params
    for test_2 in test_1:
        test_3 = test_2.args
        print(test_3)
        test_4 = test_2.description
        print(test_4)
        test_5 = test_2.arg_name
        print(test_5)
        test_6 = test_2.type_name
        print(test_6)
        test_7 = test_2.is_optional
        print(test_7)
        test_8 = test_2.default
        print(test_8)