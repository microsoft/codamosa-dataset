

# Generated at 2022-06-25 16:12:42.267023
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta([], '')


# Generated at 2022-06-25 16:12:47.090779
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_meta_0 = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_meta_0.args == ["deprecated"]
    assert docstring_meta_0.description == "description"
    assert docstring_meta_0.version == "version"


# Generated at 2022-06-25 16:12:48.504713
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises([], "description", "type_name")


# Generated at 2022-06-25 16:13:01.882183
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description == None, 'Failed to initialize variables: short_description'
    assert docstring_0.long_description == None, 'Failed to initialize variables: long_description'
    assert docstring_0.blank_after_short_description == False, 'Failed to initialize variables: blank_after_short_description'
    assert docstring_0.blank_after_long_description == False, 'Failed to initialize variables: blank_after_long_description'
    assert docstring_0.meta == [], 'Failed to initialize variables: meta'
    assert docstring_0.params == [], 'Failed to return type: params'
    assert docstring_0.raises == [], 'Failed to return type: raises'
    assert docstring_0.returns

# Generated at 2022-06-25 16:13:06.835204
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_1 = DocstringReturns(["returns"], "", "", False)
    assert(docstring_1.args == ["returns"])
    assert(docstring_1.description == "")
    assert(docstring_1.type_name == "")
    assert(docstring_1.is_generator == False)


# Generated at 2022-06-25 16:13:08.084191
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert True



# Generated at 2022-06-25 16:13:13.107739
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "returns the value", "int")
    assert (docstring_returns.type_name == "int")
    assert (docstring_returns.description == "returns the value")
    assert (docstring_returns.is_generator == False)


# Generated at 2022-06-25 16:13:15.067219
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam([], "desc", "arg", "type", None, None).__init__ is not None


# Generated at 2022-06-25 16:13:17.257545
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['a', 'b'], 'c', 'd')


# Generated at 2022-06-25 16:13:24.421234
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args = [], description = "", type_name = "str", is_generator = False, return_name = 0)
    DocstringReturns(args = [], description = "", type_name = "str", is_generator = False, return_name = 0)
    DocstringReturns(args = [], description = "", type_name = "str", is_generator = False, return_name = 0)


# Generated at 2022-06-25 16:13:34.531333
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("This is an exception!")
    assert err.args[0] == "This is an exception!"


# Generated at 2022-06-25 16:13:40.884865
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args = ['param', ' description'], description = "description", version = "1.2.2")
    assert docstring_deprecated.args == ['param', ' description']
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "1.2.2"


# Generated at 2022-06-25 16:13:43.631636
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("New Test ParseError")
    except ParseError as e:
        assert e.args[0] == "New Test ParseError"


# Generated at 2022-06-25 16:13:44.640310
# Unit test for constructor of class Docstring
def test_Docstring():
    assert test_case_0()


# Generated at 2022-06-25 16:13:46.760294
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError
    assert parse_error_0


# Generated at 2022-06-25 16:13:59.898992
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """
    Checks for the constructor of class DocstringParam
    """
    docstring_param = DocstringParam(["param", "p", "parameter"], "some description.",
                                     "p", "str", True, "default")
    assert isinstance(docstring_param, DocstringMeta)
    assert [docstring_param.args[i] for i in range(len(docstring_param.args))] == [
        "param", "p", "parameter"
    ]
    assert (
        docstring_param.description == "some description."
    )  # The space at the end is important
    assert docstring_param.arg_name == "p"
    assert docstring_param.type_name == "str"
    assert docstring_param.is_optional is True

# Generated at 2022-06-25 16:14:05.112388
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()
    # assert


# Generated at 2022-06-25 16:14:06.900922
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # test correct input
    test_case_0()


# Generated at 2022-06-25 16:14:11.754265
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Create instance of class DocstringRaises
    docstring_0 = DocstringRaises(["parameter"], "test", "test")
    assert(docstring_0.description == "test")
    assert(docstring_0.type_name == "test")


# Generated at 2022-06-25 16:14:13.644719
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        print("ParseError Constructor test successful")


# Generated at 2022-06-25 16:14:32.016965
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["arg"]
    description = "test"
    arg_name = "arg"
    type_name = "test_type"
    is_optional = False
    default = None

    test_case = DocstringParam(
        args, description, arg_name, type_name, is_optional, default
    )
    assert test_case.args == ["arg"]
    assert test_case.description == "test"
    assert test_case.arg_name == "arg"
    assert test_case.type_name == "test_type"
    assert test_case.is_optional == False
    assert test_case.default == None



# Generated at 2022-06-25 16:14:35.002485
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    docstring_deprecated = DocstringDeprecated(docstring_0.meta,
                                                      docstring_0.long_description,
                                                      docstring_0.version)


# Generated at 2022-06-25 16:14:36.553019
# Unit test for constructor of class ParseError
def test_ParseError():
    docstring_1 = Docstring()


# Generated at 2022-06-25 16:14:39.700497
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "return type of function", "int", False, "name")



# Generated at 2022-06-25 16:14:45.060154
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        assert (
            1,
            ) == 1
    except AssertionError:
        raise AssertionError(
            "{} should be equal to {}".format(
                repr(1),
                repr(1),
                ))


# Generated at 2022-06-25 16:14:49.010458
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args = ['param', 'x','string','True','None'], description = 'Test case', arg_name ='x', type_name = 'string', is_optional = True, default = None)
    print(docstring_param.args[3])


# Generated at 2022-06-25 16:14:50.384655
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass


# Generated at 2022-06-25 16:14:50.962128
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:14:52.991549
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()
    assert(isinstance(parse_error_0, RuntimeError))


# Generated at 2022-06-25 16:14:55.250201
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_1 = DocstringRaises(["arg"], "description", "type")


# Generated at 2022-06-25 16:15:05.110979
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:15:08.026712
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    docstring_meta = DocstringMeta(None, None)
    docstring_deprecated = DocstringDeprecated(None, None, None)


# Generated at 2022-06-25 16:15:09.728252
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    assert docstring_0


# Generated at 2022-06-25 16:15:15.994322
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg_name = "DocstringParam"
    type_name = "DocstringMeta"
    description = "Unit test for constructor of class DocstringParam"
    arg_name = "DocstringParam"
    type_name = "DocstringMeta"
    is_optional = True
    default = "None"
    docstring_param = DocstringParam(arg_name,type_name,description,is_optional,default)



# Generated at 2022-06-25 16:15:22.570159
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    _args = [':return:']
    _description = 'str'
    _type_name = None
    _is_generator = True
    _return_name = None

    # Class attributes should be initialized upon instantiation of the class
    assert(_args[0] == ':return:')
    assert(_description == 'str')
    assert(_type_name == None)
    assert(_is_generator == True)

    # Create instance of the DocstringReturns class
    docstring_returns = DocstringReturns(_args, _description, _type_name, _is_generator, _return_name)

    # Class attributes should be set by the constructor
    assert(docstring_returns.args[0] == ':return:')
    assert(docstring_returns.description == 'str')

# Generated at 2022-06-25 16:15:24.361383
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(['a'], 'b', 'c')



# Generated at 2022-06-25 16:15:26.261115
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises"], "description", "type_name")



# Generated at 2022-06-25 16:15:27.162228
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "")


# Generated at 2022-06-25 16:15:29.348766
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)


# Generated at 2022-06-25 16:15:35.843791
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_meta = DocstringDeprecated(["deprecated"], "This is deprecated", "1.0")
    assert docstring_meta.args == ["deprecated"], \
        "args of class should be a list of string"
    assert docstring_meta.description == "This is deprecated", \
        "Description should be a string"
    assert docstring_meta.version == "1.0", \
        "version should be a string"


# Generated at 2022-06-25 16:15:54.809047
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = Docstring()
    docstring_meta_0 = DocstringMeta(list(), str())


# Generated at 2022-06-25 16:15:56.796160
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

test_Docstring()

# Generated at 2022-06-25 16:15:58.350246
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], None, None, None, None, None)



# Generated at 2022-06-25 16:16:00.205164
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_0 = DocstringRaises(["arg"], "description", "type_name")



# Generated at 2022-06-25 16:16:02.707459
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_test = DocstringMeta(['args'], 'description')
    assert docstring_meta_test.args == ['args']
    assert docstring_meta_test.description == 'description'


# Generated at 2022-06-25 16:16:05.407391
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['param', 'arg', 'keyword'], 'description', '0.9')


# Generated at 2022-06-25 16:16:15.886178
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_0.short_description = "changes the value of variable x"
    docstring_0.long_description = "The function increase or decrease the variable x by one"
    docstring_0.blank_after_short_description = True
    docstring_0.blank_after_long_description = False
    docstring_0.meta = [
        DocstringReturns(
            "return_or_yield",
            "This is the value of the return",
            "int",
            False,
            "x",
        ),
        DocstringParam(
            "raise",
            "This is the raised exception",
            "TypeError",
            "str",
            False,
            "x",
        )
    ]
    # Constructor test

# Generated at 2022-06-25 16:16:18.785241
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.long_description == None
    assert docstring_0.params == []
    assert docstring_0.deprecation == None
    assert docstring_0.raises == []
    assert docstring_0.returns == None
    assert docstring_0.short_description == None


# Generated at 2022-06-25 16:16:20.578113
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:16:25.173230
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'in version 1.0', '1.0')
    assert docstring_deprecated.description == 'in version 1.0'
    assert docstring_deprecated.version == '1.0'


# Generated at 2022-06-25 16:17:03.596750
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()



# Generated at 2022-06-25 16:17:12.878790
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = "test"
    arg_name = "arg"
    type_name = None
    is_optional = False
    default = None

    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == "Any"
    assert docstring_param.is_optional == False
    assert docstring_param.default == None


# Generated at 2022-06-25 16:17:15.406083
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_1 = DocstringParam()
    docstring_2 = DocstringReturns()
    docstring_3 = DocstringRaises()
    docstring_4 = DocstringDeprecated()



# Generated at 2022-06-25 16:17:16.215812
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:17:18.927209
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(list("param arg: arg"), "desc", "arg_name", "type_name", True, 3)


# Generated at 2022-06-25 16:17:22.844208
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_0.short_description = "docstring_0"
    docstring_0.long_description = "Long description"
    assert docstring_0.short_description == "docstring_0"
    assert docstring_0.long_description == "Long description"


# Generated at 2022-06-25 16:17:26.199878
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:17:28.482180
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()



# Generated at 2022-06-25 16:17:35.957400
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["test"]
    description = "test"
    type = "test"
    ds = DocstringRaises(args, description, type)
    assert ds.args == args
    assert ds.description == description
    assert ds.type_name == type


# Generated at 2022-06-25 16:17:38.989245
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """
    Test DocstringMeta constructor
    """
    docstringMeta = DocstringMeta(['one'], 'None')
    assert docstringMeta.args == ['one']
    assert docstringMeta.description == 'None'


# Generated at 2022-06-25 16:18:58.447419
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args = "a", description = "", version = "")
    assert docstring_deprecated.args == "a"
    assert docstring_deprecated.description == ""
    assert docstring_deprecated.version == ""


# Generated at 2022-06-25 16:18:59.699941
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:19:06.997447
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises"]
    description = "if something happens"
    type_name = "ValueError"
    a = DocstringRaises(args, description, type_name)
    # check that attribute "args" is the same
    assert a.args == args
    # check that attribute "description" is the same
    assert a.description == description
    # check that attribute "type_name" is the same
    assert a.type_name == type_name



# Generated at 2022-06-25 16:19:11.015787
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam([], None, 'arg_name', 'type_name', False, None)
    assert isinstance(item, DocstringMeta)
    assert item.arg_name == 'arg_name'
    assert item.type_name == 'type_name'
    assert item.is_optional == False
    assert item.default is None


# Generated at 2022-06-25 16:19:14.613478
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:19:18.808710
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([":raises"], None, None)



# Generated at 2022-06-25 16:19:21.569195
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['param'], None, 'arg', 'int', False, 'None')


# Generated at 2022-06-25 16:19:29.519862
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_Obj = DocstringReturns([':returns', 'type_name', ':returns'], 'description', 'type_name', True)
    assert docstring_Obj.args == [':returns', 'type_name', ':returns']
    assert docstring_Obj.description == 'description'
    assert docstring_Obj.type_name == 'type_name'
    assert docstring_Obj.is_generator == True
    assert docstring_Obj.return_name == None


# Generated at 2022-06-25 16:19:33.370528
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(args = ['param'], description = 'This is a test for DocstringMeta')
    assert docstring.args == ['param'] and docstring.description == 'This is a test for DocstringMeta'


# Generated at 2022-06-25 16:19:34.263392
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(1, 2)
