

# Generated at 2022-06-25 16:12:48.975199
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = None
    str_0 = '"\nXFsU9#'
    docstring_meta_0 = DocstringMeta(list_0, str_0)
    docstring_returns_0 = DocstringReturns(list_0, str_0, str_0, True)
    docstring_returns_0.description
    docstring_returns_0.description = str_0
    docstring_returns_0.description
    docstring_returns_0.description = str_0
    docstring_returns_0.description
    docstring_returns_0.args[1]
    docstring_returns_0.args = list_0
    docstring_returns_0.args[1]
    docstring_returns_0.is_generator
    docstring_returns_

# Generated at 2022-06-25 16:12:53.191295
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = None
    str_0 = '"\nXFsU9#'
    str_1 = '7\u0012'
    bool_0 = False
    docstring_returns_0 = DocstringReturns(list_0, str_0, str_1, bool_0)


# Generated at 2022-06-25 16:12:57.783506
# Unit test for constructor of class Docstring
def test_Docstring():
    list_0 = list
    str_0 = '"\nXFsU9#'
    docstring_meta_0 = DocstringMeta(list_0, str_0)


# Generated at 2022-06-25 16:13:02.583471
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = None
    str_0 = 'R\x1f-/+;@65>^BCH'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)
    str_1 = '"\nXFsU9#'
    docstring_raises_1 = DocstringRaises(list_0, str_1, str_1)


# Generated at 2022-06-25 16:13:05.121098
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    list_0 = None
    str_0 = '"\nXFsU9#'
    docstring_meta_0 = DocstringMeta(list_0, str_0)


# Generated at 2022-06-25 16:13:07.779182
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = None
    str_0 = '"\nXFsU9#'
    DocstringReturns_0 = DocstringReturns(list_0, str_0, str_0, True)

# Generated at 2022-06-25 16:13:10.476275
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_0 = None
    description_0 = 'J8>'
    type_name_0 = '8'
    docstring_raises_0 = DocstringRaises(args_0, description_0, type_name_0)


# Generated at 2022-06-25 16:13:13.909691
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    str_0 = '"\nXFsU9#'
    list_0 = None
    docstring_raises_0 = DocstringRaises(list_0, str_0, "C1['|")


# Generated at 2022-06-25 16:13:15.051446
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:13:17.479260
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = None
    str_0 = '"\nXFsU9#'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_0)


# Generated at 2022-06-25 16:13:26.557054
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(args=['return'], type_name='str', is_generator=True, return_name=None)
    assert docstring_returns.description == None
    assert docstring_returns.type_name == 'str'
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name == None


# Generated at 2022-06-25 16:13:28.392772
# Unit test for constructor of class Docstring
def test_Docstring():
    print('Testing constructor of class Docstring...')
    test_case_0()

    

# Generated at 2022-06-25 16:13:40.582797
# Unit test for constructor of class DocstringRaises

# Generated at 2022-06-25 16:13:50.456019
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    str_0 = "arg"
    str_1 = "description"
    str_2 = "version"
    local_docstring_deprecated_0 = DocstringDeprecated(str_0, str_1, str_2)
    str_3 = local_docstring_deprecated_0.description
    str_4 = local_docstring_deprecated_0.version
    local_docstring_meta_0 = local_docstring_deprecated_0.args
    str_5 = str(local_docstring_meta_0)
    str_6 = local_docstring_meta_0.pop()
    int_0 = local_docstring_meta_0.index("arg")
    int_1 = len(local_docstring_meta_0)
    str_7 = local_docstring_meta_0.pop()


# Generated at 2022-06-25 16:13:56.813151
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    def test_case_0():
        args = ['param', 'arg', 'attribute', 'key', 'keyword', 'param', 'parameter', 'arg', 'argument']
        description = 'description'
        version = 'version'
        obj = DocstringDeprecated(args, description, version)
        assert obj


# Generated at 2022-06-25 16:13:59.414369
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """
    Test class DocstringDeprecated
    """
    with pytest.raises(TypeError):
        test_case_1()
    with pytest.raises(TypeError):
        test_case_2()
    with pytest.raises(TypeError):
        test_case_3()


# Generated at 2022-06-25 16:14:05.732305
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        test_case_0()
    except Exception:
        print("Exception caught in test_ParseError()")


# Generated at 2022-06-25 16:14:13.198383
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = None
    arg_name = "arg"
    type_name = None
    is_optional = None
    default = None
    d = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    d_arg = d.args
    d_description = d.description
    d_arg_name = d.arg_name
    d_type_name = d.type_name
    d_is_optional = d.is_optional
    d_default = d.default


# Generated at 2022-06-25 16:14:22.438183
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        output = DocstringReturns(['param', 'arg', 'argument', 'attribute', 'key', 'keyword',
                                 'raises', 'raise', 'except', 'exception', 'return', 'returns',
                                 'yield', 'yields'], 'Description', 'TypeName')
        if output.type_name == 'TypeName':
            pass
        else:
            raise Exception('Test failed')
    except Exception as e:
        print(e)


# Generated at 2022-06-25 16:14:29.202690
# Unit test for constructor of class Docstring
def test_Docstring():

    result_1 = Docstring()
    expected_1 = None
    assert result_1.short_description == expected_1
    assert result_1.long_description == expected_1
    assert result_1.blank_after_short_description == False
    assert result_1.blank_after_long_description == False
    assert result_1.meta == []



# Generated at 2022-06-25 16:14:37.677065
# Unit test for constructor of class ParseError
def test_ParseError():
    assert hasattr(ParseError, '__init__')
    assert ParseError.__init__.__doc__ is not None


# Generated at 2022-06-25 16:14:38.739293
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_case_0()

# Generated at 2022-06-25 16:14:40.296414
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_0()


# Generated at 2022-06-25 16:14:51.984281
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    str_0 = '\x1d\x1c\x16\x0f\x0e\x0d\x07\x06\x03\x02\x01\n\t\r\x0e\x0f'
    str_1 = '\x1d\x1c\x16\x0f'
    str_2 = '\x1d\x1c\x16\x0f\x0e\x0d\x07\x06\x03\x02\x01\n\t\r\x0e\x0f'
    str_3 = '\x1d\x1c\x16'

# Generated at 2022-06-25 16:14:59.326437
# Unit test for constructor of class Docstring
def test_Docstring():
    str_0 = '"\nXFsU9#'
    docstr1 = Docstring()
    assert docstr1.short_description == None
    assert docstr1.long_description == None
    assert docstr1.blank_after_short_description == False
    assert docstr1.blank_after_long_description == False
    assert docstr1.meta == []


# Generated at 2022-06-25 16:15:02.473531
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    str_0 = 'XAX6U'
    test_case_0(str_0)
    str_0 = 'BfZsU'


# Generated at 2022-06-25 16:15:13.875496
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Case-1 (Normal case)
    args_0 = ['arg1', 'arg2']
    description_0 = 'All good'
    version_0 = '1.0'
    d = DocstringDeprecated(args=args_0, description=description_0, version=version_0)
    if d.args != args_0: print('FAILED: test_DocstringDeprecated() case-1-1')
    if d.description != description_0: print('FAILED: test_DocstringDeprecated() case-1-1')
    if d.version != version_0: print('FAILED: test_DocstringDeprecated() case-1-1')

    # Case-2 (Abnormal case)
    args_0 = ['arg1', 'arg2']
    description_0 = 'All good'
    version

# Generated at 2022-06-25 16:15:19.238151
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # pylint: disable=missing-docstring
    # Setup
    arg_name = None
    type_name = None
    is_optional = None
    default = None
    docstring_param = DocstringParam(['param'], 'description', arg_name, type_name, is_optional, default)
    print('args:', docstring_param.args)
    print('description:', docstring_param.description)
    # Teardown


# Generated at 2022-06-25 16:15:24.668121
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = '"\nXFsU9#'
    description = '"\nXFsU9#'
    type_name = '"\nXFsU9#'
    is_generator = True
    return_name = '"\nXFsU9#'
    test = DocstringReturns(args, description, type_name, is_generator, return_name)


# Generated at 2022-06-25 16:15:32.956510
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test with args = ["param", "name"], description = "A nice function.", type_name = "Test"
    args_0 = ["param", "name"]
    description_0 = "A nice function."
    type_name_0 = "Test"
    docstring_raises_0 = DocstringRaises(args_0, description_0, type_name_0)
    assert docstring_raises_0.args == ["param", "name"]
    assert docstring_raises_0.description == "A nice function."
    assert docstring_raises_0.type_name == "Test"


# Generated at 2022-06-25 16:15:38.170322
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0( )


# Generated at 2022-06-25 16:15:41.442033
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    description = 'TZR0'
    args = [ '!', '!', '!', '!', '!', '!', '!', '!', '!', '!', '!' ]
    version = 'w1l'
    test_obj_0 = DocstringDeprecated(args, description, version)

# Generated at 2022-06-25 16:15:47.679809
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['description'], ['description'], ['description'])
    assert docstring_deprecated.description == ['description']
    assert docstring_deprecated.args == ['description']
    assert docstring_deprecated.version == ['description']


# Generated at 2022-06-25 16:15:48.723969
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:15:54.847714
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    str_0 = '"\nXFsU9#'
    list_0 = ['', '', '']
    test_case_0()
    # Constructor of class DocstringMeta
    test_docstringmeta = DocstringMeta(list_0, str_0)
    assert test_docstringmeta.args == list_0
    assert test_docstringmeta.description == str_0


# Generated at 2022-06-25 16:15:56.832690
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-25 16:16:01.123804
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [1, 2, 3, 4]
    description = "This is a test description"
    myObject = DocstringMeta(args, description)
    assert myObject.args == args, "The result is wrong"
    assert myObject.description == description, "The result is wrong" 


# Generated at 2022-06-25 16:16:02.003268
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringMeta(1,2)


# Generated at 2022-06-25 16:16:03.383622
# Unit test for constructor of class ParseError
def test_ParseError():
    runtime_error = RuntimeError()
    test_0 = ParseError(runtime_error)


# Generated at 2022-06-25 16:16:13.632557
# Unit test for constructor of class Docstring
def test_Docstring():
    str_0 = '"\nXFsU9#'
    d_0 = Docstring()
    assert d_0.short_description == None
    assert d_0.long_description == None
    assert d_0.blank_after_short_description == False
    assert d_0.blank_after_long_description == False
    assert d_0.meta == []

    test_case_0()
    test_DocstringMeta()
    test_DocstringParam()
    test_DocstringReturns()
    test_DocstringRaises()
    test_DocstringDeprecated()
    test_parse_docstring_type()
    test_parse_docstring()
    test_parse_type_var()

# Generated at 2022-06-25 16:16:18.622208
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert True



# Generated at 2022-06-25 16:16:20.374890
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()

#Unit test for constructor of class DocstringMeta

# Generated at 2022-06-25 16:16:22.149809
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()



# Generated at 2022-06-25 16:16:26.778796
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args_0 = ['param']
    description_0 = 'description'
    type_name_0 = 'int'
    is_generator_0 = False
    return_name_0 = 'retval'
    test_0 = DocstringReturns(args_0, description_0, type_name_0, is_generator_0, return_name_0)


# Generated at 2022-06-25 16:16:33.044218
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert not isinstance(DocstringReturns(['',''],None,None,None),DocstringReturns)
    assert isinstance(DocstringReturns(['param'], None, '', False), DocstringReturns)
    assert isinstance(DocstringReturns(['', ''], None, '', False), DocstringReturns)
    assert not isinstance(DocstringReturns(['', ''], '', '', False), DocstringReturns)
    assert isinstance(DocstringReturns(['', ''], None, '', True), DocstringReturns)
    assert not isinstance(DocstringReturns(['', ''], '', '', True), DocstringReturns)
    assert isinstance(DocstringReturns(['', ''], None, '', False, 'ReturnName'), DocstringReturns)

# Generated at 2022-06-25 16:16:35.306762
# Unit test for constructor of class ParseError
def test_ParseError():

    try:
        test_case_0()
    except Exception as err:
        print(err)



# Generated at 2022-06-25 16:16:37.092181
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    str_0 = '"\nXFsU9#'


# Generated at 2022-06-25 16:16:38.025653
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()

# Generated at 2022-06-25 16:16:42.410800
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()


# Generated at 2022-06-25 16:16:50.035103
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns([], "your docstring here", "str", "type_name", True, "return_name")

    # Assert type of docstring_returns.args
    assert isinstance(docstring_returns.args, list)
    # Assert type of docstring_returns.description
    assert isinstance(docstring_returns.description, str)
    # Assert type of docstring_returns.type_name
    assert isinstance(docstring_returns.type_name, str)
    # Assert type of docstring_returns.is_generator
    assert isinstance(docstring_returns.is_generator, bool)
    # Assert type of docstring_returns.return_name
    assert isinstance(docstring_returns.return_name, str)



# Generated at 2022-06-25 16:16:55.646832
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(Docstring())


# Generated at 2022-06-25 16:16:59.595339
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(args='', description=' ')


# Generated at 2022-06-25 16:17:02.076750
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(['parameter'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')


# Generated at 2022-06-25 16:17:02.973252
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-25 16:17:07.484614
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    line = ":return: a subtraction of b from a"
    words = line.split()
    docstringReturns_0 = DocstringReturns(words, "a subtraction of b from a", None, False)



# Generated at 2022-06-25 16:17:13.713966
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(
        [
            "metadata_0",
        ],
        "This is a valid docstring",
        "1.9",
    )
    assert docstring_deprecated_0.args[0] == 'metadata_0'
    assert docstring_deprecated_0.description == 'This is a valid docstring'
    assert docstring_deprecated_0.version == '1.9'


# Generated at 2022-06-25 16:17:16.839379
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_1 = DocstringParam(["param", "arg", "argument"], "Description", "arg", "str", True, "None")
    docstring_param_2 = DocstringParam([], "", "", "", False, "")


# Generated at 2022-06-25 16:17:19.726410
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(['return', 'returns'], "return description", "return type", True, "return name")


# Generated at 2022-06-25 16:17:22.249363
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["args"], "description")
    assert docstring_meta.args == ["args"]
    assert docstring_meta.description == "description"



# Generated at 2022-06-25 16:17:25.572357
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_test = Docstring()
    assert docstring_test.short_description is None
    assert docstring_test.long_description is None
    assert docstring_test.blank_after_short_description == False
    assert docstring_test.blank_after_long_description == False
    assert docstring_test.meta == []


# Generated at 2022-06-25 16:17:36.701564
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated", "since", "1.0"], "", "1.0")


# Generated at 2022-06-25 16:17:44.102666
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Case 0
    docstring_0 = Docstring()

    # Case 1
    docstring_1 = Docstring()
    docstring_1.short_description = "docstring_1"
    docstring_1.long_description = "docstring_1"
    docstring_1.blank_after_short_description = True
    docstring_1.blank_after_long_description = False
    docstring_1_deprecated = DocstringDeprecated(["docstring_1", "docstring_1", "0.1"], "docstring_1", "0.1")
    docstring_1.meta.append(docstring_1_deprecated)

    assert docstring_1.deprecation.version == "0.1"
    assert docstring_1.deprecation.description == "docstring_1"

# Generated at 2022-06-25 16:17:47.195839
# Unit test for constructor of class ParseError
def test_ParseError():
    assert (isinstance(ParseError(), RuntimeError))



# Generated at 2022-06-25 16:17:51.242670
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated = DocstringDeprecated(["deprecated:", "deprecated"], "description", version="version")
    assert isinstance(DocstringDeprecated, DocstringDeprecated)
    return DocstringDeprecated


# Generated at 2022-06-25 16:18:01.454916
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_DocstringParam = DocstringParam(["param", "arg", "attribute", "key", "keyword"],
                                   "the color of the car",
                                   "color",
                                   "str",
                                   True,
                                   "black")
    assert test_DocstringParam.args == ["param", "arg", "attribute", "key", "keyword"]
    assert test_DocstringParam.description == "the color of the car"
    assert test_DocstringParam.arg_name == "color"
    assert test_DocstringParam.type_name == "str"
    assert test_DocstringParam.is_optional == True
    assert test_DocstringParam.default == "black"
    assert test_DocstringParam.args == ["param", "arg", "attribute", "key", "keyword"]
    assert test_Docstring

# Generated at 2022-06-25 16:18:05.612325
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    assert (docstring_1.short_description == None)
    assert (docstring_1.long_description == None)
    assert (docstring_1.blank_after_short_description == False)
    assert (docstring_1.blank_after_long_description == False)
    assert (docstring_1.meta == [])
    print("Test for constructor of class Docstring completed")


# Generated at 2022-06-25 16:18:08.335539
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns('args', 'description', 'type_name', 'is_generator', 'return_name')

# Testing class DocstringReturns

# Generated at 2022-06-25 16:18:11.236290
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'description']
    description = 'description'
    docstring_meta_0 = DocstringMeta(args, description)


# Generated at 2022-06-25 16:18:14.566653
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=['param'], description='description', arg_name='arg', type_name='Optional[int]', is_optional=False, default='None')


# Generated at 2022-06-25 16:18:17.283603
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = test_case_0()
    assert isinstance(docstring_1, Docstring)
    assert docstring_1.__init__() == None


# Generated at 2022-06-25 16:18:39.260990
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []



# Generated at 2022-06-25 16:18:47.816787
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_0 = ['param']
    description_0 = 'description'
    arg_name_0 = 'arg'
    type_name_0 = 'type'
    is_optional_0 = True
    default_0 = 'value'

    assert isinstance(DocstringParam(args_0,description_0,arg_name_0,type_name_0,is_optional_0,default_0),DocstringParam)


# Generated at 2022-06-25 16:18:50.972188
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', False, 'default')


# Generated at 2022-06-25 16:18:52.361529
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "description")


# Generated at 2022-06-25 16:18:53.850206
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(["return"], "", "", False)


# Generated at 2022-06-25 16:18:58.656190
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam([], "", "", "", "")
    assert len(param.args) == 0
    assert param.description == ""
    assert param.arg_name == ""
    assert param.type_name == ""
    assert param.is_optional == ""
    assert param.default == ""


# Generated at 2022-06-25 16:19:00.704294
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:19:02.040764
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()



# Generated at 2022-06-25 16:19:06.083391
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert not docstring.long_description
    assert not docstring.short_description
    assert not docstring.blank_after_long_description
    assert not docstring.blank_after_short_description
    assert not docstring.meta

# Generated at 2022-06-25 16:19:07.565894
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # test 0
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:20:01.103240
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    
    docstring_0 = DocstringReturns(["return", "returns"], "a", "int", False)
    docstring_1 = DocstringReturns(["return", "returns"], "a", "int", True)
    docstring_2 = DocstringReturns(["return", "returns"], "", "int", False)
    docstring_3 = DocstringReturns(["return", "returns"], "", "int", False, "")
    docstring_4 = DocstringReturns(["return", "returns"], "a", None, False)
    docstring_5 = DocstringReturns(["return", "returns"], "a", None, True)
    docstring_6 = DocstringReturns(["return", "returns"], "a", None, False, "")

# Generated at 2022-06-25 16:20:02.581509
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_0 = DocstringRaises([], None, None)


# Generated at 2022-06-25 16:20:04.403910
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(['arg','description'],'description','arg_name','type_name',True,'default')


# Generated at 2022-06-25 16:20:06.610486
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args_0 = []
    description_0 = "no description"
    version_0 = "0.0.1"
    test_0 = DocstringDeprecated(args_0, description_0, version_0)


# Generated at 2022-06-25 16:20:10.649556
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(args = ["returns"],
                                         description = "This function returns nothing",
                                         type_name = "None",
                                         is_generator = False,
                                         return_name = "None")


# Generated at 2022-06-25 16:20:11.794654
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert(error is not None)


# Generated at 2022-06-25 16:20:14.226233
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises(args="Arg",description="description",type_name="type")


# Generated at 2022-06-25 16:20:19.810716
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "initalize self"
    arg_name = "self"
    type_name = "None"
    is_optional = None
    default = None
    test_case_1 = DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-25 16:20:31.841981
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_new_0 = ['A','D']
    description_new_0 = "This is the description of the DocstringRaises"
    type_name_new_0 = "A"
    docstringRaises_0 = DocstringRaises(args_new_0,description_new_0,type_name_new_0)
    assert docstringRaises_0.args == ['A','D']
    assert docstringRaises_0.description == "This is the description of the DocstringRaises"
    assert docstringRaises_0.type_name == "A"


# Generated at 2022-06-25 16:20:32.601382
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:22:09.801813
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(
        [], None, None
    )



# Generated at 2022-06-25 16:22:11.357660
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:22:13.099596
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass


# Generated at 2022-06-25 16:22:21.453002
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    docstring_0.short_description = "Docstring description with no blank lines after short description"
    docstring_0.long_description = "This is the long description of the Docstring"
    docstring_0.blank_after_short_description = False
    docstring_0.blank_after_long_description = False
    for meta in docstring_0.meta:
        # print(meta.args[0])
        if meta.args[0] == "param":
            print("Parameter name: " + meta.arg_name)
            print("Description: " + meta.description)
        if meta.args[0] == "raises":
            print("Exception: " + meta.type_name)
            print("Description: " + meta.description)

# Generated at 2022-06-25 16:22:23.071044
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam([0,0], 0,'arg_name',0,0,0)


# Generated at 2022-06-25 16:22:27.113954
# Unit test for constructor of class Docstring
def test_Docstring():

    docstring_0 = Docstring()
    assert docstring_0 != None

    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:22:30.022572
# Unit test for constructor of class ParseError
def test_ParseError():
    error_msg = "An Error Occurred"
    error = ParseError(error_msg)
    assert error.args[0] == error_msg


# Generated at 2022-06-25 16:22:35.962990
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Case 0
    # Empty constructor
    docstring_param_0 = DocstringParam([], "")
    # Case 1
    # Constructor with value
    docstring_param_1 = DocstringParam(["param"], "This is a parameter")
    # Case 2
    # Constructor with value
    docstring_param_2 = DocstringParam(["param", "attribute"], "This is a parameter")
