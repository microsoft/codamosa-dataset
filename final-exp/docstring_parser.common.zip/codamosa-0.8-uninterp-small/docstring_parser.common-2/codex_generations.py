

# Generated at 2022-06-25 16:12:42.118571
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:12:50.582250
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_prop = ["Args:", "param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description_prop = ["My description"]
    type_name_prop = ["My type"]
    test_instance_prop = DocstringRaises(args_prop, description_prop, type_name_prop)
    args_result = test_instance_prop.args
    assert args_result == ["Args:", "param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description_result = test_instance_prop.description
    assert description_result == ["My description"]
    type_name_result = test_instance_prop.type_name
    assert type_name_result == ["My type"]

# Generated at 2022-06-25 16:13:02.444535
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []
    docstring_1 = Docstring()
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []
    docstring_2 = Docstring()
    assert docstring_2.short_description == None
    assert docstring_2.long_description == None
   

# Generated at 2022-06-25 16:13:05.667357
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(args = ["Symbolizes"], description = "lines")
    assert docstring_meta.args == ["Symbolizes"]
    assert docstring_meta.description == "lines"


# Generated at 2022-06-25 16:13:06.960147
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated([], None, None)


# Generated at 2022-06-25 16:13:12.886292
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test case 0
    args_0 = ["deprecated"]
    description_0 = "There is a better way."
    version_0 = "2.0.0"
    try:
        docstring_deprecated_0 = DocstringDeprecated(
            args_0, description_0, version_0
        )
    except Exception:
        print("Exception thrown while unit testing function")
        raise
    assert docstring_deprecated_0.args == args_0
    assert docstring_deprecated_0.description == description_0
    assert docstring_deprecated_0.version == version_0


# Generated at 2022-06-25 16:13:15.919464
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_returns_0 = DocstringReturns(["return", "returns"], "Returns something", None, False)
    assert isinstance(docstring_returns_0, DocstringMeta)


# Generated at 2022-06-25 16:13:17.371359
# Unit test for constructor of class ParseError
def test_ParseError():
    result = ParseError("test")
    assert "test" == result.args[0]


# Generated at 2022-06-25 16:13:21.603392
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=[":param"],
                          description="The first parameter.",
                          arg_name="a",
                          type_name=None,
                          is_optional=False,
                          default=None)
    assert DocstringParam(args=[":param"],
                          description="The second parameter.",
                          arg_name="b",
                          type_name=None,
                          is_optional=False,
                          default=None)
    # Add a new method here to test all the constructor methods in DocstringParam.


# Generated at 2022-06-25 16:13:26.178800
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "arg description") == DocstringMeta(["param"], "arg description")
    assert DocstringMeta(["param"], "arg description") != DocstringMeta(["parameter"], "arg description")
    assert DocstringMeta(["param"], "arg description") != DocstringMeta(["param"], "arg description.")


# Generated at 2022-06-25 16:13:31.956059
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1=Docstring()
    assert not docstring_1.returns


# Generated at 2022-06-25 16:13:34.208058
# Unit test for constructor of class ParseError
def test_ParseError():
    error_0 = ParseError()
    error_0.__init__()


# Generated at 2022-06-25 16:13:35.320054
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError()


# Generated at 2022-06-25 16:13:38.054326
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_0 = DocstringReturns(["return","returns"], "Return", "Type", True)


# Generated at 2022-06-25 16:13:41.345587
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_0 = []
    description_0 = None
    type_name_0 = None
    sample_0 = DocstringRaises(args_0, description_0, type_name_0)


# Generated at 2022-06-25 16:13:48.121120
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    params = ['param', 'parameter', 'arg', 'argument']
    desc = 'description'
    type_name = 'an_int'
    is_generator = False
    ret_obj = DocstringReturns(params, desc, type_name, is_generator)
    assert ret_obj.description == desc
    assert ret_obj.type_name == type_name
    assert ret_obj.is_generator == is_generator
    assert ret_obj.args == params


# Generated at 2022-06-25 16:13:55.774950
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    


# Generated at 2022-06-25 16:13:58.463185
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([], "Test", "arg", "str", False, "None")
    # Asserting the test object
    assert isinstance(docstring_param, DocstringParam)


# Generated at 2022-06-25 16:14:04.486663
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = 'This function is used to find sum of two numbers'
    type_name = 'int'
    test_DocstringRaises0 = DocstringRaises(
        args, description, type_name)


# Generated at 2022-06-25 16:14:09.529934
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_description0 = DocstringDeprecated(['deprecated'], '', '0.0')
    assert docstring_description0.args == ['deprecated']
    assert docstring_description0.description == ''
    assert docstring_description0.version == '0.0'



# Generated at 2022-06-25 16:14:23.064046
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:14:23.824034
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:14:29.550354
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_meta_deprecated = DocstringDeprecated(args=['Raises'],description="raised if....",version="1.0")
    assert isinstance(docstring_meta_deprecated, DocstringMeta)


# Generated at 2022-06-25 16:14:36.318393
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test 1.
    docstring_meta = DocstringRaises(
        args=['raises', 'ValueError'],
        description='if something happens',
        type_name='ValueError'
    )
    assert docstring_meta is not None
    assert docstring_meta.args == ['raises', 'ValueError']
    assert docstring_meta.description == 'if something happens'
    assert docstring_meta.type_name == 'ValueError'


# Generated at 2022-06-25 16:14:37.886181
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns([], None, None, None)


# Generated at 2022-06-25 16:14:45.547004
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(['param'], 'description of docstring','int', True)
    assert docstring_returns_0.args == ['param']
    assert docstring_returns_0.description == 'description of docstring'
    assert docstring_returns_0.type_name == 'int'
    assert docstring_returns_0.is_generator == True


# Generated at 2022-06-25 16:14:50.398496
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(
        args=["deprecated"], description="Some other description", version=None
    )
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description is None
    assert docstring_deprecated.version is None
    assert isinstance(docstring_deprecated, DocstringMeta)


# Generated at 2022-06-25 16:14:55.002624
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(
        args=['deprecated'], description='This is a deprecated', version='0.1')

    assert (docstring_deprecated.args == ['deprecated'])
    assert (docstring_deprecated.description == 'This is a deprecated')
    assert (docstring_deprecated.version == '0.1')


# Generated at 2022-06-25 16:15:07.338031
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam_0 = DocstringParam(args=list([]), description=None, arg_name="arg_name0", type_name=None, is_optional=None, default=None)
    assert docstringParam_0 is not None
    assert len(docstringParam_0.args) == 0
    assert docstringParam_0.description is None
    assert docstringParam_0.arg_name == "arg_name0"
    assert docstringParam_0.type_name is None
    assert docstringParam_0.is_optional is None
    assert docstringParam_0.default is None
    docstringParam_0.args = list([])
    docstringParam_0.description = None
    docstringParam_0.arg_name = "arg_name0"
    docstringParam_0.type_name = None


# Generated at 2022-06-25 16:15:12.486807
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0


# Generated at 2022-06-25 16:15:30.152480
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta("a", "b")
        assert True
    except:
        assert False
		

# Generated at 2022-06-25 16:15:33.566862
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta_0 = DocstringMeta(['param', 'arg', 'key', 'attribute'], 'description')
    assert meta_0.args == ['param', 'arg', 'key', 'attribute']
    assert meta_0.description == 'description'



# Generated at 2022-06-25 16:15:36.095837
# Unit test for constructor of class ParseError
def test_ParseError():
    _ = ParseError("Test")
    pass


# Generated at 2022-06-25 16:15:43.440234
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arg_list = ['arg1', 'arg2']
    desc = "This is a test case"
    type_name = "int"
    is_gen = True
    ret_name = "return"

    try:
        # Case with all args
        docstring_0 = DocstringReturns(arg_list, desc, type_name, is_gen,
                                                                ret_name)
    except:
        print("Error: test_DocstringReturns 0 failed")

    try:
        # Case with minimum args
        docstring_0 = DocstringReturns(arg_list, None, None, is_gen)
    except:
        print("Error: test_DocstringReturns 1 failed")


# Generated at 2022-06-25 16:15:48.909663
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    type_name = None # type: T.Optional[str]
    description = "Error description"
    args = ["param", "arg", "argument", ":raises"]
    item_0 = DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:15:50.748712
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        DocstringDeprecated(args=[], description="", version="2.0")
    except:
        raise



# Generated at 2022-06-25 16:15:54.215740
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Some message")
    except ParseError:
        pass
    else:
        assert False


# Generated at 2022-06-25 16:16:00.255320
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    return docstring_0


# Generated at 2022-06-25 16:16:02.781937
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        DocstringDeprecated(args=None, description=None, version=None)
    except Exception:
        print("Error: Exception raised when constructing a DocstringDeprecated instance")
        assert False


# Generated at 2022-06-25 16:16:10.133808
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = "Deleting a DAG does not delete the tasks and pools associated with it."
    type_name = None
    obj = DocstringRaises(args, description, type_name)
    assert obj.args == args
    assert obj.description == description
    assert obj.type_name == type_name



# Generated at 2022-06-25 16:16:27.957503
# Unit test for constructor of class ParseError
def test_ParseError():
    error_msg = 'Parsing error'
    exc_obj = ParseError(error_msg)
    assert exc_obj.args[0] == error_msg


# Generated at 2022-06-25 16:16:29.094813
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_1 = Do

# Generated at 2022-06-25 16:16:30.160448
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(args = [], description = "")


# Generated at 2022-06-25 16:16:34.871814
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["version"]
    description = "description"
    version = "version"

    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-25 16:16:44.442570
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    class TestDocstringMeta:

        def __init__(self, args: T.List[str], description: str) -> None:
            """Initialize self.

            :param args: list of arguments. The exact content of this variable is
                         dependent on the kind of docstring; it's used to distinguish between
                         custom docstring meta information items.
            :param description: associated docstring description.
            """
            self.args = args
            self.description = description

    docstring_meta = DocstringMeta(['a', 'b'], 'c')
    test_docstring_meta = TestDocstringMeta(['a', 'b'], 'c')


# Generated at 2022-06-25 16:16:48.501143
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['raises', 'ValueError'], "Test description", 'ValueError')
    assert docstring_raises.args == ['raises', 'ValueError']
    assert docstring_raises.description == "Test description"
    assert docstring_raises.type_name == 'ValueError'


# Generated at 2022-06-25 16:16:50.745861
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg']
    description = 'description'
    variable = DocstringMeta(args, description)
    assert variable.args == ['param', 'arg']
    assert variable.description == 'description'


# Generated at 2022-06-25 16:16:54.214216
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["raises"], "description", "type_name")
    assert docstring_raises.type_name == "type_name"
    assert docstring_raises.description == "description"


# Generated at 2022-06-25 16:16:59.307824
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["return", "returns"],
                                         "Returns a new string object containing a copy of the value.",
                                         "str:", True, "test")
    assert docstring_returns.args == ["return", "returns"]
    assert docstring_returns.description == "Returns a new string object containing a copy of the value."
    assert docstring_returns.type_name == "str:"
    assert docstring_returns.is_generator is True
    assert docstring_returns.return_name == "test"



# Generated at 2022-06-25 16:17:01.213914
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam([],None, "arg_name", None, None, None)


# Generated at 2022-06-25 16:17:18.927247
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:17:21.914614
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(['raises', 'TypeError', ':'], 'this is a test', 'TypeError')
    assert (x.args) == ['raises', 'TypeError', ':']
    assert (x.description) == 'this is a test'
    assert (x.type_name) == 'TypeError'
    y = DocstringRaises(['raises', 'ValueError', ':'], 'this is a test', 'ValueError')
    assert (y.args) == ['raises', 'ValueError', ':']
    assert (y.description) == 'this is a test'
    assert (y.type_name) == 'ValueError'


# Generated at 2022-06-25 16:17:28.285166
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(param_list0, description0, param_list1=param_list1)
    docstring_returns_1 = DocstringReturns(param_list0, description0, param_list1=param_list1)
    assert docstring_returns_0.args is docstring_returns_1.args
    assert docstring_returns_0.description is docstring_returns_1.description
    assert docstring_returns_0.type_name is docstring_returns_1.type_name
    assert docstring_returns_0.is_generator is docstring_returns_1.is_generator
    assert docstring_returns_0.return_name is docstring_returns_1.return_name


# Generated at 2022-06-25 16:17:31.515059
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:17:34.186177
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    parse_param_meta(['param', 'a', ':', 'int', ':', 'a descrip'])


# Generated at 2022-06-25 16:17:35.002584
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = 'Test'
    ex = ParseError(msg)
    assert str(ex) == 'Test'



# Generated at 2022-06-25 16:17:37.404284
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns_0 = DocstringReturns(args, description, type_name, is_generator, return_name)


# Generated at 2022-06-25 16:17:38.669334
# Unit test for constructor of class ParseError
def test_ParseError():    
    parse_error = ParseError("Error: A runtime error")


# Generated at 2022-06-25 16:17:42.064773
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-25 16:17:46.994419
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert type(docstring_1.meta) == list



# Generated at 2022-06-25 16:18:06.038078
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# TODO: add function test cases

# Generated at 2022-06-25 16:18:07.419371
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([], None, None)


# Generated at 2022-06-25 16:18:11.979026
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "")
    DocstringMeta(["returns"], "")
    DocstringMeta(["yields"], "")
    DocstringMeta(["raises"], "")
    DocstringMeta(["deprecated"], "")
    DocstringMeta(["some_other_meta"], "")


# Generated at 2022-06-25 16:18:20.283389
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        ['returns', 'return'], 'None.', 'None', False, 'value'
    )
    assert docstring_returns.args == ['returns', 'return']
    assert docstring_returns.description == 'None.'
    assert docstring_returns.type_name == 'None'
    assert not docstring_returns.is_generator
    assert docstring_returns.return_name == 'value'


# Generated at 2022-06-25 16:18:21.614735
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta([], "")

DocstringMeta([], "")


# Generated at 2022-06-25 16:18:28.131873
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp_0 = DocstringParam(['param', 'name'], 'This is a name', 'name', None, None, None)
    assert dp_0.args[0] == 'param'
    assert dp_0.args[1] == 'name'
    assert dp_0.description == 'This is a name'
    assert dp_0.arg_name == 'name'
    assert dp_0.type_name == None
    assert dp_0.is_optional == None
    assert dp_0.default == None


# Generated at 2022-06-25 16:18:32.916704
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['Return', '200', 'if', 'document', 'found']
    description = "return"
    type_name = "hello"
    assert DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:18:39.659085
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns([], None, None, False)
    assert d.args == []
    assert d.description is None
    assert d.type_name is None
    assert d.is_generator == False
    assert d.return_name is None

    d = DocstringReturns([], None, "str", True)
    assert d.args == []
    assert d.description is None
    assert d.type_name == "str"
    assert d.is_generator == True
    assert d.return_name is None


# Generated at 2022-06-25 16:18:42.568215
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta("args", "description")


# Generated at 2022-06-25 16:18:48.175141
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises([], "description", "keyword")
    if not isinstance(docstringRaises, DocstringRaises) or not isinstance(docstringRaises, DocstringMeta) or docstringRaises.type_name != "keyword":
        raise Exception("Not true")


# Generated at 2022-06-25 16:19:29.352075
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

if __name__ == "__main__":
    test_Docstring()



# Generated at 2022-06-25 16:19:30.186215
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()


# Generated at 2022-06-25 16:19:32.415563
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated([], "", "")


# Generated at 2022-06-25 16:19:38.804446
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["version"]
    description = "This is deprecated"
    version = "1.0"
    docstring_deprecated_0 = DocstringDeprecated(args, description, version)
    assert docstring_deprecated_0.args == ["version"]
    assert docstring_deprecated_0.description == "This is deprecated"
    assert docstring_deprecated_0.version == "1.0"


# Generated at 2022-06-25 16:19:45.191107
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    my_docstring_param = DocstringParam(args=['arg:', 'description'],
                                        description='description',
                                        arg_name='arg',
                                        type_name=None,
                                        is_optional=False,
                                        default=None
                                        )
    assert my_docstring_param.args == ['arg:', 'description']
    assert my_docstring_param.description == 'description'
    assert my_docstring_param.arg_name == 'arg'
    assert my_docstring_param.type_name is None
    assert my_docstring_param.is_optional is False
    assert my_docstring_param.default is None



# Generated at 2022-06-25 16:19:48.494875
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(["a", "b"], "c", "d")


# Generated at 2022-06-25 16:19:50.769811
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param"], "descriptionsss")


# Generated at 2022-06-25 16:19:54.486498
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([], None, "arg_name", None, False, None)
    if docstring_param.arg_name == None or docstring_param.default == False:
        return False
    return True


# Generated at 2022-06-25 16:19:59.621221
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    type_name = "ValueError"
    args = ['raises', 'Raises', 'Raise', 'raise', 'Except', 'except', 'Exception', 'exception']
    description = "Description of error"
    docstring_raises = DocstringRaises(args, description, type_name)



# Generated at 2022-06-25 16:20:01.643086
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam("args", "description", "arg_name", None, None, None)


# Generated at 2022-06-25 16:21:32.901986
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam is DocstringParam


# Generated at 2022-06-25 16:21:37.807038
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as e:
        assert True


# Generated at 2022-06-25 16:21:42.054423
# Unit test for constructor of class Docstring
def test_Docstring():
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:21:47.044917
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args = ['param'], description = 'hello', arg_name = 'x', type_name = 'int', is_optional = True, default = '3')
    assert docstring_param.args == ['param']
    assert docstring_param.description == 'hello'
    assert docstring_param.arg_name == 'x'
    assert docstring_param.type_name == 'int'
    assert docstring_param.is_optional == True
    assert docstring_param.default == '3'



# Generated at 2022-06-25 16:21:57.345060
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    with pytest.raises(TypeError):
        DocstringReturns()
        DocstringReturns(type_name="int", is_generator=False, return_name="return")
    with pytest.raises(TypeError):
        DocstringReturns(args=["returns"], description="This is a test", type_name="int", return_name="return")
    with pytest.raises(TypeError):
        DocstringReturns(args=["returns"], description="This is a test", return_name="return")
    with pytest.raises(TypeError):
        DocstringReturns(args=["returns"], description="This is a test", type_name="int")
    with pytest.raises(TypeError):
        DocstringReturns(args=["returns"], description="This is a test", is_generator=False)
   

# Generated at 2022-06-25 16:22:03.653290
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["returns"], "None", "None", True)
    b = DocstringReturns(["returns"], "None", "None", False)
    c = DocstringReturns(["returns"], "None", "None", False, "None")


# Generated at 2022-06-25 16:22:05.361641
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns([], "", None, True, None)


# Generated at 2022-06-25 16:22:06.112375
# Unit test for constructor of class ParseError
def test_ParseError():
    assert True


# Generated at 2022-06-25 16:22:08.046113
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()

test_ParseError()
test_case_0()

# Generated at 2022-06-25 16:22:18.683072
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    >>> docstring = Docstring()
    >>> docstring.short_description == None
    True
    >>> docstring.long_description == None
    True
    >>> docstring.blank_after_short_description == False
    True
    >>> docstring.blank_after_long_description == False
    True
    >>> docstring.meta == []
    True
    """
    docstring_0 = Docstring()
    docstring_0.short_description = None
    docstring_0.long_description = None
    docstring_0.blank_after_short_description = False
    docstring_0.blank_after_long_description = False
    docstring_0.meta = []

    print("Function test_Docstring passed.")
    # return True

test_Docstring()
