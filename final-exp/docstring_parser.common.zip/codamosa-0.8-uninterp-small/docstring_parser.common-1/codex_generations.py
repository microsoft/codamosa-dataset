

# Generated at 2022-06-25 16:12:42.515898
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()


# Generated at 2022-06-25 16:12:45.972144
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()
    parse_error_1 = ParseError("test_message")
    parse_error_2 = ParseError("test_message", "test_description")



# Generated at 2022-06-25 16:12:51.862762
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    input_args = ["returns", "returns/DocstringReturns(input_args,input_description,input_type_name,input_is_generator,input_return_name)"]
    input_description = "test1"
    input_type_name = "test2"
    input_is_generator = 1
    input_return_name = "test3"
    expect_return = DocstringReturns(input_args, input_description, input_type_name, input_is_generator, input_return_name)
    assert input_args == expect_return.args
    assert input_description == expect_return.description
    assert input_type_name == expect_return.type_name
    assert input_is_generator == expect_return.is_generator
    assert input_return_name == expect_return.return_

# Generated at 2022-06-25 16:12:53.709325
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["x"], "description", "arg_name", "type_name", "True", "None")


# Generated at 2022-06-25 16:13:04.041145
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for :any:`DocstringDeprecated`."""
    #
    # Create a test DocstringDeprecated instance and verify if the attributes have the expected values

# Generated at 2022-06-25 16:13:07.862580
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assertDocstringRaises = DocstringRaises([], [], [])
    assert not isinstance(assertDocstringRaises, DocstringParam)
    assert not isinstance(assertDocstringRaises, DocstringReturns)
    assert not isinstance(assertDocstringRaises, DocstringDeprecated)


# Generated at 2022-06-25 16:13:09.291877
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_1 = ParseError()


# Generated at 2022-06-25 16:13:13.474046
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert_docstringreturn = DocstringReturns(
        args = [],
        description = 'test description',
        type_name = 'test_type_name',
        is_generator = True,
        return_name = 'test_return_name',
    )


# Generated at 2022-06-25 16:13:14.398777
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:13:16.236560
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([], "")
    assert a.args == []
    assert a.description == ""


# Generated at 2022-06-25 16:13:26.812146
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], 'description of param', 'param_name', 'param_type', True, 'param_default')
    assert docstring_param.args == ['param']
    assert docstring_param.description == 'description of param'
    assert docstring_param.arg_name == 'param_name'
    assert docstring_param.type_name == 'param_type'
    assert docstring_param.is_optional == True
    assert docstring_param.default == 'param_default'


# Generated at 2022-06-25 16:13:34.477643
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['param']
    description = 'This is a parameter.'
    type_name = 'int'
    is_generator = False
    return_name = 'ret'
    test1 = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test1.args == ['param']
    assert test1.description == 'This is a parameter.'
    assert test1.type_name == 'int'
    assert test1.is_generator == False
    assert test1.return_name == 'ret'

# Generated at 2022-06-25 16:13:38.055289
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        test_case_0()
    except ParseError:
        print("ParseError")

if __name__ == "__main__":
    test_DocstringParam()

# Generated at 2022-06-25 16:13:38.904772
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["arg1", "arg2"], "description", "typeName")


# Generated at 2022-06-25 16:13:41.393319
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns_0 = DocstringReturns(["param"], "description", "type_name", True, "return_name")


# Generated at 2022-06-25 16:13:48.734428
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    par_args = ["param", "arg_name", "type_name", "is_optional", "default"]
    par = DocstringParam(par_args, "description", "arg_name", "type_name", "is_optional", "default")
    assert par.args == par_args
    assert par.description == "description"
    assert par.arg_name == "arg_name"
    assert par.type_name == "type_name"
    assert par.is_optional == "is_optional"
    assert par.default == "default"


# Generated at 2022-06-25 16:13:51.456611
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['param'], 'description', 'int', True)


# Generated at 2022-06-25 16:13:56.176799
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert isinstance(ds, Docstring)
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.meta == []




# Generated at 2022-06-25 16:14:03.229349
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated.__init__.__annotations__['args'] == T.List[str]
    assert DocstringDeprecated.__init__.__annotations__['description'] == T.Optional[str]
    assert DocstringDeprecated.__init__.__annotations__['version'] == T.Optional[str]
    docstring_deprecated_0 = DocstringDeprecated(['args'], 'description', 'version')
    assert docstring_deprecated_0.args == ['args']
    assert docstring_deprecated_0.description == 'description'
    assert docstring_deprecated_0.version == 'version'
    assert docstring_deprecated_0.description == 'description'


# Generated at 2022-06-25 16:14:10.197130
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None



# Generated at 2022-06-25 16:14:17.923082
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()


# Generated at 2022-06-25 16:14:23.366594
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['a', 'b']
    description = 'c'
    type_name = 'd'
    test_raises = DocstringRaises(args, description, type_name)
    assert test_raises.args == args
    assert test_raises.description == description
    assert test_raises.type_name == type_name


# Generated at 2022-06-25 16:14:30.904286
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = Docstring()
    # params given as arguments of class DocstringParam
    docstring.meta = [
        DocstringParam(
            args=["param"],
            description=None,
            arg_name="arg",
            type_name=None,
            is_optional=None,
            default=None,
        )
    ]



# Generated at 2022-06-25 16:14:32.255753
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args=[], description="", type_name="", is_generator=True, return_name="")


# Generated at 2022-06-25 16:14:34.639307
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['arg'], 'raising errors', 'ValueError')
    DocstringRaises(['arg'], 'raising errors', None)


# Generated at 2022-06-25 16:14:37.997638
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam_0 = DocstringParam(
        ["param", "arg", "description"], "value", "value", "value", True, "value"
    )


# Generated at 2022-06-25 16:14:39.699601
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert test_case_0


# Generated at 2022-06-25 16:14:45.815896
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Create DocstringReturns for unit test."""
    return_object = DocstringReturns(["returns"], "Return a number", "int")
    assert return_object.args == ["returns"]
    assert return_object.description == "Return a number"
    assert return_object.type_name == "int"


# Generated at 2022-06-25 16:14:49.892832
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_string = ':type f: str'
    test_args = test_string.split()
    test = DocstringDeprecated(test_args, 'description', 'version')
    assert test.args == test_args
    assert test.description == 'description'
    assert test.version == 'version'


# Generated at 2022-06-25 16:14:53.184580
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test standard DocstringMeta object
    test_args = ["param", "arg", "description"]
    test_description = "test description"
    test_object = DocstringMeta(test_args, test_description)
    assert test_object.args == test_args
    assert test_object.description == test_description

    # Test changing each variable
    test_args = ["param", "arg", "description", "test"]
    test_description = "test description\n"
    test_object = DocstringMeta(test_args, test_description)
    assert test_object.args == test_args
    assert test_object.description == test_description


# Generated at 2022-06-25 16:14:58.161767
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:15:01.828116
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(
        ['param'],
        'description',
        'arg_name',
        'type_name',
        False,
        'default'
    )


# Generated at 2022-06-25 16:15:02.978839
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:15:05.938884
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring0 = DocstringDeprecated(['type', 'description'], 'description', 'description')
    assert docstring0.description == 'description'


# Generated at 2022-06-25 16:15:06.848096
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-25 16:15:10.745483
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        dsr = DocstringReturns(['yield', 'yields'], 'test description', 'test type', False)
    except Exception:
        raise RuntimeError('test DocstringReturns failed')


# Generated at 2022-06-25 16:15:14.821281
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['keyword']
    description = 'meta description'
    test_case_1 = DocstringMeta(args, description)
    assert test_case_1.args == ['keyword']
    assert test_case_1.description == 'meta description'


# Generated at 2022-06-25 16:15:18.539905
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated", "since", "2.0"], "", "2.0")
    assert d.args == ["deprecated", "since", "2.0"]
    assert d.description == ""
    assert d.version == "2.0"


# Generated at 2022-06-25 16:15:21.540039
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises([], "", "")
    assert docstring_raises.args == []
    assert docstring_raises.description == ""
    assert docstring_raises.args == []


# Generated at 2022-06-25 16:15:27.578037
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    params = ["param", "arg", "argument", "attribute", "key"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = "default"
    docstring_param = DocstringParam(params, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-25 16:15:36.671550
# Unit test for constructor of class ParseError
def test_ParseError():
    _ = ParseError('test')


# Generated at 2022-06-25 16:15:38.260348
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_1()
    test_case_2()
    test_case_3()


# Generated at 2022-06-25 16:15:43.260079
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        StringIO("This is a StringIO object")
    except BaseException as e:
        assert isinstance(e, ParseError)

# Generated at 2022-06-25 16:15:46.727224
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(['arg'], 'description')


# Generated at 2022-06-25 16:15:50.887918
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(msg=None)
    ParseError(msg='')
    ParseError(msg='msg')
    ParseError('msg')


# Generated at 2022-06-25 16:16:01.580950
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Case 0: Initialize: two parameters
    ds_0 = DocstringReturns(["return", "type"], "Descriptions", "type_name")
    assert ds_0.args == ["return", "type"]
    assert ds_0.description == "Descriptions"
    assert ds_0.type_name == "type_name"
    
    # Case 1: Initialize: one parameter
    ds_1 = DocstringReturns(["return"], "Descriptions", None)
    assert ds_1.args == ["return"]
    assert ds_1.description == "Descriptions"
    assert ds_1.type_name is None


# Generated at 2022-06-25 16:16:07.622541
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args_0 = ["test1", "test2", "test3"]
    description_0 = "test"
    version_0 = "test"
    test_0 = DocstringDeprecated(args_0, description_0, version_0)
    return test_0.args, test_0.description, test_0.version


# Generated at 2022-06-25 16:16:13.149308
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Create a DocstringRaises object
    DocstringRaises()



# Generated at 2022-06-25 16:16:15.920800
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(["param", "parameter"], "description", "arg", "type name", "is optional", "default")


# Generated at 2022-06-25 16:16:17.645865
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError as e:
        assert isinstance(e, ParseError)


# Generated at 2022-06-25 16:16:38.278296
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-25 16:16:42.666817
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["test1", "test2"]
    description = "test description"
    expected = DocstringMeta(args, description)
    assert expected.args == args
    assert expected.description == description


# Generated at 2022-06-25 16:16:43.712619
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "desc")


# Generated at 2022-06-25 16:16:50.282616
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    case_0 = DocstringParam(args=[], description=None, arg_name="arg", type_name=None, is_optional=False, default=None)
    case_1 = DocstringParam(args=[], description=None, arg_name="arg", type_name=None, is_optional=True, default="None")
    case_2 = DocstringParam(args=[], description=None, arg_name="arg", type_name="str", is_optional=False, default=None)
    case_3 = DocstringParam(args=[], description=None, arg_name="arg", type_name="str", is_optional=True, default="None")
    case_4 = DocstringParam(args=[], description="arg description", arg_name="arg", type_name=None, is_optional=False, default=None)
    case_

# Generated at 2022-06-25 16:16:51.407408
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("This is an error")
    assert(isinstance(error, RuntimeError))


# Generated at 2022-06-25 16:16:56.381685
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "this is a parameter", "arg_name", "typename", False, "default")


# Generated at 2022-06-25 16:17:03.513483
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    t = DocstringReturns(['param', 'parameter', 'arg'], 'description', 'type_name', True)
    assert(t.args == ['param', 'parameter', 'arg'])
    assert(t.description == 'description')
    assert(t.type_name == 'type_name')
    assert(t.is_generator == True)
    assert(t.return_name == None)


# Generated at 2022-06-25 16:17:05.559867
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([], None, "", None, None, None)


# Generated at 2022-06-25 16:17:08.594219
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['test'], 'test case')
    assert docstring_meta is not None


# Generated at 2022-06-25 16:17:18.382754
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args = ["param"], description = "description", arg_name = "arg_name", type_name = "type_name", is_optional = True, default = "default")
    assert docstring_param.args == ["param"], 'args should be ["param"]'
    assert docstring_param.description == "description", 'description should be "description"'
    assert docstring_param.arg_name == "arg_name", 'arg_name should be "arg_name"'
    assert docstring_param.type_name == "type_name", 'type_name should be "type_name"'
    assert docstring_param.is_optional == True, 'is_optional should be True'
    assert docstring_param.default == "default", 'default should be "default"'


# Generated at 2022-06-25 16:17:54.583072
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of class Docstring."""

    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:17:58.027803
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description=None
    version=None
    obj=DocstringDeprecated(args,description,version)
    assert type(obj) == DocstringDeprecated


# Generated at 2022-06-25 16:18:01.971278
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:18:07.100531
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(args = ["yield"],
                                         description = "This is a generator function.",
                                         type_name = "generator",
                                         is_generator = True,
                                         return_name = "N/A")


# Generated at 2022-06-25 16:18:10.746718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], 
                                    "test description", 
                                    "test_arg", 
                                    "int", 
                                    True, 
                                    "2")



# Generated at 2022-06-25 16:18:16.243045
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print("Unit test for constructor of class DocstringDeprecated")
    docstring_deprecated_0 = DocstringDeprecated(
        [], "", ""
    )
    print(docstring_deprecated_0.args)
    print(docstring_deprecated_0.description)
    print(docstring_deprecated_0.version)


# Generated at 2022-06-25 16:18:22.268566
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        dr = DocstringRaises(['a', 'b'], 'desc', 'Type')
    except:
        print("Unexpected exception.")
        return
    assert (dr.args == ['a', 'b']) and (dr.description == 'desc') and (dr.type_name == 'Type')


# Generated at 2022-06-25 16:18:27.996362
# Unit test for constructor of class ParseError
def test_ParseError():
    # Assert that instance of class ParseError can be created
    assert isinstance(ParseError(), ParseError)
    # Assert that instance of class ParseError can be created with msg
    assert isinstance(ParseError("test"), ParseError)
    # Assert that instance of class ParseError can be created with msg and cause
    exception = KeyError()
    assert isinstance(ParseError("test", cause=exception), ParseError)


# Generated at 2022-06-25 16:18:32.445242
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError = ParseError("arg1", 2)
    assert ParseError.args == "arg1" and ParseError.args == 2


# Generated at 2022-06-25 16:18:34.178278
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('error_message')
    except ParseError:
        assert True


# Generated at 2022-06-25 16:19:50.321782
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([':deprecated'], None, None)


# Generated at 2022-06-25 16:19:51.407800
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:19:57.677819
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(args=["return"], description="Empty list", type_name="list", is_generator=False)
    assert docstring_returns.args == ["return"]
    assert docstring_returns.description == "Empty list"
    assert docstring_returns.type_name == "list"
    assert docstring_returns.is_generator == False

# Generated at 2022-06-25 16:20:00.077193
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta_1 = DocstringRaises(["raises","exception","error"], "if x is not defined", "Exception")

# Generated at 2022-06-25 16:20:02.693070
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated()
    docstring_deprecated_1 = DocstringDeprecated(['abcd'], 'xyz', 'v12')


# Generated at 2022-06-25 16:20:07.583516
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=['param'],
                                     description="Parameter x",
                                     arg_name="x",
                                     type_name=None,
                                     is_optional=None,
                                     default=None)
    assert docstring_param.args == ['param']
    assert docstring_param.description == "Parameter x"
    assert docstring_param.arg_name == "x"
    assert docstring_param.type_name == None
    assert docstring_param.is_optional == None
    assert docstring_param.default == None


# Generated at 2022-06-25 16:20:08.454149
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(1)


# Generated at 2022-06-25 16:20:11.393480
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["arg", "this is an arg"], "description", "type_name")
    DocstringRaises(["arg", "this is an arg"], None, None)


# Generated at 2022-06-25 16:20:13.017780
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()
    assert True



# Generated at 2022-06-25 16:20:14.268838
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError()
