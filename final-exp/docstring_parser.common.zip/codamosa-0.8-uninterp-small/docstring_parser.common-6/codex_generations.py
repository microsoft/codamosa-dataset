

# Generated at 2022-06-25 16:12:41.118871
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    temp = DocstringReturns(["return:", "returns:"], "temp_description", "temp_type_name", False, "temp_return_name")


# Generated at 2022-06-25 16:12:49.377094
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(args=[], description=None, arg_name='foo', type_name=None, is_optional=None, default=None)
# Check that the constructor of DocstringParam works
    assert(docstring_param_0.args == [])
    assert(docstring_param_0.description is None)
    assert(docstring_param_0.arg_name == 'foo')
    assert(docstring_param_0.type_name is None)
    assert(docstring_param_0.is_optional is None)
    assert(docstring_param_0.default is None)


# Generated at 2022-06-25 16:12:55.801990
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-25 16:12:57.612079
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(None, None, None, False, "")


# Generated at 2022-06-25 16:12:59.370812
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['param'], 'Some description', None, False, None) != None


# Generated at 2022-06-25 16:13:03.511110
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # test __init__
    ds = DocstringDeprecated(['a', 'b'], 'test description', 'test version')
    assert (ds.args == ['a', 'b'])
    assert (ds.description == 'test description')
    assert (ds.version == 'test version')


# Generated at 2022-06-25 16:13:06.785991
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["raises"], "ddd", "TypeError")
    assert a.args == ["raises"]
    assert a.description == "ddd"
    assert a.type_name == "TypeError"



# Generated at 2022-06-25 16:13:08.376810
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()
    print("DocstringMeta constructor test has passed.")


# Generated at 2022-06-25 16:13:12.884593
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d_1 = DocstringRaises(['raises'], 'if something happens', 'ValueError')
    assert d_1.args == ['raises']
    assert d_1.description == 'if something happens'
    assert d_1.type_name == 'ValueError'


# Generated at 2022-06-25 16:13:14.185679
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "", "a", "", None, "")


# Generated at 2022-06-25 16:13:25.634506
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["parameter", "arg"]
    description = "description"
    type_name = "int"
    is_generator = False
    return_name = "test"

    assert type_name == "int"
    assert is_generator == False
    assert return_name == "test"


# Generated at 2022-06-25 16:13:28.029223
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_Returns = DocstringReturns(['args', 'description'], None, None, True)


# Generated at 2022-06-25 16:13:34.902946
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Constructor test for class DocstringRaises"""

    # Initialize input
    args = ["type_name"]
    description = "Some description"

    # Call constructor
    test_case_0 = DocstringRaises(args, description, "type_name")

    # Check values
    assert test_case_0.args == args
    assert test_case_0.description == description
    assert test_case_0.type_name == "type_name"


# Generated at 2022-06-25 16:13:45.178187
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['return'], 'Return the inverse of matrix m.', 'matrix', False, 'inverse').args == ['return']
    assert DocstringReturns(['return'], 'a matrix', 'matrix', False, 'matrix').description == 'a matrix'
    assert DocstringReturns(['return'], 'a matrix', 'matrix', False, 'matrix').type_name == 'matrix'
    assert DocstringReturns(['return'], 'a matrix', 'matrix', False, 'matrix').is_generator == False
    assert DocstringReturns(['return'], 'a matrix', 'matrix', False, 'matrix').return_name == 'matrix'


# Generated at 2022-06-25 16:13:52.107346
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert isinstance(docstring_0, Docstring)
    assert isinstance(docstring_0.short_description, type(None))
    assert isinstance(docstring_0.long_description, type(None))
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert isinstance(docstring_0.meta, list)
    assert len(docstring_0.meta) == 0


# Generated at 2022-06-25 16:13:54.967677
# Unit test for constructor of class ParseError
def test_ParseError():
    p_err = ParseError()
    print(p_err)



# Generated at 2022-06-25 16:13:57.415690
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj = DocstringRaises(["raises"], "description", "type") 
    assert obj.type_name == "type"
    assert obj.description == "description"


# Generated at 2022-06-25 16:14:02.876345
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = ['deprecated', 'version']
    b = "123"
    c = "456"
    test_0 = DocstringDeprecated(a, b, c)


# Generated at 2022-06-25 16:14:07.886298
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta
    arg_1 = ['arg']
    arg_2 = 'test_desc'
    test_meta = meta(arg_1, arg_2)
    assert test_meta.args == arg_1
    assert test_meta.description == arg_2

# Generated at 2022-06-25 16:14:09.492551
# Unit test for constructor of class DocstringRaises

# Generated at 2022-06-25 16:14:35.610798
# Unit test for constructor of class ParseError
def test_ParseError():
    # Initialization of variable
    line = 0
    expected_line = 0
    source = "This is a source string"
    expected_source = "This is a source string"
    # Need to assign:
    expected_msg = ""
    try:
        # Test constructor of class ParseError
        pe = ParseError(line, source)
    except:
        # Test unsuccessful
        msg = "Construction of ParseError object unsuccessful"
        raise AssertionError(msg)
    else:
        # Test successful
        # Test values of attributes of object "pe"
        assert pe.line == expected_line, \
            "Value of attribute 'line' should be {}".format(expected_line)

# Generated at 2022-06-25 16:14:36.653311
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param", "arg"], "description")


# Generated at 2022-06-25 16:14:40.940272
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=[":param"],
        description="",
        arg_name="arg_name",
        type_name="str",
        is_optional=False,
        default="",
    )


# Generated at 2022-06-25 16:14:44.249874
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  DocstringRaises(['arg'], 'desc', 'typename')


# Generated at 2022-06-25 16:14:46.385241
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], "This is deprecated",
                                               "2.0.0")


# Generated at 2022-06-25 16:14:49.690829
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # No args in parameters
    args = []
    description = None
    version = None
    test_case_0 = DocstringDeprecated(args, description, version)
    assert test_case_0.args == args, "Failed to create test_case_0"
    assert test_case_0.description == description, "Failed to create test_case_0"
    assert test_case_0.version == version, "Failed to create test_case_0"


# Generated at 2022-06-25 16:14:52.027046
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(["Returns"], "string", "type name", True, "return name")


# Generated at 2022-06-25 16:14:55.375245
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam_0 = DocstringParam(['args'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')


# Generated at 2022-06-25 16:15:06.180334
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["type", "float", "description", "returns the number of seconds since the Epoch"]
    description = "returns the number of seconds since the Epoch"
    type_name = "float"
    is_generator = False
    return_name = None
    test = DocstringReturns(args, description, type_name, is_generator,
                            return_name)
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name
    assert test.is_generator == is_generator
    assert test.return_name == return_name
    assert len(test.meta) == 0


# Generated at 2022-06-25 16:15:07.779056
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_0 = DocstringRaises(["arg"], "description", "type_name")


# Generated at 2022-06-25 16:15:41.314178
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # create a DocstringParam object
    param = DocstringParam(
        args=PARAM_KEYWORDS,
        description="The position of the element to remove (defaults to the last).",
        arg_name="position",
        type_name="int",
        is_optional=True,
        default="-1",
    )
    # check content of attribute args
    assert set(param.args) == set(PARAM_KEYWORDS)
    # check content of attribute description
    assert (
        param.description
        == "The position of the element to remove (defaults to the last)."
    )
    # check content of attribute arg_name
    assert param.arg_name == "position"
    # check content of attribute type_name
    assert param.type_name == "int"
    # check content of attribute is_optional

# Generated at 2022-06-25 16:15:46.142504
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param", "arg"], "description")
    assert docstring_meta.args == ["param", "arg"]
    assert docstring_meta.description == "description"

# Generated at 2022-06-25 16:15:47.394758
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:15:53.946230
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # test constructor of class DocstringReturns
    try:
        docstring_0 = Docstring()
        docstring_params = [] # type: T.List[DocstringParam]
        docstring_params.append(DocstringParam(["Return type: "], "", "", "", "", ""))
        docstring_0.meta = docstring_params
        test_case_0()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 16:15:54.847572
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()

# Generated at 2022-06-25 16:16:04.634162
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_0.short_description = "Test docstring"
    docstring_0.long_description = "This is a test docstring"
    docstring_0.blank_after_long_description = False
    args_0 = [
        "return",
        "returns",
    ]
    type_name_0 = "int"
    is_generator_0 = True
    return_name_0 = "return_value"
    description_0 = "returns"
    docstring_0.meta = [
        DocstringReturns(
            args_0,
            description_0,
            type_name_0,
            is_generator_0,
            return_name_0,
        ),
    ]

# Generated at 2022-06-25 16:16:09.658271
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    # Unit test for init
    try:
        docstring_0.__init__()
    except TypeError as e:
        print( e )
    else:
        print( "test_DocstringReturns int failed" )


# Generated at 2022-06-25 16:16:10.565418
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:16:13.595049
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg_0 = DocstringParam(["args", "b", "c", "d"], "description", "arg_name", "type_name", True, "default")


# Generated at 2022-06-25 16:16:17.295118
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Constructor tests
    args_0 = ["Description"]
    description_0 = "Testing DocstringRaises"
    type_name_0 = "Not defined"
    temp_0 = DocstringRaises(args_0, description_0, type_name_0)


# Generated at 2022-06-25 16:17:15.908145
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    test_DocstringReturns_0 = """
    This function would return a DocstringReturns object which is used to represent a returns
    annotation in docstrings.
    """
    if isinstance(docstring_0.returns, DocstringReturns):
        print(test_DocstringReturns_0 + " - Success")
    else:
        print(test_DocstringReturns_0 + " - Fail")


# Generated at 2022-06-25 16:17:17.025198
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc_r0 = DocstringRaises([], "", "")


# Generated at 2022-06-25 16:17:19.557984
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "test", "arg", "test", True, "test")


# Generated at 2022-06-25 16:17:25.989175
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # test for  type error on args
    try:
        DocstringMeta(5,5)
    except TypeError:
        print("Type error on args")
    else:
        print("Type error not occured")

    # test for  type error on description
    try:
        DocstringMeta(["list"],5)
    except TypeError:
        print("Type error on description")
    else:
        print("Type error not occured")

    # test for non type error
    try:
        DocstringMeta(["list"],"string")
    except TypeError:
        print("Type error on DocstringMeta")
    else:
        print("Type error not occured")



# Generated at 2022-06-25 16:17:32.121758
# Unit test for constructor of class Docstring
def test_Docstring():
    from darglint.docstring import Docstring
    docstring_0 = Docstring()
    assert(docstring_0.short_description == None)
    assert(docstring_0.long_description == None)
    assert(docstring_0.blank_after_short_description == False)
    assert(docstring_0.blank_after_long_description == False)


# Generated at 2022-06-25 16:17:35.242394
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises(["raises"], "viery", "ValueError")


# Generated at 2022-06-25 16:17:37.525032
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)


# Generated at 2022-06-25 16:17:40.220642
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except Exception:
        pass
    try:
        raise ParseError("test", 3)
    except Exception:
        pass


# Generated at 2022-06-25 16:17:42.766979
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    description = "description"
    type_name = "TypeError"
    args = ["raises"]
    assert DocstringRaises(args, description, type_name)



# Generated at 2022-06-25 16:17:46.943621
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(["param"], "description", "arg", "type", True, "default")


# Generated at 2022-06-25 16:19:52.556790
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("demo")
        assert 0
    except ParseError:
        assert 1
    else:
        assert 0 


# Generated at 2022-06-25 16:19:59.263052
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args1 = ['param', 'foo', 'description']
    args2 = ['param', 'foo', ':type:', 'int']
    args3 = ['param', 'foo', ':type:', 'int', ':returns:']
    args4 = ['param', 'foo', ':param', 'foo', ':type:', 'int', ':returns:']
    assert args1 == ['param', 'foo', 'description']


# Generated at 2022-06-25 16:20:02.003292
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(['param'], 'comment')
    assert docstring_0.args[0] == 'param'
    assert docstring_0.description == 'comment'


# Generated at 2022-06-25 16:20:06.232984
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_a = DocstringReturns(["raises"], "foo", "bar", True)
    docstring_b = DocstringReturns(["raises"], "foo", "bar", is_generator=True)
    docstring_c = DocstringReturns(["raises"], "foo", "bar", False)
    docstring_d = DocstringReturns(["raises"], "foo", "bar", is_generator=False)


# Generated at 2022-06-25 16:20:08.783740
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    # Test test_case_0
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:20:11.084680
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Programmer logic error.')
    except ParseError as err:
        print(err)


# Generated at 2022-06-25 16:20:16.909741
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['meta'], 'description', 'version')
    assert docstring_deprecated.args == ['meta']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-25 16:20:23.962075
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 16:20:26.669988
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta.__init__


# Generated at 2022-06-25 16:20:28.481977
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['return', 'returns'], 'a short description', 'object')
