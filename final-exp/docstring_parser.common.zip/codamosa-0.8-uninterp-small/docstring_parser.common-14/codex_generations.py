

# Generated at 2022-06-25 16:12:42.982818
# Unit test for constructor of class ParseError
def test_ParseError():
    print("test: ParseError")
    message = "Some error message"
    error = ParseError(message)
    assert error.args == (message,)


# Generated at 2022-06-25 16:12:47.283719
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # docstring_meta_0 = DocstringDeprecated(list_0, str_0, str_1)
    # docstring_meta_0.args
    # docstring_meta_0.description
    # docstring_meta_0.version
    return None


# Generated at 2022-06-25 16:12:49.619432
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_meta_0 = DocstringMeta(list_0, str_0)

test_DocstringMeta()


# Generated at 2022-06-25 16:12:50.661574
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:12:58.035191
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    list_1 = []
    str_0 = 'EzT%c"TQa8'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)
    docstring_raises_1 = DocstringRaises(list_1, str_0, str_0)


# Generated at 2022-06-25 16:12:59.424020
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(["a"], "b", "c", False)



# Generated at 2022-06-25 16:13:01.856441
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_meta_0 = DocstringMeta([], 'x.Z^N8H"tX1')


# Generated at 2022-06-25 16:13:07.861922
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = 'lI1b'
    str_2 = '0C,X9'
    str_3 = ''
    str_4 = 'o`'
    str_5 = 'P: '
    docstring_param_0 = DocstringParam(list_0, str_0, str_1, str_2, str_3, str_4, str_5)


# Generated at 2022-06-25 16:13:12.144599
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_0)
# Tests for attributes of class DocstringDeprecated

# Generated at 2022-06-25 16:13:20.074740
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = []
    str_0 = "7xU6)rI_[Z"
    str_1 = '''
    '''
    bool_0 = False
    str_2 = "5p3qbZwY^8"
    docstring_returns_0 = DocstringReturns(list_0, str_0, str_1, bool_0, str_2)
    str_3 = "XeNL]P)"
    assert docstring_returns_0.type_name == str_3
    str_4 = "CXlk-a"
    assert docstring_returns_0.args == list_0
    str_5 = "aM&yX7m"
    assert docstring_returns_0.description == str_5

# Generated at 2022-06-25 16:13:28.144038
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["a", "b"], "My Description", "arg0", "type_a", True, "0")


# Generated at 2022-06-25 16:13:35.471738
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        var_0 = [1, 2, 3]
        var_1 = 'Sample description'
        var_2 = 'arg_name'
        var_3 = 'Sample type name'
        var_4 = False
        var_5 = 'Sample default name'
        var_6 = DocstringParam(var_0, var_1, var_2, var_3, var_4, var_5)
    except:
        traceback.print_exc()
        raise AssertionError


# Generated at 2022-06-25 16:13:40.922996
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-25 16:13:41.845369
# Unit test for constructor of class Docstring
def test_Docstring():
    assert var_0 is not None


# Generated at 2022-06-25 16:13:44.233753
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam([], var_0, '', None, None, None)
    except Exception:
        pass


# Generated at 2022-06-25 16:13:46.761069
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    var_0 = DocstringDeprecated(None, None, None)
    assert isinstance(var_0, DocstringMeta) is True


# Generated at 2022-06-25 16:13:58.067126
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arg0 = ['return', 'returns']
    arg1 = '123'
    arg2 = None
    arg3 = False
    arg4 = None
    docstring_returns = DocstringReturns(arg0, arg1, arg2, arg3, arg4)
    assert docstring_returns.return_name == None
    assert docstring_returns.args == ['return', 'returns']
    assert docstring_returns.type_name == None
    assert docstring_returns.is_generator == False
    assert docstring_returns.description == '123'


# Generated at 2022-06-25 16:14:01.948939
# Unit test for constructor of class Docstring
def test_Docstring():
    var_0 = Docstring()
    return var_0



# Generated at 2022-06-25 16:14:04.295834
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = None
    description = None
    doc_string = DocstringMeta(args=args, description=description)
    assert doc_string


# Generated at 2022-06-25 16:14:06.899826
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  var_0 = DocstringRaises(['x'], None, None)


# Generated at 2022-06-25 16:14:12.436749
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Testing __init__ of class DocstringRaises
    test_case_0()


# Generated at 2022-06-25 16:14:19.712510
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = 'kyp'
    str_2 = 'xgp]t2#*'
    bool_0 = True
    docstring_returns_0 = DocstringReturns(list_0, str_0, str_1, bool_0, str_2)


# Generated at 2022-06-25 16:14:24.549598
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_meta_0 = DocstringMeta(list_0, str_0)
    str_1 = 'aYw(J_P'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_1)


# Generated at 2022-06-25 16:14:27.705321
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:14:36.571849
# Unit test for constructor of class ParseError
def test_ParseError():
    exc_info_0 = (None, None, None)
    str_0 = ': '
    str_1 = 'p>H_V8Nu'
    int_0 = eval(str_0)
    str_2 = ': '
    str_3 = 'j_yb?l[B'
    int_1 = eval(str_2)
    str_4 = ': '
    str_5 = 'c%xS}p&'
    int_2 = eval(str_4)
    str_6 = ': '
    str_7 = 'B+;(ce#C'
    int_3 = eval(str_6)
    str_8 = ': '
    str_9 = 'XnvYJEZ'
    int_4 = eval(str_8)
    str_

# Generated at 2022-06-25 16:14:43.177799
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = '~/2Hb|4LLxI2'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_1)



# Generated at 2022-06-25 16:14:48.839884
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)
    str_1 = 'x.Z^N8H"tX1'
    docstring_raises_1 = DocstringRaises(list_0, str_1, str_0)


# Generated at 2022-06-25 16:14:51.000992
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_returns_0 = DocstringReturns(list_0, str_0, None, False, None)


# Generated at 2022-06-25 16:14:57.255855
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_1 = []
    str_1 = 'x.Z^N8H"tX1'
    docstring_raises_0 = DocstringRaises(list_1, str_1, str_1)
    assert docstring_raises_0.type_name == str_1
    assert docstring_raises_0.description == str_1


# Generated at 2022-06-25 16:15:06.974559
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = '`9kv$j"3qh '
    str_1 = '5v5g2?j%c@$Q'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_1)
    str_2 = docstring_raises_0.type_name
    assert (str_1 == str_2)
    str_3 = docstring_raises_0.description
    assert (str_0 == str_3)
    list_1 = docstring_raises_0.args
    assert (list_0 == list_1)


# Generated at 2022-06-25 16:15:18.185055
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = '0.1'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_1)


# Generated at 2022-06-25 16:15:23.243725
# Unit test for constructor of class Docstring
def test_Docstring():
    # A new Docstring is created with no data
    docstring = Docstring()

    # Assert that the docstring is empty
    assert docstring.meta == []
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description


# Generated at 2022-06-25 16:15:28.330399
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = '1W=A8:?-~%Gm[0'
    str_1 = 'I$X"@Q!d^1>-H'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_1)



# Generated at 2022-06-25 16:15:36.238604
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    bool_0 = False
    dict_0 = dict()
    list_1 = []
    str_1 = 'x.Z^N8H"tX1'
    tuple_0 = (dict_0, list_1, str_1)
    docstring_param_0 = DocstringParam(list_0, str_0, str_0, str_0, bool_0, str_0)


# Generated at 2022-06-25 16:15:39.467383
# Unit test for constructor of class DocstringParam
def test_DocstringParam(): 
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_meta_0 = DocstringParam(list_0, str_0, str_0, str_0, False, str_0)


# Generated at 2022-06-25 16:15:48.078118
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = 'H:e'
    str_2 = 'RjY>=Sd'
    bool_0 = True
    test_object = DocstringReturns(list_0, str_0, str_1, bool_0)


# Generated at 2022-06-25 16:15:50.218543
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # basic test case
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_meta_0 = DocstringRaises(list_0, str_0)


# Generated at 2022-06-25 16:15:52.739745
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'KtwBeqw"4'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)


# Generated at 2022-06-25 16:16:00.445688
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    list_0 = []
    str_0 = 'lgfP:N%jT#C'
    str_1 = '&8X/Wd/vxK'
    str_2 = 'tEa@tHwL`'
    bool_0 = False
    str_3 = '|JCQYb~j3<'
    docstring_param_0 = DocstringParam(list_0, str_0, str_1, str_2, bool_0, str_3)


# Generated at 2022-06-25 16:16:03.535607
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    str_0 = '{rDcb'
    str_1 = 'n;@*G'
    docstring_Deprecated_0 = DocstringDeprecated(list_0, str_0, str_1)


# Generated at 2022-06-25 16:16:24.917638
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-25 16:16:25.655801
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

test_Docstring()

# Generated at 2022-06-25 16:16:29.442588
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_meta_0 = DocstringMeta(list_0, str_0)
    docstring_param_1 = DocstringParam(list_0, str_0, str_0, str_0, False, str_0)


# Generated at 2022-06-25 16:16:33.674587
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:16:37.763440
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)


# Generated at 2022-06-25 16:16:45.146829
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, 'ABt_D')


# Generated at 2022-06-25 16:16:51.966483
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        # Test initializing DocstringReturns
        list_0 = []
        str_0 = 'x.Z^N8H"tX1'
        docstring_returns_0 = DocstringReturns(list_0, str_0, None, True)
        # Test that DocstringReturns has set properties correctly
        assert docstring_returns_0.args == list_0
        assert docstring_returns_0.description == str_0
        assert docstring_returns_0.type_name is None
        assert docstring_returns_0.is_generator is True
        assert docstring_returns_0.return_name is None
    except Exception as e:
        print('An exception has been raised during the test')
        print(e)
        raise e


# Generated at 2022-06-25 16:16:55.269241
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()


# Generated at 2022-06-25 16:17:00.870671
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Code coverage:
    # assert True
    param_list_0 = []
    param_str_0 = "Returns a list of the available output names."
    param_str_1 = "The output names are the keys of the outputs dictionary returned by " \
                  "self.forward()"
    param_str_2 = "v0.6.0"
    docstring_deprecated = DocstringDeprecated(param_list_0, param_str_1, param_str_2)
    param_int_0 = 0
    param_int_1 = 0
    param_int_2 = 0
    assert docstring_deprecated.args[param_int_0] == param_str_0
    assert docstring_deprecated.args[param_int_1] == param_str_1

# Generated at 2022-06-25 16:17:11.924950
# Unit test for constructor of class Docstring
def test_Docstring():
    list_0 = [7.459031285488345e+307]
    str_0 = 'K{y(k/<8r1b'
    docstring_meta_0 = DocstringMeta(list_0, str_0)
    str_1 = 'U6k[jV7eUFZ'
    docstring_param_0 = DocstringParam(list_0, str_0, str_1, str_0, True, str_1)
    docstring_param_0 = DocstringParam(list_0, str_0, str_1, str_0, True, str_1)
    str_2 = 'EutP5'
    str_3 = '!%c$wN*|n'

# Generated at 2022-06-25 16:17:50.778838
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    str_0 = 'A,oOZ_G*X9~a'
    str_1 = 'yO"O*zwH"i%Y'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_1)


# Generated at 2022-06-25 16:17:52.307910
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()


# Generated at 2022-06-25 16:17:56.767721
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_0)


# Generated at 2022-06-25 16:18:01.847850
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

if __name__ == '__main__':
    test_Docstring()

# Generated at 2022-06-25 16:18:04.314317
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()
    return

if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-25 16:18:10.322186
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    tuple_0 = (1, 42, 42, 42, 42, 42, 42)
    list_0 = list(tuple_0)
    str_0 = 'x.Z^N8H"tX1'
    str_1 = ':param:'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_1)


# Generated at 2022-06-25 16:18:14.028185
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    test = DocstringRaises(list_0, str_0, str_0)


# Generated at 2022-06-25 16:18:15.733473
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], None, None)


# Generated at 2022-06-25 16:18:16.622179
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:18:23.076928
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = [0]
    str_0 = 'R%M(|Z<'
    str_1 = 'x.Z^N8H"tX1'
    str_2 = '1u`7Y`Ww}c'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_1)
    docstring_deprecated_0.version = str_0
    docstring_deprecated_0.args = list_0
    docstring_deprecated_0.description = str_2


# Generated at 2022-06-25 16:19:42.683409
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = '{D0H(Zh'
    docstring_meta_0 = DocstringDeprecated(
        list_0, str_0, str_1)
    test_case_0()

# Generated at 2022-06-25 16:19:50.958965
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()
    list_1 = []
    str_1 = 'x.Z^N8H"tX1'
    docstring_deprecated_0 = DocstringDeprecated(list_1, str_1)


# Generated at 2022-06-25 16:20:00.232345
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    list_0 = []
    list_1 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = 'x.Z^N8H"tX1'
    docstring_deprecated_0 = DocstringDeprecated(list_0, str_0, str_1)
    
    assert docstring_deprecated_0.version == 'x.Z^N8H"tX1'
    assert docstring_deprecated_0.description == 'x.Z^N8H"tX1'
    assert docstring_deprecated_0.args == []


# Generated at 2022-06-25 16:20:07.511418
# Unit test for constructor of class Docstring
def test_Docstring():
    list_0 = []
    str_0 = '0uV7}yI#C?}'
    docstring_meta_0 = DocstringMeta(list_0, str_0)
    list_1 = []
    str_1 = '}(n^p.\U00000100|>8$'
    str_2 = 'SxD\u00bda\u00b4&]ZP4|'
    docstring_param_0 = DocstringParam(list_1, str_1, str_2, None, None, None)
    str_3 = 'b+QY\U000e090f^/G0c'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_3)
    docstring_0 = Docstring()

# Generated at 2022-06-25 16:20:11.430433
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()

if __name__ == '__main__':
    import sys
    import logging

    logger = logging.getLogger()
    logger.level = logging.DEBUG
    logger.addHandler(logging.StreamHandler(sys.stdout))

    test_DocstringDeprecated()

# Generated at 2022-06-25 16:20:12.499202
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()



# Generated at 2022-06-25 16:20:18.460822
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_0 = []
    str_0 = 'x.Z^N8H"tX1'
    str_1 = 'x.Z^N8H"tX1'
    docstring_raises_0 = DocstringRaises(list_0, str_0, str_1)


# Generated at 2022-06-25 16:20:24.426312
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = "description"
    type_name = "type_name"
    DocstringRaises_0 = DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:20:26.811752
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        test_case_0()
        print("PASSED")
    except:
        print("FAILED")


# Generated at 2022-06-25 16:20:29.476870
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()
