

# Generated at 2022-06-25 16:12:45.018144
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dr = DocstringReturns(args=["a", "b"], description='this is a test', type_name="int")


# Generated at 2022-06-25 16:12:47.282941
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()

if __name__ == "__main__":
    # test_ParseError()
    pass

# Generated at 2022-06-25 16:12:51.340059
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ara = DocstringRaises([],[], None)
    assert ara.args == []
    assert ara.description == []
    assert ara.type_name == None


# Generated at 2022-06-25 16:12:53.027583
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()


# Generated at 2022-06-25 16:12:56.840303
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()
    assert type(parse_error_0) == ParseError


# Generated at 2022-06-25 16:13:05.287437
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_1 = DocstringRaises(['param'], 'desc', 'Exc')
    test_2 = DocstringRaises(['param'], None, 'Exc')
    test_3 = DocstringRaises(['param'], None, None)
    test_list = [test_1, test_2, test_3]
    test_list_args = ['param', 'param', 'param']
    test_list_desc = ['desc', None, None]
    test_list_type = ['Exc', 'Exc', None]
    for i in range(3):
        assert test_list[i].args == test_list_args[i]
        assert test_list[i].description == test_list_desc[i]
        assert test_list[i].type_name == test_list_type[i]

# Unit test

# Generated at 2022-06-25 16:13:10.863539
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """DocstringMeta symbolizing deprecation metadata."""
    args_0 = ["param"]
    description_0 = "description"
    version_0 = "version"
    docstring_deprecated_0 = DocstringDeprecated(args_0, description_0, version_0)
    assert docstring_deprecated_0.version == version_0
    assert docstring_deprecated_0.args == args_0
    assert docstring_deprecated_0.description == description_0


# Generated at 2022-06-25 16:13:11.604571
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:13:14.398203
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises error"]
    description = "it raises an error"
    type_name = "ValueError"
    DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:13:16.013927
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises_0 = DocstringRaises(args=[], description=None, type_name=None)



# Generated at 2022-06-25 16:13:25.701587
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

if __name__ == "__main__":
    test_Docstring()
    import doctest
    doctest.testmod()

# Generated at 2022-06-25 16:13:30.252302
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated([], "description_0", "version_0")
    docstring_deprecated_1 = DocstringDeprecated(["a"], "description_1", None)
    docstring_deprecated_2 = DocstringDeprecated([""], "description_2", "")



# Generated at 2022-06-25 16:13:42.412393
# Unit test for constructor of class DocstringReturns

# Generated at 2022-06-25 16:13:43.632217
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()

# Generated at 2022-06-25 16:13:49.044791
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns_test = DocstringReturns(["a","b"],"descr","type","name")
    assert DocstringReturns_test.args == ["a", "b"]
    assert DocstringReturns_test.description == "descr"
    assert DocstringReturns_test.type_name == "type"
    assert DocstringReturns_test.is_generator == False
    assert DocstringReturns_test.return_name == None


# Generated at 2022-06-25 16:13:51.860291
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_meta_0 = DocstringDeprecated([], "")


# Generated at 2022-06-25 16:13:58.308250
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test case 0:
    args_0 = []
    description_0 = None
    version_0 = None
    assert DocstringDeprecated(args_0, description_0, version_0).args == []
    assert DocstringDeprecated(args_0, description_0, version_0).description == None
    assert DocstringDeprecated(args_0, description_0, version_0).version == None


# Generated at 2022-06-25 16:14:02.685412
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['return'], 'Return type "int"', 'int')



# Generated at 2022-06-25 16:14:03.741871
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:14:08.657723
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-25 16:14:27.392398
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], "", "").args == []
    assert DocstringDeprecated([], "", "").description == ""
    assert DocstringDeprecated([], "", "").version == ""


# Generated at 2022-06-25 16:14:30.318724
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = 'z'
    d = DocstringMeta(args, description)
    assert d.args == args
    assert d.description == description


# Generated at 2022-06-25 16:14:33.619556
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()
    str(parse_error_0)
    repr(parse_error_0)
    parse_error_0.__str__()
    parse_error_0.__repr__()



# Generated at 2022-06-25 16:14:37.042206
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error_0 = ParseError()
    return


# Generated at 2022-06-25 16:14:43.123228
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
   DocstringReturns("","",0,0,0)
   DocstringReturns("","",0,0)
   DocstringReturns("","",0,0)
   DocstringReturns("","",0,0,0)
   DocstringReturns("","",0,0)


# Generated at 2022-06-25 16:14:48.787325
# Unit test for constructor of class Docstring
def test_Docstring():
    assert __name__ == '__main__'
    Docstring()
    test_case_0()

# Generated at 2022-06-25 16:14:49.730541
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises()



# Generated at 2022-06-25 16:14:53.320675
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = 0
    description = 0
    type_name = 0
    result = DocstringRaises(args, description, type_name)
    assert result.args == 0
    assert result.description == 0
    assert result.type_name == 0


# Generated at 2022-06-25 16:14:56.452736
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises', 'ValueError'], 'if something happens', 'ValueError')


# Generated at 2022-06-25 16:15:00.453160
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    Test if the constructor for ParseError exists
    """
    try:
        parse_error_0 = ParseError()
    except:
        parse_error_0 = None
    assert parse_error_0 is not None


# Generated at 2022-06-25 16:15:31.360971
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-25 16:15:36.417586
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-25 16:15:42.908010
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Invalid parameters
    DocstringDeprecated(None, None, None)
    DocstringDeprecated([], None, None)
    DocstringDeprecated([""], None, None)
    DocstringDeprecated(["", ""], None, None)
    DocstringDeprecated(["", "", "version"], None, None)
    DocstringDeprecated(["", "", "", ""], None, None)
    DocstringDeprecated(["", "", "version", "description"], None, None)
    # Valid parameters
    DocstringDeprecated(["", "", "version", "description"], "description",
                        "version")
    DocstringDeprecated(["", "", "version", "description"], "description", None)



# Generated at 2022-06-25 16:15:45.440563
# Unit test for constructor of class ParseError
def test_ParseError():
    assert str(test_case_0()) == "<base class>"


# Generated at 2022-06-25 16:15:49.798165
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Testing string in constructor
    test = DocstringMeta(["arg"], "Description")
    assert test.args == ["arg"], "Test failed: args not initialized correctly"
    assert test.description == "Description", "Test failed: description not initialized correctly"



# Generated at 2022-06-25 16:15:50.913240
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["arg"], "description")


# Generated at 2022-06-25 16:15:53.531568
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([], "", None)



# Generated at 2022-06-25 16:15:55.218342
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated([], None, None)
    assert s is not None


# Generated at 2022-06-25 16:15:57.476040
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringmeta = DocstringMeta([],"")


# Generated at 2022-06-25 16:15:59.896898
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)


# Generated at 2022-06-25 16:16:58.965182
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args_0 = ["param"]
    test_description_0 = "description"
    test_version_0 = "3.2"
    test_init_0 = DocstringDeprecated(test_args_0, test_description_0, test_version_0)


# Generated at 2022-06-25 16:17:05.264458
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(None, None, None, None, None, None)
    assert(docstring_param.arg_name == None)
    assert(docstring_param.args == None)
    assert(docstring_param.description == None)
    assert(docstring_param.type_name == None)
    assert(docstring_param.is_optional == None)
    assert(docstring_param.default == None)


# Generated at 2022-06-25 16:17:09.398821
# Unit test for constructor of class Docstring
def test_Docstring():
    docst = Docstring()
    assert isinstance(docst, Docstring)
    assert docst.short_description is None
    assert docst.long_description is None
    assert docst.meta == []


# Generated at 2022-06-25 16:17:13.674758
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [""]
    description = ""
    version = ""
    item = DocstringDeprecated(args, description, version)
    assert isinstance(item, DocstringDeprecated)
    assert item.args == args
    assert item.description == description
    assert item.version == version


# Generated at 2022-06-25 16:17:20.098812
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns_object = DocstringReturns(
        ['return'], 'value to be returned', 'int', False, 'return_name'
    )
    assert isinstance(returns_object, DocstringMeta)
    assert returns_object.args == ['return']
    assert returns_object.description == 'value to be returned'
    assert returns_object.type_name == 'int'
    assert returns_object.is_generator == False
    assert returns_object.return_name == 'return_name'


# Generated at 2022-06-25 16:17:22.601470
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        doc_depr_0 = DocstringDeprecated([], "", "")
    except ParseError:
        return
    print('test_DocstringDeprecated failed! ')


# Generated at 2022-06-25 16:17:24.820424
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['a', 'b'], 'desc')
    assert docstring_meta.args == ['a', 'b']
    assert docstring_meta.description == 'desc'


# Generated at 2022-06-25 16:17:26.090924
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring



# Generated at 2022-06-25 16:17:28.429736
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError()


# Generated at 2022-06-25 16:17:31.945811
# Unit test for constructor of class ParseError
def test_ParseError():
    import pytest
    parse_error_0 = ParseError()


# Generated at 2022-06-25 16:19:39.723824
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError.__doc__ == "Base class for all parsing related errors."
    assert ParseError.__init__.__doc__ == "Initialize self."


# Generated at 2022-06-25 16:19:40.965504
# Unit test for constructor of class Docstring
def test_Docstring():
    assert isinstance(Docstring(), Docstring)


# Generated at 2022-06-25 16:19:42.323693
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error=ParseError()
    assert(isinstance(parse_error,RuntimeError))


# Generated at 2022-06-25 16:19:47.875781
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()


# Generated at 2022-06-25 16:19:49.849313
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Constructor
    DocstringDeprecated()


# Generated at 2022-06-25 16:19:53.562570
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring.args == ['deprecated']
    assert docstring.description == 'description'
    assert docstring.version == 'version'


# Generated at 2022-06-25 16:19:54.637922
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case_0()

# Generated at 2022-06-25 16:20:04.722433
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test for default constructor of class DocstringMeta
    args_0 = ["arg0", "arg1", "arg2"]
    description_0 = "This is a description"
    obj_0 = DocstringMeta(args_0,description_0)
    assert obj_0.args == ["arg0", "arg1", "arg2"]
    assert obj_0.description == "This is a description"
    # Test for constructor with named arguments of class DocstringMeta
    args_1 = ["arg0", "arg1", "arg2"]
    description_1 = "This is a description"
    obj_1 = DocstringMeta(args=args_1,description=description_1)
    assert obj_1.args == ["arg0", "arg1", "arg2"]
    assert obj_1.description == "This is a description"



# Generated at 2022-06-25 16:20:08.665896
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['param', 'x'], 'x does something', 'int', True, 'y')
    if x.args != ['param', 'x'] or x.description != 'x does something' or x.type_name != 'int' or x.is_generator != True or x.return_name != 'y':
        return False

    return True


# Generated at 2022-06-25 16:20:10.976706
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated_0 = DocstringDeprecated(
        args=[""], description="", version=""
    )
