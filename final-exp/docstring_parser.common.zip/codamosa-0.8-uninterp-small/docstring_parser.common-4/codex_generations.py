

# Generated at 2022-06-25 16:12:46.227856
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    y = DocstringRaises(["arg"], "description", "type_name")
    assert y.args == ["arg"], "Wrong value of args"
    assert y.description == "description", "Wrong value of description"
    assert y.type_name == "type_name", "Wrong value of type_name"


# Generated at 2022-06-25 16:12:47.729789
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam_0 = DocstringParam(list(), str())


# Generated at 2022-06-25 16:12:52.480221
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated([''], '', None)
    docstring_deprecated_1 = DocstringDeprecated(['', ''], '1', '2')
    docstring_deprecated_2 = DocstringDeprecated(['', '', '', ''], '', '1')


# Generated at 2022-06-25 16:13:02.688653
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    local_args_0: T.List[str] = []
    local_description_0: T.Optional[str] = None
    local_arg_name_0: str = str()
    local_type_name_0: T.Optional[str] = None
    local_is_optional_0: T.Optional[bool] = None
    local_default_0: T.Optional[str] = None
    local_docstring_param_0: DocstringParam = DocstringParam(local_args_0, local_description_0, local_arg_name_0, local_type_name_0, local_is_optional_0, local_default_0)


# Generated at 2022-06-25 16:13:07.693035
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['param', 'arg', 'keyword'], 'description of a parameter', 'name of a parameter')

    assert docstring_raises.args == ['param', 'arg', 'keyword']
    assert docstring_raises.description == 'description of a parameter'
    assert docstring_raises.type_name == 'name of a parameter'


# Generated at 2022-06-25 16:13:12.404952
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_0 = ['parameter', 'arg', 'attribute', 'key']
    description_0 = 'description'
    arg_name_0 = 'arg_name'
    type_name_0 = 'type_name'
    is_optional_0 = True
    default_0 = 'default'
    obj_0 = DocstringParam(args_0, description_0, arg_name_0, type_name_0, is_optional_0, default_0)


# Generated at 2022-06-25 16:13:13.842313
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert True
    

# Generated at 2022-06-25 16:13:15.394240
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises([str], T.Optional[str], T.Optional[str])


# Generated at 2022-06-25 16:13:20.182143
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()

    args = None
    description = "Desc"
    version = None
    docstring_deprecated_0 = DocstringDeprecated(args, description, version)
    # This works because we are using default arguments in DocstringDeprecated
    assert docstring_deprecated_0.args == args and \
            docstring_deprecated_0.description == description and \
            docstring_deprecated_0.version == version


# Generated at 2022-06-25 16:13:25.916275
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    docstringMeta_0 = DocstringMeta(
        [], ""
    )
    docstringRaises_0 = DocstringRaises(
        [], "", "",
    )
    assert isinstance(docstringRaises_0, DocstringMeta)


# Generated at 2022-06-25 16:13:30.656282
# Unit test for constructor of class Docstring
def test_Docstring():
    assert isinstance(Docstring(), Docstring)


# Generated at 2022-06-25 16:13:39.683264
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_0 = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description_0 = "description"
    arg_name_0 = "arg_name"
    type_name_0 = "type_name"
    is_optional_0 = True
    default_0 = "default"
    docstring_param_0 = DocstringParam(args_0, description_0, arg_name_0, type_name_0, is_optional_0, default_0)


# Generated at 2022-06-25 16:13:41.548232
# Unit test for constructor of class Docstring
def test_Docstring():
    #
    # The following lines are manually written to test the class constructor.
    #
    docstringObj = Docstring()


# Generated at 2022-06-25 16:13:44.684771
# Unit test for constructor of class ParseError
def test_ParseError():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    parse_error_0 = ParseError(docstring_0, docstring_0)



# Generated at 2022-06-25 16:13:47.842111
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_0 = DocstringRaises([], "", "")
    docstring_raises_0.description
    docstring_raises_0.type_name


# Generated at 2022-06-25 16:13:53.458120
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    expected1 = DocstringDeprecated(['deprecated'], 'version 1.0 removed', '1.0')
    actual1 = DocstringDeprecated(['deprecated'], 'version 1.0 removed', '1.0')
    assert expected1.args == actual1.args
    assert expected1.description == actual1.description
    assert expected1.version == actual1.version
    expected2 = DocstringDeprecated(['deprecated'], None, None)
    actual2 = DocstringDeprecated(['deprecated'], None, None)
    assert expected2.args == actual2.args
    assert expected2.description == actual2.description
    assert expected2.version == actual2.version


# Generated at 2022-06-25 16:13:56.689616
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(args, None, None)
    # Arguments "description" and "version" are optional



# Generated at 2022-06-25 16:14:04.038500
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Element 0
    args_0 = []
    description_0 = 'This is a docstring for a class.'
    type_name_0 = 'None'
    is_generator_0 = False
    return_name_0 = None
    docstring_returns_0 = DocstringReturns(args_0, description_0, type_name_0, is_generator_0, return_name_0)
    # Element 1
    args_1 = []
    description_1 = 'This is a docstring for a class.'
    type_name_1 = 'None'
    is_generator_1 = False
    return_name_1 = None
    docstring_returns_1 = DocstringReturns(args_1, description_1, type_name_1, is_generator_1, return_name_1)
   

# Generated at 2022-06-25 16:14:08.176888
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_1 = DocstringDeprecated([], None, None)
    assert docstring_1.args == []
    assert docstring_1.description == None
    assert docstring_1.version == None



# Generated at 2022-06-25 16:14:19.352613
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringParam(["param"],None,"arg_name",None,None,None)
    assert docstring_0.args == ["param"]
    assert docstring_0.description == None
    assert docstring_0.arg_name == "arg_name"
    assert docstring_0.type_name == None
    assert docstring_0.is_optional == None
    assert docstring_0.default == None
    docstring_1 = DocstringReturns(["param"],None,None,None)
    assert docstring_1.args == ["param"]
    assert docstring_1.description == None
    assert docstring_1.type_name == None
    assert docstring_1.is_generator == None
    assert docstring_1.return_name == None

# Generated at 2022-06-25 16:14:36.099172
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Assert that docstring_0 is an instance of class DocstringReturns
    assert type(docstring_0) == DocstringReturns
    # Assert that docstring_0 attribute 'args' is a list of type_name of type str
    assert type(docstring_0.args) == list
    assert type(docstring_0.args[0]) == str
    # Assert that docstring_0 attribute 'description' is of type str
    assert type(docstring_0.description) == str
    # Assert that docstring_0 attribute 'type_name' is of type str
    assert type(docstring_0.type_name) == str
    # Assert that docstring_0 attribute 'is_generator' is of type bool
    assert type(docstring_0.is_generator) == bool
    # Assert that docstring

# Generated at 2022-06-25 16:14:45.451239
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_0 = []
    description_0 = "`str` is a sequence of characters."
    type_name_0 = "str"
    obj_0 = DocstringRaises(
        args_0,
        description_0,
        type_name_0
    )
    assert isinstance(
        obj_0,
        DocstringRaises
    ) == True
    assert obj_0.args == args_0
    assert obj_0.description == description_0
    assert obj_0.type_name == type_name_0


# Generated at 2022-06-25 16:14:45.976420
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:14:47.770550
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(['a'], 'b')


# Generated at 2022-06-25 16:14:51.365392
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ["args"]
    test_description = "description"
    test_DocstringMeta = DocstringMeta(test_args, test_description)

    # Check if the value of args matches the inputted value
    assert test_DocstringMeta.args == ["args"]

    # Check if the value of description matches the inputted value
    assert test_DocstringMeta.description == "description"


# Generated at 2022-06-25 16:14:57.544658
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    from typing import List, Optional
    from typing_extensions import final
    args = [str]
    description = str
    arg_name = str
    type_name = str
    is_optional = bool
    default = str
    docstring_param_0 = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    args = [str]
    description = str
    arg_name = str
    type_name = str
    is_optional = bool
    default = str
    docstring_param_1 = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    docstring_param_0.args = []
    assert docstring_param_0.args == docstring_param_1.args

# Generated at 2022-06-25 16:14:59.598402
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(['param'], '', '1.0')


# Generated at 2022-06-25 16:15:11.337191
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        DocstringRaises(["arg"], "description", "type_name")
    except ParseError as e:
        print(e)
    else:
        pass
    finally:
        try:
            DocstringRaises(["arg"], "description", "type_name")
        except ParseError as e:
            print(e)
        else:
            pass
        finally:
            try:
                DocstringRaises(["arg"], "description", "type_name")
            except ParseError as e:
                print(e)
            else:
                pass
            finally:
                try:
                    DocstringRaises(["arg"], "description", "type_name")
                except ParseError as e:
                    print(e)
                else:
                    pass

# Generated at 2022-06-25 16:15:20.295469
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    docstring_1 = Docstring()

    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert isinstance(docstring_0.meta, list)
    assert docstring_0.meta == []
    assert docstring_0.params == []
    assert docstring_0.raises == []
    assert docstring_0.returns is None
    assert docstring_0.deprecation is None

    assert docstring_1.short_description is None
    assert docstring_1.long_description is None
    assert docstring_1.blank_after_short_description is False

# Generated at 2022-06-25 16:15:28.829089
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from pydocstyle.utils import DocstringMeta
    docstring_meta_0 = DocstringMeta([], None)
    docstring_meta_1 = DocstringMeta(None, "")
    docstring_meta_2 = DocstringMeta([], "")
    assert docstring_meta_0.args is None
    assert docstring_meta_0.description is None
    assert docstring_meta_1.args is None
    assert docstring_meta_1.description == ""
    assert docstring_meta_2.args == []
    assert docstring_meta_2.description == ""


# Generated at 2022-06-25 16:15:54.891869
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test constructor of class Docstring."""
    ds = Docstring()
    assert ds is not None, "Object docstring should not be None"
    assert ds.short_description is None, "Docstring value should be None"
    assert ds.long_description is None, "Docstring value should be None"
    assert ds.blank_after_short_description is False, "Docstring value should be False"
    assert ds.blank_after_long_description is False, "Docstring value should be False"
    assert len(ds.meta) == 0, "Docstring value should be an empty list"
    print("All test cases passed for constructor of class Docstring")


# Generated at 2022-06-25 16:16:01.671624
# Unit test for constructor of class ParseError
def test_ParseError():
    docstring_1 = Docstring()
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    assert isinstance(parse_error_1, ParseError)
    assert parse_error_1 is not parse_error_0
    try:
        parse_error_1 = ParseError(docstring_1, 0)
    except Exception as e:
        assert isinstance(e, TypeError)


# Generated at 2022-06-25 16:16:07.453304
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    docstring_returns_0 = DocstringReturns(['returns'], "returns value", None, False, None)
    assert docstring_returns_0.return_name is None
    assert docstring_returns_0.args == ['returns']
    assert docstring_returns_0.description == "returns value"
    assert docstring_returns_0.type_name is None
    assert docstring_returns_0.is_generator is False
    docstring_returns_1 = DocstringReturns(['return'], "returns value", None, False, "result")
    assert docstring_returns_1.return_name == "result"
    assert docstring_returns_1.args == ['return']

# Generated at 2022-06-25 16:16:11.069333
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    docstring_returns_0 = DocstringReturns(args=list(), description=None, type_name=None, is_generator=False, return_name=None)


# Generated at 2022-06-25 16:16:14.334177
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Implicit test if class constructor is invoked without errors
    DocstringReturns(args=None, description=None, type_name=None, is_generator=None, return_name=None)


# Generated at 2022-06-25 16:16:16.501433
# Unit test for constructor of class ParseError
def test_ParseError():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()


# Generated at 2022-06-25 16:16:18.415569
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    
    DocstringReturns(['arg'], 'description', 'type_name', True, 'return_name')
    DocstringReturns(['arg'], 'description', 'type_name', True)



# Generated at 2022-06-25 16:16:22.926175
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_1 = Docstring()
    parse_error_0 = ParseError()
    DocstringMeta([], None)
    DocstringMeta.args = None
    DocstringMeta.description =None


# Generated at 2022-06-25 16:16:27.303672
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(
        args=[],
        description="Deprecation documentation",
        version="3.0.0"
    )
    assert docstring_deprecated.args == []
    assert docstring_deprecated.description == "Deprecation documentation"
    assert docstring_deprecated.version == "3.0.0"



# Generated at 2022-06-25 16:16:37.550648
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    from astroid import MANAGER
    from gitmanager import parse
    from gitmanager.parse import DocstringReturns
    from gitmanager.parse import DocstringMeta
    from gitmanager.parse import Docstring
    from gitmanager.parse import DocstringParam
    from gitmanager.parse import DocstringRaises
    from gitmanager.parse import parse_docstring
    from gitmanager.parse import ParseError
    from gitmanager.parse import DocstringDeprecated
    from typing import List
    from typing import Optional
    from typing import Tuple
    # Testing constructor
    test_DocstringReturns_0 = DocstringReturns(
        args=[], description='', type_name=None, is_generator=False
    )
    # Testing constructor

# Generated at 2022-06-25 16:17:07.811088
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    if (docstring_1.meta != []):
        raise RuntimeError
    else:
        True


# Generated at 2022-06-25 16:17:08.849732
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:17:13.199072
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    docstring_deprecated_0 = DocstringDeprecated([], '', '')
    assert isinstance(docstring_deprecated_0.version, str)
    assert isinstance(docstring_deprecated_0.description, str)
    assert isinstance(docstring_deprecated_0.args, list)


# Generated at 2022-06-25 16:17:16.637791
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    args_0 = list()
    description_0 = None
    version_0 = None
    object_0 = DocstringDeprecated(args_0, description_0, version_0)


# Generated at 2022-06-25 16:17:23.999074
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["eee", "fff"], "ddd", "aaa", "bbb", True, "ccc")
    print("args: " + str(docstring_param.args))
    print("description: " + docstring_param.description)
    print("arg_name: " + docstring_param.arg_name)
    print("type_name: " + str(docstring_param.type_name))
    print("is_optional: " + str(docstring_param.is_optional))
    print("default: " + str(docstring_param.default))


# Generated at 2022-06-25 16:17:33.583153
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    docstring_1 = Docstring()
    docstring_2 = Docstring()
    docstring_3 = Docstring()
    docstring_4 = Docstring()
    parse_error_0 = ParseError()
    parse_error_1 = ParseError()
    parse_error_2 = ParseError()
    parse_error_3 = ParseError()
    parse_error_4 = ParseError()
    parse_error_5 = ParseError()
    parse_error_6 = ParseError()
    parse_error_7 = ParseError()
    parse_error_8 = ParseError()
    parse_error_9 = ParseError()
    parse_error_10 = ParseError()


# Generated at 2022-06-25 16:17:39.485347
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_1 = Docstring()
    docstring_meta_0 = DocstringMeta(
        ["param", "arg"],
        "description",
    )
    assert isinstance(docstring_meta_0, DocstringMeta)
    assert docstring_meta_0.args == ["param", "arg"]
    assert docstring_meta_0.description == "description"


# Generated at 2022-06-25 16:17:42.344254
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # DocstringMeta(__init__) test 1
    docstring_Meta_0 = DocstringMeta(['param'], 'This is the first test case for DocstringMeta constructor')
    assert isinstance(docstring_Meta_0, DocstringMeta)


# Generated at 2022-06-25 16:17:54.283633
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args_0 = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 
    '', '', '', '', '', '', '']
    description_0 = ['']
    type_name_0 = ['', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 
    '', '', '', '', '', '', '']
    is_generator_0 = [False, True]

# Generated at 2022-06-25 16:17:56.145914
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:19:04.723902
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    docstring_deprecated_0 = DocstringDeprecated(['deprecated'], 'Deprecated', '1.0')



# Generated at 2022-06-25 16:19:07.249383
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = Docstring()
    param_test_0 = DocstringParam(["param"], "test for param", "arg_name", "type_name", True, "default")


# Generated at 2022-06-25 16:19:09.604821
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam_0 = DocstringParam(list(), None, None, None, None, None)
    assert docstringParam_0 is not None


# Generated at 2022-06-25 16:19:17.197686
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  args = ["a1", "a2"]
  description = "desc"
  type_name = "type"
  docstring_raises_0 = DocstringRaises(args, description, type_name)
  assert docstring_raises_0.args == args
  assert docstring_raises_0.description == description
  assert docstring_raises_0.type_name == type_name


# Generated at 2022-06-25 16:19:21.448322
# Unit test for constructor of class Docstring
def test_Docstring():
    instance_0 = Docstring()
    assert instance_0.short_description is None
    assert instance_0.long_description is None
    assert instance_0.blank_after_short_description is False
    assert instance_0.blank_after_long_description is False
    assert instance_0.meta == []


# Generated at 2022-06-25 16:19:29.061216
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        assert DocstringRaises
    except:
        raise AssertionError("DocstringRaises() constructor is not defined")
    try:
        assert issubclass(DocstringRaises, DocstringMeta)
    except:
        raise AssertionError("DocstringRaises() should be a subclass of DocstringMeta")


if __name__ == "__main__":
    test_DocstringRaises()
    print("DocstringRaises class is defined")

# Generated at 2022-06-25 16:19:30.549502
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = Docstring()
    docstringMeta_0 = DocstringMeta(list(),"")

# Generated at 2022-06-25 16:19:33.488294
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([":param"], "description", "arg1", "str", True, "3")


# Generated at 2022-06-25 16:19:36.873197
# Unit test for constructor of class ParseError
def test_ParseError():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
 #Instance method for class ParseError

# Generated at 2022-06-25 16:19:45.081202
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    # Create test case 1
    args_1 = ['arg']
    description_1 = 'description'
    # Construct call to the function
    DocstringMeta_Object_1 = DocstringMeta(args_1, description_1)
    # Get the value of some attributes
    args_1 = DocstringMeta_Object_1.args
    description_1 = DocstringMeta_Object_1.description

    # Create test case 2
    args_2 = ['param']
    description_2 = 'description'
    # Construct call to the function
    DocstringMeta_Object_2 = DocstringMeta(args_2, description_2)
    # Get the value of some attributes
    args_2 = DocstringMeta_Object_2.args
    description_2 = DocstringMeta_Object_2.description

    # Create test case 3
    args_3

# Generated at 2022-06-25 16:22:29.735792
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = Docstring()
    parse_error_0 = ParseError()
    docstring_meta_0 = DocstringMeta([], parse_error_0.__class__.__module__)


# Generated at 2022-06-25 16:22:36.598375
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(["arg1","arg2"],"arg6")
    # Check the value of the attribute args
    assert docstring_0.args == ["arg1","arg2"], "docstring_0.args: expected \"arg1\" and \"arg2\" but got {}".format(docstring_0.args)
    # Check the value of the attribute description
    assert docstring_0.description == "arg6", "docstring_0.description: expected \"arg6\" but got {}".format(docstring_0.description)
