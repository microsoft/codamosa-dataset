

# Generated at 2022-06-25 16:12:40.869664
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(['arg'], 'description')


# Generated at 2022-06-25 16:12:50.251032
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    
    assert repr("DocstringDeprecated") == repr(DocstringDeprecated)
    assert repr("DocstringDeprecated") != repr(DocstringRaises)
    assert repr("DocstringDeprecated") != repr(DocstringReturns)
    assert repr("DocstringDeprecated") != repr(DocstringParam)

    assert repr("DocstringDeprecated") != repr("DocstringRaises")
    assert repr("DocstringDeprecated") != repr("DocstringReturns")
    assert repr("DocstringDeprecated") != repr("DocstringParam")

    test_case_0()


if __name__ == "__main__":
    test_DocstringDeprecated()
     
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-25 16:12:52.481560
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    if not isinstance(error, RuntimeError):
        error = ParseError("test")


# Generated at 2022-06-25 16:12:58.966452
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    print("Constructor for Class Docstring successful")
test_Docstring()


# Generated at 2022-06-25 16:13:00.543905
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(
        [], 'This is an error',  str
    )



# Generated at 2022-06-25 16:13:04.780047
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param"]
    description = "test description"
    arg_name = "test_name"
    type_name = "int"
    is_optional = True
    default = "10"
    test_case = DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-25 16:13:06.407487
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param", "arg", "parameter"], "A test")


# Generated at 2022-06-25 16:13:12.195989
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "parameter", "arg", "argument", "attribute", "key", "keyword")
    assert (isinstance(docstring_param.args, list))
    assert (isinstance(docstring_param.description, str))
    assert (isinstance(docstring_param.arg_name, str))
    assert (isinstance(docstring_param.type_name, str))
    assert (isinstance(docstring_param.is_optional, bool))
    assert (isinstance(docstring_param.default, str))


# Generated at 2022-06-25 16:13:13.952512
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "Description")
    pass



# Generated at 2022-06-25 16:13:22.052808
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description == None
    assert docstring_0.long_description == None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    # Test meta is an array
    assert len(docstring_0.meta) == 0
    print('Test Docstring constructor PASS')

test_Docstring()
test_case_0()

# Generated at 2022-06-25 16:13:33.670062
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dsr = DocstringRaises(["param"], "description", "type_name")
    if dsr.args != ["param"] or dsr.description != "description" or dsr.type_name != "type_name":
        raise AssertionError()


# Generated at 2022-06-25 16:13:36.910305
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    case = DocstringMeta(["param"], "")
    assert case.args == ["param"]
    assert case.description == ""


# Generated at 2022-06-25 16:13:39.433066
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError(RuntimeError)
    assert error.__str__ == "this is a new error"



# Generated at 2022-06-25 16:13:44.142741
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test instansiate DocstringRaises class with description
    param_0 = DocstringRaises(['raises', 'IllegalArgumentException'], 'Stuff', None)
    assert len(param_0.args) == 2
    assert param_0.description == 'Stuff'
    assert param_0.type_name == None


# Generated at 2022-06-25 16:13:46.262153
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam([], 'param arg', 'arg', 'int', True, '2')


# Generated at 2022-06-25 16:13:51.716371
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta_0 = DocstringMeta(['param'], 'description')
    assert meta_0.args == ['param']
    assert meta_0.description == 'description'


# Generated at 2022-06-25 16:14:00.541038
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_DocstringParam_1 = DocstringParam(['param'], 'description', 'arg_names', 'str', 'True', 'None')
    if ((test_DocstringParam_1.args) == ['param']) and (test_DocstringParam_1.description == 'description') and (test_DocstringParam_1.arg_name == 'arg_names') and (test_DocstringParam_1.type_name == 'str') and (test_DocstringParam_1.is_optional == 'True') and (test_DocstringParam_1.default == 'None'):
        print("passed")
    else:
        print("failed")


# Generated at 2022-06-25 16:14:07.116154
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    type_name = "None"
    type_name = None
    description = "missing 1 required positional argument: 'arg'"
    
    result = DocstringRaises(args, description, type_name)
    assert isinstance(result, DocstringRaises)



# Generated at 2022-06-25 16:14:18.643566
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test DocstringParam constructor."""
    args_val = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description_val = "description"
    arg_name_val = "arg_name"
    type_name_val = "type_name"
    is_optional_val = True
    default_val = "default"

    # execute constructor
    param = DocstringParam(args_val, description_val, arg_name_val, type_name_val, is_optional_val, default_val)

    # assert all attributes are set correctly
    assert param.args == args_val
    assert param.description == description_val
    assert param.arg_name == arg_name_val
    assert param.type_name == type_name_val
    assert param.is_optional == is_optional

# Generated at 2022-06-25 16:14:19.665299
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("test")

# Generated at 2022-06-25 16:14:31.157270
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Initialize an object of DocstringReturns
    args_0 = ["return", "returns"]
    DocstringReturns_0 = DocstringReturns(args_0, None, None, False, None)
    assert DocstringReturns_0.type_name == None


# Generated at 2022-06-25 16:14:36.743517
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_1 = DocstringParam(['a string', 'a string', 'include=False', 'None'], 'the string')
    assert docstring_1.args == ['a string', 'a string', 'include=False', 'None']
    assert docstring_1.description == 'the string'
    assert docstring_1.arg_name == 'a string'
    assert docstring_1.type_name == 'a string'
    assert docstring_1.is_optional == 'include=False'
    assert docstring_1.default == 'None'


# Generated at 2022-06-25 16:14:39.493173
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], "test description", "test_param", "int", True, "")


# Generated at 2022-06-25 16:14:40.474766
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()

# Generated at 2022-06-25 16:14:50.038961
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    Define a class DocstringReturns which inherits from DocstringMeta
    """
    
    class DocstringReturns(DocstringMeta):
        def __init__(
            self,
            args: T.List[str],
            description: T.Optional[str],
            type_name: T.Optional[str],
            is_generator: bool,
            return_name: T.Optional[str] = None,
        ):
            super().__init__(args, description)
            self.type_name = type_name
            self.is_generator = is_generator
            self.return_name = return_name



# Generated at 2022-06-25 16:14:53.248129
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(["A","B"], "testing")
    assert doc.args[0] == "A"
    assert doc.args[1] == "B"
    assert doc.description == "testing"


# Generated at 2022-06-25 16:14:56.201877
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(None, None, None)
    assert docstring_deprecated


# Generated at 2022-06-25 16:15:05.938827
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["one", "two"]
    description = "test param"
    arg_name = "test"
    type_name = "str"
    is_optional = True
    default = "None"

    test_case = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert test_case.args == args
    assert test_case.description == description
    assert test_case.arg_name == arg_name
    assert test_case.type_name == type_name
    assert test_case.is_optional == is_optional
    assert test_case.default == default


# Generated at 2022-06-25 16:15:07.096550
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    my_docstring_meta = DocstringMeta(['arg'], 'description')
    assert my_docstring_meta.args == ['arg']
    assert my_docstring_meta.description == 'description'


# Generated at 2022-06-25 16:15:09.134540
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    msg_0=DocstringParam(['param', 'arg'], 'test description for argument arg', 'arg', 'test', True, '1')


# Generated at 2022-06-25 16:15:18.918081
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()



# Generated at 2022-06-25 16:15:20.569521
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_0 = DocstringParam([], '', '', '', '', '')


# Generated at 2022-06-25 16:15:23.042544
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param','arg','argument','key','keyword'], '', '', None, None, None)


# Generated at 2022-06-25 16:15:24.750157
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg", "type", True, "1")


# Generated at 2022-06-25 16:15:26.626542
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc_returns_0 = DocstringReturns(["return"], "description", "int", False)


# Generated at 2022-06-25 16:15:28.633160
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_case_0()

test_DocstringRaises()

# Generated at 2022-06-25 16:15:29.875120
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:15:31.499925
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(["return"], None, None, True, None)


# Generated at 2022-06-25 16:15:33.901566
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "description", "version")
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-25 16:15:36.417394
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("This is a exception message")


# Generated at 2022-06-25 16:15:50.232510
# Unit test for constructor of class ParseError
def test_ParseError():
    
    ParseError_obj1 = ParseError()
    assert True


# Generated at 2022-06-25 16:15:52.384614
# Unit test for constructor of class DocstringParam
def test_DocstringParam():

    docstringparam_0 = DocstringParam(['param'], 'A parameter', 'arg', 'int', True, 'None')


# Generated at 2022-06-25 16:15:53.479358
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:15:54.516823
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass


# Generated at 2022-06-25 16:16:03.419712
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()
    assert(docstring_0.short_description == None)
    assert(docstring_0.long_description == None)
    assert(docstring_0.blank_after_short_description == False)
    assert(docstring_0.blank_after_long_description == False)
    assert(docstring_0.params == [])
    assert(docstring_0.meta == [])
    assert(docstring_0.raises == [])
    assert(docstring_0.deprecation == None)
    assert(docstring_0.returns == None)

test_case_0()
test_DocstringDeprecated()

# Generated at 2022-06-25 16:16:14.509565
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(
        [],
        "description",
        "type_name",
        True,
        return_name='return_name'
    )
    docstring_returns_1 = DocstringReturns(
        [],
        "description",
        "type_name",
        False
    )
    docstring_returns_2 = DocstringReturns(
        [],
        description=None,
        type_name=None,
        is_generator=False,
        return_name=None
    )
    assert(docstring_returns_0.type_name == "type_name")
    assert(docstring_returns_0.is_generator == True)
    assert(docstring_returns_0.return_name == "return_name")

# Generated at 2022-06-25 16:16:18.461868
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(["args"], None, None, False)
    assert docstring_0.args == "args"
    assert docstring_0.description == None
    assert docstring_0.type_name == None
    assert docstring_0.is_generator == False
    assert docstring_0.return_name == None


# Generated at 2022-06-25 16:16:22.408462
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        ['return', 'returns'],
        None,
        'float',
        False,
        None,
    )

# Generated at 2022-06-25 16:16:24.918059
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')


# Generated at 2022-06-25 16:16:26.483974
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(args=[], description='')


# Generated at 2022-06-25 16:16:37.024120
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("something went wrong")


# Generated at 2022-06-25 16:16:38.744235
# Unit test for constructor of class Docstring
def test_Docstring():
    # Unit test for constructor of class Docstring
    assert(test_case_0())

# Generated at 2022-06-25 16:16:42.662510
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("docstring parsing failed")
    except ParseError as e:
        assert(str(e) == "docstring parsing failed")


# Generated at 2022-06-25 16:16:46.247172
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_Deprecated = DocstringDeprecated(
        ['9999'], 'string', 'string')
    assert docstring_Deprecated.args == ['9999']
    assert docstring_Deprecated.description == 'string'
    assert docstring_Deprecated.version == 'string'


# Generated at 2022-06-25 16:16:53.018219
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        docstring_0 = DocstringDeprecated(['deprecated', 'parameter'], 'description', '1.0.0')
    except:
        print('TEST FAIL : test_DocstringDeprecated')


# Generated at 2022-06-25 16:16:55.331797
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam is not None



# Generated at 2022-06-25 16:16:56.819806
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["a"], "b", "c", "d", False, "e")
    

# Generated at 2022-06-25 16:17:00.674141
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args_0 = ['param', 'arg']
    description_0 = "description"
    docstringMeta_0 = DocstringMeta(args_0, description_0)


# Generated at 2022-06-25 16:17:02.193400
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(test_case_0())
    print("test_Docstring passed")


# Generated at 2022-06-25 16:17:09.754665
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DOCSTRING_DEPRECATED_args = [
        "param",
        "parameter",
        "arg",
        "argument"
    ]
    DOCSTRING_DEPRECATED_description = "description"
    DOCSTRING_DEPRECATED_version = "version"

    docstring_deprecated = DocstringDeprecated(
        DOCSTRING_DEPRECATED_args,
        DOCSTRING_DEPRECATED_description,
        DOCSTRING_DEPRECATED_version
    )


# Generated at 2022-06-25 16:17:32.375388
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("Oops")
    print("Exception message: ",exc)


# Generated at 2022-06-25 16:17:35.709071
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns([], None, None, False, None)


# Generated at 2022-06-25 16:17:37.404333
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns0 = DocstringReturns(["return"], "return the result", "int")


# Generated at 2022-06-25 16:17:40.150505
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises","ValueError"]
    description = None
    type_name = "ValueError"
    test = DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:17:41.562853
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("error message")
    assert error.args == ('error message',)


# Generated at 2022-06-25 16:17:42.386281
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert True


# Generated at 2022-06-25 16:17:43.327293
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-25 16:17:50.317685
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_Raises = DocstringRaises(['raises'], 'description', 'TypeError')
    assert docstring_Raises.args == ['raises']
    assert docstring_Raises.description == 'description'
    assert docstring_Raises.type_name == 'TypeError'


# Generated at 2022-06-25 16:17:51.232440
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_case_0()


# Generated at 2022-06-25 16:17:54.641905
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [""]
    description = "description"
    meta = DocstringMeta(args, description)

    # Test for constructor
    assert meta.args == args
    assert meta.description == description


# Generated at 2022-06-25 16:18:32.482168
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(['deprecated', 'version'], 'because version x is released', 'x')


# Generated at 2022-06-25 16:18:35.846455
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_meta = DocstringReturns(
        ['param', 'arg', 'attribute'],
        'description',
        'type_name',
        True,
        'return_name',
    )


# Generated at 2022-06-25 16:18:39.297672
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args_0 = ["param", "spam", "description"]
    description_0 = "description"
    docstringmeta_0 = DocstringMeta(args_0, description_0)


# Generated at 2022-06-25 16:18:42.044565
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta([], "")

# Generated at 2022-06-25 16:18:48.035066
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['param']
    description = 'These are the params'
    version = '1.0'

    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version



# Generated at 2022-06-25 16:18:52.183222
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_return = DocstringReturns(['return'], '', '', False, 'result')
    assert docstring_return is not None
    assert docstring_return.return_name == 'result'



# Generated at 2022-06-25 16:18:55.870584
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    # Test that the constructor sets the attributes appropriately
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

test_Docstring()


# Generated at 2022-06-25 16:19:05.615456
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([], "wrong input", "TypeError")
    DocstringRaises(["a", "b"], "wrong input", "TypeError")
    DocstringRaises([], None, None)
    DocstringRaises(["a", "b"], None, None)
    DocstringRaises([], None, "TypeError")
    DocstringRaises(["a", "b"], None, "TypeError")
    DocstringRaises([], "wrong input", None)
    DocstringRaises(["a", "b"], "wrong input", None)


# Generated at 2022-06-25 16:19:08.529326
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        test_case_0()
    except NameError as error:
        print(error.args)
    #assert 0

test_DocstringRaises()

# Generated at 2022-06-25 16:19:15.127917
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert(str(e) == "Test")


# Generated at 2022-06-25 16:20:46.084343
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:20:48.990361
# Unit test for constructor of class Docstring
def test_Docstring():
    #docstring_0 = Docstring()
    assert True == True

if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-25 16:20:52.147802
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        test_case_0()
    except Exception:
        pass
    else:
        raise Exception("test_case_0 of DocstringMeta failed!")



# Generated at 2022-06-25 16:20:56.006446
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    description = "description"
    type_name = "type_name"
    is_generator = False
    return_name = "return_name"
    docstring_0 = DocstringReturns(args, description, type_name, is_generator, return_name)


# Generated at 2022-06-25 16:21:00.572811
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], None, None).args == []
    assert DocstringRaises([], None, None).description == None
    assert DocstringRaises([], None, None).type_name == None


# Generated at 2022-06-25 16:21:01.420563
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:21:02.226156
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:21:09.488218
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args_0 = ['arg', 'arg2']
    description_0 = 'This docstring has two parameters whose names are arg and arg2'
    docstring_meta_0 = DocstringMeta(args_0, description_0)
    assert docstring_meta_0.args == ['arg', 'arg2']
    assert docstring_meta_0.description == 'This docstring has two parameters whose names are arg and arg2'


# Generated at 2022-06-25 16:21:12.735708
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['param'], 'some description', 'some type')


# Generated at 2022-06-25 16:21:21.135506
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(['param'], 'description', 'arg', 'type',
                        False, 'default')
    assert docstring_param_0.args == ['param']
    assert docstring_param_0.description == 'description'
    assert docstring_param_0.arg_name == 'arg'
    assert docstring_param_0.type_name == 'type'
    assert docstring_param_0.is_optional == False
    assert docstring_param_0.default == 'default'

