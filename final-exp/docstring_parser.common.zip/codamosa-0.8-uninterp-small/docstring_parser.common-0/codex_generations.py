

# Generated at 2022-06-25 16:12:45.068456
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        DocstringRaises(['', '', '', '', '', ''], '', '')
    except Exception:
        # test failed if exception is raised
        assert False
    else:
        assert True


# Generated at 2022-06-25 16:12:48.812758
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["arg1", "arg2"]
    description = "This is a test"
    docstring_0 = DocstringMeta(args, description)
    assert docstring_0.args == ["arg1", "arg2"]
    assert docstring_0.description == "This is a test"


# Generated at 2022-06-25 16:12:53.491107
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []


# Generated at 2022-06-25 16:13:00.895746
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringParam(
        ["param", "arg", "keyword"], "description", "arg", "type", True
    )
    assert dm is not None
    assert dm.args == ["param", "arg", "keyword"]
    assert dm.description == "description"
    assert dm.arg_name == "arg"
    assert dm.type_name == "type"
    assert dm.is_optional == True


# Generated at 2022-06-25 16:13:02.153910
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc0 = DocstringMeta(args = [], description = "")


# Generated at 2022-06-25 16:13:05.359140
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_param = DocstringReturns(
        args=['return', 'returns'],
        description='value. ',
        type_name='int',
        is_generator=False,
        return_name=None
    )


# Generated at 2022-06-25 16:13:13.217963
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(None, None, None)
    assert docstring_deprecated_0.args == None
    assert docstring_deprecated_0.description == None
    assert docstring_deprecated_0.version == None
    args_0 = None
    description_0 = None
    version_0 = None
    docstring_deprecated_1 = DocstringDeprecated(args_0, description_0, version_0)
    assert docstring_deprecated_1.args == None
    assert docstring_deprecated_1.description == None
    assert docstring_deprecated_1.version == None
    args_1 = None
    description_1 = None
    version_1 = None

# Generated at 2022-06-25 16:13:14.820026
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert isinstance(docstring_0, Docstring)



# Generated at 2022-06-25 16:13:20.852718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test constructor and public variables
    args = ['parameter', 'arg']
    description = 'this is a test'
    arg_name = 'arg'
    type_name = 'int'
    is_optional = True
    default = '0'
    obj = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    
    # Check if variables initialized properly
    assert obj.args == args
    assert obj.description == description
    assert obj.arg_name == arg_name
    assert obj.type_name == type_name
    assert obj.is_optional == is_optional
    assert obj.default == default


# Generated at 2022-06-25 16:13:27.212781
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_0 = DocstringRaises(
        [], "description", "type_name")
    docstring_raises_0.description = "description"
    docstring_raises_0.args = []
    docstring_raises_0.type_name = "type_name"
    assert docstring_raises_0.description == "description"
    assert docstring_raises_0.args == []
    assert docstring_raises_0.type_name == "type_name"


# Generated at 2022-06-25 16:13:35.267793
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("error")


# Generated at 2022-06-25 16:13:43.237650
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = Docstring()
    docstring_1 = Docstring()
    docstring_2 = Docstring()
    docstring_3 = Docstring()
    docstring_4 = Docstring()
    docstring_5 = Docstring()
    docstring_6 = Docstring()
    docstring_7 = Docstring()
    docstring_8 = Docstring()
    docstring_9 = Docstring()
    docstring_10 = Docstring()
    docstring_11 = Docstring()


# Generated at 2022-06-25 16:13:48.236635
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test with empty parameters
    param_args = []
    param_description = None
    param_version = None
    d = DocstringDeprecated(param_args, param_description, param_version)
    assert(d.args == param_args)
    assert(d.description == param_description)
    assert(d.version == param_version)


# Generated at 2022-06-25 16:13:49.176573
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_0()


# Generated at 2022-06-25 16:13:56.772793
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['index']
    description = 'Returns the index of the first occurrence of needle in haystack, or -1 if needle is not part of haystack.'
    docstring_meta_0 = DocstringMeta(args, description)
    args_docmeta_0 = docstring_meta_0.args
    desc_docmeta_0 = docstring_meta_0.description


# Generated at 2022-06-25 16:13:58.108651
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['return'], 'None', 'None', True)


# Generated at 2022-06-25 16:14:02.788557
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(['', '', '', '', '', ''], None, None)


# Generated at 2022-06-25 16:14:03.944000
# Unit test for constructor of class ParseError
def test_ParseError():
    temp = ParseError("test")


# Generated at 2022-06-25 16:14:06.943447
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = DocstringParam(['parameter'], 'The required parameter', 'arg', 'str', True, "default")


# Generated at 2022-06-25 16:14:08.736657
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    return


# Generated at 2022-06-25 16:14:24.911160
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(["Param","param"], "This is description")
    assert obj.args == ["Param","param"]
    assert obj.description == "This is description"


# Generated at 2022-06-25 16:14:35.337305
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [
        'param'
    ]
    description = 'description'
    arg_name = 'arg'
    type_name = 'Optional[int]'
    is_optional = True
    default = '1'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args[0] == 'param'
    assert docstring_param.description == 'description'
    assert docstring_param.arg_name == 'arg'
    assert docstring_param.type_name == 'Optional[int]'
    assert docstring_param.is_optional == True
    assert docstring_param.default == '1'


# Generated at 2022-06-25 16:14:44.354103
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # raises is not none
    try:
        DocstringRaises([1, 2, 3], 's', 4)
    except Exception as e:
        print('Cannot create DocstringRaises')
    else:
        print('Create DocstringRaises')
    # raises is none
    try:
        DocstringRaises([1, 2, 3], 's', None)
    except Exception as e:
        print('Cannot create DocstringRaises')
    else:
        print('Create DocstringRaises')


# Generated at 2022-06-25 16:14:53.872490
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1 = Docstring()
    docstring_1.short_description = "class docstrings"
    docstring_1.long_description = "This is the first line of the docstring.\n\nThe second line of the docstring."
    docstring_1.blank_after_short_description = False
    docstring_1.blank_after_long_description = True
    docstring_1.meta = [
    DocstringReturns(['Return', 'type'], 'The', 'return', False, None),
    DocstringRaises(['Raises'], 'If', 'ValueError'),
    DocstringRaises(['Raises'], 'If', 'Exception'),
    DocstringRaises(['Raises', 'exception'], 'if', 'Exception'),
    ]


# Generated at 2022-06-25 16:14:59.079419
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_0 = DocstringMeta(args=['arg', 'argument', 'attribute', 'key'], description="description")
    assert docstring_0.args == ['arg', 'argument', 'attribute', 'key']
    assert docstring_0.description == 'description'


# Generated at 2022-06-25 16:15:07.027784
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description is False
    assert docstring_0.blank_after_long_description is False
    assert docstring_0.meta == []
    assert docstring_0.params == []
    assert docstring_0.raises == []
    assert docstring_0.returns is None
    assert docstring_0.deprecation is None


# Generated at 2022-06-25 16:15:08.303673
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()
    test_case_1()


# Generated at 2022-06-25 16:15:15.646220
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    docstring_param_0 = DocstringParam(["param", "arg"], "description",
                                       "arg", None, None, None)
    assert docstring_param_0.arg_name == "arg"
    assert docstring_param_0.type_name == None
    assert docstring_param_0.is_optional == None
    assert docstring_param_0.default == None
    assert docstring_param_0.description == "description"
    docstring_param_1 = DocstringParam(["param", "arg"], "description",
                                       "arg", "type", True,
                                       "default value")
    assert docstring_param_1.arg_name == "arg"
    assert docstring_param_1.type_name == "type"
    assert docstring_param

# Generated at 2022-06-25 16:15:17.740068
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('some message')
    except Exception as e:
        assert e.args == 'some message'


# Generated at 2022-06-25 16:15:20.897590
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is ParseError")
        assert False
    except ParseError as e:
        assert str(e) == "This is ParseError"


# Generated at 2022-06-25 16:15:37.875343
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()

# Generated at 2022-06-25 16:15:44.680980
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Case 0:
    # To test the functionality of constructor
    test_case_0()
    args = []
    assert isinstance(args, list) == True
    assert len(args) == 0
    docstring_0.short_description = "Docstring short description"
    assert isinstance(docstring_0.short_description, str) == True
    docstring_0.long_description = "Docstring long description"
    assert isinstance(docstring_0.long_description, str) == True
    docstring_0.blank_after_short_description = True
    assert docstring_0.blank_after_short_description == True
    docstring_0.blank_after_long_description = True
    assert docstring_0.blank_after_long_description == True
    docstring_0.blank_after_long_

# Generated at 2022-06-25 16:15:52.289621
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = None
    arg_name = '  '
    type_name = None
    is_optional = None
    default = None
    assert DocstringParam(args,description,arg_name,type_name,is_optional,default)


# Generated at 2022-06-25 16:15:54.371691
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    rais = DocstringRaises(["param", "parameter", "arg", "argument", "attribute", "key", "keyword"], "description", "type_name")
    assert rais.args == ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    assert rais.description == "description"
    assert rais.type_name == "type_name"


# Generated at 2022-06-25 16:15:57.017391
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises(['raises'], 'wrong type', 'TypeError')


# Generated at 2022-06-25 16:15:58.589386
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)


# Generated at 2022-06-25 16:16:02.163656
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(
        args=["param", "age"],
        description="None",
        arg_name="age",
        type_name="None",
        is_optional="None",
        default="None"
    )

# Generated at 2022-06-25 16:16:02.963370
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:16:05.856171
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["wrong_arg"], "wrong_arg", "ValueError")
    DocstringRaises(["wrong_arg"], "wrong_arg", "ValueError")


# Generated at 2022-06-25 16:16:09.999205
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert docstring_0.long_description is None
    assert docstring_0.short_description is None
    assert not docstring_0.meta


# Generated at 2022-06-25 16:16:42.643086
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_case_0()


# Generated at 2022-06-25 16:16:44.799961
# Unit test for constructor of class ParseError
def test_ParseError():
    instance = ParseError()
    assert isinstance(instance, RuntimeError)


# Generated at 2022-06-25 16:16:45.759572
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    item = DocstringRaises([], None, None)
    assert item


# Generated at 2022-06-25 16:16:48.322255
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error!")
    except ParseError as e:
        print(e)



# Generated at 2022-06-25 16:16:53.901507
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc_raises_0 = DocstringRaises(["raises", "CustomError", "Raises CustomError"], "Raises CustomError.", "CustomError")
    doc_raises_1 = DocstringRaises(["raises", "CustomError"], "Raises CustomError.", "CustomError")


# Generated at 2022-06-25 16:16:58.669192
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_DocstringDeprecated = DocstringDeprecated([" :version: "], 
        "The documentation is outdated and will be removed in the next release", "1.2.1")
    assert test_case_0.docstring_0
    assert isinstance(test_DocstringDeprecated, DocstringMeta)


# Generated at 2022-06-25 16:17:04.165915
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_0 = ["test"]
    description_0 = "test"
    arg_name_0 = "test"
    type_name_0 = "test"
    is_optional_0 = False
    default_0 = "test"
    new_obj = DocstringParam(args_0, description_0, arg_name_0, type_name_0, is_optional_0, default_0)


# Generated at 2022-06-25 16:17:05.213807
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:17:06.691009
# Unit test for constructor of class Docstring
def test_Docstring():
    assert test_case_0() == None

# Generated at 2022-06-25 16:17:13.791286
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_1 = Docstring()
    assert docstring_1.short_description == None
    assert docstring_1.long_description == None
    assert docstring_1.blank_after_short_description == False
    assert docstring_1.blank_after_long_description == False
    assert docstring_1.meta == []
    assert docstring_1.params == []
    assert docstring_1.raises == []
    assert docstring_1.returns == None
    assert docstring_1.deprecation == None


# Generated at 2022-06-25 16:18:20.903559
# Unit test for constructor of class Docstring
def test_Docstring():
    test_case_0()


# Generated at 2022-06-25 16:18:22.268046
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated([], "", "")
    assert docstring_deprecated


# Generated at 2022-06-25 16:18:27.180374
# Unit test for constructor of class ParseError
def test_ParseError():
 
    # test without parameters
    try:
        raise ParseError()

    except ParseError as e:
        assert "RuntimeError" in str(e)

    # test with parameters
    try:
        raise ParseError("Bad indentation.")

    except ParseError as e:
        assert "Bad indentation." in str(e)



# Generated at 2022-06-25 16:18:32.025459
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(
        ["returns","return"],
        "Returns a list of products",
        "list",
        False,
        "product_list"
    )
    print(str(docstring_0.args))


# Generated at 2022-06-25 16:18:34.220870
# Unit test for constructor of class ParseError
def test_ParseError():
    string = "ParseError(RuntimeError)"
    assert(str(ParseError("RuntimeError")) == string)


# Generated at 2022-06-25 16:18:39.512099
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_case = DocstringReturns(["returns"], "This method does not return anything", None, False)
    assert test_case.args == ["returns"]
    assert test_case.description == "This method does not return anything"
    assert test_case.type_name == None
    assert test_case.is_generator == False
    assert test_case.return_name == None


# Generated at 2022-06-25 16:18:45.187084
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["deprecated"], "my description", "some_version")
    assert a.args == ["deprecated"]
    assert a.description == "my description"
    assert a.version == "some_version"


# Generated at 2022-06-25 16:18:48.216649
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = list([])
    description = None
    type_name = None
    dummy = DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:18:50.474351
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError("Error occured")


# Generated at 2022-06-25 16:18:52.093741
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:20:08.669395
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()

# Generated at 2022-06-25 16:20:13.012429
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta_0 = DocstringMeta([], '')
    docstringMeta_0.args.append('arg ')
    docstringMeta_0.description = 'description'

    assert docstringMeta_0.args == ['arg ']
    assert docstringMeta_0.description == 'description'



# Generated at 2022-06-25 16:20:16.754163
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert isinstance(DocstringRaises(["raises"], None, None), DocstringRaises)


# Generated at 2022-06-25 16:20:24.979741
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = None
    description = None
    arg_name = None
    type_name = None
    is_optional = None
    default = None
    test_case_0 = DocstringParam(args,description,arg_name,type_name,is_optional,default)


# Generated at 2022-06-25 16:20:35.495687
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep_0 = DocstringDeprecated(args=['deprecated', 'since', 'version'], description="This is a deprecation notice", version="1.0.0")
    dep_1 = DocstringDeprecated(args=['deprecated'], description="This is a deprecation notice")
    dep_2 = DocstringDeprecated(args=['deprecated'], description="")
    dep_3 = DocstringDeprecated(args=['deprecation'], description="")
    dep_4 = DocstringDeprecated(args=['deprecation', 'since'], description="")
    dep_5 = DocstringDeprecated(args=['deprecated',  'since', 'version'], description="")

# Generated at 2022-06-25 16:20:38.615488
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(['return'], 'some string',
                                   'type_string', False)
    assert docstring_0.args == ['return']
    assert docstring_0.description == 'some string'
    assert docstring_0.type_name == 'type_string'
    assert docstring_0.is_generator == False
    assert docstring_0.return_name is None
    assert isinstance(docstring_0, DocstringReturns)


# Generated at 2022-06-25 16:20:41.075332
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ":deprecated: 1.0"
    description = "This function is deprecated"
    version = "1.0"
    DocstringDeprecated(args, description, version)


# Generated at 2022-06-25 16:20:48.231636
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated", "in", "version", "0.0.1", ":", "as", "of", "0.0.1"]
    description = "Use the `new_func` function instead"
    version = "0.0.1"
    test = DocstringDeprecated(args, description, version)
    if test.args == args and test.description == description and test.version == version:
        print("DocstringDeprecated passed test")
    else:
        print("DocstringDeprecated failed test")


# Generated at 2022-06-25 16:20:56.782409
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ["returns"]
    test_description = "some_desc"
    test_type_name = "return_type"
    test_is_generator = False
    test_return_name = "some_name"
    test_case = DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    assert test_case.args == test_args
    assert test_case.description == test_description
    assert test_case.type_name == test_type_name
    assert test_case.is_generator == test_is_generator
    assert test_case.return_name == test_return_name


# Generated at 2022-06-25 16:21:00.383144
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_0 = DocstringDeprecated(['hello', 'world'], 'This is a test', '0.1.1')

