

# Generated at 2022-06-25 16:12:42.118684
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()


# Generated at 2022-06-25 16:12:43.754265
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_0 = DocstringRaises([], None, None)


# Generated at 2022-06-25 16:12:45.891082
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        print("success")


# Generated at 2022-06-25 16:12:47.960306
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(
            [":raises"],
            "if something happens",
            "ValueError",
    )


# Generated at 2022-06-25 16:12:49.685993
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    pass
    # Test class constructor
    # Test class attributes


# Generated at 2022-06-25 16:12:50.705507
# Unit test for constructor of class ParseError
def test_ParseError():
    c = ParseError()


# Generated at 2022-06-25 16:12:53.668493
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert eval("DocstringMeta(args=[], description='')") == DocstringMeta(
        args=[], description=""
    )



# Generated at 2022-06-25 16:12:56.493582
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta_0 = DocstringMeta(["arg"], "description")


# Generated at 2022-06-25 16:12:59.912447
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    sample1 = DocstringParam(
        args=['param', 'attribute', 'arg'], description="",
        arg_name="self", type_name=None,
        is_optional=None, default=None
    )



# Generated at 2022-06-25 16:13:01.728837
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_1 = DocstringReturns(['returns'], 'returning something', 'int', False)


# Generated at 2022-06-25 16:13:07.222822
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(['arg'], 'description', 'type_name')


# Generated at 2022-06-25 16:13:11.154761
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    import sys
    try:
        DocstringRaises(["a", "b"], "des", "int")
    except:
        exc_class, exc, tb = sys.exc_info()
        while tb.tb_next:
            tb = tb.tb_next
        raise exc_class(exc).with_traceback(tb)


# Generated at 2022-06-25 16:13:19.492532
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-25 16:13:20.586129
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "")

# Generated at 2022-06-25 16:13:22.355850
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_DocstringReturns=DocstringReturns(['a'],'description', 'name', True, 'None')


# Generated at 2022-06-25 16:13:23.523007
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-25 16:13:26.484895
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args = ["1", "2", "3"], description = "my_description", arg_name = "my_arg_name", type_name = "my_type_name", is_optional = False, default = "None")


# Generated at 2022-06-25 16:13:28.392398
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_case_0_object = test_case_0()


test_DocstringParam()

# Generated at 2022-06-25 16:13:33.615801
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(':param arg:', 'description', 'arg', 'str', True, 'None')
    assert docstring.arg_name == "arg"
    assert docstring.type_name == "str"
    assert docstring.is_optional == True
    assert docstring.default == "None"


# Generated at 2022-06-25 16:13:37.284207
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param"], "desc")
    assert docstring_meta.args == ["param"]
    assert docstring_meta.description == "desc"


# Generated at 2022-06-25 16:13:48.629654
# Unit test for constructor of class ParseError
def test_ParseError():
    # test with no input
    try:
        raise ParseError()
    except ParseError:
        pass

    # test of normal case
    try:
        raise ParseError("Test message")
    except ParseError as e:
        assert(e.args[0] == "Test message")


# Generated at 2022-06-25 16:13:51.363268
# Unit test for constructor of class Docstring
def test_Docstring():
    s = Docstring()
    print("N/A")





# Generated at 2022-06-25 16:13:56.813760
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-25 16:13:57.940782
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_1 = DocstringMeta(['arg'],"description")
    assert docstring_meta_1.args == ['arg'] and docstring_meta_1.description == "description"


# Generated at 2022-06-25 16:14:08.126634
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param", "int"], "this is int", "int", "int", True, "")
    assert docstring_param.args == ["param", "int"]
    assert docstring_param.description == "this is int"
    assert docstring_param.arg_name == "int"
    assert docstring_param.type_name == "int"
    assert docstring_param.is_optional == True
    assert docstring_param.default == ""


# Generated at 2022-06-25 16:14:09.893316
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()
    test_case_1()
    test_case_2()



# Generated at 2022-06-25 16:14:11.485992
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("error")
    assert error.args == ("error",)


# Generated at 2022-06-25 16:14:13.635218
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=[],
        description=None,
        arg_name="arg",
        type_name=None,
        is_optional=None,
        default=None,
    )


# Generated at 2022-06-25 16:14:19.125325
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args=["raises","Exception"]
    description=None
    type_name="Exception"
    try:
        DocstringRaises(args,description,type_name)
    except RuntimeError:
        assert False
    assert True

# Generated at 2022-06-25 16:14:23.372000
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(['args'], 'description')
    assert doc_meta.args == ['args'], "DocstringMeta constructor is not correct."
    assert doc_meta.description == 'description', "DocstringMeta constructor is not correct."


# Generated at 2022-06-25 16:14:46.249529
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args_DocstringDeprecated = ["deprecated", "Present since", "1.0.0"]
    description_DocstringDeprecated = "Deprecated. Present since 1.0.0."
    version_DocstringDeprecated = "1.0.0"
    docstring_deprecated = DocstringDeprecated(args_DocstringDeprecated, description_DocstringDeprecated, version_DocstringDeprecated)
    assert docstring_deprecated.version == version_DocstringDeprecated


# Generated at 2022-06-25 16:14:47.679012
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated([], "", "")


# Generated at 2022-06-25 16:14:52.244604
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecation = DocstringDeprecated(['A', 'B'], None, None)
    assert (docstring_deprecation.args == ['A', 'B'])
    assert (docstring_deprecation.description == None)
    assert (docstring_deprecation.version == None)


# Generated at 2022-06-25 16:14:56.629662
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_0 = DocstringReturns(
        ["returns"],
        "The returned value is...",
        "int",
        False,
        "value",
    )


# Generated at 2022-06-25 16:14:58.774883
# Unit test for constructor of class ParseError
def test_ParseError():
    ex = ParseError('')
    print(ex)


test_ParseError()

# Generated at 2022-06-25 16:15:00.938954
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises"], "Something blows up", "ValueError")


# Generated at 2022-06-25 16:15:02.633511
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([], "", "")


# Generated at 2022-06-25 16:15:10.777855
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()
    assert isinstance(docstring_0.short_description, type(None))
    assert isinstance(docstring_0.long_description, type(None))
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    meta_docstring_0 = docstring_0.meta
    assert len(meta_docstring_0) == 0

if __name__ == '__main__':
    test_case_0()
    test_Docstring()

# Generated at 2022-06-25 16:15:12.842678
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert(hasattr(err, "args"))


# Generated at 2022-06-25 16:15:15.774461
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['', ''], 'foo')
    assert docstring_meta.args == ['', '']
    assert docstring_meta.description == 'foo'


# Generated at 2022-06-25 16:15:46.250679
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dummy=DocstringReturns(['param'], 'function description', 'int', 'False')


# Generated at 2022-06-25 16:15:57.063798
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    parameters = ["param", "arg"]
    description = "description of Foo"
    arg_name = "Foo"
    type_name = "string"
    is_optional = True
    default = "0"
    d_param = DocstringParam(parameters, description, arg_name, type_name, is_optional, default)
    assert (d_param.args == parameters)
    assert(d_param.description == description)
    assert(d_param.arg_name == arg_name)
    assert(d_param.type_name == type_name)
    assert(d_param.is_optional == is_optional)
    assert(d_param.default == default)


# Generated at 2022-06-25 16:16:02.335405
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """docstring for function test_DocstringParam"""
    arguments = []
    description = "description_1"
    arg_name = ""
    type_name = "type_name_1"
    is_optional = True
    default = "default_1"
    docstring_param = DocstringParam(arguments, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-25 16:16:14.473815
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        ["param", "arg"],
        "The argument description",
        "arg",
        None,
        None,
        None
    )
    assert docstring_param.args == ["param", "arg"]
    assert docstring_param.description == "The argument description"
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name is None
    assert docstring_param.is_optional is None
    assert docstring_param.default is None
    # Test for keyword arguments
    docstring_param = DocstringParam(
        args=["param", "arg"],
        description="The argument description",
        arg_name="arg",
        type_name=None,
        is_optional=None,
        default=None
    )
    assert doc

# Generated at 2022-06-25 16:16:16.501296
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["@deprecated"], " ", "1.0.0")


# Generated at 2022-06-25 16:16:20.076023
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    test_docstring_0 = DocstringParam(["",""], "", "", None, None, None)
    assert test_docstring_0.description == "Unknown description"
    assert test_docstring_0.args == ["",""]
    assert test_docstring_0.type_name == "No type"
    assert test_docstring_0.is_optional == None
    assert test_docstring_0.arg_name == "Unknown argument"
    assert test_docstring_0.default == "Unknown default"


# Generated at 2022-06-25 16:16:21.878525
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_case_0()


# Generated at 2022-06-25 16:16:26.224059
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError"""
    msg = "ParseError() takes exactly 2 arguments (1 given)"
    try:
        raise ParseError()
    except TypeError as e:
        assert str(e) == msg
        msg = "ParseError() missing 1 required positional argument: 'message'"
    try:
        raise ParseError(None)
    except TypeError as e:
        assert str(e) == msg
        msg = "ParseError() takes exactly 2 arguments (3 given)"
    try:
        raise ParseError(None, None, None)
    except TypeError as e:
        assert str(e) == msg
        msg = "ParseError() missing 1 required positional argument: 'message'"

# Generated at 2022-06-25 16:16:26.899924
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['raises'], None, None)



# Generated at 2022-06-25 16:16:28.725790
# Unit test for constructor of class ParseError
def test_ParseError():

    text = 'this is just my test text'
    assert text in ParseError(text).args[0]

# Generated at 2022-06-25 16:17:33.968119
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta_0 = DocstringMeta(args=[], description="")
    assert docstring_meta_0.args == []
    assert docstring_meta_0.description == ""


# Generated at 2022-06-25 16:17:38.065181
# Unit test for constructor of class ParseError
def test_ParseError():
    error_1 = ParseError("Error 1")
    error_2 = ParseError("Error 2", 4)
    print(error_1)
    print(error_2)


# Generated at 2022-06-25 16:17:41.838232
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(
        arg_name= "arg_name_1",
        args=["arg1"],
        description= "description_1",
        type_name= "type_name_1",
        is_optional= "is_optional_1",
        default= "default_1"
    )


# Generated at 2022-06-25 16:17:46.686563
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta = ''
    description = ''
    type_name = ''
    docstring_raises = DocstringRaises([meta], description, type_name)
    assert docstring_raises


# Generated at 2022-06-25 16:17:47.668308
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0 = Docstring()

# Generated at 2022-06-25 16:17:55.858741
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['a', 'b'], 'My name is nachiket')
    assert (docstring_meta.args == ['a', 'b'])
    assert (docstring_meta.description == 'My name is nachiket')


# Generated at 2022-06-25 16:17:56.959740
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()


# Generated at 2022-06-25 16:18:00.163246
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param_0 = DocstringParam(
        args=['raises'],
        description='if something happens',
        arg_name='error',

    )
    arg_name_0 = docstring_param_0.arg_name
    assert arg_name_0 == 'error'



# Generated at 2022-06-25 16:18:02.429261
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param']
    description = 'desc'
    type_name = 'int'
    test_DocstringRaises_0 = DocstringRaises(args, description, type_name)


# Generated at 2022-06-25 16:18:10.871350
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring_0=Docstring()
    assert docstring_0.short_description is None
    assert docstring_0.long_description is None
    assert docstring_0.blank_after_short_description == False
    assert docstring_0.blank_after_long_description == False
    assert docstring_0.meta == []
    assert docstring_0.params == []
    assert docstring_0.raises == []
    assert docstring_0.returns == None
    assert docstring_0.deprecation == None


# Generated at 2022-06-25 16:20:35.940254
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_0 = DocstringReturns(["",""], "", "int", False)

    assert docstring_returns_0.args == ["",""]
    assert docstring_returns_0.description == ""
    assert docstring_returns_0.is_generator == False
    assert docstring_returns_0.type_name == "int"


# Generated at 2022-06-25 16:20:37.838764
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raise_ = DocstringRaises(['raises'], 'description', 'type_name')
    assert type(raise_) == DocstringRaises
    assert raise_.description == 'description'
    assert raise_.type_name == 'type_name'


# Generated at 2022-06-25 16:20:44.682981
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    # Test that self.short_description is None
    assert docstring.short_description is None
    # Test that self.long_description is None
    assert docstring.long_description is None
    # Test that self.blank_after_short_description is False
    assert docstring.blank_after_short_description == False
    # Test that self.blank_after_long_description is False
    assert docstring.blank_after_long_description == False
    # Test that self.meta is an empty list
    assert docstring.meta == []

# Generated at 2022-06-25 16:20:55.573750
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns"""

    dr = DocstringReturns(["returns"], "returns description", "return type", False,
                          return_name="return name")
    dr1 = DocstringReturns(["yields"], "yields description", "yield type", True, return_name=None)
    dr2 = DocstringReturns(["return"], "return description", None, False)
    dr3 = DocstringReturns(["yield"], "yield description", None, True)
    print(dr.__dict__)
    print(dr1.__dict__)
    print(dr2.__dict__)
    print(dr3.__dict__)


if __name__ == '__main__':
    test_DocstringReturns()

# Generated at 2022-06-25 16:21:00.137618
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    my_doc_deprecated = DocstringDeprecated(args=[":deprecated"], description=None, version=None)
    assert(my_doc_deprecated.version)

# Generated at 2022-06-25 16:21:03.687196
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_0 = DocstringDeprecated(["param"], "arg_name: type_name",'')
    assert docstring_0.args == ["param"]
    assert docstring_0.description == "arg_name: type_name"
    assert docstring_0.version == ''


# Generated at 2022-06-25 16:21:05.938552
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()



# Generated at 2022-06-25 16:21:09.072422
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError('foo').args[0] == 'foo'


# Generated at 2022-06-25 16:21:11.581434
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_case_0()


# Generated at 2022-06-25 16:21:14.395487
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_0 = Docstring()
    docstring_0.short_description = "This function ..."
    assert docstring_0.short_description == "This function ..."
