

# Generated at 2022-06-23 16:55:31.936840
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_long_description == False
    assert a.blank_after_short_description == False
    assert len(a.meta) == 0




# Generated at 2022-06-23 16:55:43.001657
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg_name = 'arg_name'
    args = []
    description = 'description'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    assert arg_name != None
    assert args != None
    assert description != None
    assert type_name != None
    assert is_optional != None
    assert default != None
    x = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert x.arg_name == arg_name
    assert x.description == description
    assert x.type_name == type_name
    assert x.is_optional == is_optional
    assert x.default == default
    assert x.args == args
    print("PASSED::test_DocstringParam")


# Generated at 2022-06-23 16:55:47.961513
# Unit test for constructor of class ParseError
def test_ParseError():
    # Invalid syntax
    try:
        raise ParseError()
    except SyntaxError:
        pass

    # Invalid type
    try:
        raise ParseError(1)
    except TypeError:
        pass

    raise ParseError('This is a message')


# Generated at 2022-06-23 16:55:50.463112
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d1 = DocstringMeta(["param"], "arg")
    assert d1.args[0] == "param"
    assert d1.description == "arg"



# Generated at 2022-06-23 16:55:57.566980
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('abc')
    assert error

if __name__ == '__main__':
    # Unit test for constructor of class DocstringMeta
    def test_DocstringMeta():
        meta = DocstringMeta(['arg1', 'arg2'], 'description')
        assert meta.args
        assert meta.description

    # Unit test for constructor of class DocstringParam
    def test_DocstringParam():
        param = DocstringParam(
            ['arg1', 'arg2'],
            'description',
            'arg_name',
            'type_name',
            True,
            'default',
        )
        assert param.args
        assert param.description
        assert param.arg_name == 'arg_name'
        assert param.type_name == 'type_name'
        assert param.is_optional == True

# Generated at 2022-06-23 16:55:59.485971
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
 
    assert DocstringParam("a","b","c","d",False,"e")



# Generated at 2022-06-23 16:56:02.471548
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []
    print('Constructor test for class Docstring passed!')


# Generated at 2022-06-23 16:56:03.596738
# Unit test for constructor of class Docstring
def test_Docstring():
    isinstance(Docstring(), Docstring)


# Generated at 2022-06-23 16:56:12.900904
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	print("Testing constructor of class DocstringReturns(param, description, type, isGenerator)")
	args = ["param", "this is a param"]
	description = "testing constructor"
	typeName = "str"
	isGenerator = True
	testReturn = DocstringReturns(args, description, typeName, isGenerator)
	assert testReturn.args == args
	assert testReturn.description == description
	assert testReturn.type_name == typeName
	assert testReturn.is_generator == isGenerator


# Generated at 2022-06-23 16:56:14.603473
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises.__init__(['args'], 'description', 'type_name')

# Generated at 2022-06-23 16:56:18.626053
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert (a.short_description == None)
    assert (a.long_description == None)
    assert (a.blank_after_short_description == False)
    assert (a.blank_after_long_description == False)
    assert (a.meta == [])


# Generated at 2022-06-23 16:56:19.644703
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["param"], "test", "int", True, "test")

# Generated at 2022-06-23 16:56:23.427128
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert len(d.meta) == 0

# Generated at 2022-06-23 16:56:26.642803
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_doc = DocstringDeprecated(['deprecated'], 'this method is deprecated','1.0')
    assert test_doc.args == ['deprecated']
    assert test_doc.description == 'this method is deprecated'
    assert test_doc.version == '1.0'

#Unit test for constructor of class DocstringRaises

# Generated at 2022-06-23 16:56:30.591026
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r = DocstringReturns(args = ["returns"], description = "Returns something", type_name = "int")


# Generated at 2022-06-23 16:56:35.074649
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated_instance = DocstringDeprecated(['param', 'description'], 'description', 'version')
    if not isinstance(docstring_deprecated_instance, DocstringDeprecated):
        print('Construction fails')
    else:
        print('Construction succeeds')


# Generated at 2022-06-23 16:56:39.138092
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(['param'], 'description', 'TypeError')
    assert isinstance(docstring, DocstringRaises)
    assert docstring.args == ['param']
    assert docstring.description == 'description'
    assert docstring.type_name == 'TypeError'


# Generated at 2022-06-23 16:56:40.593922
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test message")
    except ParseError as err:
        assert str(err) == "Test message"


# Generated at 2022-06-23 16:56:42.851848
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['deprecated'], 'Description', 'Version')
    assert d is not None


# Generated at 2022-06-23 16:56:50.105150
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test = DocstringParam(["param"], "Description", "arg_name", "type_name", None, None)

    assert test.args == ["param"]
    assert test.description == "Description"
    assert test.arg_name == "arg_name"
    assert test.type_name == "type_name"
    assert test.is_optional == None
    assert test.default == None


# Generated at 2022-06-23 16:56:59.862974
# Unit test for constructor of class DocstringParam
def test_DocstringParam():

    args = ["test_arg"]
    description = "test_description"
    arg_name = "test_arg_name"
    type_name = "test_type_name"
    is_optional = False
    default = "test_default"

    item = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert item.args == ["test_arg"]
    assert item.description == "test_description"
    assert item.arg_name == "test_arg_name"
    assert item.type_name == "test_type_name"
    assert item.is_optional == False
    assert item.default == "test_default"




# Generated at 2022-06-23 16:57:02.598782
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta([], "")
    except TypeError as te:
        print(str(te))
        assert False


# Generated at 2022-06-23 16:57:05.115300
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc_string_raises = DocstringRaises(['arg','argument','desc'],"description", str)

# Generated at 2022-06-23 16:57:05.782220
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    pass



# Generated at 2022-06-23 16:57:09.135921
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated("param", "description", "version")
    assert d.args == ["param"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-23 16:57:17.161584
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["return" ,"returns"]
    type_name = "self"
    is_generator = False
    return_name = "returns"
    description = None
    docstring = DocstringReturns(args, description, type_name, is_generator, return_name)
    if docstring.args is not None:
        print("Correct args")
    if docstring.type_name is not None:
        print("Correct type_name")
    if docstring.is_generator is not None:
        print("Correct is_generator")
    if docstring.return_name is not None:
        print("Correct return_name")
    if docstring.description is not None:
        print("Correct description")
    else:
        print("Error")


# Generated at 2022-06-23 16:57:19.056508
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor."""
    e = ParseError("ParseError")
    assert e.args[0] == "ParseError"


# Generated at 2022-06-23 16:57:27.758790
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test DocstringReturns."""
    result = DocstringReturns(["returns"], "type_name", "is_generator", "return_name")
    assert (
        result.args
        == ["returns"]
    ), "args must be ['returns'] but was: " + str(result.args)
    assert (
        result.description
        == "type_name"
    ), "description must be 'type_name' but was: " + str(result.description)
    assert (
        result.is_generator
        == "is_generator"
    ), "is_generator must be 'is_generator' but was: " + str(result.is_generator)

# Generated at 2022-06-23 16:57:34.346871
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This method is deprecated"
    version = "1.0"
    # Initialize a DocstringDeprecated object
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-23 16:57:35.712224
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a is not None



# Generated at 2022-06-23 16:57:39.638648
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test with a message
    try:
        raise ParseError("Error.")
    except ParseError as err:
        assert str(err) == "Error."

    # Test without a message
    try:
        raise ParseError()
    except ParseError as err:
        assert str(err) is None


# Generated at 2022-06-23 16:57:41.981631
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    str1=DocstringMeta(['a'],"p");



# Generated at 2022-06-23 16:57:44.170697
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()


# Generated at 2022-06-23 16:57:44.805952
# Unit test for constructor of class ParseError
def test_ParseError():
    assert True

# Generated at 2022-06-23 16:57:49.037082
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        assert DocstringDeprecated(args=['a', 'b', 'c'], description='a' * 150, version='1.0') is not None
        assert True
    except:
        assert False


# Generated at 2022-06-23 16:57:53.768667
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"],
                           "blah",
                           "arg_name",
                           "type_name",
                           None,
                           None)
    assert param.arg_name == "arg_name"
    assert param.type_name == "type_name"
    assert param.is_optional is None
    assert param.default is None


# Generated at 2022-06-23 16:57:59.627037
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-23 16:58:03.073584
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description=None
    version = None
    testObj = DocstringDeprecated(args, description, version)
    args=[testObj]
    description=None
    version=None


# Generated at 2022-06-23 16:58:07.464908
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    obj = DocstringReturns(["param"], "Description", "type_name", False, "return_name")
    assert obj.args == ["param"]
    assert obj.description == "Description"
    assert obj.type_name == "type_name"
    assert obj.is_generator == False
    assert obj.return_name == "return_name"



# Generated at 2022-06-23 16:58:13.279128
# Unit test for constructor of class DocstringParam
def test_DocstringParam(): 
    param = DocstringParam(["param"], "doc", "name", "type", True, "default")
    assert param.description == "doc"
    assert param.args == ["param"]
    assert param.arg_name == "name"
    assert param.type_name == "type"
    assert param.is_optional is True
    assert param.default == "default"

# Generated at 2022-06-23 16:58:17.618381
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print("Testing...")
    args = []
    description = "descriptions"
    doc_meta = DocstringMeta(args, description)
    assert isinstance(doc_meta, DocstringMeta)
    assert doc_meta.args == args
    assert doc_meta.description == description
    print("Done.")


# Generated at 2022-06-23 16:58:22.488803
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    metadoc = DocstringMeta(args=["test"], description="test doc")
    assert metadoc.args == ["test"]
    assert metadoc.description == "test doc"


# Generated at 2022-06-23 16:58:27.559293
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    # check the initialization of the object
    assert param.args == ["param"]
    assert param.description == "description"
    assert param.arg_name == "arg_name"
    assert param.type_name == "type_name"
    assert param.is_optional == True
    assert param.default == "default"


# Generated at 2022-06-23 16:58:28.621211
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns()


# Generated at 2022-06-23 16:58:35.214897
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    from sphinx.domains.python import DocstringDeprecated

    inst = DocstringDeprecated(['deprecated', 'ignore_missing'], 'some_description', '2.0.1')
    assert inst.description == 'some_description'
    assert inst.version == '2.0.1'


# Generated at 2022-06-23 16:58:41.322276
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = 'aa'
    arg_name = 'bb'
    type_name = 'cc'
    is_optional = True
    default = 'dd'
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert dp.args == args
    assert dp.description == description
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default



# Generated at 2022-06-23 16:58:44.968810
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print("DocstringMeta class: constructor")
    args = ['param', 'arg']
    description = "description"
    dm = DocstringMeta(args, description)
    assert dm.args == ['param', 'arg']
    assert dm.description == "description"


# Generated at 2022-06-23 16:58:48.643023
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit tests for :class:Docstring.

    Checks the initialization and the properties of the class.
    """
    # TODO: Write unit test
    ds = Docstring()


# Generated at 2022-06-23 16:58:51.268161
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['hey','hey'], '19')
    assert a.args == ['hey','hey']
    assert a.description == '19'


# Generated at 2022-06-23 16:58:54.032403
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['returns'], None, None, False)


# Generated at 2022-06-23 16:59:00.193018
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param', 'attribute', 'key', 'keyword']
    description = 'description'
    type_name = 'type_name'
    ex = DocstringRaises(args, description, type_name)
    assert ex.args[0] == args[0]
    assert ex.description == description
    assert ex.type_name == type_name



# Generated at 2022-06-23 16:59:04.432560
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns(['args'], 'arg1', 'arg2', 'True', 'return_value')
    assert doc.args == ['args']
    assert doc.description == 'arg1'
    assert doc.type_name == 'arg2'
    assert doc.is_generator == 'True'
    assert doc.return_name == 'return_value'



# Generated at 2022-06-23 16:59:07.157267
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test_ParseError')
    except Exception as e:
        pass

# Generated at 2022-06-23 16:59:11.226358
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # test initialization
    args = ['one']
    description = "description"
    version = "version"
    ds = DocstringDeprecated(args, description, version)

    assert ds == DocstringDeprecated(args, description, version)


# Generated at 2022-06-23 16:59:15.411495
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test = DocstringParam([], None, None, None, None, None)
    assert isinstance(test, DocstringParam)


# Generated at 2022-06-23 16:59:22.759590
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None

# Generated at 2022-06-23 16:59:32.084398
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # We can initialize it using a constructor
    t1 = DocstringDeprecated("param", "description", "version")
    t1_1 = DocstringDeprecated(["param"], "version", "description")
    # There are members for arguments, description and version
    t1.args[0]
    t1.description
    t1.version
    t1_1.args[0]
    t1_1.description
    t1_1.version


# Generated at 2022-06-23 16:59:34.893121
# Unit test for constructor of class Docstring
def test_Docstring():
    inst = Docstring()
    assert inst != None
    return inst

# Generated at 2022-06-23 16:59:40.247426
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(
        args=['parameter', 'arg', 'param', 'keyword'],
        description='description',
        arg_name='arg_name',
        type_name='type_name',
        is_optional=True,
        default="test123"
    )

# Generated at 2022-06-23 16:59:43.061919
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['a', 'b']
    description = 'desc'
    ds = DocstringMeta(args, description)
    assert ds.args == args
    assert ds.description == description


# Generated at 2022-06-23 16:59:45.581333
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg", "type_name", True, "default")


# Generated at 2022-06-23 16:59:52.085546
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    type_name = 'ValueError'
    description = 'if something happens'
    a = DocstringRaises(args, description, type_name)
    assert a.type_name == type_name
    assert a.description == description
    assert a.args == args


# Generated at 2022-06-23 17:00:01.405082
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(args=["type=Deprecated", "version=1.0.0"], description="This is deprecated module.", version="1.0.0")
    docstring.version == "1.0.0"
    docstring.args == ["type=Deprecated", "version=1.0.0"]
    docstring.description == "This is deprecated module."


# Generated at 2022-06-23 17:00:11.529126
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam
    # Test 1
    test_param = DocstringParam(["param"], "myParam", "myParam", "str", False, None)
    assert test_param.args == ["param"]
    assert test_param.description == "myParam"
    assert test_param.arg_name == "myParam"
    assert test_param.type_name == "str"
    assert test_param.is_optional == False
    assert test_param.default == None
    # Test 2
    test_param2 = DocstringParam(["arg"], "myArg", "myArg", None, True, "3")
    assert test_param2.args == ["arg"]
    assert test_param2.description == "myArg"
    assert test_param2.arg_name == "myArg"

# Generated at 2022-06-23 17:00:17.574949
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    class DocStringMeta_test(DocstringMeta):
        def __init__(
            self,
            args: T.List[str],
            description: T.Optional[str],
            version: T.Optional[str],
        ) -> None:
            super().__init__(args, description)
            self.version = version
            self.description = description
        
    args = ['arg']
    description = 'description'

    # Unit test for constructor of class DocStringMeta_test
    def test_DocStringMeta_test():
        DocStringMeta_test([args], description, 2)
    
    test_DocStringMeta_test()

# Generated at 2022-06-23 17:00:21.014166
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('This is a Parse Error')
    assert error


# Generated at 2022-06-23 17:00:27.275733
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_DocstringReturns_object = DocstringReturns([], None, None, None)
    assert test_DocstringReturns_object.args == []
    assert test_DocstringReturns_object.description == None
    assert test_DocstringReturns_object.type_name == None
    assert test_DocstringReturns_object.is_generator == None
    assert test_DocstringReturns_object.return_name == None

# Generated at 2022-06-23 17:00:31.258192
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam("args", "desc", "arg_name", "type_name", False, "default")
    assert isinstance(a, DocstringParam)
    #print("DocstringParam successfully created and initialized")


# Generated at 2022-06-23 17:00:32.778391
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()


# Generated at 2022-06-23 17:00:38.399252
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(1, 2, 3, 4, 5, 6)
    assert(a.args == 1 and a.description == 2 and a.arg_name == 3 and 
           a.type_name == 4 and a.is_optional == 5 and a.default == 6)


# Generated at 2022-06-23 17:00:46.713283
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    "Unit test" for constructor of class DocstringReturns
    """
    # Init
    args = ['arg1']
    description = 'description1'
    type_name = 'typename1'
    is_generator = True
    return_name = 'returnname1'
    # Action
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    # Assert
    assert docstring_returns.args == ['arg1']
    assert docstring_returns.description == 'description1'
    assert docstring_returns.type_name == 'typename1'
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name == 'returnname1'


# Generated at 2022-06-23 17:00:52.326873
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test constructor of class Docstring."""
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []


# Generated at 2022-06-23 17:00:55.522914
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError('Sample Error')
    assert pe.args == ('Sample Error',)

# Generated at 2022-06-23 17:00:59.962187
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=["arg"], description="description",
                          arg_name="arg_name", type_name="type_name", default="default",
                          is_optional=False)


# Generated at 2022-06-23 17:01:03.357439
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "description"
    dsm = DocstringMeta(args,description)
    assert dsm.args == args
    assert dsm.description == description


# Generated at 2022-06-23 17:01:09.018004
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Unit tests for class DocstringParam

# Generated at 2022-06-23 17:01:14.502565
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["Raises an error"]
    description = "An error occured"
    type_name = "Error"
    test = DocstringRaises(args, description, type_name)
    assert test.args == ["Raises an error"]
    assert test.description == "An error occured"
    assert test.type_name == "Error"

test_DocstringRaises()


# Generated at 2022-06-23 17:01:20.921577
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['arg1', 'arg2'], 'description', 'version')
    assert(isinstance(d, DocstringMeta))
    assert(d.args == ['arg1', 'arg2'])
    assert(d.description == 'description')
    assert(d.version == 'version')


# Generated at 2022-06-23 17:01:24.005970
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(
        args=["return", "foo"],
        description=None,
        type_name=None,
        is_generator=False,
        return_name=None
    )


# Generated at 2022-06-23 17:01:27.820114
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    Testing the constructor of class DocstringReturns:
    """
    myFunction = DocstringReturns(["hello"], "this is the description", "int")
    assert myFunction.args[0] == "hello"
    assert myFunction.description == "this is the description"
    assert myFunction.type_name == "int"

# Generated at 2022-06-23 17:01:29.792614
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is the test for raising an exception")
    except ParseError:
        print("ParseError has been raised")


# Generated at 2022-06-23 17:01:33.121120
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['param'], 'deprecated docstring', '2.0')
    assert a.description == 'deprecated docstring'
    assert a.version == '2.0'


# Generated at 2022-06-23 17:01:36.279143
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	a = DocstringRaises(["param", "attribute"], "description", "int")
	assert (a.description == "description")
	assert (a.args == ["param", "attribute"])
	assert (a.type_name == "int")

# Generated at 2022-06-23 17:01:40.519088
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():    
    DocstringMeta.__init__(args="param arg: description of arg", description="description")
    assert args == "param arg: description of arg"
    assert description == "description"


# Generated at 2022-06-23 17:01:46.237569
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-23 17:01:55.475116
# Unit test for constructor of class Docstring
def test_Docstring():
    # create object for Docstring
    object = Docstring()
    # test if object is an instatnce of the class Docstring
    assert isinstance(object, Docstring)
    # test if object has the attribute params
    assert hasattr(object, 'params')
    # test if object has the attribute raises
    assert hasattr(object, 'raises')
    # test if object has the attribute returns
    assert hasattr(object, 'returns')
    # test if object has the attribute deprecation
    assert hasattr(object, 'deprecation')
    # test if object has the attribute short_description
    assert hasattr(object, 'short_description')
    # test if object has the attribute long_description
    assert hasattr(object, 'long_description')
    # test if object has the attribute blank_after_short_description
   

# Generated at 2022-06-23 17:01:56.490481
# Unit test for constructor of class ParseError
def test_ParseError():
    obj = ParseError()


# Generated at 2022-06-23 17:02:03.021698
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["arg"], "description", "arg_name", "type_name", False, "")

    assert docstring_param.args == ["arg"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == False
    assert docstring_param.default == ""


# Generated at 2022-06-23 17:02:07.120952
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['param', 'arg', 'attribute', 'key', 'keyword']
    description = 'description'
    version = 'version'
    x = DocstringDeprecated(args,description,version)
    assert x.description == description
    assert x.args == args
    assert x.version == version


# Generated at 2022-06-23 17:02:08.340930
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=[], description=None, version=None)


# Generated at 2022-06-23 17:02:11.027721
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as error:
        #print("ParseError caught: " + error)
        if (error == "test"):
            assert True
        else:
            assert False


# Generated at 2022-06-23 17:02:15.482224
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test DocstringRaises constructor."""
    d = DocstringRaises(["a"], "descr", "Type")
    assert d.args == ["a"]
    assert d.type_name == "Type"
    assert d.description == "descr"


# Generated at 2022-06-23 17:02:21.868959
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:02:25.988599
# Unit test for constructor of class ParseError
def test_ParseError():

    try:
        raise ParseError("Error parsing docstring")
    except ParseError as e:
        assert str(e) == "Error parsing docstring"


# Generated at 2022-06-23 17:02:28.797225
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['param', 'arg'], 'description').args == ['param', 'arg']
    assert DocstringMeta(['param', 'arg'], 'description').description == 'description'


# Generated at 2022-06-23 17:02:31.530363
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-23 17:02:35.072670
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    DocstringMeta(args, description)

# Generated at 2022-06-23 17:02:37.949872
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ddes = DocstringDeprecated(['deprecated', 'd'], 'testing', '3')
    assert ddes.description == 'testing'
    assert ddes.version == '3'
    assert ddes.args == ['deprecated', 'd']


# Generated at 2022-06-23 17:02:40.030106
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated('keyword', 'description', 'version')
    assert doc.args == ['keyword']
    assert doc.description == 'description'
    assert doc.version == 'version'


# Generated at 2022-06-23 17:02:41.346886
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert e != None


# Generated at 2022-06-23 17:02:45.260703
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ob = DocstringReturns(args=['a'], description='Hello docstring', type_name=str, is_generator=True)
    assert ob.args == ['a']
    assert ob.description == 'Hello docstring'
    assert ob.type_name == str
    assert ob.is_generator == True



# Generated at 2022-06-23 17:02:48.051227
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns([], None, None, True)
    assert doc


# Generated at 2022-06-23 17:02:53.810142
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(
        args=['raises'],
        description='description',
        type_name='ValueError'
    )
    assert docstring.args == ['raises']
    assert docstring.description == 'description'
    assert docstring.type_name == 'ValueError'



# Generated at 2022-06-23 17:02:57.132324
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(['raises', 'ValueError'], "if something happens", "ValueError")
    assert doc.args == ['raises', 'ValueError']
    assert doc.description == "if something happens"
    assert doc.type_name == "ValueError"

# Generated at 2022-06-23 17:03:02.306206
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [1, 2, 3]
    description = 'This is the description'
    meta = DocstringMeta(args, description)
    assert meta.args == args
    assert meta.description == description



# Generated at 2022-06-23 17:03:05.577995
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    parameters = DocstringReturns(['args'], 'desc', 'a', False)
    assert parameters.type_name == 'a'
    assert parameters.description == 'desc'
    assert parameters.is_generator == False

# Generated at 2022-06-23 17:03:12.839291
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ['arg1', 'arg2', 'arg3']
    test_arg_name = 'test_arg'
    test_type_name = None
    test_is_optional = None
    test_default = None
    test_description = 'this is a test doc'
    x = DocstringMeta(test_args, test_description)
    assert x.args == test_args
    assert x.description == test_description
    x = DocstringParam(test_args, test_description, test_arg_name, test_type_name, test_is_optional, test_default)
    assert x.arg_name == test_arg_name
    assert x.description == test_description
    assert x.is_optional == None
    assert x.type_name == None
    assert x.default == None
    test_type

# Generated at 2022-06-23 17:03:15.526428
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test that constructor works
    err = ParseError()
    assert err

    # Test that error message can be passed to constructor
    err = ParseError("some error message")
    assert str(err) == "some error message"


# Generated at 2022-06-23 17:03:18.705815
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Bad argument')
    except ParseError as e:
        print('Caught:', e.args[0])

# Generated at 2022-06-23 17:03:25.853638
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstrparam = DocstringParam(["param"], "Test docstring", "arg_name", "type_name", True, "Default")

    assert docstrparam.args[0] == "param"
    assert docstrparam.description == "Test docstring"
    assert docstrparam.arg_name == "arg_name"
    assert docstrparam.type_name == "type_name"
    assert docstrparam.is_optional == True
    assert docstrparam.default == "Default"


# Generated at 2022-06-23 17:03:29.759165
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(["param", "parameter", "arg", "argument", "attribute",
     "key", "keyword"], "description", "version")
    assert doc.args == ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    assert doc.description == "description"
    assert doc.version == "version"



# Generated at 2022-06-23 17:03:39.029554
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("\nUnit test for docstring_param.py")
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    test = DocstringParam(
        args=args,
        description=description,
        arg_name=arg_name,
        type_name=type_name,
        is_optional=is_optional,
        default=default,
    )
    assert test.args == ["param"]
    assert test.description == "description"
    assert test.arg_name == "arg_name"
    assert test.type_name == "type_name"
    assert test.is_optional == True
    assert test.default == "default"

# Generated at 2022-06-23 17:03:42.862970
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['raises'], 'description', 'type_name')
    assert docstringRaises.description == 'description'
    assert docstringRaises.type_name == 'type_name'

# Generated at 2022-06-23 17:03:45.333262
# Unit test for constructor of class ParseError
def test_ParseError():
    class Test(ParseError):
        """Esse é um teste para a classe ParseError."""

# Generated at 2022-06-23 17:03:49.185749
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a=[]
    b="Description"
    c="Type"
    x=DocstringRaises(a,b,c)
    assert x.type_name==c
    assert x.description==b 
    assert x.args==a

# Generated at 2022-06-23 17:03:52.436985
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['version'], 'Invalid arg', '1.0')
    assert docstring.version == '1.0'
    assert docstring.description == 'Invalid arg'
    assert docstring.args == ['version']

# Generated at 2022-06-23 17:04:00.580163
# Unit test for constructor of class Docstring
def test_Docstring():
	ds = Docstring()
	assert ds.short_description is None
	assert ds.long_description is None
	assert ds.blank_after_short_description is False
	assert ds.blank_after_long_description is False
	assert ds.meta == []

	assert ds.params == []
	assert ds.raises == []
	assert ds.returns is None 
	assert ds.deprecation is None

test_Docstring()

# TODO: add unit test for function parse_docstring

# Generated at 2022-06-23 17:04:05.784617
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "This is description"
    arg_name = "arg"
    type_name = "int"
    is_optional = True
    default = "100"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param != None


# Generated at 2022-06-23 17:04:07.653203
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    print(docstring.short_description)


# Generated at 2022-06-23 17:04:13.069582
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  docstring = DocstringParam(['param'], "description of myDocString", 'arg', 'type_name', True, 'default')
  assert docstring.args == ['param']
  assert docstring.description == "description of myDocString"
  assert docstring.arg_name == 'arg'
  assert docstring.type_name == 'type_name'
  assert docstring.is_optional == True
  assert docstring.default == 'default'
  #raise Exception("Not implemented")


# Generated at 2022-06-23 17:04:14.476179
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass



# Generated at 2022-06-23 17:04:22.891529
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert(DocstringDeprecated(':deprecated', '3.0', '3.0') is not None)
    assert(DocstringDeprecated(':deprecated', '3.0', None) is not None)
    assert(DocstringDeprecated(':deprecated', None, '3.0') is not None)
    assert(DocstringDeprecated(':deprecated', None, None) is not None)
    assert(DocstringDeprecated(None, '3.0', '3.0') is not None)
    assert(DocstringDeprecated(None, '3.0', None) is not None)
    assert(DocstringDeprecated(None, None, '3.0') is not None)
    assert(DocstringDeprecated(None, None, None) is not None)


# Generated at 2022-06-23 17:04:27.608921
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    desc = 'Returns True if x is larger than y, False otherwise.'
    v = '3.2'
    result = DocstringDeprecated(args, desc, v)
    assert result.args == args
    assert result.description == desc
    assert result.version == v


# Generated at 2022-06-23 17:04:29.642980
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated({'deprecated', 'removed'}, 'This has been deprecated', '2.0')


# Generated at 2022-06-23 17:04:35.830524
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-23 17:04:39.651814
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test for constructor of class DocstringRaises."""
    args = [":raises", "ValueError:", "if", "something", "happens"]
    description = "if something happens"
    type_name = "ValueError"
    assert isinstance(
        DocstringRaises(args, description, type_name), DocstringRaises
    )


# Generated at 2022-06-23 17:04:43.499472
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(["param"], "N/A")
    assert [item for item in docstring.args] == ["param"]
    assert docstring.description == "N/A"


# Generated at 2022-06-23 17:04:48.061002
# Unit test for constructor of class Docstring
def test_Docstring():

    docstring = Docstring()
    assert(docstring.short_description == None)
    assert(docstring.long_description == None)
    assert(docstring.blank_after_short_description == False)
    assert(docstring.blank_after_long_description == False)
    assert(len(docstring.meta) == 0)

    return 0


# Generated at 2022-06-23 17:04:49.433965
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param","arg"], "description", "arg_name", "type_name", True, "default")

# Generated at 2022-06-23 17:04:50.800411
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(('two', 3), ('two', 3))


# Generated at 2022-06-23 17:04:58.189415
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["arg1","arg2"]
    description = "This is a test case for DocstringParam class"
    arg_name = "arg1"
    type_name = "None"
    is_optional = "True"
    default = "None"
    instance = DocstringParam(args, description,arg_name,type_name,is_optional,default)
    #print(instance)


# Generated at 2022-06-23 17:05:02.494214
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    meta = DocstringReturns(args=["does", "not", "matter"],
                            description="Test Description",
                            type_name="Test Type",
                            is_generator=False)
    assert(meta.type_name == "Test Type")
    assert(meta.description == "Test Description")
    assert(meta.is_generator == False)

# Generated at 2022-06-23 17:05:05.550727
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta


# Generated at 2022-06-23 17:05:11.511422
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr_return = DocstringReturns(
        [''],
        None,
        '',
        False,
    )
    assert docstr_return.args == ['']
    assert docstr_return.description is None
    assert docstr_return.type_name == ''
    assert docstr_return.is_generator is False
    assert docstr_return.return_name is None


# Generated at 2022-06-23 17:05:15.418740
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []

# END: Unit test for constructor of class Docstring


# Generated at 2022-06-23 17:05:18.475107
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    raise_ParseError = ParseError(args = "Not implemented yet")
    

# Generated at 2022-06-23 17:05:21.007132
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print('DocstringRaises test')
    assert DocstringRaises([], 'descr', 'type')
    

# Generated at 2022-06-23 17:05:24.630769
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test constructor of class DocstringDeprecated"""
    args = [':deprecated']
    DocstringDeprecated(args, "This api will be deprecated", "1.0.0")



# Generated at 2022-06-23 17:05:28.356857
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    paramArgs = ["version", "description"]
    paramDescription = "description of the docstring"
    paramVersion = "1.0"
    assert DocstringDeprecated(paramArgs, paramDescription, paramVersion)
