

# Generated at 2022-06-23 16:55:35.158803
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert len(d.meta) == 0
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False

# Generated at 2022-06-23 16:55:39.425096
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(['param', 'arg'], 'desc', 'int', False)
    assert d.type_name == 'int'
    assert d.args == ['param', 'arg']
    assert d.description == 'desc'
    assert d.return_name == None

# Generated at 2022-06-23 16:55:50.877782
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ["a", "b", "c"]
    test_description = "test_description"
    test_type_name = "type"
    test_is_generator = True
    test_return_name = "return_name"
    ds = DocstringReturns(
        test_args, test_description, test_type_name, test_is_generator, test_return_name
    )
    assert ds.args == test_args, "args are wrong"
    assert ds.description == test_description, "description is wrong"
    assert (
        ds.type_name == test_type_name
    ), "type_Name is wrong, should be {} but is {}".format(
        test_type_name, ds.type_name
    )

# Generated at 2022-06-23 16:55:58.708497
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test DocstringRaises constructor."""
    args = ['Exception', 'if something happens']
    description = 'if something happens'
    type_name = 'Exception'
    raise_DocstringRaises = DocstringRaises(args, description, type_name)
    assert raise_DocstringRaises.args == ['Exception', 'if something happens']
    assert raise_DocstringRaises.description == 'if something happens'
    assert raise_DocstringRaises.type_name == 'Exception'

# Generated at 2022-06-23 16:56:00.943633
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('this is a parse error')
    assert str(err) == 'this is a parse error'


# Generated at 2022-06-23 16:56:06.346504
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    args = []
    description = None
    arg_name = 'x'
    type_name = None
    is_optional = None
    default = None
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == []
    assert dp.description == None
    assert dp.arg_name == 'x'
    assert dp.type_name == None
    assert dp.is_optional == None
    assert dp.default == None


# Generated at 2022-06-23 16:56:11.807466
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    description = "test description"
    type_name = "test type name"
    docstringRaises = DocstringRaises([], description, type_name)
    assert docstringRaises.args == []
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-23 16:56:18.472813
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert not ds.blank_after_short_description
    assert ds.long_description == None
    assert not ds.blank_after_long_description
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-23 16:56:23.863874
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=['type1', 'arg1'],
        description='descrption1',
        arg_name='param1',
        type_name='type1',
        is_optional=True,
        default='default1'
    )

    assert docstring_param.args == ['type1', 'arg1']
    assert docstring_param.description == 'descrption1'
    assert docstring_param.arg_name == 'param1'
    assert docstring_param.type_name == 'type1'
    assert docstring_param.is_optional == True
    assert docstring_param.default == 'default1'


# Generated at 2022-06-23 16:56:27.617478
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None 
    assert docstring.long_description == None 
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == [] 

param = DocstringMeta(['parameter'], 'description')

# Generated at 2022-06-23 16:56:31.908980
# Unit test for constructor of class Docstring
def test_Docstring():
    try:
        from doctest import run_docstring_examples as dtest
        assert dtest(Docstring, globals(), verbose=False) == 0
    except ImportError:
        pass


# Generated at 2022-06-23 16:56:35.192508
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["param"], "description", "int")
    assert a.args == ["param"]
    assert a.description == "description"
    assert a.type_name == "int"

# Generated at 2022-06-23 16:56:36.926196
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError()
    assert isinstance(pe, RuntimeError)


# Generated at 2022-06-23 16:56:40.308082
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert e is not None


# Generated at 2022-06-23 16:56:42.210964
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()



# Generated at 2022-06-23 16:56:45.551867
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Constructed just to test if the constructor works
    # as intended
    raises = DocstringRaises(["args"], "description", "TypeError")
    assert isinstance(raises, DocstringMeta)
    assert isinstance(raises, DocstringRaises)


# Generated at 2022-06-23 16:56:51.065739
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(args=["a", "b", "c"], description="d", version="e")
    assert docstring_deprecated.args == ["a", "b", "c"]
    assert docstring_deprecated.description == "d"
    assert docstring_deprecated.version == "e"


# Generated at 2022-06-23 16:56:56.287113
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [1]
    description = 2
    version = 3

    docstring_deprecated = DocstringDeprecated(args, description, version)

    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-23 16:56:58.135920
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns = DocstringReturns()
    assert docstringReturns.return_name == None


# Generated at 2022-06-23 16:57:01.698298
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(None, None, None, None, None, None)
        assert True
    except:
        assert False


# Generated at 2022-06-23 16:57:05.739210
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["return"]
    description = ""
    type_name = "int"
    is_generator = False
    return_name = "x"
    doc = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(doc.is_generator == is_generator)
    assert(doc.return_name == return_name)
    assert(doc.type_name == type_name)

# Generated at 2022-06-23 16:57:11.956654
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        args = ['arg', 'type', 'default']
        description = 'A string'
        arg_name = 'arg'
        type_name = 'type'
        is_optional = False
        default = 'default'
        DocstringParam(args, description, arg_name, type_name, is_optional, default)
        raise RuntimeError('test_DocstringParam did not raise ParseError')
    except ParseError as ex:
        assert 'description' in str(ex)
        

# Generated at 2022-06-23 16:57:12.680261
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test =DocstringRaises(100,100,100)
    print(test)

# Generated at 2022-06-23 16:57:17.628135
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "returns:", "return:", "return"]
    description = "a string"
    type_name = "string"
    is_generator = True
    return_name = "str"
    doc = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert doc.description == description 
    assert doc.type_name == type_name
    assert doc.is_generator == is_generator
    assert doc.return_name == return_name
    assert doc.args == args


# Generated at 2022-06-23 16:57:19.904540
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Something went wrong")
    assert isinstance(err, RuntimeError)
    assert err.args[0] == "Something went wrong"


# Generated at 2022-06-23 16:57:23.008697
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param"]
    description = "description"
    version = "version"
    actual = DocstringDeprecated(args, description, version)
    expected = DocstringDeprecated(args, description, version)
    assert actual == expected

# Generated at 2022-06-23 16:57:28.099640
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args=[]
    description=None
    version=None
    result = DocstringDeprecated(args, description, version)
    expected_result = DocstringDeprecated(None, None, None)
    assert result.version == expected_result.version
    assert result.args == expected_result.args


# Generated at 2022-06-23 16:57:33.694272
# Unit test for constructor of class Docstring
def test_Docstring():

  #test 1
  def test_1():
    doc = Docstring()
    assert(doc.short_description == None)

  #test 2
  def test_2():
    doc = Docstring()
    assert(doc.long_description == None)

  #test 3
  def test_3():
    doc = Docstring()
    assert(doc.blank_after_short_description == False)

  #test 4
  def test_4():
    doc = Docstring()
    assert(doc.blank_after_long_description == False)

  #test 5
  def test_5():
    doc = Docstring()
    assert(doc.meta == [])

  #test 6
  def test_6():
    doc = Docstring()
    assert(doc.params == [])

  #test 7

# Generated at 2022-06-23 16:57:36.622802
# Unit test for constructor of class ParseError
def test_ParseError():
   try:
        raise ParseError('test message.')
   except ParseError as error:
        assert str(error) == 'test message.'
        assert error.__str__() == 'test message.'


# Generated at 2022-06-23 16:57:40.187391
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['args']
    description = 'description'
    type_name = 'type_name'
    is_generator = False
    return_name = 'return_name'
    assert isinstance(DocstringReturns(args, description, type_name, is_generator, return_name), DocstringReturns)


# Generated at 2022-06-23 16:57:42.824853
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("custom error message")
    assert pe.args == ('custom error message',)

# Generated at 2022-06-23 16:57:45.644072
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj = DocstringRaises(['raises'], 'description', 'type')
    assert obj.description == 'description'
    assert obj.type_name == 'type'



# Generated at 2022-06-23 16:57:49.855567
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    list_arg = ['arg']
    description = 'description'
    dm = DocstringMeta(args=['arg'], description='description')
    assert dm.args == list_arg
    assert dm.description == description



# Generated at 2022-06-23 16:57:57.462051
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []  # type: T.List[str]
    description = 'description'  # type: T.Optional[str]
    type_name = 'typename'  # type: T.Optional[str]
    docstringRaises = DocstringRaises(args, description, type_name)  # type: DocstringRaises
    # Check if the initialized DocstringRaises is of type DocstringRaises
    assert isinstance(docstringRaises, DocstringRaises)
    # Check if the initialized DocstringRaises has the correct values
    assert docstringRaises.args == []
    assert docstringRaises.description == 'description'
    assert docstringRaises.type_name == 'typename'


# Generated at 2022-06-23 16:58:02.785777
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0



# Generated at 2022-06-23 16:58:04.664112
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=[], description=1, type_name=2)

# Generated at 2022-06-23 16:58:09.902263
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'deprecated', 'version', 'version']
    description = 'This thing is deprecated'
    DocstringDeprecated(args, description, "1.0")
    print("Class DocstringDeprecated(DocstringMeta): constructor is OK")


# Generated at 2022-06-23 16:58:15.344066
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam(['args'], 'description', 'arg_name', 'type_name', True, 'default')
    assert docstringParam.args == ['args']
    assert docstringParam.description == 'description'
    assert docstringParam.arg_name == 'arg_name'
    assert docstringParam.type_name == 'type_name'
    assert docstringParam.is_optional == True
    assert docstringParam.default == 'default'

# Generated at 2022-06-23 16:58:21.095331
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Create a new instance of the class DocstringRaises
    docstringRaises = DocstringRaises(['args'], 'description', 'type_name')
    # Check if the instance has the correct attributes
    assert docstringRaises.args == ['args']
    assert docstringRaises.description == 'description'
    assert docstringRaises.type_name == 'type_name'


# Generated at 2022-06-23 16:58:22.068770
# Unit test for constructor of class ParseError
def test_ParseError():
    if ParseError:
        pass



# Generated at 2022-06-23 16:58:25.535778
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(
        args = [],
        description = "this is deprecated",
        version = "1.0"
    )
    assert doc.description is "this is deprecated"
    assert doc.version is "1.0"
    assert doc.args is []

# Generated at 2022-06-23 16:58:26.922874
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert isinstance(e, RuntimeError)

# Generated at 2022-06-23 16:58:28.985392
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid syntax")
    except ParseError as e:
        assert str(e) == 'Invalid syntax'

# Generated at 2022-06-23 16:58:30.555160
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg", "type", True, "Default")


# Generated at 2022-06-23 16:58:39.427684
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the constructor of DocstringParam."""
    import pytest
    from pytest_trio._core import _core

    a = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", "is_optional", "default",)
    assert a.args == ["param", "arg"]
    assert a.description == "description"
    assert a.arg_name == "arg_name"
    assert a.type_name == "type_name"
    assert a.is_optional == "is_optional"
    assert a.default == "default"

# Generated at 2022-06-23 16:58:44.499329
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam('args', 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert isinstance(x, DocstringParam)
    assert isinstance(x, DocstringMeta)


# Generated at 2022-06-23 16:58:50.951705
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "Это будет использовано вместо текста описания по умолчанию в исключениях,", "param", "str", True, "")
    print(docstring_param.description)


# Generated at 2022-06-23 16:58:57.955447
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(None, None, "arg", None, None, None)
    assert dp.arg_name == "arg"
    assert dp.type_name is None
    assert dp.is_optional is None
    assert dp.default is None
    assert dp.description is None
    assert dp.args is None


# Generated at 2022-06-23 16:59:06.236711
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("test_DocstringParam():\n")

# Generated at 2022-06-23 16:59:09.380577
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	assert DocstringParam(['foo'], 'a parameter', 'param', 'int', False, None) is not None



# Generated at 2022-06-23 16:59:13.063718
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of the class Docstring."""
    docstring = Docstring()
    assert docstring.short_description == None  # type: ignore
    assert docstring.long_description == None  # type: ignore
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:59:15.955150
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta([], "")
    assert meta.args == []
    assert meta.description == ""

# Generated at 2022-06-23 16:59:18.750302
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj1 = DocstringRaises([], None, None)
    assert obj1 is not None


# Generated at 2022-06-23 16:59:21.625838
# Unit test for constructor of class ParseError
def test_ParseError():
    # Two steps here:
    # 1. Create the class
    # 2. Create the object with a specific error message
    ParseError("Could not parse docstring. Empty string.")

# Generated at 2022-06-23 16:59:24.875279
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert isinstance(DocstringReturns(["returns"], None, None, False),DocstringReturns)


# Generated at 2022-06-23 16:59:28.001987
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["raises"], "This is an error.", "ValueError")
    testErrorMsg = "It looks like DocstringRaises constructor doesn't work."
    assert test.description == "This is an error.", testErrorMsg
    assert test.args == ["raises"], testErrorMsg
    assert test.type_name == "ValueError", testErrorMsg
    print("All test cases for DocstringRaises constructor passed.")



# Generated at 2022-06-23 16:59:33.821856
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(args = [],
                description = "TestDescription",
                arg_name = "arg_name",
                type_name = "type_name",
                is_optional = True,
                default = "default")
    except:
        print("Erreur ! DocstringParam(...)")
    else:
        print("Génial ! DocstringParam(...)")


# Generated at 2022-06-23 16:59:36.307386
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('msg')
    except ParseError as err:
        assert err.args[0] == 'msg'


# Generated at 2022-06-23 16:59:41.586242
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['return'], 'some description', 'some_type', False)
    assert a.description == 'some description'
    assert a.type_name == 'some_type'
    assert a.is_generator == False
    assert a.return_name == None

# Generated at 2022-06-23 16:59:52.524618
# Unit test for constructor of class Docstring
def test_Docstring():
    # _Test_: instantiation of class Docstring
    doc = Docstring()
    assert doc is not None

    # _Test_: attributes of a Docstring object
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None


# _Test_: instantiation of class DocstringParam

# Generated at 2022-06-23 16:59:55.600968
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        return True
    return False



# Generated at 2022-06-23 16:59:59.511829
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error message")
    except ParseError as e:
        assert e.args == ('error message',)


# Generated at 2022-06-23 17:00:10.125665
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """This function is to test the constructor of DocstringReturns.
    """
    # When passing the empty list
    args = []
    description = "This is a test passing the empty list"
    type_name = "int"
    is_generator = False
    return_name = "return_value"
    assert (DocstringReturns(args, description, type_name, is_generator, return_name).args == args)
    assert (DocstringReturns(args, description, type_name, is_generator, return_name).description == description)
    assert (DocstringReturns(args, description, type_name, is_generator, return_name).type_name == type_name)
    assert (DocstringReturns(args, description, type_name, is_generator, return_name).is_generator == is_generator)


# Generated at 2022-06-23 17:00:17.217201
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring_obj = Docstring()

    assert(type(Docstring_obj.short_description) == type(None))
    assert(type(Docstring_obj.long_description) == type(None))
    assert(Docstring_obj.meta == [])

    # Note: we do not test the properties params, raises, returns and deprecation
    # here, as those are tested in test_properties


# Generated at 2022-06-23 17:00:19.336026
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns("args","description",None,False,return_name=None)

# Generated at 2022-06-23 17:00:20.002120
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()


# Generated at 2022-06-23 17:00:21.330457
# Unit test for constructor of class ParseError
def test_ParseError():
    try :
        raise ParseError("Oopsie")
    except ParseError as err:
        assert err.args[0] == "Oopsie"
    else :
        assert False, "Error not raised"

# Generated at 2022-06-23 17:00:28.029598
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam1 = DocstringParam(["param"], "some description", "some_argument", "SomeType", True, "optional")
    assert DocstringParam1.args == ["param"]
    assert DocstringParam1.description == "some description"
    assert DocstringParam1.arg_name == "some_argument"
    assert DocstringParam1.type_name == "SomeType"
    assert DocstringParam1.is_optional == True
    assert DocstringParam1.default == "optional"

# Generated at 2022-06-23 17:00:32.739602
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(['param'], "description", "version")
    assert docstringDeprecated.args == ['param']
    assert docstringDeprecated.description == "description"
    assert docstringDeprecated.version == "version"


# Generated at 2022-06-23 17:00:36.710492
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError"""

    # don't need to do much here
    with pytest.raises(RuntimeError) as _:
        raise ParseError("....")


# Generated at 2022-06-23 17:00:41.190333
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description is False
    assert Docstring().blank_after_long_description is False
    assert Docstring().meta is not None
    print('>> test for Docstring passed')


# Generated at 2022-06-23 17:00:46.010913
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert str(DocstringReturns(["param"], "description", "type", True, "return")) == "DocstringReturns(['param'], 'description', 'type', True, 'return')"

# Generated at 2022-06-23 17:00:49.951669
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    current_instance = DocstringParam([], "", "", None, None, None)
    assert type(current_instance) == DocstringParam
    assert type(current_instance.args) == list
    assert type(current_instance.description) == str
    assert type(current_instance.arg_name) == str
    assert current_instance.is_optional == None
    assert current_instance.default == None


# Generated at 2022-06-23 17:00:54.304608
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['raises'], 'if something happens', 'ValueError')
    assert docstringRaises.args == ['raises']
    assert docstringRaises.description == 'if something happens'
    assert docstringRaises.type_name == 'ValueError'


# Generated at 2022-06-23 17:00:56.734424
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "asdf").args == []
    assert DocstringMeta(["asdf"], "asdf").args == ["asdf"]
    assert DocstringMeta([], "asdf").description == "asdf"


# Generated at 2022-06-23 17:01:00.586610
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam
    assert a.__init__(a, 'arg', 'description', 'arg_name', 'type_name', 'True',
                      'None') is None

# Generated at 2022-06-23 17:01:10.634571
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # case 1 test for constructor
    print("case 1 test for constructor")
    args = ['parameter']
    description = 'description'
    type_name = 'int'
    is_generator = False
    doc_return = DocstringReturns(args, description, type_name, is_generator)
    # here the is_generator is False
    # therefore we can directly get the return value
    assert (doc_return.args == ['parameter'])
    assert (doc_return.description == 'description')
    assert (doc_return.type_name == 'int')
    assert (doc_return.is_generator == False)
    # case 2 test for constructor
    print("case 2 test for constructor")
    args = ['parameter']
    description = 'description'
    type_name = 'int'
    is_gener

# Generated at 2022-06-23 17:01:14.780328
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test for constructor of class ParseError."""
    pe = ParseError("Das ist die Nachricht.")
    assert str(pe) == "Das ist die Nachricht."
    assert repr(pe) == "ParseError(msg='Das ist die Nachricht.')"


# Generated at 2022-06-23 17:01:20.772013
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    import unittest
    # Create a test object
    ds_test = DocstringMeta([':param', 'arg'], "description")
    # Check if values were correctly assigned
    assert ds_test.args == [':param', 'arg']
    assert ds_test.description == "description"



# Generated at 2022-06-23 17:01:24.203636
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam(['param', 'arg'], 'desc', 'arg', 'type_name', 'is_optional', 'default')
    if docstringParam.args != ['param', 'arg']:
        return False
    if docstringParam.description != 'desc':
        return False
    if docstringParam.arg_name != 'arg':
        return False
    if docstringParam.type_name != 'type_name':
        return False
    if docstringParam.is_optional != 'is_optional':
        return False
    if docstringParam.default != 'default':
        return False
    return True


# Generated at 2022-06-23 17:01:30.320069
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    my_test = DocstringRaises(['param'], 'description', 'type')
    assert my_test.description == 'description'
    assert my_test.type_name == 'type'
    assert my_test.args == ['param']


# Generated at 2022-06-23 17:01:34.890265
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['test args']
    description = 'test description'
    type_name = 'test type name'
    docstringRaises = DocstringRaises(args, description, type_name)
    docstringRaises.args == args
    docstringRaises.description == description
    docstringRaises.type_name == type_name


# Generated at 2022-06-23 17:01:38.595389
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        x = DocstringRaises
    except Exception:
        raise AssertionError("DocstringRaises not defined")


# Generated at 2022-06-23 17:01:50.997741
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    description = 'This is description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = 'is_optional'
    default = 'default'
    assert DocstringParam(['param'], description, arg_name, type_name, is_optional, default).description == description
    assert DocstringParam(['param'], description, arg_name, type_name, is_optional, default).arg_name == arg_name
    assert DocstringParam(['param'], description, arg_name, type_name, is_optional, default).type_name == type_name
    assert DocstringParam(['param'], description, arg_name, type_name, is_optional, default).is_optional == is_optional

# Generated at 2022-06-23 17:01:56.218248
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from collections import namedtuple
    args = ['a', 'b', 'c']
    description = 'here is the description'
    d = DocstringMeta(args, description)
    assert d.args == args
    assert d.description == description



# Generated at 2022-06-23 17:01:57.195666
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises.__init__


# Generated at 2022-06-23 17:01:58.900234
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(None, None, None, None, None, None)
    assert a.args == None
    assert a.description == None
    assert a.arg_name == None
    assert a.type_name == None
    assert a.is_optional == None
    assert a.default == None


# Generated at 2022-06-23 17:02:02.847246
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dsr = DocstringRaises(['1', '2', '3'], '4', '5')
    assert(dsr.args == ['1', '2', '3'])
    assert(dsr.description == '4')
    assert(dsr.type_name == '5')


# Generated at 2022-06-23 17:02:11.616015
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("\nUnit test for constructor of class DocstringParam")
    arguments = ["a", "param"]
    description = "a description"
    param_name = "my_param"
    type_name = "float"
    is_optional = True
    default = "42.0"
    dsp = DocstringParam(arguments, description, param_name, type_name, is_optional, default)
    print("DocstringParam dsp = {}".format(dsp))
    print("dsp.args = {}".format(dsp.args))
    print("dsp.description = {}".format(dsp.description))
    print("dsp.arg_name = {}".format(dsp.arg_name))
    print("dsp.type_name = {}".format(dsp.type_name))

# Generated at 2022-06-23 17:02:16.987471
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["version", "1.0"], "my description", "1.0")
    assert docstring_deprecated.description == "my description"
    assert docstring_deprecated.version == "1.0"
    assert docstring_deprecated.args == ["version", "1.0"]


# Generated at 2022-06-23 17:02:20.765451
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = ['deprecated', 'removed']
    d = DocstringDeprecated(a, None, '1')
    assert d.args == ['deprecated', 'removed']

# Generated at 2022-06-23 17:02:25.016010
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["param", "parameter"], "some description", "some version")
    assert docstring_deprecated.description == "some description"
    assert docstring_deprecated.args == ["param", "parameter"]
    assert docstring_deprecated.version == "some version"


# Generated at 2022-06-23 17:02:28.750744
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test with message
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert e.message == "Test"
    assert True
    # Test without message
    try:
        raise ParseError()
    except ParseError as e:
        assert e.message == ""
    assert True


# Generated at 2022-06-23 17:02:30.140595
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(None, None, None) is not None


# Generated at 2022-06-23 17:02:35.932374
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of class DocstringMeta."""
    dm = DocstringMeta(['Hello', 'World'], 'This is a description.')
    assert dm.args == ['Hello', 'World']
    assert dm.description == 'This is a description.'


# Generated at 2022-06-23 17:02:41.225103
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    elem = DocstringParam(args=[':param', 'xpto'], description = 'is the best', arg_name = 'arg1', type_name = 'int', is_optional = True, default = '0')
    assert elem.args == [':param', 'xpto']
    assert elem.description == 'is the best'
    assert elem.arg_name == 'arg1'
    assert elem.type_name == 'int'
    assert elem.is_optional == True
    assert elem.default == '0'
    
    
    
    
    

# Generated at 2022-06-23 17:02:46.791213
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(args=[1,2,3], description="123", arg_name='p', type_name='int', is_optional=True, default='1')
    assert(p.args[0] == 1)
    assert(p.args[1] == 2)
    assert(p.args[2] == 3)
    assert(p.description == "123")
    assert(p.arg_name == "p")
    assert(p.type_name == "int")
    assert(p.is_optional == True)
    assert(p.default == "1")


# Generated at 2022-06-23 17:02:51.430532
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	args = [':arg', ':attribute']
	description = "Raise a TypeError!"
	type_name = "TypeError"
	assert_raises_docstring = DocstringRaises(args, description, type_name)

# Generated at 2022-06-23 17:02:56.143022
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "description ..."
    version = "1.0"
    deprecation = DocstringDeprecated(args, description, version)
    assert deprecation.version == version
    assert deprecation.description == description
    assert deprecation.args == args

# Generated at 2022-06-23 17:03:00.339043
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dr = DocstringRaises(["param"], "description", "type_name")
    assert dr.param == "type_name"
    assert dr.description == "description"

# Generated at 2022-06-23 17:03:08.050101
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    description = "string"
    type_name = "type"
    is_generator = True
    return_name = "name"
    actual = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert actual.args == args
    assert actual.description == description
    assert actual.type_name == type_name
    assert actual.is_generator == is_generator
    assert actual.return_name == return_name

test_DocstringReturns()

# Generated at 2022-06-23 17:03:14.546125
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    description = None
    arg_name = 'arg'
    type_name = None
    is_optional = None
    default = None

    metaparam = DocstringParam(args, description, arg_name, type_name,
                               is_optional, default)

    assert metaparam.args == ['param', 'arg', 'description']
    assert metaparam.description is None
    assert metaparam.arg_name == 'arg'
    assert metaparam.type_name is None
    assert metaparam.is_optional is None
    assert metaparam.default is None


# Generated at 2022-06-23 17:03:21.408537
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated', 'version', 'description']
    description = 'description'

    class TestClass(DocstringDeprecated):
        def __init__(self,args:T.List[str],description:T.Optional[str]) -> None:
            super().__init__(args,description)

    y = TestClass(args,description)
    assert y.args == ['deprecated', 'version', 'description']
    assert y.description == 'description'


# Generated at 2022-06-23 17:03:30.802088
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_list = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    test_obj = DocstringRaises(test_list, "describe test_obj", "Error(BaseException)")
    test_obj_2 = DocstringRaises(test_list, "describe test_obj_2", "Error(BaseException)")
    assert test_obj.args == test_list
    assert test_obj.description == "describe test_obj"
    assert test_obj.type_name == "Error(BaseException)"
    assert not (test_obj == test_obj_2)


# Generated at 2022-06-23 17:03:35.671261
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns is None
    assert ds.deprecation is None


# Generated at 2022-06-23 17:03:39.030671
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-23 17:03:44.947795
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['returns'], "This is a return", "str", False)
    assert x.args == ['returns']
    assert x.description == "This is a return"
    assert x.type_name == "str"
    assert x.is_generator == False
    assert x.return_name == None

# Generated at 2022-06-23 17:03:50.447560
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid input source")
    except ParseError as err:
        if err.args[0] == "Invalid input source":
            return "Success"
        else:
            return "ParseError constructor is not working"



# Generated at 2022-06-23 17:03:55.640459
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None 
    assert ds.long_description == None 
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []

if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-23 17:03:58.590110
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["param"], "description")
    assert meta.args == ["param"]
    assert meta.description == "description"


# Generated at 2022-06-23 17:04:07.609965
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [" :param ", " arg: ", " description"]
    description = "description"
    type_name = "type_name"
    docstring_raises_1 = DocstringRaises(args,description, type_name)
    docstring_raises_2 = DocstringRaises(args,description, type_name)
    assert docstring_raises_1 == docstring_raises_2
    assert docstring_raises_1.args == docstring_raises_2.args
    assert docstring_raises_1.description == docstring_raises_2.description
    assert docstring_raises_1.type_name == docstring_raises_2.type_name



# Generated at 2022-06-23 17:04:13.035639
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['Return', 'returns', 'Returns', 'return']
    description = 'This is a description'
    type_name = 'str'
    is_generator = False
    return_name = 'foo'
    foo = DocstringReturns(args, description, type_name, is_generator, return_name)
    print(foo.description)
    print(foo.type_name)
    print(foo.is_generator)
    print(foo.return_name)


# Generated at 2022-06-23 17:04:15.882433
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    >>> d = Docstring()
    >>> d.short_description
    >>> d.long_description
    >>> d.params
    >>> d.raises
    >>> d.returns
    >>> d.deprecation
    """
    pass



# Generated at 2022-06-23 17:04:20.817038
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises"""
    args= ['raises']
    description= 'if something happens'
    type_name= 'ValueError'
    doc_str= DocstringRaises(args, description, type_name)
    assert doc_str.args == ['raises']
    assert doc_str.description == 'if something happens'
    assert doc_str.type_name == 'ValueError'

# Generated at 2022-06-23 17:04:25.608693
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docStringDeprecated = DocstringDeprecated(["1", "2"], "3", "4")
    assert docStringDeprecated.args == ["1", "2"]
    assert docStringDeprecated.description == "3"
    assert docStringDeprecated.version == "4"


# Generated at 2022-06-23 17:04:28.314632
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = "test"
    doc = DocstringMeta(args, description)
    assert doc.args == []
    assert doc.description == "test"


# Generated at 2022-06-23 17:04:30.197124
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises."""
    assert DocstringRaises([], "description", None)



# Generated at 2022-06-23 17:04:37.744433
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of the Docstring class."""
    test_docstring = Docstring()
    assert test_docstring.short_description is None
    assert test_docstring.long_description is None
    assert test_docstring.blank_after_short_description is False
    assert test_docstring.blank_after_long_description is False
    assert test_docstring.meta == []
    assert test_docstring.params == []
    assert test_docstring.raises == []
    assert test_docstring.deprecation is None

if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-23 17:04:42.304916
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_doc = DocstringReturns([], None, 'float', True)
    assert return_doc.args == []
    assert return_doc.description == None
    assert return_doc.type_name == 'float'
    assert return_doc.is_generator == True
    assert return_doc.return_name == None

# Generated at 2022-06-23 17:04:53.252369
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns1 = DocstringReturns(['return', 'returns'], "This is a description.", "None", False)
    assert returns1.args == ['return', 'returns']
    assert returns1.description == "This is a description."
    assert returns1.type_name == "None"
    assert returns1.is_generator == False
    assert returns1.return_name is None

    returns2 = DocstringReturns(['yield', 'yields'], "This is a description.", "int", True, "This is a return name.")
    assert returns2.args == ['yield', 'yields']
    assert returns2.description == "This is a description."
    assert returns2.type_name == "int"
    assert returns2.is_generator == True

# Generated at 2022-06-23 17:04:56.459691
# Unit test for constructor of class ParseError
def test_ParseError():
    code = "message"
    PE = ParseError(code)
    assert PE.args[0] == "message"


# Generated at 2022-06-23 17:05:01.091749
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg_name = 'arg_name'
    description = 'description'
    args = ['args']
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    assert DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-23 17:05:03.347779
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    type_name = None
    args = []
    description = None
    assert DocstringRaises(args, description, type_name) is not None


# Generated at 2022-06-23 17:05:04.389562
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], "", "")

# Generated at 2022-06-23 17:05:10.977791
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['test']
    description = 'this is a test'
    type_name = 'string'
    is_generator = False
    return_name = 'test'
    test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test.type_name == type_name
    assert test.is_generator == is_generator
    assert test.return_name == return_name

# Generated at 2022-06-23 17:05:19.613107
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['a', 'b']
    description = 'test_description'
    type_name = 'int'
    is_generator = True
    return_name = 'test_name'
    d = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert (d.args == args)
    assert (d.description == description)
    assert (d.type_name == type_name)
    assert (d.is_generator == is_generator)
    assert (d.return_name == return_name)

# Generated at 2022-06-23 17:05:24.972598
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns:', '(int)', 'the', 'foo']
    description = 'the foo'
    type_name = '(int)'
    is_generator = False
    return_name = None 
    DocstringReturns(args, description, type_name, is_generator, return_name)


# Generated at 2022-06-23 17:05:27.549632
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(['param', 'arg'], 'description')
    assert doc.description == 'description'
