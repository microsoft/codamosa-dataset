

# Generated at 2022-06-23 16:55:33.694759
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["Lorem"], "Ipsum")
    assert a.args == ["Lorem"]
    assert a.description == "Ipsum"


# Generated at 2022-06-23 16:55:45.155341
# Unit test for constructor of class Docstring
def test_Docstring():
    import hypothesis.strategies as st
    import hypothesis.extra.datetime as dt
    import hypothesis.extra.numpy as np
    import hypothesis.searchstrategy as ss
    import hypothesis.stateful as state
    import hypothesis.strategies as st
    from hypothesis import given
    from hypothesis import settings
    from hypothesis import Verbosity
    from hypothesis.strategies import SearchStrategy

    st.register_type_strategy(Docstring, st.builds(Docstring))

    class DocstringStrategy(SearchStrategy):
        def __init__(self):
            self.string_strat = st.text()

        def calc_is_empty(self, example: Docstring) -> bool:
            if example.short_description is None and example.long_description is None:
                return True
            return False


# Generated at 2022-06-23 16:55:49.221565
# Unit test for constructor of class Docstring
def test_Docstring():
    assert hasattr(Docstring, '__init__')
    assert callable(Docstring.__init__)
    assert hasattr(Docstring, '__init__')
    assert callable(Docstring.__init__)


# Generated at 2022-06-23 16:55:50.194629
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError


# Generated at 2022-06-23 16:55:53.915379
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam([], 'abcd', 'arg', 'type', False, None)
    assert a.arg_name == 'arg'
    assert a.type_name == 'type'
    assert a.is_optional == False
    assert a.default == None
    print('Passed test_DocstringParam')


# Generated at 2022-06-23 16:55:55.703392
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["a", "b", "c"], "d")



# Generated at 2022-06-23 16:56:00.394549
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'attribute', 'key', 'keyword']
    description = 'meta information'
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-23 16:56:05.812989
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None

# Generated at 2022-06-23 16:56:07.559088
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-23 16:56:14.150429
# Unit test for constructor of class Docstring
def test_Docstring():
	print("class Docstring:")
	a = Docstring()
	assert a.short_description is None
	assert a.long_description is None
	assert a.blank_after_short_description == False
	assert a.blank_after_long_description == False
	assert len(a.meta) == 0
	assert a.params == []
	assert a.raises == []
	assert a.returns == None
	assert a.deprecation == None
test_Docstring()

# Generated at 2022-06-23 16:56:21.264953
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    return_value = DocstringReturns(["returns", ":return:", ":returns:"],
                                    "The return value", "int", False, "value")
    assert return_value.args == ["returns", ":return:", ":returns:"]
    assert return_value.description == "The return value"
    assert return_value.type_name == "int"
    assert return_value.is_generator == False
    assert return_value.return_name == "value"



# Generated at 2022-06-23 16:56:23.006213
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as error:
        print(error)



# Generated at 2022-06-23 16:56:26.343352
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doctringRaises = DocstringRaises(args=['param'], description='test_desc', type_name='test_type')
    assert doctringRaises.args == ['param']
    assert doctringRaises.description == 'test_desc'
    assert doctringRaises.type_name == 'test_type'


# Generated at 2022-06-23 16:56:29.141458
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    import sys
    import os
    here = os.path.abspath(os.path.dirname(__file__))
    sys.path.append(here)
    sys.path.append(os.path.join(here, 'sphinx-issues'))
    from my_testcase import test_DocstringParam
    test_DocstringParam()

# Generated at 2022-06-23 16:56:34.460597
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:56:38.018557
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['keyword argument', 'optional', 'key', 'arg', 'parameter']
    description = 'description'
    arg_name = 'argname'
    type_name = 'typename'
    is_optional = True
    default = 'default'
    test = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert test.args == args
    assert test.description == description
    assert test.arg_name == arg_name
    assert test.type_name == type_name
    assert test.is_optional == is_optional
    assert test.default == default



# Generated at 2022-06-23 16:56:42.395863
# Unit test for constructor of class Docstring
def test_Docstring():
    from .parse import Docstring
    testDocstring = Docstring()
    assert testDocstring.short_description == None
    assert testDocstring.long_description == None
    assert testDocstring.blank_after_short_description == False
    assert testDocstring.blank_after_long_description == False
    assert testDocstring.meta == []


# Generated at 2022-06-23 16:56:47.153915
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated("args", "description", "version")
    assert docstring
    assert docstring.args == "args"
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-23 16:56:49.949028
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(args = [], description = None, type_name = None, is_generator = True)
    assert a == a

# Generated at 2022-06-23 16:56:51.829862
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(args=[], description='', type_name='')

# Generated at 2022-06-23 16:56:54.258448
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["a", "b"]
    description = "c"
    type_name = "d"
    x = DocstringRaises(args, description, type_name)
    assert x.args == ["a", "b"]
    assert x.description == "c"
    assert x.type_name == "d"


# Generated at 2022-06-23 16:57:00.572455
# Unit test for constructor of class Docstring
def test_Docstring():
    test1 = Docstring()

    assert test1.short_description == None
    assert test1.long_description == None
    assert test1.blank_after_short_description == False
    assert test1.blank_after_long_description == False
    assert test1.meta == []

    assert test1.params == []
    assert test1.raises == []
    assert test1.returns == None
    assert test1.deprecation == None

test_Docstring()

# Generated at 2022-06-23 16:57:07.421141
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    param = ["raises", "ValueError"]
    meta = DocstringRaises(param, "if something happens", "ValueError")
    assert isinstance(meta, DocstringRaises)
    assert meta.args == ["raises", "ValueError"]
    assert meta.description == "if something happens"
    assert meta.type_name == "ValueError"


# Generated at 2022-06-23 16:57:09.599196
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args: T.List[str] = []
    r = DocstringReturns(args, "", "", False, "")
    assert isinstance(r, DocstringReturns)

# Generated at 2022-06-23 16:57:13.717758
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
     d = DocstringParam(['param'],None,"arg_name","type_name",True,"default")
     assert d.args == ['param']
     assert d.description == None
     assert d.arg_name == "arg_name"
     assert d.type_name == "type_name"
     assert d.is_optional == True
     assert d.default == "default"


# Generated at 2022-06-23 16:57:15.042036
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(['a'], 'b', 'c')



# Generated at 2022-06-23 16:57:21.584921
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    x = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert x.description == description
    assert x.arg_name == arg_name
    assert x.type_name == type_name
    assert x.is_optional == is_optional
    assert x.default == default


# Generated at 2022-06-23 16:57:24.255128
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    inst = DocstringMeta(args=['Param', 'attribute'], description='Description of this parameter')
    assert inst.args == ['Param', 'attribute']
    assert inst.description == 'Description of this parameter'


# Generated at 2022-06-23 16:57:27.974909
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a=DocstringDeprecated(["deprecated", "version"], "", "")
    assert isinstance(a,DocstringMeta)
    assert a.args[0]=="deprecated"
    assert a.args[1]=="version"
    assert a.description==""
    assert a.version==""



# Generated at 2022-06-23 16:57:34.544485
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert not ds.short_description
    assert not ds.long_description
    assert not ds.blank_after_short_description
    assert not ds.blank_after_long_description
    assert not ds.meta
    assert not ds.params
    assert not ds.raises
    assert not ds.returns
    assert not ds.deprecation

# Generated at 2022-06-23 16:57:37.821306
# Unit test for constructor of class DocstringParam

# Generated at 2022-06-23 16:57:40.696876
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta = DocstringMeta(["someArgs"], "some description")
    assert(docstringMeta.args == ["someArgs"])
    assert(docstringMeta.description == "some description")


# Generated at 2022-06-23 16:57:43.411821
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("This is a custom error message.")
    print("ok")
    return error


# Generated at 2022-06-23 16:57:45.750198
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise(ParseError('error'))
    except ParseError:
        return True
    return False


# Generated at 2022-06-23 16:57:48.062773
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test = DocstringMeta([], "descript")
    assert test.args == []
    assert test.description == "descript"



# Generated at 2022-06-23 16:57:54.392055
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns(): 
    test_meta_args = ['param', 'user_id']
    test_meta_desc = 'user id'
    test_meta_type_name = 'str'
    test_meta_is_generator = True
    test_meta_return_name = None

    assert DocstringReturns(test_meta_args,test_meta_desc,test_meta_type_name,test_meta_is_generator,test_meta_return_name) != None


# Generated at 2022-06-23 16:57:57.186338
# Unit test for constructor of class Docstring
def test_Docstring():
    s = Docstring()
    assert s.short_description == None
    assert s.long_description == None
    assert s.blank_after_short_description == False
    assert s.blank_after_long_description == False
    assert s.meta == []


# Generated at 2022-06-23 16:58:02.731818
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param", "arg", "type", "str"], "some description", "arg", "str", True, "default")
    assert a.is_optional == True
    assert a.default == "default"
    assert a.type_name == "str"


# Generated at 2022-06-23 16:58:05.211201
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([],None).args==[]
    assert DocstringMeta([],None).description==None


# Generated at 2022-06-23 16:58:11.822384
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    the_args = []
    the_description = None
    the_is_generator = True
    return_name = None
    type_name = None

    new_returns = DocstringReturns(the_args,
                                   the_description,
                                   type_name,
                                   the_is_generator,
                                   return_name)
    assert isinstance(new_returns, DocstringMeta)
    assert new_returns.args == the_args
    assert new_returns.description == the_description
    assert new_returns.return_name == return_name
    assert new_returns.type_name == type_name
    assert new_returns.is_generator == the_is_generator


# Generated at 2022-06-23 16:58:15.693450
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  args={'args':[1,2],'description':[3,4],'type_name':[5,6]}
  DocstringRaises(**args)
import unittest
if __name__ == '__main__':
  unittest.main()

# Generated at 2022-06-23 16:58:16.991305
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta('args', 'description')



# Generated at 2022-06-23 16:58:22.797286
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    temp = DocstringRaises(
        args=["param"],
        description="foobar",
        type_name="foobar"
    )
    assert temp.args == ["param"] and temp.description == "foobar" and temp.type_name == "foobar"



# Generated at 2022-06-23 16:58:27.204223
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
   assert(DocstringMeta(["args"], "description"))
   assert(DocstringParam([], "description", "arg", "type", "optional"))
   assert(DocstringReturns([], "description", "type", True, "return"))
   assert(DocstringRaises([], "description", "type"))
   assert(DocstringDeprecated([], "description", 2))


# Generated at 2022-06-23 16:58:28.949764
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError(None)
    except ParseError:
        # expected
        pass

# Generated at 2022-06-23 16:58:40.693665
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    import Docstring as D
    D.DocstringMeta(args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"],description="This function is used to add two numbers").__init__()
    D.DocstringParam(args= ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"],description="This function is used to add two numbers", arg_name="x", type_name="integer", is_optional="true", default="0").__init__()
    D.DocstringReturns(args= ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"],description="This function is used to add two numbers",type_name="integer", is_generator="false").__init__()

# Generated at 2022-06-23 16:58:46.166424
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    def check(
        args: T.List[str],
        description: T.Optional[str],
        arg_name: str,
        type_name: T.Optional[str],
        is_optional: T.Optional[bool],
        default: T.Optional[str],
    ):
        param = DocstringParam(
            args, description, arg_name, type_name, is_optional, default
        )
        assert param.args == args
        assert param.description == description
        assert param.arg_name == arg_name
        assert param.type_name == type_name
        assert param.is_optional == is_optional
        assert param.default == default


# Generated at 2022-06-23 16:58:52.176322
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    docstring_obj = Docstring()
    assert docstring_obj.short_description is None
    assert docstring_obj.long_description is None
    assert docstring_obj.blank_after_short_description is False
    assert docstring_obj.blank_after_long_description is False
    assert docstring_obj.meta == []


# Generated at 2022-06-23 16:58:56.042124
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(args = ["raises", "Raises"], description = None, version = "0.1.0")
    if obj == None:
        raise RuntimeError("DocstringDeprecated constructor not functioning properly")


# Generated at 2022-06-23 16:59:00.306605
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    assert obj.short_description == None
    assert obj.long_description == None
    assert obj.blank_after_short_description == False
    assert obj.blank_after_long_description == False
    assert obj.meta == []


# Generated at 2022-06-23 16:59:01.900383
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    args = [None, None]
    description = None

    DocstringMeta(args, description)

    print("DocstringMeta constructed successfully")



# Generated at 2022-06-23 16:59:06.478681
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam.__init__(["arg"],
                                   "description",
                                   "arg_name",
                                   "type_name",
                                   True,
                                   "default") is None


# Generated at 2022-06-23 16:59:11.875517
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-23 16:59:21.294856
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-23 16:59:29.497896
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    obj = DocstringReturns(['arg1'], "testReturns", "str", False, "return_name")
    assert obj.args == ['arg1']
    assert obj.description == "testReturns"
    assert obj.type_name == "str"
    assert obj.is_generator == False
    assert obj.return_name == "return_name"


# Generated at 2022-06-23 16:59:32.310642
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    m = DocstringMeta(args=["param"], description="description")
    assert m.args == ["param"]
    assert m.description == "description"


# Generated at 2022-06-23 16:59:37.975792
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error")
    except ParseError as e:
        assert e.__class__ == ParseError
        assert e.args == ("error",)

# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-23 16:59:40.323955
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []



# Generated at 2022-06-23 16:59:44.647103
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == []
    #assert docstringRaises.description == "if something happens"
    assert docstringRaises.type_name == "ValueError"


# Generated at 2022-06-23 16:59:47.193771
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []



# Generated at 2022-06-23 16:59:47.905281
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(None, None, None)


# Generated at 2022-06-23 16:59:55.631563
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = 'a docstring'
    arg_name = 'a'
    type_name = 'int'
    is_optional = True
    default = '1'
    a = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert a.__doc__ == 'DocstringMeta symbolizing :param metadata.'
    assert a.__class__ == DocstringParam
    assert a.args == args
    assert a.description == description
    assert a.arg_name == arg_name
    assert a.type_name == type_name
    assert a.is_optional == is_optional
    assert a.default == default


# Generated at 2022-06-23 16:59:58.985192
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param", "arg", "argument"], "description", "arg_name", "type_name", True, "default")

# Generated at 2022-06-23 17:00:00.883310
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    k = DocstringRaises(
    args = ["raises","ValueError"],
    description = "if something happens",
    type_name = "ValueError")


# Generated at 2022-06-23 17:00:05.284425
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-23 17:00:17.751673
# Unit test for constructor of class Docstring
def test_Docstring():
    d_str = Docstring()
    d_str.short_description = "Constructor of class Docstring"
    d_str.long_description = "Unit test for constructor of class Docstring"
    d_str.blank_after_short_description = True
    d_str.blank_after_long_description = True
    d_str.meta = ["", ""]
    assert d_str.short_description == "Constructor of class Docstring"
    assert d_str.long_description == "Unit test for constructor of class Docstring"
    assert d_str.blank_after_short_description == True
    assert d_str.blank_after_long_description == True
    assert d_str.meta == ["", ""]
    
    
    

# Generated at 2022-06-23 17:00:24.746386
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta"""
    a = DocstringMeta(["arg", "arg2", "arg3"], "test_description")
    assert a.args == ["arg", "arg2", "arg3"]
    assert a.description == "test_description"


# Generated at 2022-06-23 17:00:27.897140
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Verify that DocstringReturns can be constructed."""
    returns = DocstringReturns(
        ["returns"], description=None, type_name=None, is_generator=False
    )



# Generated at 2022-06-23 17:00:32.991971
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "I am a parameter"
    r = DocstringMeta(args, description)
    assert (
        "DocstringMeta(args=['param'], description='I am a parameter')" ==
        repr(r))
    assert "I am a parameter" == r.description

# Generated at 2022-06-23 17:00:40.565182
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None

# Generated at 2022-06-23 17:00:42.610132
# Unit test for constructor of class ParseError
def test_ParseError():
    example = ParseError()
    assert(example)
    

# Generated at 2022-06-23 17:00:45.574494
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("test_DocstringParam")
    pass


# Generated at 2022-06-23 17:00:52.492100
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(args = ["raises", "ValueError"], description = "description", type_name = "ValueError")
    assert(docstring_raises.args == ["raises", "ValueError"])
    assert(docstring_raises.description == "description")
    assert(docstring_raises.type_name == "ValueError")



# Generated at 2022-06-23 17:01:00.377986
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["hey", "this", "is", "a", "test"], "long desc here", "1.0")
    assert test.args == ["hey", "this", "is", "a", "test"]
    assert test.description == "long desc here"
    assert test.version == "1.0"

# Generated at 2022-06-23 17:01:06.850819
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    wrong_arguments = ["test", "test2", "test3", "test4", "test5", "test6", "test7"]
    _ = DocstringReturns(wrong_arguments[0], wrong_arguments[1], wrong_arguments[2], wrong_arguments[3], wrong_arguments[4], wrong_arguments[5], wrong_arguments[6])


# Generated at 2022-06-23 17:01:08.152061
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['param','arg'], 'description')


# Generated at 2022-06-23 17:01:13.233502
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None 
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None
    print("PASS")

if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-23 17:01:20.130156
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(Docstring())
    assert(Docstring().short_description is None)
    assert(Docstring().long_description is None)
    assert(Docstring().blank_after_short_description is False)
    assert(Docstring().blank_after_long_description is False)
    assert(Docstring().meta == [])



# Generated at 2022-06-23 17:01:24.714806
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_code = DocstringReturns(["return", "returns"], "", "")
    assert return_code.description == ''
    assert return_code.type_name == ''
    assert return_code.is_generator == False
    assert return_code.return_name == None


# Generated at 2022-06-23 17:01:29.332629
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["a"], "test")
    assert isinstance(meta, DocstringMeta)
    assert meta.args == ["a"]
    assert meta.description == "test"


# Generated at 2022-06-23 17:01:34.797591
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    res = DocstringReturns(['a', 'b', 'c'], "description", "type", "is_generator")
    assert res.args == ['a', 'b', 'c']
    assert res.description == "description"
    assert res.type_name == "type"
    assert res.is_generator == "is_generator"
    assert res.return_name == None

# Generated at 2022-06-23 17:01:38.900000
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param']
    description = 'the description'
    type_name = 'String'
    try:
        DocstringRaises(args, description, type_name)
    except Exception as e:
        print('Constructor of class DocstringRaises has error: ', e)
    else:
        print('Constructor of class DocstringRaises is correct!')

# Generated at 2022-06-23 17:01:42.719944
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        test = DocstringDeprecated("test", "test", "test")
    except:
        raise AssertionError("test_DocstringDeprecated")


# Generated at 2022-06-23 17:01:46.363668
# Unit test for constructor of class Docstring
def test_Docstring():
    new_docstring = Docstring()
    assert new_docstring.params == []
    assert new_docstring.raises == []
    assert new_docstring.deprecation is None


# Generated at 2022-06-23 17:01:48.128645
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError(msg='Test')



# Generated at 2022-06-23 17:01:49.268318
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['returns', 'Return', 'return', 'yields', 'Yield'], '', False, '', '', None, None)

# Generated at 2022-06-23 17:01:51.196141
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([" :deprecated: ", "deprecated", "since"], "version 1", "version 1")

# Generated at 2022-06-23 17:01:59.974309
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = 'This is a description'
    arg_name = 'param'
    type_name = 'int'
    is_optional = False
    default = None
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.arg_name == 'param'
    assert dp.description == 'This is a description'
    assert dp.type_name == 'int'
    assert dp.is_optional == False
    assert dp.default == None


# Generated at 2022-06-23 17:02:10.953237
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test the constructor of class DocstringDeprecated"""
    a = DocstringDeprecated([], None, '3.8')
    assert isinstance(a, DocstringDeprecated)
    assert a.args == [] and a.description == None and a.version == '3.8'

    a = DocstringDeprecated(['deprecated'], 'message', '3.8')
    assert isinstance(a, DocstringDeprecated)
    assert a.args == ['deprecated'] and a.description == 'message' and a.version == '3.8'
    
    a = DocstringDeprecated(['deprecated'], 'message', '2.4')
    assert isinstance(a, DocstringDeprecated)
    assert a.args == ['deprecated'] and a.description == 'message' and a.version == '2.4'

#

# Generated at 2022-06-23 17:02:12.920036
# Unit test for constructor of class ParseError
def test_ParseError():
     with pytest.raises(Exception):
        raise ParseError('test passed')

# Generated at 2022-06-23 17:02:24.337311
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['returns'], 'The sum of a and b', 'int', False, 'result').args == ['returns']
    assert DocstringReturns(['returns'], 'The sum of a and b', 'int', False, 'result').is_generator == False
    assert DocstringReturns(['returns'], 'The sum of a and b', 'int', False, 'result').description == 'The sum of a and b'
    assert DocstringReturns(['returns'], 'The sum of a and b', 'int', False, 'result').type_name == 'int'
    assert DocstringReturns(['returns'], 'The sum of a and b', 'int', False, 'result').return_name == 'result'



# Generated at 2022-06-23 17:02:26.633521
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    exception = DocstringRaises(["raises"], "if something happens", "ValueError")
    assert exception

# Generated at 2022-06-23 17:02:29.513432
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.params == []
    assert docstring.raises == []


# Generated at 2022-06-23 17:02:37.174183
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    item_args = ["this", "is", "args"]
    item_description = "this is description"
    item_version = "this is version"

    item = DocstringDeprecated(item_args, item_description, item_version)
    assert item.args == item_args
    assert item.description == item_description
    assert item.version == item_version


# Generated at 2022-06-23 17:02:39.380320
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "description", version="0.0.1")


# Generated at 2022-06-23 17:02:43.157061
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises(): 
    try:
        _ = DocstringRaises(["arg1", "arg2"], "desc", "TypeError")
    except SyntaxError as e:
        print(e)
    else:
        print("OKKKKKKKKKKKKKK")


# Generated at 2022-06-23 17:02:50.682936
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam"""
    test_args=["param", "joe"]
    test_description="description"
    test_arg_name="joe"
    test_type_name="str"
    test_is_optional=False
    test_default="4"
    assert DocstringParam(test_args, test_description, test_arg_name, test_type_name, test_is_optional, test_default)


# Generated at 2022-06-23 17:02:57.190956
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(['a'], 'description of a', 'a', 'b')
        assert False
    except TypeError:
        assert True
    except:
        assert False

    DocstringParam(['a'], 'description of a', 'a', 'b', True)

    try:
        DocstringParam(['a'], 'description of a', 'a', 'b', 'hello')
        assert False
    except TypeError:
        assert True
    except:
        assert False

# Generated at 2022-06-23 17:03:02.827791
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test message')
    except ParseError as err:
        assert str(err) == 'test message'
    else:
        assert 0, 'Cannot raise ParseError'


# Generated at 2022-06-23 17:03:04.994123
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Something went wrong")
    except RuntimeError:
        pass

# Generated at 2022-06-23 17:03:07.797896
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = 'test description'
    assert DocstringMeta(args, description).args == args
    assert DocstringMeta(args, description).description == description


# Generated at 2022-06-23 17:03:10.376676
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """
    Unit test for constructor of class DocstringMeta.
    """
    try:
        x = DocstringMeta('args', 'description')
        assert True
    except Exception:
        assert False


# Generated at 2022-06-23 17:03:16.373020
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    description = None
    type_name = None
    is_generator = False
    return_name = None
    doct_returns = DocstringReturns(args,description,type_name,is_generator,return_name)
    assert doct_returns.args == args
    assert doct_returns.description == description
    assert doct_returns.type_name == type_name
    assert doct_returns.is_generator == is_generator
    assert doct_returns.return_name == return_name

# Generated at 2022-06-23 17:03:20.484114
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a  = DocstringRaises(["raises"], "desc", "Exception")
    assert a.args == ["raises"]
    assert a.description == "desc"
    assert a.type_name == "Exception"


# Generated at 2022-06-23 17:03:24.048361
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert len(doc.params) == 0
    assert len(doc.raises) == 0
    assert doc.returns is None
    assert doc.deprecation is None
    return

# Generated at 2022-06-23 17:03:26.795714
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = ''
    docmeta = DocstringMeta(args, description)
    assert docmeta.args is args
    assert docmeta.description is description



# Generated at 2022-06-23 17:03:31.852766
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dsr = DocstringReturns(['return', 'returns'], 'descr', 'R')
    assert dsr.is_generator == False
    assert dsr.return_name == None
    assert dsr.type_name == 'R'
    assert dsr.description == 'descr'


# Generated at 2022-06-23 17:03:33.580155
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("This is an error")
    return



# Generated at 2022-06-23 17:03:39.897136
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    tmp = DocstringReturns(args=["param"], description="Descr", type_name="int", is_generator=False)
    if tmp.args != ["param"] or tmp.description != "Descr" or tmp.type_name != "int" or tmp.is_generator or tmp.return_name != None:
        raise RuntimeError("Failed test_DocstringReturns test")
    else:
        print("Passed test_DocstringReturns test")


# Generated at 2022-06-23 17:03:46.737360
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Arrange
    args = ["deprecated"]
    description = "This is a deprecated function"
    version = "1.0.0"
    # Act
    actual = DocstringDeprecated(args, description, version)

    # Assert
    assert isinstance(actual, DocstringDeprecated)
    assert actual.args == args
    assert actual.description == description
    assert actual.version == version



# Generated at 2022-06-23 17:03:54.355287
# Unit test for constructor of class ParseError
def test_ParseError():
    #__init__(self, args: T.List[str], description: str) -> None:
    try:
        raise ParseError(["lalal", "lilili"], "lololo")
    except ParseError as e:
        assert e.args == ("lalal", "lilili")
        assert str(e) == "lololo"
    try:
        raise ParseError(None, None)
    except ParseError as e:
        assert e.args == ()
        assert str(e) == ''


# Generated at 2022-06-23 17:03:59.704498
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:04:02.802963
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    err = ParseError()
    assert issubclass(ParseError, RuntimeError)
    assert isinstance(err, RuntimeError)


# Generated at 2022-06-23 17:04:08.012212
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test the constructor"""
    test_args = ["Args", "Args1", "Args2"]
    test_description = "Test Description"
    test_type_name = "Test Type Name"
    test_object = DocstringRaises(test_args, test_description, test_type_name)
    assert test_object.args == test_args
    assert test_object.description == test_description
    assert test_object.type_name == test_type_name


# Generated at 2022-06-23 17:04:10.024523
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    with raises(RuntimeError):
        raise ParseError("hello")


# Generated at 2022-06-23 17:04:11.255015
# Unit test for constructor of class ParseError
def test_ParseError():
    perror = ParseError()
    assert perror is not None


# Generated at 2022-06-23 17:04:20.143542
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['']
    description = "a description"
    test_type = "int"
    is_generator = False 
    returns_test = DocstringReturns(args, description, test_type, is_generator)
    print(returns_test.args)
    print(returns_test.description)
    print(returns_test.type_name)
    print(returns_test.is_generator)
    print(returns_test.return_name)


if __name__ == '__main__':
    test_DocstringReturns()

# Generated at 2022-06-23 17:04:28.533893
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["raises", "ValueError"]
    desc = "when something happens"
    type_name = "string"
    is_generator = False
    return_name = "return_name"

    ret = DocstringReturns(args, desc, type_name, is_generator, return_name)
    assert ret.args == args
    assert ret.description == desc
    assert ret.type_name == type_name
    assert ret.is_generator == is_generator
    assert ret.return_name == return_name

# Generated at 2022-06-23 17:04:31.282922
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta([":param","test"], "Test")
    assert dsm.args == [":param","test"]
    assert dsm.description == "Test"


# Generated at 2022-06-23 17:04:32.412801
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError



# Generated at 2022-06-23 17:04:40.117508
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d_param = DocstringParam(
        args=['hello'],
        description='this is my description',
        arg_name='This is my argument',
        type_name='arg_type',
        is_optional=True,
        default='default'
    )

    assert d_param.args == ['hello']
    assert d_param.description == 'this is my description'
    assert d_param.arg_name == 'This is my argument'
    assert d_param.type_name == 'arg_type'
    assert d_param.is_optional == True
    assert d_param.default == 'default'


# Generated at 2022-06-23 17:04:44.059173
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ':-1'
    description = 'short description'
    type_name = 'int'
    test_obj = DocstringRaises(args, description, type_name)


# Generated at 2022-06-23 17:04:45.900198
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test_ParseError")
    if not isinstance(pe, ParseError):
        raise ValueError("test_ParseError failed")



# Generated at 2022-06-23 17:04:48.086672
# Unit test for constructor of class Docstring
def test_Docstring():
    c = Docstring()
    print(c.params)
    print(c.raises)
    print(c.returns)
    print(c.deprecation)
    print(c.meta)

test_Docstring()


# Generated at 2022-06-23 17:04:50.809595
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_gDT = DocstringRaises(["raises"], "a test string", "type_name")
    assert test_gDT.args == ["raises"]
    assert test_gDT.description == "a test string"
    assert test_gDT.type_name == "type_name"


# Generated at 2022-06-23 17:04:56.918962
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringdeprecated = DocstringDeprecated(["param"], "some_description", "v1.0")
    assert docstringdeprecated.args == ["param"]
    assert docstringdeprecated.description == "some_description"
    assert docstringdeprecated.version == "v1.0"


# Generated at 2022-06-23 17:05:00.027777
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    new = DocstringDeprecated("args", "description", "version")
    assert new.args == "args"
    assert new.description == "description"
    assert new.version == "version"


# Generated at 2022-06-23 17:05:04.000650
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    Obj = DocstringReturns(["a", "b", "c"], "description", "a", False)
    assert(Obj.description == "description")
    assert(Obj.args == ["a", "b", "c"])
    assert(Obj.type_name == "a")
    assert(Obj.is_generator == False)


# Generated at 2022-06-23 17:05:08.385595
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    list_args = ['a','b','c']
    description = "This is a description"
    test_meta = DocstringMeta(list_args,description)
    assert test_meta.args == list_args
    assert test_meta.description == description


# Generated at 2022-06-23 17:05:10.644012
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
  DocstringReturns(["return", "returns", "return_type"], "hello world", "int", False)



# Generated at 2022-06-23 17:05:12.598974
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    os.system("pytest test_docstring.py -k test_DocstringRaises")


# Generated at 2022-06-23 17:05:18.366171
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["a", "b", "c", "d"]
    description = "Hello"
    type_name = "string"
    is_generator = "True"
    return_name = "greetings"
    a = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert a.description == description, "description wrong"
    assert a.type_name == type_name, "type_name wrong"
    assert a.is_generator == is_generator, "is_generator wrong"
    assert a.return_name == return_name, "return_name wrong"



# Generated at 2022-06-23 17:05:20.254053
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['a'], 'a', 'a')
    assert docstring.args == ['a'] 
    assert docstring.description == 'a'
    assert docstring.version == 'a'

# Generated at 2022-06-23 17:05:22.606414
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-23 17:05:24.549451
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-23 17:05:35.603262
# Unit test for constructor of class DocstringRaises