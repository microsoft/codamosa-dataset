

# Generated at 2022-06-23 16:55:32.991446
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-23 16:55:36.234704
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['a'], "d")
    assert a.args == ['a']
    assert a.description == "d"


# Generated at 2022-06-23 16:55:37.974433
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises", "ValueError"], "description", "ValueError")


# Generated at 2022-06-23 16:55:42.795715
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("A")
    assert str(a) == "A"
    a = ParseError("A", 2)
    assert str(a) == "A"
    try:
        raise ParseError("A")
    except ParseError as e:
        assert str(e) == "A"


# Generated at 2022-06-23 16:55:48.616599
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "This is version one", "1.0")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.type_name == "1.0"
    assert docstring_deprecated.description == "This is version one"


# Generated at 2022-06-23 16:55:51.719051
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['deprecated'], 'Documentation for the deprecated DocstringDeprecated class.', '0.9')
    print(d.args)
    print(d.description)
    print(d.version)

# Generated at 2022-06-23 16:55:58.480278
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    #test with empty arguments
    ds = DocstringParam([], None, None, None, None, None)
    assert ds.args == []
    assert ds.description is None
    assert ds.arg_name is None
    assert ds.type_name is None
    assert ds.is_optional is None
    assert ds.default is None

    #test with non-empty arguments
    ds = DocstringParam([], None, 'arg_name', 'type_name', True, None)
    assert ds.args == []
    assert ds.description is None
    assert ds.arg_name == 'arg_name'
    assert ds.type_name == 'type_name'
    assert ds.is_optional == True
    assert ds.default is None

# Generated at 2022-06-23 16:56:03.214174
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Create DocstringRaises object with all fields and check
    d = DocstringRaises(["raises","ValueError"], "if something happens", "ValueError")
    assert d.args == ["raises","ValueError"]
    assert d.description == "if something happens"
    assert d.type_name == "ValueError"


# Generated at 2022-06-23 16:56:08.164584
# Unit test for constructor of class ParseError
def test_ParseError():
    error1 = ParseError('No docstring found')
    error2 = ParseError()
    assert error1.args == ('No docstring found',)
    assert error2.args == tuple()


# Generated at 2022-06-23 16:56:09.710442
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises','raise','except','exception'],None,None)

# Generated at 2022-06-23 16:56:14.121619
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises([], "description", "type_name")
    assert d


# Generated at 2022-06-23 16:56:17.474663
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # WHEN
    a = DocstringDeprecated(["arg1"], "description", "version")

    # THEN
    assert a.args == ["arg1"]
    assert a.description == "description"
    assert a.version == "version"



# Generated at 2022-06-23 16:56:24.323454
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated('test', 'test', 'test')
    if isinstance(docstring.description, type(None)):
        print("description of args is None")
    if isinstance(docstring.type_name, type(None)):
        print("type_name of args is None")
    if isinstance(docstring.version, type(None)):
        print("of args is None")
    print(docstring.args)
    print(docstring.description)
    print(docstring.version)
    return docstring


# Generated at 2022-06-23 16:56:29.146068
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(['parameter'], 'desc', 'ValueError')
    assert docstring.args == ['parameter']
    assert docstring.description == 'desc'
    assert docstring.type_name == 'ValueError'


# Generated at 2022-06-23 16:56:31.810061
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(args=['arg1', 'arg2'], description='description')


# Generated at 2022-06-23 16:56:35.896972
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg1', 'arg2']
    description = 'hello world'
    doc_string = DocstringMeta(args, description)
    assert doc_string.args == ['arg1', 'arg2']
    assert doc_string.description == 'hello world'


# Generated at 2022-06-23 16:56:40.545418
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ON_DUPLICATES_REPLACE']
    description = 'if an item with the same key is added twice'
    type_name = 'DuplicateKeyError'
    doc = DocstringRaises(args, description, type_name)
    assert doc.args == args
    assert doc.description == description
    assert doc.type_name == type_name



# Generated at 2022-06-23 16:56:43.524873
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r = DocstringReturns(0,1,2,3)
    assert r.args == 0
    assert r.description == 1
    assert r.type_name == 2
    assert r.is_generator == 3

# Generated at 2022-06-23 16:56:45.929057
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    parse_error = ParseError


# Generated at 2022-06-23 16:56:48.581459
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Construct empty DocstringReturns object
    DocstringReturns([], None, None, None, None)


# Generated at 2022-06-23 16:56:50.903022
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(args=[], description="desc")
    assert obj.args == []
    assert obj.description == "desc"


# Generated at 2022-06-23 16:56:53.732284
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    t = DocstringMeta(['param'], 'description')
    assert t.args == ['param']
    assert t.description == 'description'


# Generated at 2022-06-23 16:56:59.663626
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam([':param', 'arg'], 'description', 'arg', None, None, None)
    assert p.args == [':param', 'arg']
    assert p.description == 'description'
    assert p.arg_name == 'arg'
    assert p.type_name == None
    assert p.is_optional == None
    assert p.default == None



# Generated at 2022-06-23 16:57:02.879059
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args=['arg: description'], description='description', type_name='type_name', is_generator=True, return_name='return_name')



# Generated at 2022-06-23 16:57:08.304329
# Unit test for constructor of class ParseError
def test_ParseError():
    error_message = "test_error"
    try:
        raise ParseError(error_message)
    except ParseError as e:
        assert e.__str__() == error_message

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 16:57:12.497424
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param", "arg:", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "arg"
    is_optional = "arg"
    default = "arg"
    obj = DocstringParam(args,description,arg_name,type_name,is_optional,default)
if __name__ == "__main__":
    test_DocstringParam()

# Generated at 2022-06-23 16:57:14.416283
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description of the argument", "arg_name",
                   "type_name", "is_optional", "default")



# Generated at 2022-06-23 16:57:20.029027
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test function for constructor of class DocstringRaises"""
    raise_info = DocstringRaises(
        args=[
            "raises",
            "ValueError",
        ],
        description="description",
        type_name="ValueError",
    )
    assert raise_info.args == [
        "raises",
        "ValueError",
    ]
    assert raise_info.description == "description"
    assert raise_info.type_name == "ValueError"


# Generated at 2022-06-23 16:57:23.716048
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns."""
    assert DocstringReturns(
        args=["returns"],
        description="Foo",
        type_name="Bar",
        is_generator=False,
        return_name="baz"
    )

# Generated at 2022-06-23 16:57:31.980634
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(["param", "arg"], "description", "arg", "type_name", "is_optional", "default")
    assert docstring.args == ["param", "arg"]
    assert docstring.description == "description"
    assert docstring.arg_name == "arg"
    assert docstring.type_name == "type_name"
    assert docstring.is_optional == "is_optional"
    assert docstring.default == "default"


# Generated at 2022-06-23 16:57:35.170378
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(
        args=["returns"],
        description="...",
        type_name="my_type",
        is_generator=True,
        return_name="my_return_name"
    )

# Generated at 2022-06-23 16:57:37.925064
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        print("test_ParseError: pass")
    else:
        print("test_ParseError: failed")



# Generated at 2022-06-23 16:57:38.697302
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()
    return None

# Generated at 2022-06-23 16:57:41.379790
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docmeta = DocstringMeta(None, None)
    assert docmeta.args is None
    assert docmeta.description is None



# Generated at 2022-06-23 16:57:46.901963
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(["deprecated"], "this is deprecated", "0.3.0")
    assert ds is not None
    assert str(ds) == "DocstringDeprecated()"
    assert ds.version == "0.3.0"
    assert ds.description == "this is deprecated"


# Generated at 2022-06-23 16:57:50.289527
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dsm = DocstringMeta(['kw'], 'kw description')
    assert dsm.args == ['kw']
    assert dsm.description == 'kw description'


# Generated at 2022-06-23 16:57:57.716537
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """ Unit test for constructor of class DocstringParam """
    list_of_strings = []
    list_of_strings.append("parameter")
    string = "test_description"

    test_parameter = DocstringParam(list_of_strings,string,"arg_name", "type_name", True, "default")

    assert (test_parameter.args == list_of_strings)
    assert (test_parameter.description == string)
    assert (test_parameter.arg_name == "arg_name")
    assert (test_parameter.type_name == "type_name")
    assert (test_parameter.is_optional == True)
    assert (test_parameter.default == "default")



# Generated at 2022-06-23 16:58:02.701723
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg']
    description = 'description'
    type_name = 'int'
    is_generator = False
    return_name = None
    assert DocstringReturns(args, description, type_name, is_generator, return_name).args == args
    assert DocstringReturns(args, description, type_name, is_generator, return_name).description == description
    assert DocstringReturns(args, description, type_name, is_generator, return_name).type_name == type_name
    assert DocstringReturns(args, description, type_name, is_generator, return_name).is_generator == is_generator
    assert DocstringReturns(args, description, type_name, is_generator, return_name).return_name == return_name

# Generated at 2022-06-23 16:58:04.420334
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        return True
    return False


# Generated at 2022-06-23 16:58:09.297948
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['raises'], 'haha', 'type')
    assert d.args == ['raises']
    assert d.description == 'haha'
    assert d.type_name == 'type'


# Generated at 2022-06-23 16:58:14.767721
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated(version=2.0)"]
    description = "This function is deprecated. Use other function."
    version = "2.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated is not None
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version



# Generated at 2022-06-23 16:58:20.371165
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test for the constructor of the class DocstringRaises."""
    args = ['param', 'arg', 'name']
    description = 'With this parameter I do something.'
    type_name = 'int'
    a = DocstringRaises(args, description, type_name)
    assert a.args == args
    assert a.description == description
    assert a.type_name == type_name

# Generated at 2022-06-23 16:58:22.372509
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["param"], "description")
    assert meta.args == ["param"]
    assert meta.description == "description"


# Generated at 2022-06-23 16:58:27.794729
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=[], description='', arg_name='', type_name='', is_optional=False, default='')
    assert docstring_param.args == []
    assert docstring_param.description == ''
    assert docstring_param.arg_name == ''
    assert docstring_param.type_name == ''
    assert docstring_param.is_optional == False
    assert docstring_param.default == ''


# Generated at 2022-06-23 16:58:32.685179
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
   test_var = DocstringDeprecated(['deprecated'], 'The function is no longer supported', 'version 1.0')
   result = test_var.version
   assert result == 'version 1.0'


# Generated at 2022-06-23 16:58:39.114712
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    test.short_description = 'JH'
    assert test.short_description == 'JH'

    # test.blank_after_short_description = True
    # assert test.blank_after_short_description == True

    # test.blank_after_long_description = False
    # assert test.blank_after_long_description == False

    # test.meta = ['JH']
    # assert test.meta == ['JH']

# Generated at 2022-06-23 16:58:40.848423
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["param"], "description", "1.0.0")
    if not isinstance(docstring, DocstringDeprecated):
        raise RuntimeError("Error on initialization of DocstringDeprecated")


# Generated at 2022-06-23 16:58:42.225232
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(None, None, None)
    assert isinstance(a, DocstringRaises)


# Generated at 2022-06-23 16:58:43.379136
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta([], "")



# Generated at 2022-06-23 16:58:44.622479
# Unit test for constructor of class ParseError
def test_ParseError():
    raise ParseError("test")


# Generated at 2022-06-23 16:58:50.237212
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of class DocstringParam."""
    d = DocstringParam(None,
        None,
        None,
        None,
        None,
        None)
    assert d.args == None
    assert d.description == None
    assert d.arg_name == None
    assert d.type_name == None
    assert d.is_optional == None
    assert d.default == None


# Generated at 2022-06-23 16:58:59.109311
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    from docstring_parser import parse
    # Test for :raises metadata
    code = """
    def test(x: int) -> None:
        \"\"\"
        This is a docstring
        :raises ValueError: if value is 5
        \"\"\"
    """
    code_expect_result = [(parse(code) is not None)]
    code_result = [True]
    assert code_expect_result == code_result


# Generated at 2022-06-23 16:59:05.089895
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["", "", "", "", "", "", "", "", "", "", "", "", "", "", ""], None, None, False, None)
    DocstringReturns([], "", "", True, "")

# Generated at 2022-06-23 16:59:07.272890
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(args=["test1","test2"],description="test")


# Generated at 2022-06-23 16:59:08.997736
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass



# Generated at 2022-06-23 16:59:10.552918
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert isinstance(DocstringDeprecated(['type'], 'description', 'version'), DocstringDeprecated)



# Generated at 2022-06-23 16:59:23.652283
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(
        args=["a", "b", "c"],
        description="d",
        type_name="e",
        return_name="f",
        is_generator=False,
    )
    DocstringReturns(
        args=["a", "b", "c"],
        description="d",
        type_name="e",
        return_name="f",
        is_generator=True,
    )
    DocstringReturns(
        args=["a", "b", "c"],
        description="d",
        type_name=None,
        is_generator=False,
        return_name="f",
    )

# Generated at 2022-06-23 16:59:26.473168
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err.args[0] == "None"


# Generated at 2022-06-23 16:59:33.161060
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([":"], None, "arg", "int", None, None)

    assert docstring_param.args == [":"]
    assert docstring_param.description == None
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "int"
    assert docstring_param.is_optional == None
    assert docstring_param.default == None


# Generated at 2022-06-23 16:59:37.254496
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ':deprecated,:version'
    description = 'some deprecated function.'
    version = '1.0.0'
    a = DocstringDeprecated(args,description,version)
    assert a.args == ':deprecated,:version'
    assert a.description == 'some deprecated function.'
    assert a.version == '1.0.0'


# Generated at 2022-06-23 16:59:46.469020
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test for methods of DocstringReturns."""
    args = ["param", "arg", ":", "name", ":", "param", "type_name", "=", "default"]
    description = "Example"
    arg_name = "name"
    type_name = "param"
    is_optional = True
    default = "default"
    obj = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert obj.args == args, "args of DocstringParam is wrong"
    assert obj.description == description, "description of DocstringParam is wrong"
    assert obj.arg_name == arg_name, "arg_name of DocstringParam is wrong"
    assert obj.type_name == type_name, "type_name of DocstringParam is wrong"

# Generated at 2022-06-23 16:59:54.807638
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["return", "description"]
    description = "description"
    type_name = "int"
    is_generator = True
    return_name = "new_return"

    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(returns)
    assert(returns.args == args)
    assert(returns.description == description)
    assert(returns.type_name == type_name)
    assert(returns.is_generator == is_generator)
    assert(returns.return_name == return_name)


# Generated at 2022-06-23 16:59:56.390428
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstringReturns = DocstringReturns(['a'], ' ', 'int', True)
    print(docstringReturns.is_generator)


# Generated at 2022-06-23 17:00:00.099936
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert isinstance(DocstringParam(['',''], '', '', '', '', '',), DocstringParam)


# Generated at 2022-06-23 17:00:05.760223
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['a'], 'b', 'c', 'd', 'e', 'f')
    assert param.args == ['a']
    assert param.description == 'b'
    assert param.arg_name == 'c'
    assert param.type_name == 'd'
    assert param.is_optional == 'e'
    assert param.default == 'f'


# Generated at 2022-06-23 17:00:11.319270
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['string1', 'string2']
    description = 'description'
    test_docstringmeta = DocstringMeta(args, description)
    assert test_docstringmeta.args == args
    assert test_docstringmeta.description == description


# Generated at 2022-06-23 17:00:14.251449
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["My args"]
    description = "My description"
    version = "My version"
    d = DocstringDeprecated(args, description, version)

    assert d.args == args
    assert d.description == description
    assert d.version == version



# Generated at 2022-06-23 17:00:18.112012
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam([':parameter'], 'description', 'arg_name', 'type_name', False, None)
    assert param.args == [':parameter']
    assert param.description == 'description'
    assert param.arg_name == 'arg_name'
    assert param.type_name == 'type_name'
    assert param.is_optional == False
    assert param.default == None



# Generated at 2022-06-23 17:00:25.878009
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param"]
    description = "Description"
    version = "1.0.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == ["param"]
    assert docstring_deprecated.description == "Description"
    assert docstring_deprecated.version == "1.0.0"


# Generated at 2022-06-23 17:00:27.660308
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()



# Generated at 2022-06-23 17:00:31.948151
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False


# Generated at 2022-06-23 17:00:40.447973
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-23 17:00:52.199590
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        args=["return", "returns"],
        description="The return value",
        type_name="int",
        is_generator=False,
        return_name="foo",
    )
    assert isinstance(docstring_returns, DocstringReturns)
    assert docstring_returns.description == "The return value"
    assert docstring_returns.type_name == "int"
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == "foo"



# Generated at 2022-06-23 17:00:56.543798
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert isinstance(DocstringRaises(
        args=list(),
        description=None,
        type_name=None
    ), object)

# Generated at 2022-06-23 17:00:59.320665
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated([],None,1)
    assert doc.version == 1


# Generated at 2022-06-23 17:01:03.099405
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc_meta = DocstringRaises(args=['a', 'b', 'c'], description="Error message", type_name="Type",
    arg_name="arg", is_optional=True, default="Default")


# Generated at 2022-06-23 17:01:07.066876
# Unit test for constructor of class ParseError
def test_ParseError():
    # Setup
    expected_value = "GOT 'Test'"
    # Exercise
    actual_output = ParseError(expected_value)
    # Verify
    assert actual_output.args == (expected_value,)
    # Cleanup - none necessary


# Generated at 2022-06-23 17:01:08.677759
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("Test Error")
    assert("Test Error" in a.args[0])


# Generated at 2022-06-23 17:01:10.292225
# Unit test for constructor of class ParseError
def test_ParseError():
    s = ParseError("Test")
    assert "Test" in str(s)

# Generated at 2022-06-23 17:01:12.351455
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert isinstance(err, RuntimeError)


# Generated at 2022-06-23 17:01:14.278282
# Unit test for constructor of class ParseError
def test_ParseError():
    def initialize():
        raise ParseError("Test fail")

    try:
        initialize()
    except:
        pass


# Generated at 2022-06-23 17:01:16.400436
# Unit test for constructor of class ParseError
def test_ParseError():
    test_p_error = ParseError('a'*10)
    test_p_error.message

# Generated at 2022-06-23 17:01:27.711380
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    if test_docstring.short_description is None:
        print(
            "DocString short_description is initialized properly, the value is None."
        )
    else:
        print(
            "DocString short_description is not initialized properly, the value is not None."
        )
    if test_docstring.long_description is None:
        print(
            "DocString long_description is initialized properly, the value is None."
        )
    else:
        print(
            "DocString long_description is not initialized properly, the value is not None."
        )
    if len(test_docstring.meta) == 0:
        print("DocString meta is initialized properly, the value is 0.")

# Generated at 2022-06-23 17:01:30.054417
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("A simple exception")
    except ParseError as exc:
        assert str(exc) == "A simple exception" or "A simple exception" in str(exc)


# Generated at 2022-06-23 17:01:32.736088
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["param", "arg"], "description")
    assert meta.__dict__ == {
        'args': ["param", "arg"],
        'description': "description",
    }


# Generated at 2022-06-23 17:01:35.212335
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(
        args=['deprecated', 'param'],
        description='some description',
        version='1.0.0'
    )


# Generated at 2022-06-23 17:01:44.792501
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test for initializing funtion.

    Implementation of unit test for intializing function
    """
    # initialize an instance DocstringReturns
    doc_return = DocstringReturns([], None, None, True)
    # check whether is_generator is True
    assert doc_return.is_generator
    # check whether args is []
    assert doc_return.args == []
    # check whether type_name is None
    assert doc_return.type_name is None
    # check whether description is None
    assert doc_return.description is None

# Generated at 2022-06-23 17:01:49.917427
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    in1 = DocstringRaises(args = ["raises", "ValuerError"], description = "if something fails.")
    assert in1.args == ["raises", "ValuerError"]
    assert in1.description == "if something fails."
    assert in1.type_name == None


# Generated at 2022-06-23 17:01:54.943759
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_obj = DocstringMeta(["test_arg"], "test_description")
    assert test_obj.args == ["test_arg"]
    assert test_obj.description == "test_description"


# Generated at 2022-06-23 17:01:57.690212
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test error message")
    except ParseError as e:
        assert "Test error message" == str(e)


# Generated at 2022-06-23 17:02:02.661963
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(
        args=["param", "parameter"],
        description="description",
        type_name="type_name"
    )
    assert docstringRaises.args == ["param", "parameter"]
    assert docstringRaises.description == "description"
    assert docstringRaises.type_name == "type_name"



# Generated at 2022-06-23 17:02:05.739383
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description")
    assert DocstringMeta(["param"], "description").args == ["param"]
    assert DocstringMeta(["param"], "description").description == "description"


# Generated at 2022-06-23 17:02:08.648320
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    x = DocstringDeprecated(['deprecated'], 'description', 'version')

    assert x.version == 'version'
    assert x.description == 'description'
    assert x.args == ['deprecated']



# Generated at 2022-06-23 17:02:10.689297
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = ""
    version = ""
    dd = DocstringDeprecated(args, description, version)
    print(dd.version)



# Generated at 2022-06-23 17:02:13.590385
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    param1 = DocstringMeta([], "description")
    assert param1.args == []
    assert param1.description == "description"


# Generated at 2022-06-23 17:02:24.029232
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    # test values
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name
    

# Generated at 2022-06-23 17:02:26.926384
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["a"], "b")
    assert meta.args == ["a"]
    assert meta.description == "b"



# Generated at 2022-06-23 17:02:32.357404
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arr = ['a','b','c']
    desc = "ciao"
    type = "ciao"
    gen = True
    name = "ciao"
    x = DocstringReturns(arr,desc,type,gen)
    print(x.args)
    print(x.description)
    print(x.type_name)
    print(x.is_generator)
    print(x.return_name)


# Generated at 2022-06-23 17:02:34.606116
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass
    else:
        assert False, "constructor of class ParseError failed"


# Generated at 2022-06-23 17:02:38.775152
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return1 = DocstringReturns(['returns'], 'return the value', 'int')
    print(return1.args)
    print(return1.description)
    print(return1.type_name)
    print(return1.is_generator)



# Generated at 2022-06-23 17:02:41.660167
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    lst = str_to_list('.. deprecated')
    my_class = DocstringDeprecated(lst, 'not None', 'not None')
    assert my_class.version == 'not None'
    assert my_class.description == 'not None'
    assert my_class.args == ['..', 'deprecated']
    
# Unit tests for DocstringMeta class

# Generated at 2022-06-23 17:02:45.498086
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    parameter = DocstringRaises(
               ["raises"],
               "testing decription",
               "type_name",
    )
    assert parameter.args == ["raises"]
    assert parameter.description == "testing decription"
    assert parameter.type_name == "type_name"
test_DocstringRaises()



# Generated at 2022-06-23 17:02:50.421734
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=['param', 'arg'], 
                          arg_name='arg', 
                          description='description', 
                          type_name='str',
                          is_optional=False,
                          default='default')


# Generated at 2022-06-23 17:02:56.581425
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["test", "test2"]
    description = "Arguments for testing"
    type_name = "testing"
    test = DocstringRaises(args, description, type_name)
    assert test.args == ["test", "test2"]
    assert test.description == "Arguments for testing"
    assert test.type_name == "testing"


# Generated at 2022-06-23 17:03:03.762376
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    docstring = DocstringDeprecated(['deprecated', 'version=1.0'],
                                    'this is deprecated', '1.0')
    assert docstring.args == ['deprecated', 'version=1.0']
    assert docstring.description == 'this is deprecated'
    assert docstring.version == '1.0'



# Generated at 2022-06-23 17:03:09.506555
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Arrange
    args = ["param", "arg"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    # Act
    actual = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    # Assert
    assert actual.args == args
    assert actual.description == description
    assert actual.arg_name == arg_name
    assert actual.type_name == type_name
    assert actual.is_optional == is_optional
    assert actual.default == default


# Generated at 2022-06-23 17:03:16.176430
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg']
    arg_name = 'arg_name'
    type_name = 'str'
    is_optional = True
    default = None
    description = 'desc'
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == ['arg']
    assert dp.description == 'desc'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'str'
    assert dp.is_optional == True
    assert dp.default == None

# unit test for constructor of class DocstringReturns

# Generated at 2022-06-23 17:03:19.030287
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string.short_description is None
    assert doc_string.long_description is None


# Generated at 2022-06-23 17:03:25.785393
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg","arg2"]
    description = "some description"
    type_name = "type"
    a = DocstringRaises(args,description,type_name)
    assert args == a.args
    assert description == a.description
    assert type_name == a.type_name

if __name__ == "__main__":
    import sys
    test_name = sys.argv[1]
    globals()["test_" + test_name]()

# Generated at 2022-06-23 17:03:30.256982
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = 'The first parameter'
    type_name = 'int'
    is_generator = False
    return_name = 'a'

    assert DocstringReturns(args, description, type_name, is_generator, return_name)



# Generated at 2022-06-23 17:03:34.946887
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docRaisesVar = DocstringRaises(
        ["raises"], "ValueError", "ValueError occured")
    assert docRaisesVar.args == ["raises"]
    assert docRaisesVar.description == "ValueError"
    assert docRaisesVar.type_name == "ValueError occured"


# Generated at 2022-06-23 17:03:39.614388
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc=DocstringParam(["p"], "description", "arg_name", "type_name", True, "default")
    assert doc.args == ["p"]
    assert doc.description == "description"
    assert doc.arg_name == "arg_name"
    assert doc.type_name == "type_name"
    assert doc.is_optional == True
    assert doc.default == "default"


# Generated at 2022-06-23 17:03:46.011358
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_docstring = DocstringReturns(["parameter"], "description", "type", True, "a")
    assert return_docstring.description == "description"
    assert return_docstring.type_name == "type"
    assert return_docstring.is_generator == True
    assert return_docstring.return_name == "a"


# Generated at 2022-06-23 17:03:49.229248
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test ParseError initialization."""
    try:
        raise ParseError("foo")
    except ParseError as e:
        assert str(e) == "foo"


# Generated at 2022-06-23 17:03:53.260496
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["a", "b", "c"], "xx", "x", True, "ab")
    assert ds.type_name == "x"
    assert ds.is_generator == True
    assert ds.return_name == "ab"


# Generated at 2022-06-23 17:03:54.706605
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    return DocstringRaises(list, None, None)


# Generated at 2022-06-23 17:04:01.717758
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['args']
    description = 'Description'
    type_name = 'TypeName'
    assert (DocstringRaises(args, description, type_name).args == args)
    assert (DocstringRaises(args, description, type_name).description == description)
    assert (DocstringRaises(args, description, type_name).type_name == type_name)
    return "DocstringRaises constructor tested successfully."


# Generated at 2022-06-23 17:04:04.567861
# Unit test for constructor of class ParseError
def test_ParseError():
    test_case = ParseError('Error')
    assert test_case.args[0] == 'Error'


# Generated at 2022-06-23 17:04:06.464501
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert(DocstringParam([''], '', '', '', False, ''))


# Generated at 2022-06-23 17:04:09.228850
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        description = "blablabla"
        version = "0.0.0"
        args = ["deprecated", "since"]
        item = DocstringDeprecated(args, description, version)
    except:
        pass


# Generated at 2022-06-23 17:04:14.446965
# Unit test for constructor of class ParseError
def test_ParseError():
    obj = ParseError()
    assert(obj.__class__ == ParseError)
    assert(obj.args == ())
    assert(obj.__class__ == ParseError)
    assert(isinstance(obj, RuntimeError))

# Unit tests for class DocstringMeta

# Generated at 2022-06-23 17:04:19.752369
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():

    testdocstringmetadata = {"args": [], "description": "Test", "type_name": "TestException"}
    testobject = DocstringRaises(testdocstringmetadata["args"], testdocstringmetadata["description"], testdocstringmetadata["type_name"])

    assert testobject.args == []
    assert testobject.description == "Test"
    assert testobject.type_name == "TestException"


# Generated at 2022-06-23 17:04:26.986650
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args = 1, description = 2, arg_name = 3, type_name = 4, is_optional = 5, default = 1)
    assert dp.args == 1
    assert dp.description == 2
    assert dp.arg_name == 3
    assert dp.type_name == 4
    assert dp.is_optional == 5
    assert dp.default == 1


# Generated at 2022-06-23 17:04:30.505011
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["key", "value"]
    description = "This returns a key-value pair"
    type_name = "Dict[str, int]"
    item = DocstringRaises(args, description, type_name)
    assert item

# Generated at 2022-06-23 17:04:32.361494
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=['DocstringRaises'],description='description',type_name='type_name')

# Generated at 2022-06-23 17:04:33.710815
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
  assert DocstringMeta(['param'], 'description')


# Generated at 2022-06-23 17:04:36.042773
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    tester = DocstringMeta(['param'], 'description')
    assert tester.args == ['param']
    assert tester.description == 'description'


# Generated at 2022-06-23 17:04:38.665300
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass



# Generated at 2022-06-23 17:04:47.978100
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["arg"]
    description = "DocstringParam"
    arg_name = "arg_name"
    type_name = None
    is_optional = None
    default = None
    docstring_param_obj = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param_obj.args == ["arg"]
    assert docstring_param_obj.description == "DocstringParam"
    assert docstring_param_obj.arg_name == "arg_name"
    assert docstring_param_obj.type_name == None
    assert docstring_param_obj.is_optional == None
    assert docstring_param_obj.default == None



# Generated at 2022-06-23 17:04:52.222448
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description == None
    assert test_docstring.long_description == None
    assert test_docstring.blank_after_short_description == False
    assert test_docstring.blank_after_long_description == False



# Generated at 2022-06-23 17:04:53.795131
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringmeta = DocstringMeta(["param"], "description")
    assert docstringmeta.args == ["param"]
    assert docstringmeta.description == "description"


# Generated at 2022-06-23 17:04:58.263522
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []
    

# Generated at 2022-06-23 17:05:00.450066
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['param', 'parameter'], 'if something happens', 'ValueError',False,
        'return') == 'DocstringReturns'

# Generated at 2022-06-23 17:05:05.626197
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    "Tests DocstringRaises constructor"
    docstring_raises_obj = DocstringRaises(['raises','error'], 'A brief description of why an activity raises the specified error.', 'error')
    assert docstring_raises_obj.args == ['raises','error']
    assert docstring_raises_obj.description == 'A brief description of why an activity raises the specified error.'
    assert docstring_raises_obj.type_name == 'error'


# Generated at 2022-06-23 17:05:07.331673
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError(docstring="Hello")


# Generated at 2022-06-23 17:05:08.714421
# Unit test for constructor of class Docstring
def test_Docstring():
    assert str == type(Docstring.__init__.__doc__)


# Generated at 2022-06-23 17:05:11.604410
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DM = DocstringMeta(["1","2"], "description")
    assert(DM.args == ["1","2"])
    assert(DM.description == "description")


# Generated at 2022-06-23 17:05:15.770187
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # :param arg: description
    dsm = DocstringMeta(['param', 'arg', 'description'], 'Some Description')
    assert dsm.args[0] == 'param'
    assert dsm.args[1] == 'arg'
    assert dsm.args[2] == 'description'
    assert dsm.description == 'Some Description'


# Generated at 2022-06-23 17:05:26.464428
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(['a','b'],'d','c',True)
    assert x.args == ['a','b']
    assert x.description == 'd'
    assert x.type_name == 'c'
    assert x.is_generator == True
    assert x.return_name == None

    y = DocstringReturns(['a','b'],'d','c',False,'return name')
    assert y.args == ['a','b']
    assert y.description == 'd'
    assert y.type_name == 'c'
    assert y.is_generator == False
    assert y.return_name == 'return name'

if __name__ == '__main__':
    test_DocstringReturns()