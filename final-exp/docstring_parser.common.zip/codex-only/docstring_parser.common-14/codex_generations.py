

# Generated at 2022-06-23 16:55:32.582016
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as error:
        assert error.args[0] == "Test"


# Generated at 2022-06-23 16:55:34.697691
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of DocstringReturns."""
    DocstringReturns([], None, None, False, None)

# Generated at 2022-06-23 16:55:40.741062
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(["name"], None, "Type")
    if docstringRaises.args == ["name"] and docstringRaises.type_name == "Type" and docstringRaises.description == None: 
        print("The constructor for DocstringRaises works perfectly.")
    else:
        print("The constructor for DocstringRaises has some bugs.")
        
test_DocstringRaises()


# Generated at 2022-06-23 16:55:47.274940
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "describe", "name", "type", False, "default")
    assert param.args==["param"]
    assert param.description=="describe"
    assert param.arg_name=="name"
    assert param.type_name=="type"
    assert param.is_optional==False
    assert param.default=="default"

# Generated at 2022-06-23 16:55:49.117075
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["a"], "b")
    assert a.args == ["a"]


# Generated at 2022-06-23 16:55:50.993536
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["aa", "bb"], "something", "int")


# Generated at 2022-06-23 16:55:59.538456
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print('Testing DocstringRaises...')
    docStringRaises = DocstringRaises(["_"], "this is a test", "ValueError")
    assert docStringRaises.args == ["_"], "args = {}".format(docStringRaises.args)
    assert docStringRaises.description == "this is a test", "description = {}".format(docStringRaises.description)
    assert docStringRaises.type_name == "ValueError", "type_name = {}".format(docStringRaises.type_name)
    


# Generated at 2022-06-23 16:56:02.765274
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(args=["param"],
                           description="Parsed parameters",
                           arg_name="args",
                           type_name=None,
                           is_optional=None,
                           default=None)
    assert param.args == ["param"]
    assert param.description == "Parsed parameters"
    assert param.arg_name == "args"
    assert param.type_name == None
    assert param.is_optional == None
    assert param.default == None

# Generated at 2022-06-23 16:56:07.936324
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	test_item = DocstringParam(["param", "test_arg", ":", "test_arg", ":", "test_type_name"], "test_description", "test_arg", "test_type_name", None, None)

# Generated at 2022-06-23 16:56:14.376808
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d_returns = DocstringReturns(['yield', 'yields'], 'a generator is returned', 'str', True, 'a string')
    assert d_returns.args == ['yield', 'yields']
    assert d_returns.description == 'a generator is returned'
    assert d_returns.type_name == 'str'
    assert d_returns.is_generator
    assert d_returns.return_name == 'a string'


# Generated at 2022-06-23 16:56:16.646887
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Unit test for ParseError")
    except ParseError:
        pass


# Generated at 2022-06-23 16:56:18.939932
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring
    assert docstring.long_description == None
    assert docstring.meta == []
    assert docstring.params == []


# Generated at 2022-06-23 16:56:21.161938
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(["asd"], "asd")
    assert docstring is not None and isinstance(docstring, DocstringMeta)

# Generated at 2022-06-23 16:56:26.127059
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-23 16:56:33.854452
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    try:
        a = DocstringDeprecated(":deprecated:","0.1.2","Use the other")
        assert a.args == ":deprecated:"
        assert a.description == "0.1.2"
        assert a.version == "Use the other"
    except Exception:
        print("Error in DocstringDeprecated")
        assert False


# Generated at 2022-06-23 16:56:37.987597
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated(["param"], "parameter", "0.0.1")
    assert docstringDeprecated.args == ["param"]
    assert docstringDeprecated.description == "parameter"
    assert docstringDeprecated.version == "0.0.1"


# Generated at 2022-06-23 16:56:45.258896
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param"]
    description = "abcdefg"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = "is_optional"
    default = "False"
    a = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    output = DocstringMeta(args, description)
    assert a.args == output.args
    assert a.description == output.description


# Generated at 2022-06-23 16:56:57.399516
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert (DocstringParam([' :param x: '], 'x parameter', 'x', None, False, 'None')
        == DocstringParam([' :param x: '], 'x parameter', 'x', None, False, 'None'))
    assert (DocstringParam([' :param x: '], 'x parameter', 'x', None, False, 'None')
        == 'Invalid DocstringParam')
    assert (DocstringParam([' :param x: '], 'x parameter', 'x', None, False, 'None')
        != DocstringParam([' :param y: '], 'x parameter', 'x', None, False, 'None'))

# Generated at 2022-06-23 16:57:00.622484
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "A parameter"
    arg_name = "parameter"
    type_name = "int"
    is_optional = True
    default = "0"
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    return dp.arg_name


# Generated at 2022-06-23 16:57:05.533468
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description==None
    assert doc.long_description==None
    assert doc.blank_after_short_description==False
    assert doc.blank_after_long_description==False
    assert doc.meta==[]


# Generated at 2022-06-23 16:57:09.266308
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated([], "", "")
    assert docstringDeprecated.version == ""
    assert docstringDeprecated.args == []
    assert docstringDeprecated.description == ""

# Generated at 2022-06-23 16:57:15.698342
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    print("This is test_DocstringParam")
    test_DocstringParam = DocstringParam(
        ['param'],
        "descripiton",
        "arg_name",
        "type_name",
        False,
        "default",
    )
    assert test_DocstringParam.args == ['param']
    assert test_DocstringParam.description == "descripiton"
    assert test_DocstringParam.arg_name == "arg_name"
    assert test_DocstringParam.type_name == "type_name"
    assert test_DocstringParam.is_optional == False
    assert test_DocstringParam.default == "default"


# Generated at 2022-06-23 16:57:20.078210
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args= ['deprecated']
    description='This method is deprecated'
    version='1.1'
    g=DocstringDeprecated(args,description,version)
    assert g.args==['deprecated']
    assert g.description=='This method is deprecated'
    assert g.version=='1.1'


# Generated at 2022-06-23 16:57:23.523044
# Unit test for constructor of class ParseError
def test_ParseError():
    print("Testing constructor of class ParseError")
    try:
        raise ParseError("Parsing failed")
    except ParseError as pe:
        print(type(pe))
        print(pe.args)
        print(pe)


# Generated at 2022-06-23 16:57:26.289504
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated([], "", "")
    assert (d.description == None)
    assert (d.type_name == None)


# Generated at 2022-06-23 16:57:30.262504
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta([], "description")
    assert docstring_meta.args == []
    assert docstring_meta.description == "description"


# Generated at 2022-06-23 16:57:35.074010
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:57:39.144369
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['raises', 'ValueError'], 'if something happens', 'ValueError')
    assert d.args[0] == 'raises'
    assert d.args[1] == 'ValueError'
    assert d.type_name == 'ValueError'
    assert d.description == 'if something happens'


# Generated at 2022-06-23 16:57:40.550563
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert type(DocstringMeta) == type



# Generated at 2022-06-23 16:57:45.807028
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test constructor of class Docstring."""
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []



# Generated at 2022-06-23 16:57:47.294579
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """test_DocstringReturns"""
    pass

# Generated at 2022-06-23 16:57:50.655733
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description").args == ["param"]
    assert DocstringMeta(["param"], "description").description == "description"


# Generated at 2022-06-23 16:57:53.691078
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False


# Generated at 2022-06-23 16:57:56.823018
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(["arg"], "description", "argname", "int", True, "None")
    return True


# Generated at 2022-06-23 16:58:02.217456
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args=['deprecated'], description=None, version=None)
    assert d.args == ['deprecated']
    assert d.is_generator == None
    assert d.description == None
    assert d.type_name == None



# Generated at 2022-06-23 16:58:09.752999
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()
    assert doc_string.short_description == None
    assert doc_string.long_description == None
    assert doc_string.blank_after_short_description == False
    assert doc_string.blank_after_long_description == False
    assert doc_string.meta == []
    assert doc_string.params == []
    assert doc_string.raises == []
    assert doc_string.returns == None
    assert doc_string.deprecation == None


# Generated at 2022-06-23 16:58:17.329388
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args=[":since", "0.5"], description="Use x instead", version="0.5")
    d1 = DocstringDeprecated(args=[":since", "0.5"], description=None, version="0.5")
    d2 = DocstringDeprecated(args=[":since", "0.5"], description=None, version=None)
    d3 = DocstringDeprecated(args=[":since", "0.5"], description="Use x instead", version=None)
    assert d.version == "0.5"
    assert d.args == [":since", "0.5"]
    assert d.description == "Use x instead"

    assert d1.version == "0.5"
    assert d1.args == [":since", "0.5"]
    assert d1.description == None

   

# Generated at 2022-06-23 16:58:23.639600
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring()
    assert docstr.short_description is None
    assert docstr.long_description is None
    assert docstr.blank_after_short_description is False
    assert docstr.blank_after_long_description is False
    assert docstr.meta == []
# End of unit test


# Generated at 2022-06-23 16:58:25.369249
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['a'], 'b', 'c')


# Generated at 2022-06-23 16:58:26.917707
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("test")


# Generated at 2022-06-23 16:58:29.584856
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []

# Generated at 2022-06-23 16:58:35.520322
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docparam1 = DocstringParam([], None, "arg_name1", "type_name1", None, None)
    docparam2 = DocstringParam([], None, "arg_name2", "type_name2", None, None)
    docparam3 = DocstringParam([], None, "arg_name3", "type_name3", None, None)
    docparam4 = DocstringParam([], None, "arg_name4", "type_name4", None, None)
    docparam5 = DocstringParam([], None, "arg_name5", "type_name5", None, None)
    docparam6 = DocstringParam([], None, "arg_name6", "type_name6", None, None)

# Generated at 2022-06-23 16:58:41.454544
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    # assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    # assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:58:47.791423
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["asd"], "description", "arg_name", "type_name", True, "default")
    assert(dp.args == ["asd"])
    assert(dp.description == "description")
    assert(dp.arg_name == "arg_name")
    assert(dp.type_name == "type_name")
    assert(dp.is_optional == True)
    assert(dp.default == "default")


# Generated at 2022-06-23 16:58:54.697363
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    function = DocstringReturns(["returns"], "description", "str")
    assert function.args == ["returns"]
    assert function.description == "description"
    assert function.type_name == "str"
    assert function.args == ["returns"]


# Generated at 2022-06-23 16:58:56.764535
# Unit test for constructor of class ParseError
def test_ParseError():
    sut = ParseError
    assert sut


# Generated at 2022-06-23 16:59:00.875707
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None 
    assert doc.long_description == None 
    assert doc.blank_after_short_description == False 
    assert doc.blank_after_long_description == False 
    assert doc.meta == []


# Generated at 2022-06-23 16:59:04.583141
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('')
    except ParseError as e:
        print(e)


# Generated at 2022-06-23 16:59:10.805714
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args=[':raises ValueError: description',':raises Error: description']
    description = 'Raises a value error'
    type_name = 'ValueError'
    assert DocstringRaises(args,description,type_name).args ==args
    assert DocstringRaises(args,description,type_name).description ==description
    assert DocstringRaises(args,description,type_name).type_name ==type_name

# Generated at 2022-06-23 16:59:15.566853
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test the constructor correctly set the value
    err = ParseError("test")
    assert (err.args[0] == "test")
    return


# Generated at 2022-06-23 16:59:20.958914
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = None
    arg_name = 'q'
    type_name = None
    is_optional = None
    default = None
    assert DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-23 16:59:26.703404
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises(['a','b','c'],"description", "TypeName")
    assert raises.args == ['a','b','c']
    assert raises.description == "description"
    assert raises.type_name == "TypeName"

# Generated at 2022-06-23 16:59:31.860718
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = [1,2,3]
    description = "abc"
    dm = DocstringMeta(args, description)
    assert dm.args == args
    assert dm.description == description


# Generated at 2022-06-23 16:59:40.526480
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None



# Generated at 2022-06-23 16:59:47.514795
# Unit test for constructor of class Docstring
def test_Docstring():

      # Test 1: Docstring with all elements
      # Description
      #
      # Expected: Docstring object with all elements
      test = Docstring()
      test.short_description = "Test 1 Desc"
      test.long_description = "Test 1 long desc"
      test.blank_after_short_description = True
      test.blank_after_long_description = False

      # Expected: DocstringParam object
      testParam = DocstringParam([], "Test Desc", "arg", "int", False, 0)
      test.meta.append(testParam)

      # Expected: DocstringRaises object
      testRaises = DocstringRaises([], "Test raises", "ValueError")
      test.meta.append(testRaises)

      # Expected: DocstringReturns object

# Generated at 2022-06-23 16:59:50.850837
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises", "raise", "exception", "except"], "Error if filter is not met", "ValueError")



# Generated at 2022-06-23 16:59:55.097053
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['test_arg']
    description = 'test_description'
    type_name = 'test_type_name'
    is_generator = False
    return_name = 'test_return_name'
    test_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    return test_DocstringReturns


# Generated at 2022-06-23 17:00:04.570465
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(
        args=["param"],
        description="description",
        arg_name="arg_name",
        type_name="int",
        is_optional=False,
        default="5",
    )
    assert obj.args == ["param"]
    assert obj.description == "description"
    assert obj.arg_name == "arg_name"
    assert obj.type_name == "int"
    assert obj.is_optional == False
    assert obj.default == "5"



# Generated at 2022-06-23 17:00:18.152645
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # No type
    param = DocstringParam(args=['param', 'arg', 'a'], description='description', arg_name='a', type_name=None, is_optional=False, default=None)
    assert not param.is_optional
    assert param.default == None
    assert param.arg_name == 'a'
    assert param.type_name == None
    assert param.args == ['param', 'arg', 'a']
    assert param.description == 'description'

    # Type
    param = DocstringParam(args=['param', 'arg', 'a'], description='description', arg_name='a', type_name='Dict[str, list]', is_optional=False, default=None)
    assert not param.is_optional
    assert param.arg_name == 'a'
    assert param.type_

# Generated at 2022-06-23 17:00:25.187196
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [":deprecated:", "version:0.0"]
    description = "description"
    version = "0.0"
    result = DocstringDeprecated(args, description, version)
    assert result.args == args
    assert result.description == description
    assert result.version == version


# Generated at 2022-06-23 17:00:26.865817
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    D = DocstringMeta(args=['param'], description='test description')


# Generated at 2022-06-23 17:00:30.957242
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    description = "Test description"
    args = ["Test args"]

    test_DocstringMeta = DocstringMeta(args, description)
    assert test_DocstringMeta.args == args
    assert test_DocstringMeta.description == description


# Generated at 2022-06-23 17:00:33.373637
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError()



# Generated at 2022-06-23 17:00:35.250150
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('Runtime error')
    print(err)

# Generated at 2022-06-23 17:00:44.237156
# Unit test for constructor of class ParseError
def test_ParseError():
    
    # Test with default constructor
    try:
        raise ParseError()
    except ParseError as pe:
        assert True
        assert len(pe.args) == 0

    # Test with one arg constructor
    try:
        raise ParseError('test_str')
    except ParseError as pe:
        assert True
        assert pe.args[0] == 'test_str'

    # Test with with two arg constructor
    try:
        raise ParseError('test_str1', 'test_str2')
    except ParseError as pe:
        assert True
        assert pe.args[0] == 'test_str1'
        assert pe.args[1] == 'test_str2'

    # Test with three arg constructor

# Generated at 2022-06-23 17:00:55.306778
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":parameter", "arg", "arg_name:", "argument", "description"]
    assert DocstringParam(args, "description", "arg_name", None, None, None).arg_name == "arg_name"
    assert DocstringParam(args, "description", "arg_name", None, None, None).description == "description"
    assert DocstringParam(args, "description", "arg_name", None, None, None).type_name == None
    assert DocstringParam(args, "description", "arg_name", None, None, None).is_optional == None
    assert DocstringParam(args, "description", "arg_name", None, None, None).default == None


# Generated at 2022-06-23 17:01:04.339461
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns', 'Returns', 'yields']
    description = 'description'
    type_name = 'type name'
    is_generator = True
    return_name = 'return name'
    a = DocstringReturns(
        args=args,
        description=description,
        type_name=type_name,
        is_generator=is_generator,
        return_name=return_name,
    )
    assert a.type_name == type_name
    assert a.is_generator == is_generator
    assert a.return_name == return_name
    assert a.args == args

# Generated at 2022-06-23 17:01:08.717949
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['x', 'y']
    description = 'test_DocstringParam'
    arg_name = 'x'
    type_name = 'int'
    is_optional = True
    default = '10'
    DocstringParam(args, description, arg_name, type_name,\
                   is_optional, default)


# Generated at 2022-06-23 17:01:13.290350
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
# Tesing that constructor works

    d = DocstringMeta(['param'], 'docstring')
    assert d.args == ['param']
    assert d.description == 'docstring'
    assert d.args != 'param'
    assert d.description != 'Docstring'
# End of unit test


# Generated at 2022-06-23 17:01:18.265370
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
 d = DocstringReturns(["returns"], "None.", "None.")
 assert d.description == "None."
 assert d.is_generator == False
 assert d.return_name == None
 assert d.type_name == "None."


# Generated at 2022-06-23 17:01:23.690714
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['raises'], 'description', 'ValueError')
    assert test.args == ['raises'], 'Returned wrong arguments'
    assert test.type_name == 'ValueError', 'Returned wrong type name'
    assert test.description == 'description', 'Returned wrong description'


# Generated at 2022-06-23 17:01:26.968453
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    my_DocstringDeprecated = DocstringDeprecated([], "", 1)
    assert my_DocstringDeprecated.args == []
    assert my_DocstringDeprecated.description == ""
    assert my_DocstringDeprecated.version == None


# Generated at 2022-06-23 17:01:29.179259
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta = DocstringMeta(["param", "parameter"], "description")
    assert DocstringMeta.args == ["param", "parameter"]
    assert DocstringMeta.description == "description"



# Generated at 2022-06-23 17:01:38.868193
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ds = {
        "description": "description of the function",
        "is_optional": "none",
        "arg_name": "name of the argument",
        "type_name": "type of the argument",
        "default": 3
    }
    for index, value in enumerate(ds):
        if ds[value] == "none":
            ds[value] = None
        ds_meta = DocstringParam(["param"], ds["description"], ds["arg_name"], ds["type_name"], ds["is_optional"], ds["default"])
        assert ds_meta.description == ds["description"]
        assert ds_meta.arg_name == ds["arg_name"]
        assert ds_meta.type_name == ds["type_name"]
        assert ds_

# Generated at 2022-06-23 17:01:41.438345
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['deprecated'], 'Use abc instead.', '1.0')


# Generated at 2022-06-23 17:01:44.595249
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg','description']
    doc = DocstringMeta(args, 'description')
    assert doc.args == args
    assert doc.description == 'description'


# Generated at 2022-06-23 17:01:50.898241
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(args=['raises'],description='description',type_name=None)
    # Test the constructed class DocstringRaises
    assert docstring.args == ['raises'], "DocstringRaises constructor failed"
    assert docstring.description == 'description',"DocstringRaises constructor failed"
    assert docstring.type_name == None,"DocstringRaises constructor failed"


# Generated at 2022-06-23 17:01:54.498493
# Unit test for constructor of class ParseError
def test_ParseError():
    import pytest
    with pytest.raises(ParseError):
        raise ParseError('error')


# Generated at 2022-06-23 17:01:55.660356
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('1')


# Generated at 2022-06-23 17:01:57.010672
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring is not None


# Generated at 2022-06-23 17:02:00.639967
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test for DocstringMeta"""
    docmeta = DocstringMeta(['param', 'parameter'], 'description')
    assert docmeta.args == ['param', 'parameter']
    assert docmeta.description == 'description'


# Generated at 2022-06-23 17:02:03.025822
# Unit test for constructor of class ParseError
def test_ParseError(): 
    test_pe=ParseError('x')
    assert isinstance(test_pe,RuntimeError)
    assert test_pe.args==('x',)


# Generated at 2022-06-23 17:02:11.748631
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    from inspect import Signature, Parameter
    from .parse import DocstringRaises
    sig = Signature([Parameter('name',Parameter.KEYWORD_ONLY)])
    # Just to check that it works
    foo = DocstringRaises([],None)
    print(foo.args)
    print(foo.description)
    print(foo.args)
    print(foo.description)
    print('This is the second test.')
    # Just to check that it works
    foo = DocstringRaises([],None)
    print(foo.args)
    print(foo.description)
    print(foo.args)
    print(foo.description)
    print('This is the third test.')
    # Just to check that it works
    foo = DocstringRaises([],None)
    print(foo.args)

# Generated at 2022-06-23 17:02:19.019966
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None  # type: ignore
    assert doc.long_description == None  # type: ignore
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    with pytest.raises(TypeError):
        Docstring(1)  # type: ignore



# Generated at 2022-06-23 17:02:21.965708
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstr = DocstringReturns(['hello'], 'world', 'theory')
    assert docstr.description == 'world'
    assert docstr.type_name == 'theory'
    assert docstr.is_generator == False
    assert docstr.return_name is None


# Generated at 2022-06-23 17:02:26.580048
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert(DocstringParam("arg", "description", "arg", "type", True, "default") == DocstringParam("arg", "description", "arg", "type", True, "default"))


# Generated at 2022-06-23 17:02:29.066447
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    m = DocstringMeta(args=[], description="test")
    assert m.args == []
    assert m.description == "test"


# Generated at 2022-06-23 17:02:32.395884
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["x"], "y", "j")
    try:
        assert a.args == ["x"]
        assert a.description == "y"
        assert a.type_name == "j"
    except:
        print("test failed")


# Generated at 2022-06-23 17:02:35.248094
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns"""
    assert DocstringReturns([], None, None)

# Generated at 2022-06-23 17:02:39.376757
# Unit test for constructor of class Docstring
def test_Docstring():
  ds = Docstring()
  assert ds.short_description == None
  assert ds.long_description == None
  assert ds.blank_after_short_description == False
  assert ds.blank_after_long_description == False
  assert ds.params == []
  assert ds.raises == []
  assert ds.returns == None
  assert ds.deprecation == None


# Generated at 2022-06-23 17:02:40.542509
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError("test") 


# Generated at 2022-06-23 17:02:44.294369
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "This is deprecated.", "2.1")
    assert isinstance(d, DocstringDeprecated)
    assert d.args == ["deprecated"]
    assert d.description == "This is deprecated."
    assert d.version == "2.1"

# Generated at 2022-06-23 17:02:56.770119
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    #test 1
    p = DocstringParam(["param"], "words1", 'arg', 'type', False, 'default')
    assert p.arg_name == 'arg'
    assert p.type_name == 'type'
    assert p.is_optional == False
    assert p.default == 'default'
    #test 2
    p2 = DocstringParam(["param"], "words2", 'arg2', 'type2', False, None)
    assert p2.arg_name == 'arg2'
    assert p2.type_name == 'type2'
    assert p2.is_optional == False
    assert p2.default == None
    #test 3
    p3 = DocstringParam(["param"], "words3", 'arg3', 'type3', True, 'default3')
    assert p3.arg_name

# Generated at 2022-06-23 17:03:06.627058
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        test = DocstringReturns([], None, None, None)
    except TypeError:
        print("TypeError: __init__() missing 1 required positional argument 'is_generator'")
    try:
        test2 = DocstringReturns([], None, None, None, None)
    except TypeError:
        print("TypeError: __init__() missing 1 required positional argument 'is_generator'")
    test3 = DocstringReturns([], None, None, True)
    test4 = DocstringReturns([], None, None, True, None)


# Generated at 2022-06-23 17:03:08.161972
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("test")
    print("test_ParseError: ", err)
    return None


# Generated at 2022-06-23 17:03:12.451838
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(args=[":param"], description="", arg_name="arg", type_name="type", is_optional="is_optional", default="default")
    param.args == [":param"]
    param.description == ""
    param.arg_name == "arg"
    param.type_name == "type"
    param.is_optional == "is_optional"
    param.default == "default"


# Generated at 2022-06-23 17:03:20.674670
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    ds = DocstringParam(
        args = ['param'], 
        description = 'Get a file-like object for the given field_name'
            ' storing its content into destination.',
        arg_name = 'field_name', 
        type_name = 'str', 
        is_optional = True, 
        default = 'None'
    )
    assert ds.args == ['param']
    assert ds.arg_name == 'field_name'
    assert ds.type_name == 'str'
    assert ds.is_optional == True
    assert ds.default == 'None'


# Generated at 2022-06-23 17:03:22.504013
# Unit test for constructor of class ParseError
def test_ParseError():
    exception = ParseError()
    assert exception.args == tuple()


# Generated at 2022-06-23 17:03:24.095528
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=[""], description=str, version=str)

# Generated at 2022-06-23 17:03:25.989549
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('hello')
    except ParseError as error:
        assert str(error) == 'hello'


# Generated at 2022-06-23 17:03:28.876871
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(['param'], 'description')
    assert isinstance(doc_meta, DocstringMeta)
    assert doc_meta.args == ['param']
    assert doc_meta.description == 'description'


# Generated at 2022-06-23 17:03:33.519042
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    r = DocstringRaises('', '', '')
    if r:
        print("DocstringRaises is set")
    else:
        print("DocstringRaises is not set")


# Generated at 2022-06-23 17:03:36.701536
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Constructor of class DocstringMeta."""
    args = ["arg", "description"]
    description = "description"
    assert DocstringMeta(args, description).args == args
    assert DocstringMeta(args, description).description == description


# Generated at 2022-06-23 17:03:48.177513
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """
    Tests the constructor of DocstringParam
    :return: None

    """
    doc_string = DocstringParam(["param"], "test_description", "arg_name", "type_name", True, "default")
    assert doc_string.description == "test_description", "Description is incorrect"
    assert doc_string.args == ["param"], "Args is incorrect"
    assert doc_string.arg_name == "arg_name", "Arg name is incorrect"
    assert doc_string.type_name == "type_name", "Type name is incorrect"
    assert doc_string.is_optional == True, "is_optional is incorrect"
    assert doc_string.default == "default", "default is incorrect"



# Generated at 2022-06-23 17:03:53.388036
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns_object = DocstringReturns(["return"], "description", "int", False)
    assert docstring_returns_object.description == "description"
    assert docstring_returns_object.args == ["return"]
    assert docstring_returns_object.type_name == "int"
    assert docstring_returns_object.is_generator == False

# Generated at 2022-06-23 17:03:56.731551
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    m = DocstringMeta(['a'], 'b')
    assert m.args == ['a']
    assert m.description == 'b'


# Generated at 2022-06-23 17:03:58.905966
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert err.__class__ == ParseError

# Generated at 2022-06-23 17:04:08.641949
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Empty DocstringMeta constructor
    check_object = DocstringMeta([],None)
    assert check_object.description == None
    assert check_object.args == []
    # DocstringMeta constructor with arguments
    check_object = DocstringMeta(["arg1","arg2"],None)
    assert check_object.description == None
    assert check_object.args == ["arg1", "arg2"]
    check_object = DocstringMeta([], "descripton")
    assert check_object.description == "descripton"
    assert check_object.args == []
    check_object = DocstringMeta(["arg1"], "descripton")
    assert check_object.description == "descripton"
    assert check_object.args == ["arg1"]


# Generated at 2022-06-23 17:04:09.819798
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    r = DocstringRaises(args=['a'], description='c' , type_name=None)


# Generated at 2022-06-23 17:04:14.295609
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None 
    assert d.long_description is None 
    assert d.blank_after_short_description is False 
    assert d.blank_after_long_description is False 
    assert d.meta == [] 
    assert d.params == [] 
    assert d.raises == [] 
    assert d.returns is None 
    assert d.deprecation is None 


# Generated at 2022-06-23 17:04:15.123261
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError()
    assert str(pe) == 'None'

# Generated at 2022-06-23 17:04:17.779165
# Unit test for constructor of class ParseError
def test_ParseError():
    from unittest import TestCase
    try:
        raise ParseError
    except ParseError as parseError:
        assert parseError is not None


# Generated at 2022-06-23 17:04:21.851259
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    description = 'description'

    doc_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-23 17:04:23.456539
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, 'None', False)



# Generated at 2022-06-23 17:04:34.028748
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Create a new DocstringParam object
    DocstringParamObject = DocstringParam(["param", "arg", "parameter"], "description", "arg_name", "type_name", "is_optional", "default")

    # Assert the description is "description"
    assert DocstringParamObject.description == "description"

    # Assert the arg_name is "arg_name"
    assert DocstringParamObject.arg_name == "arg_name"

    # Assert the type_name is "type_name"
    assert DocstringParamObject.type_name == "type_name"

    # Assert the is_optional is "is_optional"
    assert DocstringParamObject.is_optional == "is_optional"

    # Assert the default is "default"
    assert DocstringParamObject.default == "default"

# Unit

# Generated at 2022-06-23 17:04:36.697870
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(
        ["param"], "this is description", "arg_name", "type_name", True, "1"
    )
    print(a)



# Generated at 2022-06-23 17:04:40.094010
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(['args'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
        print("Constructor of DocstringParam class works correctly")
    except:
        print("Constructor of DocstringParam class does not work correctly")

# Unit Test for constructor of class DocstringReturns

# Generated at 2022-06-23 17:04:44.013054
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        assert True
    except Exception:
        assert False

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 17:04:46.440251
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta('args', 'description')
    assert docstring_meta.args == 'args'
    assert docstring_meta.description == 'description'


# Generated at 2022-06-23 17:04:48.060854
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError("Test")


# Generated at 2022-06-23 17:04:49.083545
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    print(e)


# Generated at 2022-06-23 17:04:51.362901
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "description")
    DocstringMeta(["raises"], "description")
    DocstringMeta(["returns"], "description")
    DocstringMeta(["yields"], "description")
    DocstringMeta(["deprecated"], "description")


# Generated at 2022-06-23 17:05:00.121223
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns is None
    assert ds.deprecation is None
    #assert ds.meta == []  # This doesn't work in mypy 0.710
    
    

# Generated at 2022-06-23 17:05:04.086163
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError", "if", "something", "happens"]
    args_two = ["raises", "ValueError", "if", "something", "happens", "asdfg"]
    item = DocstringRaises(args, None, None)
    assert item.args == args
    assert item.type_name == None

# Generated at 2022-06-23 17:05:07.278451
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["a","b"], "asdf")
    assert d.args == ["a","b"]
    assert d.description == "asdf"


# Generated at 2022-06-23 17:05:16.434273
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test = DocstringMeta( [1, 2, 3], "string")
    assert(test.args == [1, 2, 3])
    assert(test.description == "string")
    # test constructor of subclass DocstringParam
    test2 = DocstringParam( [1, 2, 3], "string", "name", "type", False, None)
    assert(test2.args == [1, 2, 3])
    assert(test2.description == "string")
    assert(test2.arg_name == "name")
    assert(test2.type_name == "type")
    assert(test2.is_optional == False)
    assert(test2.default == None)
    # test constructor of subclass DocstringReturns
    test3 = DocstringReturns( [1, 2, 3], "string", "type", False)

# Generated at 2022-06-23 17:05:18.813170
# Unit test for constructor of class Docstring
def test_Docstring():
    my_Docstring = Docstring()
    return my_Docstring


# Generated at 2022-06-23 17:05:19.558259
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["return", "returns"], "Hello", "None")


# Generated at 2022-06-23 17:05:23.868336
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d_m = DocstringMeta(["l1", "l2"], "this is a description")
    assert d_m.args == ["l1", "l2"]
    assert d_m.description == "this is a description"


# Generated at 2022-06-23 17:05:27.147400
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["param"], "description", "version")
    assert d.args == ["param"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-23 17:05:30.632108
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["Good"], "Test", "1.0")
    assert a.description == "Test"
    assert a.description == "Test"