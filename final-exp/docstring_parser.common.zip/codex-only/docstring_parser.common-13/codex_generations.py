

# Generated at 2022-06-23 16:55:34.664576
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of class DocstringParam."""
    c=DocstringParam([], "", "", "dict", True, "")
    assert c.arg_name==""
    assert c.description==""
    assert c.args==[]
    assert c.is_optional==True
    assert c.type_name=="dict"
    assert c.default==""


# Generated at 2022-06-23 16:55:46.550718
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test a good example."""
    docstring = Docstring()
    docstring.short_description = "short description"
    docstring.long_description = "long description"
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True
    docstring.params = [DocstringParam, "args", "description"]
    docstring.raises = [DocstringRaises, "args", "description"]
    docstring.returns = [DocstringReturns, "args", "description"]
    docstring.deprecation = [DocstringDeprecated, "args", "description"]
    p = docstring.params
    r = docstring.raises
    ret = docstring.returns
    d = docstring.deprecation
    s = docstring.short_description
    long = doc

# Generated at 2022-06-23 16:55:49.624682
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["a"], "b", "c")

    assert docstring.args == ["a"]
    assert docstring.description == "b"
    assert docstring.version == "c"

# Generated at 2022-06-23 16:55:53.387760
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['param', 'description']
    dep = DocstringDeprecated(args, 'description', version='version')
    assert dep
# End of unit test


# Generated at 2022-06-23 16:55:59.972131
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args: T.List[str] = []
    description: T.Optional[str] = None
    type_name: T.Optional[str] = None
    is_generator: bool = False
    return_name: T.Optional[str] = None
    a = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert a.is_generator == False


# Generated at 2022-06-23 16:56:02.396047
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(["param"], "a description", "arg_name", "type_name", "is_optional", "default")


# Generated at 2022-06-23 16:56:09.556496
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    item = DocstringReturns(args=[], description=None, type_name="TypeName", is_generator=True, return_name=None)
    assert isinstance(item, DocstringMeta)
    assert isinstance(item, DocstringReturns)
    assert item.type_name == "TypeName"
    assert item.is_generator == True
    assert item.return_name == None


# Generated at 2022-06-23 16:56:15.270484
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False


# Generated at 2022-06-23 16:56:16.195146
# Unit test for constructor of class ParseError
def test_ParseError():
    perror = ParseError()


# Generated at 2022-06-23 16:56:25.661884
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	args = ["returns", ":", "int", "return", "value", "of", "function"]
	description = "Returns int value of function"
	type_name = "int"
	is_generator = False
	return_name = "value"
	assert args == DocstringReturns(args, description, type_name, is_generator, return_name).args
	assert description == DocstringReturns(args, description, type_name, is_generator, return_name).description
	assert type_name == DocstringReturns(args, description, type_name, is_generator, return_name).type_name
	assert is_generator == DocstringReturns(args, description, type_name, is_generator, return_name).is_generator

# Generated at 2022-06-23 16:56:33.805970
# Unit test for constructor of class Docstring
def test_Docstring():
    # Check the length of docstring
    newDocstring = Docstring()
    assert len(newDocstring.params) == 0
    assert len(newDocstring.raises) == 0
    assert len(newDocstring.returns) == 0
    assert len(newDocstring.deprecation) == 0

if __name__ == "__main__":
    # Unit test for class Docstring
    test_Docstring()

# Generated at 2022-06-23 16:56:36.981074
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = "DocstringMeta"
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-23 16:56:44.173455
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    def docstringRaises_test_1():
        DocstringRaises(["raises"], "description", "type")
    DocstringRaises(["raises"], "description", "type")
    DocstringRaises(["raises"], "description", "type")
    DocstringRaises(["raises"], "description", "type")
    DocstringRaises(["raises"], "description", "type")


# Generated at 2022-06-23 16:56:47.239334
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(['arg', 'description'], 'class DocstringMeta is defined')
    assert doc.args != None
    assert doc.description != None


# Generated at 2022-06-23 16:56:50.852576
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(args=['param'], description="The number to square.",
                          arg_name='x', type_name='int',
                          is_optional=False, default=None)


# Generated at 2022-06-23 16:56:52.586648
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert type(DocstringParam(
        [''], '', '', None, None, None)
    ) == DocstringParam

# Generated at 2022-06-23 16:56:54.659272
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(['param'], 'param desc', '1.0.0')


# Generated at 2022-06-23 16:57:00.254911
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()

    def expect(attr: str) -> bool:
        if hasattr(ds, attr):
            return getattr(ds, attr) is not None
        return True

    assert expect("short_description")
    assert expect("long_description")
    assert expect("blank_after_short_description")
    assert expect("blank_after_long_description")
    assert expect("meta")

# Generated at 2022-06-23 16:57:05.270222
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-23 16:57:12.188922
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(['param'], 'some description', 'arg', 'type', True, 'default')
    assert d.args[0] == 'param'
    assert d.description == 'some description'
    assert d.arg_name == 'arg'
    assert d.type_name == 'type'
    assert d.is_optional == True
    assert d.default == 'default'



# Generated at 2022-06-23 16:57:18.191027
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises(): 
    args = ["hola", "ieo", "hola", "ieo"]
    description = "HOLA"
    type_name = "hola"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.type_name == "hola"
    assert docstringRaises.description == "HOLA"


# Generated at 2022-06-23 16:57:21.585197
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    t = DocstringDeprecated(
        [],
        'This is deprecated',
        '2020.01.01',
    )
    assert t.args == []
    assert t.description == 'This is deprecated'
    assert t.version == '2020.01.01'


# Generated at 2022-06-23 16:57:25.483091
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    '''test for DocstringRaises constructor'''
    a = DocstringRaises(['arg1'], 'some description', 'some_type')
    assert a.args == ['arg1']
    assert a.description == 'some description'
    assert a.type_name == 'some_type'

# Generated at 2022-06-23 16:57:35.670999
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = 'return_name'
    test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(test.args == ['arg1', 'arg2'])
    assert(test.description == 'description')
    assert(test.type_name == 'type_name')
    assert(test.is_generator == True)
    assert(test.return_name == 'return_name')


# Generated at 2022-06-23 16:57:39.329537
# Unit test for constructor of class ParseError
def test_ParseError():
    init_args = {'args': ['int', ' a: int'], 'description': 'Takes two numbers and returns the sum of them'}
    assert init_args['args'] == ['int', ' a: int'] and init_args['description'] == 'Takes two numbers and returns the sum of them'

# Generated at 2022-06-23 16:57:45.381284
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test for constructor of class ParseError."""
    error_msg = "something went wrong"
    try:
        raise ParseError(error_msg)
    except ParseError as exc:
        assert str(exc) == error_msg, "The error message does not match"
    else:
        assert False, "The exception wasn't raised"

# Generated at 2022-06-23 16:57:49.653107
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(
        ["param"], "This is a parameter", "version" )
    assert d.args == ["param"]
    assert d.description == "This is a parameter"
    assert d.version == "version"



# Generated at 2022-06-23 16:57:51.122246
# Unit test for constructor of class ParseError
def test_ParseError():
    ex = ParseError()
    print(type(ex))
    print(ex)

# Generated at 2022-06-23 16:57:58.203639
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    test_description = "Test description"
    test_type = "int"
    test_generator = True
    test_return_name = "return_name"

    test_return = DocstringReturns(test_args, test_description, test_type, test_generator, test_return_name)

    assert test_return.args == test_args
    assert test_return.description == test_description
    assert test_return.type_name == test_type
    assert test_return.is_generator == test_generator
    assert test_return.return_name == test_return_name


# Generated at 2022-06-23 16:58:00.420161
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(args=["param", "arg", "description"], description="description")


# Generated at 2022-06-23 16:58:02.182295
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = []
    d = DocstringReturns([], None, None, False)
    assert d.args == test_args
    assert d.is_generator == False
    assert d.return_name == None
    assert d.type_name == None

# Generated at 2022-06-23 16:58:07.977394
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a='a'
    b='desc'
    c='d'
    d='t'
    e=True
    f='1'
    a1=DocstringParam(a,b,c,d,e,f)
    assert a1.args == a 
    assert a1.description ==b
    assert a1.arg_name== c
    assert a1.type_name==d
    assert a1.is_optional==e
    assert a1.default==f


# Generated at 2022-06-23 16:58:12.992781
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():

    """
    :param args: list of arguments. The exact content of this variable is
                 dependent on the kind of docstring; it's used to distinguish between
                 custom docstring meta information items.
    
    :param description: associated docstring description.
    """
    assert DocstringRaises([], "example").description == "example"

# Generated at 2022-06-23 16:58:20.758317
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        args=['return', 'description'],
        description='description',
        type_name='int',
        is_generator=True,
        return_name='return_name')
    assert docstring_returns.args == ['return', 'description']
    assert docstring_returns.description == 'description'
    assert docstring_returns.type_name == 'int'
    assert docstring_returns.is_generator
    assert docstring_returns.return_name == 'return_name'


# Generated at 2022-06-23 16:58:26.669565
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "Null"
    type_name = None
    is_generator = False
    return_name = None
    actual = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert isinstance(actual, DocstringMeta)
    assert actual.args == []
    assert actual.description == "Null"
    assert actual.type_name == None
    assert actual.is_generator == False
    assert actual.return_name == None


# Generated at 2022-06-23 16:58:30.218981
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dummy = DocstringReturns(args=[], description='This method is responsible for handling any get requests from the client from the path /hello/{name}', type_name='None', is_generator=False, return_name='name')
    print(dummy.__dict__)


if __name__ == '__main__':
    test_DocstringReturns()

# Generated at 2022-06-23 16:58:33.985317
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(['param'], 'This is a param', 'param_name', 'type', True, 'default')


# Generated at 2022-06-23 16:58:42.675340
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    docstring.short_description = "mock_short_description"
    docstring.long_description = "mock_long_description"
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True

    assert docstring.short_description == "mock_short_description"
    assert docstring.long_description == "mock_long_description"
    assert docstring.blank_after_short_description == True
    assert docstring.blank_after_long_description == True

    # Unit test for property "params"
    assert docstring.params == []

    # Unit test for property "raises"
    assert docstring.raises == []

    # Unit test for property "returns"
    assert docstring.returns is None

    


# Generated at 2022-06-23 16:58:45.418599
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["it"], "desc", "version")
    assert d.args == ["it"]
    assert d.description == "desc"
    assert d.version == "version"



# Generated at 2022-06-23 16:58:51.681050
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    meta_list = []
    type_name = "bool"
    is_generator = False
    return_name = "return"
    description = "True if the values are near."
    args = ["returns"]
    item = DocstringReturns(
        args, description, type_name, is_generator, return_name
    )
    meta_list.append(item)
    print(item.type_name)



# Generated at 2022-06-23 16:58:54.992774
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([], "")
    assert a.args == []
    assert a.description == ""


# Generated at 2022-06-23 16:59:00.632248
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = 'desc'
    version = '1.0.0'
    item = DocstringDeprecated(args, description, version)
    assert item.args == args
    assert item.description == description
    assert item.version == version


# Generated at 2022-06-23 16:59:04.319265
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    raiseParam = DocstringRaises(args,description,type_name)
    assert raiseParam.description == description
    assert raiseParam.type_name == type_name


# Generated at 2022-06-23 16:59:09.315711
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError"""
    try:
        """Unit test for constructor of class ParseError"""
        raise ParseError("enter a correct code")
    except ParseError as e:
        assert str(e)


# Generated at 2022-06-23 16:59:11.873628
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["deprecated"], "test description", "1.0")
    assert test.description == "test description"
    assert test.version == "1.0"
    assert test.args == ["deprecated"]


# Generated at 2022-06-23 16:59:15.801004
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(1,2)
    assert a.args == 1
    assert a.description == 2


# Generated at 2022-06-23 16:59:18.158202
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta=DocstringMeta
    deprecated=DocstringDeprecated(meta, "description", "version")

    assert deprecated.description == "description"
    assert deprecated.version == "version"


# Generated at 2022-06-23 16:59:19.691035
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta()

# Generated at 2022-06-23 16:59:21.126081
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises([], None, None)


# Generated at 2022-06-23 16:59:26.856396
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    line = ':raises: ValueError, an exception occurred'
    all_args = line[7:].strip().split(',' )
    DocstringRaises(all_args, description = 'an exception occurred', type_name='ValueError')

# Generated at 2022-06-23 16:59:33.520132
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test of the constructor for DocstringReturns"""
    try:
        return_meta = DocstringReturns(
            ["returns"],
            "returns type",
            "str",
            False,
            "return_name",
        )
    except:
        raise RuntimeError("An error was raised in the constructor")


# Generated at 2022-06-23 16:59:36.538438
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc_test = DocstringReturns(["a", "b"], "description", "type_name", True)


# Generated at 2022-06-23 16:59:41.399767
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    len_ = DocstringReturns(['parameterize'], 'An example of parametrized testing', 'type_name', True, 'Test')
    print(len_.return_name, len_.description, len_.type_name, len_.is_generator)

# Generated at 2022-06-23 16:59:46.321756
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == [item for item in d.meta if isinstance(item, DocstringParam)]
    assert d.raises == [item for item in d.meta if isinstance(item, DocstringRaises)]
    assert d.returns == None
    assert d.deprecation == None

# Generated at 2022-06-23 16:59:51.283890
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param"], "desc")
    assert docstring_meta.args == ["param"]
    assert docstring_meta.description == "desc"


# Generated at 2022-06-23 16:59:54.663332
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(
        args=['1.0'],
        description='What can I describe here?',
        version='1.0',
    )
    assert meta.description == 'What can I describe here?'
    assert meta.version == '1.0'

# Generated at 2022-06-23 16:59:57.365819
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    assert_equal(str(error), "test")


# Generated at 2022-06-23 17:00:02.252397
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(["deprecated", "in", "version", "1.0.0"], "description", "1.0.0")
    assert ds is not None


# Generated at 2022-06-23 17:00:06.502204
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert isinstance(d, Docstring)
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None



# Generated at 2022-06-23 17:00:13.528542
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    from Docstring import DocstringMeta
    docstringMeta1 = DocstringMeta(['param'], 'The first argument')
    docstringMeta1.args
    docstringMeta1.description
    assert docstringMeta1.args == ['param']
    assert docstringMeta1.description == 'The first argument'
    return

# Generated at 2022-06-23 17:00:14.985943
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ValueError) as excinfo:
        raise ParseError('hello')

# Generated at 2022-06-23 17:00:17.461040
# Unit test for constructor of class ParseError
def test_ParseError():
    '''Test constructor for class ParseError'''
    ParseError("error message")


# Generated at 2022-06-23 17:00:27.421374
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "This is a description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = "is_optional"
    default = "default"
    d = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert d.args == args and d.description == description and d.arg_name == arg_name and d.type_name == type_name and d.is_optional == is_optional and d.default == default



# Generated at 2022-06-23 17:00:34.384096
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_keyword = 'returns'
    description = 'this is a docstring'
    docstring = DocstringReturns([return_keyword], description, None, True)
    assert docstring.description == description
    assert docstring.return_name is None
    assert docstring.type_name is None
    assert docstring.args == [return_keyword]
    assert docstring.is_generator is True


# Generated at 2022-06-23 17:00:35.518639
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['param', 'a'], 'this is a parameter.', 'a', 'int', False, None)


# Generated at 2022-06-23 17:00:38.027893
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    for param in PARAM_KEYWORDS:
        DocstringParam([param], 'This is a test', 'arg', 'int', True, None)


# Generated at 2022-06-23 17:00:42.178949
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    exc = DocstringRaises(["raises","RuntimeError"],"if something goes wrong", "RuntimeError")
    assert exc.args == ["raises","RuntimeError"], "args are not set properly"
    assert exc.description == "if something goes wrong"
    assert exc.type_name == "RuntimeError"

# Generated at 2022-06-23 17:00:49.141287
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['a', 'b', 'c'], 'This is a description of a function')
    assert d.args == ['a', 'b', 'c']
    assert d.description == 'This is a description of a function'


# Generated at 2022-06-23 17:00:50.073232
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d
    assert isinstance(d, Docstring)


# Generated at 2022-06-23 17:00:54.971818
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"

    obj = DocstringRaises(args, description, type_name)
    assert obj.args == ["raises", "ValueError"]
    assert obj.description == "if something happens"
    assert obj.type_name == "ValueError"


# Generated at 2022-06-23 17:00:59.828744
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['\u200btest']
    description = 'some description'
    version = 'some_version'

    d = DocstringDeprecated(args, description, version)
    assert d.args == ['\u200btest']
    assert d.description == 'some description'
    assert d.version == 'some_version'



# Generated at 2022-06-23 17:01:01.092329
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError(RuntimeError) == RuntimeError


# Generated at 2022-06-23 17:01:04.804161
# Unit test for constructor of class Docstring
def test_Docstring():
    test_Docstring = Docstring()
    if test_Docstring.short_description is None and test_Docstring.long_description is None:
        return True
    return False

test_Docstring()


# Generated at 2022-06-23 17:01:07.390369
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for the exception ParseError."""
    import pytest
    with pytest.raises(ParseError):
        raise ParseError("Test exception")

# Generated at 2022-06-23 17:01:13.074111
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["raises","Exception"], "Raises an exception", None)
    assert docstring_raises.args == ["raises", "Exception"]
    assert docstring_raises.description == "Raises an exception"
    assert docstring_raises.type_name == None

# Generated at 2022-06-23 17:01:18.207246
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    temp = DocstringReturns([1,2,3],'description','type',True)
    assert temp.description == 'description'
    assert temp.type_name == 'type'
    assert temp.is_generator == True


# Generated at 2022-06-23 17:01:26.104888
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_name = "a"
    args = ['param', 'a']
    description = "description"
    type_name = "type"
    is_generator = False
    docstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name = return_name)
    assert docstringReturns.return_name == return_name
    assert docstringReturns.description == description
    assert docstringReturns.type_name == type_name
    assert docstringReturns.is_generator == is_generator


# Generated at 2022-06-23 17:01:28.972590
# Unit test for constructor of class ParseError
def test_ParseError():
    with raises(ParseError):
        raise ParseError("error message")


# Generated at 2022-06-23 17:01:36.586618
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(
        args = ["a","b","c"],
        description = "test for description",
        arg_name = "arg",
        type_name = "int",
        is_optional = True,
        default = "2"
    )
    assert doc.args == ["a","b","c"]
    assert doc.description == "test for description"
    assert doc.arg_name == "arg"
    assert doc.type_name == "int"
    assert doc.is_optional == True
    assert doc.default == "2"



# Generated at 2022-06-23 17:01:38.770927
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('Test error')
    assert error


# Generated at 2022-06-23 17:01:44.302728
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(
        args=["param", "arg"], description="A short description"
    ).args == ["param", "arg"]
    assert DocstringMeta(
        args=["param", "arg"], description="A short description"
    ).description == "A short description"
    return



# Generated at 2022-06-23 17:01:48.979916
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []

# Generated at 2022-06-23 17:01:51.295123
# Unit test for constructor of class Docstring
def test_Docstring():
    # create a Docstring object
    d = Docstring()
    # check it exists
    assert d is not None


# Generated at 2022-06-23 17:01:56.587880
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()

    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []



# Generated at 2022-06-23 17:01:58.597937
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(args=['arg', 'a,b'], description='description')


# Generated at 2022-06-23 17:02:00.451703
# Unit test for constructor of class ParseError
def test_ParseError():
    obj = ParseError("error")
    assert obj.args[0] == "error"


# Generated at 2022-06-23 17:02:02.486790
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = [""]
    description = ""
    version = ""
    docstringdeprecated = DocstringDeprecated(args, description, version)


# Generated at 2022-06-23 17:02:06.608243
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['raises', 'ValueError', 'if', 'something'],
                           'Description', 'ValueError')
    assert test.type_name == 'ValueError'
    assert test.description == 'Description'
    assert test.args == ['raises', 'ValueError', 'if', 'something']

# Generated at 2022-06-23 17:02:13.730416
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = ["1","2","3","4","5","6","7","8","9","10"]
    b = "description"
    c = "type_name"
    d = True
    obj1 = DocstringReturns(a,b,c,d)
    assert obj1.args == ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
    assert obj1.description == "description"
    assert obj1.type_name == "type_name"
    assert obj1.is_generator == True
    assert obj1.return_name == None
    obj2 = DocstringReturns(a,b,c,d,return_name = 'return')
    assert obj2.return_name == "return"

# Generated at 2022-06-23 17:02:16.512456
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param", "parameter"], "description","arg_name", "type_name", True, "default")



# Generated at 2022-06-23 17:02:22.209480
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    assert obj.short_description == None
    assert obj.long_description == None
    assert obj.blank_after_short_description == False
    assert obj.blank_after_long_description == False
    assert obj.meta == []


# Generated at 2022-06-23 17:02:32.162892
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = 'arg1'
    description = 'describe'
    arg_name = 'arg_name1'
    type_name = 'type_name1'
    is_optional = True
    default = 'default1'
    docstring_param = DocstringParam(args,description,arg_name,type_name,is_optional,default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-23 17:02:33.951045
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert (DocstringReturns(['return'], 'This is returned')) == DocstringReturns(['return'], 'This is returned')


# Generated at 2022-06-23 17:02:35.951081
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['args']
    description = 'description'
    version = 'version'
    DocstringDeprecated(args, description, version)



# Generated at 2022-06-23 17:02:36.472626
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()


# Generated at 2022-06-23 17:02:39.379906
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = ""
    version = "0.0.0"
    dD = DocstringDeprecated(args, description, version)
    assert dD.args == args
    assert dD.description == description
    assert dD.version == version


# Generated at 2022-06-23 17:02:40.192617
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()

# Generated at 2022-06-23 17:02:50.083201
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Create a new DocstringReturns instance
    this_new_one = DocstringReturns(
        args= RAISES_KEYWORDS,
        description= "This is a new DocstringReturns instance",
        type_name= "type",
        is_generator= True, 
        return_name= "value"
    )
    
    # Print out the values of the instance
    print(
        this_new_one.args,
        this_new_one.description,
        this_new_one.type_name,
        this_new_one.is_generator,
        this_new_one.return_name
    )


if __name__ == "__main__":
    test_DocstringReturns()

# Generated at 2022-06-23 17:02:55.770091
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(["yields"], None, None, True).type_name == None
    assert DocstringReturns(["yields"], None, "", True).type_name == ""
    assert DocstringReturns(["yields"], None, "NoneType", True).type_name == "NoneType"


# Generated at 2022-06-23 17:02:59.952506
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    error = ParseError("Test error")
    assert(error.args == ("Test error",))


# Generated at 2022-06-23 17:03:03.710570
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Message")
    assert err.__str__() == "Message"
    assert err.__repr__() == "Message"


# Generated at 2022-06-23 17:03:07.673483
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises('args', 'description', 'type_name')
    assert docstring_raises.args == 'args'
    assert docstring_raises.description == 'description'
    assert docstring_raises.type_name == 'type_name'

# Generated at 2022-06-23 17:03:10.760795
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []


# Generated at 2022-06-23 17:03:12.324874
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["version"], "some description", "some version")


# Generated at 2022-06-23 17:03:16.571946
# Unit test for constructor of class DocstringRaises

# Generated at 2022-06-23 17:03:19.405785
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("testing")
    assert (
        str(err) == "testing"
    )


# Generated at 2022-06-23 17:03:24.143715
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:03:28.642524
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(args=[], description="")
    assert obj.args == []
    assert obj.description == ""
    # Make sure it raises TypeError if called with wrong arguments type
    try:
        DocstringMeta(args=1, description="")
    except TypeError:
        pass
    try:
        DocstringMeta(args=[], description=1)
    except TypeError:
        pass


# Generated at 2022-06-23 17:03:37.054220
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['test1', 'test2']
    description = 'test'
    type_name = 'test'
    is_generator = False
    return_name = None
    docstringReturnsObj = DocstringReturns(args, description, type_name, is_generator)
    assert docstringReturnsObj.type_name == type_name
    assert docstringReturnsObj.description == description
    assert docstringReturnsObj.is_generator == is_generator
    assert docstringReturnsObj.return_name == None
    assert docstringReturnsObj.args == args


# Generated at 2022-06-23 17:03:41.521768
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['raises'], 'IOError', 'IOError')
    assert d.args == ['raises']
    assert d.type_name == 'IOError'
    assert d.description == 'IOError'

test_DocstringRaises()

# Generated at 2022-06-23 17:03:48.225232
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    expected_args = ['param', 'name', 'Test']
    expected_description = "docstring meta testing"
    actual = DocstringMeta(expected_args, expected_description)
    try:
        assert(actual.args == expected_args)
        assert(actual.description == expected_description)
    except AssertionError:
        print("test_DocstringMeta failed")


# Generated at 2022-06-23 17:03:51.876670
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam([], None, None, None, None)
    docstring_returns = DocstringReturns([], None, None, None)
    assert type(docstring_param) is DocstringParam


# Generated at 2022-06-23 17:04:00.857220
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test init with empty description and args
    dsm = DocstringMeta([], '')
    assert dsm.args == []
    assert dsm.description == ''

    # Test init with args strings and description string
    dsm = DocstringMeta(['args'], 'description')
    assert dsm.args == ['args']
    assert dsm.description == 'description'

    # Test init with args list and description string
    dsm = DocstringMeta([['args']], 'description')
    assert dsm.args == [['args']]
    assert dsm.description == 'description'


# Generated at 2022-06-23 17:04:05.700078
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert isinstance(docstring, Docstring)
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert isinstance(docstring.meta, list)


# Generated at 2022-06-23 17:04:08.686145
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(None, None, None, None, None, None) is not None
    assert DocstringParam([], [], [], [], [], []) is not None


# Generated at 2022-06-23 17:04:14.342507
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_type = DocstringReturns(["returns"], "some desc", "some args",
                                   "is_generator", "Return")
    assert return_type.type_name == "some args"
    assert return_type.is_generator == "is_generator"
    assert return_type.return_name == "Return"


# Generated at 2022-06-23 17:04:17.083475
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    a = DocstringDeprecated(args=["a"], description="abc", version="abc")


# Generated at 2022-06-23 17:04:18.504249
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], "test description")


# Generated at 2022-06-23 17:04:20.888124
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Testing docstring")
    assert error is not None


# Generated at 2022-06-23 17:04:25.656085
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    some_args = ["arg1", "arg2"]
    description = "A docstring"
    d = DocstringMeta(some_args, description)
    assert d.args == ["arg1", "arg2"]
    assert d.description == "A docstring"


# Generated at 2022-06-23 17:04:27.180938
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=[],description="",type_name="")


# Generated at 2022-06-23 17:04:32.709251
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []
    assert Docstring().params == []
    assert Docstring().raises == []
    assert Docstring().deprecation == None


# Generated at 2022-06-23 17:04:38.048191
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the constructor of class DocstringParam"""
    param = DocstringParam(["parameter"], "description", "arg_name", "type_name", True, "default")
    assert param.args == ["parameter"]
    assert param.description == "description"
    assert param.arg_name == "arg_name"
    assert param.type_name == "type_name"
    assert param.is_optional == True
    assert param.default == "default"


# Generated at 2022-06-23 17:04:41.666036
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    _doc = DocstringMeta(["args"], "This is a test")
    assert len(_doc.args) == 1
    assert _doc.args[0] == "args"
    assert _doc.description == "This is a test"



# Generated at 2022-06-23 17:04:47.330778
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(
        args=["deprecated"],
        description="This function is not recommended.",
        version="0.1.1")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "This function is not recommended."
    assert docstring.version == "0.1.1"

test_DocstringDeprecated()


# Generated at 2022-06-23 17:04:55.126821
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-23 17:04:59.644509
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises ValueError: if something happens']
    description = "description"
    type_name = 'ValueError'
    dr = DocstringRaises(args, description, type_name)
    print(dr.args)
    print(dr.description)
    print(dr.type_name)

# Generated at 2022-06-23 17:05:07.083861
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    instance = DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')
    assert isinstance(instance, DocstringMeta)
    assert instance.args == ['param']
    assert instance.description == 'description'
    assert instance.arg_name == 'arg_name'
    assert instance.type_name == 'type_name'
    assert instance.is_optional == True
    assert instance.default == 'default'
    assert instance.__repr__() == 'DocstringParam(args=\'"["param"]"\', description=\'description\', arg_name=\'arg_name\', type_name=\'type_name\', is_optional=True, default=\'default\')'


# Generated at 2022-06-23 17:05:09.650766
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta([], "")
    assert docstring_meta.args == []
    assert docstring_meta.description == ""



# Generated at 2022-06-23 17:05:13.023944
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = None
    description = None
    arg_name = None
    type_name = None
    is_optional = None
    default = None
    DocstringParam(args, description, arg_name, type_name, is_optional, default)



# Generated at 2022-06-23 17:05:14.964915
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["parameter"], "description", "version")


# Generated at 2022-06-23 17:05:19.713884
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    str1 = 'args'
    str2 = 'description'
    str3 = 'type_name'
    b = True
    str4 = 'return_name'
    assert DocstringReturns(str1, str2, str3, b, str4) is not None

# Generated at 2022-06-23 17:05:25.987519
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    assert test.short_description is None
    assert test.long_description is None
    assert test.blank_after_short_description is False
    assert test.blank_after_long_description is False
    assert test.meta == []
    assert test.params == []
    assert test.raises == []
    assert test.deprecation is None
    assert test.returns is None



# Generated at 2022-06-23 17:05:31.762006
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(
        args=['yields'],
        description='generator that is the result of reading a file line by line',
        type_name='generator',
        is_generator=True,
        return_name='FileIO',
    )
    print(d.__dict__)
