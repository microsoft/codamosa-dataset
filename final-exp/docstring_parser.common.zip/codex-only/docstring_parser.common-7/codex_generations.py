

# Generated at 2022-06-23 16:55:32.491460
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['a'], 'a description')
    a.args
    a.description
    

# Generated at 2022-06-23 16:55:36.659303
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Tests if the information are correct."""
    doc = DocstringDeprecated(["yields"], "description", "1.0")

    assert doc.description == "description"
    assert doc.version == "1.0"

# Generated at 2022-06-23 16:55:40.349007
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    assert obj.short_description is None
    assert obj.long_description is None
    assert obj.blank_after_short_description is False
    assert obj.blank_after_long_description is False
    assert obj.meta is not None


# Generated at 2022-06-23 16:55:41.225325
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()
    

# Generated at 2022-06-23 16:55:50.161228
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = "description"
    type_name = "int"
    test_object = DocstringRaises(args, description, type_name)
    assert isinstance(test_object, DocstringMeta), "Should be of type DocstringMeta."
    assert test_object.args == args, "Should be args of DocstringRaises class."
    assert test_object.description == description, "Should be description of DocstringRaises class."
    assert test_object.type_name == type_name, "Should be type_name of DocstringRaises class."

# Generated at 2022-06-23 16:55:52.500540
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=['a'], description='b', version=['c'])

# Generated at 2022-06-23 16:55:54.489979
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    s = DocstringMeta(["a"], "Description")
    assert s.description == "Description"
    assert s.args == ["a"]


# Generated at 2022-06-23 16:55:59.439911
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMetadata = DocstringMeta(["temp1","temp2","temp3"],"the line describes")
    assert(docstringMetadata.args == ["temp1","temp2","temp3"])
    assert(docstringMetadata.description == "the line describes")


# Generated at 2022-06-23 16:56:02.003601
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("This is a test.")
    assert error.args == ("This is a test.",)


# Generated at 2022-06-23 16:56:03.178427
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert isinstance(d, Docstring)



# Generated at 2022-06-23 16:56:11.705907
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None

# Generated at 2022-06-23 16:56:13.818422
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=['ao', 'pao'], description=None, type_name=None)


# Generated at 2022-06-23 16:56:15.143542
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['param'], 'description', None, False)


# Generated at 2022-06-23 16:56:17.420226
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Invalid")
    except RuntimeError as e:
        assert e.args[0] == "Invalid"

# Generated at 2022-06-23 16:56:20.593273
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['return', 'returns'], 'test', None, False, 'return_name')
    assert a.type_name is None
    assert a.is_generator == False
    assert a.return_name == 'return_name'

# Generated at 2022-06-23 16:56:28.513626
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['param'], 'a desc', 'arg', 'type', True, 'a def').args == ['param']
    assert DocstringParam(['param'], 'a desc', 'arg', 'type', True, 'a def').description == 'a desc'
    assert DocstringParam(['param'], 'a desc', 'arg', 'type', True, 'a def').arg_name == 'arg'
    assert DocstringParam(['param'], 'a desc', 'arg', 'type', True, 'a def').type_name == 'type'
    assert DocstringParam(['param'], 'a desc', 'arg', 'type', True, 'a def').is_optional == True
    assert DocstringParam(['param'], 'a desc', 'arg', 'type', True, 'a def').default == 'a def'
   

# Generated at 2022-06-23 16:56:34.766647
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
        args = ["p1", "p2"]
        description = "test description"
        type_name = "test type"
        doc_raises = DocstringRaises(args, description, type_name)
        assert len(doc_raises.args) == 2
        assert doc_raises.description == description
        assert doc_raises.type_name == type_name

# Generated at 2022-06-23 16:56:35.578498
# Unit test for constructor of class ParseError
def test_ParseError():
    test_ParseError = ParseError()
    print(test_ParseError)


# Generated at 2022-06-23 16:56:37.273891
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("some message")
    assert error.args == "some message"

# Generated at 2022-06-23 16:56:44.888469
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns', ':return:']
    description = None
    type_name = 'int'
    is_generator = False
    return_name = None
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    print(returns.description)
    print(returns.type_name)
    print(returns.is_generator)
    print(returns.return_name)


# Generated at 2022-06-23 16:56:50.800742
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['param', 'type_name']
    d = DocstringReturns(args, 'description', 'type_name', True, 'return_name')
    assert d.type_name == 'type_name'
    assert d.is_generator == True
    assert d.return_name == 'return_name'
    assert d.description == 'description'


# Generated at 2022-06-23 16:56:52.188961
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring"""
    Docstring()
    return True

# Generated at 2022-06-23 16:56:57.100984
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []



# Generated at 2022-06-23 16:57:01.808445
# Unit test for constructor of class Docstring
def test_Docstring():
    d_string = Docstring()
    assert d_string.short_description is None
    assert d_string.long_description is None
    assert d_string.blank_after_short_description is False
    assert d_string.blank_after_long_description is False
    assert d_string.params == []
    assert d_string.raises == []
    assert d_string.returns is None
    assert d_string.deprecation is None


# Generated at 2022-06-23 16:57:10.317340
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [""]
    description = "this is a test"
    type_name = "Test"
    is_generator = False
    return_name = "test"
    x = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert x.args == args
    assert x.description == description
    assert x.type_name == type_name
    assert x.is_generator == is_generator
    assert x.return_name == return_name

test_DocstringReturns()

# Generated at 2022-06-23 16:57:17.148453
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    result = DocstringDeprecated(["deprecated", "a" , "b"], "desc", "ver")
    assert result.args == ["deprecated", "a", "b"], "Wrong initialization"
    assert result.description == "desc", "Wrong initialization"
    assert result.version == "ver", "Wrong initialization"

test_DocstringDeprecated()


# Generated at 2022-06-23 16:57:22.602203
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = []
    b = "a"
    c = "a"
    d = "a"
    e = True
    f = "a"
    x = DocstringParam(a, b, c, d, e, f)
    assert x.args == a
    assert x.description == b
    assert x.arg_name == c
    assert x.type_name == d
    assert x.is_optional == e
    assert x.default == f


# Generated at 2022-06-23 16:57:25.018346
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    x = ParseError('test')
    assert isinstance(x, ParseError)


# Generated at 2022-06-23 16:57:37.231690
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg1','arg2','arg3','arg4','arg5','arg6','arg7','arg8','arg9','arg10']
    description = "This is description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = "is_optional"
    default = "default"
    d = DocstringParam(args,description,arg_name,type_name,is_optional,default)
    assert d.args == ['arg1','arg2','arg3','arg4','arg5','arg6','arg7','arg8','arg9','arg10']
    assert d.description == "This is description"
    assert d.arg_name == "arg_name"
    assert d.type_name == "type_name"

# Generated at 2022-06-23 16:57:44.014169
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['param', 'arg', 'value'], 'description', 'arg', 'value', 'True', 'default')
    assert a.args == ['param', 'arg', 'value']
    assert a.description == 'description'
    assert a.arg_name == 'arg'
    assert a.type_name == 'value'
    assert a.is_optional == 'True'
    assert a.default == 'default'


# Generated at 2022-06-23 16:57:52.984992
# Unit test for constructor of class Docstring
def test_Docstring():
    docString = Docstring()
    docString.short_description = None  # type: T.Optional[str]
    docString.long_description = None  # type: T.Optional[str]
    docString.blank_after_short_description = False
    docString.blank_after_long_description = False
    docString.meta = []  # type: T.List[DocstringMeta]
    assert docString.short_description == None
    assert docString.long_description == None
    assert docString.blank_after_short_description == False
    assert docString.long_description == None
    assert docString.meta == []


# Generated at 2022-06-23 16:57:54.966934
# Unit test for constructor of class ParseError
def test_ParseError():
    assert(ParseError)


# Generated at 2022-06-23 16:57:58.370766
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('test')
    
    assert isinstance(e, RuntimeError)
    assert e.args == ('test', )


# Generated at 2022-06-23 16:58:02.886144
# Unit test for constructor of class Docstring
def test_Docstring():
    result = Docstring()
    assert result.short_description is None
    assert result.long_description is None
    assert result.blank_after_short_description is False
    assert result.blank_after_long_description is False
    assert result.meta == []


# Generated at 2022-06-23 16:58:05.445174
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = ""
    meta = DocstringMeta(args, description)
    assert meta


# Generated at 2022-06-23 16:58:09.867725
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None


# Generated at 2022-06-23 16:58:14.884781
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['type', 'argument'], 'description', 'arg_name', 'type', True, None)
    assert param.args == ['type', 'argument']
    assert param.arg_name == 'arg_name'
    assert param.description == 'description'
    assert param.type_name == 'type'
    assert param.is_optional == True
    assert param.default == None


# Generated at 2022-06-23 16:58:16.299297
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(["args"], "description", "type_name")

# Generated at 2022-06-23 16:58:19.210946
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of class DocstringMeta"""
    actual = DocstringMeta(['args'], 'description')
    assert actual.args == ['args']
    assert actual.description == 'description'


# Generated at 2022-06-23 16:58:21.071301
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass



# Generated at 2022-06-23 16:58:22.373116
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass

# Generated at 2022-06-23 16:58:29.041202
# Unit test for constructor of class Docstring
def test_Docstring():
    test1 = Docstring()
    print(test1.short_description)  # None
    print(test1.long_description)  # None
    print(test1.blank_after_short_description)  # False
    print(test1.blank_after_long_description)  # False
    print(test1.meta)  # []
    print(test1.params)  # []
    print(test1.raises)  # []
    print(test1.returns)  # None
    print(test1.deprecation)  # None
    return test1


# Generated at 2022-06-23 16:58:36.142212
# Unit test for constructor of class Docstring
def test_Docstring():
    # type: () -> None
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []



# Generated at 2022-06-23 16:58:38.829922
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(['a', 'b'], 'This is description')
    assert docstring.args == ['a', 'b']
    assert docstring.description == 'This is description'


# Generated at 2022-06-23 16:58:50.552341
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_arg_names = ['Hello', 'Hola', 'Bonjour']
    test_description = 'description'
    test_type_name = 'type_name'
    test_is_optional = True
    test_default = 1.2
    t = DocstringParam( test_arg_names, test_description, 'arg_name', test_type_name, test_is_optional, test_default)
    assert t.args == test_arg_names
    assert t.description == test_description
    assert t.arg_name == 'arg_name'
    assert t.type_name == test_type_name
    assert t.is_optional == test_is_optional
    assert t.default == test_default


# Generated at 2022-06-23 16:59:00.322034
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test DocstringRaises class."""
    assert isinstance(DocstringRaises(args=[], description="" ), DocstringRaises)
    assert isinstance(DocstringRaises(args=[], description="", type_name=""), DocstringRaises)
    assert isinstance(DocstringRaises(args=[""], description=""), DocstringRaises)
    assert isinstance(DocstringRaises(args=[], description="", type_name=""), DocstringRaises)
    assert isinstance(DocstringRaises(args=[""], description="", type_name=""), DocstringRaises)


# Generated at 2022-06-23 16:59:02.693028
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['test'], 'test_description', 'test_type')
    assert a.args == ['test']
    assert a.description == 'test_description'
    assert a.type_name == 'test_type'

# Generated at 2022-06-23 16:59:09.772007
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arg_name = "arg"
    args = ["param"]
    description = "description"
    type_name = "type"
    is_optional = True
    default = "default"

    """
    Test of constructor for class DocstringParam
    """
    DocstringParam(args, description, arg_name, type_name, is_optional, default)



# Generated at 2022-06-23 16:59:13.596499
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError as e:
        assert str(e) == ''


# Generated at 2022-06-23 16:59:15.801065
# Unit test for constructor of class ParseError
def test_ParseError():
    # No error because this is empty
    ParseError()


# Generated at 2022-06-23 16:59:20.469061
# Unit test for constructor of class Docstring
def test_Docstring():
    print("Unit test for constructor of class Docstring")
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    print("Passed!")

test_Docstring()

# Generated at 2022-06-23 16:59:28.309355
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    tester = DocstringReturns(["returns"], "returns test", "Test")
    assert tester.args == ["returns"]
    assert tester.description == "returns test"
    assert tester.type_name == "Test"
    assert tester.is_generator == False
    assert tester.return_name == None



# Generated at 2022-06-23 16:59:35.303799
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(['param', 'a', 'description'],
                       'description',
                       'a',
                       'description',
                       None,
                       None)
    assert d.args == ['param', 'a', 'description']
    assert d.description == 'description'
    assert d.arg_name == 'a'
    assert d.type_name == 'description'
    assert d.is_optional is None
    assert d.default is None
    assert isinstance(d, DocstringMeta)



# Generated at 2022-06-23 16:59:42.266974
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ags = ['ag', 'b']
    des = "des"
    type_n = "type_n"
    test_DocstringRaises = DocstringRaises(ags, des, type_n)
    print("test_DocstringRaises:", test_DocstringRaises.args, test_DocstringRaises.description, test_DocstringRaises.type_name)


# Generated at 2022-06-23 16:59:47.013417
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ["parameter", "arg", "argument", "attribute", "key", "keyword"]
    test_description = "description"
    assert DocstringMeta(test_args, test_description) is not None


# Generated at 2022-06-23 16:59:53.302080
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    from pinject import DocstringDeprecated
    args = []
    description = None
    version = None
    test1 = DocstringDeprecated(args,description,version)
    print(test1)
    tracking = [test1.args,test1.description,test1.version]
    print(tracking)
    assert(tracking == [args,description,version])

# Generated at 2022-06-23 16:59:55.169321
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["arg1", "arg2"], None, "arg3", None, None, None)



# Generated at 2022-06-23 17:00:02.773300
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description is None
    assert test_docstring.long_description is None
    assert test_docstring.blank_after_short_description is False
    assert test_docstring.blank_after_long_description is False
    assert test_docstring.meta is []


# Generated at 2022-06-23 17:00:10.138225
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_args = [':param', 'arg', ':', 'description']
    param_arg_name = 'arg'
    param_type_name = None
    param_is_optional = None
    param_default = None
    param = DocstringParam(param_args, param_arg_name, param_type_name, param_is_optional, param_default)
    print(param.args)
    print(param.arg_name)
    print(param.type_name)
    print(param.is_optional)
    print(param.default)


# Generated at 2022-06-23 17:00:15.255628
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstr_meta = DocstringDeprecated(args=["deprecated", "dep"], description="this is deprecated")
    assert docstr_meta.args == ["deprecated", "dep"]
    assert docstr_meta.description == "this is deprecated"
    assert docstr_meta.version is None

    docstr_meta = DocstringDeprecated(args=["deprecated", "dep"], description="this is deprecated", version="0.0.1")
    assert docstr_meta.version == "0.0.1"



# Generated at 2022-06-23 17:00:25.587503
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    my_DocstringReturns = DocstringReturns("args", "description", "type_name", "is_generator", "return_name")
    assert my_DocstringReturns.args == "args"
    assert my_DocstringReturns.description == "description"
    assert my_DocstringReturns.type_name == "type_name"
    assert my_DocstringReturns.is_generator == "is_generator"
    assert my_DocstringReturns.return_name == "return_name"



# Generated at 2022-06-23 17:00:29.430602
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('1')
    except ParseError as exception:
        print(exception)
        assert isinstance(exception, ParseError)


# Generated at 2022-06-23 17:00:34.149697
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    new_item = DocstringMeta(["param", "arg", "argument"], "description")
    assert new_item.args == ["param", "arg", "argument"], "args is not initialized correctly"
    assert new_item.description == "description", "description is not initialized correctly"


# Generated at 2022-06-23 17:00:37.220654
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises([''], '', 'ValueError')
    assert doc.description == 'ValueError'
    assert doc.args == ['']



# Generated at 2022-06-23 17:00:40.960101
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
   meta = DocstringMeta(["param", "parameter"], "description")
   assert meta.args == ["param", "parameter"]
   assert meta.description == "description"
   assert meta.__class__ == DocstringMeta


# Generated at 2022-06-23 17:00:49.142135
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    "Unit test for constructor of class DocstringDeprecated"
    a = DocstringDeprecated(['deprecated'], 'Why this function is deprecated', '1.0')
    assert a.args == ['deprecated']
    assert a.description == 'Why this function is deprecated'
    assert a.version == '1.0'


# Generated at 2022-06-23 17:00:49.524861
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    return

# Generated at 2022-06-23 17:00:57.133145
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item = DocstringParam(
        ["param", "arg"],
        "description",
        "arg_name",
        "type_name",
        True,
        "default_value")
    assert item.args == ["param", "arg"], "Arg should be param, arg"
    assert item.description == "description", "Description should be description"
    assert item.arg_name == "arg_name", "Argument name should be arg_name"
    assert item.type_name == "type_name", "Type name should be type_name"
    assert item.is_optional == True, "Optional should be True"
    assert item.default == "default_value", "Default should be default_value"


# Generated at 2022-06-23 17:01:03.192165
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print("Start test: test_DocstringRaises")
    args = ["test", "test2"]
    description = "test description"
    type_name = "type test"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert(docstring_raises)
    print("Passed test: test_DocstringRaises")


# Generated at 2022-06-23 17:01:08.875436
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test if default values are set when calling constructor
    assert (
        DocstringDeprecated(
            args=["No args"],
            description="No Description",
            version="No version",
        ).version
        == "No version"
    )
    assert (
        DocstringDeprecated(
            args=["No args"],
            description="No Description",
            version="No version",
        ).description
        == "No Description"
    )



# Generated at 2022-06-23 17:01:10.147891
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	assert DocstringReturns([],[],None, False, None)

# Generated at 2022-06-23 17:01:13.334475
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param", "Hello"], "Hello").args[0] == "param"
    assert DocstringMeta(["param", "Hello"], "Hello").description == "Hello"


# Generated at 2022-06-23 17:01:22.768932
# Unit test for constructor of class DocstringParam
def test_DocstringParam():

    docstringPar = DocstringParam(["a", "b", "c"], "description", "arg_name", "type_name", "true", "default")

    assert docstringPar.args == ["a", "b", "c"]
    assert docstringPar.description == "description"
    assert docstringPar.arg_name == "arg_name"
    assert docstringPar.type_name == "type_name"
    assert docstringPar.is_optional == "true"
    assert docstringPar.default == "default"



# Generated at 2022-06-23 17:01:23.463011
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("value")


# Generated at 2022-06-23 17:01:27.080656
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated([":deprecated", ":dep"], "description", "4.8")
    assert doc.args == [":deprecated", ":dep"]
    assert doc.description == "description"
    assert doc.version == "4.8"


# Generated at 2022-06-23 17:01:27.855226
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["abcd"], "e")

# Generated at 2022-06-23 17:01:33.711973
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['self']
    parameter = 'description'
    type_name = ['None']
    is_generator = True
    return_name = "returns"

    test = DocstringReturns(
        args, parameter, type_name, is_generator, return_name)

    # Test for returned values
    assert test.args == ['self'] and test.description == 'description'
    assert test.type_name == ['None'] and test.is_generator == True
    assert test.return_name == 'returns'


# Generated at 2022-06-23 17:01:37.181018
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description is False
    assert Docstring().blank_after_long_description is False
    assert Docstring().meta == []


# Generated at 2022-06-23 17:01:45.652897
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    temp = DocstringParam(["a","b"], "c", "d", "e", True, "f")
    assert temp.args == ["a", "b"]
    assert temp.description == "c"
    assert temp.arg_name == "d"
    assert temp.type_name == "e"
    assert temp.is_optional is True
    assert temp.default == "f"

if __name__ == "__main__":
    test_DocstringParam()
    print("All tests passed")

# Generated at 2022-06-23 17:01:47.872015
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param"], "x", "1", None, False, None)



# Generated at 2022-06-23 17:01:49.137505
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test function for function ParseError."""
    with pytest.raises(RuntimeError):
        raise ParseError("test")


# Generated at 2022-06-23 17:01:53.860077
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["args", "args2", "args3"]
    description = "args is a list of arguments"
    test_obj = DocstringMeta(args, description)
    expected_res = True
    actual_res = False
    if test_obj.args == args and test_obj.description == description:
        actual_res = True
    assert actual_res == expected_res

# Generated at 2022-06-23 17:01:59.516827
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    #Test initialization with empty list of args
    dm = DocstringMeta([], "desc")
    assert dm.args == []
    assert dm.description == "desc"

    #Test initialization with non-empty list of args
    dm = DocstringMeta(["foo"], "desc")
    assert dm.args == ["foo"]
    assert dm.description == "desc"


# Generated at 2022-06-23 17:02:04.018110
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []


# Generated at 2022-06-23 17:02:09.754910
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['param'], "describe param", "a", "int", True, "10")
    assert dp.args == ['param']
    assert dp.description=="describe param"
    assert dp.arg_name == "a"
    assert dp.type_name == "int"
    assert dp.is_optional == True
    assert dp.default == "10"

if __name__ == "__main__":
    test_DocstringParam()

# Generated at 2022-06-23 17:02:20.718677
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = 'description'
    type_name = 'type_name'
    item = DocstringRaises(args, description, type_name)
    assert item.description == 'description'
    assert item.type_name == 'type_name'
    assert item.args == ['arg']


for item in [DocstringParam, DocstringReturns, DocstringRaises, DocstringDeprecated]:
    # Unit test for constructor of class DocstringMeta
    def test_DocstringMeta():
        args = ['arg']
        description = 'description'
        item_meta = item(args, description)
        assert item_meta.args == ['arg']
        assert item_meta.description == 'description'



# Generated at 2022-06-23 17:02:21.321662
# Unit test for constructor of class ParseError
def test_ParseError():
    pass

# Generated at 2022-06-23 17:02:27.900411
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None  # type: ignore
    assert docstring.long_description == None  # type: ignore
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:02:30.145368
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test the constructor of class DocstringReturns."""
    a = DocstringReturns(['raises'], 'test', 'str', False)



# Generated at 2022-06-23 17:02:35.932403
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert len(docstring.meta) == 0

# Generated at 2022-06-23 17:02:36.570037
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError

# Generated at 2022-06-23 17:02:37.961778
# Unit test for constructor of class ParseError
def test_ParseError():
    test = ParseError("test")
    assert test.args[0] == "test"

# Generated at 2022-06-23 17:02:40.839207
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    deprecation = DocstringDeprecated(["deprecated"], "Removed", "0.5.0")
    assert deprecation.args == ["deprecated"]



# Generated at 2022-06-23 17:02:42.374682
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], description='description', version='2')


# Generated at 2022-06-23 17:02:44.945565
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('error')
    except ParseError as e:
        assert str(e) == 'Error in: error'


# Generated at 2022-06-23 17:02:48.104444
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert isinstance(err, ParseError)
    assert isinstance(err, RuntimeError)



# Generated at 2022-06-23 17:02:56.539946
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = Docstring()
    docstring.short_description = 'Documents a function'
    docstring.blank_after_short_description = True
    docstring.long_description = 'This is a long description that should be the body of an email'
    docstring.blank_after_long_description = True
    docstring.meta = [DocstringMeta(['param'], 'description')]
    assert len(docstring.meta) == 1
    assert docstring.long_description is not None
    assert len(docstring.meta) == 1

# Generated at 2022-06-23 17:03:01.501598
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.meta == []




# Generated at 2022-06-23 17:03:04.644620
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringmeta = DocstringMeta(["param"], "description")
    assert docstringmeta.args == ["param"]
    assert docstringmeta.description == "description"


# Generated at 2022-06-23 17:03:06.640105
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    foo = DocstringParam(
    args = [],
    description = '',
    arg_name = '',
    type_name = '',
    is_optional = False,
    default = '',)


# Generated at 2022-06-23 17:03:07.618288
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["a"], "b", "c")



# Generated at 2022-06-23 17:03:10.442163
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []

# Generated at 2022-06-23 17:03:12.449113
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"

# --------------------------------- Helper methods ---------------------------------

# Generated at 2022-06-23 17:03:16.153104
# Unit test for constructor of class Docstring
def test_Docstring():
    #Constructor with no args
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-23 17:03:17.887939
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("abc")

# Generated at 2022-06-23 17:03:19.219789
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(
        [], None, None
    )



# Generated at 2022-06-23 17:03:21.809174
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Check that the constructor works correctly."""
    DocstringParam(["a"], "b", "c", "d", True, "f")


# Generated at 2022-06-23 17:03:26.646657
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dr = DocstringReturns(['args'], "description", "type_name", True)
    assert dr.args == ['args']
    assert dr.description == "description"
    assert dr.type_name == "type_name"
    assert dr.is_generator == True
    assert dr.return_name == None


# Generated at 2022-06-23 17:03:37.012705
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(["param", "type", "name", "optional"], "description", "arg",
        "type_name", "is_optional", "default")
    assert d.args == ["param", "type", "name", "optional"], "DocstringParam constructor has error 1"
    assert d.description == "description", "DocstringParam constructor has error 2"
    assert d.arg_name == "arg", "DocstringParam constructor has error 3"
    assert d.type_name == "type_name", "DocstringParam constructor has error 4"
    assert d.is_optional == "is_optional", "DocstringParam constructor has error 5"
    assert d.default == "default", "DocstringParam constructor has error 6"


# Generated at 2022-06-23 17:03:41.102524
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    exp = DocstringDeprecated(
        args=['deprecated'], description=None, version=None
    )
    assert exp.args == ['deprecated']
    assert exp.description == None
    assert exp.version == None


# Generated at 2022-06-23 17:03:48.178316
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["a", "b"], None, "arg", "int", False, None)
    assert param.args == ["a", "b"]
    assert param.description is None
    assert param.arg_name == "arg"
    assert param.type_name == "int"
    assert param.is_optional == False
    assert param.default is None

test_DocstringParam()

# Generated at 2022-06-23 17:03:51.831234
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Oh no!")
    except ParseError as e:
        print("The error message is: {}".format(e))
        print("The error is of type {}".format(type(e)))


# Generated at 2022-06-23 17:04:03.178065
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [
        "",         # this is the input string
        ":",        # colons for separating args
        "param",    # first arg of argc
        "arg",      # second arg of argc
        ":",        # colons for separating args
        "type",     # optional arg for type name
        "Optional", # optional arg for Optional
        "=",        # optional arg for assigning default value
        "None",     # optional arg for None as default value
        ":",        # colons for separating args
        "this",     # the text after the last colon
        "is",
        "the",
        "docstring",
    ]

# Generated at 2022-06-23 17:04:12.346526
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # First test case
    args = ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = "parameter description"
    type_name = "string"
    
    docstringRaisesInstance = DocstringRaises(args, description, type_name)
    assert docstringRaisesInstance.args == args
    assert docstringRaisesInstance.description == description
    assert docstringRaisesInstance.type_name is not None
    assert docstringRaisesInstance.__str__() == "<DocstringRaises: args=['param', 'arg', 'argument', 'attribute', 'key', 'keyword'], description='parameter description', type_name='string'>"
    
    # Second test case
    args2 = ['raises', 'raise', 'except', 'exception']
    description2 = "description"


# Generated at 2022-06-23 17:04:19.750155
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(['args'], 'description', 'arg_name', 'type_name', False, 'default')
    assert docstring_param.args == ['args']
    assert docstring_param.description == 'description'
    assert docstring_param.arg_name == 'arg_name'
    assert docstring_param.type_name == 'type_name'
    assert not docstring_param.is_optional
    assert docstring_param.default == 'default'


# Generated at 2022-06-23 17:04:22.006180
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["version"], "desc")

# Generated at 2022-06-23 17:04:25.021380
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    def bar():
        """Docstring for function bar.

        :param arg: some arg
        """
        pass

# Generated at 2022-06-23 17:04:29.200909
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(['arg'], 'description', 'typename')
    assert doc.args[0] == 'arg'
    assert doc.description == 'description'
    assert doc.type_name == 'typename'
    return
test_DocstringRaises()



# Generated at 2022-06-23 17:04:31.966996
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('some error')
    except ParseError as e:
        assert str(e) == 'some error'


# Generated at 2022-06-23 17:04:36.925297
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_1 = DocstringRaises(["int"], "Desc", "int")
    assert docstring_raises_1.args == ["int"]
    assert docstring_raises_1.description == "Desc"
    assert docstring_raises_1.type_name == "int"
    assert isinstance(docstring_raises_1,DocstringMeta)



# Generated at 2022-06-23 17:04:40.994872
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["meta", "information"], "This is a test").args == ["meta", "information"]
    assert DocstringMeta(["meta", "information"], "This is a test").description == "This is a test"



# Generated at 2022-06-23 17:04:45.681678
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "This function is deprecated.", "0.0.1")
    assert d.args[0] == "deprecated"
    assert d.description == "This function is deprecated."
    assert d.version == "0.0.1"

# Generated at 2022-06-23 17:04:48.356443
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta([], "description")
    assert d.args == []
    assert d.description == "description"


if __name__ == "__main__":
    test_DocstringMeta()

# Generated at 2022-06-23 17:04:49.902019
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError('test message')

# Unit test of class DocstringMeta

# Generated at 2022-06-23 17:04:55.759030
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This is deprecated'
    version = '1.0.0'
    dd = DocstringDeprecated(args, description, version)
    assert dd.args[0] == 'deprecated'
    assert dd.description == description
    assert dd.version == version


# Generated at 2022-06-23 17:05:01.969841
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    my_arg = DocstringParam(['param'], 'description', 'arg', 'type', 'is_optional', 'default')
    assert my_arg.args == ['param']
    assert my_arg.description == 'description'
    assert my_arg.arg_name == 'arg'
    assert my_arg.type_name == 'type'
    assert my_arg.is_optional == 'is_optional'
    assert my_arg.default == 'default'


# Generated at 2022-06-23 17:05:04.111994
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(':param arg_name: arg_description', ':param arg_name: arg_description', 'arg_name', None, False, None)



# Generated at 2022-06-23 17:05:08.525542
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docStringDeprecated = DocstringDeprecated(["hello world"], "description", "version")
    assert docStringDeprecated.args == ["hello world"]
    assert docStringDeprecated.description == "description"
    assert docStringDeprecated.version == "version"


# Generated at 2022-06-23 17:05:15.160177
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta is not None
    assert len(ds.meta) == 0
    assert ds.params is not None
    assert len(ds.params) == 0
    assert ds.raises is not None
    assert len(ds.raises) == 0



# Generated at 2022-06-23 17:05:18.587919
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = None
    type_name = None
    test_var = DocstringRaises(args, description, type_name)
    assert test_var.args == []

# Generated at 2022-06-23 17:05:24.886724
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = "desc"
    type_name = "type"
    return_val = DocstringRaises(args, description, type_name)

    assert return_val.args == args
    assert return_val.description == description
    assert return_val.type_name == type_name


# Generated at 2022-06-23 17:05:34.491853
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_str = Docstring()
    assert doc_str.short_description is None
    assert doc_str.long_description is None
    assert doc_str.blank_after_short_description is False
    assert doc_str.blank_after_long_description is False
    assert doc_str.meta is not None
    assert len(doc_str.meta) == 0
    assert doc_str.params is not None
    assert len(doc_str.params) == 0
    assert doc_str.raises is not None
    assert len(doc_str.raises) == 0
    assert doc_str.returns is None
    assert doc_str.deprecation is None
