

# Generated at 2022-06-23 16:55:26.640908
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()


# Generated at 2022-06-23 16:55:34.513583
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(args=[':return'], description='Return value', type_name=['int'])
    assert docstring_returns.args == [':return']
    assert docstring_returns.description == 'Return value'
    assert docstring_returns.type_name == ['int']
    assert docstring_returns.is_generator == False


# Generated at 2022-06-23 16:55:38.268305
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(['a'], 'b', 'c')
    assert ds.args == ['a']
    assert ds.description == 'b'
    assert ds.version == 'c'


# Generated at 2022-06-23 16:55:41.220295
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring = DocstringMeta(['Testing'], 'TestingDoc')
    assert (docstring.args == ['Testing'])
    assert (docstring.description == 'TestingDoc')


# Generated at 2022-06-23 16:55:46.132620
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(["a","v"],"description","type")
    assert ds.args == ["a", "v"]
    assert ds.description == "description"
    assert ds.type_name == "type"


# Generated at 2022-06-23 16:55:48.023897
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError("testing")
    assert p.args[0] == "testing"


# Generated at 2022-06-23 16:55:50.527465
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError
    with pytest.raises(RuntimeError):
        raise ParseError('test')


# Generated at 2022-06-23 16:55:57.603953
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
  test_args = []
  test_description = 'Test description'
  test_type_name = 'Test type name'
  test_is_generator = False
  test_return_name = 'Test return name'
  assert DocstringReturns(test_args,test_description,test_type_name,test_is_generator,test_return_name).args == test_args
  assert DocstringReturns(test_args,test_description,test_type_name,test_is_generator,test_return_name).return_name == test_return_name
  assert DocstringReturns(test_args,test_description,test_type_name,test_is_generator,test_return_name).type_name == test_type_name

# Generated at 2022-06-23 16:55:58.206920
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(args=['arg'],description="description")
    assert a

# Generated at 2022-06-23 16:55:59.829332
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-23 16:56:01.013354
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    s = DocstringMeta(["test"], "test")
    assert s.args == ["test"]
    assert s.description == "test"


# Generated at 2022-06-23 16:56:04.852630
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_str = Docstring()
    assert not doc_str.short_description
    assert not doc_str.meta
    assert not doc_str.params
    assert not doc_str.deprecation
    assert not doc_str.raises
    assert not doc_str.returns


# Generated at 2022-06-23 16:56:08.385928
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(["raises"], "if you'r an idiot", "RuntimeError")


# Generated at 2022-06-23 16:56:09.995773
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises'], 'test', 'Exception')


# Generated at 2022-06-23 16:56:14.211015
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    newOne = DocstringRaises(['a', 'b'], "this is a test", 'c')
    assert newOne.args == ['a', 'b']
    assert newOne.description == "this is a test"
    assert newOne.type_name == 'c'


# Generated at 2022-06-23 16:56:19.955179
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-23 16:56:21.970243
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError


# Generated at 2022-06-23 16:56:25.310905
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["a", "b", "c"]
    description = "desc"
    type_name = "typename"
    dsr = DocstringRaises(args, description, type_name)
    assert dsr.args == args
    assert dsr.description == description
    assert dsr.type_name == type_name


# Generated at 2022-06-23 16:56:26.984537
# Unit test for constructor of class ParseError
def test_ParseError():
    """Constructor raises an Exception."""
    exception = ParseError("Testing")
    assert "Testing" in str(exception)


# Generated at 2022-06-23 16:56:39.098028
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    import pytest
    from hypothesis import given, strategies as st
    from hypothesis.strategies import composite

    @composite
    def docstring_str(draw) -> str:
        return draw(st.text(min_size=2, max_size=50))

    @given(docstring_str(), docstring_str())
    def test_docstring_meta(args: str, description: str) -> None:
        test1 = DocstringMeta(args, description)
        assert test1.args == args
        assert test1.description == description
    test_docstring_meta()

    with pytest.raises(TypeError):
        test2 = DocstringMeta("no", "success")

    with pytest.raises(TypeError):
        test3 = DocstringMeta(["no", "success"], "success")


# Generated at 2022-06-23 16:56:40.158465
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error message")
    except ParseError:
        pass


# Generated at 2022-06-23 16:56:43.928192
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'bla'
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description
    assert type(docstringMeta) == DocstringMeta


# Generated at 2022-06-23 16:56:48.936319
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    deprecated_test = DocstringDeprecated(["test"], "test description", "test version")
    assert deprecated_test.args == ["test"]
    assert deprecated_test.description == "test description"
    assert deprecated_test.version == "test version"


# Generated at 2022-06-23 16:56:55.483782
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc_ret = DocstringReturns(['returns'], 'A render_object', 'A render_object', False, "m")
    assert doc_ret.description == 'A render_object'
    assert doc_ret.type_name == "A render_object"
    assert doc_ret.is_generator == False
    assert doc_ret.return_name == "m"
    assert doc_ret.args == ['returns']


# Generated at 2022-06-23 16:56:59.073856
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises_var = DocstringRaises("args", "description", "type_name")
    assert DocstringRaises_var.args == "args"
    assert DocstringRaises_var.description == "description"
    assert DocstringRaises_var.type_name == "type_name"


# Generated at 2022-06-23 16:57:06.082947
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None



# Generated at 2022-06-23 16:57:14.522219
# Unit test for constructor of class Docstring
def test_Docstring():
  """
  Args:
    Docstring
  Returns:
    DocstringTest
  """
  d = Docstring()
  d.short_description = "Test short description"
  d.long_description = "Test long description"
  d.blank_after_short_description = True
  d.blank_after_long_description = True
  d.meta = ["ValueError"]
  #assert(d.short_description == "Test short description")
  #assert(d.long_description == "Test long description")
  #assert(d.blank_after_short_description == True)
  #assert(d.blank_after_long_description == True)
  #assert(d.meta == ["ValueError"])
  return d

test_Docstring()

# Generated at 2022-06-23 16:57:22.121682
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['a', 'b', 'c']
    description = 'None'
    type_name = 'None'
    is_generator = False

    docstring_returns = DocstringReturns(args, description, type_name, is_generator)

    assert docstring_returns.args == ['a', 'b', 'c']
    assert docstring_returns.description == 'None'
    assert docstring_returns.type_name == 'None'
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == None


# Generated at 2022-06-23 16:57:25.106370
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['deprecated'], 'test description', 'test version')
    assert doc.args == ['deprecated']
    assert doc.description == 'test description'
    assert doc.version == 'test version'


# Generated at 2022-06-23 16:57:30.525021
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # ~The following arguments are passed as a list of strings~
    args = ["return", "returns"]
    description = "the sum of x and y"
    type_name = "int"
    is_generator = False
    return_name = "return_value"

    # Creating an object of DocstringReturns
    testObject = DocstringReturns(
        args, description, type_name, is_generator, return_name
    )

    # Verifying the two arguments are of the correct type
    assert type(testObject.args) == list
    assert type(testObject.description) == str



# Generated at 2022-06-23 16:57:33.243125
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated([], "", "")
    assert isinstance(obj, DocstringDeprecated)


# Generated at 2022-06-23 16:57:37.318902
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:57:44.170689
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["a"], "b", "c", "d", "e")
    if a.args[0] == "a" and a.description == "b" and a.type_name == "c" and a.is_generator == "d" and a.return_name == "e":
        print("Pass")
    else:
        print("Fail")

if __name__ == "__main__":
    test_DocstringReturns()

# Generated at 2022-06-23 16:57:47.009218
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["a"], "b")
    assert dm.args == ["a"]
    assert dm.description == "b"



# Generated at 2022-06-23 16:57:51.229790
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["arg1", "arg2"], "description", "type_name")
    print (d.description)
    print (d.type_name)
    print (d.args)
    print (d.description)


# Generated at 2022-06-23 16:58:02.065712
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Test the case that the values of the 3 arguments are not None
    docstringRaises = DocstringRaises(["a"], "b", "c")
    assert docstringRaises.args == ["a"] and docstringRaises.description == "b" and docstringRaises.type_name == "c"
    # Test the case that the value of the 3rd argument is None
    docstringRaises = DocstringRaises(["a"], "b", None)
    assert docstringRaises.args == ["a"] and docstringRaises.description == "b" and docstringRaises.type_name == None


# Generated at 2022-06-23 16:58:03.133992
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    item=DocstringParam(["abc", "xyz"],"description", "arg_name", "type_name", None, None)
    assert item != None

# Generated at 2022-06-23 16:58:05.523863
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(args=[":param", "arg"], description="description", arg_name="arg", type_name="int", is_optional=False, default=None)

# Generated at 2022-06-23 16:58:11.783836
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # create instance of DocstringDeprecated
    test_Deprecated = DocstringDeprecated(['hello'], 'world', 'there')
    assert isinstance(test_Deprecated, DocstringDeprecated)
    assert test_Deprecated.description == "world"
    assert test_Deprecated.version == "there"


# Generated at 2022-06-23 16:58:22.199630
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_args = ['param', 'arg']
    test_description = 'This is a description of a DocstringParam object.'
    test_arg_name = 'arg'
    test_type_name = 'str'
    test_is_optional = True
    test_default = 'some string'
    testDocstringParam = DocstringParam(test_args, test_description, test_arg_name, test_type_name, test_is_optional, test_default)
    assert(testDocstringParam.args == ['param', 'arg'])
    assert(testDocstringParam.description == 'This is a description of a DocstringParam object.')
    assert(testDocstringParam.arg_name == 'arg')
    assert(testDocstringParam.type_name == 'str')

# Generated at 2022-06-23 16:58:27.319114
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit test for constructor of class DocstringMeta
    
    It tests whether the type of description is a string and the type of args is a list
    """
    arg_list = ['param', 'arg']
    description = 'arg description'
    docstring_meta = DocstringMeta(arg_list, description)
    assert isinstance(docstring_meta.description, str)
    assert isinstance(docstring_meta.args, list)    


# Generated at 2022-06-23 16:58:29.078655
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([], "hello world")
    assert a.args == []
    assert a.description == 'hello world'


# Generated at 2022-06-23 16:58:32.785742
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ob = DocstringMeta([], "")
    assert isinstance(ob, DocstringMeta)


# Generated at 2022-06-23 16:58:39.850782
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(args = ['yields', 'test', 'int'],
                          description = 'test description',
                          type_name = 'int',
                          is_generator = True,
                          return_name = 'test')
    assert ds.args == ['yields', 'test', 'int']
    assert ds.description == 'test description'
    assert ds.type_name == 'int'
    assert ds.is_generator == True
    assert ds.return_name == 'test'

# Generated at 2022-06-23 16:58:43.030250
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["P", "param"], "Description string.", "arg_name", "type_name", False, "default_value")



# Generated at 2022-06-23 16:58:47.410429
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises_1 = DocstringRaises(args=['param', 'keyword'], description='description', type_name='type_name')
    assert docstring_raises_1 is not None


# Generated at 2022-06-23 16:58:50.412390
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = None
    version = None
    docstringDeprecated = DocstringDeprecated(args, description, version)
    assert docstringDeprecated.args == args
    assert docstringDeprecated.description == description
    assert docstringDeprecated.version == version


# Generated at 2022-06-23 16:58:53.154517
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert (DocstringRaises(['param',"valueError","Error"], 'description', 'str'))



# Generated at 2022-06-23 16:59:00.029070
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert not d.blank_after_short_description
    assert not d.blank_after_long_description
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None



# Generated at 2022-06-23 16:59:00.777830
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test class."""
    ParseError(1)

# Generated at 2022-06-23 16:59:11.353309
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg"]
    description = "This is the description of the parameter"
    arg_name = "arg"
    type_name = "name"
    is_optional = True
    default = "somethign"
    ds = DocstringParam(
        args, description, arg_name, type_name, is_optional, default
    )
    assert args == ds.args
    assert description == ds.description
    assert arg_name == ds.arg_name
    assert type_name == ds.type_name
    assert is_optional == ds.is_optional
    assert default == ds.default


# Generated at 2022-06-23 16:59:17.432821
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg', 'description']
    description = 'description'
    dsmt = DocstringMeta(args, description)
    assert dsmt.args == args
    assert dsmt.description == description


# Generated at 2022-06-23 16:59:21.945370
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    testObj = DocstringDeprecated(["deprecated"], "Deprecated message", "9.9.9")
    assert testObj.args == ["deprecated"]
    assert testObj.description == "Deprecated message"
    assert testObj.version == "9.9.9"

# Generated at 2022-06-23 16:59:30.576898
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None
    return

# Generated at 2022-06-23 16:59:33.633313
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["arg"]
    description = "Test"
    version = "1.0"
    test = DocstringDeprecated(args, description, version)
    assert test.args == args
    assert test.description == description
    assert test.version == version



# Generated at 2022-06-23 16:59:45.193417
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args1 = ["deprecated", "version", "1.0"]
    desc1 = "this is the test description"
    version1 = "1.0"
    # test for correct metadata construction
    assert DocstringDeprecated(args1, desc1, version1).args == args1
    assert DocstringDeprecated(args1, desc1, version1).description == desc1
    assert DocstringDeprecated(args1, desc1, version1).version == version1
    # test for correct transformation of text to necessary type
    assert DocstringDeprecated(args1, desc1, "1.0").version == 1.0
    assert DocstringDeprecated(args1, desc1, 10).version == 10
    assert DocstringDeprecated(args1, desc1, "10").version == 10

# Generated at 2022-06-23 16:59:53.135884
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParamObj = DocstringParam(['arg'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert docstringParamObj.args == ['arg'], 'Docstring Parameter constructor not working'
    assert docstringParamObj.description == 'description', 'Docstring Parameter constructor not working'
    assert docstringParamObj.arg_name == 'arg_name', 'Docstring Parameter constructor not working'
    assert docstringParamObj.type_name == 'type_name', 'Docstring Parameter constructor not working'
    assert docstringParamObj.is_optional == 'is_optional', 'Docstring Parameter constructor not working'
    assert docstringParamObj.default == 'default', 'Docstring Parameter constructor not working'
    

# Generated at 2022-06-23 17:00:01.637677
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_title = ["toto"]
    description = "toto"
    type_name = "toto"
    docstringRaises = DocstringRaises(args_title, description, type_name)
    assert docstringRaises.args == args_title
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name
test_DocstringRaises()



# Generated at 2022-06-23 17:00:03.872957
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
  args = ["param", "arg", "description"]
  DocstringMeta(args, "arg")


# Generated at 2022-06-23 17:00:11.250197
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []



# Generated at 2022-06-23 17:00:13.232386
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(
        args=["raises", "ValueError", "if", "something"],
        description="something",
        type_name="ValueError"
    )

# Generated at 2022-06-23 17:00:16.504177
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["deprecated", "since", "1.0"], "description", "1.0")
    assert a.description == "description"
    assert a.version == "1.0"
    assert a.args == ["deprecated", "since", "1.0"]


# Generated at 2022-06-23 17:00:27.602311
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    args = ["arg1", "arg2", "arg3"]
    description = "my description"
    type_name = "int"
    return_name = "return_name"
    test_case = DocstringReturns(
        args, description, type_name, False, return_name
    )
    assert test_case.args == args
    assert test_case.description == description
    assert test_case.type_name == type_name
    assert test_case.is_generator == False
    assert test_case.return_name == return_name



# Generated at 2022-06-23 17:00:35.909070
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0
    assert len(docstring.params) == 0
    assert len(docstring.raises) == 0
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-23 17:00:36.936502
# Unit test for constructor of class Docstring
def test_Docstring():
    print(Docstring().params)


# Generated at 2022-06-23 17:00:40.168733
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["param"], "test", "int")
    print(test.type_name)



# Generated at 2022-06-23 17:00:42.463939
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError()

# Generated at 2022-06-23 17:00:46.860393
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert repr(DocstringMeta(["testarg"], "test description")) == "DocstringMeta(['testarg'], 'test description')"


# Generated at 2022-06-23 17:00:48.090831
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()


# Generated at 2022-06-23 17:00:52.072513
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "description"
    docstring = DocstringMeta(args, description)
    assert docstring.args == args
    assert docstring.description == description


# Generated at 2022-06-23 17:01:03.481886
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
  docstring_param1 = DocstringReturns(['returns'],"Test",None,False)
  docstring_param2 = DocstringReturns(['returns'],"Test",None,True)
  assert(docstring_param1.return_name == None)
  assert(docstring_param1.type_name == None)
  assert(docstring_param1.is_generator == False)

  assert(docstring_param2.return_name == None)
  assert(docstring_param2.type_name == None)
  assert(docstring_param2.is_generator == True)
#Test for getter params of Docstring

# Generated at 2022-06-23 17:01:11.529167
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test for the constructor of class DocstringMeta."""
    doc_string1 = DocstringMeta(["param"], "the arg1 is integer")
    assert doc_string1.args == ["param"]
    assert doc_string1.description == "the arg1 is integer"

    doc_string2 = DocstringMeta(["returns"], "the return is bool type")
    assert doc_string2.args == ["returns"]
    assert doc_string2.description == "the return is bool type"


# Generated at 2022-06-23 17:01:13.645217
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Method for testing the constructor for class DocstringDeprecated"""
    assert DocstringDeprecated(["deprecated"], "version 1.0")



# Generated at 2022-06-23 17:01:19.126349
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam(['one', 'two'], 'good', 'arg_name', 'int', None, None)
    assert docstringParam.args == ['one', 'two']
    assert docstringParam.description == 'good', 'description must be good'
    assert docstringParam.arg_name == 'arg_name', 'arg_name must be arg_name'
    assert docstringParam.type_name == 'int', 'type_name must be int'
    assert docstringParam.is_optional is None, 'is_optional must be None'
    assert docstringParam.default is None, 'default must be None'
    docstringParam = DocstringParam(['one', 'two'], 'good', 'arg_name', 'int', True, None)

# Generated at 2022-06-23 17:01:23.342411
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['deprecated'], 'hello', '1.0.0')
    assert doc.args == ['deprecated']
    assert doc.description == 'hello'
    assert doc.version == '1.0.0'


# Generated at 2022-06-23 17:01:29.201719
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert (
        docstring.short_description is None
        and docstring.long_description is None
        and docstring.blank_after_long_description is False
        and docstring.blank_after_short_description is False
        and docstring.meta == []
    )



# Generated at 2022-06-23 17:01:37.493712
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = None
    arg_name = "arg"
    type_name = None
    is_optional = True
    default = None
    
    docstring_param = DocstringParam(args, description, arg_name, type_name,
        is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default
    

# Generated at 2022-06-23 17:01:44.302688
# Unit test for constructor of class Docstring
def test_Docstring():
  d = Docstring()
  assert d.short_description is None
  assert d.long_description is None
  assert d.blank_after_short_description is False
  assert d.blank_after_long_description is False 
  assert d.meta == []
  assert d.params == []
  assert d.raises == []
  assert d.returns == None
  assert d.deprecation == None

# Generated at 2022-06-23 17:01:48.519739
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test for class ParseError."""
    assert issubclass(ParseError, RuntimeError)  # type: ignore
    assert ParseError.__init__ is RuntimeError.__init__  # type: ignore



# Generated at 2022-06-23 17:01:51.955360
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["parameter"], "description", "arg_name", "type_name", True, "def_val").__init__(["parameter"], "description", "arg_name", "type_name", True, "def_val")

# Generated at 2022-06-23 17:02:00.833080
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    args = ["param", "arg1", "arg2", "arg3"]
    description = "This is the description of the argument."
    type_name = "int"
    is_generator = True
    return_name = "value"
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert returns.args == args
    assert returns.description == description
    assert returns.type_name == type_name
    assert returns.is_generator == is_generator
    assert returns.return_name == return_name


# Generated at 2022-06-23 17:02:04.326638
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args=RAISES_KEYWORDS, description=":param arg: description", version="3")
    assert d.args == RAISES_KEYWORDS
    assert d.description == ":param arg: description"
    assert d.version == "3"


# Generated at 2022-06-23 17:02:07.120151
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(args=["deprecated"], description="test", version="1.0")
    assert doc.version == "1.0"
    assert doc.description == "test"


# Generated at 2022-06-23 17:02:11.501039
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    description = "description"
    type_name = "int"
    is_generator = False
    item = DocstringReturns(args,description,type_name,is_generator)
    assert item.args == args
    assert item.description == description
    assert item.type_name == type_name
    assert item.is_generator == is_generator


# Generated at 2022-06-23 17:02:14.759949
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(args='args', description='desc', version='version')
    assert (docstring.args == 'args' and docstring.description == 'desc' and docstring.version == 'version')



# Generated at 2022-06-23 17:02:24.950025
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "total"
    args = ["param", "parameter"]

    test_case = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_case is not None
    assert test_case.args == args
    assert test_case.description == description
    assert test_case.type_name == type_name
    assert test_case.is_generator == is_generator
    assert test_case.return_name == return_name


# Generated at 2022-06-23 17:02:30.790564
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None



# Generated at 2022-06-23 17:02:34.821005
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	assert hasattr(DocstringMeta, '__init__')
	assert callable(DocstringMeta.__init__)


# Generated at 2022-06-23 17:02:39.381742
# Unit test for constructor of class Docstring
def test_Docstring():
    actual = Docstring()
    assert actual
    assert actual.short_description == None
    assert actual.long_description == None
    assert actual.blank_after_short_description == False
    assert actual.blank_after_long_description == False
    assert actual.meta == []


# Generated at 2022-06-23 17:02:41.654653
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Test error')
    except ParseError as e:
        print(e)


# Generated at 2022-06-23 17:02:43.855839
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['A'], 'B', 'C', 'D', False, 'E')


# Generated at 2022-06-23 17:02:45.146783
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert isinstance(DocstringDeprecated(["para"], "desc"), DocstringDeprecated)

# Generated at 2022-06-23 17:02:48.802205
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args=None, description=None, arg_name=None, type_name=None, is_optional=None, default=None)


# Generated at 2022-06-23 17:02:55.770907
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	x=DocstringRaises(['raises', 'ValueError'], 'if something happens', 'ValueError')
	assert x.args == ['raises', 'ValueError'], 'Description of the error is not as mentioned'
	assert x.description == 'if something happens', 'Description of the error is not as mentioned'
	assert x.type_name == 'ValueError', 'Description of the error is not as mentioned'


# Generated at 2022-06-23 17:03:01.852246
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["test"]
    desc = "This is an implementation of DocstringMeta"
    test_DocstringMeta = DocstringMeta(args, desc)

    assert test_DocstringMeta.args == args
    assert test_DocstringMeta.description == desc


# Generated at 2022-06-23 17:03:06.798892
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["param"], "description", "arg", "str", True , "default")
    assert a.description == "description"
    assert a.arg_name == "arg"
    assert a.type_name == "str"
    assert a.is_optional == True
    assert a.default == "default"


# Generated at 2022-06-23 17:03:09.596204
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # test for init method
    docstring_param = DocstringParam(["_"], "", "_", "", "", "")
    assert docstring_param.args == ["_"]

# Generated at 2022-06-23 17:03:10.911447
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(args=None, description=None, version=None) is not None


# Generated at 2022-06-23 17:03:14.189984
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args=['a','b']
    description='Hey!'
    test=DocstringMeta(args,description)
    assert test.args[0]=='a'
    assert test.args[1]=='b'
    assert test.description=='Hey!'

# Generated at 2022-06-23 17:03:17.554211
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(
        args=['version'],
        description='version 1.0',
        version='1.0',
    )
    assert d.args == ['version']
    assert d.description == 'version 1.0'
    assert d.version == '1.0'



# Generated at 2022-06-23 17:03:26.395418
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args = ['param'], description = 'here is a string', arg_name = 'arg', type_name = 'str', is_optional = False, default = None)
    assert docstring_param.arg_name == 'arg'
    assert docstring_param.type_name == 'str'
    assert docstring_param.is_optional == False
    assert docstring_param.default == None
    assert docstring_param.description == 'here is a string'
    assert docstring_param.args == ['param']
    assert isinstance(docstring_param, DocstringMeta)


# Generated at 2022-06-23 17:03:28.154053
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated("","","")
    # expected result: does not throw error, not expecting any runtime error


# Generated at 2022-06-23 17:03:35.129213
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()
    assert x.short_description is None
    assert x.long_description is None
    assert x.blank_after_short_description is False
    assert x.blank_after_long_description is False
    assert x.meta == []
    assert x.params == []
    assert x.raises == []
    assert x.returns is None
    assert x.deprecation is None


# Generated at 2022-06-23 17:03:37.535707
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    type_name = None
    description = None
    assert DocstringRaises(RAISES_KEYWORDS, description, type_name) != None


# Generated at 2022-06-23 17:03:41.976340
# Unit test for constructor of class ParseError
def test_ParseError():
    e1 = ParseError()
    assert e1.args == ('',)
    e2 = ParseError('some message')
    assert e2.args == ('some message',)
    e2 = ParseError('')
    assert e2.args == ('',)

# Generated at 2022-06-23 17:03:54.316924
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['returns'], 'Return something', 'int')
    b = DocstringReturns(['yield'], 'Yield something', 'int')
    if (a.args[0] != 'returns'):
        print('test fail at DocstringReturns 1')
    elif (a.type_name != 'int'):
        print('test fail at DocstringReturns 2')
    elif (a.is_generator != False):
        print('test fail at DocstringReturns 3')
    elif (a.return_name != None):
        print('test fail at DocstringReturns 4')
    elif (b.args[0] != 'yield'):
        print('test fail at DocstringReturns 5')

# Generated at 2022-06-23 17:03:59.222972
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()

    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-23 17:04:06.573199
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    params = ["parameter"]
    description = "Description"
    type_name = "int"
    is_generator = False
    return_name = "retVal"
    
    returns_obj = DocstringReturns(params, description, type_name, is_generator, return_name)
    
    assert returns_obj.return_name == "retVal"
    assert returns_obj.description == "Description"
    assert returns_obj.type_name == "int"
    assert returns_obj.is_generator == False
    assert returns_obj.args == ["parameter"]

# Generated at 2022-06-23 17:04:10.861694
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        DocstringParam(
            args = ['a'],
            description = "a",
            arg_name = 'a',
            type_name = 'a',
            is_optional = True,
            default = True
        )
        return True
    except:
        return False

assert test_DocstringParam()

# Generated at 2022-06-23 17:04:14.772899
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], "description", 'type_name', False, "return_name")


# Generated at 2022-06-23 17:04:23.245297
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    b = DocstringRaises(["raises"], "if something happens", None)
    c = DocstringRaises(["raise", "ValueError"], None, None)
    d = DocstringRaises(["except", "ValueError"], "if something happens", None)
    e = DocstringRaises(["exception", "ValueError"], "if something happens", "ValueError")
    assert a.args == ["raises", "ValueError"]
    assert a.description == "if something happens"
    assert a.type_name == "ValueError"
    assert b.args == ["raises"]
    assert b.description == "if something happens"
    assert b.type_name is None

# Generated at 2022-06-23 17:04:24.507474
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    ds = DocstringMeta([''], '')
    assert ds.args == ['']
    assert ds.description == ''

# Generated at 2022-06-23 17:04:31.461800
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = 'testing keyword'
    type_name = 'int'
    is_generator = False
    return_name = None

    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.description == "testing keyword" and docstring_returns.type_name == "int" and docstring_returns.is_generator == False and docstring_returns.return_name == None


# Generated at 2022-06-23 17:04:34.777133
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(["returns"], "returns a string", "str")
    assert returns.args == ["returns"]
    assert returns.description == "returns a string"
    assert returns.type_name == "str"


# Generated at 2022-06-23 17:04:37.972016
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(['return'], None, 'int', False)
    assert docstring_returns.type_name is 'int'
    assert docstring_returns.is_generator is False
    assert docstring_returns.return_name is None

# Generated at 2022-06-23 17:04:41.209671
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dc1 = DocstringMeta(['param'], 'description')
    assert dc1.args == ['param']
    assert dc1.description == 'description'


# Unit tests for constructor of class DocstringParam

# Generated at 2022-06-23 17:04:45.184859
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """This function is a unit test for DocstringReturns.

    returns:
        an instance of DocstringReturns
    """
    assert isinstance(DocstringReturns([], "", ""),DocstringReturns)


# Generated at 2022-06-23 17:04:49.194325
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated("args", "description", "version")
    assert "args" == s.args, "The argument 'args' was modified"
    assert "description" == s.description, "The argument 'description' was modified"
    assert "version" == s.version, "The argument 'version' was modified"


# Generated at 2022-06-23 17:04:51.269012
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta([],'')
    dm1 = DocstringMeta(['args'], 'description')
    assert(dm.args == [])
    assert(dm.description == '')
    assert(dm1.args == ['args'])
    assert(dm1.description == 'description')


# Generated at 2022-06-23 17:04:57.267001
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated=DocstringDeprecated(['arg1','arg2'],'description','version')
    assert docstringDeprecated.description == 'description'
    assert docstringDeprecated.version == 'version'
    assert docstringDeprecated.args == ['arg1','arg2']



# Generated at 2022-06-23 17:05:06.152972
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    args = ["args"]
    description = "description"
    type_name = "type_name"
    is_generator = True

    # No return name
    docstring_returns = DocstringReturns(args,description,type_name,is_generator)

    assert isinstance(docstring_returns, DocstringReturns)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == None

    # With return name
    return_name = "return_name"
    docstring_returns = DocstringReturns(args,description,type_name,is_generator,return_name)

   

# Generated at 2022-06-23 17:05:08.988270
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(['args', 'description'], 'description')
    assert meta.args == ['args', 'description']
    assert meta.description == 'description'


# Generated at 2022-06-23 17:05:14.301457
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param"], "description", "arg_name", "type_name", False, "default")
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == False
    assert dp.default == "default"


# Generated at 2022-06-23 17:05:26.025427
# Unit test for constructor of class Docstring
def test_Docstring():
    short_description = "Short Description"
    long_description = "Long Description"
    docstring = Docstring()
    docstring.short_description = short_description
    docstring.long_description = long_description
    docstring.meta.append(DocstringParam(["parameter"], "Description", "arg", "int", True, "1"))
    docstring.meta.append(DocstringRaises(["raises"], "Description", "ValueError"))
    docstring.meta.append(DocstringReturns(["returns"], "Description", "int", False))
    docstring.meta.append(DocstringDeprecated(["deprecated"], "Description", "True"))
    assert docstring.short_description == short_description
    assert docstring.long_description == long_description
    assert docstring.params[0].default == "1"
   