

# Generated at 2022-06-23 16:55:32.007018
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("test")

# Generated at 2022-06-23 16:55:34.020023
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["add"]
    description = "description"
    meta = DocstringMeta(args, description)
    assert meta.args == args
    assert meta.description == description


# Generated at 2022-06-23 16:55:39.108099
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = False
    default = None
    a = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert a.args is args



# Generated at 2022-06-23 16:55:41.660668
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    Testing constructor for Docstring
    """
    doc=Docstring()
    print(doc)



# Generated at 2022-06-23 16:55:46.451888
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test.")
    except ParseError as exc:
        assert (
            str(exc)
            == "ParseError: Test."
        ), "ParseError constructor did not behave like expected"


# Generated at 2022-06-23 16:55:52.996538
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test 1
    meta1 = DocstringDeprecated(['deprecated'], 'No longer in use', 'version 1.0')
    assert meta1.args == ['deprecated']
    assert meta1.description == 'No longer in use'
    assert meta1.version == 'version 1.0'
    # Test 2
    meta2 = DocstringDeprecated(['deprecated'], None, None)
    assert meta2.args == ['deprecated']
    assert meta2.description == None
    assert meta2.version == None



# Generated at 2022-06-23 16:55:58.160552
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "A param for a function"
    test_doc_meta = DocstringMeta(args, description)
    assert test_doc_meta.args == args, "args is not the same"
    assert test_doc_meta.description == description, "description is not the same"

# Generated at 2022-06-23 16:56:01.600945
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dd = DocstringDeprecated(['args'], 'description', 'version')
    assert dd.args == ['args']
    assert dd.description == 'description'
    assert dd.version == 'version'

# Generated at 2022-06-23 16:56:03.141486
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert error.args[0] == 'RuntimeError'


# Generated at 2022-06-23 16:56:13.542307
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=['a','b','c'],
        description='description',
        arg_name='arg2',
        type_name='str',
        is_optional=False,
        default="default"
    )
    assert docstring_param.args == ['a','b','c']
    assert docstring_param.description == 'description'
    assert docstring_param.arg_name == 'arg2'
    assert docstring_param.type_name == 'str'
    assert docstring_param.is_optional == False
    assert docstring_param.default == "default"


# Generated at 2022-06-23 16:56:15.607352
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test with Exception as parameter
    try:
        raise ParseError('Bla')
    except ParseError:
        assert True


# Generated at 2022-06-23 16:56:20.901040
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises(['raises','ValueError','if','a','b','c'], 'should not raise ValueError','ValueError')
    assert raises.args == ['raises','ValueError','if','a','b','c']
    assert raises.description == 'should not raise ValueError'
    assert raises.type_name == 'ValueError'
    # Unit test for constructor of class DocstringReturns

# Generated at 2022-06-23 16:56:22.607534
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "description here", "version here") is DocstringDeprecated


# Generated at 2022-06-23 16:56:24.542199
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "")
    assert d.args == ["param"]
    assert d.description == ""


# Generated at 2022-06-23 16:56:27.843362
# Unit test for constructor of class ParseError
def test_ParseError():
    line_number = 42
    error_message = 'Test Error Message'
    with pytest.raises(ParseError) as excinfo:
        raise ParseError(line_number, error_message)
    assert excinfo.type == ParseError
    assert str(excinfo.value) == f'42: {error_message}'


# Generated at 2022-06-23 16:56:31.961985
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated([], "description", "version")
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-23 16:56:34.820622
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['t', 'a'], 'some string', 'some string', True, 'some string').type_name == 'some string'


# Generated at 2022-06-23 16:56:36.124331
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(["test"], "","test","test")
    x.args
    x.description
    x.type_name
    x.is_generator
    x.return_name

# Generated at 2022-06-23 16:56:40.307988
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc is not None
    assert isinstance(doc, Docstring)



# Generated at 2022-06-23 16:56:52.798970
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # In this test, we just want to make sure that nothing breaks when
    # we instantiate a class DocstringMeta in line 33
    args = ["param", "arg", "attribute", "key", "keyword"]
    description = "description"
    description2 = "description2"
    description3 = "description3"
    description4 = "description4"
    description5 = "description5"
    description6 = "description6"
    description7 = "description7"
    description8 = "description8"
    description9 = "description9"
    description10 = "description10"
    description11 = "description11"
    description12 = "description12"
    description13 = "description13"
    description14 = "description14"
    description15 = "description15"
    description16 = "description16"

# Generated at 2022-06-23 16:56:53.447882
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert 1==1

# Generated at 2022-06-23 16:56:58.141444
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test the constructor method of class DocstringRaises"""
    try:
        a = DocstringRaises(['raises', 'ValueError'], 'description', 'type')
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-23 16:57:07.834910
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    lst_args=["return"]
    description=""
    type_name=""
    is_generator=""
    return_name=""
    returns_test=DocstringReturns(lst_args,description,type_name,is_generator,return_name)
    assert returns_test.args == ["return"]
    assert returns_test.description == ""
    assert returns_test.type_name == ""
    assert returns_test.is_generator == ""
    assert returns_test.return_name == ""


# Generated at 2022-06-23 16:57:10.244725
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except Exception as err:
        assert isinstance(err,ParseError)

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 16:57:13.469764
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    instance = DocstringRaises(['a', 'b'], 'abc', 'abc')
    assert isinstance(instance, DocstringRaises)
    assert instance.args == ['a', 'b']
    assert instance.description == 'abc'
    assert instance.type_name == 'abc'


# Generated at 2022-06-23 16:57:16.160567
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)
    assert issubclass(ParseError, RuntimeError)
    assert isinstance(ParseError, type)


# Generated at 2022-06-23 16:57:22.155749
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args = ['deprecated', '1.2.3']
    test_description = 'this is a test of DocstringDeprecated'
    test_version = '1.2.3'
    testObj = DocstringDeprecated(test_args, test_description, test_version)
    # test the getter properties
    assert testObj.args == test_args
    assert testObj.description == test_description
    assert testObj.version == test_version


# Generated at 2022-06-23 16:57:27.684980
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['retornos']
    description = 'returns something'
    type_name = 'int'
    is_generator = True
    return_name = 'myReturn'
    test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name
    assert test.is_generator == is_generator
    assert test.return_name == return_name

# Generated at 2022-06-23 16:57:32.024904
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    import pytest
    args = "args"
    description = "description"
    docstringmeta = DocstringMeta(args, description)
    assert docstringmeta.args == "args"
    assert docstringmeta.description == "description"


# Generated at 2022-06-23 16:57:38.754418
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description is None
    assert test_docstring.long_description is None
    assert test_docstring.blank_after_short_description is False
    assert test_docstring.blank_after_long_description is False
    assert len(test_docstring.meta) == 0
    assert test_docstring.params == []
    assert test_docstring.raises == []
    assert test_docstring.returns is None
    assert test_docstring.deprecation is None

# Generated at 2022-06-23 16:57:41.470958
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("This is a test error")
    assert pe.args[0] == "This is a test error"


# Generated at 2022-06-23 16:57:43.100215
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    return


# Generated at 2022-06-23 16:57:44.647548
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta([], "")  # bla


# Generated at 2022-06-23 16:57:47.002752
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "description")
    assert d.args == ["param"]
    assert d.description == "description"


# Generated at 2022-06-23 16:57:49.971469
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["param"], "abc", "abc")
    print(a.type_name)



# Generated at 2022-06-23 16:57:58.023466
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    return1 = DocstringReturns(['Returns'], 'description', 'return_type', 'True')
    return2 = DocstringReturns(['Returns'], 'description', 'return_type', 'True', 'return_name')

    if (return1.args != ['Returns'])or(return1.description != 'description')or(return1.type_name != 'return_type')or(return1.is_generator != 'True')or(return1.return_name != None):
        raise Exception("Error in test_DocstringReturns")


# Generated at 2022-06-23 16:58:03.459050
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated"""
    args = [":param", "arg", "description"]
    description = "description"
    version = "version"
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version

# Generated at 2022-06-23 16:58:05.828301
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    def parse(args, description):
        return DocstringMeta(args, description)
    assert parse(["param"], "description").args == ["param"]


# Generated at 2022-06-23 16:58:08.720740
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError('msg')
    assert error.args == ('msg',)


# Generated at 2022-06-23 16:58:14.063720
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    check = DocstringReturns(args=['param'], description=None, type_name=None, is_generator = False, return_name = None)
    assert check.args == ['param']
    assert check.description == None
    assert check.type_name == None
    assert check.is_generator == False
    assert check.return_name == None
    
    

# Generated at 2022-06-23 16:58:17.306078
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args=[], description = "An exception to be raised", type_name="ValueError")


# Generated at 2022-06-23 16:58:25.241207
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test1 = DocstringReturns(["return", "returns"], "hey", "String", False)
    test1.args == ["return", "returns"]
    test1.description == "hey"
    test1.type_name == "String"
    test1.is_generator == False

    test2 = DocstringReturns(["return", "returns"], "hey", "String", True)
    test2.args == ["return", "returns"]
    test2.description == "hey"
    test2.type_name == "String"
    test2.is_generator == True


# Generated at 2022-06-23 16:58:29.198192
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = DocstringReturns(['a'], 'Return a + b', 'int', 'True', 'a')
    assert docstring.args == ['a']
    assert docstring.description == 'Return a + b'
    assert docstring.type_name == 'int'
    assert docstring.is_generator == True

# Generated at 2022-06-23 16:58:34.187057
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_obj = DocstringRaises(["what","the","hey"], "description", "type_name")
    assert test_obj.type_name == "type_name"


# Generated at 2022-06-23 16:58:35.316480
# Unit test for constructor of class ParseError
def test_ParseError():
    parseError = ParseError('Test')

# Generated at 2022-06-23 16:58:39.154616
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    description = "This is meta description"
    args = []
    meta = DocstringMeta(args, description)
    # test various attributes
    assert hasattr(meta, "args")
    assert hasattr(meta, "description")
    assert meta.args is args
    assert meta.description is description


# Generated at 2022-06-23 16:58:40.936302
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['a', 'b']
    description = 'c'
    d = DocstringMeta(args, description)
    assert d.args == ['a', 'b']
    assert d.description == 'c'


# Generated at 2022-06-23 16:58:43.214214
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc_obj = DocstringRaises(['raises'], 'error', 'ValueError')
    assert doc_obj.args == ['raises']
    assert doc_obj.description == 'error'
    assert doc_obj.type_name == 'ValueError'


# Generated at 2022-06-23 16:58:45.765323
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-23 16:58:48.496617
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('testing')
    assert(isinstance(err, ParseError))


# Generated at 2022-06-23 16:58:53.084824
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([], "", "")
    assert a.args == []
    assert a.description == ""
    assert a.type_name == ""

# Generated at 2022-06-23 16:58:59.234518
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(['param'], "description", "arg", "type", True, 'default')
    assert docstring.args == ['param']
    assert docstring.description == "description"
    assert docstring.arg_name == "arg"
    assert docstring.type_name == "type"
    assert docstring.is_optional == True
    assert docstring.default == 'default'


# Generated at 2022-06-23 16:59:10.240474
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "this is an optional description"
    type_name = "int"
    is_generator = True
    return_name = "my_return"
    return_test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert return_test.args == args
    assert return_test.description == description
    assert return_test.type_name == type_name
    assert return_test.is_generator == is_generator
    assert return_test.return_name == return_name

# Generated at 2022-06-23 16:59:16.732031
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_doc_obj = DocstringMeta(["x"], "")
    assert isinstance(test_doc_obj, DocstringMeta)
    assert test_doc_obj.args == ["x"]
    assert test_doc_obj.description == ""


# Generated at 2022-06-23 16:59:20.915263
# Unit test for constructor of class ParseError
def test_ParseError():
	print("test_ParseError")
	try:
		raise ParseError("test error")
		print("test success")
	except ParseError:
		print("test failed")


# Generated at 2022-06-23 16:59:23.303119
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([":"], "", "", "", "")

# Generated at 2022-06-23 16:59:29.200982
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring = DocstringReturns([], "Returns description", "bool", False, "")
    assert docstring.description == "Returns description"
    assert docstring.type_name == "bool"
    assert docstring.is_generator == False
    assert docstring.return_name =="return"

# Generated at 2022-06-23 16:59:36.694100
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    from typing import List, Optional
    args = ['param', 'arg_name', 'description']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = 1
    default = 'default'
    obj = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    print(type(obj.args))
    print(obj.arg_name)
    print(obj.type_name)
    print(obj.is_optional)
    print(obj.description)
    print(obj.default)


# Generated at 2022-06-23 16:59:43.282111
# Unit test for constructor of class Docstring
def test_Docstring():
    o = Docstring()
    print(o.short_description, o.long_description, o.blank_after_short_description, o.blank_after_long_description, o.meta)
    print(o.params, o.raises, o.deprecation)
test_Docstring()
#print(PARAM_KEYWORDS, RAISES_KEYWORDS, RETURNS_KEYWORDS, YIELDS_KEYWORDS)

# Generated at 2022-06-23 16:59:51.648075
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg', 'description']
    type_name = 'type'
    is_optional = True
    default = 'default'
    a = DocstringParam(args, type_name, is_optional, default)
    assert a.args == args
    assert a.type_name == type_name
    assert a.is_optional == is_optional
    assert a.default == default


# Generated at 2022-06-23 16:59:54.780052
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [1, "A", "3"]
    description = "Description of this function"
    type_name = "int"
    is_generator = False
    return_name = "return"
    dret = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(dret is not None)

# Generated at 2022-06-23 16:59:58.478314
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test = DocstringParam(['a', 'b'], 'test', 'a', 'b', False, 'c')
    assert test.args == ['a', 'b']
    assert test.description == 'test'
    assert test.arg_name == 'a'
    assert test.type_name == 'b'
    assert test.is_optional == False
    assert test.default == 'c'


# Generated at 2022-06-23 16:59:59.840733
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError('foo')

# Generated at 2022-06-23 17:00:07.077630
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    args = ["return", "returns"]
    description = "x"
    type_name = "int"
    is_generator = False
    return_name = "y"
    
    ans = DocstringReturns(args, description, type_name, is_generator, return_name)
    
    assert ans.type_name == "int"
    assert ans.is_generator == False
    assert ans.return_name == "y"
    assert ans.args == ["return", "returns"]
    assert ans.description == "x"



# Generated at 2022-06-23 17:00:14.599795
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    _args = ['param', 'arg', 'attribute', 'key']
    _description = "description"
    docstring_meta = DocstringMeta(_args, _description)
    assert docstring_meta.args == ['param', 'arg', 'attribute', 'key']
    assert docstring_meta.description == "description"


# Generated at 2022-06-23 17:00:16.005589
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a=DocstringMeta(["rutvij"], "rutvij")


# Generated at 2022-06-23 17:00:22.551027
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(
        args=["deprecated"],
        description="You should no longer use this function.",
        version="0.4.2",
    )
    assert isinstance(docstring_deprecated, DocstringDeprecated)


# Generated at 2022-06-23 17:00:29.810309
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_docstring_param = DocstringParam(
        ['param', 'x', ':', 'int', 'description'],
        'description',
        'x',
        'int',
        True,
        'None')
    assert test_docstring_param.args == ['param', 'x', ':', 'int', 'description']
    assert test_docstring_param.description == 'description'
    assert test_docstring_param.arg_name == 'x'
    assert test_docstring_param.type_name == 'int'
    assert test_docstring_param.is_optional
    assert test_docstring_param.default == 'None'


# Generated at 2022-06-23 17:00:36.988215
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert isinstance(doc.meta, list)
    assert len(doc.meta) == 0
    assert doc.params == []
    assert doc.raises == []
    assert doc.deprecation is None

# Generated at 2022-06-23 17:00:40.447901
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "this is a description")
    assert d.args == ["param"]
    assert d.description == "this is a description"



# Generated at 2022-06-23 17:00:51.065753
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert(DocstringDeprecated(["deprecated"], "example description", ["1.1"]).args != ["deprecated", "something else"])
    assert(DocstringDeprecated(["foo"], "example description", ["3.0"]).args != ["foo", "something else"])
    assert(DocstringDeprecated(["foo"], "example description", ["2.2"]).args != ["foo", "something else"])

if __name__ == "__main__":
    test_DocstringDeprecated()

# Generated at 2022-06-23 17:00:54.895698
# Unit test for constructor of class Docstring
def test_Docstring():
    s = Docstring()
    assert s.short_description is None
    assert s.long_description is None
    assert not s.blank_after_short_description
    assert not s.blank_after_long_description
    assert s.meta == []
    assert s.params == []
    assert s.raises == []
    assert s.returns is None
    assert s.deprecation is None


# Generated at 2022-06-23 17:01:00.020320
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['type_name', 'description']
    description = "description"
    type_name = "type_name"
    obj = DocstringRaises(args, description, type_name)
    assert obj.args == ['type_name', 'description']
    assert obj.description == "description"
    assert obj.type_name == "type_name"

# Generated at 2022-06-23 17:01:10.175622
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['args']
    description = 'description'
    type_name = 'type_name'
    is_generator = 'is_generator'
    return_name = 'return_name'
    test2 = DocstringReturns(args, description, type_name, is_generator, return_name)
    args = ['args']
    description = 'description'
    type_name = 'type_name'
    is_generator = 'is_generator'
    test3 = DocstringReturns(args, description, type_name, is_generator)
    assert test2.args == args
    assert test2.description == description
    assert test2.type_name == type_name
    assert test2.is_generator == is_generator
    assert test2.return_name == return_name

# Generated at 2022-06-23 17:01:15.886810
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(args=['arg'], description='descr', arg_name='arg',\
                           type_name='str', is_optional=False, default='null')
    assert param.__class__ == DocstringParam
    assert param.args == ['arg']
    assert param.description == 'descr'
    assert param.arg_name == 'arg'
    assert param.type_name == 'str'
    assert param.is_optional == False
    assert param.default == 'null'



# Generated at 2022-06-23 17:01:22.831618
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        assert DocstringRaises([1, 2, 3], 'abc').args==[1,2,3] and DocstringRaises([1, 2, 3], 'abc').description=='abc'
        print("DocstringRaises(args, description) Test passed.")
    except:
        print("DocstringRaises(args, description) Test failed.")


# Generated at 2022-06-23 17:01:28.784125
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['deprecation', 'parameter']
    description = "A description"
    type_name = 'type name'
    test = DocstringRaises(args, description, type_name)
    assert test.args == ['deprecation', 'parameter']
    assert test.description == "A description"
    assert test.type_name == 'type name'


# Generated at 2022-06-23 17:01:38.616615
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    line = ":returns: Test"
    words = line.split(":", 2)
    assert len(words) == 3, "invalid input: no : delimiter"
    args = words[1].split()
    assert len(args) == 1, "invalid input: incorrect number of arguments"
    assert args[0] in RETURNS_KEYWORDS, "invalid input: no return keyword"
    assert words[2] == "Test", "invalid input: incorrect description"
    return_name, type_name, description = _parse_returns(words[2])
    assert return_name == None, "invalid input: incorrect return name"
    assert type_name == None, "invalid input: incorrect type name"
    assert description == "Test", "invalid input: incorrect description"



# Generated at 2022-06-23 17:01:45.274787
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    import pytest

    with pytest.raises(TypeError) as err:
        # DocstringDeprecated takes 5 arguments (1 given)
        DocstringDeprecated(args="")

    assert "DocstringDeprecated" in str(err.value)
    assert "missing" in str(err.value)
    assert "4" in str(err.value)
    assert "given" in str(err.value)



# Generated at 2022-06-23 17:01:53.600714
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    version1 = "1"
    version2 = "2"
    description1 = "description1"
    description2 = "description2"
    args1 = {'param': 'param'}
    args2 = {'param': 'param'}

    # Create two different instances
    docstring_deprecated1 = DocstringDeprecated(args1, description1, version1)
    docstring_deprecated2 = DocstringDeprecated(args2, description2, version2)

    # Check if the two instances are different
    assert docstring_deprecated1 != docstring_deprecated2


# Generated at 2022-06-23 17:01:55.931001
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(
        args=["param", "arg"],
        description="description",
        version="version"
    )


# Generated at 2022-06-23 17:02:05.695116
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Initialize object docstring_param
    docstring_param = DocstringParam(
        ['param', 'arg', 'argument', 'attribute', 'key', 'keyword'], 'String representing the currency code.', 'currency', 'str', True, 'usd'
    )
    # Check if the inputs are assigned to the correct attributes
    assert docstring_param.args == ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    assert docstring_param.description == 'String representing the currency code.'
    assert docstring_param.arg_name == 'currency'
    assert docstring_param.type_name == 'str'
    assert docstring_param.is_optional == True
    assert docstring_param.default == 'usd'


# Generated at 2022-06-23 17:02:08.171353
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass

# Generated at 2022-06-23 17:02:08.909083
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], "", "i", "int", is_optional=False, default=None)

# Generated at 2022-06-23 17:02:09.405538
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-23 17:02:11.651075
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	test = DocstringMeta(['id','name'], "Path to the destination file.")
	#print(test.args)
	#print(test.description)

# test_DocstringMeta()


# Generated at 2022-06-23 17:02:12.961231
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    pass



# Generated at 2022-06-23 17:02:14.627569
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Some error")
    assert error.args == "Some error"


# Generated at 2022-06-23 17:02:18.609852
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "test"
    e = ParseError(msg)
    assert msg in str(e)


# Generated at 2022-06-23 17:02:20.513818
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(args=[], description="a").description == "a"


# Generated at 2022-06-23 17:02:23.909627
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test message")
    except ParseError as e:
        assert e.args[0] == "Test message"

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 17:02:26.927709
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test that Docstring constructor doesn't throw any exception"""
    try:
        Docstring()
    except Exception:
        assert False


# Generated at 2022-06-23 17:02:28.610362
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Test")
    assert err.args[0] == "Test"

# Generated at 2022-06-23 17:02:30.007411
# Unit test for constructor of class ParseError
def test_ParseError():
    p = ParseError()
    assert isinstance(p, ParseError)

# Generated at 2022-06-23 17:02:42.737311
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg","attribute"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    args_test = docstring.args
    description_test = docstring.description
    arg_name_test = docstring.arg_name
    type_name_test = type_name
    is_optional_test = docstring.is_optional
    default_test = docstring.default
    assert args_test == args
    assert description_test == description
    assert arg_name_test == arg_name
    assert type_name_test == type_name

# Generated at 2022-06-23 17:02:45.740182
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['raises', 'asset not found'], 'Asset not found', "AssetNotFound")
    assert isinstance(docstringRaises, DocstringRaises)


# Generated at 2022-06-23 17:02:57.733721
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args=["deprecated"]
    description="This is a test"
    version="1.0"
    test_instance=DocstringDeprecated(args,description,version)
    assert isinstance(test_instance, DocstringDeprecated), 'test_instance should be an instance of DocstringDeprecated.'
    assert test_instance.args==args, 'test_instance.args is not assigned to args.'
    assert test_instance.description==description, 'test_instance.description is not assigned to description.'
    assert test_instance.version==version, 'test_instance.version is not assigned to version.'
    assert test_instance.args==test_instance.args, 'test_instance.args is not equal to .args.'
    assert test_instance.description==test_instance.description, 'test_instance.description is not equal to .description.'
    assert test

# Generated at 2022-06-23 17:03:03.813977
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-23 17:03:06.360918
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(args=[],
                     description="abc",
                     type_name="abc",
                     is_generator=True,
                     return_name=None)

# Generated at 2022-06-23 17:03:07.555462
# Unit test for constructor of class ParseError
def test_ParseError():
    a = ParseError("ttt")
    assert(a.args == "ttt")


# Generated at 2022-06-23 17:03:09.124786
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    with pytest.raises(ParseError):
        raise ParseError



# Generated at 2022-06-23 17:03:13.389392
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test the DocstringDeprecated class"""
    # with default param
    d = DocstringDeprecated(["since"], "description")
    assert d.description == "description"
    assert d.version is None
    # without default param
    d = DocstringDeprecated(["since", "1.4"], "description")
    assert d.description == "description"
    assert d.version == "1.4"


# Generated at 2022-06-23 17:03:24.450727
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    l=[]
    l.append("a")
    l.append("b")
    l.append("c")
    l.append("d")
    l.append("e")
    l.append("f")
    l.append("g")
    l.append("h")
    l.append("i")
    l.append("j")
    l.append("k")
    l.append("l")
    l.append("w")
    l.append("r")
    l.append("s")
    l.append("t")
    l.append("y")
    l.append("u")
    l.append("0")
    l.append("1")
    l.append("2")
    l.append("3")
    l.append("4")
    l.append("5")
    l

# Generated at 2022-06-23 17:03:35.809908
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    params = []

    # Test when argument passed is a parameter
    params.append(DocstringParam(["param"], "some description", "some param", "SomeType", True, "default value"))

    # Test when argument passed is an argument
    params.append(DocstringParam(["argument"], "some description", "some param", "SomeType", True, "default value"))

    # Test when argument passed is an arg
    params.append(DocstringParam(["arg"], "some description", "some param", "SomeType", True, "default value"))

    # Test when argument passed is an attribute
    params.append(DocstringParam(["attribute"], "some description", "some param", "SomeType", True, "default value"))

    # Test when argument passed is a keyword

# Generated at 2022-06-23 17:03:37.833314
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta("test", "test")
    assert meta.args == ["test"] and meta.description == "test"


# Generated at 2022-06-23 17:03:39.328501
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert isinstance(ds, Docstring)



# Generated at 2022-06-23 17:03:45.845581
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
	description = 'description'
	typename = 'int'
	r = DocstringRaises(args,description,typename)
	assert r.args == args
	assert r.description == description
	assert r.type_name == typename


# Generated at 2022-06-23 17:03:49.093254
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args= [], description=None, version=None)
    assert a.args == []
    assert a.description == None
    assert a.version == None


# Generated at 2022-06-23 17:03:54.705682
# Unit test for constructor of class Docstring
def test_Docstring():
    # Test the constructor
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []

    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None


# Generated at 2022-06-23 17:03:56.788927
# Unit test for constructor of class ParseError
def test_ParseError():
    foo = ParseError('bar')
    foo.args
    str(foo)

# Generated at 2022-06-23 17:04:02.640833
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['args']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = None
    a = DocstringReturns(args, description, type_name, is_generator)
    assert a.args == ['args']
    assert a.description == 'description'
    assert a.type_name == 'type_name'
    assert a.is_generator == True
    assert a.return_name == None
    return_name = 'return_name'
    b = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert b.args == ['args']
    assert b.description == 'description'
    assert b.type_name == 'type_name'
    assert b.is_generator == True

# Generated at 2022-06-23 17:04:06.279999
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert not docstring.short_description
    assert not docstring.long_description
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert not docstring.meta


# Generated at 2022-06-23 17:04:09.552993
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Run tests for constructor of class DocstringMeta."""

    dm = DocstringMeta(['param'], 'description')
    assert dm.args == ['param']
    assert dm.description == 'description'



# Generated at 2022-06-23 17:04:16.225949
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_str_deprecated = DocstringDeprecated(["deprecated", "deprecate"], "Please Use A", "3.0")
    assert doc_str_deprecated.args == ["deprecated", "deprecate"]
    assert doc_str_deprecated.description == "Please Use A"
    assert doc_str_deprecated.version  == "3.0"


# Generated at 2022-06-23 17:04:18.455578
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Simple test for class DocstringMeta."""
    DocstringMeta(args=['arg'], description='description')


# Generated at 2022-06-23 17:04:24.426206
# Unit test for constructor of class Docstring
def test_Docstring():
    test_docstring = Docstring()
    assert test_docstring.short_description is None
    assert test_docstring.long_description is None
    assert test_docstring.blank_after_short_description is False
    assert test_docstring.blank_after_long_description is False
    assert test_docstring.meta == []


# Generated at 2022-06-23 17:04:29.246146
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [":returns"]
    a = DocstringReturns(args, "this is the description", "s", False)
    assert a.args == [":returns"]
    assert a.description == "this is the description"
    assert a.type_name == "s"
    assert a.is_generator is False


# Generated at 2022-06-23 17:04:32.017957
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecate"], "Deprecate this", "1.0")
    assert docstring.long_description == "Deprecate this"
    assert docstring.short_description == "Deprecate this"

# Generated at 2022-06-23 17:04:33.178798
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None


# Generated at 2022-06-23 17:04:38.691092
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test case 1
    try:
        raise ParseError()
    except ParseError as err:
        assert err.args == tuple()
    # Test case 2
    try:
        raise ParseError(10)
    except ParseError as err:
        assert err.args == (10,)
    # Test case 3
    try:
        raise ParseError(1,2,3)
    except ParseError as err:
        assert err.args == (1,2,3)


# Generated at 2022-06-23 17:04:40.000269
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([], None, None, None, None, None)

# Generated at 2022-06-23 17:04:44.722079
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['args', 'description', 'type_name'], True, 'HelloWorld')
    assert d.args == ['args', 'description', 'type_name']
    assert d.description == True
    assert d.type_name == 'HelloWorld'

# Generated at 2022-06-23 17:04:46.396037
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert isinstance(DocstringMeta, object), "DocstringMeta is not an object"
    
    

# Generated at 2022-06-23 17:04:48.356129
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert isinstance(DocstringRaises(args=["a"],
        description="description", type_name="A"), DocstringRaises)


# Generated at 2022-06-23 17:04:51.467211
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    metadata = DocstringRaises(args = ['raises', 'BlankValueError'], description = 'This is raised if a given string is blank.', type_name = None)
    assert metadata.args == ['raises', 'BlankValueError']
    assert metadata.description == 'This is raised if a given string is blank.'
    assert metadata.type_name == None


# Generated at 2022-06-23 17:04:53.283577
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc1 = DocstringMeta(['param'], 'short description')
    assert str(doc1.args) == str(['param'])
    assert doc1.description == 'short description'


# Generated at 2022-06-23 17:04:56.864305
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        DocstringReturns(["param"], None, None, False)
    except TypeError:
        return True
    except:
        return False


# Generated at 2022-06-23 17:04:59.204984
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    x = DocstringMeta(args, description)
    assert x.args == args
    assert x.description == description


# Generated at 2022-06-23 17:05:00.588051
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("Hello World")


# Generated at 2022-06-23 17:05:04.446836
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Set up for test
    args = ["param", "arg", "name", "type", "default"]
    description = "description"
    
    # Now test
    actual = DocstringMeta(args, description)
    # Check actual values
    assert actual.args[0] == args[0]
    assert actual.description == description


# Generated at 2022-06-23 17:05:07.633821
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(args=["arg"], description="description")
    assert meta.args == ["arg"]
    assert meta.description == "description"


# Generated at 2022-06-23 17:05:09.484925
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(args=['param', 'foo'], description='This is a foo parameter.')
    assert meta.args == ['param', 'foo']
    assert meta.description == 'This is a foo parameter.'



# Generated at 2022-06-23 17:05:11.130831
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()

# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-23 17:05:12.510444
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    my_var = DocstringDeprecated(['deprecated'], '', '')
    assert my_var


# Generated at 2022-06-23 17:05:14.421023
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError.__doc__ is not None
    with pytest.raises(RuntimeError):
        raise ParseError()


# Generated at 2022-06-23 17:05:18.363426
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("")
    except ParseError as err:
        assert issubclass(err.__class__, ParseError)
        assert type(err) == ParseError



# Generated at 2022-06-23 17:05:21.305580
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated.__init__ in DocstringDeprecated.__init__.__annotations__, "DocstringDeprecated __init__ should have type annotations"


# Generated at 2022-06-23 17:05:27.021884
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['arg'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')

    assert(a.arg_name == 'arg_name')
    assert(a.description == 'description')
    assert(a.type_name == 'type_name')
    assert(a.is_optional == 'is_optional')
    assert(a.default == 'default')


# Generated at 2022-06-23 17:05:35.741366
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(['param', 'arg', 'argument', 'attribute', 'key', 'keyword'], "description"
    , "arg_name", "type_name", "is_optional", "default")
    assert dp.args == ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == "is_optional"
    assert dp.default == "default"
