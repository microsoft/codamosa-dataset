

# Generated at 2022-06-23 16:55:29.706511
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    def test():
        a = DocstringReturns(args=[], description=None, type_name="None", is_generator=False, return_name=None)

# Generated at 2022-06-23 16:55:33.176247
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []



# Generated at 2022-06-23 16:55:34.781424
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], "", "1.0")


# Generated at 2022-06-23 16:55:39.413477
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword'],
                                'docstring description',
                                'arg_name',
                                'type_name',
                                'is_optional',
                                'default')


# Generated at 2022-06-23 16:55:41.502765
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['arg', 'description']
    DocstringParam(args,None,None,None,None,None)


# Generated at 2022-06-23 16:55:44.468845
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['arg'], 'description').args == ['arg']
    assert DocstringMeta(['arg'], 'description').description == 'description'

# Generated at 2022-06-23 16:55:48.669522
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["raises"], "description", "type_name")
    assert d.description == "description" and d.type_name == "type_name"
    assert d.args == ["raises"]


# Generated at 2022-06-23 16:55:51.762645
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    
    def_rep = DocstringDeprecated(['1'], 'Deprecation', '1')
    assert def_rep.args == ['1']
    assert def_rep.description == 'Deprecation'


# Generated at 2022-06-23 16:55:52.662847
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()


# Generated at 2022-06-23 16:55:53.946373
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # TODO: write unit test
    raise NotImplementedError()


# Generated at 2022-06-23 16:55:57.544918
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(args=[], description="", arg_name="", type_name=None,
                         is_optional=None, default=None)
    assert obj is not None

# Generated at 2022-06-23 16:56:02.529873
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = "description"
    type_name = "ValueError"
    d = DocstringRaises(args, description, type_name)

    # test attributes
    assert d.args == args
    assert d.description == description
    assert d.type_name == type_name



# Generated at 2022-06-23 16:56:07.056588
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_meta = DocstringMeta(["a","b"], "This is a test")
    assert doc_meta.args == ["a","b"]
    assert doc_meta.description == "This is a test"


# Generated at 2022-06-23 16:56:10.112287
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "Exception message"
    try:
        raise ParseError(msg)
    except ParseError as e:
        assert e.args[0] == msg

# Generated at 2022-06-23 16:56:14.330503
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a=DocstringParam(1,1,1,1,1,1)



# Generated at 2022-06-23 16:56:19.064409
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param"]
    description = 'This is a description of the metadata item'
    version = '9.9.9'
    doc = DocstringDeprecated(args, description, version)
    #assert doc.args == args
    #assert doc.description == description
    #assert doc.version == version
    assert doc is not None
test_DocstringDeprecated()


# Generated at 2022-06-23 16:56:21.949157
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["a","b"],"a", "b")
    assert a.args == ["a","b"]
    assert a.description == "a"
    assert a.type_name == "b"


# Generated at 2022-06-23 16:56:25.007610
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []
# End of unit test


# Generated at 2022-06-23 16:56:28.721858
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstr = DocstringParam(['param', 'x'], 'the first arg', 'x', 'int',  True, '0')
    assert docstr.args == ['param', 'x']

    assert docstr.description == 'the first arg'

    assert docstr.arg_name == 'x'

    assert docstr.type_name == 'int'

    assert docstr.is_optional == True

    assert docstr.default == '0'


# Generated at 2022-06-23 16:56:31.080398
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of class Docstring."""
    test = Docstring()
    assert test.short_description is None
    assert test.long_description is None
    assert test.blank_after_short_description is False
    assert test.blank_after_long_description is False
    assert test.meta == []



# Generated at 2022-06-23 16:56:35.022959
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_dep = DocstringDeprecated(["Deprecated"], None, "1.0")
    assert doc_dep.args == ["Deprecated"]
    assert doc_dep.description == None
    assert doc_dep.version == "1.0"

# Generated at 2022-06-23 16:56:39.994469
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    obj = Docstring()
    assert(obj.short_description == None)
    assert(obj.long_description == None)
    assert(obj.blank_after_short_description == False)
    assert(obj.blank_after_long_description == False)
    assert(obj.meta == [])

test_Docstring()


# Generated at 2022-06-23 16:56:42.302545
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises", "error", "on", "invalid", "data"], "this is the expected behavior", None)



# Generated at 2022-06-23 16:56:45.935511
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # DocstringMeta object
    test_DocstringMeta_1 = DocstringMeta(["param"], "description")
    # Check is the value is assigned correctly
    assert test_DocstringMeta_1.args == ["param"]
    assert test_DocstringMeta_1.description == "description"



# Generated at 2022-06-23 16:56:49.031124
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["a"], "b")
    assert a.args == ["a"]
    assert a.description == "b"



# Generated at 2022-06-23 16:56:52.799072
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(args=["param"], description="descr", version="1.0")
    assert meta.args == ["param"]
    assert meta.description == "descr"
    assert meta.version == "1.0"



# Generated at 2022-06-23 16:56:57.905849
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-23 16:57:04.657752
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x=DocstringReturns([],None,None,True,None)
    y=DocstringReturns(['raises'],None,None,True,None)
    assert x.description is None
    assert x.type_name is None
    assert y.description is None
    assert y.type_name is None


# Generated at 2022-06-23 16:57:13.795330
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(args=[':param'],
                       description='description',
                       arg_name='arg_name',
                       type_name='type_name',
                       is_optional=True,
                       default='default')
    assert(d.args == [':param'])
    assert(d.description == 'description')
    assert(d.arg_name == 'arg_name')
    assert(d.type_name == 'type_name')
    assert(d.is_optional == True)
    assert(d.default == 'default')


# Generated at 2022-06-23 16:57:15.733250
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # docstring_meta = DocstringMeta("args", "description")
    assert False


# Generated at 2022-06-23 16:57:21.095089
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_DocstringDeprecated = DocstringDeprecated([':deprecated:', 'since 1.2.3'],
                                  'description', '1.2.3')
    assert test_DocstringDeprecated.args == [':deprecated:', 'since 1.2.3']
    assert test_DocstringDeprecated.description == 'description'
    assert test_DocstringDeprecated.version == '1.2.3'


# Generated at 2022-06-23 16:57:25.189002
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises."""
    docstring_raises = DocstringRaises(["raises"], "", "ValueError")
    assert docstring_raises.args == ["raises"]
    assert docstring_raises.description == ""
    assert docstring_raises.type_name == "ValueError"


# Generated at 2022-06-23 16:57:31.877748
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg"]
    description = "This is a description."
    type_name = "TypeName"
    item = DocstringRaises(args, description, type_name)
    assert item.args == args
    assert item.description == description
    assert item.type_name == type_name
    
test_DocstringRaises()


# Generated at 2022-06-23 16:57:33.038177
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "name"]
    pass

# Generated at 2022-06-23 16:57:39.969069
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring()
    docstr.short_description = "hello"
    docstr.long_description = "not again"
    docstr.blank_after_short_description = True
    docstr.blank_after_long_description = True
    docstr.meta = [DocstringMeta(["param"], "here")]
    assert docstr.short_description == "hello" and docstr.long_description == "not again" and docstr.blank_after_short_description == True and docstr.blank_after_long_description == True and docstr.meta == [DocstringMeta(["param"], "here")]

# Generated at 2022-06-23 16:57:44.961517
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    sample_DocstringMeta = DocstringMeta(args = ['kjs'], description = "test")
    if sample_DocstringMeta.args == ['kjs']:
        if sample_DocstringMeta.description == "test":
            print("DocstringMeta constructor works!")


# Generated at 2022-06-23 16:57:46.903364
# Unit test for constructor of class ParseError
def test_ParseError():
    msg = "sample message"
    e = ParseError(msg)
    assert e == msg



# Generated at 2022-06-23 16:57:49.856281
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    msg = "DocstringParam.__init__() not yet implemented"
    raise NotImplementedError(msg)


# Generated at 2022-06-23 16:57:53.385926
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "because we want to", "2.0.0")
    assert d.args == ["deprecated"]
    assert d.description == "because we want to"
    assert d.version == "2.0.0"


# Generated at 2022-06-23 16:57:59.020544
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dcp = DocstringReturns(["a"], "b", "c", False)
    assert dcp.description == "b"
    assert dcp.type_name == "c"
    assert dcp.is_generator == False

# Generated at 2022-06-23 16:58:02.860411
# Unit test for constructor of class Docstring
def test_Docstring():
    exxpected_short_description = "Hello world"
    exxpected_long_description = "This is a very long doc string."
    exxpected_blank_after_short_description = False
    exxpected_blank_after_long_description = False
    exxpected_meta = []

    docstring = Docstring()
    assert docstring.short_description == exxpected_short_description
    assert docstring.long_description == exxpected_long_description
    assert docstring.blank_after_short_description == exxpected_blank_after_short_description
    assert docstring.blank_after_long_description == exxpected_blank_after_long_description
    assert docstring.meta == exxpected_meta


# Generated at 2022-06-23 16:58:06.277878
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_docstring = DocstringDeprecated(["param"], "description", "version")
    assert test_docstring.args == ["param"]
    assert test_docstring.description == "description"
    assert test_docstring.version == "version"



# Generated at 2022-06-23 16:58:08.584354
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["raises"]
    description = "if something happens"
    type_name = "ValueError"
    is_generator = False
    return_name = None
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert returns.args == args
    assert returns.description == description
    assert returns.type_name == type_name
    assert returns.is_generator == is_generator
    assert returns.return_name == return_name


# Generated at 2022-06-23 16:58:12.332433
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    d = DocstringDeprecated(args, 'description', 'version')
    assert d.args == args
    assert d.description == 'description'
    assert d.version == 'version'

# Generated at 2022-06-23 16:58:14.671551
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error description")
    except ParseError as err:
        assert err.args[0] == "Error description"



# Generated at 2022-06-23 16:58:19.329135
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except RuntimeError as err:
        if __name__ == '__main__':
            print(err)
        else:
            print(err)
            raise


# Generated at 2022-06-23 16:58:22.547816
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    object = DocstringDeprecated("args", "description", "version")
    assert object.args == "args"
    assert object.description == "description"
    assert object.version == "version"


# Generated at 2022-06-23 16:58:26.671240
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(['param'], "", "arg", None, False, None)
    print(obj.args)
    print(obj.description)
    print(obj.arg_name)
    print(obj.type_name)
    print(obj.is_optional)
    print(obj.default)

# Generated at 2022-06-23 16:58:28.421528
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param", "arg"], "description") is not None


# Generated at 2022-06-23 16:58:30.337348
# Unit test for constructor of class Docstring
def test_Docstring():
    object_ = Docstring()
    assert object_ != None


# Generated at 2022-06-23 16:58:33.302224
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert(str(e) == "")


# Generated at 2022-06-23 16:58:37.868076
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(['a'], 'foo', 'bar')
    assert docstringRaises.args == ['a']
    assert docstringRaises.description == 'foo'
    assert docstringRaises.type_name == 'bar'

test_DocstringRaises()

# Generated at 2022-06-23 16:58:42.028390
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(args=['a','b'],description='description')
    dm.args


# Generated at 2022-06-23 16:58:44.644619
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass


# Generated at 2022-06-23 16:58:52.938557
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    is_generator = True
    type_name = None
    arg = "returns"
    return_name = None
    description = "test"
    args = [arg]
    docstring_return = DocstringReturns(args=args, description=description, type_name=type_name,
                                        is_generator=is_generator, return_name=return_name)

    assert docstring_return.args == args
    assert docstring_return.description == description
    assert docstring_return.type_name == type_name
    assert docstring_return.is_generator == is_generator
    assert docstring_return.return_name == return_name


# Generated at 2022-06-23 16:58:56.087958
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test if docstring returns works correctly."""
    DocstringReturns(["returns", "yield"], "some description", "some type", "some generator")



# Generated at 2022-06-23 16:58:58.731343
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("Test")
    assert pe.args == ("Test",)


# Generated at 2022-06-23 16:59:00.355330
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], [], [])

# Generated at 2022-06-23 16:59:04.619556
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam([], '', 'arg_name', 'type_name', True, 'default')
    assert param.args == []
    assert param.description == ''
    assert param.arg_name == 'arg_name'
    assert param.type_name == 'type_name'
    assert param.is_optional == True
    assert param.default == 'default'


# Generated at 2022-06-23 16:59:10.507730
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Arguments
    # Arguments
    arguments = []
    # Arguments
    arguments.append(['param', 'arg'])
    arguments.append(['parameter', 'arg'])
    arguments.append(['arg', 'arg'])
    arguments.append(['argument', 'arg'])
    arguments.append(['attribute', 'arg'])
    arguments.append(['key', 'arg'])
    arguments.append(['keyword', 'arg'])
    # Description
    description = []
    description.append('description')
    description.append('')
    description.append(None)
    # arg_name
    arg_name = []
    arg_name.append('name')
    arg_name.append('')
    arg_name.append(None)
    # type_name
    type_name

# Generated at 2022-06-23 16:59:18.421431
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    assert a.args == ["raises", "ValueError"]
    assert a.description == "if something happens"
    assert a.type_name == "ValueError"

# also this should test the constructor of class DocstringMeta

# Generated at 2022-06-23 16:59:22.684852
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """
    A function to test __init__ function of the class DocstringRaises
    :return: pass or fail
    """
    args = ["key1", "key2"]
    description = "This is a description."
    typeName = "A Type"
    # obj = DocstringRaises(args, description, typeName)

    assert isinstance(DocstringRaises(args, description, typeName), DocstringRaises)
    return "pass"


# if __name__ == "__main__":
#     print(test_DocstringRaises())

# Generated at 2022-06-23 16:59:30.788677
# Unit test for constructor of class Docstring
def test_Docstring():
    test = Docstring()
    assert test.short_description is None 
    assert test.blank_after_short_description == False
    assert test.blank_after_long_description == False
    assert test.meta == []
    assert test.params == []
    assert test.raises == []
    assert test.returns is None
    assert test.deprecation is None
    return 0

# Generated at 2022-06-23 16:59:33.158069
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args=['param'], description="Description for an argument", arg_name="arg", type_name="type", is_optional=True, default="0")


# Generated at 2022-06-23 16:59:36.207197
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    s = DocstringDeprecated(
        args=['args'], description=None, version=None
    )
    assert(s.args == None)
    assert(s.description == None)
    assert(s.version == None)


# Generated at 2022-06-23 16:59:41.040669
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    Unit test for constructor of class ParseError
    :return:
    """
    pe = ParseError("Test")
    assert str(pe) == "Test"
    assert pe.args == ("Test",)


# Generated at 2022-06-23 16:59:44.061648
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(["deprecated"], "This one is deprecated", "1.0.0")
    assert doc.args == ["deprecated"]
    assert doc.description == "This one is deprecated"
    assert doc.version == "1.0.0"

# Generated at 2022-06-23 16:59:50.089395
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()

    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []



# Generated at 2022-06-23 16:59:53.902902
# Unit test for constructor of class Docstring
def test_Docstring():
    # Initialize Docstring
    d = Docstring()
    # Tests
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-23 16:59:58.450922
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(args=['return', 'yield'], description='blablabla', type_name='generator', is_generator=True, return_name='yield') is not None

# Generated at 2022-06-23 17:00:00.084062
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)


# Generated at 2022-06-23 17:00:02.999337
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises"], "IndexError: if index is out of range", "IndexError")



# Generated at 2022-06-23 17:00:10.504988
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["arg"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == args
    assert dp.description == description
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default


# Generated at 2022-06-23 17:00:11.605061
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        ParseError()


# Generated at 2022-06-23 17:00:14.251532
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["deprecated"], "version", "1.0")
    # assert test.version == "1.0"
    # assert test.description == "version"
    # assert test.args == ["deprecated"]



# Generated at 2022-06-23 17:00:18.578021
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test DocstringReturns constructor."""
    docstr = DocstringReturns(
        ["returns"],
        "testing",
        "name",
        True,
        "TESTING"
    )
    assert docstr.args == ["returns"]
    assert docstr.description == "testing"
    assert docstr.type_name == "name"
    assert docstr.is_generator == True
    assert docstr.return_name == "TESTING"


# Generated at 2022-06-23 17:00:22.551207
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    x = DocstringMeta('hello','world')
    assert str(x.args) == '[\'hello\']'
    assert x.description == 'world'

# Generated at 2022-06-23 17:00:24.908733
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "I am a parameter"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == ["param"]
    assert docstring_meta.description == "I am a parameter"


# Generated at 2022-06-23 17:00:35.039907
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Test 1: Test DocstringReturns constructor
    args = ["return", "returns"]
    description = "The return value"
    obj = DocstringReturns(args, description, None, False)
    assert obj.args == args
    assert obj.description == description
    assert obj.type_name == None
    assert obj.is_generator == False
    assert obj.return_name == None

    # Test 2: Test DocstringReturns constructor
    args = ["yield", "yields"]
    description = "The yield value"
    type_name = "int"
    obj = DocstringReturns(args, description, type_name, True)
    assert obj.args == args
    assert obj.description == description
    assert obj.type_name == type_name
    assert obj.is_generator == True
    assert obj.return_

# Generated at 2022-06-23 17:00:38.660906
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print("test_DocstringRaises")
    test_args = []
    test_description = ""
    test_type_name = ""
    test_DocstringRaises1 = DocstringRaises(test_args, test_description, test_type_name)


# Generated at 2022-06-23 17:00:46.365131
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    type_name = "str"
    return_name = "x"
    is_optional = True
    default = "None"

    # Test the constructor: DocstringParam
    try:
        param = DocstringParam("name", "description", "arg_name", "type_name", "is_optional", "default")
    except NameError:
        print("\nFailed to initialize DocstringParam with constructor: DocstringParam(args, description, arg_name, type_name, is_optional, default)\n")
        return -1
    else:
        print("\nSuccessfully initialized DocstringParam with constructor: DocstringParam(args, description, arg_name, type_name, is_optional, default)\n")

    return 0


# Generated at 2022-06-23 17:00:50.647306
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam(['param'], 'docstring', 'arg_name', 'type_name', False, 'default')
    assert d.args == ['param']
    assert d.description == 'docstring'
    assert d.arg_name == 'arg_name'
    assert d.type_name == 'type_name'
    assert d.is_optional == False
    assert d.default == 'default'


# Generated at 2022-06-23 17:00:56.847310
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # test '__init__' method
    try:
        result = DocstringReturns(["returns"], "description", "type_name", True)
        assert result.args == ["returns"]
        assert result.description == "description"
        assert result.type_name == "type_name"
        assert result.is_generator == True
        assert result.return_name == None
    except Exception as e:
        print(e)
        assert False

    # test 'return_name' == "name"

# Generated at 2022-06-23 17:01:02.510938
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # TEST CASE:
    docstring_raises = DocstringRaises(["raises"], "description", "Exception")
    assert docstring_raises.args == ["raises"]
    assert docstring_raises.description == "description"
    assert docstring_raises.type_name == "Exception"


# Generated at 2022-06-23 17:01:10.040297
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None

# Generated at 2022-06-23 17:01:13.894755
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError('test_ParseError')
    assert err.args == ('test_ParseError',)
    try:
        raise err
    except ParseError as e:
        assert e.args == ('test_ParseError',)

# Generated at 2022-06-23 17:01:26.105338
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    docstring.short_description = "this is short description"
    docstring.long_description = "this is long description"
    docstring.blank_after_short_description = True
    docstring.blank_after_long_description = True
    docstring.meta.append("Test Meta")
    assert docstring.short_description == "this is short description"
    assert docstring.long_description == "this is long description"
    assert docstring.blank_after_short_description == True

# Generated at 2022-06-23 17:01:28.604591
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """ """
    print("Hello world")


# Generated at 2022-06-23 17:01:35.167813
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    >>> DocstringReturns(['return'], 'test', type_name='test_type', is_generator=False, return_name='test_name')
    <DocstringMeta object at 0x0000023E43C7F9E8>
    """
    assert DocstringReturns(
        ["return"],
        'test',
        type_name="test_type",
        is_generator=False,
        return_name="test_name",
    )



# Generated at 2022-06-23 17:01:38.647772
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    item = DocstringReturns([], "Description", "typename", False, "def")
    assert item.description == "Description"
    assert item.type_name == "typename"
    assert item.is_generator == False
    assert item.return_name == "def"


# Generated at 2022-06-23 17:01:43.744163
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(['return'], '', '')
    assert returns.args == ['return']
    assert returns.description == ''
    assert returns.type_name == ''
    assert returns.is_generator == False
    assert returns.return_name == None


# Generated at 2022-06-23 17:01:48.776525
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    

# Generated at 2022-06-23 17:01:51.842014
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["hello", "world"], "page is not found", "ValueError")

if __name__ == "__main__":
    for test in [test_DocstringRaises]:
        test()

# Generated at 2022-06-23 17:02:02.574966
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test constructor without an argument
    error = ParseError()
    assert isinstance(
        error, ParseError
    ), "Error: 'ParseError()' created an instance that is not an instance of 'ParseError'."
    assert (
        str(error) == "RuntimeError()"
    ), "Error: 'ParseError()' does not create an instance with an empty string for the message."
    # Test constructor with an argument
    error = ParseError("error")
    assert isinstance(
        error, ParseError
    ), "Error: 'ParseError('error')' created an instance that is not an instance of 'ParseError'."
    assert (
        str(error) == "RuntimeError('error')"
    ), "Error: 'ParseError('error')' does not create an instance with an error message."

#

# Generated at 2022-06-23 17:02:06.011676
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(args=['version'],description= 'description',version='version')
    assert doc.description == 'description'
    assert doc.version == 'version'
    assert doc.args[0] == 'version'


# Generated at 2022-06-23 17:02:11.835427
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-23 17:02:14.126309
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Error')
    except ParseError:
        return "Exception is handled"

    assert False, "Expected an exception to be raised"

# Generated at 2022-06-23 17:02:19.772352
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []

# Generated at 2022-06-23 17:02:22.343981
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated([], "", "1.0")
    assert d.version == "1.0"



# Generated at 2022-06-23 17:02:29.391676
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    version = "version"
    description = "this is a test"
    args = ["deprecated", "deprecation"]
    
    object1 = DocstringDeprecated(args, description, version)
    object2 = DocstringDeprecated(args, None, version)
    object3 = DocstringDeprecated(args, description, None)
    object4 = DocstringDeprecated(args, None, None)


# Generated at 2022-06-23 17:02:33.953852
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["args"]
    description = "description"
    type_name = "type_name"
    test_docstringRaises = DocstringRaises(args, description, type_name)
    assert test_docstringRaises.args == ["args"]
    assert test_docstringRaises.description == "description"
    assert test_docstringRaises.type_name == "type_name"


# Generated at 2022-06-23 17:02:35.312025
# Unit test for constructor of class Docstring
def test_Docstring():
    x = Docstring()
    assert x is not None



# Generated at 2022-06-23 17:02:38.155912
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	args = []
	description = None
	type_name = None
	doc = DocstringRaises(args, description, type_name)
	assert(doc.args == [])
	assert(doc.description == None)
	assert(doc.type_name == None)


# Generated at 2022-06-23 17:02:38.921185
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam != None

# Generated at 2022-06-23 17:02:39.659711
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError


# Generated at 2022-06-23 17:02:44.338248
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'Use this instead.', '1.0')
    assert docstring_deprecated.args[0] == 'deprecated'
    assert docstring_deprecated.description == 'Use this instead.'
    assert docstring_deprecated.version == '1.0'

# Generated at 2022-06-23 17:02:50.421736
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    t = DocstringReturns(['a', 'b'], 'c', 'd', True, 'e')
    assert t.args == ['a', 'b']
    assert t.description == 'c'
    assert t.type_name == 'd'
    assert t.is_generator == True
    assert t.return_name == 'e'


# Generated at 2022-06-23 17:02:51.274365
# Unit test for constructor of class ParseError
def test_ParseError():
    pass

# Generated at 2022-06-23 17:02:59.725105
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    ds = Docstring()
    ds.short_description = 'Trasform a string according to the specified mask.'
    ds.long_description = "Mask can be a function (string.upper, string.lower, etc) or a string with the following chars: 'c' - capitalize, 'u' - uppercase, 'l' - lowercase, 'f' - first char uppercase, 't' - all other string.lower, 'T' - all other string.upper"
    ds.blank_after_short_description = True
    ds.blank_after_long_description = True
    ds.meta = [DocstringParam(['type'], 'the type of the variable', 'value', 'str', False, None)]

    assert ds.short_description == 'Trasform a string according to the specified mask.'

# Generated at 2022-06-23 17:03:02.305661
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except:
        print('raised')


# Generated at 2022-06-23 17:03:02.934626
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    pass

# Generated at 2022-06-23 17:03:05.042046
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError()
    assert isinstance(parse_error, ParseError)

# Generated at 2022-06-23 17:03:12.655547
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    tests = [
        (
            ":deprecated: until version 3.2 Use `new_data` instead",
            ["deprecated"],
            "until version 3.2 Use `new_data` instead",
            "3.2",
        ),
        (
            ":deprecated: Use `new_data` instead",
            ["deprecated"],
            "Use `new_data` instead",
            None,
        ),
        (
            ":deprecated:",
            ["deprecated"],
            None,
            None,
        ),
    ]
    for arg, args, description, version in tests:
        try:
            obj = DocstringDeprecated(args, description, version)
            result = ":deprecated: {}".format(description)
        except:
            result = "Error"
        assert result == arg

#

# Generated at 2022-06-23 17:03:14.703271
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("PARSE ERROR")
    except Exception as err:
        assert str(err) == "PARSE ERROR"


# Generated at 2022-06-23 17:03:19.125660
# Unit test for constructor of class Docstring
def test_Docstring():
    obj = Docstring()
    assert obj.short_description == None
    assert obj.long_description == None
    assert obj.blank_after_short_description == False
    assert obj.blank_after_long_description == False
    assert obj.meta == []


# Generated at 2022-06-23 17:03:22.504473
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    r = DocstringReturns([], None, "str", False)
    assert r.type_name == "str"
    assert r.is_generator == False
    assert r.return_name == None


# Generated at 2022-06-23 17:03:24.095476
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['deprecated'], 'Deprecated', '0.1')

# Generated at 2022-06-23 17:03:27.220344
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-23 17:03:34.258809
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['param', 'arg'], 'description', 'arg_name', 'type_name', None, None)
    assert param.args == ['param', 'arg']
    assert param.description == 'description'
    assert param.arg_name == 'arg_name'
    assert param.type_name == 'type_name'
    assert param.is_optional == None
    assert param.default == None


# Generated at 2022-06-23 17:03:38.422623
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    success = True
    try:
        arg = ["TEST"]
        description = "TEST"
        version = "TEST"
        dep = DocstringDeprecated(arg, description, version)
    except Exception:
        success = False

    assert success is True


# Generated at 2022-06-23 17:03:41.747544
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises."""
    # Test for required arguments of DocstringRaises class
    assert DocstringRaises(['pass'], 'pass', 'pass')



# Generated at 2022-06-23 17:03:45.788735
# Unit test for constructor of class ParseError
def test_ParseError():
    # Create a ParseError object and test if the right message was created
    e = ParseError('message')
    assert(e.args[0] == 'message')


# Generated at 2022-06-23 17:03:48.053214
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "It is deprecated."
    version = "3.0"
    myobject = DocstringDeprecated(args, description, version)

    # Check attributes of the object
    assert myobject.args == ["deprecated"]
    assert myobject.description == "It is deprecated."
    assert myobject.version == "3.0"


# Generated at 2022-06-23 17:03:56.318861
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument"]
    description = "this function is deprecated"
    type_name = "the type of arg"
    is_generator = False
    return_name = "return name"
    doc = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert doc.args is args
    assert doc.description is description
    assert doc.type_name is type_name
    assert doc.is_generator is is_generator
    assert doc.return_name is return_name


# Generated at 2022-06-23 17:03:57.995577
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated([], "", None)
    assert d is not None


# Generated at 2022-06-23 17:04:02.116833
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError()
    assert str(error) == "", "The error message is empty."
    error = ParseError("Oh no!")
    assert error.__str__() == "Oh no!", "The error message is \"Oh no!\"."


# Generated at 2022-06-23 17:04:08.146228
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arg = []
    description = 'This'
    # Initialize a object
    doc1 = DocstringMeta(arg, description)
    doc2 = DocstringMeta(arg, description)
    assert doc1.args == doc2.args
    assert doc1.description == doc2.description

    # test constructor with  difference value
    arg2 = [1, 2]
    doc3 = DocstringMeta(arg2, description)
    assert doc3.args == arg2


# Generated at 2022-06-23 17:04:12.574154
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(["args"], "des", "arg", "str", True, "haha")
    assert doc.args == ["args"]
    assert doc.description == "des"
    assert doc.arg_name == "arg"
    assert doc.type_name == "str"
    assert doc.is_optional == True
    assert doc.default == "haha"


# Generated at 2022-06-23 17:04:16.225980
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arr1 = ['a','b','c']
    a1 = DocstringReturns(args = arr1, description = None, type_name = None, is_generator = True)
    print(a1.args,a1.description,a1.type_name,a1.is_generator)

test_DocstringReturns()

# Generated at 2022-06-23 17:04:19.018906
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert(d.short_description is None)
    assert(d.long_description is None)
    assert(d.meta == [])
# End of test



# Generated at 2022-06-23 17:04:24.636500
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-23 17:04:32.414594
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    print("test_Docstring")
    print("a.meta:", a.meta)
    print("a.short_description:", a.short_description)
    print("a.long_description:", a.long_description)
    print("a.params:", a.params)
    print("a.raises:", a.raises)
    print("a.returns:", a.returns)
    print("a.deprecation:", a.deprecation)

# test_Docstring()
# print("end")

# Generated at 2022-06-23 17:04:35.872714
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test class DocstringRaises constructor."""
    assert isinstance(
        DocstringRaises(
            args=[":raises"],
            description="description",
            type_name="TypeName",
        ),
        DocstringRaises,
    )


# Generated at 2022-06-23 17:04:40.490971
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None

# Generated at 2022-06-23 17:04:45.856553
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta_deprecation = DocstringDeprecated([":deprecated", ":version"], "description", "version")

    assert meta_deprecation.args == [":deprecated", ":version"]
    assert meta_deprecation.description == "description"
    assert meta_deprecation.version == "version"


# Generated at 2022-06-23 17:04:50.627069
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Initializing test variables
    args = ["param"]
    description = "Helper class for parsing docstrings."
    version = "3.7"

    # Initializing DocstringDeprecated object
    meta = DocstringDeprecated(args, description, version)

    # Asserting DocstringDeprecated properties
    assert meta.args == args
    assert meta.description == description
    assert meta.version == version


# Generated at 2022-06-23 17:04:56.288030
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    parser_DI=DocstringReturns("Test","Description", "type_name",True)
    assert parser_DI.args == "Test"
    assert parser_DI.type_name == "type_name"
    assert parser_DI.is_generator == True


# Generated at 2022-06-23 17:04:59.793550
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['arg'], 'description', 'type_name')
    assert d.args == ['arg']
    assert d.description == 'description'
    assert d.type_name == 'type_name'


# Generated at 2022-06-23 17:05:08.941718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = "A description"
    arg_name = "name"
    type_name = "str"
    is_optional = True
    default = "None"
    doc_str_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert doc_str_param.args == args
    assert doc_str_param.description == description
    assert doc_str_param.arg_name == arg_name
    assert doc_str_param.type_name == type_name
    assert doc_str_param.is_optional == is_optional
    assert doc_str_param.default == default

# Generated at 2022-06-23 17:05:13.932362
# Unit test for constructor of class Docstring
def test_Docstring():
  doc = Docstring()
  assert(doc.short_description == None)
  assert(doc.long_description == None)
  assert(doc.blank_after_short_description == False)
  assert(doc.blank_after_long_description == False)
  assert(isinstance(doc.meta, list))
  assert(len(doc.meta) == 0)


# Generated at 2022-06-23 17:05:20.299179
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """ write unit test here """
    args = ["@param", "arg"]
    dp = DocstringParam(args, "arg", "arg", "str", True, None)

    assert dp.args == args
    assert dp.arg_name == "arg"
    assert dp.type_name == "str"
    # since default is None, return is None 
    assert dp.default == None

# Generated at 2022-06-23 17:05:22.778852
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a_docdeprecated = DocstringDeprecated(':deprecated', 'This method is deprecated.','version')
    a_docdeprecated.description == 'This method is deprecated.'
    a_docdeprecated.version == 'version'
    return a_docdeprecated

test_DocstringDeprecated()

# Generated at 2022-06-23 17:05:24.929355
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    new = DocstringDeprecated(['deprecated'], "blah", "1.1.1.1")
    assert new is not None

# Generated at 2022-06-23 17:05:27.496451
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test = DocstringReturns(['returns'], '', 'str', False)
    assert test.is_generator == False
