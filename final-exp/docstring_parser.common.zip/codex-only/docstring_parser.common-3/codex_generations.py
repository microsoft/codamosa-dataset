

# Generated at 2022-06-23 16:55:33.758872
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises(['raises', 'RuntimeError'], 'message', 'RuntimeError')
    assert raises.type_name == 'RuntimeError'
    assert raises.description == 'message'
    assert raises.args == ['raises', 'RuntimeError']

# Generated at 2022-06-23 16:55:44.764960
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['params', 'description', 'arg_name', 'type_name', 'is_optional', 'default']
    description = 'Test Docstring Meta'
    assert DocstringMeta(args, description) == DocstringMeta(['params', 'description', 'arg_name', 'type_name', 'is_optional', 'default'], 'Test Docstring Meta')
    assert DocstringMeta(args, description).args == DocstringMeta(['params', 'description', 'arg_name', 'type_name', 'is_optional', 'default'], 'Test Docstring Meta').args
    assert DocstringMeta(args, description).description == DocstringMeta(['params', 'description', 'arg_name', 'type_name', 'is_optional', 'default'], 'Test Docstring Meta').description


# Generated at 2022-06-23 16:55:50.069040
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    strtest = ":deprecated: 1.0"
    strtest = strtest.split()
    strtest = DocstringDeprecated(strtest, "value", "1.0")
    assert strtest.args == ["deprecated"]
    assert strtest.description == "value"
    assert strtest.version == "1.0"


# Generated at 2022-06-23 16:56:02.438269
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    #testing for a function that returns a value.
    testReturnFunction = DocstringReturns(["return"], "This is the return value.", "int")
    assert testReturnFunction.description == "This is the return value.", "The description did not match"
    assert testReturnFunction.type_name == "int", "The type was not returned"
    assert testReturnFunction.return_name == None, "The return name must be None for a function that returns a value."

    #testing for a generator function.
    testGeneratorFunction = DocstringReturns(["yields"], "This is the value returned by the generator.", "int", True)
    assert testGeneratorFunction.description == "This is the value returned by the generator.", "The description did not match"
    assert testGeneratorFunction.type_name == "int", "The type was not returned"
    assert test

# Generated at 2022-06-23 16:56:13.036481
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "arg_name"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    x = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert(x.args == args)
    assert(x.description == description)
    assert(x.arg_name == arg_name)
    assert(x.type_name == type_name)
    assert(x.is_optional == is_optional)
    assert(x.default == default)


# Generated at 2022-06-23 16:56:21.668085
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	args = ['param', 'arg']
	description = 'parameter description'
	arg_name = 'name of argument'
	type_name = 'type'
	is_optional = False
	default = '10'
	obj = DocstringParam(args, description, arg_name, type_name, is_optional, default)
	assert obj.args == ['param', 'arg']
	assert obj.description == 'parameter description'
	assert obj.arg_name == 'name of argument'
	assert obj.type_name == 'type'
	assert obj.is_optional == False
	assert obj.default == '10'
	return True

assert test_DocstringParam()



# Generated at 2022-06-23 16:56:26.804886
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None


# Generated at 2022-06-23 16:56:30.218381
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "").args == []
    assert DocstringMeta([], "").description == ""


# Generated at 2022-06-23 16:56:36.669944
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of DocstringParam."""
    val = DocstringParam(['param'], 'Test', 'arg', 'str', 'False', 'None')
    assert val.args == ['param']
    assert val.arg_name == 'arg'
    assert val.description == 'Test'
    assert val.default == 'None'
    assert val.is_optional == 'False'
    assert val.type_name == 'str'


# Generated at 2022-06-23 16:56:40.310989
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("test exception")
    print(pe)


# Generated at 2022-06-23 16:56:42.846732
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(args = ["arg1", "arg2"], description = "some description")
    assert isinstance(obj, DocstringMeta)

# Generated at 2022-06-23 16:56:48.757261
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    argument = ['returns']
    description = 'description'
    type_name = 'typename'
    is_generator = False
    return_name = 'return_name'
    doc_string = DocstringReturns(argument, description, type_name, is_generator, return_name)
    assert (doc_string.args == argument)
    assert (doc_string.description == description)
    assert (doc_string.type_name == type_name)
    assert (doc_string.is_generator == is_generator)
    assert (doc_string.return_name == return_name)

# Generated at 2022-06-23 16:56:53.252178
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print("Testing constructor of class DocstringDeprecated with valid input")
    assert(DocstringDeprecated(["deprecated"], "description") != DocstringDeprecated(["deprecated"], None))
    assert(DocstringDeprecated(["deprecated"], None) != DocstringDeprecated(["deprecated"], "description"))



# Generated at 2022-06-23 16:56:56.281807
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    t = DocstringMeta(["param"], "ABC")
    assert t.args == ["param"]
    assert t.description == "ABC"



# Generated at 2022-06-23 16:57:00.633875
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test1 = DocstringMeta(['parameter:', 'param:'], 'describes a parameter')
    assert isinstance(test1, DocstringMeta)
    assert test1.args == ['parameter:', 'param:']
    assert test1.description == 'describes a parameter'
    assert test1 != ['param:', 'describes a parameter']


# Generated at 2022-06-23 16:57:03.579265
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    try:
        DocstringReturns(['returns'], "", "", "")
    except ParseError as ex:
        pytest.fail(ex)

test_DocstringReturns()

# Generated at 2022-06-23 16:57:13.835915
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "example description"
    type_name = "int"
    is_generator = True
    return_name = "return_name"
    my_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert args == my_DocstringReturns.args
    assert description == my_DocstringReturns.description
    assert type_name == my_DocstringReturns.type_name
    assert is_generator == my_DocstringReturns.is_generator
    assert return_name == my_DocstringReturns.return_name


# Generated at 2022-06-23 16:57:16.198310
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
   docstring = Docstring()
   param = DocstringParam(["param"], "bla", "arg", "type", "not", "default")
   assert isinstance(param, DocstringParam)


# Generated at 2022-06-23 16:57:17.613608
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-23 16:57:18.837555
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except:
        assert True


# Generated at 2022-06-23 16:57:27.281814
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    docstring_param = DocstringParam(
        args=["param", "foo", ":", "arg", "name="],
        description="foo is a simple example",
        arg_name="foo",
        type_name=None,
        is_optional=None,
        default=None
    )
    assert docstring_param.args == ["param", "foo", ":", "arg", "name="]
    assert docstring_param.description == "foo is a simple example"
    assert docstring_param.arg_name == "foo"
    assert docstring_param.type_name is None
    assert docstring_param.is_optional is None
    assert docstring_param.default is None


# Generated at 2022-06-23 16:57:34.648653
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ''
    description = ''
    type_name = ''
    is_generator = ''
    return_name = ''
    test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert(test.args == '')
    assert(test.description == '')
    assert(test.type_name == '')
    assert(test.is_generator == '')
    assert(test.return_name == '')



# Generated at 2022-06-23 16:57:35.622531
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert 1==1


# Generated at 2022-06-23 16:57:37.664190
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    item = DocstringMeta(["param"], "description")
    assert item.args == ["param"]
    assert item.description == "description"


# Generated at 2022-06-23 16:57:39.124598
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docStringMeta = DocstringMeta(["param"], "description")
    assert docStringMeta



# Generated at 2022-06-23 16:57:44.697830
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []



# Generated at 2022-06-23 16:57:47.050075
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['a'], 'b')
    assert a.args == ['a']
    assert a.description == 'b'

# Generated at 2022-06-23 16:57:50.447410
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docStringReturns = DocstringReturns(["return"], "something", "int", False, "x")
    assert docStringReturns.return_name is "x"



# Generated at 2022-06-23 16:57:54.137980
# Unit test for constructor of class ParseError
def test_ParseError():
    mess = "all work and no play make jack a dull boy"
    ParseError.__init__(mess)
    ParseError.__init__(mess)
    ParseError.__init__(mess)
    assert ParseError.__init__(mess) == ParseError(mess)


# Generated at 2022-06-23 16:57:59.300884
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    from docstring_parser import DocstringReturns
    dr = DocstringReturns(['yields'], 'Next item', 'str', True)
    assert isinstance(dr, DocstringReturns)
    assert isinstance(dr, DocstringMeta)


# Generated at 2022-06-23 16:58:02.781579
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_m = DocstringMeta(["a", "b"], "c")
    assert doc_m.args == ["a", "b"]
    assert doc_m.description == "c"



# Generated at 2022-06-23 16:58:05.169315
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['parameter'], "description", "int", True, "1")
    DocstringReturns(['type'], "description", "int", False)

# Generated at 2022-06-23 16:58:06.397931
# Unit test for constructor of class ParseError
def test_ParseError():
    a = "Das ist ein Test"
    assert ParseError(a)

# Generated at 2022-06-23 16:58:13.665301
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert type(docstring.meta) == list
    assert len(docstring.meta) == 0
    #print(docstring.__dict__)
    assert isinstance(docstring, Docstring)


# Generated at 2022-06-23 16:58:22.122229
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns(["param", "parameter"], "Argument xyz.", "int")
    assert doc.args == ["param", "parameter"]
    assert doc.description == "Argument xyz."
    assert doc.type_name == "int"
    assert doc.is_generator == False
    assert doc.return_name == None


# Generated at 2022-06-23 16:58:24.546421
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    item = DocstringMeta(["1.0"], "Test description")
    assert item.args == ["1.0"]
    assert item.description == "Test description"



# Generated at 2022-06-23 16:58:30.149856
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for the constructor of class Docstring."""
    docstring = Docstring()
    assert docstring
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None

# Generated at 2022-06-23 16:58:39.699364
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(['parameter'], 'description', 'arg', 'type', True, 'default')
    try:
# TODO: check if all the properties of DocstringParam is initialized to the passed parameters
        assert(x.args[0] == 'parameter')
        assert(x.description == 'description')
        assert(x.arg_name == 'arg')
        assert(x.type_name == 'type')
        assert(x.is_optional == True)
        assert(x.default == 'default')
        print("success")
    except AssertionError as e:
        print("Failed", e)


# Generated at 2022-06-23 16:58:43.469421
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = None
    type_name = "TypeError"
    DocstringRaises(args, description, type_name)


# Generated at 2022-06-23 16:58:47.263105
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    source = '''
    :param arg: description
    :raises ValueError: if something happens
    '''
    raise ValueError("Not finished!")

# Generated at 2022-06-23 16:58:50.342899
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []


# Generated at 2022-06-23 16:58:54.843376
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm=DocstringMeta('args','description')
    assert dm.args == 'args'
    assert dm.description == 'description'

# Testing for constructor of class DocstringParam

# Generated at 2022-06-23 16:59:00.268203
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['a'], 'a', 'a', True, 'a')
    assert a.args == ['a']
    assert a.description == 'a'
    assert a.type_name == 'a'
    assert a.is_generator == True
    assert a.return_name == 'a'


# Generated at 2022-06-23 16:59:02.635975
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam.__init__()


# Generated at 2022-06-23 16:59:10.017378
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test = DocstringParam(["param", "parameter"], "description", "arg", "str", True, "123")
    assert test.args == ["param", "parameter"]
    assert test.description == "description"
    assert test.arg_name == "arg"
    assert test.type_name == "str"
    assert test.is_optional == True
    assert test.default == "123"


# Generated at 2022-06-23 16:59:15.224364
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	a = DocstringReturns(['', ''], 'description', 'type_name', True)
	a.args
	a.description
	a.type_name
	a.is_generator



# Generated at 2022-06-23 16:59:16.138087
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["A", "B"], "A", "B")

# Generated at 2022-06-23 16:59:22.251522
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"

    param = DocstringRaises(args, description, type_name)
    assert param.args == ["raises", "ValueError"]
    assert param.description == "if something happens"
    assert param.type_name == "ValueError"

# Generated at 2022-06-23 16:59:26.781313
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta(["param", "parameter", "arg", "argument"], "description")
    except ParseError:
        print("Error")



# Generated at 2022-06-23 16:59:33.038365
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None

# Generated at 2022-06-23 16:59:45.025790
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["a"], "b", "c", False)
    assert a.args == ["a"], "Unexpected value"
    assert a.description == "b", "Unexpected value"
    assert a.type_name == "c", "Unexpected value"
    assert a.is_generator == False, "Unexpected value"
    assert a.return_name == None, "Unexpected value"
    a = DocstringReturns(["a"], "b", "c", False, "d")
    assert a.args == ["a"], "Unexpected value"
    assert a.description == "b", "Unexpected value"
    assert a.type_name == "c", "Unexpected value"
    assert a.is_generator == False, "Unexpected value"

# Generated at 2022-06-23 16:59:50.533773
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()  # type: Docstring
    assert not ds.meta
    assert ds.params == []
    assert ds.raises == []
    assert ds.returns == None
    assert ds.deprecation == None

# Generated at 2022-06-23 16:59:51.087072
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pass

# Generated at 2022-06-23 16:59:56.385660
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test1 = DocstringReturns(['returns'], 'None', None, False)
    assert(test1.args == ['returns'])
    assert(test1.description == 'None')
    assert(test1.type_name == None)
    assert(test1.is_generator == False)
    assert(test1.return_name == None)
    assert(str(type(test1)) == "<class 'parse.darglint.parse.DocstringReturns'>")



# Generated at 2022-06-23 16:59:59.134029
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated is not None
    assert DocstringDeprecated([], None, None) is not None


# Generated at 2022-06-23 17:00:00.640662
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    print(docstring.long_description)

if __name__ == '__main__':
    test_Docstring()

# Generated at 2022-06-23 17:00:10.551516
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    a_doc_string: Docstring = Docstring()
    a_doc_string.short_description = 'Constructor for class DocstringParam.'
    a_doc_string.long_description = 'Initialize self.'
    a_doc_string.blank_after_short_description = False
    a_doc_string.blank_after_long_description = True
    a_meta_list = ['param arg: list of arguments.', 'param description: associated docstring description.']
    a_meta_description = 'the exact content of this variable is dependent on the kind of docstring; it\'s used to distinguish between custom docstring meta information items.'
    a_arg_name = 'args'
    a_type_name = 'T.List[str]'

# Generated at 2022-06-23 17:00:12.500200
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(["deprecated"], "test", None)
    assert meta.args == ["deprecated"]
    assert meta.description == "test"
    assert meta.version == None

# Generated at 2022-06-23 17:00:19.136847
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param"], "descr", "name", "type", "option", "default")
    assert dp.args == ["param"], "args of docstring param has not been set up correctly"
    assert dp.description == "descr", "description of docstring param not set up correctly"
    assert dp.arg_name == "name", "name of docstring param not set up correctly"
    assert dp.type_name == "type", "type of docstring param not set up correctly"
    assert dp.is_optional == "option", "optionality of docstring param not set up correctly"
    assert dp.default == "default", "default value of docstring param not set up correctly"


# Generated at 2022-06-23 17:00:22.761596
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print('Testing constructor of class DocstringDeprecated... ', end='')
    docstring_deprecated = DocstringDeprecated(['parameter'], 'description', 'version')
    assert(docstring_deprecated.args == ['parameter'])
    assert(docstring_deprecated.description == 'description')
    assert(docstring_deprecated.version == 'version')
    print('Passed.')


# Generated at 2022-06-23 17:00:26.943357
# Unit test for constructor of class Docstring
def test_Docstring():
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    return



# Generated at 2022-06-23 17:00:30.376000
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    docstring_deprecated_test = DocstringDeprecated(
        args=["deprecated", "version"], description="test", version="test"
    )
    assert docstring_deprecated_test is not None
    assert docstring_deprecated_test.version == "test"
    assert docstring_deprecated_test.description == "test"


# Generated at 2022-06-23 17:00:32.689308
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError("some message")
    assert e.args[0] == "some message"



# Generated at 2022-06-23 17:00:34.506100
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert(DocstringDeprecated([], "", "") != None)

# Generated at 2022-06-23 17:00:40.536579
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print('test_DocstringDeprecated:')
    args = ['a', 'b']
    description = 'description'
    version = 'v1'
    dep = DocstringDeprecated(args, description, version)
    print(dep.args)
    print(dep.description)
    print(dep.version)


# Generated at 2022-06-23 17:00:47.341766
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Arrange
    args = ["param"]
    description = "test"

    # Act
    docstring_meta = DocstringMeta(args, description)

    # Assert
    assert docstring_meta.args == args
    assert docstring_meta.description == description

# Generated at 2022-06-23 17:00:50.053370
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], 'The mail subject', 'subject', 'str', True, 'Hello')

# Generated at 2022-06-23 17:00:57.880678
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print("Testing DocstringRaises constructor.")
    # Test 1: no arguments passed
    print("Test 1: no arguments passed")
    try:
        test = DocstringRaises()
        assert False, "Did not throw exception"
    except TypeError:
        pass
    # Test 2: args is not a list
    print("Test 2: args is not a list")
    try:
        args = "invalid"
        description = "Description"
        test = DocstringRaises(args, description)
        assert False, "Did not throw exception"
    except TypeError:
        pass
    # Test 3: description is not a string
    print("Test 3: description is not a string")

# Generated at 2022-06-23 17:01:01.648634
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a=[]
    description=None
    typename=None
    is_generator=True
    DocstringReturns(a,description,typename,is_generator)

# Generated at 2022-06-23 17:01:13.584179
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    class TestArgs:
        def __init__(self, args: T.List[str], description: T.Optional[str], version: T.Optional[str]) -> None:
            """Initialize self."""
            self.args = args
            self.description = description
            self.version = version
    test_arg = TestArgs(["test"], "test desc", "test version")
    match_arg = DocstringDeprecated(["test"], "test desc", "test version")
    if test_arg.args != match_arg.args:
        raise Exception("test_args.args", test_arg.args, match_arg.args)
    if test_arg.description != match_arg.description:
        raise Exception("test_args.description", test_arg.description, match_arg.description)

# Generated at 2022-06-23 17:01:19.136233
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(["type_name"])
    assert obj.args == ["type_name"]
    assert obj.type_name == "type_name"
    assert obj.is_generator == False
    assert obj.return_name == None



# Generated at 2022-06-23 17:01:24.764347
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    arguments = ['raises', 'ValueError']
    description = 'if something happens'
    exception = 'ValueError'

    a = DocstringRaises (arguments, description, exception)
    assert a.args == ['raises', 'ValueError']
    assert a.description == 'if something happens'
    assert a.type_name == 'ValueError'



# Generated at 2022-06-23 17:01:30.211325
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    # create a DocstringMeta object
    my_meta = DocstringMeta(['param'], "description")

    # check for parameters
    assert my_meta.args == ['param']
    assert my_meta.description == "description"


# Generated at 2022-06-23 17:01:31.624578
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Test error")


# Generated at 2022-06-23 17:01:34.560051
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated("a", "b", "c")
    return (a.args == "a" and a.description == "b" and a.version == "c")


# Generated at 2022-06-23 17:01:36.929828
# Unit test for constructor of class ParseError
def test_ParseError():
    print('Testing constructor ParseError')
    error = ParseError()
    assert(isinstance(error,ParseError))
    print('Testing constructor ParseError completed')


# Generated at 2022-06-23 17:01:38.372447
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises([""], "", "")
    assert test.type_name == ""

# Generated at 2022-06-23 17:01:44.695820
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "Description")
    DocstringMeta(["parameter"], "Description")
    DocstringMeta(["arg"], "Description")
    DocstringMeta(["argument"], "Description")
    DocstringMeta(["attribute"], "Description")
    DocstringMeta(["key"], "Description")
    DocstringMeta(["keyword"], "Description")


# Generated at 2022-06-23 17:01:52.446548
# Unit test for constructor of class Docstring
def test_Docstring():
    doc1 = Docstring()
    doc2 = Docstring()
    assert(doc1.short_description == None)
    assert(doc1.long_description == None)
    assert(doc1.meta == [])
    assert(doc1.blank_after_short_description == False)
    assert(doc1.blank_after_long_description == False)
    assert(doc1.params == [])
    assert(doc1.raises == [])
    assert(doc1.returns == None)
    assert(doc1.deprecation == None)

# Generated at 2022-06-23 17:01:53.763045
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(
        ["raises"], None, None
    ).description == None

# Generated at 2022-06-23 17:01:59.822559
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(['param'], 'description', 'arg', 'type_name', True, 'value')
    assert(len(doc.args) == 1)
    assert(doc.description == 'description')
    assert(doc.arg_name == 'arg')
    assert(doc.type_name == 'type_name')
    assert(doc.is_optional == True)
    assert(doc.default == 'value')


# Generated at 2022-06-23 17:02:03.529746
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(args=['param', 'parameter'], description='description')
    assert [obj.args, obj.description] == [['param', 'parameter'], 'description']


# Generated at 2022-06-23 17:02:04.935604
# Unit test for constructor of class ParseError
def test_ParseError():
    _ = ParseError("This is an error message.")


# Generated at 2022-06-23 17:02:08.547867
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    x = DocstringReturns(["return", "returns"], "returns description", "type_name", True, "return name")


# Generated at 2022-06-23 17:02:11.748272
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-23 17:02:13.055851
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["param", "param1"], "Hi", "12.0")

# Generated at 2022-06-23 17:02:19.384831
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(['param'], 'description')
    DocstringMeta(['raises'], 'description')
    DocstringMeta(['return'], 'description')
    DocstringMeta(['yield'], 'description')
    DocstringMeta(['deprecated'], 'description')


# Generated at 2022-06-23 17:02:23.465660
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", True,"default")
    assert docstring_param.args[1] == "arg"
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-23 17:02:30.760036
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args=[' :deprecated:'],description='s',version='s')
    assert d.args == [' :deprecated:']
    assert d.description == 's'
    assert d.version == 's'
    assert d.__init__.__annotations__.items() == dict(
        args = T.List[str],
        description = T.Optional[str],
        version = T.Optional[str]
    ).items()

# Generated at 2022-06-23 17:02:34.820949
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().meta == []
    

# Generated at 2022-06-23 17:02:35.990137
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        assert True

# Generated at 2022-06-23 17:02:38.190117
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    d = DocstringMeta(args, description)
    assert(d.args == args)
    assert(d.description == description)


# Generated at 2022-06-23 17:02:39.499323
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError("there was an error")
    assert 1 == 1


# Generated at 2022-06-23 17:02:42.917120
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    print(a.short_description)
    print(a.long_description)
    print(a.blank_after_short_description)
    print(a.blank_after_long_description)
    print(a.meta)
    print(a.params)
    print(a.raises)
    print(a.returns)
    print(a.deprecation)


if __name__ == "__main__":
    test_Docstring()

# Generated at 2022-06-23 17:02:55.726343
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test for passing valid parameters.
    args = [":deprecated"]
    description = "Deprecated in version 1.2."
    version = "1.2"
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version
    # Test for passing empty string as description.
    args = [":deprecated"]
    description = ""
    version = "1.2"
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == ""
    assert docstring.version == version
    # Test for passing None as version parameter.
    args = [":deprecated"]
    description = "Deprecated in version 1.2."
    version = None
   

# Generated at 2022-06-23 17:03:04.271433
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    k1 = DocstringRaises(["param"], "parameter", None)
    assert k1.args == ["param"]
    assert k1.description == "parameter"
    assert k1.type_name == None
    k2 = DocstringRaises(["param"], "parameter", "None")
    assert k2.args == ["param"]
    assert k2.description == "parameter"
    assert k2.type_name == None

# Generated at 2022-06-23 17:03:05.780843
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(args='x',description='y',version='0.0.0')
    assert type(test) is DocstringDeprecated

# Generated at 2022-06-23 17:03:07.487622
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # works
    assert DocstringMeta('args', 'description')


# Generated at 2022-06-23 17:03:09.570363
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError – if no message is given, the
    constructor should just call super()."""
    e = ParseError()
    assert e.args == tuple()


# Generated at 2022-06-23 17:03:13.415455
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
  obj = DocstringReturns([1,2,3], "t1", "t2", "t3")
  obj.args[0] == 1
  obj.args[1] == 2
  obj.args[2] == 3
  print(obj.description)
  print(obj.type_name)
  print(obj.is_generator)



# Generated at 2022-06-23 17:03:18.483123
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns"""
    args = ['return', 'description']
    description = 'description'
    type_name = 'None'
    is_generator = 'False'
    return_name = 'None'
    assert(DocstringReturns(args, description, type_name, is_generator, return_name))


# Generated at 2022-06-23 17:03:29.607888
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    label = "test_DocstringReturns"
    print(label)
    args = ["raises","exception","error"]
    description = "test description"
    type_name = "test type"
    is_generator = True
    return_name = "test_return_name"
    print(label+"0")
    dsr = DocstringReturns(args, description, type_name, is_generator, return_name)
    print(dsr)
    print(label+"1")
    assert dsr.args == args
    print(label+"2")
    assert dsr.description == description
    print(label+"3")
    assert dsr.type_name == type_name
    print(label+"4")
    assert dsr.is_generator == is_generator

# Generated at 2022-06-23 17:03:33.391543
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = ""
    my_docstringMeta = DocstringMeta(args, description)
    assert my_docstringMeta.args == []
    assert my_docstringMeta.description == ""


# Generated at 2022-06-23 17:03:39.028828
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test an object of type DocstringReturns."""
    arg = ["return", "returns"]
    desc = "A function"
    type_name = "int"
    generator = False
    obj = DocstringReturns(arg, desc, type_name, generator)
    assert obj.args == arg
    assert obj.description == desc
    assert obj.type_name == type_name
    assert obj.is_generator == generator
    assert obj.return_name == None

# Generated at 2022-06-23 17:03:44.947670
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    new_docstring = DocstringDeprecated(['deprecated'], 'old', 'v1')
    # Confirm that the class constructor for DocstringDeprecated works
    assert new_docstring.args == ['deprecated']
    assert new_docstring.description == 'old'
    assert new_docstring.version == 'v1'


# Generated at 2022-06-23 17:03:48.225604
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Something went wrong")
    except ParseError as e:
        assert str(e) == "Something went wrong";


# Generated at 2022-06-23 17:03:52.295255
# Unit test for constructor of class Docstring
def test_Docstring():
    d=Docstring()
    assert d.short_description == None 
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []



# Generated at 2022-06-23 17:03:54.499416
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['a', 'b', 'c']
    description = "Test of constructor of DocStringMeta"
    assert DocstringMeta(args, description)

# Generated at 2022-06-23 17:04:02.706681
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(args=[], description="My description", arg_name="arg", type_name="str", is_optional=False, default="None")
    assert docstring_param.short_description == "My description"
    assert docstring_param.args == []
    assert docstring_param.arg_name == "arg"
    assert docstring_param.type_name == "str"
    assert docstring_param.is_optional == False
    assert docstring_param.default == "None"



# Generated at 2022-06-23 17:04:12.007000
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    
    # This is a sample docstring, with each type of DocstringMeta
    # We feed this in, and test the constructor to see if it gets parsed correctly
    sample_docstring = [
        "\"\"\"This is the summary line for a class docstring.\n",
        "This is the class docstring itself, which may span multiple lines.\n",
        "    This is a sample param.  There may be multiple params\n",
        "    This is a sample raises.  There may be multiple raises\n",
        "    This is a sample returns.  There could be another returns\n",
        "    This is a sample yields.  There could be another yields\n",
        "    This is a sample deprecated.  There could be multiple deprecations\n",
        "\"\"\""
    ]

    # Dummy description to

# Generated at 2022-06-23 17:04:14.664279
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()
    ParseError("test")


# Generated at 2022-06-23 17:04:18.277360
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []

# Generated at 2022-06-23 17:04:19.542585
# Unit test for constructor of class ParseError
def test_ParseError():
  error=ParseError("message")
  print(error)


# Generated at 2022-06-23 17:04:21.315786
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert isinstance(DocstringMeta([], ""))



# Generated at 2022-06-23 17:04:23.546650
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(args=[":deprecated"], description=None, version=None)
    assert doc.args[0] == ":deprecated"
    assert doc.description == None
    assert doc.version == None

# Generated at 2022-06-23 17:04:26.601770
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    with pytest.raises(TypeError):
        DocstringReturns("args", "string", "type_name", "bool", "return_name")



# Generated at 2022-06-23 17:04:30.504914
# Unit test for constructor of class Docstring
def test_Docstring():
    description = Docstring()
    assert description.short_description is None 
    assert description.long_description is None
    assert description.blank_after_long_description is False
    assert description.blank_after_short_description is False
    assert description.meta == []

# Generated at 2022-06-23 17:04:37.591953
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg"]
    description = "desc"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default
    assert dp.description == description
    assert dp.args == args


# Generated at 2022-06-23 17:04:43.428350
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print("Testing DocstringDeprecated constructor.")
    args = [""]
    desc = "description"
    version = "version"
    docstring = DocstringDeprecated(args, desc, version)
    assert docstring.args == [""]
    assert docstring.description == "description"
    assert docstring.version == "version"



# Generated at 2022-06-23 17:04:50.802955
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1 -
    # initializing with two args instead of 7
    # expected output: AttributeError
    try:
        DocstringParam(['a', 'b'])
    except AttributeError:
        pass
    finally:
        print("Test 1 passed")

    # Test 2 -
    # initializing with 7 args
    # expected output: No exception
    try:
        test_object = DocstringParam(['a', 'b'], 2, 'a', 'b', 'c', True, None)
    except:
        print("Test 2 failed")
    else:
        print("Test 2 passed")


# Generated at 2022-06-23 17:04:54.565465
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error message")
    except ParseError as e:
        assert e.args[0] == "error message"

# Generated at 2022-06-23 17:05:02.404901
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param","arg"]
    description = "this function is used to add two numbers"
    type_name = "Integer"
    is_generator = False
    return_name = "sum"
    test_instance = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_instance.args == args
    assert test_instance.description == description
    assert test_instance.type_name == type_name
    assert test_instance.is_generator == is_generator
    assert test_instance.return_name == return_name


# Generated at 2022-06-23 17:05:04.484257
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = []
    description = ""

    a = DocstringMeta(args,description)
    assert a.args == args
    assert a.description == description


# Generated at 2022-06-23 17:05:05.865414
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None 


# Generated at 2022-06-23 17:05:09.506988
# Unit test for constructor of class ParseError
def test_ParseError():
    """
    Unit test for constructor of class ParseError.
    """
    error = ParseError("Custom Error")
    assert str(error) == 'Custom Error'
    assert repr(error) == 'Custom Error'


# Generated at 2022-06-23 17:05:15.904484
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    # Test that the arguments are assigned to the object
    assert dp.args == args and dp.description == description
    assert dp.arg_name == arg_name and dp.type_name == type_name
    assert dp.is_optional == is_optional and dp.default == default
    # Test the arguments are assigned to the parent class
    assert dp.args == args and dp.description == description 



# Generated at 2022-06-23 17:05:19.504975
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg"]
    description = "desc"
    type_name = "type"
    DocstringRaises(args, description, type_name)


# Generated at 2022-06-23 17:05:23.818570
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstringMeta = DocstringMeta(None, None)
    assert isinstance(docstringMeta.args, list)
    assert isinstance(docstringMeta.description, str)
    assert isinstance(docstringMeta, DocstringMeta)



# Generated at 2022-06-23 17:05:29.157297
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    d = DocstringDeprecated(args=[], description="", version="")
    # The following line is not permitted since version is not a public attribute of DocstringDeprecated
    # d.version = "1.0.1"
    assert(d.version == "")

