

# Generated at 2022-06-23 16:55:31.800662
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param", "parameter"], "hello", "arg", "str", True, "abc")
    assert isinstance(param, DocstringParam)


# Generated at 2022-06-23 16:55:33.705282
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(args = 0, description = 0, version = 0)


# Generated at 2022-06-23 16:55:36.183797
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "test", "arg", "Test", True, "hello world")

# Generated at 2022-06-23 16:55:38.679258
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(['deprecated'], 'description', '1.0')
    assert isinstance(obj, DocstringDeprecated)


# Generated at 2022-06-23 16:55:39.786417
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    pass


# Generated at 2022-06-23 16:55:44.140010
# Unit test for constructor of class ParseError
def test_ParseError():
    x = ParseError("Hi")
    assert x.args == ("Hi",)

    y = ParseError("Hello", "World")
    assert y.args == ("Hello", "World")

    z = ParseError("Hello", "World", 6)
    assert z.args == ("Hello", "World", 6)


# Generated at 2022-06-23 16:55:48.716405
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert len(doc.meta) == 0

# Generated at 2022-06-23 16:55:51.803863
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated([":deprecated"], "description", "1.0")
    assert doc.args == [":deprecated"]
    assert doc.description == "description"
    assert doc.version == "1.0"


# Generated at 2022-06-23 16:55:54.630794
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args=["return","returns"]
    type_name=None
    description="Test instance of class DocstringReturns"
    assert str(DocstringReturns(args,description,type_name,False).description)=="Test instance of class DocstringReturns"
    

# Generated at 2022-06-23 16:56:02.652200
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError:', 'if', 'something', 'happens']
    description = "if something happens"
    type_name = 'ValueError'
    test = DocstringRaises(args=args, description=description, type_name=type_name)
    assert test.args == ['raises', 'ValueError:', 'if', 'something', 'happens']
    assert test.description == "if something happens"
    assert test.type_name == 'ValueError'


# Generated at 2022-06-23 16:56:03.452921
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string = Docstring()


# Generated at 2022-06-23 16:56:10.312608
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["b"],'c', 'd', 'e', 'f', 'g')
    print(a.args)
    print(a.description)
    print(a.arg_name)
    print(a.type_name)
    print(a.is_optional)
    print(a.default)


# Generated at 2022-06-23 16:56:17.904581
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Create an instance of DocstringRaises
    DocstringRaises_obj_1 = DocstringRaises(args=["type_name"], description="", type_name="type_name")
    # Test code for DocstringRaises
    assert DocstringRaises_obj_1.args == ["type_name"]
    assert DocstringRaises_obj_1.description == ""
    assert DocstringRaises_obj_1.type_name == "type_name"
    # Test for deprecated
    DocstringRaises_obj_2 = DocstringRaises(args=None, description=None, type_name=None,)


# Generated at 2022-06-23 16:56:21.965680
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test the constructor of class DocstringDeprecated."""
    d = DocstringDeprecated(['a', 'b', 'c'], 'description', 'version')
    assert d.args == ['a', 'b', 'c']
    assert d.description == 'description'
    assert d.version == 'version'

# Generated at 2022-06-23 16:56:24.736624
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    x = DocstringParam(
        args=["I'm an argument:"],
        description="I'm the description.",
        arg_name="x",
        type_name="int",
        is_optional="True",
        default=0,
    )


# Generated at 2022-06-23 16:56:35.801501
# Unit test for constructor of class Docstring
def test_Docstring():
    # Create variable
    a = Docstring()
    # Assign values to the variable
    a.short_description = 'this is short description'
    a.long_description = 'this is long description'
    a.blank_after_short_description = True
    a.blank_after_long_description = True
    a.meta = [DocstringMeta([], '')]

    # Print the variable
    print(a.short_description)
    print(a.long_description)
    print(a.blank_after_short_description)
    print(a.blank_after_long_description)
    print(a.meta)

# Testing constructor of Docstring class
test_Docstring()

# Generated at 2022-06-23 16:56:41.055262
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["returns"], "description", "type_name", False, "return_name")
    print(a.args)
    print(a.description)
    print(a.type_name)
    print(a.is_generator)
    print(a.return_name)
    # Test if isinstance works properly
    assert isinstance(a, DocstringReturns)
    assert isinstance(a, DocstringMeta)


# Generated at 2022-06-23 16:56:47.932716
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = Docstring()
    meta = DocstringDeprecated(["deprecated"], "deprecation", "1.1")
    doc.meta.append(meta)
    assert doc.deprecation == meta
    assert doc.deprecation.description == meta.description
    assert doc.deprecation.version == meta.version
    meta2 = DocstringDeprecated(["deprecated"], "deprecation", "1.1")
    doc.meta.append(meta2)
    assert doc.deprecation == meta2
    assert doc.deprecation.description == meta2.description
    assert doc.deprecation.version == meta2.version


# Generated at 2022-06-23 16:56:51.239137
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param"], "This is a desc", "arg", "type", True, None)
    assert(dp.args == ["param"])
    assert(dp.description == "This is a desc")
    assert(dp.arg_name == "arg")
    assert(dp.type_name == "type")
    assert(dp.is_optional == True)
    assert(dp.default == None)

# Generated at 2022-06-23 16:56:54.575605
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Create DocstringMeta object."""
    obj = DocstringMeta(["param"], "Description")
    assert obj.args == ["param"]
    assert obj.description == "Description"


# Generated at 2022-06-23 16:56:59.662529
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(["raises", "ValueError"],
                                      "description", "description")
    assert docstringRaises.args == ["raises", "ValueError"]
    assert docstringRaises.description == "description"
    assert docstringRaises.type_name == "description"

test_DocstringRaises()

# Generated at 2022-06-23 16:57:05.115199
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # instantiate the DocstringMeta class
    with pytest.raises(TypeError):
        DocstringMeta()
    try:
        DocstringMeta()
    except TypeError as inst:
        assert inst.args[0] == "__init__() missing 2 required positional arguments: 'args' and 'description'"


# Generated at 2022-06-23 16:57:12.989595
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    description = "A docstring"
    type_name = 'str'
    is_generator = False
    return_name = 'ret'
    ds = DocstringReturns(
        args, description, type_name, is_generator, return_name
    )
    assert ds.type_name == type_name
    assert ds.is_generator == is_generator
    assert ds.return_name == return_name


# Generated at 2022-06-23 16:57:17.534136
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["param"], "description", "version")

    assert docstring_deprecated.args == ["param"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"

# Generated at 2022-06-23 16:57:18.105030
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()

# Generated at 2022-06-23 16:57:19.693347
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    item = DocstringDeprecated(['hello'], 'description', 'version')
    assert item.description == 'description'

# Generated at 2022-06-23 16:57:25.193001
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param", "arg", "attribute", "key", "keyword"]
    description = "This is the description"
    version = "1.0"
    known_error = "param is not allowed"
    try:
        DocstringDeprecated(args, description, version)
    except ParseError as e:
        assert e.args[0] == known_error
    else:
        assert 0, "Exception not raised when it should have"


# Generated at 2022-06-23 16:57:31.143680
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    TEST_OBJ = DocstringParam(
        args=["param"],
        description="any",
        arg_name="arg",
        type_name="int",
        is_optional=True,
        default=5,
    )
    assert TEST_OBJ is not None


# Generated at 2022-06-23 16:57:33.850025
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	print(DocstringDeprecated(["deprecated","deprecates"], "deprecated by", "1.0.0"))


# Generated at 2022-06-23 16:57:36.645735
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docD = DocstringDeprecated(['param', 'type:', 'arg'], 'description', 'version')
    assert docD.args == ['param', 'type:', 'arg']
    assert docD.description == 'description'
    assert docD.version == 'version'


# Generated at 2022-06-23 16:57:45.382683
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the  constructor
    """
    args = []
    description = "Duh"
    arg_name = "arg"
    type_name = "str"
    is_optional = True
    default = "None"

    subject = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert subject.args == []
    assert subject.description == "Duh"
    assert subject.arg_name == "arg"
    assert subject.type_name == "str"
    assert subject.is_optional == True
    assert subject.default == "None"

# Test of property Docstring.params

# Generated at 2022-06-23 16:57:55.441967
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    list_of_args_1 = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    list_of_args_2 = ['raises', 'raise', 'except', 'exception']
    docstring_raises = DocstringRaises(list_of_args_1, 'description', 'type_name')
    assert docstring_raises.args == list_of_args_1
    assert docstring_raises.description == 'description'
    assert docstring_raises.type_name == 'type_name'
    docstring_raises = DocstringRaises(list_of_args_2, 'description', 'type_name')
    assert docstring_raises.args == list_of_args_2
    assert docstring_raises.description == 'description'

# Generated at 2022-06-23 16:57:56.471546
# Unit test for constructor of class ParseError
def test_ParseError():
    pass



# Generated at 2022-06-23 16:58:00.894296
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    d = Docstring()
    d.short_description = None
    d.long_description = None
    d.meta = []
    return d



# Generated at 2022-06-23 16:58:07.834775
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    testargs = ["arg", "arg2"]
    testDescription = "This function is useless"
    testType = "int"
    testIsGenerator = False
    testReturnName = "Return Name"

    docstring = DocstringReturns(testargs, testDescription, testType, testIsGenerator, testReturnName)

    assert docstring.args == testargs
    assert docstring.description == testDescription
    assert docstring.type_name == testType
    assert docstring.is_generator == testIsGenerator
    assert docstring.return_name == testReturnName



# Generated at 2022-06-23 16:58:11.851274
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """
    Test the constructor of DocstringReturns
    """
    test_returns = DocstringReturns(['param'], 'description', 'type_name', False)
    assert test_returns.args == ['param']
    assert test_returns.description == 'description'
    assert test_returns.type_name == 'type_name'
    assert test_returns.is_generator == False
    assert test_returns.return_name == None



# Generated at 2022-06-23 16:58:16.032878
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """testing constructor of class DocstringDeprecated"""
    assert DocstringDeprecated([''], [''], None).args == ['']
    assert DocstringDeprecated([], [''], '1').description == ['']
    assert DocstringDeprecated([''], [''], '1').version == '1'



# Generated at 2022-06-23 16:58:19.455769
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test = DocstringMeta(["param"], "blah")
    assert test.args == ["param"]
    assert test.description == "blah"
    assert test.is_generator == False
    return True


# Generated at 2022-06-23 16:58:22.682616
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("There was an error in parsing")
    except ParseError as exc:
        assert exc.args[0] == "There was an error in parsing"



# Generated at 2022-06-23 16:58:24.759259
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta("1", "2")
    print(a.args)
    print(a.description)


# Generated at 2022-06-23 16:58:28.583948
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(["return", "returns"], "Description", "int", False)
    assert a.description == "Description"
    assert a.args == ["return", "returns"]
    assert a.return_name == None
    assert a.type_name == "int"
    assert a.is_generator == False


# Generated at 2022-06-23 16:58:37.517835
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    m = DocstringParam(args = ["arg"],
                       description = "description",
                       arg_name = "arg",
                       type_name = "str",
                       is_optional = True,
                       default = "1")
    assert m.args == ["arg"]
    assert m.description == "description"
    assert m.arg_name == "arg"
    assert m.type_name == "str"
    assert m.is_optional == True
    assert m.default == "1"


# Generated at 2022-06-23 16:58:41.167129
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError()
    assert isinstance(err, RuntimeError)


# Generated at 2022-06-23 16:58:51.360597
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    my_docstring = DocstringMeta(
        args=["indent", "arg_name", "type", "optional", "default"],
        description="desc"
    )
    if not(my_docstring.args == ["indent", "arg_name", "type", "optional", "default"]):
        raise ValueError("DocstringMeta.args should be a list of strings")
    if not(isinstance(my_docstring.args, list)):
        raise TypeError("DocstringMeta.args should be a list")
    if not(isinstance(my_docstring.args[0], str)):
        raise ValueError("DocstringMeta.args should be a list of strings")
    if not(my_docstring.description == "desc"):
        raise ValueError("DocstringMeta.description should be a string")

# Generated at 2022-06-23 16:59:02.450330
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    #case 1
    args = [":"]
    description = "this is a variable"
    arg_name = "a"
    type_name = "int"
    is_optional = False
    default = "3"
    DocstringParam1 = DocstringParam(
        args, description, arg_name, type_name, is_optional, default
    )
    assert DocstringParam1.args == [":"]
    assert DocstringParam1.description == "this is a variable"
    assert DocstringParam1.arg_name == "a"
    assert DocstringParam1.type_name == "int"
    assert DocstringParam1.is_optional == False
    assert DocstringParam1.default == "3"

    #case 2
    args = ["__init__"]
    description = "this is a variable"
    arg_

# Generated at 2022-06-23 16:59:05.061912
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():

    desc_meta = DocstringMeta(":param", "description")
    assert desc_meta.args == [":param"]
    assert desc_meta.description == "description"


# Generated at 2022-06-23 16:59:10.017273
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(2,3,4)
    assert x.args == 2, "Did not initialize properly"
    assert x.description == 3, "Did not initialize properly"
    assert x.type_name == 4, "Did not initialize properly"


# Generated at 2022-06-23 16:59:20.658489
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test_args = ['a', 'b', 'c']
    test_description = 'test'
    test_type_name = 'none'
    test_docstring_raises = DocstringRaises(test_args, test_description, test_type_name)
    assert test_docstring_raises.args == ['a', 'b', 'c']
    assert test_docstring_raises.description == 'test'
    assert test_docstring_raises.type_name == 'none'


# Generated at 2022-06-23 16:59:28.309647
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test Exception")
    except ParseError as e:
        print("Caught ParseError with message:")
        print("   " + str(e))

# Unittest for constructors of classes DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns, DocstringDeprecated

# Generated at 2022-06-23 16:59:32.642299
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # :deprecated: 1.1: Deprecation description goes here.
    meta = DocstringDeprecated(["deprecated"], "Deprecation description goes here.", "1.1")
    assert meta.version == "1.1"
    assert meta.description == "Deprecation description goes here."

# Generated at 2022-06-23 16:59:38.915317
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    deprecation=DocstringDeprecated(["deprecated"], "test", "1.0")
    assert deprecation.args == ["deprecated"]
    assert deprecation.description == "test"
    assert deprecation.version == "1.0"
        

# Generated at 2022-06-23 16:59:40.658681
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('ParseError test')
    except ParseError:
        pass

# Generated at 2022-06-23 16:59:42.374249
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['args'], 'description', 'type') # type: ignore



# Generated at 2022-06-23 16:59:54.061404
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Setup data for testing
    args = ['raises', 'TypeError']
    description = 'if something happens'
    type_name = 'TypeError'
    is_generator = False
    return_name = None
    # Initialize a new DocstringReturns instance
    docstring_returns = DocstringReturns(args,description,type_name,is_generator,return_name)
    # Run the unit test
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-23 17:00:04.965266
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test value of fields in constructor of class DocstringParam"""
    args = list()
    description = "test"
    arg_name = "arg_name"
    type_name = None
    is_optional = True
    default = None
    result = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert result.args == args
    assert result.description == description
    assert result.arg_name == arg_name
    assert result.type_name == type_name
    assert result.is_optional == is_optional
    assert result.default == default


# Generated at 2022-06-23 17:00:15.417071
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-23 17:00:21.849712
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
	doc = DocstringDeprecated(args=['param'], description='desc1', version='v1')

	assert(doc.args == ['param'])
	assert(doc.description == 'desc1')
	assert(doc.version == 'v1')



# Generated at 2022-06-23 17:00:26.544841
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.arg_name == arg_name
    assert docstring.type_name == type_name
    assert docstring.is_optional == is_optional
    assert docstring.default == default

# Generated at 2022-06-23 17:00:38.480920
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # :param arg: description
    data = DocstringReturns(["arg", "argument"], "description", "the_type", False)
    assert data.args == ["arg", "argument"]
    assert data.description == "description"
    assert data.type_name == "the_type"
    assert data.return_name is None
    assert data.is_generator is False

    # :param arg: description
    data = DocstringReturns(["arg", "argument"], "description", "the_type", True)
    assert data.args == ["arg", "argument"]
    assert data.description == "description"
    assert data.type_name == "the_type"
    assert data.return_name is None
    assert data.is_generator is True

    # :param arg: description

# Generated at 2022-06-23 17:00:41.983719
# Unit test for constructor of class Docstring
def test_Docstring():
    d1 = Docstring()
    assert isinstance(d1, Docstring)
    assert d1.short_description is None
    assert d1.long_description is None
    assert d1.meta == []



# Generated at 2022-06-23 17:00:53.887675
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arguments = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = False
    return_name = "return_name"
    dr = DocstringReturns(arguments, description, type_name, is_generator, return_name)
    assert(dr.args == arguments)
    assert(dr.description == description)
    assert(dr.is_generator == is_generator)
    assert(dr.return_name == return_name)
    assert(dr.type_name == type_name)
    print("DocstringReturns class works fine.")

test_DocstringReturns()

# Generated at 2022-06-23 17:00:57.589042
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docStringParam = DocstringParam(['param'], "The parameter", "arg", "int", True, "def")
    assert docStringParam.args == ['param']
    assert docStringParam.description == "The parameter"
    assert docStringParam.arg_name == "arg"
    assert docStringParam.type_name == "int"
    assert docStringParam.is_optional
    assert docStringParam.default == "def"



# Generated at 2022-06-23 17:01:05.672071
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Function to unit test the DocstringRaises constructor."""
    args = ['arg', 'argument']
    description = 'a Docstring meta item'
    type_name = 'ValueError'

    # create a DocstringRaises object
    docstring_raises = DocstringRaises(args, description, type_name)

    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name

test_DocstringRaises()

# Generated at 2022-06-23 17:01:07.704846
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(None, None, 'arg_name', 'type_name', None, None)
    assert a



# Generated at 2022-06-23 17:01:12.765801
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-23 17:01:15.161520
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    msg = "DocstringDeprecated message"
    version = "1.0"
    d = DocstringDeprecated(msg, version)
    assert d.description == msg
    assert d.version == version

# Generated at 2022-06-23 17:01:20.665959
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    result = DocstringRaises(["raise", "ValueError", "if"], "reason why!", "int")
    assert result.args == ["raise", "ValueError", "if"]
    assert result.description == "reason why!"
    assert result.type_name == "int"

# Generated at 2022-06-23 17:01:22.831263
# Unit test for constructor of class Docstring
def test_Docstring():
    simple_docstring = Docstring()
    assert isinstance(simple_docstring, Docstring)
    return

# Generated at 2022-06-23 17:01:23.488214
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    pass


# Generated at 2022-06-23 17:01:27.080087
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    print("Testing DocstringDeprecated constructor... ")
    dd = DocstringDeprecated([""], "", "")
    assert(dd.args == [])
    assert(dd.description == "")
    assert(dd.version == "")
    print("Passed.")


# Generated at 2022-06-23 17:01:29.274634
# Unit test for constructor of class ParseError
def test_ParseError():
    msg: str = "This is a parse error."
    try:
        raise ParseError("This is a parse error.")
    except ParseError as e:
        assert msg == e.args[0]

# Generated at 2022-06-23 17:01:31.956646
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "A deprecated function.", "1.2.3")
    assert docstring is not None

# Generated at 2022-06-23 17:01:34.514650
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    result = DocstringMeta(["Hello", "World"], "Test")
    assert result.args == ["Hello", "World"]
    assert result.description == "Test"


# Generated at 2022-06-23 17:01:38.445679
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(['raises', 'Exception'],
                                'General Exceptions raise',
                                'Exception')
    assert (a.args == ['raises', 'Exception'])
    assert (a.description == 'General Exceptions raise')
    assert (a.type_name == 'Exception')


# Generated at 2022-06-23 17:01:46.018994
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None

# Generated at 2022-06-23 17:01:48.162888
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    return DocstringParam([], "description", "arg", "value", True, "default")


# Generated at 2022-06-23 17:01:49.679416
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc_obj = DocstringDeprecated(["parameter"], "Description", "Version")
    assert doc_obj.args == ["parameter"]
    assert doc_obj.description == "Description"
    assert doc_obj.version == "Version"

# Generated at 2022-06-23 17:01:51.270175
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arguments = ["a","b"]
    description = "Description"
    docstring_meta = DocstringMeta(arguments,description)
    assert docstring_meta.args == arguments
    assert docstring_meta.description == description


# Generated at 2022-06-23 17:01:54.855865
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	new_class = DocstringMeta(args = [], description = 'hello')
	new_class.args == []
	new_class.description == 'hello'


# Generated at 2022-06-23 17:02:05.253335
# Unit test for constructor of class Docstring
def test_Docstring():
    std = Docstring()
    std.short_description = "This is a short description"
    std.long_description = "This is a long description"
    std.blank_after_short_description = True
    std.blank_after_long_description = True
    std.meta = [DocstringParam(["param"], "param description", "arg", "arg_type", False, None)]
    assert std.short_description == "This is a short description"
    assert std.long_description == "This is a long description"
    assert std.blank_after_short_description == True
    assert std.blank_after_long_description == True
    assert std.params[0].description == "param description"
    assert std.params[0].arg_name == "arg"

# Generated at 2022-06-23 17:02:08.090596
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert isinstance(DocstringMeta([], None), DocstringMeta)



# Generated at 2022-06-23 17:02:11.064592
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_value = DocstringReturns(['True'], "A short description", 'True', True)
    assert return_value.description == 'A short description'
    assert return_value.type_name == 'True'
    assert return_value.is_generator == True

# Generated at 2022-06-23 17:02:16.031022
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():

    #Test 1 with default type_name and description
    description = None
    args = ".. deprecated:: 1.2 Use something else instead.".split()
    version = "1.2"
    type_name = None
    old = DocstringDeprecated(args, description, version)
    new = DocstringDeprecated(args, description, version)

    assert old.args == new.args
    assert old.description == new.description
    assert old.type_name == new.type_name
    assert old.version == new.version

    #Test 2 with default type_name
    description = "This is a test description."
    args = ".. deprecated:: 1.2 Use something else instead.".split()
    version = "1.2"
    type_name = None
    old = DocstringDeprecated(args, description, version)
    new

# Generated at 2022-06-23 17:02:22.017879
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-23 17:02:25.295472
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("test")
    assert error.args == ("test",)


# Generated at 2022-06-23 17:02:27.505346
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError('The message of the error')
    assert str(e) == 'The message of the error'

# Generated at 2022-06-23 17:02:32.200610
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert len(docstring.meta) == 0



# Generated at 2022-06-23 17:02:34.757609
# Unit test for constructor of class ParseError
def test_ParseError():
    name = "function_name"
    message = "message"
    e = ParseError(name, message)
    assert e.args[0] == "function_name: message"


# Generated at 2022-06-23 17:02:36.806701
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Test message')
    except:
        x = 1


# Generated at 2022-06-23 17:02:42.064044
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["args", "arg2"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = False
    default = None

    doc_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    assert doc_param.args == args
    assert doc_param.description == description
    assert doc_param.arg_name == arg_name
    assert doc_param.type_name == type_name
    assert doc_param.is_optional == is_optional
    assert doc_param.default == default


# Generated at 2022-06-23 17:02:43.884591
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises", "Raises"], "Test", "TypeError")


# Generated at 2022-06-23 17:02:45.579363
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass


# Generated at 2022-06-23 17:02:55.213327
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docParam = DocstringParam(["a","b"],"abc","testArgName","testTypeName",True,"testDefault")

    assert(docParam.args[0] == "a")
    assert(docParam.args[1] == "b")
    assert(docParam.description == "abc")
    assert(docParam.arg_name == "testArgName")
    assert(docParam.type_name == "testTypeName")
    assert(docParam.is_optional == True)
    assert(docParam.default == "testDefault")


# Generated at 2022-06-23 17:02:56.769195
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
        DocstringDeprecated(["deprecated"], "This function should not be used", "1.3.4")

# Generated at 2022-06-23 17:03:00.605960
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        print(1 / 0)
    except ZeroDivisionError as e:
        e = ParseError(str(e))
        raise e

# Generated at 2022-06-23 17:03:02.106839
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description")

# Generated at 2022-06-23 17:03:03.965771
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(None, None)
    pass


# Generated at 2022-06-23 17:03:06.799992
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(["raises"], "because", "ValueError")
    assert test.type_name == "ValueError"
    assert test.description == "because"
    assert test.args == ["raises"]

# Generated at 2022-06-23 17:03:09.671271
# Unit test for constructor of class ParseError
def test_ParseError():
    # Instantiate ParseError with a string
    parse_error = ParseError('Test ParseError')

    # Check if the error string was initialized correctly.
    assert isinstance(parse_error, ParseError)
    assert parse_error.args[0] == 'Test ParseError'


# Generated at 2022-06-23 17:03:13.477440
# Unit test for constructor of class Docstring
def test_Docstring():    # NOSONAR
    """Unit test for constructor of class Docstring"""
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:03:14.738917
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(RuntimeError):
        raise ParseError

# Generated at 2022-06-23 17:03:19.984780
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args_list = [":param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = None
    is_optional = None
    default = None
    assert DocstringParam(args_list, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-23 17:03:23.945700
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["deprecated"], "test", "1.0")
    assert test.args == ["deprecated"]
    assert test.description == "test"
    assert test.version == "1.0"


# Generated at 2022-06-23 17:03:33.442198
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated", ": since 1.0"],
        "This is the description of deprecation", "1.0") == DocstringDeprecated(["deprecated", ": since 1.0"],
        "This is the description of deprecation", "1.0")
    assert DocstringDeprecated(["deprecated", ": since 1.0"], "This is the description of deprecation", "1.0") != DocstringDeprecated(["deprecated", ": since 2.0"],
        "This is the description of deprecation", "1.0")

# Unit tests for constructor of class DocstringRaises

# Generated at 2022-06-23 17:03:39.649212
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Create with constructor of class DocstringParam"""
    DocstringParam1 = DocstringParam("param arg: description", "arg_name",
                                     "type_name", True, "default")
    assert DocstringParam1.args == "param arg: description"
    assert DocstringParam1.description == "arg_name"
    assert DocstringParam1.arg_name == "type_name"
    assert DocstringParam1.type_name == True
    assert DocstringParam1.is_optional is True
    assert DocstringParam1.default == "default"

# Generated at 2022-06-23 17:03:43.520191
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  a = DocstringRaises([1,2],None,3)
  assert a.args[0] == 1
  assert a.args[1] == 2
  assert a.description == None
  assert a.type_name == 3


# Generated at 2022-06-23 17:03:45.789969
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(args=["arg"], description="Hello")


# Generated at 2022-06-23 17:03:47.878367
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        assert ParseError("test")
    except ParseError:
        assert True


# Generated at 2022-06-23 17:03:53.301713
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    temp_DocstringMeta = DocstringMeta(["parameter", "arg", "argument", "attribute",
                                        "key", "keyword"], "Description")
    assert temp_DocstringMeta.args == ["parameter", "arg", "argument", "attribute",
                                       "key", "keyword"]
    assert temp_DocstringMeta.description == "Description"


# Generated at 2022-06-23 17:03:58.589917
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:04:03.530027
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(Docstring().short_description == None)
    assert(Docstring().long_description == None)
    assert(Docstring().blank_after_short_description == False)
    assert(Docstring().blank_after_long_description == False)
    assert(Docstring().meta == [])

test_Docstring()


# Generated at 2022-06-23 17:04:07.237590
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param", "parameter", "arg", "argument"], "Description", "arg", "str", None, None)
    assert(param.args == ["param", "parameter", "arg", "argument"])
    assert(param.description == "Description")
    assert(param.arg_name == "arg")
    assert(param.type_name == "str")


# Generated at 2022-06-23 17:04:11.407616
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # create object of DocstringMeta
    x = DocstringMeta([], None)
    # pass list of args
    x.args = ['args']
    # pass description of the args
    x.description = 'description of the args'
    assert x.args == ['args']
    assert x.description == 'description of the args'


# Generated at 2022-06-23 17:04:15.670346
# Unit test for constructor of class ParseError
def test_ParseError():
  a = ParseError('ParseError tester')
  a.__str__()
  assert(a.__str__() == 'ParseError tester')


# Generated at 2022-06-23 17:04:18.045241
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        d=DocstringMeta(['V','V'], 'test')
    except:
        print('Error in DocstringMeta constructor')


# Generated at 2022-06-23 17:04:21.743149
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [' rais', 'e', 'Value', 'Error:']
    description = 'if something happens'
    type_name = 'ValueError'
    x = DocstringRaises(args, description, type_name)
    assert x.args == args
    assert x.description == description
    assert x.type_name == type_name



# Generated at 2022-06-23 17:04:24.707894
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(args = ["raises", "ValueError"], description = "If the arg does not exist", type_name = 'ValueError')


# Generated at 2022-06-23 17:04:29.026236
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert len(docstring.meta) == 0



# Generated at 2022-06-23 17:04:37.243695
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        args=['return', 'returns'], 
        description='test description', 
        type_name='test type name', 
        is_generator=False, 
        return_name='test return name'
    )

    # Assert type_name is of type string
    assert isinstance(docstring_returns.type_name, str)
    # Assert return_name is of type string
    assert isinstance(docstring_returns.return_name, str)
    # Assert is_generator is of type bool
    assert isinstance(docstring_returns.is_generator, bool)



# Generated at 2022-06-23 17:04:46.397296
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert isinstance(docstring.meta, list)
    assert len(docstring.meta) == 0
    assert isinstance(docstring.params, list)
    assert isinstance(docstring.raises, list)
    assert isinstance(docstring.returns, tuple)
    assert isinstance(docstring.deprecation, tuple)


# Generated at 2022-06-23 17:04:50.589340
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d = DocstringReturns(args=["arg1", "arg2"], description="Description", type_name="TypeName", is_generator=False, return_name="ReturnName")
    assert d.args[0] == "arg1"
    assert d.args[1] == "arg2"
    assert d.description == "Description"
    assert d.type_name == "TypeName"
    assert not d.is_generator
    assert d.return_name == "ReturnName"



# Generated at 2022-06-23 17:04:54.286288
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        # Create a parse error
        error = ParseError("This is a test")


# Generated at 2022-06-23 17:04:56.443770
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    import doctring
    doctring.DocstringReturns(['param'], 'description', 'str', True, 'return_name')

# Generated at 2022-06-23 17:04:59.154851
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(1, 2, 3)
    assert a.args == 1
    assert a.description == 2
    assert a.version == 3


# Generated at 2022-06-23 17:05:03.137908
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-23 17:05:05.029957
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError('Test')
    assert True


# Generated at 2022-06-23 17:05:07.939739
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["param"], "test")
    assert dm.args == ["param"]
    assert dm.description == "test"


# Generated at 2022-06-23 17:05:09.398746
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for all subclass of ParseError."""
    raise ParseError() from None  # type: ignore
    raise ParseError("message") from None  # type: ignore



# Generated at 2022-06-23 17:05:11.893510
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([':raises'], 'ValueError', 'Something happens')
    assert a.type_name == 'Something happens'

# Generated at 2022-06-23 17:05:15.419264
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ""
    description = ""
    arg_name = ""
    type_name = ""
    is_optional = False
    default = ""
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param


# Generated at 2022-06-23 17:05:19.393939
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises([], "something", "ValueError")
    assert a.args == []
    assert a.description == "something"
    assert a.type_name == "ValueError"



# Generated at 2022-06-23 17:05:20.596867
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["a"], "b")

# Generated at 2022-06-23 17:05:23.977557
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    obj = DocstringMeta(args = ["arg"],description = "description")
    assert(len(obj.args) == 1)
    assert(obj.description == "description")


# Generated at 2022-06-23 17:05:27.195034
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test = DocstringDeprecated(["1","2"],"hello","1")
    assert ["1","2"] == test.args
    assert test.description == "hello"
    assert test.version == "1"