

# Generated at 2022-06-23 16:55:31.609003
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['arg'], 'description', 'type', True, 'return')



# Generated at 2022-06-23 16:55:34.703995
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print('Test _init_')
    docstring = DocstringRaises(['arg1', 'arg2'], 'Exception for invalid call', 'ValueError')
    assert docstring.args == ['arg1', 'arg2']
    assert docstring.description == 'Exception for invalid call'
    assert docstring.type_name == 'ValueError'


# Generated at 2022-06-23 16:55:37.333660
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("This is a test error.")
    assert error.args[0] == "This is a test error."


# Generated at 2022-06-23 16:55:38.987861
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["return"], "None.", "None", False, "-")


# Generated at 2022-06-23 16:55:47.427612
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param"]
    description = "TODO "
    type_name = "int"
    is_generator = True
    return_name = "return_name"
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert returns.args == args
    assert returns.description == description
    assert returns.type_name == type_name
    assert returns.is_generator == is_generator
    assert returns.return_name == return_name


# Generated at 2022-06-23 16:55:50.783548
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = []
    description = '''asdf'''
    version = '''1.0'''
    DocstringDeprecated(args, description, version)
    print("DocstringDeprecated : Test 1 : Passed")


# Generated at 2022-06-23 16:55:56.255914
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = [":param"]
    description = "something"
    arg_name = "arg"
    type_name = "int"
    is_optional = False
    default = None
    try:
        tmp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    except:
        assert False

# Generated at 2022-06-23 16:55:58.062194
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    with pytest.raises(AssertionError):
        assert DocstringMeta(['arg','arg2','arg3'], 'this is a description')


# Generated at 2022-06-23 16:55:59.625868
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    x = DocstringRaises(args = [], description = "test", type_name = None)
    assert x.args == []
    assert x.description == "test"
    assert x.type_name == None

# Generated at 2022-06-23 16:56:02.692436
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arg_list = ['arg1', 'arg2']
    description = 'description'
    
    test_dm = DocstringMeta(arg_list, description)
    assert isinstance(test_dm, DocstringMeta)
    assert test_dm.args == arg_list
    assert test_dm.description == description


# Generated at 2022-06-23 16:56:09.191263
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    line = ''':param x: some param
    :return: some return
    :rtype: str'''
    parser = DocstringParser()
    docstring = parser.parse(line)
    assert docstring.returns.description == "some return"
    assert docstring.returns.type_name == "str"


# Generated at 2022-06-23 16:56:11.608252
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test ParseError")
    except ParseError as e:
        print(e)


# Generated at 2022-06-23 16:56:14.434159
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # test the empty case
    with pytest.raises(TypeError):
        DocstringMeta()


# Generated at 2022-06-23 16:56:15.380207
# Unit test for constructor of class ParseError
def test_ParseError():
    assert 1 == 1



# Generated at 2022-06-23 16:56:21.810528
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['a']
    description = 'b'
    type_name = 'c'
    is_generator = False
    return_name = 'd'

    dr = DocstringReturns(args,description,type_name,is_generator,return_name)
    assert dr.args is args
    assert dr.description is description
    assert dr.type_name is type_name
    assert dr.is_generator is is_generator
    assert dr.return_name is return_name



# Generated at 2022-06-23 16:56:27.636902
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["arg:", "description"], "sample_description", "arg_name", "type_name", "is_optional", "default")
    assert docstring_param.args == ["arg:", "description"]
    assert docstring_param.default == "default"
    assert docstring_param.description == "sample_description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == "is_optional"


# Generated at 2022-06-23 16:56:30.752857
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(['yield', 'yields'], 'Type of item to yield.',
                     'list', True, 'item')



# Generated at 2022-06-23 16:56:32.185223
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-23 16:56:34.611357
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test=DocstringMeta("", "")
    assert test.args == ""
    assert test.description == ""



# Generated at 2022-06-23 16:56:36.045490
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises'], 'description', 'TypeError')

# Generated at 2022-06-23 16:56:41.431943
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test = DocstringReturns(args = ["a","b"], description = "d", type_name = "t", is_generator = False, return_name = "r")
    assert(test.args[0] == "a")
    assert(test.args[1] == "b")
    assert(test.description == "d")
    assert(test.type_name == "t")
    assert(test.is_generator == False)
    assert(test.return_name == "r")


# Generated at 2022-06-23 16:56:43.582144
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        print("Passed")


# Generated at 2022-06-23 16:56:46.652111
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta([], "")
    assert d.args == []
    assert d.description == ""



# Generated at 2022-06-23 16:56:51.470702
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    version = "1.0"
    args = ["deprecated", "func", "deprecated_func"]
    description = "Deprecated function"
    o = DocstringDeprecated(args, description, version)
    assert o.version == version
    assert o.description == description
    assert o.args == args


# Generated at 2022-06-23 16:56:56.282447
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  d = DocstringRaises(["param"], "valueError raised","ValueError")
  assert(d.args == ['param'])
  assert(d.description == 'valueError raised')
  assert(d.type_name == 'ValueError')


# Generated at 2022-06-23 16:56:59.835413
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(['parameter'], 'description', 'type_name')
    assert docstring.args == ['parameter']
    assert docstring.description == 'description'
    assert docstring.type_name == 'type_name'



# Generated at 2022-06-23 16:57:02.545472
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("something went wrong")
    assert "something went wrong" in error.args[0]


# Generated at 2022-06-23 16:57:07.942444
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["a"]
    description = "A description"
    version = "1.2"
    Test = DocstringDeprecated(args, description, version)
    Test.description == description
    Test.version == version
    Test.args == args


# Generated at 2022-06-23 16:57:11.277104
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['args'], 'description', 'version')
    assert d.args == ['args']
    assert d.description == 'description'
    assert d.version == 'version'

if __name__ == '__main__':
    test_DocstringDeprecated()

# Generated at 2022-06-23 16:57:22.226221
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["arg"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    dDocstringParam = DocstringParam(args, description, arg_name, type_name, is_optional, default)

    if not dDocstringParam.args == args:
        return False
    if not dDocstringParam.description == description:
        return False
    if not dDocstringParam.arg_name == arg_name:
        return False
    if not dDocstringParam.type_name == type_name:
        return False
    if not dDocstringParam.is_optional == is_optional:
        return False
    if not dDocstringParam.default == default:
        return False

    return True

#

# Generated at 2022-06-23 16:57:29.838301
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_args=['test_arg']
    test_description='test_description'
    test_arg_name='test_arg_name'
    test_type_name='test_type_name'
    test_is_optional=True
    test_default="default"
    test_obj=DocstringParam(test_args,test_description,test_arg_name,test_type_name,test_is_optional,test_default)
    assert test_obj.args==test_args
    assert test_obj.description==test_description
    assert test_obj.arg_name==test_arg_name
    assert test_obj.type_name==test_type_name
    assert test_obj.is_optional==test_is_optional
    assert test_obj.default==test_default

# Generated at 2022-06-23 16:57:32.092573
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert(DocstringReturns(["returns"], "None", "None", "False") is not None)



# Generated at 2022-06-23 16:57:34.093290
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(ParseError):
        raise ParseError("test error")



# Generated at 2022-06-23 16:57:39.256971
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
  x1 = DocstringDeprecated(args=['s'], description=None, version=None)
  assert x1.version == None
  assert x1.description == None
  assert x1.args == ['s']
  x2 = DocstringDeprecated(args=['t'], description=None, version=None)
  assert x2.version == None
  assert x2.description == None
  assert x2.args == ['t']


# Generated at 2022-06-23 16:57:41.069662
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, '', False, '')


# Generated at 2022-06-23 16:57:42.770245
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("Error")

# Generated at 2022-06-23 16:57:45.297602
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for DocstringDeprecated constructor."""
    description = "This is a description"
    vers = "1.0"
    args = []
    deprecated = DocstringDeprecated(args, description, vers)
    assert deprecated.description == description
    assert deprecated.version == vers
    assert deprecated.args == []

# Generated at 2022-06-23 16:57:50.809370
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test1 = DocstringDeprecated(["deprecated"], "version 1.0", "1.0")
    test2 = DocstringDeprecated(["deprecated"], "version 1.0", "2.0")
    assert test1.version == "1.0"
    assert test2.version == "2.0"


# Generated at 2022-06-23 16:57:52.855200
# Unit test for constructor of class ParseError
def test_ParseError():
    # type: () -> None
    try:
        raise ParseError("error")
    except ParseError:
        pass


# Generated at 2022-06-23 16:57:59.246364
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description is None
    assert a.long_description is None
    assert a.blank_after_short_description is False
    assert a.blank_after_long_description is False
    assert a.meta == []


# Generated at 2022-06-23 16:58:07.616271
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    n = DocstringReturns(["arg"], "description", "arg", is_generator=True)
    assert n.description == "description"
    assert n.args == ["arg"]
    assert n.type_name == "arg"
    assert n.is_generator
    assert n.return_name == None
    m = DocstringReturns(["arg"], "description", "arg", is_generator=True, return_name="name")
    assert m.description == "description"
    assert m.args == ["arg"]
    assert m.type_name == "arg"
    assert m.is_generator
    assert m.return_name == "name"



# Generated at 2022-06-23 16:58:13.704812
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises', 'error'], 'this is error', 'type')
    DocstringRaises(['raises', 'error'], None, 'type')
    DocstringRaises(['raises', 'error'], 'this is error', None)
    try:
        DocstringRaises(['raises', 'error'], None, None)
    except TypeError:
        pass

# Generated at 2022-06-23 16:58:16.999277
# Unit test for constructor of class ParseError
def test_ParseError():
	try:
		raise ParseError
	except ParseError:
		pass


# Generated at 2022-06-23 16:58:20.608759
# Unit test for constructor of class ParseError
def test_ParseError():
    """Name of test."""
    with pytest.raises(RuntimeError):
        raise ParseError("message")


# Generated at 2022-06-23 16:58:28.663932
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    d = DocstringParam(
        args=['arg'],
        description='test',
        arg_name='arg',
        type_name='int',
        is_optional=True,
        default=None,
    )
    assert d.args == ['arg']
    assert d.description == 'test'
    assert d.arg_name == 'arg'
    assert d.type_name == 'int'
    assert d.is_optional == True
    assert d.default == None


# Generated at 2022-06-23 16:58:34.853672
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns("args", "description", "type_name", True)
    assert returns.args == "args"
    assert returns.description == "description"
    assert returns.type_name == "type_name"
    assert returns.is_generator == True


# Generated at 2022-06-23 16:58:41.322948
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = []
    description = "text"
    arg_name = "arg1"
    type_name = "type1"
    is_optional = "optional"
    default = "default"
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == args
    assert dp.description == description
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default


# Generated at 2022-06-23 16:58:43.160664
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['deprecated', 'since', 'v.19.04'], 'This class is deprecated', 'v.19.04')
    assert d is not None


# Generated at 2022-06-23 16:58:46.336822
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None


# Generated at 2022-06-23 16:58:48.402169
# Unit test for constructor of class ParseError
def test_ParseError():
    raise(ParseError)

# Generated at 2022-06-23 16:58:54.843162
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor for class DocstringMeta."""
    test_docstring_meta = DocstringMeta([], 'this is a description')
    assert test_docstring_meta.args == []
    assert test_docstring_meta.description == 'this is a description'


# Generated at 2022-06-23 16:58:56.993229
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "This is a parameter")



# Generated at 2022-06-23 16:58:59.149005
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DR = DocstringRaises(["a", "b"], "c", "d")
    assert DR


# Generated at 2022-06-23 16:59:04.583360
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        try:
            raise Exception
        except:
            raise ParseError('test')
    except ParseError as e:
        print(e)   #should print 'test'


# Generated at 2022-06-23 16:59:07.273178
# Unit test for constructor of class ParseError
def test_ParseError():
    obj = ParseError('oh no')
    assert obj.args == ('oh no',)


# Generated at 2022-06-23 16:59:10.954853
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	a = DocstringRaises(["raises"], "desc", "type")
	assert a.args == ["raises"]
	assert a.description == "desc"
	assert a.type_name == "type"


# Generated at 2022-06-23 16:59:17.590365
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()

    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-23 16:59:20.352646
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["a", "b", "c"], "testing") == 1


# Generated at 2022-06-23 16:59:25.786148
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dmeta = DocstringMeta(["param", "arg"], "description")
    assert dmeta.args == ["param", "arg"]
    assert dmeta.description == "description"


# Generated at 2022-06-23 16:59:26.826641
# Unit test for constructor of class Docstring
def test_Docstring():
    tester = Docstring()
    assert tester


# Generated at 2022-06-23 16:59:31.541886
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is a ParseError test.")
    except ParseError:
        pass
    else:
        assert False

# Generated at 2022-06-23 16:59:36.751496
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["a", "b"]
    description = "description"
    dm = DocstringMeta(args, description)
    assert dm.args == args
    assert dm.description == description

# Generated at 2022-06-23 16:59:37.411503
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-23 16:59:42.485580
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():

    class TestClass(DocstringRaises):
        def __init__(self):
            args = "kwargs"
            description = "description"
            type_name = "type_name"
            super().__init__(args, description, type_name)
    # END Class TestClass
# END unit test



# Generated at 2022-06-23 16:59:48.973304
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-23 16:59:53.320694
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    to_be_tested = DocstringReturns(None, None, None, None)
    assert to_be_tested.args == None
    assert to_be_tested.description == None
    assert to_be_tested.type_name == None
    assert to_be_tested.is_generator == None
    assert to_be_tested.return_name == None


# Generated at 2022-06-23 16:59:59.662846
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_is_generator = True
    test_args = ["test_args"]
    test_return_name = "test_return_name"
    test_description = "test_description"
    test_type_name = "test_type_name"
    test_result = DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    print("test_result.args: ", test_result.args)
    print("test_result.description: ", test_result.description)
    print("test_result.type_name: ", test_result.type_name)
    print("test_result.is_generator: ", test_result.is_generator)
    print("test_result.return_name: ", test_result.return_name)



# Generated at 2022-06-23 17:00:06.465603
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args=['param', 'parameter', 'arg', 'argument']
    description="Some description"
    type_name="int"
    is_generator=True
    return_name="a"
    docstring_returns=DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.type_name==type_name
    assert docstring_returns.is_generator==is_generator
    assert docstring_returns.return_name==return_name

# Generated at 2022-06-23 17:00:13.453876
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['args']
    description = "test description"
    arg_name = 'test_arg_name'
    type_name = 'test_type_name'
    is_optional = True
    default = 'test_default'
    DocstringParam(args, description, arg_name, type_name, is_optional, default)


# Generated at 2022-06-23 17:00:16.680201
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:00:21.544220
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['description']
    description = "some description"
    type_name = "TypeError"
    _ = DocstringRaises(args, description, type_name)

# Generated at 2022-06-23 17:00:27.854283
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a=DocstringReturns(["string"], "Raise ValueError", "ValueError", True, "this_function")
    assert isinstance(a,DocstringReturns)
    assert a.args == ["string"]
    assert a.description == "Raise ValueError"
    assert a.type_name =="ValueError"
    assert a.is_generator is True
    assert a.return_name =="this_function"

# Generated at 2022-06-23 17:00:31.514533
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """This function tests if the constructor of class DocstringDeprecated 
    works properly."""
    assert DocstringDeprecated(["a"], "description", 1).description == "description"


# Generated at 2022-06-23 17:00:35.702174
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a_docstring = DocstringMeta(['param arg'], "Hello world!")
    assert a_docstring.args == ['param arg']
    assert a_docstring.description == "Hello world!"



# Generated at 2022-06-23 17:00:41.214370
# Unit test for constructor of class Docstring
def test_Docstring():
    print("*** Testing Docstring...")
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    print("OK!")



# Generated at 2022-06-23 17:00:44.808258
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass
    print("test passed")



# Generated at 2022-06-23 17:00:48.359538
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    dep = DocstringDeprecated(['deprecated'], 'Use :any:`abc` or xyz instead.', '0.1')
    return dep.version

# Generated at 2022-06-23 17:00:52.199675
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """
    test_DocstringDeprecated is the unit test for constructor of class DocstringDeprecated
    :return:
    """
    a = DocstringDeprecated(['a'], '123', [1])



# Generated at 2022-06-23 17:00:56.469728
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert isinstance(DocstringMeta(['hola'], 'hola'), DocstringMeta)

# Unit tests for constructor of class DocstringParam

# Generated at 2022-06-23 17:01:00.377986
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = ""
    type_name = ""
    assert DocstringRaises(args,description,type_name) == None


# Generated at 2022-06-23 17:01:07.576807
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    '''

    :param test:
    :return:
    '''
    print("\nRunning unit test for ${test_DocstringDeprecated.__name__}")
    a = DocstringDeprecated(["hello", "world", "in", "a", "list"], "asdf", "test")
    print('a.args', a.args)
    print('a.description', a.description)
    print('a.version', a.version)

test_DocstringDeprecated()



# Generated at 2022-06-23 17:01:13.772659
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [':param']
    description = 'This is a description'
    type_name = 'ValueError'

    doc = DocstringRaises(args,description,type_name)
    assert doc.args == [':param']
    assert doc.description == 'This is a description'
    assert doc.type_name == 'ValueError'
    return doc



# Generated at 2022-06-23 17:01:19.673857
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(['a','b','c'], 2, 3)
    assert docstring_raises.args == ['a','b','c']
    assert docstring_raises.description == 2
    assert docstring_raises.type_name == 3


# Generated at 2022-06-23 17:01:22.572522
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    D = DocstringMeta(args=["param"], description="description")
    assert D.args[0] == "param"
    assert D.description == "description"


# Generated at 2022-06-23 17:01:26.937640
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    x = DocstringDeprecated(["param"], "param description", "1.5")
    assert x.args[0] == "param", "args should return param"
    assert x.description == "param description", "description should return param description"
    assert x.version == "1.5", "version should return 1.5"


# Generated at 2022-06-23 17:01:30.621730
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Some error occured')
    except ParseError as e:
        assert (str(e) == 'Some error occured')

# Generated at 2022-06-23 17:01:32.849083
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
   a = DocstringMeta(["param"], "description")
   assert a.args == ["param"]
   assert a.description == "description"


# Generated at 2022-06-23 17:01:40.763349
# Unit test for constructor of class Docstring
def test_Docstring():
	#Instatiate an object from class
	docstring = Docstring()
	
	#Assert that the properties are not None
	assert (docstring.meta is not None)
	assert (docstring.returns is not None)
	assert (docstring.deprecation is not None)
	
	#Assert short description
	assert (docstring.short_description is None)
	docstring.short_description = "testing short description"
	assert (docstring.short_description is not None)
	assert (docstring.short_description == "testing short description")
	
	#Assert long description
	assert (docstring.long_description is None)
	docstring.long_description = "testing long description"
	assert (docstring.long_description is not None)

# Generated at 2022-06-23 17:01:45.136859
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['return', 'returns']
    description = 'Return X and Y'
    type_name = 'int'
    is_generator = False
    return_name = 'Z'
    assert DocstringReturns(args, description, type_name, is_generator, return_name).args == args
    assert DocstringReturns(args, description, type_name, is_generator, return_name).description == description
    assert DocstringReturns(args, description, type_name, is_generator, return_name).type_name == type_name
    assert DocstringReturns(args, description, type_name, is_generator, return_name).is_generator == is_generator
    assert DocstringReturns(args, description, type_name, is_generator, return_name).return_name == return_name
    assert Doc

# Generated at 2022-06-23 17:01:49.882081
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta==[]



# Generated at 2022-06-23 17:01:55.833165
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test1 = DocstringMeta(["param", "arg"], "this is test 1")
    assert isinstance(test1.args, list)
    assert test1.args == ["param", "arg"]
    assert test1.description == "this is test 1"


# Generated at 2022-06-23 17:02:04.064558
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param_name = "param_name"
    param_desc = "param_desc"
    type_name = "type_name"
    is_optional = True
    default_value = "default_value"
    obj = DocstringParam(param_name, param_desc, type_name, is_optional, default_value)
    # Test that everything is correct for type and name
    assert obj.arg_name == param_name
    assert obj.description == param_desc
    assert obj.type_name == type_name
    assert obj.is_optional == is_optional
    assert obj.default == default_value


# Generated at 2022-06-23 17:02:08.848897
# Unit test for constructor of class Docstring
def test_Docstring():
    # constructor of class Docstring
    doc_string = Docstring()
    assert doc_string is not None
    assert doc_string.short_description is None
    assert doc_string.long_description is None
    assert doc_string.blank_after_short_description is False
    assert doc_string.blank_after_long_description is False
    assert doc_string.meta == [] 

# Generated at 2022-06-23 17:02:13.680860
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param","arg1","arg2","argument"]
    arg_name = "arg3"
    type_name = "parameter"
    is_optional = True
    default = "parameter"
    description = "test"
    par = DocstringReturns(args, description, type_name, is_optional, return_name)
    assert par.args == args
    assert par.description == description
    assert par.type_name == type_name
    assert par.is_optional == is_optional
    assert par.return_name == return_name


# Generated at 2022-06-23 17:02:20.047594
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arg = ["test"]
    description = "This is a function"
    doc_test = DocstringMeta(arg, description)
    assert doc_test.args == arg
    assert doc_test.description == description

    assert doc_test.args != arg
    assert doc_test.description != description


# Generated at 2022-06-23 17:02:24.771851
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns(['returns'], 'returns the result', 'int', False)
    assert isinstance(doc, DocstringReturns)
    assert doc.args == ['returns']
    assert doc.description == 'returns the result'
    assert doc.type_name == 'int'
    assert doc.is_generator == False


# Generated at 2022-06-23 17:02:26.255550
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    meta = DocstringRaises()
    assert meta is not None

# Generated at 2022-06-23 17:02:33.723906
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = None
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = 'False'
    default = 'default'
    testObject = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert testObject.args == args
    assert testObject.description == description
    assert testObject.arg_name == arg_name
    assert testObject.type_name == type_name
    assert testObject.is_optional == is_optional
    assert testObject.default == default
    


# Generated at 2022-06-23 17:02:36.975676
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    var1 = DocstringRaises(['args'], 'description', 'type_name')
    assert var1.args==['args']
    assert var1.description=='description'
    assert var1.type_name=='type_name'


# Generated at 2022-06-23 17:02:41.109802
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(args="param", description="description", arg_name="arg name", type_name="type name", is_optional="optional", default="default")
    assert a.args == "param"
    assert a.description == "description"
    assert a.arg_name == "arg name"
    assert a.type_name == "type name"
    assert a.is_optional == "optional"
    assert a.default == "default"


# Generated at 2022-06-23 17:02:43.639301
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    try:
        DocstringMeta(['a'], 'b')
    except ParseError as e:
        print(e)

# Generated at 2022-06-23 17:02:51.161367
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises(
        args=['parameter', 'arg', 'argument', 'attribute', 'key', 'keyword'],
        description='description',
        type_name='type_name'
    )
    assert(docstring.args == ['parameter', 'arg', 'argument', 'attribute', 'key', 'keyword'])
    assert(docstring.description == 'description')
    assert(docstring.type_name == 'type_name')


# Generated at 2022-06-23 17:02:54.496686
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], 'This is a description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-23 17:02:56.898515
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    x = DocstringDeprecated(
        "hello",
        "hi",
        "hi",
    )
    assert x.args is not None
    assert x.description is not None
    assert x.version is not None

# Generated at 2022-06-23 17:02:59.181748
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()


# Generated at 2022-06-23 17:03:05.395267
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args: T.List[str] = []
    description: T.Optional[str] = "description"
    version: T.Optional[str] = "1.2.0"
    d = DocstringDeprecated(args, description, version)
    assert d.description == "description"
    assert d.version == "1.2.0"


# Generated at 2022-06-23 17:03:09.712921
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = 'description'
    type_name = 'type'
    test = DocstringRaises(args, description, type_name)
    assert test.args == ['arg']
    assert test.description == 'description'
    assert test.type_name == 'type'


# Generated at 2022-06-23 17:03:11.036227
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("")
    except ParseError:
        pass


# Generated at 2022-06-23 17:03:12.323796
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], "", "")


# Generated at 2022-06-23 17:03:15.232826
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        DocstringRaises(args = [],
                    description = None,
                    type_name = None)
        print('Passed')
    except:
        print('Failed')

test_DocstringRaises()

# Generated at 2022-06-23 17:03:20.294250
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(
        ['DocstringParam'], 'This is a description', 'arg_name',
        'type_name', 'is_optional', 'default'
    )
    assert dp.args == ['DocstringParam']
    assert dp.description == 'This is a description'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == 'is_optional'
    assert dp.default == 'default'


# Generated at 2022-06-23 17:03:31.951451
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    args = ["arg", "int", "string", "default value"]
    description = "This is the description of DocstringParam"
    docstringParam = DocstringParam(args, description, "arg", "int", None, "default value")
    if docstringParam.arg_name != "arg":
        print("Error: docstringParam.arg_name is not 'arg' when it should be")
    if docstringParam.type_name != "int":
        print("Error: docstringParam.type_name is not 'int' when it should be")
    if docstringParam.is_optional is not None:
        print("Error: docstringParam.is_optional is not None when it should be")

# Generated at 2022-06-23 17:03:37.791761
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param", "arg", "description"], "description", "arg", "description", False, False)
    assert dp.description == "description"
    assert dp.args == ["param", "arg", "description"]
    assert dp.arg_name == "arg"
    assert dp.type_name == "description"
    assert dp.is_optional == False
    assert dp.default == False


# Generated at 2022-06-23 17:03:39.839518
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(['param'], 'description')
    assert(dm.args == ['param'])
    assert(dm.description == 'description')


# Generated at 2022-06-23 17:03:40.847344
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()


# Generated at 2022-06-23 17:03:43.094372
# Unit test for constructor of class ParseError
def test_ParseError():
    e = ParseError()
    assert isinstance(e, RuntimeError)

#===============================================================================

# Generated at 2022-06-23 17:03:44.536913
# Unit test for constructor of class ParseError
def test_ParseError():
    test_error = ParseError("test error")

# Generated at 2022-06-23 17:03:51.412387
# Unit test for constructor of class Docstring
def test_Docstring():
  docstring = Docstring()
  assert docstring.short_description is None
  assert docstring.long_description is None
  assert docstring.blank_after_short_description == False
  assert docstring.blank_after_long_description == False
  assert len(docstring.meta) == 0

  assert len(docstring.params) == 0
  assert len(docstring.raises) == 0
  assert docstring.returns is None
  assert docstring.deprecation is None

test_Docstring()

# Generated at 2022-06-23 17:03:52.251010
# Unit test for constructor of class ParseError
def test_ParseError():
    pass

# Generated at 2022-06-23 17:03:53.901183
# Unit test for constructor of class ParseError
def test_ParseError():
    err = ParseError("Error")
    assert err.args[0] == "Error"


# Generated at 2022-06-23 17:04:05.057565
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    print('Testing DocstringRaises')
    errors = 0
    d1 = (
        ['raises', 'ValueError'],
        'Because of this',
        'ValueError',
    )
    d2 = (
        ['raises', 'ValueError'],
        None,
        'ValueError',
    )
    d3 = (
        ['raises', 'ValueError'],
        'Because of this',
        'ValueError',
    )
    d4 = (
        ['raises', 'ValueError'],
        None,
        'ValueError',
    )
    test = [d1, d2, d3, d4]

# Generated at 2022-06-23 17:04:06.837050
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param", "arg", "parameter"], "description")


# Generated at 2022-06-23 17:04:11.407550
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    ds = DocstringReturns(["arg"], description = "desc", type_name = "type",
            is_generator = True)
    assert(ds.args == ["arg"])
    assert(ds.description == "desc")
    assert(ds.type_name == "type")
    assert(ds.is_generator == True)
    assert(ds.return_name == None)

# Generated at 2022-06-23 17:04:17.316601
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	obj=DocstringReturns(["a", "b"], "c", "d")
	assert(obj.args == ["a", "b"])
	assert(obj.description == "c")
	assert(obj.type_name == "d")
	assert(obj.return_name == None)


# Generated at 2022-06-23 17:04:24.243181
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args_list = ["test"]
    description = "description"
    type_name = "type"

    test_DocstringRaises = DocstringRaises(args_list, description, type_name)

    assert test_DocstringRaises.args == args_list
    assert test_DocstringRaises.description == description
    assert test_DocstringRaises.type_name == type_name


# Generated at 2022-06-23 17:04:26.456399
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        print("ParseError")

# Generated at 2022-06-23 17:04:30.726291
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['Arg1', 'Arg2'], 'This is an example description')
    assert d.__repr__() == 'This is an example description'
    assert d.args == ['Arg1', 'Arg2']
    assert d.description == 'This is an example description'


# Generated at 2022-06-23 17:04:32.332344
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring = DocstringRaises([":"], "description", None)
    assert(docstring.description == "description")


# Generated at 2022-06-23 17:04:36.800453
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["a", "b", "c"]
    description = "this is description"
    type_name = "int"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-23 17:04:39.495279
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated", "version"], "description", "version")


# Generated at 2022-06-23 17:04:47.724701
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    ds = DocstringParam(['param','arg','argument'], 'description', "arg_name",
                        'type_name', True, 'default')
    assert type(ds) == DocstringParam
    assert ds.arg_name == "arg_name"
    assert ds.args == ['param', 'arg', 'argument']
    assert ds.description == 'description'
    assert ds.type_name == 'type_name'
    assert ds.is_optional == True
    assert ds.default == 'default'
    print('test_DocstringParam executed successfully')


# Generated at 2022-06-23 17:04:48.439487
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated is not None


# Generated at 2022-06-23 17:04:54.243541
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['arg'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    b = DocstringParam(['arg', 'arg1'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert a.args == ['arg'] and a.description == 'description' and a.arg_name == 'arg_name' and a.type_name == 'type_name' \
        and a.is_optional == 'is_optional' and a.default == 'default'
    assert b.args == ['arg', 'arg1'] and b.description == 'description' and a.arg_name == 'arg_name' and b.type_name == 'type_name' \
            and a.is_optional == 'is_optional' and a.default

# Generated at 2022-06-23 17:04:55.914671
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description is None
    assert Docstring().long_description is None

# Generated at 2022-06-23 17:04:59.156030
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc_string = DocstringMeta(["param", "arg"], "description")
    assert doc_string.args == ["param", "arg"]
    assert doc_string.description == "description"


# Generated at 2022-06-23 17:05:00.543356
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated([":deprecated"], "Test", "version")


# Generated at 2022-06-23 17:05:06.705042
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test the constructor of the class DocstringReturns"""
    args = ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = 'Test description'

    type_name = 'example_type_name'
    is_generator = True

    assert DocstringReturns(args, description, type_name, is_generator).type_name == 'example_type_name'
    assert DocstringReturns(args, description, type_name, is_generator).description == 'Test description'
    assert DocstringReturns(args, description, type_name, is_generator).is_generator == True

# Generated at 2022-06-23 17:05:07.385735
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert True

# Generated at 2022-06-23 17:05:14.261797
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return"]
    description = "Returns a string."
    type_name = "str"
    is_generator = False
    return_name = ''
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert returns.args == ["returns", "return"]
    assert returns.description == "Returns a string."
    assert returns.type_name == "str"
    assert returns.is_generator == False
    assert returns.return_name == None


# Generated at 2022-06-23 17:05:17.995036
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test=DocstringDeprecated(["deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated"],
"description","version")
    assert test.args==["deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated","deprecated"]
    assert test.description=="description"
    assert test.version=="version"


# Generated at 2022-06-23 17:05:21.458747
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['param'], 'description', 'optional')
    assert a.description == 'description'
    assert a.type_name == 'optional'
    assert a.args == ['param']


# Generated at 2022-06-23 17:05:25.015828
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(["param"], "desc", None)
    assert doc.args == ["param"]
    assert doc.description == "desc"
    assert doc.version == None


# Generated at 2022-06-23 17:05:25.630153
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert True

# Generated at 2022-06-23 17:05:36.307281
# Unit test for constructor of class ParseError
def test_ParseError():
    assert issubclass(ParseError, RuntimeError)

    assert str(ParseError) == 'dargparse.ParseError'
    assert repr(ParseError) == 'dargparse.ParseError'
    assert str(ParseError()) == 'dargparse.ParseError'
    assert repr(ParseError()) == 'dargparse.ParseError'
    parsed_error = ParseError('hello')
    assert parsed_error.args == ('hello',)
    assert str(parsed_error) == 'hello'
    assert repr(parsed_error) == 'dargparse.ParseError(\'hello\',)'
    parsed_error = ParseError('hello', 'world')
    assert parsed_error.args == ('hello', 'world')