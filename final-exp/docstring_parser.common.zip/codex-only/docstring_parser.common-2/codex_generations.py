

# Generated at 2022-06-23 16:55:36.244812
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ['param', 'name']
    test_description = 'description'
    test_class = DocstringMeta(
        args=test_args, description=test_description)
    assert test_class.args == ['param', 'name']
    assert test_class.description == 'description'


# Generated at 2022-06-23 16:55:38.672119
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(args=None, description=None, version=None)
    a.args=None
    a.description=None
    a.version=None


# Generated at 2022-06-23 16:55:39.775144
# Unit test for constructor of class Docstring
def test_Docstring():
    # TODO
    pass

# Generated at 2022-06-23 16:55:45.204928
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc_returns = DocstringReturns(["return", "returns"], 'return value', 'int', False, 'x')
    assert doc_returns.args == ['return', 'returns']
    assert doc_returns.description == 'return value'
    assert doc_returns.type_name == 'int'
    assert doc_returns.is_generator == False
    assert doc_returns.return_name == 'x'


# Generated at 2022-06-23 16:55:47.292995
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args,description,type_name = 1,2,3
    raises = DocstringRaises(args,description,type_name)
    assert(raises.args == 1)
    assert(raises.description == 2)
    assert(raises.type_name == 3)

# Generated at 2022-06-23 16:55:48.532477
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass
    else:
        assert False


# Generated at 2022-06-23 16:55:52.393768
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['deprecated', 'since'], 'Outdated', '1.1.1')
    assert doc.args == ['deprecated', 'since']
    assert doc.description == 'Outdated'
    assert doc.version == '1.1.1'


# Generated at 2022-06-23 16:55:53.631203
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([], None, None, False)
    assert a is not None

# Generated at 2022-06-23 16:55:56.919386
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a=DocstringMeta("parameter","desription")
    assert a.args=="parameter"
    assert a.description=="desription"


# Generated at 2022-06-23 16:56:05.506469
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], None, "arg", "type", True, "default")
    DocstringParam(["param"], None, "arg", "type", False, None)
    DocstringParam(["args"], None, "arg", "type", False, None)
    DocstringParam(["arg"], None, "arg", "type", None, None)
    DocstringParam(["arg"], None, "arg", None, None, None)
    DocstringParam(["arg"], None, "arg", "type", True, None)
    DocstringParam(["arg"], None, "arg", "type", None, "default")
    DocstringParam(["arg"], None, "arg", None, True, None)
    DocstringParam(["arg"], None, "arg", None, None, "default")

# Generated at 2022-06-23 16:56:08.540537
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass


# Generated at 2022-06-23 16:56:18.625891
# Unit test for constructor of class Docstring
def test_Docstring():
    def my_function():
        """
        Docstring test

        :param arg0: test arg0
        :param arg1: test arg1
        :return: test return
        :raises ValueError: raise test
        """
        pass

    ds = Docstring()

    ds.short_description = 'Docstring test'
    ds.long_description = ''
    ds.meta.append(DocstringParam(['param','arg0'], 'test arg0', 'arg0',None,None,None))
    ds.meta.append(DocstringParam(['param', 'arg1'], 'test arg1', 'arg1', None, None, None))
    ds.meta.append(DocstringReturns(['return'], 'test return', None, False))

# Generated at 2022-06-23 16:56:20.208384
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    testDocstringDeprecated = DocstringDeprecated([], "", "")
    assert testDocstringDeprecated is not None


# Generated at 2022-06-23 16:56:22.950515
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("hello")
    except RuntimeError as re:
        assert str(re) == "hello"
    except:
        assert False



# Generated at 2022-06-23 16:56:26.948934
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []
    print("[test_Docstring] Docstring constructor works.")


# Generated at 2022-06-23 16:56:33.103397
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated"""
    import sys

    try:
        DocstringDeprecated(args=[], description=None, version=None)
    except:
        print("Test of DocstringDeprecated fails")
        sys.exit()
    print("Test of DocstringDeprecated passed")



# Generated at 2022-06-23 16:56:38.040800
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    param1 = ["raises", "ValueError", ":", "Parameter", "desc.", "int"]
    param2 = "description"
    param3 = "ValueError"
    x = DocstringRaises(param1, param2, param3)
    assert x.args == param1
    assert x.description == param2
    assert x.type_name == param3


# Generated at 2022-06-23 16:56:41.124726
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ''
    description = ''
    type_name = ''
    result = DocstringRaises(args,description,type_name)
    assert result.args == args
    assert result.description == description
    assert result.type_name == type_name


# Generated at 2022-06-23 16:56:45.697068
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param","argument"]
    description = "it's a docstring"
    type_name = "int"
    return [item for item in args]
    assert args[0] == "param"
    assert args[1] == "argument"
    assert description == "it's a docstring"
    assert type_name == "int"


# Generated at 2022-06-23 16:56:52.412637
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_item = DocstringReturns(['param'], 'ss', 'ss', False, 'sss')
    assert isinstance(return_item, DocstringReturns)
    assert return_item.args == ['param']
    assert return_item.description == 'ss'
    assert return_item.type_name == 'ss'
    assert return_item.is_generator == False
    assert return_item.return_name == 'sss'


# Generated at 2022-06-23 16:56:55.325985
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        a = False
        if(a):
            pass
    except ParseError:
        pass


# Generated at 2022-06-23 16:56:59.978606
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    print('passed')

# Unit tests for properties of class Docstring

# Generated at 2022-06-23 16:57:07.478832
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    obj = DocstringParam(['a'], 'a', 'a', 'a', False, 'a')
    assert obj.args == ['a']
    assert obj.description == 'a'
    assert obj.arg_name == 'a'
    assert obj.type_name == 'a'
    assert obj.is_optional == False
    assert obj.default == 'a'

test_DocstringParam()


# Generated at 2022-06-23 16:57:10.283047
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test that ParseError is properly initialized."""
    msg = "Test"
    error = ParseError(msg)
    assert issubclass(ParseError, RuntimeError)
    assert error.args[0] is msg


# Generated at 2022-06-23 16:57:12.809322
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raises', 'www'], None, None)

# Generated at 2022-06-23 16:57:17.374174
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    inst_meta = DocstringMeta([":param", "int"], "param description.")
    assert inst_meta.args[0] == ":param"
    assert inst_meta.args[1] == "int"
    assert inst_meta.description == "param description."


# Generated at 2022-06-23 16:57:19.609535
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(['param', 'arg'], 'description')
    assert meta.args == ['param', 'arg']
    assert meta.description == 'description'


# Generated at 2022-06-23 16:57:21.179566
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta.__init__(["param", "arg"], "description")



# Generated at 2022-06-23 16:57:24.211948
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a=DocstringMeta(['a','b'],"This is a test")
    assert a.args[0]=='a'
    assert a.args[1]=='b'
    assert a.description=="This is a test"


# Generated at 2022-06-23 16:57:28.789154
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dsparam = DocstringParam(["string"], "This is a sample", "sample", None, None, None)
    assert dsparam.args == ["string"]
    assert dsparam.description == "This is a sample"
    assert dsparam.arg_name == "sample"
    assert dsparam.type_name == None
    assert dsparam.is_optional == None
    assert dsparam.default == None


# Generated at 2022-06-23 16:57:34.597530
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = 'If something happens'
    type_name = 'float'
    s = DocstringRaises(args, description, type_name)
    assert s.args == ['raises', 'ValueError']
    assert s.description == 'If something happens'
    assert s.type_name == 'float'


# Generated at 2022-06-23 16:57:39.392482
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
  param_arg = DocstringParam(["param","parameter"], "description", "arg", None, False, None)
  assert param_arg.arg == "param"
  assert param_arg.args == ["param","parameter"]
  assert param_arg.description == "description" 
  assert param_arg.arg_name == "arg"
  assert param_arg.type_name == None
  assert param_arg.is_optional == False
  assert param_arg.default == None


# Generated at 2022-06-23 16:57:41.480360
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    return DocstringDeprecated(["deprecated"], "description", "1.2.3")

# Generated at 2022-06-23 16:57:43.107146
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("bad")

# Generated at 2022-06-23 16:57:45.042003
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Check the constructor of class DocstringMeta."""
    d = DocstringMeta([], "")
    assert isinstance(d, DocstringMeta)
    assert d.args == []
    assert d.description == ""



# Generated at 2022-06-23 16:57:47.396209
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(['param', 'args'], 'This is description.', 'args', 'Type', 'optional', 'default')


# Generated at 2022-06-23 16:57:49.494476
# Unit test for constructor of class ParseError
def test_ParseError():
    # No test needed since constructor is trivial
    pass


# Generated at 2022-06-23 16:57:51.378684
# Unit test for constructor of class ParseError
def test_ParseError():
    s = ParseError()
    assert str(s) == "The input source contains errors"


# Generated at 2022-06-23 16:57:55.383305
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
  docstring_meta = DocstringMeta(['param'], 'This is a parameter')
  assert docstring_meta.args == ['param']
  assert docstring_meta.description == 'This is a parameter'

# Generated at 2022-06-23 16:57:56.421568
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("Test error")


# Generated at 2022-06-23 16:58:03.530145
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Test DocstringDeprecated."""
    ds = DocstringDeprecated(
        args=['1', '2', '3', '4'], description=None, version=None
    )
    assert ds.args == ['1', '2', '3', '4']
    assert ds.description is None
    assert ds.version is None


# Generated at 2022-06-23 16:58:09.852455
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['a', 'b']
    description = "test"
    type_name = "c"
    a = DocstringRaises(args, description, type_name)
    
    assert a.args == args
    #assert a.description == "test"
    assert a.type_name == type_name
    

# Generated at 2022-06-23 16:58:12.180881
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Test Error')
    except:
        print('error')


# Generated at 2022-06-23 16:58:16.601462
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises","argument"]
    description = "description"
    type_name = "type"
    a = DocstringRaises(args,description,type_name)
    assert a.args == ["raises", "argument"]
    assert a.description == "description"
    assert a.type_name == "type"
    return

# Generated at 2022-06-23 16:58:24.959157
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test constructor of class DocstringRaises."""
    # init
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    # test
    meta = DocstringRaises(args, description, type_name)
    # assert
    assert meta.args == ["raises", "ValueError"]
    assert meta.description == "if something happens"
    assert meta.type_name == "ValueError"


# Generated at 2022-06-23 16:58:27.627369
# Unit test for constructor of class ParseError
def test_ParseError():
    """Testing for constructor of class ParseError."""

    with pytest.raises(ParseError):
        raise ParseError


# Unit tests for constructor of class DocstringMeta

# Generated at 2022-06-23 16:58:32.883361
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    testDocstringRaises = DocstringRaises([], "", "")
    assert testDocstringRaises.type_name == ""
    assert testDocstringRaises.description == ""
    assert testDocstringRaises.args == []


# Generated at 2022-06-23 16:58:34.853868
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(None, None, None)



# Generated at 2022-06-23 16:58:35.898677
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert isinstance(ds, Docstring)


# Generated at 2022-06-23 16:58:37.648899
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError:
        pass



# Generated at 2022-06-23 16:58:47.190535
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(args=['param'],description='description1',arg_name='arg_name1',type_name=None,is_optional=None,default=None)
    assert doc.args == ['param']
    assert doc.description == 'description1'
    assert doc.arg_name =='arg_name1'
    assert doc.type_name ==None
    assert doc.is_optional ==None
    assert doc.default ==None



# Generated at 2022-06-23 16:58:51.097819
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['args']
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args,description,type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-23 16:58:51.517585
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring()

# Generated at 2022-06-23 16:58:54.262314
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_obj = DocstringDeprecated(args=["a", "b"], description="desc", version="2.0")
    assert docstring_obj.args == ["a", "b"]
    assert docstring_obj.description == "desc"
    assert docstring_obj.version == "2.0"


# Generated at 2022-06-23 16:58:56.102098
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit tests for constructor of class ParseError."""
    error = ParseError('An exception')
    assert error.args[0] == 'An exception'

# Generated at 2022-06-23 16:59:03.033356
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # test for constructor
    docstring_param = DocstringParam(["test_arg"], "test_description", "test_arg_name", "test_type_name", True, "test_default_value")
    assert docstring_param.args == ["test_arg"]
    assert docstring_param.description == "test_description"
    assert docstring_param.arg_name == "test_arg_name"
    assert docstring_param.type_name == "test_type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "test_default_value"


# Generated at 2022-06-23 16:59:06.401885
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as err:
        assert str(err) == "Error"


# Generated at 2022-06-23 16:59:09.957196
# Unit test for constructor of class ParseError
def test_ParseError():
    """Create an object of class ParseError."""
    exc = ParseError("This allows to raise any kind of exception.")
    assert exc.args == ("This allows to raise any kind of exception.",)

# Generated at 2022-06-23 16:59:13.207912
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        print(e)

# Generated at 2022-06-23 16:59:16.653404
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta(args=['a'], description='b')
    assert isinstance(doc, DocstringMeta)


# Generated at 2022-06-23 16:59:22.759399
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated([":deprecated", "1.2"], "I'm deprecated", "1.2")
    assert docstringDeprecated.args == [":deprecated", "1.2"]
    assert docstringDeprecated.version == "1.2"
    assert docstringDeprecated.description == "I'm deprecated"

# Unit tests for constructor of class DocstringRaises

# Generated at 2022-06-23 16:59:31.444578
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(
        [], None, 'arg', 'type', True, 'default')
    assert(param.args == [])
    assert(param.description == None)
    assert(param.arg_name == 'arg')
    assert(param.type_name == 'type')
    assert(param.is_optional == True)
    assert(param.default == 'default')


# Generated at 2022-06-23 16:59:41.327420
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert(ds.short_description is None)
    assert(ds.long_description is None)
    assert(ds.blank_after_short_description is False)
    assert(ds.blank_after_long_description is False)
    assert(ds.params == [])
    assert(ds.raises == [])
    assert(ds.returns is None)
    assert(ds.deprecation is None)


# Generated at 2022-06-23 16:59:42.850730
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    bug= DocstringParam('None', 'None', 'arg_name', 'type_name', 'None', 'None')

# Generated at 2022-06-23 16:59:51.792573
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc = DocstringParam(args=["param"], description="Test description.", arg_name="arg", type_name="int", is_optional=True, default=1)
    assert doc.args == ["param"]
    assert doc.description == "Test description."
    assert doc.arg_name == "arg"
    assert doc.type_name == "int"
    assert doc.is_optional == True
    assert doc.default == 1


# Generated at 2022-06-23 16:59:53.903040
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc = DocstringMeta([1,2,3], "descrizione")
    assert doc.args == [1,2,3]
    assert doc.description == "descrizione"

# Generated at 2022-06-23 16:59:56.833553
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc = DocstringReturns("args", "description", "type_name", True)
    assert doc.args == "args"
    assert doc.description == "description"
    assert doc.type_name == "type_name"
    assert doc.is_generator == True
    assert doc.return_name == None

# Generated at 2022-06-23 17:00:04.847389
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    if ds.short_description is not None:
        raise Exception()
    if ds.long_description is not None:
        raise Exception()
    if ds.blank_after_short_description != False:
        raise Exception()
    if ds.blank_after_long_description != False:
        raise Exception()
    if not isinstance(ds.meta, list):
        raise Exception()


# Generated at 2022-06-23 17:00:12.722204
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_string_input = Docstring()
    assert doc_string_input.short_description is None
    assert doc_string_input.long_description is None
    assert doc_string_input.blank_after_short_description is False
    assert doc_string_input.blank_after_long_description is False
    assert doc_string_input.meta == []


# Generated at 2022-06-23 17:00:16.042633
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_obj = DocstringDeprecated(['param'], 'This is a test', 'v3.0')
    assert test_obj.args == ['param']
    assert test_obj.description == 'This is a test'
    assert test_obj.version == 'v3.0'


# Generated at 2022-06-23 17:00:20.782063
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Test for the constructor of DocstringRaises class."""
    assert DocstringRaises(["raises","ValueError"], None, "ValueError")


# Generated at 2022-06-23 17:00:23.514266
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test for constructor of class DocstringMeta."""
    args = ['param', 'arg', 'keyword']
    description = 'Description'
    d = DocstringMeta(args, description)
    print(d.args)
    print(d.description)


# Generated at 2022-06-23 17:00:28.165945
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["param"], "description", "2.0")
    b = DocstringDeprecated(["param"], "description", None)
    c = DocstringDeprecated(["param"], None, None)
    assert a.version == "2.0"
    assert b.version == None
    assert c.version == None
    assert c.description == None

# Generated at 2022-06-23 17:00:29.501264
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-23 17:00:33.846627
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Check if constructor is able to initialize class
    try:
        assert DocstringReturns(["raises"], "description", "ValueError", False)
    except Exception:
        print("Constructor is not able to initialize")
    

# Generated at 2022-06-23 17:00:38.347106
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    arg_list = ["return", "returns"]
    description = "this is just a test"
    type_name = "int"
    is_generator = False
    return_name = None
    assert DocstringReturns(arg_list, description, type_name, is_generator, return_name)


# Generated at 2022-06-23 17:00:41.274841
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert str(DocstringReturns("args", "description", True, True)) == "args"
    assert str(DocstringReturns("args", "description", 1.0, True)) == "args"

# Generated at 2022-06-23 17:00:48.748205
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    e1 = DocstringRaises(["raises", "ValueError"],
                         "some description", "ValueError")
    assert e1.type_name == "ValueError"
    assert e1.description == "some description"
    assert e1.args == ["raises", "ValueError"]


# Generated at 2022-06-23 17:00:54.306963
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

    # Test property params
    docstring = Docstring()
    docstring_param = DocstringParam(
        args=["param"],
        description="some description",
        arg_name="arg",
        type_name="type",
        is_optional=True,
        default="1",
    )
    docstring.meta.append(docstring_param)
    assert docstring.params == [docstring_param]

    # Test property raises
    docstring = Docstring()

# Generated at 2022-06-23 17:00:56.484609
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns"""
    ds = DocstringReturns(args=[], description=None, type_name=None, is_generator=False)
    assert ds
    

# Generated at 2022-06-23 17:00:59.253061
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError()
    # Test that class is correctly initialized
    assert 1 == 1


# Generated at 2022-06-23 17:01:01.261428
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam([], "", "", "", "", "")
    assert(isinstance(a,DocstringMeta))

# Generated at 2022-06-23 17:01:03.563193
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError("Error")
    assert str(parse_error) == "Error"

# Generated at 2022-06-23 17:01:04.586618
# Unit test for constructor of class Docstring
def test_Docstring():
  d = Docstring()
  return d

# Generated at 2022-06-23 17:01:06.848793
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['param'], "test")
    assert a.args == ['param']
    assert a.description == 'test'


# Generated at 2022-06-23 17:01:10.669199
# Unit test for constructor of class Docstring
def test_Docstring():
    my_docstring = Docstring()
    assert my_docstring.short_description is None
    assert my_docstring.long_description is None
    assert my_docstring.blank_after_short_description == False
    assert my_docstring.blank_after_long_description == False
    assert not my_docstring.meta


# Generated at 2022-06-23 17:01:12.737781
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    try:
        new_DocstringRaises = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    except NameError:
        print("name not found")


# Generated at 2022-06-23 17:01:20.455562
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['Since', '2.0.0']
    description = 'desc'
    version = '2.0.0'
    d = DocstringDeprecated(args, description, version)
    assert d.args == ['Since', '2.0.0']
    assert d.description == 'desc'
    assert d.version == '2.0.0'


# Generated at 2022-06-23 17:01:24.616474
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []


# Generated at 2022-06-23 17:01:34.466463
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    testP = DocstringParam(['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword'],
    'description', 'arg', 'type_name', None, None)
    assert testP.args == ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    assert testP.description == 'description'
    assert testP.arg_name == 'arg'
    assert testP.type_name == 'type_name'
    assert testP.is_optional == None
    assert testP.default == None



# Generated at 2022-06-23 17:01:36.498950
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta([''], '')
    assert a.args == ['']
    assert a.description == ''



# Generated at 2022-06-23 17:01:38.385308
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()


# Generated at 2022-06-23 17:01:40.469622
# Unit test for constructor of class ParseError
def test_ParseError():
    obj = ParseError
    return isinstance(obj,RuntimeError)
    

    

# Generated at 2022-06-23 17:01:44.546284
# Unit test for constructor of class ParseError
def test_ParseError():
    """ Unit test for constructor of class ParseError """
    error = ParseError("test")
    if str(error) != "test":
        print("ERROR: test_ParseError")
    return


# Generated at 2022-06-23 17:01:54.050162
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg']
    description = "this is a description"
    arg_name = "variable"
    type_name = None
    is_optional = None
    default = "some default value"
    under_test = DocstringParam(args=args, description=description, arg_name=arg_name, type_name=type_name, is_optional=is_optional, default=default)
    assert under_test.args == args
    assert under_test.description == description
    assert under_test.arg_name == arg_name
    assert under_test.type_name == type_name
    assert under_test.is_optional == is_optional
    assert under_test.default == default


# Generated at 2022-06-23 17:02:01.243982
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test."""
    Doc = DocstringParam(
        args = ["param", "arg", "Argument"],
        arg_name = "arg",
        description = "Description",
        type_name = "float",
        is_optional = False,
        default= None
    )
    assert Doc.args == ["param", "arg", "Argument"]
    assert Doc.arg_name == "arg"
    assert Doc.type_name == "float"
    assert Doc.is_optional == False
    assert Doc.default == None


# Generated at 2022-06-23 17:02:06.143240
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg']
    description = 'description of param'
    arg_name = 'arg'
    type_name = None
    is_optional = False
    default = None
    new_DocstringParam = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert new_DocstringParam is not None


# Generated at 2022-06-23 17:02:08.687285
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    arg = ['arg', 'arg']
    desc = 'desc'
    dm = DocstringMeta(arg, desc)
    assert dm.args == arg
    assert dm.description == desc


# Generated at 2022-06-23 17:02:11.321373
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test1 = DocstringRaises(['param'],"blah", "2")
    assert test1.args == ['param']
    assert test1.description == "blah"
    assert test1.type_name == "2"


# Generated at 2022-06-23 17:02:15.539102
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    returns = DocstringReturns(['return', 'returns'], 'Return type: str')
    assert returns.args == ['return', 'returns'], 'Args are not the same'
    assert returns.description == 'Return type: str', 'Description is not the same'



# Generated at 2022-06-23 17:02:19.117733
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["param"], "a string", "1.0")



# Generated at 2022-06-23 17:02:21.339919
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """DocstringMeta unit test."""
    docstring_meta = DocstringMeta(["param"], None)
    assert docstring_meta.args == ["param"]
    assert docstring_meta.description is None


# Generated at 2022-06-23 17:02:30.961116
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = []
    for i in range (4):
        args.append("Test")
    test_returns = DocstringReturns(args, "test_description", "test_type_name", False, "test_return_name")
    assert test_returns.args == ["Test", "Test", "Test", "Test"]
    assert test_returns.description == "test_description"
    assert test_returns.type_name == "test_type_name"
    assert test_returns.is_generator == False
    assert test_returns.return_name == "test_return_name"



# Generated at 2022-06-23 17:02:38.600469
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    expected_args = ['param']
    expected_description = 'This function is deprecated'
    expected_version = '1.0'
    test_item = DocstringDeprecated(expected_args, expected_description, expected_version)
    assert test_item.args == expected_args
    assert test_item.description == expected_description
    assert test_item.version == expected_version


# Generated at 2022-06-23 17:02:42.485747
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []



# Generated at 2022-06-23 17:02:50.082280
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dr1 = DocstringReturns(["arg1","arg2"], "abc", "xyz", True)
    dr2 = DocstringReturns(["arg1","arg2"], "abc", "xyz", False)
    assert dr1.args == ["arg1","arg2"]
    assert dr1.description == "abc"
    assert dr1.type_name == "xyz"
    assert dr1.is_generator == True
    assert dr1.return_name == None
    assert dr2.is_generator == False

# Generated at 2022-06-23 17:02:52.792783
# Unit test for constructor of class ParseError
def test_ParseError():
    test = ParseError("Custom message")
    assert str(test) == "Custom message"



# Generated at 2022-06-23 17:02:55.948670
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(args = [1, True, None], description = 'Test')
    assert meta.args == [1, True, None]
    assert meta.description == 'Test'


# Generated at 2022-06-23 17:02:59.247695
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Code for testing
    DocstringParam(['a'], 'a', 'a', 'a', 'a', 'a')

# Generated at 2022-06-23 17:03:03.965814
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = ""
    type_name = ""
    item = DocstringRaises(args, description, type_name)
    assert item.__dict__ == {'args': [], 'description': '', 'type_name': ''}

# Generated at 2022-06-23 17:03:08.754777
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_args = ['test_arg']
    test_description = None
    test_version = None
    test_object = DocstringDeprecated(test_args, test_description, test_version)

    assert test_object.args == test_args
    assert test_object.description == test_description
    assert test_object.version == test_version

# Generated at 2022-06-23 17:03:11.581496
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(
        ['deprecated'], 'no longer used', '1.0')
    assert docstring.version == '1.0'
    assert docstring.description == 'no longer used'
    assert docstring.args == ['deprecated']


# Generated at 2022-06-23 17:03:15.524278
# Unit test for constructor of class ParseError
def test_ParseError():
    # Test if the exception is raised
    try:
        raise ParseError("test")
    except ParseError:
        pass
    # Test if the message is the one expected
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-23 17:03:20.627941
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description is None
    assert ds.long_description is None
    assert ds.blank_after_short_description is False
    assert ds.blank_after_long_description is False
    assert ds.meta == []


# Generated at 2022-06-23 17:03:26.698187
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["something"]
    description = "some description"
    version = "1.0.0"
    result = DocstringDeprecated(args, description, version)
    correct_result = DocstringDeprecated(args, description, version)
    assert result.args == correct_result.args
    assert result.description == correct_result.description
    assert result.version == correct_result.version

# Generated at 2022-06-23 17:03:34.752648
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # create instance of class DocstringReturns
    args = ["param", "arg", "parameter"]
    description = "description"
    type_name = "typed name"
    is_generator = True
    return_name = "dummy name"

    ds = DocstringReturns(
        args, description, type_name, is_generator=is_generator, return_name=return_name
    )

    assert ds.args == ["param", "arg", "parameter"]
    assert ds.description == "description"
    assert ds.type_name == "typed name"
    assert ds.is_generator == True
    assert ds.return_name == "dummy name"



# Generated at 2022-06-23 17:03:37.490211
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['deprecated'], "1.0", "1.0")
    assert doc.type_name == "1.0"
    assert doc.description == "1.0"

# Generated at 2022-06-23 17:03:39.028281
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass


# Generated at 2022-06-23 17:03:47.608256
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = [] # type: T.List[str]
    type_name = None # type: T.Optional[str]
    is_generator = True
    return_name = "hello" # type: T.Optional[str]
    docstring_returns = DocstringReturns(args, "", type_name, is_generator, return_name)
    print(docstring_returns.is_generator)
    print(docstring_returns.return_name)

test_DocstringReturns()

# Generated at 2022-06-23 17:03:51.046777
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['args', 'description', 'version'], 'description', 'version')
    assert 'version' == d.version
    assert 'description' == d.description
    assert ['args', 'description', 'version'] == d.args


# Generated at 2022-06-23 17:03:57.685185
# Unit test for constructor of class Docstring
def test_Docstring():
    from Docstring import Docstring
    obj = Docstring()
    assert obj.short_description == None
    assert obj.long_description == None
    assert obj.blank_after_short_description == False
    assert obj.blank_after_long_description == False
    assert obj.meta == []
    assert obj.params == []
    assert obj.raises == []
    assert obj.returns == None
    assert obj.deprecation == None


# Generated at 2022-06-23 17:04:00.518891
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["test"], "testdoc")
    assert dm.description == "testdoc"
    assert dm.args == ["test"]


# Generated at 2022-06-23 17:04:06.658159
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam([], "desc", "arg_name", "type_name", True, "12")

    assert docstringParam.args == []
    assert docstringParam.description == "desc"
    assert docstringParam.arg_name == "arg_name"
    assert docstringParam.type_name == "type_name"
    assert docstringParam.is_optional == True
    assert docstringParam.default == "12"


# Generated at 2022-06-23 17:04:09.900286
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    type_name = 'ValueError'
    description = 'if something bad happens'
    DocstringRaises('raises', 'ValueError', 'ValueError', 'if something bad happens')



# Generated at 2022-06-23 17:04:13.280309
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam([], '', 'arg_name', None, None, None)



# Generated at 2022-06-23 17:04:15.349600
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(
        'arg', 'description', 'type_name')
    assert test.args == 'arg'
    assert test.description == 'description'
    assert test.type_name == 'type_name'


# Generated at 2022-06-23 17:04:18.410684
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(['param'], 'test')
    assert isinstance(a, DocstringMeta)
    assert a.args == ['param']
    assert a.description == 'test'


# Generated at 2022-06-23 17:04:22.554487
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    p = DocstringParam(['param', 'name'], 'Name', 'name', None, False, None)
    assert p.args == ['param', 'name']
    assert p.description == 'Name'
    assert p.arg_name == 'name'
    assert p.type_name is None
    assert p.is_optional is True
    assert p.default == 'name'


# Generated at 2022-06-23 17:04:23.691386
# Unit test for constructor of class Docstring
def test_Docstring():
    Docstring()


# Generated at 2022-06-23 17:04:28.214950
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["param","arg"], "description", "1.0.0")
    assert d.args == ["param","arg"]
    assert d.description == "description"
    assert d.version == "1.0.0"

# Test for constructor of class DocstringReturns

# Generated at 2022-06-23 17:04:37.783128
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    import pytest
    args = ["raises", "ValueError"]
    description = "desc"
    type_name = "ValueError"
    assert DocstringRaises(args, description, type_name).args == ["raises",
                                                            "ValueError"]
    assert DocstringRaises(args, description, type_name).description == "desc"
    assert DocstringRaises(args, description, type_name).type_name == "ValueError"
    with pytest.raises(TypeError):
        DocstringRaises(args, description, 123)
    with pytest.raises(TypeError):
        DocstringRaises(args, description, "ValueError").type_name = 123
    with pytest.raises(TypeError):
        DocstringRaises(args, description, "ValueError").description = 123

# Generated at 2022-06-23 17:04:41.838527
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    '''Tests docstring deprecated entry
    '''
    doc_string = DocstringDeprecated(['Deprecated'],None,'1.2')
    assert doc_string.args == ['Deprecated']
    assert doc_string.version == '1.2'


# Generated at 2022-06-23 17:04:44.582464
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['a'], 'this is a test', 'a', 'int', False)



# Generated at 2022-06-23 17:04:50.800181
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['param', 'var:type=20']
    description = 'desc'
    version = '2003'
    d = DocstringDeprecated(args, description, version)
    assert d.args[0] == 'param'
    assert d.args[1] == 'var:type=20'
    assert d.description == 'desc'
    assert d.version == '2003'
    assert d.args == args and d.description == description and d.version == version
    print("test_DocstringDeprecated passed")



# Generated at 2022-06-23 17:04:55.126374
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    doc=DocstringMeta(['foo'], 'bar')
    assert doc.args == ['foo']
    assert doc.description == 'bar'


# Generated at 2022-06-23 17:04:57.567949
# Unit test for constructor of class ParseError
def test_ParseError():
	err = ParseError("this is an error")
	assert err.args[0] == "this is an error"


# Generated at 2022-06-23 17:04:59.005958
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["args"], "description", "type_name")

# Generated at 2022-06-23 17:05:03.774434
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(args=["asd"], description="Test", type_name="str", is_generator=True)
    print(f"args = {a.args}")
    print(f"description = {a.description}")
    print(f"type_name = {a.type_name}")
    print(f"is_generator = {a.is_generator}")


# Generated at 2022-06-23 17:05:10.150143
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	argList = ['param', 'arg', 'description']
	d = DocstringParam(argList, '', 'arg', 'str', True, 'None')
	assert d.args == argList
	assert d.description == ''
	assert d.arg_name == 'arg'
	assert d.type_name == 'str'
	assert d.is_optional == True
	assert d.default == 'None'


# Generated at 2022-06-23 17:05:15.120823
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta1 = DocstringMeta(['args'], 'description')
    assert DocstringMeta1.args == ['args']
    assert DocstringMeta1.description == 'description'
    DocstringMeta2 = DocstringMeta(['args', 'args'], 'description')
    assert DocstringMeta2.args == ['args', 'args']
    assert DocstringMeta2.description == 'description'


# Generated at 2022-06-23 17:05:16.446568
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError('test')
    assert(pe.args == 'test')

# Generated at 2022-06-23 17:05:18.812920
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert isinstance(ds, Docstring)



# Generated at 2022-06-23 17:05:20.297621
# Unit test for constructor of class ParseError
def test_ParseError():
    pe = ParseError()
    assert isinstance(pe, Exception)


# Generated at 2022-06-23 17:05:22.627523
# Unit test for constructor of class Docstring
def test_Docstring():
    a = Docstring()
    assert a.short_description == None
    assert a.long_description == None
    assert a.blank_after_short_description == False
    assert a.blank_after_long_description == False
    assert a.meta == []



# Generated at 2022-06-23 17:05:32.932655
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert parse.DocstringDeprecated([], "", "").args == []
    assert parse.DocstringDeprecated([""], "", "").args == [""]
    assert parse.DocstringDeprecated(["", ""], "", "").args == ["", ""]
    assert parse.DocstringDeprecated([], "", "").description is None
    assert parse.DocstringDeprecated([], "", "").version is None
    assert parse.DocstringDeprecated([], "", "").version is None
    assert parse.DocstringDeprecated([], "", "1.0").version is "1.0"
    assert parse.DocstringDeprecated([], "Test", "").description is "Test"
    assert parse.DocstringDeprecated([], "", "1.0").description is None
