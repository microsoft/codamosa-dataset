

# Generated at 2022-06-23 16:55:38.065592
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(['returns', 'yields'], 'Return value.', 'int', False)
    assert docstring_returns.args == ['returns', 'yields']
    assert docstring_returns.description == 'Return value.'
    assert docstring_returns.type_name == 'int'
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == None



# Generated at 2022-06-23 16:55:43.882349
# Unit test for constructor of class Docstring
def test_Docstring():
  docstring = Docstring()
  assert docstring.short_description is None
  assert docstring.long_description is None
  assert docstring.blank_after_short_description is False
  assert docstring.blank_after_long_description is False
  assert docstring.meta == []

  assert docstring.params == []
  assert docstring.raises == []
  assert docstring.returns is None
  assert docstring.deprecation is None

# Generated at 2022-06-23 16:55:46.601030
# Unit test for constructor of class Docstring
def test_Docstring():
    my_Docstring = Docstring()
    assert isinstance(my_Docstring, Docstring)



# Generated at 2022-06-23 16:55:51.422834
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated", "version", "2.0"], None, "2.0")
    assert docstring_deprecated.args == ["deprecated", "version", "2.0"]
    assert docstring_deprecated.description is None
    assert docstring_deprecated.version == "2.0"


# Generated at 2022-06-23 16:56:02.310726
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	a = DocstringParam(["param"], "I am a parameter", "arg", "int", True, "None")
	if a.args != ["param"]:
		raise Exception("Unit test failed")
	if a.description != "I am a parameter":
		raise Exception("Unit test failed")
	if a.arg_name != "arg":
		raise Exception("Unit test failed")
	if a.type_name != "int":
		raise Exception("Unit test failed")
	if a.is_optional != True:
		raise Exception("Unit test failed")
	if a.default != "None":
		raise Exception("Unit test failed")
	print("Unit test for constructor of class DocstringParam is passed")


# Generated at 2022-06-23 16:56:14.377050
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    import re
    import string
    import random
    import textwrap
    import itertools

    def random_string(length):
        return ''.join(random.choice(string.ascii_letters) for m in range(length))

    def random_string_list(n_values, max_length):
        return [random_string(random.randint(1, max_length)) for m in range(n_values)]

    def generate_docstring():
        doc = Docstring()
        lines = []
        doc.short_description = random_string(random.randint(1, 10))
        lines.append(doc.short_description)
        doc.blank_after_short_description = random.choice([True, False])
        lines.append("") if doc.blank_after_short_description else None
        doc.long

# Generated at 2022-06-23 16:56:16.664235
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstringDeprecated = DocstringDeprecated([],['Description'],['Version number'])
    assert docstringDeprecated.description == ['Description']
    assert docstringDeprecated.version == ['Version number']


# Generated at 2022-06-23 16:56:17.947111
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['1', '2'], '3')

# Generated at 2022-06-23 16:56:21.285200
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test the constructor of class Docstring."""
    docstring = Docstring()
    # assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []



# Generated at 2022-06-23 16:56:28.358497
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Case 1: Test with minimum number of arguments
    # Test with valid input
    args = ["param", "type_name", "arg_name", "description"]
    arg_name = "arg_name"
    type_name = "type_name"
    description = "description"
    test_docstring_param = DocstringParam(args, description, arg_name, type_name, None, None)
    assert test_docstring_param.args == args
    assert test_docstring_param.description == description
    assert test_docstring_param.arg_name == arg_name
    assert test_docstring_param.type_name == type_name
    assert test_docstring_param.is_optional == None
    assert test_docstring_param.default == None
    
    # Test with invalid input

# Generated at 2022-06-23 16:56:34.057472
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "str"
    b = DocstringRaises(args, description, type_name)
    print("Raises args:", b.args, "Raises description:", b.description, "Raises type name:", b.type_name)


# Generated at 2022-06-23 16:56:38.194892
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:56:39.778731
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("DocstringParser", "docstring")
    except ParseError as e:
        assert e.args[0] == "Error in DocstringParser docstring"


# Generated at 2022-06-23 16:56:44.270619
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam([], '', '', '', '', '')
    assert docstring.args == []
    assert docstring.description == ''
    assert docstring.arg_name == ''
    assert docstring.type_name == ''
    assert docstring.is_optional == ''
    assert docstring.default == ''


# Generated at 2022-06-23 16:56:46.844618
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test DocstringMeta class constructor."""
    with pytest.raises(TypeError):
        DocstringMeta()



# Generated at 2022-06-23 16:56:53.455258
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = 'args'
    description = 'description'
    type_name = 'type_name'
    x = DocstringRaises(args, description, type_name)
    assert x.args == args
    assert isinstance(x.args, (list, tuple))
    assert x.description == description
    assert x.type_name == type_name
    assert isinstance(x.__dict__, dict)


# Generated at 2022-06-23 16:56:58.852493
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = list()
    description = "Some description."
    type_name = "SomeTypeName"
    test_object = DocstringRaises(args, description, type_name)
    assert test_object.args == args
    assert test_object.description == description
    assert test_object.type_name == type_name


# Generated at 2022-06-23 16:57:04.370155
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """
    Method that tests constructor of class DocstringRaises
    """
    x = DocstringRaises([],[], 'test_type_name')
    assert x.args == []
    assert x.description == []
    assert x.type_name == 'test_type_name'


# Generated at 2022-06-23 16:57:07.734458
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns('args', 'description', 'type_name', 'is_generator', 'return_name')



# Generated at 2022-06-23 16:57:10.154336
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except ParseError as e:
        #Checking the class of Exception
        assert(isinstance(e,ParseError))
        

# Generated at 2022-06-23 16:57:18.539378
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, None, False, None) is not None
    assert DocstringReturns([], None, None, False, None).args == []
    assert DocstringReturns([], None, None, False, None).description is None
    assert DocstringReturns([], None, None, False, None).type_name is None
    assert DocstringReturns([], None, None, False, None).is_generator == False
    assert DocstringReturns([], None, None, False, None).return_name is None
    # normal usage
    assert DocstringReturns(['param'], 'description', 'type', True, 'name') is not None
    assert DocstringReturns(['param'], 'description', 'type', True, 'name').args == ['param']

# Generated at 2022-06-23 16:57:20.453062
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError()
    assert parse_error.args == ()

#Unit test for constructor of class DocstringMeta

# Generated at 2022-06-23 16:57:23.213871
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docmeta = DocstringMeta(["param"], "description")
    assert docmeta.args == ["param"], "y"
    assert docmeta.description == "description", "y"


# Generated at 2022-06-23 16:57:27.974763
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None

# Generated at 2022-06-23 16:57:30.761328
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, None, True)

if __name__ == "__main__":
    test_DocstringReturns()

# Generated at 2022-06-23 16:57:32.571386
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['arg'], 'description', '1.0.0')

# Generated at 2022-06-23 16:57:35.782799
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['parameter']
    description = 'hey'
    type_name = 'boolean'
    d = DocstringRaises(args, description, type_name)
    assert d.is_generator == False
    assert d.return_name == None
    assert d.args == ['parameter']
    assert d.description == 'hey'
    assert d.type_name == 'boolean'

# Generated at 2022-06-23 16:57:37.794216
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(["raises"], "ValueError", type_name = "ValueError").type_name == "ValueError"


# Generated at 2022-06-23 16:57:47.007437
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'int'
    is_optional = True
    default = '3'
    d = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert (d.args == args)
    assert (d.description == description)
    assert (d.arg_name == arg_name)
    assert (d.type_name == type_name)
    assert (d.is_optional == is_optional)
    assert (d.default == default)



# Generated at 2022-06-23 16:57:53.652054
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    my_item = DocstringParam(args=['param'], description=[], arg_name='', type_name=None, is_optional=None, default=None)
    assert my_item.args == ['param']
    assert my_item.description == []
    assert my_item.arg_name == ''
    assert my_item.type_name == None
    assert my_item.is_optional == None
    assert my_item.default == None


# Generated at 2022-06-23 16:57:59.948871
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []

    return


# Generated at 2022-06-23 16:58:07.502109
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    meta = DocstringReturns(
        args=['type', 'generator', 'return'],
        description='content of return',
        type_name='list',
        is_generator=True,
        return_name='res')
    assert meta.args[0] == 'type'
    assert meta.args[1] == 'generator'
    assert meta.args[2] == 'return'
    assert meta.description == 'content of return'
    assert meta.type_name == 'list'
    assert meta.is_generator == True
    assert meta.return_name == 'res'



# Generated at 2022-06-23 16:58:08.766461
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
	pass


# Generated at 2022-06-23 16:58:12.533640
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test data
    args = ["param", "arg", "name"]
    description = "description"
    # Test object construction
    DocstringMeta(args, description)
    assert True


# Generated at 2022-06-23 16:58:15.823299
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    arguments = ["test"]
    description = "test description"
    type_name = "type"
    result = DocstringRaises(arguments, description, type_name)
    assert result != None
    pass


# Generated at 2022-06-23 16:58:19.097176
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(['a', 'b'], 'c', 'd')
    assert d.args == ['a', 'b']
    assert d.description == 'c'
    assert d.type_name == 'd'


# Generated at 2022-06-23 16:58:23.176322
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == list()


# Generated at 2022-06-23 16:58:28.820710
# Unit test for constructor of class Docstring
def test_Docstring():
    import unittest

    class TestDocstring(unittest.TestCase):
        def test_1(self):
            docstring = Docstring()
            assert docstring
            assert docstring.short_description is None
            assert docstring.long_description is None
            assert docstring.blank_after_short_description is False
            assert docstring.blank_after_long_description is False
            assert docstring.meta == list()

    tests = TestDocstring()
    tests.test_1()



# Generated at 2022-06-23 16:58:38.459801
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of DocstringParam."""
    docstringParam = DocstringParam(["param"], "type", "arg", None, None, None)
    # Test that correct parameters are assigned in constructor
    assert isinstance(docstringParam, DocstringMeta)
    assert docstringParam.args == ["param"]
    assert docstringParam.description == "type"
    assert docstringParam.arg_name == "arg"
    assert docstringParam.type_name is None
    assert docstringParam.is_optional is None
    assert docstringParam.default is None


# Generated at 2022-06-23 16:58:43.030003
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(["raises"], None, None)
    assert doc.args == ["raises"]
    assert doc.description == None
    assert doc.type_name == None

# Generated at 2022-06-23 16:58:44.499324
# Unit test for constructor of class ParseError
def test_ParseError():
    pass


# Generated at 2022-06-23 16:58:46.573316
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated("a","b","c") is not None


# Generated at 2022-06-23 16:58:52.231433
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	a = DocstringParam(['a'], 'a', 'b', 'c', 'd', 'e')
	assert a.args == ['a']
	assert a.description == 'a'
	assert a.arg_name == 'b'
	assert a.type_name == 'c'
	assert a.is_optional == 'd'
	assert a.default == 'e'



# Generated at 2022-06-23 16:58:59.233585
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(['arg:', 'parameter'], 'description', 'arg', 'string', 'is_optional', 'default')
    assert param.args == ['arg:', 'parameter']
    assert param.description == 'description'
    assert param.arg_name == 'arg'
    assert param.type_name == 'string'
    assert param.is_optional == 'is_optional'
    assert param.default == 'default'


# Generated at 2022-06-23 16:59:05.229078
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert (DocstringMeta(['a', 'b'], 'c')).args == ['a', 'b']
    assert (DocstringMeta(['a', 'b'], 'c')).description == 'c'


# Generated at 2022-06-23 16:59:10.805860
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert(docstring.short_description is None)
    assert(docstring.long_description is None)
    assert(docstring.blank_after_short_description == False)
    assert(docstring.blank_after_long_description == False)
    assert(len(docstring.meta) == 0)

# Unit tests for property params

# Generated at 2022-06-23 16:59:14.841082
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test Exception")
    except ParseError:
        a = True
    assert a == True


# Generated at 2022-06-23 16:59:25.583845
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam"""
    #Arrange
    dsParam_1 = DocstringParam(["param", "arg"], "description", "arg", "type_name", True, "default")
    dsParam_2 = DocstringParam(["param", "arg"], "description", "arg", "type_name", False, "default")
    dsParam_3 = DocstringParam(["param", "arg"], "description", "arg", "type_name", True, None)
    dsParam_4 = DocstringParam(["param", "arg"], "description", "arg", "type_name", False, None)
    dsParam_5 = DocstringParam(["param", "arg"], "description", "arg", None, True, "default")

# Generated at 2022-06-23 16:59:26.528925
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError('message')


# Generated at 2022-06-23 16:59:28.552124
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    return_docstring = DocstringReturns([], "A Value", "Return")
    assert return_docstring.type_name == "Return"
    assert return_docstring.description == "A Value"
    assert return_docstring.args == []



# Generated at 2022-06-23 16:59:37.614631
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_return_args = ['returns']
    docstring_return_description = 'it returns a number'
    docstring_return_type = 'int'
    docstring_return_is_generator = False
    docstring_returns = DocstringReturns(docstring_return_args,docstring_return_description,
        docstring_return_type,docstring_return_is_generator)
    assert docstring_returns.args == ['returns']
    assert docstring_returns.description == 'it returns a number'
    assert docstring_returns.type_name == 'int'
    assert docstring_returns.is_generator == False
    print("Passed test_DocstringReturns")

# Unit testing for method docstring.params

# Generated at 2022-06-23 16:59:39.971162
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(["raises"], "description", "ValueError")
    assert docstringRaises.args == ["raises"]
    assert docstringRaises.description == "description"
    assert docstringRaises.type_name == "ValueError"



# Generated at 2022-06-23 16:59:47.330838
# Unit test for constructor of class Docstring
def test_Docstring():
    docStr = Docstring()
    docStr.short_description = "Hello"
    docStr.long_description = "World"
    docStr.blank_after_short_description = True
    docStr.blank_after_long_description = False
    print(docStr.short_description)
    print(docStr.long_description)
    print(docStr.blank_after_long_description)
    print(docStr.blank_after_short_description)

    myEle = DocstringParam([], "", "", "", True, "")
    docStr.meta.append(myEle)
    for item in docStr.meta:
        if isinstance(item, DocstringParam):
            print("Found one!!")
    myEle = DocstringReturns([], "", "", True)

# Generated at 2022-06-23 16:59:49.208911
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["description"], "description", None)
    assert docstring_deprecated.args == ["description"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == None
    assert isinstance(docstring_deprecated, DocstringMeta)


# Generated at 2022-06-23 16:59:51.862038
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Parse Error')
    except ParseError as error:
        print(error)

# Generated at 2022-06-23 16:59:59.059118
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except RuntimeError:
        pass
    else:
        assert False, "ParseError should be a subclass of RuntimeError"


# Unit tests for constructors of classes DocstringMeta, DocstringParam, DocstringRaises, DocstringReturns, DocstringDeprecated

# Generated at 2022-06-23 17:00:00.146603
# Unit test for constructor of class ParseError
def test_ParseError():
    with pytest.raises(Exception):
        raise ParseError()

# Generated at 2022-06-23 17:00:03.438507
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(['deprecated', 'since', '1.0'], 'use foo() instead', '1.0')


# Generated at 2022-06-23 17:00:12.504402
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # TODO: this should be a formal test, using a test package
    r = DocstringReturns(args=['arg1', 'arg2'], description="descr", type_name="type_name")
    print(r.args)
    print(r.description)
    print(r.type_name)
    return

if __name__ == '__main__':
    test_DocstringReturns()

# Generated at 2022-06-23 17:00:17.721093
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

### TESTING: PARSE DOCSTRING

# Generated at 2022-06-23 17:00:25.672057
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstringRaises = DocstringRaises(["raises", "FileNotFoundError", "description"], "description", "FileNotFoundError")
    assert docstringRaises.args == ["raises", "FileNotFoundError", "description"]
    assert docstringRaises.description == "description"
    assert docstringRaises.type_name == "FileNotFoundError"


# Generated at 2022-06-23 17:00:31.411256
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []

# Generated at 2022-06-23 17:00:34.041810
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam([':param'], 'description', 'arg', 'type', True, 'default')



# Generated at 2022-06-23 17:00:41.805961
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(["a","b"],["c", "d"],["e","f"])
    assert not DocstringRaises(["a"],["c", "d"],["e","f"])
    assert not DocstringRaises(["a","b"],["c","d"],["e","f", "g"])
    assert not DocstringRaises(["a","b"],["c","d"],["e","f", "g", "h"])
    assert not DocstringRaises(["a","b","c"],["c","d"],["e","f", "g", "h"])




# Generated at 2022-06-23 17:00:48.747496
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    obj = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    assert obj.args == ["raises", "ValueError"]
    assert obj.type_name == "ValueError"
    assert obj.description == "if something happens"

# Generated at 2022-06-23 17:00:51.382056
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['abc'], None, 'abc', 'abc', True, None)
    

# Generated at 2022-06-23 17:00:54.869415
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(args=['deprecate'], description='description', version='version')
    doc

# Generated at 2022-06-23 17:01:05.856134
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Create a DocstringReturns object with required parameters
    test_args = ["arg1", "arg2"]
    test_description = "description"
    test_type_name = "type1"
    test_is_generator = False
    test_return_name = "return_name"
    test_object = DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    # Test if initial values are stored correctly in the DocstringReturns object
    assert test_object.args == test_args and test_object.description == test_description and test_object.type_name == test_type_name and test_object.is_generator == test_is_generator and test_object.return_name == test_return_name
    # Test the to_dict() function of

# Generated at 2022-06-23 17:01:09.385670
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("msg")
    except ParseError as e:
        print("test_ParseError: ParseError.__init__: Passed:", e)

if __name__ == "__main__":
    test_ParseError()

# Generated at 2022-06-23 17:01:15.230202
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(args=["param"], description="",
                           arg_name="arg_name", type_name="type_name", is_optional=True, default="12")
    assert param.args == ["param"]
    assert param.description == ""
    assert param.arg_name == "arg_name"
    assert param.type_name == "type_name"
    assert param.is_optional == True
    assert param.default == "12"



# Generated at 2022-06-23 17:01:22.056998
# Unit test for constructor of class Docstring
def test_Docstring():
    """Test constructor of class Docstring."""
    # test_Docstring_01
    d = Docstring()
    assert isinstance(d, Docstring)
    assert not d.short_description
    assert not d.long_description
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []



# Generated at 2022-06-23 17:01:23.853124
# Unit test for constructor of class ParseError
def test_ParseError():
    from pytest import raises
    with raises(RuntimeError):
        raise ParseError

# Generated at 2022-06-23 17:01:27.674612
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:01:29.043140
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # first parameter is args, second is description
    assert DocstringRaises(args="", description="")


# Generated at 2022-06-23 17:01:33.720920
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    pos_args = ["arg1", "arg2"]
    kwargs = dict(description="test")
    expected_value = DocstringMeta(pos_args, **kwargs)
    assert(expected_value.args == pos_args)
    assert(expected_value.description == kwargs["description"])

# Generated at 2022-06-23 17:01:34.621778
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], "", "", False, "")


# Generated at 2022-06-23 17:01:37.441685
# Unit test for constructor of class Docstring
def test_Docstring():
    my_docstring = Docstring()
    assert my_docstring.short_description == None
    assert my_docstring.long_description == None
    assert my_docstring.blank_after_short_description == False
    assert my_docstring.blank_after_long_description == False
    assert my_docstring.meta == []

################################################################################
# class DocstringParam


# Generated at 2022-06-23 17:01:44.696337
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-23 17:01:51.432204
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # if args is an empty list, then description is returned
    d = DocstringMeta([], 'description')
    assert d.description == 'description'
    assert d.args == []

    # if args is not an empty list, description is still returned
    d = DocstringMeta(['one','two'], 'description')
    assert d.description == 'description'
    assert d.args == ['one', 'two']



# Generated at 2022-06-23 17:02:00.739478
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ["param", "test", "arg", "argument", "attribute", "key", "keyword"]
    test_description = "This is a test docstring"
    test_type_name = "str"
    test_is_generator = True
    test_return_name = "test_return_name"

    r = DocstringReturns(test_args, test_description, test_type_name, test_is_generator, test_return_name)
    print(r)
    print(r.args, r.description, r.type_name, r.is_generator, r.return_name)


# Generated at 2022-06-23 17:02:05.220404
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    def test():
        args=[":deprecated: version 1.2.3", "Another line"]
        description="asdf"
        version="1.2.3"
        test_case = DocstringDeprecated(args, description, version)
        assert test_case.args == args
        assert test_case.description == description
        assert test_case.version == version

# Generated at 2022-06-23 17:02:12.871778
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    test_yields = DocstringParam(
        [1,2,3],
        "testing",
        "arg_1",
        "int",
        True,
        "def_val")
    assert test_yields.args == [1,2,3]
    assert test_yields.description == "testing"
    assert test_yields.arg_name == "arg_1"
    assert test_yields.type_name == "int"
    assert test_yields.is_optional == True
    assert test_yields.default == "def_val"


# Generated at 2022-06-23 17:02:18.593039
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    A = DocstringDeprecated(['deprecated','since','1.0'],"This is a test function.", "1.0")
    assert A.type_name == 'deprecated'
    assert A.description == 'This is a test function.'
    assert A.version == '1.0'

# Generated at 2022-06-23 17:02:21.717751
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['deprecated', 'version', '1.0'], "Deprecated.", "1.1")
    assert doc.type_name == None
    assert doc.description == "Deprecated."
    assert doc.version == "1.1"


# Generated at 2022-06-23 17:02:24.298906
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """
    This method tests the constructor of the DocstringDeprecated class.
    """
    # initialization
    args = ""
    description = ""
    version = ""
    DocstringDeprecated(args, description, version)

# Generated at 2022-06-23 17:02:33.221074
# Unit test for constructor of class Docstring
def test_Docstring():
    """
    Test the construction of Docstring with the following values:
        - short_description = None
        - long_description = None
        - blank_after_short_description = False
        - blank_after_long_description = False
        - meta = []
    """

    e = Docstring()

    c = Docstring()
    assert c.short_description == e.short_description
    assert c.long_description == e.long_description
    assert c.blank_after_short_description == e.blank_after_short_description
    assert c.blank_after_long_description == e.blank_after_long_description
    assert c.meta == e.meta



# Generated at 2022-06-23 17:02:37.133418
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    test_docstring = DocstringDeprecated(['deprecated'], 'description', '1.0')
    assert test_docstring.description == 'description'
    assert test_docstring.version == '1.0'


# Generated at 2022-06-23 17:02:41.257782
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    #create a new object
    a = DocstringDeprecated(args=["a"], description="asd", version="1.0")
    #check if the correct class is returned
    assert(isinstance(a, DocstringDeprecated) == True)
test_DocstringDeprecated()

# Generated at 2022-06-23 17:02:43.783994
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"

# Generated at 2022-06-23 17:02:49.327505
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ':param arg: description'.split()
    description = 'description'
    type_name = 'type_name'
    d = DocstringRaises(args, description, type_name)
    assert d.args == args
    assert d.description == description
    assert d.type_name == type_name


# Generated at 2022-06-23 17:02:50.680311
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    pass


# Generated at 2022-06-23 17:02:55.361264
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Unit tests for constructor of class DocstringMeta."""
    a = DocstringMeta([" : param : "], " description ")
    assert a.args == [" : param : "]
    assert a.description == " description "



# Generated at 2022-06-23 17:02:56.133913
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError("test")


# Generated at 2022-06-23 17:03:02.251328
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []



# Generated at 2022-06-23 17:03:07.053050
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["test", "function"]
    description = "desc"
    type_name = "type"
    x = DocstringRaises(args, description, type_name)
    assert x.args == ["test", "function"]
    assert x.description == description
    assert x.type_name == type_name


# Generated at 2022-06-23 17:03:08.362311
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    obj = DocstringDeprecated(None, None, None)
    assert obj.version == None


# Generated at 2022-06-23 17:03:10.362314
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], "", None).description is None
    assert DocstringDeprecated([], "", None).version is None
    assert DocstringDeprecated([], "", None).args == []


# Generated at 2022-06-23 17:03:16.293946
# Unit test for constructor of class Docstring
def test_Docstring():
    docstr = Docstring()
    assert (docstr.short_description is None)
    assert (docstr.long_description is None)
    assert (docstr.blank_after_short_description == False)
    assert (docstr.blank_after_long_description == False)
    assert (len(docstr.meta) == 0)
    assert (docstr.params == [])
    assert (docstr.raises == [])
    assert (docstr.returns == None)
    assert (docstr.deprecation == None)


# Generated at 2022-06-23 17:03:22.759929
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(["a"], "some description", "arg", "str", True, "str")
    assert(a.args[0] == "a")
    assert(a.description == "some description")
    assert(a.arg_name == "arg")
    assert(a.type_name == "str")
    assert(a.is_optional == True)
    assert(a.default == "str")

# Generated at 2022-06-23 17:03:26.451149
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []

# Generated at 2022-06-23 17:03:28.846577
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['a'], 'b', 'float', True, 'return_name')
    print(a.__dict__)


# Generated at 2022-06-23 17:03:33.882284
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    newDeprecated = DocstringDeprecated(
        ["text"], "text2", "1"
    )
    assert newDeprecated is not None
    assert newDeprecated.version == "1"
    assert newDeprecated.description == "text2"


# Generated at 2022-06-23 17:03:38.088514
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['a']
    description = 'something'
    type_name = 'int'
    test_obj = DocstringRaises(args, description, type_name)
    assert test_obj.args == args \
            and test_obj.description == description \
            and test_obj.type_name == type_name



# Generated at 2022-06-23 17:03:44.040688
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    dsr = DocstringReturns("args", "description", "typename", True, "return_name")
    assert dsr.args == "args"
    assert dsr.description == "description"
    assert dsr.type_name == "typename"
    assert dsr.is_generator == True
    assert dsr.return_name == "return_name"


# Generated at 2022-06-23 17:03:49.273565
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns('args', 'description', 'type_name', True).__dict__ == \
           {'args': 'args',
            'description': 'description',
            'type_name': 'type_name',
            'is_generator': True,
            'return_name': None}

# Generated at 2022-06-23 17:03:56.318725
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring = DocstringParam(args = "param", description = "description", arg_name = "arg_name", type_name = "type_name", is_optional = None, default = None)
    assert docstring.args == "param"
    assert docstring.description == "description"
    assert docstring.arg_name == "arg_name"
    assert docstring.type_name == "type_name"
    assert docstring.is_optional == None
    assert docstring.default == None


# Generated at 2022-06-23 17:04:06.082004
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    parameters = ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    descript = 'this is the description'
    argname = 'argname'
    typename = 'typename'
    is_opt = True
    dfault = 'default'

    for param in parameters:
        _param = DocstringParam([param], descript, argname, typename, is_opt, dfault)

        assert(_param.args == [param])
        assert(_param.description == descript)
        assert(_param.arg_name == argname)
        assert(_param.type_name == typename)
        assert(_param.is_optional == is_opt)
        assert(_param.default == dfault)


# Generated at 2022-06-23 17:04:10.450449
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    z = DocstringReturns(['return', 'returns'], "Returns description", "str", False)
    assert z.description == "Returns description"
    assert not z.is_generator
    assert z.type_name == 'str'
    assert z.args == ['return', 'returns']
    assert z.return_name is None


# Generated at 2022-06-23 17:04:14.019699
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a_param = DocstringParam([], None, None, None, None, None)
    assert a_param.args == []
    assert a_param.description == None
    assert a_param.arg_name == None
    assert a_param.type_name == None
    assert a_param.is_optional == None
    assert a_param.default == None


# Generated at 2022-06-23 17:04:18.425546
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()

    assert(ds.short_description == None)
    assert(ds.long_description == None)
    assert(ds.blank_after_long_description == False)
    assert(ds.blank_after_short_description == False)
    assert(ds.meta == [])


# Generated at 2022-06-23 17:04:21.314445
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated([], 'desc', '5.5')
    assert DocstringDeprecated(['1', '2', '3'], None, None)

# Generated at 2022-06-23 17:04:26.555377
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    input = DocstringDeprecated(["abc", "abd"], "deprecation description", "1.2.3")
    assert input.args == ["abc", "abd"]
    assert input.description == "deprecation description"
    assert input.version == "1.2.3"


# Generated at 2022-06-23 17:04:33.208934
# Unit test for constructor of class Docstring
def test_Docstring():
    """Unit test for constructor of class Docstring."""
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_long_description == False
    assert docstring.blank_after_short_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None



# Generated at 2022-06-23 17:04:34.865153
# Unit test for constructor of class ParseError
def test_ParseError():
    exc = ParseError("Caught an error")
    assert str(exc) == "Caught an error"

# Generated at 2022-06-23 17:04:39.538885
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-23 17:04:41.513478
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    input = DocstringMeta(":param int a: desc", None)
    assert input.args == ":param int a: desc"
    

# Generated at 2022-06-23 17:04:52.794477
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description == None
    assert doc.long_description == None
    assert doc.blank_after_short_description == False
    assert doc.blank_after_long_description == False
    assert doc.meta == []

    # testing property params
    doc.meta.append(DocstringParam(["param"], "description", "arg_name", None, None, None))
    # return value of property params
    assert doc.params == [DocstringParam(["param"], "description", "arg_name", None, None, None)]

    # testing property raises
    doc.meta.append(DocstringRaises(["raises"], "description", None))
    # return value of property raises
    assert doc.raises == [DocstringRaises(["raises"], "description", None)]

    # testing property returns

# Generated at 2022-06-23 17:05:03.584320
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    test_args = ["args"]
    test_description = "Test description"
    test_type_name = "test_type_name"
    test_is_generator = True
    test_return_name = "test_return_name"
    test_DocstringReturns = DocstringReturns(test_args, test_description,
                                             test_type_name, test_is_generator,
                                             test_return_name)

    assert test_DocstringReturns.args == test_args
    assert test_DocstringReturns.description == test_description
    assert test_DocstringReturns.type_name == test_type_name
    assert test_DocstringReturns.is_generator == test_is_generator
    assert test_DocstringReturns.return_name == test_return_name


# Generated at 2022-06-23 17:05:08.336005
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    this_docstring = DocstringDeprecated(["This", "is"], "the description.", "1.0")
    assert this_docstring.args == ["This", "is"]
    assert this_docstring.description == "the description."
    assert this_docstring.version == "1.0"


# Generated at 2022-06-23 17:05:11.130136
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["string", "test"], "description")
    assert d.args == ["string", "test"]
    assert d.description == "description"


# Generated at 2022-06-23 17:05:12.010687
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated("args", "description", "version")

# Generated at 2022-06-23 17:05:15.955823
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(['param'], 'Some Description', 'TypeError')
    assert ds.args == ['param']
    assert ds.description == "Some Description"
    assert ds.type_name == "TypeError"

# Generated at 2022-06-23 17:05:20.538995
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	args = ["a", "b"]
	description = "This is a description"
	type_name = "str"
	data = DocstringRaises(args, description, type_name)
	assert data.a
	assert data.b

# Generated at 2022-06-23 17:05:29.484007
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    doc_item = DocstringReturns(['Yields'], 'value when x is greater than 0', type_name=None, is_generator=False)
    assert doc_item.args == ['Yields'], 'There was an error in the initialization of the DocstringReturns class'
    assert doc_item.description == 'value when x is greater than 0', 'There was an error in the initialization of the DocstringReturns class'
    assert doc_item.type_name is None, 'There was an error in the initialization of the DocstringReturns class'
    assert doc_item.is_generator is False, 'There was an error in the initialization of the DocstringReturns class'
    assert doc_item.return_name is None, 'There was an error in the initialization of the DocstringReturns class'


# Generated at 2022-06-23 17:05:31.982522
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass
    except Exception:
        assert False
