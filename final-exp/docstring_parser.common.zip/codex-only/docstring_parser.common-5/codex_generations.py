

# Generated at 2022-06-23 16:55:28.908258
# Unit test for constructor of class ParseError
def test_ParseError():
	pass

# Generated at 2022-06-23 16:55:40.770789
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    doc_param = DocstringParam(args=['param', 'arg'], description='description',
                               arg_name='arg', type_name='type_name', is_optional='is_optional',
                               default='default')
    assert doc_param.args == ['param', 'arg']
    assert doc_param.description == 'description'
    assert doc_param.arg_name == 'arg'
    assert doc_param.type_name == 'type_name'
    assert doc_param.is_optional == 'is_optional'
    assert doc_param.default == 'default'
    #test for None type
    doc_param = DocstringParam(args=['param', 'arg'], description='description',
                               arg_name=None, type_name=None, is_optional=None, default=None)
    assert doc_

# Generated at 2022-06-23 16:55:43.420183
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError"""
    assert ParseError("test")
    print("test_ParseError done")

# Generated at 2022-06-23 16:55:46.703106
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        pass
    except Exception as e:
        raise ParseError('ParseError test_ParseError') from e


# Generated at 2022-06-23 16:55:53.417126
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_meta = DocstringRaises(["raises", "ValueError"], "if something happens", "ValueError")
    assert (docstring_meta.args == ["raises", "ValueError"])
    assert (docstring_meta.description == "if something happens")
    assert (docstring_meta.type_name == "ValueError")
    assert (not isinstance(docstring_meta, DocstringParam))
    assert (not isinstance(docstring_meta, DocstringReturns))
    assert (not isinstance(docstring_meta, DocstringDeprecated))


# Generated at 2022-06-23 16:55:55.922269
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError()
    except ParseError:
        pass
    else:
        assert False


# Generated at 2022-06-23 16:55:57.659204
# Unit test for constructor of class Docstring
def test_Docstring():
    assert(Docstring())


# Generated at 2022-06-23 16:56:00.809658
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    d = DocstringRaises(["raises", "ValueError"], "description", "type_name")
    assert d.type_name == "type_name"
    assert d.description == "description"

# Generated at 2022-06-23 16:56:03.641999
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    item = DocstringRaises(["param"], "description", "type")
    assert item.args == ["param"]
    assert item.description == "description"
    assert item.type_name == "type"


# Generated at 2022-06-23 16:56:10.060887
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert (DocstringReturns(['arg'], 'description', None, False).is_generator)
    assert (not DocstringReturns(['arg'], 'description', None, False).return_name)
    assert (not DocstringReturns(['arg'], 'description', None, False).description)


# Generated at 2022-06-23 16:56:11.569267
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(args=[], description='')


# Generated at 2022-06-23 16:56:19.303059
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Constructor of class DocstringDeprecated
    args = []
    description = "test"
    version = "0.0.0.4"
    testDocstringDeprecated = DocstringDeprecated(args, description, version)
    print("testDocstringDeprecated", testDocstringDeprecated)
    print("testDocstringDeprecated.args", testDocstringDeprecated.args)
    print("testDocstringDeprecated.description", testDocstringDeprecated.description)
    print("testDocstringDeprecated.version", testDocstringDeprecated.version)


# Generated at 2022-06-23 16:56:21.913248
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of class DocstringMeta."""
    obj = DocstringMeta(["arg"], "Test description")
    assert obj.args == ["arg"]
    assert obj.description == "Test description"


# Generated at 2022-06-23 16:56:25.548892
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("This is not a valid docstring")
    except ParseError as e:
        assert e.args[0] == "This is not a valid docstring"

s = """
:param arg: description
:raises ValueError: if something happens
"""

# Generated at 2022-06-23 16:56:34.715164
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
	docstringparam = DocstringParam(['some_stuff'], 'description', 'arg_name', 'type_name', True, 'default')
	assert docstringparam.args == ['some_stuff']
	assert docstringparam.description == 'description'
	assert docstringparam.arg_name == 'arg_name'
	assert docstringparam.type_name == 'type_name'
	assert docstringparam.is_optional == True
	assert docstringparam.default == 'default'

# Generated at 2022-06-23 16:56:38.805516
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 16:56:42.945151
# Unit test for constructor of class Docstring
def test_Docstring():
    assert Docstring().short_description == None
    assert Docstring().long_description == None
    assert Docstring().blank_after_short_description == False
    assert Docstring().blank_after_long_description == False
    assert Docstring().meta == []


# Generated at 2022-06-23 16:56:48.974336
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():

    args = ['arg1', 'arg2', 'arg3']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = None

    assert DocstringReturns(args, description, type_name, is_generator, return_name)


# Generated at 2022-06-23 16:56:57.087794
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    ob1 = DocstringParam(['param','arg','argument','attribute','key','keyword'],"description", "arg_name", "type_name", False, "default")
    assert ob1.args == ['param','arg','argument','attribute','key','keyword']
    assert ob1.description == "description"
    assert ob1.arg_name == "arg_name"
    assert ob1.type_name == "type_name"
    assert ob1.is_optional == False
    assert ob1.default == "default"


# Generated at 2022-06-23 16:56:58.457782
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    print(DocstringMeta([], ""))


# Generated at 2022-06-23 16:57:03.132118
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'My description'
    version = '1.2'
    x = DocstringDeprecated(args,description,version)
    assert x.description == description
    assert x.version == version

# Generated at 2022-06-23 16:57:09.414621
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """
    Test the constructor of class DocstringMeta.
    """
    args = ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = 'description'
    test_object = DocstringMeta(args, description)
    assert test_object.args == args
    assert test_object.description == description


# Generated at 2022-06-23 16:57:20.067003
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
  # Declaring instances of classes
  dm_keyword_raise = DocstringRaises(["raise"], "if something happens", "ValueError")
  dm_keyword_raises = DocstringRaises(["raises"], "if something happens", "ValueError")
  dm_keyword_except = DocstringRaises(["except"], "if something happens", "ValueError")
  dm_keyword_exception = DocstringRaises(["exception"], "if something happens", "ValueError")
  assert dm_keyword_raise.description == "if something happens"
  assert dm_keyword_raises.description == "if something happens"
  assert dm_keyword_except.description == "if something happens"
  assert dm_keyword_exception.description == "if something happens"
  assert dm_

# Generated at 2022-06-23 16:57:24.559505
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert(docstring)
    assert(docstring.short_description is None)
    assert(docstring.long_description is None)
    assert(docstring.blank_after_short_description is False)
    assert(docstring.blank_after_long_description is False)
    assert(docstring.meta == [])
test_Docstring()



# Generated at 2022-06-23 16:57:29.039283
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []
    assert doc.params == []
    assert doc.raises == []
    assert doc.returns is None
    assert doc.deprecation is None


# Generated at 2022-06-23 16:57:31.778792
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test error")
    except ParseError:
        return True
    return False


# Generated at 2022-06-23 16:57:33.797681
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("type error")
    assert error.args[0] == "type error"


# Generated at 2022-06-23 16:57:41.469462
# Unit test for constructor of class Docstring
def test_Docstring():
	
	# Inialize 3 different objects from class Docstring
	test_object = Docstring()
	test_object.short_description = 'test_short'
	test_object.long_description = 'test_long'
	test_object.blank_after_short_description = False
	test_object.blank_after_long_description = False
	test_object.meta = []
	
	test_object2 = Docstring()
	test_object2.short_description = 'test_short2'
	test_object2.long_description = 'test_long2'
	test_object2.blank_after_short_description = False
	test_object2.blank_after_long_description = False
	test_object2.meta = []
	
	test_object3 = Docstring()

# Generated at 2022-06-23 16:57:53.148459
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg']
    description = 'description'
    type_name = None
    is_generator = False
    return_name = None
    docstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert type(docstringReturns.args) == list
    assert type(docstringReturns.description) == str
    assert type(docstringReturns.type_name) == NoneType
    assert type(docstringReturns.is_generator) == bool
    assert type(docstringReturns.return_name) == NoneType
    assert docstringReturns.args == ['arg']
    assert docstringReturns.description == 'description'
    assert docstringReturns.type_name == None
    assert docstringReturns.is_generator == False
    assert docstringReturns.return_name == None



# Generated at 2022-06-23 16:58:05.955009
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    print(docstring.params)
    print(docstring.raises)
    print(docstring.returns)
    print(docstring.deprecation)

test_Docstring()

"""
                                              | Params
                                              |  Raises
                                              |   Returns
                                              |         Deprecated
                                              |                       Short description
                                              |                       Long description
                                              |                       Meta info
"""
STRING = """
This is a function that does something.

:param arg: description
:param arg2: description2
:type arg2: str
:param arg3: description3
:raise ValueError: if something happens
:return: description
:rtype: int
:deprecated: 0.11
"""

STRING_NO_SHORT_DESC

# Generated at 2022-06-23 16:58:06.866159
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test error')
    except ParseError as e:
        assert str(e) == 'test error'

# Generated at 2022-06-23 16:58:11.784053
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(['raises', 'ValueError'], 'Test Description', None).type_name == None
    assert DocstringRaises(['raises', 'ValueError'], 'Test Description', 'ValueError').type_name == 'ValueError'


# Generated at 2022-06-23 16:58:14.710188
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    print("testing constructor of class ParseError")
    test = ParseError("Test Input")
    assert test.args[0] == "Test Input"

# Generated at 2022-06-23 16:58:22.074763
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param", "arg"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["param", "arg"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-23 16:58:26.224905
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test for the constructor of class DocstringReturns."""
    x = DocstringReturns(["returns"], "Some description", None, False)
    assert x.args == ["returns"]
    assert x.description == "Some description"
    assert x.type_name == None
    assert x.is_generator == False


# Generated at 2022-06-23 16:58:31.326951
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert(docstring.short_description == None)
    assert(docstring.long_description == None)
    assert(docstring.blank_after_short_description == False)
    assert(docstring.blank_after_long_description == False)
    assert(docstring.meta == [])
    assert(docstring.params == [])
    assert(docstring.raises == [])
    assert(docstring.deprecation == None)
    assert(docstring.returns == None)



# Generated at 2022-06-23 16:58:41.321692
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # :param arg: description
    # :parameter arg: description
    # :arg arg: description
    # :argument arg: description
    # :key arg: description
    # :keyword arg: description
    # :attribute arg: description

    # tests for :param
    dm = DocstringMeta(["param", "arg"], "description")
    assert dm.args == ["param", "arg"]
    assert dm.description == "description"

    # tests for :parameter
    dm = DocstringMeta(["parameter", "arg"], "description")
    assert dm.args == ["parameter", "arg"]
    assert dm.description == "description"

    # tests for :arg
    dm = DocstringMeta(["arg", "arg"], "description")
    assert dm.args == ["arg", "arg"]

# Generated at 2022-06-23 16:58:43.662549
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(
        ["param", "blah"], "This is a docstring", "blah", "str", True, "blah"
    ) is not None



# Generated at 2022-06-23 16:58:48.450432
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    assert DocstringRaises(
        args = ["raises"],
        description = "if something happens",
        type_name = "ValueError"
    ).__init__(
        args = ["raises"],
        description = "if something happens",
        type_name = "ValueError"
    )

# Generated at 2022-06-23 16:58:54.251890
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    raises = DocstringRaises(['param'], 'description', 'type')
    assert raises.args == ['param']
    assert raises.description == 'description'
    assert raises.type_name == 'type'



# Generated at 2022-06-23 16:59:00.268361
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns', 'type', 'des']
    k = DocstringReturns(args, 'type', 'des', False)
    assert(k.args == args)
    assert(k.description == 'type') # Description can not be assigned in the DocstringReturns init
    assert(k.type_name == 'des')
    assert(k.is_generator == False)


# Generated at 2022-06-23 16:59:12.153345
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    ds = DocstringDeprecated(args=['param', 'j'], description='desc',
                             version='0.1')  # type: DocstringDeprecated
    assert ds.args == ['param', 'j']
    assert ds.description == 'desc'
    assert ds.version == '0.1'
    assert isinstance(ds, DocstringMeta)
    ds = DocstringDeprecated(args=['param', 'j'],
                             description='desc', version=None)
    assert ds.args == ['param', 'j']
    assert ds.description == 'desc'
    assert ds.version is None
    assert isinstance(ds, DocstringMeta)
    ds = DocstringDeprecated(args=['param', 'j'], description=None,
                             version='0.1')  #

# Generated at 2022-06-23 16:59:18.421432
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "Hello World", "1.0.0")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "Hello World"
    assert docstring.version == "1.0.0"

# Generated at 2022-06-23 16:59:22.102951
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    def_obj = DocstringDeprecated(['deprecated'], 'This version is not supported', '1.0')
    assert def_obj.type_name == '1.0'
    assert def_obj.description == 'This version is not supported'

# Generated at 2022-06-23 16:59:33.835361
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    # Testing this path of the constructor, when a value is supplied for each parameter
    test_constructor1 = DocstringRaises(['param'], 'raises', 'ValueError')
    assert test_constructor1.args == ['param']
    assert test_constructor1.description == 'raises'
    assert test_constructor1.type_name == 'ValueError'

    # Testing this path of the constructor, when no value is supplied for 'self.description'
    test_constructor2 = DocstringRaises(['param'], None, None)
    assert test_constructor2.args == ['param']
    assert test_constructor2.description is None
    assert test_constructor2.type_name is None


# Generated at 2022-06-23 16:59:36.861665
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'foo']
    description = 'description of args'

    doc_meta = DocstringMeta(args, description)
    assert doc_meta.args == args
    assert doc_meta.description == description


# Generated at 2022-06-23 16:59:43.622533
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-23 16:59:50.236713
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """Unit test for constructor of class DocstringRaises"""
    a = DocstringRaises(['a','b','c'], 'an error', 'b')
    print(a)
    print(a.args)
    print(a.description)
    print(a.type_name)

test_DocstringRaises()

# Generated at 2022-06-23 16:59:53.198087
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
	m = DocstringRaises(['args'], 'description', 'type_name')
	assert m.type_name == 'type_name'
	assert m.description == 'description'


# Generated at 2022-06-23 17:00:03.438281
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    testObject = DocstringParam(["param"], "This is description", "arg", "str", None, None)
    assert testObject.args == ["param"], "The args are wrong"
    assert testObject.description == "This is description", "The description is wrong"
    assert testObject.type_name == "str", "The type_name is wrong"
    assert testObject.is_optional == None, "The is_optional is wrong"
    assert testObject.default == None, "The default is wrong"


# Generated at 2022-06-23 17:00:08.959164
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(['version', '2.0'], 'description', '3.0')
    assert doc.version == '3.0'
    assert doc.description == 'description'


# Generated at 2022-06-23 17:00:18.612757
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta1 = DocstringDeprecated(
        ["deprecated"],
        "This function is deprecated, use new_function instead.",
        "1.0",
    )
    assert meta1.args == ["deprecated"]
    assert meta1.description == "This function is deprecated, use new_function instead."
    assert meta1.version == "1.0"

    meta2 = DocstringDeprecated(
        ["Remove"],
        "This function is deprecated, use new_function instead.",
        None,
    )
    assert meta2.args == ["Remove"]
    assert meta2.description == "This function is deprecated, use new_function instead."
    assert meta2.version is None


# Generated at 2022-06-23 17:00:23.236843
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(args = [], description = "description")
    assert str(d) == "DocstringMeta('description')", print(str(d))


# Generated at 2022-06-23 17:00:25.630341
# Unit test for constructor of class Docstring
def test_Docstring():
    assert str(Docstring) == "<class 'pydocstyle.checker.parse.Docstring'>"



# Generated at 2022-06-23 17:00:28.324944
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("Error message.")
    assert str(error) == "Error message."


# Generated at 2022-06-23 17:00:32.690355
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    try:
        raise ParseError("Please check the input")
    except ParseError as err:
        assert err.args[0] == "Please check the input"


# Generated at 2022-06-23 17:00:40.413557
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = "description"
    type_name = "type"
    is_generator = True
    return_name = "return_name"
    d = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert d.args == args
    assert d.description == description
    assert d.type_name == type_name
    assert d.is_generator == is_generator
    assert d.return_name == return_name

# Generated at 2022-06-23 17:00:47.341876
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = []
    description = ""
    type_name = None
    raiseInstance = DocstringRaises(args, description, type_name)
    assert raiseInstance.args is args
    assert raiseInstance.description is description
    assert raiseInstance.type_name is None


# Generated at 2022-06-23 17:00:50.752750
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated(ver >= 1.0.0):"], "is deprecated", "since 1.0.0")



# Generated at 2022-06-23 17:00:52.494443
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("ParseError")
    except (ParseError):
        pass


# Generated at 2022-06-23 17:00:54.029845
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('Parsing Error')
    except ParseError as err:
        assert str(err) == 'Parsing Error'


# Generated at 2022-06-23 17:01:00.240997
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'Raise', 'Exception']
    description = None
    type_name = 'Exception'
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.__init__(args, description, type_name)



# Generated at 2022-06-23 17:01:04.629533
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(["param","arg", "arugment"], "something goes wrong", "ValueError")
    assert a.args == ["param","arg", "arugment"]
    assert a.description == "something goes wrong"
    assert a.type_name == "ValueError"

# Generated at 2022-06-23 17:01:12.928581
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    d1 = DocstringReturns(['arg1', 'arg2'], 'desc', 'type', False, 'return_name')
    docstring_returns = DocstringReturns(['arg1'], 'desc', 'type', False, 'return_name')
    assert d1.args == ['arg1', 'arg2']
    assert d1.description == 'desc'
    assert d1.type_name == 'type'
    assert d1.is_generator == False
    assert d1.return_name == 'return_name'
    assert docstring_returns.args == ['arg1']
    assert docstring_returns.description == 'desc'
    assert docstring_returns.type_name == 'type'
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name

# Generated at 2022-06-23 17:01:15.211166
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "parameter")



# Generated at 2022-06-23 17:01:25.386828
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    # Instantiate DocstringReturns object
    args = ['arg1', 'arg2']
    description = 'stuff'
    type_name = 'int'
    is_generator = True
    doc_str = DocstringReturns(args, description, type_name, is_generator)
    # Assertions
    assert doc_str.args == ['arg1', 'arg2']
    assert doc_str.description == 'stuff'
    assert doc_str.type_name == 'int'
    assert doc_str.is_generator
    assert doc_str.return_name == None



# Generated at 2022-06-23 17:01:32.803940
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    meta = DocstringDeprecated(args=["param"], description="description", version="version")
    assert meta.args == ["param"]
    assert meta.description == "description"
    assert meta.version == "version"
    assert meta.type_name is None
    assert meta.is_generator is None
    assert meta.arg_name is None
    assert meta.is_optional is None
    assert meta.default is None
    assert meta.return_name is None

# Generated at 2022-06-23 17:01:34.248280
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(['raise'], 'exception', 'ValueError')


# Generated at 2022-06-23 17:01:35.924670
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(args=[], description="", version="1.0")


# Generated at 2022-06-23 17:01:41.316980
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(['a', 'b'], 'this is a description', 2)
    assert d.args == ['a', 'b']
    assert d.description == 'this is a description'
    assert d.version == 2



# Generated at 2022-06-23 17:01:47.068895
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns(['a'], "a", "a", "a", False)
    assert a.description == "a"
    assert a.is_generator == "a"
    assert a.return_name == False
    assert a.type_name == "a"
    assert a.args == ['a']


# Generated at 2022-06-23 17:01:54.229545
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [":param", ":raises"]
    description = "raised if too many parameters"
    type_name = "ValueError"
    raises = DocstringRaises(args, description, type_name)
    assert raises.args == [":param", "raises"]
    assert raises.description == description
    assert raises.type_name == type_name
    assert raises.args[0] == ":param"
    assert raises.args[1] == "raises"
    assert raises.description is not None
    assert raises.type_name is not None



# Generated at 2022-06-23 17:01:55.774110
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns([], None, None, False, None)



# Generated at 2022-06-23 17:01:57.897134
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    a = DocstringRaises(None, None, "ValueError")
    assert a.type_name == "ValueError"


# Generated at 2022-06-23 17:02:02.175397
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["test","param"], "description")
    assert meta.description == "description"
    assert meta.args == ["test","param"]
    args = []
    for arg in meta.args:
        args.append(arg)
    assert args == ["test", "param"]


# Generated at 2022-06-23 17:02:04.064720
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
	assert DocstringReturns([], None, None, False, None) is not None


# Generated at 2022-06-23 17:02:09.481187
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = [""]
    description = "test_description"
    type_name = "test_type_name"
    a = DocstringRaises(args, description, type_name)
    assert a.args == [""]
    assert a.description == "test_description"
    assert a.type_name == "test_type_name"
    assert a.args == [""]
    assert a.description == "test_description"
    assert a.type_name == "test_type_name"

# Generated at 2022-06-23 17:02:12.422274
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docDeprecated = DocstringDeprecated(["deprecated"], "Old Function", "0.0.1")
    assert docDeprecated.__dict__ == {"args": ["deprecated"], "description": "Old Function", "version": "0.0.1"}

# Generated at 2022-06-23 17:02:14.038619
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises([1, 2, 3], 'desc.', 'TypeName')
    #assert True

# Generated at 2022-06-23 17:02:16.264763
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test!")
    except ParseError as e:
        pass


# Generated at 2022-06-23 17:02:19.816808
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['args'], 'summary', 'type')
    assert test.args == ['args']

# Generated at 2022-06-23 17:02:22.738340
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    """
    Unit test for constructor of class DocstringRaises
    """
    assert DocstringRaises([], "test_description", "ValueError")


# Generated at 2022-06-23 17:02:25.453136
# Unit test for constructor of class ParseError
def test_ParseError():
    error = ParseError("overall")
    assert "overall" in str(error)


# Generated at 2022-06-23 17:02:30.148996
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:02:40.164338
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstringParam = DocstringParam(['param','arg','argument'],"description of the function","arg1", "int", None, None)
    print("Short Description: ",docstringParam.args)
    print("long description: ",docstringParam.description)
    print("argname: ",docstringParam.arg_name)
    print("argtype: ",docstringParam.type_name)
    print("isOptional: ",docstringParam.is_optional)
    print("default: ",docstringParam.default)
    assert docstringParam != None

test_DocstringParam()


# Generated at 2022-06-23 17:02:42.986052
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    try:
        param_example = DocstringParam(["a", "b"], "c", "arg_name", "type_name", True, "default")
    except:
        return False
    return True


# Generated at 2022-06-23 17:02:45.579416
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    ds = DocstringRaises(["raises"], "desc", "Exception")
    assert ds.type_name == "Exception"
    assert ds.description == "desc"


# Generated at 2022-06-23 17:02:50.681613
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    doc = DocstringRaises(["arg1", "arg2"], "description", "ValueError")
    assert doc.args == ["arg1", "arg2"]
    assert doc.description == "description"
    assert doc.type_name == "ValueError"



# Generated at 2022-06-23 17:02:53.795179
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["param"]
    description = "Some description"
    version = "1.7"
    test = DocstringDeprecated(args, description, version)


# Generated at 2022-06-23 17:02:55.682258
# Unit test for constructor of class ParseError
def test_ParseError():
    assert(str(ParseError("test")) == "test")

test_ParseError()

# Generated at 2022-06-23 17:02:59.247613
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    D = DocstringDeprecated([], None, None)
    assert D.args is None and D.description is None and D.version is None


# Generated at 2022-06-23 17:03:04.778724
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(args = ['a','b'], description = None, version = '1.0')
    assert isinstance(d, DocstringDeprecated)
    assert d.args == ['a', 'b']
    assert d.description == None
    assert d.version == '1.0'

# Generated at 2022-06-23 17:03:06.538784
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    d = DocstringParam([], "", "", "", "", "")



# Generated at 2022-06-23 17:03:08.848482
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    import pytest
    from pydocstyle.violations import Violation
    DocstringDeprecated(["deprecated"], "description", None)
    with pytest.raises(Violation):
        DocstringDeprecated(["not"], "description", None)

# Generated at 2022-06-23 17:03:11.455447
# Unit test for constructor of class ParseError
def test_ParseError():
    """Unit test for constructor of class ParseError."""
    err = ParseError('raise Exception', 'test error.')
    assert err.args == ('raise Exception',)
    assert err.__str__() == 'test error.\n'

# Generated at 2022-06-23 17:03:12.027503
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    pass

# Generated at 2022-06-23 17:03:13.935767
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    a = DocstringReturns([], "", "", "", "")
    print("DocstringReturns test passed")
    return 0


# Generated at 2022-06-23 17:03:15.122036
# Unit test for constructor of class ParseError
def test_ParseError():
    # Error message is A
    ParseError("A")


# Generated at 2022-06-23 17:03:20.482962
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', '', 'arg', '', 'description']
    arg_name = args[2]
    type_name = args[4]
    default = args[6]
    is_optional = False
    dsParam = DocstringParam(args, 'description', arg_name, type_name, is_optional, default)

# Generated at 2022-06-23 17:03:21.292064
# Unit test for constructor of class ParseError
def test_ParseError():
    assert ParseError
    assert ParseError('')


# Generated at 2022-06-23 17:03:26.795518
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = None
    arg_name = 'a'
    type_name = None
    is_optional = None
    default = None
    dp = DocstringParam(args=args, description=description, arg_name=arg_name, type_name=type_name, is_optional=is_optional, default=default)


# Generated at 2022-06-23 17:03:28.129486
# Unit test for constructor of class ParseError
def test_ParseError():
    parseError = ParseError()

test_ParseError()


# Generated at 2022-06-23 17:03:33.163321
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ["args"]
    test_description = "description"
    test_docstring = DocstringMeta(test_args, test_description)
    assert test_docstring.args == test_args
    assert test_docstring.description == test_description


# Generated at 2022-06-23 17:03:37.490852
# Unit test for constructor of class Docstring
def test_Docstring():
    doc_variables = ['short_description', 'long_description', 'blank_after_short_description', 'blank_after_long_description', 'meta']
    docstring = Docstring()
    # check that each attribute exists
    for var in doc_variables:
        assert hasattr(docstring, var)



# Generated at 2022-06-23 17:03:40.047773
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    import doctest
    if doctest.testmod()[0] == 0:
        print("All tests passed")

# Generated at 2022-06-23 17:03:43.096522
# Unit test for constructor of class ParseError
def test_ParseError():
    # has correct base class
    assert issubclass(ParseError, RuntimeError)
    # instance can be created
    err = ParseError()


# Generated at 2022-06-23 17:03:48.916480
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    dR = DocstringRaises(['raises'], 'description', 'type1')
    print(dR.args, dR.description, dR.type_name)
    assert dR.args == ['raises']
    assert dR.description == 'description'
    assert dR.type_name == 'type1'


# Generated at 2022-06-23 17:03:51.316732
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("error message")
    except ParseError as e:
        assert e.args[0] == "error message"


# Generated at 2022-06-23 17:03:53.549195
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
     import pytest
     with pytest.raises(TypeError):
         DocstringDeprecated(args = "test", description = "test", version = "test")

# Generated at 2022-06-23 17:04:02.262103
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    arguments = ['', '']
    description = 'This is a test description'
    arg_name = 'arg'
    type_name = 'str'
    is_optional = False
    default = 'None'
    test = DocstringParam(arguments, description, arg_name, type_name, is_optional, default)
    assert test.args == arguments
    assert test.description == description
    assert test.arg_name == arg_name
    assert test.type_name == type_name
    assert test.is_optional == is_optional
    assert test.default == default


# Generated at 2022-06-23 17:04:04.308752
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        constructor = ParseError('MyError')
    except ParseError as e:
        print(e)


# Generated at 2022-06-23 17:04:08.012647
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = Docstring()
    assert docstring.deprecation is None
    docstring.meta.append(DocstringDeprecated(args = [], description = "foo"))
    assert not isinstance(docstring.meta[0], DocstringDeprecated)
    assert isinstance(docstring.deprecation, DocstringDeprecated)
    assert docstring.deprecation.description == "foo"

# Generated at 2022-06-23 17:04:13.990635
# Unit test for constructor of class ParseError
def test_ParseError():
    ParseError("something is broken")
test_ParseError()



# Generated at 2022-06-23 17:04:16.325977
# Unit test for constructor of class ParseError
def test_ParseError():
    """Docstring test."""
    try:
        raise ParseError
    except ParseError:
        pass



# Generated at 2022-06-23 17:04:19.908456
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test function for constructor of class ParseError"""
    err = ParseError("An error occured while parsing")
    print(err)
    assert str(err) == "An error occured while parsing"
    # Unit test for constructor of class DocstringParam


# Generated at 2022-06-23 17:04:31.561527
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring1 = DocstringReturns([], None, None, False)
    assert docstring1.description == None
    assert docstring1.type_name == None
    assert docstring1.is_generator == False
    assert docstring1.return_name == None
    docstring2 = DocstringReturns([], None, None, True)
    assert docstring2.description == None
    assert docstring2.type_name == None
    assert docstring2.is_generator == True
    assert docstring2.return_name == None
    docstring3 = DocstringReturns([], None, "x", False)
    assert docstring3.description == None
    assert docstring3.type_name == "x"
    assert docstring3.is_generator == False
    assert docstring3.return_name == None
    docstring4

# Generated at 2022-06-23 17:04:34.160370
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError
    except Exception as e:
        print('Test case for constructor of ParseError passed')
        print(e.args)


# Generated at 2022-06-23 17:04:39.323597
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    e = DocstringRaises(args=["raises ValueError: if something happens"],
                    description="something happens",
                    type_name="ValueError")
    assert type(e.args) == list
    assert type(e.description) == str
    assert type(e.type_name) == str


# Generated at 2022-06-23 17:04:43.615601
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == []
    assert docstring.deprecation == []



# Generated at 2022-06-23 17:04:47.113397
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-23 17:04:48.536607
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta("args", "description")
    assert meta.args == "args"
    assert meta.description == "description"


# Generated at 2022-06-23 17:04:50.167636
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    item = DocstringDeprecated(["deprecated"], "description", "version")
    assert item.description == "description"
    assert item.version == "version"
    assert item.args == ["deprecated"]


# Generated at 2022-06-23 17:04:51.951727
# Unit test for constructor of class ParseError
def test_ParseError():
    parse_error = ParseError("Test Exception")

# Generated at 2022-06-23 17:04:55.862646
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta_test = DocstringMeta(["arg"], "desc")
    assert meta_test.args[0] == "arg"
    assert meta_test.description == "desc"


# Generated at 2022-06-23 17:05:00.632816
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], '').args == []
    assert DocstringMeta([], '').description == ''
    assert DocstringMeta(['a', 'b'], 'a').args == ['a', 'b']
    assert DocstringMeta(['a', 'b'], 'a').description == 'a'

# Unit tests for constructor of class DocstringParam

# Generated at 2022-06-23 17:05:04.290408
# Unit test for constructor of class Docstring
def test_Docstring():
    example = Docstring()

    assert example.short_description is None
    assert example.long_description is None
    assert example.blank_after_short_description is False
    assert example.blank_after_long_description is False
    assert example.meta == []


# Generated at 2022-06-23 17:05:07.270926
# Unit test for constructor of class Docstring
def test_Docstring():
    test_object = Docstring()
    assert test_object.short_description is None
    assert test_object.long_description is None
    assert test_object.blank_after_short_description is False
    assert test_object.blank_after_long_description is False
    assert test_object.meta == []


# Generated at 2022-06-23 17:05:09.033088
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(None, None, None, None)
    DocstringReturns(None, None, None, None, None)

# Generated at 2022-06-23 17:05:13.339894
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-23 17:05:17.648047
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    item = DocstringReturns([], None, None, False, None)

    print(item.args)
    print(item.description)
    print(item.type_name)
    print(item.is_generator)
    print(item.return_name)



# Generated at 2022-06-23 17:05:19.899453
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """
    Initialize class DocstringParam and check if it is not None
    """
    docParam = DocstringParam(None, None, None, None, None, None)

    # If the object is not None, then the test has passed
    assert docParam is not None


# Generated at 2022-06-23 17:05:24.544371
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of class DocstringMeta."""
    new_obj = DocstringMeta(['parameter'], 'A parameter used in function')
    assert 'parameter' in new_obj.args
    assert 'A parameter used in function' in new_obj.description


# Generated at 2022-06-23 17:05:32.818622
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert not docstring.blank_after_short_description
    assert not docstring.blank_after_long_description
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None
    print("test_Docstring: passed")

if __name__ == '__main__':
    test_Docstring()