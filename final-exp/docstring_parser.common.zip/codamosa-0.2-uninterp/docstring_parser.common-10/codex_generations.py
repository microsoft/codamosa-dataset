

# Generated at 2022-06-17 18:06:18.618428
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:06:22.586477
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This is deprecated'
    version = '1.0'
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version


# Generated at 2022-06-17 18:06:26.544596
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:06:34.372374
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:06:38.128969
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-17 18:06:40.206276
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        assert str(e) == "Error"


# Generated at 2022-06-17 18:06:52.290251
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return"]
    description = "Returns the value of the argument"
    type_name = "int"
    is_generator = False
    return_name = "value"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:01.758188
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:03.853860
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:07:15.433464
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Test 1
    args = ["returns", "type_name", "is_generator", "return_name"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    test_1 = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_1.args == ["returns", "type_name", "is_generator", "return_name"]
    assert test_1.description == "description"
    assert test_1.type_name == "type_name"
    assert test_1.is_generator == True
    assert test_1.return_name == "return_name"

    # Test 2

# Generated at 2022-06-17 18:07:25.923864
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:07:34.229088
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param"]
    description = "description"
    type_name = "int"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:39.287627
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-17 18:07:47.648522
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test DocstringReturns constructor."""
    d = DocstringReturns(["returns"], "description", "type_name", True)
    assert d.args == ["returns"]
    assert d.description == "description"
    assert d.type_name == "type_name"
    assert d.is_generator == True
    assert d.return_name == None


# Generated at 2022-06-17 18:07:55.960888
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:04.736652
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:08.412228
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This function is deprecated."
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:08:10.942154
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:08:20.142599
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'type'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:27.964034
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:36.919333
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "argument"]
    description = "description"
    d = DocstringMeta(args, description)
    assert d.args == args
    assert d.description == description


# Generated at 2022-06-17 18:08:40.430635
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:08:41.505501
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "returns description", "returns type", True)


# Generated at 2022-06-17 18:08:48.559046
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:08:51.475250
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    """Test constructor of class DocstringMeta."""
    args = ["param", "arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:08:55.161647
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    test = DocstringRaises(args, description, type_name)
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name


# Generated at 2022-06-17 18:08:57.494020
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "argument"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:09:02.225343
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-17 18:09:11.079085
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:09:21.609314
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:09:40.502872
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:09:47.357491
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:09:51.719809
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    d = DocstringDeprecated(["deprecated"], "description", "version")
    assert d.args == ["deprecated"]
    assert d.description == "description"
    assert d.version == "version"


# Generated at 2022-06-17 18:09:58.525443
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = 'if something happens'
    type_name = 'ValueError'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == ['raises', 'ValueError']
    assert docstringRaises.description == 'if something happens'
    assert docstringRaises.type_name == 'ValueError'


# Generated at 2022-06-17 18:10:05.206193
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:10:08.535178
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:10:10.788926
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass


# Generated at 2022-06-17 18:10:14.731825
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:10:17.884489
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == ['arg']
    assert docstringMeta.description == 'description'


# Generated at 2022-06-17 18:10:23.036411
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated", "since", "1.0"]
    description = "This function is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:10:55.538727
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:10:57.197004
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param"], "description", "arg", "type", True, "default")


# Generated at 2022-06-17 18:11:04.191333
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:11:05.992365
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "description", "type_name", False)


# Generated at 2022-06-17 18:11:08.242649
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        assert str(e) == "Error"


# Generated at 2022-06-17 18:11:12.456337
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:11:18.832421
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:11:31.036588
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default
    # Test 2
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
   

# Generated at 2022-06-17 18:11:36.155894
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-17 18:11:44.118085
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:12:47.396310
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:12:51.457306
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated", "since", "1.0"]
    description = "This function is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:12:53.236409
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test the constructor of class ParseError."""
    error = ParseError("error")
    assert error.args == ("error",)


# Generated at 2022-06-17 18:12:57.445644
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    test_DocstringRaises = DocstringRaises(args, description, type_name)
    assert test_DocstringRaises.args == args
    assert test_DocstringRaises.description == description
    assert test_DocstringRaises.type_name == type_name


# Generated at 2022-06-17 18:12:59.830620
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:13:02.009825
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:13:10.612352
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    test_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_DocstringReturns.args == args
    assert test_DocstringReturns.description == description
    assert test_DocstringReturns.type_name == type_name
    assert test_DocstringReturns.is_generator == is_generator
    assert test_DocstringReturns.return_name == return_name


# Generated at 2022-06-17 18:13:15.850036
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert dp.args == ["param"]
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == True
    assert dp.default == "default"


# Generated at 2022-06-17 18:13:18.941981
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:13:23.944557
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:14:32.483332
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:14:39.858023
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:14:44.475828
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:14:51.699535
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:14:53.582412
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:15:01.823547
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == ["returns"]
    assert docstring_returns.description == "This is a description"
    assert docstring_returns.type_name == "int"
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == "return"


# Generated at 2022-06-17 18:15:05.387332
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:15:15.612246
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:15:22.497199
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=["param"],
        description="description",
        arg_name="arg_name",
        type_name="type_name",
        is_optional=True,
        default="default",
    )
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:15:25.400725
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert e.args[0] == "Test"
