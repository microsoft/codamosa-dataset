

# Generated at 2022-06-17 18:06:26.618330
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=["param"],
        description="description",
        arg_name="arg_name",
        type_name="type_name",
        is_optional=True,
        default="default",
    )
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:06:28.942280
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass


# Generated at 2022-06-17 18:06:32.109585
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This function is deprecated"
    version = "1.0.0"
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version


# Generated at 2022-06-17 18:06:33.955056
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "", "1.0")


# Generated at 2022-06-17 18:06:37.682040
# Unit test for constructor of class Docstring
def test_Docstring():
    doc = Docstring()
    assert doc.short_description is None
    assert doc.long_description is None
    assert doc.blank_after_short_description is False
    assert doc.blank_after_long_description is False
    assert doc.meta == []


# Generated at 2022-06-17 18:06:44.289450
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args=['param'], description='description', arg_name='arg_name', type_name='type_name', is_optional=True, default='default')
    assert dp.args == ['param']
    assert dp.description == 'description'
    assert dp.arg_name == 'arg_name'
    assert dp.type_name == 'type_name'
    assert dp.is_optional == True
    assert dp.default == 'default'


# Generated at 2022-06-17 18:06:51.149569
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "int"
    is_optional = True
    default = "0"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:06:55.154548
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:07:00.984292
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None

# Generated at 2022-06-17 18:07:02.962974
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:07:11.464136
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:07:18.415242
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg']
    description = 'description'
    arg_name = 'arg'
    type_name = 'int'
    is_optional = True
    default = 'None'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:30.515256
# Unit test for constructor of class DocstringDeprecated

# Generated at 2022-06-17 18:07:32.562632
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:07:41.803748
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:48.855921
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:07:54.504778
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    a = DocstringParam(['param'], 'description', 'arg', 'type', 'is_optional', 'default')
    assert a.args == ['param']
    assert a.description == 'description'
    assert a.arg_name == 'arg'
    assert a.type_name == 'type'
    assert a.is_optional == 'is_optional'
    assert a.default == 'default'


# Generated at 2022-06-17 18:07:55.859186
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "description", "version")

# Generated at 2022-06-17 18:07:59.066071
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:08:08.013140
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "returns description", "returns type_name", False)
    DocstringReturns(["returns"], "returns description", "returns type_name", True)
    DocstringReturns(["returns"], "returns description", "returns type_name", False, "returns return_name")
    DocstringReturns(["returns"], "returns description", "returns type_name", True, "returns return_name")
    DocstringReturns(["returns"], None, "returns type_name", False)
    DocstringReturns(["returns"], None, "returns type_name", True)
    DocstringReturns(["returns"], None, "returns type_name", False, "returns return_name")

# Generated at 2022-06-17 18:08:16.974270
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    DocstringRaises(["raises"], "description", "type_name")


# Generated at 2022-06-17 18:08:21.156245
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:08:26.181790
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:08:33.408600
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == ["raises", "ValueError"]
    assert docstringRaises.description == "if something happens"
    assert docstringRaises.type_name == "ValueError"


# Generated at 2022-06-17 18:08:36.778292
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:08:40.607907
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:08:46.607869
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated'], 'This is deprecated', '1.0')
    assert docstring.args == ['deprecated']
    assert docstring.description == 'This is deprecated'
    assert docstring.version == '1.0'


# Generated at 2022-06-17 18:08:49.926849
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(['param'], 'description', 'arg_name', 'type_name', True, 'default')


# Generated at 2022-06-17 18:08:54.783695
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:08:56.244067
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:09:15.418563
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:09:18.163234
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:09:20.900596
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:09:25.383955
# Unit test for constructor of class Docstring
def test_Docstring():
    ds = Docstring()
    assert ds.short_description == None
    assert ds.long_description == None
    assert ds.blank_after_short_description == False
    assert ds.blank_after_long_description == False
    assert ds.meta == []


# Generated at 2022-06-17 18:09:32.725911
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:09:35.688722
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:42.026237
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(
        args=["returns"],
        description="The return value",
        type_name="int",
        is_generator=False,
        return_name="return_value",
    )
    assert docstring_returns.args == ["returns"]
    assert docstring_returns.description == "The return value"
    assert docstring_returns.type_name == "int"
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == "return_value"


# Generated at 2022-06-17 18:09:44.000404
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:09:53.452871
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:09:55.420623
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param"], "description", "arg", "type_name", True, "default")


# Generated at 2022-06-17 18:10:28.155652
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "", "", False)


# Generated at 2022-06-17 18:10:37.826940
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=["param"],
        description="description",
        arg_name="arg_name",
        type_name="type_name",
        is_optional=True,
        default="default",
    )
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:10:43.181720
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == ["raises", "ValueError"]
    assert docstring_raises.description == "if something happens"
    assert docstring_raises.type_name == "ValueError"


# Generated at 2022-06-17 18:10:49.489757
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:10:57.551953
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:11:03.092607
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-17 18:11:11.546760
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    test_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_DocstringReturns.args == args
    assert test_DocstringReturns.description == description
    assert test_DocstringReturns.type_name == type_name
    assert test_DocstringReturns.is_generator == is_generator
    assert test_DocstringReturns.return_name == return_name


# Generated at 2022-06-17 18:11:17.250212
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    test_args = ["param", "arg"]
    test_description = "description"
    test_docstring_meta = DocstringMeta(test_args, test_description)
    assert test_docstring_meta.args == test_args
    assert test_docstring_meta.description == test_description


# Generated at 2022-06-17 18:11:24.376150
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    # Test 1
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'type'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default
    # Test 2
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
   

# Generated at 2022-06-17 18:11:31.493210
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None



# Generated at 2022-06-17 18:12:38.710102
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:12:41.804742
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:12:43.523436
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:12:45.933408
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description").args == ["param"]
    assert DocstringMeta(["param"], "description").description == "description"


# Generated at 2022-06-17 18:12:53.450249
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-17 18:12:56.884062
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:13:05.326881
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.type_name == type_name
    assert docstring.is_generator == is_generator
    assert docstring.return_name == return_name


# Generated at 2022-06-17 18:13:07.306294
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:13:10.356786
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:13:14.359794
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:15:30.291305
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises']
    description = 'description'
    type_name = 'ValueError'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == ['raises']
    assert docstringRaises.description == 'description'
    assert docstringRaises.type_name == 'ValueError'


# Generated at 2022-06-17 18:15:35.969687
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    dp = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert dp.args == args
    assert dp.description == description
    assert dp.arg_name == arg_name
    assert dp.type_name == type_name
    assert dp.is_optional == is_optional
    assert dp.default == default


# Generated at 2022-06-17 18:15:41.320951
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:15:49.951688
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    param = DocstringParam(["param"], "description", "arg", "type", True, "default")
    assert param.args == ["param"]
    assert param.description == "description"
    assert param.arg_name == "arg"
    assert param.type_name == "type"
    assert param.is_optional == True
    assert param.default == "default"


# Generated at 2022-06-17 18:15:54.420637
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:15:56.616680
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:16:02.385882
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:16:09.116780
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:16:13.116874
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
