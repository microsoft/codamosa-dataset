

# Generated at 2022-06-17 18:06:22.161764
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-17 18:06:24.412619
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(['returns'], '', '', False)


# Generated at 2022-06-17 18:06:28.200199
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-17 18:06:32.513522
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:06:36.153722
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:06:39.629302
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    raises = DocstringRaises(args, description, type_name)
    assert raises.args == args
    assert raises.description == description
    assert raises.type_name == type_name


# Generated at 2022-06-17 18:06:48.805870
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:06:50.805916
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        assert str(e) == "Error"


# Generated at 2022-06-17 18:06:55.105465
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["param"], "description", "version")
    assert docstring_deprecated.args == ["param"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:07:03.088083
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_value"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:14.074902
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:07:15.931758
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['param'], 'description')
    assert docstring_meta.args == ['param']
    assert docstring_meta.description == 'description'


# Generated at 2022-06-17 18:07:21.588404
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:07:24.547102
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:07:28.171532
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(["deprecated"], "description", "version")
    assert a.args == ["deprecated"]
    assert a.description == "description"
    assert a.version == "version"


# Generated at 2022-06-17 18:07:31.802423
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:07:36.630877
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This function is deprecated'
    version = '1.0'
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version


# Generated at 2022-06-17 18:07:45.929481
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:49.938161
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError', 'if', 'something', 'happens']
    description = 'if something happens'
    type_name = 'ValueError'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == ['raises', 'ValueError', 'if', 'something', 'happens']
    assert docstringRaises.description == 'if something happens'
    assert docstringRaises.type_name == 'ValueError'


# Generated at 2022-06-17 18:07:54.469723
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:08:00.591148
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError:
        pass


# Generated at 2022-06-17 18:08:01.888706
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['param'], 'description')


# Generated at 2022-06-17 18:08:06.145961
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:08:08.923418
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:08:10.872279
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description").args == ["param"]
    assert DocstringMeta(["param"], "description").description == "description"


# Generated at 2022-06-17 18:08:13.676899
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This function is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:08:19.433057
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    raises = DocstringRaises(args, description, type_name)
    assert raises.args == args
    assert raises.description == description
    assert raises.type_name == type_name


# Generated at 2022-06-17 18:08:27.460616
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:32.876214
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:08:36.652061
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:08:54.646302
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'type'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:56.465692
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:09:08.607454
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    # Test 1
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    test_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_DocstringReturns.args == args
    assert test_DocstringReturns.description == description
    assert test_DocstringReturns.type_name == type_name
    assert test_DocstringReturns.is_generator == is_generator
    assert test_DocstringReturns.return_name == return_name
    # Test 2
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]

# Generated at 2022-06-17 18:09:10.895314
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param"], "description", "arg", "type_name", True, "default")


# Generated at 2022-06-17 18:09:16.968927
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:09:20.801000
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "argument"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:09:25.295220
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:09:28.079378
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:09:32.180647
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:09:36.398042
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = "description"
    dm = DocstringMeta(args, description)
    assert dm.args == args
    assert dm.description == description


# Generated at 2022-06-17 18:09:45.803062
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "", "") is not None


# Generated at 2022-06-17 18:09:52.363964
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:55.570751
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    dm = DocstringMeta(args, description)
    assert dm.args == args
    assert dm.description == description


# Generated at 2022-06-17 18:10:01.953876
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:10:13.478287
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "x"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:10:17.671228
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:10:21.944604
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    docstring_raises = DocstringRaises(["raises"], "description", "type_name")
    assert docstring_raises.args == ["raises"]
    assert docstring_raises.description == "description"
    assert docstring_raises.type_name == "type_name"


# Generated at 2022-06-17 18:10:25.749769
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-17 18:10:30.349568
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:10:37.149639
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['returns', 'return', 'returns']
    description = 'This is a description'
    type_name = 'int'
    is_generator = False
    return_name = 'x'
    test = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name
    assert test.is_generator == is_generator
    assert test.return_name == return_name


# Generated at 2022-06-17 18:10:59.496443
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-17 18:11:03.837888
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:11:09.237927
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:11:11.963379
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:11:15.839144
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:11:20.501507
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:11:22.932819
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    meta = DocstringMeta(["param"], "description")
    assert meta.args == ["param"]
    assert meta.description == "description"


# Generated at 2022-06-17 18:11:31.874574
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:34.787330
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:11:37.005102
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    error = ParseError("test")
    assert error.args == ("test",)


# Generated at 2022-06-17 18:12:14.705524
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:12:17.123380
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    d = DocstringMeta(args, description)
    assert d.args == args
    assert d.description == description


# Generated at 2022-06-17 18:12:21.594253
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:12:28.776654
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    dp = DocstringParam(args=["param"], description="description", arg_name="arg_name", type_name="type_name", is_optional=True, default="default")
    assert dp.args == ["param"]
    assert dp.description == "description"
    assert dp.arg_name == "arg_name"
    assert dp.type_name == "type_name"
    assert dp.is_optional == True
    assert dp.default == "default"


# Generated at 2022-06-17 18:12:32.954275
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:12:34.192777
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "returns description", "returns type", False)

# Generated at 2022-06-17 18:12:35.884227
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "description", "type_name", True)


# Generated at 2022-06-17 18:12:39.968949
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This is a description'
    version = '1.0'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:12:52.952667
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:12:57.230285
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:14:06.908152
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    a = DocstringDeprecated(['param'], 'description', 'version')
    assert a.args == ['param']
    assert a.description == 'description'
    assert a.version == 'version'


# Generated at 2022-06-17 18:14:12.591992
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns is None
    assert d.deprecation is None


# Generated at 2022-06-17 18:14:19.031198
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:14:22.854110
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:14:24.565676
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    DocstringMeta(["param"], "description")


# Generated at 2022-06-17 18:14:28.208940
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(['param', 'arg'], 'description')
    assert docstring_meta.args == ['param', 'arg']
    assert docstring_meta.description == 'description'


# Generated at 2022-06-17 18:14:30.001287
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError:
        pass


# Generated at 2022-06-17 18:14:33.551858
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["return", "returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "x"
    test_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_returns.args == args
    assert test_returns.description == description
    assert test_returns.type_name == type_name
    assert test_returns.is_generator == is_generator
    assert test_returns.return_name == return_name

# Generated at 2022-06-17 18:14:35.293765
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:14:36.461741
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(['param'], 'description')
    assert d.args == ['param']
    assert d.description == 'description'
