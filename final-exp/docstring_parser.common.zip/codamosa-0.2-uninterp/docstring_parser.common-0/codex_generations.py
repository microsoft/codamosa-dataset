

# Generated at 2022-06-17 18:06:18.946089
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = 'return_name'
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:06:26.884634
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "returns a string"
    type_name = "str"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:06:31.654914
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = 'if something happens'
    type_name = 'ValueError'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:06:37.546990
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:06:40.318234
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError('test')
    except ParseError as e:
        assert e.args[0] == 'test'


# Generated at 2022-06-17 18:06:48.069049
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:06:52.293718
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:06:59.507726
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:07:02.669560
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:07:08.407737
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param"]
    description = "description"
    type_name = "type_name"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:07:19.503190
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Unit test for constructor of class DocstringParam."""
    args = ["param", "parameter", "arg", "argument"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:29.219539
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:32.389986
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:07:36.886251
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:07:42.416899
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    """Unit test for constructor of class DocstringDeprecated."""
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    version = "version"
    docstring = DocstringDeprecated(args, description, version)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.version == version


# Generated at 2022-06-17 18:07:46.589827
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-17 18:07:48.159756
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:07:57.326798
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:08:05.817253
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test the constructor of class DocstringReturns."""
    args = ["param", "arg"]
    description = "description"
    type_name = "int"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:08:11.776981
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:08:24.224906
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:08:26.180779
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:08:31.572368
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a test"
    type_name = "int"
    is_generator = False
    return_name = "test"
    test_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_DocstringReturns.args == args
    assert test_DocstringReturns.description == description
    assert test_DocstringReturns.type_name == type_name
    assert test_DocstringReturns.is_generator == is_generator
    assert test_DocstringReturns.return_name == return_name


# Generated at 2022-06-17 18:08:33.673128
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:08:40.184733
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:08:50.075586
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "description", "type_name", False, "return_name")
    assert docstring_returns.args == ["returns"]
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == "return_name"


# Generated at 2022-06-17 18:08:54.831365
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:08:56.858420
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:00.527970
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:09:07.672371
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "description", "type_name", True)
    assert docstring_returns.args == ["returns"]
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name == None


# Generated at 2022-06-17 18:09:21.309110
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:23.212757
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "This function is deprecated", "1.0")


# Generated at 2022-06-17 18:09:27.735322
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["param"], "description", "version")
    assert docstring_deprecated.args == ["param"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:09:30.399563
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:09:39.242129
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name



# Generated at 2022-06-17 18:09:42.217667
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:48.342594
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:09:53.554557
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError', 'if', 'something', 'happens']
    description = 'if something happens'
    type_name = 'ValueError'
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:59.805227
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:10:04.477764
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-17 18:10:21.089707
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description")


# Generated at 2022-06-17 18:10:26.989811
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:10:29.753372
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:10:38.756190
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "this is a description"
    type_name = "str"
    is_generator = True
    return_name = "return_name"
    test_docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_docstring_returns.args == args
    assert test_docstring_returns.description == description
    assert test_docstring_returns.type_name == type_name
    assert test_docstring_returns.is_generator == is_generator
    assert test_docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:10:41.333780
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:10:46.677305
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-17 18:10:55.238207
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(['param'], 'description', 'arg_name', 'type_name', 'is_optional', 'default')
    assert docstring_param.args == ['param']
    assert docstring_param.description == 'description'
    assert docstring_param.arg_name == 'arg_name'
    assert docstring_param.type_name == 'type_name'
    assert docstring_param.is_optional == 'is_optional'
    assert docstring_param.default == 'default'


# Generated at 2022-06-17 18:11:00.509716
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated"]
    description = "This is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:11:06.602606
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns([], None, None, False).args == []
    assert DocstringReturns([], None, None, False).description == None
    assert DocstringReturns([], None, None, False).type_name == None
    assert DocstringReturns([], None, None, False).is_generator == False
    assert DocstringReturns([], None, None, False).return_name == None


# Generated at 2022-06-17 18:11:10.181660
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-17 18:11:44.112704
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args == ("test",)


# Generated at 2022-06-17 18:11:47.529700
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    assert DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")


# Generated at 2022-06-17 18:11:50.416213
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:11:54.344649
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated'], 'This is deprecated', '1.0')
    assert docstring.args == ['deprecated']
    assert docstring.description == 'This is deprecated'
    assert docstring.version == '1.0'


# Generated at 2022-06-17 18:11:59.029048
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-17 18:12:01.357912
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:12:08.981324
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "type_name"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:12:13.925630
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring.args == ['deprecated']
    assert docstring.description == 'description'
    assert docstring.version == 'version'


# Generated at 2022-06-17 18:12:20.800979
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg']
    description = 'description'
    type_name = 'type_name'
    is_generator = False
    return_name = 'return_name'
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == ['arg']
    assert docstring_returns.description == 'description'
    assert docstring_returns.type_name == 'type_name'
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == 'return_name'


# Generated at 2022-06-17 18:12:29.294665
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    test = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert test.args == args
    assert test.description == description
    assert test.arg_name == arg_name
    assert test.type_name == type_name
    assert test.is_optional == is_optional
    assert test.default == default


# Generated at 2022-06-17 18:13:33.396751
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    # Test 1
    args = ['param', 'arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description

    # Test 2
    args = ['param', 'arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:13:37.777520
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []


# Generated at 2022-06-17 18:13:39.163591
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(['param'], 'description')


# Generated at 2022-06-17 18:13:46.023472
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:13:55.971941
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return", "returns"]
    description = "description"
    type_name = "type_name"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:14:04.538042
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = 'return_name'

    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:14:11.248118
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:14:18.005354
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:14:21.425647
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "argument"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:14:30.483699
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name
