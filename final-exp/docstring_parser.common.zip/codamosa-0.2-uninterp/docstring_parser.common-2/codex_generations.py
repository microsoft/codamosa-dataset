

# Generated at 2022-06-17 18:06:18.197312
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:06:23.966630
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:06:25.962304
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")


# Generated at 2022-06-17 18:06:33.552112
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a test"
    type_name = "int"
    is_generator = False
    return_name = "test"
    test_DocstringReturns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_DocstringReturns.args == args
    assert test_DocstringReturns.description == description
    assert test_DocstringReturns.type_name == type_name
    assert test_DocstringReturns.is_generator == is_generator
    assert test_DocstringReturns.return_name == return_name


# Generated at 2022-06-17 18:06:35.790791
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:06:39.629109
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ["deprecated", "version"]
    description = "This function is deprecated"
    version = "1.0"
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:06:52.956768
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test the constructor of class DocstringParam."""
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:02.155076
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "returns a value"
    type_name = "int"
    is_generator = False
    return_name = "value"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:06.196345
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:07:12.991568
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:07:24.071264
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['raises', 'ValueError']
    description = 'if something happens'
    type_name = 'ValueError'
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == ['raises', 'ValueError']
    assert docstring_raises.description == 'if something happens'
    assert docstring_raises.type_name == 'ValueError'


# Generated at 2022-06-17 18:07:30.557521
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description == None
    assert d.long_description == None
    assert d.blank_after_short_description == False
    assert d.blank_after_long_description == False
    assert d.meta == []
    assert d.params == []
    assert d.raises == []
    assert d.returns == None
    assert d.deprecation == None


# Generated at 2022-06-17 18:07:35.081486
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:07:41.476755
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:07:43.626664
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "description", "version")


# Generated at 2022-06-17 18:07:46.881818
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    d = DocstringMeta(["param"], "description")
    assert d.args == ["param"]
    assert d.description == "description"


# Generated at 2022-06-17 18:07:55.474928
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:08:02.278807
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:08:05.095893
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "description"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:08:08.447056
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    test = DocstringRaises(args, description, type_name)
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name


# Generated at 2022-06-17 18:08:21.105588
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:08:25.413101
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This is deprecated'
    version = '0.1'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:08:28.331615
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:08:32.048209
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:08:35.830506
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:08:39.183678
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    test = DocstringRaises(['raises', 'ValueError'], 'if something happens', 'ValueError')
    assert test.args == ['raises', 'ValueError']
    assert test.description == 'if something happens'
    assert test.type_name == 'ValueError'


# Generated at 2022-06-17 18:08:42.073442
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:08:52.257258
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert returns.args == args
    assert returns.description == description
    assert returns.type_name == type_name
    assert returns.is_generator == is_generator
    assert returns.return_name == return_name


# Generated at 2022-06-17 18:08:58.125749
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return", "returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "x"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:09:02.060852
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    docstring_meta = DocstringMeta(["param"], "description")
    assert docstring_meta.args == ["param"]
    assert docstring_meta.description == "description"


# Generated at 2022-06-17 18:09:20.850567
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'This is deprecated', '1.0')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'This is deprecated'
    assert docstring_deprecated.version == '1.0'


# Generated at 2022-06-17 18:09:26.053680
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    test_object = DocstringRaises(args, description, type_name)
    assert test_object.args == args
    assert test_object.description == description
    assert test_object.type_name == type_name


# Generated at 2022-06-17 18:09:29.782951
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:09:33.188502
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:09:39.548568
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["return", "returns"], "description", "type_name", True, "return_name")
    assert docstring_returns.args == ["return", "returns"]
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name == "return_name"


# Generated at 2022-06-17 18:09:48.577429
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:09:52.785517
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:09:57.906315
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:10:04.417969
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "value"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:10:09.588774
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'argument']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:10:39.023446
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:10:41.666599
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:10:47.059691
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "argument"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:10:56.804679
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:03.381575
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    assert DocstringRaises(args, description, type_name).args == args
    assert DocstringRaises(args, description, type_name).description == description
    assert DocstringRaises(args, description, type_name).type_name == type_name


# Generated at 2022-06-17 18:11:11.133962
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns", "return"]
    description = "This is a description"
    type_name = "int"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:13.146289
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    assert DocstringReturns(["returns"], "", "", False)


# Generated at 2022-06-17 18:11:15.041094
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    DocstringDeprecated(["deprecated"], "description", "version")


# Generated at 2022-06-17 18:11:22.923776
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Unit test for constructor of class DocstringReturns."""
    args = ["param", "arg", "argument"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:34.001811
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(
        args=["param", "parameter", "arg", "argument", "attribute", "key", "keyword"],
        description="description",
        arg_name="arg_name",
        type_name="type_name",
        is_optional="is_optional",
        default="default",
    )
    assert docstring_param.args == [
        "param",
        "parameter",
        "arg",
        "argument",
        "attribute",
        "key",
        "keyword",
    ]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == "is_optional"
   

# Generated at 2022-06-17 18:12:35.669557
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param', 'arg', 'description']
    description = 'description'
    arg_name = 'arg'
    type_name = 'type'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:12:37.683578
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:12:41.805551
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg']
    description = 'description'
    type_name = 'type_name'
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:12:51.692936
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:12:55.649263
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:12:59.807800
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None

# Generated at 2022-06-17 18:13:05.240794
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "description", "type_name", False)
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == False
    assert docstring_returns.return_name == None


# Generated at 2022-06-17 18:13:09.334116
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    test = DocstringRaises(args, description, type_name)
    assert test.args == args
    assert test.description == description
    assert test.type_name == type_name


# Generated at 2022-06-17 18:13:10.208977
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta([], "")


# Generated at 2022-06-17 18:13:17.660731
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:15:15.950685
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:15:18.889744
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:15:23.449503
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "description", "type_name", True)
    assert docstring_returns.args == ["returns"]
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name == None


# Generated at 2022-06-17 18:15:28.675292
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:15:30.645847
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Error")
    except ParseError as e:
        assert str(e) == "Error"


# Generated at 2022-06-17 18:15:31.887918
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    assert DocstringMeta(["param"], "description")


# Generated at 2022-06-17 18:15:41.782870
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["args"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:15:50.893190
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:15:54.921664
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:15:56.888994
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["param"], "description")
    assert dm.args == ["param"]
    assert dm.description == "description"
