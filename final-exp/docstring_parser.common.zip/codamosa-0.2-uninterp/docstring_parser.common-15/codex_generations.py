

# Generated at 2022-06-17 18:06:19.208574
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:06:27.815960
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ['param']
    description = 'description'
    arg_name = 'arg'
    type_name = 'type'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:06:34.795423
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:06:35.965640
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "This is deprecated", "1.0")


# Generated at 2022-06-17 18:06:38.128862
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    dm = DocstringMeta(["param"], "description")
    assert dm.args == ["param"]
    assert dm.description == "description"


# Generated at 2022-06-17 18:06:41.667960
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:06:45.977465
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:06:49.260164
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    docstringmeta = DocstringMeta(args, description)
    assert docstringmeta.args == args
    assert docstringmeta.description == description


# Generated at 2022-06-17 18:06:58.170817
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param"]
    description = "description"
    arg_name = "arg_name"
    type_name = "type_name"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:03.459704
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    docstring_returns = DocstringReturns(["returns"], "description", "type_name", True)
    assert docstring_returns.args == ["returns"]
    assert docstring_returns.description == "description"
    assert docstring_returns.type_name == "type_name"
    assert docstring_returns.is_generator == True
    assert docstring_returns.return_name == None


# Generated at 2022-06-17 18:07:14.189162
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['param', 'parameter', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = 'description'
    type_name = 'type_name'
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:07:19.164219
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "description"
    type_name = "type_name"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:24.394907
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:07:33.373266
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:07:42.381438
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "str"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:07:48.896777
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['a', 'b', 'c']
    description = 'This is a description'
    type_name = 'int'
    is_generator = True
    return_name = 'return_name'
    test_return = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert test_return.args == args
    assert test_return.description == description
    assert test_return.type_name == type_name
    assert test_return.is_generator == is_generator
    assert test_return.return_name == return_name


# Generated at 2022-06-17 18:07:55.859025
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:08:01.953158
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == ['arg1', 'arg2']
    assert docstringRaises.description == 'description'
    assert docstringRaises.type_name == 'type_name'


# Generated at 2022-06-17 18:08:08.558976
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = 'return_name'
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:08:11.684279
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:08:31.628876
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    # Test case 1
    args = ['deprecated']
    description = 'This function is deprecated'
    version = '1.0'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'This function is deprecated'
    assert docstring_deprecated.version == '1.0'
    # Test case 2
    args = ['deprecated']
    description = 'This function is deprecated'
    version = None
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'This function is deprecated'
    assert docstring_deprecated.version == None
    # Test case 3
   

# Generated at 2022-06-17 18:08:34.783080
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:08:36.045763
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    assert DocstringDeprecated(["deprecated"], "", "")


# Generated at 2022-06-17 18:08:38.168782
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:08:45.403625
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    docstring_param = DocstringParam(["param"], "description", "arg_name", "type_name", True, "default")
    assert docstring_param.args == ["param"]
    assert docstring_param.description == "description"
    assert docstring_param.arg_name == "arg_name"
    assert docstring_param.type_name == "type_name"
    assert docstring_param.is_optional == True
    assert docstring_param.default == "default"


# Generated at 2022-06-17 18:08:50.445539
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:08:57.377217
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    args = ["param", "arg", "description"]
    description = "description"
    arg_name = "arg"
    type_name = "type"
    is_optional = True
    default = "default"
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:09:02.119982
# Unit test for constructor of class Docstring
def test_Docstring():
    d = Docstring()
    assert d.short_description is None
    assert d.long_description is None
    assert d.blank_after_short_description is False
    assert d.blank_after_long_description is False
    assert d.meta == []


# Generated at 2022-06-17 18:09:07.959196
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:09:09.778221
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "description", "type_name", True)


# Generated at 2022-06-17 18:09:31.620277
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = False
    return_name = 'return_name'
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:09:35.691855
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:09:38.754547
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    doc = DocstringDeprecated(["deprecated"], "This is deprecated", "1.0")
    assert doc.args == ["deprecated"]
    assert doc.description == "This is deprecated"
    assert doc.version == "1.0"


# Generated at 2022-06-17 18:09:40.773603
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring.args == ['deprecated']
    assert docstring.description == 'description'
    assert docstring.version == 'version'


# Generated at 2022-06-17 18:09:48.719144
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:09:51.581343
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:09:55.226273
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['arg']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:09:58.252641
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert str(e) == "test"


# Generated at 2022-06-17 18:10:02.267527
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    docstring = DocstringRaises(args, description, type_name)
    assert docstring.args == args
    assert docstring.description == description
    assert docstring.type_name == type_name


# Generated at 2022-06-17 18:10:07.755585
# Unit test for constructor of class ParseError
def test_ParseError():
    """Test constructor of class ParseError."""
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert e.args[0] == "Test"


# Generated at 2022-06-17 18:10:43.940656
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns."""
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = 'return_name'
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:10:53.443451
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:10:57.957169
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    args = ['deprecated']
    description = 'This function is deprecated'
    version = '1.0'
    docstring_deprecated = DocstringDeprecated(args, description, version)
    assert docstring_deprecated.args == args
    assert docstring_deprecated.description == description
    assert docstring_deprecated.version == version


# Generated at 2022-06-17 18:11:08.091154
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    """Test constructor of class DocstringReturns."""
    args = ["returns", "return"]
    description = "Test description"
    type_name = "int"
    is_generator = False
    return_name = "test"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:11.420831
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []


# Generated at 2022-06-17 18:11:16.430479
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring.args == ["deprecated"]
    assert docstring.description == "description"
    assert docstring.version == "version"


# Generated at 2022-06-17 18:11:19.702254
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ["param", "arg"]
    description = "description"
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:11:29.553661
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ['arg1', 'arg2']
    description = 'description'
    type_name = 'type_name'
    is_generator = True
    return_name = 'return_name'
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:36.673497
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["returns"]
    description = "This is a description"
    type_name = "str"
    is_generator = False
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:11:42.757638
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns == None
    assert docstring.deprecation == None


# Generated at 2022-06-17 18:12:41.117109
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("Test")
    except ParseError as e:
        assert str(e) == "Test"


# Generated at 2022-06-17 18:12:47.668288
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(['deprecated'], 'description', 'version')
    assert docstring_deprecated.args == ['deprecated']
    assert docstring_deprecated.description == 'description'
    assert docstring_deprecated.version == 'version'


# Generated at 2022-06-17 18:12:53.948364
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    args = ["arg1", "arg2"]
    description = "description"
    type_name = "type_name"
    is_generator = True
    return_name = "return_name"
    docstring_returns = DocstringReturns(args, description, type_name, is_generator, return_name)
    assert docstring_returns.args == args
    assert docstring_returns.description == description
    assert docstring_returns.type_name == type_name
    assert docstring_returns.is_generator == is_generator
    assert docstring_returns.return_name == return_name


# Generated at 2022-06-17 18:12:56.912988
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:13:01.359812
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:13:07.602822
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    docstring_raises = DocstringRaises(args, description, type_name)
    assert docstring_raises.args == args
    assert docstring_raises.description == description
    assert docstring_raises.type_name == type_name


# Generated at 2022-06-17 18:13:10.870653
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'argument', 'attribute', 'key', 'keyword']
    description = "description"
    docstringMeta = DocstringMeta(args, description)
    assert docstringMeta.args == args
    assert docstringMeta.description == description


# Generated at 2022-06-17 18:13:12.521664
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    a = DocstringMeta(["param"], "description")
    assert a.args == ["param"]
    assert a.description == "description"


# Generated at 2022-06-17 18:13:16.323862
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:13:20.734811
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    assert DocstringRaises(args, description, type_name)


# Generated at 2022-06-17 18:14:30.051753
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description is None
    assert docstring.long_description is None
    assert docstring.blank_after_short_description is False
    assert docstring.blank_after_long_description is False
    assert docstring.meta == []
    assert docstring.params == []
    assert docstring.raises == []
    assert docstring.returns is None
    assert docstring.deprecation is None


# Generated at 2022-06-17 18:14:32.914007
# Unit test for constructor of class ParseError
def test_ParseError():
    try:
        raise ParseError("test")
    except ParseError as e:
        assert e.args[0] == "test"


# Generated at 2022-06-17 18:14:36.805150
# Unit test for constructor of class Docstring
def test_Docstring():
    docstring = Docstring()
    assert docstring.short_description == None
    assert docstring.long_description == None
    assert docstring.blank_after_short_description == False
    assert docstring.blank_after_long_description == False
    assert docstring.meta == []


# Generated at 2022-06-17 18:14:40.507753
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:14:48.919594
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["raises", "ValueError"]
    description = "if something happens"
    type_name = "ValueError"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name


# Generated at 2022-06-17 18:14:53.157864
# Unit test for constructor of class DocstringMeta
def test_DocstringMeta():
    args = ['param', 'arg', 'argument']
    description = 'description'
    docstring_meta = DocstringMeta(args, description)
    assert docstring_meta.args == args
    assert docstring_meta.description == description


# Generated at 2022-06-17 18:15:02.077718
# Unit test for constructor of class DocstringParam
def test_DocstringParam():
    """Test constructor of class DocstringParam."""
    args = ['param']
    description = 'description'
    arg_name = 'arg_name'
    type_name = 'type_name'
    is_optional = True
    default = 'default'
    docstring_param = DocstringParam(args, description, arg_name, type_name, is_optional, default)
    assert docstring_param.args == args
    assert docstring_param.description == description
    assert docstring_param.arg_name == arg_name
    assert docstring_param.type_name == type_name
    assert docstring_param.is_optional == is_optional
    assert docstring_param.default == default


# Generated at 2022-06-17 18:15:05.308454
# Unit test for constructor of class DocstringDeprecated
def test_DocstringDeprecated():
    docstring_deprecated = DocstringDeprecated(["deprecated"], "description", "version")
    assert docstring_deprecated.args == ["deprecated"]
    assert docstring_deprecated.description == "description"
    assert docstring_deprecated.version == "version"


# Generated at 2022-06-17 18:15:08.168152
# Unit test for constructor of class DocstringReturns
def test_DocstringReturns():
    DocstringReturns(["returns"], "returns a value", "int", False, "return_name")


# Generated at 2022-06-17 18:15:14.349034
# Unit test for constructor of class DocstringRaises
def test_DocstringRaises():
    args = ["param", "parameter", "arg", "argument", "attribute", "key", "keyword"]
    description = "description"
    type_name = "type_name"
    docstringRaises = DocstringRaises(args, description, type_name)
    assert docstringRaises.args == args
    assert docstringRaises.description == description
    assert docstringRaises.type_name == type_name
