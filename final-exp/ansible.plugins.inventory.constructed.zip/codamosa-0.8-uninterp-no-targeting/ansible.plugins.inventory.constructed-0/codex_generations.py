

# Generated at 2022-06-21 05:01:25.259523
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.playbook.play_context import PlayContext
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader

    m = inventory_loader.get('constructed')
    
    loader = DataLoader()
    inventory = PlaybookInventory(loader, m, '../../../test/validate/')
    inventory.subset('all')
    
    play_context = PlayContext()
    play_context.inventory = inventory
    play_context.remote_addr = None
    play_context.become = False
    play_context.become_method = 'sudo'
    play_context.become_user = 'root'

# Generated at 2022-06-21 05:01:36.346821
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import sys
    import ansible.parsing.dataloader
    from ansible.parsing.data import DataLoader
    from ansible.inventory import Inventory
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six.moves import StringIO

    # setup
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list='tests/inventory')
    group = Group('group1')
    group.vars = { "var1": 10, "var2": 5 }

# Generated at 2022-06-21 05:01:39.204870
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file('inventory.config')
    assert not InventoryModule().verify_file('inventory.jar')

# Generated at 2022-06-21 05:01:40.668865
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    print(im)

# Generated at 2022-06-21 05:01:48.091433
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import inventory_loader

    groups = ["all"]
    host = Host(name="localhost", groups=groups)
    host.vars = {'ansible_user': 'root', 'ansible_ssh_pass': AnsibleVaultEncryptedUnicode('fakepass')}

    InventoryModule.get_vars_from_inventory_sources = lambda self, loader, sources, groups, stage: {'foo_var': 'bar_val'}

    inv_mod = inventory_loader.get('constructed', class_only=True)(datastructure={'use_vars_plugins': True})

# Generated at 2022-06-21 05:01:56.475338
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_module = InventoryModule()
    path = "/tmp/path/to/file.config"
    assert inv_module.verify_file(path) == True
    path = "/tmp/path/to/file.ini"
    assert inv_module.verify_file(path) == False
    path = "/tmp/path/to/file.yml"
    assert inv_module.verify_file(path) == True
    path = "/tmp/path/to/file.yaml"
    assert inv_module.verify_file(path) == True

# Generated at 2022-06-21 05:02:02.983932
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    assert plugin.verify_file('./test/unit/plugins/inventory/config/const_inv.config')
    assert not plugin.verify_file('const_inv.notconfig')
    assert plugin.verify_file('const_inv.yaml')
    assert plugin.verify_file('const_inv.yml')
    assert plugin.verify_file('const_inv.json')

# Generated at 2022-06-21 05:02:15.117920
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    import unittest
    import ansible.plugins.inventory.constructed

    class FakeFactCache(object):
        def __init__(self):
            self.storage = {'fact1.example.org': {'fact_1': 'value1'}, 'fact2.example.org': {'fact_2': 'value2'}}
        def __getitem__(self, key):
            return self.storage[key]

    class FakeHost(object):
        def __init__(self, name):
            self.name = name
            self.vars = {'test_var': 'test_var_value'}
        def get_name(self):
            return self.name
        def get_vars(self):
            return self.vars


# Generated at 2022-06-21 05:02:19.871781
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    inv_mod = InventoryModule()
    inv_mod.get_all_host_vars('dummy_host', 'dummy_loader', 'dummy_sources')

# Generated at 2022-06-21 05:02:22.655675
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import pytest
    module = InventoryModule()
    assert module is not None


# Generated at 2022-06-21 05:02:29.058629
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    print("execution finished without errors")

# Generated at 2022-06-21 05:02:36.549385
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    #import os
    #path = 'tests/inventory_plugins/vars_plugins/inventory_test_constructed.config'
    #path = os.path.join(os.path.dirname(__file__), path)
    #assert module.verify_file(path) == True
    host = 'test'
    path = 'inventory_test_constructed.config'
    loader = 'loader'
    inventory = 'inventory'
    module.parse(inventory, loader, path, cache=False)

# Generated at 2022-06-21 05:02:42.119882
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader

    def get_group_vars(group):
        return {group.name: 'group_vars'}

    def get_host_vars(host):
        return {host.name: 'host_vars'}

    loader = DataLoader()
    inv_module = InventoryModule()

    groups = Group(loader=loader, name='group', inventory=inv_module)
    host = Host(loader=loader, name='host', inventory=inv_module, groups=[groups])

    groups.vars = {'groupvars': 'yes'}
    host.vars = {'hostvars': 'yes'}


# Generated at 2022-06-21 05:02:49.862417
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import ansible.utils.vars as au_vars
    from ansible.inventory.host import Host

    inventory = {
        'all': {
            'vars': {'ansible_ssh_host': '127.0.0.1',
                     'ansible_ssh_port': 22,
                     'ansible_hostname': '127.0.0.1'},
            'hosts': {'127.0.0.1': {'vars': {'var1': 1,
                                             'ansible_ssh_host': '127.0.0.1',
                                             'ansible_ssh_port': 22,
                                             'ansible_hostname': '127.0.0.1'}}}
        }
    }
    plugin = InventoryModule()

# Generated at 2022-06-21 05:02:50.715146
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    pass

# Generated at 2022-06-21 05:02:55.235404
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' constructor test '''
    module = InventoryModule()
    assert module is not None
    print("constructor test passed.", module)


# Generated at 2022-06-21 05:03:08.096781
# Unit test for method verify_file of class InventoryModule

# Generated at 2022-06-21 05:03:15.151142
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory import Inventory
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import PluginLoader
    inventory = Inventory(loader=DataLoader(), variable_manager=VariableManager(), host_list=[])
    InventoryModule.host_vars(InventoryModule(), '127.0.0.1', DataLoader(), [], inventory, 'fake')


# Generated at 2022-06-21 05:03:21.631546
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.vars.manager import VariableManager

    import os

    # Create a mock host
    host_name = 'test_host'
    host = Host(name=host_name)

    # Create a mock group
    group_name = 'test_group'
    group = InventoryManager(loader=inventory_loader).get_group(group_name)
    group.add_host(host)

    host.set_variable('test_host_var', 'test_host_value')
    group.set_variable('test_group_var', 'test_group_value')

    # Create a mock inventory
    inventory = InventoryManager(loader=inventory_loader)
    inventory.add_

# Generated at 2022-06-21 05:03:25.722057
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # NOTE: This test uses an empty path since the contents of the file do not matter
    path = ""
    loader = None
    inventory = None
    im = InventoryModule()
    im.parse(inventory, loader, path)

# Generated at 2022-06-21 05:03:38.608645
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    # Test fixture setup
    test_object_1 = InventoryModule()

    # Test target
    test_target = test_object_1.get_all_host_vars

    # Test cases
    # This test case is not supported
    # Test setup
    # None

    # Test execution
    # N/A

    # Test cleanup
    # None

    # Verify call
    assert False


# Generated at 2022-06-21 05:03:48.776392
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory = InventoryModule()

    # 1. test if InventoryModule.host_groupvars() returns a empty dict if 'use_vars_plugins' is True
    inventory.set_option('use_vars_plugins', True)
    assert inventory.host_groupvars(host=None, loader=None, sources=['host_vars', 'group_vars']) == {}

    # 2. test if InventoryModule.host_groupvars() returns a empty dict if 'use_vars_plugins' is False
    inventory.set_option('use_vars_plugins', False)
    assert inventory.host_groupvars(host=None, loader=None, sources=None) == {}



# Generated at 2022-06-21 05:03:58.676485
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import ansible.plugins.inventory as base
    base.PLUGIN_PATH = 'Lib/ansible/plugins/inventory'
    import os
    import tempfile
    import shutil
    tmpdir = tempfile.mkdtemp()
    fname = os.path.join(tmpdir, 'constructed.yml')
    with open(fname, 'w') as f:
        f.write('plugin: constructed')
    expt = InventoryModule().verify_file(fname)
    shutil.rmtree(tmpdir)
    assert expt == True


# Generated at 2022-06-21 05:04:06.475146
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Set up
    from ansible.plugins.inventory.host_list import BaseFileInventoryModule
    import os
    import yaml
    import tempfile
    import shutil

    # Generate path to test file

# Generated at 2022-06-21 05:04:21.497430
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.plugins.loader import vars_loader
    from ansible.vars.manager import VariableManager

    variables = VariableManager()
    all_vars = {'ec2_tags': {'owner': 'bob'}, 'ec2_key_pair': 'abc123'}
    host = 'test_hostname'
    host_vars = all_vars.copy()
    host_vars['ec2_key_pair'] = 'test_key_pair'
    host_vars['owner'] = 'test_owner'
    host_vars['test_test'] = 'test_test'

    inventory = FakeInventory(hosts={host: host_vars}, all_vars=all_vars)
    group_cache = {}
    cache = {}

# Generated at 2022-06-21 05:04:30.091006
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from .unit import get_test_plugins_path
    from .unit import get_test_inventory_path
    from .unit.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = VariableManager()
    inventory_path = get_test_inventory_path('')
    plugin = InventoryModule()
    plugin._read_config_data(inventory_path)

    plugin.set_options(loader=loader, var_manager=inventory)

    test_host = Host("TEST")
    test_host.vars = {"test_var": "test_value"}

    result = plugin.get_all_host_vars(test_host, None, None)

# Generated at 2022-06-21 05:04:44.642406
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():

    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

    inv = InventoryManager(loader=DataLoader(), sources="localhost ansible_connection=local")
    inv.parse_sources()
    inv.add_group("testgroup")
    inv.add_host("localhost")
    inv.get_group("testgroup").add_child("all")
    inv.add_host("localhost", "testgroup")

    vars_mgr = VariableManager(loader=DataLoader(), inventory=inv)

    # instantiate the plugin class
    constructed_plugin = InventoryModule()
    constructed_plugin.verify_file("/tmp/inventory.config")

# Generated at 2022-06-21 05:04:59.872869
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory import Inventory
    import ansible.constants as C
    import ansible.cli.playbook

    ansible.cli.playbook.playbook_options('test')

    loader = DataLoader()
    inventory = Inventory(loader, host_list=['localhost'])

    inv_module = InventoryModule()
    inv_module.parse(inventory, loader, "./test-data/inventory.config", cache=True)

    assert inventory.hosts['localhost'].vars == {"server_type": "web", "var_sum": 10}
    assert 'webservers' in inventory.hosts['localhost'].get_groups()
    assert 'development' in inventory.hosts['localhost'].get_groups()

# Generated at 2022-06-21 05:05:09.015493
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''unit test for InventoryModule.verify_file'''

    C.HOST_VARS_PLUGINS = []  # allow .config extension

    inventory_module = InventoryModule()

    assert inventory_module.verify_file("foo.yml")
    assert not inventory_module.verify_file("foo.yaml")
    assert inventory_module.verify_file("foo.yaml.config")
    assert inventory_module.verify_file("foo.config")
    assert not inventory_module.verify_file("foo")
    assert not inventory_module.verify_file("foo.yml/bar.config")
    assert not inventory_module.verify_file("foo/bar.yml")

    C.HOST_VARS_PLUGINS = []  # reset it (do not modify global cfg)

# Generated at 2022-06-21 05:05:11.545360
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    #TODO: write a unit test
    pass


# Generated at 2022-06-21 05:05:40.086026
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    ''' Unit test for method get_all_host_vars of class InventoryModule '''

    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager

    # create a host
    host1 = Host(name='host1', port=22)

    # add group vars to host
    group_vars_path = './group_vars'
    group_vars_file1 = 'all'
    group_vars_file2 = 'group1'
    group_vars_file3 = 'group2'

    group_vars_file1_path = os.path.join(group_vars_path, group_vars_file1)
    group_vars_file2_path = os.path.join(group_vars_path, group_vars_file2)

# Generated at 2022-06-21 05:05:46.373837
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ''' unit test for method parse of class InventoryModule '''
    # Module created to test the behavior of the parse method of the class InventoryModule
    # Constructor
    test = InventoryModule()

    # Unit test variables

# Generated at 2022-06-21 05:05:59.634297
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    # A PluginManager object with the constructed plugin as the only entry in its inventory_plugins attr
    # Constructed is being mocked here because of the unfortunate way it was written, which makes it very hard to test
    # The inventory plugin is not being mocked because we actually want to test the get_host_vars method of the inventory
    # class which is a very important part of the inventory plugin architecture.
    # It is important to test the get_host_vars method because it is used by ansible during runtime. This is why we
    # are using a 'real' inventory object here instead of a mock.
    plugin_manager = type('', (), dict(inventory_plugins=['constructed']))
    plugin_manager.construct_inventory = type('', (), dict(get_option=lambda *args, **kwargs: False))

# Generated at 2022-06-21 05:06:11.471973
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    inv_mod = InventoryModule()
    loader = DummyLoader()
    sources = [1,2,3]

    from ansible.inventory.host import Host
    
    host_1 = Host('test_1')
    host_1.vars = {'one':1, 'two':2}

    host_2 = Host('test_2')
    host_2.vars = {'three':3, 'four':4}

    host_3 = Host('test_3')

    host_4 = Host('test_4')

    host_5 = Host('test_5')
    host_5.vars = {'five':5, 'four':4}

    from ansible.inventory.group import Group
    group_1 = Group('group_1')

# Generated at 2022-06-21 05:06:19.737742
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    loader = None
    sources = {}
    host = dict()
    host['test1'] = "Server1"
    host['test2'] = "Server2"
    inventory = [host]
    test = InventoryModule()
    test.parse(inventory, loader, path, cache=False)
    test.host_vars(host, loader, sources)
    assert test.host_vars(host, loader, sources) is not None


# Generated at 2022-06-21 05:06:23.605489
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' constructor class InventoryModule '''

    inventory_module = InventoryModule()

    assert inventory_module, "Failed to create InventoryModule object"

# Generated at 2022-06-21 05:06:33.472672
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # This is a test function for unit testing method host_vars of class
    # InventoryModule. We need to create a mock inventory object for that.

    class TestInventory():
        def host(self, hostname):
            # return a TestHost object
            return TestHost(hostname)

    class TestHost():
        def __init__(self, hostname):
            self.vars = { hostname: 'test_host' }

        def get_vars(self):
            return self.vars

    import ansible.inventory.data
    class TestLoaderModule():
        def __init__(self):
            pass

        def get_basedir(self):
            return "/root"


# Generated at 2022-06-21 05:06:46.320649
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    import ansible.plugins.loader as plugin_loader
    import ansible.inventory.manager as inventory_manager
    import ansible.parsing.yaml.objects as yaml_object

    inventory_loader = plugin_loader.get('inventory_loader', class_only=True)
    inventory = inventory_loader.InventoryLoader(inventory_manager.InventoryManager('localhost,'))

    plugin_loader._inventory_plugins = {}
    plugin_loader._all_plugin_classes = None

    constructed_plugin = inventory_loader.get('constructed', class_only=True)

    host = inventory.hosts['localhost']
    host.set_variable('foo_var', 'foo_value')
    host.set_variable('bar_var', 20)
    host.set_variable('baz_var', [22, 33, 44])

    group

# Generated at 2022-06-21 05:06:57.280158
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible_collections.notstdlib.moveitallout.plugins.inventory.host import Host

    # host object to test with
    host_a = Host(name="host_a")
    host_a.set_variable('ansible_ssh_user', 'bar')
    host_a.set_variable('ansible_ssh_host', '127.0.0.2')

    # host object to test with
    host_b = Host(name="host_b")
    host_b.set_variable('ansible_ssh_user', 'foo')
    host_b.set_variable('ansible_ssh_host', '127.0.0.1')

    # config file
    from ansible_collections.notstdlib.moveitallout.plugins.loader import PluginLoader

# Generated at 2022-06-21 05:07:03.680944
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from units.compat import unittest

    class MockInventory():
        ''' mock object for Inventory '''
        def __init__(self):
            self.hosts = {}
            self.groups = {}
            self.patterns = {}

        def add_host(self, hostname):
            self.hosts[hostname] = {}

        def add_group(self, groupname):
            self.groups[groupname] = {}

        def add_host_to_composed_group(self, groupname, hostname, vars=None, strict=True):
            if groupname not in self.groups:
                self.add_group(groupname)
            self.groups[groupname][hostname] = vars

        def get_host(self, hostname):
            return self.hosts[hostname]

       

# Generated at 2022-06-21 05:07:38.523139
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ans_obj = InventoryModule()
    ans_obj.verify_file(path='main.ini')
    ans_obj.parse(inventory=None, loader=None, path='main.ini', cache=True)

# Generated at 2022-06-21 05:07:47.593899
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_path = os.path.join(os.path.dirname(__file__), 'test_inventory_manager')
    inventory = InventoryManager(loader=loader, sources=inv_path)
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    im = InventoryModule()
    im.set_options({'use_vars_plugins': True})

    hvars = im.host_vars(inventory.hosts['host0'], loader, inventory.sources)
    assert hvars['foo'] == 'bar'
    assert hvars['some_var'] == 'group_var_value'

# Generated at 2022-06-21 05:07:50.228428
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    try:
        assert inventory_module.verify_file('some_file')
    except AssertionError:
        print('Expected assert to pass, but failed')


# Generated at 2022-06-21 05:08:01.987036
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    # mock the loader needed by get_vars_from_inventory_sources
    class MockedLoader():
        def load_from_file(self, file_name, file_path):
            return dict(test=dict(key="value"))

    # mock the inventory needed by get_group_vars and get_vars_from_inventory_sources
    class MockedInventory():
        def __init__(self):
            self.hosts = dict()
        def get_hosts(self, pattern="all"):
            return []

    # mock the inventory host object
    class MockedHost():
        def __init__(self, name):
            self.name = name
            self.vars = dict()
        def get_groups(self):
            return []
        def get_name(self):
            return self.name


# Generated at 2022-06-21 05:08:13.727519
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    plugin = InventoryModule()
    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=[])
    group = inv_manager.create_group('test_group')
    host = inv_manager.create_host('test_host', group=group)
    variable_manager = VariableManager()
    variable_manager.set_host_variable(host, 'var1', 1)
    variable_manager.set_host_variable(host, 'var2', 2)

    # Test _read_config_data()
    plugin._read_config_data("/test_path")

    # Test parse()

# Generated at 2022-06-21 05:08:23.358169
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    ''' builtin unit test
    $ python -m ansible.plugins.inventory.constructed test_InventoryModule_verify_file
    '''

# Generated at 2022-06-21 05:08:34.891331
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    m = InventoryModule()

    # file exists and is a config file

    p1 = os.path.dirname(__file__) + os.sep + 'test_playbooks' + os.sep + 'test_inventory_constructed.config'
    assert m.verify_file(p1) == True

    # file is a yaml file

    p1 = os.path.dirname(__file__) + os.sep + 'test_playbooks' + os.sep + 'test_inventory_constructed.yaml'
    assert m.verify_file(p1) == True

    # file does not exist

    p1 = os.path.dirname(__file__) + os.sep + 'test_playbooks' + os.sep + 'doesnotexist.config'
    assert m.verify

# Generated at 2022-06-21 05:08:45.317684
# Unit test for method get_all_host_vars of class InventoryModule
def test_InventoryModule_get_all_host_vars():
    import ansible.inventory.manager

    class Host:
        def __init__(self, host_name):
            self.name = host_name

        def get_groups(self):
            return []

    host = Host('localhost')

    script_path = 'constructed.py'
    sources = ['test/test_constructed_inventory.config']

    loader = ansible.parsing.dataloader.DataLoader()
    inventory = ansible.inventory.manager.InventoryManager(loader, sources)
    plugin = InventoryModule()
    plugin.parse(inventory, loader, script_path)
    host_vars = plugin.get_all_host_vars(host, loader, sources)

    assert host_vars['keyed_group'] == 'group'
    assert host_vars['group_sum'] == 0


# Generated at 2022-06-21 05:08:56.025290
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    import json
    from ansible.inventory.host import Host
    from ansible.plugins.loader import add_all_plugin_dirs

    add_all_plugin_dirs()

    hostname = 'local'
    file_name = '/tmp/host_vars_unit_test'
    with open(file_name, 'w') as the_file:
        the_file.write(json.dumps({'a': 1, 'b': 2, 'ansible_ssh_host': '10.1.1.1'}))
    host = Host(hostname)
    im = InventoryModule()
    im.set_option('use_vars_plugins', True)
    result = im.host_vars(host, None, [file_name])
    print(result)
    import os

# Generated at 2022-06-21 05:09:05.738806
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory = dict(
        hosts = dict()
    )   

    loader = dict(
        get_basedir = dict(
            return_value = '.'
        )
    )

    path = './test'

    # We have to create an instance of the plugin class inside the test,
    # otherwise the parse() method will not process the plugin options.
    # Setting the plugin options from here and calling super(InventoryModule, self).parse(...)
    # in the parse() method does not seem to work.
    plugin = InventoryModule()
    plugin._options['compose'] = dict(
        var_sum = 'var1 + var2'
    )
    plugin._options['groups'] = dict(
        webservers = 'inventory_hostname.startswith("web")'
    )
    plugin._options['keyed_groups']

# Generated at 2022-06-21 05:10:28.572968
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_class = InventoryModule()
    # populating groups
    groups = [['test', 'all', 'group_test_all'], ['test', 'group', 'test_group']]
    for group in groups:
        inventory_class.inventory.add_group(group[0])
        inventory_class.inventory.add_group(group[1])
        inventory_class.inventory.add_child(group[2], group[0])
        inventory_class.inventory.add_child(group[2], group[1])
    # populating vars
    test_group = inventory_class.inventory.groups['test_group']
    test_group.vars['test'] = 'test'
    all_group = inventory_class.inventory.groups['all']
    all_group.vars['all'] = 'all'
    # pop

# Generated at 2022-06-21 05:10:37.738779
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    '''Unit test for method host_vars of class InventoryModule'''

    # empty case
    try:
        InventoryModule().host_vars('', False, False)
        assert False, 'should raise'
    except AnsibleOptionsError as e:
        assert 'The option use_vars_plugins requires ansible >= 2.11.' == str(e)

    # empty case
    host = {'_host': 'host', 'vars': {}}
    host_obj = type('host', (), host)()
    loader = type('loader', (), {})()
    inventory = type('inventory', (), {})()
    InventoryModule().host_groupvars(host_obj, loader, [])
    InventoryModule().host_vars(host_obj, loader, [])

# Generated at 2022-06-21 05:10:42.151042
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    assert module.verify_file('inventory.config')
    assert not module.verify_file('inventory.txt')

# Generated at 2022-06-21 05:10:53.561982
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader
    from ansible.inventory.group import Group
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play

    host_vars = {'var1': 'value1', 'var2': 'value2'}
    host = Host(name="foo")
    host.set_variable('var1', 'value1')
    host.set_variable('var2', 'value2')

    inventory = InventoryManager(loader=DataLoader())

# Generated at 2022-06-21 05:11:08.177963
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.manager import InventoryManager

    plugin = InventoryModule()

    group_vars_dir = os.path.join(os.path.dirname(__file__), '..', 'group_vars')
    host_vars_dir = os.path.join(os.path.dirname(__file__), '..', 'host_vars')
    inventory_dir = os.path.join(os.path.dirname(__file__), '..', 'inventory')

    # This is the way to access inventory host data
    # In this case the full path of a file should be passed
    inventory_path = os.path.join(inventory_dir, 'inventory.cfg')
    inventory = InventoryManager(loader=None, sources=[inventory_path])
    host_name = 'ec2_test'
    host = inventory

# Generated at 2022-06-21 05:11:18.445915
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import InventoryPluginLoader

    loader = DataLoader()
    host_object = Host(name="127.0.0.1")
    host_object.vars.update(dict(var1="inhostobject"))
    hostvars = InventoryModule.host_vars(host_object, loader, loader.all_inventory_names)
    assert hostvars['var1'] == "inhostobject"
