

# Generated at 2022-06-25 09:40:39.058271
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    bytes_0 = b'0\xea\xac\xb1\xf1\xa9'
    inventory_module_1 = InventoryModule()
    inventory_0 = inventory_module_1.parse(loader, path='/dev/null')


# Generated at 2022-06-25 09:40:49.402180
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    print("\n")
    print("###########################")
    print("# Testing host_groupvars() #")
    print("###########################")

    inventory_module_2 = InventoryModule()
    loader_2 = ansible.parsing.dataloader.DataLoader()
    ansible_vars_2 = ansible.vars.manager.VariableManager()
    ansible_inventory_2 = ansible.inventory.manager.InventoryManager(loader=loader_2, sources=[""],
        variable_manager=ansible_vars_2, host_list=[])
    ansible_host_2 = ansible.inventory.host.Host('hostname')
    ansible_host_2.groups = [ansible.inventory.group.Group]

# Generated at 2022-06-25 09:40:50.227410
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:40:51.812256
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars() is None


# Generated at 2022-06-25 09:40:54.563547
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    bytes_0 = b'j\xb5^\xce\xbfop\xd5\x1c\xe9\xd6\x86'
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:41:00.790182
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    bytes_0 = b'j\xb5^\xce\xbfop\xd5\x1c\xe9\xd6\x86'
    inventory_module_0 = InventoryModule()
    inventory_0 = bytes_0
    loader_0 = bytes_0
    sources_0 = bytes_0
    result = inventory_module_0.host_groupvars(inventory_module_0, inventory_0, loader_0, sources_0)
    assert result == None


# Generated at 2022-06-25 09:41:06.123927
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    test_host_1 = {
        'inventory_hostname': 'Router-1'
    }
    test_loader_1 = None
    test_sources_1 = [
        'configfile1.yml'
    ]

    #TODO test_result_1 = inventory_module_1.host_vars(test_host_1, test_loader_1, test_sources_1)



# Generated at 2022-06-25 09:41:15.769676
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    bytes_0 = b'\x80\x10\x1b\x13\xf2P\xea\xbe\x9c\x81\x00\xdb\xc6\x84\x18\x13\xd6'
    loader_0 = DataLoader()
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory(loader_0)
    loader_0.set_basedir(None)
    host_0 = Host('127.0.0.1', port=None)
    inventory_0.add_host(host_0)
    result = inventory_module_0.host_groupvars(inventory_0.hosts['127.0.0.1'], loader_0, bytes_0)
    assert result == {}


# Generated at 2022-06-25 09:41:20.849468
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    with pytest.raises(AnsibleOptionsError, match=r"The option use_vars_plugins requires ansible >= 2.11."):
        inventory_module_0 = InventoryModule()
        result_0 = inventory_module_0.host_vars(None, None, None)
        assert result_0 == None


# Generated at 2022-06-25 09:41:29.719902
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    ansible_vars_1 = dict()
    ansible_vars_1["ansible_inventory_hostname"] = "host"
    ansible_vars_1["ansible_hostname"] = "host"

    # Test case 0
    loader_0 = None
    path_0 = "/home/foo/"
    sources_0 = []
    host_0 = "foo"

    result = inventory_module_1.host_vars(ansible_vars_1, loader_0, path_0, sources_0, host_0)
    assert result == ansible_vars_1


# Generated at 2022-06-25 09:41:36.646920
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars() == None



# Generated at 2022-06-25 09:41:38.870424
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    result = inventory_module.verify_file(path = "/path/to/file")
    assert result == False

# Generated at 2022-06-25 09:41:41.380299
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module = InventoryModule()
    host = "test host"
    loader = "test loader"
    sources = "test sources"
    result = inventory_module.host_vars(host, loader, sources)
    assert result is not None


# Generated at 2022-06-25 09:41:44.941362
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = "../file.config"

    assert inventory_module_0.verify_file(path) == True


# Generated at 2022-06-25 09:41:49.590766
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = [None, None]
    loader_0 = [None, None]
    path_0 = ""
    cache_0 = [None, None]
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 09:41:51.070900
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path, cache=False)

# Generated at 2022-06-25 09:41:53.910147
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars() == None


# Generated at 2022-06-25 09:41:55.003975
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert(InventoryModule().verify_file('./inventory.config') == True)


# Generated at 2022-06-25 09:41:57.424694
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    tmp_path = os.path.realpath(__file__)
    inventory_0 = Inventory(loader=_Loader(), host_list=[])
    inventory_module_0.parse(inventory_0, _Loader(), tmp_path)


# Generated at 2022-06-25 09:41:59.730316
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file(path)



# Generated at 2022-06-25 09:42:05.456755
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()

    # from unittest.mock import patch



# Generated at 2022-06-25 09:42:06.692392
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file("inventory.yaml")



# Generated at 2022-06-25 09:42:13.116658
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_1 = {'vars': {}, 'groups': {}}
    loader_1 = {'cache': {}, '_real_file': {}}
    path_1 = '/etc/ansible/hosts'
    inventory_module_1.parse(inventory_1, loader_1, path_1)



# Generated at 2022-06-25 09:42:19.213997
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    try:
        inventory_module = InventoryModule()
        inventory_module.parse(inventory, loader, path, cache=False)
    except Exception as e:
        print("\nException in parsing InventoryModule %s" %e)
        raise

if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:42:22.524245
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory='inventory', loader='loader', path='path')


# Generated at 2022-06-25 09:42:27.775133
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_2 = {}
    loader_3 = {}
    path_4 = {}
    cache_5 = {}
    result_dict = inventory_module_1.parse(inventory_2, loader_3, path_4, cache_5)
    assert result_dict == None


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_parse()

# Generated at 2022-06-25 09:42:31.227002
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    ansible_hosts = [{u'ansible_host': u'localhost'}]
    loader = [{u'hosts': ansible_hosts}]
    path = 'testInventoryModules'
    inventory_module_0.parse(loader, path)

# Generated at 2022-06-25 09:42:34.146238
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:42:37.401845
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    assert not inventory_module_0.host_groupvars(inventory_module_0, inventory_module_0, inventory_module_0)


# Generated at 2022-06-25 09:42:40.933085
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    inventory_module_1.options = {'use_vars_plugins': True}
    assert inventory_module_1.host_vars('host1', 'loader', 'sources') == combine_vars(get_group_vars(['host1']), get_group_vars(['host1']))

# Generated at 2022-06-25 09:42:58.903416
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # TODO: Fix the params
    #assert inventory_module_0.parse(inventory, loader, path, cache=False) == ('./inventory.config file in YAML format', 'plugin: constructed', 'strict: False', 'compose:', '  var_sum: var1 + var2', 'groups:', '  webservers: inventory_hostname.startswith(\'web\')', '  development: "\'devel\' in (ec2_tags|list)"', '  private_only: not (public_dns_name is defined or ip_address is defined)', '  multi_group: (group_names | intersect([\'alpha\', \'beta\', \'omega\'])) | length >= 2', 'keyed_groups:', '  - prefix: distro', '   

# Generated at 2022-06-25 09:42:59.880005
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:43:01.529150
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'inventory.config'
    assert inventory_module_0.verify_file(path) == True


# Generated at 2022-06-25 09:43:05.689770
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module = InventoryModule()
    
    inventory_module.parse(inventory, loader, path, cache=False)
    
    assert 1 == 1

# Generated at 2022-06-25 09:43:06.585801
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # test case 0
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:43:09.855002
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    inventory_module_verify_file.verify_file("inventory.config")


# Generated at 2022-06-25 09:43:13.224376
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

    inventory = None
    loader = None
    path = None
    cache = None

    inventory_module_0.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:43:16.404514
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = ""
    loader = ""
    path = ""
    cache = False
    inventory_module.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:43:17.220611
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:43:22.058689
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    parser = ansible.parsing.yaml.objects.AnsibleVaultEncryptedUnicode()
    loader = ansible.parsing.dataloader.DataLoader()
    inventory = mock.MagicMock()
    inventory_module_1.parse(inventory, loader, '/etc/ansible/hosts', False)

# Generated at 2022-06-25 09:43:52.607411
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    print("Running test case 0: ")
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, path)
    ansible_vars = inventory.hosts[inventory.hosts['host_0']]
    ansible_vars = get_group_vars(inventory.hosts['host_0'].get_groups())



# Generated at 2022-06-25 09:43:57.662377
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_instance_0.verify_file(inventory_module_1) == False


inventory_module_instance_0 = InventoryModule()
inventory_module_instance_0.verify_file(inventory_module_instance_0)
inventory_module_instance_1 = InventoryModule()
inventory_module_instance_0.verify_file(inventory_module_instance_1)

# Generated at 2022-06-25 09:44:05.661406
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    # Test for simple 'host_groupvars' with following kind of input:
    #  - InventoryModule object
    #  - Host Object
    #  - loader object
    #  - sources list object

    inventory_module_1 = InventoryModule()
    host_1 = "test_host_1"
    inventory_module_1.inventory.hosts[host_1] = "Test-Host-1"
    loader_1 = "loader_1"
    sources_1 = ["sources_1"]

    try:
        inventory_module_1.host_groupvars(host_1, loader_1, sources_1)
    except AnsibleOptionsError:
        # This exception is expected, user enabled non-default option and it is Ansible < 2.11
        # So no valid test case possible
        pass


# Generated at 2022-06-25 09:44:09.674784
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse("inventory", "loader", "path")
    try :
        inventory.add_host("host", "group")
        inventory_module_0.host_groupvars("host", "loader", "sources")
    except Exception as e :
        print("Failed : %s" % e)


# Generated at 2022-06-25 09:44:18.952309
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    class Host:
        def __init__(self):
            self.name = ''
            self.has_vars = False
        def set_name(self, name):
            self.name = name
        def set_vars(self, vars):
            self.has_vars = True
        def get_name(self):
            return self.name
        def get_vars(self):
            if self.has_vars == False:
                return {}
            else:
                return {'properties': {'host_name': self.name}}
    host_1 = Host()
    host_1.set_name('host_1')
    loader_1 = ''
    sources_1 = []

# Generated at 2022-06-25 09:44:29.562490
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile
    from ansible.parsing.dataloader import DataLoader


# Generated at 2022-06-25 09:44:34.577831
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    """
    Test the host_groupvars function with no arguments
    """

    # Run the test
    try:
        # Call the function
        inventory_module_1.host_groupvars(None, None, None)
    except:
        pass


# Generated at 2022-06-25 09:44:35.239139
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-25 09:44:37.451172
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert(inventory_module_0.verify_file(constants.ANSIBLE_INVENTORY_CONSTRUCTED_PATH))

# Generated at 2022-06-25 09:44:40.066660
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = FactCache()
    loader = FactCache()
    path = '/tmp/inventory'
    test_case_module = InventoryModule()
    test_case_module.parse(inventory, loader, path)

# Generated at 2022-06-25 09:45:03.642433
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    # Create an instance of class InventoryModule
    inventory_module = InventoryModule()

    # Create an instance of class Host
    host = Host(name="testhost", vars={"ansible_host": "192.168.1.1"})
    # Create a list of sources
    sources = []

    # Create an instance of class DataLoader
    loader = DataLoader()

    # Call method host_vars with parameters host and loader
    result = inventory_module.host_vars(host, loader, sources)

    assert result == host.get_vars()

# Generated at 2022-06-25 09:45:07.232459
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    host_0 = Host(name = "foo")
    loader_0 = None
    sources_0 = []
    InventoryModule.host_groupvars(inventory_module_0, host_0, loader_0, sources_0)


# Generated at 2022-06-25 09:45:08.111751
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module = InventoryModule()


# Generated at 2022-06-25 09:45:10.282333
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_2 = InventoryModule()
    inventory_1 = "inventory"
    loader_1 = "loader"
    path_1 = "path"
    inventory_module_2.parse(inventory_1, loader_1, path_1)


# Generated at 2022-06-25 09:45:21.093632
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # processing_path is not used by constructor.
    # this is just a workaround to make the test pass.
    class InventoryModule_parse_args:
        processing_path = 'fakepath'

    mocker = Mocker()
    obj = mocker.patch(InventoryModule())

    inventory = InventoryModule_parse_args()
    loader = mocker.patch('ansible.parsing.dataloader.DataLoader')
    path = 'fakepath'
    cache = True

    obj.verify_file(path)
    mocker.result(True)
    obj._read_config_data(path)
    obj.get_option = mocker.Mock()
    obj.get_option('strict')
    mocker.result(False)
    obj.get_option('compose')

# Generated at 2022-06-25 09:45:25.350206
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:45:27.180361
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = {}
    loader_0 = {}
    sources_0 = []
    assert inventory_module_0.host_vars(host_0, loader_0, sources_0) == {}

# Generated at 2022-06-25 09:45:31.025946
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars(host=host, loader=host, sources=host)


# Generated at 2022-06-25 09:45:35.306735
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    host = {}
    loader = "loader"
    sources = []
    result = inventory_module_1.host_vars(host, loader, sources)
    assert result == {}

# Generated at 2022-06-25 09:45:38.982543
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    inventory_module_1 = InventoryModule()
    host_1 = {}
    loader_1 = {}
    sources_1 = []
    assert inventory_module_1.host_groupvars(host_1, loader_1, sources_1) == {}


# Generated at 2022-06-25 09:46:24.292702
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
# check if there is a canary test to run

if __name__ == "__main__":
    import os
    file_name = os.path.basename(__file__)
    print("Running test: " + file_name)

    test_case_0()
    test_InventoryModule_host_groupvars()

# Generated at 2022-06-25 09:46:28.497875
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module = InventoryModule()
    hosts = ('host1', 'host2', 'host3', 'host4')
    fact_cache = fact_cache = FactCache(hosts=hosts)
    fact_cache.set_host_facts('host1', dict(var1='value1'))
    fact_cache.set_host_facts('host2', dict(var1='value2'))
    fact_cache.set_host_facts('host3', dict(var1='value3'))
    fact_cache.set_host_facts('host4', dict(var1='value4'))
    inventory_module._cache = fact_cache
    assert inventory_module.host_vars('host1', 'loader', 'sources') == dict(var1='value1')

# Generated at 2022-06-25 09:46:32.539232
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    print("\n# Unit test for method host_vars of class InventoryModule")
    inventory_module_1 = InventoryModule()
    inventory_module_1.get_option = lambda x: None
    inventory_module_1.host_vars(host, loader, sources)


# Generated at 2022-06-25 09:46:35.200303
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    args = {'path': 'path'}
    kwargs = {}
    result = inventory_module_0.verify_file(**args)
    assert isinstance(result, bool)


# Generated at 2022-06-25 09:46:38.753257
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    print("Create InventoryModule object to test its method host_groupvars")
    inventory_module = InventoryModule()
    ret = inventory_module.host_groupvars()
    assert ret == 'host_groupvars() is executed', 'host_groupvars() is not executed'
    print("host_groupvars() is executed")
    print("Verified that host_groupvars() is executed")


# Generated at 2022-06-25 09:46:49.012525
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = {"hostvars": {"hostvar_0": "hostvar_0"}, "vars": {"var_0": "var_0", "var_1": "var_1", "var_2": "var_2"}}

# Generated at 2022-06-25 09:46:53.997971
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module = InventoryModule()
    inventory_module.parse(inventory, loader, path, cache=False)
    host_vars = inventory_module.host_vars(host, loader, sources)
    print(host_vars)


# Generated at 2022-06-25 09:46:55.142279
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    assert not inventory_module.parse('','','',None)


# Generated at 2022-06-25 09:47:02.512048
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:47:03.784170
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    my_args = ['args']
    inventory_module_parse.parse(my_args)


# Generated at 2022-06-25 09:48:37.979362
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Called when executing inventory module as a script."""
    for ansible_version in [1, 2, 2.4, 2.5]:
        inventory_module_0 = InventoryModule()

# Constructor test for class InventoryModule

# Generated at 2022-06-25 09:48:44.669112
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert inventory_module_0.verify_file('../tests/test_inventory_plugins/inventory.yaml')
    assert inventory_module_0.verify_file('../tests/test_inventory_plugins/inventory.config')
    assert not inventory_module_0.verify_file('../tests/test_inventory_plugins/inventory.json')
    assert not inventory_module_0.verify_file('../tests/test_inventory_plugins/inventory_1.json')
    assert not inventory_module_0.verify_file('../tests/test_inventory_plugins/inventory_2.yaml')
    assert inventory_module_0.verify_file('../tests/test_inventory_plugins/inventory_0.yaml')

# Generated at 2022-06-25 09:48:52.127864
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory = {"_meta": {"hostvars": {
        "test_host": {
            "test_var_1": "abc",
            "test_var_2": 123
        }
    }}}
    inventory_module = InventoryModule()
    loader = MockLoader()
    path = "/some/path/inventory.conf"
    sources = []

    result = inventory_module.host_vars(inventory["_meta"]["hostvars"]["test_host"], loader, sources)
    expected = {"test_var_1": "abc", "test_var_2": 123}
    assert result == expected



# Generated at 2022-06-25 09:48:54.539587
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    loader_0 = None
    path_0 = ''
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)

# Generated at 2022-06-25 09:48:56.167589
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.get_plugin_name()

# Generated at 2022-06-25 09:48:58.514510
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.options_list = {'use_vars_plugins': 'False'}
    inventory_module_0.host_vars(host=None, loader=None, sources=None)


# Generated at 2022-06-25 09:49:01.836005
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Add functionality to test
    return

# Generated at 2022-06-25 09:49:06.935852
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    groups_0 = [
        'webservers',
        'production',
        'webservers',
        'development',
        'webservers',
    ]
    host_0 = {
        'name': 'web_dbserver_1',
    }
    host_1 = {
        'name': 'web_dbserver_2',
    }
    var_0 = inventory_module_0.host_groupvars(
        host_0,
        loader,
        sources,
    )
    var_1 = inventory_module_0.host_groupvars(
        host_1,
        loader,
        sources,
    )
    print(var_0)
    print(var_1)


# Generated at 2022-06-25 09:49:08.497900
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()



# Generated at 2022-06-25 09:49:11.457676
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = None
    loader = '1'
    path = 2
    cache = False
    inventory_module.parse(inventory, loader, path, cache)
