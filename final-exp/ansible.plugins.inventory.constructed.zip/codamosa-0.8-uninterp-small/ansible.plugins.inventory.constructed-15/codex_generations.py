

# Generated at 2022-06-25 09:40:39.258303
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_host_vars = InventoryModule()

    assert inventory_module_host_vars.host_vars() == None

# Generated at 2022-06-25 09:40:42.029130
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory = AnsibleInventory(hosts_list=[])
    loader = AnsibleLoader([], [])
    path = 'path'
    # Parse the inventory file and get a list of hosts
    inventory_module_0.parse(inventory, loader, path)

# Generated at 2022-06-25 09:40:45.947677
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('AnsibleInventory', 'ansible_loader_0', 'str_path', cache=True)


# Generated at 2022-06-25 09:40:48.308460
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_groupvars is not None


# Generated at 2022-06-25 09:40:54.590263
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(path=None) is None
    assert inventory_module_0.verify_file(path="path_0") is None
    assert inventory_module_0.verify_file(path="path_1") is None


# Generated at 2022-06-25 09:40:58.085711
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()
    inventory_module_0.get_option('strict')
    inventory_module_0.get_option('use_vars_plugins')
    inventory_module_0.host_groupvars()
    inventory_module_0.host_vars()
    inventory_module_0.get_all_host_vars()

# Generated at 2022-06-25 09:41:06.836940
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_host_groupvars_0 = InventoryModule()
    try:
        assert inventory_module_host_groupvars_0.host_groupvars().__class__.__name__ == 'builtins.dict'
    except AssertionError as e:
        print("test_InventoryModule_host_groupvars (test_case_0.py): FAIL: InventoryModule.host_groupvars(): " + str(e))
    else:
        print("test_InventoryModule_host_groupvars (test_case_0.py): PASS")


# Generated at 2022-06-25 09:41:12.595458
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    result_dict = {}
    inventory_module_0 = InventoryModule()
    verify_file_args = (['**/*.config'], )
    verify_file_kwargs = {'match_all': True}
    try:
        result_dict['result'] = inventory_module_0.verify_file(*verify_file_args, **verify_file_kwargs)
        result_dict['verified'] = True
    except Exception as e:
        result_dict['verified'] = False
        result_dict['result'] = e
    return result_dict


# Generated at 2022-06-25 09:41:14.365843
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    assert None == inventory_module_1.host_vars(None, None, None)


# Generated at 2022-06-25 09:41:15.057611
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:41:34.965815
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    # create host object, then load it with vars
    host_object_with_vars = type('host1', (), {})()
    host_object_with_vars.vars = dict()
    host_object_with_vars.vars['var1'] = 'value1'
    host_object_with_vars.vars['var2'] = 'value2'

    # create host object
    host_object = type('host2', (), {})()

    # create source list
    source_list = ['source1', 'source2']

    # test InventoryModule.host_vars method
    inventory_module_0 = InventoryModule()
    ansible_facts_result = inventory_module_0.host_vars(host_object, 'loader', source_list)

# Generated at 2022-06-25 09:41:37.019872
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.host_vars("host", "loader", "sources")

# Generated at 2022-06-25 09:41:40.117527
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'opt/ansible/ansible/plugins/inventory/constructed.py'
    assert inventory_module_0.verify_file(path) == True


# Generated at 2022-06-25 09:41:46.468888
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    path = {}
    expected = False
    actual = inventory_module_verify_file.verify_file(path)
    assert expected == actual
    print('test_InventoryModule_verify_file passed!')

if __name__ == '__main__':
    pytest.main([__file__, '-vv'])

# Generated at 2022-06-25 09:41:50.297153
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:41:52.238306
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.host_vars() == None


# Generated at 2022-06-25 09:41:54.915956
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = Host(name='host_name_0')
    loader_0 = None
    sources_0 = ['sources_0']
    try:
        inventory_module_0.host_vars(host_0, loader_0, sources_0)
    except:
        pass


# Generated at 2022-06-25 09:41:56.233956
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    pass


# Generated at 2022-06-25 09:42:00.020228
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    # no error is raised with these parameters


# Generated at 2022-06-25 09:42:04.040047
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    # FIXME - improve tests to check if host_vars is returning the correct results
    params = [None, None, None]
    inventory_module_0.host_vars(*params)


# Generated at 2022-06-25 09:42:24.854071
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory = BaseInventoryPlugin()
    inventory.add_group("group1")
    group = inventory.groups["group1"]
    group.add_host("foo1")
    group.add_host("foo2")

    loader = BaseInventoryPlugin()
    sources = BaseInventoryPlugin()

    # tests
    host1 = inventory.hosts["foo1"]
    host2 = inventory.hosts["foo2"]

    # test using BaseInventoryPlugin as loader
    host_groupvars = InventoryModule.host_groupvars(InventoryModule(), host1, loader, sources)
    assert isinstance(host_groupvars, dict)
    assert host_groupvars == {'group_names': ['group1'], 'group_names+': ['group1']}
    host_groupvars = InventoryModule.host_groupv

# Generated at 2022-06-25 09:42:28.550503
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory()
    loader_0 = DataLoader()
    path_0 = '.'
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 09:42:30.458982
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'dummy_path'
    ret = inventory_module_0.verify_file(path)
    assert ret is False


# Generated at 2022-06-25 09:42:37.150541
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = {  }
    loader = DictDataLoader()
    loader.set_basedir("")
    sources = [  ]
    test_0 = inventory_module_0.host_vars(host_0, loader, sources)


# Generated at 2022-06-25 09:42:39.265569
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()

    assert inventory_module_0.verify_file('/etc/ansible/hosts') == False


# Generated at 2022-06-25 09:42:44.060885
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    loader_0 = BaseInventoryPlugin()
    sources_0 = [loader_0]
    host_0 = inventory_0.hosts['ssh_host']
    inventory_module_0.host_groupvars(host_0, loader_0, sources_0)


# Generated at 2022-06-25 09:42:46.636845
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = "inventory.config"
    inventory_module_0.verify_file(path)


# Generated at 2022-06-25 09:42:49.630267
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_obj = InventoryModule()
    assert inventory_module_obj.verify_file('/etc/ansible/hosts')
    assert not inventory_module_obj.verify_file('/etc/ansible/hosts_')


# Generated at 2022-06-25 09:42:59.303865
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    group_vars = {
      "foo": {
        "test_var_0": 0
      },
      "bar": {
        "test_var_1": 1
      },
      "baz": {
        "test_var_2": 2
      },
      "foobar": {
        "test_var_3": 3
      }
    }


    result = {
      "test_var_0": 0,
      "test_var_1": 1,
      "test_var_2": 2,
      "test_var_3": 3
    }

    inventory = InventoryModule()

    actual = inventory.host_groupvars(group_vars)

    assert actual == result



# Generated at 2022-06-25 09:43:07.785718
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # test variables
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.inventory.host import Host
    test_host = Host(name='test_host_name')
    # test parm values
    test_host.vars = {'var1': 'value1', 'var2': 'value2'}
    test_host.groups = [
        {'g1_name': 'g1', 'g1_vars': {'var1': 'g1_value1', 'var2': 'g1_value2'}},
        {'g2_name': 'g2', 'g2_vars': {'var1': 'g2_value1', 'var2': 'g2_value2'}}
    ]

# Generated at 2022-06-25 09:43:35.375532
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    host_0 = {}
    loader_0 = {}
    sources_0 = []
    result_0 = inventory_module_0.host_groupvars(host_0, loader_0, sources_0)
    assert result_0['ansible_user'] == ''

if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_host_groupvars()

# Generated at 2022-06-25 09:43:39.614627
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    loader = DataLoader()
    inventory_module_0.parse(inventory, loader, '/opt/ansible/inventory/inventory.yml', cache=True)
    host = 'local'
    myansible_host_vars = inventory_module_0.host_vars(host, loader, inventory.processed_sources)
    assert myansible_host_vars == {}


# Generated at 2022-06-25 09:43:45.017577
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Initialize InventoryModule instance
    inventory_module = InventoryModule()

    # Get 'dict' type variable inventory

    # Get 'object' type variable loader

    # Get 'str' type variable path

    # Get 'bool' type variable cache

    # Call method parse of InventoryModule
    inventory_module.parse(inventory, loader, path, cache)

# Generated at 2022-06-25 09:43:54.203986
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory()
    loader_0 = DataLoader()
    path_0 = "inventory.config"
    test_case_0()
    assert(inventory_module_0.get_option('plugin') == 'constructed')
    assert(inventory_module_0.verify_file(path_0) == True)
    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0, cache=False)
    except Exception as e:
        raise
    #assert(inventory_module_0.parse(inventory_0, loader_0, path_0, cache=False) == [])


# Generated at 2022-06-25 09:44:00.945593
# Unit test for method host_groupvars of class InventoryModule

# Generated at 2022-06-25 09:44:05.573090
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = inventory_module_0.host_vars("", "", "")


# Generated at 2022-06-25 09:44:09.264190
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    hosts = ['test-host-1', 'test-host-2']
    loader = BaseInventoryPlugin()
    sources = []
    assert False == inventory_module_0.host_groupvars(hosts, loader, sources)


# Generated at 2022-06-25 09:44:14.211028
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # inventory_module_0 = InventoryModule()
    # inventory_0 = Inventory()
    # loader_0 = None
    # path_0 = None
    # value_0 = inventory_module_0.parse(inventory_0, loader_0, path_0)
    pass


# Generated at 2022-06-25 09:44:21.006017
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # Test set up
    inventory_module_1 = InventoryModule()
    inventory_module_1.get_option = lambda x: 'ansible-inventory'
    ansible_host = {}
    ansible_host['hostname'] = 'inventory_hostname'
    ansible_host['_options'] = {}
    loader = 'loader'
    sources = ['sources']
    # Testing
    assert inventory_module_1.host_vars(ansible_host, loader, sources) == ansible_host


# Generated at 2022-06-25 09:44:23.781670
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:45:41.804465
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse()

# Generated at 2022-06-25 09:45:46.909564
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    fact_cache_host_vars_1 = FactCache()
    fact_cache_host_vars_1[inventory_module_1].ansible_distribution = "CentOS"
    inventory_module_1._cache = fact_cache_host_vars_1
    print (inventory_module_1.host_vars("inventory_module_1", "loader", "sources"))


if __name__ == '__main__':
    test_case_0()
    test_InventoryModule_host_vars()

# Generated at 2022-06-25 09:45:48.634993
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    assert isinstance(inventory_module_0, InventoryModule)



# Generated at 2022-06-25 09:45:54.507263
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module = InventoryModule()
    try:
        print('Testing for host_groupvars')
        host_groupvars(host, loader, sources)
        raise Exception
    except:
        pass
    finally:
        InventoryModule.test_case_0()


# Generated at 2022-06-25 09:45:58.368283
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    Tests the parse method of class InventoryModule
    Ensures that any exceptions raised are AnsibleParserError
    '''
    # create instance of class
    test_obj = InventoryModule()
    # assert that parse raises AnsibleParserError
    with pytest.raises(AnsibleParserError):
        test_obj.parse()



# Generated at 2022-06-25 09:46:04.207612
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    test_param1_1 = ''
    test_param1_2 = ''
    test_param1_3 = ''
    inventory_module_1.host_groupvars(test_param1_1, test_param1_2, test_param1_3)


# Generated at 2022-06-25 09:46:07.046735
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file("/usr/share/ansible/plugins/inventory/constructed.py")

# Generated at 2022-06-25 09:46:08.801831
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(path='inventory.config')


# Generated at 2022-06-25 09:46:10.991441
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path = 'constructed_test.config'
    result = inventory_module_0.verify_file(path)
    assert result == True



# Generated at 2022-06-25 09:46:16.222189
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_1 = 'host_1'
    loader_2 = 'loader_2'
    sources_3 = ['sources_31', 'sources_32']
    inventory_module_0.host_vars(host_1, loader_2, sources_3)


# Generated at 2022-06-25 09:47:45.931237
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    # Loader for the test
    loader = DataLoader()
    # inventory sources that are used by the test
    sources = [{"plugin": "apple", "path": "sources_path", "name": "apple", "s_group": "my_group", "s_host": "my_host"}]

    # Reading the test config file
    test_file = open("test_constructed_inventory.config", "r")
    test_config = test_file.read()
    test_file.close()

    # Creating a test inventory
    test_inventory = InventoryManager(loader=loader)

    # Adding the test inventory sources
    test_inventory.processed_sources = sources

    # Creating a test host
    test_host = Host(name='my_host')

    # Creating a test groups

# Generated at 2022-06-25 09:47:52.244689
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    loader_0 = DictDataLoader({'ansible_inventory': 'ec2.yml'})
    path_0 = 'ec2.yml'
    host_vars_0 = inventory_module_0.host_vars(inventory_module_0, loader_0, path_0)


# Generated at 2022-06-25 09:47:56.710879
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    host = dict(name='test_host', vars=dict(var1=1))
    loader = None
    sources = ['source1']
    inventory_module = InventoryModule()

    # Variable to test
    host_vars = inventory_module.host_vars(host, loader, sources)
    assert host_vars == dict(var1=1)


# Generated at 2022-06-25 09:47:58.608792
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module = InventoryModule()
    assert inventory_module.host_groupvars(hostvars=dict,loader='loader',sources='sources') is not None, "This test case passes"


# Generated at 2022-06-25 09:48:06.235746
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    # Init parser
    loader_0 = DataLoader()
    inventory_0 = InventoryManager(loader=loader_0)
    # Init data source for inventory_0
    # Parse data sources for inventory_0
    inventory_0.parse_sources('localhost,')
    # Init the first host 'fake_host_0'
    fake_host_0 = Host('fake_host_0')
    inventory_0.add_host(fake_host_0, 'fake_group_0')
    # Init data source for inventory_0
    sources_0 = []
    # Add data source for inventory_0
    sources_0.append(inventory_0)
    # Set data source for inventory_0
    # Call method host_vars of class InventoryModule
    inventory_module_0.host_

# Generated at 2022-06-25 09:48:15.033693
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module_1 = InventoryModule()
    assert inventory_module_1.verify_file('inventory.config') == True
    assert inventory_module_1.verify_file('inventory.yml') == True
    assert inventory_module_1.verify_file('inventory.yaml') == True
    assert inventory_module_1.verify_file('inventory') == True
    assert inventory_module_1.verify_file('/etc/ansible/hosts') == True
    assert inventory_module_1.verify_file('inventory.ini') == False


# Generated at 2022-06-25 09:48:18.500934
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ir_0 = InventoryModule()
    ir_0.parse('inventory','loader','path','cache')

# Generated at 2022-06-25 09:48:22.548880
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:48:25.479403
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()

    # False
    assert inventory_module_1.host_vars() == False



# Generated at 2022-06-25 09:48:29.708379
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # Create a test inventory object
    inventory_object = InventoryModule()
    # TODO: Create a test host object
    host_object = host()
    # Create a test loader object
    loader_object = loader()
    # Create a test sources object
    sources_object = sources()

    inventory_object.host_vars(host=host_object, loader=loader_object, sources=sources_object)
