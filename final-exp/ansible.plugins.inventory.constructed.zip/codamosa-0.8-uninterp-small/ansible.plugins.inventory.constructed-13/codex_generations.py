

# Generated at 2022-06-25 09:40:33.775313
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.host_groupvars() == None


# Generated at 2022-06-25 09:40:44.015601
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    examples_dir = '../../../../examples'
    inventory_path = os.path.join(examples_dir, 'inventory.config')
    loader = DataLoader()
    inventory = InventoryManager(loader, [inventory_path])
    inventory.parse_sources()
    inventory.extra_vars = {'var1': 1, 'var2': 2,
                            'var3': True, 'var4': False, 'var5': "test", 'var6': "foo", 'var7': [1, 2]}
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, inventory_path)

# Generated at 2022-06-25 09:40:48.160414
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_object = {
    }

    inventory_module_0.parse(inventory_object, loader=None, path=None, cache=False)

# Generated at 2022-06-25 09:40:52.570367
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = 'inventory.config'
    if(inventory_module_0.verify_file(path) == False):
        return True
    return False


# Generated at 2022-06-25 09:40:55.074887
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    host_groupvars_0 = inventory_module_1.host_groupvars(host, loader, sources)


# Generated at 2022-06-25 09:41:00.868300
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_verify_file = InventoryModule()
    # Verify file extention
    assert inventory_module_verify_file.verify_file("/home/user/test.yaml") == True
    assert inventory_module_verify_file.verify_file("/home/user/test.yml") == True
    assert inventory_module_verify_file.verify_file("/home/user/test.yaml.txt") == False
    assert inventory_module_verify_file.verify_file("/home/user/test.config") == True
    assert inventory_module_verify_file.verify_file("/home/user/test.txt") == False
    assert inventory_module_verify_file.verify_file("/home/user/test") == False

# Generated at 2022-06-25 09:41:03.077041
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse_0 = InventoryModule()
    assert inventory_module_parse_0.parse(inventory, loader, path, cache=cache) == None


# Generated at 2022-06-25 09:41:11.432064
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    def new_get_all_host_vars(host, loader, sources):
        return inventory_module_0.get_all_host_vars(host, loader, sources)
    inventory_module_0.get_all_host_vars = new_get_all_host_vars

    inventory_0 = BaseInventoryPlugin()
    loader_0 = get_vars_from_inventory_sources
    path_0 = ['foo.yml']
    def new_parse(inventory, loader, path, cache=False):
        return inventory_module_0.parse(inventory, loader, path, cache=cache)

    inventory_module_0.parse = new_parse
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=False)


# Generated at 2022-06-25 09:41:21.068694
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    # Test with known passes
    inventory_1 = InventoryModule()
    loader_1 = InventoryModule()
    path_1 = InventoryModule()
    cache_1 = False
    # inventory_module_0.parse(inventory_1, loader_1, path_1, cache_1)
    # Test with known fails
    inventory_2 = InventoryModule()
    loader_2 = InventoryModule()
    path_2 = InventoryModule()
    # cache_2 = False
    # inventory_module_0.parse(inventory_2, loader_2, path_2, cache_2)


# Generated at 2022-06-25 09:41:26.996867
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse(inventory, loader, ['inventory.config'])
    test_host_0 = inventory.hosts['127.0.0.1']
    ret_val = inventory_module_0.host_groupvars(test_host_0, loader, [])
    assert ret_val is not None


# Generated at 2022-06-25 09:41:36.364784
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module = InventoryModule()
    loader = None
    sources = []
    host = None


# Generated at 2022-06-25 09:41:38.629694
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_groupvars('host', 'loader', 'sources') == []


# Generated at 2022-06-25 09:41:39.990277
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse({'loader': {'_basedir': '.'}}, {'_basedir': '.'}, '.')

# Generated at 2022-06-25 09:41:49.508835
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    mock_host = {'vars': {'foo': 'bar'}}
    mock_host_class_instance = MagicMock()
    mock_host_class_instance.get_vars.return_value = mock_host['vars']

    inventory_module = InventoryModule()
    inventory_module.get_vars_from_inventory_sources = MagicMock()

    inventory_module.host_vars(mock_host_class_instance, None, None)

    assert mock_host['vars'] == inventory_module.host_vars(mock_host_class_instance, None, None)


# Generated at 2022-06-25 09:41:50.684589
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()



# Generated at 2022-06-25 09:41:53.663038
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Initialize the class
    inventory_module_0 = InventoryModule()

    # Initialize arguments for method test_case_0
    path = None

    # Invoke method
    response = inventory_module_0.verify_file(path)

    # Check for method response
    assert response is not None


# Generated at 2022-06-25 09:41:54.753436
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert(inventory_module.verify_file("ext") == False)


# Generated at 2022-06-25 09:41:57.761216
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    input_path_1 = './tests/test_inventory/hosts'
    output = inventory_module_1.verify_file(input_path_1)
    assert(output == True)


# Generated at 2022-06-25 09:42:02.857769
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # host_vars with the following parameters:
    #   host
    #   loader
    #   sources
    #
    # The results of the method should be stored in the "_result" attribute
    inventory_module_1 = InventoryModule()

    inventory_module_1._result = None
    return inventory_module_1


# Generated at 2022-06-25 09:42:06.186919
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse('inventory', 'loader', 'path', True)
    inventory_module_0.verify_file('path')



# Generated at 2022-06-25 09:42:23.480427
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    print('Inside test_InventoryModule_parse')
    inventory_module_0 = InventoryModule()

    print('Importing AnsibleInventory from ansible.inventory')
    from ansible.inventory import AnsibleInventory
    ansible_inventory_0 = AnsibleInventory()

    print('Importing DataLoader from ansible.parsing.dataloader')
    from ansible.parsing.dataloader import DataLoader
    data_loader_0 = DataLoader()
    print('Creating loader')
    loader_0 = data_loader_0.set_basedir('/home/noureddine/workspace/ansible/lib/ansible')

    print('Creating path')
    path_0 = './constructed_inventory.config'

    print('Creating cache')
    cache_0 = True


# Generated at 2022-06-25 09:42:25.215887
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory_module_1.parse()


# Generated at 2022-06-25 09:42:27.051819
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    assert inventory_module_1.host_groupvars is not None


# Generated at 2022-06-25 09:42:29.814394
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # check that a string without extension will fail
    inventory_module_0 = InventoryModule()
    valid = inventory_module_0.verify_file("test_string")
    assert not valid


# Generated at 2022-06-25 09:42:32.233600
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    print (inventory_module_0.host_vars())

if __name__ == '__main__':
    test_case_0()
    # test_InventoryModule_host_vars()

# Generated at 2022-06-25 09:42:37.986413
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_host_vars = InventoryModule()
    host_0 = dict()
    loader_0 = dict()
    sources_0 = dict()
    assert inventory_module_host_vars.host_vars(host_0, loader_0, sources_0) is None


# Generated at 2022-06-25 09:42:46.395505
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-25 09:42:51.019525
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Initializing test values
    inventory_mod_obj = InventoryModule()
    inventory_mod_obj.filename = "test.yml"
    expected_result = True
    actual_result = inventory_mod_obj.verify_file(inventory_mod_obj.filename)
    assert expected_result == actual_result


if __name__ == "__main__":
    test_case_0()
    test_InventoryModule_verify_file()

# Generated at 2022-06-25 09:42:53.454934
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:42:54.933999
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:43:14.329607
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    print('Test case started')
    inventory_module_0 = InventoryModule()
    host_0 = {'_vars': {}}

    # first execution with always invalid group name
    group_0 = 'invalid'
    loader_0 = {}
    sources_0 = ['ec2']
    result = inventory_module_0.host_groupvars(host_0, loader_0, sources_0)
    print('Result:',result)


# Generated at 2022-06-25 09:43:19.474147
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    test_parse_0 = inventory_module_1.parse
    test_parse_0(inventory_module_1, loader, path, cache=False)

# Generated at 2022-06-25 09:43:23.422982
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()
    test_cases = []
    test_cases.append(('ansible.cfg', False))
    test_cases.append(('inventory', False))
    test_cases.append(('inventory.config', True))
    test_cases.append(('inventory.yml', True))
    test_cases.append(('inventory.yaml', True))
    test_cases.append(('inventory.json', False))
    test_cases.append(('inventory.ini', False))
    for test_case in test_cases:
        if inventory_module.verify_file(test_case[0]) != test_case[1]:
            raise AssertionError("failed test case " + str(test_case))

# Generated at 2022-06-25 09:43:24.723848
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()



# Generated at 2022-06-25 09:43:27.989330
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()
try:
    test_InventoryModule_parse()
except Exception as e:
    print('Unit test failed: %s' % e)
    import sys
    sys.exit(1)

# Generated at 2022-06-25 09:43:36.192241
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    # test inventory_module
    inventory_module = InventoryModule()
    class MockHost:
        def get_vars(self):
            return dict()
    mock_host = MockHost()
    inventory_module.host_vars(mock_host, None, None)

    # test inventory_module_0
    inventory_module_0 = InventoryModule()
    class MockHost:
        def get_vars(self):
            return dict()
    mock_host = MockHost()
    inventory_module_0.host_vars(mock_host, None, None)

# Generated at 2022-06-25 09:43:38.641234
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module = InventoryModule()
    loader = None
    sources = []
    host = None
    result = inventory_module.host_vars(host, loader, sources)
    assert result is None


# Generated at 2022-06-25 09:43:45.152547
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_parse = InventoryModule()
    # The parameters
    inventory = "inventory"
    loader = "loader"
    path = "path"
    cache = "cache"
    actual_result = inventory_module_parse.parse(inventory, loader, path, cache)
    expected_result = None
    assert expected_result == actual_result


# Generated at 2022-06-25 09:43:51.038667
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    import ansible.inventory.host
    import ansible.vars.manager
    vars_manager = ansible.vars.manager.VariableManager()
    # Input parameters
    host = ansible.inventory.host.Host(name="localhost", port=None)
    # Output parameters
    result = host.get_vars()
    # Unit test
    assert result == {}


# Generated at 2022-06-25 09:43:52.614295
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars == 'host_vars'

# Generated at 2022-06-25 09:44:25.393830
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    host = Host('test_host')
    sources = None
    loader = DictDataLoader({})
    result = inventory_module_0.host_groupvars(host, loader, sources)
    assert result is None


# Generated at 2022-06-25 09:44:26.622272
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()

# Generated at 2022-06-25 09:44:29.058217
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = {} # dict
    loader = {} # dict
    path = "inventory.config"
    inventory_module.parse(inventory, loader, path)


# Generated at 2022-06-25 09:44:34.577493
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    inventory_module_0 = InventoryModule()
    loader_0 = None
    sources_0 = None
    host_0 = None

    host_groupvars_0 = inventory_module_0.host_groupvars(host_0, loader_0, sources_0)
    assert host_groupvars_0 == None

# Generated at 2022-06-25 09:44:39.911590
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    from ansible.inventory.host import Host
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.manager import VariableManager

    variables = {'foo': 'bar'}

    host = Host(name='testhost', port=22)
    variable_manager = VariableManager(loader=None, variables=variables)

    inventory_module_0 = InventoryModule()
    inventory_module_0.add_host(host, group=None)
    
    host_groupvars_value = inventory_module_0.host_groupvars(host, loader=None, sources=[])
    
    assert len(host_groupvars_value) == 1
    assert host_groupvars_value == {'foo': 'bar'}


# Generated at 2022-06-25 09:44:47.952441
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    # test case_0
    path = 'sample_file_name.txt'
    actual_result = inventory_module.verify_file(path)
    expected_result = False
    assert actual_result == expected_result, 'Test failed: {} != {}'.format(actual_result, expected_result)
    # test case_1
    path = 'sample_file_name.yaml'
    actual_result = inventory_module.verify_file(path)
    expected_result = True
    assert actual_result == expected_result, 'Test failed: {} != {}'.format(actual_result, expected_result)
    # test case_2
    path = 'sample_file_name.yml'
    actual_result = inventory_module.verify_file(path)

# Generated at 2022-06-25 09:44:49.410662
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars == False


# Generated at 2022-06-25 09:44:54.571424
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = object()
    cache_0 = object()

    # Call method InventoryModule.parse (line: 15)
    # Call method BaseInventoryPlugin.parse (line: 293)
    args = (inventory_0, loader_0, path_0, )
    kwargs = {'cache': cache_0}
    inventory_module_0.parse(*args, **kwargs)


# Generated at 2022-06-25 09:44:56.420200
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    result = inventory_module_0.host_groupvars(loader, sources)
    assert result is None


# Generated at 2022-06-25 09:45:04.749166
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import json
    import sys
    import os
    from unittest.mock import patch
    from io import StringIO
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import inventory_loader
    #from ansible.module_utils._text import to_text
    
    sys.modules['ansible.module_utils.facts.system.base'] = None
    sys.modules['ansible.module_utils.facts.system.linux'] = None
    sys.modules['ansible.module_utils.facts.system.freebsd'] = None
    sys.modules['ansible.module_utils.facts.system.netbsd'] = None
    sys.modules['ansible.module_utils.facts.system.openbsd'] = None

# Generated at 2022-06-25 09:46:51.769008
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.host_vars()

# Generated at 2022-06-25 09:46:53.049646
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()


# Generated at 2022-06-25 09:46:54.744789
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    assert None != inventory_module_1.host_groupvars(None, None, None)


# Generated at 2022-06-25 09:47:00.091271
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # GIVEN
    inventory_module = InventoryModule()
    inventory = AnsibleParserError()
    loader = AnsibleOptionsError()
    path = to_native()
    cache = False

    # WHEN
    inventory_module.parse(inventory, loader, path, cache=cache)

# Generated at 2022-06-25 09:47:05.374194
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file('') == False


# Generated at 2022-06-25 09:47:06.904106
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_1 = InventoryModule()
    host = Host()
    loader = None
    sources = []
    inventory_module_1.host_vars(host, loader, sources)

# Generated at 2022-06-25 09:47:11.303794
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    inventory_module_0.verify_file('inventory.config')


# Generated at 2022-06-25 09:47:18.891997
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    inventory_module_1 = InventoryModule()
    host_obj = Host(name='test_host')
    host_obj.vars = { 'foo': 'bar' }
    assert True == isinstance(inventory_module_1.host_vars(host_obj, None, None), dict)
    assert inventory_module_1.host_vars(host_obj, None, None) == { 'foo': 'bar' }


# Generated at 2022-06-25 09:47:21.063702
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory = InventoryModule()
    inventory.parse(inventory, None, "/home/user/inventory.config", cache=False)

    inventory_module = InventoryModule()
    inventory_module.host_groupvars(inventory.get_host('public_dns_name'), None, [])


# Generated at 2022-06-25 09:47:24.136212
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:50:02.046056
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()

    # set up params
    inventory = None
    loader = None
    path = None
    cache = False

    # call method to test on
    inventory_module_1.parse(inventory, loader, path, cache)


if __name__ == '__main__':
    import sys

# parse input arguments
    if not len(sys.argv) > 1:
        test_case_0()
    else:
        print(sys.argv)
        for arg in sys.argv[1:]:
            if arg == 'parse':
                test_InventoryModule_parse()

# Generated at 2022-06-25 09:50:04.396897
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test with parameters path=None
    inventory_module_0 = InventoryModule()
    assert inventory_module_0.verify_file(path=None) == False
    assert inventory_module_0.parse(inventory=None, loader=None, path=None, cache=False) == None


# Generated at 2022-06-25 09:50:07.690263
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module = InventoryModule()
    inventory_module.host_vars('host', 'loader', 'sources')

# Generated at 2022-06-25 09:50:09.878004
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_1 = InventoryModule()
    inventory = inventory_module_1.name
    loader = inventory_module_1.loader
    path = inventory_module_1.name
    cache = False
    inventory_module_1.parse(inventory, loader, path, cache=cache)

# Generated at 2022-06-25 09:50:17.425720
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():

    inventory_module_0 = InventoryModule()

    host_0 = {'name': 'foo', 'groups': ['bar', 'baz']}
    loader_0 = {}
    sources_0 = [{'path': 'foo', 'host_groups': {'bar': {'vars': 'foo'}, 'baz': {'vars': 'foo'}}}]

    assert isinstance(inventory_module_0.host_groupvars(host_0, loader_0, sources_0), dict)


# Generated at 2022-06-25 09:50:20.614021
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()

# Generated at 2022-06-25 09:50:24.730229
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module = InventoryModule()
    inventory_module.parse('test_inventory', 'loader', 'test_config_file')
    assert inventory_module.host_vars('test_host', 'loader', []) == 'test_host_vars'


# Generated at 2022-06-25 09:50:29.046201
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    variables = dict()
    variables['a'] = 'a'
    variables['b'] = 'b'

    loader = DictDataLoader({
        'group_vars/all': 'all: {}',
        'group_vars/groupA': 'a: a2',
        'group_vars/groupB': 'b: b2',
        'group_vars/groupC': 'c: c',
        'host_vars/host1': 'a: a3',
        'host_vars/host2': 'b: b3',
        'host_vars/host3': 'c: c',
    })
    loader_mock = MockLoader(loader)