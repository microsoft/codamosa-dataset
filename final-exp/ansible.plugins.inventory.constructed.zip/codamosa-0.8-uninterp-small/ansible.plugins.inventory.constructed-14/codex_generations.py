

# Generated at 2022-06-25 09:40:36.126696
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    inventory_module_0 = InventoryModule()
    assert inventory_module_0.host_vars(host_0, loader_0, sources_0) == dict()


# Generated at 2022-06-25 09:40:45.430149
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    import pytest

    # examples and expected results

# Generated at 2022-06-25 09:40:49.821709
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory = None
    loader = None
    path = '../../tests/inventory/host_vars/host_vars_1'
    cache = False
    inventory_module.parse(inventory, loader, path, cache)


# Generated at 2022-06-25 09:40:52.572482
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    host_1 = Host()

    """Test invoke host_groupvars() of InventoryModule with normal input arguments """
    inventory_module_1.host_groupvars(host_1, None, None)


# Generated at 2022-06-25 09:40:53.845831
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    set_0 = set()


# Generated at 2022-06-25 09:41:00.139065
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_host_vars_0 = InventoryModule()
    # pre - conditions
    inventory = None
    loader = None
    sources = None
    from ansible.vars.hostvars import HostVars
    host = HostVars()
    inventory = inventory
    loader = loader
    sources = sources
    inventory_module_host_vars_0.host_vars(host, loader, sources)


# Generated at 2022-06-25 09:41:08.632540
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Create an instance of class InventoryModule
    inventory_module_0 = InventoryModule()

    # Set members of the class
    inventory_module_0.config_data = {}
    inventory_module_0.group_patterns = {}
    inventory_module_0.groups = {}
    inventory_module_0.plugin_type_name = "inventory"

    # Create a new instance of class Inventory
    inventory_0 = InventoryModule()

    # Set members of the class
    inventory_0.host_patterns = {}
    inventory_0.hosts = {}
    inventory_0.parser = object()
    inventory_0.parse_cache = {}
    inventory_0.patterns = {}

    # Create a new instance of class DataLoader
    data_loader_0 = InventoryModule()

    # Set members of the class
    data_loader_

# Generated at 2022-06-25 09:41:12.223318
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryManager(loader=None, sources=[])
    inventory_module_0.parse(inventory_0, None, "/usr/lib/python3/dist-packages/ansible/modules/network/nxos/nxos_ospf.py")


# Generated at 2022-06-25 09:41:17.024500
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Input params
    inventory_module_0 = InventoryModule()
    inventory_1 = inventory_module_0
    loader_2 = inventory_module_0
    path_3 = ''
    cache_4 = False

    test_inventory_module = InventoryModule()
    try:
        test_inventory_module.parse(inventory_1, loader_2, path_3, cache_4)
    except:
        pass


if __name__ == '__main__':
    test_case_0()

    test_InventoryModule_parse()

# Generated at 2022-06-25 09:41:20.219277
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():

    inventory_module_0 = InventoryModule()

    # TODO: implement proper testing
    host_0 = "host = None"
    loader_0 = None
    sources_0 = None

    try:
        inventory_module_0.host_vars(host_0, loader_0, sources_0)
    except:
        assert False


# Generated at 2022-06-25 09:41:30.226705
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = ''
    inventory_module_0.verify_file(path_0)


# Generated at 2022-06-25 09:41:34.222070
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = InventoryModule()
    loader_0 = AnsibleLoader()
    path_0 = load_fixture_file('construct.config')
    print('parse(): ', InventoryModule.parse)
    try:
        inventory_module_0.parse(inventory_0, loader_0, path_0)
    except AnsibleParserError as e:
        print('AnsibleParserError:', e)


# Generated at 2022-06-25 09:41:36.211149
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = None
    inventory_module_0 = InventoryModule()
    inventory = None
    loader = None
    cache = False
    inventory_module_0.parse(inventory, loader, path, cache=cache)


# Generated at 2022-06-25 09:41:40.061608
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Host()
    loader_0 = DataLoader()
    path_0 = ''

    # Call method parse
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=False)


# Generated at 2022-06-25 09:41:41.105106
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_case_0()

# Generated at 2022-06-25 09:41:51.896254
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_module_0.options = {'plugin': 'constructed'}
    inventory_module_0.cache = {'results': {}, 'failures': {}, 'skipped': {}, 'successes': {}}
    inventory_module_1 = InventoryModule()
    inventory_module_1.options = {'plugin': 'constructed'}
    inventory_module_1.cache = {'results': {}, 'failures': {}, 'skipped': {}, 'successes': {}}
    inventory_module_0.cache.get('results')['hostvars'] = {'hostvars': {}}
    inventory_module_1.cache.get('results')['hostvars'] = {'hostvars': {}}

# Generated at 2022-06-25 09:41:57.962598
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # Test default results
    inventory_module_1 = InventoryModule()
    inventory_module_2 = InventoryModule()
    inventory_module_2.options = {'use_vars_plugins': False}
    inventory_module_3 = InventoryModule()
    inventory_module_3.options = {'use_vars_plugins': False}
    inventory_module_4 = InventoryModule()
    inventory_module_5 = InventoryModule()
    inventory_module_5.options = {'use_vars_plugins': False}
    inventory_module_6 = InventoryModule()
    inventory_module_6.options = {'use_vars_plugins': False}

    # Test for path to a file

# Generated at 2022-06-25 09:42:01.835049
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    set_0 = set()
    set_1 = set()
    set_2 = set()
    set_3 = set()

    #
    # TODO: test code here
    #


# Generated at 2022-06-25 09:42:10.562182
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.utils.vars import combine_vars

    inventory_module_1 = InventoryModule()
    host_1 = 'host'
    loader_1 = object()
    sources_1 = object()

    # For inventory_module_1.get_all_host_vars():
    inventory_module_1.use_vars_plugins = True

    # For inventory_module_1.host_groupvars():
    inventory_module_1.use_vars_plugins = True
    # For inventory_module_1.host_vars():
    inventory_module_1.use_vars_plugins = True

    with pytest.raises(AnsibleOptionsError):
        inventory_module_1.host_vars(host_1, loader_1, sources_1)
    inventory_module_1.use_v

# Generated at 2022-06-25 09:42:11.309834
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:42:21.273666
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    set_0 = set()


# Generated at 2022-06-25 09:42:25.454382
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = 'host_0'
    loader_0 = 'loader_0'
    sources_0 = 'sources_0'
    inventory_module_0.host_vars(host_0, loader_0, sources_0)


# Generated at 2022-06-25 09:42:32.496809
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    # Initialization of inventory module
    inventory_module_1 = InventoryModule()
    # Module initialization of the fact_cache.FactCache class
    fact_cache_1 = FactCache()
    # Declaration of variables
    host_1 = host
    loader_1 = loader
    sources_1 = sources
    # Initialization of the fact_cache.FactCache class
    fact_cache_2 = FactCache()
    # Initialization of the fact_cache.FactCache class
    fact_cache_3 = FactCache()
    # Call to the function host_vars of the class InventoryModule
    return inventory_module_1.host_vars(host_1, loader_1, sources_1)


# Generated at 2022-06-25 09:42:38.944898
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    set_0 = set()
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    loader_0 = BaseInventoryPlugin()
    # Test exception catch with try statement
    try:
        inventory_module_0.host_vars(set_0, loader_0, inventory_0)
    except TypeError:
        pass
    return


# Generated at 2022-06-25 09:42:41.439525
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    set_0 = set()
    inventory_module_0 = InventoryModule()
    sources = []
    loader = None
    host = None
    inventory_module_0.get_all_host_vars(host, loader, sources)


# Generated at 2022-06-25 09:42:47.164592
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    host = Mock()
    loader = Mock()
    sources = set()

    # Call InventoryModule.host_groupvars
    inventory_module_0.host_groupvars(host, loader, sources)


# Generated at 2022-06-25 09:42:50.121344
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    group_0 = 'group_0'
    group_1 = 'group_1'
    set_0 = set()
    inventory_module_0.host_vars(group_0, group_1, set_0)


# Generated at 2022-06-25 09:42:55.659679
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory()
    loader_0 = Loader()
    path_0 = ''
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache=cache_0)

# Generated at 2022-06-25 09:42:56.997854
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:43:02.263836
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    host_0 = Host()
    loader_0 = DataLoader()
    sources_0 = []
    try:
        host_groupvars_0 = inventory_module_0.host_groupvars(host_0, loader_0, sources_0)
    except Exception as e_0:
        print(e_0)


# Generated at 2022-06-25 09:43:16.768923
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Test class InventoryModule

# Generated at 2022-06-25 09:43:18.542899
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_obj_0 = InventoryModule()

    # Call method parse of class InventorModule with required arguments.
    inventory_module_obj_0.parse(inventory_module_obj_0)

    # Test cases


# Generated at 2022-06-25 09:43:20.378092
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    set_1 = set()
    assert set_1 == inventory_module_1.host_groupvars(set_1, set_1, set_1)


# Generated at 2022-06-25 09:43:28.260721
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    set_0 = set()
    loader_0 = DataLoader()
    sources_0 = []
    host_0 = Host()
    host_0.set_name(u'webservers')
    host_0.set_hostname(u'ec2-107-23-40-83.compute-1.amazonaws.com')
    host_0.set_variables(None)
    host_0.set_groups(None)
    host_0.set_port(22)
    host_0.set_not_port(None)
    host_0.set_vars_files(None)
    host_0.set_vars_dir(None)
    host_0.set_connection_options(None)
    result_0 = inventory_module_0

# Generated at 2022-06-25 09:43:31.543815
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    #
    # tests InventoryModule.host_groupvars() without exception raised
    #
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()
    #
    # tests InventoryModule.host_groupvars() with exception raised
    #
    inventory_module_0 = InventoryModule()
    inventory_module_0.parse()


# Generated at 2022-06-25 09:43:33.795994
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = Host()
    loader_0 = DataLoader()
    sources_0 = []
    inventory_module_0.host_vars(host_0, loader_0, sources_0)


# Generated at 2022-06-25 09:43:39.756062
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    loader_0 = None
    sources_0 = None
    sources_1 = None
    host_0 = None

    # Call InventoryModule.host_groupvars(host, loader, sources)
    try:
        inventory_module_1.host_groupvars(host_0, loader_0, sources_0)
        inventory_module_1.host_groupvars(host_0, loader_0, sources_1)
    except Exception as e:
        print("Method InventoryModule.host_groupvars() raised an exception: {}".format(e))



# Generated at 2022-06-25 09:43:43.956896
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = object()
    loader_0 = object()
    path_0 = object()
    inventory_module_0.parse(inventory_0, loader_0, path_0)


# Generated at 2022-06-25 09:43:47.835497
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = None
    cache_0 = False
    inventory_module.parse(inventory_0, loader_0, path_0, cache=cache_0)


# Generated at 2022-06-25 09:43:51.550598
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = "path"
    ret_0 = inventory_module_0.verify_file(path_0)
    assert ret_0 is True


# Generated at 2022-06-25 09:44:20.817855
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()


# Generated at 2022-06-25 09:44:26.582059
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = BaseInventoryPlugin()
    loader_0 = Constructable()
    path_0 = ""
    set_0 = set()
    # Python3 code
    # inventory_module_0.parse(inventory_0, loader_0, path_0)

# Generated at 2022-06-25 09:44:30.058225
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    loader_0 = Vars()
    sources_0 = set()
    host_0 = Host(name = "test_host", port = 1)
    print(inventory_module_0.host_groupvars(host_0, loader_0, sources_0))


# Generated at 2022-06-25 09:44:39.938674
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    path_0 = 'inventory.config'
    path_1 = 'inventory.yml'
    path_2 = 'inventory.yaml'
    path_3 = 'inventory.cfg'
    # Test for path_0 (valid extension)
    assert inventory_module_0.verify_file(path_0) == True
    # Test for path_1 (valid extension)
    assert inventory_module_0.verify_file(path_1) == True
    # Test for path_2 (valid extension)
    assert inventory_module_0.verify_file(path_2) == True
    # Test for path_3 (valid extension)
    assert inventory_module_0.verify_file(path_3) == True


# Generated at 2022-06-25 09:44:43.087100
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = None
    loader_0 = None
    path_0 = None
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:44:48.486627
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = host()
    loader_0 = loader()
    set_0 = set()
    inventory_module_0.host_vars(host_0, loader_0, set_0)


# Generated at 2022-06-25 09:44:49.269641
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    pass


# Generated at 2022-06-25 09:44:56.907797
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    for ansible_hostname in [ 'host_0', 'host_1', 'host_2' ]:
        for host_vars in [ { 'host_var_0': 'host_var_value_0' }, { 'host_var_0': 'host_var_value_1' } ]:
            for loader_0 in [ None, object() ]:
                for sources_0 in [ [], [ None, object() ] ]:
                    set_0 = set()
                    inventory_module_0 = InventoryModule()

# Generated at 2022-06-25 09:45:03.856412
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    host_0 = {'ansible_host': 'host_0', 'some_var': 'some_value', 'ip_address': 'ip_address_0'}
    sources_0 = []
    loader_0 = 'loader_0'
    expected_0 = {'some_var': 'some_value', 'ip_address': 'ip_address_0'}
    actual_0 = inventory_module_0.host_vars(host_0, loader_0, sources_0)
    assert actual_0 == expected_0


# Generated at 2022-06-25 09:45:10.383894
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    inventory_module_0 = InventoryModule()
    loader_0 = 0
    sources_0 = {}
    for method in dir(InventoryModule):
        if method == "host_vars":
            assert 0 == inventory_module_0.host_vars(loader_0, sources_0)
        else:
            throwException("Attribute %s not found in InventoryModule" % method)


# Generated at 2022-06-25 09:46:32.431627
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # check if get_option returns an instance of the object

    inventory_module = InventoryModule()
    inventory_module.get_option('plugin')

    # check if verify_file returns bool value

    inventory_module = InventoryModule()
    assert isinstance(inventory_module.verify_file('inventory.config'), bool)

    # check if get_all_host_vars returns a dict

    inventory_module = InventoryModule()
    loader, sources = None, None
    assert isinstance(inventory_module.get_all_host_vars('host', loader, sources), dict)

    # check if host_groupvars returns a dict

    inventory_module = InventoryModule()
    loader, sources = None, None
    assert isinstance(inventory_module.host_groupvars('host', loader, sources), dict)

    # check if host_v

# Generated at 2022-06-25 09:46:33.781861
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    set_0 = set()

# Generated at 2022-06-25 09:46:37.240714
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    set_0 = test_case_0()

# Generated at 2022-06-25 09:46:39.388846
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_0 = InventoryModule()
    inventory_0 = Inventory()
    loader_0 = DataLoader()
    path_0 = "path"
    cache_0 = False
    inventory_module_0.parse(inventory_0, loader_0, path_0, cache_0)


# Generated at 2022-06-25 09:46:41.337735
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_0 = InventoryModule()
    str_0 = "path"
    inventory_module_0.verify_file(str_0)
    inventory_module_0._display.display("message", color='CYAN')


# Generated at 2022-06-25 09:46:43.097931
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_1 = InventoryModule()
    path_1 = "inventory.config"
    assert inventory_module_1.verify_file(path_1) == True


# Generated at 2022-06-25 09:46:51.590189
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # attempt to parse with bad ext
    fake_path = 'path/to/file.foo'
    fake_inventory = type('', (object,), {'hosts': {'fake_host': {}}})
    fake_loader = type('', (object,), {})()

    assert not InventoryModule().verify_file(fake_path)
    with pytest.raises(AnsibleParserError):
        InventoryModule().parse(fake_inventory, fake_loader, fake_path)

    # attempt to parse with empty data
    fake_path = 'path/to/file.yml'
    fake_inventory = type('', (object,), {'hosts': {'fake_host': {}}})
    fake_loader = type('', (object,), {})()
    assert InventoryModule().verify_file(fake_path)

# Generated at 2022-06-25 09:46:55.636054
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    set_0 = set()
    set_0.add('hello')
    set_0.add(4)
    set_0.add(True)
    set_0.add(0.0)
    set_0.add(False)
    inventory_module_0.host_groupvars(set_0, set_0, set_0)


# Generated at 2022-06-25 09:47:00.137544
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_0 = InventoryModule()
    host_0 = {'groups': {}}
    loader_0 = {}
    sources_0 = {}
    assert inventory_module_0.host_groupvars(host_0, loader_0, sources_0) == {}


# Generated at 2022-06-25 09:47:05.373210
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    inventory_module_1 = InventoryModule()
    assert isinstance(inventory_module_1.host_groupvars(), dict)
