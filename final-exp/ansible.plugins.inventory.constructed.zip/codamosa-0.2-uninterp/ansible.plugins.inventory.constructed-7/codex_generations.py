

# Generated at 2022-06-17 11:44:25.314575
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # create host
    host = Host(name="foobar")
    host.vars = {
        'var1': 1,
        'var2': 2,
        'ec2_tags': {
            'devel': 'true'
        }
    }
    inv_manager.add_host(host)

    # create group

# Generated at 2022-06-17 11:44:31.748418
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    import os
    import json
    import sys
    import shutil

    class CallbackModule(CallbackBase):
        """
        Callback module for use by Unit tests
        """

# Generated at 2022-06-17 11:44:43.151129
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='group1')
    group.vars = {'groupvar1': 'groupvar1_value'}
    host.set_variable('hostvar1', 'hostvar1_value')
    host.add_group(group)
    inventory.add_group(group)


# Generated at 2022-06-17 11:44:56.053995
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create host
    host = Host(name="localhost")
    host.set_variable('var1', 1)
    host.set_variable('var2', 2)
    host.set_variable('ansible_hostname', 'localhost')
    host.set_variable('ansible_distribution', 'CentOS')

# Generated at 2022-06-17 11:45:06.294319
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    host.set_variable('ansible_hostname', 'localhost')

# Generated at 2022-06-17 11:45:16.553763
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.plugins.loader import inventory_loader, vars_loader, strategy_loader
    from ansible.plugins.callback import CallbackBase
    from ansible.template import Templar
    import os
    import yaml
    import json
    import shutil


# Generated at 2022-06-17 11:45:28.172271
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    host.set_variable('ansible_hostname', 'localhost')
    host.set_variable('ansible_connection', 'local')
    host.set_variable('ansible_python_interpreter', '/usr/bin/python')
    host.set_variable('ansible_python_version', '2.7.5')

# Generated at 2022-06-17 11:45:40.561901
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    inventory.set_variable_manager(variable_manager)

    im = InventoryModule()
    im.parse(inventory, loader, 'localhost,')

# Generated at 2022-06-17 11:45:51.514110
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create constructed plugin
    constructed_plugin = InventoryModule()
    constructed_plugin.parse(inventory, loader, 'test/inventory/constructed.config')

    # create groups
    group_all = Group('all')
    group_webservers = Group('webservers')
    group_development = Group('development')

# Generated at 2022-06-17 11:46:03.372793
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/test_inventory_constructed'])
    inv = inv_manager.get_inventory()
    assert inv.get_host('host1').get_vars()['var_sum'] == 3
    assert inv.get_host('host1').get_vars()['server_type'] == 'web'
    assert inv.get_host('host2').get_vars()['server_type'] == 'db'
    assert inv.get_host('host3').get_vars()['server_type'] == 'db'
    assert inv.get_host('host4').get_vars()['server_type']

# Generated at 2022-06-17 11:46:16.748806
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # Create a host
    host = Host(name="foobar")
    inv_manager.add_host(host)

    # Create a constructed inventory plugin
    constructed_plugin = InventoryModule()
    constructed_plugin.parse(inv_manager, loader, 'constructed.config', cache=False)

    # Test if the constructed plugin has created the group 'testgroup'
    assert 'testgroup' in inv_manager.groups

# Generated at 2022-06-17 11:46:20.915089
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('inventory.config')
    assert module.verify_file('inventory.yaml')
    assert module.verify_file('inventory.yml')
    assert module.verify_file('inventory.json')
    assert module.verify_file('inventory')
    assert not module.verify_file('inventory.txt')

# Generated at 2022-06-17 11:46:32.141847
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])

# Generated at 2022-06-17 11:46:40.497733
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inventory = VariableManager()
    host = Host(name='testhost')
    host.vars = {'testvar': 'testvalue'}
    inventory.add_host(host)

    plugin = InventoryModule()
    plugin.parse(inventory, loader, 'testhost')
    assert plugin.host_vars(host, loader, []) == {'testvar': 'testvalue'}

# Generated at 2022-06-17 11:46:43.957604
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('inventory.config')
    assert inventory_module.verify_file('inventory.yml')
    assert inventory_module.verify_file('inventory.yaml')
    assert not inventory_module.verify_file('inventory.txt')

# Generated at 2022-06-17 11:46:55.985369
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)
    inventory.set_variable_manager(variable_manager)

# Generated at 2022-06-17 11:47:07.193073
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name="test_host")
    group = Group(name="test_group")
    group.add_host(host)
    inventory.add_group(group)

    inventory_plugin = inventory_loader.get('constructed')
    inventory_plugin.parse(inventory, loader, '', cache=False)

    assert inventory_

# Generated at 2022-06-17 11:47:12.908830
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test with valid file
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("inventory.config")

    # Test with invalid file
    assert not inventory_module.verify_file("inventory.txt")

# Generated at 2022-06-17 11:47:20.902413
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/path/to/inventory.config')
    assert inventory_module.verify_file('/path/to/inventory.yml')
    assert inventory_module.verify_file('/path/to/inventory.yaml')
    assert inventory_module.verify_file('/path/to/inventory.yaml.j2')
    assert not inventory_module.verify_file('/path/to/inventory.txt')

# Generated at 2022-06-17 11:47:29.494746
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.group import Group
    from ansible.vars.hostvars import HostVars
    from ansible.vars.hostvars import HostVarsVars
    from ansible.vars.hostvars import HostVars

# Generated at 2022-06-17 11:47:44.847137
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group1')
    group.vars = {'group_var': 'group_var_value'}
    host.add_group(group)

    inventory_module = InventoryModule()
    inventory_module.set_options({'use_vars_plugins': True})

    host_groupvars = inventory_module.host_

# Generated at 2022-06-17 11:47:54.160876
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    host.set_variable('foo', 'bar')
    group = Group(name='group1')
    group.set_variable('foo', 'baz')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)
    im = InventoryModule()
    im.set_

# Generated at 2022-06-17 11:47:58.193670
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test with a file that has a valid extension
    assert InventoryModule().verify_file('inventory.config') == True

    # Test with a file that has an invalid extension
    assert InventoryModule().verify_file('inventory.yaml') == False

# Generated at 2022-06-17 11:48:07.833378
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    # Create a host
    host = Host(name='test_host')

    # Create a group
    group = Group(name='test_group')

    # Add the host to the group
    group.add_host(host)

    # Create a variable manager
    variable_manager = VariableManager()

    # Create a loader
    loader = DataLoader()

    # Create an inventory manager
    inventory = InventoryManager(loader=loader, sources=['localhost,'])

    # Add the group to the inventory
    inventory.add_

# Generated at 2022-06-17 11:48:15.994056
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('/path/to/inventory.config')
    assert inventory_module.verify_file('/path/to/inventory.yaml')
    assert inventory_module.verify_file('/path/to/inventory.yml')
    assert inventory_module.verify_file('/path/to/inventory')
    assert not inventory_module.verify_file('/path/to/inventory.txt')

# Generated at 2022-06-17 11:48:27.058173
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # create a host
    host = Host(name="foobar")
    # set some host variables
    host.vars = {'ansible_ssh_host': '127.0.0.1', 'ansible_ssh_port': 22, 'ansible_ssh_user': 'root'}
    # add host to group

# Generated at 2022-06-17 11:48:36.273359
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)

    plugin = inventory_loader.get('constructed')
    plugin.parse(inventory, loader, 'localhost,')


# Generated at 2022-06-17 11:48:44.829460
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.utils.display import Display
    from ansible.utils.vars import load_extra_vars
    from ansible.utils.vars import load_options_vars
    from ansible.utils.vars import load_options

# Generated at 2022-06-17 11:48:55.921849
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    inventory.set_variable_manager(variable_manager)

    plugin = InventoryModule()
    plugin.parse(inventory, loader, '', cache=False)
    assert plugin.host_group

# Generated at 2022-06-17 11:49:01.651035
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # create a host
    host = Host(name="testhost")
    host.set_variable('ansible_distribution', 'CentOS')
    host.set_variable('ansible_distribution_major_version', '7')
    host.set_variable('ansible_distribution_version', '7.4.1708')

# Generated at 2022-06-17 11:49:17.443196
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader

    # Create a host
    host = Host(name='testhost')
    host.set_variable('var1', 'value1')
    host.set_variable('var2', 'value2')

    # Create a loader
    loader = DataLoader()

    # Create an inventory
    inventory = InventoryManager(loader=loader, sources='')
    inventory.add_host(host)

    # Create a variable manager
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a constructed plugin

# Generated at 2022-06-17 11:49:28.958425
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    host = Host(name='localhost')
    group = Group(name='group')
    host.set_variable('ansible_distribution', 'CentOS')
    host.set_variable('ansible_architecture', 'x86_64')

# Generated at 2022-06-17 11:49:40.134709
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.plugins.loader import vars_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)

    # Create a group_vars directory

# Generated at 2022-06-17 11:49:47.920648
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    groups = [Group('group1'), Group('group2')]
    host = Host(name='testhost', groups=groups)
    inventory = VariableManager()
    inventory.add_host(host)
    inventory.add_group(groups[0])
    inventory.add_group(groups[1])
    inventory.set_variable(host, 'group1', 'group1_var')
    inventory.set_variable(host, 'group2', 'group2_var')
    inventory.set_variable(host, 'host', 'host_var')

# Generated at 2022-06-17 11:49:58.852014
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    # create host
    host = Host(name="test_host")
    host.vars = {'var1': 1, 'var2': 2, 'var3': 3}
    inv_manager.add_host(host)

    # create group
    group = Group(name="test_group")

# Generated at 2022-06-17 11:50:08.346826
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.display import Display
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.inventory import BaseInventoryPlugin, Constructable
    from ansible.plugins.loader import inventory_loader

# Generated at 2022-06-17 11:50:19.595274
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create host
    host = Host(name="localhost")
    host.set_variable('ansible_distribution', 'CentOS')
    host.set_variable('ansible_distribution_version', '7.4.1708')
    host.set_variable('ansible_architecture', 'x86_64')

# Generated at 2022-06-17 11:50:30.173611
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    from ansible.utils.display import Display
    import json


# Generated at 2022-06-17 11:50:42.163861
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['/dev/null'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    host = Host(name="test_host")
    group = Group(name="test_group")
    group.add_host(host)
    inv_manager.add_group(group)

    plugin = InventoryModule()
    plugin.parse(inv_manager, loader, 'test_inventory.config', cache=False)


# Generated at 2022-06-17 11:50:52.386396
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    host.set_variable('ansible_hostname', 'localhost')
    host.set_variable('ansible_ssh_host', 'localhost')
    host.set_variable('ansible_ssh_port', 22)
    host.set_variable('ansible_ssh_user', 'root')
    host.set_variable('ansible_ssh_pass', 'password')

# Generated at 2022-06-17 11:51:21.365794
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    import unittest
    import ansible.plugins.loader as plugin_loader
    import ansible.inventory.manager as inventory_manager
    import ansible.inventory.host as inventory_host
    import ansible.vars.manager as vars_manager
    import ansible.vars.host_vars as host_vars
    import ansible.vars.host_group_vars as host_group_vars
    import ansible.vars.plugins.host_group_vars as host_group_vars_plugin
    import ansible.vars.plugins.host_vars as host_vars_plugin
    import ansible.vars.plugins.group_vars as group_vars_plugin
    import ansible.vars.plugins.yaml as yaml_plugin
    import ansible.vars.plugins.ini

# Generated at 2022-06-17 11:51:33.644511
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    # Create a host
    host = Host(name='testhost')
    host.vars = {'var1': 'value1', 'var2': 'value2'}
    host.groups = [Group(name='group1'), Group(name='group2')]

    # Create a loader
    loader = DataLoader()

    # Create a variable manager
    variable_manager = VariableManager()

    # Create an inventory manager

# Generated at 2022-06-17 11:51:43.285158
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    host.vars = {'var1': 'value1'}
    inventory.add_host(host)
    group = Group(name='group1')
    group.vars = {'var2': 'value2'}
    inventory.add_group(group)
    host.set_groups([group])

    im = InventoryModule()
    im

# Generated at 2022-06-17 11:51:48.321137
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    host = Host(name='localhost')
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    host.set_variable('ansible_ssh_port', '22')
    host.set_variable('ansible_ssh_user', 'root')
    host.set_variable('ansible_ssh_pass', 'password')
    inv_manager.add_host(host)

   

# Generated at 2022-06-17 11:51:59.818762
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['tests/inventory/host_vars_inventory'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    host = Host(name='test_host')
    inv_manager.add_host(host, 'test_group')
    inv_manager.add_host(host, 'test_group2')
    inv_manager.add_host(host, 'test_group3')
    inv_manager.add_host(host, 'test_group4')

# Generated at 2022-06-17 11:52:04.834402
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Add new group
    g1 = Group('g1')
    inventory.add_group(g1)

    # Add new host to g1
    h1 = Host('h1')
    h1.set_variable('ansible_host', '127.0.0.1')
    h1.set_variable('ansible_port', '22')
    h1

# Generated at 2022-06-17 11:52:11.678542
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    inv_manager.parse_sources()
    host = Host(name='localhost')
    host.set_variable('ansible_host', '127.0.0.1')
    host.set_variable('ansible_connection', 'local')
    inv_manager.add_host(host)
    inv_manager.add_group('all')
    inv_manager.add_child('all', host)
    inv_manager.set_variable_manager(VariableManager())
    inv_manager.set_host

# Generated at 2022-06-17 11:52:22.067371
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    plugin = inventory_loader.get('constructed')
    plugin.parse(inv_manager, loader, 'localhost,')

    assert inv_manager.get_host('localhost').get_vars()['var_sum'] == 3
    assert inv_manager.get_group('webservers').get_hosts()[0].name == 'localhost'
    assert inv_manager.get_group('private_only').get_

# Generated at 2022-06-17 11:52:28.983166
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)

    host = Host(name='localhost')
    host.set_variable('ansible_ssh_host', '127.0.0.1')
    host.set_variable('ansible_ssh_port', 22)
    host.set_variable('ansible_ssh_user', 'root')
    host.set_variable('ansible_ssh_pass', 'password')
   

# Generated at 2022-06-17 11:52:38.538808
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    host = Host(name='localhost')
    group = Group(name='group1')
    group.vars = {'group_var': 'group_var_value'}
    host.set_variable('host_var', 'host_var_value')
    host.add_group(group)

    inventory_module = InventoryModule()

# Generated at 2022-06-17 11:53:15.297278
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # create a host
    host = Host(name="foobar")
    host.vars = {'ansible_distribution': 'CentOS'}
    inventory.add_host(host)

    # create a group
    group = Group(name="foogroup")
    group.vars = {'ansible_distribution': 'CentOS'}
    inventory

# Generated at 2022-06-17 11:53:20.837333
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='group1')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-17 11:53:32.604791
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.plugins.strategy import StrategyBase
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.vars import combine_vars
    from ansible.plugins.loader import add_all_plugin_dirs
    from ansible.plugins.loader import add_directory
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.plugins.inventory.constructed import Inventory

# Generated at 2022-06-17 11:53:41.265795
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.plugins.callback import CallbackBase
    import json
    import os
    import shutil
    import tempfile
    import pytest


# Generated at 2022-06-17 11:53:52.208763
# Unit test for method host_groupvars of class InventoryModule
def test_InventoryModule_host_groupvars():
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    host = Host(name='localhost')
    group = Group(name='all')
    group.add_host(host)
    inventory.add_group(group)
    inventory.add_host(host)
    variable_manager.set_inventory(inventory)

    plugin = inventory_loader.get('constructed')
    plugin.parse(inventory, loader, 'localhost,')



# Generated at 2022-06-17 11:54:04.297296
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test_constructed_inventory.config'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Test the group 'webservers'
    group = inventory.groups['webservers']
    assert group.name == 'webservers'
    assert len(group.hosts) == 2
    assert 'web01' in group.hosts
    assert 'web02' in group.hosts
    assert 'web03' not in group

# Generated at 2022-06-17 11:54:14.201301
# Unit test for method host_vars of class InventoryModule
def test_InventoryModule_host_vars():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inv_manager = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inv_manager)
    host = Host(name='localhost')
    inv_module = inventory_loader.get('constructed')
    inv_module.parse(inv_manager, loader, 'localhost,')
    hostvars = inv_module.host_vars(host, loader, inv_manager.processed_sources)
    assert hostvars['inventory_dir'] == 'localhost,'
   