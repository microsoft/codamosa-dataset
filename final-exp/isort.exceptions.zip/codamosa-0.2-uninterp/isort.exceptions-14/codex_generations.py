

# Generated at 2022-06-17 21:29:01.398120
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(kind=str, expected_kind=int)
    except LiteralSortTypeMismatch as e:
        assert e.kind == str
        assert e.expected_kind == int
        assert str(e) == "isort was told to sort a literal of type <class 'int'> but was given a literal of type <class 'str'>."


# Generated at 2022-06-17 21:29:04.272425
# Unit test for constructor of class UnsupportedSettings
def test_UnsupportedSettings():
    unsupported_settings = {
        "foo": {"value": "bar", "source": "config"},
        "baz": {"value": "qux", "source": "cli"},
    }
    error = UnsupportedSettings(unsupported_settings)
    assert error.unsupported_settings == unsupported_settings

# Generated at 2022-06-17 21:29:07.692106
# Unit test for constructor of class AssignmentsFormatMismatch
def test_AssignmentsFormatMismatch():
    try:
        raise AssignmentsFormatMismatch("a = 1\nb = 2")
    except AssignmentsFormatMismatch as e:
        assert e.code == "a = 1\nb = 2"

# Generated at 2022-06-17 21:29:11.056723
# Unit test for constructor of class InvalidSettingsPath
def test_InvalidSettingsPath():
    try:
        raise InvalidSettingsPath("test")
    except InvalidSettingsPath as e:
        assert e.settings_path == "test"


# Generated at 2022-06-17 21:29:15.147326
# Unit test for constructor of class IntroducedSyntaxErrors
def test_IntroducedSyntaxErrors():
    try:
        raise IntroducedSyntaxErrors("test")
    except IntroducedSyntaxErrors as e:
        assert e.file_path == "test"

# Generated at 2022-06-17 21:29:18.502720
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"


# Generated at 2022-06-17 21:29:20.996569
# Unit test for constructor of class FileSkipped
def test_FileSkipped():
    try:
        raise FileSkipped("message", "file_path")
    except FileSkipped as e:
        assert e.message == "message"
        assert e.file_path == "file_path"

# Generated at 2022-06-17 21:29:27.211577
# Unit test for constructor of class FileSkipSetting
def test_FileSkipSetting():
    file_path = "test_file_path"
    try:
        raise FileSkipSetting(file_path)
    except FileSkipSetting as e:
        assert e.file_path == file_path
        assert e.args[0] == f"{file_path} was skipped as it's listed in 'skip' setting" \
                            " or matches a glob in 'skip_glob' setting"

# Generated at 2022-06-17 21:29:36.597307
# Unit test for constructor of class ProfileDoesNotExist
def test_ProfileDoesNotExist():
    try:
        raise ProfileDoesNotExist("test")
    except ProfileDoesNotExist as e:
        assert e.profile == "test"

# Generated at 2022-06-17 21:29:39.461402
# Unit test for constructor of class LiteralSortTypeMismatch
def test_LiteralSortTypeMismatch():
    try:
        raise LiteralSortTypeMismatch(int, str)
    except LiteralSortTypeMismatch as e:
        assert e.kind == int
        assert e.expected_kind == str
